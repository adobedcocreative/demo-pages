(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[342,252,52,37],[396,252,52,37],[450,252,38,30],[255,252,85,73],[0,252,253,45],[302,0,182,250],[450,284,42,25],[0,0,300,250]]}
];


// symbols:



(lib.Add_UI_morph = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_none = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_preview = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_tile_1 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.bar = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.BG_300 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.fade = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.frame1b_300x250 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteRect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTyMAAAgnjMAu3AAAMAAAAnjg");
	this.shape.setTransform(160.9,58.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteRect, new cjs.Rectangle(10.9,-67.7,300,253.3), null);


(lib.whiteBox = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ar4UTMAAAgolIXxAAMAAAAolg");
	this.shape.setTransform(76.075,129.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteBox, new cjs.Rectangle(0,0,152.2,259.8), null);


(lib.whiteBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAvKMAAAheTMAu3AAAMAAABeTg");
	this.shape.setTransform(150,301.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteBG, new cjs.Rectangle(0,0,300,603.7), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.4824,406.9813,1,0.4316);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,231.4,971,351.20000000000005), null);


(lib.Tween31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E43E24").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(148.05,-175,1.987,0.4167);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,596.1,250);


(lib.Tween30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("AjTgwID9hWICqgYIiAE9g");
	this.shape.setTransform(0.0016,0.0051);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.2,-15.9,42.4,31.8);


(lib.Tween29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC3B1A").s().p("AuELxIOE3hIOFXhg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.1,-75.3,180.2,150.7);


(lib.Tween28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("Ah6h7ID0BIIi3Cvg");
	this.shape.setTransform(0.0029,-0.0206);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.2,-12.4,24.5,24.8);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4BBFE3").s().p("AqHodIUPAAIqIQ7g");
	this.shape.setTransform(-0.0209,0.03);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.8,-54.2,129.6,108.5);


(lib.Tween26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D01C").s().p("AvFNFIPF6JIPGaJg");
	this.shape.setTransform(0.0297,-0.0221);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96.6,-83.7,193.3,167.4);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape.setTransform(-0.0196,-31.5218);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_1.setTransform(9.4056,-17.5216);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_2.setTransform(-0.0196,-17.5216);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_3.setTransform(-9.4197,-17.5216);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_4.setTransform(18.8557,-3.5214);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_5.setTransform(9.4056,-3.5214);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_6.setTransform(-0.0196,-3.5214);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_7.setTransform(-9.4197,-3.5214);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_8.setTransform(-18.8699,-3.5214);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_9.setTransform(28.2809,10.4788);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_10.setTransform(18.8557,10.4788);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_11.setTransform(9.4056,10.4788);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_12.setTransform(-0.0196,10.4788);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_13.setTransform(-9.4197,10.4788);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_14.setTransform(-18.8699,10.4788);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_15.setTransform(-28.295,10.4788);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_16.setTransform(37.706,24.479);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_17.setTransform(28.2809,24.479);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_18.setTransform(18.8557,24.479);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_19.setTransform(9.4056,24.479);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_20.setTransform(-0.0196,24.479);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_21.setTransform(-9.4197,24.479);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_22.setTransform(-18.8699,24.479);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_23.setTransform(-28.295,24.479);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_24.setTransform(-37.7451,24.479);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_25.setTransform(4.7055,-24.4967);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_26.setTransform(-4.7196,-24.4967);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_27.setTransform(14.1306,-10.4965);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_28.setTransform(4.7055,-10.4965);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_29.setTransform(-4.7196,-10.4965);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_30.setTransform(-14.1448,-10.4965);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_31.setTransform(23.5808,3.5037);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_32.setTransform(14.1306,3.5037);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_33.setTransform(4.7055,3.5037);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_34.setTransform(-4.7196,3.5037);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_35.setTransform(-14.1448,3.5037);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_36.setTransform(-23.5699,3.5037);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_37.setTransform(33.0059,17.5039);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_38.setTransform(23.5808,17.5039);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_39.setTransform(14.1306,17.5039);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_40.setTransform(4.7055,17.5039);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_41.setTransform(-4.7196,17.5039);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_42.setTransform(-14.1448,17.5039);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_43.setTransform(-23.5699,17.5039);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_44.setTransform(-33.0201,17.5039);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_45.setTransform(42.4311,31.5041);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_46.setTransform(33.0059,31.5041);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_47.setTransform(23.5808,31.5041);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_48.setTransform(14.1306,31.5041);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_49.setTransform(4.7055,31.5041);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_50.setTransform(-4.7196,31.5041);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_51.setTransform(-14.1448,31.5041);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_52.setTransform(-23.5699,31.5041);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_53.setTransform(-33.0201,31.5041);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_54.setTransform(-42.4452,31.5041);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.1,-35,94.30000000000001,70);


(lib.Tween24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("Ah0h0IDpA9IipCsg");
	this.shape.setTransform(-0.0209,-0.0214);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.7,-11.7,23.4,23.4);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC3B1A").s().p("AhuhuIDdA6IigCjg");
	this.shape.setTransform(-0.0212,0.0038);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.1,-11.1,22.2,22.2);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#373535").s().p("AAZArIgxhJIAABJIgGAAIAAhVIAGAAIAxBJIAAhJIAGAAIAABVg");
	this.shape.setTransform(65.553,-0.0887,3.7483,3.7483);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#373535").s().p("AgUAjQgGgGgBgIQgBgEAAgRQAAgPABgGQABgIAGgFQAIgJAMAAQANAAAIAJQAGAFABAIQABAGAAAPQAAARgBAEQgBAIgGAGQgJAIgMABQgLgBgJgIgAgPgeQgFAFgBAGIgBATIABAUQABAGAFAFQAGAGAJAAQAKAAAGgGQAFgFABgGIABgUIgBgTQgBgGgFgFQgGgHgKABQgJgBgGAHg");
	this.shape_1.setTransform(34.2549,0.005,3.7483,3.7483);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#373535").s().p("AgCArIAAhVIAFAAIAABVg");
	this.shape_2.setTransform(13.452,-0.0887,3.7483,3.7483);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#373535").s().p("AgCArIAAhPIgaAAIAAgGIA5AAIAAAGIgaAAIAABPg");
	this.shape_3.setTransform(-4.9146,-0.0887,3.7483,3.7483);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#373535").s().p("AgUAjQgGgGgBgIQgBgEAAgRQAAgPABgGQABgIAGgFQAIgJAMAAQANAAAIAJQAGAFABAIQABAGAAAPQAAARgBAEQgBAIgGAGQgJAIgMABQgLgBgJgIgAgPgeQgFAFgBAGIgBATIABAUQABAGAFAFQAGAGAJAAQAKAAAGgGQAFgFABgGIABgUIgBgTQgBgGgFgFQgGgHgKABQgJgBgGAHg");
	this.shape_4.setTransform(-30.7777,0.005,3.7483,3.7483);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#373535").s().p("AAeArIAAhGIgaA6IgGAAIgbg6IAABGIgGAAIAAhVIAGAAIAeBBIAdhBIAGAAIAABVg");
	this.shape_5.setTransform(-63.8562,-0.0887,3.7483,3.7483);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.3,-16.3,154.6,32.6);


(lib.Transform_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Transform", "6px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Transform_txt, new cjs.Rectangle(0,0,30.5,15.5), null);


(lib.Share_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Share", "6px 'Segoe Pro'", "#B7472A");
	this.txt.name = "txt";
	this.txt.lineHeight = 9;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Share_txt, new cjs.Rectangle(0,0,18.6,12.8), null);


(lib.scene4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.BG_300();
	this.instance.setTransform(35,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene4, new cjs.Rectangle(0,0,300,251), null);


(lib.scene_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.frame1b_300x250();
	this.instance.setTransform(547,119);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene_1, new cjs.Rectangle(518,119,358.1,601), null);


(lib.right_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglAgIAAg/IBLAAIAAA/gAADAaIAdAAIAAgmIg/AAIAAAmIAdAAIAAgaIgIAIIgFgEIAPgPIAQAPIgEAEIgJgIgAgfgSIA/AAIAAgHIg/AAg");
	this.shape.setTransform(3.8288,3.2752);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeAfIAAgwIAMAAIAAgOIAxAAIAAAyIgMAAIAAAMgAgZAaIAnAAIAAgmIgnAAgAgMgRIAfAAIAAAeIAGAAIAAgmIglAAg");
	this.shape_1.setTransform(30.0792,3.3502);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAAAEIgcAdIgEgEIAdgdIgdgcIAEgEIAcAdIAdgdIAEAEIgdAcIAdAdIgEAEg");
	this.shape_2.setTransform(44.4544,3.3252);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeACIAAgDIA9AAIAAADg");
	this.shape_3.setTransform(17.479,3.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.right_icons, new cjs.Rectangle(0,0,47.8,6.7), null);


(lib.replaySub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Ready_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Ready", "6px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Ready_txt, new cjs.Rectangle(0,0,20.1,13.5), null);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCoICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh9QAAgJgGgDQgDgHgJAAQgHAAgGAHQgGADAAAJIAAAxQAAABgDACQAAADgCAAQgCAAgCgDQgCgCAAgBIAAg/QAAgJgHgEQgDgGgJAAQgIAAgHAGQgGAEAAAJIAAAzQgBABgCAAQgDAAgBgBIAAhDQAAgGgGgHQgGgEgJAAQgIAAgEAEQgCAAAAABQgGAGAAAGIAABAQAAADAAABQgBAAgDAAQgCAAgBAAQAAgBAAgDIAAh6QAAgJgGgEQgHgGgIAAQgJAAgDAGQgGAEAAAJIAACqQAAADgCAAQAAABgCAAQgDADgDgDQgDgEgCgGIgEgOQAAgCgCAAIgPgRIgBgCQgRgNgOAKIAAADQgGAGgCAFQgDAIAFAIIBWBtIADACQADAHAAAHIAAAfQAAACACAAQACACACAAg");
	this.shape.setTransform(14.1804,16.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcCoQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhtQgFgIADgIQACgGAGgFIAAgEQAOgJARANIABACIAPARQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAGADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAirQAAgIAGgEQADgGAJAAQAIAAAHAGQAGAEAAAIIAAB7IAAADIADAAIAEAAIAAgDIAAhAQAAgHAGgFQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQAEgEAIAAQAJAAAGAEQAGAGAAAHIAABCIAEABIADgBIAAgyQAAgKAGgDQAHgGAIAAQAJAAADAGQAHADAAAKIAAA/QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgxQAAgJAGgDQAGgHAHAAQAJAAADAHQAGADAAAJIAAB9IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_1.setTransform(14.1804,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCVICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh0QAAgIgGgEIAAgCQgDgEgJAAQgHAAgGAEIAAACQgGAEAAAIIAAAnQAAACgDACQAAADgCAAQgCAAgCgDQgCgCAAgCIAAg1QAAgIgHgFIAAgBQgDgGgJAAQgIAAgHAGIAAABQgGAFAAAIIAAApQgBABgCAAQgDAAgBgBIAAg3QAAgIgGgGQgGgEgJAAQgIAAgEAEIgCAAQgGAGAAAIIAAA1QAAACAAABQgBAAgDAAQgCAAgBAAQAAgBAAgCIAAhTQAAgIgGgGQgHgGgIAAQgGAAgGAGQgGAGAAAIIAACDQAAADgCAAQAAAAgCAAQgDADgDgDQgDgDgCgFIgEgPQAAgBgCAAIgPgTIgBgBQgRgNgOAJIAAAEQgGAFgCAGQgDAJAFAIIBWBsIADACQADAGAAAIIAAAfQAAACACAAQACACACAAg");
	this.shape_2.setTransform(14.1804,18.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#BCBCBC","#FCFCFC","#FFFFFF"],[0,0.259,1],-7.3,-14.5,1.8,9.6).s().p("AgcCVQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhsQgFgIADgJQACgGAGgFIAAgEQAOgJARANIABACIAPASQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAFADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAiDQAAgHAGgHQAGgGAGAAQAIAAAHAGQAGAHAAAHIAABTIAAADIADAAIAEAAIAAgDIAAg1QAAgIAGgGIACAAQAEgDAIgBQAJABAGADQAGAGAAAIIAAA3IAEABIADgBIAAgpQAAgHAGgGIAAgBQAHgGAIAAQAJAAADAGIAAABQAHAGAAAHIAAA2QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgoQAAgIAGgEIAAgCQAGgEAHAAQAJAAADAEIAAACQAGAEAAAIIAAB0IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_3.setTransform(14.1804,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,-1.2,28,35.6);


(lib.Percentage_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("89%", "6px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Percentage_txt, new cjs.Rectangle(0,0,15.5,13.5), null);


(lib.PageLayout_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Draw", "6px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PageLayout_txt, new cjs.Rectangle(0,0,17.8,15.5), null);


(lib.ON_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("On", "6px 'Segoe Pro'", "#B7472A");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ON_txt, new cjs.Rectangle(0,0,12.5,12.5), null);


(lib.Notes_txtcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Notes", "6px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Notes_txtcopy, new cjs.Rectangle(0,0,19.5,13.5), null);


(lib.Name_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Daniela Duarte", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Name_txt, new cjs.Rectangle(0,0,42.7,13.6), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.motion_graphics_2_bars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape.setTransform(-0.021,11.9776);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_1.setTransform(-0.021,-0.0225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_2.setTransform(-0.021,-12.0227);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.motion_graphics_2_bars, new cjs.Rectangle(-34.6,-14.9,69.2,29.8), null);


(lib.motion_graphics_1_bars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiYAdIAjg5IEOAAIAAA5g");
	this.shape.setTransform(19.3274,11.9789);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8D01C").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_1.setTransform(-2.2229,11.9789);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#203B6B").s().p("AiBAdIAAg5IEEAAIgjA5g");
	this.shape_2.setTransform(-21.5482,11.9789);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah0AdIAjg5IDGAAIAAA5g");
	this.shape_3.setTransform(22.9275,-0.0213);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8D01C").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_4.setTransform(4.9772,-0.0213);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#203B6B").s().p("AilAdIAAg5IFMAAIgjA5g");
	this.shape_5.setTransform(-17.9481,-0.0213);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhQAdIAjg5IB+AAIAAA5g");
	this.shape_6.setTransform(26.5025,-12.0214);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F8D01C").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_7.setTransform(12.1273,-12.0214);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#203B6B").s().p("AjJAdIAAg5IGTAAIgiA5g");
	this.shape_8.setTransform(-14.3731,-12.0214);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.motion_graphics_1_bars, new cjs.Rectangle(-34.6,-14.9,69.2,29.8), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.left_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKANIAMgNIgMgMIAFgEIAQAQIgQARg");
	this.shape.setTransform(51.0765,5.2502);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhEAyQgVAAgOgOQgPgPAAgVQAAgTAPgPQAOgPAVAAICJAAQAVAAAPAPQAOAPAAATQAAAVgOAPQgPAOgVAAgAA1gPQgHAHAAAIQAAAKAHAHQAHAHAJAAQAKAAAHgHQAHgHAAgKQAAgIgHgHQgHgHgKAAQgJAAgHAHg");
	this.shape_1.setTransform(11.9259,5.0252);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiAzIgRgRIAAhUIBnAAIAABlgAAaAOIAAAfIATAAIAAhZIgNAAIAAAnIg/AAIAAgnIgOAAIAABMIAOANIAHAAIAAgfgAgSAtIAmAAIAAgZIgmAAgAgZgLIAzAAIAAghIgzAAg");
	this.shape_2.setTransform(36.0762,5.3253);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgKANIAMgNIgMgMIAFgEIAQAQIgQARg");
	this.shape_3.setTransform(48.6264,5.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.left_icons, new cjs.Rectangle(0,0,52.2,10.5), null);


(lib.Insert_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Insert", "6px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Insert_txt, new cjs.Rectangle(0,0,18.5,15.5), null);


(lib.Home_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Home", "6px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Home_txt, new cjs.Rectangle(0,0,20.1,16), null);


(lib.greyicons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7472A").s().p("AgUANIgGAAIAAglIA2AAIAAAlIgjAAIgNAMgAgXAJIAHAAIAAAIIAIgIIAgAAIAAgeIgvAAg");
	this.shape.setTransform(96.3016,4.8308,1.1356,1.1356);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBE9E7").s().p("AjxA7QgFAAgDgDQgDgDAAgFIAAhfQAAgEADgDQADgEAFAAIHjAAQAFAAADAEQADADAAAEIAABfQAAAFgDADQgDADgFAAgAj3g1QgCADgBADIAABfQABADACADQACACAEAAIHjAAQAEAAACgCQACgDABgDIAAhfQgBgDgCgDQgCgDgEABInjAAQgEgBgCADg");
	this.shape_1.setTransform(114.3576,5.2122,0.9802,0.8814);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjnA7QgIAAgGgGQgHgGAAgKIAAhJQAAgJAHgHQAGgGAIAAIHPAAQAIAAAHAGQAGAHAAAJIAABJQAAAKgGAGQgHAGgIAAg");
	this.shape_2.setTransform(114.3576,5.2122,0.9802,0.8814);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7472A").s().p("AADAJIgGABIgHACIgHAEQgEACgBADIAAgEIABgHIACgGIAEgFIAFgEIAHgCIAGgBIAAgMIAVAUIgVAVgAgCgEIgDABIgFADIgDADIgEAEIgBAFIAKgFIALgBIAEAAIAAAGIALgMIgLgLIAAAGIgEAAg");
	this.shape_3.setTransform(59.0211,3.5509,1.1054,1.1054);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B7472A").s().p("AgYATIAAglIADAAIAAAjIArAAIAAgUIADAAIAAAWg");
	this.shape_4.setTransform(57.8051,6.0382,1.1054,1.1054);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EBE9E7").s().p("AieA7QgFAAgDgDQgDgDAAgFIAAhfQAAgEADgDQADgEAFAAIE+AAQAEAAADAEQADADAAAEIAABfQAAAFgDADQgDADgEAAgAingvIAABfQAAAJAJgBIE+AAQADAAACgCQADgDAAgDIAAhfQAAgDgDgDQgCgDgDABIk+AAQgJAAAAAIg");
	this.shape_5.setTransform(68.6895,5.2122,0.9871,0.8814);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiCA0QgIAAgGgFQgFgGAAgIIAAhBQAAgIAFgFQAGgGAIAAIEGAAQAHAAAGAGQAFAFAAAIIAABBQAAAIgFAGQgGAFgHAAg");
	this.shape_6.setTransform(68.6717,5.2001,1.12,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#494846").s().p("AgQAUIATgUIgTgTIAHgHIAaAaIgaAbg");
	this.shape_7.setTransform(5.0779,5.3164,0.8451,0.8451);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#494846").s().p("AgRAUIAVgUIgVgTIAHgHIAbAaIgbAbg");
	this.shape_8.setTransform(2.5637,5.3164,0.8451,0.8451);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.greyicons, new cjs.Rectangle(1.1,0,138.1,10.4), null);


(lib.Formulas_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Design", "6px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Formulas_txt, new cjs.Rectangle(0,0,22.1,15.5), null);


(lib.Excel_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("PowerPoint", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_txt, new cjs.Rectangle(0,0,34,17.3), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.Comments_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Comments", "6px 'Segoe Pro'", "#B7472A");
	this.txt.name = "txt";
	this.txt.lineHeight = 9;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Comments_txt, new cjs.Rectangle(0,0,32.4,12.8), null);


(lib.bottomicons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#797775").s().p("AgQAiIAAhDIAhAAIAABDg");
	this.shape.setTransform(142.4284,6.6252);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#676767").s().p("AgWAFIAAgJIAtAAIAAAJg");
	this.shape_1.setTransform(111.2279,6.3752);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#676767").s().p("AgXAEIAAgHIAvAAIAAAHg");
	this.shape_2.setTransform(180.179,6.6002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#676767").s().p("AgDAYIAAgvIAHAAIAAAvg");
	this.shape_3.setTransform(180.179,6.6002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ABABAB").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_4.setTransform(145.6284,6.3752);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ABABAB").s().p("AkqAEIAAgHIJVAAIAAAHg");
	this.shape_5.setTransform(145.7034,6.3752);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#606060").s().p("AgPAIIAPgPIAQAPg");
	this.shape_6.setTransform(3.4263,3.9501);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#606060").s().p("AgRACIAAgDIAjAAIAAADg");
	this.shape_7.setTransform(1.8262,9.4002);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#606060").s().p("AghACIAAgDIBDAAIAAADg");
	this.shape_8.setTransform(3.4263,7.7502);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#606060").s().p("AghACIAAgDIBDAAIAAADg");
	this.shape_9.setTransform(3.4263,6.1502);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#707070").s().p("AgLAKIAAgTIAXAAIAAATgAgEADIAJAAIAAgGIgJAAg");
	this.shape_10.setTransform(44.4519,5.4501);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#707070").s().p("AgaACIAAgDIA0AAIAAADg");
	this.shape_11.setTransform(44.3519,7.9002);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#707070").s().p("AgBAkIAAhHIADAAIAABHg");
	this.shape_12.setTransform(41.8518,6.4252);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#707070").s().p("AglAkIAAhHIBLAAIAABHgAgeAeIA9AAIAAg6Ig9AAg");
	this.shape_13.setTransform(43.4769,6.4252);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#747474").s().p("AgBAMIAAgXIADAAIAAAXg");
	this.shape_14.setTransform(97.9027,8.7502);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#747474").s().p("AgNACIAAgDIAbAAIAAADg");
	this.shape_15.setTransform(97.9027,9.8752);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#747474").s().p("AgVACIAAgDIArAAIAAADg");
	this.shape_16.setTransform(97.8777,5.0501);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#747474").s().p("AgmAFIAAgJIBNAAIAAAJg");
	this.shape_17.setTransform(97.9027,3.3001);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#747474").ss(0.7).p("AAXgVIgtAAQgFAAAAAFIAAAhQAAAFAFAAIAtAAQAFAAAAgFIAAghQAAgFgFAAg");
	this.shape_18.setTransform(97.9027,5.2251);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_19.setTransform(79.7524,8.3002);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_20.setTransform(79.7524,7.0752);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_21.setTransform(79.7524,5.8501);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_22.setTransform(79.7524,4.6501);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_23.setTransform(81.7775,7.9002);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_24.setTransform(81.7775,6.6502);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_25.setTransform(81.7775,5.4501);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_26.setTransform(81.7775,4.2501);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_27.setTransform(77.7524,7.9002);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_28.setTransform(77.7524,6.6502);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_29.setTransform(77.7524,5.4501);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_30.setTransform(77.7524,4.2501);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#707070").ss(0.7).p("AAAgdIAAA6");
	this.shape_31.setTransform(79.7524,6.6002);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#707070").ss(0.7).p("AgRgWQAAgFAEgCQAEgCAOAAIANAAIAAA8IgSAAQgRAAAAAH");
	this.shape_32.setTransform(81.5775,6.1501);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#707070").ss(0.7).p("AASgWQAAgFgEgCQgFgCgOAAIgMAAIAAA8IATAAQAQAAAAAH");
	this.shape_33.setTransform(77.9524,6.1501);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#747474").s().p("AgcAlQgIAAAAgIIAAg5QAAgIAIAAIA5AAQAIAAAAAIIAAA5QAAAIgIAAgAgdgcIAAA5IABACIA5AAIABgCIAAg5IgBgBIg5AAg");
	this.shape_34.setTransform(211.2044,6.2502);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#747474").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_35.setTransform(211.2044,3.8501);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#747474").s().p("AgBAKIAAgTIADAAIAAATg");
	this.shape_36.setTransform(211.2044,4.2501);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#747474").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_37.setTransform(211.2044,8.6752);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#747474").s().p("AgBAKIAAgTIADAAIAAATg");
	this.shape_38.setTransform(211.2044,8.2752);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#747474").s().p("AgBAGIAAgLIADAAIAAALg");
	this.shape_39.setTransform(213.6045,6.2502);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#747474").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_40.setTransform(213.2045,6.2502);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#747474").s().p("AgBAGIAAgLIADAAIAAALg");
	this.shape_41.setTransform(208.7794,6.2502);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#747474").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_42.setTransform(209.1794,6.2502);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_43.setTransform(63.6272,8.4752);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_44.setTransform(59.6021,8.4752);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_45.setTransform(63.6272,4.4251);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_46.setTransform(59.6021,4.4251);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#C8C6C4").s().p("AhaBCIAAiDIC1AAIAACDg");
	this.shape_47.setTransform(43.4769,6.6502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottomicons, new cjs.Rectangle(0,0,214.9,13.3), null);


(lib.AutoSave_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("AutoSave", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(3.75,8.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.AutoSave_txt, new cjs.Rectangle(1.8,6.5,28.7,14), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Add_UI_Tile_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#898989").ss(1,1,1).p("AqJlhIUTAAIAALDI0TAAg");
	this.shape.setTransform(40.375,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// flash0.ai
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#7AF4F9").s().p("AjcDiIAAh9QAAgcATgSQASgSAbAAIA9AAIAAkFIC+AAIAAEFIA+AAQAbAAASASQATASAAAcIAAB9g");
	this.shape_1.setTransform(72.3346,22.586,0.1951,0.1951);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#873273").s().p("AjcDiIAAh9QAAgcASgSQASgSAbAAIA/AAIAAj8IgBgJIC+AAIAAEFIA+AAQAbAAASASQATATAAAbIAAB9g");
	this.shape_2.setTransform(82.1594,22.586,0.1951,0.1951);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#7AF4F9").s().p("ABvGOQgZAAgRgSQgSgTAAgbIAAh8IB8AAQAbAAASgTQARgTAAgaIAAi2QAAgRgJgKQgIgKgQAAQgMAAgIAKQgJAKAAARIAAAbQAAAZgSASQgTATgbAAImaAAQg1AAglglQglgkAAg1IAAlEIDAAAIgBALIAAC+QAAAZASARQARARAaAAIFdAAQAbAAASgRQARgRAAgZIAAi+IgBgLIC/AAIgBALIAAKQQAAA2gkAlQgkAlg1AAg");
	this.shape_3.setTransform(49.1337,25.9471,0.1951,0.1951);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8D3379").s().p("AieDiIAAh+QAAgaASgTQATgTAZAAQAcAAASgSQATgSAAgZIgCjHIDAAAIgBALIAAE5QAAA0gmAlQglAlg1AAg");
	this.shape_4.setTransform(24.7377,22.586,0.1951,0.1951);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#7AF4F9").s().p("AkJDiQg1gBgkgjQgkgkgBg2IABlEIC8AAQgBARALAPQAPASAYAAIEzAAQAYAAAPgSQALgPgBgRIC8AAIAAAlQABA/glAgQgmAhhPAAImHAAQgZABgOAQQgLAOABATQgBATALANQAOARAZAAIIfAAIAAB6QAAAbgSATQgSASgaAAg");
	this.shape_5.setTransform(4.6784,22.586,0.1951,0.1951);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7AF4F9").s().p("AiZAZQgYAAgPgSQgLgOABgRIGVAAQABARgLAOQgPASgYAAg");
	this.shape_6.setTransform(4.6784,18.6834,0.1951,0.1951);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#8D3379").s().p("ADtE3IAAhdQAAgbgRgSQgSgTgbAAIldAAQgbAAgSATQgRASAAAbIAABdIi+AAIAAjcQAAg1AlgkQAlgjA0AAIGdAAQAaAAASASQASARAAAaIAAAkQAAALAJAIQAIAIALAAQAQAAAJgIQAJgIAAgLIAAk2QAAgaATgTQATgTAaAAIB+AAIAAJtg");
	this.shape_7.setTransform(78.569,-18.7864,0.1951,0.1951);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#8D3379").s().p("AlbCuIAAjaQAAg1AmgmQAmgmA1AAII2AAIAACBQAAAZgSATQgTARgbAAIl5AAQgbAAgSASQgSASAAAaIAABfg");
	this.shape_8.setTransform(55.3437,-16.1131,0.1951,0.1951);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#423273").s().p("ADuE2IAAhbQAAgdgSgTQgSgTgbAAIldAAQgbAAgRATQgSATAAAdIAABbIi+AAIAAprIB9AAQAaAAAUASQASATABAZIAAE3QgBAJAJAJQAIAIAKAAQAPAAAMgIQAJgJAAgJIAAgkQAAgbASgRQASgRAbAAIGcAAQA1gBAlAkQAkAkAAA0IAADcg");
	this.shape_9.setTransform(32.1233,-18.7717,0.1951,0.1951);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#8D3379").s().p("ACOCsIAAhdQABgbgTgSQgRgSgbAAIkdAAQgbAAgSASQgSASgBAbIAABdIi8AAIAAjaQAAgzAlglQAlglA0AAIFdAAQAZAAATASQASATAAAaIAAAjQAAALAJAIQAJAIAPAAQAOAAAIgIQAHgIAAgLIAAhiIE8AAIAAB9QAAAbgTASQgSARgbAAIg+AAIAACcg");
	this.shape_10.setTransform(5.5369,-16.0838,0.1951,0.1951);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#443379").s().p("ADbECQgEgWgQgPQgSgQgZAAIi7AAQgXAAgRAQQgSAPgEAWIi/AAIAAlHIg9AAQgbAAgSgSQgTgSAAgcIAAh8ID9AAQAaAAASASQATATAAAZIAAE1QAAALAIAJQAJAJAKAAQAQAAAKgJQAJgJAAgLIAAgiQAAgaATgTQASgTAaAAID7AAQA1AAAkAlQAmAlgBA1IAABzg");
	this.shape_11.setTransform(76.0177,13.1466,0.1951,0.1951);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#443379").s().p("ACtB5QgDgXgRgPQgRgPgYAAIldAAQgXAAgQAPQgRAPgEAXIjAAAIAAhzQAAgzAlglQAmgmA0ABIGaAAQAbgBATATQASARAAAcIAAAiQAAAMAJAIQAIAIAMAAQAPAAAJgIQAJgIAAgMIAAgiQAAgcATgRQASgTAbABIC8AAQAcgBASATQASARAAAcIAAB8IhAAAQgWAAgSAPQgSAPgEAXg");
	this.shape_12.setTransform(50.363,15.8345,0.1951,0.1951);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#443379").s().p("Ah+EDIABgyIi9AAIAAiAQAAgaATgSQASgSAbAAIB9AAIABhLQABhNgBAAQAAg0AkglQAlgkAzAAIE7AAIAAB9QAAAbgSATQgTATgbAAIh8AAQgbAAgRASQgTASABAaIAAB9QgBAKAJAIQAIAJALAAQAOAAALgJQAJgIABgKIAAgmQgBgZATgTQASgSAYAAICAAAIAAB/QAAAbgSASQgTASgbAAIh8AAQgYAAgRAOQgRAOgDAWg");
	this.shape_13.setTransform(26.5621,13.1368,0.1951,0.1951);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#443379").s().p("ADLB5QAAgSgLgPQgOgTgZAAIkyAAQgZAAgOATQgLAPAAASIi7AAIAAixQAAgbATgSQASgSAaAAIA8AAQAbgBATATQAUARAAAaIAAAkQgBANAKAIQAJAHAMAAQAMAAAJgHQAKgIAAgNIAAgkQABgaASgRQASgTAaABIFWAAQA1gBAkAlQAlAkAAA1IAABzg");
	this.shape_14.setTransform(4.6881,15.8345,0.1951,0.1951);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#7AF4F9").s().p("AksCtQg0AAglgkQglgkAAg1IAAjcIC+AAIAABfQAAAbARARQASASAbAAIFdAAQAbAAASgSQARgRAAgbIAAhfIC+AAIAADcQAAA1glAkQgkAkg1AAg");
	this.shape_15.setTransform(78.569,-9.3372,0.1951,0.1951);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#433276").s().p("Ak1CJQgmglAAg0IAAjdIC/AAIAABfQAAAbASATQASATAbAAIF5AAQAbAAATARQASARAAAbIAAB9Il7AAQgaAAgSgSQgRgTgBgZIAAgdQAAgQgJgJQgJgKgQAAQgMAAgIAKQgJAKAAAQIAAAcQAAAagSASQgSATgaAAQg2AAglglg");
	this.shape_16.setTransform(55.3437,-9.3226,0.1951,0.1951);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#7AF4F9").s().p("AktCtQg0ABgkglQglgkAAg0IAAjdIC+AAIAABfQAAAbASARQARASAbAAIFdAAQAbAAASgSQASgRAAgbIAAhfIC9AAIAADdQAAA0gkAkQglAlg1gBg");
	this.shape_17.setTransform(32.1233,-9.3372,0.1951,0.1951);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#7AF4F9").s().p("ACvCtQgaAAgTgSQgTgSAAgbIAAgbQAAgjgeAAQgOAAgJAJQgJAKAAAQIAAAbQAAAbgSASQgTASgYAAIleAAQg0ABglglQglgmAAgzIAAjcIC8AAIAABfQAAAbATASQASATAbgBIEdAAQAaABASgTQASgSAAgbIAAhfIC+AAIAABfQAAAbATASQASATAZgBIB+AAIAAB8QAAAbgSASQgSASgaAAg");
	this.shape_18.setTransform(6.1467,-9.3372,0.1951,0.1951);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_3
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AqFFkIAArHIULAAIAALHg");
	this.shape_19.setTransform(39.95,0.825);

	this.timeline.addTween(cjs.Tween.get(this.shape_19).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_4, new cjs.Rectangle(-25.6,-35.8,132,72.69999999999999), null);


(lib.Add_UI_Tile_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#898989").ss(1,1,1).p("AqJlhIUTAAIAALDI0TAAg");
	this.shape.setTransform(40.375,0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AqFFkIAArHIULAAIAALHg");
	mask.setTransform(39.9506,0.8212);

	// flash0.ai
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#714470").s().p("AgPARQgHgHAAgKQAAgKAGgGQAGgHAKAAQAKAAAGAHQAHAGAAAKQAAAJgHAHQgGAHgKAAIAAABQgJAAgGgHg");
	this.shape_1.setTransform(41.2113,27.1728,0.2983,0.2983);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#71446F").s().p("AACAfQgKAAgLgLQgKgLAAgLQAAgLAIgIQAKgKAMABQAOABAIAIQAIAJgBANQAAANgIAJQgIAIgLAAIgBAAg");
	this.shape_2.setTransform(49.7666,22.9483,0.2983,0.2983);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#71436F").s().p("AAAAiQgPAAgKgKQgJgKAAgOQAAgOAKgKQALgJAOAAQAOgBALAMQAKALgBANQgBAOgKAJQgJAJgPAAIAAAAg");
	this.shape_3.setTransform(45.1059,25.0459,0.2983,0.2983);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#71446F").s().p("AAAAeQgLgBgJgJQgJgJABgLQAAgMAJgIQAIgJALAAQAMAAAIAJQAKAJgBAMQAAALgJAJQgJAJgLAAIAAAAg");
	this.shape_4.setTransform(109.009,54.6871,0.2983,0.2983);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#71446F").s().p("AgVAWQgJgJAAgNQAAgLAKgKQAJgJALAAQANAAAJAKQAJAJAAANQAAAMgJAJQgJAIgNAAQgMAAgJgJg");
	this.shape_5.setTransform(94.9121,47.4221,0.2983,0.2983);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#71436F").s().p("AAAAiQgOABgKgLQgKgKAAgOQAAgNAKgKQAKgJAOgBQAPgBALAMQAJAKAAANQABAMgKALQgKAKgNAAIgDAAg");
	this.shape_6.setTransform(94.9501,43.3959,0.2983,0.2983);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#714470").s().p("AAAAXQgJAAgHgHQgGgHAAgJQABgXAVAAQAKAAAHAHQAGAHAAAJQAAAKgHAHQgHAHgIAAIgBgBg");
	this.shape_7.setTransform(92.026,-1.9302,0.2983,0.2983);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#71446F").s().p("AgSAUQgIgJAAgLQAAgLAHgHQAIgIALAAQAKgBAJAJQAIAIAAAKQABALgJAIQgIAHgLABIgBAAQgJAAgIgHg");
	this.shape_8.setTransform(90.9375,-16.9286,0.2983,0.2983);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#71436F").s().p("AAAAeQgMAAgIgJQgJgJAAgMQAAgNAKgJQAJgIAKABQANAAAIAIQAIAIABAOQAAAMgJAJQgJAIgLAAIgBAAg");
	this.shape_9.setTransform(64.3848,11.7705,0.2983,0.2983);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#71446F").s().p("AACAfQgKAAgLgLQgKgLAAgLQgBgLAJgJQAKgJALABQAOAAAIAJQAIAIAAANQAAANgIAJQgIAJgLAAIgBAAg");
	this.shape_10.setTransform(100.588,-6.1549,0.2983,0.2983);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#71436F").s().p("AAAAiQgPAAgJgKQgLgKABgOQAAgNAKgKQAKgJAOgBQAPgBAKAMQAKAKAAAMQAAANgKALQgJAKgNAAIgDAAg");
	this.shape_11.setTransform(95.9268,-4.0551,0.2983,0.2983);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#72436F").s().p("ABjGrIiNgiIhxgYQgagGgugIIhIgNIhrgVIgqgLQgJgDACgGQACgHAIAAQA8AABJAHQBeAJBzAVICQAcIAEABQABAAAAAAQABAAAAAAQABgBAAAAQABAAAAAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIgDgEQiFjzhqkBQgJgVAAgEQgCgNAHgJQAGgJANgEQBegXBlghQDFhAC2hYQAQgIAFgBQALgCAKAHQASAKgBAUQAAAQgUAKQjKBfjVBDQhHAWhHASQgHACgCAEQgBADADAHQA/CRAzBpQBPCjBCB3QAJARgLAPQgJALgMAAIgJgBg");
	this.shape_12.setTransform(84.6842,-19.6973,0.2983,0.2983);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#71436F").s().p("Al7FpQgZgKAKgZIDDngQAGgQAMgDQALgDANAKIDJCgIAsiiQAhh1ATg7QAFgPAPgCQAMgCAJAPQBEBqBJBjIBHBdQAIALgFAJQgEAFgJgBQgDAAgGgHQhHhUhDhYIhBhVQgEAKgEAQIhUEpQgFAQgKAEQgLADgNgKIjAiTIgHgFQgEgBgEAIQgnBrgpBmQg1CFgvBnQgGAKgIAEQgFADgFAAQgEAAgEgCg");
	this.shape_13.setTransform(3.0202,23.9911,0.2983,0.2983);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#71436F").s().p("Al7FpQgZgKAKgZIDDngQAGgQAMgDQALgDANAKIDJCgIAsiiQAhh1ATg7QAFgPAPgCQAMgCAJAPQA9BhBPBsIBIBdQAIALgGAJQgDAFgJgBQgDAAgGgHQg/hKhLhiIhBhVQgEALgEAPIgHAaIgpCSIgkB9QgFAQgKAEQgLADgNgKIjAiTIgIgFQgDgBgEAIQgeBSgyB/Qg2CIgvBkQgFAKgIAEQgFADgEAAQgFAAgEgCg");
	this.shape_14.setTransform(101.8061,6.1952,0.2983,0.2983);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#714470").s().p("AgQARQgGgIAAgJQABgLAGgGQAGgGAJABQAKAAAHAHQAGAHAAAIQAAAKgHAHQgHAHgJAAQgJAAgHgHg");
	this.shape_15.setTransform(64.3848,80.7387,0.2983,0.2983);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#71446F").s().p("AgSAUQgIgJAAgLQAAgLAHgIQAIgHALAAQAKgBAJAJQAIAIAAAKQABAKgJAIQgIAIgLABIgBAAQgJAAgIgHg");
	this.shape_16.setTransform(63.2963,65.7414,0.2983,0.2983);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#71436F").s().p("AgUAVQgJgJAAgMQAAgNAKgJQAJgIAKABQANAAAIAIQAIAJABAOQAAALgJAJQgJAJgMAAQgMAAgIgKg");
	this.shape_17.setTransform(67.398,69.8196,0.2983,0.2983);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#71446F").s().p("AgTAUQgKgLAAgLQgBgLAJgJQAKgJALABQAOAAAIAJQAIAIAAANQAAANgIAJQgIAJgMAAQgKAAgLgLg");
	this.shape_18.setTransform(72.9468,76.5147,0.2983,0.2983);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#71436F").s().p("AAAAiQgOAAgKgKQgLgKABgOQAAgNAKgKQAKgKAOgBQAPAAAKAMQAKAKAAAMQAAANgJALQgKALgNAAIgDgBg");
	this.shape_19.setTransform(68.2856,78.6083,0.2983,0.2983);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#714470").s().p("AAAAXQgJAAgHgHQgGgHAAgJQABgXAVAAQAKABAHAGQAGAHAAAJQAAAKgHAHQgHAHgIAAIgBgBg");
	this.shape_20.setTransform(0.8981,73.8779,0.2983,0.2983);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#71446F").s().p("AgJAaQgKgDgFgLQgEgKADgKQACgKALgFQALgFAKADQALAEAFAKQAEAKgEAKQgDAKgLAFQgGADgGAAIgIgBg");
	this.shape_21.setTransform(-14.8853,54.324,0.2983,0.2983);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#71436F").s().p("AgKAbQgLgDgFgMQgGgLAEgLQAEgLAMgFQAMgFALAEQAMAEAFAMQAFALgEAKQgIAUgSAAQgGAAgHgDg");
	this.shape_22.setTransform(-20.117,56.8153,0.2983,0.2983);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#72436F").s().p("AEyIiQgPgGgDgWQgWjbAJjiQADg/AHhUQABgIgDgCQgDgDgHAAQigALhyAMQivATiLAYQgUADgKgQQgKgPALgQIBPh7IA9hiQAagpAwhVIA4heIAYgkQAGgIAFAEQAGAEgDAIQgUA4gfBDQgnBTg7BoQgeA0guBLIgCADQgBABAAAAQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQABABAAAAQABAAAAAAQABAAAAAAIAFgBQEWgsERgNIAOgBQAIAAAFABQANACAGAKQAHAJgCANQgKBfgDBsQgGDOAWDKIABAWQgCAMgKAGQgKAJgLAAQgGAAgGgCg");
	this.shape_23.setTransform(104.724,36.914,0.2983,0.2983);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#71446F").s().p("AgHAaQgLgEgFgJQgGgJAEgLQAEgKAKgGQAIgGALAEQALAEAFAKQAFAKgDAJQgDALgKAFQgGADgGAAIgIgBg");
	this.shape_24.setTransform(24.0325,-30.0305,0.2983,0.2983);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#71436F").s().p("AgIAdQgLgEgHgNQgGgKAFgLQAEgMALgFQAKgGALAEQAMAFAGALQAGALgEAMQgFALgKAFQgHADgHAAIgIgBg");
	this.shape_25.setTransform(18.5198,-31.777,0.2983,0.2983);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#71446F").s().p("AgBAbQgKgBgJgIQgHgHABgLQACgNAIgHQAJgHAKABQAKAAAIAJQAHAJgBAKQgBAMgIAHQgHAGgJAAIgDAAg");
	this.shape_26.setTransform(-17.31,-30.8901,0.2983,0.2983);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#71436F").s().p("AgDAeQgMgBgIgJQgIgKACgLQABgNAKgIQAKgJAMACQAMACAHAJQAIAKgBALQgBAMgLAJQgHAGgKAAIgEAAg");
	this.shape_27.setTransform(-17.8098,-25.1284,0.2983,0.2983);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#71446F").s().p("AgJAaQgKgDgFgLQgEgKADgKQACgKALgFQALgFAKADQALAEAFAKQAEAKgEAKQgDAKgLAFQgGADgGAAIgIgBg");
	this.shape_28.setTransform(-8.9185,-5.344,0.2983,0.2983);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#71436F").s().p("AgKAbQgLgDgFgMQgGgLAEgLQAEgLAMgFQAMgFALAEQAMAEAFAMQAFALgEAKQgIAUgSAAQgGAAgHgDg");
	this.shape_29.setTransform(-14.1502,-2.8527,0.2983,0.2983);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#72436F").s().p("AExIiQgPgGgCgWQgWjiAJjbQADhPAHhEQABgIgDgCQgDgDgHAAQihALhxAMQivATiMAYQgTADgKgQQgKgPAKgQIBQh7IA8hiQAPgXAXgoIAlg/IA3heIAZgkQAGgIAFAEQAFAEgCAIQgSAzgiBIQgmBTg8BoQgVAmg2BZIgCADQgBABAAAAQAAABAAAAQAAABAAAAQAAABAAAAQABABAAAAQABABAAAAQABAAAAAAQABAAAAAAIAFgBQEWgsERgNIANgBQAJAAAFABQANACAGAKQAGAJgBANQgKBfgDBsQgGDLAWDNIABAWQgCAMgKAGQgKAJgLAAQgGAAgHgCg");
	this.shape_30.setTransform(-6.8886,-9.8177,0.2983,0.2983);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#71446F").s().p("AgSAUQgIgJAAgLQgBgLAIgHQAHgIAMAAQAKAAAIAIQAJAIAAAKQABALgJAIQgIAHgLABIgCAAQgJAAgHgHg");
	this.shape_31.setTransform(-0.176,58.88,0.2983,0.2983);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#71436F").s().p("AgUAVQgJgJAAgMQAAgNAKgIQAJgJAKABQANAAAIAIQAIAJABAOQAAALgJAJQgJAJgMAAQgMAAgIgKg");
	this.shape_32.setTransform(5.8505,29.1857,0.2983,0.2983);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#71446F").s().p("AACAfQgKAAgLgLQgKgLAAgLQgBgLAJgJQAKgJALABQAOAAAIAJQAIAIAAANQAAAOgIAJQgHAIgMAAIgBAAg");
	this.shape_33.setTransform(9.46,69.6533,0.2983,0.2983);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#71436F").s().p("AAAAjQgOgBgKgJQgKgLAAgOQAAgNAKgLQAKgJAOAAQAPgCAKAMQAKALAAANQAAAMgJAKQgKAMgOAAIgCAAg");
	this.shape_34.setTransform(4.7992,71.7592,0.2983,0.2983);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#72436F").s().p("ABjGqIj9g5IhIgOIhJgNIhrgVIgqgLQgJgDACgGQACgHAIAAQAygBBUAIQBdAIBzAVICQAcIAEACQABAAABAAQAAAAABAAQAAgBABAAQAAAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIgDgEQiIj6hnj5QgIgVgBgFQgCgMAHgKQAGgJANgDQBhgYBiggQC/g+C8haQAQgIAFgBQALgCAKAHQASAJgBAUQAAARgUAJQjIBfjXBDQhUAag5APQgIACgBADQgCADADAHQA8CMA2BuQBLCeBGB8QAKARgMAQQgIAKgNAAIgJgBg");
	this.shape_35.setTransform(-6.4437,56.1178,0.2983,0.2983);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#72436F").s().p("AkKNFQgCgLAIgHQAvgrBHg1QBOg4B0hFICLhNIAFgCQACgBAAgDQABgEgCgDIgFgDQjxjhjakCIgLgNQgHgHgDgGQgIgQABgRQABgSAJgOQBDhmBKiBQCHjuBxkLQAKgWAEgFQAIgNAMACQAVAAAJAbQAIAWgMAcQh+EiiUEAQg3BdgwBLQgFAIAAAGQABAGAGAHQCBCTBfBjQCLCQCCB4QARAQgDAdQgCAcgSAIIiMBEIhtA5QgaANgqAZIhFAnIhnA5IgqASIgEABQgFAAgCgHg");
	this.shape_36.setTransform(30.8115,28.7461,0.2983,0.2983);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#72436F").s().p("AkKIYQgCgHAIgEQAqgaBMgkQBTgnBvgpICLgyQAGgBABgCQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAIgEgDQjuiOjeinIgLgIIgJgJQgIgJABgMQAAgLAKgJQBDhCBKhSQCHiYBxisQAJgOAEgDQAJgIAMABQAUAAAKARQAHAOgMASQh/C8iTCiQg4A9guAvQgFAFAAAEQAAADAGAFQB/BcBiBBQCSBiB7BHQAQALgCASQgDATgRAFIiMArQhIAZglALQgbAJgpAQIhFAZIhnAkIgqAMIgFABQgFAAgBgFg");
	this.shape_37.setTransform(48.3357,69.3793,0.2983,0.2983);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#704470").s().p("AAAAXQgKAAgGgHQgHgGAAgKQAAgJAHgHQAHgGAKAAQAKABAHAHQAGAGAAAJQgBAKgGAGQgHAGgJAAIgBAAg");
	this.shape_38.setTransform(88.7746,97.849,0.2983,0.2983);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#71446F").s().p("AgEAZQgJAAgFgIQgGgIAAgKQAAgKAIgHQAHgHALAAQAKABAGAHQAHAGAAALQgBALgIAHQgIAIgLAAIgBgBg");
	this.shape_39.setTransform(45.201,-9.8661,0.2983,0.2983);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#71446F").s().p("AgaABQAAgKAIgIQAIgJAKAAQALABAIAIQAIAIAAAKQgBAMgHAHQgIAHgMAAQgZAAAAgag");
	this.shape_40.setTransform(48.6474,-5.4288,0.2983,0.2983);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#71446F").s().p("AgEAZQgJAAgFgIQgGgIAAgKQAAgKAIgHQAHgHALAAQAKABAGAHQAHAGAAALQgBALgIAHQgIAIgLAAIgBgBg");
	this.shape_41.setTransform(45.201,43.8351,0.2983,0.2983);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#71446F").s().p("AgaABQAAgKAIgIQAIgJAKAAQALABAIAIQAIAIAAAKQgBAMgHAHQgIAHgMAAQgZAAAAgag");
	this.shape_42.setTransform(48.6474,48.2724,0.2983,0.2983);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#71446F").s().p("AgSATQgIgJABgKQABgaAZAAQAaAAgBAbQAAAMgHAHQgHAHgMAAQgKgBgIgHg");
	this.shape_43.setTransform(91.9515,89.585,0.2983,0.2983);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#71446F").s().p("AgBAbQgLAAgIgHQgHgHAAgMQgBgKAJgJQAJgJAKAAQANAAAIAIQAIAIgBALQAAAMgJAIQgIAIgLAAIgBgBg");
	this.shape_44.setTransform(99.4696,93.434,0.2983,0.2983);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#71436F").s().p("AgXAYQgJgKAAgOQAAgPAJgJQAJgJAOAAQAPAAAJAJQAJAJAAAPQAAAPgKAKQgJAJgOAAQgOAAgJgKg");
	this.shape_45.setTransform(25.3168,2.2684,0.2983,0.2983);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#71436F").s().p("AAAAiQgOAAgKgKQgKgKAAgOQAAgNAKgKQAKgJAOgBQAPgBAKAMQAKAKAAAMQAAANgJALQgKAKgNAAIgDAAg");
	this.shape_46.setTransform(21.8494,43.5451,0.2983,0.2983);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#71436F").s().p("AAvBSIg+hxQgEgIgDgBQgEgCgIAEQgNAFgYAXIgTARQgUAQgQgSQgPgPATgRIAfgdQATgRAQgJQAQgKASgCQAZACAOAcIAdBAIAQAjQAEAIACAAQACABAFgIIAjgyQAEgIAEgBQAIgCAEAEQAFAFgEALQgIAVgQAaIgbAqQgIALgJAAQgJAAgHgNg");
	this.shape_47.setTransform(77.5649,33.4002,0.2983,0.2983);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#71436F").s().p("AAaBcQgvgEg4gJQgNgFgIABQgGAAAAgJQABgGAGABIAtACIAAgBIAqAAQAGAAABgCQABgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAIgDgDQgvg1gpg5QgFgGgBgDQgCgGADgFQAGgKAOgBQA/gIBNAJQAKABATAEQAJACAFAIQADAIgCAJQgFARgUgDQgwgIhFgEIgEgBQAAAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAABQgBACAEAGQAsA7ApAtQALANgFALQgEAHgGABIgGABIgHgBg");
	this.shape_48.setTransform(-16.9346,77.9085,0.2983,0.2983);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#71436F").s().p("AAaBdQgzgFgzgJQgOgEgHAAQgIAAABgIQABgGAHAAIAsACIAAAAIAqAAQAGAAABgDQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIgEgDQgyg4gmg1IgFgKQgCgFADgGQAEgJAPgCQBAgIBMAJQAKABAUAFQAJABAEAIQAEAIgDAKQgEARgVgEQg0gIhAgEQgHgBgBACQgBADAEAFQApA2AsAyQAMANgGAMQgDAGgHACIgFAAIgIAAg");
	this.shape_49.setTransform(35.9295,92.1356,0.2983,0.2983);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#71436F").s().p("AhJCMQgHgHgBgJIgNiqQgBgQALgGQALgFALAHQBNA1ARANQAEABADgBIgJgTIgKgUIgmhPIgCgHQgFgMALgGQAJgFAHALQAWAhAMAWQAbAxAdA7QAFALgFAJQgFAIgNAAQgOABgQgHQgJgEgSgLQgXgPgigWQgHgFgCABQgBAAAAABQgBAAAAAAQAAABAAABQAAAAAAABIAAAEIAJB5QACAWgRACIgDAAQgHAAgGgFg");
	this.shape_50.setTransform(55.8479,-19.3824,0.2983,0.2983);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#71436F").s().p("AEiGAIgWgGIhHgSIiOgcQgLgDgagDQhQgJghgBQgegCALgcQAthuAQhEQAOg2AEgrQABgKgLgCIiOgrIhwgiQgOgEgDgLQgEgKAJgMQA3hNASh1IALg7QACgMAGgFQAHgFAMABQAKABAIAHQAHAIAAALQgBAbgLA+QgRBWgsBHIDzBJQAXAGgEAYQgTB9gqCPIgFANQgDAHADAEQACAEAIAAIANAAICHAYQAzAKA7AQIBZAZIAIABIADADQAFAPgFAMQgBAAAAAAQAAABgBAAQAAAAgBAAQgBABAAAAQgJgEgNgDg");
	this.shape_51.setTransform(35.9229,-12.8209,0.2983,0.2983);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#72436F").s().p("AgUFjQg0guhghiIhAhBQgNgOADgNQADgNATgEQAkgKBDgOIBegWIB0gaIBAgOQAGgCgBgDQAAgBgEgFQgfguggg5Qg0hggehjIgGgRQgEgLABgJQABgPAGgHQAFgGAMgDQAJgCAKAGQAKAHAEAKIAfBKIAfBJQA2B4A7BWQAIAMgBAHQAAAMgIAJQgHAIgNADIl3BJQgHACAAADQgBADAFAFQBbBeAvA3IAcAiQAMAPgKAKQgFAFgEAAQgHAAgJgIg");
	this.shape_52.setTransform(27.2681,68.9143,0.2983,0.2983);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#71436F").s().p("AJ0DwIkDiFIjRhrQjEhnhOgkQgHgDgDACQgBACgBAGQgLA2gPA3IgOAtQgEALgIAEQgJADgKgEQhhgkhtg4QhBghiIhRQgagQgQgUQgGgIABgEQAAgLALgHQAKgHALADQASAGAVAMIAjAYQA3AnBqA4QBOApBaAmQAIADADgCQABgCACgGQAShCANg8IAFgbQADgLAKgFQAKgFAKAFIBPAtQBBAmChBSQAgAQCJBIIEtCfQAOAIgFAMQgEAHgGACIgFABQgEAAgEgCg");
	this.shape_53.setTransform(73.8477,18.9947,0.2983,0.2983);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#71436F").s().p("Al7FoQgYgKAJgYIDDngQAGgQAMgDQALgEANALIChB/IAoAhIAsiiQAih6ASg2QAFgQAPgBQAMgCAJAPQBBBnBMBlIBHBeQAIALgFAJQgEAFgJgBQgDAAgGgHQhJhXhBhWIhBhVQgHASgIAjIhNEPQgFAQgKAEQgLADgNgKIjAiTIgHgFQgEgBgEAIQgsB3gkBaQgzCCgxBpQgFALgJAEQgFACgEAAQgFAAgEgCg");
	this.shape_54.setTransform(13.4502,91.0075,0.2983,0.2983);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#72436F").s().p("AA7H5QgEgKAMgJQAugjAvghIA7gnQAIgFABgDQAAgDgHgHQhZhch6iFIjPjjIhXhgQgVgWATgUQBxh+CDh5QAWgTAdgPQAGgDAKAAQALgCAHAOQAGAOgHAMQgYAmglAdQhPA9h7CAQgFAGAAAEQAAAEAFAFID9ERQCkCyBZBnQAZAbggATIhbA3Qg0AfgpAVQgMAGgFABIgDAAQgKAAgFgJg");
	this.shape_55.setTransform(61.7884,44.4095,0.2983,0.2983);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#71436F").s().p("ABoMXQgaghgjg7Qg/hshWi4QgagwgKgcQgNgjADgZQACgaAUgXIASgVQBkhxCPiMIARgRQAFgDAAgEQAAgDgDgGQg4hbgbguIiHjtQhOiKg1hsIgPgfQgJgUAHgVQAFgUASABQAKgCALATQAqBIBPCXQBNCUCZEBIAfA0QALATgBASQgCARgOAOIh4BvIiSCQQgLAKggAiQgHAIAEATQADARAHATIAOAiQAPAoAZAyIAsBWIA6BuQAlBFAVAqIADAHQAHAPgIAJQgDAEgDAAQgEAAgEgGg");
	this.shape_56.setTransform(-17.8086,21.821,0.2983,0.2983);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#71436F").s().p("ABoOkQgcgrghhBQhDiJhSjPQgag5gKggQgMgpACgeQADgfAUgcIASgYQBbh6CXiwIARgUQAFgEAAgEQAAgEgDgHIhTiiQhai5gtheQhOiig1h/IgPglQgJgXAHgZQAGgXARAAQAKgCALAWQAiBFBYDDQBKCpCbE0IAfA9QALAWgBAVQgCAVgOAPIh4CEQhhBygxA3IgrA0QgGAIADAXQADAUAHAYIAOAoQAPAtAaA8IArBlQAPAmArBcQAlBSAVAxIADAIQAHASgHALQgDAEgEAAQgEAAgEgHg");
	this.shape_57.setTransform(16.0231,-9.8624,0.2983,0.2983);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#71436F").s().p("AB6JGQghgbgmgpQhKhPhliHQgfgkgLgUQgPgaADgSQADgUAXgRIAVgPQB6hWCjhkIAUgMQAGgCAAgDQAAgDgEgEQhJhLgYgaIifiuQhbhlg/hQIgRgXQgLgOAJgQQAGgOAVAAQALgCAOAPQApAsBlB4QBVBnC4DDIAkAmQANAOgBANQgCANgQAJIiNBSIirBqIgzAgQgIAGAEAOQAEAMAIAPIAQAZQASAdAeAlIAzA/QAUAaAwA3QAtA0AXAeIAEAEQAIAMgJAHQgDACgEAAQgEAAgGgEg");
	this.shape_58.setTransform(65.8161,-17.0054,0.2983,0.2983);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#72436F").s().p("AAqEBIhXiBQgfguhUhyIgRgZQgKgOgIgJQgKgLgIgBQgIgBgOAIQgfATgiAeQgUAQgpAmQgfAcg9A8Qg8A7ghAdIgEAEQgKAKgIgIQgHgIAHgLQAigvA7g8QA5g6CFhzIAMgNQABgDADAAIAQgMQAKgHAHgDQAUgJAOADQAPADANAPQAfAiAvA/QBlCDA7BWQAFAHADAAQACgBAGgFQDEjZCuiqQAagbAugnQAMgKALgBQALgBAIAJQAJAJAAAMQAAAOgLALQg3A6hkBgQhcBXi6DJIgjAmQgOAPgMAAQgOAAgMgSg");
	this.shape_59.setTransform(65.1772,93.4383,0.2983,0.2983);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#72436F").s().p("AB5JGQgsgkg5hAQg6hEhmiFIgMgNQgDgBAAgDQgPgWgEgNQgHgUADgOQAEgOARgNQAggaBFguQCHhaBdg2QAHgEAAgDQAAgDgGgFQjRjbiXixQgcggghgtQgJgMAAgLQAAgMAJgHQAJgIANABQANAAALAMQA8BCBSBjQBWBnC4DDIAjAlQAdAegkAWIiHBOQgnAXiABQIgaAPQgPAJgJAIQgMAKgCAHQgCAIAIAOQAbAzBEBTQAZAfA4BDQA2A/AbAjIAEAEQAJALgJAIQgDACgEAAQgFAAgGgEg");
	this.shape_60.setTransform(90.533,62.2986,0.2983,0.2983);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#00FED4").s().p("EgmZAmZMAAAhMyMBMzAAAMAAABMyg");
	this.shape_61.setTransform(45.5745,32.617,0.2983,0.2983);

	var maskedShapeInstanceList = [this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_3, new cjs.Rectangle(-25.6,-35.8,132,72.69999999999999), null);


(lib.Add_UI_Tile_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// flash0.ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#183C6C").s().p("Ah6h7ID1BHIi4Cwg");
	this.shape.setTransform(-13.0549,-8.9044,0.0972,0.0972);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#183C6C").s().p("Ah5h7ID0BIIi5Cvg");
	this.shape_1.setTransform(-18.2016,-14.4372,0.0972,0.0972);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiYAdIAjg5IEOAAIAAA5g");
	this.shape_2.setTransform(-20.9146,-17.4927,0.0972,0.0972);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FDCF08").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_3.setTransform(-23.0082,-17.4927,0.0972,0.0972);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#183C6C").s().p("AiCAdIAAg5IEEAAIgiA5g");
	this.shape_4.setTransform(-24.8857,-17.4927,0.0972,0.0972);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah0AdIAjg5IDGAAIAAA5g");
	this.shape_5.setTransform(-20.5648,-18.6585,0.0972,0.0972);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FDCF08").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_6.setTransform(-22.3087,-18.6585,0.0972,0.0972);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#183C6C").s().p("AimAdIAAg5IFMAAIgiA5g");
	this.shape_7.setTransform(-24.5359,-18.6585,0.0972,0.0972);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhQAdIAjg5IB+AAIAAA5g");
	this.shape_8.setTransform(-20.2175,-19.8243,0.0972,0.0972);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FDCF08").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_9.setTransform(-21.6141,-19.8243,0.0972,0.0972);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#183C6C").s().p("AjJAdIAAg5IGTAAIgiA5g");
	this.shape_10.setTransform(-24.1886,-19.8243,0.0972,0.0972);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#E43E24").s().p("AuELxIGwrTIHSAAIAAg4ImvAAIAlg+IGKAAIAAg6IlnAAIAlg/IFCAAIAAg5IkgAAIEinnIOFXig");
	this.shape_11.setTransform(-19.399,-17.5097,0.0972,0.0972);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_12.setTransform(-10.9515,-25.6341,0.0972,0.0972);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_13.setTransform(-10.9515,-26.7999,0.0972,0.0972);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_14.setTransform(-10.9515,-27.9657,0.0972,0.0972);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FDCF08").s().p("Ah6h7ID1BIIi4Cvg");
	this.shape_15.setTransform(-21.2983,-8.8631,0.0972,0.0972);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#2BBFE3").s().p("Ah6h7ID1BIIi4Cvg");
	this.shape_16.setTransform(-23.2608,-8.9287,0.0972,0.0972);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FDCF08").s().p("Ah4h8IDyBPIi+Cqg");
	this.shape_17.setTransform(-4.9742,-13.2617,0.0972,0.0972);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#E43E24").s().p("AhuhuIDdA6IigCjg");
	this.shape_18.setTransform(-11.9716,-18.3452,0.0972,0.0972);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#183C6C").s().p("Ah0h0IDpA9IipCsg");
	this.shape_19.setTransform(-10.1743,-19.6057,0.0972,0.0972);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_20.setTransform(-1.9318,-22.223,0.097,0.097);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_21.setTransform(-1.0179,-20.8655,0.097,0.097);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_22.setTransform(-1.9318,-20.8655,0.097,0.097);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_23.setTransform(-2.8434,-20.8655,0.097,0.097);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_24.setTransform(-0.1015,-19.5079,0.097,0.097);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_25.setTransform(-1.0179,-19.5079,0.097,0.097);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_26.setTransform(-1.9318,-19.5079,0.097,0.097);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_27.setTransform(-2.8434,-19.5079,0.097,0.097);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_28.setTransform(-3.7597,-19.5079,0.097,0.097);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_29.setTransform(0.8124,-18.1503,0.097,0.097);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_30.setTransform(-0.1015,-18.1503,0.097,0.097);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_31.setTransform(-1.0179,-18.1503,0.097,0.097);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_32.setTransform(-1.9318,-18.1503,0.097,0.097);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_33.setTransform(-2.8434,-18.1503,0.097,0.097);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_34.setTransform(-3.7597,-18.1503,0.097,0.097);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_35.setTransform(-4.6737,-18.1503,0.097,0.097);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_36.setTransform(1.7263,-16.7927,0.097,0.097);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_37.setTransform(0.8124,-16.7927,0.097,0.097);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_38.setTransform(-0.1015,-16.7927,0.097,0.097);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_39.setTransform(-1.0179,-16.7927,0.097,0.097);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_40.setTransform(-1.9318,-16.7927,0.097,0.097);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_41.setTransform(-2.8434,-16.7927,0.097,0.097);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_42.setTransform(-3.7597,-16.7927,0.097,0.097);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_43.setTransform(-4.6737,-16.7927,0.097,0.097);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_44.setTransform(-5.59,-16.7927,0.097,0.097);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_45.setTransform(-1.4737,-21.5418,0.097,0.097);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_46.setTransform(-2.3876,-21.5418,0.097,0.097);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_47.setTransform(-0.5597,-20.1843,0.097,0.097);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_48.setTransform(-1.4737,-20.1843,0.097,0.097);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_49.setTransform(-2.3876,-20.1843,0.097,0.097);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_50.setTransform(-3.3015,-20.1843,0.097,0.097);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_51.setTransform(0.3566,-18.8267,0.097,0.097);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_52.setTransform(-0.5597,-18.8267,0.097,0.097);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_53.setTransform(-1.4737,-18.8267,0.097,0.097);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_54.setTransform(-2.3876,-18.8267,0.097,0.097);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_55.setTransform(-3.3015,-18.8267,0.097,0.097);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_56.setTransform(-4.2155,-18.8267,0.097,0.097);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_57.setTransform(1.2706,-17.4691,0.097,0.097);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_58.setTransform(0.3566,-17.4691,0.097,0.097);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_59.setTransform(-0.5597,-17.4691,0.097,0.097);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_60.setTransform(-1.4737,-17.4691,0.097,0.097);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_61.setTransform(-2.3876,-17.4691,0.097,0.097);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_62.setTransform(-3.3015,-17.4691,0.097,0.097);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_63.setTransform(-4.2155,-17.4691,0.097,0.097);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_64.setTransform(-5.1318,-17.4691,0.097,0.097);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_65.setTransform(2.1845,-16.1115,0.097,0.097);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_66.setTransform(1.2706,-16.1115,0.097,0.097);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_67.setTransform(0.3566,-16.1115,0.097,0.097);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_68.setTransform(-0.5597,-16.1115,0.097,0.097);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_69.setTransform(-1.4737,-16.1115,0.097,0.097);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_70.setTransform(-2.3876,-16.1115,0.097,0.097);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_71.setTransform(-3.3015,-16.1115,0.097,0.097);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_72.setTransform(-4.2155,-16.1115,0.097,0.097);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_73.setTransform(-5.1318,-16.1115,0.097,0.097);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#183C6C").s().p("AguAjIAuhFIAvBFg");
	this.shape_74.setTransform(-6.0458,-16.1115,0.097,0.097);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FDCF08").s().p("AvFNFIPF6JIPGaJg");
	this.shape_75.setTransform(-6.6865,-23.8707,0.0972,0.0972);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#2BBFE3").s().p("AqHodIUPAAIqIQ7g");
	this.shape_76.setTransform(-10.2618,-10.5511,0.0972,0.0972);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#183C6C").s().p("AoFnAIQMAAIoHOBg");
	this.shape_77.setTransform(-3.993,-12.5476,0.0972,0.0972);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#183C6C").s().p("AjTgwID9hWICqgYIiAE9g");
	this.shape_78.setTransform(-26.0904,-9.7132,0.0972,0.0972);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#F4EFB8").s().p("Am1luINrAAIm2Ldg");
	this.shape_79.setTransform(-15.1728,-12.159,0.0972,0.0972);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_2
	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#E43E24").ss(2,1,1).p("AklilIJLAAIAAFLIpLAAg");
	this.shape_80.setTransform(-13.15,-18.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_80).wait(1));

	// Layer_1
	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AkkCgIAAk/IJJAAIAAE/g");
	this.shape_81.setTransform(-13.45,-19.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_81).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_2, new cjs.Rectangle(-43.5,-36.3,60.8,35.099999999999994), null);


(lib.Add_UI_Tile_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#898989").ss(1,1,1).p("AkrirIHZAAIB+AAIAAFXIh+AAInZAAg");
	this.shape.setTransform(30.025,19.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjNB/IAAj9IGbAAIAAD9g");
	mask.setTransform(30.075,18.7);

	// Layer_1
	this.instance = new lib.Add_UI_tile_1();
	this.instance.setTransform(6,0,0.5603,0.5603);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkqCqIAAlTIJVAAIAAFTg");
	this.shape_1.setTransform(30.025,19.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_1, new cjs.Rectangle(-1,1.7,62.1,36.3), null);


(lib.add_preview_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Preview", "5px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add_preview_txt, new cjs.Rectangle(0,0,21,16.2), null);


(lib.add_none_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("None", "4px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 6;
	this.txt.lineWidth = 11;
	this.txt.parent = this;
	this.txt.setTransform(6.0001,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add_none_txt, new cjs.Rectangle(4,0,14.7,10), null);


(lib.add_morph_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Morph", "3px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 9;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add_morph_txt, new cjs.Rectangle(0,0,13.2,10), null);


(lib.add_effectoptions_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Fa.de", "3px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 3;
	this.txt.lineWidth = 19;
	this.txt.parent = this;
	this.txt.setTransform(11.5001,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add_effectoptions_txt, new cjs.Rectangle(0,0,23,12.1), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3/GkIAAtHMAv/AAAIAANHg");
	mask.setTransform(153.6,42);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#727272").s().p("ANiCnQgSgTAAgoIAAh8IhWAAIAADEIg6AAIAAjEIgpAAIAAgwIApAAIAAgiQAAgmAZgZQAZgYAnAAIATABQAIAAAGADIAAAyIgKgEQgIgDgIABQgTAAgJALQgKALAAAWIAAAdIBWAAIAAg2IA6gSIAABIIA6AAIAAAwIg6AAIAABxQAAAXAIAJQAIAKASAAIAMgDIAMgFIAAAvQgGADgMADQgLACgOAAQglAAgSgTgAG3CZQgigiAAg6QAAg8AjgjQAjgjA8AAQA5AAAgAiQAhAjAAA4QAAA8gjAjQghAjg8AAQg4AAgighgAHjAAQgSAVAAAnQAAAmASAUQARAUAhABQAfgBAQgUQARgUAAgoQAAgogRgTQgRgTgfAAQgfAAgSAUgAD5C2QgUgEgLgFIAAg5QANALAUAHQAUAGANABQATgBAKgFQAJgGAAgNQAAgLgJgIQgKgJgbgKQgggOgNgRQgNgQAAgaQAAggAagVQAagVAqgBQANAAAQAEQASADAIADIAAA4QgLgJgPgFQgOgFgQAAQgRAAgJAGQgJAHAAAKQAAAMAIAHQAIAIAaAKQAkAPANAQQAOARAAAZQAAAigbAWQgZAUgvAAQgQAAgRgEgAgbCZQghgiAAg6QAAg8AigjQAigjA8AAQA5AAAhAiQAgAjAAA4QAAA8giAjQgiAjg7AAQg5AAghghgAAQAAQgQAVAAAnQAAAmAQAUQASAUAgABQAfgBARgUQAQgUAAgoQAAgogRgTQgRgTgfAAQgfAAgSAUgAmWCYQgigiAAg1QAAg7AiglQAjgnA/AAQAPAAASAFQASAFAIAFIAAA2QgNgJgOgGQgOgFgOAAQgiAAgVAVQgVAXAAAlQAAAmAUATQAUAWAiAAQANgBAQgFQAQgHAMgJIAAA1QgOAJgRADQgQAEgXAAQg2AAghgigAjNC0IAAj0IA5AAIAAAnIABAAQAIgUAQgLQAQgMAWABIANABIAJACIAAA6QgEgDgJgDQgJgDgMAAQgWAAgOARQgPAQAAAnIAAB7gAoaC0IAAj0IA6AAIAAD0gAqNC0IAAkKIgBAAIhpEKIgoAAIhskKIgBAAIAAEKIg3AAIAAlUIBVAAIBiD8IACAAIBnj8IBSAAIAAFUgAoWhuQgKgKAAgOQAAgOALgKQAJgKAPAAQAPAAAKALQAKAJAAAOQAAAOgKAKQgKAJgPAAQgPAAgKgJg");
	this.shape.setTransform(201.475,18.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#727272").s().p("AhPBeQgfggAAg9QAAg4AigkQAigjAwAAQAyAAAbAgQAcAgAAA5IAAAUIilAAQABAiAUASQATASAiAAQAoAAAggXIAAAtQgiAUg2AAQg1AAgeghgAgihEQgRARgDAcIBwAAQgBgegNgQQgOgRgYAAQgXAAgRASg");
	this.shape_1.setTransform(213.475,71.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#727272").s().p("Ag9BeQghgiAAg2QAAg8AkgkQAkgkA6AAQAjAAAYALIAAA0QgZgTgdAAQgkAAgUAXQgXAYAAAlQAAAmAVAWQAVAWAjAAQAeAAAagVIAAAwQgdAQgoAAQg2AAghghg");
	this.shape_2.setTransform(190.675,71.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#727272").s().p("AgbCzIAAjzIA2AAIAADzgAgXh8QgJgIAAgOQAAgOAJgJQAKgJANAAQAOAAAJAJQAKAJAAAOQAAAMgKAKQgJAJgOAAQgNAAgKgJg");
	this.shape_3.setTransform(175.225,65.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("AgnC3IAAjHIgpAAIAAgsIApAAIAAgnQAAgmAZgXQAZgWAlAAQAVAAAMAFIAAAtQgLgGgOAAQgpAAAAAtIAAAhIA5AAIAAAsIg5AAIAADHg");
	this.shape_4.setTransform(162.2,65.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727272").s().p("AgmC3IAAjHIgqAAIAAgsIAqAAIAAgnQAAgnAZgWQAYgWAmAAQAUAAAMAFIAAAtQgLgGgOAAQgpAAAAAtIAAAhIA5AAIAAAsIg4AAIAADHg");
	this.shape_5.setTransform(146.925,65.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#727272").s().p("Ah2CAQgtgwAAhMQAAhRAtgxQAugxBMAAQBIAAAsAvQAsAxAABLQAABTgtAxQgtAwhKAAQhKAAgsgwgAhKhaQgdAiAAA5QAAA5AcAiQAdAjAuAAQAwAAAcgiQAcghAAg7QAAg8gbghQgbgigxABQguAAgdAjg");
	this.shape_6.setTransform(120.425,66.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#727272").s().p("AhjCgIAAg1QAiAWAiAAQAhAAAVgSQAWgRgBgeQABgdgWgQQgVgQgoAAIg3ADIALiyICnAAIAAAvIh5AAIgGBVIAfgBQA1AAAdAcQAdAbAAAwQAAAzghAeQgiAeg6AAQgyAAgYgNg");
	this.shape_7.setTransform(297.15,66.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#727272").s().p("AhSCGQgggoABhLQAAg6ASgsQASgsAhgYQAigYAqAAQApAAATAKIAAAxQgdgOgdAAQgoAAgZAjQgZAigBA7IABAAQALgUAUgLQAUgLAWAAQAtAAAaAcQAbAdgBAvQAAAhgOAcQgPAagZAOQgbAPgeAAQg1AAgggqgAgmAQQgRARAAAaQABATAHARQAIARAMAJQAOAKAQAAQAagBAPgRQAPgTAAgdQAAgfgPgSQgPgQgaAAQgZAAgQAQg");
	this.shape_8.setTransform(272.05,66.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#727272").s().p("AhECqQgXgFgMgHIAAg2QARAMAVAHQAWAIAVAAQAfAAATgQQATgOAAgaQAAgcgWgPQgXgPgoAAIgeAAIAAgsIAdAAQAkAAATgNQATgOABgbQAAgXgQgOQgQgMgbAAQgjAAggAYIAAgyQAQgJAVgFQAVgFAYAAQAeAAAXALQAYAMALARQAMAUgBAXQAAAggRAWQgSAWggAIIAAABQAmAFAUAUQAVAWAAAhQAAAughAdQgiAcg6AAQgWAAgYgGg");
	this.shape_9.setTransform(246.9,66.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(104.1,0,203.1,84), null);


(lib.transition_wipe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween31("synched",0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.transition_wipe, new cjs.Rectangle(-150,-300,596.1,250), null);


(lib.top_right = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.icons.cache(-50,-10,100,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.right_icons();
	this.icons.name = "icons";
	this.icons.setTransform(23.9,3.3,1,1,0,0,0,23.9,3.3);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_right, new cjs.Rectangle(0,0,47.8,6.7), null);


(lib.top_left = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.icons.cache(-55,-15,110,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.left_icons();
	this.icons.name = "icons";
	this.icons.setTransform(26.1,5.2,1,1,0,0,0,26.1,5.2);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_left, new cjs.Rectangle(0,0,52.2,10.5), null);


(lib.ScreenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.whiteRect();
	this.instance.setTransform(150,236,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ScreenBG, new cjs.Rectangle(10.9,-131.7,300,253.29999999999998), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replaySub("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.motion_graphics_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}
	this.frame_79 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// Layer_2
	this.instance = new lib.motion_graphics_2_bars();
	this.instance.setTransform(-2.3,-48.05,0.0112,0.5613,-30.9993,0,0,2.3,-0.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({regX:4.7,regY:0,scaleX:0.5613,scaleY:0.5612,rotation:0,x:13.55,y:-78.75},40,cjs.Ease.quadOut).wait(1));

	// Layer_6
	this.instance_1 = new lib.Tween23("synched",0);
	this.instance_1.setTransform(-0.05,-53.65,0.0065,0.0065,111.4747,0,0,10.1,4.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:0,regY:0,scaleX:0.841,scaleY:0.841,rotation:111.5398,x:-131.9,y:11.9},39,cjs.Ease.sineInOut).to({regX:-0.1,regY:0.1,scaleX:0.5613,scaleY:0.5613,rotation:0,x:-75.2,y:-64.55},40,cjs.Ease.sineInOut).wait(1));

	// Layer_7
	this.instance_2 = new lib.Tween24("synched",0);
	this.instance_2.setTransform(-71.65,6.25,0.0096,0.0096,106.4818,0,0,5,-1.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:0.1,regY:0.3,scaleX:0.4557,scaleY:0.4557,rotation:144.1554,x:-130.9,y:-79.5},39).to({regX:-0.1,regY:0,scaleX:0.5613,scaleY:0.5613,rotation:0,x:-78.6,y:-102.3},40).wait(1));

	// Layer_8
	this.instance_3 = new lib.Tween25("synched",0);
	this.instance_3.setTransform(20.05,35.65,0.5613,0.5613,-42.466);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({regX:-0.1,regY:0.1,rotation:0,x:9.95,y:-34.5},40,cjs.Ease.sineInOut).wait(1));

	// Layer_10
	this.instance_4 = new lib.Tween27("synched",0);
	this.instance_4.setTransform(-157.25,4.1,0.0214,0.0203,-61.4686,0,0,-3.1,-1);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:-1.2,regY:0.6,scaleX:0.2863,scaleY:0.2858,rotation:-113.0729,x:-36,y:71.7},39,cjs.Ease.sineInOut).to({regX:-0.1,regY:0.1,scaleX:0.5613,scaleY:0.5613,rotation:0,x:-39.35,y:-25.95},40,cjs.Ease.sineInOut).wait(1));

	// Layer_9
	this.instance_5 = new lib.Tween26("synched",0);
	this.instance_5.setTransform(-37.85,-129.55,0.0139,0.0139,-47.2658);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:-0.1,scaleX:0.4707,scaleY:0.4707,rotation:-50.51,x:-15.6,y:-89.2},39,cjs.Ease.sineInOut).to({regX:-0.1,regY:0.1,scaleX:0.5613,scaleY:0.5613,rotation:0,x:-17.85,y:-61.8},40,cjs.Ease.sineInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-158.7,-130.3,302.9,297.5);


(lib.motion_graphics_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}
	this.frame_79 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// Layer_3
	this.instance = new lib.Tween28("synched",0);
	this.instance.setTransform(-1.9,-217.7,0.0113,0.0113,-119.7256,0,0,3.9,2.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,regY:-0.2,scaleX:0.6789,scaleY:0.6789,rotation:7.5096,x:142.15,y:-39.05},38,cjs.Ease.sineInOut).to({regX:0,regY:-0.1,scaleX:0.566,scaleY:0.566,rotation:0,x:37.5,y:-138.45},41,cjs.Ease.sineInOut).wait(1));

	// Layer_4
	this.instance_1 = new lib.motion_graphics_1_bars();
	this.instance_1.setTransform(64.45,-57,0.0466,0.566,-17.7101,0,0,-1.4,-0.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(38).to({_off:false},0).to({regX:0,regY:-0.1,scaleX:0.566,rotation:0,x:35.6,y:-108.3},41,cjs.Ease.sineOut).wait(1));

	// Layer_13
	this.instance_2 = new lib.Tween29("synched",0);
	this.instance_2.setTransform(89.55,-43.6,0.075,0.075,59.4682);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regY:-0.2,scaleX:0.5086,scaleY:0.5086,rotation:-32.5811,x:80.2,y:-76.3},38,cjs.Ease.sineInOut).to({regX:-0.1,regY:-0.1,scaleX:0.566,scaleY:0.566,rotation:0,x:55.35,y:-101.6},41,cjs.Ease.sineInOut).wait(1));

	// Layer_16
	this.instance_3 = new lib.Tween30("synched",0);
	this.instance_3.setTransform(77.55,-114.45,0.0113,0.0113,0,0,0,4.4,-4.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:2.6,regY:0.1,scaleX:0.6787,scaleY:0.6787,rotation:102.77,x:81.9,y:-9.9},38,cjs.Ease.sineInOut).to({regX:-0.1,regY:0,scaleX:0.566,scaleY:0.566,rotation:0,x:16.35,y:-56.15},41,cjs.Ease.sineInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52,-217.7,202.8,306.1);


(lib.Motion_clip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_28 = function() {
		this.stop();
	}
	this.frame_109 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(28).call(this.frame_28).wait(81).call(this.frame_109).wait(51));

	// Layer 1
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(28,-8.25,0.2,0.2,0,0,0,0.2,0.2);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,regY:-0.1,scaleX:0.8052,scaleY:0.8052,x:28.05,y:-8.4,alpha:1},19,cjs.Ease.cubicOut).to({regX:-0.1,scaleX:0.8054,scaleY:0.8056,x:27.85},10,cjs.Ease.cubicInOut).to({regX:0,regY:0.1,scaleX:0.4975,scaleY:0.4975,x:-15.7,y:-17.95},40,cjs.Ease.cubicInOut).to({regX:-0.2,regY:0,scaleX:0.4976,scaleY:0.4979,x:-19.65,y:-48.55},40,cjs.Ease.cubicInOut).to({regY:-0.1,scaleY:0.4969,x:-20.95,y:-48.5},50).wait(1));

	// Layer_6
	this.instance_1 = new lib.motion_graphics_1("synched",0,false);
	this.instance_1.setTransform(-52.2,92.1,0.85,0.85,0,0,0,-0.2,0.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({_off:false},0).wait(131));

	// Layer_18
	this.instance_2 = new lib.motion_graphics_2("synched",0,false);
	this.instance_2.setTransform(97.3,33.8,0.85,0.85,0,0,0,0.2,0.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).wait(131));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D7D7D7").ss(1,1,1).p("Axzt7MAjnAAAIAAb3MgjnAAAg");
	this.shape.setTransform(31.4,8.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AxyN8IAA73MAjlAAAIAAb3g");
	this.shape_1.setTransform(31.4,8.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(160));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.5,-93,229.9,207.1);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.grey_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.icons.cache(-135,-15,270,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.greyicons();
	this.icons.name = "icons";
	this.icons.setTransform(66.3,5.9,1,1,0,0,0,66.3,5.9);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grey_icons, new cjs.Rectangle(1.1,0,138.1,10.4), null);


(lib.bottom_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.icons.cache(-215,-15,430,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.bottomicons();
	this.icons.name = "icons";
	this.icons.setTransform(107.5,6.7,1,1,0,0,0,107.5,6.7);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottom_icons, new cjs.Rectangle(0,0,214.9,13.3), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._365Logo_Greyai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 365Logo_Grey.ai
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(153.6,42,1,1,0,0,0,153.6,42);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape.setTransform(61.675,64.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_1.setTransform(19.225,64.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_2.setTransform(61.675,21.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_3.setTransform(19.225,21.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,307.2,84);


(lib.UI_layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Top_bar
	this.instance = new lib.Transform_txt();
	this.instance.setTransform(139.15,42.95,1,1,0,0,0,17.2,7);

	this.instance_1 = new lib.Share_txt();
	this.instance_1.setTransform(227.05,41.95,1,1,0,0,0,10.2,6.3);

	this.instance_2 = new lib.Comments_txt();
	this.instance_2.setTransform(272.35,41.95,1,1,0,0,0,17.6,6.3);

	this.instance_3 = new lib.grey_icons();
	this.instance_3.setTransform(221.1,36.05,1,1,0,0,0,66.3,5.9);

	this.instance_4 = new lib.ON_txt();
	this.instance_4.setTransform(43.8,19.65,1,1,0,0,0,6.2,6.2);

	this.instance_5 = new lib.top_left();
	this.instance_5.setTransform(58.8,13.15,0.8325,0.8325,0,0,0,26.2,5.2);

	this.instance_6 = new lib.top_right();
	this.instance_6.setTransform(274.1,13,0.8302,0.8302,0,0,0,23.9,3.4);

	this.instance_7 = new lib.AutoSave_txt();
	this.instance_7.setTransform(22.75,13.95,1,1,0,0,0,17.8,7);

	this.instance_8 = new lib.Excel_txt();
	this.instance_8.setTransform(146.35,22.05,1,1,0,0,0,13.5,8.6);

	this.instance_9 = new lib.Name_txt();
	this.instance_9.setTransform(233.45,20.25,1,1,0,0,0,25.6,6.8);

	this.instance_10 = new lib.Home_txt();
	this.instance_10.setTransform(19.5,42.95,1,1,0,0,0,12.4,7);

	this.instance_11 = new lib.Insert_txt();
	this.instance_11.setTransform(47.35,42.95,1,1,0,0,0,11.3,7);

	this.instance_12 = new lib.PageLayout_txt();
	this.instance_12.setTransform(86.3,42.95,1,1,0,0,0,22.4,7);

	this.instance_13 = new lib.Formulas_txt();
	this.instance_13.setTransform(107.55,42.95,1,1,0,0,0,17.2,7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7472A").s().p("AhXAGIAAgLICvAAIAAALg");
	this.shape.setTransform(16.975,40.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F1F1F1").s().p("A3bBmIAAjLMAu3AAAIAADLg");
	this.shape_1.setTransform(150.0023,35.6005);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7472A").s().p("A3bB/IAAj9MAu3AAAIAAD9g");
	this.shape_2.setTransform(150,12.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Bottom_bar
	this.instance_14 = new lib.bottom_icons();
	this.instance_14.setTransform(204.75,244.7,0.8383,0.8383,0,0,0,107.5,6.7);

	this.instance_15 = new lib.Notes_txtcopy();
	this.instance_15.setTransform(131.6,250.75,1,1,0,0,0,11.5,6.7);

	this.instance_16 = new lib.Ready_txt();
	this.instance_16.setTransform(17.05,250.75,1,1,0,0,0,11.5,6.7);

	this.instance_17 = new lib.Percentage_txt();
	this.instance_17.setTransform(279.3,250.75,1,1,0,0,0,10.1,6.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F2F1").s().p("A3bBoIAAjPMAu3AAAIAADPg");
	this.shape_3.setTransform(150.0023,247.834);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI_layout, new cjs.Rectangle(0,0,300,258.3), null);


(lib.screenAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_1 = function() {
		this.motiongraphics.play();
	}
	this.frame_82 = function() {
		this.motiongraphics.play();
	}
	this.frame_205 = function() {
		this.stop()
			exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(81).call(this.frame_82).wait(123).call(this.frame_205).wait(1));

	// hand
	this.instance = new lib.pointer("single",0);
	this.instance.setTransform(337.05,434.15,0.785,0.7842,0,0,0,14,16.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(46).to({_off:false},0).to({regX:14.1,scaleY:0.785,x:89.3,y:80.2},23,cjs.Ease.quadOut).wait(11).to({regX:14,scaleY:0.7842,x:89.25},0).wait(2).to({regX:14.2,scaleY:0.8842,x:89.4,y:81.9,startPosition:1},0).wait(4).to({regX:14,scaleY:0.7842,x:89.25,y:80.2,startPosition:0},0).wait(22).to({startPosition:0},0).to({x:220.3,y:89.9},15,cjs.Ease.quadInOut).wait(57).to({startPosition:0},0).to({regX:11.9,regY:16.4,x:311.7,y:181.4},21,cjs.Ease.cubicIn).to({_off:true},1).wait(4));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D7D7D7").ss(1,1,1).p("A3Wh8MAutAAAIAAD5MgutAAAg");
	this.shape.setTransform(150.1,58.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(206));

	// UI
	this.instance_1 = new lib.UI_layout();
	this.instance_1.setTransform(150,299.2,1,1,0,0,0,150,299.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(206));

	// Add_UI_txt
	this.instance_2 = new lib.add_effectoptions_txt();
	this.instance_2.setTransform(122.9,71.1,1,1,0,0,0,11.5,6.7);

	this.instance_3 = new lib.add_morph_txt();
	this.instance_3.setTransform(92.5,71.1,1,1,0,0,0,11.5,6.7);

	this.instance_4 = new lib.add_none_txt();
	this.instance_4.setTransform(52.75,71.1,1,1,0,0,0,11.5,6.7);

	this.instance_5 = new lib.add_preview_txt();
	this.instance_5.setTransform(12.95,71.1,1,1,0,0,0,11.5,6.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(206));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#E43E24").ss(1,1,1).p("AidhfIE7AAQAUAAAAARIAACdQAAARgUAAIk7AAQgUAAAAgRIAAidQAAgRAUAAg");
	this.shape_1.setTransform(52,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(83).to({x:87.8},0).wait(123));

	// Icons
	this.instance_6 = new lib.fade();
	this.instance_6.setTransform(111,48,0.6315,0.6315);

	this.instance_7 = new lib.Add_UI_none();
	this.instance_7.setTransform(42,48,0.3892,0.3892);

	this.instance_8 = new lib.Add_UI_morph();
	this.instance_8.setTransform(77,48,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]}).to({state:[{t:this.instance_8},{t:this.instance_7},{t:this.instance_6}]},83).wait(123));

	// Add_UI_highlight
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E43E24").ss(1,1,1).p("AidhfIE7AAQAUAAAAARIAACdQAAARgUAAIk7AAQgUAAAAgRIAAidQAAgRAUAAg");
	this.shape_2.setTransform(52,57.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F8C4B6").s().p("AidBgQgTAAAAgRIAAidQAAgRATAAIE7AAQAUAAAAARIAACdQAAARgUAAg");
	this.shape_3.setTransform(52,57.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8C4B6").s().p("AidBgQgTAAgBgRIAAidQABgRATAAIE7AAQAUAAAAARIAACdQAAARgUAAg");
	this.shape_4.setTransform(87.8,57.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2,p:{x:52}}]}).to({state:[{t:this.shape_4},{t:this.shape_2,p:{x:87.8}}]},83).wait(123));

	// Add_UI
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D6E6E").s().p("AgRgkIAkAkIgkAlg");
	this.shape_5.setTransform(144.8967,57.6695,0.7432,0.7432);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E4E6E4").s().p("AgEBrIAAjVIAJAAIAADVg");
	this.shape_6.setTransform(25.0004,58.3259);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#E4E6E4").p("AJSBpIyjAAQgIAAgFgFQgGgDAAgFIAAi3QAAgFAGgEQAFgEAIAAISjAAQAIAAAFAEQAGAEAAAFIAAC3QAAAFgGADQgGAFgHAAg");
	this.shape_7.setTransform(89.2263,57.9509);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("ApRBpQgIgBgFgEQgGgDAAgFIAAi3QAAgFAGgDQAFgFAIAAISjAAQAIAAAFAFQAGADAAAFIAAC3QAAAFgGADQgGAEgHABg");
	this.shape_8.setTransform(89.2263,57.9509);

	this.instance_9 = new lib.bar();
	this.instance_9.setTransform(152,46,0.5679,0.5679);

	this.instance_10 = new lib.Add_UI_Tile_4();
	this.instance_10.setTransform(17.25,218,0.4603,0.4603);

	this.instance_11 = new lib.Add_UI_preview();
	this.instance_11.setTransform(4,47,0.4368,0.4368);

	this.instance_12 = new lib.Add_UI_Tile_3();
	this.instance_12.setTransform(17.25,175.3,0.4603,0.4603);

	this.instance_13 = new lib.Add_UI_Tile_2();
	this.instance_13.setTransform(48.5,150.2);

	this.instance_14 = new lib.Add_UI_Tile_1();
	this.instance_14.setTransform(6,68.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F1F1F1").s().p("AsgCGIAAgqIAAhzIAAhuIZBAAIAABuIAABzIAAAqg");
	this.shape_9.setTransform(80.675,57.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AlhM1IAA5pILDAAIAAZpg");
	this.shape_10.setTransform(36.05,153.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(206));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ax2M+IAA57MAjsAAAIAAZ7g");
	mask.setTransform(185.75,154.9);

	// Motion_graphics_canvas
	this.motiongraphics = new lib.Motion_clip();
	this.motiongraphics.name = "motiongraphics";
	this.motiongraphics.setTransform(154,152.1);

	var maskedShapeInstanceList = [this.motiongraphics];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.motiongraphics).wait(206));

	// ScreenBG
	this.instance_15 = new lib.ScreenBG();
	this.instance_15.setTransform(138.8,229.5,1,1,0,0,0,150,98);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(206));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.2,348.7,448.3);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-22.25,-3.3,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-4.05,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("ArNCbIAAk0IWbAAIAAE0g");
	this.shape.setTransform(-35.525,-2.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-107.3,-17.5,143.6,30.9), null);


(lib.Microsoftlogo_rgb_cgrayai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib._365Logo_Greyai("synched",0);
	this.instance.setTransform(129.4,32.75,0.8655,0.8655,0,0,0,153.6,42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.5,-3.6,265.9,72.69999999999999);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_51 = function() {
		exportRoot.tl1.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(51).call(this.frame_51).wait(23).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298,335.5,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:335.25},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("Amoe6IAAysMBGZAAAIAASsg");
	var mask_graphics_15 = new cjs.Graphics().p("Am4e6IAAysMBGZAAAIAASsg");
	var mask_graphics_16 = new cjs.Graphics().p("Anme6IAAysMBGZAAAIAASsg");
	var mask_graphics_17 = new cjs.Graphics().p("Aoze6IAAysMBGZAAAIAASsg");
	var mask_graphics_18 = new cjs.Graphics().p("Aqee6IAAysMBGZAAAIAASsg");
	var mask_graphics_19 = new cjs.Graphics().p("Aspe6IAAysMBGZAAAIAASsg");
	var mask_graphics_20 = new cjs.Graphics().p("AvSe6IAAysMBGZAAAIAASsg");
	var mask_graphics_21 = new cjs.Graphics().p("Ax7e6IAAysMBGZAAAIAASsg");
	var mask_graphics_22 = new cjs.Graphics().p("A0Ge6IAAysMBGZAAAIAASsg");
	var mask_graphics_23 = new cjs.Graphics().p("A1xe6IAAysMBGZAAAIAASsg");
	var mask_graphics_24 = new cjs.Graphics().p("A2+e6IAAysMBGZAAAIAASsg");
	var mask_graphics_25 = new cjs.Graphics().p("A3se6IAAysMBGZAAAIAASsg");
	var mask_graphics_26 = new cjs.Graphics().p("A38e6IAAysMBGZAAAIAASsg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:197.8084}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:197.8084}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:197.8084}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:197.8084}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:197.8084}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:197.8084}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:197.8084}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:197.8084}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:197.8084}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:197.8084}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:197.8084}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:197.8084}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:197.8084}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.setTransform(78.9,328.6,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(300.35,328.6,5.5415,5.5415,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:300.35},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2BBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhMxBBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTfBBgMAAAiC/MCXtAAAMAAACC/g");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhaiBBgMAAAiC/MCXtAAAMAAACC/g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0398,y:340.4751}).wait(51).to({graphics:mask_1_graphics_51,x:298.0398,y:340.4751}).wait(1).to({graphics:mask_1_graphics_52,x:295.8366,y:340.4751}).wait(1).to({graphics:mask_1_graphics_53,x:289.2271,y:340.4751}).wait(1).to({graphics:mask_1_graphics_54,x:278.2112,y:340.4751}).wait(1).to({graphics:mask_1_graphics_55,x:262.789,y:340.4751}).wait(1).to({graphics:mask_1_graphics_56,x:242.9605,y:340.4751}).wait(1).to({graphics:mask_1_graphics_57,x:218.7255,y:340.4751}).wait(1).to({graphics:mask_1_graphics_58,x:190.0843,y:340.4751}).wait(1).to({graphics:mask_1_graphics_59,x:157.0366,y:340.4751}).wait(1).to({graphics:mask_1_graphics_60,x:119.5827,y:340.4751}).wait(1).to({graphics:mask_1_graphics_61,x:77.7224,y:340.4751}).wait(1).to({graphics:mask_1_graphics_62,x:31.4557,y:340.4751}).wait(1).to({graphics:mask_1_graphics_63,x:-19.2173,y:340.4751}).wait(1).to({graphics:mask_1_graphics_64,x:-74.2967,y:340.4751}).wait(1).to({graphics:mask_1_graphics_65,x:-133.7824,y:340.4751}).wait(1).to({graphics:mask_1_graphics_66,x:-197.6745,y:340.4751}).wait(1).to({graphics:mask_1_graphics_67,x:-265.9729,y:340.4751}).wait(1).to({graphics:mask_1_graphics_68,x:-338.6776,y:340.4751}).wait(1).to({graphics:mask_1_graphics_69,x:-415.7888,y:340.4751}).wait(1).to({graphics:mask_1_graphics_70,x:-491.398,y:340.4751}).wait(1).to({graphics:mask_1_graphics_71,x:-534.3599,y:340.4751}).wait(1).to({graphics:mask_1_graphics_72,x:-579.525,y:340.4751}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.setTransform(300.35,328.6,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(297.95,340.25,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-673.65},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.setTransform(297.95,340.25,1,2.3867,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-666.45},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1159,-78.7,1942.5,838.5);


(lib.anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// LogoEnd
	this.logoEnd = new lib.Microsoftlogo_rgb_cgrayai();
	this.logoEnd.name = "logoEnd";
	this.logoEnd.setTransform(257,472.25,0.2111,0.2111,0,0,0,434.4,2163.2);

	this.timeline.addTween(cjs.Tween.get(this.logoEnd).wait(5));

	// Logo
	this.logo_white = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_white.name = "logo_white";
	this.logo_white.setTransform(107.55,472.25,0.2111,0.2111,0,0,0,434.4,2163.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_white).wait(5));

	// transition
	this.wipe = new lib.transition_wipe();
	this.wipe.name = "wipe";
	this.wipe.setTransform(375,300.1,0.5,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.wipe).wait(5));

	// WhiteBox
	this.whiteBox = new lib.whiteBox();
	this.whiteBox.name = "whiteBox";
	this.whiteBox.setTransform(226.15,124.7,1,1,0,0,0,76,129.8);

	this.timeline.addTween(cjs.Tween.get(this.whiteBox).wait(5));

	// scene4
	this.scene_4 = new lib.scene4();
	this.scene_4.name = "scene_4";
	this.scene_4.setTransform(148.5,235,1,1,0,0,0,200,236);

	this.timeline.addTween(cjs.Tween.get(this.scene_4).wait(5));

	// Screen
	this.screenAnim = new lib.screenAnim();
	this.screenAnim.name = "screenAnim";
	this.screenAnim.setTransform(153,132.5,1,1,0,0,0,153,132.5);

	this.timeline.addTween(cjs.Tween.get(this.screenAnim).wait(5));

	// scene1
	this.scene_1 = new lib.scene_1();
	this.scene_1.name = "scene_1";
	this.scene_1.setTransform(121,510,1,1,0,0,0,668,629);

	this.timeline.addTween(cjs.Tween.get(this.scene_1).to({_off:true},1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1110.1,-3554,2399.8,3812.3);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// intro logo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(208.85,219.15,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(266.45,222.3,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Anim
	this.animMC = new lib.anim();
	this.animMC.name = "animMC";

	this.timeline.addTween(cjs.Tween.get(this.animMC).wait(1));

	// BG
	this.bg = new lib.whiteBG();
	this.bg.name = "bg";
	this.bg.setTransform(150,124.95,1,0.4141,0,0,0,150,301.7);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-16.5,-5.1,614.6,263.40000000000003), null);


// stage content:
(lib.Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.animMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		this.runBanner = function() {
			
			
			
			
			exportRoot.tl1 = new TimelineLite();
			
			this.tl1.stop();
			mc.logo_intro.gotoAndPlay(1);
			
			//scene1 parallax
			//exportRoot.tl1.from(mc.animMC.scene_1.fg, 2,{x:"+=150", ease:Power3.easeOut});
			//exportRoot.tl1.from(mc.animMC.scene_1.bg, 2,{x:"+=75", ease:Power3.easeOut}, "-=2");
			
			//zoom in
			exportRoot.tl1.from(mc.animMC.screenAnim, 0.7,{alpha:0, scaleX:0.9, scaleY:0.256, x:"+=0", y:"+=0", ease: Power3.easeInOut}, "+=1");
			exportRoot.tl1.to(mc.animMC.scene_1, 0.7,{ scaleX:3.96, scaleY:3.96, y:"+=1400", x: "-=200", ease:Power3.easeInOut,onComplete: function(){mc.animMC.screenAnim.play(); mc.animMC.scene_1.alpha=0; exportRoot.tl1.stop();}}, "-=0.7");
			exportRoot.tl1.to(mc.animMC.logo_white, 0.7,{ scaleX:3.96, scaleY:3.96, ease:Power3.easeInOut}, "-=0.7");
			
			//final Scene 
			//exportRoot.tl1.from(mc.animMC.logo_white, 0.7,{x: "-=100", ease:Power3.easeInOut}, "-=0.7");
			exportRoot.tl1.to(mc.animMC.screenAnim, 1,{x:"-=300", ease:Power4.easeInOut});
			//exportRoot.tl1.from(mc.animMC.scene_3, .7,{scaleX:8, scaleY:8, x:"-=80", y:"+=515", ease:Power3.easeInOut},"-=.7");
			//exportRoot.tl1.to(mc.animMC.scene_3, 2,{ y:"-=600", ease:Power4.easeInOut},"+=2");
			exportRoot.tl1.to(mc.animMC.wipe, 1,{x:"-=830", scaleX:1, ease:Power2.easeInOut},"-=1");
			//exportRoot.tl1.to(mc.animMC.wipe_mask, 2,{y:"-=860", scaleY:.2, ease:Power3.easeInOut},"-=2");
			exportRoot.tl1.from(mc.animMC.scene_4, 1,{ x:"+=330", ease:Power4.easeOut},"-=0.6");
			exportRoot.tl1.from(mc.animMC.whiteBox, 1,{ x:"+=150", ease:Power4.easeOut},"-=0.9");
			exportRoot.tl1.from(mc.animMC.logoEnd, 1,{ x:"+=150", ease:Power4.easeOut},"-=0.8");
		
			exportRoot.tl1.stop();
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
					for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
		
			exportRoot.tl1.from(mc.cta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl1.from(mc.txtCta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "-=0.7");
			
			
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(133.5,119.9,464.6,138.4);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#0078D4",
	opacity: 1.00,
	manifest: [
		{src:"images/Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_.png?1581955562232", id:"Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Designer_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;