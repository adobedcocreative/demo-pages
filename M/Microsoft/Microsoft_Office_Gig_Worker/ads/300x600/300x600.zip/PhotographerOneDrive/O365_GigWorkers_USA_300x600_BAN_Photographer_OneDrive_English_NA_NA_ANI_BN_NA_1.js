(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,0,445,485],[779,0,204,163],[447,0,330,371],[779,165,155,77],[779,244,120,77],[447,373,91,77],[936,165,60,77],[901,244,120,77],[884,323,103,78],[779,323,103,78]]}
];


// symbols:



(lib._300x600_final_frameCopy = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._300x600_laptop = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Foreground_300x600 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.tile_13 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.tile_14 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.tile_15 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.tile_16 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.tile_17 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.tile_19 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.tile_20 = function() {
	this.initialize(ss["O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteRect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteRect, new cjs.Rectangle(0,0,300,600), null);


(lib.whiteBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAvKMAAAheTMAu3AAAMAAABeTg");
	this.shape.setTransform(150.0023,724.4012,1,2.4001);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteBG, new cjs.Rectangle(0,0,300,1448.8), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(-350,-382,1.5732,1.5732);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-350,-382,700.1,763);


(lib.tile_20_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoCmFIQFAAIAAMLIwFAAg");
	mask.setTransform(0.0008,0.0006);

	// Layer_1
	this.instance = new lib.tile_20();
	this.instance.parent = this;
	this.instance.setTransform(-52,-39,1.515,1.515);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_20_1, new cjs.Rectangle(-51.5,-39,103,78), null);


(lib.tile_19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_19();
	this.instance.parent = this;
	this.instance.setTransform(-51.5,-39);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_19_1, new cjs.Rectangle(-51.5,-39,103,78), null);


(lib.tile_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEGBIAAsBIKJAAIAAMBg");

	// Layer_3
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(32.5,-91,1.6793,1.6793,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_18, new cjs.Rectangle(-32.5,-38.5,65,76.8), null);


(lib.tile_17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApXmAISvAAIAAMBIyvAAg");
	mask.setTransform(0.0009,0.0006);

	// Layer_1
	this.instance = new lib.tile_17();
	this.instance.parent = this;
	this.instance.setTransform(-103,-39,1.3592,1.3592);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_17_1, new cjs.Rectangle(-60,-38.5,120,77), null);


(lib.tile_16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkrGBIAAsBIJXAAIAAMBg");

	// Layer_2
	this.instance = new lib.tile_15();
	this.instance.parent = this;
	this.instance.setTransform(34,-57,1.3738,1.3738,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_16_1, new cjs.Rectangle(-30,-38.5,60,77), null);


(lib.tile_15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnGGBIAAsBIONAAIAAMBg");

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(148,-150,0.472,0.472,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_15_1, new cjs.Rectangle(-45.5,-38.5,91,77), null);


(lib.tile_14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(-60,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_14_1, new cjs.Rectangle(-60,-38.5,120,77), null);


(lib.tile_13_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.247)").s().p("AlRGLIAAsVIKjAAIAAMVg");
	this.shape.setTransform(2.775,-1.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlRGLIAAsVIKjAAIAAMVg");
	mask.setTransform(2.775,-1.75);

	// Layer_1
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(-52,-4.4,0.5744,2.5919,0,180,0);

	this.instance_1 = new lib.tile_13();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-52,-7,0.5744,0.5744);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_13_2, new cjs.Rectangle(-31,-41.2,67.6,79), null);


(lib.tile_13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(-77.5,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_13_1, new cjs.Rectangle(-77.5,-38.5,155,77), null);


(lib.tile_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmZGBIAAsBIMzAAIAAMBg");

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(-164,-68,0.5,0.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_11, new cjs.Rectangle(-41,-38.5,82,77), null);


(lib.tile_10_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.247)").s().p("AlYGBIAAsBIKxAAIAAMBg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlYGBIAAsBIKxAAIAAMBg");

	// Layer_3
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(-79,-39);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_10_2, new cjs.Rectangle(-34.5,-38.5,69,77), null);


(lib.tile_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlYGBIAAsBIKxAAIAAMBg");

	// Layer_3
	this.instance = new lib.tile_19();
	this.instance.parent = this;
	this.instance.setTransform(-35,-39,1.3039,1.3039);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_10, new cjs.Rectangle(-34.5,-38.5,69,77), null);


(lib.tile_09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmjGBIAAsBINHAAIAAMBg");
	mask.setTransform(9.55,0);

	// Layer_2
	this.instance = new lib.tile_16();
	this.instance.parent = this;
	this.instance.setTransform(51.6,-56,1.41,1.41,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_09, new cjs.Rectangle(-32.4,-38.5,84,77), null);


(lib.tile_08_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoCGBIAAsBIQFAAIAAMBg");

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(143,-127,0.4382,0.4382,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_08_2, new cjs.Rectangle(-51.5,-38.5,103,77), null);


(lib.tile_08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmrJYIAAsBIQFAAIAAMBg");
	mask.setTransform(60.2496,60.0009);

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(462,-208,1,1,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_08, new cjs.Rectangle(17.5,43,103,77), null);


(lib.tile_07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEGBIAAsBIKJAAIAAMBg");

	// Layer_2
	this.instance = new lib.tile_19();
	this.instance.parent = this;
	this.instance.setTransform(-102,-48,1.3083,1.3083);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_07, new cjs.Rectangle(-32.5,-38.5,65,77), null);


(lib.tile_06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ApXGBIAAsBISvAAIAAMBg");
	mask.setTransform(1,-0.5);

	// Layer_2
	this.instance = new lib.tile_17();
	this.instance.parent = this;
	this.instance.setTransform(60.85,-92,1.6903,1.6903,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_06, new cjs.Rectangle(-59,-39,119.9,77), null);


(lib.tile_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ADyGGInkAAIiLAAIAAsLICLAAIHkAAICNAAIAAMLg");
	mask.setTransform(-21.25,-1);

	// Layer_2
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(17,-116,1.9999,1.9999,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_05, new cjs.Rectangle(-59.5,-40,76.5,78), null);


(lib.tile_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnGGGIAAsLIONAAIAAMLg");
	mask.setTransform(-190,-1);

	// Layer_2
	this.instance = new lib.tile_20();
	this.instance.parent = this;
	this.instance.setTransform(-80.7,-80,1.5078,1.5078,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_04, new cjs.Rectangle(-235.5,-40,91,77.6), null);


(lib.tile_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AoRDSIAAmjIQjAAIAAGjg");
	mask.setTransform(107,0);

	// Layer_2
	this.instance = new lib.tile_15();
	this.instance.parent = this;
	this.instance.setTransform(178,-57,1.3738,1.3738,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_03, new cjs.Rectangle(54,-21,106,42), null);


(lib.tile_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AskDSIAAmjIQFAAIAAGjg");
	mask.setTransform(-80.5004,0);

	// Layer_2
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(-52,-25,1,1,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_02, new cjs.Rectangle(-161,-21,103,42), null);


(lib.tile_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEDSIAAmjIKJAAIAAGjg");

	// Layer_2
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(-82,-32,0.8,0.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_01, new cjs.Rectangle(-32.5,-21,65,42), null);


(lib.replaySub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,1,1).p("AAChwIAOAAAgRhwIATAAIAADhIARAAAgPBxIARAA");
	this.shape.setTransform(10.7,15.125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCoICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh9QAAgJgGgDQgDgHgJAAQgHAAgGAHQgGADAAAJIAAAxQAAABgDACQAAADgCAAQgCAAgCgDQgCgCAAgBIAAg/QAAgJgHgEQgDgGgJAAQgIAAgHAGQgGAEAAAJIAAAzQgBABgCAAQgDAAgBgBIAAhDQAAgGgGgHQgGgEgJAAQgIAAgEAEQgCAAAAABQgGAGAAAGIAABAQAAADAAABQgBAAgDAAQgCAAgBAAQAAgBAAgDIAAh6QAAgJgGgEQgHgGgIAAQgJAAgDAGQgGAEAAAJIAACqQAAADgCAAQAAABgCAAQgDADgDgDQgDgEgCgGIgEgOQAAgCgCAAIgPgRIgBgCQgRgNgOAKIAAADQgGAGgCAFQgDAIAFAIIBWBtIADACQADAHAAAHIAAAfQAAACACAAQACACACAAg");
	this.shape_1.setTransform(14.1804,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcCoQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhtQgFgIADgIQACgGAGgFIAAgEQAOgJARANIABACIAPARQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAGADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAirQAAgIAGgEQADgGAJAAQAIAAAHAGQAGAEAAAIIAAB7IAAADIADAAIAEAAIAAgDIAAhAQAAgHAGgFQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQAEgEAIAAQAJAAAGAEQAGAGAAAHIAABCIAEABIADgBIAAgyQAAgKAGgDQAHgGAIAAQAJAAADAGQAHADAAAKIAAA/QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgxQAAgJAGgDQAGgHAHAAQAJAAADAHQAGADAAAJIAAB9IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_2.setTransform(14.1804,16.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCVICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh0QAAgIgGgEIAAgCQgDgEgJAAQgHAAgGAEIAAACQgGAEAAAIIAAAnQAAACgDACQAAADgCAAQgCAAgCgDQgCgCAAgCIAAg1QAAgIgHgFIAAgBQgDgGgJAAQgIAAgHAGIAAABQgGAFAAAIIAAApQgBABgCAAQgDAAgBgBIAAg3QAAgIgGgGQgGgEgJAAQgIAAgEAEIgCAAQgGAGAAAIIAAA1QAAACAAABQgBAAgDAAQgCAAgBAAQAAgBAAgCIAAhTQAAgIgGgGQgHgGgIAAQgGAAgGAGQgGAGAAAIIAACDQAAADgCAAQAAAAgCAAQgDADgDgDQgDgDgCgFIgEgPQAAgBgCAAIgPgTIgBgBQgRgNgOAJIAAAEQgGAFgCAGQgDAJAFAIIBWBsIADACQADAGAAAIIAAAfQAAACACAAQACACACAAg");
	this.shape_3.setTransform(14.1804,18.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#BCBCBC","#FCFCFC","#FFFFFF"],[0,0.259,1],-7.3,-14.5,1.8,9.6).s().p("AgcCVQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhsQgFgIADgJQACgGAGgFIAAgEQAOgJARANIABACIAPASQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAFADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAiDQAAgHAGgHQAGgGAGAAQAIAAAHAGQAGAHAAAHIAABTIAAADIADAAIAEAAIAAgDIAAg1QAAgIAGgGIACAAQAEgDAIgBQAJABAGADQAGAGAAAIIAAA3IAEABIADgBIAAgpQAAgHAGgGIAAgBQAHgGAIAAQAJAAADAGIAAABQAHAGAAAHIAAA2QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgoQAAgIAGgEIAAgCQAGgEAHAAQAJAAADAEIAAACQAGAEAAAIIAAB0IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_4.setTransform(14.1804,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,-1.2,28,35.6);


(lib.Percentage_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("150%", "7px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Percentage_txt, new cjs.Rectangle(0,0,20.2,13.5), null);


(lib.PageLayout_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Flow", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.PageLayout_txt, new cjs.Rectangle(0,0,18.4,15.5), null);


(lib.Name_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Daniela Duarte", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Name_txt, new cjs.Rectangle(0,0,44.5,13.6), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Microsoftlogo_rgb_cgrayai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MS-symbol
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(54.9,54.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(17.125,54.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(54.9,17.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(17.125,17.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("ARIDTQgXgYAAgyIAAieIhsAAIAAD5IhKAAIAAj5Ig0AAIAAg7IA0AAIAAgrQAAgxAggfQAfggAyAAQANAAALACIASAEIAAA/QgDgCgKgDQgJgDgMAAQgXAAgMAOQgMAOAAAcIAAAmIBsAAIAAhGIBKgWIAABcIBJAAIAAA7IhJAAIAACQQAAAcAKANQAKALAXAAQAGAAAJgDQAHgCAIgFIAAA8QgHAEgQAEQgPADgQAAQgvAAgXgZgAIsDCQgrgrAAhJQAAhNAsgsQArgtBNAAQBJAAApAsQApAsAABHQAABMgsAsQgrAthLAAQhIAAgqgqgAJjAAQgWAaAAAyQAAAwAWAaQAWAZApAAQAoAAAVgZQAVgaAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAE7DnQgXgEgRgIIAAhHQAWAOAVAIQAWAIAUAAQAYAAAMgHQAMgHAAgQQAAgPgMgLQgMgKgigOQgogQgSgWQgRgVAAggQAAgpAigbQAhgbA1AAQAOAAAWADQATAEAPAGIAABFQgOgJgUgHQgRgHgVAAQgVAAgLAIQgMAIAAANQAAAQAKAJQAJAIAjAOQAsASARAVQASAWAAAfQAAAsgiAaQggAbg6AAQgTAAgYgFgAgiDCQgqgrAAhJQAAhNArgsQAqgtBOAAQBIAAApAsQApArAABIQAABMgsAsQgrAthLAAQhHAAgqgqgAAVAAQgVAZAAAzQAAAxAVAZQAWAZApAAQAnAAAVgZQAVgaAAgyQAAgzgWgYQgVgZgnAAQgoAAgWAagAoDDBQgqgrAAhEQAAhLArgvQAsgwBQAAQATAAAWAFQAVAFANAHIAABGQgQgLgTgIQgSgHgSAAQgrAAgaAbQgbAcAAAwQAAAvAaAaQAZAaAsAAQAQAAAUgHQAUgIAQgMIAABEQgRAJgXAGQgVAFgcAAQhEAAgrgrgAkEDkIAAk0IBIAAIAAAxIACAAQAKgaAUgOQAUgOAcAAIAQABIAMADIAABKQgGgEgLgEQgLgEgQAAQgaAAgTAVQgTAYAAAuIAACcgAqpDkIAAk0IBJAAIAAE0gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB9FAIABAAICDlAIBnAAIAAGvgAqkiMQgNgMAAgSQAAgRANgNQAOgMARAAQAUAAAMAMQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(215.625,34.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,337.7,72);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Insert_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Upload", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Insert_txt, new cjs.Rectangle(0,0,26.5,15.5), null);


(lib.Home_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("New", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Home_txt, new cjs.Rectangle(0,0,18.1,16), null);


(lib.Formulas_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Sync", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Formulas_txt, new cjs.Rectangle(0,0,18.3,15.5), null);


(lib.Excel_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("OneDrive", "9px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 14;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Excel_txt, new cjs.Rectangle(0,0,41.4,17.5), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bottom_icons_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#706F6F").s().p("AgEACIAAgCIAJAAIAAACg");
	this.shape.setTransform(68.3273,7.359);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#706F6F").s().p("AgKABIAAgBIAVAAIAAABg");
	this.shape_1.setTransform(70.5524,6.109);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#706F6F").s().p("AgKABIAAgCIAVAAIAAACg");
	this.shape_2.setTransform(70.5524,5.159);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#706F6F").s().p("AgKACIAAgCIAVAAIAAACg");
	this.shape_3.setTransform(70.5524,4.209);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#706F6F").s().p("AgKACIAAgCIAVAAIAAACg");
	this.shape_4.setTransform(70.5524,3.309);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#706F6F").s().p("AgKABIAAgBIAVAAIAAABg");
	this.shape_5.setTransform(70.5524,2.359);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#706F6F").s().p("AgKACIAAgDIAVAAIAAADg");
	this.shape_6.setTransform(70.5524,1.409);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#706F6F").s().p("AgKABIAAgBIAVAAIAAABg");
	this.shape_7.setTransform(66.1523,6.109);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#706F6F").s().p("AgKABIAAgCIAVAAIAAACg");
	this.shape_8.setTransform(66.1523,5.159);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#706F6F").s().p("AgKACIAAgCIAVAAIAAACg");
	this.shape_9.setTransform(66.1523,4.209);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#706F6F").s().p("AgKACIAAgCIAVAAIAAACg");
	this.shape_10.setTransform(66.1523,3.309);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#706F6F").s().p("AgKABIAAgBIAVAAIAAABg");
	this.shape_11.setTransform(66.1523,2.359);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#706F6F").s().p("AgKACIAAgDIAVAAIAAADg");
	this.shape_12.setTransform(66.1523,1.409);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#706F6F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_13.setTransform(68.3273,6.409);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#706F6F").s().p("AgEACIAAgDIAJAAIAAADg");
	this.shape_14.setTransform(68.3273,5.459);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#706F6F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_15.setTransform(68.3273,4.509);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#706F6F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_16.setTransform(68.3273,3.609);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#706F6F").s().p("AgEACIAAgDIAJAAIAAADg");
	this.shape_17.setTransform(68.3273,2.659);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#706F6F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_18.setTransform(68.3273,1.709);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#706F6F").s().p("AgBAkIAAhGIADAAIAABGg");
	this.shape_19.setTransform(68.3023,4.309);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#706F6F").s().p("AgEACIAAgDIAJAAIAAADg");
	this.shape_20.setTransform(68.3273,0.7589);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#706F6F").s().p("AgSAjIAAhEIAlAAIAAACIgiAAIAAA+IAiAAIAAAEg");
	this.shape_21.setTransform(65.9773,3.759);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#706F6F").s().p("AgSAjIAAgEIAiAAIAAg+IgiAAIAAgCIAlAAIAABEg");
	this.shape_22.setTransform(70.7024,3.759);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#706F6F").s().p("AgoAmIAAhLIBRAAIAABLgAglAjIBLAAIAAhFIhLAAg");
	this.shape_23.setTransform(84.8276,3.884);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#706F6F").s().p("AgfACIAAgDIA/AAIAAADg");
	this.shape_24.setTransform(84.8276,6.259);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#706F6F").s().p("AgfABIAAgBIA/AAIAAABg");
	this.shape_25.setTransform(84.8276,5.309);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#706F6F").s().p("AgfACIAAgDIA/AAIAAADg");
	this.shape_26.setTransform(84.8276,4.359);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#706F6F").s().p("AgfABIAAgBIA/AAIAAABg");
	this.shape_27.setTransform(84.8276,3.409);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#706F6F").s().p("AgfABIAAgCIA/AAIAAACg");
	this.shape_28.setTransform(84.8276,2.459);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#706F6F").s().p("AgfACIAAgCIA/AAIAAACg");
	this.shape_29.setTransform(84.8276,1.509);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#747474").s().p("AgjAhIAAhBIBHAAIAAAgIgDAAIAAgdIhCAAIAAA7IAgAAIAAADg");
	this.shape_30.setTransform(100.9778,3.334);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#747474").s().p("AgIACIAAgDIASAAIAAADg");
	this.shape_31.setTransform(99.5528,5.259);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#747474").s().p("AgLACIAAgCIAXAAIAAACg");
	this.shape_32.setTransform(99.8528,4.309);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#747474").s().p("AgQABIAAgCIAhAAIAAACg");
	this.shape_33.setTransform(100.3528,3.359);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#747474").s().p("AgXACIAAgCIAvAAIAAACg");
	this.shape_34.setTransform(100.9778,2.409);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#747474").s().p("AgXABIAAgCIAvAAIAAACg");
	this.shape_35.setTransform(100.9778,1.459);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#747474").s().p("AgPAQQgHgGAAgKQAAgJAHgGQAHgIAIABQAKgBAGAIQAHAGAAAJQAAAKgHAGQgGAIgKgBQgIABgHgIgAgTAAQAAAIAGAFQAGAGAHABIADgBIgBgGIgCgIQgBgFgDgBIgDgBQgEgCgBgFIAAgCIgCAAIAAgBQgFAHAAAFgAAGgPIgBACQgFAIAAABIAAADQAAACAEABIAOAFIAAAAIACgHQAAgMgLgEIgBAAg");
	this.shape_36.setTransform(103.3779,5.809);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#747474").s().p("AgQADIAAgFIAhAAIAAAFg");
	this.shape_37.setTransform(114.528,3.884);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#CACAC9").s().p("AgCAPIAAgdIAFAAIAAAdg");
	this.shape_38.setTransform(150.3536,3.859);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#747474").s().p("AgNAjIAAhFIAaAAIAABFg");
	this.shape_39.setTransform(154.3536,3.559);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#CACAC9").s().p("Ak3AFIAAgJIJvAAIAAAJg");
	this.shape_40.setTransform(150.6536,3.859);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#626262").s().p("AgCAXIAAgUIgUAAIAAgFIAUAAIAAgUIAFAAIAAAUIAUAAIAAAFIgUAAIAAAUg");
	this.shape_41.setTransform(185.8291,3.884);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottom_icons_, new cjs.Rectangle(64.1,0,124,8.2), null);


(lib.AutoSave_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Office 365", "9px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 14;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.AutoSave_txt, new cjs.Rectangle(0,0,44.2,16.2), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.UI_Top_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#286DBD").s().p("AghAFIAAgJIBDAAIAAAJg");
	this.shape.setTransform(70.65,41,0.5788,0.5788,0,0,0,0.2,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#286DBD").s().p("AAAgBIgZAYIAAgVIAZgYIAZAYIAAAVg");
	this.shape_1.setTransform(70.509,43.4557,0.5785,0.5785);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#286DBD").s().p("AgHAwIAAhfIAOAAIAABfg");
	this.shape_2.setTransform(70.5094,45.9009,0.5786,0.5786);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Outline
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_3.setTransform(240.5,20.85,0.525,0.525,0,0,0,0.1,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEBGIAAgcQAAgJAPgPQANgKAFgIQAIgKAAgLQAAgTgLgKQgKgJgPAAQgPAAgKAKQgMAKAAASIgKAAQAAgXAPgNQAOgMASAAQATAAAMAMQAPANAAAXQAAAOgJANQgHAHgMAMQgOANAAAEIAAAcg");
	this.shape_4.setTransform(240.55,15.65,0.525,0.525,0,0,0,0.2,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#494846").s().p("AgdgKIAAgHIAdAcIAegcIAAAHIgeAcg");
	this.shape_5.setTransform(43.025,46.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(1));

	// Outline
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQBZIgfgMQgEgCABgEIAEgTIgBgCIgTAGQgFACgBgEIgOgeQgDgDAEgDIAQgLIgBgIIgQgLQgEgCACgEIAOgeQACgEADACIARAEIAEgFIgFgTQgBgEAFgCIAegMQAFgBABAEIAJAPIAGAAIAJgPQACgEAEABIAfAMQAEABgBAFIgEASIAFAGIARgFQAEgBACAEIAOAeQACAEgEACIgRALIAAABIgBAJIAPAKQADACgCAEIgOAeQgCAEgEgCIgTgGIAAABIAEATQABAEgEACIgfAMIgCAAQgDAAgBgDIgKgRIAAAAIgKARQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAIgCAAgAADA7QADAAACACIAJARIAWgJIgEgSQgBgDADgCIAFgEQACgDADACIARAFIAKgVIgNgKQgDgCABgDIABgKIgBgDQAAgFAEgBIAAAAIAPgJIgKgWIgQAEQgEABgBgCIgJgJQgDgDABgCIAEgRIgXgJIgIAOQgBADgDAAIgLAAQgDAAgCgCIgIgPIgXAJIAFASQAAADgCACIgIAIQgBACgEgBIgPgEIgKAWIAPAKQABAAAAABQABAAAAABQAAAAAAABQAAABAAAAIAAAEIABAIQAAAEgCABIgPALIALAWIARgGQAEgCABADIAGAFQACABAAAEIgEASIAWAJIAJgRQACgCADAAIABAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAg");
	this.shape_6.setTransform(224.4875,16.4422,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWAYQgKgKAAgOQAAgNAKgJQAJgKANAAQAOAAAKAKQAJAJAAANQAAAOgJAKQgKAJgOAAQgNAAgJgJgAgPgPQgHAHAAAIQAAAKAHAGQAHAHAIAAQAKAAAGgHQAHgGAAgKQAAgIgHgHQgGgHgKAAQgIAAgHAHg");
	this.shape_7.setTransform(224.4125,16.4375,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(1));

	// Outline
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOAFQgGgGAAgJIAKAAQAAAFADAEQADACAEAAQAFAAADgCQADgEAAgFIAKAAQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape_8.setTransform(208.5043,20.3368,0.525,0.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhDAFIAAgJICHAAIAAAJg");
	this.shape_9.setTransform(208.5831,19.5887,0.525,0.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAtA/IAAhGQAAgSgNgOQgNgNgTAAQgRAAgOANQgNAOAAASIAABGIgKAAIAAhGQAAgXAQgQQAQgQAWAAQAXAAAQAQQAQAQAAAXIAABGg");
	this.shape_10.setTransform(208.5043,16.2943,0.525,0.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Layer_2
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#286DBD").s().p("AAjAYQgTAAgRgJQgRgIgNgPIgCAMIgGgJIAFgSIASAEIAFAKIgKgDQALANAPAHQARAHASgBIAAAKg");
	this.shape_11.setTransform(171.375,48.5875,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#286DBD").s().p("AhMAaQAJgYAUgOQAUgPAZgBQAUgBATAIQATAJANAQIADgMIAFAJIgEASIgSgEIgGgKIAKADQgLgNgQgHQgRgHgQABQgWABgSANQgSANgIAUg");
	this.shape_12.setTransform(173.2125,42.8599,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#286DBD").s().p("AgWAzIAAgOIAPAAIAAgNIgqAAIAAhKIBjAAIAABKIgrAAIAAANIAQAAIAAAOgAgjAKIBHAAIAAguIhHAAg");
	this.shape_13.setTransform(176.025,47.3125,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]}).wait(1));

	// Outline
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#286DBD").s().p("AgEAqIAAgjIgmAAIAAgJIAmAAIAAgnIAJAAIAAAnIAlAAIAAAJIglAAIAAAjg");
	this.shape_14.setTransform(13.6994,45.6344,0.5999,0.5999);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

	// Layer_2
	this.instance = new lib.Home_txt();
	this.instance.parent = this;
	this.instance.setTransform(31.65,52,1,1,0,0,0,12.4,7);

	this.instance_1 = new lib.AutoSave_txt();
	this.instance_1.parent = this;
	this.instance_1.setTransform(52.8,25,1,1,0,0,0,17.8,7);

	this.instance_2 = new lib.Excel_txt();
	this.instance_2.parent = this;
	this.instance_2.setTransform(141.5,26.6,1,1,0,0,0,13.5,8.6);

	this.instance_3 = new lib.Name_txt();
	this.instance_3.parent = this;
	this.instance_3.setTransform(276.6,22.8,1,1,0,0,0,25.6,6.8);

	this.instance_4 = new lib.Insert_txt();
	this.instance_4.parent = this;
	this.instance_4.setTransform(85.3,52,1,1,0,0,0,11.3,7);

	this.instance_5 = new lib.PageLayout_txt();
	this.instance_5.parent = this;
	this.instance_5.setTransform(156.15,52,1,1,0,0,0,22.4,7);

	this.instance_6 = new lib.Formulas_txt();
	this.instance_6.parent = this;
	this.instance_6.setTransform(198.95,52,1,1,0,0,0,17.2,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#286DBD").s().p("AgeAtIAAgOIAQAAIAbhMIATAAIAAAPIgJAAIgbBLg");
	this.shape_15.setTransform(125,45.525,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#286DBD").s().p("AgbAbIAAg2IA4AAIAAA2gAgNAMIAaAAIAAgXIgaAAg");
	this.shape_16.setTransform(127.95,43.6,0.5,0.5,0,0,0,0.1,0.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#286DBD").s().p("AgcAbIAAg2IA4AAIAAA2gAgMANIAaAAIAAgYIgaAAg");
	this.shape_17.setTransform(122.475,47.275,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]}).wait(1));

	// Layer_11
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#DBE9F6").ss(1,1,1).p("AAAieIAAE9");
	this.shape_18.setTransform(30.2,16.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAbA8IAAghIAhAAIAAAhgAgPA8IAAghIAfAAIAAAhgAg7A8IAAghIAgAAIAAAhgAAbAQIAAgfIAhAAIAAAfgAgPAQIAAgfIAfAAIAAAfgAg7AQIAAgfIAgAAIAAAfgAAbgbIAAggIAhAAIAAAggAgPgbIAAggIAfAAIAAAggAg7gbIAAggIAgAAIAAAgg");
	this.shape_19.setTransform(13.05,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18}]}).wait(1));

	// Layer_1
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#DBE9F6").s().p("A3bB0IAAjnMAu3AAAIAADng");
	this.shape_20.setTransform(150.0023,44.8507);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#056EBF").s().p("A3bCnIAAlNMAu3AAAIAAFNg");
	this.shape_21.setTransform(150,17.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_Top_bar, new cjs.Rectangle(0,-0.3,300,61.3), null);


(lib.tile_12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3YLnIAA3NMAuxAAAIAAXNg");
	mask.setTransform(79.675,-22.875);

	// Layer_5
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-31.6,-52.25,0.7448,0.68,0,0,0,-0.4,-0.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_12copy, new cjs.Rectangle(-70,-97.2,299.4,148.7), null);


(lib.tile_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ApXGGIAAsLISvAAIAAMLg");
	var mask_graphics_1 = new cjs.Graphics().p("ApXGHIAAsNISvAAIAAMNg");
	var mask_graphics_2 = new cjs.Graphics().p("ApbGRIAAshIS3AAIAAMhg");
	var mask_graphics_3 = new cjs.Graphics().p("AplGqIAAtTITLAAIAANTg");
	var mask_graphics_4 = new cjs.Graphics().p("Ap5HbIAAu1ITzAAIAAO1g");
	var mask_graphics_5 = new cjs.Graphics().p("AqZIsIAAxXIUzAAIAARXg");
	var mask_graphics_6 = new cjs.Graphics().p("ArIKlIAA1JIWRAAIAAVJg");
	var mask_graphics_7 = new cjs.Graphics().p("AsLNNIAA6ZIYXAAIAAaZg");
	var mask_graphics_8 = new cjs.Graphics().p("AtkQuMAAAghbIbJAAMAAAAhbg");
	var mask_graphics_9 = new cjs.Graphics().p("AvWVOMAAAgqbIetAAMAAAAqbg");
	var mask_graphics_10 = new cjs.Graphics().p("AxcajMAAAg1FMAi5AAAMAAAA1Fg");
	var mask_graphics_11 = new cjs.Graphics().p("AzOfDMAAAg+FMAmdAAAMAAAA+Fg");
	var mask_graphics_12 = new cjs.Graphics().p("EgUnAijMAAAhFFMApPAAAMAAABFFg");
	var mask_graphics_13 = new cjs.Graphics().p("EgVqAlMMAAAhKXMArVAAAMAAABKXg");
	var mask_graphics_14 = new cjs.Graphics().p("EgWZAnFMAAAhOJMAszAAAMAAABOJg");
	var mask_graphics_15 = new cjs.Graphics().p("EgW5AoWMAAAhQrMAtzAAAMAAABQrg");
	var mask_graphics_16 = new cjs.Graphics().p("EgXNApHMAAAhSNMAubAAAMAAABSNg");
	var mask_graphics_17 = new cjs.Graphics().p("EgXXApgMAAAhS/MAuvAAAMAAABS/g");
	var mask_graphics_18 = new cjs.Graphics().p("EgXbAppMAAAhTRMAu3AAAMAAABTRg");
	var mask_graphics_19 = new cjs.Graphics().p("EgXbAprMAAAhTVMAu3AAAMAAABTVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:0.0005,y:-0.0037}).wait(1).to({graphics:mask_graphics_1,x:0.0471,y:-0.0146}).wait(1).to({graphics:mask_graphics_2,x:0.3737,y:-0.0906}).wait(1).to({graphics:mask_graphics_3,x:1.2602,y:-0.2969}).wait(1).to({graphics:mask_graphics_4,x:2.9864,y:-0.6987}).wait(1).to({graphics:mask_graphics_5,x:5.8323,y:-1.3612}).wait(1).to({graphics:mask_graphics_6,x:10.0779,y:-2.3494}).wait(1).to({graphics:mask_graphics_7,x:16.003,y:-3.7286}).wait(1).to({graphics:mask_graphics_8,x:23.8876,y:-5.5639}).wait(1).to({graphics:mask_graphics_9,x:34.0116,y:-7.9205}).wait(1).to({graphics:mask_graphics_10,x:45.9901,y:-10.7088}).wait(1).to({graphics:mask_graphics_11,x:56.1141,y:-13.0654}).wait(1).to({graphics:mask_graphics_12,x:63.9987,y:-14.9007}).wait(1).to({graphics:mask_graphics_13,x:69.9239,y:-16.2799}).wait(1).to({graphics:mask_graphics_14,x:74.1694,y:-17.2681}).wait(1).to({graphics:mask_graphics_15,x:77.0153,y:-17.9306}).wait(1).to({graphics:mask_graphics_16,x:78.7416,y:-18.3324}).wait(1).to({graphics:mask_graphics_17,x:79.628,y:-18.5387}).wait(1).to({graphics:mask_graphics_18,x:79.9546,y:-18.6147}).wait(1).to({graphics:mask_graphics_19,x:80.0012,y:-18.5754}).wait(1));

	// Layer_5
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-45,-5.45,0.3,0.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:-50,y:-131.5},19,cjs.Ease.cubicInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,-350,300,600);


(lib.ScreenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.whiteRect();
	this.instance.parent = this;
	this.instance.setTransform(150,236,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ScreenBG, new cjs.Rectangle(0,-64,300,600), null);


(lib.screen_tiles = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.247)").s().p("Aw4ofMAhlgAFIAMRGMghlAADg");
	this.shape.setTransform(0.375,-0.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AH4IiIAAkKIIKAAIAAEKgACvIiIAAkKIEuAAIAAEKgAl7IiIAAkKIIOAAIAAEKgAwCIiIAAkKIJqAAIAAEKgAwCEAIAAl/IJqAAIAAF/gAnfiYIAAmJIIPAAIAAGJg");
	mask.setTransform(2.05,-0.4);

	// Layer_3
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(-126.7,-13.5,0.5652,0.5029,0,-0.5216,0);

	this.instance_1 = new lib.tile_14();
	this.instance_1.parent = this;
	this.instance_1.setTransform(52,28,0.5779,0.5779);

	this.instance_2 = new lib.tile_19();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-38.75,0,0.7694,0.7694,0,0,180);

	this.instance_3 = new lib.tile_15();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-43,28,0.6528,0.8088);

	this.instance_4 = new lib.tile_17();
	this.instance_4.parent = this;
	this.instance_4.setTransform(3.2,27.25,0.5185,0.5029,0,-0.5216,0);

	this.instance_5 = new lib.tile_13();
	this.instance_5.parent = this;
	this.instance_5.setTransform(19,-73.6,0.8,0.7906,0,-0.4999,180);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_6 = new lib.tile_08_2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(45.95,-4.65,0.5026,0.5026,0,0,0,45.5,-20.8);

	this.tile_18 = new lib.tile_18();
	this.tile_18.name = "tile_18";
	this.tile_18.parent = this;
	this.tile_18.setTransform(25.2,-35.7,0.4778,0.5104,0,-0.4984,0,0.4,-0.4);

	this.instance_7 = new lib.tile_15();
	this.instance_7.parent = this;
	this.instance_7.setTransform(52.45,-13.5,0.5652,0.5029,0,-0.5216,0);

	this.instance_8 = new lib.tile_16();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-35.95,-13.5,0.522,0.5029,0,-0.5216,0);

	this.instance_9 = new lib.tile_19();
	this.instance_9.parent = this;
	this.instance_9.setTransform(43.05,-55.05,0.584,0.5029,0,-0.5216,0);

	this.instance_10 = new lib.tile_20();
	this.instance_10.parent = this;
	this.instance_10.setTransform(-100.9,-55.05,0.5185,0.5029,0,-0.5216,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.tile_18},{t:this.instance_6}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_tiles, new cjs.Rectangle(-107.7,-81.9,216.2,136.2), null);


(lib.scene1_fg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.screen_tiles();
	this.instance.parent = this;
	this.instance.setTransform(206.8,358.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.Foreground_300x600();
	this.instance_1.parent = this;
	this.instance_1.setTransform(22,229);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene1_fg, new cjs.Rectangle(22,229,330,371), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replaySub("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.officeBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9E9E9").s().p("AzQPUIAA+nIDSAAIAAbJIfQAAIAA7JID/ABIAAemg");
	this.shape.setTransform(119.3,96.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_8
	this.instance = new lib.tile_13_2();
	this.instance.parent = this;
	this.instance.setTransform(117,58,2,2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#E1E1E1","#FFFFFF"],[0,1],-99.7,-3.3,-31.1,-2.6).s().p("AvTNVIAA6oIAAgBIenAAIAAABIgMAAIAAaog");
	this.shape_1.setTransform(119,84.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],41.5,-39.9,43,0.1).s().p("A1tCxIAAldIAAgFMAl9AAAIAAAFIFeFdIgVABg");
	this.shape_2.setTransform(136.025,210.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],-40.3,-9.8,-7.4,-10.9).s().p("ACXR8IAVgBIldleIAAgEIAA+UIFjAAMAAAAj3g");
	this.shape_3.setTransform(257.8,113.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B5B5B5").s().p("AgNNUIAA6nIAbAAIAAang");
	this.shape_4.setTransform(19.6,84.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9E9E9").s().p("AyvPKIgeAAIAA+TIAnAAIDLAAIAAaoIAcAAIebAAIAA6oIAMAAIDmAAIAAeTg");
	this.shape_5.setTransform(117,96.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance}]}).wait(1));

	// Layer_3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],40.4,13.2,7.5,12.1).s().p("AiwViMAAAgrDIAEAAIFZFfIgDABIADADIAEAAIAAf9IAAAEIldFeIAWABg");
	this.shape_6.setTransform(243.8,185.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],13,48.1,12.2,8.9).s().p("AlxCyIgIgDIADgCIlZleIWfAAIAAFeIAAAEIAAABg");
	this.shape_7.setTransform(298.575,65.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],25.5,-39.9,24,0.1).s().p("ArPCxIFeldIAAgFIRBAAIAAAFIAAFdI2KABg");
	this.shape_8.setTransform(298.575,305.925);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#E9E9E9").s().p("AogP/IAA/9IRBAAIAACqIufAAIAAa3IOfAAIAABzIAAApg");
	this.shape_9.setTransform(316.075,185.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(1));

	// Layer_11
	this.instance_1 = new lib.tile_10_2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(364.75,192.7,1.7,1.7,0,0,0,-0.5,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_10
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.18,1],42.7,-39.3,42.7,29.3).s().p("Al7loIAAgPIAOAAILpAAIgFLvg");
	this.shape_10.setTransform(315.075,137.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.18,1],-41.5,-8.5,27.1,-8.5).s().p("Al5NtIAA7GILzLgIAAPmgAl5toIAAgEIALAAIAEAEg");
	this.shape_11.setTransform(314.825,187.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Layer_9
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B3C2C0").s().p("EgbpAu4MAAAhdvMA3TAAUMgAUBdbg");
	this.shape_12.setTransform(177.025,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

}).prototype = getMCSymbolPrototype(lib.officeBG, new cjs.Rectangle(-6,-350,441.3,950), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.laptop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_12copy();
	this.instance.parent = this;
	this.instance.setTransform(-70.8,2.3,0.512,0.5133,0,-0.8124,0,-45.6,-5.2);

	this.instance_1 = new lib._300x600_laptop();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-102,-81.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop, new cjs.Rectangle(-199.1,-155,301.1,266.2), null);


(lib.final_frame_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.laptop = new lib.laptop();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(203,171.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(253,253,253,0)","rgba(253,253,253,0.184)","rgba(253,253,253,0.753)","#FDFDFD"],[0,0.243,0.651,1],-4,177.8,-4,57.8).s().p("EgzAAc5IjrgFMAAAg5tMBtXAAAMAAAA5tMhOqgApIgCgQQgCgUABgQQAbgQCLhMQB/hLAAgfQADgxhQgpQgugWhhgrQgVghgkgjIgnglIgwhEQgggtgagaQhPhOiCgDQjEgEh1C7QglA7gXBGIgRA7Ig4AAIggh4Qgnh8gmgWQgQgJhFAdQhLAfhUA4QjiCUhaCvQgeA8gIBRQgBAVAABOQgBAChBAAIipgBg");
	this.shape.setTransform(0,-440.8559);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(-350,-381,1.5721,1.5721);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.final_frame_bg, new cjs.Rectangle(-350,-625.9,700,1007.4), null);


(lib.bottom_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.icons.cache(-200,-10,400,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.bottom_icons_();
	this.icons.name = "icons";
	this.icons.parent = this;
	this.icons.setTransform(94,4.2,1,1,0,0,0,94,4.2);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottom_icons, new cjs.Rectangle(64.1,0,124,8.2), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.UI_Bottom_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Percentage_txt();
	this.instance.parent = this;
	this.instance.setTransform(136.35,7.8,1,1,0,0,0,10.1,6.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.bottom_icons();
	this.instance_1.parent = this;
	this.instance_1.setTransform(28.2,0.5,1,1,0,0,0,94,4.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F2F1").s().p("A3bBhIAAjBMAu3AAAIAADBg");
	this.shape.setTransform(0.0023,0.559);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_Bottom_bar, new cjs.Rectangle(-150,-9.1,300,23.7), null);


(lib.scene3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 300x600_laptop.png
	this.bg = new lib.final_frame_bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(-49,218.5);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene3, new cjs.Rectangle(-399,-407.4,700,1007.4), null);


(lib.scene_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.fg = new lib.scene1_fg();
	this.fg.name = "fg";
	this.fg.parent = this;
	this.fg.setTransform(124,300,1,1,0,0,0,176,300);

	this.timeline.addTween(cjs.Tween.get(this.fg).wait(1));

	// Layer_6
	this.bg = new lib.officeBG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(565,595.5,1,1,0,0,0,617,595.5);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene_1, new cjs.Rectangle(-58,-350,441.3,950), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-11.6,-0.65,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("ApyCjIAAlFITkAAIAAFFg");
	this.shape.setTransform(-37.5,-1.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-100.1,-17.5,125.3,32.6), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_51 = function() {
		exportRoot.tl1.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(51).call(this.frame_51).wait(23).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298,898.75,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:898.5},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgGoBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("EgG4BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("EgHmBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("EgIzBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("EgKeBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("EgMpBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("EgPSBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("EgR7BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("EgUGBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("EgVxBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("EgW+BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("EgXsBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("EgX8BK6IAAyrMBGZAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:479.4334}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:479.4334}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:479.4334}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:479.4334}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:479.4334}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:479.4334}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:479.4334}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:479.4334}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:479.4334}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:479.4334}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:479.4334}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:479.4334}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:479.4334}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.9,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:300.35},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhMxCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTfCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhaiCXxMAAAkvhMCXsAAAMAAAEvhg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:903.6504}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:903.6504}).wait(1).to({graphics:mask_1_graphics_52,x:295.8292,y:903.6504}).wait(1).to({graphics:mask_1_graphics_53,x:289.2197,y:903.6504}).wait(1).to({graphics:mask_1_graphics_54,x:278.2038,y:903.6504}).wait(1).to({graphics:mask_1_graphics_55,x:262.7816,y:903.6504}).wait(1).to({graphics:mask_1_graphics_56,x:242.953,y:903.6504}).wait(1).to({graphics:mask_1_graphics_57,x:218.7181,y:903.6504}).wait(1).to({graphics:mask_1_graphics_58,x:190.0769,y:903.6504}).wait(1).to({graphics:mask_1_graphics_59,x:157.0292,y:903.6504}).wait(1).to({graphics:mask_1_graphics_60,x:119.5753,y:903.6504}).wait(1).to({graphics:mask_1_graphics_61,x:77.7149,y:903.6504}).wait(1).to({graphics:mask_1_graphics_62,x:31.4483,y:903.6504}).wait(1).to({graphics:mask_1_graphics_63,x:-19.2247,y:903.6504}).wait(1).to({graphics:mask_1_graphics_64,x:-74.3041,y:903.6504}).wait(1).to({graphics:mask_1_graphics_65,x:-133.7898,y:903.6504}).wait(1).to({graphics:mask_1_graphics_66,x:-197.6819,y:903.6504}).wait(1).to({graphics:mask_1_graphics_67,x:-265.9803,y:903.6504}).wait(1).to({graphics:mask_1_graphics_68,x:-338.6851,y:903.6504}).wait(1).to({graphics:mask_1_graphics_69,x:-415.7962,y:903.6504}).wait(1).to({graphics:mask_1_graphics_70,x:-491.398,y:903.6504}).wait(1).to({graphics:mask_1_graphics_71,x:-534.3599,y:903.6504}).wait(1).to({graphics:mask_1_graphics_72,x:-579.525,y:903.6504}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-673.65},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-666.45},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1159,-67.6,1942.5,1942.6);


(lib.MainComposition = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Bottom_bar = new lib.UI_Bottom_bar();
	this.Bottom_bar.name = "Bottom_bar";
	this.Bottom_bar.parent = this;
	this.Bottom_bar.setTransform(150,589.7);

	this.Top_bar = new lib.UI_Top_bar();
	this.Top_bar.name = "Top_bar";
	this.Top_bar.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Top_bar},{t:this.Bottom_bar}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MainComposition, new cjs.Rectangle(0,0.2,300,604.0999999999999), null);


(lib.screenAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_99 = function() {
		this.tile_12.play();
	}
	this.frame_119 = function() {
		this.stop()
			exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(20).call(this.frame_119).wait(1));

	// hand
	this.instance = new lib.pointer("single",0);
	this.instance.parent = this;
	this.instance.setTransform(340.05,437.8,1,1,0,0,0,14,16.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(63).to({_off:false},0).to({x:80.6,y:394},23,cjs.Ease.quadOut).wait(13).to({startPosition:1},0).wait(4).to({startPosition:0},0).to({x:321.8,y:489.1},15,cjs.Ease.quadInOut).to({_off:true},1).wait(1));

	// UI
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#007FEC").ss(3,1,0,3).p("ApLl0ISXAAIAALpIyXAAg");
	this.shape.setTransform(70.275,351.3);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(81).to({_off:false},0).to({_off:true},19).wait(20));

	// text
	this.UI = new lib.MainComposition();
	this.UI.name = "UI";
	this.UI.parent = this;
	this.UI.setTransform(150,304.1,1,1,0,0,0,150,304.1);

	this.timeline.addTween(cjs.Tween.get(this.UI).wait(120));

	// Tile_12
	this.tile_12 = new lib.tile_12();
	this.tile_12.name = "tile_12";
	this.tile_12.parent = this;
	this.tile_12.setTransform(71,352);

	this.timeline.addTween(cjs.Tween.get(this.tile_12).wait(120));

	// tile_01
	this.tile_01 = new lib.tile_01();
	this.tile_01.name = "tile_01";
	this.tile_01.parent = this;
	this.tile_01.setTransform(258.5,624.5);
	this.tile_01.alpha = 0;
	this.tile_01._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_01).wait(34).to({_off:false},0).to({y:579.5,alpha:1},24,cjs.Ease.quartOut).to({_off:true},61).wait(1));

	// tile_02
	this.tile_02 = new lib.tile_02();
	this.tile_02.name = "tile_02";
	this.tile_02.parent = this;
	this.tile_02.setTransform(170.5,624.5);
	this.tile_02.alpha = 0;
	this.tile_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_02).wait(30).to({_off:false},0).to({y:579.5,alpha:1},24,cjs.Ease.quartOut).wait(4).to({_off:true},61).wait(1));

	// tile_03
	this.tile_03 = new lib.tile_03();
	this.tile_03.name = "tile_03";
	this.tile_03.parent = this;
	this.tile_03.setTransform(62.5,624.5);
	this.tile_03.alpha = 0;
	this.tile_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_03).wait(32).to({_off:false},0).to({y:579.5,alpha:1},24,cjs.Ease.quartOut).wait(2).to({_off:true},61).wait(1));

	// tile_04
	this.tile_04 = new lib.tile_04();
	this.tile_04.name = "tile_04";
	this.tile_04.parent = this;
	this.tile_04.setTransform(245.5,561);
	this.tile_04.alpha = 0;
	this.tile_04._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_04).wait(25).to({_off:false},0).to({y:516,alpha:1},24,cjs.Ease.quartOut).wait(9).to({_off:true},61).wait(1));

	// tile_08
	this.tile_08 = new lib.tile_08();
	this.tile_08.name = "tile_08";
	this.tile_08.parent = this;
	this.tile_08.setTransform(170,478.5);
	this.tile_08.alpha = 0;
	this.tile_08._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_08).wait(28).to({_off:false},0).to({y:433.5,alpha:1},24,cjs.Ease.quartOut).wait(6).to({_off:true},61).wait(1));

	// tile_05
	this.tile_05 = new lib.tile_05();
	this.tile_05.name = "tile_05";
	this.tile_05.parent = this;
	this.tile_05.setTransform(166,561);
	this.tile_05.alpha = 0;
	this.tile_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_05).wait(26).to({_off:false},0).to({y:516,alpha:1},24,cjs.Ease.quartOut).wait(8).to({_off:true},61).wait(1));

	// tile_06
	this.tile_06 = new lib.tile_06();
	this.tile_06.name = "tile_06";
	this.tile_06.parent = this;
	this.tile_06.setTransform(141.5,498);
	this.tile_06.alpha = 0;
	this.tile_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_06).wait(23).to({_off:false},0).to({x:140,y:434,alpha:1},24,cjs.Ease.quartOut).wait(64).to({_off:true},8).wait(1));

	// tile_07
	this.tile_07 = new lib.tile_07();
	this.tile_07.name = "tile_07";
	this.tile_07.parent = this;
	this.tile_07.setTransform(43.5,478.5);
	this.tile_07.alpha = 0;
	this.tile_07._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_07).wait(21).to({_off:false},0).to({y:433.5,alpha:1},24,cjs.Ease.quartOut).wait(13).to({_off:true},61).wait(1));

	// tile_09
	this.tile_09 = new lib.tile_09();
	this.tile_09.name = "tile_09";
	this.tile_09.parent = this;
	this.tile_09.setTransform(239,478.5);
	this.tile_09.alpha = 0;
	this.tile_09._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_09).wait(25).to({_off:false},0).to({y:433.5,alpha:1},24,cjs.Ease.quartOut).wait(9).to({_off:true},61).wait(1));

	// tile_10
	this.tile_10 = new lib.tile_10();
	this.tile_10.name = "tile_10";
	this.tile_10.parent = this;
	this.tile_10.setTransform(256.5,396.5);
	this.tile_10.alpha = 0;
	this.tile_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10).wait(19).to({_off:false},0).to({y:351.5,alpha:1},24,cjs.Ease.quartOut).wait(15).to({_off:true},61).wait(1));

	// tile_11
	this.tile_11 = new lib.tile_11();
	this.tile_11.name = "tile_11";
	this.tile_11.parent = this;
	this.tile_11.setTransform(177,396.5);
	this.tile_11.alpha = 0;
	this.tile_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_11).wait(17).to({_off:false},0).to({y:351.5,alpha:1},24,cjs.Ease.quartOut).wait(17).to({_off:true},61).wait(1));

	// tile_13
	this.tile_13 = new lib.tile_13_1();
	this.tile_13.name = "tile_13";
	this.tile_13.parent = this;
	this.tile_13.setTransform(213.5,269.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_13).to({_off:true},119).wait(1));

	// tile_14
	this.tile_14 = new lib.tile_14_1();
	this.tile_14.name = "tile_14";
	this.tile_14.parent = this;
	this.tile_14.setTransform(71,269.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_14).to({_off:true},119).wait(1));

	// tile_15
	this.tile_15 = new lib.tile_15_1();
	this.tile_15.name = "tile_15";
	this.tile_15.parent = this;
	this.tile_15.setTransform(245.5,187.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_15).to({_off:true},119).wait(1));

	// tile_16
	this.tile_16 = new lib.tile_16_1();
	this.tile_16.name = "tile_16";
	this.tile_16.parent = this;
	this.tile_16.setTransform(166,187.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_16).to({_off:true},119).wait(1));

	// tile_17
	this.tile_17 = new lib.tile_17_1();
	this.tile_17.name = "tile_17";
	this.tile_17.parent = this;
	this.tile_17.setTransform(71,187.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_17).to({_off:true},119).wait(1));

	// tile_18
	this.tile_18 = new lib.tile_18();
	this.tile_18.name = "tile_18";
	this.tile_18.parent = this;
	this.tile_18.setTransform(258.5,105.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_18).to({_off:true},119).wait(1));

	// tile_19
	this.tile_19 = new lib.tile_19_1();
	this.tile_19.name = "tile_19";
	this.tile_19.parent = this;
	this.tile_19.setTransform(169.5,106);

	this.timeline.addTween(cjs.Tween.get(this.tile_19).to({_off:true},119).wait(1));

	// tile_20
	this.tile_20 = new lib.tile_20_1();
	this.tile_20.name = "tile_20";
	this.tile_20.parent = this;
	this.tile_20.setTransform(62.5,106);

	this.timeline.addTween(cjs.Tween.get(this.tile_20).to({_off:true},119).wait(1));

	// ScreenBG
	this.instance_1 = new lib.ScreenBG();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,163,1,1,0,0,0,150,98);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(113).to({scaleY:0.1251,y:21.2},0).wait(7));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-127,0.2,759,755.3);


(lib.anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Logo
	this.logo_white = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_white.name = "logo_white";
	this.logo_white.parent = this;
	this.logo_white.setTransform(122.85,487.45,0.2111,0.2111,0,0,0,434.4,2163.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_white).wait(5));

	// Screen
	this.screenAnim = new lib.screenAnim();
	this.screenAnim.name = "screenAnim";
	this.screenAnim.parent = this;
	this.screenAnim.setTransform(150,302.4,1,1,0,0,0,150,302.4);

	this.timeline.addTween(cjs.Tween.get(this.screenAnim).wait(5));

	// scene1
	this.scene_1 = new lib.scene_1();
	this.scene_1.name = "scene_1";
	this.scene_1.parent = this;
	this.scene_1.setTransform(150.1,308.9,1,1,0,0,0,150.1,308.9);

	this.timeline.addTween(cjs.Tween.get(this.scene_1).to({_off:true},1).wait(4));

	// Logo
	this.logo_grey = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_grey.name = "logo_grey";
	this.logo_grey.parent = this;
	this.logo_grey.setTransform(66.85,38.45,0.2111,0.2111,0,0,0,169.1,36.3);

	this.timeline.addTween(cjs.Tween.get(this.logo_grey).wait(5));

	// scene3
	this.scene_3 = new lib.scene3();
	this.scene_3.name = "scene_3";
	this.scene_3.parent = this;
	this.scene_3.setTransform(150,386.1,1,1,0,0,0,150,386.1);

	this.timeline.addTween(cjs.Tween.get(this.scene_3).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-399,-407.4,792.5,1011.6999999999999);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// intro logo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(225.2,554.85,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(277.4,556.4,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Anim
	this.animMC = new lib.anim();
	this.animMC.name = "animMC";
	this.animMC.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.animMC).wait(1));

	// BG
	this.bg = new lib.whiteBG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(150,124.95,1,0.4141,0,0,0,150,301.7);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-399,-407.4,792.5,1012.1), null);


// stage content:
(lib.O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.animMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		this.runBanner = function() {
			
			
			
			
			exportRoot.tl1 = new TimelineLite();
			
			this.tl1.stop();
			mc.logo_intro.gotoAndPlay(1);
			
			//scene1 parallax
			exportRoot.tl1.from(mc.animMC.scene_1.fg, 2,{x:"+=100", ease:Power3.easeOut});
			exportRoot.tl1.from(mc.animMC.scene_1.bg, 2,{x:"+=50", ease:Power3.easeOut}, "-=2");
			
			//zoom in
			exportRoot.tl1.from(mc.animMC.screenAnim, 0.7,{alpha:0, scaleX:0.915, scaleY:0.235, x:"+=0", y:"+=50", skewX:-0.5, skewY:-0.3, ease: Power3.easeInOut}, "+=0");
			exportRoot.tl1.to(mc.animMC.scene_1, 0.7,{ scaleX:4.25, scaleY:4.25, y:"-=180", ease:Power3.easeInOut,onStart: function(){mc.animMC.screenAnim.play();}}, "-=0.7");
			exportRoot.tl1.to(mc.animMC.logo_white, 0.7,{ scaleX:4.25, scaleY:4.25, ease:Power3.easeInOut,onComplete: function(){ mc.animMC.scene_1.alpha=0; exportRoot.tl1.stop();}}, "-=0.7");
		
			
			//final Scene 
			//exportRoot.tl1.to(mc.animMC.screenAnim, 2,{ x:"-=3", y:"+=76", scaleX:.5133, scaleY:.1689, skewX:-0.4, alpha:0, ease:Power3.easeInOut});
		
			exportRoot.tl1.to(mc.animMC.screenAnim, 1,{ x:"-=3", y:"+=76", scaleY:.95, scaleY:.1689, skewX:-0.4, alpha:-1, ease:Power3.easeInOut});
			exportRoot.tl1.from(mc.animMC.scene_3.bg, 1,{ y:"-=860", x:"-=840", scaleX:5.9, scaleY:5.9, ease:Power3.easeInOut},"-=1");
			//exportRoot.tl1.from(mc.animMC.scene_3.bg, 2,{ x:"+=50", ease:Power3.easeOut},"-=2");
		
			exportRoot.tl1.to(mc.animMC.scene_3.bg, 2,{ scaleX:.635, scaleY:.635, x:"+=260", y:"+=175", ease:Power3.easeInOut},"+=0");
			exportRoot.tl1.to(mc.animMC.scene_3.bg.laptop, 1,{ x:"+=25", ease:Power3.easeIn},"-=1.5");
		
			exportRoot.tl1.stop();
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=1.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
					for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
		
			exportRoot.tl1.from(mc.cta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl1.from(mc.txtCta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "-=0.7");
			
			
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-249,-107.4,642.5,712.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#0078D4",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_.png?1567156858053", id:"O365_GigWorkers_USA_300x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;