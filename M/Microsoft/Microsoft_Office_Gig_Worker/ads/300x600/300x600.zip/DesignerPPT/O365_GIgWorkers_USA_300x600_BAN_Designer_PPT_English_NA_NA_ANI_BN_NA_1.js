(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[334,602,40,32],[280,602,52,37],[226,602,52,37],[376,602,38,30],[0,602,85,73],[87,602,85,73],[174,602,50,73],[302,0,300,600],[0,0,300,600]]}
];


// symbols:



(lib.Add_UI_effectoptions = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_morph = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_none = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_preview = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_tile_1 = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_tile_2 = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Add_UI_tile_3 = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.frame1b_300x600 = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.frame4_300x600 = function() {
	this.initialize(ss["O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteRect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteRect, new cjs.Rectangle(0,0,300,600), null);


(lib.whiteBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAvKMAAAheTMAu3AAAMAAABeTg");
	this.shape.setTransform(150.0023,724.4012,1,2.4001);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteBG, new cjs.Rectangle(0,0,300,1448.8), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.Tween31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E43E24").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-150,-300,300,600);


(lib.Tween30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("AjTgwID9hWICqgYIiAE9g");
	this.shape.setTransform(0.0016,0.0051);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-21.2,-15.9,42.4,31.8);


(lib.Tween29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC3B1A").s().p("AuELxIOE3hIOFXhg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.1,-75.3,180.2,150.7);


(lib.Tween28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("Ah6h7ID0BIIi3Cvg");
	this.shape.setTransform(0.0029,-0.0206);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.2,-12.4,24.5,24.8);


(lib.Tween27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4BBFE3").s().p("AqHodIUPAAIqIQ7g");
	this.shape.setTransform(-0.0209,0.03);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-64.8,-54.2,129.6,108.5);


(lib.Tween26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F8D01C").s().p("AvFNFIPF6JIPGaJg");
	this.shape.setTransform(0.0297,-0.0221);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-96.6,-83.7,193.3,167.4);


(lib.Tween25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape.setTransform(-0.0196,-31.5218);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_1.setTransform(9.4056,-17.5216);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_2.setTransform(-0.0196,-17.5216);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_3.setTransform(-9.4197,-17.5216);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_4.setTransform(18.8557,-3.5214);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_5.setTransform(9.4056,-3.5214);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_6.setTransform(-0.0196,-3.5214);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_7.setTransform(-9.4197,-3.5214);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_8.setTransform(-18.8699,-3.5214);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_9.setTransform(28.2809,10.4788);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_10.setTransform(18.8557,10.4788);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_11.setTransform(9.4056,10.4788);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_12.setTransform(-0.0196,10.4788);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_13.setTransform(-9.4197,10.4788);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_14.setTransform(-18.8699,10.4788);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_15.setTransform(-28.295,10.4788);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_16.setTransform(37.706,24.479);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_17.setTransform(28.2809,24.479);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_18.setTransform(18.8557,24.479);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_19.setTransform(9.4056,24.479);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_20.setTransform(-0.0196,24.479);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_21.setTransform(-9.4197,24.479);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_22.setTransform(-18.8699,24.479);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_23.setTransform(-28.295,24.479);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_24.setTransform(-37.7451,24.479);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_25.setTransform(4.7055,-24.4967);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_26.setTransform(-4.7196,-24.4967);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_27.setTransform(14.1306,-10.4965);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_28.setTransform(4.7055,-10.4965);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_29.setTransform(-4.7196,-10.4965);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_30.setTransform(-14.1448,-10.4965);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_31.setTransform(23.5808,3.5037);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_32.setTransform(14.1306,3.5037);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_33.setTransform(4.7055,3.5037);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_34.setTransform(-4.7196,3.5037);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_35.setTransform(-14.1448,3.5037);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_36.setTransform(-23.5699,3.5037);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_37.setTransform(33.0059,17.5039);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_38.setTransform(23.5808,17.5039);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_39.setTransform(14.1306,17.5039);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_40.setTransform(4.7055,17.5039);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_41.setTransform(-4.7196,17.5039);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_42.setTransform(-14.1448,17.5039);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_43.setTransform(-23.5699,17.5039);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_44.setTransform(-33.0201,17.5039);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_45.setTransform(42.4311,31.5041);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_46.setTransform(33.0059,31.5041);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_47.setTransform(23.5808,31.5041);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_48.setTransform(14.1306,31.5041);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_49.setTransform(4.7055,31.5041);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_50.setTransform(-4.7196,31.5041);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_51.setTransform(-14.1448,31.5041);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_52.setTransform(-23.5699,31.5041);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_53.setTransform(-33.0201,31.5041);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#203B6B").s().p("AguAjIAuhFIAvBFg");
	this.shape_54.setTransform(-42.4452,31.5041);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47.1,-35,94.30000000000001,70);


(lib.Tween24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#203B6B").s().p("Ah0h0IDpA9IipCsg");
	this.shape.setTransform(-0.0209,-0.0214);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.7,-11.7,23.4,23.4);


(lib.Tween23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC3B1A").s().p("AhuhuIDdA6IigCjg");
	this.shape.setTransform(-0.0212,0.0038);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.1,-11.1,22.2,22.2);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#373535").s().p("AAZArIgxhJIAABJIgGAAIAAhVIAGAAIAxBJIAAhJIAGAAIAABVg");
	this.shape.setTransform(65.5792,-0.0857,3.749,3.749);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#373535").s().p("AgUAjQgGgGgBgIQgBgEAAgRQAAgPABgGQABgIAGgFQAIgJAMAAQANAAAIAJQAGAFABAIQABAGAAAPQAAARgBAEQgBAIgGAGQgJAIgMABQgLgBgJgIgAgPgeQgFAFgBAGIgBATIABAUQABAGAFAFQAGAGAJAAQAKAAAGgGQAFgFABgGIABgUIgBgTQgBgGgFgFQgGgHgKABQgJgBgGAHg");
	this.shape_1.setTransform(34.2754,0.008,3.749,3.749);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#373535").s().p("AgCArIAAhVIAFAAIAABVg");
	this.shape_2.setTransform(13.4686,-0.0857,3.749,3.749);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#373535").s().p("AgCArIAAhPIgaAAIAAgGIA5AAIAAAGIgaAAIAABPg");
	this.shape_3.setTransform(-4.9013,-0.0857,3.749,3.749);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#373535").s().p("AgUAjQgGgGgBgIQgBgEAAgRQAAgPABgGQABgIAGgFQAIgJAMAAQANAAAIAJQAGAFABAIQABAGAAAPQAAARgBAEQgBAIgGAGQgJAIgMABQgLgBgJgIgAgPgeQgFAFgBAGIgBATIABAUQABAGAFAFQAGAGAJAAQAKAAAGgGQAFgFABgGIABgUIgBgTQgBgGgFgFQgGgHgKABQgJgBgGAHg");
	this.shape_4.setTransform(-30.7691,0.008,3.749,3.749);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#373535").s().p("AAeArIAAhGIgaA6IgGAAIgbg6IAABGIgGAAIAAhVIAGAAIAeBBIAdhBIAGAAIAABVg");
	this.shape_5.setTransform(-63.8537,-0.0857,3.749,3.749);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.3,-16.3,154.6,32.6);


(lib.Share_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Share", "7px 'Segoe Pro'", "#B7472A");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Share_txt, new cjs.Rectangle(0,0,20.1,12.8), null);


(lib.scene_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.frame1b_300x600();
	this.instance.parent = this;
	this.instance.setTransform(547,119);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene_1, new cjs.Rectangle(518,119,358.1,601), null);


(lib.right_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglAgIAAg/IBLAAIAAA/gAADAaIAdAAIAAgmIg/AAIAAAmIAdAAIAAgaIgIAIIgFgEIAPgPIAQAPIgEAEIgJgIgAgfgSIA/AAIAAgHIg/AAg");
	this.shape.setTransform(3.8288,3.2752);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeAfIAAgwIAMAAIAAgOIAxAAIAAAyIgMAAIAAAMgAgZAaIAnAAIAAgmIgnAAgAgMgRIAfAAIAAAeIAGAAIAAgmIglAAg");
	this.shape_1.setTransform(30.0792,3.3502);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAAAEIgcAdIgEgEIAdgdIgdgcIAEgEIAcAdIAdgdIAEAEIgdAcIAdAdIgEAEg");
	this.shape_2.setTransform(44.4544,3.3252);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgeACIAAgDIA9AAIAAADg");
	this.shape_3.setTransform(17.479,3.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.right_icons, new cjs.Rectangle(0,0,47.8,6.7), null);


(lib.replaySub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Ready_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Ready", "7px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ready_txt, new cjs.Rectangle(0,0,22.9,13.5), null);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,1,1).p("AAChwIAADhAgPBxIARAAIARAAAgRhwIATAAIAOAA");
	this.shape.setTransform(10.7,15.125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCoICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh9QAAgJgGgDQgDgHgJAAQgHAAgGAHQgGADAAAJIAAAxQAAABgDACQAAADgCAAQgCAAgCgDQgCgCAAgBIAAg/QAAgJgHgEQgDgGgJAAQgIAAgHAGQgGAEAAAJIAAAzQgBABgCAAQgDAAgBgBIAAhDQAAgGgGgHQgGgEgJAAQgIAAgEAEQgCAAAAABQgGAGAAAGIAABAQAAADAAABQgBAAgDAAQgCAAgBAAQAAgBAAgDIAAh6QAAgJgGgEQgHgGgIAAQgJAAgDAGQgGAEAAAJIAACqQAAADgCAAQAAABgCAAQgDADgDgDQgDgEgCgGIgEgOQAAgCgCAAIgPgRIgBgCQgRgNgOAKIAAADQgGAGgCAFQgDAIAFAIIBWBtIADACQADAHAAAHIAAAfQAAACACAAQACACACAAg");
	this.shape_1.setTransform(14.1804,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgcCoQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhtQgFgIADgIQACgGAGgFIAAgEQAOgJARANIABACIAPARQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAGADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAirQAAgIAGgEQADgGAJAAQAIAAAHAGQAGAEAAAIIAAB7IAAADIADAAIAEAAIAAgDIAAhAQAAgHAGgFQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQAEgEAIAAQAJAAAGAEQAGAGAAAHIAABCIAEABIADgBIAAgyQAAgKAGgDQAHgGAIAAQAJAAADAGQAHADAAAKIAAA/QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgxQAAgJAGgDQAGgHAHAAQAJAAADAHQAGADAAAJIAAB9IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_2.setTransform(14.1804,16.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCVICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh0QAAgIgGgEIAAgCQgDgEgJAAQgHAAgGAEIAAACQgGAEAAAIIAAAnQAAACgDACQAAADgCAAQgCAAgCgDQgCgCAAgCIAAg1QAAgIgHgFIAAgBQgDgGgJAAQgIAAgHAGIAAABQgGAFAAAIIAAApQgBABgCAAQgDAAgBgBIAAg3QAAgIgGgGQgGgEgJAAQgIAAgEAEIgCAAQgGAGAAAIIAAA1QAAACAAABQgBAAgDAAQgCAAgBAAQAAgBAAgCIAAhTQAAgIgGgGQgHgGgIAAQgGAAgGAGQgGAGAAAIIAACDQAAADgCAAQAAAAgCAAQgDADgDgDQgDgDgCgFIgEgPQAAgBgCAAIgPgTIgBgBQgRgNgOAJIAAAEQgGAFgCAGQgDAJAFAIIBWBsIADACQADAGAAAIIAAAfQAAACACAAQACACACAAg");
	this.shape_3.setTransform(14.1804,18.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#BCBCBC","#FCFCFC","#FFFFFF"],[0,0.259,1],-7.3,-14.5,1.8,9.6).s().p("AgcCVQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhsQgFgIADgJQACgGAGgFIAAgEQAOgJARANIABACIAPASQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAFADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAiDQAAgHAGgHQAGgGAGAAQAIAAAHAGQAGAHAAAHIAABTIAAADIADAAIAEAAIAAgDIAAg1QAAgIAGgGIACAAQAEgDAIgBQAJABAGADQAGAGAAAIIAAA3IAEABIADgBIAAgpQAAgHAGgGIAAgBQAHgGAIAAQAJAAADAGIAAABQAHAGAAAHIAAA2QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgoQAAgIAGgEIAAgCQAGgEAHAAQAJAAADAEIAAACQAGAEAAAIIAAB0IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_4.setTransform(14.1804,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,-1.2,28,35.6);


(lib.plus_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#7D7D7D").ss(1,1,1).p("AiLhmIEXAAIAADNIkXAAg");
	this.shape.setTransform(0.025,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAAAIA/AAAAAg+IAAA+IAAA/Ag+AAIA+AA");
	this.shape_1.setTransform(0.35,-0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.plus_btn, new cjs.Rectangle(-15,-11.2,30.1,22.5), null);


(lib.Percentage_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("89%", "7px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Percentage_txt, new cjs.Rectangle(0,0,17.5,13.5), null);


(lib.PageLayout_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Draw", "9px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 13;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.PageLayout_txt, new cjs.Rectangle(0,0,23.6,15.5), null);


(lib.ON_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("On", "6px 'Segoe Pro'", "#B7472A");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.ON_txt, new cjs.Rectangle(0,0,12.5,12.5), null);


(lib.Notes_txtcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Notes", "7px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Notes_txtcopy, new cjs.Rectangle(0,0,20.9,13.5), null);


(lib.Name_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Daniela Duarte", "7px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Name_txt, new cjs.Rectangle(0,0,50.6,13.6), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.motion_graphics_2_bars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape.setTransform(-0.021,11.9776);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_1.setTransform(-0.021,-0.0225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AlZAdIAAg5IKzAAIAAA5g");
	this.shape_2.setTransform(-0.021,-12.0227);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.motion_graphics_2_bars, new cjs.Rectangle(-34.6,-14.9,69.2,29.8), null);


(lib.motion_graphics_1_bars = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiYAdIAjg5IEOAAIAAA5g");
	this.shape.setTransform(19.3274,11.9789);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8D01C").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_1.setTransform(-2.2229,11.9789);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#203B6B").s().p("AiBAdIAAg5IEEAAIgjA5g");
	this.shape_2.setTransform(-21.5482,11.9789);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("Ah0AdIAjg5IDGAAIAAA5g");
	this.shape_3.setTransform(22.9275,-0.0213);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F8D01C").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_4.setTransform(4.9772,-0.0213);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#203B6B").s().p("AilAdIAAg5IFMAAIgjA5g");
	this.shape_5.setTransform(-17.9481,-0.0213);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhQAdIAjg5IB+AAIAAA5g");
	this.shape_6.setTransform(26.5025,-12.0214);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F8D01C").s().p("AhgAdIAig5ICfAAIgiA5g");
	this.shape_7.setTransform(12.1273,-12.0214);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#203B6B").s().p("AjJAdIAAg5IGTAAIgiA5g");
	this.shape_8.setTransform(-14.3731,-12.0214);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.motion_graphics_1_bars, new cjs.Rectangle(-34.6,-14.9,69.2,29.8), null);


(lib.Microsoftlogo_rgb_cgrayai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MS-symbol
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(54.9,54.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(17.125,54.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(54.9,17.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(17.125,17.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("ARIDTQgXgYAAgyIAAieIhsAAIAAD5IhKAAIAAj5Ig0AAIAAg7IA0AAIAAgrQAAgxAggfQAfggAyAAQANAAALACIASAEIAAA/QgDgCgKgDQgJgDgMAAQgXAAgMAOQgMAOAAAcIAAAmIBsAAIAAhGIBKgWIAABcIBJAAIAAA7IhJAAIAACQQAAAcAKANQAKALAXAAQAGAAAJgDQAHgCAIgFIAAA8QgHAEgQAEQgPADgQAAQgvAAgXgZgAIsDCQgrgrAAhJQAAhNAsgsQArgtBNAAQBJAAApAsQApAsAABHQAABMgsAsQgrAthLAAQhIAAgqgqgAJjAAQgWAaAAAyQAAAwAWAaQAWAZApAAQAoAAAVgZQAVgaAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAE7DnQgXgEgRgIIAAhHQAWAOAVAIQAWAIAUAAQAYAAAMgHQAMgHAAgQQAAgPgMgLQgMgKgigOQgogQgSgWQgRgVAAggQAAgpAigbQAhgbA1AAQAOAAAWADQATAEAPAGIAABFQgOgJgUgHQgRgHgVAAQgVAAgLAIQgMAIAAANQAAAQAKAJQAJAIAjAOQAsASARAVQASAWAAAfQAAAsgiAaQggAbg6AAQgTAAgYgFgAgiDCQgqgrAAhJQAAhNArgsQAqgtBOAAQBIAAApAsQApArAABIQAABMgsAsQgrAthLAAQhHAAgqgqgAAVAAQgVAZAAAzQAAAxAVAZQAWAZApAAQAnAAAVgZQAVgaAAgyQAAgzgWgYQgVgZgnAAQgoAAgWAagAoDDBQgqgrAAhEQAAhLArgvQAsgwBQAAQATAAAWAFQAVAFANAHIAABGQgQgLgTgIQgSgHgSAAQgrAAgaAbQgbAcAAAwQAAAvAaAaQAZAaAsAAQAQAAAUgHQAUgIAQgMIAABEQgRAJgXAGQgVAFgcAAQhEAAgrgrgAkEDkIAAk0IBIAAIAAAxIACAAQAKgaAUgOQAUgOAcAAIAQABIAMADIAABKQgGgEgLgEQgLgEgQAAQgaAAgTAVQgTAYAAAuIAACcgAqpDkIAAk0IBJAAIAAE0gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB9FAIABAAICDlAIBnAAIAAGvgAqkiMQgNgMAAgSQAAgRANgNQAOgMARAAQAUAAAMAMQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(215.625,34.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,337.7,72);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.left_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKANIAMgNIgMgMIAFgEIAQAQIgQARg");
	this.shape.setTransform(51.0765,5.2502);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhEAyQgVAAgOgOQgPgPAAgVQAAgTAPgPQAOgPAVAAICJAAQAVAAAPAPQAOAPAAATQAAAVgOAPQgPAOgVAAgAA1gPQgHAHAAAIQAAAKAHAHQAHAHAJAAQAKAAAHgHQAHgHAAgKQAAgIgHgHQgHgHgKAAQgJAAgHAHg");
	this.shape_1.setTransform(11.9259,5.0252);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiAzIgRgRIAAhUIBnAAIAABlgAAaAOIAAAfIATAAIAAhZIgNAAIAAAnIg/AAIAAgnIgOAAIAABMIAOANIAHAAIAAgfgAgSAtIAmAAIAAgZIgmAAgAgZgLIAzAAIAAghIgzAAg");
	this.shape_2.setTransform(36.0762,5.3253);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgKANIAMgNIgMgMIAFgEIAQAQIgQARg");
	this.shape_3.setTransform(48.6264,5.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.left_icons, new cjs.Rectangle(0,0,52.2,10.5), null);


(lib.Insert_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Insert", "9px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 13;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Insert_txt, new cjs.Rectangle(0,0,24.8,15.5), null);


(lib.Home_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Home", "9px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 13;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Home_txt, new cjs.Rectangle(0,0,26.9,16), null);


(lib.greyicons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7472A").s().p("AgUANIgGAAIAAglIA2AAIAAAlIgjAAIgNAMgAgXAJIAHAAIAAAIIAIgIIAgAAIAAgeIgvAAg");
	this.shape.setTransform(89.0038,5.8507);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBE9E7").s().p("AjxA7QgFAAgDgDQgDgDAAgFIAAhfQAAgEADgDQADgEAFAAIHjAAQAFAAADAEQADADAAAEIAABfQAAAFgDADQgDADgFAAgAj3g1QgCADgBADIAABfQABADACADQACACAEAAIHjAAQAEAAACgCQACgDABgDIAAhfQgBgDgCgDQgCgDgEABInjAAQgEgBgCADg");
	this.shape_1.setTransform(107.3041,5.9007);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AjnA7QgIAAgGgGQgHgGAAgKIAAhJQAAgJAHgHQAGgGAIAAIHPAAQAIAAAHAGQAGAHAAAJIAABJQAAAKgGAGQgHAGgIAAg");
	this.shape_2.setTransform(107.3041,5.9007);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7472A").s().p("AADAJIgGABIgHACIgHAEQgEACgBADIAAgEIABgHIACgGIAEgFIAFgEIAHgCIAGgBIAAgMIAVAUIgVAVgAgCgEIgDABIgFADIgDADIgEAEIgBAFIAKgFIALgBIAEAAIAAAGIALgMIgLgLIAAAGIgEAAg");
	this.shape_3.setTransform(51.2532,4.6757);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B7472A").s().p("AgYATIAAglIADAAIAAAjIArAAIAAgUIADAAIAAAWg");
	this.shape_4.setTransform(50.1532,6.9257);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#EBE9E7").s().p("AieA7QgFAAgDgDQgDgDAAgFIAAhfQAAgEADgDQADgEAFAAIE+AAQAEAAADAEQADADAAAEIAABfQAAAFgDADQgDADgEAAgAingvIAABfQAAAJAJgBIE+AAQADAAACgCQADgDAAgDIAAhfQAAgDgDgDQgCgDgDABIk+AAQgJAAAAAIg");
	this.shape_5.setTransform(60.6784,5.9007);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AiUA7QgJAAgGgGQgGgGAAgKIAAhJQAAgJAGgHQAGgGAJAAIEpAAQAJAAAGAGQAGAHAAAJIAABJQAAAKgGAGQgGAGgJAAg");
	this.shape_6.setTransform(60.6784,5.9007);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#494846").s().p("AgQAUIATgUIgTgTIAHgHIAaAaIgaAbg");
	this.shape_7.setTransform(5.1507,5.8455,1.0995,1.0995);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#494846").s().p("AgRAUIAVgUIgVgTIAHgHIAbAaIgbAbg");
	this.shape_8.setTransform(1.8796,5.8455,1.0995,1.0995);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.greyicons, new cjs.Rectangle(0,0,132.6,11.8), null);


(lib.Formulas_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Design", "9px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 13;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Formulas_txt, new cjs.Rectangle(0,0,29.7,15.5), null);


(lib.Excel_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("PowerPoint", "10px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 15;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Excel_txt, new cjs.Rectangle(0,0,52.7,17.3), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.Comments_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Comments", "7px 'Segoe Pro'", "#B7472A");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Comments_txt, new cjs.Rectangle(0,0,35,12.8), null);


(lib.bottomicons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#797775").s().p("AgQAiIAAhDIAhAAIAABDg");
	this.shape.setTransform(142.4284,6.6252);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#676767").s().p("AgWAFIAAgJIAtAAIAAAJg");
	this.shape_1.setTransform(111.2279,6.3752);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#676767").s().p("AgXAEIAAgHIAvAAIAAAHg");
	this.shape_2.setTransform(180.179,6.6002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#676767").s().p("AgDAYIAAgvIAHAAIAAAvg");
	this.shape_3.setTransform(180.179,6.6002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#ABABAB").s().p("AgDAQIAAgfIAHAAIAAAfg");
	this.shape_4.setTransform(145.6284,6.3752);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#ABABAB").s().p("AkqAEIAAgHIJVAAIAAAHg");
	this.shape_5.setTransform(145.7034,6.3752);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#606060").s().p("AgPAIIAPgPIAQAPg");
	this.shape_6.setTransform(3.4263,3.9501);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#606060").s().p("AgRACIAAgDIAjAAIAAADg");
	this.shape_7.setTransform(1.8262,9.4002);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#606060").s().p("AghACIAAgDIBDAAIAAADg");
	this.shape_8.setTransform(3.4263,7.7502);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#606060").s().p("AghACIAAgDIBDAAIAAADg");
	this.shape_9.setTransform(3.4263,6.1502);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#707070").s().p("AgLAKIAAgTIAXAAIAAATgAgEADIAJAAIAAgGIgJAAg");
	this.shape_10.setTransform(44.4519,5.4501);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#707070").s().p("AgaACIAAgDIA0AAIAAADg");
	this.shape_11.setTransform(44.3519,7.9002);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#707070").s().p("AgBAkIAAhHIADAAIAABHg");
	this.shape_12.setTransform(41.8518,6.4252);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#707070").s().p("AglAkIAAhHIBLAAIAABHgAgeAeIA9AAIAAg6Ig9AAg");
	this.shape_13.setTransform(43.4769,6.4252);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#747474").s().p("AgBAMIAAgXIADAAIAAAXg");
	this.shape_14.setTransform(97.9027,8.7502);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#747474").s().p("AgNACIAAgDIAbAAIAAADg");
	this.shape_15.setTransform(97.9027,9.8752);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#747474").s().p("AgVACIAAgDIArAAIAAADg");
	this.shape_16.setTransform(97.8777,5.0501);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#747474").s().p("AgmAFIAAgJIBNAAIAAAJg");
	this.shape_17.setTransform(97.9027,3.3001);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#747474").ss(0.7).p("AAXgVIgtAAQgFAAAAAFIAAAhQAAAFAFAAIAtAAQAFAAAAgFIAAghQAAgFgFAAg");
	this.shape_18.setTransform(97.9027,5.2251);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_19.setTransform(79.7524,8.3002);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_20.setTransform(79.7524,7.0752);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_21.setTransform(79.7524,5.8501);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#707070").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_22.setTransform(79.7524,4.6501);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_23.setTransform(81.7775,7.9002);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_24.setTransform(81.7775,6.6502);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_25.setTransform(81.7775,5.4501);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_26.setTransform(81.7775,4.2501);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_27.setTransform(77.7524,7.9002);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_28.setTransform(77.7524,6.6502);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_29.setTransform(77.7524,5.4501);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#707070").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_30.setTransform(77.7524,4.2501);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#707070").ss(0.7).p("AAAgdIAAA6");
	this.shape_31.setTransform(79.7524,6.6002);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#707070").ss(0.7).p("AgRgWQAAgFAEgCQAEgCAOAAIANAAIAAA8IgSAAQgRAAAAAH");
	this.shape_32.setTransform(81.5775,6.1501);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#707070").ss(0.7).p("AASgWQAAgFgEgCQgFgCgOAAIgMAAIAAA8IATAAQAQAAAAAH");
	this.shape_33.setTransform(77.9524,6.1501);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#747474").s().p("AgcAlQgIAAAAgIIAAg5QAAgIAIAAIA5AAQAIAAAAAIIAAA5QAAAIgIAAgAgdgcIAAA5IABACIA5AAIABgCIAAg5IgBgBIg5AAg");
	this.shape_34.setTransform(211.2044,6.2502);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#747474").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_35.setTransform(211.2044,3.8501);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#747474").s().p("AgBAKIAAgTIADAAIAAATg");
	this.shape_36.setTransform(211.2044,4.2501);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#747474").s().p("AgFACIAAgDIALAAIAAADg");
	this.shape_37.setTransform(211.2044,8.6752);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#747474").s().p("AgBAKIAAgTIADAAIAAATg");
	this.shape_38.setTransform(211.2044,8.2752);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#747474").s().p("AgBAGIAAgLIADAAIAAALg");
	this.shape_39.setTransform(213.6045,6.2502);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#747474").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_40.setTransform(213.2045,6.2502);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#747474").s().p("AgBAGIAAgLIADAAIAAALg");
	this.shape_41.setTransform(208.7794,6.2502);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#747474").s().p("AgJACIAAgDIATAAIAAADg");
	this.shape_42.setTransform(209.1794,6.2502);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_43.setTransform(63.6272,8.4752);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_44.setTransform(59.6021,8.4752);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_45.setTransform(63.6272,4.4251);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#747474").s().p("AgRAQIAAgfIAjAAIAAAfgAgKAJIAVAAIAAgRIgVAAg");
	this.shape_46.setTransform(59.6021,4.4251);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#C8C6C4").s().p("AhaBCIAAiDIC1AAIAACDg");
	this.shape_47.setTransform(43.4769,6.6502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottomicons, new cjs.Rectangle(0,0,214.9,13.3), null);


(lib.AutoSave_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("AutoSave", "7px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.AutoSave_txt, new cjs.Rectangle(0,0,33.1,14), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Add_UI_Tile_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#898989").ss(1,1,1).p("AF0FmIrnAAIAArLILnAA");
	this.shape.setTransform(12.4,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Add_UI_tile_3();
	this.instance.parent = this;
	this.instance.setTransform(-25,-36.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_3, new cjs.Rectangle(-25.7,-36.7,76.3,73.5), null);


(lib.Add_UI_Tile_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E43E24").ss(2,1,1).p("AmjllINHAAIAALLItHAAg");
	this.shape.setTransform(-0.225,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Add_UI_tile_2();
	this.instance.parent = this;
	this.instance.setTransform(-42.5,-36.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_2, new cjs.Rectangle(-43.2,-36.7,86,73.5), null);


(lib.Add_UI_Tile_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#898989").ss(1,1,1).p("AmjllINHAAIAALLItHAAg");
	this.shape.setTransform(-0.225,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.Add_UI_tile_1();
	this.instance.parent = this;
	this.instance.setTransform(-42.5,-36.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Add_UI_Tile_1, new cjs.Rectangle(-43.2,-36.7,86,73.5), null);


(lib.add_slide_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Slide 2 of 12", "9px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 14;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_slide_txt, new cjs.Rectangle(0,0,50.5,16.2), null);


(lib.add_preview_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Preview", "9px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 14;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_preview_txt, new cjs.Rectangle(0,0,34.7,16.2), null);


(lib.add_none_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("None", "8px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 12;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_none_txt, new cjs.Rectangle(0,0,23.5,16.2), null);


(lib.add_morph_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Morph", "8px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 12;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_morph_txt, new cjs.Rectangle(0,0,28.1,16.2), null);


(lib.add_effectoptions_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Effect\nOptions", "9px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(17.65,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_effectoptions_txt, new cjs.Rectangle(0,0,35.3,29.7), null);


(lib.add_3_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("3", "7px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_3_txt, new cjs.Rectangle(0,0,10.2,13.5), null);


(lib.add_2_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("2", "7px 'Segoe Pro'", "#E43E24");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_2_txt, new cjs.Rectangle(0,0,10.2,13.5), null);


(lib.add_1_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("1", "7px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.add_1_txt, new cjs.Rectangle(0,0,10.2,13.5), null);


(lib.transition_wipe = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween31("synched",0);
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.transition_wipe, new cjs.Rectangle(-150,-300,300,600), null);


(lib.top_right = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.icons.cache(-50,-10,100,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.right_icons();
	this.icons.name = "icons";
	this.icons.parent = this;
	this.icons.setTransform(23.9,3.3,1,1,0,0,0,23.9,3.3);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

}).prototype = getMCSymbolPrototype(lib.top_right, new cjs.Rectangle(0,0,47.8,6.7), null);


(lib.top_left = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.icons.cache(-55,-15,110,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.left_icons();
	this.icons.name = "icons";
	this.icons.parent = this;
	this.icons.setTransform(26.1,5.2,1,1,0,0,0,26.1,5.2);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

}).prototype = getMCSymbolPrototype(lib.top_left, new cjs.Rectangle(0,0,52.2,10.5), null);


(lib.ScreenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.whiteRect();
	this.instance.parent = this;
	this.instance.setTransform(150,236,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ScreenBG, new cjs.Rectangle(0,-64,300,600), null);


(lib.scene4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.logo_white = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_white.name = "logo_white";
	this.logo_white.parent = this;
	this.logo_white.setTransform(122.85,487.45,0.2111,0.2111,0,0,0,434.4,2163.2);

	this.instance = new lib.frame4_300x600();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.logo_white}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene4, new cjs.Rectangle(0,0,300,600), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replaySub("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.motion_graphics_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}
	this.frame_79 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// Layer_2
	this.instance = new lib.motion_graphics_2_bars();
	this.instance.parent = this;
	this.instance.setTransform(89.85,-111.35,0.02,1,-30.9999,0,0,4.7,-0.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).to({regX:4.8,scaleX:1,scaleY:0.9999,rotation:0,x:58.45,y:-84.05},40,cjs.Ease.quadOut).wait(1));

	// Layer_6
	this.instance_1 = new lib.Tween23("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(34.2,-39.25,0.0115,0.0115,111.5057);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.4983,scaleY:1.4983,rotation:111.5397,x:-141.2,y:-4.5},39,cjs.Ease.sineInOut).to({scaleX:1,scaleY:1,rotation:0,x:-99.7,y:-58.7},40,cjs.Ease.sineInOut).wait(1));

	// Layer_7
	this.instance_2 = new lib.Tween24("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-93.4,67.45,0.0172,0.0172,0,106.5188,106.4412);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regY:0.2,scaleX:0.8119,scaleY:0.8119,rotation:144.1549,skewX:0,skewY:0,x:-139.25,y:-167.45},39).to({regY:0,scaleX:1,scaleY:1,rotation:0,x:-129.25,y:-124.4},40).wait(1));

	// Layer_8
	this.instance_3 = new lib.Tween25("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(129.65,37.85,1,1,-42.4652);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(39).to({_off:false},0).to({rotation:0,x:52,y:-5.15},40,cjs.Ease.sineInOut).wait(1));

	// Layer_10
	this.instance_4 = new lib.Tween27("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(-245.85,63.65,0.0381,0.0362,-61.4339,0,0,-1.2,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:-1.3,regY:0.8,scaleX:0.5101,scaleY:0.5092,rotation:-113.0728,x:29.7,y:102.05},39,cjs.Ease.sineInOut).to({regX:0,regY:0,scaleX:1,scaleY:1,rotation:0,x:-35.8,y:10.1},40,cjs.Ease.sineInOut).wait(1));

	// Layer_9
	this.instance_5 = new lib.Tween26("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(-33.2,-174.5,0.0248,0.0248,-47.2926);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:-0.1,scaleX:0.8386,scaleY:0.8386,rotation:-50.509,x:66.1,y:-184.65},39,cjs.Ease.sineInOut).to({regY:0,scaleX:1,scaleY:1,rotation:0,x:2.5,y:-53.8},40,cjs.Ease.sineInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-248.7,-229.2,436.79999999999995,396.4);


(lib.motion_graphics_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		stop();
	}
	this.frame_79 = function() {
		stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// Layer_3
	this.instance = new lib.Tween28("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-26.3,-218.1,0.0199,0.0199,-119.7449);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.1,regY:-0.1,scaleX:1.1995,scaleY:1.1995,rotation:7.51,x:17.65,y:-38.1},38,cjs.Ease.sineInOut).to({regX:0,regY:0,scaleX:1,scaleY:1,rotation:0,x:-31.6,y:-78.1},41,cjs.Ease.sineInOut).wait(1));

	// Layer_4
	this.instance_1 = new lib.motion_graphics_1_bars();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-110.4,5.1,0.0824,1,-17.7103,0,0,-0.8,-0.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(38).to({_off:false},0).to({regX:0,regY:0,scaleX:1,rotation:0,x:-34.95,y:-24.8},41,cjs.Ease.sineOut).wait(1));

	// Layer_13
	this.instance_2 = new lib.Tween29("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(135.35,89.45,0.1325,0.1325,59.4675);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regY:-0.1,scaleX:0.8986,scaleY:0.8986,rotation:-32.5815,x:-91.8,y:-104},38,cjs.Ease.sineInOut).to({regY:0,scaleX:1,scaleY:1,rotation:0,x:0,y:-13},41,cjs.Ease.sineInOut).wait(1));

	// Layer_16
	this.instance_3 = new lib.Tween30("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(114.1,-35.7,0.02,0.02,0,0,0,2.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:2.7,regY:0.1,scaleX:1.1991,scaleY:1.1991,rotation:102.7704,x:-88.85,y:13.35},38,cjs.Ease.sineInOut).to({regX:0,regY:0,scaleX:1,scaleY:1,rotation:0,x:-68.9,y:67.25},41,cjs.Ease.sineInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-128.2,-218.2,272.2,323);


(lib.Motion_clip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_28 = function() {
		this.stop();
	}
	this.frame_109 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(28).call(this.frame_28).wait(81).call(this.frame_109).wait(51));

	// Layer 1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(0.65,0.25,0.2,0.2,0,0,0,0.3,0.3);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0,regY:0,scaleX:1,scaleY:1,alpha:1},19,cjs.Ease.cubicOut).to({startPosition:0},10,cjs.Ease.cubicInOut).to({scaleX:0.9,scaleY:0.9,x:-40.9,y:51.25},40,cjs.Ease.cubicInOut).to({scaleX:1,scaleY:1,x:-50.35,y:-43.75},40,cjs.Ease.cubicInOut).wait(51));

	// Layer_6
	this.instance_1 = new lib.motion_graphics_1("synched",0,false);
	this.instance_1.parent = this;
	this.instance_1.setTransform(-52.2,92.1,0.85,0.85,0,0,0,-0.2,0.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(29).to({_off:false},0).wait(131));

	// Layer_18
	this.instance_2 = new lib.motion_graphics_2("synched",0,false);
	this.instance_2.parent = this;
	this.instance_2.setTransform(97.3,33.8,0.85,0.85,0,0,0,0.2,0.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(29).to({_off:false},0).wait(131));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D7D7D7").ss(1,1,1).p("A3b4NMAu3AAAMAAAAwbMgu3AAAg");

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A3bYOMAAAgwbMAu3AAAMAAAAwbg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(160));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-161,-161.1,418,342.2);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.grey_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.icons.cache(-135,-15,270,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.greyicons();
	this.icons.name = "icons";
	this.icons.parent = this;
	this.icons.setTransform(66.3,5.9,1,1,0,0,0,66.3,5.9);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

}).prototype = getMCSymbolPrototype(lib.grey_icons, new cjs.Rectangle(0,0,132.6,11.8), null);


(lib.bottom_icons = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.icons.cache(-215,-15,430,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icons = new lib.bottomicons();
	this.icons.name = "icons";
	this.icons.parent = this;
	this.icons.setTransform(107.5,6.7,1,1,0,0,0,107.5,6.7);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottom_icons, new cjs.Rectangle(0,0,214.9,13.3), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.Add_UI_more_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.plus_btn();
	this.instance.parent = this;
	this.instance.setTransform(1.25,-0.55);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D7D7D7").ss(1,1,1).p("AC9JjIl5AAIAAzFIF5AA");
	this.shape.setTransform(-0.25,0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ai8JjIAAzFIF5AAIAATFg");
	this.shape_1.setTransform(-0.25,0.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Add_UI_more_btn, new cjs.Rectangle(-20.1,-62.1,39.8,124.30000000000001), null);


(lib.UI_layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Top_bar
	this.instance = new lib.Share_txt();
	this.instance.parent = this;
	this.instance.setTransform(223.7,50.15,1,1,0,0,0,10.2,6.3);

	this.instance_1 = new lib.Comments_txt();
	this.instance_1.parent = this;
	this.instance_1.setTransform(270.05,50.1,1,1,0,0,0,17.6,6.3);

	this.instance_2 = new lib.grey_icons();
	this.instance_2.parent = this;
	this.instance_2.setTransform(225.8,42.95,1,1,0,0,0,66.3,5.9);

	this.instance_3 = new lib.ON_txt();
	this.instance_3.parent = this;
	this.instance_3.setTransform(53.1,22.15,1,1,0,0,0,6.3,6.2);

	this.instance_4 = new lib.top_left();
	this.instance_4.parent = this;
	this.instance_4.setTransform(71.2,16.3,1,1,0,0,0,26.1,5.2);

	this.instance_5 = new lib.top_right();
	this.instance_5.parent = this;
	this.instance_5.setTransform(267.15,16.1,1,1,0,0,0,23.9,3.3);

	this.instance_6 = new lib.AutoSave_txt();
	this.instance_6.parent = this;
	this.instance_6.setTransform(27,23.85,1,1,0,0,0,17.8,7);

	this.instance_7 = new lib.Excel_txt();
	this.instance_7.parent = this;
	this.instance_7.setTransform(135.75,25.4,1,1,0,0,0,13.5,8.6);

	this.instance_8 = new lib.Name_txt();
	this.instance_8.parent = this;
	this.instance_8.setTransform(214.1,23.85,1,1,0,0,0,25.6,6.8);

	this.instance_9 = new lib.Home_txt();
	this.instance_9.parent = this;
	this.instance_9.setTransform(21.6,50.85,1,1,0,0,0,12.4,7);

	this.instance_10 = new lib.Insert_txt();
	this.instance_10.parent = this;
	this.instance_10.setTransform(58.85,50.8,1,1,0,0,0,11.3,7);

	this.instance_11 = new lib.PageLayout_txt();
	this.instance_11.parent = this;
	this.instance_11.setTransform(106.5,50.8,1,1,0,0,0,22.4,7);

	this.instance_12 = new lib.Formulas_txt();
	this.instance_12.parent = this;
	this.instance_12.setTransform(135.15,50.8,1,1,0,0,0,17.2,7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7472A").s().p("AhoAGIAAgLIDRAAIAAALg");
	this.shape.setTransform(22.025,49.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F1F1F1").s().p("A3bB0IAAjnMAu3AAAIAADng");
	this.shape_1.setTransform(150.0019,43.8492);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7472A").s().p("A3bChIAAlBMAu3AAAIAAFBg");
	this.shape_2.setTransform(150,16.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Bottom_bar
	this.instance_13 = new lib.bottom_icons();
	this.instance_13.parent = this;
	this.instance_13.setTransform(186.8,591.3,1,1,0,0,0,107.5,6.7);

	this.instance_14 = new lib.Notes_txtcopy();
	this.instance_14.parent = this;
	this.instance_14.setTransform(97.9,597.9,1,1,0,0,0,11.5,6.7);

	this.instance_15 = new lib.Ready_txt();
	this.instance_15.parent = this;
	this.instance_15.setTransform(18.25,596.85,1,1,0,0,0,11.5,6.7);

	this.instance_16 = new lib.Percentage_txt();
	this.instance_16.parent = this;
	this.instance_16.setTransform(274.6,597.5,1,1,0,0,0,10.1,6.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F3F2F1").s().p("A3bBoIAAjPMAu3AAAIAADPg");
	this.shape_3.setTransform(150,591.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_layout, new cjs.Rectangle(0,0,300,604.7), null);


(lib.screenAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_1 = function() {
		this.motiongraphics.play();
	}
	this.frame_82 = function() {
		this.motiongraphics.play();
	}
	this.frame_205 = function() {
		this.stop()
			exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(81).call(this.frame_82).wait(123).call(this.frame_205).wait(1));

	// hand
	this.instance = new lib.pointer("single",0);
	this.instance.parent = this;
	this.instance.setTransform(340.05,437.8,1,1,0,0,0,14,16.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(46).to({_off:false},0).to({x:194,y:101.9},23,cjs.Ease.quadOut).wait(11).to({startPosition:0},0).wait(2).to({regX:14.1,x:194.1,startPosition:1},0).wait(4).to({regX:14,x:194,startPosition:0},0).wait(22).to({startPosition:0},0).to({x:264,y:176.9},15,cjs.Ease.quadInOut).wait(57).to({startPosition:0},0).to({x:373.75,y:231.1},21,cjs.Ease.cubicIn).to({_off:true},1).wait(4));

	// UI
	this.instance_1 = new lib.UI_layout();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,299.2,1,1,0,0,0,150,299.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(206));

	// Layer_5
	this.instance_2 = new lib.Add_UI_more_btn();
	this.instance_2.parent = this;
	this.instance_2.setTransform(281.3,520.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(206));

	// Layer_6
	this.instance_3 = new lib.Add_UI_preview();
	this.instance_3.parent = this;
	this.instance_3.setTransform(9,61,0.8,0.8);

	this.instance_4 = new lib.Add_UI_none();
	this.instance_4.parent = this;
	this.instance_4.setTransform(90,60,0.8,0.8);

	this.instance_5 = new lib.Add_UI_morph();
	this.instance_5.parent = this;
	this.instance_5.setTransform(166,60,0.8,0.8);

	this.instance_6 = new lib.Add_UI_effectoptions();
	this.instance_6.parent = this;
	this.instance_6.setTransform(257,59,0.8,0.8);

	this.instance_7 = new lib.Add_UI_Tile_3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(249,531.5);

	this.instance_8 = new lib.Add_UI_Tile_2();
	this.instance_8.parent = this;
	this.instance_8.setTransform(165.5,531.5);

	this.instance_9 = new lib.Add_UI_Tile_1();
	this.instance_9.parent = this;
	this.instance_9.setTransform(64.5,531.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3}]}).wait(206));

	// Add_UI_txt
	this.instance_10 = new lib.add_effectoptions_txt();
	this.instance_10.parent = this;
	this.instance_10.setTransform(265.1,98.7,1,1,0,0,0,11.5,6.7);

	this.instance_11 = new lib.add_morph_txt();
	this.instance_11.parent = this;
	this.instance_11.setTransform(184.1,100.95,1,1,0,0,0,11.5,6.7);

	this.instance_12 = new lib.add_none_txt();
	this.instance_12.parent = this;
	this.instance_12.setTransform(110.55,100.95,1,1,0,0,0,11.5,6.7);

	this.instance_13 = new lib.add_preview_txt();
	this.instance_13.parent = this;
	this.instance_13.setTransform(17.05,100.95,1,1,0,0,0,11.5,6.7);

	this.instance_14 = new lib.add_slide_txt();
	this.instance_14.parent = this;
	this.instance_14.setTransform(20.55,487.1,1,1,0,0,0,11.5,6.7);

	this.instance_15 = new lib.add_3_txt();
	this.instance_15.parent = this;
	this.instance_15.setTransform(222.35,505.15,1,1,0,0,0,11.5,6.7);

	this.instance_16 = new lib.add_2_txt();
	this.instance_16.parent = this;
	this.instance_16.setTransform(123.1,505.15,1,1,0,0,0,11.5,6.7);

	this.instance_17 = new lib.add_1_txt();
	this.instance_17.parent = this;
	this.instance_17.setTransform(21.55,505.15,1,1,0,0,0,11.5,6.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10}]}).wait(206));

	// Add_UI_highlight
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E43E24").ss(1,1,1).p("AlJjWIKTAAQAoAAAAAoIAAFdQAAAogoAAIqTAAQgoAAAAgoIAAldQAAgoAoAAg");
	this.shape.setTransform(111.075,80.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F8C4B6").s().p("AlJDXQgoAAAAgoIAAldQAAgoAoAAIKTAAQAoAAAAAoIAAFdQAAAogoAAg");
	this.shape_1.setTransform(111.075,80.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{x:111.075}},{t:this.shape,p:{x:111.075}}]}).to({state:[{t:this.shape_1,p:{x:186.975}},{t:this.shape,p:{x:186.975}}]},83).wait(123));

	// flash0.ai
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#6D6E6E").s().p("AgRgkIAkAkIgkAlg");
	this.shape_2.setTransform(241.5529,81.0004);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E4E6E4").s().p("AgHD4IAAnvIAPAAIAAHvg");
	this.shape_3.setTransform(49.5,80.9754);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#E4E6E4").p("AO/DzI99AAQgIAAgGgGQgGgFAAgJIAAm9QAAgJAGgFQAGgGAIAAId9AAQAIAAAGAGQAGAFAAAJIAAG9QAAAJgGAFQgGAGgIAAg");
	this.shape_4.setTransform(152.7516,81.0004);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Au9DzQgJAAgGgGQgFgFgBgJIAAm9QABgJAFgFQAGgGAJAAId8AAQAIAAAFAGQAHAFAAAJIAAG9QAAAJgHAFQgFAGgIAAg");
	this.shape_5.setTransform(152.7516,81.0004);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(206));

	// Add_UI
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D7D7D7").ss(1,1,1).p("EgXbggYMAu3AAAIAADVMgu3AAAgEgXbggYMAu3AAAIAAoyMgu3AAAgA3bTHMAu3AAAIAADBMgu3AAAgEgXbApLMAu3AAAIAAzBMgu3AAAg");
	this.shape_6.setTransform(150,317.675);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F1F1F1").s().p("EgXbApLIAAzBMAu3AAAIAATBgA3bWIIAAjBMAu3AAAIAADBgA3b9DIAAjVMAu3AAAIAADVgEgXbggYIAAoyMAu3AAAIAAIyg");
	this.shape_7.setTransform(150,317.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(206));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bYYMAAAgwvMAu3AAAMAAAAwvg");
	mask.setTransform(150,285);

	// Motion_graphics_canvas
	this.motiongraphics = new lib.Motion_clip();
	this.motiongraphics.name = "motiongraphics";
	this.motiongraphics.parent = this;
	this.motiongraphics.setTransform(150,285);

	var maskedShapeInstanceList = [this.motiongraphics];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.motiongraphics).wait(206));

	// ScreenBG
	this.instance_18 = new lib.ScreenBG();
	this.instance_18.parent = this;
	this.instance_18.setTransform(150,163,1,1,0,0,0,150,98);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(206));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,0,389,605);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-11.6,-0.65,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("ApyCjIAAlFITkAAIAAFFg");
	this.shape.setTransform(-37.5,-1.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-100.1,-17.5,125.3,32.6), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_51 = function() {
		exportRoot.tl1.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(51).call(this.frame_51).wait(23).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298,898.75,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:898.5},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgGoBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("EgG4BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("EgHmBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("EgIzBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("EgKeBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("EgMpBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("EgPSBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("EgR7BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("EgUGBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("EgVxBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("EgW+BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("EgXsBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("EgX8BK6IAAyrMBGZAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:479.4334}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:479.4334}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:479.4334}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:479.4334}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:479.4334}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:479.4334}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:479.4334}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:479.4334}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:479.4334}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:479.4334}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:479.4334}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:479.4334}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:479.4334}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.9,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:300.35},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhMxCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTfCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhaiCXxMAAAkvhMCXsAAAMAAAEvhg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:903.6504}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:903.6504}).wait(1).to({graphics:mask_1_graphics_52,x:295.8292,y:903.6504}).wait(1).to({graphics:mask_1_graphics_53,x:289.2197,y:903.6504}).wait(1).to({graphics:mask_1_graphics_54,x:278.2038,y:903.6504}).wait(1).to({graphics:mask_1_graphics_55,x:262.7816,y:903.6504}).wait(1).to({graphics:mask_1_graphics_56,x:242.953,y:903.6504}).wait(1).to({graphics:mask_1_graphics_57,x:218.7181,y:903.6504}).wait(1).to({graphics:mask_1_graphics_58,x:190.0769,y:903.6504}).wait(1).to({graphics:mask_1_graphics_59,x:157.0292,y:903.6504}).wait(1).to({graphics:mask_1_graphics_60,x:119.5753,y:903.6504}).wait(1).to({graphics:mask_1_graphics_61,x:77.7149,y:903.6504}).wait(1).to({graphics:mask_1_graphics_62,x:31.4483,y:903.6504}).wait(1).to({graphics:mask_1_graphics_63,x:-19.2247,y:903.6504}).wait(1).to({graphics:mask_1_graphics_64,x:-74.3041,y:903.6504}).wait(1).to({graphics:mask_1_graphics_65,x:-133.7898,y:903.6504}).wait(1).to({graphics:mask_1_graphics_66,x:-197.6819,y:903.6504}).wait(1).to({graphics:mask_1_graphics_67,x:-265.9803,y:903.6504}).wait(1).to({graphics:mask_1_graphics_68,x:-338.6851,y:903.6504}).wait(1).to({graphics:mask_1_graphics_69,x:-415.7962,y:903.6504}).wait(1).to({graphics:mask_1_graphics_70,x:-491.398,y:903.6504}).wait(1).to({graphics:mask_1_graphics_71,x:-534.3599,y:903.6504}).wait(1).to({graphics:mask_1_graphics_72,x:-579.525,y:903.6504}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-673.65},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-666.45},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1159,-67.6,1942.5,1942.6);


(lib.anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Logo
	this.logo_white = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_white.name = "logo_white";
	this.logo_white.parent = this;
	this.logo_white.setTransform(122.85,487.45,0.2111,0.2111,0,0,0,434.4,2163.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_white).wait(5));

	// transition
	this.wipe = new lib.transition_wipe();
	this.wipe.name = "wipe";
	this.wipe.parent = this;
	this.wipe.setTransform(375,300.1,0.5,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.wipe).wait(5));

	// scene4
	this.scene_4 = new lib.scene4();
	this.scene_4.name = "scene_4";
	this.scene_4.parent = this;
	this.scene_4.setTransform(200,236,1,1,0,0,0,200,236);

	this.timeline.addTween(cjs.Tween.get(this.scene_4).wait(5));

	// Screen
	this.screenAnim = new lib.screenAnim();
	this.screenAnim.name = "screenAnim";
	this.screenAnim.parent = this;
	this.screenAnim.setTransform(150,302.4,1,1,0,0,0,150,302.4);

	this.timeline.addTween(cjs.Tween.get(this.screenAnim).wait(5));

	// scene1
	this.scene_1 = new lib.scene_1();
	this.scene_1.name = "scene_1";
	this.scene_1.parent = this;
	this.scene_1.setTransform(121,510,1,1,0,0,0,668,629);

	this.timeline.addTween(cjs.Tween.get(this.scene_1).to({_off:true},1).wait(4));

	// Logo
	this.logo_grey = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_grey.name = "logo_grey";
	this.logo_grey.parent = this;
	this.logo_grey.setTransform(66.85,38.45,0.2111,0.2111,0,0,0,169.1,36.3);

	this.timeline.addTween(cjs.Tween.get(this.logo_grey).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1110.1,-3554,2399.8,4799.7);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// intro logo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(225.2,554.85,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(277.4,556.4,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Anim
	this.animMC = new lib.anim();
	this.animMC.name = "animMC";
	this.animMC.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.animMC).wait(1));

	// BG
	this.bg = new lib.whiteBG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(150,124.95,1,0.4141,0,0,0,150,301.7);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-0.9,-1.4,450.9,606.1), null);


// stage content:
(lib.O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.animMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		this.runBanner = function() {
			
			
			
			
			exportRoot.tl1 = new TimelineLite();
			
			this.tl1.stop();
			mc.logo_intro.gotoAndPlay(1);
			
			//scene1 parallax
			//exportRoot.tl1.from(mc.animMC.scene_1.fg, 2,{x:"+=150", ease:Power3.easeOut});
			//exportRoot.tl1.from(mc.animMC.scene_1.bg, 2,{x:"+=75", ease:Power3.easeOut}, "-=2");
			
			//zoom in
			exportRoot.tl1.from(mc.animMC.screenAnim, 0.7,{alpha:0, scaleX:0.9, scaleY:0.256, x:"+=15", y:"+=54", ease: Power3.easeInOut}, "+=1");
			exportRoot.tl1.to(mc.animMC.scene_1, 0.7,{ scaleX:3.96, scaleY:3.96, y:"+=498", ease:Power3.easeInOut,onComplete: function(){mc.animMC.screenAnim.play(); mc.animMC.scene_1.alpha=0; exportRoot.tl1.stop();}}, "-=0.7");
			exportRoot.tl1.to(mc.animMC.logo_white, 0.7,{ scaleX:3.96, scaleY:3.96, ease:Power3.easeInOut}, "-=0.7");
			
			//final Scene 
			exportRoot.tl1.to(mc.animMC.screenAnim, 1,{x:"-=300", ease:Power4.easeInOut});
			//exportRoot.tl1.from(mc.animMC.scene_3, .7,{scaleX:8, scaleY:8, x:"-=80", y:"+=515", ease:Power3.easeInOut},"-=.7");
			//exportRoot.tl1.to(mc.animMC.scene_3, 2,{ y:"-=600", ease:Power4.easeInOut},"+=2");
			exportRoot.tl1.to(mc.animMC.wipe, 1,{x:"-=525", scaleX:1, ease:Power2.easeInOut},"-=1");
			//exportRoot.tl1.to(mc.animMC.wipe_mask, 2,{y:"-=860", scaleY:.2, ease:Power3.easeInOut},"-=2");
			exportRoot.tl1.from(mc.animMC.scene_4, 1,{ x:"+=300", ease:Power4.easeInOut},"-=1");
		
			exportRoot.tl1.stop();
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
					for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
		
			exportRoot.tl1.from(mc.cta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl1.from(mc.txtCta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "-=0.7");
			
			
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149.1,298.6,300.9,306.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#0078D4",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_.png?1566815292383", id:"O365_GIgWorkers_USA_300x600_BAN_Designer_PPT_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;