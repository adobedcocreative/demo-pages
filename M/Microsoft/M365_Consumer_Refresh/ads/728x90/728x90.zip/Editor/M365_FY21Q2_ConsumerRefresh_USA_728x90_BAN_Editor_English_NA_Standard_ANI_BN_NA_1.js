(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1", frames: [[0,373,119,120],[502,0,500,333],[243,373,31,32],[0,0,500,371],[121,373,120,111],[502,335,500,333]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.avatar = function() {
	this.initialize(ss["M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.blur_BG = function() {
	this.initialize(ss["M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.earth = function() {
	this.initialize(ss["M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.UI = function() {
	this.initialize(ss["M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4OAWyMAAAgtjMFwdAAAMAAAAtjg");
	this.shape.setTransform(0.0046,0.0301);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1179.1,-145.7,2358.3,291.5);


(lib.tile_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.text_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgCAmIAAhLIAFAAIAABLg");
	this.shape.setTransform(121.475,22.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgPAYQgGgFABgHQgBgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgEAAgEADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAFgCAEgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAEgCADgDQACgEAAgEIAAgGg");
	this.shape_1.setTransform(117.8,23.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIgBgDIABgEQABAAAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADABIACAEIgCADIgDABIgDgBg");
	this.shape_2.setTransform(114.3,22.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#505050").s().p("AgLAYQgFgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAFgDAHgBQAGABAFACQAFACADAEQACAEABAFIgGAAQgBgFgFgDQgEgDgGgBQgHABgFAFQgFAGAAAJQAAAKAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFIAGAAQgBAHgGAFQgGAFgJAAQgGAAgGgEg");
	this.shape_3.setTransform(110.725,23.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAFgDAHgBQAHABAGADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgGAEgHAAQgHAAgFgEgAgMgPQgFAGAAAJQAAAKAFAGQAFAGAHAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgHABgFAFg");
	this.shape_4.setTransform(105.25,23.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_5.setTransform(100.075,23.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_6.setTransform(92.675,23.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#505050").s().p("AgLAcIAAg2IAGAAIAAAKIAAAAQACgFADgDQADgCAFAAIACAAIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAhg");
	this.shape_7.setTransform(88.575,23.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgDgGAAgJQAAgHADgHQADgGAFgDQAGgDAGgBQAHABAGADQAFADAEAGQACAHABAHQgBAJgCAGQgEAGgFADQgGAEgHAAQgGAAgGgEgAgMgPQgFAGAAAJQAAAKAFAGQAFAGAHAAQAIAAAFgGQAFgGgBgKQABgJgFgGQgFgFgIgBQgHABgFAFg");
	this.shape_8.setTransform(83.95,23.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#505050").s().p("AAeAcIAAgjQAAgGgEgDQgDgEgGAAQgGAAgEAEQgEAEAAAGIAAAiIgFAAIAAgkQAAgFgEgEQgDgDgGAAQgGAAgEAEQgEAFAAAGIAAAhIgGAAIAAg2IAGAAIAAAKIAAAAQACgFAEgDQAEgCAGAAQAGAAAEADQADADACAFQACgFAEgDQAFgDAGAAQAIAAAFAEQAEAGAAAIIAAAkg");
	this.shape_9.setTransform(76.925,23.35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_10.setTransform(67.725,23.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#505050").s().p("AAeAcIAAgjQAAgGgEgDQgDgEgGAAQgGAAgEAEQgEAEAAAGIAAAiIgFAAIAAgkQAAgFgEgEQgDgDgGAAQgGAAgEAEQgEAFAAAGIAAAhIgGAAIAAg2IAGAAIAAAKIAAAAQACgFAEgDQAEgCAGAAQAGAAAEADQADADACAFQACgFAEgDQAFgDAGAAQAIAAAFAEQAEAGAAAIIAAAkg");
	this.shape_11.setTransform(60.775,23.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#505050").s().p("AgMAYQgFgDgEgGQgDgGAAgJQAAgHADgHQAEgGAFgDQAGgDAGgBQAHABAGADQAFADADAGQADAHAAAHQAAAJgDAGQgDAGgFADQgGAEgHAAQgGAAgGgEgAgMgPQgFAGAAAJQAAAKAFAGQAFAGAHAAQAIAAAFgGQAFgGAAgKQAAgJgFgGQgFgFgIgBQgHABgFAFg");
	this.shape_12.setTransform(53.75,23.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#505050").s().p("AgLAYQgFgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAFgDAHgBQAGABAFACQAFACADAEQACAEABAFIgGAAQgBgFgFgDQgEgDgGgBQgHABgFAFQgFAGAAAJQAAAKAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFIAGAAQgBAHgGAFQgGAFgJAAQgGAAgGgEg");
	this.shape_13.setTransform(48.375,23.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_14.setTransform(43.025,23.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#505050").s().p("AgJAjQgFgDgDgGIAAAMIgGAAIAAhLIAGAAIAAAgIABAAQACgFAFgDQAFgDAFAAQAHAAAFADQAFAEADAGQADAFAAAIQAAAJgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDgAgIgHQgEACgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_15.setTransform(37.625,22.35);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_16.setTransform(29.875,23.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#505050").s().p("AgMAjQgGgEgCgGQgDgGAAgJQAAgIACgFQADgGAGgEQAFgDAHAAQAFAAAFADQAFADACAFIAAggIAHAAIAABLIgGAAIAAgMQgDAGgFADQgFADgFAAQgHAAgFgDgAgIgHQgEACgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_17.setTransform(24.475,22.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#505050").s().p("AAPAcIAAgiQAAgGgEgEQgDgEgHAAQgHAAgEAEQgEAFAAAHIAAAgIgHAAIAAg2IAGAAIAAAKIABAAQACgFAEgDQAFgCAGAAQAJAAAFAFQAFAFAAAJIAAAjg");
	this.shape_18.setTransform(18.975,23.35);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgFAAgDADQgEADgBAFIgHAAQABgFADgEQACgDAFgCQAEgCAFgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCACgDQACgEAAgEIAAgGg");
	this.shape_19.setTransform(13.5,23.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#505050").s().p("AgLAcIAAg2IAGAAIAAAKIAAAAQACgFADgDQADgCAFAAIACAAIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAhg");
	this.shape_20.setTransform(9.575,23.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#505050").s().p("AgJAjQgFgDgDgGIAAAMIgGAAIAAhLIAGAAIAAAgIABAAQACgFAFgDQAFgDAFAAQAHAAAFADQAFAEADAGQADAFAAAIQAAAJgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDgAgIgHQgEACgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_21.setTransform(5.075,22.35);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#505050").s().p("AgNAhQgHgDgBgHIAIAAQABADADADQAFACAEAAQAJAAAEgDQAFgEgBgGIAAgMQgCAGgFADQgFADgGABQgGgBgFgDQgFgDgEgHQgCgFAAgIQAAgJACgFQAEgHAFgDQAFgDAHgBQAFABAGADQAEADACAFIAAgLIAHAAIAAA0QAAAGgDAFQgDAEgFACQgFADgIAAQgIAAgFgEgAgJgbQgDACgCAFQgCAGgBAGQABAHACADQACAFADADQAEACAFABQAFgBAEgCQAEgDACgFQACgEAAgGQAAgGgCgGQgCgFgEgCQgEgDgFAAQgFAAgEADg");
	this.shape_22.setTransform(179,10);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#505050").s().p("AAPAbIAAghQAAgHgEgEQgDgDgHAAQgHAAgEAEQgEAFAAAIIAAAeIgHAAIAAg1IAGAAIAAAKIABAAQACgEAEgEQAFgCAGgBQAJABAFAFQAFAGAAAIIAAAig");
	this.shape_23.setTransform(173.525,9.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#505050").s().p("AgCAlIAAg1IAFAAIAAA1gAgCgcIgBgDIABgDQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIACADIgCADIgDABIgCgBg");
	this.shape_24.setTransform(169.8,8.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#505050").s().p("AgXAkIAAhHIAGAAIAAALQACgFAFgDQAFgDAGgBQAHABAFADQAFAEADAGQADAGAAAIQAAAIgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDQgFgEgCgEIgBAAIAAAcgAgIgbQgEADgCAFQgDAFAAAGQAAAHADAEQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgEAAgHQAAgGgCgFQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_25.setTransform(166.075,9.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#505050").s().p("AgCAmIAAhLIAFAAIAABLg");
	this.shape_26.setTransform(162.075,8.025);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_27.setTransform(158.425,9.075);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#505050").s().p("AAQAmIAAgiQAAgGgFgEQgDgEgHAAQgGAAgFAFQgEAEgBAHIAAAgIgGAAIAAhLIAGAAIAAAgIABAAQACgFAEgDQAFgDAFAAQAKAAAFAFQAFAGAAAIIAAAjg");
	this.shape_28.setTransform(152.95,8.025);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#505050").s().p("AgLAbIAAg1IAGAAIAAAKIAAAAQACgFADgDQADgCAFgBIACABIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAgg");
	this.shape_29.setTransform(146.425,9.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAGgDAGgBQAIABAFADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgFAEgIAAQgGAAgGgEgAgMgPQgFAGAAAJQAAAKAFAGQAEAGAIAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgIABgEAFg");
	this.shape_30.setTransform(141.8,9.075);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#505050").s().p("AgEAlIAAgwIgIAAIAAgFIAIAAIAAgGQAAgIADgDQADgDAGAAIADAAIACAAIAAAGIgCgBIgCAAQgEAAgCACQgBADAAAEIAAAGIALAAIAAAFIgLAAIAAAwg");
	this.shape_31.setTransform(137.425,8.1);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#505050").s().p("AgMAjQgGgEgCgGQgDgGAAgJQAAgIACgFQADgGAGgEQAFgDAHgBQAFABAFADQAFADACAFIAAggIAHAAIAABKIgGAAIAAgLQgDAGgFADQgFADgFAAQgHAAgFgDgAgIgIQgEADgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_32.setTransform(130.775,8.05);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_33.setTransform(125.325,9.075);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_34.setTransform(120.225,9.075);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIgBgDIABgDQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIABADIgBADIgDABIgDgBg");
	this.shape_35.setTransform(116.85,8.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#505050").s().p("AgPAYQgFgFgBgHQABgHAFgEQAEgDAKAAIAQgBIAAgFQAAgGgEgDQgDgEgHAAQgEAAgEADQgEADgBAFIgGAAQAAgFADgEQADgDAEgCQAFgCAEgBQAKABAFAEQAFAFAAAIIAAAkIgGAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCABgDQADgEAAgEIAAgGg");
	this.shape_36.setTransform(113.15,9.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#505050").s().p("AgLAbIAAg1IAGAAIAAAKIAAAAQACgFADgDQADgCAFgBIACABIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAgg");
	this.shape_37.setTransform(109.225,9.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#505050").s().p("AgXAkIAAhHIAGAAIAAALQACgFAFgDQAFgDAGgBQAHABAFADQAFAEADAGQADAGAAAIQAAAIgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDQgFgEgCgEIgBAAIAAAcgAgIgbQgEADgCAFQgDAFAAAGQAAAHADAEQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgEAAgHQAAgGgCgFQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_38.setTransform(104.675,9.95);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#505050").s().p("AAPAbIAAghQAAgHgEgEQgDgDgHAAQgHAAgEAEQgEAFAAAIIAAAeIgHAAIAAg1IAGAAIAAAKIABAAQACgEAEgEQAFgCAGgBQAJABAFAFQAFAGAAAIIAAAig");
	this.shape_39.setTransform(96.625,9.05);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_40.setTransform(91.175,9.075);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_41.setTransform(85.775,9.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#505050").s().p("AgJAjQgFgDgDgGIAAALIgGAAIAAhKIAGAAIAAAgIABAAQACgFAFgDQAFgDAFgBQAHABAFADQAFAEADAGQADAFAAAIQAAAJgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDgAgIgIQgEADgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_42.setTransform(80.375,8.05);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_43.setTransform(72.625,9.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgFAAgDADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAEgCAFgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCACgDQACgEAAgEIAAgGg");
	this.shape_44.setTransform(67.5,9.075);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#505050").s().p("AAPAmIAAgiQAAgGgDgEQgEgEgHAAQgGAAgFAFQgEAEAAAHIAAAgIgHAAIAAhLIAHAAIAAAgIAAAAQACgFAFgDQAEgDAGAAQAJAAAFAFQAFAGAAAIIAAAjg");
	this.shape_45.setTransform(62.2,8.025);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#505050").s().p("AgPAYQgGgFABgHQgBgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgEAAgEADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAFgCAEgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAEgCADgDQACgEAAgEIAAgGg");
	this.shape_46.setTransform(54.35,9.075);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIgBgDIABgDQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIABADIgBADIgDABIgDgBg");
	this.shape_47.setTransform(50.85,8.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#505050").s().p("AgMAjQgGgEgCgGQgDgGAAgJQAAgIACgFQADgGAGgEQAFgDAHgBQAFABAFADQAFADACAFIAAggIAHAAIAABKIgGAAIAAgLQgDAGgFADQgFADgFAAQgHAAgFgDgAgIgIQgEADgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_48.setTransform(46.875,8.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_49.setTransform(41.425,9.075);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#505050").s().p("AAeAbIAAgiQAAgGgEgEQgDgDgGAAQgGAAgEAEQgEAEAAAGIAAAhIgFAAIAAgjQAAgFgEgEQgDgDgGAAQgGAAgEAEQgEAFAAAGIAAAgIgGAAIAAg1IAGAAIAAAKIAAAAQACgEAEgEQAEgCAGgBQAGABAEADQADADACAFQACgFAEgDQAFgDAGgBQAIABAFAFQAEAEAAAIIAAAkg");
	this.shape_50.setTransform(34.475,9.05);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#505050").s().p("AgCAmIAAhLIAFAAIAABLg");
	this.shape_51.setTransform(26.975,8.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgEAAgEADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAFgCAEgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAEgCADgDQACgEAAgEIAAgGg");
	this.shape_52.setTransform(23.3,9.075);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIAAgDIAAgDQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIABADIgBADIgDABIgDgBg");
	this.shape_53.setTransform(19.8,8.1);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#505050").s().p("AgLAYQgFgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAFgDAHgBQAGABAFACQAFACADAEQACAEABAFIgGAAQgBgFgFgDQgEgDgGgBQgHABgFAFQgFAGAAAJQAAAKAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFIAGAAQgBAHgGAFQgGAFgJAAQgGAAgGgEg");
	this.shape_54.setTransform(16.225,9.075);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAFgDAHgBQAHABAGADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgGAEgHAAQgHAAgFgEgAgMgPQgFAGAAAJQAAAKAFAGQAEAGAIAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgIABgEAFg");
	this.shape_55.setTransform(10.75,9.075);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#505050").s().p("AgMAjQgGgDgEgFQgDgEAAgGIAGAAQABAEACADQADADAFACQAEACAFAAQAFAAAEgCQAFgBACgEQACgDAAgEQAAgFgDgDQgEgDgIgCIgIgDQgKgBgFgFQgFgEABgHQAAgGADgFQADgEAGgDQAFgCAGAAQAIAAAFACQAGADADAEQADAFAAAFIgHAAQAAgGgFgEQgFgDgIAAQgEAAgEACQgEABgCADQgCADAAAEQAAAFADADQAEADAIACIAHACQALACAFAEQAEAFAAAHQAAAHgDAEQgDAFgGADQgGACgIAAQgHAAgFgCg");
	this.shape_56.setTransform(4.975,8.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_c, new cjs.Rectangle(0,0,186.5,30.6), null);


(lib.text_2ccopy = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgCAmIAAhLIAFAAIAABLg");
	this.shape.setTransform(159.825,22.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgFAAgDADQgEADgBAFIgHAAQABgFADgEQACgDAFgCQAEgCAFgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCACgDQACgEAAgEIAAgGg");
	this.shape_1.setTransform(156.15,23.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#505050").s().p("AAPAcIAAgiQAAgGgEgEQgDgEgHAAQgHAAgEAEQgEAFAAAHIAAAgIgHAAIAAg2IAGAAIAAAKIABAAQACgFAEgDQAFgCAGAAQAJAAAFAFQAFAFAAAJIAAAjg");
	this.shape_2.setTransform(150.875,23.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAFgDAHgBQAHABAGADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgGAEgHAAQgHAAgFgEgAgMgPQgFAGAAAJQAAAKAFAGQAEAGAIAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgIABgEAFg");
	this.shape_3.setTransform(145.3,23.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#505050").s().p("AgCAlIAAg1IAFAAIAAA1gAgCgcIgBgDIABgEQAAAAAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADABIACAEIgCADIgDABIgCgBg");
	this.shape_4.setTransform(141.55,22.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#505050").s().p("AgBAeQgDgDAAgHIAAgiIgIAAIAAgGIAIAAIAAgNIAGAAIAAANIALAAIAAAGIgLAAIAAAiQAAAEACACQABACAEAAIABAAIACAAIABAAIAAAFIgDAAIgCABQgHAAgCgEg");
	this.shape_5.setTransform(138.925,22.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#505050").s().p("AgQAYQgEgFgBgHQABgHAEgEQAFgDAKAAIAQgBIAAgFQAAgGgEgDQgDgEgHAAQgEAAgEADQgEADgBAFIgGAAQAAgFADgEQADgDAEgCQAFgCAEgBQAKABAFAEQAGAFgBAIIAAAkIgGAAIAAgKQgCAFgFADQgFADgGAAQgIAAgFgEgAAAACQgHAAgDADQgEADAAAEQAAAFAEACQADADAGAAIAIgCQAEgCABgDQADgEAAgEIAAgGg");
	this.shape_6.setTransform(134.85,23.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_7.setTransform(129.925,23.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#505050").s().p("AgLAcIAAg2IAGAAIAAAKIAAAAQACgFADgDQADgCAFAAIACAAIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAhg");
	this.shape_8.setTransform(126.125,23.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_9.setTransform(121.625,23.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#505050").s().p("AgDAbIgUg1IAHAAIAQAuIARguIAHAAIgVA1g");
	this.shape_10.setTransform(116.475,23.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#505050").s().p("AAPAcIAAgiQAAgGgEgEQgDgEgHAAQgHAAgEAEQgEAFAAAHIAAAgIgHAAIAAg2IAGAAIAAAKIABAAQACgFAEgDQAFgCAGAAQAJAAAFAFQAFAFAAAJIAAAjg");
	this.shape_11.setTransform(111.275,23.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAFgDAHgBQAHABAGADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgGAEgHAAQgHAAgFgEgAgMgPQgFAGAAAJQAAAKAFAGQAEAGAIAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgIABgEAFg");
	this.shape_12.setTransform(105.7,23.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#505050").s().p("AgLAYQgFgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAFgDAHgBQAGABAFACQAFACADAEQACAEABAFIgGAAQgBgFgFgDQgEgDgGgBQgHABgFAFQgFAGAAAJQAAAKAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFIAGAAQgBAHgGAFQgGAFgJAAQgGAAgGgEg");
	this.shape_13.setTransform(100.325,23.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_14.setTransform(92.675,23.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#505050").s().p("AgLAcIAAg2IAGAAIAAAKIAAAAQACgFADgDQADgCAFAAIACAAIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAhg");
	this.shape_15.setTransform(88.575,23.35);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgDgGAAgJQAAgHADgHQADgGAFgDQAGgDAGgBQAHABAGADQAFADAEAGQACAHABAHQgBAJgCAGQgEAGgFADQgGAEgHAAQgGAAgGgEgAgMgPQgFAGAAAJQAAAKAFAGQAFAGAHAAQAIAAAFgGQAFgGgBgKQABgJgFgGQgFgFgIgBQgHABgFAFg");
	this.shape_16.setTransform(83.95,23.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#505050").s().p("AAeAcIAAgjQAAgGgEgDQgDgEgGAAQgGAAgEAEQgEAEAAAGIAAAiIgFAAIAAgkQAAgFgEgEQgDgDgGAAQgGAAgEAEQgEAFAAAGIAAAhIgGAAIAAg2IAGAAIAAAKIAAAAQACgFAEgDQAEgCAGAAQAGAAAEADQADADACAFQACgFAEgDQAFgDAGAAQAIAAAFAEQAEAGAAAIIAAAkg");
	this.shape_17.setTransform(76.925,23.35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_18.setTransform(67.725,23.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#505050").s().p("AAeAcIAAgjQAAgGgEgDQgDgEgGAAQgGAAgEAEQgEAEAAAGIAAAiIgFAAIAAgkQAAgFgEgEQgDgDgGAAQgGAAgEAEQgEAFAAAGIAAAhIgGAAIAAg2IAGAAIAAAKIAAAAQACgFAEgDQAEgCAGAAQAGAAAEADQADADACAFQACgFAEgDQAFgDAGAAQAIAAAFAEQAEAGAAAIIAAAkg");
	this.shape_19.setTransform(60.775,23.35);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#505050").s().p("AgMAYQgFgDgEgGQgDgGAAgJQAAgHADgHQAEgGAFgDQAGgDAGgBQAHABAGADQAFADADAGQADAHAAAHQAAAJgDAGQgDAGgFADQgGAEgHAAQgGAAgGgEgAgMgPQgFAGAAAJQAAAKAFAGQAFAGAHAAQAIAAAFgGQAFgGAAgKQAAgJgFgGQgFgFgIgBQgHABgFAFg");
	this.shape_20.setTransform(53.75,23.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#505050").s().p("AgLAYQgFgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAFgDAHgBQAGABAFACQAFACADAEQACAEABAFIgGAAQgBgFgFgDQgEgDgGgBQgHABgFAFQgFAGAAAJQAAAKAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFIAGAAQgBAHgGAFQgGAFgJAAQgGAAgGgEg");
	this.shape_21.setTransform(48.375,23.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_22.setTransform(43.025,23.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#505050").s().p("AgJAjQgFgDgDgGIAAAMIgGAAIAAhLIAGAAIAAAgIABAAQACgFAFgDQAFgDAFAAQAHAAAFADQAFAEADAGQADAFAAAIQAAAJgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDgAgIgHQgEACgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_23.setTransform(37.625,22.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_24.setTransform(29.875,23.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#505050").s().p("AgMAjQgGgEgCgGQgDgGAAgJQAAgIACgFQADgGAGgEQAFgDAHAAQAFAAAFADQAFADACAFIAAggIAHAAIAABLIgGAAIAAgMQgDAGgFADQgFADgFAAQgHAAgFgDgAgIgHQgEACgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_25.setTransform(24.475,22.35);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#505050").s().p("AAPAcIAAgiQAAgGgEgEQgDgEgHAAQgHAAgEAEQgEAFAAAHIAAAgIgHAAIAAg2IAGAAIAAAKIABAAQACgFAEgDQAFgCAGAAQAJAAAFAFQAFAFAAAJIAAAjg");
	this.shape_26.setTransform(18.975,23.35);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgFAAgDADQgEADgBAFIgHAAQABgFADgEQACgDAFgCQAEgCAFgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCACgDQACgEAAgEIAAgGg");
	this.shape_27.setTransform(13.5,23.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#505050").s().p("AgLAcIAAg2IAGAAIAAAKIAAAAQACgFADgDQADgCAFAAIACAAIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAhg");
	this.shape_28.setTransform(9.575,23.35);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#505050").s().p("AgJAjQgFgDgDgGIAAAMIgGAAIAAhLIAGAAIAAAgIABAAQACgFAFgDQAFgDAFAAQAHAAAFADQAFAEADAGQADAFAAAIQAAAJgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDgAgIgHQgEACgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgCQgEgDgFAAQgEAAgEADg");
	this.shape_29.setTransform(5.075,22.35);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#505050").s().p("AgNAhQgHgDgBgHIAIAAQABADADADQAFACAEAAQAJAAAEgDQAFgEgBgGIAAgMQgCAGgFADQgFADgGABQgGgBgFgDQgFgDgEgHQgCgFAAgIQAAgJACgFQAEgHAFgDQAFgDAHgBQAFABAGADQAEADACAFIAAgLIAHAAIAAA0QAAAGgDAFQgDAEgFACQgFADgIAAQgIAAgFgEgAgJgbQgDACgCAFQgCAGgBAGQABAHACADQACAFADADQAEACAFABQAFgBAEgCQAEgDACgFQACgEAAgGQAAgGgCgGQgCgFgEgCQgEgDgFAAQgFAAgEADg");
	this.shape_30.setTransform(179,10);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#505050").s().p("AAPAbIAAghQAAgHgEgEQgDgDgHAAQgHAAgEAEQgEAFAAAIIAAAeIgHAAIAAg1IAGAAIAAAKIABAAQACgEAEgEQAFgCAGgBQAJABAFAFQAFAGAAAIIAAAig");
	this.shape_31.setTransform(173.525,9.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#505050").s().p("AgCAlIAAg1IAFAAIAAA1gAgCgcIgBgDIABgDQAAgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIACADIgCADIgDABIgCgBg");
	this.shape_32.setTransform(169.8,8.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#505050").s().p("AgXAkIAAhHIAGAAIAAALQACgFAFgDQAFgDAGgBQAHABAFADQAFAEADAGQADAGAAAIQAAAIgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDQgFgEgCgEIgBAAIAAAcgAgIgbQgEADgCAFQgDAFAAAGQAAAHADAEQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgEAAgHQAAgGgCgFQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_33.setTransform(166.075,9.95);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#505050").s().p("AgCAmIAAhLIAFAAIAABLg");
	this.shape_34.setTransform(162.075,8.025);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_35.setTransform(158.425,9.075);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#505050").s().p("AAQAmIAAgiQAAgGgFgEQgDgEgHAAQgGAAgFAFQgEAEgBAHIAAAgIgGAAIAAhLIAGAAIAAAgIABAAQACgFAEgDQAFgDAFAAQAKAAAFAFQAFAGAAAIIAAAjg");
	this.shape_36.setTransform(152.95,8.025);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#505050").s().p("AgLAbIAAg1IAGAAIAAAKIAAAAQACgFADgDQADgCAFgBIACABIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAgg");
	this.shape_37.setTransform(146.425,9.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAGgDAGgBQAIABAFADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgFAEgIAAQgGAAgGgEgAgMgPQgFAGAAAJQAAAKAFAGQAEAGAIAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgIABgEAFg");
	this.shape_38.setTransform(141.8,9.075);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#505050").s().p("AgEAlIAAgwIgIAAIAAgFIAIAAIAAgGQAAgIADgDQADgDAGAAIADAAIACAAIAAAGIgCgBIgCAAQgEAAgCACQgBADAAAEIAAAGIALAAIAAAFIgLAAIAAAwg");
	this.shape_39.setTransform(137.425,8.1);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#505050").s().p("AgMAjQgGgEgCgGQgDgGAAgJQAAgIACgFQADgGAGgEQAFgDAHgBQAFABAFADQAFADACAFIAAggIAHAAIAABKIgGAAIAAgLQgDAGgFADQgFADgFAAQgHAAgFgDgAgIgIQgEADgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_40.setTransform(130.775,8.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_41.setTransform(125.325,9.075);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_42.setTransform(120.225,9.075);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIgBgDIABgDQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIABADIgBADIgDABIgDgBg");
	this.shape_43.setTransform(116.85,8.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#505050").s().p("AgPAYQgFgFgBgHQABgHAFgEQAEgDAKAAIAQgBIAAgFQAAgGgEgDQgDgEgHAAQgEAAgEADQgEADgBAFIgGAAQAAgFADgEQADgDAEgCQAFgCAEgBQAKABAFAEQAFAFAAAIIAAAkIgGAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCABgDQADgEAAgEIAAgGg");
	this.shape_44.setTransform(113.15,9.075);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#505050").s().p("AgLAbIAAg1IAGAAIAAAKIAAAAQACgFADgDQADgCAFgBIACABIACAAIAAAHIgCAAIgDgBQgGAAgCAEQgEAEAAAHIAAAgg");
	this.shape_45.setTransform(109.225,9.05);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#505050").s().p("AgXAkIAAhHIAGAAIAAALQACgFAFgDQAFgDAGgBQAHABAFADQAFAEADAGQADAGAAAIQAAAIgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDQgFgEgCgEIgBAAIAAAcgAgIgbQgEADgCAFQgDAFAAAGQAAAHADAEQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgEAAgHQAAgGgCgFQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_46.setTransform(104.675,9.95);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#505050").s().p("AAPAbIAAghQAAgHgEgEQgDgDgHAAQgHAAgEAEQgEAFAAAIIAAAeIgHAAIAAg1IAGAAIAAAKIABAAQACgEAEgEQAFgCAGgBQAJABAFAFQAFAGAAAIIAAAig");
	this.shape_47.setTransform(96.625,9.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_48.setTransform(91.175,9.075);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_49.setTransform(85.775,9.075);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#505050").s().p("AgJAjQgFgDgDgGIAAALIgGAAIAAhKIAGAAIAAAgIABAAQACgFAFgDQAFgDAFgBQAHABAFADQAFAEADAGQADAFAAAIQAAAJgDAGQgDAGgFAEQgFADgHAAQgGAAgEgDgAgIgIQgEADgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_50.setTransform(80.375,8.05);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#505050").s().p("AgKAaQgEgCgDgEQgDgDAAgFIAHAAQAAAFAEACQAEADAFAAQAGAAAEgCQAEgDAAgEQAAgEgCgCQgDgCgFgBIgIgCQgHgCgEgDQgDgDAAgFQAAgFACgDQADgEAEgCIAJgCQAGABAEACQAEACADADQACAEABAEIgHAAQAAgEgEgDQgDgDgGAAQgFAAgDADQgEACAAAEQAAAEADACQACACAFABIAIACQAIABADADQAEAEAAAFQAAAFgDADQgDAEgEACQgFACgGAAQgFAAgFgCg");
	this.shape_51.setTransform(72.625,9.075);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgFAAgDADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAEgCAFgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAFgCACgDQACgEAAgEIAAgGg");
	this.shape_52.setTransform(67.5,9.075);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#505050").s().p("AAPAmIAAgiQAAgGgDgEQgEgEgHAAQgGAAgFAFQgEAEAAAHIAAAgIgHAAIAAhLIAHAAIAAAgIAAAAQACgFAFgDQAEgDAGAAQAJAAAFAFQAFAGAAAIIAAAjg");
	this.shape_53.setTransform(62.2,8.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#505050").s().p("AgPAYQgGgFABgHQgBgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgEAAgEADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAFgCAEgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAEgCADgDQACgEAAgEIAAgGg");
	this.shape_54.setTransform(54.35,9.075);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIgBgDIABgDQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIABADIgBADIgDABIgDgBg");
	this.shape_55.setTransform(50.85,8.1);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#505050").s().p("AgMAjQgGgEgCgGQgDgGAAgJQAAgIACgFQADgGAGgEQAFgDAHgBQAFABAFADQAFADACAFIAAggIAHAAIAABKIgGAAIAAgLQgDAGgFADQgFADgFAAQgHAAgFgDgAgIgIQgEADgCAFQgDAEAAAGQAAAHADAFQACAEAEADQAEADAEAAQAFAAAEgDQAEgDACgEQACgFAAgHQAAgGgCgEQgCgFgEgDQgEgCgFAAQgEAAgEACg");
	this.shape_56.setTransform(46.875,8.05);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#505050").s().p("AgLAYQgGgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAGgDAGgBQAHABAGADQAFADADAGQACAGABAIIAAACIgoAAIAAAAQAAAJAFAGQAFAFAHAAQAGAAAEgDQAEgDABgEIAHAAQgBAFgDADQgDAEgFACQgFACgFAAQgHAAgFgEgAARgDQgBgIgEgFQgEgFgIAAQgGAAgFAFQgFAFAAAIIAhAAIAAAAg");
	this.shape_57.setTransform(41.425,9.075);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#505050").s().p("AAeAbIAAgiQAAgGgEgEQgDgDgGAAQgGAAgEAEQgEAEAAAGIAAAhIgFAAIAAgjQAAgFgEgEQgDgDgGAAQgGAAgEAEQgEAFAAAGIAAAgIgGAAIAAg1IAGAAIAAAKIAAAAQACgEAEgEQAEgCAGgBQAGABAEADQADADACAFQACgFAEgDQAFgDAGgBQAIABAFAFQAEAEAAAIIAAAkg");
	this.shape_58.setTransform(34.475,9.05);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#505050").s().p("AgCAmIAAhLIAFAAIAABLg");
	this.shape_59.setTransform(26.975,8.025);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#505050").s().p("AgPAYQgGgFAAgHQAAgHAGgEQAEgDAKAAIAQgBIAAgFQAAgGgDgDQgFgEgGAAQgEAAgEADQgEADgBAFIgHAAQABgFADgEQADgDAEgCQAFgCAEgBQAJABAGAEQAFAFABAIIAAAkIgHAAIAAgKQgDAFgEADQgFADgGAAQgIAAgEgEgAAAACQgHAAgEADQgDADAAAEQAAAFADACQAEADAGAAIAHgCQAEgCADgDQACgEAAgEIAAgGg");
	this.shape_60.setTransform(23.3,9.075);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#505050").s().p("AgDAlIAAg1IAGAAIAAA1gAgDgcIAAgDIAAgDQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAIADACIABADIgBADIgDABIgDgBg");
	this.shape_61.setTransform(19.8,8.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#505050").s().p("AgLAYQgFgDgDgGQgDgGAAgJQAAgHADgGQADgHAFgDQAFgDAHgBQAGABAFACQAFACADAEQACAEABAFIgGAAQgBgFgFgDQgEgDgGgBQgHABgFAFQgFAGAAAJQAAAKAFAGQAFAGAHAAQAGAAAEgDQAEgDACgFIAGAAQgBAHgGAFQgGAFgJAAQgGAAgGgEg");
	this.shape_62.setTransform(16.225,9.075);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#505050").s().p("AgMAYQgFgDgDgGQgEgGAAgJQAAgHAEgHQADgGAFgDQAFgDAHgBQAHABAGADQAFADADAGQAEAHAAAHQAAAJgEAGQgDAGgFADQgGAEgHAAQgHAAgFgEgAgMgPQgFAGAAAJQAAAKAFAGQAEAGAIAAQAIAAAFgGQAEgGABgKQgBgJgEgGQgFgFgIgBQgIABgEAFg");
	this.shape_63.setTransform(10.75,9.075);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#505050").s().p("AgMAjQgGgDgEgFQgDgEAAgGIAGAAQABAEACADQADADAFACQAEACAFAAQAFAAAEgCQAFgBACgEQACgDAAgEQAAgFgDgDQgEgDgIgCIgIgDQgKgBgFgFQgFgEABgHQAAgGADgFQADgEAGgDQAFgCAGAAQAIAAAFACQAGADADAEQADAFAAAFIgHAAQAAgGgFgEQgFgDgIAAQgEAAgEACQgEABgCADQgCADAAAEQAAAFADADQAEADAIACIAHACQALACAFAEQAEAFAAAHQAAAHgDAEQgDAFgGADQgGACgIAAQgHAAgFgCg");
	this.shape_64.setTransform(4.975,8.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_2ccopy, new cjs.Rectangle(0,0,186.5,30.6), null);


(lib.text = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAGARIgCAAQgDAAgBgBQgBgCgBgEIAAgRIgDAAIAAgDIADAAIAAgGIADAAIAAAGIAFAAIAAADIgFAAIAAARIABADIADABIABAAIAAAAIAAAAIAAADg");
	this.shape.setTransform(190.7,168.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEANIgEgDIgCgEIAEAAQAAAAAAABQAAAAABABQAAAAAAABQABAAAAABQACABACAAQADAAACgBQABAAAAgBQABAAAAgBQAAAAAAgBQAAAAAAgBIgBgCIgEgCIgEgBQgDgBgCgBQAAgBgBAAQAAgBAAAAQgBgBAAAAQAAgBAAgBIACgEIADgCIAEgBIAFABIAEACQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABIgDAAQAAgBAAAAQAAgBgBgBQAAAAAAAAQgBgBAAAAQgBgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAIABADIAEACIADABIAGABQACACAAADIgCAEQAAABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAIgGABQgCAAgCgBg");
	this.shape_1.setTransform(188.725,168.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgGAMQgCgBgCgEQgCgDAAgEQAAgEACgDIAEgFQADgBADAAQAEAAADABQADACABADQACADAAAEQAAAEgCADQgBAEgDABQgDACgEAAQgDAAgDgCgAgGgHQgCADAAAEQAAAFACADQADADADAAQAEAAADgDQACgDAAgFQAAgEgCgDQgDgDgEAAQgDAAgDADg");
	this.shape_2.setTransform(186.125,168.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMATIAAglIANAAQAEAAACACIAEAEQABADABADQgBAEgBACIgEADQgCACgEAAIgJAAIAAAOgAgIACIAIAAQAEgBACgBQADgCAAgEQAAgEgDgCQgCgCgEAAIgIAAg");
	this.shape_3.setTransform(183.25,168.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#808080").s().p("AgFALIgEgEQgBgDAAgEQAAgDABgDQABgDADgBQACgCADAAQADAAAEACQACABABADQACADgBADIAAABIgRAAIAAABQAAADACACQADACABAAIAEgBIADgDIAEAAIgCAEIgDADIgGABQgCAAgDgCgAAHgBQAAgDgDgCQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBABIgCAFIANAAIAAAAg");
	this.shape_4.setTransform(121.9,192.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#808080").s().p("AAGAPIgCAAQgEAAgBgBQgBgCAAgDIAAgOIgEAAIAAgEIAEAAIAAgFIAEAAIAAAFIAFAAIAAAEIgFAAIAAAOIABACIACABIABAAIABAAIAAADIgBAAg");
	this.shape_5.setTransform(119.725,192.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#808080").s().p("AgGAMIgDgDIgBgEQAAgDADgCQACgBAFAAIAGAAIAAgCQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAgBgBIgEgBIgCABIgCADIgFAAIACgEIADgDQADgBACAAQAEAAADACQADACAAAEIAAARIgFAAIAAgEIgDADIgEABIgFgBgAAAACIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIADABIADgBIACgCIABgDIAAgCg");
	this.shape_6.setTransform(117.675,192.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#808080").s().p("AANANIAAgPIgBgEQgBgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAAAQAAABAAABQAAAAAAABIAAAPIgFAAIAAgQQAAAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBAAgBAAQAAAAgBABQAAAAgBAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAAAQAAABAAAAIAAAPIgFAAIAAgZIAFAAIAAAFQAAgBABAAQAAgBAAAAQABgBAAAAQABgBAAAAIAEgBIAFABIACAEIACgEIAGgBQADAAACACQADADAAADIAAARg");
	this.shape_7.setTransform(114.4,192.525);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#808080").s().p("AAMANIAAgPIgBgEQAAgBAAAAQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABQAAAAgBABQAAAAAAAAQAAABAAABQgBAAAAABIAAAPIgDAAIAAgQQAAAAgBgBQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAQAAABAAAAQgBABAAAAQAAABgBAAQAAABAAAAQAAABAAAAIAAAPIgFAAIAAgZIAFAAIAAAFQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBABAAIAEgBIAFABIABAEIAEgEIAEgBQAEAAADACQACADAAADIAAARg");
	this.shape_8.setTransform(110.3,192.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#808080").s().p("AgGAMIgDgDIgBgEQAAgDADgCQACgBAFAAIAGAAIAAgCQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAgBgBIgEgBIgCABIgCADIgFAAIACgEIADgDQADgBACAAQAEAAADACQADACAAAEIAAARIgFAAIAAgEIgDADIgEABIgFgBgAAAACIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIADABIADgBIACgCIABgDIAAgCg");
	this.shape_9.setTransform(106.925,192.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#808080").s().p("AgFALIgEgEQgBgDgBgEQABgDABgDQABgDADgBQADgCACAAQADAAADACQADABABADQABADABADIAAABIgRAAIAAABQAAADABACQACACADAAIADgBIACgDIAGAAIgCAEIgFADIgEABQgDAAgDgCgAAGgBQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBABIgBAFIALAAIAAAAg");
	this.shape_10.setTransform(104.4,192.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#808080").s().p("AAGAPIgCAAQgEAAgBgBQgBgCAAgDIAAgOIgEAAIAAgEIAEAAIAAgFIAEAAIAAAFIAFAAIAAAEIgFAAIAAAOIABACIACABIABAAIABAAIAAADIgBAAg");
	this.shape_11.setTransform(102.225,192.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#808080").s().p("AgGAMIgDgDIgBgEQAAgDADgCQACgBAFAAIAGAAIAAgCQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAgBgBIgEgBIgCABIgCADIgFAAIACgEIADgDQADgBACAAQAEAAADACQADACAAAEIAAARIgFAAIAAgEIgDADIgEABIgFgBgAAAACIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIADABIADgBIACgCIABgDIAAgCg");
	this.shape_12.setTransform(99.075,192.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#808080").s().p("AgFALIgEgEQgCgDABgEQgBgDACgDQACgDACgBQACgCADAAQAEAAADACQACABABADQABADAAADIAAABIgRAAIAAABQAAADADACQACACABAAIAFgBIACgDIAEAAIgCAEIgDADIgGABQgCAAgDgCgAAHgBQAAgDgCgCQgBgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIgDAFIANAAIAAAAg");
	this.shape_13.setTransform(95.45,192.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#808080").s().p("AAGAPIgCAAQgEAAgBgBQgBgCAAgDIAAgOIgEAAIAAgEIAEAAIAAgFIAEAAIAAAFIAFAAIAAAEIgFAAIAAAOIABACIACABIABAAIABAAIAAADIgBAAg");
	this.shape_14.setTransform(93.275,192.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#808080").s().p("AgGAMIgDgDIgBgEQAAgDADgCQACgBAFAAIAGAAIAAgCQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAAAgBgBIgEgBIgCABIgCADIgFAAIACgEIADgDQADgBACAAQAEAAADACQADACAAAEIAAARIgFAAIAAgEIgDADIgEABIgFgBgAAAACIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAIADABIADgBIACgCIABgDIAAgCg");
	this.shape_15.setTransform(91.225,192.525);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#808080").s().p("AgFANIAAgZIAFAAIAAAFQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAIADgBIABAAIABAAIAAAFIgBAAIgBAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAABIAAAOg");
	this.shape_16.setTransform(89.3,192.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#808080").s().p("AgDAQQAAAAgBAAQAAAAgBgBQAAAAAAgBQgBAAAAgBIAAAAIAAAEIgFAAIAAgiIAFAAIAAAOQAAAAABgBQAAAAABgBQAAAAABAAQAAgBABAAIADgBQAEAAACACQACABACADIABAGIgBAHQgCADgCABIgGACIgEgCgAgDgCIgCACIgBAFQAAAEACACQACACACABQADgBACgCQACgCAAgEQAAgEgCgCQgCgCgDAAIgDABg");
	this.shape_17.setTransform(87.075,192.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#808080").s().p("AgFALIgEgEQgCgDABgEQgBgDACgDQACgDACgBQACgCADAAQAEAAADACQACABABADQABADAAADIAAABIgRAAIAAABQABADACACQACACABAAIAFgBIACgDIAEAAIgCAEIgDADIgGABQgDAAgCgCgAAHgBQAAgDgCgCQgBgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABIgDAFIANAAIAAAAg");
	this.shape_18.setTransform(84.3,192.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#808080").s().p("AgBASIAAgjIADAAIAAAjg");
	this.shape_19.setTransform(82.5,192.025);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#808080").s().p("AgFALIgEgEQgCgDAAgEQAAgDACgDQABgDADgBQADgCACAAQADAAADACQADABABADQABADABADIAAABIgRAAIAAABQAAADABACQACACADAAIADgBIACgDIAGAAIgCAEIgFADIgEABQgDAAgDgCgAAGgBQAAgDgCgCQAAgBAAAAQgBAAAAAAQgBgBgBAAQAAAAgBAAQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBABIgBAFIALAAIAAAAg");
	this.shape_20.setTransform(80.65,192.525);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#808080").s().p("AgHAQQgEgCgBgEQgCgEAAgGQAAgEACgEQABgEAEgCQAEgCAEgBQADABAEABIAEAEQACADAAADIgEAAQgBgDgCgCIgGgCQgCAAgDACIgDAEIgBAGIABAHIADAEQADACACAAQADAAADgCIADgEIAFAAQgBAFgEADQgEADgFAAQgEAAgEgCg");
	this.shape_21.setTransform(77.7,192.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#808080").s().p("AAGAQIgCAAQgEAAgBgBQgBgCAAgEIAAgOIgEAAIAAgEIAEAAIAAgGIAEAAIAAAGIAFAAIAAAEIgFAAIAAAOIABACIACABIABAAIABAAIAAAEIgBAAg");
	this.shape_22.setTransform(118.7,149.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#808080").s().p("AgHALQgDgCAAgDIAGAAIABADIADABIAEgBQAAgBABAAQAAAAAAgBQAAAAAAAAQABgBAAAAIgBgCIgEgBIgDgBQgEgBgCgBQAAgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIABgEIAEgDIAEgBIAFABIAEADIABAEIgFAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAIgEgCIgCABQgBAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABIABACIADABIAEABQAEABABABQABABAAAAQAAABABAAQAAABAAAAQAAABAAABIgCAEIgDADIgGABQgEAAgDgDg");
	this.shape_23.setTransform(116.7,149.825);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#808080").s().p("AgFAMQgDgCgCgDQgCgDAAgEQAAgDACgDQACgDADgCQACgCADAAQAEAAACACQAEACABADQACADgBADQABAEgCADQgBADgEACQgCACgEAAQgDAAgCgCgAgEgGQgCADAAADQAAAEACADQACACACAAQADAAACgCQACgDAAgEQAAgDgCgDQgCgCgDAAQgCAAgCACg");
	this.shape_24.setTransform(114.05,149.825);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#808080").s().p("AgMASIAAgjIAGAAIAAAFQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAgBQADgBACAAQADAAACACQADABABAEQABADABADQgBAEgBADQgBADgDACIgFABIgFgBIgDgEIAAAOgAgEgKQgCACAAAEQAAAEACACQACACACABQAEgBABgCQACgCAAgEQAAgEgCgCQgBgCgEgBQgCABgCACg");
	this.shape_25.setTransform(111.25,150.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#808080").s().p("AgGANIAAgZIAGAAIAAAEQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAABAAQABgBAAAAIABABIABAAIAAAFIgBgBIgCAAQAAABgBAAQAAAAgBAAQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAABIAAAOg");
	this.shape_26.setTransform(107.825,149.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#808080").s().p("AgIALQgDgDAAgEIAAgQIAGAAIAAAPQAAAAAAABQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABQABAAAAAAQABAAAAAAQABAAAAAAQACAAACgBQACgCAAgDIAAgOIAGAAIAAAZIgGAAIAAgFIAAAAQAAABgBABQAAAAAAABQgBAAAAAAQAAABgBAAQgCABgCAAQgFAAgCgCg");
	this.shape_27.setTransform(105.5,149.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#808080").s().p("AgFAMQgDgCgCgDQgBgDgBgEQABgDABgDQACgDADgCQACgCADAAQAEAAACACQAEACABADQABADAAADQAAAEgBADQgBADgEACQgCACgEAAQgDAAgCgCgAgEgGQgCADAAADQAAAEACADQACACACAAQADAAACgCQACgDAAgEQAAgDgCgDQgCgCgDAAQgCAAgCACg");
	this.shape_28.setTransform(102.7,149.825);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#808080").s().p("AgHASIgCAAIAAgFIABABIABAAIADgBIABgDIABgCIgKgZIAGAAIAGAVIAHgVIAGAAIgKAbIgDAEIgCADIgEABIgBAAg");
	this.shape_29.setTransform(100,150.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#808080").s().p("AgFAMQgDgCgCgDQgBgDAAgEQAAgDABgDQACgDADgCQACgCADAAQAEAAACACQADACACADQABACAAAEIAAABIgRAAIAAABQAAADACACQABACACAAIAFgBIACgDIAFAAIgCAFIgEADIgGABQgDAAgCgCgAAHgBQAAgEgCgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAABQgCABAAAEIAMAAIAAAAg");
	this.shape_30.setTransform(96.2,149.825);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#808080").s().p("AgFAMQgDgCgCgDQgBgDAAgEQAAgDABgDQACgDADgCQACgCADAAQAEAAACACQADACACADQABACAAAEIAAABIgRAAIAAABQAAADACACQABACACAAIAFgBIACgDIAFAAIgCAFIgEADIgGABQgDAAgCgCgAAHgBQAAgEgCgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAABQgCABAAAEIAMAAIAAAAg");
	this.shape_31.setTransform(93.5,149.825);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#808080").s().p("AgGALQgEgCAAgDIAGAAIABADIADABIAEgBQAAgBABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIgBgCIgCgBIgEgBQgEgBgBgBQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIABgEIAEgDIAEgBIAFABIAEADIABAEIgFAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAIgEgCIgDABQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABIABACIADABIAEABQADABACABQAAABABAAQAAABAAAAQABABAAAAQAAABAAABIgBAEIgFADIgFABQgEAAgCgDg");
	this.shape_32.setTransform(90.9,149.825);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#808080").s().p("AgFAMQgDgCgBgDQgCgDAAgEQAAgDACgDQABgDADgCQADgCADAAQADAAADACQACACABADQACACAAAEIAAABIgSAAIAAABQAAADACACQACACADAAIADgBIADgDIAFAAIgCAFIgEADIgFABQgDAAgDgCgAAHgBQgBgEgBgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAgBABQgCABAAAEIANAAIAAAAg");
	this.shape_33.setTransform(87.15,149.825);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#808080").s().p("AgCASIAAgkIAFAAIAAAkg");
	this.shape_34.setTransform(85.25,149.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#808080").s().p("AgLASIAAgjIAFAAIAAAFQAAgBABAAQAAgBAAAAQABgBAAAAQABAAABgBQACgBABAAQAEAAADACQACABABAEQABADAAADQAAAEgBADQgBADgCACIgHABIgDgBIgEgEIAAAOgAgEgKQgCACAAAEQAAAEACACQACACACABQAEgBABgCQACgCAAgEQAAgEgCgCQgBgCgEgBQgCABgCACg");
	this.shape_35.setTransform(83.3,150.25);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#808080").s().p("AgGAMQgDgCgBgDQgCgDAAgEQAAgDACgDQABgDADgCQADgCADAAQAEAAADACQACACACADQACADgBADQABAEgCADQgCADgCACQgDACgEAAQgDAAgDgCgAgEgGQgCADAAADQAAAEACADQACACACAAQAEAAABgCQACgDAAgEQAAgDgCgDQgBgCgEAAQgCAAgCACg");
	this.shape_36.setTransform(80.4,149.825);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#808080").s().p("AgFAMQgDgCgCgDQgBgDAAgEQAAgDABgDQACgDADgCQACgCADAAQAEAAACACQADACABADQACACAAAEIAAABIgRAAIAAABQAAADACACQABACACAAIAFgBIACgDIAFAAIgCAFIgEADIgGABQgDAAgCgCgAAHgBQgBgEgBgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAABQgCABAAAEIAMAAIAAAAg");
	this.shape_37.setTransform(77.65,149.825);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#808080").s().p("AgMASIAAgjIAGAAIAAAFQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAgBQACgBADAAQADAAADACQACABABAEQACADgBADQABAEgCADQgBADgCACIgGABIgFgBIgDgEIAAAOgAgEgKQgCACAAAEQAAAEACACQACACACABQADgBACgCQACgCAAgEQAAgEgCgCQgCgCgDgBQgCABgCACg");
	this.shape_38.setTransform(74.9,150.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#808080").s().p("AAGAQIgCAAQgEAAgBgBQgBgCAAgEIAAgOIgEAAIAAgEIAEAAIAAgGIAEAAIAAAGIAFAAIAAAEIgFAAIAAAOIABACIADABIABAAIAAAAIAAAEIgBAAg");
	this.shape_39.setTransform(71.35,149.525);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#808080").s().p("AAGASIAAgPQAAgBAAgBQAAgBAAAAQgBAAAAAAQAAgBAAAAIgFgCQgCAAgBACIgCAFIAAAOIgGAAIAAgkIAGAAIAAAPIAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQACgCACAAQAEABADADQADACAAAEIAAAQg");
	this.shape_40.setTransform(69.2,149.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#808080").s().p("AgFARIgDgCIgDgEIAGAAIACACIADABQADAAACgBQABgBAAAAQAAgBABAAQAAgBAAAAQAAgBAAgBIAAgEQAAABgBAAQAAABAAAAQgBAAAAABQgBAAgBAAQgBACgDAAQgCAAgDgCIgEgFQgBgCgBgEQABgEABgDQABgDADgBQADgCACAAQADAAABABQABAAABABQAAAAABABQAAAAAAABQABAAAAABIAAAAIAAgFIAGAAIAAAZQgBAFgDADQgDACgGAAIgFgBgAgEgKQgCACAAAEQAAAEACACQACACACAAQADAAACgCQACgCAAgEQAAgEgCgCQgCgCgDgBQgCABgCACg");
	this.shape_41.setTransform(66.25,150.275);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#808080").s().p("AgBASIAAgZIADAAIAAAZgAgBgMIgBgCIABgCIABgBIACABIABACIgBACIgCABIgBgBg");
	this.shape_42.setTransform(64.3,149.325);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#808080").s().p("AgGANIAAgZIAGAAIAAAEQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBABAAQAAAAABgBQAAAAABAAQAAAAABAAQABgBAAAAIABABIABAAIAAAFIgBgBIgCAAQAAABgBAAQgBAAAAAAQgBAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAABIAAAOg");
	this.shape_43.setTransform(62.975,149.8);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#808080").s().p("AgFAMQgDgCgBgDQgCgDAAgEQAAgDACgDQABgDADgCQACgCADAAQAEAAADACQACACABADQACACAAAEIAAABIgSAAIAAABQABADACACQACACABAAIAFgBIACgDIAFAAIgCAFIgEADIgGABQgDAAgCgCgAAHgBQgBgEgBgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAAAABQgCABgBAEIANAAIAAAAg");
	this.shape_44.setTransform(59.55,149.825);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#808080").s().p("AAGASIAAgPQAAgBAAgBQAAgBAAAAQgBAAAAAAQAAgBgBAAIgDgCQgDAAgCACIgBAFIAAAOIgGAAIAAgkIAGAAIAAAPIAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQACgCACAAQAFABACADQACACABAEIAAAQg");
	this.shape_45.setTransform(56.8,149.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#808080").s().p("AAGAQIgCAAQgEAAgBgBQgBgCAAgEIAAgOIgEAAIAAgEIAEAAIAAgGIAEAAIAAAGIAFAAIAAAEIgFAAIAAAOIABACIACABIABAAIABAAIAAAEIgBAAg");
	this.shape_46.setTransform(54.45,149.525);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#808080").s().p("AgMASIAAgjIAGAAIAAAFQAAgBABAAQAAgBAAAAQABgBAAAAQABAAAAgBQADgBABAAQAEAAADACQACABABAEQACADgBADQABAEgCADQgBADgCACIgHABIgEgBIgDgEIAAAOgAgEgKQgCACAAAEQAAAEACACQACACACABQAEgBABgCQACgCAAgEQAAgEgCgCQgBgCgEgBQgCABgCACg");
	this.shape_47.setTransform(51.15,150.25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#808080").s().p("AgBASIAAgkIADAAIAAAkg");
	this.shape_48.setTransform(49.1,149.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#808080").s().p("AgFAMQgDgCgBgDQgCgDAAgEQAAgDACgDQABgDADgCQADgCACAAQAEAAADACQACACABADQACACAAAEIAAABIgSAAIAAABQAAADACACQADACABAAIAEgBIADgDIAFAAIgCAFIgEADIgGABQgCAAgDgCgAAHgBQgBgEgBgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBABAAAAQgBAAgBABQgCABAAAEIANAAIAAAAg");
	this.shape_49.setTransform(47.2,149.825);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#808080").s().p("AAJARIAAgPIgRAAIAAAPIgGAAIAAghIAGAAIAAAOIARAAIAAgOIAGAAIAAAhg");
	this.shape_50.setTransform(44.075,149.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#0378B4").s().p("AgEARIgFgCIgBgEIAFAAIACACIADABQADAAACgBQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBAAgBIAAgEQAAABgBAAQAAABAAAAQgBAAAAABQgBAAAAAAQgDACgCAAQgCAAgDgCIgEgFQgCgCABgEQgBgEACgDQACgDACgBQADgCACAAQACAAADABQAAAAABABQAAAAABABQAAAAAAABQABAAAAABIABAAIAAgFIAFAAIAAAZQAAAFgEADQgDACgGAAIgEgBgAgEgKQgCACAAAEQAAAEACACQABACADAAQADAAACgCQACgCAAgEQAAgEgCgCQgCgCgDgBQgDABgBACg");
	this.shape_51.setTransform(29.85,150.275);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#0378B4").s().p("AgGANIgDgDIgBgEQAAgEACgCQADgBAFAAIAGAAIAAgDQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAIgEgBIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAABIgFAAQAAgBAAAAQAAgBABgBQAAAAAAgBQAAAAABgBIADgDIAFgBQAFAAACADQADACAAAEIAAARIgFAAIAAgEIgDADIgEACIgFgBgAAAACIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAABQAAAAABAAIADABIADAAIACgDIABgDIAAgCg");
	this.shape_52.setTransform(27.125,149.825);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#0378B4").s().p("AAGAQIgCAAQgEAAAAgBQgCgCAAgEIAAgOIgEAAIAAgEIAEAAIAAgGIAEAAIAAAGIAFAAIAAAEIgFAAIAAAOIABACIACABIABAAIABAAIAAAEIgBAAg");
	this.shape_53.setTransform(24.95,149.525);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#0378B4").s().p("AAGASIAAgPQAAgBAAgBQAAgBAAAAQgBAAAAAAQAAgBgBAAIgDgCQgDAAgCACIgCAFIAAAOIgEAAIAAgkIAEAAIAAAPIABAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQACgCACAAQAEABADADQADACgBAEIAAAQg");
	this.shape_54.setTransform(22.8,149.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#0378B4").s().p("AgGALQgDgCgBgDIAFAAIACADIADABIAEgBQAAgBABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIgBgCIgDgBIgDgBQgDgBgCgBQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBIABgEIADgDIAFgBIAFABIAEADIABAEIgFAAQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAIgDgCIgDABQAAAAAAABQAAAAgBAAQAAABAAAAQAAAAAAABIABACIADABIADABQAFABABABQAAABABAAQAAABAAAAQABABAAAAQAAABAAABIgBAEIgFADIgFABQgEAAgCgDg");
	this.shape_55.setTransform(20.1,149.825);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#0378B4").s().p("AgGANIgDgDIgBgEQAAgEACgCQADgBAFAAIAGAAIAAgDQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAIgEgBIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAABIgFAAQAAgBAAAAQAAgBABgBQAAAAAAgBQAAAAABgBIADgDIAFgBQAFAAACADQADACAAAEIAAARIgFAAIAAgEIgDADIgEACIgFgBgAAAACIgDABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAABQAAAAABAAIADABIADAAIACgDIABgDIAAgCg");
	this.shape_56.setTransform(17.525,149.825);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#0378B4").s().p("AAGASIAAgPQAAgBAAgBQAAgBAAAAQgBAAAAAAQAAgBAAAAIgEgCQgDAAgCACIgBAFIAAAOIgGAAIAAgkIAGAAIAAAPIAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQABgBAAAAQACgCACAAQAFABACADQACACABAEIAAAQg");
	this.shape_57.setTransform(14.85,149.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#0378B4").s().p("AgGARQgDgCgBgDQgBgDAAgEQAAgEABgCQABgDADgCQADgCADAAQABAAACACQABAAABAAQAAABABAAQAAABAAAAQABABAAAAIAAgPIAFAAIAAAkIgEAAIAAgEIgBAAQAAAAgBABQAAAAAAABQgBAAAAABQAAAAgBAAIgEACIgGgCgAgEgBQgCACAAAEQAAAEACADQACACACAAQAEAAABgCQACgDAAgEQAAgEgCgCQgBgCgEAAQgCAAgCACg");
	this.shape_58.setTransform(10.75,149.325);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#0378B4").s().p("AgGARQgDgCgBgDQgCgDAAgEQAAgEACgCQABgDADgCQADgCADAAQACAAABACQABAAABAAQAAABABAAQAAABAAAAQABABAAAAIAAgPIAFAAIAAAkIgEAAIAAgEIgBAAQAAAAgBABQAAAAAAABQgBAAAAABQAAAAgBAAIgEACIgGgCgAgEgBQgCACAAAEQAAAEACADQACACACAAQADAAACgCQACgDAAgEQAAgEgCgCQgCgCgDAAQgCAAgCACg");
	this.shape_59.setTransform(7.85,149.325);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#0378B4").s().p("AAKARIgDgJIgNAAIgDAJIgGAAIANghIAFAAIANAhgAAFAEIgFgPIAAAAIgEAPIAJAAg");
	this.shape_60.setTransform(4.825,149.4);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#808080").s().p("AgFAMQgDgCgBgDQgCgDAAgEQAAgDACgDQABgDADgCQACgCADAAQAEAAADACQACACABADQACACAAAEIAAABIgSAAIAAABQABADACACQACACABAAIAFgBIACgDIAFAAIgCAFIgEADIgGABQgDAAgCgCgAAHgBQgBgEgBgBQgCgCgDAAQAAAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAABQgCABgBAEIANAAIAAAAg");
	this.shape_61.setTransform(51,40.725);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#808080").s().p("AAGANIAAgPQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQgBAAAAAAIgFACQgBACAAADIAAAOIgGAAIAAgZIAGAAIAAAFQAAgBABgBQAAAAAAgBQABAAAAAAQABgBAAAAQACgBACgBQAFAAACAEQACACABAEIAAAQg");
	this.shape_62.setTransform(48.25,40.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#808080").s().p("AgFAMQgDgCgCgDQgBgDgBgEQABgDABgDQACgDADgCQACgCADAAQAEAAACACQADACACADQABADABADQgBAEgBADQgCADgDACQgCACgEAAQgDAAgCgCgAgEgGQgCADAAADQAAAEACADQACACACAAQADAAACgCQACgDAAgEQAAgDgCgDQgCgCgDAAQgCAAgCACg");
	this.shape_63.setTransform(45.45,40.725);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#808080").s().p("AgHASIgCAAIAAgEIABAAIABAAIADgBIABgDIABgCIgKgZIAGAAIAGAVIAHgVIAGAAIgKAaIgDAGIgCACIgEABIgBAAg");
	this.shape_64.setTransform(42.75,41.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#808080").s().p("AAGANIAAgPQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQAAgBgBAAQgBAAAAAAIgFACQgBACAAADIAAAOIgGAAIAAgZIAGAAIAAAFQAAgBABgBQAAAAAAgBQABAAAAAAQABgBAAAAQACgBACgBQAFAAACAEQACACABAEIAAAQg");
	this.shape_65.setTransform(40.05,40.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#808080").s().p("AAKARIgDgJIgNAAIgDAJIgGAAIANgiIAFAAIANAigAAFAEIgFgPIAAAAIgEAPIAJAAg");
	this.shape_66.setTransform(37.025,40.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AgJAOQgDgCgBgFIAHAAQAAABAAAAQAAABABAAQAAABAAAAQABAAAAABQACABACAAQADAAACgBQABAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAIgBgDIgEgCIgFgBIgHgCQgCgDAAgDQAAgDACgCQABgDADgBQADgBADAAQAEAAADABIAEAEQACACAAADIgGAAIgCgEIgFgBIgEABQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAAAIABADIAEACIAEABQAFABACABQADACAAAEQAAADgCACQgCADgDABQgDABgEAAQgFAAgEgDg");
	this.shape_67.setTransform(61.725,30.325);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AAIARIAAgTQAAgEgCgCQgCgCgEAAQgCAAgDACQgCADAAAEIAAASIgGAAIAAghIAGAAIAAAGIAEgEQADgCADAAQAFAAADAEQADADAAAGIAAAUg");
	this.shape_68.setTransform(58.375,30.3);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgHAPQgEgCgBgEQgCgEAAgFQAAgEACgEQABgEAEgCQADgCAEAAQAFAAADACQADACACAEQACADAAAFIAAACIgXAAIAAAAQAAAFADACQACADADAAQADAAADgCQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAIAHAAQgBADgCACQgCADgDABQgDABgEAAQgDAAgEgCgAAIgCQAAgEgCgCQgCgDgEAAQgDAAgCADQgCACgBAEIAQAAIAAAAg");
	this.shape_69.setTransform(54.925,30.325);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AAHARIgHgYIgGAYIgHAAIgJghIAGAAIAGAaIABAAIAHgaIAFAAIAHAaIAGgaIAHAAIgJAhg");
	this.shape_70.setTransform(50.825,30.325);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgKAUQgFgDgCgFQgDgFAAgHQAAgGADgFQACgFAFgDQAFgDAFAAQAGAAAFADQAFADACAFQADAFAAAGQAAAHgDAFQgCAFgFADQgFADgGAAQgFAAgFgDgAgGgOQgDACgCAEQgCAEAAAEQAAAFACAEQACAEADACQADACADAAQAEAAADgCQADgCACgEQACgEAAgFQAAgEgCgEQgCgEgDgCQgDgCgEAAQgDAAgDACg");
	this.shape_71.setTransform(46.075,29.775);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgHAPQgEgCgBgEQgCgEAAgFQAAgEACgEQABgEAEgCQADgCAEAAQAFAAADACQADACACAEQACADAAAFIAAACIgXAAIAAAAQAAAFADACQACADADAAQADAAADgCQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAIAHAAQgBADgCACQgCADgDABQgDABgEAAQgDAAgEgCgAAIgCQAAgEgCgCQgCgDgEAAQgDAAgCADQgCACgBAEIAQAAIAAAAg");
	this.shape_72.setTransform(40.625,30.325);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgHAPQgEgCgBgEQgCgEAAgFQAAgEACgEQABgEAEgCQADgCAEAAQAFAAADACQADACACAEQACADAAAFIAAACIgXAAIAAAAQAAAFADACQACADADAAQADAAADgCQAAAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAIAHAAQgBADgCACQgCADgDABQgDABgEAAQgDAAgEgCgAAIgCQAAgEgCgCQgCgDgEAAQgDAAgCADQgCACgBAEIAQAAIAAAAg");
	this.shape_73.setTransform(37.225,30.325);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AAQARIAAgUQAAgDgBgCQgCgCgDAAQgDAAgCACQgCACAAAEIAAATIgGAAIAAgUQABgEgCgCQgCgBgDAAQgDAAgCACQgCACAAAEIAAATIgGAAIAAghIAGAAIAAAGQABgCACgCIAHgCIAFACIADAEQABgCADgCIAHgCQAFABADACQACADAAAFIAAAWg");
	this.shape_74.setTransform(32.85,30.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AgDAXIAAghIAGAAIAAAhgAgCgPIgBgDIABgDIACgBIADABIABADIgBADIgDABIgCgBg");
	this.shape_75.setTransform(29.45,29.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AAMAWIgEgMIgQAAIgEAMIgHAAIAQgrIAHAAIAQArgAAGAFIgGgTIgGATIAMAAg");
	this.shape_76.setTransform(26.725,29.775);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgCAXQgCgCAAgGIAAgYIgGAAIAAgHIAGAAIAAgJIAHAAIAAAJIAIAAIAAAHIgIAAIAAAXIABAEQABAAAAAAQABABAAAAQABAAAAAAQABAAAAAAIACAAIABAAIAAAHIgCAAIgDAAQgGAAgCgDg");
	this.shape_77.setTransform(49.125,9.375);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgLASQgFgDAAgGIAIAAQABADACACQACABADAAQAEAAADgBQAAgBABAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAgBIgFgCIgHgBQgFgCgDgCQgDgDAAgEQAAgEACgDQACgDAEgBQADgCAEAAQAFAAAEACIAFAEQACADABAEIgIAAQgBgDgCgCQgCgBgEAAQgDAAgCABQAAABgBAAQAAAAAAABQgBAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABQABABAEABIAGACQAGABADACQADACgBAFQAAAEgCADQgCADgEABQgEACgFAAQgGAAgFgEg");
	this.shape_78.setTransform(45.8786,9.825);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgKATQgEgDgDgEQgCgFAAgHQAAgGACgFQADgEAEgDQAFgDAFAAQAGAAAEADQAFADACAEQADAFAAAGQAAAHgDAFQgCAEgFADQgEADgGAAQgFAAgFgDgAgIgKQgCAEAAAGQAAAHACAEQAEAEAEAAQAFAAADgEQADgEABgHQgBgGgDgEQgDgEgFAAQgEAAgEAEg");
	this.shape_79.setTransform(41.65,9.825);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgTAcIAAg3IAIAAIAAAHQACgEAEgCQADgCAEABQAFgBAEADQAEADADAFQACAFAAAGQAAAGgCAFQgDAFgEACQgDADgGAAQgDAAgEgCQgDgCgCgDIAAAUgAgHgQQgDAEgBAGQABAGADAEQADADAEABQAFgBADgDQADgEAAgGQAAgGgDgEQgDgEgFAAQgEAAgDAEg");
	this.shape_80.setTransform(37.175,10.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgKAUQgDgBgCgDQgCgDAAgEQAAgFAEgEQAEgCAIAAIALgBIAAgDQAAgEgDgCQgCgCgEAAQgDAAgCACQgDACAAACIgIAAQAAgDACgDQACgDAFgCQADgCAEAAQAIAAAEAEQAFAEAAAGIAAAcIgIAAIAAgHIAAAAQgCAEgEACQgDACgEAAQgEAAgDgCgAAAADQgEAAgCACQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACADAAIAFgBIAEgEQACgCAAgDIAAgDg");
	this.shape_81.setTransform(30.7,9.825);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgJATQgEgCgDgFQgCgFAAgHQAAgFACgFQADgFAEgDQAEgDAFAAQAGAAAEADQAFACACAFQACAFAAAGIAAACIgdAAIAAABQAAAFADAEQAEADAEAAQAEAAACgCQADgBABgDIAIAAQgBAEgCADIgHAEQgEACgEAAQgGAAgEgDgAALgDQAAgFgDgDQgDgDgFAAQgDAAgDADQgDADgBAFIAVAAIAAAAg");
	this.shape_82.setTransform(24.625,9.825);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgCAXQgCgCAAgGIAAgYIgGAAIAAgHIAGAAIAAgJIAHAAIAAAJIAIAAIAAAHIgIAAIAAAXIABAEQABAAAAAAQAAABABAAQAAAAABAAQABAAAAAAIACAAIABAAIAAAHIgCAAIgDAAQgGAAgCgDg");
	this.shape_83.setTransform(21.075,9.375);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgKAUQgEgBgBgDQgCgDAAgEQAAgFAEgEQAEgCAIAAIALgBIAAgDQAAgEgDgCQgCgCgEAAQgDAAgCACQgDACAAACIgIAAQAAgDACgDQACgDAFgCQADgCAEAAQAIAAAEAEQAFAEAAAGIAAAcIgIAAIAAgHIAAAAQgCAEgEACQgDACgEAAQgEAAgDgCgAAAADQgEAAgCACQgBAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACADAAIAFgBIAEgEQACgCAAgDIAAgDg");
	this.shape_84.setTransform(17.65,9.825);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgJATQgEgCgDgFQgCgFAAgHQAAgFACgFQADgFAEgDQAEgDAFAAQAGAAAEADQAFACACAFQACAFAAAGIAAACIgdAAIAAABQAAAFADAEQAEADAEAAQAEAAACgCQADgBABgDIAIAAQgBAEgCADIgHAEQgEACgEAAQgGAAgEgDgAALgDQAAgFgDgDQgDgDgFAAQgDAAgDADQgDADgBAFIAVAAIAAAAg");
	this.shape_85.setTransform(13.425,9.825);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgKAWIAAgqIAIAAIAAAHQABgEACgCQADgCAEABIABAAIACAAIAAAIIgCAAIgCAAQgFgBgCADQgBADAAAEIAAAZg");
	this.shape_86.setTransform(10.075,9.8);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgLAaQgHgEgCgGQgEgHAAgJQAAgIAEgGQACgHAHgDQAFgEAHAAQAGAAAFACQAGADADAEQADAFABAGIgJAAQgBgGgEgDQgEgDgGAAQgEAAgEACQgEADgCAFQgCAEAAAGQAAAHACAEQACAFAEADQAEACAEABQAGgBAEgCQAEgDABgFIAJAAQgBAJgHAEQgGAFgKAAQgHAAgFgDg");
	this.shape_87.setTransform(5.8,9.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text, new cjs.Rectangle(1,2.4,192.8,194.6), null);


(lib.stripes_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#439AC7").ss(1.3,2,1).p("Ah2AAIDtAA");
	this.shape.setTransform(11.9002,1.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#439AC7").ss(1.3,2,1).p("Ah2AAIDtAA");
	this.shape_1.setTransform(11.9,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.stripes_c, new cjs.Rectangle(-1,-1,25.8,3.8), null);


(lib.shadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-230.8,-240.45,1.6303,1.6303);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-230.8,-240.4,815.2,604.8), null);


(lib.pop_shdw_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AwbPXIgC+yIBkgCIACAAIADAAIATAAIAHAAIAaAAIeZAAIAFe7g");
	this.shape.setTransform(105.4,99.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_shdw_c, new cjs.Rectangle(0,0,210.8,198.1), null);


(lib.pencil_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2D82DD").s().p("EhBRBR/QgaiAgUjLIgakyUAP0gWtAx4hF/UAY8gjAAVxgedIUaOMMhihCJGItfI+Qt8JYiQCDQgoAkgjAAQheAAg2kJg");
	this.shape.setTransform(30.8468,28.8774,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#42A8F6").s().p("Eg/bBUWQBNizE8wbIEtv3MBi2iH1IRYMwUgVkAelgY1AjCUgxqBGEgQWAWVQi9AxhwAbQjMAxiFARQhSALg9AAQjbAAA9iPg");
	this.shape_1.setTransform(26.7872,24.1727,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#154599").s().p("ArFO7QhKgpgjhJQgkhNAXhSQBMkWBakWQCQm+CfmBIQ5kdIB6QPInsFhQoNF5ilCAQhfBJhmAJQgQACgQAAQhKAAhBgkg");
	this.shape_2.setTransform(4.7916,46.0668,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#184897").s().p("A39nOQBkiMEKlNQDRkGB3iPQAmgtCHARQCDAQDABGQGpCZGfEXQHFExE6FeQCdCwBDCGQBJCTgsBRQhMCNlRHLIlBGvg");
	this.shape_3.setTransform(52.5033,6.9105,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#164399").s().p("Egq7ASLQjUAAgyhXQgphGA3inQBVjbAsiEQBPjvAAi+IAAh0QAAjgBXjNQBUjGCZiaQCZiZDGhUQDOhXDfAAMA4WAAAQDgAADNBXQDGBUCZCZQCZCaBVDGQBXDNAADgIAAB0QAADfhXDOQhVDGiZCZQiZCZjGBUQjNBXjgAAg");
	this.shape_4.setTransform(26.3492,44.2731,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1C5FC8").s().p("Egq7ASLQjUAAgyhXQgphGA3inQBVjbAsiFQBPjvAAi+IAAh0QAAjfBXjOQBUjGCZiZQCZiZDGhUQDOhXDfAAMA4WAAAQDgAADNBXQDGBUCZCZQCZCZBVDGQBXDOAADfIAAB0QAADghXDNQhVDHiZCZQiZCZjGBUQjNBXjgAAg");
	this.shape_5.setTransform(40.9326,32.6703,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1C5FC8").s().p("Egq7ASLQjUAAgyhXQgphGA3inQBVjbAriEQBPjwAAi9IAAh1QAAjfBXjOQBVjGCZiZQCZiZDGhUQDNhXDgAAMA4WAAAQDgAADNBXQDGBUCZCZQCZCZBVDGQBXDOAADfIAAB1QAADfhXDOQhVDGiZCZQiZCZjGBUQjNBXjgAAg");
	this.shape_6.setTransform(54.6809,20.9463,0.0457,0.0456,0,14.5854,14.4631);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E5E5E5").s().p("EhiFBLTQg2gegZg0QgZg3AQg8QBllxCBliQhpgOAlhXQA3iBDkr2IDZrcMBoRhjeQBJhmC/jvQCbjDBShhQAbghBhAMQBeAMCLAyQEzBvEsDJQFGDcDiD8QD2ESg+BzQhLCJmNIRIjhE5MAwdAELQCiAACUA/QCPA9BuBuQBvBvA8CPQA/CTAACiIAABVQAAChg/CUQg8CPhvBuQhuBviPA8QiUA/iiAAMhDTgELInbKWMApWAFWQCiAACTA/QCPA9BvBuQBuBvA9CPQA/CTAACiIAABUQAACig/CUQg9CPhuBuQhvBviPA8QiTA/iiAAMg8LgFXInnKlIesJPQCiAACUA/QCPA9BuBuQBvBvA8CPQA/CTAACiIAABUQAACig/CUQg8CPhvBuQhuBviPA8QiUA/iiAAMhXCgHuQrGHdhqBgQhMBFgxhwQm3E7h/BhQhEA1hKAHIgXABQg1AAgvgag");
	this.shape_7.setTransform(33.5951,35.3586,0.0457,0.0456,0,14.5854,14.4631);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pencil_c, new cjs.Rectangle(0,0,68.3,55.8), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.familiar_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AgKAWIAAgqIAIAAIAAAHQABgEACgCQADgBAEAAIABAAIACAAIAAAIIgCAAIgCAAQgFgBgCADQgBADAAAEIAAAZg");
	this.shape.setTransform(28.525,7.45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgKAUQgDgBgCgDQgCgDAAgEQAAgFAEgEQAEgCAIAAIAKgBIAAgDQAAgEgBgCQgDgCgFAAQgCAAgCACQgCACgBACIgIAAQAAgDADgDQACgDADgCQAEgCAEAAQAIAAAFAEQAEAEAAAGIAAAcIgIAAIAAgHIgBAAQgBAEgDACQgFACgCAAQgFAAgDgCgAAAADQgEAAgDACQAAAAAAABQgBAAAAAAQAAABAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQADACAEAAIAEgBIAEgEQACgCgBgDIAAgDg");
	this.shape_1.setTransform(24.8,7.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AgDAdIAAgqIAHAAIAAAqgAgCgUQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBABAAIACgBIAEABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAABgBAAQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAgBAAAAg");
	this.shape_2.setTransform(21.85,6.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#999999").s().p("AgDAeIAAg7IAHAAIAAA7g");
	this.shape_3.setTransform(20.025,6.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("AgDAdIAAgqIAHAAIAAAqgAgCgUQgBAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBABAAIACgBIAEABQAAAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAABgBAAQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAgBAAAAg");
	this.shape_4.setTransform(18.25,6.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AAVAWIAAgaQAAgEgCgDQgCgCgEAAQgEAAgDACQgCADAAAEIAAAaIgHAAIAAgbQAAgEgDgCQgCgCgDAAQgEAAgDACQgCADAAAFIAAAZIgJAAIAAgqIAIAAIAAAIQACgFADgCQADgBAEAAQAFgBADADQACACABAEQACgEAEgCQADgDAFABQAGAAAEADQAEAEAAAGIAAAdg");
	this.shape_5.setTransform(13.975,7.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("AgKAUQgEgBgBgDQgCgDAAgEQAAgFAEgEQAFgCAHAAIAKgBIAAgDQAAgEgCgCQgCgCgFAAQgCAAgCACQgCACgBACIgIAAQAAgDADgDQACgDADgCQAEgCAEAAQAIAAAFAEQAEAEAAAGIAAAcIgIAAIAAgHIgBAAQgBAEgDACQgFACgCAAQgFAAgDgCgAAAADQgEAAgDACQAAAAAAABQgBAAAAAAQAAABAAABQgBAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABAAAAQADACADAAIAFgBIAEgEQABgCAAgDIAAgDg");
	this.shape_6.setTransform(8.35,7.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("AgEAdIAAgjIgGAAIAAgHIAGAAIAAgEQAAgFADgDQABgDAHAAIACAAIACAAIAAAHIgBAAIgCAAIgEABQAAAAAAABQgBAAAAABQAAAAAAABQAAAAAAABIAAADIAIAAIAAAHIgIAAIAAAjg");
	this.shape_7.setTransform(4.925,6.7214);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AlaBtIAAjaIK1AAIAADag");
	this.shape_8.setTransform(17.4859,7.8517,0.4843,0.6574);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("AyrFVIAAqFIArgkIAAJsMAksAAAIg1A9g");
	this.shape_9.setTransform(17.1072,8.6041,0.1431,0.2321);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.familiar_c, new cjs.Rectangle(0,0,34.3,16.5), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.conversational_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AgDAeIAAg7IAHAAIAAA7g");
	this.shape.setTransform(55.825,6.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgKAUQgEgBgBgDQgCgDAAgEQAAgFAEgEQAEgCAIAAIALgBIAAgDQAAgEgDgCQgCgCgEAAQgDAAgCACQgDACAAACIgIAAQAAgDACgDQACgDAFgCQADgCAEAAQAIAAAEAEQAFAEAAAGIAAAcIgIAAIAAgHIAAAAQgCAEgEACQgDACgEAAQgEAAgDgCgAAAADQgEAAgCACQgBAAAAABQgBAAAAAAQAAABAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACADAAIAFgBIAEgEQACgCAAgDIAAgDg");
	this.shape_1.setTransform(52.75,7.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AAKAWIAAgZQAAgFgCgDQgDgCgEAAQgEAAgDADQgDADABAFIAAAYIgJAAIAAgqIAIAAIAAAHQACgEADgCQAEgBADAAQAIAAADAEQAEAEAAAIIAAAag");
	this.shape_2.setTransform(48.45,7.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#999999").s().p("AgJATQgFgDgCgEQgDgFAAgHQAAgGADgFQACgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAGQAAAHgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgHgKQgDAEAAAGQAAAHADAEQADAEAEAAQAGAAADgEQACgEAAgHQAAgGgCgEQgDgEgGAAQgEAAgDAEg");
	this.shape_3.setTransform(43.95,7.475);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("AgEAdIAAgqIAIAAIAAAqgAgDgUQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAIADgBIADABQABAAAAABQAAAAABABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAQAAAAAAABQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAgBgBAAg");
	this.shape_4.setTransform(40.8,6.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AgCAXQgCgCAAgGIAAgYIgGAAIAAgHIAGAAIAAgJIAHAAIAAAJIAIAAIAAAHIgIAAIAAAXIABAEQABAAAAAAQABABAAAAQAAAAABAAQABAAAAAAIACAAIABAAIAAAHIgCAAIgDAAQgGAAgCgDg");
	this.shape_5.setTransform(38.525,7.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("AgKAUQgDgBgCgDQgCgDAAgEQAAgFAEgEQAFgCAHAAIALgBIAAgDQgBgEgCgCQgCgCgEAAQgDAAgCACQgDACAAACIgIAAQAAgDADgDQABgDAFgCQADgCAEAAQAIAAAFAEQAEAEAAAGIAAAcIgIAAIAAgHIAAAAQgCAEgEACQgEACgDAAQgEAAgDgCgAAAADQgEAAgCACQgBAAAAABQgBAAAAAAQAAABAAABQgBAAAAABQAAABABAAQAAABAAAAQAAABABAAQAAABABAAQACACADAAIAFgBIAEgEQACgCAAgDIAAgDg");
	this.shape_6.setTransform(35.1,7.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("AgLASQgFgDAAgGIAIAAQABADACACQACABADAAQAEAAADgBQAAgBABAAQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAgBIgFgCIgHgBQgFgCgDgCQgDgDAAgEQAAgEACgDQACgDAEgBQADgCAEAAQAFAAAEACIAFAEQACADABAEIgIAAQgBgDgCgCQgCgBgEAAQgDAAgCABQAAABgBAAQAAABAAAAQgBAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQAAAAABABQABABAEABIAGACQAGABADACQADACgBAFQAAAEgCADQgCADgEABQgEACgFAAQgGAAgFgEg");
	this.shape_7.setTransform(31.0286,7.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#999999").s().p("AgKAWIAAgqIAIAAIAAAHQABgEACgCQADgBAEAAIABAAIACAAIAAAIIgCAAIgCAAQgFgBgCADQgBADAAAEIAAAZg");
	this.shape_8.setTransform(27.875,7.45);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("AgJATQgEgCgDgFQgCgFAAgHQAAgFACgFQADgFAEgDQAEgDAFAAQAGAAAEADQAFACACAFQACAFAAAGIAAACIgdAAIAAABQAAAFADAEQAEADAEAAQAEAAACgCQADgBABgDIAIAAQgBAEgCADIgHAEQgEACgEAAQgGAAgEgDgAALgDQAAgFgDgDQgDgDgFAAQgDAAgDADQgDADgBAFIAVAAIAAAAg");
	this.shape_9.setTransform(24.175,7.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#999999").s().p("AgDAVIgQgpIAJAAIAKAhIALghIAJAAIgPApg");
	this.shape_10.setTransform(19.95,7.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#999999").s().p("AAJAWIAAgZQAAgFgCgDQgCgCgFAAQgEAAgCADQgDADAAAFIAAAYIgIAAIAAgqIAIAAIAAAHQACgEAEgCQACgBAFAAQAGAAAFAEQADAEAAAIIAAAag");
	this.shape_11.setTransform(15.65,7.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#999999").s().p("AgKATQgEgDgDgEQgCgFAAgHQAAgGACgFQADgEAEgDQAFgDAFAAQAGAAAFADQAEADACAEQADAFAAAGQAAAHgDAFQgCAEgEADQgFADgGAAQgFAAgFgDgAgIgKQgDAEAAAGQAAAHADAEQADAEAFAAQAFAAADgEQAEgEAAgHQAAgGgEgEQgDgEgFAAQgFAAgDAEg");
	this.shape_12.setTransform(11.15,7.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#999999").s().p("AgJATQgEgDgDgEQgCgFAAgHQAAgGACgEQADgFAEgDQAFgDAFAAQAFAAAEACQAEACADAEQACADAAAEIgIAAQAAgDgDgCQgDgCgEgBQgFABgDADQgCAEAAAGQAAAHACAEQAEAEAEAAQAEAAADgCQADgCAAgEIAIAAQAAAHgFAEQgGAEgHAAQgFAAgFgDg");
	this.shape_13.setTransform(6.8,7.475);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AlaBtIAAjaIK1AAIAADag");
	this.shape_14.setTransform(30.8333,7.7517,0.8556,0.6574);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("AyrFVIAAqFIArgkIAAJsMAksAAAIg1A9g");
	this.shape_15.setTransform(30.2258,8.5041,0.2528,0.2321);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.conversational_c, new cjs.Rectangle(0,0,60.5,16.4), null);


(lib.Communal_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AgDAeIAAg7IAHAAIAAA7g");
	this.shape.setTransform(41.275,6.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgKAUQgDgBgCgDQgCgDAAgEQAAgFAEgEQAFgCAHAAIAKgBIAAgDQAAgEgBgCQgDgCgFAAQgCAAgCACQgCACgBACIgIAAQAAgDACgDQADgDADgCQAEgCAEAAQAIAAAEAEQAFAEAAAGIAAAcIgIAAIAAgHIgBAAQgBAEgEACQgEACgCAAQgFAAgDgCgAAAADQgEAAgDACQAAAAAAABQgBAAAAAAQAAABAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABABAAQAAABAAAAQADACAEAAIAEgBIAEgEQABgCAAgDIAAgDg");
	this.shape_1.setTransform(38.2,7.475);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AAJAWIAAgZQAAgFgCgDQgCgCgFAAQgDAAgDADQgCADgBAFIAAAYIgIAAIAAgqIAIAAIAAAHQACgEAEgCQACgBAFAAQAGAAAFAEQADAEAAAIIAAAag");
	this.shape_2.setTransform(33.9,7.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#999999").s().p("AgNASQgEgFAAgHIAAgbIAIAAIAAAZQAAAFADACQACADAEAAQAEAAADgDQADgDAAgFIAAgYIAIAAIAAAqIgIAAIAAgIQgCAFgDABQgDACgEAAQgHAAgEgDg");
	this.shape_3.setTransform(29.375,7.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("AAVAWIAAgaQAAgEgCgDQgCgCgEAAQgEAAgDACQgCADAAAEIAAAaIgHAAIAAgbQAAgEgDgCQgCgCgDAAQgEAAgDACQgCADAAAFIAAAZIgJAAIAAgqIAIAAIAAAIQACgFADgCQADgBAEAAQAFgBADADQACACABAEQACgEAEgCQADgDAFABQAGAAAEADQAEAEAAAGIAAAdg");
	this.shape_4.setTransform(23.775,7.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AAVAWIAAgaQAAgEgCgDQgCgCgEAAQgEAAgDACQgCADAAAEIAAAaIgHAAIAAgbQAAgEgDgCQgCgCgDAAQgEAAgDACQgCADAAAFIAAAZIgJAAIAAgqIAIAAIAAAIQACgFADgCQADgBAEAAQAFgBADADQACACABAEQACgEAEgCQADgDAFABQAGAAAEADQAEAEAAAGIAAAdg");
	this.shape_5.setTransform(16.975,7.45);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("AgJATQgFgDgDgEQgCgFAAgHQAAgGACgFQADgEAFgDQAEgDAFAAQAGAAAEADQAFADADAEQACAFAAAGQAAAHgCAFQgDAEgFADQgEADgGAAQgFAAgEgDgAgIgKQgCAEAAAGQAAAHACAEQADAEAFAAQAGAAACgEQADgEAAgHQAAgGgDgEQgCgEgGAAQgFAAgDAEg");
	this.shape_6.setTransform(11.3,7.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("AgIATQgFgDgCgEQgDgFAAgHQAAgGADgEQACgFAFgDQAEgDAFAAQAFAAAEACQAEACADAEQABADABAEIgIAAQgBgDgCgCQgCgCgFgBQgEABgDADQgDAEAAAGQAAAHADAEQADAEAEAAQAEAAADgCQACgCABgEIAIAAQAAAHgGAEQgEAEgIAAQgFAAgEgDg");
	this.shape_7.setTransform(6.95,7.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AyVE2IAAprMAkrAAAIAAJrg");
	this.shape_8.setTransform(23.6444,7.3519,0.1942,0.2321);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("AyrFVIAAqFIArgkIAAJsMAksAAAIg1A9g");
	this.shape_9.setTransform(23.2268,8.0541,0.1942,0.2321);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Communal_c, new cjs.Rectangle(0,0,46.5,16), null);


(lib.blur_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.blur_BG();
	this.instance.setTransform(0,0,0.9062,0.918);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blur_UI, new cjs.Rectangle(0,0,453.1,305.7), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(363.9999,44.9936,2.4267,0.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,728,90), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.UI_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.text();
	this.instance.setTransform(104,99.45,1,1,0,0,0,97.2,99);

	this.instance_1 = new lib.earth();
	this.instance_1.setTransform(35.1,37.95,0.1672,0.1672);

	this.instance_2 = new lib.avatar();
	this.instance_2.setTransform(10.1,26.95,0.1574,0.1574);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAHIgaAbIgHgHIAbgbIgbgaIAHgHIAaAbIAbgbIAHAHIgbAaIAbAbIgHAHg");
	this.shape.setTransform(200.4077,9.6008);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#808080").s().p("AgVgKIArAAIgWAVg");
	this.shape_1.setTransform(65.8807,41.4513);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#808080").ss(0.3).p("AjBgtIGDAAQAHAAAAAHIAABOQAAAGgHAAImDAAQgHAAAAgGIAAhOQAAgHAHAAg");
	this.shape_2.setTransform(51.8805,40.8763);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0378B4").s().p("AhsA/QgEAAgDgDQgDgEAAgEIAAhnQAAgFADgDQADgDAEAAIDZAAQAEAAADADQADADAAAFIAABnQAAAEgDAEQgDADgEAAg");
	this.shape_3.setTransform(192.8076,169.1782);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AlxA8QgZAAgRgRQgSgSAAgZQAAgYASgSQARgRAZAAILiAAQAaAAARARQASASAAAYQAAAZgSASQgRARgaAAg");
	this.shape_4.setTransform(108.5563,192.3786);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#666667").s().p("AgdAlIAAhJIAnAAIAUAUIAAA1gAgaghIAABDIA1AAIAAgvIgSAAIAAgUg");
	this.shape_5.setTransform(70.2057,169.4032);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#666667").s().p("AgeAYQgFABAAgFIAAgnQAAgFAFABIApAAQAFgBAAAFIAAAKIAQgKIADAAQAAAAAAABQABAAAAAAQAAAAAAABQAAAAAAABIAAAhQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgCABIgBgBIgQgKIAAAKQAAAFgFgBgAghgTIAAAnQAAAAAAABQABAAAAAAQAAABABAAQAAAAABAAIApAAQABAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAIAAgnQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAIgpAAQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABAAAAgAAQgGIAAANIARALIABgBIAAghIgBgBg");
	this.shape_6.setTransform(51.8305,170.3033);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#666667").s().p("AgEAGQgBgGAEgCQADgDAEABIAAACQgEAAgCACQgCABAAAFg");
	this.shape_7.setTransform(32.8552,170.1408);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#666667").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFgAgJgJQgFAEABAFQgBAGAFAEQAEAFAFAAQAGAAAEgFQAFgEAAgGQAAgFgFgEQgEgFgGAAQgFAAgEAFg");
	this.shape_8.setTransform(33.2052,170.4283);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#666667").s().p("AgfAhQgFAAAAgFIAAgtQAAgFAFABIAOAAIACgGQACgFAFAAIAQAAQAFAAACAFIACAGIAPAAQAFgBAAAFIAAAtQAAAFgFAAgAghgRIAAAtQAAABAAAAQAAABAAAAQABAAAAAAQAAAAABAAIA/AAQABAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBIAAgtQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAAAgBAAIgRAAIgDgIQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBAAgBAAIgQAAQgDAAgBACIgDAIIgQAAQgBAAAAAAQAAAAgBAAQAAABAAAAQAAABAAAAg");
	this.shape_9.setTransform(33.1302,169.9033);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0378B4").s().p("AgEAlIAAggIggAAIAAgJIAgAAIAAggIAJAAIAAAgIAgAAIAAAJIggAAIAAAgg");
	this.shape_10.setTransform(14.4799,169.1032);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F1F1F1").s().p("AwvB7IAAjFIBaAAIAvgwIAvAwIenAAIAADFg");
	this.shape_11.setTransform(107.2313,189.6036);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("At3MuIgvgwIgvAwIhaAAIAA5aMAhfAAAIAAZag");
	this.shape_12.setTransform(107.2313,100.7022);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0378B4").s().p("AwvBhIAAisQAAgIAGgHQAHgGAIAAMAg1AAAQAJAAAGAGQAGAHAAAIIAACsg");
	this.shape_13.setTransform(107.2313,9.6758);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI_c, new cjs.Rectangle(0,0,214.5,201.9), null);


(lib.ui = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ui.cache(-215,-202,430,404,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.ui = new lib.UI_c();
	this.ui.name = "ui";
	this.ui.setTransform(107.2,100.9,1,1,0,0,0,107.2,100.9);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ui, new cjs.Rectangle(0,0,214.5,201.9), null);


(lib.text_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text_c.cache(-190,-31,380,62,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text_c = new lib.text_2ccopy();
	this.text_c.name = "text_c";
	this.text_c.setTransform(93.3,15.3,1,1,0,0,0,93.3,15.3);

	this.timeline.addTween(cjs.Tween.get(this.text_c).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_2, new cjs.Rectangle(0,0,186.5,30.6), null);


(lib.text_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text_c.cache(-190,-31,380,62,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text_c = new lib.text_c();
	this.text_c.name = "text_c";
	this.text_c.setTransform(93.3,15.3,1,1,0,0,0,93.3,15.3);

	this.timeline.addTween(cjs.Tween.get(this.text_c).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_1, new cjs.Rectangle(0,0,186.5,30.6), null);


(lib.stripes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stripes.cache(-24,-2,48,4,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.stripes = new lib.stripes_c();
	this.stripes.name = "stripes";
	this.stripes.setTransform(11.9,0.8,1,1,0,0,0,11.9,0.8);

	this.timeline.addTween(cjs.Tween.get(this.stripes).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.stripes, new cjs.Rectangle(-0.8,-0.8,25.400000000000002,3.4000000000000004), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.pop_up_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-211,-200,422,400,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.pop_shdw_c();
	this.shadow.name = "shadow";
	this.shadow.setTransform(105.4,99,1,1,0,0,0,105.4,99);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_up_shadow, new cjs.Rectangle(0,0,210.8,198.1), null);


(lib.pop_up = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}
	this.frame_60 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(11).call(this.frame_60).wait(1));

	// 1st_linemask copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_26 = new cjs.Graphics().p("AAIhUIAAgbIAMAAIAAAbg");
	var mask_graphics_27 = new cjs.Graphics().p("AAIhUIAAgbIAMAAIAAAbg");
	var mask_graphics_28 = new cjs.Graphics().p("AAFhUIAAgbIASAAIAAAbg");
	var mask_graphics_29 = new cjs.Graphics().p("AAChUIAAgbIAYAAIAAAbg");
	var mask_graphics_30 = new cjs.Graphics().p("AgChUIAAgbIAhAAIAAAbg");
	var mask_graphics_31 = new cjs.Graphics().p("AgJhUIAAgbIAuAAIAAAbg");
	var mask_graphics_32 = new cjs.Graphics().p("AgRhUIAAgbIA+AAIAAAbg");
	var mask_graphics_33 = new cjs.Graphics().p("AgbhUIAAgbIBRAAIAAAbg");
	var mask_graphics_34 = new cjs.Graphics().p("AgmhUIAAgbIBnAAIAAAbg");
	var mask_graphics_35 = new cjs.Graphics().p("AgyhUIAAgbIB+AAIAAAbg");
	var mask_graphics_36 = new cjs.Graphics().p("AhAhUIAAgbICaAAIAAAbg");
	var mask_graphics_37 = new cjs.Graphics().p("AhOhUIAAgbIC1AAIAAAbg");
	var mask_graphics_38 = new cjs.Graphics().p("AhahUIAAgbIDNAAIAAAbg");
	var mask_graphics_39 = new cjs.Graphics().p("AhlhUIAAgbIDiAAIAAAbg");
	var mask_graphics_40 = new cjs.Graphics().p("AhvhUIAAgbID2AAIAAAbg");
	var mask_graphics_41 = new cjs.Graphics().p("Ah3hUIAAgbIEFAAIAAAbg");
	var mask_graphics_42 = new cjs.Graphics().p("Ah+hUIAAgbIETAAIAAAbg");
	var mask_graphics_43 = new cjs.Graphics().p("AiDhUIAAgbIEcAAIAAAbg");
	var mask_graphics_44 = new cjs.Graphics().p("AiGhUIAAgbIEjAAIAAAbg");
	var mask_graphics_45 = new cjs.Graphics().p("AiJhUIAAgbIEoAAIAAAbg");
	var mask_graphics_46 = new cjs.Graphics().p("AiGhUIAAgbIEpAAIAAAbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_graphics_26,x:1.9741,y:-11.15}).wait(1).to({graphics:mask_graphics_27,x:2.0441,y:-11.15}).wait(1).to({graphics:mask_graphics_28,x:2.2541,y:-11.15}).wait(1).to({graphics:mask_graphics_29,x:2.6041,y:-11.15}).wait(1).to({graphics:mask_graphics_30,x:3.0942,y:-11.15}).wait(1).to({graphics:mask_graphics_31,x:3.7242,y:-11.15}).wait(1).to({graphics:mask_graphics_32,x:4.4943,y:-11.15}).wait(1).to({graphics:mask_graphics_33,x:5.4044,y:-11.15}).wait(1).to({graphics:mask_graphics_34,x:6.4544,y:-11.15}).wait(1).to({graphics:mask_graphics_35,x:7.6445,y:-11.15}).wait(1).to({graphics:mask_graphics_36,x:8.9746,y:-11.15}).wait(1).to({graphics:mask_graphics_37,x:10.3048,y:-11.15}).wait(1).to({graphics:mask_graphics_38,x:11.4949,y:-11.15}).wait(1).to({graphics:mask_graphics_39,x:12.5449,y:-11.15}).wait(1).to({graphics:mask_graphics_40,x:13.455,y:-11.15}).wait(1).to({graphics:mask_graphics_41,x:14.2251,y:-11.15}).wait(1).to({graphics:mask_graphics_42,x:14.8551,y:-11.15}).wait(1).to({graphics:mask_graphics_43,x:15.3452,y:-11.15}).wait(1).to({graphics:mask_graphics_44,x:15.6952,y:-11.15}).wait(1).to({graphics:mask_graphics_45,x:15.9052,y:-11.15}).wait(1).to({graphics:mask_graphics_46,x:16.3002,y:-11.15}).wait(15));

	// lines copy
	this.instance = new lib.stripes();
	this.instance.setTransform(17.55,-22.55,1,1,0,0,0,11.9,0.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(26).to({_off:false},0).to({_off:true},24).wait(11));

	// 1st_linemask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("AAJhjIAAgbIAMAAIAAAbg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AAJhjIAAgbIAMAAIAAAbg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AAGhjIAAgbIASAAIAAAbg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AADhjIAAgbIAYAAIAAAbg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AgBhjIAAgbIAhAAIAAAbg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AgIhjIAAgbIAuAAIAAAbg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AgQhjIAAgbIA+AAIAAAbg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AgahjIAAgbIBRAAIAAAbg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AglhjIAAgbIBnAAIAAAbg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AgxhjIAAgbIB+AAIAAAbg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Ag/hjIAAgbICaAAIAAAbg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AhNhjIAAgbIC1AAIAAAbg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AhZhjIAAgbIDNAAIAAAbg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AhkhjIAAgbIDiAAIAAAbg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AhuhjIAAgbID2AAIAAAbg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Ah2hjIAAgbIEFAAIAAAbg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ah9hjIAAgbIETAAIAAAbg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AiChjIAAgbIEcAAIAAAbg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AiFhjIAAgbIEjAAIAAAbg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AiIhjIAAgbIEoAAIAAAbg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AiFhjIAAgbIEpAAIAAAbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:2.0741,y:-12.675}).wait(1).to({graphics:mask_1_graphics_23,x:2.1441,y:-12.675}).wait(1).to({graphics:mask_1_graphics_24,x:2.3541,y:-12.675}).wait(1).to({graphics:mask_1_graphics_25,x:2.7041,y:-12.675}).wait(1).to({graphics:mask_1_graphics_26,x:3.1942,y:-12.675}).wait(1).to({graphics:mask_1_graphics_27,x:3.8242,y:-12.675}).wait(1).to({graphics:mask_1_graphics_28,x:4.5943,y:-12.675}).wait(1).to({graphics:mask_1_graphics_29,x:5.5044,y:-12.675}).wait(1).to({graphics:mask_1_graphics_30,x:6.5544,y:-12.675}).wait(1).to({graphics:mask_1_graphics_31,x:7.7445,y:-12.675}).wait(1).to({graphics:mask_1_graphics_32,x:9.0746,y:-12.675}).wait(1).to({graphics:mask_1_graphics_33,x:10.4048,y:-12.675}).wait(1).to({graphics:mask_1_graphics_34,x:11.5949,y:-12.675}).wait(1).to({graphics:mask_1_graphics_35,x:12.6449,y:-12.675}).wait(1).to({graphics:mask_1_graphics_36,x:13.555,y:-12.675}).wait(1).to({graphics:mask_1_graphics_37,x:14.3251,y:-12.675}).wait(1).to({graphics:mask_1_graphics_38,x:14.9551,y:-12.675}).wait(1).to({graphics:mask_1_graphics_39,x:15.4452,y:-12.675}).wait(1).to({graphics:mask_1_graphics_40,x:15.7952,y:-12.675}).wait(1).to({graphics:mask_1_graphics_41,x:16.0052,y:-12.675}).wait(1).to({graphics:mask_1_graphics_42,x:16.4002,y:-12.675}).wait(19));

	// lines
	this.instance_1 = new lib.stripes();
	this.instance_1.setTransform(17.55,-22.55,1,1,0,0,0,11.9,0.8);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({_off:true},28).wait(11));

	// status copy
	this.instance_2 = new lib.text_1();
	this.instance_2.setTransform(0.85,-36.1,1,1,0,0,0,93.3,15.3);

	this.instance_3 = new lib.text_2();
	this.instance_3.setTransform(0.85,-36.1,1,1,0,0,0,93.3,15.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2}]}).to({state:[{t:this.instance_3}]},50).wait(11));

	// UI
	this.UI = new lib.ui();
	this.UI.name = "UI";
	this.UI.setTransform(7.1,-4.05,1,1,0,0,0,107.2,100.9);

	this.timeline.addTween(cjs.Tween.get(this.UI).wait(61));

	// Layer_3
	this.popup_shdw = new lib.pop_up_shadow();
	this.popup_shdw.name = "popup_shdw";
	this.popup_shdw.setTransform(6.4,-5.6,0.94,0.94,0,0,0,105.4,99);
	this.popup_shdw.alpha = 0.25;
	this.popup_shdw.filters = [new cjs.BlurFilter(60, 60, 1)];
	this.popup_shdw.cache(-2,-2,215,202);

	this.timeline.addTween(cjs.Tween.get(this.popup_shdw).wait(61));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-122.6,-128.6,261,249);


(lib.pencil = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pencil.cache(-70,-56,140,112,0.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pencil = new lib.pencil_c();
	this.pencil.name = "pencil";
	this.pencil.setTransform(34.1,27.9,1,1,0,0,0,34.1,27.9);

	this.timeline.addTween(cjs.Tween.get(this.pencil).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pencil, new cjs.Rectangle(0,0,68.3,55.8), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		//exportRoot.mainMC.icons.play()
	}
	this.frame_86 = function() {
		exportRoot.tl1.play()
		//exportRoot.mainMC.screen.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(17).call(this.frame_86).wait(14).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regY:0.4,scaleX:2.4363,scaleY:2.4363,x:-707.05,y:265.15},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.3,337.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-879.8,191.6,2358.3,291.6);


(lib.icon_teams = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.familiar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.box.cache(-35,-17,70,34,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.box = new lib.familiar_c();
	this.box.name = "box";
	this.box.setTransform(17.2,8.3,1,1,0,0,0,17.2,8.3);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.familiar, new cjs.Rectangle(0,0,34.3,16.5), null);


(lib.conversational = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.box.cache(-60,-16,120,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.box = new lib.conversational_c();
	this.box.name = "box";
	this.box.setTransform(30.3,8.2,1,1,0,0,0,30.3,8.2);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.conversational, new cjs.Rectangle(0,0,60.5,16.4), null);


(lib.communal = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.box.cache(-46,-16,92,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Communal_c
	this.box = new lib.Communal_c();
	this.box.name = "box";
	this.box.setTransform(23.2,8,1,1,0,0,0,23.2,8);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.communal, new cjs.Rectangle(0,0,46.5,16), null);


(lib.BG_gray = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,728,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,728,90), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.words = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// communal
	this.communal = new lib.communal();
	this.communal.name = "communal";
	this.communal.setTransform(24.85,-15.9,1.7002,1.7002,0,0,0,23.2,8);

	this.timeline.addTween(cjs.Tween.get(this.communal).wait(1));

	// Familiar
	this.familiar = new lib.familiar();
	this.familiar.name = "familiar";
	this.familiar.setTransform(14.7,12.9,1.7002,1.7002,0,0,0,17.2,8.3);

	this.timeline.addTween(cjs.Tween.get(this.familiar).wait(1));

	// Conversational
	this.conversational = new lib.conversational();
	this.conversational.name = "conversational";
	this.conversational.setTransform(36.95,42.95,1.7002,1.7002,0,0,0,30.3,8.2);

	this.timeline.addTween(cjs.Tween.get(this.conversational).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.words, new cjs.Rectangle(-14.6,-29.5,102.89999999999999,86.4), null);


(lib.logo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.screen_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pencil
	this.pencil = new lib.pencil();
	this.pencil.name = "pencil";
	this.pencil.setTransform(281.25,-242.35,0.2143,0.2153,0,0,0,1,48.8);

	this.timeline.addTween(cjs.Tween.get(this.pencil).wait(1));

	// Layer_2
	this.words = new lib.words();
	this.words.name = "words";
	this.words.setTransform(153.65,-95.45,1.3868,1.3868,0,0,0,15.6,17.7);

	this.timeline.addTween(cjs.Tween.get(this.words).wait(1));

	// pop_up
	this.popup = new lib.pop_up();
	this.popup.name = "popup";
	this.popup.setTransform(112.1,-105,0.9825,0.9825);

	this.timeline.addTween(cjs.Tween.get(this.popup).wait(1));

	// Blur
	this.blur = new lib.blur_UI();
	this.blur.name = "blur";
	this.blur.setTransform(117.4,-126.85,1,1,0,0,0,226.6,152.8);
	this.blur.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.blur).wait(1));

	// main_Ui
	this.instance = new lib.UI();
	this.instance.setTransform(-109.2,-279.65,0.9062,0.918);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_anim, new cjs.Rectangle(-109.2,-279.6,453.09999999999997,305.70000000000005), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-31.8,3.55,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("AmjBxIAAjiINHAAIAADig");
	this.shape.setTransform(-57.15,3.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-99.2,-7.4,84.10000000000001,22.700000000000003), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(272.05,-59,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// screen
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(430.8,90.25,0.3905,0.3125,0,-28.3369,-17.0392,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// shadow
	this.shadow = new lib.shadow_1();
	this.shadow.name = "shadow";
	this.shadow.setTransform(451.05,41.05,0.3904,0.3904,0,0,0,125.3,77.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(713.25,2,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(678.1,62.55,1,1,0,0,0,1.2,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(744.3,58,1.0683,1.0683,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-83.1,728.3,236.1), null);


// stage content:
(lib.M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var screen = mc.screen
		var shadow = mc.shadow
		var options = mc.options
		var pencil = mc.screen.pencil
		
		/*mc.cta.alpha=0
		mc.replay_btn.alpha=0*/
		
		this.runBanner = function() {
			
			this.tl1 = new TimelineLite();
			
					for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "+=0.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
						
				exportRoot.tl1.from(screen, 1.4, {  x: "+=250",y: "+=250",	ease:Power4.easeOut}, "-=0.9");
				exportRoot.tl1.from(shadow, 1.4, {  x: "+=250",y: "+=250",	ease:Power4.easeOut}, "-=1.4");
		
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "-=110", alpha: 0, ease:Power4.easeInOut}, "+=0.3");
				if (i!=0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "-=110", alpha: 0, ease:Power4.easeInOut}, "-=0.7");
				}
				
				exportRoot.tl1.to(screen, 1.4, {scaleX: "0.403",scaleY: "0.323", x: "-=87",y: "+=8", ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.to(shadow, 1.4, {scaleX: "0.403",scaleY: "0.403", x: "-=87",y: "+=8", ease:Power4.easeOut}, "-=1.4");
			
				exportRoot.tl1.to(screen.popup, 1.4, {scaleX: "1.963",scaleY: "1.963", x: "+=0",y: "-=15",ease:Power4.easeInOut,onComplete:function(){screen.popup.gotoAndPlay(0);}}, "-=1.4");
				exportRoot.tl1.to(screen.blur, 1.4, {alpha :1,ease:Power4.easeInOut}, "-=1.4");
				exportRoot.tl1.to(screen.popup.popup_shdw, 1.4, {alpha :0.25,ease:Power4.easeInOut}, "-=1.4");
				exportRoot.tl1.to(pencil, 1.4, {rotation: -15,scaleX: "0.97",scaleY: "0.97", x: "-=60",y: "+=40",ease:Power4.easeInOut}, "-=1.4");
		
				exportRoot.tl1.from(screen.words.communal, 0.8, {alpha: 0, x: "+=50",ease:Power4.easeInOut}, "+=0.8");
				exportRoot.tl1.from(screen.words.familiar, 0.8, {alpha: 0, x: "+=50",ease:Power4.easeInOut}, "-=0.7");
				exportRoot.tl1.from(screen.words.conversational, 0.8, {alpha: 0, x: "+=50",ease:Power4.easeInOut}, "-=0.7");
				
				exportRoot.tl1.to(pencil, 0.8, {rotation: -20,y: "+=140",x: "-=10",ease:Power4.easeInOut}, "+=0.0");
				
				exportRoot.tl1.to(screen.words, 1.8, {y: "-=113",ease:Power4.easeInOut}, "-=0.8");		
				exportRoot.tl1.to(screen.words.communal, 0.1, {alpha :0,ease:Power1.easeInOut}, "-=1.15");
				exportRoot.tl1.to(screen.words.familiar, 0.1, {alpha :0,ease:Power1.easeInOut}, "-=0.94");
				exportRoot.tl1.to(screen.words.conversational, 0.8, {alpha :0,ease:Power1.easeInOut,onStart:function(){screen.popup.gotoAndPlay(50);}}, "-=0");
		
				exportRoot.tl1.to(screen.popup, 1.4, {scaleX: "0.98",scaleY: "0.98", x: "-=0",y: "+=15",ease:Power4.easeInOut}, "-=0.4");
				exportRoot.tl1.to(screen.blur, 1.4, {alpha :0,ease:Power4.easeInOut}, "-=1.4");
				exportRoot.tl1.to(screen.popup.popup_shdw, 1.4, {alpha :0,ease:Power4.easeInOut}, "-=1.4");
				exportRoot.tl1.to(pencil, 1.4, {rotation: 0,scaleX: "0.21",scaleY: "0.21", x: "+=70",y: "-=180",ease:Power4.easeInOut}, "-=1.4");
			
				exportRoot.tl1.to(screen, 1.2, {x: "-=126",y: "-=10",scaleX: "0.384",scaleY: "0.308", ease:Power4.easeInOut}, "-=1");
				exportRoot.tl1.to(shadow, 1.2, {x: "-=126",y: "-=10",scaleX: "0.384",scaleY: "0.384", ease:Power4.easeInOut}, "-=1.2");
		
			
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.6");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,-38.1,364.29999999999995,191.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1.png?1599135026809", id:"M365_FY21Q2_ConsumerRefresh_USA_728x90_BAN_Editor_English_NA_Standard_ANI_BN_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;