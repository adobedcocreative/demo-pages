// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#505050>Work in real time, together","15px",385,15 ,"17","350", "left"];

	bannerData.headline2 = ["<#505050>Coauthor documents and communicate in real |time across your favorite apps, plus 1 TB of |OneDrive cloud storage","10px",385,37,"12","350", "left"];


	bannerData.CTA = ["<#FFFFFF>BUY NOW","11px",0,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
