(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[922,0,100,147],[922,149,100,147],[352,202,100,147],[454,202,100,147],[0,235,100,147],[102,235,100,147],[204,235,100,147],[556,276,100,147],[658,276,100,147],[760,276,100,147],[862,298,100,147],[306,351,100,147],[408,351,100,147],[0,384,100,147],[102,384,100,147],[204,384,100,147],[654,188,250,86],[806,0,114,181],[622,425,100,80],[654,0,150,186],[510,425,110,109],[0,0,350,233],[352,0,300,200]]}
];


// symbols:



(lib._0090 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._0092 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._0094 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._0096 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._0098 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._0100 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._0102 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._0104 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib._0106 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib._0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib._0110 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib._0112 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib._0114 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib._0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib._0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib._0120 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.BG_Grass2 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.bodyResize = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Icon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.leafA = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.LeafB = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.screenshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.screenshadow();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_75 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(75).call(this.frame_75).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_52 = new cjs.Graphics().p("AAWIAICQgyIC3ISIiQAyg");
	var mask_graphics_53 = new cjs.Graphics().p("AiWIAIHqipIC2ISInrCog");
	var mask_graphics_54 = new cjs.Graphics().p("Ak1IAIMnkWIC3ISIsnEVg");
	var mask_graphics_55 = new cjs.Graphics().p("AnFIAIRIl5IC2IRIxHF5g");
	var mask_graphics_56 = new cjs.Graphics().p("ApHIAIVMnTIC2ISI1MHSg");
	var mask_graphics_57 = new cjs.Graphics().p("Aq8IAIY2ojIC3IRI43Ijg");
	var mask_graphics_58 = new cjs.Graphics().p("AslIAIcIprIC3IRI8JJrg");
	var mask_graphics_59 = new cjs.Graphics().p("AuDIAIfEqrIC2IQI/EKsg");
	var mask_graphics_60 = new cjs.Graphics().p("AvVIAMAhogLkIC3IRMghpALkg");
	var mask_graphics_61 = new cjs.Graphics().p("AwdIAMAj4gMVIC3IQMgj5AMWg");
	var mask_graphics_62 = new cjs.Graphics().p("AxcIAMAl2gNAIC2IQMgl2ANBg");
	var mask_graphics_63 = new cjs.Graphics().p("AyRIAMAnggNlIC3IQMgnhANmg");
	var mask_graphics_64 = new cjs.Graphics().p("Ay/IAMAo8gOEIC2IQMgo7AOFg");
	var mask_graphics_65 = new cjs.Graphics().p("AzlIAMAqIgOeIC2IQMgqHAOfg");
	var mask_graphics_66 = new cjs.Graphics().p("A0EIAMArGgO0IC2IRMgrFAO0g");
	var mask_graphics_67 = new cjs.Graphics().p("A0cIAMAr2gPFIC3IRMgr3APFg");
	var mask_graphics_68 = new cjs.Graphics().p("A0wIAMAsegPSIC2IQMgsdAPTg");
	var mask_graphics_69 = new cjs.Graphics().p("A0+IAMAs6gPcIC3IQMgs7APdg");
	var mask_graphics_70 = new cjs.Graphics().p("A1JIAMAtQgPjIC2IQMgtPAPkg");
	var mask_graphics_71 = new cjs.Graphics().p("A1QIAMAtegPoIC2IRMgtdAPog");
	var mask_graphics_72 = new cjs.Graphics().p("A1UIAMAtmgPrIC2IRMgtlAPrg");
	var mask_graphics_73 = new cjs.Graphics().p("A1WIAMAtqgPsIC2IQMgtqAPtg");
	var mask_graphics_74 = new cjs.Graphics().p("A1XIAMAtsgPtIC2IRMgtrAPtg");
	var mask_graphics_75 = new cjs.Graphics().p("A1VH/MAtsgPtIC2IRMgtsAPug");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_graphics_52,x:34.8614,y:104.1502}).wait(1).to({graphics:mask_graphics_53,x:52.2231,y:104.1483}).wait(1).to({graphics:mask_graphics_54,x:68.0761,y:104.1468}).wait(1).to({graphics:mask_graphics_55,x:82.489,y:104.1453}).wait(1).to({graphics:mask_graphics_56,x:95.5304,y:104.144}).wait(1).to({graphics:mask_graphics_57,x:107.2688,y:104.1429}).wait(1).to({graphics:mask_graphics_58,x:117.7727,y:104.1418}).wait(1).to({graphics:mask_graphics_59,x:127.1109,y:104.1409}).wait(1).to({graphics:mask_graphics_60,x:135.3517,y:104.1401}).wait(1).to({graphics:mask_graphics_61,x:142.5639,y:104.1393}).wait(1).to({graphics:mask_graphics_62,x:148.816,y:104.1387}).wait(1).to({graphics:mask_graphics_63,x:154.1766,y:104.1382}).wait(1).to({graphics:mask_graphics_64,x:158.7143,y:104.1378}).wait(1).to({graphics:mask_graphics_65,x:162.4975,y:104.1374}).wait(1).to({graphics:mask_graphics_66,x:165.595,y:104.1371}).wait(1).to({graphics:mask_graphics_67,x:168.0753,y:104.1368}).wait(1).to({graphics:mask_graphics_68,x:170.0069,y:104.1366}).wait(1).to({graphics:mask_graphics_69,x:171.4585,y:104.1365}).wait(1).to({graphics:mask_graphics_70,x:172.4986,y:104.1364}).wait(1).to({graphics:mask_graphics_71,x:173.1958,y:104.1363}).wait(1).to({graphics:mask_graphics_72,x:173.6187,y:104.1363}).wait(1).to({graphics:mask_graphics_73,x:173.8359,y:104.1362}).wait(1).to({graphics:mask_graphics_74,x:173.9159,y:104.1362}).wait(1).to({graphics:mask_graphics_75,x:174.1059,y:104.0752}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AselkIY+DSI5AH3g");
	this.shape.setTransform(102.8826,174.2367,0.6439,0.6439);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(52).to({_off:false},0).wait(24));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_52 = new cjs.Graphics().p("AAWIAICQgyIC3ISIiQAyg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AiWIAIHqipIC2ISInrCog");
	var mask_1_graphics_54 = new cjs.Graphics().p("Ak1IAIMnkWIC3ISIsnEVg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AnFIAIRIl5IC2IRIxHF5g");
	var mask_1_graphics_56 = new cjs.Graphics().p("ApHIAIVMnTIC2ISI1MHSg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Aq8IAIY2ojIC3IRI43Ijg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AslIAIcIprIC3IRI8JJrg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AuDIAIfEqrIC2IQI/EKsg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AvVIAMAhogLkIC3IRMghpALkg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AwdIAMAj4gMVIC3IQMgj5AMWg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AxcIAMAl2gNAIC2IQMgl2ANBg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AyRIAMAnggNlIC3IQMgnhANmg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ay/IAMAo8gOEIC2IQMgo7AOFg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AzlIAMAqIgOeIC2IQMgqHAOfg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A0EIAMArGgO0IC2IRMgrFAO0g");
	var mask_1_graphics_67 = new cjs.Graphics().p("A0cIAMAr2gPFIC3IRMgr3APFg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A0wIAMAsegPSIC2IQMgsdAPTg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A0+IAMAs6gPcIC3IQMgs7APdg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A1JIAMAtQgPjIC2IQMgtPAPkg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A1QIAMAtegPoIC2IRMgtdAPog");
	var mask_1_graphics_72 = new cjs.Graphics().p("A1UIAMAtmgPrIC2IRMgtlAPrg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A1WIAMAtqgPsIC2IQMgtqAPtg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A1XIAMAtsgPtIC2IRMgtrAPtg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A1VH/MAtsgPtIC2IRMgtsAPug");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_1_graphics_52,x:34.8614,y:104.1502}).wait(1).to({graphics:mask_1_graphics_53,x:52.2231,y:104.1483}).wait(1).to({graphics:mask_1_graphics_54,x:68.0761,y:104.1468}).wait(1).to({graphics:mask_1_graphics_55,x:82.489,y:104.1453}).wait(1).to({graphics:mask_1_graphics_56,x:95.5304,y:104.144}).wait(1).to({graphics:mask_1_graphics_57,x:107.2688,y:104.1429}).wait(1).to({graphics:mask_1_graphics_58,x:117.7727,y:104.1418}).wait(1).to({graphics:mask_1_graphics_59,x:127.1109,y:104.1409}).wait(1).to({graphics:mask_1_graphics_60,x:135.3517,y:104.1401}).wait(1).to({graphics:mask_1_graphics_61,x:142.5639,y:104.1393}).wait(1).to({graphics:mask_1_graphics_62,x:148.816,y:104.1387}).wait(1).to({graphics:mask_1_graphics_63,x:154.1766,y:104.1382}).wait(1).to({graphics:mask_1_graphics_64,x:158.7143,y:104.1378}).wait(1).to({graphics:mask_1_graphics_65,x:162.4975,y:104.1374}).wait(1).to({graphics:mask_1_graphics_66,x:165.595,y:104.1371}).wait(1).to({graphics:mask_1_graphics_67,x:168.0753,y:104.1368}).wait(1).to({graphics:mask_1_graphics_68,x:170.0069,y:104.1366}).wait(1).to({graphics:mask_1_graphics_69,x:171.4585,y:104.1365}).wait(1).to({graphics:mask_1_graphics_70,x:172.4986,y:104.1364}).wait(1).to({graphics:mask_1_graphics_71,x:173.1958,y:104.1363}).wait(1).to({graphics:mask_1_graphics_72,x:173.6187,y:104.1363}).wait(1).to({graphics:mask_1_graphics_73,x:173.8359,y:104.1362}).wait(1).to({graphics:mask_1_graphics_74,x:173.9159,y:104.1362}).wait(1).to({graphics:mask_1_graphics_75,x:174.1059,y:104.0752}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A2FDaMAsKgNVIAAHDMgq0AM0g");
	this.shape_1.setTransform(192.95,129.375);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(52).to({_off:false},0).wait(24));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_29 = new cjs.Graphics().p("ATpSEIBEosIKZBRIhDIsg");
	var mask_2_graphics_30 = new cjs.Graphics().p("APcRjIBDosIOnByIhEIsg");
	var mask_2_graphics_31 = new cjs.Graphics().p("ALTRDIBDosISwCSIhEIsg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AHTQkIBEosIWuCxIhEIsg");
	var mask_2_graphics_33 = new cjs.Graphics().p("ADiQHIBEosIafDOIhEIsg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AACPsIBEosId+DpIhDIsg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AjJPTIBEosMAhJAECIhEIsg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AmCO8IBEosMAkCAEZIhEIsg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AonOoIBEosMAmmAEtIhDIsg");
	var mask_2_graphics_38 = new cjs.Graphics().p("Aq5OWIBDosMAo5AE/IhEIsg");
	var mask_2_graphics_39 = new cjs.Graphics().p("As7OGIBDorMAq7AFOIhEIsg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AuuN4IBDorMAsuAFcIhEIsg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AwUNsIBEosMAuTAFpIhEIsg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AxtNhIBEosMAvsAF0IhEIsg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Ay8NYIBEosMAw6AF9IhDIsg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0BNPIBEosMAx/AGGIhDIsg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0+NIIBEosMAy8AGNIhEIsg");
	var mask_2_graphics_46 = new cjs.Graphics().p("A1zNBIBDosMAzyAGUIhEIsg");
	var mask_2_graphics_47 = new cjs.Graphics().p("A2iM8IBEosMA0gAGZIhEIsg");
	var mask_2_graphics_48 = new cjs.Graphics().p("A3LM3IBEosMA1JAGeIhEIsg");
	var mask_2_graphics_49 = new cjs.Graphics().p("A3uMyIBDosMA1tAGjIhEIsg");
	var mask_2_graphics_50 = new cjs.Graphics().p("A4NMvIBEosMA2LAGmIhEIsg");
	var mask_2_graphics_51 = new cjs.Graphics().p("A4nMrIBDorMA2mAGpIhEIsg");
	var mask_2_graphics_52 = new cjs.Graphics().p("A4+MoIBDosMA28AGtIhEIsg");
	var mask_2_graphics_75 = new cjs.Graphics().p("A4+MoIBDosMA28AGtIhEIsg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_2_graphics_29,x:199.0364,y:123.725}).wait(1).to({graphics:mask_2_graphics_30,x:198.993,y:123.7235}).wait(1).to({graphics:mask_2_graphics_31,x:198.9503,y:123.722}).wait(1).to({graphics:mask_2_graphics_32,x:198.9092,y:123.7205}).wait(1).to({graphics:mask_2_graphics_33,x:198.8704,y:123.7191}).wait(1).to({graphics:mask_2_graphics_34,x:198.8344,y:123.7178}).wait(1).to({graphics:mask_2_graphics_35,x:198.8014,y:123.7166}).wait(1).to({graphics:mask_2_graphics_36,x:198.7717,y:123.7155}).wait(1).to({graphics:mask_2_graphics_37,x:198.7452,y:123.7145}).wait(1).to({graphics:mask_2_graphics_38,x:198.7215,y:123.7137}).wait(1).to({graphics:mask_2_graphics_39,x:198.7006,y:123.7129}).wait(1).to({graphics:mask_2_graphics_40,x:198.6821,y:123.7122}).wait(1).to({graphics:mask_2_graphics_41,x:198.6658,y:123.7116}).wait(1).to({graphics:mask_2_graphics_42,x:198.6514,y:123.7111}).wait(1).to({graphics:mask_2_graphics_43,x:198.6388,y:123.7107}).wait(1).to({graphics:mask_2_graphics_44,x:198.6276,y:123.7102}).wait(1).to({graphics:mask_2_graphics_45,x:198.6178,y:123.7099}).wait(1).to({graphics:mask_2_graphics_46,x:198.6092,y:123.7096}).wait(1).to({graphics:mask_2_graphics_47,x:198.6017,y:123.7093}).wait(1).to({graphics:mask_2_graphics_48,x:198.5951,y:123.7091}).wait(1).to({graphics:mask_2_graphics_49,x:198.5894,y:123.7089}).wait(1).to({graphics:mask_2_graphics_50,x:198.5844,y:123.7087}).wait(1).to({graphics:mask_2_graphics_51,x:198.5802,y:123.7085}).wait(1).to({graphics:mask_2_graphics_52,x:198.5114,y:123.65}).wait(23).to({graphics:mask_2_graphics_75,x:198.5114,y:123.65}).wait(1));

	// bottom
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,0,0,0.008)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_2.setTransform(168,131);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A5zAMIAAnFMAznAGhIg7HSg");
	this.shape_3.setTransform(216.6,196.025);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},29).to({state:[{t:this.shape_3}]},46).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18,6,363.8,250);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bodyResize();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(0,0,114,181), null);


(lib.mscopy_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mscopy_white, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(172.2024,63.4258);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(172.2024,63.4258);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],20.7,54.8,0,20.7,54.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(172.2024,71.5759);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(0,0,344.4,135), null);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LeafB();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110,109), null);


(lib.leafA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA();
	this.instance.setTransform(0,0,1.32,1.32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA_1, new cjs.Rectangle(0,0,198,245.5), null);


(lib.Icon_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon();
	this.instance.setTransform(1.1,-6.45,1.6,1.6,0.0005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon_1, new cjs.Rectangle(1.1,-6.4,160,128), null);


(lib.grass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.BG_Grass2();
	this.instance.setTransform(11.85,4.65,1.3923,1.3923);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass, new cjs.Rectangle(11.9,4.7,348,119.7), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// DinoHead copy
	this.instance = new lib._0090();
	this.instance.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_1 = new lib._0092();
	this.instance_1.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_2 = new lib._0094();
	this.instance_2.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_3 = new lib._0096();
	this.instance_3.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_4 = new lib._0098();
	this.instance_4.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_5 = new lib._0100();
	this.instance_5.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_6 = new lib._0102();
	this.instance_6.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_7 = new lib._0104();
	this.instance_7.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_8 = new lib._0106();
	this.instance_8.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_9 = new lib._0108();
	this.instance_9.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_10 = new lib._0110();
	this.instance_10.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_11 = new lib._0112();
	this.instance_11.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_12 = new lib._0114();
	this.instance_12.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_13 = new lib._0116();
	this.instance_13.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_14 = new lib._0118();
	this.instance_14.setTransform(1.95,42.35,0.8906,0.8906);

	this.instance_15 = new lib._0120();
	this.instance_15.setTransform(1.95,42.35,0.8906,0.8906);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_15}]},24).to({state:[]},1).to({state:[{t:this.instance_15}]},4).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_10}]},3).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[]},1).to({state:[{t:this.instance_15}]},7).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(30).to({_off:false},0).wait(24).to({_off:true},1).wait(4).to({_off:false},0).wait(1).to({_off:true},2).wait(35).to({_off:false},0).wait(7));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(2,42.4,89,130.9);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384549").s().p("A4MPeIAA7rIgBgWIgEgUIATgFQAUgFADABQARAFAQAAQAIAAAOgFQAPgFAJAAQALAAAGAGIAHAIIBSAoIAdACQADgGAHgEQAEgCAdgBIAcgBIARAKIALgGIAiAGIANgSIARAAIAOAKIBKgCIAKAHIBCgDIAJgHIAWACIAKgEIAfAAIAJgGQALgGAIAAQAOAAANAOIAigBIAJgHIAJADIAYAUIATAAIATAOIAWAAIAVAQIABANIANAAIADAOIAVAXIAOACIAAAKIASAIIABAIIALAAIAGAJIANABIgBALIAKAAIAOAKIABAJIAWAJIAXgUIALgFIAAgIIAjgMIADgJIAUgBIAVATIALAAIAeAcIANgJIATANQASgBADgBIANgLIAHAIIAJgGIALABIAJgEIARgDIALAKIAFgLIARgBIAHgCIAJADIAbAEIAJAIIAKgGIAKABIAGgRIASgQIAUgEQAEgBATADIA7AAIALgCIAMAGIANAAIAMgIIAQAKIAWAXIATABIAbAXIAMgCIAUAUIARACQAEAAAGAEIAHAHIAIANIAfALIAHAAIAEAHIA3AAIAGgGIAJAEIAeAAIAigoIAIAAIgCgJIAIgJIADgKQAQgJABgEQABgDAEgFIAGgEIAIgDIAAgSQAKACAAgDIgDgRIAIgBIAEgNIALgNQAOgOADgCQAEgCAPgCIATgNIAKABIAFgNIASAAIAAgQIAPgFIAHgKIAGgDQAFgEAEAAIAlADIAKACIAGAHIAdgdIABgOIAMAAIAZgNIAdgHIACgKIAIACIAEgJIALAAIABgJIATgLIACgMIANgCIANgLIABgJIAfgWIAQgGIAFAKIAQABIAXAPIASgUIAMgBIAGgHIAOAAIAOgMIANAAIAHAFIAhAAIAVAJIATgJIAgAAQApgDAOADQAOAEAQAKIAmABIAOgIIAQAGIACAHIBWABQAEAAAPgIQAPgHABAAQAEACAigBIAFgIIAJgCIAGAGIAWgLIAngBIAmgJIAOgHIAxAaIgITYIAALJg");
	this.shape.setTransform(155.4,98.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(0,0,310.8,198), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150.0023,124.9924,1,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-31.6,-11.15,416.5,277.25,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(176.7,127.45,1,1,0,0,0,208.3,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(-31.6,-11.1,416.5,277.20000000000005), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim_White = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.mscopy_white();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_White, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// WhiteLogo
	this.instance_1 = new lib.MSFT_Logo_anim_White();
	this.instance_1.setTransform(222.05,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.msoftLogoWhite = new lib.MSFT_Logo_anim_White();
	this.msoftLogoWhite.name = "msoftLogoWhite";
	this.msoftLogoWhite.setTransform(-25.15,1.05,2.2543,2.2543,0,0,0,-0.1,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},59).to({state:[{t:this.msoftLogoWhite}]},41).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({_off:true,regX:-0.1,regY:0.4,scaleX:2.2543,scaleY:2.2543,x:-25.15,y:1.05,alpha:1},41,cjs.Ease.quadInOut).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.4,scaleX:2.2543,scaleY:2.2543,x:-25.15,y:1.05},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.setTransform(299.85,340.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-68.3,982,817.0999999999999);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_graphics_79 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_graphics_80 = new cjs.Graphics().p("A3dTlMAAAgnIMAu7AAAMAAAAnIg");
	var mask_graphics_81 = new cjs.Graphics().p("A3bTjMAAAgnAMAu3AAAMAAAAnAg");
	var mask_graphics_82 = new cjs.Graphics().p("A3VTgMAAAgmyMAuxAAAMAAAAmyg");
	var mask_graphics_83 = new cjs.Graphics().p("A3MTbMAAAgmfMAuoAAAMAAAAmfg");
	var mask_graphics_84 = new cjs.Graphics().p("A3BTVMAAAgmGMAucAAAMAAAAmGg");
	var mask_graphics_85 = new cjs.Graphics().p("A2zTNMAAAglnMAuNAAAMAAAAlng");
	var mask_graphics_86 = new cjs.Graphics().p("A2iTFMAAAglEMAt7AAAMAAAAlEg");
	var mask_graphics_87 = new cjs.Graphics().p("A2QS6MAAAgkZMAtoAAAMAAAAkZg");
	var mask_graphics_88 = new cjs.Graphics().p("A16SvMAAAgjrMAtRAAAMAAAAjrg");
	var mask_graphics_89 = new cjs.Graphics().p("A1iSiMAAAgi2MAs4AAAMAAAAi2g");
	var mask_graphics_90 = new cjs.Graphics().p("A1ISTMAAAgh7MAsdAAAMAAAAh7g");
	var mask_graphics_91 = new cjs.Graphics().p("A0rSEMAAAgg8MAr+AAAMAAAAg8g");
	var mask_graphics_92 = new cjs.Graphics().p("A0LRzIAA/3MArdAAAIAAf3g");
	var mask_graphics_93 = new cjs.Graphics().p("AzpRgIAA+sMAq5AAAIAAesg");
	var mask_graphics_94 = new cjs.Graphics().p("AzFRMIAA9bMAqTAAAIAAdbg");
	var mask_graphics_95 = new cjs.Graphics().p("AygQ4IAA8KMApsAAAIAAcKg");
	var mask_graphics_96 = new cjs.Graphics().p("Ax+QmIAA7AMApIAAAIAAbAg");
	var mask_graphics_97 = new cjs.Graphics().p("AxfQVIAA57MAooAAAIAAZ7g");
	var mask_graphics_98 = new cjs.Graphics().p("AxCQFIAA47MAoJAAAIAAY7g");
	var mask_graphics_99 = new cjs.Graphics().p("AwoP3IAA4BMAnuAAAIAAYBg");
	var mask_graphics_100 = new cjs.Graphics().p("AwQPqIAA3MMAnVAAAIAAXMg");
	var mask_graphics_101 = new cjs.Graphics().p("Av6PeIAA2dMAm9AAAIAAWdg");
	var mask_graphics_102 = new cjs.Graphics().p("AvnPUIAA1zMAmpAAAIAAVzg");
	var mask_graphics_103 = new cjs.Graphics().p("AvXPLIAA1PMAmZAAAIAAVPg");
	var mask_graphics_104 = new cjs.Graphics().p("AvJPEIAA0xMAmKAAAIAAUxg");
	var mask_graphics_105 = new cjs.Graphics().p("Au+O9IAA0XMAl+AAAIAAUXg");
	var mask_graphics_106 = new cjs.Graphics().p("Au1O5IAA0FMAl1AAAIAAUFg");
	var mask_graphics_107 = new cjs.Graphics().p("AuvO1IAAz2MAlvAAAIAAT2g");
	var mask_graphics_108 = new cjs.Graphics().p("AurOzIAAzuMAlqAAAIAATug");
	var mask_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:149.8293,y:125.4028}).wait(79).to({graphics:mask_graphics_79,x:149.8293,y:125.4028}).wait(1).to({graphics:mask_graphics_80,x:149.8825,y:125.3345}).wait(1).to({graphics:mask_graphics_81,x:150.0283,y:125.1294}).wait(1).to({graphics:mask_graphics_82,x:149.9958,y:124.7878}).wait(1).to({graphics:mask_graphics_83,x:149.9502,y:124.3094}).wait(1).to({graphics:mask_graphics_84,x:149.8917,y:123.6944}).wait(1).to({graphics:mask_graphics_85,x:149.8201,y:122.9426}).wait(1).to({graphics:mask_graphics_86,x:149.7356,y:122.0543}).wait(1).to({graphics:mask_graphics_87,x:149.638,y:121.0292}).wait(1).to({graphics:mask_graphics_88,x:149.5274,y:119.8675}).wait(1).to({graphics:mask_graphics_89,x:149.4038,y:118.5691}).wait(1).to({graphics:mask_graphics_90,x:149.2672,y:117.134}).wait(1).to({graphics:mask_graphics_91,x:149.1175,y:115.5622}).wait(1).to({graphics:mask_graphics_92,x:148.9549,y:113.8538}).wait(1).to({graphics:mask_graphics_93,x:148.7792,y:112.0087}).wait(1).to({graphics:mask_graphics_94,x:148.5906,y:110.0269}).wait(1).to({graphics:mask_graphics_95,x:148.4019,y:108.0451}).wait(1).to({graphics:mask_graphics_96,x:148.2263,y:106.2}).wait(1).to({graphics:mask_graphics_97,x:148.0636,y:104.4916}).wait(1).to({graphics:mask_graphics_98,x:147.914,y:102.9198}).wait(1).to({graphics:mask_graphics_99,x:147.7774,y:101.4847}).wait(1).to({graphics:mask_graphics_100,x:147.6538,y:100.1863}).wait(1).to({graphics:mask_graphics_101,x:147.5432,y:99.0246}).wait(1).to({graphics:mask_graphics_102,x:147.4456,y:97.9995}).wait(1).to({graphics:mask_graphics_103,x:147.361,y:97.1111}).wait(1).to({graphics:mask_graphics_104,x:147.2895,y:96.3594}).wait(1).to({graphics:mask_graphics_105,x:147.2309,y:95.7444}).wait(1).to({graphics:mask_graphics_106,x:147.1854,y:95.266}).wait(1).to({graphics:mask_graphics_107,x:147.1529,y:94.9243}).wait(1).to({graphics:mask_graphics_108,x:147.1333,y:94.7193}).wait(1).to({graphics:mask_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_graphics_135,x:147.1518,y:94.651}).wait(41));

	// LeafA
	this.instance = new lib.leafA_1();
	this.instance.setTransform(84,98.1,1,1,0,0,0,99,122.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({scaleX:0.6362,scaleY:0.6362,x:58.25,y:128.95},30,cjs.Ease.quadInOut).wait(67));

	// ScreenMaskA copy 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A3dTlMAAAgnIMAu7AAAMAAAAnIg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A3bTjMAAAgnAMAu3AAAMAAAAnAg");
	var mask_1_graphics_82 = new cjs.Graphics().p("A3VTgMAAAgmyMAuxAAAMAAAAmyg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A3MTbMAAAgmfMAuoAAAMAAAAmfg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A3BTVMAAAgmGMAucAAAMAAAAmGg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A2zTNMAAAglnMAuNAAAMAAAAlng");
	var mask_1_graphics_86 = new cjs.Graphics().p("A2iTFMAAAglEMAt7AAAMAAAAlEg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A2QS6MAAAgkZMAtoAAAMAAAAkZg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A16SvMAAAgjrMAtRAAAMAAAAjrg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A1iSiMAAAgi2MAs4AAAMAAAAi2g");
	var mask_1_graphics_90 = new cjs.Graphics().p("A1ISTMAAAgh7MAsdAAAMAAAAh7g");
	var mask_1_graphics_91 = new cjs.Graphics().p("A0rSEMAAAgg8MAr+AAAMAAAAg8g");
	var mask_1_graphics_92 = new cjs.Graphics().p("A0LRzIAA/3MArdAAAIAAf3g");
	var mask_1_graphics_93 = new cjs.Graphics().p("AzpRgIAA+sMAq5AAAIAAesg");
	var mask_1_graphics_94 = new cjs.Graphics().p("AzFRMIAA9bMAqTAAAIAAdbg");
	var mask_1_graphics_95 = new cjs.Graphics().p("AygQ4IAA8KMApsAAAIAAcKg");
	var mask_1_graphics_96 = new cjs.Graphics().p("Ax+QmIAA7AMApIAAAIAAbAg");
	var mask_1_graphics_97 = new cjs.Graphics().p("AxfQVIAA57MAooAAAIAAZ7g");
	var mask_1_graphics_98 = new cjs.Graphics().p("AxCQFIAA47MAoJAAAIAAY7g");
	var mask_1_graphics_99 = new cjs.Graphics().p("AwoP3IAA4BMAnuAAAIAAYBg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AwQPqIAA3MMAnVAAAIAAXMg");
	var mask_1_graphics_101 = new cjs.Graphics().p("Av6PeIAA2dMAm9AAAIAAWdg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AvnPUIAA1zMAmpAAAIAAVzg");
	var mask_1_graphics_103 = new cjs.Graphics().p("AvXPLIAA1PMAmZAAAIAAVPg");
	var mask_1_graphics_104 = new cjs.Graphics().p("AvJPEIAA0xMAmKAAAIAAUxg");
	var mask_1_graphics_105 = new cjs.Graphics().p("Au+O9IAA0XMAl+AAAIAAUXg");
	var mask_1_graphics_106 = new cjs.Graphics().p("Au1O5IAA0FMAl1AAAIAAUFg");
	var mask_1_graphics_107 = new cjs.Graphics().p("AuvO1IAAz2MAlvAAAIAAT2g");
	var mask_1_graphics_108 = new cjs.Graphics().p("AurOzIAAzuMAlqAAAIAATug");
	var mask_1_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_1_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:149.8293,y:125.4028}).wait(79).to({graphics:mask_1_graphics_79,x:149.8293,y:125.4028}).wait(1).to({graphics:mask_1_graphics_80,x:149.8825,y:125.3344}).wait(1).to({graphics:mask_1_graphics_81,x:150.0283,y:125.1294}).wait(1).to({graphics:mask_1_graphics_82,x:149.9958,y:124.7877}).wait(1).to({graphics:mask_1_graphics_83,x:149.9502,y:124.3094}).wait(1).to({graphics:mask_1_graphics_84,x:149.8917,y:123.6944}).wait(1).to({graphics:mask_1_graphics_85,x:149.8201,y:122.9426}).wait(1).to({graphics:mask_1_graphics_86,x:149.7356,y:122.0543}).wait(1).to({graphics:mask_1_graphics_87,x:149.638,y:121.0292}).wait(1).to({graphics:mask_1_graphics_88,x:149.5274,y:119.8675}).wait(1).to({graphics:mask_1_graphics_89,x:149.4038,y:118.569}).wait(1).to({graphics:mask_1_graphics_90,x:149.2672,y:117.134}).wait(1).to({graphics:mask_1_graphics_91,x:149.1175,y:115.5622}).wait(1).to({graphics:mask_1_graphics_92,x:148.9549,y:113.8538}).wait(1).to({graphics:mask_1_graphics_93,x:148.7792,y:112.0087}).wait(1).to({graphics:mask_1_graphics_94,x:148.5906,y:110.0269}).wait(1).to({graphics:mask_1_graphics_95,x:148.4019,y:108.0451}).wait(1).to({graphics:mask_1_graphics_96,x:148.2263,y:106.2}).wait(1).to({graphics:mask_1_graphics_97,x:148.0636,y:104.4915}).wait(1).to({graphics:mask_1_graphics_98,x:147.914,y:102.9198}).wait(1).to({graphics:mask_1_graphics_99,x:147.7774,y:101.4847}).wait(1).to({graphics:mask_1_graphics_100,x:147.6538,y:100.1863}).wait(1).to({graphics:mask_1_graphics_101,x:147.5432,y:99.0246}).wait(1).to({graphics:mask_1_graphics_102,x:147.4456,y:97.9995}).wait(1).to({graphics:mask_1_graphics_103,x:147.361,y:97.1111}).wait(1).to({graphics:mask_1_graphics_104,x:147.2895,y:96.3594}).wait(1).to({graphics:mask_1_graphics_105,x:147.2309,y:95.7444}).wait(1).to({graphics:mask_1_graphics_106,x:147.1854,y:95.266}).wait(1).to({graphics:mask_1_graphics_107,x:147.1529,y:94.9243}).wait(1).to({graphics:mask_1_graphics_108,x:147.1333,y:94.7193}).wait(1).to({graphics:mask_1_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_1_graphics_135,x:147.1518,y:94.651}).wait(41));

	// LeafB
	this.instance_1 = new lib.leafB();
	this.instance_1.setTransform(247.1,52.55,1,1,0,0,0,55,54.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79).to({regX:55.1,regY:54.6,scaleX:0.6995,scaleY:0.6995,x:255.85,y:101.15},30,cjs.Ease.quadInOut).wait(67));

	// ScreenMaskA copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_2_graphics_79 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_2_graphics_80 = new cjs.Graphics().p("A3dTlMAAAgnIMAu7AAAMAAAAnIg");
	var mask_2_graphics_81 = new cjs.Graphics().p("A3bTjMAAAgnAMAu3AAAMAAAAnAg");
	var mask_2_graphics_82 = new cjs.Graphics().p("A3VTgMAAAgmyMAuxAAAMAAAAmyg");
	var mask_2_graphics_83 = new cjs.Graphics().p("A3MTbMAAAgmfMAuoAAAMAAAAmfg");
	var mask_2_graphics_84 = new cjs.Graphics().p("A3BTVMAAAgmGMAucAAAMAAAAmGg");
	var mask_2_graphics_85 = new cjs.Graphics().p("A2zTNMAAAglnMAuNAAAMAAAAlng");
	var mask_2_graphics_86 = new cjs.Graphics().p("A2iTFMAAAglEMAt7AAAMAAAAlEg");
	var mask_2_graphics_87 = new cjs.Graphics().p("A2QS6MAAAgkZMAtoAAAMAAAAkZg");
	var mask_2_graphics_88 = new cjs.Graphics().p("A16SvMAAAgjrMAtRAAAMAAAAjrg");
	var mask_2_graphics_89 = new cjs.Graphics().p("A1iSiMAAAgi2MAs4AAAMAAAAi2g");
	var mask_2_graphics_90 = new cjs.Graphics().p("A1ISTMAAAgh7MAsdAAAMAAAAh7g");
	var mask_2_graphics_91 = new cjs.Graphics().p("A0rSEMAAAgg8MAr+AAAMAAAAg8g");
	var mask_2_graphics_92 = new cjs.Graphics().p("A0LRzIAA/3MArdAAAIAAf3g");
	var mask_2_graphics_93 = new cjs.Graphics().p("AzpRgIAA+sMAq5AAAIAAesg");
	var mask_2_graphics_94 = new cjs.Graphics().p("AzFRMIAA9bMAqTAAAIAAdbg");
	var mask_2_graphics_95 = new cjs.Graphics().p("AygQ4IAA8KMApsAAAIAAcKg");
	var mask_2_graphics_96 = new cjs.Graphics().p("Ax+QmIAA7AMApIAAAIAAbAg");
	var mask_2_graphics_97 = new cjs.Graphics().p("AxfQVIAA57MAooAAAIAAZ7g");
	var mask_2_graphics_98 = new cjs.Graphics().p("AxCQFIAA47MAoJAAAIAAY7g");
	var mask_2_graphics_99 = new cjs.Graphics().p("AwoP3IAA4BMAnuAAAIAAYBg");
	var mask_2_graphics_100 = new cjs.Graphics().p("AwQPqIAA3MMAnVAAAIAAXMg");
	var mask_2_graphics_101 = new cjs.Graphics().p("Av6PeIAA2dMAm9AAAIAAWdg");
	var mask_2_graphics_102 = new cjs.Graphics().p("AvnPUIAA1zMAmpAAAIAAVzg");
	var mask_2_graphics_103 = new cjs.Graphics().p("AvXPLIAA1PMAmZAAAIAAVPg");
	var mask_2_graphics_104 = new cjs.Graphics().p("AvJPEIAA0xMAmKAAAIAAUxg");
	var mask_2_graphics_105 = new cjs.Graphics().p("Au+O9IAA0XMAl+AAAIAAUXg");
	var mask_2_graphics_106 = new cjs.Graphics().p("Au1O5IAA0FMAl1AAAIAAUFg");
	var mask_2_graphics_107 = new cjs.Graphics().p("AuvO1IAAz2MAlvAAAIAAT2g");
	var mask_2_graphics_108 = new cjs.Graphics().p("AurOzIAAzuMAlqAAAIAATug");
	var mask_2_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_2_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:149.8293,y:125.4028}).wait(79).to({graphics:mask_2_graphics_79,x:149.8293,y:125.4028}).wait(1).to({graphics:mask_2_graphics_80,x:149.8825,y:125.3344}).wait(1).to({graphics:mask_2_graphics_81,x:150.0283,y:125.1294}).wait(1).to({graphics:mask_2_graphics_82,x:149.9958,y:124.7877}).wait(1).to({graphics:mask_2_graphics_83,x:149.9502,y:124.3094}).wait(1).to({graphics:mask_2_graphics_84,x:149.8917,y:123.6944}).wait(1).to({graphics:mask_2_graphics_85,x:149.8201,y:122.9426}).wait(1).to({graphics:mask_2_graphics_86,x:149.7356,y:122.0543}).wait(1).to({graphics:mask_2_graphics_87,x:149.638,y:121.0292}).wait(1).to({graphics:mask_2_graphics_88,x:149.5274,y:119.8675}).wait(1).to({graphics:mask_2_graphics_89,x:149.4038,y:118.569}).wait(1).to({graphics:mask_2_graphics_90,x:149.2672,y:117.134}).wait(1).to({graphics:mask_2_graphics_91,x:149.1175,y:115.5622}).wait(1).to({graphics:mask_2_graphics_92,x:148.9549,y:113.8538}).wait(1).to({graphics:mask_2_graphics_93,x:148.7792,y:112.0087}).wait(1).to({graphics:mask_2_graphics_94,x:148.5906,y:110.0269}).wait(1).to({graphics:mask_2_graphics_95,x:148.4019,y:108.0451}).wait(1).to({graphics:mask_2_graphics_96,x:148.2263,y:106.2}).wait(1).to({graphics:mask_2_graphics_97,x:148.0636,y:104.4915}).wait(1).to({graphics:mask_2_graphics_98,x:147.914,y:102.9198}).wait(1).to({graphics:mask_2_graphics_99,x:147.7774,y:101.4847}).wait(1).to({graphics:mask_2_graphics_100,x:147.6538,y:100.1863}).wait(1).to({graphics:mask_2_graphics_101,x:147.5432,y:99.0246}).wait(1).to({graphics:mask_2_graphics_102,x:147.4456,y:97.9995}).wait(1).to({graphics:mask_2_graphics_103,x:147.361,y:97.1111}).wait(1).to({graphics:mask_2_graphics_104,x:147.2895,y:96.3594}).wait(1).to({graphics:mask_2_graphics_105,x:147.2309,y:95.7444}).wait(1).to({graphics:mask_2_graphics_106,x:147.1854,y:95.266}).wait(1).to({graphics:mask_2_graphics_107,x:147.1529,y:94.9243}).wait(1).to({graphics:mask_2_graphics_108,x:147.1333,y:94.7193}).wait(1).to({graphics:mask_2_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_2_graphics_135,x:147.1518,y:94.651}).wait(41));

	// Grass
	this.instance_2 = new lib.grass();
	this.instance_2.setTransform(150.15,188.7,1,1,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(79).to({regX:186.2,regY:63.1,scaleX:0.7513,scaleY:0.6595,x:163.55,y:150.1},30,cjs.Ease.quadInOut).wait(67));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(175.1,55.3,1.2782,1.2782,-2.4276,0,0,50.3,75.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:50.1,rotation:0,x:174.8,y:55,mode:"synched",loop:false},24,cjs.Ease.cubicInOut).to({y:58.1,startPosition:5},5,cjs.Ease.quadInOut).to({y:30.4,startPosition:21},16,cjs.Ease.quadInOut).to({regX:50.2,regY:75.3,rotation:-3.5207,x:174.9,y:36.25,startPosition:30},9,cjs.Ease.cubicIn).to({regY:75.4,rotation:-6.7393,y:36.45,mode:"single",startPosition:52},25,cjs.Ease.cubicOut).to({scaleX:0.7912,scaleY:0.7912,rotation:-6.5523,x:148.5,y:57.25,startPosition:54},30,cjs.Ease.quadInOut).wait(15).to({startPosition:54},0).to({regX:50.3,rotation:-9.4874,x:148.6,y:60.3,mode:"synched",startPosition:59,loop:false},9,cjs.Ease.quadInOut).to({rotation:2.8731,y:51.4,startPosition:73},14,cjs.Ease.quadInOut).to({regX:50.1,rotation:-4.575,x:148.45,y:57.3,startPosition:97},17,cjs.Ease.quadInOut).wait(12));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(177.05,224.65,1.1792,1.1792,0,0,0,58,159.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({y:225.4},5,cjs.Ease.quadInOut).to({regY:159.7,scaleY:1.2169,y:223.3},12,cjs.Ease.quadInOut).to({regY:159.6,scaleY:1.1792,y:224.65},16,cjs.Ease.quadInOut).wait(22).to({scaleX:0.7303,scaleY:0.7303,x:149.85,y:171.75},30,cjs.Ease.quadInOut).wait(15).to({regY:159.7,scaleY:0.7053,y:171.85},9,cjs.Ease.quadInOut).to({scaleY:0.7554,y:171.8},14,cjs.Ease.quadInOut).to({regY:159.6,scaleY:0.7303,y:171.75},17,cjs.Ease.quadInOut).wait(12));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_3_graphics_79 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_3_graphics_80 = new cjs.Graphics().p("A3dTlMAAAgnIMAu7AAAMAAAAnIg");
	var mask_3_graphics_81 = new cjs.Graphics().p("A3bTjMAAAgnAMAu3AAAMAAAAnAg");
	var mask_3_graphics_82 = new cjs.Graphics().p("A3VTgMAAAgmyMAuxAAAMAAAAmyg");
	var mask_3_graphics_83 = new cjs.Graphics().p("A3MTbMAAAgmfMAuoAAAMAAAAmfg");
	var mask_3_graphics_84 = new cjs.Graphics().p("A3BTVMAAAgmGMAucAAAMAAAAmGg");
	var mask_3_graphics_85 = new cjs.Graphics().p("A2zTNMAAAglnMAuNAAAMAAAAlng");
	var mask_3_graphics_86 = new cjs.Graphics().p("A2iTFMAAAglEMAt7AAAMAAAAlEg");
	var mask_3_graphics_87 = new cjs.Graphics().p("A2QS6MAAAgkZMAtoAAAMAAAAkZg");
	var mask_3_graphics_88 = new cjs.Graphics().p("A16SvMAAAgjrMAtRAAAMAAAAjrg");
	var mask_3_graphics_89 = new cjs.Graphics().p("A1iSiMAAAgi2MAs4AAAMAAAAi2g");
	var mask_3_graphics_90 = new cjs.Graphics().p("A1ISTMAAAgh7MAsdAAAMAAAAh7g");
	var mask_3_graphics_91 = new cjs.Graphics().p("A0rSEMAAAgg8MAr+AAAMAAAAg8g");
	var mask_3_graphics_92 = new cjs.Graphics().p("A0LRzIAA/3MArdAAAIAAf3g");
	var mask_3_graphics_93 = new cjs.Graphics().p("AzpRgIAA+sMAq5AAAIAAesg");
	var mask_3_graphics_94 = new cjs.Graphics().p("AzFRMIAA9bMAqTAAAIAAdbg");
	var mask_3_graphics_95 = new cjs.Graphics().p("AygQ4IAA8KMApsAAAIAAcKg");
	var mask_3_graphics_96 = new cjs.Graphics().p("Ax+QmIAA7AMApIAAAIAAbAg");
	var mask_3_graphics_97 = new cjs.Graphics().p("AxfQVIAA57MAooAAAIAAZ7g");
	var mask_3_graphics_98 = new cjs.Graphics().p("AxCQFIAA47MAoJAAAIAAY7g");
	var mask_3_graphics_99 = new cjs.Graphics().p("AwoP3IAA4BMAnuAAAIAAYBg");
	var mask_3_graphics_100 = new cjs.Graphics().p("AwQPqIAA3MMAnVAAAIAAXMg");
	var mask_3_graphics_101 = new cjs.Graphics().p("Av6PeIAA2dMAm9AAAIAAWdg");
	var mask_3_graphics_102 = new cjs.Graphics().p("AvnPUIAA1zMAmpAAAIAAVzg");
	var mask_3_graphics_103 = new cjs.Graphics().p("AvXPLIAA1PMAmZAAAIAAVPg");
	var mask_3_graphics_104 = new cjs.Graphics().p("AvJPEIAA0xMAmKAAAIAAUxg");
	var mask_3_graphics_105 = new cjs.Graphics().p("Au+O9IAA0XMAl+AAAIAAUXg");
	var mask_3_graphics_106 = new cjs.Graphics().p("Au1O5IAA0FMAl1AAAIAAUFg");
	var mask_3_graphics_107 = new cjs.Graphics().p("AuvO1IAAz2MAlvAAAIAAT2g");
	var mask_3_graphics_108 = new cjs.Graphics().p("AurOzIAAzuMAlqAAAIAATug");
	var mask_3_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_3_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:149.8293,y:125.4028}).wait(79).to({graphics:mask_3_graphics_79,x:149.8293,y:125.4028}).wait(1).to({graphics:mask_3_graphics_80,x:149.8825,y:125.3344}).wait(1).to({graphics:mask_3_graphics_81,x:150.0283,y:125.1294}).wait(1).to({graphics:mask_3_graphics_82,x:149.9958,y:124.7877}).wait(1).to({graphics:mask_3_graphics_83,x:149.9502,y:124.3094}).wait(1).to({graphics:mask_3_graphics_84,x:149.8917,y:123.6944}).wait(1).to({graphics:mask_3_graphics_85,x:149.8201,y:122.9426}).wait(1).to({graphics:mask_3_graphics_86,x:149.7356,y:122.0543}).wait(1).to({graphics:mask_3_graphics_87,x:149.638,y:121.0292}).wait(1).to({graphics:mask_3_graphics_88,x:149.5274,y:119.8675}).wait(1).to({graphics:mask_3_graphics_89,x:149.4038,y:118.569}).wait(1).to({graphics:mask_3_graphics_90,x:149.2672,y:117.134}).wait(1).to({graphics:mask_3_graphics_91,x:149.1175,y:115.5622}).wait(1).to({graphics:mask_3_graphics_92,x:148.9549,y:113.8538}).wait(1).to({graphics:mask_3_graphics_93,x:148.7792,y:112.0087}).wait(1).to({graphics:mask_3_graphics_94,x:148.5906,y:110.0269}).wait(1).to({graphics:mask_3_graphics_95,x:148.4019,y:108.0451}).wait(1).to({graphics:mask_3_graphics_96,x:148.2263,y:106.2}).wait(1).to({graphics:mask_3_graphics_97,x:148.0636,y:104.4915}).wait(1).to({graphics:mask_3_graphics_98,x:147.914,y:102.9198}).wait(1).to({graphics:mask_3_graphics_99,x:147.7774,y:101.4847}).wait(1).to({graphics:mask_3_graphics_100,x:147.6538,y:100.1863}).wait(1).to({graphics:mask_3_graphics_101,x:147.5432,y:99.0246}).wait(1).to({graphics:mask_3_graphics_102,x:147.4456,y:97.9995}).wait(1).to({graphics:mask_3_graphics_103,x:147.361,y:97.1111}).wait(1).to({graphics:mask_3_graphics_104,x:147.2895,y:96.3594}).wait(1).to({graphics:mask_3_graphics_105,x:147.2309,y:95.7444}).wait(1).to({graphics:mask_3_graphics_106,x:147.1854,y:95.266}).wait(1).to({graphics:mask_3_graphics_107,x:147.1529,y:94.9243}).wait(1).to({graphics:mask_3_graphics_108,x:147.1333,y:94.7193}).wait(1).to({graphics:mask_3_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_3_graphics_135,x:147.1518,y:94.651}).wait(41));

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(150.2,155.45,1,1,0,0,0,155.4,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(79).to({regX:155.3,scaleX:0.8242,scaleY:0.8242,x:167.9,y:158.75},30,cjs.Ease.quadInOut).wait(67));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_4_graphics_79 = new cjs.Graphics().p("A3eTmMAAAgnLMAu9AAAMAAAAnLg");
	var mask_4_graphics_80 = new cjs.Graphics().p("A3dTlMAAAgnIMAu7AAAMAAAAnIg");
	var mask_4_graphics_81 = new cjs.Graphics().p("A3bTjMAAAgnAMAu3AAAMAAAAnAg");
	var mask_4_graphics_82 = new cjs.Graphics().p("A3VTgMAAAgmyMAuxAAAMAAAAmyg");
	var mask_4_graphics_83 = new cjs.Graphics().p("A3MTbMAAAgmfMAuoAAAMAAAAmfg");
	var mask_4_graphics_84 = new cjs.Graphics().p("A3BTVMAAAgmGMAucAAAMAAAAmGg");
	var mask_4_graphics_85 = new cjs.Graphics().p("A2zTNMAAAglnMAuNAAAMAAAAlng");
	var mask_4_graphics_86 = new cjs.Graphics().p("A2iTFMAAAglEMAt7AAAMAAAAlEg");
	var mask_4_graphics_87 = new cjs.Graphics().p("A2QS6MAAAgkZMAtoAAAMAAAAkZg");
	var mask_4_graphics_88 = new cjs.Graphics().p("A16SvMAAAgjrMAtRAAAMAAAAjrg");
	var mask_4_graphics_89 = new cjs.Graphics().p("A1iSiMAAAgi2MAs4AAAMAAAAi2g");
	var mask_4_graphics_90 = new cjs.Graphics().p("A1ISTMAAAgh7MAsdAAAMAAAAh7g");
	var mask_4_graphics_91 = new cjs.Graphics().p("A0rSEMAAAgg8MAr+AAAMAAAAg8g");
	var mask_4_graphics_92 = new cjs.Graphics().p("A0LRzIAA/3MArdAAAIAAf3g");
	var mask_4_graphics_93 = new cjs.Graphics().p("AzpRgIAA+sMAq5AAAIAAesg");
	var mask_4_graphics_94 = new cjs.Graphics().p("AzFRMIAA9bMAqTAAAIAAdbg");
	var mask_4_graphics_95 = new cjs.Graphics().p("AygQ4IAA8KMApsAAAIAAcKg");
	var mask_4_graphics_96 = new cjs.Graphics().p("Ax+QmIAA7AMApIAAAIAAbAg");
	var mask_4_graphics_97 = new cjs.Graphics().p("AxfQVIAA57MAooAAAIAAZ7g");
	var mask_4_graphics_98 = new cjs.Graphics().p("AxCQFIAA47MAoJAAAIAAY7g");
	var mask_4_graphics_99 = new cjs.Graphics().p("AwoP3IAA4BMAnuAAAIAAYBg");
	var mask_4_graphics_100 = new cjs.Graphics().p("AwQPqIAA3MMAnVAAAIAAXMg");
	var mask_4_graphics_101 = new cjs.Graphics().p("Av6PeIAA2dMAm9AAAIAAWdg");
	var mask_4_graphics_102 = new cjs.Graphics().p("AvnPUIAA1zMAmpAAAIAAVzg");
	var mask_4_graphics_103 = new cjs.Graphics().p("AvXPLIAA1PMAmZAAAIAAVPg");
	var mask_4_graphics_104 = new cjs.Graphics().p("AvJPEIAA0xMAmKAAAIAAUxg");
	var mask_4_graphics_105 = new cjs.Graphics().p("Au+O9IAA0XMAl+AAAIAAUXg");
	var mask_4_graphics_106 = new cjs.Graphics().p("Au1O5IAA0FMAl1AAAIAAUFg");
	var mask_4_graphics_107 = new cjs.Graphics().p("AuvO1IAAz2MAlvAAAIAAT2g");
	var mask_4_graphics_108 = new cjs.Graphics().p("AurOzIAAzuMAlqAAAIAATug");
	var mask_4_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_4_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:149.8293,y:125.4028}).wait(79).to({graphics:mask_4_graphics_79,x:149.8293,y:125.4028}).wait(1).to({graphics:mask_4_graphics_80,x:149.8825,y:125.3344}).wait(1).to({graphics:mask_4_graphics_81,x:150.0283,y:125.1294}).wait(1).to({graphics:mask_4_graphics_82,x:149.9958,y:124.7877}).wait(1).to({graphics:mask_4_graphics_83,x:149.9502,y:124.3094}).wait(1).to({graphics:mask_4_graphics_84,x:149.8917,y:123.6944}).wait(1).to({graphics:mask_4_graphics_85,x:149.8201,y:122.9426}).wait(1).to({graphics:mask_4_graphics_86,x:149.7356,y:122.0543}).wait(1).to({graphics:mask_4_graphics_87,x:149.638,y:121.0292}).wait(1).to({graphics:mask_4_graphics_88,x:149.5274,y:119.8675}).wait(1).to({graphics:mask_4_graphics_89,x:149.4038,y:118.569}).wait(1).to({graphics:mask_4_graphics_90,x:149.2672,y:117.134}).wait(1).to({graphics:mask_4_graphics_91,x:149.1175,y:115.5622}).wait(1).to({graphics:mask_4_graphics_92,x:148.9549,y:113.8538}).wait(1).to({graphics:mask_4_graphics_93,x:148.7792,y:112.0087}).wait(1).to({graphics:mask_4_graphics_94,x:148.5906,y:110.0269}).wait(1).to({graphics:mask_4_graphics_95,x:148.4019,y:108.0451}).wait(1).to({graphics:mask_4_graphics_96,x:148.2263,y:106.2}).wait(1).to({graphics:mask_4_graphics_97,x:148.0636,y:104.4915}).wait(1).to({graphics:mask_4_graphics_98,x:147.914,y:102.9198}).wait(1).to({graphics:mask_4_graphics_99,x:147.7774,y:101.4847}).wait(1).to({graphics:mask_4_graphics_100,x:147.6538,y:100.1863}).wait(1).to({graphics:mask_4_graphics_101,x:147.5432,y:99.0246}).wait(1).to({graphics:mask_4_graphics_102,x:147.4456,y:97.9995}).wait(1).to({graphics:mask_4_graphics_103,x:147.361,y:97.1111}).wait(1).to({graphics:mask_4_graphics_104,x:147.2895,y:96.3594}).wait(1).to({graphics:mask_4_graphics_105,x:147.2309,y:95.7444}).wait(1).to({graphics:mask_4_graphics_106,x:147.1854,y:95.266}).wait(1).to({graphics:mask_4_graphics_107,x:147.1529,y:94.9243}).wait(1).to({graphics:mask_4_graphics_108,x:147.1333,y:94.7193}).wait(1).to({graphics:mask_4_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_4_graphics_135,x:147.1518,y:94.651}).wait(41));

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(159.05,57.45,1,1,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(79).to({scaleX:0.7852,scaleY:0.7852,x:166.1,y:87.6},30,cjs.Ease.quadInOut).wait(67));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(0,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(176));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-11.8,300.5,262.6);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_88 = function() {
		exportRoot.tlLogo.to(exportRoot.mainMC.logo_intro.msoftLogoWhite, 0.3, { alpha: 0}, "-=0");
	}
	this.frame_120 = function() {
		exportRoot.tl1.play();
	}
	this.frame_187 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(88).call(this.frame_88).wait(32).call(this.frame_120).wait(67).call(this.frame_187).wait(1));

	// Icon
	this.instance = new lib.Icon_1();
	this.instance.setTransform(94.6,130.4,0.9671,0.9671,0,0,0,50.1,50.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(110).to({_off:false},0).to({scaleX:0.74,scaleY:0.74,x:104.65,y:148.5,alpha:1},15,cjs.Ease.quartOut).wait(63));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(58.6,14.8,1,1,0,0,0,58.6,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regY:15.2,scaleX:0.7011,scaleY:0.6497,skewX:-29.3007,skewY:-16.7971,x:132.65,y:126.65,startPosition:109},30,cjs.Ease.quadInOut).wait(69));

	// Shadow
	this.instance_2 = new lib.shadow();
	this.instance_2.setTransform(198.45,161.7,1,1,0,0,0,176.7,127.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105).to({_off:false},0).to({x:233.35,y:141.65,alpha:1},14,cjs.Ease.quadOut).wait(69));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.8,-11.8,451.40000000000003,312.1);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-30.35,2.5,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Am6B5IAAjyIN1AAIAADyg");
	this.shape.setTransform(-59.375,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-10.1,88.7,24.299999999999997), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(46.05,220.4,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(117.2,217.5,1.1404,1.1404,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(197.1,130.8,1,1,0,0,0,197.1,130.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(284.3,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Ribbon
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-17.55,-5.2);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-24,-24.7,355.3,279.1), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"


		this.initBanner = function (data) {

			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;

			Object.keys = function(obj) {
				var keys = [];

				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)

				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}


		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}



		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}


		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		var ribbon = mc.ribbon;



		this.runBanner = function() {

			this.tlLogo = new TimelineLite();
			this.tl1 = new TimelineLite();

				exportRoot.tl1.from(screen, 0.5, { alpha: 1, ease:Power3.easeOut,onStart: function() {;screen.gotoAndPlay(1)}, onComplete: function() {exportRoot.tl1.pause()}}, "+=0.5");


				exportRoot.tl1.to(screen, 0.3, { alpha: 1, ease:Power3.easeInOut,onComplete:function(){ribbon.gotoAndPlay(0);}}, "-=0");


				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.3");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}

				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}


				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "-=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");

				exportRoot.tl1.stop();

			mc.logo_intro.gotoAndPlay(1)

		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(126,100.3,205.3,154.10000000000002);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593009069237", id:"M365_FY21Q1_BTS_USA_300x250_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
	var lastW, lastH, lastS=1;
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas();
	function resizeCanvas() {
		var w = lib.properties.width, h = lib.properties.height;
		var iw = window.innerWidth, ih=window.innerHeight;
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
		if(isResp) {
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
				sRatio = lastS;
			}
			else if(!isScale) {
				if(iw<w || ih<h)
					sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==1) {
				sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==2) {
				sRatio = Math.max(xRatio, yRatio);
			}
		}
		domContainers[0].width = w * pRatio * sRatio;
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {
			container.style.width = w * sRatio + 'px';
			container.style.height = h * sRatio + 'px';
		});
		stage.scaleX = pRatio*sRatio;
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;
		stage.tickOnUpdate = false;
		stage.update();
		stage.tickOnUpdate = true;
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
