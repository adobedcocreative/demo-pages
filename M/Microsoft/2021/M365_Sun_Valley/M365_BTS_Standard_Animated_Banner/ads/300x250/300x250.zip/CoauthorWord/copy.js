// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#505050>Work in real time, together","15.3px",15,44 ,"20","350", "left"];

	bannerData.headline2 = ["<#505050>Coauthor documents and communicate in real |time across your favorite apps, plus 1 TB of |OneDrive cloud storage","10.2px",15,68,"12.2","350", "left"];


	bannerData.CTA = ["<#FFFFFF>BUY NOW","12px",-2,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
