(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1", frames: [[0,0,604,384],[606,235,268,215],[634,452,168,106],[284,386,177,130],[560,623,102,86],[804,558,156,76],[107,579,104,86],[463,386,122,39],[664,623,104,82],[804,452,151,104],[0,579,105,86],[876,345,112,90],[606,0,350,233],[463,452,169,106],[0,386,282,191],[284,518,120,111],[406,560,152,63],[560,560,152,61],[876,235,138,108]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.basicUI1111 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.girllefticon = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticon = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.guylefticon = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontribution = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.secondimage = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.titleshadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.tile_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.text03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,0,88.5,65), null);


(lib.text01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.secondimage_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.secondimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage_1, new cjs.Rectangle(0,0,84.5,53), null);


(lib.screenBG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.basicUI1111();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(0,0,302,192), null);


(lib.screenshadowpicture = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.screenshadow();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.roundshadowshape = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.roundshadow1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45), null);


(lib.Outlook_shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.image01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(0,0,75.5,52), null);


(lib.firstimage_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(0,0,84,53), null);


(lib.fill = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girlrighticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.girllefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(0,0,51,43), null);


(lib.face02 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guylefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52,41), null);


(lib.face01 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.guyrighticon1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,0,52.5,43), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.boxshadowpicture = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150.0023,124.9924,1,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.WordUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(0,0,302,192), null);


(lib.squareshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-31.6,-11.15,416.5,277.25,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(176.6,127.45,1,1,0,0,0,208.2,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-31.6,-11.1,416.5,277.20000000000005), null);


(lib.roundshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0,56,45), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(10));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(83));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(83));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.4,scaleX:2.408,scaleY:2.408,x:-12,y:7.9},41,cjs.Ease.quadInOut).to({_off:true},1).wait(9));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,340.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-68.3,982,817.0999999999999);


(lib.iconcache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(14,0,1.6738,1.6738);

	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(127.4,117.7,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconcache, new cjs.Rectangle(0,0,254.6,219.9), null);


(lib.icon_teams = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.guyrighticon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,0,52.5,43), null);


(lib.guyrightcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution_1, new cjs.Rectangle(0,0,75.5,52), null);


(lib.guylefticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon_1, new cjs.Rectangle(0,0,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.girlrigthcontribution = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon_1, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon_1, new cjs.Rectangle(0,0,51,43), null);


(lib.girlleftcontribution_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution_1, new cjs.Rectangle(0,0,88.5,65), null);


(lib.BG_gray = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.WordIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.icon.cache(-260,-230,520,460,0.8);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.icon = new lib.iconcache();
	this.icon.name = "icon";
	this.icon.setTransform(225.3,236.4,1,1,0,0,0,127.3,109.9);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(98,126.5,254.60000000000002,219.89999999999998), null);


(lib.logo_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.screenanimation = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_157 = function() {
		exportRoot.tl1.play();
	}
	this.frame_218 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(157).call(this.frame_157).wait(61).call(this.frame_218).wait(1));

	// guy right icon.png
	this.instance = new lib.guyrighticon();
	this.instance.setTransform(222.3,-24.35,1,1,0,0,0,26.4,21.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({x:195.35,y:60.7,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:26.2,x:195.15},0).wait(11).to({regX:26.4,x:195.35},0).wait(1).to({regX:26.2,scaleX:0.9984,scaleY:0.9984,x:195.7,y:60.9},0).wait(1).to({scaleX:0.9966,scaleY:0.9966,x:196.3,y:61.25},0).wait(1).to({scaleX:0.9946,scaleY:0.9946,x:196.95,y:61.5},0).wait(1).to({scaleX:0.9925,scaleY:0.9925,x:197.65,y:61.85},0).wait(1).to({scaleX:0.9902,scaleY:0.9902,x:198.45,y:62.2},0).wait(1).to({scaleX:0.9878,scaleY:0.9878,x:199.25,y:62.55},0).wait(1).to({scaleX:0.9852,scaleY:0.9852,x:200.1,y:62.95},0).wait(1).to({scaleX:0.9825,scaleY:0.9825,x:201.05,y:63.35},0).wait(1).to({scaleX:0.9796,scaleY:0.9796,x:202,y:63.8},0).wait(1).to({scaleX:0.9766,scaleY:0.9766,x:203.05,y:64.25},0).wait(1).to({scaleX:0.9735,scaleY:0.9735,x:204.1,y:64.75},0).wait(1).to({scaleX:0.9701,scaleY:0.9701,x:205.2,y:65.25},0).wait(1).to({scaleX:0.9667,scaleY:0.9667,x:206.4,y:65.8},0).wait(1).to({scaleX:0.9631,scaleY:0.9631,x:207.6,y:66.3},0).wait(1).to({scaleX:0.9594,scaleY:0.9594,x:208.85,y:66.9},0).wait(1).to({scaleX:0.9556,scaleY:0.9556,x:210.15,y:67.45},0).wait(1).to({scaleX:0.9517,scaleY:0.9517,x:211.45,y:68.05},0).wait(1).to({scaleX:0.9477,scaleY:0.9477,x:212.85,y:68.7},0).wait(1).to({scaleX:0.9436,scaleY:0.9436,x:214.15,y:69.3},0).wait(1).to({scaleX:0.9395,scaleY:0.9395,x:215.6,y:69.95},0).wait(1).to({scaleX:0.9353,scaleY:0.9353,x:217,y:70.55},0).wait(1).to({scaleX:0.931,scaleY:0.931,x:218.45,y:71.2},0).wait(1).to({scaleX:0.9267,scaleY:0.9267,x:219.9,y:71.85},0).wait(1).to({scaleX:0.9225,scaleY:0.9225,x:221.35,y:72.55},0).wait(1).to({scaleX:0.9182,scaleY:0.9182,x:222.8,y:73.2},0).wait(1).to({scaleX:0.9139,scaleY:0.9139,x:224.25,y:73.85},0).wait(1).to({scaleX:0.9097,scaleY:0.9097,x:225.7,y:74.5},0).wait(1).to({scaleX:0.9055,scaleY:0.9055,x:227.05,y:75.1},0).wait(1).to({scaleX:0.9014,scaleY:0.9014,x:228.45,y:75.8},0).wait(1).to({scaleX:0.8973,scaleY:0.8973,x:229.85,y:76.4},0).wait(1).to({scaleX:0.8934,scaleY:0.8934,x:231.15,y:76.95},0).wait(1).to({scaleX:0.8895,scaleY:0.8895,x:232.5,y:77.55},0).wait(1).to({scaleX:0.8857,scaleY:0.8857,x:233.75,y:78.15},0).wait(1).to({scaleX:0.8821,scaleY:0.8821,x:235,y:78.7},0).wait(1).to({scaleX:0.8786,scaleY:0.8786,x:236.15,y:79.25},0).wait(1).to({scaleX:0.8752,scaleY:0.8752,x:237.35,y:79.75},0).wait(1).to({scaleX:0.8719,scaleY:0.8719,x:238.4,y:80.25},0).wait(1).to({scaleX:0.8688,scaleY:0.8688,x:239.45,y:80.75},0).wait(1).to({scaleX:0.8659,scaleY:0.8659,x:240.5,y:81.15},0).wait(1).to({scaleX:0.8631,scaleY:0.8631,x:241.4,y:81.6},0).wait(1).to({scaleX:0.8604,scaleY:0.8604,x:242.3,y:82},0).wait(1).to({scaleX:0.8579,scaleY:0.8579,x:243.15,y:82.4},0).wait(1).to({scaleX:0.8556,scaleY:0.8556,x:243.95,y:82.75},0).wait(1).to({scaleX:0.8534,scaleY:0.8534,x:244.65,y:83.1},0).wait(1).to({scaleX:0.8514,scaleY:0.8514,x:245.35,y:83.4},0).wait(1).to({scaleX:0.8495,scaleY:0.8495,x:246,y:83.65},0).wait(1).to({scaleX:0.8478,scaleY:0.8478,x:246.55,y:83.95},0).wait(1).to({scaleX:0.8462,scaleY:0.8462,x:247.1,y:84.2},0).wait(1).to({scaleX:0.8448,scaleY:0.8448,x:247.6,y:84.4},0).wait(1).to({scaleX:0.8435,scaleY:0.8435,x:248,y:84.6},0).wait(1).to({scaleX:0.8424,scaleY:0.8424,x:248.4,y:84.75},0).wait(1).to({scaleX:0.8414,scaleY:0.8414,x:248.75,y:84.95},0).wait(1).to({scaleX:0.8406,scaleY:0.8406,x:249,y:85},0).wait(1).to({scaleX:0.8399,scaleY:0.8399,x:249.25,y:85.15},0).wait(1).to({scaleX:0.8393,scaleY:0.8393,x:249.45,y:85.25},0).wait(1).to({scaleX:0.8389,scaleY:0.8389,x:249.6,y:85.3},0).wait(1).to({scaleX:0.8386,scaleY:0.8386,x:249.7,y:85.35},0).wait(1).to({scaleX:0.8384,scaleY:0.8384,x:249.75,y:85.4},0).wait(1).to({regX:26.4,regY:21.6,scaleX:0.8383,scaleY:0.8383,x:249.95,y:85.45},0).wait(1).to({regX:26.2,regY:21.5,x:249.75,y:85.35},0).wait(15).to({regX:26.4,regY:21.6,x:249.95,y:85.45},0).wait(1).to({regX:26.2,regY:21.5,scaleX:0.8382,scaleY:0.8382,x:249.75,y:85.3},0).wait(1).to({scaleX:0.838,scaleY:0.838},0).wait(1).to({scaleX:0.8377,scaleY:0.8377,y:85.25},0).wait(1).to({scaleX:0.8373,scaleY:0.8373,x:249.8},0).wait(1).to({scaleX:0.8367,scaleY:0.8367,x:249.75,y:85.2},0).wait(1).to({scaleX:0.8361,scaleY:0.8361,x:249.8,y:85.15},0).wait(1).to({scaleX:0.8353,scaleY:0.8353,x:249.85,y:85.05},0).wait(1).to({scaleX:0.8344,scaleY:0.8344,y:84.95},0).wait(1).to({scaleX:0.8334,scaleY:0.8334,x:249.95,y:84.8},0).wait(1).to({scaleX:0.8321,scaleY:0.8321,y:84.7},0).wait(1).to({scaleX:0.8307,scaleY:0.8307,x:250,y:84.55},0).wait(1).to({scaleX:0.8291,scaleY:0.8291,x:250.05,y:84.45},0).wait(1).to({scaleX:0.8273,scaleY:0.8273,x:250.15,y:84.25},0).wait(1).to({scaleX:0.8252,scaleY:0.8252,x:250.2,y:84},0).wait(1).to({scaleX:0.8229,scaleY:0.8229,x:250.3,y:83.75},0).wait(1).to({scaleX:0.8203,scaleY:0.8203,x:250.4,y:83.5},0).wait(1).to({scaleX:0.8173,scaleY:0.8173,x:250.5,y:83.15},0).wait(1).to({scaleX:0.8139,scaleY:0.8139,x:250.6,y:82.85},0).wait(1).to({scaleX:0.81,scaleY:0.81,x:250.75,y:82.4},0).wait(1).to({scaleX:0.8055,scaleY:0.8055,x:250.9,y:81.95},0).wait(1).to({scaleX:0.8004,scaleY:0.8004,x:251.05,y:81.45},0).wait(1).to({scaleX:0.7945,scaleY:0.7945,x:251.3,y:80.85},0).wait(1).to({scaleX:0.7876,scaleY:0.7876,x:251.55,y:80.15},0).wait(1).to({scaleX:0.7793,scaleY:0.7793,x:251.8,y:79.25},0).wait(1).to({scaleX:0.7695,scaleY:0.7695,x:252.2,y:78.25},0).wait(1).to({scaleX:0.7573,scaleY:0.7573,x:252.6,y:77.05},0).wait(1).to({scaleX:0.7423,scaleY:0.7423,x:253.15,y:75.45},0).wait(1).to({scaleX:0.7238,scaleY:0.7238,x:253.8,y:73.55},0).wait(1).to({scaleX:0.7024,scaleY:0.7024,x:254.55,y:71.35},0).wait(1).to({scaleX:0.6809,scaleY:0.6809,x:255.35,y:69.15},0).wait(1).to({scaleX:0.6621,scaleY:0.6621,x:256,y:67.2},0).wait(1).to({scaleX:0.6467,scaleY:0.6467,x:256.55,y:65.6},0).wait(1).to({scaleX:0.6342,scaleY:0.6342,x:257,y:64.35},0).wait(1).to({scaleX:0.6239,scaleY:0.6239,x:257.35,y:63.25},0).wait(1).to({scaleX:0.6153,scaleY:0.6153,x:257.65,y:62.4},0).wait(1).to({scaleX:0.608,scaleY:0.608,x:257.95,y:61.6},0).wait(1).to({scaleX:0.6018,scaleY:0.6018,x:258.15,y:61},0).wait(1).to({scaleX:0.5963,scaleY:0.5963,x:258.3,y:60.4},0).wait(1).to({scaleX:0.5916,scaleY:0.5916,x:258.5,y:59.9},0).wait(1).to({scaleX:0.5874,scaleY:0.5874,x:258.65,y:59.5},0).wait(1).to({scaleX:0.5836,scaleY:0.5836,x:258.8,y:59.1},0).wait(1).to({scaleX:0.5803,scaleY:0.5803,x:258.9,y:58.8},0).wait(1).to({scaleX:0.5774,scaleY:0.5774,x:259.05,y:58.45},0).wait(1).to({scaleX:0.5748,scaleY:0.5748,x:259.1,y:58.2},0).wait(1).to({scaleX:0.5724,scaleY:0.5724,x:259.2,y:57.95},0).wait(1).to({scaleX:0.5703,scaleY:0.5703,x:259.25,y:57.75},0).wait(1).to({scaleX:0.5685,scaleY:0.5685,x:259.35,y:57.55},0).wait(1).to({scaleX:0.5668,scaleY:0.5668,x:259.4,y:57.4},0).wait(1).to({scaleX:0.5653,scaleY:0.5653,y:57.25},0).wait(1).to({scaleX:0.564,scaleY:0.564,x:259.5,y:57.1},0).wait(1).to({scaleX:0.5629,scaleY:0.5629,x:259.55,y:57},0).wait(1).to({scaleX:0.5618,scaleY:0.5618,y:56.9},0).wait(1).to({scaleX:0.561,scaleY:0.561,x:259.6,y:56.75},0).wait(1).to({scaleX:0.5602,scaleY:0.5602,x:259.65,y:56.7},0).wait(1).to({scaleX:0.5595,scaleY:0.5595,y:56.65},0).wait(1).to({scaleX:0.559,scaleY:0.559,y:56.55},0).wait(1).to({scaleX:0.5585,scaleY:0.5585,x:259.7,y:56.5},0).wait(1).to({scaleX:0.5582,scaleY:0.5582,x:259.65},0).wait(1).to({scaleX:0.5579,scaleY:0.5579,x:259.7,y:56.45},0).wait(1).to({scaleX:0.5577,scaleY:0.5577},0).wait(1).to({scaleX:0.5576,scaleY:0.5576},0).wait(1).to({regX:26.4,x:259.8,y:56.5},0).wait(1));

	// guy left icon.png
	this.instance_1 = new lib.guylefticon_1();
	this.instance_1.setTransform(-84.7,115.9,1,1,0,0,0,25.9,20.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({x:70.4,y:78.2,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:26,regY:20.5,x:70.5,y:78.3},0).wait(12).to({regX:25.9,regY:20.4,x:70.4,y:78.2},0).wait(1).to({regX:26,regY:20.5,scaleX:0.9962,scaleY:0.9962,x:72,y:78.6},0).wait(1).to({scaleX:0.992,scaleY:0.992,x:73.75,y:79.05},0).wait(1).to({scaleX:0.9875,scaleY:0.9875,x:75.55,y:79.5},0).wait(1).to({scaleX:0.9826,scaleY:0.9826,x:77.55,y:79.95},0).wait(1).to({scaleX:0.9773,scaleY:0.9773,x:79.65,y:80.45},0).wait(1).to({scaleX:0.9717,scaleY:0.9717,x:81.9,y:80.95},0).wait(1).to({scaleX:0.9658,scaleY:0.9658,x:84.35,y:81.55},0).wait(1).to({scaleX:0.9594,scaleY:0.9594,x:86.9,y:82.15},0).wait(1).to({scaleX:0.9528,scaleY:0.9528,x:89.6,y:82.8},0).wait(1).to({scaleX:0.9458,scaleY:0.9458,x:92.45,y:83.5},0).wait(1).to({scaleX:0.9384,scaleY:0.9384,x:95.45,y:84.2},0).wait(1).to({scaleX:0.9307,scaleY:0.9307,x:98.55,y:84.95},0).wait(1).to({scaleX:0.9227,scaleY:0.9227,x:101.8,y:85.65},0).wait(1).to({scaleX:0.9144,scaleY:0.9144,x:105.15,y:86.45},0).wait(1).to({scaleX:0.9059,scaleY:0.9059,x:108.6,y:87.25},0).wait(1).to({scaleX:0.897,scaleY:0.897,x:112.15,y:88.15},0).wait(1).to({scaleX:0.888,scaleY:0.888,x:115.9,y:89},0).wait(1).to({scaleX:0.8787,scaleY:0.8787,x:119.65,y:89.85},0).wait(1).to({scaleX:0.8692,scaleY:0.8692,x:123.45,y:90.8},0).wait(1).to({scaleX:0.8596,scaleY:0.8596,x:127.35,y:91.7},0).wait(1).to({scaleX:0.8498,scaleY:0.8498,x:131.3,y:92.65},0).wait(1).to({scaleX:0.84,scaleY:0.84,x:135.3,y:93.55},0).wait(1).to({scaleX:0.8301,scaleY:0.8301,x:139.35,y:94.55},0).wait(1).to({scaleX:0.8201,scaleY:0.8201,x:143.3,y:95.5},0).wait(1).to({scaleX:0.8102,scaleY:0.8102,x:147.35,y:96.45},0).wait(1).to({scaleX:0.8003,scaleY:0.8003,x:151.35,y:97.4},0).wait(1).to({scaleX:0.7905,scaleY:0.7905,x:155.35,y:98.35},0).wait(1).to({scaleX:0.7808,scaleY:0.7808,x:159.3,y:99.25},0).wait(1).to({scaleX:0.7712,scaleY:0.7712,x:163.15,y:100.15},0).wait(1).to({scaleX:0.7618,scaleY:0.7618,x:166.95,y:101.05},0).wait(1).to({scaleX:0.7526,scaleY:0.7526,x:170.65,y:101.95},0).wait(1).to({scaleX:0.7437,scaleY:0.7437,x:174.35,y:102.8},0).wait(1).to({scaleX:0.7349,scaleY:0.7349,x:177.85,y:103.65},0).wait(1).to({scaleX:0.7265,scaleY:0.7265,x:181.3,y:104.45},0).wait(1).to({scaleX:0.7183,scaleY:0.7183,x:184.6,y:105.25},0).wait(1).to({scaleX:0.7105,scaleY:0.7105,x:187.75,y:105.95},0).wait(1).to({scaleX:0.703,scaleY:0.703,x:190.85,y:106.7},0).wait(1).to({scaleX:0.6958,scaleY:0.6958,x:193.75,y:107.4},0).wait(1).to({scaleX:0.6889,scaleY:0.6889,x:196.5,y:108.05},0).wait(1).to({scaleX:0.6824,scaleY:0.6824,x:199.15,y:108.7},0).wait(1).to({scaleX:0.6763,scaleY:0.6763,x:201.65,y:109.25},0).wait(1).to({scaleX:0.6705,scaleY:0.6705,x:204,y:109.8},0).wait(1).to({scaleX:0.6651,scaleY:0.6651,x:206.15,y:110.35},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:208.2,y:110.85},0).wait(1).to({scaleX:0.6553,scaleY:0.6553,x:210.15,y:111.3},0).wait(1).to({scaleX:0.6509,scaleY:0.6509,x:211.85,y:111.7},0).wait(1).to({scaleX:0.647,scaleY:0.647,x:213.45,y:112.05},0).wait(1).to({scaleX:0.6433,scaleY:0.6433,x:215,y:112.45},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:216.3,y:112.7},0).wait(1).to({scaleX:0.6371,scaleY:0.6371,x:217.5,y:113},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:218.55,y:113.25},0).wait(1).to({scaleX:0.6322,scaleY:0.6322,x:219.5,y:113.45},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:220.25,y:113.65},0).wait(1).to({scaleX:0.6286,scaleY:0.6286,x:220.95,y:113.85},0).wait(1).to({scaleX:0.6273,scaleY:0.6273,x:221.45,y:113.95},0).wait(1).to({scaleX:0.6263,scaleY:0.6263,x:221.9,y:114.05},0).wait(1).to({scaleX:0.6256,scaleY:0.6256,x:222.15,y:114.1},0).wait(1).to({scaleX:0.6251,scaleY:0.6251,x:222.35,y:114.15},0).wait(1).to({scaleX:0.625,scaleY:0.625},0).wait(17).to({x:222.3,y:114.1},0).wait(1).to({scaleX:0.6249,scaleY:0.6249,x:222.25,y:114.05},0).wait(1).to({x:222.15},0).wait(1).to({scaleX:0.6248,scaleY:0.6248,x:222.05,y:113.95},0).wait(1).to({scaleX:0.6247,scaleY:0.6247,x:221.95,y:113.9},0).wait(1).to({scaleX:0.6246,scaleY:0.6246,x:221.8,y:113.8},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:221.6,y:113.65},0).wait(1).to({scaleX:0.6242,scaleY:0.6242,x:221.35,y:113.55},0).wait(1).to({scaleX:0.624,scaleY:0.624,x:221.05,y:113.35},0).wait(1).to({scaleX:0.6237,scaleY:0.6237,x:220.7,y:113.15},0).wait(1).to({scaleX:0.6234,scaleY:0.6234,x:220.35,y:112.95},0).wait(1).to({scaleX:0.6231,scaleY:0.6231,x:219.9,y:112.6},0).wait(1).to({scaleX:0.6227,scaleY:0.6227,x:219.4,y:112.3},0).wait(1).to({scaleX:0.6222,scaleY:0.6222,x:218.85,y:111.95},0).wait(1).to({scaleX:0.6217,scaleY:0.6217,x:218.1,y:111.55},0).wait(1).to({scaleX:0.6211,scaleY:0.6211,x:217.35,y:111.1},0).wait(1).to({scaleX:0.6203,scaleY:0.6203,x:216.45,y:110.45},0).wait(1).to({scaleX:0.6195,scaleY:0.6195,x:215.35,y:109.8},0).wait(1).to({scaleX:0.6184,scaleY:0.6184,x:214.05,y:109.05},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:212.5,y:108.05},0).wait(1).to({scaleX:0.6157,scaleY:0.6157,x:210.55,y:106.85},0).wait(1).to({scaleX:0.6138,scaleY:0.6138,x:208.15,y:105.4},0).wait(1).to({scaleX:0.6113,scaleY:0.6113,x:205.05,y:103.45},0).wait(1).to({scaleX:0.6082,scaleY:0.6082,x:201.1,y:101},0).wait(1).to({scaleX:0.6045,scaleY:0.6045,x:196.5,y:98.2},0).wait(1).to({scaleX:0.6011,scaleY:0.6011,x:192.2,y:95.45},0).wait(1).to({scaleX:0.5983,scaleY:0.5983,x:188.6,y:93.3},0).wait(1).to({scaleX:0.5961,scaleY:0.5961,x:185.8,y:91.55},0).wait(1).to({scaleX:0.5943,scaleY:0.5943,x:183.6,y:90.2},0).wait(1).to({scaleX:0.5929,scaleY:0.5929,x:181.8,y:89.1},0).wait(1).to({scaleX:0.5917,scaleY:0.5917,x:180.35,y:88.2},0).wait(1).to({scaleX:0.5907,scaleY:0.5907,x:179.05,y:87.4},0).wait(1).to({scaleX:0.5899,scaleY:0.5899,x:178.05,y:86.75},0).wait(1).to({scaleX:0.5891,scaleY:0.5891,x:177.1,y:86.2},0).wait(1).to({scaleX:0.5885,scaleY:0.5885,x:176.3,y:85.65},0).wait(1).to({scaleX:0.588,scaleY:0.588,x:175.65,y:85.25},0).wait(1).to({scaleX:0.5875,scaleY:0.5875,x:175,y:84.9},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:174.45,y:84.6},0).wait(1).to({scaleX:0.5867,scaleY:0.5867,x:174,y:84.3},0).wait(1).to({scaleX:0.5864,scaleY:0.5864,x:173.6,y:84},0).wait(1).to({scaleX:0.5861,scaleY:0.5861,x:173.25,y:83.8},0).wait(1).to({scaleX:0.5859,scaleY:0.5859,x:172.95,y:83.6},0).wait(1).to({scaleX:0.5856,scaleY:0.5856,x:172.7,y:83.45},0).wait(1).to({scaleX:0.5855,scaleY:0.5855,x:172.4,y:83.3},0).wait(1).to({scaleX:0.5853,scaleY:0.5853,x:172.25,y:83.2},0).wait(1).to({scaleX:0.5852,scaleY:0.5852,x:172.05,y:83.1},0).wait(1).to({scaleX:0.5851,scaleY:0.5851,x:171.95,y:83},0).wait(1).to({scaleX:0.585,scaleY:0.585,x:171.8,y:82.95},0).wait(1).to({scaleX:0.5849,scaleY:0.5849,x:171.75,y:82.85},0).wait(1).to({scaleX:0.5848,scaleY:0.5848,x:171.65},0).wait(1).to({x:171.6,y:82.8},0).wait(2).to({regX:26.1,regY:20.6},0).wait(8));

	// girl right icon.png
	this.instance_2 = new lib.girlrighticon_1();
	this.instance_2.setTransform(212.4,302.25,1,1,0,0,0,25.9,21.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({x:165.05,y:234.55,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:26,x:165.15},0).wait(16).to({regX:25.9,x:165.05},0).wait(1).to({regX:26,scaleX:0.9981,scaleY:0.9981,x:165.85,y:234},0).wait(1).to({scaleX:0.996,scaleY:0.996,x:166.6,y:233.4},0).wait(1).to({scaleX:0.9938,scaleY:0.9938,x:167.45,y:232.8},0).wait(1).to({scaleX:0.9913,scaleY:0.9913,x:168.35,y:232.15},0).wait(1).to({scaleX:0.9887,scaleY:0.9887,x:169.3,y:231.4},0).wait(1).to({scaleX:0.9859,scaleY:0.9859,x:170.4,y:230.65},0).wait(1).to({scaleX:0.9829,scaleY:0.9829,x:171.45,y:229.85},0).wait(1).to({scaleX:0.9798,scaleY:0.9798,x:172.6,y:228.95},0).wait(1).to({scaleX:0.9765,scaleY:0.9765,x:173.9,y:228.1},0).wait(1).to({scaleX:0.973,scaleY:0.973,x:175.2,y:227.1},0).wait(1).to({scaleX:0.9693,scaleY:0.9693,x:176.55,y:226.1},0).wait(1).to({scaleX:0.9655,scaleY:0.9655,x:177.95,y:225.05},0).wait(1).to({scaleX:0.9615,scaleY:0.9615,x:179.45,y:223.95},0).wait(1).to({scaleX:0.9574,scaleY:0.9574,x:181,y:222.85},0).wait(1).to({scaleX:0.9531,scaleY:0.9531,x:182.6,y:221.65},0).wait(1).to({scaleX:0.9487,scaleY:0.9487,x:184.2,y:220.45},0).wait(1).to({scaleX:0.9442,scaleY:0.9442,x:185.9,y:219.2},0).wait(1).to({scaleX:0.9395,scaleY:0.9395,x:187.65,y:217.95},0).wait(1).to({scaleX:0.9348,scaleY:0.9348,x:189.35,y:216.65},0).wait(1).to({scaleX:0.93,scaleY:0.93,x:191.2,y:215.35},0).wait(1).to({scaleX:0.9251,scaleY:0.9251,x:192.95,y:214},0).wait(1).to({scaleX:0.9202,scaleY:0.9202,x:194.8,y:212.65},0).wait(1).to({scaleX:0.9153,scaleY:0.9153,x:196.65,y:211.35},0).wait(1).to({scaleX:0.9103,scaleY:0.9103,x:198.45,y:209.9},0).wait(1).to({scaleX:0.9054,scaleY:0.9054,x:200.35,y:208.55},0).wait(1).to({scaleX:0.9005,scaleY:0.9005,x:202.15,y:207.25},0).wait(1).to({scaleX:0.8956,scaleY:0.8956,x:204,y:205.9},0).wait(1).to({scaleX:0.8907,scaleY:0.8907,x:205.75,y:204.55},0).wait(1).to({scaleX:0.886,scaleY:0.886,x:207.55,y:203.25},0).wait(1).to({scaleX:0.8813,scaleY:0.8813,x:209.25,y:202},0).wait(1).to({scaleX:0.8767,scaleY:0.8767,x:211,y:200.75},0).wait(1).to({scaleX:0.8722,scaleY:0.8722,x:212.65,y:199.5},0).wait(1).to({scaleX:0.8679,scaleY:0.8679,x:214.25,y:198.3},0).wait(1).to({scaleX:0.8637,scaleY:0.8637,x:215.85,y:197.15},0).wait(1).to({scaleX:0.8596,scaleY:0.8596,x:217.35,y:196.05},0).wait(1).to({scaleX:0.8557,scaleY:0.8557,x:218.8,y:194.95},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:220.2,y:193.9},0).wait(1).to({scaleX:0.8483,scaleY:0.8483,x:221.5,y:192.95},0).wait(1).to({scaleX:0.8449,scaleY:0.8449,x:222.8,y:192},0).wait(1).to({scaleX:0.8417,scaleY:0.8417,x:224,y:191.15},0).wait(1).to({scaleX:0.8386,scaleY:0.8386,x:225.15,y:190.3},0).wait(1).to({scaleX:0.8357,scaleY:0.8357,x:226.25,y:189.5},0).wait(1).to({scaleX:0.833,scaleY:0.833,x:227.2,y:188.75},0).wait(1).to({scaleX:0.8305,scaleY:0.8305,x:228.15,y:188.05},0).wait(1).to({scaleX:0.8282,scaleY:0.8282,x:229.05,y:187.4},0).wait(1).to({scaleX:0.826,scaleY:0.826,x:229.85,y:186.8},0).wait(1).to({scaleX:0.824,scaleY:0.824,x:230.55,y:186.25},0).wait(1).to({scaleX:0.8222,scaleY:0.8222,x:231.25,y:185.8},0).wait(1).to({scaleX:0.8206,scaleY:0.8206,x:231.85,y:185.35},0).wait(1).to({scaleX:0.8191,scaleY:0.8191,x:232.4,y:184.95},0).wait(1).to({scaleX:0.8178,scaleY:0.8178,x:232.9,y:184.6},0).wait(1).to({scaleX:0.8167,scaleY:0.8167,x:233.35,y:184.25},0).wait(1).to({scaleX:0.8157,scaleY:0.8157,x:233.65,y:184},0).wait(1).to({scaleX:0.8149,scaleY:0.8149,x:234,y:183.75},0).wait(1).to({scaleX:0.8142,scaleY:0.8142,x:234.2,y:183.6},0).wait(1).to({scaleX:0.8137,scaleY:0.8137,x:234.4,y:183.45},0).wait(1).to({scaleX:0.8133,scaleY:0.8133,x:234.55,y:183.4},0).wait(1).to({scaleX:0.8131,scaleY:0.8131,x:234.65,y:183.3},0).wait(1).to({regY:21.6,x:234.6},0).wait(1).to({regY:21.5,y:183.25},0).wait(15).to({regY:21.6,y:183.3},0).wait(1).to({regY:21.5,scaleX:0.8129,scaleY:0.8129,x:234.55,y:183.15},0).wait(1).to({scaleX:0.8127,scaleY:0.8127,y:183.05},0).wait(1).to({scaleX:0.8124,scaleY:0.8124,x:234.45,y:182.9},0).wait(1).to({scaleX:0.812,scaleY:0.812,x:234.4,y:182.75},0).wait(1).to({scaleX:0.8114,scaleY:0.8114,x:234.35,y:182.5},0).wait(1).to({scaleX:0.8107,scaleY:0.8107,x:234.3,y:182.25},0).wait(1).to({scaleX:0.8099,scaleY:0.8099,x:234.15,y:181.85},0).wait(1).to({scaleX:0.8089,scaleY:0.8089,x:234.05,y:181.45},0).wait(1).to({scaleX:0.8078,scaleY:0.8078,x:233.9,y:180.95},0).wait(1).to({scaleX:0.8065,scaleY:0.8065,x:233.7,y:180.45},0).wait(1).to({scaleX:0.8049,scaleY:0.8049,x:233.55,y:179.8},0).wait(1).to({scaleX:0.8032,scaleY:0.8032,x:233.3,y:179.05},0).wait(1).to({scaleX:0.8012,scaleY:0.8012,x:233.05,y:178.2},0).wait(1).to({scaleX:0.7989,scaleY:0.7989,x:232.75,y:177.25},0).wait(1).to({scaleX:0.7963,scaleY:0.7963,x:232.4,y:176.1},0).wait(1).to({scaleX:0.7933,scaleY:0.7933,x:232.05,y:174.85},0).wait(1).to({scaleX:0.7899,scaleY:0.7899,x:231.6,y:173.45},0).wait(1).to({scaleX:0.7859,scaleY:0.7859,x:231.1,y:171.75},0).wait(1).to({scaleX:0.7814,scaleY:0.7814,x:230.5,y:169.85},0).wait(1).to({scaleX:0.7761,scaleY:0.7761,x:229.85,y:167.65},0).wait(1).to({scaleX:0.7698,scaleY:0.7698,x:229,y:165},0).wait(1).to({scaleX:0.7624,scaleY:0.7624,x:228.05,y:161.85},0).wait(1).to({scaleX:0.7534,scaleY:0.7534,x:226.95,y:158.1},0).wait(1).to({scaleX:0.7424,scaleY:0.7424,x:225.5,y:153.4},0).wait(1).to({scaleX:0.7285,scaleY:0.7285,x:223.75,y:147.55},0).wait(1).to({scaleX:0.7111,scaleY:0.7111,x:221.5,y:140.25},0).wait(1).to({scaleX:0.6903,scaleY:0.6903,x:218.85,y:131.5},0).wait(1).to({scaleX:0.6689,scaleY:0.6689,x:216.1,y:122.5},0).wait(1).to({scaleX:0.6503,scaleY:0.6503,x:213.7,y:114.6},0).wait(1).to({scaleX:0.6352,scaleY:0.6352,x:211.75,y:108.2},0).wait(1).to({scaleX:0.6231,scaleY:0.6231,x:210.2,y:103.15},0).wait(1).to({scaleX:0.6133,scaleY:0.6133,x:208.95,y:99},0).wait(1).to({scaleX:0.6051,scaleY:0.6051,x:207.95,y:95.55},0).wait(1).to({scaleX:0.5983,scaleY:0.5983,x:207.05,y:92.65},0).wait(1).to({scaleX:0.5924,scaleY:0.5924,x:206.3,y:90.2},0).wait(1).to({scaleX:0.5873,scaleY:0.5873,x:205.6,y:88.1},0).wait(1).to({scaleX:0.5829,scaleY:0.5829,x:205.05,y:86.2},0).wait(1).to({scaleX:0.5791,scaleY:0.5791,x:204.55,y:84.6},0).wait(1).to({scaleX:0.5757,scaleY:0.5757,x:204.15,y:83.2},0).wait(1).to({scaleX:0.5727,scaleY:0.5727,x:203.75,y:81.9},0).wait(1).to({scaleX:0.5701,scaleY:0.5701,x:203.4,y:80.75},0).wait(1).to({scaleX:0.5677,scaleY:0.5677,x:203.1,y:79.8},0).wait(1).to({scaleX:0.5656,scaleY:0.5656,x:202.85,y:78.9},0).wait(1).to({scaleX:0.5638,scaleY:0.5638,x:202.6,y:78.1},0).wait(1).to({scaleX:0.5621,scaleY:0.5621,x:202.4,y:77.45},0).wait(1).to({scaleX:0.5607,scaleY:0.5607,x:202.25,y:76.85},0).wait(1).to({scaleX:0.5594,scaleY:0.5594,x:202.05,y:76.3},0).wait(1).to({scaleX:0.5583,scaleY:0.5583,x:201.9,y:75.85},0).wait(1).to({scaleX:0.5574,scaleY:0.5574,x:201.8,y:75.45},0).wait(1).to({scaleX:0.5565,scaleY:0.5565,x:201.65,y:75.05},0).wait(1).to({scaleX:0.5558,scaleY:0.5558,x:201.6,y:74.8},0).wait(1).to({scaleX:0.5553,scaleY:0.5553,x:201.55,y:74.55},0).wait(1).to({scaleX:0.5548,scaleY:0.5548,x:201.45,y:74.35},0).wait(1).to({scaleX:0.5544,scaleY:0.5544,x:201.4,y:74.15},0).wait(1).to({scaleX:0.5541,scaleY:0.5541,x:201.35,y:74.05},0).wait(1).to({scaleX:0.5539,scaleY:0.5539,y:73.95},0).wait(1).to({scaleX:0.5538,scaleY:0.5538,y:73.9},0).wait(1).to({regX:26.2,regY:21.7,y:74},0).wait(1));

	// girl left icon.png
	this.instance_3 = new lib.girllefticon_1();
	this.instance_3.setTransform(-95.95,220,1,1,0,0,0,25.3,21.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({x:55.55,y:176.3,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:25.5,regY:21.5,x:55.75,y:176.5},0).wait(19).to({regX:25.3,regY:21.3,x:55.55,y:176.3},0).wait(1).to({regX:25.5,regY:21.5,scaleX:0.9962,scaleY:0.9962,x:57.45,y:176.1},0).wait(1).to({scaleX:0.992,scaleY:0.992,x:59.35,y:175.8},0).wait(1).to({scaleX:0.9875,scaleY:0.9875,x:61.4,y:175.4},0).wait(1).to({scaleX:0.9827,scaleY:0.9827,x:63.55,y:174.95},0).wait(1).to({scaleX:0.9774,scaleY:0.9774,x:65.9,y:174.5},0).wait(1).to({scaleX:0.9719,scaleY:0.9719,x:68.45,y:174},0).wait(1).to({scaleX:0.9659,scaleY:0.9659,x:71.15,y:173.45},0).wait(1).to({scaleX:0.9596,scaleY:0.9596,x:73.95,y:172.95},0).wait(1).to({scaleX:0.953,scaleY:0.953,x:76.95,y:172.35},0).wait(1).to({scaleX:0.946,scaleY:0.946,x:80.1,y:171.75},0).wait(1).to({scaleX:0.9387,scaleY:0.9387,x:83.45,y:171.1},0).wait(1).to({scaleX:0.931,scaleY:0.931,x:86.9,y:170.4},0).wait(1).to({scaleX:0.9231,scaleY:0.9231,x:90.5,y:169.7},0).wait(1).to({scaleX:0.9148,scaleY:0.9148,x:94.2,y:168.95},0).wait(1).to({scaleX:0.9063,scaleY:0.9063,x:98.05,y:168.25},0).wait(1).to({scaleX:0.8975,scaleY:0.8975,x:102.05,y:167.45},0).wait(1).to({scaleX:0.8885,scaleY:0.8885,x:106.1,y:166.65},0).wait(1).to({scaleX:0.8792,scaleY:0.8792,x:110.25,y:165.85},0).wait(1).to({scaleX:0.8698,scaleY:0.8698,x:114.55,y:165.05},0).wait(1).to({scaleX:0.8602,scaleY:0.8602,x:118.85,y:164.2},0).wait(1).to({scaleX:0.8505,scaleY:0.8505,x:123.25,y:163.35},0).wait(1).to({scaleX:0.8407,scaleY:0.8407,x:127.7,y:162.45},0).wait(1).to({scaleX:0.8308,scaleY:0.8308,x:132.15,y:161.6},0).wait(1).to({scaleX:0.8209,scaleY:0.8209,x:136.6,y:160.75},0).wait(1).to({scaleX:0.811,scaleY:0.811,x:141.1,y:159.9},0).wait(1).to({scaleX:0.8012,scaleY:0.8012,x:145.5,y:159},0).wait(1).to({scaleX:0.7914,scaleY:0.7914,x:149.95,y:158.15},0).wait(1).to({scaleX:0.7818,scaleY:0.7818,x:154.3,y:157.3},0).wait(1).to({scaleX:0.7722,scaleY:0.7722,x:158.6,y:156.45},0).wait(1).to({scaleX:0.7629,scaleY:0.7629,x:162.8,y:155.65},0).wait(1).to({scaleX:0.7537,scaleY:0.7537,x:166.9,y:154.8},0).wait(1).to({scaleX:0.7448,scaleY:0.7448,x:170.95,y:154.05},0).wait(1).to({scaleX:0.7361,scaleY:0.7361,x:174.85,y:153.3},0).wait(1).to({scaleX:0.7277,scaleY:0.7277,x:178.65,y:152.55},0).wait(1).to({scaleX:0.7196,scaleY:0.7196,x:182.35,y:151.8},0).wait(1).to({scaleX:0.7118,scaleY:0.7118,x:185.85,y:151.15},0).wait(1).to({scaleX:0.7043,scaleY:0.7043,x:189.25,y:150.5},0).wait(1).to({scaleX:0.6971,scaleY:0.6971,x:192.5,y:149.85},0).wait(1).to({scaleX:0.6903,scaleY:0.6903,x:195.55,y:149.25},0).wait(1).to({scaleX:0.6839,scaleY:0.6839,x:198.5,y:148.7},0).wait(1).to({scaleX:0.6777,scaleY:0.6777,x:201.25,y:148.15},0).wait(1).to({scaleX:0.672,scaleY:0.672,x:203.85,y:147.65},0).wait(1).to({scaleX:0.6666,scaleY:0.6666,x:206.3,y:147.2},0).wait(1).to({scaleX:0.6615,scaleY:0.6615,x:208.55,y:146.7},0).wait(1).to({scaleX:0.6568,scaleY:0.6568,x:210.7,y:146.3},0).wait(1).to({scaleX:0.6525,scaleY:0.6525,x:212.65,y:145.95},0).wait(1).to({scaleX:0.6486,scaleY:0.6486,x:214.45,y:145.6},0).wait(1).to({scaleX:0.6449,scaleY:0.6449,x:216.05,y:145.25},0).wait(1).to({scaleX:0.6417,scaleY:0.6417,x:217.55,y:145},0).wait(1).to({scaleX:0.6387,scaleY:0.6387,x:218.9,y:144.75},0).wait(1).to({scaleX:0.6361,scaleY:0.6361,x:220,y:144.5},0).wait(1).to({scaleX:0.6339,scaleY:0.6339,x:221.05,y:144.3},0).wait(1).to({scaleX:0.6319,scaleY:0.6319,x:221.95,y:144.15},0).wait(1).to({scaleX:0.6303,scaleY:0.6303,x:222.65,y:144},0).wait(1).to({scaleX:0.629,scaleY:0.629,x:223.3,y:143.85},0).wait(1).to({scaleX:0.628,scaleY:0.628,x:223.7,y:143.75},0).wait(1).to({scaleX:0.6273,scaleY:0.6273,x:224.05},0).wait(1).to({scaleX:0.6268,scaleY:0.6268,x:224.25,y:143.7},0).wait(1).to({regX:25.3,regY:21.4,scaleX:0.6267,scaleY:0.6267,x:224.2,y:143.55},0).wait(1).to({regX:25.5,regY:21.5,x:224.35,y:143.6},0).wait(15).to({regX:25.3,regY:21.4,x:224.2,y:143.55},0).wait(1).to({regX:25.5,regY:21.5,x:224.35},0).wait(1).to({scaleX:0.6266,scaleY:0.6266,y:143.45},0).wait(1).to({scaleX:0.6265,scaleY:0.6265,y:143.35},0).wait(1).to({scaleX:0.6264,scaleY:0.6264,x:224.3,y:143.2},0).wait(1).to({scaleX:0.6262,scaleY:0.6262,x:224.35,y:143.05},0).wait(1).to({scaleX:0.626,scaleY:0.626,y:142.85},0).wait(1).to({scaleX:0.6258,scaleY:0.6258,x:224.4,y:142.55},0).wait(1).to({scaleX:0.6255,scaleY:0.6255,y:142.25},0).wait(1).to({scaleX:0.6251,scaleY:0.6251,x:224.45,y:141.9},0).wait(1).to({scaleX:0.6247,scaleY:0.6247,x:224.5,y:141.45},0).wait(1).to({scaleX:0.6243,scaleY:0.6243,y:140.9},0).wait(1).to({scaleX:0.6238,scaleY:0.6238,x:224.55,y:140.35},0).wait(1).to({scaleX:0.6232,scaleY:0.6232,x:224.65,y:139.7},0).wait(1).to({scaleX:0.6225,scaleY:0.6225,y:138.95},0).wait(1).to({scaleX:0.6217,scaleY:0.6217,x:224.75,y:138.05},0).wait(1).to({scaleX:0.6207,scaleY:0.6207,x:224.85,y:137.05},0).wait(1).to({scaleX:0.6197,scaleY:0.6197,x:224.9,y:135.85},0).wait(1).to({scaleX:0.6185,scaleY:0.6185,x:225,y:134.5},0).wait(1).to({scaleX:0.617,scaleY:0.617,x:225.15,y:132.9},0).wait(1).to({scaleX:0.6154,scaleY:0.6154,x:225.3,y:131.1},0).wait(1).to({scaleX:0.6133,scaleY:0.6133,x:225.5,y:128.85},0).wait(1).to({scaleX:0.6109,scaleY:0.6109,x:225.7,y:126.2},0).wait(1).to({scaleX:0.6079,scaleY:0.6079,x:225.95,y:122.8},0).wait(1).to({scaleX:0.6041,scaleY:0.6041,x:226.3,y:118.65},0).wait(1).to({scaleX:0.5993,scaleY:0.5993,x:226.75,y:113.35},0).wait(1).to({scaleX:0.5934,scaleY:0.5934,x:227.25,y:106.9},0).wait(1).to({scaleX:0.5874,scaleY:0.5874,x:227.8,y:100.2},0).wait(1).to({scaleX:0.5821,scaleY:0.5821,x:228.25,y:94.3},0).wait(1).to({scaleX:0.5778,scaleY:0.5778,x:228.6,y:89.6},0).wait(1).to({scaleX:0.5744,scaleY:0.5744,x:228.9,y:85.9},0).wait(1).to({scaleX:0.5717,scaleY:0.5717,x:229.15,y:82.85},0).wait(1).to({scaleX:0.5694,scaleY:0.5694,x:229.3,y:80.4},0).wait(1).to({scaleX:0.5675,scaleY:0.5675,x:229.5,y:78.3},0).wait(1).to({scaleX:0.5659,scaleY:0.5659,x:229.65,y:76.5},0).wait(1).to({scaleX:0.5645,scaleY:0.5645,x:229.75,y:75},0).wait(1).to({scaleX:0.5633,scaleY:0.5633,x:229.85,y:73.65},0).wait(1).to({scaleX:0.5623,scaleY:0.5623,x:230,y:72.5},0).wait(1).to({scaleX:0.5614,scaleY:0.5614,x:230.05,y:71.45},0).wait(1).to({scaleX:0.5606,scaleY:0.5606,x:230.15,y:70.55},0).wait(1).to({scaleX:0.5598,scaleY:0.5598,x:230.2,y:69.8},0).wait(1).to({scaleX:0.5592,scaleY:0.5592,x:230.25,y:69.05},0).wait(1).to({scaleX:0.5586,scaleY:0.5586,x:230.3,y:68.45},0).wait(1).to({scaleX:0.5582,scaleY:0.5582,x:230.35,y:67.9},0).wait(1).to({scaleX:0.5577,scaleY:0.5577,y:67.45},0).wait(1).to({scaleX:0.5573,scaleY:0.5573,x:230.4,y:67.05},0).wait(1).to({scaleX:0.557,scaleY:0.557,x:230.45,y:66.7},0).wait(1).to({scaleX:0.5567,scaleY:0.5567,y:66.35},0).wait(1).to({scaleX:0.5565,scaleY:0.5565,x:230.5,y:66.05},0).wait(1).to({scaleX:0.5563,scaleY:0.5563,y:65.85},0).wait(1).to({scaleX:0.5561,scaleY:0.5561,x:230.55,y:65.65},0).wait(1).to({scaleX:0.556,scaleY:0.556,y:65.5},0).wait(1).to({scaleX:0.5559,scaleY:0.5559,x:230.5,y:65.4},0).wait(1).to({scaleX:0.5558,scaleY:0.5558,y:65.3},0).wait(1).to({scaleX:0.5557,scaleY:0.5557,x:230.55,y:65.2},0).wait(2).to({regX:25.4,regY:21.4,x:230.45,y:65.15},0).wait(2));

	// guy right contribution
	this.instance_4 = new lib.guyrightcontribution_1();
	this.instance_4.setTransform(264.05,-17.4,1,1,0,0,0,38.1,26.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).to({x:237.1,y:67.65,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:37.7,regY:26,x:236.7,y:67.45},0).wait(11).to({regX:38.1,regY:26.2,x:237.1,y:67.65},0).wait(1).to({regX:37.7,regY:26,scaleX:0.9983,scaleY:0.9976,y:67.7},0).wait(1).to({scaleX:0.9965,scaleY:0.995,skewY:-0.0572,x:237.5,y:67.95},0).wait(1).to({scaleX:0.9944,scaleY:0.9921,skewY:-0.0895,x:238.05,y:68.3},0).wait(1).to({scaleX:0.9923,scaleY:0.989,skewY:-0.1245,x:238.55,y:68.6},0).wait(1).to({scaleX:0.9899,scaleY:0.9857,skewY:-0.1619,x:239.1,y:69.05},0).wait(1).to({scaleX:0.9874,scaleY:0.9822,skewY:-0.202,x:239.75,y:69.4},0).wait(1).to({scaleX:0.9848,scaleY:0.9784,skewY:-0.2446,x:240.4,y:69.8},0).wait(1).to({scaleX:0.982,scaleY:0.9744,skewY:-0.2897,x:241.05,y:70.25},0).wait(1).to({scaleX:0.979,scaleY:0.9702,skewY:-0.3374,x:241.75,y:70.75},0).wait(1).to({scaleX:0.9759,scaleY:0.9658,skewY:-0.3875,x:242.55,y:71.2},0).wait(1).to({scaleX:0.9726,scaleY:0.9612,skewY:-0.44,x:243.3,y:71.7},0).wait(1).to({scaleX:0.9692,scaleY:0.9563,skewY:-0.4948,x:244.15,y:72.25},0).wait(1).to({scaleX:0.9656,scaleY:0.9513,skewY:-0.5518,x:245,y:72.8},0).wait(1).to({scaleX:0.962,scaleY:0.9461,skewY:-0.611,x:245.9,y:73.35},0).wait(1).to({scaleX:0.9581,scaleY:0.9407,skewY:-0.6722,x:246.8,y:73.95},0).wait(1).to({scaleX:0.9542,scaleY:0.9351,skewY:-0.7353,x:247.75,y:74.55},0).wait(1).to({scaleX:0.9502,scaleY:0.9294,skewY:-0.8001,x:248.75,y:75.2},0).wait(1).to({scaleX:0.946,scaleY:0.9236,skewY:-0.8664,x:249.75,y:75.8},0).wait(1).to({scaleX:0.9418,scaleY:0.9176,skewY:-0.934,x:250.75,y:76.45},0).wait(1).to({scaleX:0.9375,scaleY:0.9115,skewY:-1.0028,x:251.8,y:77.2},0).wait(1).to({scaleX:0.9332,scaleY:0.9054,skewY:-1.0724,x:252.85,y:77.85},0).wait(1).to({scaleX:0.9288,scaleY:0.8992,skewY:-1.1428,x:253.9,y:78.55},0).wait(1).to({scaleX:0.9244,scaleY:0.8929,skewY:-1.2136,x:255,y:79.2},0).wait(1).to({scaleX:0.92,scaleY:0.8866,skewY:-1.2846,x:256.05,y:79.9},0).wait(1).to({scaleX:0.9156,scaleY:0.8804,skewY:-1.3555,x:257.1,y:80.6},0).wait(1).to({scaleX:0.9112,scaleY:0.8741,skewY:-1.4261,x:258.2,y:81.3},0).wait(1).to({scaleX:0.9068,scaleY:0.868,skewY:-1.4962,x:259.2,y:81.95},0).wait(1).to({scaleX:0.9025,scaleY:0.8618,skewY:-1.5655,x:260.3,y:82.6},0).wait(1).to({scaleX:0.8982,scaleY:0.8558,skewY:-1.6338,x:261.35,y:83.3},0).wait(1).to({scaleX:0.894,scaleY:0.8499,skewY:-1.7009,x:262.35,y:83.95},0).wait(1).to({scaleX:0.8899,scaleY:0.8441,skewY:-1.7665,x:263.35,y:84.55},0).wait(1).to({scaleX:0.8859,scaleY:0.8385,skewY:-1.8305,x:264.3,y:85.2},0).wait(1).to({scaleX:0.8821,scaleY:0.833,skewY:-1.8928,x:265.25,y:85.8},0).wait(1).to({scaleX:0.8783,scaleY:0.8276,skewY:-1.9531,x:266.15,y:86.35},0).wait(1).to({scaleX:0.8747,scaleY:0.8225,skewY:-2.0113,x:267,y:87},0).wait(1).to({scaleX:0.8712,scaleY:0.8176,skewY:-2.0674,x:267.85,y:87.5},0).wait(1).to({scaleX:0.8679,scaleY:0.8128,skewY:-2.1211,x:268.7,y:88.05},0).wait(1).to({scaleX:0.8647,scaleY:0.8083,skewY:-2.1725,x:269.45,y:88.5},0).wait(1).to({scaleX:0.8616,scaleY:0.804,skewY:-2.2214,x:270.2,y:89},0).wait(1).to({scaleX:0.8587,scaleY:0.7999,skewY:-2.2678,x:270.9,y:89.45},0).wait(1).to({scaleX:0.856,scaleY:0.796,skewY:-2.3117,x:271.55,y:89.9},0).wait(1).to({scaleX:0.8534,scaleY:0.7923,skewY:-2.353,x:272.2,y:90.3},0).wait(1).to({scaleX:0.851,scaleY:0.7889,skewY:-2.3918,x:272.75,y:90.65},0).wait(1).to({scaleX:0.8487,scaleY:0.7857,skewY:-2.428,x:273.3,y:91.05},0).wait(1).to({scaleX:0.8466,scaleY:0.7828,skewY:-2.4615,x:273.8,y:91.35},0).wait(1).to({scaleX:0.8447,scaleY:0.78,skewY:-2.4926,x:274.25,y:91.65},0).wait(1).to({scaleX:0.8429,scaleY:0.7775,skewY:-2.5211,x:274.7,y:91.9},0).wait(1).to({scaleX:0.8413,scaleY:0.7752,skewY:-2.547,x:275.1,y:92.15},0).wait(1).to({scaleX:0.8398,scaleY:0.7731,skewY:-2.5705,x:275.5,y:92.4},0).wait(1).to({scaleX:0.8385,scaleY:0.7713,skewY:-2.5915,x:275.8,y:92.55},0).wait(1).to({scaleX:0.8374,scaleY:0.7696,skewY:-2.6102,x:276.05,y:92.75},0).wait(1).to({scaleX:0.8364,scaleY:0.7682,skewY:-2.6264,x:276.3,y:92.9},0).wait(1).to({scaleX:0.8355,scaleY:0.767,skewY:-2.6404,x:276.5,y:93.1},0).wait(1).to({scaleX:0.8348,scaleY:0.766,skewY:-2.652,x:276.7,y:93.15},0).wait(1).to({scaleX:0.8342,scaleY:0.7651,skewY:-2.6614,x:276.8,y:93.3},0).wait(1).to({scaleX:0.8337,scaleY:0.7645,skewY:-2.6687,x:276.95,y:93.4},0).wait(1).to({scaleX:0.8334,scaleY:0.764,skewY:-2.6738,x:277.05},0).wait(1).to({scaleX:0.8332,scaleY:0.7638,skewY:-2.6768,x:277.1,y:93.45},0).wait(1).to({regX:38.2,regY:26.2,scaleX:0.8331,scaleY:0.7637,skewY:-2.6778,x:277.4,y:93.5},0).wait(79));

	// guy left contribution
	this.instance_5 = new lib.guyleftcontribution_1();
	this.instance_5.setTransform(-36.35,126.65,1,1,0,0,0,30.4,9.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({x:118.75,y:88.95,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:30.5,regY:9.7,x:118.85,y:88.85},0).wait(12).to({regX:30.4,regY:9.8,x:118.75,y:88.95},0).wait(1).to({regX:30.5,regY:9.7,scaleX:0.9959,scaleY:0.996,skewX:-0.08,skewY:-0.0136,x:120.1,y:89.25},0).wait(1).to({scaleX:0.9914,scaleY:0.9916,skewX:-0.1674,skewY:-0.0284,x:121.45,y:89.75},0).wait(1).to({scaleX:0.9866,scaleY:0.9868,skewX:-0.2622,skewY:-0.0445,x:122.9,y:90.25},0).wait(1).to({scaleX:0.9813,scaleY:0.9817,skewX:-0.3645,skewY:-0.0618,x:124.5,y:90.75},0).wait(1).to({scaleX:0.9757,scaleY:0.9762,skewX:-0.4743,skewY:-0.0804,x:126.2,y:91.35},0).wait(1).to({scaleX:0.9697,scaleY:0.9703,skewX:-0.5916,skewY:-0.1003,x:128.05,y:92},0).wait(1).to({scaleX:0.9633,scaleY:0.964,skewX:-0.7163,skewY:-0.1215,x:129.95,y:92.7},0).wait(1).to({scaleX:0.9566,scaleY:0.9573,skewX:-0.8485,skewY:-0.1439,x:132,y:93.45},0).wait(1).to({scaleX:0.9494,scaleY:0.9503,skewX:-0.988,skewY:-0.1676,x:134.15,y:94.15},0).wait(1).to({scaleX:0.9419,scaleY:0.943,skewX:-1.1347,skewY:-0.1924,x:136.5,y:94.95},0).wait(1).to({scaleX:0.934,scaleY:0.9352,skewX:-1.2884,skewY:-0.2185,x:138.85,y:95.75},0).wait(1).to({scaleX:0.9258,scaleY:0.9272,skewX:-1.449,skewY:-0.2457,x:141.4,y:96.7},0).wait(1).to({scaleX:0.9172,scaleY:0.9188,skewX:-1.6161,skewY:-0.2741,x:143.9,y:97.55},0).wait(1).to({scaleX:0.9084,scaleY:0.91,skewX:-1.7895,skewY:-0.3035,x:146.65,y:98.45},0).wait(1).to({scaleX:0.8992,scaleY:0.901,skewX:-1.9687,skewY:-0.3339,x:149.4,y:99.5},0).wait(1).to({scaleX:0.8897,scaleY:0.8918,skewX:-2.1534,skewY:-0.3652,x:152.3,y:100.5},0).wait(1).to({scaleX:0.88,scaleY:0.8822,skewX:-2.3431,skewY:-0.3974,x:155.25,y:101.45},0).wait(1).to({scaleX:0.87,scaleY:0.8724,skewX:-2.5372,skewY:-0.4303,x:158.25,y:102.5},0).wait(1).to({scaleX:0.8599,scaleY:0.8625,skewX:-2.7353,skewY:-0.4639,x:161.35,y:103.6},0).wait(1).to({scaleX:0.8496,scaleY:0.8524,skewX:-2.9367,skewY:-0.498,x:164.45,y:104.7},0).wait(1).to({scaleX:0.8391,scaleY:0.8421,skewX:-3.1407,skewY:-0.5326,x:167.65,y:105.75},0).wait(1).to({scaleX:0.8286,scaleY:0.8317,skewX:-3.3467,skewY:-0.5676,x:170.8,y:106.9},0).wait(1).to({scaleX:0.818,scaleY:0.8213,skewX:-3.5541,skewY:-0.6027,x:174.1,y:108.05},0).wait(1).to({scaleX:0.8073,scaleY:0.8109,skewX:-3.7619,skewY:-0.638,x:177.25,y:109.15},0).wait(1).to({scaleX:0.7967,scaleY:0.8004,skewX:-3.9697,skewY:-0.6732,x:180.55,y:110.25},0).wait(1).to({scaleX:0.7861,scaleY:0.79,skewX:-4.1765,skewY:-0.7083,x:183.7,y:111.4},0).wait(1).to({scaleX:0.7755,scaleY:0.7797,skewX:-4.3817,skewY:-0.7431,x:186.95,y:112.5},0).wait(1).to({scaleX:0.7651,scaleY:0.7695,skewX:-4.5847,skewY:-0.7775,x:190.1,y:113.6},0).wait(1).to({scaleX:0.7549,scaleY:0.7594,skewX:-4.7847,skewY:-0.8114,x:193.15,y:114.65},0).wait(1).to({scaleX:0.7448,scaleY:0.7496,skewX:-4.9811,skewY:-0.8448,x:196.25,y:115.7},0).wait(1).to({scaleX:0.735,scaleY:0.7399,skewX:-5.1734,skewY:-0.8774,x:199.2,y:116.75},0).wait(1).to({scaleX:0.7254,scaleY:0.7304,skewX:-5.3609,skewY:-0.9092,x:202.1,y:117.75},0).wait(1).to({scaleX:0.716,scaleY:0.7213,skewX:-5.5432,skewY:-0.9401,x:205,y:118.75},0).wait(1).to({scaleX:0.707,scaleY:0.7124,skewX:-5.7198,skewY:-0.97,x:207.75,y:119.75},0).wait(1).to({scaleX:0.6983,scaleY:0.7038,skewX:-5.8903,skewY:-0.9989,x:210.4,y:120.65},0).wait(1).to({scaleX:0.6899,scaleY:0.6956,skewX:-6.0544,skewY:-1.0268,x:212.95,y:121.5},0).wait(1).to({scaleX:0.6818,scaleY:0.6877,skewX:-6.2118,skewY:-1.0535,x:215.35,y:122.35},0).wait(1).to({scaleX:0.6741,scaleY:0.6801,skewX:-6.3622,skewY:-1.079,x:217.75,y:123.15},0).wait(1).to({scaleX:0.6667,scaleY:0.6729,skewX:-6.5055,skewY:-1.1033,x:219.95,y:123.95},0).wait(1).to({scaleX:0.6598,scaleY:0.6661,skewX:-6.6415,skewY:-1.1263,x:222.05,y:124.65},0).wait(1).to({scaleX:0.6532,scaleY:0.6596,skewX:-6.77,skewY:-1.1481,x:224.05,y:125.4},0).wait(1).to({scaleX:0.647,scaleY:0.6535,skewX:-6.891,skewY:-1.1687,x:225.95,y:126.05},0).wait(1).to({scaleX:0.6412,scaleY:0.6478,skewX:-7.0045,skewY:-1.1879,x:227.7,y:126.65},0).wait(1).to({scaleX:0.6358,scaleY:0.6425,skewX:-7.1104,skewY:-1.2059,x:229.35,y:127.25},0).wait(1).to({scaleX:0.6307,scaleY:0.6375,skewX:-7.2088,skewY:-1.2225,x:230.9,y:127.8},0).wait(1).to({scaleX:0.6261,scaleY:0.633,skewX:-7.2997,skewY:-1.238,x:232.3,y:128.25},0).wait(1).to({scaleX:0.6218,scaleY:0.6288,skewX:-7.3831,skewY:-1.2521,x:233.6,y:128.7},0).wait(1).to({scaleX:0.6179,scaleY:0.625,skewX:-7.4592,skewY:-1.265,x:234.8,y:129.1},0).wait(1).to({scaleX:0.6144,scaleY:0.6215,skewX:-7.5279,skewY:-1.2767,x:235.85,y:129.5},0).wait(1).to({scaleX:0.6112,scaleY:0.6184,skewX:-7.5895,skewY:-1.2871,x:236.8,y:129.85},0).wait(1).to({scaleX:0.6084,scaleY:0.6157,skewX:-7.6441,skewY:-1.2964,x:237.65,y:130.1},0).wait(1).to({scaleX:0.606,scaleY:0.6133,skewX:-7.6917,skewY:-1.3044,x:238.4,y:130.4},0).wait(1).to({scaleX:0.6039,scaleY:0.6112,skewX:-7.7325,skewY:-1.3114,x:239,y:130.6},0).wait(1).to({scaleX:0.6021,scaleY:0.6095,skewX:-7.7666,skewY:-1.3172,x:239.55,y:130.8},0).wait(1).to({scaleX:0.6007,scaleY:0.6081,skewX:-7.7942,skewY:-1.3218,x:239.95,y:130.95},0).wait(1).to({scaleX:0.5996,scaleY:0.607,skewX:-7.8155,skewY:-1.3254,x:240.3,y:131.05},0).wait(1).to({scaleX:0.5989,scaleY:0.6063,skewX:-7.8305,skewY:-1.328,x:240.5,y:131.15},0).wait(1).to({scaleX:0.5984,scaleY:0.6058,skewX:-7.8393,skewY:-1.3295,x:240.65},0).wait(1).to({regX:30.6,regY:9.8,scaleX:0.5983,scaleY:0.6057,skewX:-7.8423,skewY:-1.33,x:240.7,y:131.25},0).wait(77));

	// girl left contribution
	this.instance_6 = new lib.girlleftcontribution_1();
	this.instance_6.setTransform(-47.7,231.85,1,1,0,0,0,44,32.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({x:103.8,y:188.15,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:44.2,regY:32.5,x:104,y:188.35},0).wait(18).to({regX:44,regY:32.3,x:103.8,y:188.15},0).wait(1).to({regX:44.2,regY:32.5,scaleX:0.9949,scaleY:0.9949,x:105.45,y:188},0).wait(1).to({scaleX:0.9893,scaleY:0.9893,x:107.2,y:187.55},0).wait(1).to({scaleX:0.9832,scaleY:0.9832,x:108.95,y:187.1},0).wait(1).to({scaleX:0.9767,scaleY:0.9767,x:110.9,y:186.65},0).wait(1).to({scaleX:0.9696,scaleY:0.9696,x:113,y:186.15},0).wait(1).to({scaleX:0.9621,scaleY:0.9621,x:115.2,y:185.6},0).wait(1).to({scaleX:0.9541,scaleY:0.9541,x:117.55,y:185.05},0).wait(1).to({scaleX:0.9456,scaleY:0.9456,x:120.1,y:184.45},0).wait(1).to({scaleX:0.9367,scaleY:0.9367,x:122.75,y:183.8},0).wait(1).to({scaleX:0.9273,scaleY:0.9273,x:125.55,y:183.15},0).wait(1).to({scaleX:0.9174,scaleY:0.9174,x:128.45,y:182.4},0).wait(1).to({scaleX:0.9072,scaleY:0.9072,x:131.5,y:181.7},0).wait(1).to({scaleX:0.8964,scaleY:0.8964,x:134.65,y:180.95},0).wait(1).to({scaleX:0.8853,scaleY:0.8853,x:138,y:180.1},0).wait(1).to({scaleX:0.8739,scaleY:0.8739,x:141.35,y:179.3},0).wait(1).to({scaleX:0.862,scaleY:0.862,x:144.85,y:178.45},0).wait(1).to({scaleX:0.8499,scaleY:0.8499,x:148.45,y:177.6},0).wait(1).to({scaleX:0.8374,scaleY:0.8374,x:152.15,y:176.7},0).wait(1).to({scaleX:0.8247,scaleY:0.8247,x:155.9,y:175.8},0).wait(1).to({scaleX:0.8118,scaleY:0.8118,x:159.75,y:174.9},0).wait(1).to({scaleX:0.7987,scaleY:0.7987,x:163.6,y:173.95},0).wait(1).to({scaleX:0.7855,scaleY:0.7855,x:167.5,y:173.05},0).wait(1).to({scaleX:0.7723,scaleY:0.7723,x:171.5,y:172.1},0).wait(1).to({scaleX:0.7589,scaleY:0.7589,x:175.45,y:171.1},0).wait(1).to({scaleX:0.7456,scaleY:0.7456,x:179.35,y:170.2},0).wait(1).to({scaleX:0.7324,scaleY:0.7324,x:183.25,y:169.25},0).wait(1).to({scaleX:0.7192,scaleY:0.7192,x:187.2,y:168.25},0).wait(1).to({scaleX:0.7062,scaleY:0.7062,x:191.05,y:167.35},0).wait(1).to({scaleX:0.6934,scaleY:0.6934,x:194.85,y:166.45},0).wait(1).to({scaleX:0.6808,scaleY:0.6808,x:198.6,y:165.55},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,x:202.25,y:164.7},0).wait(1).to({scaleX:0.6565,scaleY:0.6565,x:205.75,y:163.85},0).wait(1).to({scaleX:0.6448,scaleY:0.6448,x:209.25,y:162.95},0).wait(1).to({scaleX:0.6335,scaleY:0.6335,x:212.6,y:162.2},0).wait(1).to({scaleX:0.6225,scaleY:0.6225,x:215.8,y:161.4},0).wait(1).to({scaleX:0.612,scaleY:0.612,x:218.95,y:160.65},0).wait(1).to({scaleX:0.6019,scaleY:0.6019,x:221.95,y:159.9},0).wait(1).to({scaleX:0.5923,scaleY:0.5923,x:224.8,y:159.25},0).wait(1).to({scaleX:0.5831,scaleY:0.5831,x:227.5,y:158.6},0).wait(1).to({scaleX:0.5744,scaleY:0.5744,x:230.1,y:157.95},0).wait(1).to({scaleX:0.5662,scaleY:0.5662,x:232.5,y:157.35},0).wait(1).to({scaleX:0.5584,scaleY:0.5584,x:234.85,y:156.8},0).wait(1).to({scaleX:0.5511,scaleY:0.5511,x:237,y:156.3},0).wait(1).to({scaleX:0.5443,scaleY:0.5443,x:239,y:155.8},0).wait(1).to({scaleX:0.538,scaleY:0.538,x:240.9,y:155.4},0).wait(1).to({scaleX:0.5322,scaleY:0.5322,x:242.6,y:154.95},0).wait(1).to({scaleX:0.5269,scaleY:0.5269,x:244.2,y:154.55},0).wait(1).to({scaleX:0.522,scaleY:0.522,x:245.6,y:154.2},0).wait(1).to({scaleX:0.5176,scaleY:0.5176,x:246.95,y:153.9},0).wait(1).to({scaleX:0.5136,scaleY:0.5136,x:248.1,y:153.65},0).wait(1).to({scaleX:0.5101,scaleY:0.5101,x:249.15,y:153.4},0).wait(1).to({scaleX:0.5071,scaleY:0.5071,x:250.05,y:153.15},0).wait(1).to({scaleX:0.5045,scaleY:0.5045,x:250.85,y:152.95},0).wait(1).to({scaleX:0.5023,scaleY:0.5023,x:251.45,y:152.8},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:252,y:152.65},0).wait(1).to({scaleX:0.4992,scaleY:0.4992,x:252.4,y:152.55},0).wait(1).to({scaleX:0.4982,scaleY:0.4982,x:252.65},0).wait(1).to({scaleX:0.4976,scaleY:0.4976,x:252.85,y:152.45},0).wait(1).to({scaleX:0.4974,scaleY:0.4974,x:252.8,y:152.35},0).wait(75));

	// girl rigth contribution
	this.instance_7 = new lib.girlrigthcontribution();
	this.instance_7.setTransform(276.95,303.5,1,1,0,0,0,39.1,19.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(14).to({_off:false},0).to({x:229.6,y:235.8,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:229.5,y:235.7},0).wait(17).to({regX:39.1,regY:19.1,x:229.6,y:235.8},0).wait(1).to({regX:39,regY:19,scaleX:0.9953,scaleY:0.9953,x:229.8,y:235.05},0).wait(1).to({scaleX:0.9901,scaleY:0.9901,x:230.2,y:234.35},0).wait(1).to({scaleX:0.9845,scaleY:0.9845,x:230.6,y:233.6},0).wait(1).to({scaleX:0.9784,scaleY:0.9784,x:231.05,y:232.8},0).wait(1).to({scaleX:0.9719,scaleY:0.9719,x:231.5,y:231.9},0).wait(1).to({scaleX:0.965,scaleY:0.965,x:232.05,y:231},0).wait(1).to({scaleX:0.9576,scaleY:0.9576,x:232.55,y:230},0).wait(1).to({scaleX:0.9498,scaleY:0.9498,x:233.15,y:228.95},0).wait(1).to({scaleX:0.9415,scaleY:0.9415,x:233.7,y:227.85},0).wait(1).to({scaleX:0.9328,scaleY:0.9328,x:234.4,y:226.65},0).wait(1).to({scaleX:0.9237,scaleY:0.9237,x:235,y:225.45},0).wait(1).to({scaleX:0.9142,scaleY:0.9142,x:235.7,y:224.15},0).wait(1).to({scaleX:0.9043,scaleY:0.9043,x:236.4,y:222.85},0).wait(1).to({scaleX:0.894,scaleY:0.894,x:237.15,y:221.45},0).wait(1).to({scaleX:0.8834,scaleY:0.8834,x:237.95,y:220.05},0).wait(1).to({scaleX:0.8725,scaleY:0.8725,x:238.75,y:218.6},0).wait(1).to({scaleX:0.8612,scaleY:0.8612,x:239.55,y:217.05},0).wait(1).to({scaleX:0.8497,scaleY:0.8497,x:240.4,y:215.5},0).wait(1).to({scaleX:0.838,scaleY:0.838,x:241.25,y:213.9},0).wait(1).to({scaleX:0.8261,scaleY:0.8261,x:242.1,y:212.35},0).wait(1).to({scaleX:0.814,scaleY:0.814,x:243,y:210.7},0).wait(1).to({scaleX:0.8018,scaleY:0.8018,x:243.85,y:209.1},0).wait(1).to({scaleX:0.7895,scaleY:0.7895,x:244.8,y:207.45},0).wait(1).to({scaleX:0.7772,scaleY:0.7772,x:245.65,y:205.75},0).wait(1).to({scaleX:0.7649,scaleY:0.7649,x:246.6,y:204.15},0).wait(1).to({scaleX:0.7526,scaleY:0.7526,x:247.45,y:202.5},0).wait(1).to({scaleX:0.7405,scaleY:0.7405,x:248.35,y:200.85},0).wait(1).to({scaleX:0.7285,scaleY:0.7285,x:249.2,y:199.25},0).wait(1).to({scaleX:0.7166,scaleY:0.7166,x:250.1,y:197.65},0).wait(1).to({scaleX:0.705,scaleY:0.705,x:250.95,y:196.1},0).wait(1).to({scaleX:0.6936,scaleY:0.6936,x:251.75,y:194.6},0).wait(1).to({scaleX:0.6825,scaleY:0.6825,x:252.55,y:193.05},0).wait(1).to({scaleX:0.6717,scaleY:0.6717,x:253.35,y:191.6},0).wait(1).to({scaleX:0.6612,scaleY:0.6612,x:254.1,y:190.2},0).wait(1).to({scaleX:0.6511,scaleY:0.6511,x:254.85,y:188.85},0).wait(1).to({scaleX:0.6414,scaleY:0.6414,x:255.55,y:187.55},0).wait(1).to({scaleX:0.6321,scaleY:0.6321,x:256.2,y:186.3},0).wait(1).to({scaleX:0.6232,scaleY:0.6232,x:256.85,y:185.1},0).wait(1).to({scaleX:0.6147,scaleY:0.6147,x:257.45,y:184},0).wait(1).to({scaleX:0.6066,scaleY:0.6066,x:258.05,y:182.9},0).wait(1).to({scaleX:0.599,scaleY:0.599,x:258.6,y:181.9},0).wait(1).to({scaleX:0.5919,scaleY:0.5919,x:259.15,y:180.9},0).wait(1).to({scaleX:0.5851,scaleY:0.5851,x:259.6,y:180},0).wait(1).to({scaleX:0.5789,scaleY:0.5789,x:260.05,y:179.15},0).wait(1).to({scaleX:0.573,scaleY:0.573,x:260.5,y:178.4},0).wait(1).to({scaleX:0.5676,scaleY:0.5676,x:260.9,y:177.7},0).wait(1).to({scaleX:0.5627,scaleY:0.5627,x:261.25,y:177},0).wait(1).to({scaleX:0.5582,scaleY:0.5582,x:261.55,y:176.4},0).wait(1).to({scaleX:0.5541,scaleY:0.5541,x:261.85,y:175.85},0).wait(1).to({scaleX:0.5505,scaleY:0.5505,x:262.15,y:175.35},0).wait(1).to({scaleX:0.5472,scaleY:0.5472,x:262.4,y:174.95},0).wait(1).to({scaleX:0.5444,scaleY:0.5444,x:262.6,y:174.55},0).wait(1).to({scaleX:0.542,scaleY:0.542,x:262.8,y:174.25},0).wait(1).to({scaleX:0.54,scaleY:0.54,x:262.9,y:173.95},0).wait(1).to({scaleX:0.5384,scaleY:0.5384,x:263.05,y:173.75},0).wait(1).to({scaleX:0.5371,scaleY:0.5371,x:263.1,y:173.55},0).wait(1).to({scaleX:0.5362,scaleY:0.5362,x:263.15,y:173.45},0).wait(1).to({scaleX:0.5357,scaleY:0.5357,x:263.25,y:173.4},0).wait(1).to({regX:39.1,regY:19.2,scaleX:0.5355,scaleY:0.5355,x:263.3,y:173.45},0).wait(74));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_69 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_70 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_71 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_72 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_73 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_74 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_75 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_76 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_77 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_78 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_79 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_80 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_81 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");
	var mask_graphics_82 = new cjs.Graphics().p("Azsi6QAcgKPSkuIPUkuIIXPiI+6Jgg");
	var mask_graphics_83 = new cjs.Graphics().p("Azui6QAdgKPSkuIPVkvIIZPkI+8Jfg");
	var mask_graphics_84 = new cjs.Graphics().p("Azvi6QAdgLPRktIPZkwIIYPlI++Jgg");
	var mask_graphics_85 = new cjs.Graphics().p("Azxi6QAegLPPktIPdkxIIZPmI/CJhg");
	var mask_graphics_86 = new cjs.Graphics().p("Azzi7QAfgLPNksIPhkzIIbPoI/GJjg");
	var mask_graphics_87 = new cjs.Graphics().p("Az3i7QAggMPNkrIPmk1IIcPrI/LJkg");
	var mask_graphics_88 = new cjs.Graphics().p("Az6i8QAigNPJkpIPsk3IIdPtI/PJlg");
	var mask_graphics_89 = new cjs.Graphics().p("Az9i9QAjgNPGkpIP0k4IIePvI/UJog");
	var mask_graphics_90 = new cjs.Graphics().p("A0Bi+QAkgNPEkoIP6k6IIhPyI/bJpg");
	var mask_graphics_91 = new cjs.Graphics().p("A0Fi+QAmgOPAknIQDk9IIjP1I/iJsg");
	var mask_graphics_92 = new cjs.Graphics().p("A0Li/QApgPO9kmIQMk/IIkP5I/pJug");
	var mask_graphics_93 = new cjs.Graphics().p("A0QjBQArgPO4kkQH9icIainIInP+I/xJwg");
	var mask_graphics_94 = new cjs.Graphics().p("A0WjCQAugPO0kjQH/idIjipIIpQBI/7J0g");
	var mask_graphics_95 = new cjs.Graphics().p("A0cjDQAwgQOwkhQIDieIqisIIsQGMggEAJ3g");
	var mask_graphics_96 = new cjs.Graphics().p("A0jjEQAzgSOqkfQIHieI0iwIIvQLMggPAJ8g");
	var mask_graphics_97 = new cjs.Graphics().p("A0qjGQA2gSOlkeQILifI9iyIIzQRMggcAJ+g");
	var mask_graphics_98 = new cjs.Graphics().p("A0zjIQA6gTOfkbQIQigJHi2II2QXMggnAKCg");
	var mask_graphics_99 = new cjs.Graphics().p("A07jJQA9gUOZkZQIUiiJTi5II6QdMgg1AKGg");
	var mask_graphics_100 = new cjs.Graphics().p("A1EjLQBBgVOTkXQIZijJei9II+QkMghCAKLg");
	var mask_graphics_101 = new cjs.Graphics().p("A1NjNQBEgXOMkUQIeijJsjCIJBQrMghQAKQg");
	var mask_graphics_102 = new cjs.Graphics().p("A1XjPQBJgYOEkRQIkilJ4jGIJGQyMghgAKVg");
	var mask_graphics_103 = new cjs.Graphics().p("A1hjRQBNgZN9kOQIpinKGjKIJKQ5MghvAKag");
	var mask_graphics_104 = new cjs.Graphics().p("A1sjTQBSgaN2kMQIuioKUjPIJPRBMgiAAKgg");
	var mask_graphics_105 = new cjs.Graphics().p("A13jWQBWgbNukJQI0ipKjjTIJTRJMgiRAKlg");
	var mask_graphics_106 = new cjs.Graphics().p("A2CjYQBbgdNlkGQI7iqKxjZIJZRSMgijAKrg");
	var mask_graphics_107 = new cjs.Graphics().p("A2NjaQBfgeNdkDQJBisLBjeIJdRbMgi0AKwg");
	var mask_graphics_108 = new cjs.Graphics().p("A2ZjcQBlggNUj/QJIiuLPjjIJjRjMgjHAK2g");
	var mask_graphics_109 = new cjs.Graphics().p("A2kjeQBpgiNMj8QJOiwLfjnIJnRrMgjYAK8g");
	var mask_graphics_110 = new cjs.Graphics().p("A2vjhQBugiNDj6QJTiwLvjtIJsR0MgjpALBg");
	var mask_graphics_111 = new cjs.Graphics().p("A27jjQBzgkM7j2QJaizL+jyIJxR9Mgj7ALIg");
	var mask_graphics_112 = new cjs.Graphics().p("A3GjlQB3gmMzjzQJgi0MNj3IJ2SFMgkNALOg");
	var mask_graphics_113 = new cjs.Graphics().p("A3SjoQB9gmMqjxQJni1Mcj7IJ6SMMgkeALUg");
	var mask_graphics_114 = new cjs.Graphics().p("A3cjqQCBgpMijtQJsi2MqkBIKASWMgkvALZg");
	var mask_graphics_115 = new cjs.Graphics().p("A3njsQCFgpMbjsQJyi3M4kFIKFSdMglAALeg");
	var mask_graphics_116 = new cjs.Graphics().p("A3yjuQCLgrMSjoQJ5i5NGkKIKJSmMglQALjg");
	var mask_graphics_117 = new cjs.Graphics().p("A37jwQCOgsMLjlQJ+i7NTkOIKNStMglfALog");
	var mask_graphics_118 = new cjs.Graphics().p("A4FjyQCSgtMFjjQKDi7NfkTIKSS0MgluALsg");
	var mask_graphics_119 = new cjs.Graphics().p("A4Oj0QCWguL+jgQKIi9NrkWIKWS6Mgl8ALxg");
	var mask_graphics_120 = new cjs.Graphics().p("A4Wj1QCZgwL4jeQKMi+N3kaIKZTBMgmJAL2g");
	var mask_graphics_121 = new cjs.Graphics().p("A4ej3QCcgwLyjdQKRi+OCkdIKcTGMgmWAL5g");
	var mask_graphics_122 = new cjs.Graphics().p("A4mj5QCggxLsjaQKWi/OLkiIKgTNMgmiAL+g");
	var mask_graphics_123 = new cjs.Graphics().p("A4tj6QCjgzLnjYQKZi/OVklIKjTSMgmtAMBg");
	var mask_graphics_124 = new cjs.Graphics().p("A40j8QCmgzLijVQKdjCOekoIKmTXMgm4AMFg");
	var mask_graphics_125 = new cjs.Graphics().p("A46j9QCog0LdjUQKijCOmkqIKoTbMgnBAMIg");
	var mask_graphics_126 = new cjs.Graphics().p("A5Aj+QCrg1LZjSQKkjDOuktIKrTgMgnKAMLg");
	var mask_graphics_127 = new cjs.Graphics().p("A5Gj/QCug1LVjSQKnjDO1kvIKuTkMgnTAMNg");
	var mask_graphics_128 = new cjs.Graphics().p("A5LkAQCwg2LRjQQKqjEO8kxIKvTnMgnaAMQg");
	var mask_graphics_129 = new cjs.Graphics().p("A5PkBQCxg2LOjPQKtjFPBkzIKyTrMgniAMSg");
	var mask_graphics_130 = new cjs.Graphics().p("A5TkCQCzg3LLjNQKujGPIk1IKzTuMgnoAMVg");
	var mask_graphics_131 = new cjs.Graphics().p("A5XkCQC1g4LIjNQKwjGPNk2IK1TxMgnuAMWg");
	var mask_graphics_132 = new cjs.Graphics().p("A5akDQC2g4LFjMQKzjGPRk4IK2TzMgnzAMYg");
	var mask_graphics_133 = new cjs.Graphics().p("A5dkEQC3g4LDjLQK0jGPVk6IK4T1Mgn4AMag");
	var mask_graphics_134 = new cjs.Graphics().p("A5gkEQC5g5LBjKQK1jHPZk7IK5T4Mgn8AMbg");
	var mask_graphics_135 = new cjs.Graphics().p("A5ikFQC5g5LAjJQK3jHPbk8IK6T5Mgn/AMcg");
	var mask_graphics_136 = new cjs.Graphics().p("A5kkFQC6g5K+jJQK5jIPdk8IK7T6MgoCAMdg");
	var mask_graphics_137 = new cjs.Graphics().p("A5mkGQC7g5K9jIQK5jIPgk+IK8T8MgoFAMfg");
	var mask_graphics_138 = new cjs.Graphics().p("A5nkGQC7g5K9jJQK5jIPik9IK8T8MgoHAMfg");
	var mask_graphics_139 = new cjs.Graphics().p("A5okGQC7g5K9jJQK5jHPkk/IK8T+MgoJAMfg");
	var mask_graphics_140 = new cjs.Graphics().p("A5pkGQC8g6K7jIQK7jIPkk+IK9T+MgoKAMfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:178.45,y:155.025}).wait(60).to({graphics:mask_graphics_69,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_70,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_71,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_72,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_73,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_74,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_75,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_76,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_77,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_78,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_79,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_80,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_81,x:178.45,y:155.025}).wait(1).to({graphics:mask_graphics_82,x:178.525,y:155}).wait(1).to({graphics:mask_graphics_83,x:178.65,y:154.975}).wait(1).to({graphics:mask_graphics_84,x:178.775,y:154.95}).wait(1).to({graphics:mask_graphics_85,x:178.975,y:154.875}).wait(1).to({graphics:mask_graphics_86,x:179.2,y:154.825}).wait(1).to({graphics:mask_graphics_87,x:179.45,y:154.775}).wait(1).to({graphics:mask_graphics_88,x:179.75,y:154.7}).wait(1).to({graphics:mask_graphics_89,x:180.05,y:154.625}).wait(1).to({graphics:mask_graphics_90,x:180.45,y:154.525}).wait(1).to({graphics:mask_graphics_91,x:180.85,y:154.4}).wait(1).to({graphics:mask_graphics_92,x:181.3,y:154.3}).wait(1).to({graphics:mask_graphics_93,x:181.8,y:154.2}).wait(1).to({graphics:mask_graphics_94,x:182.35,y:154.025}).wait(1).to({graphics:mask_graphics_95,x:182.925,y:153.875}).wait(1).to({graphics:mask_graphics_96,x:183.575,y:153.75}).wait(1).to({graphics:mask_graphics_97,x:184.25,y:153.575}).wait(1).to({graphics:mask_graphics_98,x:185,y:153.375}).wait(1).to({graphics:mask_graphics_99,x:185.775,y:153.175}).wait(1).to({graphics:mask_graphics_100,x:186.575,y:152.975}).wait(1).to({graphics:mask_graphics_101,x:187.45,y:152.775}).wait(1).to({graphics:mask_graphics_102,x:188.35,y:152.525}).wait(1).to({graphics:mask_graphics_103,x:189.3,y:152.275}).wait(1).to({graphics:mask_graphics_104,x:190.25,y:152.05}).wait(1).to({graphics:mask_graphics_105,x:191.25,y:151.8}).wait(1).to({graphics:mask_graphics_106,x:192.3,y:151.55}).wait(1).to({graphics:mask_graphics_107,x:193.35,y:151.275}).wait(1).to({graphics:mask_graphics_108,x:194.4,y:151}).wait(1).to({graphics:mask_graphics_109,x:195.45,y:150.75}).wait(1).to({graphics:mask_graphics_110,x:196.55,y:150.475}).wait(1).to({graphics:mask_graphics_111,x:197.6,y:150.2}).wait(1).to({graphics:mask_graphics_112,x:198.625,y:149.95}).wait(1).to({graphics:mask_graphics_113,x:199.65,y:149.7}).wait(1).to({graphics:mask_graphics_114,x:200.675,y:149.45}).wait(1).to({graphics:mask_graphics_115,x:201.65,y:149.2}).wait(1).to({graphics:mask_graphics_116,x:202.6,y:148.95}).wait(1).to({graphics:mask_graphics_117,x:203.525,y:148.725}).wait(1).to({graphics:mask_graphics_118,x:204.375,y:148.5}).wait(1).to({graphics:mask_graphics_119,x:205.225,y:148.275}).wait(1).to({graphics:mask_graphics_120,x:206.025,y:148.1}).wait(1).to({graphics:mask_graphics_121,x:206.775,y:147.9}).wait(1).to({graphics:mask_graphics_122,x:207.475,y:147.725}).wait(1).to({graphics:mask_graphics_123,x:208.125,y:147.55}).wait(1).to({graphics:mask_graphics_124,x:208.75,y:147.4}).wait(1).to({graphics:mask_graphics_125,x:209.325,y:147.25}).wait(1).to({graphics:mask_graphics_126,x:209.875,y:147.125}).wait(1).to({graphics:mask_graphics_127,x:210.375,y:146.975}).wait(1).to({graphics:mask_graphics_128,x:210.85,y:146.875}).wait(1).to({graphics:mask_graphics_129,x:211.25,y:146.775}).wait(1).to({graphics:mask_graphics_130,x:211.625,y:146.675}).wait(1).to({graphics:mask_graphics_131,x:211.975,y:146.6}).wait(1).to({graphics:mask_graphics_132,x:212.275,y:146.525}).wait(1).to({graphics:mask_graphics_133,x:212.575,y:146.45}).wait(1).to({graphics:mask_graphics_134,x:212.8,y:146.375}).wait(1).to({graphics:mask_graphics_135,x:213,y:146.325}).wait(1).to({graphics:mask_graphics_136,x:213.2,y:146.275}).wait(1).to({graphics:mask_graphics_137,x:213.325,y:146.25}).wait(1).to({graphics:mask_graphics_138,x:213.45,y:146.225}).wait(1).to({graphics:mask_graphics_139,x:213.55,y:146.175}).wait(1).to({graphics:mask_graphics_140,x:213.625,y:146.175}).wait(79));

	// r guy i shadow
	this.instance_8 = new lib.roundshadow();
	this.instance_8.setTransform(212.15,-11.85,1,1,0,0,0,28.2,22.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(19).to({_off:false},0).to({x:189.4,y:78.35,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:189.2,y:78.05},0).wait(11).to({regX:28.2,regY:22.8,x:189.4,y:78.35},0).wait(1).to({regX:28,regY:22.5,scaleX:0.9983,scaleY:0.9983,x:189.8,y:78.15},0).wait(1).to({scaleX:0.9964,scaleY:0.9964,x:190.45,y:78.3},0).wait(1).to({scaleX:0.9944,scaleY:0.9944,x:191.15,y:78.45},0).wait(1).to({scaleX:0.9922,scaleY:0.9922,x:191.95,y:78.6},0).wait(1).to({scaleX:0.9899,scaleY:0.9899,x:192.75,y:78.8},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:193.65,y:79},0).wait(1).to({scaleX:0.9847,scaleY:0.9847,x:194.6,y:79.25},0).wait(1).to({scaleX:0.9818,scaleY:0.9818,x:195.6,y:79.45},0).wait(1).to({scaleX:0.9789,scaleY:0.9789,x:196.65,y:79.65},0).wait(1).to({scaleX:0.9757,scaleY:0.9757,x:197.75,y:79.95},0).wait(1).to({scaleX:0.9724,scaleY:0.9724,x:198.95,y:80.2},0).wait(1).to({scaleX:0.969,scaleY:0.969,x:200.15,y:80.45},0).wait(1).to({scaleX:0.9654,scaleY:0.9654,x:201.45,y:80.75},0).wait(1).to({scaleX:0.9617,scaleY:0.9617,x:202.75,y:81.05},0).wait(1).to({scaleX:0.9578,scaleY:0.9578,x:204.05,y:81.35},0).wait(1).to({scaleX:0.9539,scaleY:0.9539,x:205.45,y:81.65},0).wait(1).to({scaleX:0.9498,scaleY:0.9498,x:206.9,y:81.95},0).wait(1).to({scaleX:0.9457,scaleY:0.9457,x:208.4,y:82.35},0).wait(1).to({scaleX:0.9414,scaleY:0.9414,x:209.9,y:82.65},0).wait(1).to({scaleX:0.9371,scaleY:0.9371,x:211.4,y:83},0).wait(1).to({scaleX:0.9327,scaleY:0.9327,x:212.95,y:83.35},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:214.5,y:83.7},0).wait(1).to({scaleX:0.9239,scaleY:0.9239,x:216.05,y:84.05},0).wait(1).to({scaleX:0.9194,scaleY:0.9194,x:217.65,y:84.4},0).wait(1).to({scaleX:0.915,scaleY:0.915,x:219.2,y:84.75},0).wait(1).to({scaleX:0.9106,scaleY:0.9106,x:220.8,y:85.1},0).wait(1).to({scaleX:0.9062,scaleY:0.9062,x:222.35,y:85.45},0).wait(1).to({scaleX:0.9018,scaleY:0.9018,x:223.9,y:85.8},0).wait(1).to({scaleX:0.8975,scaleY:0.8975,x:225.4,y:86.1},0).wait(1).to({scaleX:0.8933,scaleY:0.8933,x:226.9,y:86.45},0).wait(1).to({scaleX:0.8892,scaleY:0.8892,x:228.35,y:86.75},0).wait(1).to({scaleX:0.8852,scaleY:0.8852,x:229.8,y:87.05},0).wait(1).to({scaleX:0.8813,scaleY:0.8813,x:231.15,y:87.4},0).wait(1).to({scaleX:0.8775,scaleY:0.8775,x:232.45,y:87.7},0).wait(1).to({scaleX:0.8738,scaleY:0.8738,x:233.75,y:87.95},0).wait(1).to({scaleX:0.8703,scaleY:0.8703,x:235,y:88.3},0).wait(1).to({scaleX:0.867,scaleY:0.867,x:236.2,y:88.5},0).wait(1).to({scaleX:0.8637,scaleY:0.8637,x:237.35,y:88.8},0).wait(1).to({scaleX:0.8607,scaleY:0.8607,x:238.45,y:89},0).wait(1).to({scaleX:0.8578,scaleY:0.8578,x:239.45,y:89.25},0).wait(1).to({scaleX:0.855,scaleY:0.855,x:240.45,y:89.5},0).wait(1).to({scaleX:0.8524,scaleY:0.8524,x:241.35,y:89.7},0).wait(1).to({scaleX:0.85,scaleY:0.85,x:242.2,y:89.85},0).wait(1).to({scaleX:0.8477,scaleY:0.8477,x:243.05,y:90},0).wait(1).to({scaleX:0.8456,scaleY:0.8456,x:243.8,y:90.25},0).wait(1).to({scaleX:0.8437,scaleY:0.8437,x:244.4,y:90.4},0).wait(1).to({scaleX:0.8419,scaleY:0.8419,x:245.05,y:90.5},0).wait(1).to({scaleX:0.8402,scaleY:0.8402,x:245.7,y:90.65},0).wait(1).to({scaleX:0.8388,scaleY:0.8388,x:246.2,y:90.75},0).wait(1).to({scaleX:0.8374,scaleY:0.8374,x:246.65,y:90.85},0).wait(1).to({scaleX:0.8363,scaleY:0.8363,x:247.05,y:90.95},0).wait(1).to({scaleX:0.8353,scaleY:0.8353,x:247.45,y:91.05},0).wait(1).to({scaleX:0.8344,scaleY:0.8344,x:247.7},0).wait(1).to({scaleX:0.8337,scaleY:0.8337,x:248,y:91.15},0).wait(1).to({scaleX:0.8331,scaleY:0.8331,x:248.2,y:91.2},0).wait(1).to({scaleX:0.8326,scaleY:0.8326,x:248.35,y:91.25},0).wait(1).to({scaleX:0.8323,scaleY:0.8323,x:248.45,y:91.3},0).wait(1).to({scaleX:0.8321,scaleY:0.8321,x:248.55,y:91.25},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.832,scaleY:0.832,x:248.75,y:91.55},0).wait(1).to({regX:28,regY:22.5,x:248.5,y:91.2},0).wait(15).to({regX:28.3,regY:22.9,x:248.75,y:91.55},0).wait(1).to({regX:28,regY:22.5,scaleX:0.8319,scaleY:0.8319,x:248.5,y:91.15},0).wait(1).to({scaleX:0.8317,scaleY:0.8317},0).wait(1).to({scaleX:0.8314,scaleY:0.8314,y:91.1},0).wait(1).to({scaleX:0.831,scaleY:0.831},0).wait(1).to({scaleX:0.8305,scaleY:0.8305,x:248.55,y:91.05},0).wait(1).to({scaleX:0.8298,scaleY:0.8298,y:90.95},0).wait(1).to({scaleX:0.8291,scaleY:0.8291,y:90.85},0).wait(1).to({scaleX:0.8281,scaleY:0.8281,x:248.65,y:90.8},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,y:90.65},0).wait(1).to({scaleX:0.8259,scaleY:0.8259,x:248.7,y:90.55},0).wait(1).to({scaleX:0.8245,scaleY:0.8245,x:248.75,y:90.35},0).wait(1).to({scaleX:0.8229,scaleY:0.8229,x:248.8,y:90.15},0).wait(1).to({scaleX:0.8211,scaleY:0.8211,x:248.9,y:89.95},0).wait(1).to({scaleX:0.819,scaleY:0.819,x:248.95,y:89.8},0).wait(1).to({scaleX:0.8167,scaleY:0.8167,x:249,y:89.5},0).wait(1).to({scaleX:0.8141,scaleY:0.8141,x:249.15,y:89.2},0).wait(1).to({scaleX:0.8111,scaleY:0.8111,x:249.25,y:88.9},0).wait(1).to({scaleX:0.8077,scaleY:0.8077,x:249.35,y:88.5},0).wait(1).to({scaleX:0.8039,scaleY:0.8039,x:249.5,y:88.1},0).wait(1).to({scaleX:0.7995,scaleY:0.7995,x:249.7,y:87.6},0).wait(1).to({scaleX:0.7944,scaleY:0.7944,x:249.9,y:87},0).wait(1).to({scaleX:0.7885,scaleY:0.7885,x:250.1,y:86.4},0).wait(1).to({scaleX:0.7816,scaleY:0.7816,x:250.35,y:85.65},0).wait(1).to({scaleX:0.7735,scaleY:0.7735,x:250.65,y:84.7},0).wait(1).to({scaleX:0.7637,scaleY:0.7637,x:251.05,y:83.65},0).wait(1).to({scaleX:0.7517,scaleY:0.7517,x:251.5,y:82.3},0).wait(1).to({scaleX:0.7367,scaleY:0.7367,x:252.05,y:80.65},0).wait(1).to({scaleX:0.7184,scaleY:0.7184,x:252.7,y:78.6},0).wait(1).to({scaleX:0.6971,scaleY:0.6971,x:253.5,y:76.25},0).wait(1).to({scaleX:0.6758,scaleY:0.6758,x:254.3,y:73.9},0).wait(1).to({scaleX:0.6571,scaleY:0.6571,x:255,y:71.85},0).wait(1).to({scaleX:0.6418,scaleY:0.6418,x:255.55,y:70.15},0).wait(1).to({scaleX:0.6294,scaleY:0.6294,x:256,y:68.75},0).wait(1).to({scaleX:0.6192,scaleY:0.6192,x:256.45,y:67.65},0).wait(1).to({scaleX:0.6107,scaleY:0.6107,x:256.75,y:66.7},0).wait(1).to({scaleX:0.6035,scaleY:0.6035,x:257,y:65.9},0).wait(1).to({scaleX:0.5972,scaleY:0.5972,x:257.2,y:65.2},0).wait(1).to({scaleX:0.5918,scaleY:0.5918,x:257.4,y:64.55},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:257.6,y:64.05},0).wait(1).to({scaleX:0.583,scaleY:0.583,x:257.75,y:63.6},0).wait(1).to({scaleX:0.5793,scaleY:0.5793,x:257.9,y:63.2},0).wait(1).to({scaleX:0.576,scaleY:0.576,x:258.05,y:62.8},0).wait(1).to({scaleX:0.5731,scaleY:0.5731,x:258.15,y:62.5},0).wait(1).to({scaleX:0.5705,scaleY:0.5705,x:258.2,y:62.25},0).wait(1).to({scaleX:0.5682,scaleY:0.5682,x:258.3,y:62},0).wait(1).to({scaleX:0.5661,scaleY:0.5661,x:258.4,y:61.75},0).wait(1).to({scaleX:0.5642,scaleY:0.5642,x:258.45,y:61.55},0).wait(1).to({scaleX:0.5626,scaleY:0.5626,x:258.55,y:61.35},0).wait(1).to({scaleX:0.5611,scaleY:0.5611,y:61.15},0).wait(1).to({scaleX:0.5598,scaleY:0.5598,x:258.6,y:61.05},0).wait(1).to({scaleX:0.5586,scaleY:0.5586,x:258.7,y:60.9},0).wait(1).to({scaleX:0.5576,scaleY:0.5576,y:60.8},0).wait(1).to({scaleX:0.5567,scaleY:0.5567,x:258.75,y:60.7},0).wait(1).to({scaleX:0.556,scaleY:0.556,y:60.6},0).wait(1).to({scaleX:0.5553,scaleY:0.5553,x:258.8,y:60.55},0).wait(1).to({scaleX:0.5548,scaleY:0.5548,x:258.85,y:60.5},0).wait(1).to({scaleX:0.5544,scaleY:0.5544,x:258.8,y:60.4},0).wait(1).to({scaleX:0.554,scaleY:0.554,x:258.85},0).wait(1).to({scaleX:0.5537,scaleY:0.5537,y:60.35},0).wait(1).to({scaleX:0.5535,scaleY:0.5535},0).wait(1).to({scaleX:0.5534,scaleY:0.5534},0).wait(1).to({regX:28.3,regY:22.9,x:259.05,y:60.55},0).wait(1));

	// l guy i shadow
	this.instance_9 = new lib.roundshadow();
	this.instance_9.setTransform(-92.55,143.1,1,1,0,0,0,28.2,22.8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(25).to({_off:false},0).to({x:64.5,y:98.65,alpha:0.1602},45,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:64.3,y:98.35},0).wait(12).to({regX:28.2,regY:22.8,x:64.5,y:98.65},0).wait(1).to({regX:28,regY:22.5,scaleX:0.9962,scaleY:0.9962,x:65.9,y:98.5},0).wait(1).to({scaleX:0.992,scaleY:0.992,x:67.65,y:98.75},0).wait(1).to({scaleX:0.9875,scaleY:0.9875,x:69.55,y:98.95},0).wait(1).to({scaleX:0.9826,scaleY:0.9826,x:71.55,y:99.25},0).wait(1).to({scaleX:0.9773,scaleY:0.9773,x:73.75,y:99.55},0).wait(1).to({scaleX:0.9717,scaleY:0.9717,x:76.1,y:99.8},0).wait(1).to({scaleX:0.9658,scaleY:0.9658,x:78.65,y:100.15},0).wait(1).to({scaleX:0.9594,scaleY:0.9594,x:81.25,y:100.5},0).wait(1).to({scaleX:0.9528,scaleY:0.9528,x:84.1,y:100.85},0).wait(1).to({scaleX:0.9458,scaleY:0.9458,x:87.05,y:101.2},0).wait(1).to({scaleX:0.9384,scaleY:0.9384,x:90.1,y:101.6},0).wait(1).to({scaleX:0.9307,scaleY:0.9307,x:93.3,y:102},0).wait(1).to({scaleX:0.9227,scaleY:0.9227,x:96.7,y:102.4},0).wait(1).to({scaleX:0.9144,scaleY:0.9144,x:100.15,y:102.85},0).wait(1).to({scaleX:0.9059,scaleY:0.9059,x:103.7,y:103.35},0).wait(1).to({scaleX:0.897,scaleY:0.897,x:107.4,y:103.8},0).wait(1).to({scaleX:0.888,scaleY:0.888,x:111.2,y:104.3},0).wait(1).to({scaleX:0.8787,scaleY:0.8787,x:115.15,y:104.75},0).wait(1).to({scaleX:0.8692,scaleY:0.8692,x:119.1,y:105.25},0).wait(1).to({scaleX:0.8596,scaleY:0.8596,x:123.1,y:105.8},0).wait(1).to({scaleX:0.8498,scaleY:0.8498,x:127.25,y:106.25},0).wait(1).to({scaleX:0.84,scaleY:0.84,x:131.35,y:106.8},0).wait(1).to({scaleX:0.8301,scaleY:0.8301,x:135.5,y:107.35},0).wait(1).to({scaleX:0.8201,scaleY:0.8201,x:139.65,y:107.85},0).wait(1).to({scaleX:0.8102,scaleY:0.8102,x:143.85,y:108.4},0).wait(1).to({scaleX:0.8003,scaleY:0.8003,x:148,y:108.9},0).wait(1).to({scaleX:0.7905,scaleY:0.7905,x:152.1,y:109.45},0).wait(1).to({scaleX:0.7808,scaleY:0.7808,x:156.15,y:109.95},0).wait(1).to({scaleX:0.7712,scaleY:0.7712,x:160.2,y:110.45},0).wait(1).to({scaleX:0.7618,scaleY:0.7618,x:164.15,y:110.95},0).wait(1).to({scaleX:0.7526,scaleY:0.7526,x:167.95,y:111.45},0).wait(1).to({scaleX:0.7437,scaleY:0.7437,x:171.7,y:111.95},0).wait(1).to({scaleX:0.7349,scaleY:0.7349,x:175.4,y:112.4},0).wait(1).to({scaleX:0.7265,scaleY:0.7265,x:178.9,y:112.85},0).wait(1).to({scaleX:0.7183,scaleY:0.7183,x:182.3,y:113.25},0).wait(1).to({scaleX:0.7105,scaleY:0.7105,x:185.65,y:113.7},0).wait(1).to({scaleX:0.703,scaleY:0.703,x:188.8,y:114.05},0).wait(1).to({scaleX:0.6958,scaleY:0.6958,x:191.8,y:114.45},0).wait(1).to({scaleX:0.6889,scaleY:0.6889,x:194.65,y:114.85},0).wait(1).to({scaleX:0.6824,scaleY:0.6824,x:197.4,y:115.15},0).wait(1).to({scaleX:0.6763,scaleY:0.6763,x:200,y:115.5},0).wait(1).to({scaleX:0.6705,scaleY:0.6705,x:202.35,y:115.8},0).wait(1).to({scaleX:0.6651,scaleY:0.6651,x:204.65,y:116.1},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:206.8,y:116.35},0).wait(1).to({scaleX:0.6553,scaleY:0.6553,x:208.75,y:116.6},0).wait(1).to({scaleX:0.6509,scaleY:0.6509,x:210.6,y:116.85},0).wait(1).to({scaleX:0.647,scaleY:0.647,x:212.25,y:117.05},0).wait(1).to({scaleX:0.6433,scaleY:0.6433,x:213.75,y:117.2},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:215.15,y:117.4},0).wait(1).to({scaleX:0.6371,scaleY:0.6371,x:216.4,y:117.6},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:217.45,y:117.75},0).wait(1).to({scaleX:0.6322,scaleY:0.6322,x:218.45,y:117.8},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:219.25,y:117.95},0).wait(1).to({scaleX:0.6286,scaleY:0.6286,x:219.95,y:118.05},0).wait(1).to({scaleX:0.6273,scaleY:0.6273,x:220.5,y:118.1},0).wait(1).to({scaleX:0.6263,scaleY:0.6263,x:220.95,y:118.15},0).wait(1).to({scaleX:0.6256,scaleY:0.6256,x:221.2,y:118.2},0).wait(1).to({scaleX:0.6251,scaleY:0.6251,x:221.4},0).wait(1).to({regX:28.2,regY:22.8,scaleX:0.625,scaleY:0.625,x:221.6,y:118.4},0).wait(1).to({regX:28,regY:22.5,x:221.45,y:118.2},0).wait(15).to({regX:28.2,regY:22.8,x:221.6,y:118.4},0).wait(1).to({regX:28,regY:22.5,x:221.4,y:118.15},0).wait(1).to({scaleX:0.6249,scaleY:0.6249,x:221.35,y:118.1},0).wait(1).to({x:221.25},0).wait(1).to({scaleX:0.6248,scaleY:0.6248,x:221.15,y:118},0).wait(1).to({scaleX:0.6247,scaleY:0.6247,x:221.05,y:117.95},0).wait(1).to({scaleX:0.6246,scaleY:0.6246,x:220.9,y:117.85},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:220.7,y:117.7},0).wait(1).to({scaleX:0.6242,scaleY:0.6242,x:220.45,y:117.55},0).wait(1).to({scaleX:0.624,scaleY:0.624,x:220.15,y:117.4},0).wait(1).to({scaleX:0.6237,scaleY:0.6237,x:219.8,y:117.2},0).wait(1).to({scaleX:0.6234,scaleY:0.6234,x:219.45,y:117},0).wait(1).to({scaleX:0.6231,scaleY:0.6231,x:219,y:116.65},0).wait(1).to({scaleX:0.6227,scaleY:0.6227,x:218.5,y:116.35},0).wait(1).to({scaleX:0.6222,scaleY:0.6222,x:217.9,y:116},0).wait(1).to({scaleX:0.6217,scaleY:0.6217,x:217.25,y:115.6},0).wait(1).to({scaleX:0.6211,scaleY:0.6211,x:216.45,y:115.05},0).wait(1).to({scaleX:0.6203,scaleY:0.6203,x:215.5,y:114.5},0).wait(1).to({scaleX:0.6195,scaleY:0.6195,x:214.45,y:113.85},0).wait(1).to({scaleX:0.6184,scaleY:0.6184,x:213.15,y:113},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:211.6,y:112.05},0).wait(1).to({scaleX:0.6157,scaleY:0.6157,x:209.7,y:110.85},0).wait(1).to({scaleX:0.6138,scaleY:0.6138,x:207.25,y:109.35},0).wait(1).to({scaleX:0.6113,scaleY:0.6113,x:204.15,y:107.4},0).wait(1).to({scaleX:0.6082,scaleY:0.6082,x:200.25,y:105},0).wait(1).to({scaleX:0.6045,scaleY:0.6045,x:195.65,y:102.1},0).wait(1).to({scaleX:0.6011,scaleY:0.6011,x:191.3,y:99.4},0).wait(1).to({scaleX:0.5983,scaleY:0.5983,x:187.75,y:97.2},0).wait(1).to({scaleX:0.5961,scaleY:0.5961,x:184.95,y:95.45},0).wait(1).to({scaleX:0.5943,scaleY:0.5943,x:182.75,y:94.05},0).wait(1).to({scaleX:0.5929,scaleY:0.5929,x:180.95,y:92.95},0).wait(1).to({scaleX:0.5917,scaleY:0.5917,x:179.45,y:92},0).wait(1).to({scaleX:0.5907,scaleY:0.5907,x:178.25,y:91.25},0).wait(1).to({scaleX:0.5899,scaleY:0.5899,x:177.15,y:90.55},0).wait(1).to({scaleX:0.5891,scaleY:0.5891,x:176.25,y:90},0).wait(1).to({scaleX:0.5885,scaleY:0.5885,x:175.45,y:89.55},0).wait(1).to({scaleX:0.588,scaleY:0.588,x:174.75,y:89.1},0).wait(1).to({scaleX:0.5875,scaleY:0.5875,x:174.15,y:88.7},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:173.65,y:88.4},0).wait(1).to({scaleX:0.5867,scaleY:0.5867,x:173.2,y:88.1},0).wait(1).to({scaleX:0.5864,scaleY:0.5864,x:172.75,y:87.85},0).wait(1).to({scaleX:0.5861,scaleY:0.5861,x:172.4,y:87.65},0).wait(1).to({scaleX:0.5859,scaleY:0.5859,x:172.1,y:87.45},0).wait(1).to({scaleX:0.5856,scaleY:0.5856,x:171.85,y:87.3},0).wait(1).to({scaleX:0.5855,scaleY:0.5855,x:171.6,y:87.1},0).wait(1).to({scaleX:0.5853,scaleY:0.5853,x:171.4,y:87},0).wait(1).to({scaleX:0.5852,scaleY:0.5852,x:171.25,y:86.9},0).wait(1).to({scaleX:0.5851,scaleY:0.5851,x:171.1,y:86.8},0).wait(1).to({scaleX:0.585,scaleY:0.585,x:171,y:86.75},0).wait(1).to({scaleX:0.5849,scaleY:0.5849,x:170.9,y:86.65},0).wait(1).to({scaleX:0.5848,scaleY:0.5848,x:170.85},0).wait(1).to({x:170.75,y:86.6},0).wait(1).to({x:170.7},0).wait(1).to({regX:28.4,regY:22.9,x:170.9,y:86.8},0).wait(8));

	// r girl i shadow
	this.instance_10 = new lib.roundshadow();
	this.instance_10.setTransform(221.7,324.1,1,1,0,0,0,28.2,22.8);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(14).to({_off:false},0).to({x:154.3,y:253,alpha:0.1602},53,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:154.65,y:252},0).wait(1).to({x:155.2,y:251.3},0).wait(1).to({x:155.75,y:250.6},0).wait(1).to({x:156.35,y:249.9},0).wait(1).to({x:156.9,y:249.2},0).wait(1).to({x:157.5,y:248.5},0).wait(1).to({x:158.05,y:247.8},0).wait(1).to({x:158.65,y:247.1},0).wait(1).to({x:159.2,y:246.4},0).wait(1).to({x:159.8,y:245.65},0).wait(1).to({x:160.4,y:244.95},0).wait(1).to({x:161,y:244.2},0).wait(1).to({x:161.6,y:243.5},0).wait(1).to({x:162.2,y:242.75},0).wait(1).to({x:162.8,y:242},0).wait(1).to({x:163.4,y:241.25},0).wait(1).to({x:164,y:240.55},0).wait(1).to({regX:28.2,regY:22.8,x:164.85,y:240.1},0).wait(1).to({regX:28,regY:22.5,scaleX:0.9982,scaleY:0.9982,x:165.35,y:239.25},0).wait(1).to({scaleX:0.9963,scaleY:0.9963,x:166.1,y:238.65},0).wait(1).to({scaleX:0.9941,scaleY:0.9941,x:166.95,y:238.05},0).wait(1).to({scaleX:0.9918,scaleY:0.9918,x:167.8,y:237.35},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:168.8,y:236.65},0).wait(1).to({scaleX:0.9867,scaleY:0.9867,x:169.85,y:235.9},0).wait(1).to({scaleX:0.9839,scaleY:0.9839,x:170.95,y:235.1},0).wait(1).to({scaleX:0.981,scaleY:0.981,x:172.1,y:234.15},0).wait(1).to({scaleX:0.9778,scaleY:0.9778,x:173.35,y:233.3},0).wait(1).to({scaleX:0.9746,scaleY:0.9746,x:174.65,y:232.35},0).wait(1).to({scaleX:0.9711,scaleY:0.9711,x:176,y:231.3},0).wait(1).to({scaleX:0.9675,scaleY:0.9675,x:177.4,y:230.25},0).wait(1).to({scaleX:0.9638,scaleY:0.9638,x:178.9,y:229.15},0).wait(1).to({scaleX:0.9599,scaleY:0.9599,x:180.45,y:228},0).wait(1).to({scaleX:0.9558,scaleY:0.9558,x:182,y:226.8},0).wait(1).to({scaleX:0.9517,scaleY:0.9517,x:183.6,y:225.6},0).wait(1).to({scaleX:0.9474,scaleY:0.9474,x:185.3,y:224.35},0).wait(1).to({scaleX:0.9431,scaleY:0.9431,x:187,y:223.05},0).wait(1).to({scaleX:0.9386,scaleY:0.9386,x:188.75,y:221.75},0).wait(1).to({scaleX:0.9341,scaleY:0.9341,x:190.5,y:220.45},0).wait(1).to({scaleX:0.9295,scaleY:0.9295,x:192.35,y:219.1},0).wait(1).to({scaleX:0.9249,scaleY:0.9249,x:194.15,y:217.75},0).wait(1).to({scaleX:0.9203,scaleY:0.9203,x:195.95,y:216.4},0).wait(1).to({scaleX:0.9156,scaleY:0.9156,x:197.8,y:215.05},0).wait(1).to({scaleX:0.9109,scaleY:0.9109,x:199.65,y:213.7},0).wait(1).to({scaleX:0.9063,scaleY:0.9063,x:201.5,y:212.3},0).wait(1).to({scaleX:0.9017,scaleY:0.9017,x:203.3,y:210.95},0).wait(1).to({scaleX:0.8971,scaleY:0.8971,x:205.05,y:209.65},0).wait(1).to({scaleX:0.8926,scaleY:0.8926,x:206.85,y:208.35},0).wait(1).to({scaleX:0.8882,scaleY:0.8882,x:208.55,y:207.05},0).wait(1).to({scaleX:0.8839,scaleY:0.8839,x:210.25,y:205.75},0).wait(1).to({scaleX:0.8797,scaleY:0.8797,x:211.95,y:204.55},0).wait(1).to({scaleX:0.8756,scaleY:0.8756,x:213.5,y:203.3},0).wait(1).to({scaleX:0.8717,scaleY:0.8717,x:215.05,y:202.15},0).wait(1).to({scaleX:0.8678,scaleY:0.8678,x:216.6,y:201.05},0).wait(1).to({scaleX:0.8642,scaleY:0.8642,x:218.05,y:199.95},0).wait(1).to({scaleX:0.8606,scaleY:0.8606,x:219.4,y:198.9},0).wait(1).to({scaleX:0.8572,scaleY:0.8572,x:220.75,y:197.95},0).wait(1).to({scaleX:0.854,scaleY:0.854,x:222,y:197},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:223.25,y:196.1},0).wait(1).to({scaleX:0.8481,scaleY:0.8481,x:224.35,y:195.3},0).wait(1).to({scaleX:0.8454,scaleY:0.8454,x:225.4,y:194.45},0).wait(1).to({scaleX:0.8428,scaleY:0.8428,x:226.4,y:193.7},0).wait(1).to({scaleX:0.8405,scaleY:0.8405,x:227.35,y:193},0).wait(1).to({scaleX:0.8383,scaleY:0.8383,x:228.2,y:192.35},0).wait(1).to({scaleX:0.8362,scaleY:0.8362,x:229,y:191.75},0).wait(1).to({scaleX:0.8343,scaleY:0.8343,x:229.75,y:191.2},0).wait(1).to({scaleX:0.8326,scaleY:0.8326,x:230.4,y:190.75},0).wait(1).to({scaleX:0.8311,scaleY:0.8311,x:231,y:190.25},0).wait(1).to({scaleX:0.8297,scaleY:0.8297,x:231.6,y:189.85},0).wait(1).to({scaleX:0.8285,scaleY:0.8285,x:232.05,y:189.5},0).wait(1).to({scaleX:0.8274,scaleY:0.8274,x:232.45,y:189.2},0).wait(1).to({scaleX:0.8265,scaleY:0.8265,x:232.85,y:188.95},0).wait(1).to({scaleX:0.8257,scaleY:0.8257,x:233.1,y:188.75},0).wait(1).to({scaleX:0.8251,scaleY:0.8251,x:233.35,y:188.5},0).wait(1).to({scaleX:0.8246,scaleY:0.8246,x:233.55,y:188.4},0).wait(1).to({scaleX:0.8243,scaleY:0.8243,x:233.7,y:188.3},0).wait(1).to({scaleX:0.8241,scaleY:0.8241,x:233.75,y:188.25},0).wait(1).to({regX:28.2,regY:22.8,scaleX:0.824,scaleY:0.824,x:234,y:188.45},0).wait(1).to({regX:28,regY:22.5,x:233.8,y:188.2},0).wait(15).to({regX:28.2,regY:22.8,x:234,y:188.45},0).wait(1).to({regX:28,regY:22.5,scaleX:0.8239,scaleY:0.8239,x:233.75,y:188.1},0).wait(1).to({scaleX:0.8237,scaleY:0.8237,y:188.05},0).wait(1).to({scaleX:0.8234,scaleY:0.8234,x:233.7,y:187.9},0).wait(1).to({scaleX:0.8229,scaleY:0.8229,x:233.65,y:187.7},0).wait(1).to({scaleX:0.8224,scaleY:0.8224,x:233.6,y:187.45},0).wait(1).to({scaleX:0.8217,scaleY:0.8217,x:233.5,y:187.2},0).wait(1).to({scaleX:0.8208,scaleY:0.8208,x:233.4,y:186.8},0).wait(1).to({scaleX:0.8198,scaleY:0.8198,x:233.25,y:186.4},0).wait(1).to({scaleX:0.8187,scaleY:0.8187,x:233.1,y:185.9},0).wait(1).to({scaleX:0.8174,scaleY:0.8174,x:232.95,y:185.35},0).wait(1).to({scaleX:0.8158,scaleY:0.8158,x:232.75,y:184.7},0).wait(1).to({scaleX:0.814,scaleY:0.814,x:232.55,y:183.95},0).wait(1).to({scaleX:0.812,scaleY:0.812,x:232.3,y:183.05},0).wait(1).to({scaleX:0.8097,scaleY:0.8097,x:231.95,y:182.1},0).wait(1).to({scaleX:0.807,scaleY:0.807,x:231.65,y:181},0).wait(1).to({scaleX:0.804,scaleY:0.804,x:231.25,y:179.7},0).wait(1).to({scaleX:0.8005,scaleY:0.8005,x:230.85,y:178.25},0).wait(1).to({scaleX:0.7965,scaleY:0.7965,x:230.35,y:176.55},0).wait(1).to({scaleX:0.7919,scaleY:0.7919,x:229.75,y:174.6},0).wait(1).to({scaleX:0.7865,scaleY:0.7865,x:229.05,y:172.35},0).wait(1).to({scaleX:0.7802,scaleY:0.7802,x:228.3,y:169.7},0).wait(1).to({scaleX:0.7727,scaleY:0.7727,x:227.35,y:166.55},0).wait(1).to({scaleX:0.7636,scaleY:0.7636,x:226.2,y:162.7},0).wait(1).to({scaleX:0.7524,scaleY:0.7524,x:224.8,y:157.95},0).wait(1).to({scaleX:0.7383,scaleY:0.7383,x:223,y:152},0).wait(1).to({scaleX:0.7207,scaleY:0.7207,x:220.85,y:144.55},0).wait(1).to({scaleX:0.6996,scaleY:0.6996,x:218.15,y:135.7},0).wait(1).to({scaleX:0.678,scaleY:0.678,x:215.45,y:126.55},0).wait(1).to({scaleX:0.659,scaleY:0.659,x:213.05,y:118.6},0).wait(1).to({scaleX:0.6437,scaleY:0.6437,x:211.1,y:112.1},0).wait(1).to({scaleX:0.6315,scaleY:0.6315,x:209.6,y:106.95},0).wait(1).to({scaleX:0.6215,scaleY:0.6215,x:208.35,y:102.75},0).wait(1).to({scaleX:0.6133,scaleY:0.6133,x:207.3,y:99.25},0).wait(1).to({scaleX:0.6063,scaleY:0.6063,x:206.45,y:96.35},0).wait(1).to({scaleX:0.6004,scaleY:0.6004,x:205.7,y:93.8},0).wait(1).to({scaleX:0.5953,scaleY:0.5953,x:205.05,y:91.65},0).wait(1).to({scaleX:0.5908,scaleY:0.5908,x:204.5,y:89.8},0).wait(1).to({scaleX:0.5869,scaleY:0.5869,x:204,y:88.1},0).wait(1).to({scaleX:0.5834,scaleY:0.5834,x:203.55,y:86.7},0).wait(1).to({scaleX:0.5804,scaleY:0.5804,x:203.2,y:85.4},0).wait(1).to({scaleX:0.5777,scaleY:0.5777,x:202.85,y:84.25},0).wait(1).to({scaleX:0.5753,scaleY:0.5753,x:202.55,y:83.25},0).wait(1).to({scaleX:0.5732,scaleY:0.5732,x:202.3,y:82.35},0).wait(1).to({scaleX:0.5714,scaleY:0.5714,x:202.05,y:81.55},0).wait(1).to({scaleX:0.5697,scaleY:0.5697,x:201.85,y:80.85},0).wait(1).to({scaleX:0.5682,scaleY:0.5682,x:201.65,y:80.3},0).wait(1).to({scaleX:0.567,scaleY:0.567,x:201.45,y:79.7},0).wait(1).to({scaleX:0.5658,scaleY:0.5658,x:201.35,y:79.25},0).wait(1).to({scaleX:0.5649,scaleY:0.5649,x:201.2,y:78.85},0).wait(1).to({scaleX:0.564,scaleY:0.564,x:201.15,y:78.5},0).wait(1).to({scaleX:0.5633,scaleY:0.5633,x:201,y:78.15},0).wait(1).to({scaleX:0.5627,scaleY:0.5627,x:200.95,y:77.95},0).wait(1).to({scaleX:0.5622,scaleY:0.5622,x:200.9,y:77.75},0).wait(1).to({scaleX:0.5619,scaleY:0.5619,x:200.85,y:77.6},0).wait(1).to({scaleX:0.5616,scaleY:0.5616,x:200.8,y:77.45},0).wait(1).to({scaleX:0.5614,scaleY:0.5614,x:200.75,y:77.4},0).wait(1).to({scaleX:0.5613,scaleY:0.5613,y:77.35},0).wait(1).to({regX:28.2,regY:22.8,scaleX:0.5612,scaleY:0.5612,x:200.9,y:77.5},0).wait(1));

	// l girl i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(-105.9,239.95,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({x:50.3,y:193.35,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:50.1,y:193.05},0).wait(19).to({regX:28.2,regY:22.8,x:50.3,y:193.35},0).wait(1).to({regX:28,regY:22.5,scaleX:0.9962,scaleY:0.9962,x:51.85,y:192.55},0).wait(1).to({scaleX:0.992,scaleY:0.992,x:53.8,y:192.05},0).wait(1).to({scaleX:0.9875,scaleY:0.9875,x:55.85,y:191.5},0).wait(1).to({scaleX:0.9826,scaleY:0.9826,x:58.1,y:190.9},0).wait(1).to({scaleX:0.9773,scaleY:0.9773,x:60.55,y:190.25},0).wait(1).to({scaleX:0.9717,scaleY:0.9717,x:63.15,y:189.55},0).wait(1).to({scaleX:0.9658,scaleY:0.9658,x:65.9,y:188.9},0).wait(1).to({scaleX:0.9594,scaleY:0.9594,x:68.8,y:188.1},0).wait(1).to({scaleX:0.9528,scaleY:0.9528,x:71.9,y:187.3},0).wait(1).to({scaleX:0.9458,scaleY:0.9458,x:75.15,y:186.45},0).wait(1).to({scaleX:0.9384,scaleY:0.9384,x:78.55,y:185.5},0).wait(1).to({scaleX:0.9307,scaleY:0.9307,x:82.05,y:184.6},0).wait(1).to({scaleX:0.9227,scaleY:0.9227,x:85.8,y:183.6},0).wait(1).to({scaleX:0.9144,scaleY:0.9144,x:89.6,y:182.6},0).wait(1).to({scaleX:0.9059,scaleY:0.9059,x:93.55,y:181.6},0).wait(1).to({scaleX:0.897,scaleY:0.897,x:97.6,y:180.5},0).wait(1).to({scaleX:0.888,scaleY:0.888,x:101.8,y:179.4},0).wait(1).to({scaleX:0.8787,scaleY:0.8787,x:106.1,y:178.25},0).wait(1).to({scaleX:0.8692,scaleY:0.8692,x:110.5,y:177.1},0).wait(1).to({scaleX:0.8596,scaleY:0.8596,x:114.95,y:175.95},0).wait(1).to({scaleX:0.8498,scaleY:0.8498,x:119.45,y:174.7},0).wait(1).to({scaleX:0.84,scaleY:0.84,x:124,y:173.55},0).wait(1).to({scaleX:0.8301,scaleY:0.8301,x:128.6,y:172.35},0).wait(1).to({scaleX:0.8201,scaleY:0.8201,x:133.15,y:171.1},0).wait(1).to({scaleX:0.8102,scaleY:0.8102,x:137.8,y:169.95},0).wait(1).to({scaleX:0.8003,scaleY:0.8003,x:142.3,y:168.7},0).wait(1).to({scaleX:0.7905,scaleY:0.7905,x:146.9,y:167.55},0).wait(1).to({scaleX:0.7808,scaleY:0.7808,x:151.35,y:166.3},0).wait(1).to({scaleX:0.7712,scaleY:0.7712,x:155.75,y:165.15},0).wait(1).to({scaleX:0.7618,scaleY:0.7618,x:160.1,y:164.05},0).wait(1).to({scaleX:0.7526,scaleY:0.7526,x:164.35,y:162.9},0).wait(1).to({scaleX:0.7437,scaleY:0.7437,x:168.45,y:161.85},0).wait(1).to({scaleX:0.7349,scaleY:0.7349,x:172.55,y:160.75},0).wait(1).to({scaleX:0.7265,scaleY:0.7265,x:176.45,y:159.75},0).wait(1).to({scaleX:0.7183,scaleY:0.7183,x:180.15,y:158.7},0).wait(1).to({scaleX:0.7105,scaleY:0.7105,x:183.8,y:157.8},0).wait(1).to({scaleX:0.703,scaleY:0.703,x:187.3,y:156.85},0).wait(1).to({scaleX:0.6958,scaleY:0.6958,x:190.65,y:156},0).wait(1).to({scaleX:0.6889,scaleY:0.6889,x:193.8,y:155.15},0).wait(1).to({scaleX:0.6824,scaleY:0.6824,x:196.75,y:154.35},0).wait(1).to({scaleX:0.6763,scaleY:0.6763,x:199.65,y:153.6},0).wait(1).to({scaleX:0.6705,scaleY:0.6705,x:202.25,y:152.9},0).wait(1).to({scaleX:0.6651,scaleY:0.6651,x:204.8,y:152.25},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:207.15,y:151.65},0).wait(1).to({scaleX:0.6553,scaleY:0.6553,x:209.3,y:151.05},0).wait(1).to({scaleX:0.6509,scaleY:0.6509,x:211.35,y:150.55},0).wait(1).to({scaleX:0.647,scaleY:0.647,x:213.15,y:150.05},0).wait(1).to({scaleX:0.6433,scaleY:0.6433,x:214.85,y:149.55},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:216.35,y:149.2},0).wait(1).to({scaleX:0.6371,scaleY:0.6371,x:217.75,y:148.85},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:218.9,y:148.55},0).wait(1).to({scaleX:0.6322,scaleY:0.6322,x:220,y:148.2},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:220.9,y:148.05},0).wait(1).to({scaleX:0.6286,scaleY:0.6286,x:221.65,y:147.8},0).wait(1).to({scaleX:0.6273,scaleY:0.6273,x:222.25,y:147.65},0).wait(1).to({scaleX:0.6263,scaleY:0.6263,x:222.75,y:147.55},0).wait(1).to({scaleX:0.6256,scaleY:0.6256,x:223.05,y:147.45},0).wait(1).to({scaleX:0.6251,scaleY:0.6251,x:223.25,y:147.35},0).wait(1).to({regX:28.2,regY:22.8,scaleX:0.625,scaleY:0.625,x:223.45,y:147.55},0).wait(1).to({regX:28,regY:22.5,x:223.3,y:147.35},0).wait(15).to({regX:28.2,regY:22.8,x:223.45,y:147.55},0).wait(1).to({regX:28,regY:22.5,x:223.3,y:147.3},0).wait(1).to({scaleX:0.6249,scaleY:0.6249,y:147.2},0).wait(1).to({scaleX:0.6248,scaleY:0.6248,y:147.1},0).wait(1).to({scaleX:0.6247,scaleY:0.6247,y:146.95},0).wait(1).to({scaleX:0.6245,scaleY:0.6245,x:223.35,y:146.8},0).wait(1).to({scaleX:0.6243,scaleY:0.6243,y:146.6},0).wait(1).to({scaleX:0.6241,scaleY:0.6241,y:146.3},0).wait(1).to({scaleX:0.6238,scaleY:0.6238,y:146},0).wait(1).to({scaleX:0.6234,scaleY:0.6234,x:223.4,y:145.65},0).wait(1).to({scaleX:0.6231,scaleY:0.6231,x:223.45,y:145.15},0).wait(1).to({scaleX:0.6226,scaleY:0.6226,x:223.5,y:144.65},0).wait(1).to({scaleX:0.6221,scaleY:0.6221,y:144.1},0).wait(1).to({scaleX:0.6215,scaleY:0.6215,x:223.6,y:143.45},0).wait(1).to({scaleX:0.6208,scaleY:0.6208,x:223.65,y:142.6},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:223.7,y:141.75},0).wait(1).to({scaleX:0.6191,scaleY:0.6191,x:223.8,y:140.75},0).wait(1).to({scaleX:0.618,scaleY:0.618,x:223.9,y:139.55},0).wait(1).to({scaleX:0.6168,scaleY:0.6168,x:224,y:138.25},0).wait(1).to({scaleX:0.6154,scaleY:0.6154,x:224.15,y:136.65},0).wait(1).to({scaleX:0.6137,scaleY:0.6137,x:224.3,y:134.75},0).wait(1).to({scaleX:0.6117,scaleY:0.6117,x:224.5,y:132.5},0).wait(1).to({scaleX:0.6093,scaleY:0.6093,x:224.65,y:129.8},0).wait(1).to({scaleX:0.6062,scaleY:0.6062,x:224.9,y:126.5},0).wait(1).to({scaleX:0.6025,scaleY:0.6025,x:225.25,y:122.25},0).wait(1).to({scaleX:0.5976,scaleY:0.5976,x:225.75,y:116.95},0).wait(1).to({scaleX:0.5918,scaleY:0.5918,x:226.2,y:110.45},0).wait(1).to({scaleX:0.5858,scaleY:0.5858,x:226.75,y:103.75},0).wait(1).to({scaleX:0.5805,scaleY:0.5805,x:227.25,y:97.8},0).wait(1).to({scaleX:0.5762,scaleY:0.5762,x:227.65,y:93.1},0).wait(1).to({scaleX:0.5728,scaleY:0.5728,x:227.95,y:89.35},0).wait(1).to({scaleX:0.5701,scaleY:0.5701,x:228.15,y:86.35},0).wait(1).to({scaleX:0.5679,scaleY:0.5679,x:228.35,y:83.85},0).wait(1).to({scaleX:0.566,scaleY:0.566,x:228.55,y:81.75},0).wait(1).to({scaleX:0.5644,scaleY:0.5644,x:228.7,y:79.95},0).wait(1).to({scaleX:0.563,scaleY:0.563,x:228.8,y:78.4},0).wait(1).to({scaleX:0.5618,scaleY:0.5618,x:228.95,y:77.05},0).wait(1).to({scaleX:0.5607,scaleY:0.5607,x:229,y:75.9},0).wait(1).to({scaleX:0.5598,scaleY:0.5598,x:229.05,y:74.9},0).wait(1).to({scaleX:0.559,scaleY:0.559,x:229.15,y:74},0).wait(1).to({scaleX:0.5583,scaleY:0.5583,x:229.25,y:73.15},0).wait(1).to({scaleX:0.5577,scaleY:0.5577,y:72.5},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:229.35,y:71.9},0).wait(1).to({scaleX:0.5566,scaleY:0.5566,x:229.4,y:71.3},0).wait(1).to({scaleX:0.5562,scaleY:0.5562,y:70.85},0).wait(1).to({scaleX:0.5558,scaleY:0.5558,x:229.45,y:70.4},0).wait(1).to({scaleX:0.5555,scaleY:0.5555,y:70.05},0).wait(1).to({scaleX:0.5552,scaleY:0.5552,x:229.5,y:69.75},0).wait(1).to({scaleX:0.555,scaleY:0.555,x:229.55,y:69.5},0).wait(1).to({scaleX:0.5547,scaleY:0.5547,y:69.25},0).wait(1).to({scaleX:0.5546,scaleY:0.5546,y:69.05},0).wait(1).to({scaleX:0.5544,scaleY:0.5544,y:68.85},0).wait(1).to({scaleX:0.5543,scaleY:0.5543,y:68.75},0).wait(1).to({scaleX:0.5542,scaleY:0.5542,y:68.65},0).wait(1).to({y:68.6},0).wait(1).to({scaleX:0.5541,scaleY:0.5541,y:68.55},0).wait(1).to({regX:28.2,regY:23,x:229.75,y:68.75},0).wait(2));

	// l girl box shadow
	this.instance_12 = new lib.squareshadow();
	this.instance_12.setTransform(-54.5,241.45,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(9).to({_off:false},0).to({x:106.05,y:201.35,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:105.9},0).wait(19).to({regX:70.8,x:106.05},0).wait(1).to({regX:70.6,scaleX:0.6766,scaleY:0.6766,x:107.4,y:200.85,alpha:0.1585},0).wait(1).to({scaleX:0.6727,scaleY:0.6727,x:109.05,y:200.3,alpha:0.1567},0).wait(1).to({scaleX:0.6686,scaleY:0.6686,x:110.8,y:199.75,alpha:0.1548},0).wait(1).to({scaleX:0.6642,scaleY:0.6642,x:112.75,y:199.15,alpha:0.1527},0).wait(1).to({scaleX:0.6594,scaleY:0.6594,x:114.8,y:198.45,alpha:0.1505},0).wait(1).to({scaleX:0.6543,scaleY:0.6543,x:117,y:197.75,alpha:0.1481},0).wait(1).to({scaleX:0.6488,scaleY:0.6488,x:119.35,y:197,alpha:0.1455},0).wait(1).to({scaleX:0.6431,scaleY:0.6431,x:121.85,y:196.2,alpha:0.1428},0).wait(1).to({scaleX:0.637,scaleY:0.637,x:124.45,y:195.35,alpha:0.14},0).wait(1).to({scaleX:0.6306,scaleY:0.6306,x:127.2,y:194.5,alpha:0.137},0).wait(1).to({scaleX:0.6239,scaleY:0.6239,x:130.1,y:193.55,alpha:0.1338},0).wait(1).to({scaleX:0.6169,scaleY:0.6169,x:133.1,y:192.6,alpha:0.1306},0).wait(1).to({scaleX:0.6096,scaleY:0.6096,x:136.25,y:191.6,alpha:0.1272},0).wait(1).to({scaleX:0.6021,scaleY:0.6021,x:139.5,y:190.55,alpha:0.1236},0).wait(1).to({scaleX:0.5942,scaleY:0.5942,x:142.85,y:189.45,alpha:0.12},0).wait(1).to({scaleX:0.5862,scaleY:0.5862,x:146.35,y:188.3,alpha:0.1162},0).wait(1).to({scaleX:0.5779,scaleY:0.5779,x:149.9,y:187.15,alpha:0.1123},0).wait(1).to({scaleX:0.5695,scaleY:0.5695,x:153.55,y:186,alpha:0.1083},0).wait(1).to({scaleX:0.5608,scaleY:0.5608,x:157.3,y:184.8,alpha:0.1043},0).wait(1).to({scaleX:0.5521,scaleY:0.5521,x:161.05,y:183.6,alpha:0.1002},0).wait(1).to({scaleX:0.5432,scaleY:0.5432,x:164.9,y:182.35,alpha:0.096},0).wait(1).to({scaleX:0.5342,scaleY:0.5342,x:168.75,y:181.15,alpha:0.0918},0).wait(1).to({scaleX:0.5251,scaleY:0.5251,x:172.65,y:179.85,alpha:0.0876},0).wait(1).to({scaleX:0.5161,scaleY:0.5161,x:176.6,y:178.6,alpha:0.0833},0).wait(1).to({scaleX:0.507,scaleY:0.507,x:180.45,y:177.4,alpha:0.0791},0).wait(1).to({scaleX:0.498,scaleY:0.498,x:184.35,y:176.1,alpha:0.0749},0).wait(1).to({scaleX:0.4891,scaleY:0.4891,x:188.25,y:174.9,alpha:0.0707},0).wait(1).to({scaleX:0.4802,scaleY:0.4802,x:192,y:173.65,alpha:0.0665},0).wait(1).to({scaleX:0.4715,scaleY:0.4715,x:195.8,y:172.45,alpha:0.0624},0).wait(1).to({scaleX:0.463,scaleY:0.463,x:199.5,y:171.3,alpha:0.0584},0).wait(1).to({scaleX:0.4546,scaleY:0.4546,x:203.1,y:170.1,alpha:0.0545},0).wait(1).to({scaleX:0.4464,scaleY:0.4464,x:206.6,y:168.95,alpha:0.0507},0).wait(1).to({scaleX:0.4385,scaleY:0.4385,x:210,y:167.85,alpha:0.047},0).wait(1).to({scaleX:0.4308,scaleY:0.4308,x:213.35,y:166.8,alpha:0.0433},0).wait(1).to({scaleX:0.4233,scaleY:0.4233,x:216.55,y:165.8,alpha:0.0399},0).wait(1).to({scaleX:0.4162,scaleY:0.4162,x:219.65,y:164.8,alpha:0.0365},0).wait(1).to({scaleX:0.4093,scaleY:0.4093,x:222.6,y:163.8,alpha:0.0333},0).wait(1).to({scaleX:0.4028,scaleY:0.4028,x:225.45,y:162.9,alpha:0.0302},0).wait(1).to({scaleX:0.3965,scaleY:0.3965,x:228.1,y:162.05,alpha:0.0273},0).wait(1).to({scaleX:0.3906,scaleY:0.3906,x:230.65,y:161.2,alpha:0.0245},0).wait(1).to({scaleX:0.385,scaleY:0.385,x:233.1,y:160.45,alpha:0.0219},0).wait(1).to({scaleX:0.3797,scaleY:0.3797,x:235.35,y:159.7,alpha:0.0194},0).wait(1).to({scaleX:0.3748,scaleY:0.3748,x:237.5,y:159,alpha:0.0171},0).wait(1).to({scaleX:0.3702,scaleY:0.3702,x:239.5,y:158.4,alpha:0.0149},0).wait(1).to({scaleX:0.3659,scaleY:0.3659,x:241.35,y:157.8,alpha:0.0129},0).wait(1).to({scaleX:0.3619,scaleY:0.3619,x:243.05,y:157.25,alpha:0.0111},0).wait(1).to({scaleX:0.3583,scaleY:0.3583,x:244.6,y:156.75,alpha:0.0094},0).wait(1).to({scaleX:0.355,scaleY:0.355,x:246,y:156.25,alpha:0.0078},0).wait(1).to({scaleX:0.352,scaleY:0.352,x:247.3,y:155.85,alpha:0.0064},0).wait(1).to({scaleX:0.3493,scaleY:0.3493,x:248.45,y:155.5,alpha:0.0052},0).wait(1).to({scaleX:0.3469,scaleY:0.3469,x:249.5,y:155.2,alpha:0.004},0).wait(1).to({scaleX:0.3448,scaleY:0.3448,x:250.4,y:154.9,alpha:0.0031},0).wait(1).to({scaleX:0.343,scaleY:0.343,x:251.15,y:154.65,alpha:0.0022},0).wait(1).to({scaleX:0.3416,scaleY:0.3416,x:251.8,y:154.45,alpha:0.0015},0).wait(1).to({scaleX:0.3403,scaleY:0.3403,x:252.35,y:154.25,alpha:0.001},0).wait(1).to({scaleX:0.3394,scaleY:0.3394,x:252.7,y:154.1,alpha:0.0005},0).wait(1).to({scaleX:0.3388,scaleY:0.3388,x:253,y:154.05,alpha:0.0002},0).wait(1).to({scaleX:0.3384,scaleY:0.3384,x:253.2,y:153.95,alpha:0.0001},0).wait(1).to({regX:71.1,regY:48.1,scaleX:0.3383,scaleY:0.3383,x:253.3,y:154,alpha:0},0).wait(74));

	// r girl box shadow
	this.instance_13 = new lib.fill();
	this.instance_13.setTransform(253.7,154,1,1,0,0,0,32.5,30.1);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(124).to({_off:false},0).to({alpha:1},16).wait(79));

	// r guy box shadow
	this.instance_14 = new lib.squareshadow();
	this.instance_14.setTransform(249.5,5.2,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(19).to({_off:false},0).to({x:233.65,y:83.7,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:233.55},0).wait(11).to({regX:70.7,x:233.65},0).wait(1).to({regX:70.6,scaleX:0.5449,scaleY:0.5446,x:234,y:83.8},0).wait(1).to({scaleX:0.544,scaleY:0.5433,x:234.45,y:83.85},0).wait(1).to({scaleX:0.5431,scaleY:0.542,x:235,y:84},0).wait(1).to({scaleX:0.5421,scaleY:0.5406,x:235.55,y:84.15},0).wait(1).to({scaleX:0.541,scaleY:0.5391,x:236.2,y:84.25},0).wait(1).to({scaleX:0.5398,scaleY:0.5375,x:236.8,y:84.45},0).wait(1).to({scaleX:0.5386,scaleY:0.5358,x:237.5,y:84.6},0).wait(1).to({scaleX:0.5373,scaleY:0.534,x:238.3,y:84.75},0).wait(1).to({scaleX:0.5359,scaleY:0.532,x:239.05,y:85},0).wait(1).to({scaleX:0.5345,scaleY:0.53,x:239.85,y:85.2},0).wait(1).to({scaleX:0.533,scaleY:0.5279,x:240.75,y:85.4},0).wait(1).to({scaleX:0.5314,scaleY:0.5257,x:241.6,y:85.6},0).wait(1).to({scaleX:0.5297,scaleY:0.5234,x:242.55,y:85.8},0).wait(1).to({scaleX:0.528,scaleY:0.521,x:243.5,y:86.05},0).wait(1).to({scaleX:0.5263,scaleY:0.5185,x:244.5,y:86.3},0).wait(1).to({scaleX:0.5244,scaleY:0.516,x:245.55,y:86.5},0).wait(1).to({scaleX:0.5226,scaleY:0.5133,x:246.6,y:86.8},0).wait(1).to({scaleX:0.5207,scaleY:0.5107,x:247.65,y:87.05},0).wait(1).to({scaleX:0.5187,scaleY:0.5079,x:248.75,y:87.35},0).wait(1).to({scaleX:0.5167,scaleY:0.5051,x:249.9,y:87.6},0).wait(1).to({scaleX:0.5147,scaleY:0.5023,x:251,y:87.85},0).wait(1).to({scaleX:0.5127,scaleY:0.4995,x:252.15,y:88.15},0).wait(1).to({scaleX:0.5107,scaleY:0.4966,x:253.3,y:88.4},0).wait(1).to({scaleX:0.5086,scaleY:0.4938,x:254.45,y:88.7},0).wait(1).to({scaleX:0.5066,scaleY:0.4909,x:255.6,y:88.95},0).wait(1).to({scaleX:0.5045,scaleY:0.488,x:256.75,y:89.25},0).wait(1).to({scaleX:0.5025,scaleY:0.4852,x:257.95,y:89.5},0).wait(1).to({scaleX:0.5005,scaleY:0.4824,x:259.05,y:89.8},0).wait(1).to({scaleX:0.4985,scaleY:0.4797,x:260.15,y:90.1},0).wait(1).to({scaleX:0.4966,scaleY:0.4769,x:261.25,y:90.3},0).wait(1).to({scaleX:0.4947,scaleY:0.4743,x:262.35,y:90.55},0).wait(1).to({scaleX:0.4929,scaleY:0.4717,x:263.35,y:90.85},0).wait(1).to({scaleX:0.4911,scaleY:0.4692,x:264.35,y:91.1},0).wait(1).to({scaleX:0.4893,scaleY:0.4668,x:265.35,y:91.3},0).wait(1).to({scaleX:0.4877,scaleY:0.4644,x:266.3,y:91.55},0).wait(1).to({scaleX:0.486,scaleY:0.4621,x:267.2,y:91.75},0).wait(1).to({scaleX:0.4845,scaleY:0.46,x:268.1,y:92},0).wait(1).to({scaleX:0.483,scaleY:0.4579,x:268.9,y:92.2},0).wait(1).to({scaleX:0.4816,scaleY:0.4559,x:269.7,y:92.35},0).wait(1).to({scaleX:0.4803,scaleY:0.454,x:270.45,y:92.55},0).wait(1).to({scaleX:0.479,scaleY:0.4523,x:271.15,y:92.7},0).wait(1).to({scaleX:0.4778,scaleY:0.4506,x:271.9,y:92.9},0).wait(1).to({scaleX:0.4767,scaleY:0.449,x:272.5,y:93},0).wait(1).to({scaleX:0.4756,scaleY:0.4476,x:273.1,y:93.15},0).wait(1).to({scaleX:0.4747,scaleY:0.4462,x:273.6,y:93.3},0).wait(1).to({scaleX:0.4738,scaleY:0.445,x:274.15,y:93.4},0).wait(1).to({scaleX:0.473,scaleY:0.4438,x:274.6,y:93.5},0).wait(1).to({scaleX:0.4722,scaleY:0.4428,x:275.05,y:93.6},0).wait(1).to({scaleX:0.4715,scaleY:0.4418,x:275.4,y:93.7},0).wait(1).to({scaleX:0.4709,scaleY:0.441,x:275.75,y:93.85},0).wait(1).to({scaleX:0.4704,scaleY:0.4402,x:276.05,y:93.9},0).wait(1).to({scaleX:0.4699,scaleY:0.4396,x:276.35,y:93.95},0).wait(1).to({scaleX:0.4695,scaleY:0.439,x:276.55,y:94},0).wait(1).to({scaleX:0.4692,scaleY:0.4385,x:276.7,y:94.05},0).wait(1).to({scaleX:0.4689,scaleY:0.4381,x:276.85,y:94.1},0).wait(1).to({scaleX:0.4687,scaleY:0.4379,x:277,y:94.15},0).wait(1).to({scaleX:0.4685,scaleY:0.4376,x:277.1,y:94.1},0).wait(1).to({scaleY:0.4375,y:94.15},0).wait(1).to({regX:70.7,regY:48,scaleX:0.4684,x:277.2},0).wait(79));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(54.35,135.65,0.2637,0.2637,0,0,0,225.1,236.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(70).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(11).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(1).to({regX:225.3,regY:236.4,scaleX:0.2639,scaleY:0.2639,x:54.45,y:135.55},0).wait(1).to({scaleX:0.2641,scaleY:0.2641,x:54.4,y:135.5},0).wait(1).to({scaleX:0.2645,scaleY:0.2645,x:54.45,y:135.4},0).wait(1).to({scaleX:0.2649,scaleY:0.2649,y:135.3},0).wait(1).to({scaleX:0.2654,scaleY:0.2654,x:54.4,y:135.25},0).wait(1).to({scaleX:0.2659,scaleY:0.2659,y:135.1},0).wait(1).to({scaleX:0.2666,scaleY:0.2666,y:135},0).wait(1).to({scaleX:0.2673,scaleY:0.2673,y:134.85},0).wait(1).to({scaleX:0.2682,scaleY:0.2682,x:54.35,y:134.7},0).wait(1).to({scaleX:0.2691,scaleY:0.2691,x:54.3,y:134.5},0).wait(1).to({scaleX:0.2701,scaleY:0.2701,x:54.35,y:134.35},0).wait(1).to({scaleX:0.2712,scaleY:0.2712,x:54.3,y:134.1},0).wait(1).to({scaleX:0.2724,scaleY:0.2724,y:133.85},0).wait(1).to({scaleX:0.2737,scaleY:0.2737,x:54.25,y:133.6},0).wait(1).to({scaleX:0.2752,scaleY:0.2752,y:133.35},0).wait(1).to({scaleX:0.2767,scaleY:0.2767,y:133.05},0).wait(1).to({scaleX:0.2783,scaleY:0.2783,x:54.2,y:132.75},0).wait(1).to({scaleX:0.2801,scaleY:0.2801,x:54.15,y:132.4},0).wait(1).to({scaleX:0.2819,scaleY:0.2819,x:54.1,y:132.05},0).wait(1).to({scaleX:0.2838,scaleY:0.2838,y:131.7},0).wait(1).to({scaleX:0.2858,scaleY:0.2858,x:54.05,y:131.25},0).wait(1).to({scaleX:0.2879,scaleY:0.2879,x:54,y:130.85},0).wait(1).to({scaleX:0.2901,scaleY:0.2901,y:130.45},0).wait(1).to({scaleX:0.2923,scaleY:0.2923,x:53.95,y:130},0).wait(1).to({scaleX:0.2946,scaleY:0.2946,y:129.55},0).wait(1).to({scaleX:0.297,scaleY:0.297,x:53.85,y:129.1},0).wait(1).to({scaleX:0.2993,scaleY:0.2993,y:128.65},0).wait(1).to({scaleX:0.3017,scaleY:0.3017,x:53.8,y:128.15},0).wait(1).to({scaleX:0.3041,scaleY:0.3041,x:53.75,y:127.75},0).wait(1).to({scaleX:0.3065,scaleY:0.3065,x:53.7,y:127.3},0).wait(1).to({scaleX:0.3088,scaleY:0.3088,x:53.65,y:126.85},0).wait(1).to({scaleX:0.3111,scaleY:0.3111,y:126.4},0).wait(1).to({scaleX:0.3134,scaleY:0.3134,x:53.6,y:125.95},0).wait(1).to({scaleX:0.3155,scaleY:0.3155,x:53.55,y:125.55},0).wait(1).to({scaleX:0.3177,scaleY:0.3177,x:53.5,y:125.1},0).wait(1).to({scaleX:0.3197,scaleY:0.3197,y:124.75},0).wait(1).to({scaleX:0.3217,scaleY:0.3217,x:53.45,y:124.35},0).wait(1).to({scaleX:0.3235,scaleY:0.3235,y:124},0).wait(1).to({scaleX:0.3253,scaleY:0.3253,x:53.4,y:123.65},0).wait(1).to({scaleX:0.327,scaleY:0.327,x:53.35,y:123.3},0).wait(1).to({scaleX:0.3286,scaleY:0.3286,x:53.3,y:123},0).wait(1).to({scaleX:0.33,scaleY:0.33,y:122.7},0).wait(1).to({scaleX:0.3314,scaleY:0.3314,x:53.25,y:122.45},0).wait(1).to({scaleX:0.3327,scaleY:0.3327,y:122.2},0).wait(1).to({scaleX:0.3339,scaleY:0.3339,y:122},0).wait(1).to({scaleX:0.335,scaleY:0.335,y:121.75},0).wait(1).to({scaleX:0.3361,scaleY:0.3361,x:53.2,y:121.55},0).wait(1).to({scaleX:0.337,scaleY:0.337,y:121.35},0).wait(1).to({scaleX:0.3378,scaleY:0.3378,x:53.15,y:121.2},0).wait(1).to({scaleX:0.3386,scaleY:0.3386,x:53.2,y:121.05},0).wait(1).to({scaleX:0.3393,scaleY:0.3393,x:53.15,y:120.9},0).wait(1).to({scaleX:0.3399,scaleY:0.3399,y:120.8},0).wait(1).to({scaleX:0.3405,scaleY:0.3405,y:120.7},0).wait(1).to({scaleX:0.3409,scaleY:0.3409,x:53.1,y:120.6},0).wait(1).to({scaleX:0.3413,scaleY:0.3413,y:120.55},0).wait(1).to({scaleX:0.3417,scaleY:0.3417,x:53.15,y:120.45},0).wait(1).to({scaleX:0.3419,scaleY:0.3419},0).wait(1).to({scaleX:0.3421,scaleY:0.3421,y:120.4},0).wait(1).to({regX:225,regY:236.8,scaleX:0.3423,scaleY:0.3423,x:53,y:120.45},0).wait(79));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(125.4,140.2,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(17).to({regY:15.2,scaleX:0.7599,scaleY:0.7599,x:107.45,y:147.55},28,cjs.Ease.quadInOut).wait(25).to({regX:38,x:107.55},0).wait(11).to({regX:37.9,x:107.45},0).wait(1).to({regX:38,scaleX:0.7604,scaleY:0.7604,x:107.55,y:147.5},0).wait(1).to({scaleX:0.7612,scaleY:0.7612,y:147.45},0).wait(1).to({scaleX:0.7621,scaleY:0.7621,x:107.65},0).wait(1).to({scaleX:0.7633,scaleY:0.7633,x:107.7,y:147.35},0).wait(1).to({scaleX:0.7647,scaleY:0.7647,x:107.8,y:147.25},0).wait(1).to({scaleX:0.7663,scaleY:0.7663,x:107.9,y:147.2},0).wait(1).to({scaleX:0.7682,scaleY:0.7682,x:108.05,y:147.1},0).wait(1).to({scaleX:0.7703,scaleY:0.7703,x:108.15,y:147},0).wait(1).to({scaleX:0.7727,scaleY:0.7727,x:108.3,y:146.85},0).wait(1).to({scaleX:0.7754,scaleY:0.7754,x:108.5,y:146.75},0).wait(1).to({scaleX:0.7783,scaleY:0.7783,x:108.7,y:146.6},0).wait(1).to({scaleX:0.7815,scaleY:0.7815,x:108.9,y:146.45},0).wait(1).to({scaleX:0.785,scaleY:0.785,x:109.15,y:146.25},0).wait(1).to({scaleX:0.7888,scaleY:0.7888,x:109.4,y:146.05},0).wait(1).to({scaleX:0.7929,scaleY:0.7929,x:109.65,y:145.8},0).wait(1).to({scaleX:0.7973,scaleY:0.7973,x:109.9,y:145.6},0).wait(1).to({scaleX:0.802,scaleY:0.802,x:110.2,y:145.35},0).wait(1).to({scaleX:0.807,scaleY:0.807,x:110.5,y:145.1},0).wait(1).to({scaleX:0.8123,scaleY:0.8123,x:110.85,y:144.85},0).wait(1).to({scaleX:0.8179,scaleY:0.8179,x:111.25,y:144.55},0).wait(1).to({scaleX:0.8237,scaleY:0.8237,x:111.6,y:144.2},0).wait(1).to({scaleX:0.8297,scaleY:0.8297,x:112,y:143.9},0).wait(1).to({scaleX:0.836,scaleY:0.836,x:112.35,y:143.6},0).wait(1).to({scaleX:0.8425,scaleY:0.8425,x:112.8,y:143.25},0).wait(1).to({scaleX:0.8491,scaleY:0.8491,x:113.2,y:142.95},0).wait(1).to({scaleX:0.8558,scaleY:0.8558,x:113.6,y:142.6},0).wait(1).to({scaleX:0.8626,scaleY:0.8626,x:114.1,y:142.25},0).wait(1).to({scaleX:0.8695,scaleY:0.8695,x:114.55,y:141.85},0).wait(1).to({scaleX:0.8764,scaleY:0.8764,x:114.95,y:141.5},0).wait(1).to({scaleX:0.8832,scaleY:0.8832,x:115.4,y:141.15},0).wait(1).to({scaleX:0.8899,scaleY:0.8899,x:115.8,y:140.85},0).wait(1).to({scaleX:0.8966,scaleY:0.8966,x:116.25,y:140.5},0).wait(1).to({scaleX:0.903,scaleY:0.903,x:116.65,y:140.2},0).wait(1).to({scaleX:0.9093,scaleY:0.9093,x:117.05,y:139.8},0).wait(1).to({scaleX:0.9154,scaleY:0.9154,x:117.5,y:139.5},0).wait(1).to({scaleX:0.9213,scaleY:0.9213,x:117.85,y:139.2},0).wait(1).to({scaleX:0.9269,scaleY:0.9269,x:118.2,y:138.95},0).wait(1).to({scaleX:0.9323,scaleY:0.9323,x:118.55,y:138.65},0).wait(1).to({scaleX:0.9374,scaleY:0.9374,x:118.85,y:138.4},0).wait(1).to({scaleX:0.9423,scaleY:0.9423,x:119.15,y:138.1},0).wait(1).to({scaleX:0.9468,scaleY:0.9468,x:119.5,y:137.9},0).wait(1).to({scaleX:0.9511,scaleY:0.9511,x:119.75,y:137.7},0).wait(1).to({scaleX:0.9551,scaleY:0.9551,x:120,y:137.45},0).wait(1).to({scaleX:0.9588,scaleY:0.9588,x:120.25,y:137.25},0).wait(1).to({scaleX:0.9623,scaleY:0.9623,x:120.45,y:137.15},0).wait(1).to({scaleX:0.9655,scaleY:0.9655,x:120.7,y:136.95},0).wait(1).to({scaleX:0.9685,scaleY:0.9685,x:120.85,y:136.75},0).wait(1).to({scaleX:0.9711,scaleY:0.9711,x:121.05,y:136.65},0).wait(1).to({scaleX:0.9736,scaleY:0.9736,x:121.2,y:136.55},0).wait(1).to({scaleX:0.9758,scaleY:0.9758,x:121.35,y:136.45},0).wait(1).to({scaleX:0.9778,scaleY:0.9778,x:121.45,y:136.3},0).wait(1).to({scaleX:0.9796,scaleY:0.9796,x:121.55,y:136.25},0).wait(1).to({scaleX:0.9811,scaleY:0.9811,x:121.7,y:136.15},0).wait(1).to({scaleX:0.9825,scaleY:0.9825,x:121.75,y:136.1},0).wait(1).to({scaleX:0.9837,scaleY:0.9837,x:121.85,y:136},0).wait(1).to({scaleX:0.9846,scaleY:0.9846,x:121.9,y:135.95},0).wait(1).to({scaleX:0.9854,scaleY:0.9854,x:121.95},0).wait(1).to({scaleX:0.986,scaleY:0.986,y:135.9},0).wait(1).to({regX:37.9,scaleX:0.9864,scaleY:0.9864,y:135.85},0).wait(79));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(120.3,143.35,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(17).to({regX:37.7,regY:15.7,scaleX:0.7718,scaleY:0.7718,x:107.45,y:147.55},28,cjs.Ease.quadInOut).to({alpha:0},24,cjs.Ease.quadOut).wait(150));

	// first image
	this.instance_15 = new lib.firstimage_1();
	this.instance_15.setTransform(234.9,125.55,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(23).to({regX:42,regY:26.6,scaleX:0.576,scaleY:0.576,x:238.05,y:134.35},30,cjs.Ease.quadInOut).wait(17).to({regY:26.5,y:134.3},0).wait(11).to({regY:26.6,y:134.35},0).wait(1).to({regY:26.5,scaleX:0.5764,scaleY:0.5764,x:238.15,y:134.25},0).wait(1).to({scaleX:0.5769,scaleY:0.5769,x:238.35},0).wait(1).to({scaleX:0.5777,scaleY:0.5777,x:238.55,y:134.15},0).wait(1).to({scaleX:0.5786,scaleY:0.5786,x:238.85},0).wait(1).to({scaleX:0.5796,scaleY:0.5796,x:239.2,y:134},0).wait(1).to({scaleX:0.5808,scaleY:0.5808,x:239.6,y:133.95},0).wait(1).to({scaleX:0.5823,scaleY:0.5823,x:240,y:133.85},0).wait(1).to({scaleX:0.5839,scaleY:0.5839,x:240.5,y:133.7},0).wait(1).to({scaleX:0.5857,scaleY:0.5857,x:241.15,y:133.6},0).wait(1).to({scaleX:0.5877,scaleY:0.5877,x:241.8,y:133.45},0).wait(1).to({scaleX:0.5899,scaleY:0.5899,x:242.5,y:133.35},0).wait(1).to({scaleX:0.5924,scaleY:0.5924,x:243.3,y:133.15},0).wait(1).to({scaleX:0.595,scaleY:0.595,x:244.1,y:132.95},0).wait(1).to({scaleX:0.5979,scaleY:0.5979,x:245,y:132.75},0).wait(1).to({scaleX:0.601,scaleY:0.601,x:246.05,y:132.55},0).wait(1).to({scaleX:0.6044,scaleY:0.6044,x:247.1,y:132.3},0).wait(1).to({scaleX:0.6079,scaleY:0.6079,x:248.25,y:132.05},0).wait(1).to({scaleX:0.6117,scaleY:0.6117,x:249.45,y:131.75},0).wait(1).to({scaleX:0.6157,scaleY:0.6157,x:250.7,y:131.5},0).wait(1).to({scaleX:0.6199,scaleY:0.6199,x:252.1,y:131.25},0).wait(1).to({scaleX:0.6243,scaleY:0.6243,x:253.45,y:130.9},0).wait(1).to({scaleX:0.6289,scaleY:0.6289,x:254.95,y:130.55},0).wait(1).to({scaleX:0.6337,scaleY:0.6337,x:256.45,y:130.25},0).wait(1).to({scaleX:0.6385,scaleY:0.6385,x:258,y:129.9},0).wait(1).to({scaleX:0.6436,scaleY:0.6436,x:259.65,y:129.55},0).wait(1).to({scaleX:0.6487,scaleY:0.6487,x:261.3,y:129.2},0).wait(1).to({scaleX:0.6538,scaleY:0.6538,x:262.9,y:128.85},0).wait(1).to({scaleX:0.659,scaleY:0.659,x:264.6,y:128.45},0).wait(1).to({scaleX:0.6642,scaleY:0.6642,x:266.25,y:128.1},0).wait(1).to({scaleX:0.6694,scaleY:0.6694,x:267.9,y:127.75},0).wait(1).to({scaleX:0.6745,scaleY:0.6745,x:269.55,y:127.35},0).wait(1).to({scaleX:0.6795,scaleY:0.6795,x:271.15,y:127},0).wait(1).to({scaleX:0.6845,scaleY:0.6845,x:272.75,y:126.7},0).wait(1).to({scaleX:0.6892,scaleY:0.6892,x:274.25,y:126.35},0).wait(1).to({scaleX:0.6939,scaleY:0.6939,x:275.75,y:126.05},0).wait(1).to({scaleX:0.6983,scaleY:0.6983,x:277.2,y:125.7},0).wait(1).to({scaleX:0.7026,scaleY:0.7026,x:278.5,y:125.4},0).wait(1).to({scaleX:0.7067,scaleY:0.7067,x:279.85,y:125.15},0).wait(1).to({scaleX:0.7105,scaleY:0.7105,x:281.1,y:124.9},0).wait(1).to({scaleX:0.7142,scaleY:0.7142,x:282.25,y:124.6},0).wait(1).to({scaleX:0.7176,scaleY:0.7176,x:283.35,y:124.35},0).wait(1).to({scaleX:0.7209,scaleY:0.7209,x:284.4,y:124.1},0).wait(1).to({scaleX:0.7239,scaleY:0.7239,x:285.35,y:123.95},0).wait(1).to({scaleX:0.7268,scaleY:0.7268,x:286.25,y:123.7},0).wait(1).to({scaleX:0.7294,scaleY:0.7294,x:287.15,y:123.55},0).wait(1).to({scaleX:0.7318,scaleY:0.7318,x:287.9,y:123.35},0).wait(1).to({scaleX:0.734,scaleY:0.734,x:288.6,y:123.2},0).wait(1).to({scaleX:0.7361,scaleY:0.7361,x:289.25,y:123.05},0).wait(1).to({scaleX:0.738,scaleY:0.738,x:289.85,y:122.95},0).wait(1).to({scaleX:0.7396,scaleY:0.7396,x:290.4,y:122.8},0).wait(1).to({scaleX:0.7411,scaleY:0.7411,x:290.9,y:122.7},0).wait(1).to({scaleX:0.7425,scaleY:0.7425,x:291.3,y:122.65},0).wait(1).to({scaleX:0.7437,scaleY:0.7437,x:291.7,y:122.5},0).wait(1).to({scaleX:0.7447,scaleY:0.7447,x:292.05},0).wait(1).to({scaleX:0.7456,scaleY:0.7456,x:292.3,y:122.4},0).wait(1).to({scaleX:0.7463,scaleY:0.7463,x:292.55,y:122.35},0).wait(1).to({scaleX:0.7469,scaleY:0.7469,x:292.7,y:122.3},0).wait(1).to({scaleX:0.7474,scaleY:0.7474,x:292.85,y:122.25},0).wait(1).to({regX:42.1,regY:26.7,scaleX:0.7477,scaleY:0.7477,x:293.05,y:122.3},0).wait(79));

	// square shadow
	this.instance_16 = new lib.squareshadow();
	this.instance_16.setTransform(233.35,129.15,0.4651,0.4621,0,0,0,71,48);
	this.instance_16.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(23).to({regX:71.2,regY:48.2,scaleX:0.325,scaleY:0.3131,x:237.85,y:134.45},30,cjs.Ease.quadInOut).to({_off:true},1).wait(165));

	// second image
	this.instance_17 = new lib.secondimage_1();
	this.instance_17.setTransform(249.4,152.25,0.7473,0.7473,0,0,0,41.9,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(27).to({regX:42,regY:26.4,scaleX:0.5752,scaleY:0.5752,y:155.4},30,cjs.Ease.quadInOut).wait(13).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(11).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(1).to({regX:42.2,regY:26.5,scaleX:0.5756,scaleY:0.5756,x:249.65},0).wait(1).to({scaleX:0.5761,scaleY:0.5761,x:249.8,y:155.35},0).wait(1).to({scaleX:0.5769,scaleY:0.5769,x:250.1},0).wait(1).to({scaleX:0.5777,scaleY:0.5777,x:250.4,y:155.3},0).wait(1).to({scaleX:0.5788,scaleY:0.5788,x:250.7},0).wait(1).to({scaleX:0.58,scaleY:0.58,x:251.15,y:155.25},0).wait(1).to({scaleX:0.5814,scaleY:0.5814,x:251.65,y:155.2},0).wait(1).to({scaleX:0.5831,scaleY:0.5831,x:252.2,y:155.15},0).wait(1).to({scaleX:0.5849,scaleY:0.5849,x:252.8,y:155.1},0).wait(1).to({scaleX:0.5869,scaleY:0.5869,x:253.45,y:155},0).wait(1).to({scaleX:0.5891,scaleY:0.5891,x:254.25,y:154.95},0).wait(1).to({scaleX:0.5915,scaleY:0.5915,x:255.05,y:154.9},0).wait(1).to({scaleX:0.5942,scaleY:0.5942,x:255.95,y:154.8},0).wait(1).to({scaleX:0.5971,scaleY:0.5971,x:256.95,y:154.65},0).wait(1).to({scaleX:0.6002,scaleY:0.6002,x:258.05,y:154.55},0).wait(1).to({scaleX:0.6035,scaleY:0.6035,x:259.1,y:154.45},0).wait(1).to({scaleX:0.6071,scaleY:0.6071,x:260.35,y:154.35},0).wait(1).to({scaleX:0.6108,scaleY:0.6108,x:261.65,y:154.25},0).wait(1).to({scaleX:0.6148,scaleY:0.6148,x:263,y:154.1},0).wait(1).to({scaleX:0.619,scaleY:0.619,x:264.4,y:153.95},0).wait(1).to({scaleX:0.6234,scaleY:0.6234,x:265.9,y:153.75},0).wait(1).to({scaleX:0.628,scaleY:0.628,x:267.45,y:153.65},0).wait(1).to({scaleX:0.6328,scaleY:0.6328,x:269.1,y:153.45},0).wait(1).to({scaleX:0.6377,scaleY:0.6377,x:270.75,y:153.3},0).wait(1).to({scaleX:0.6427,scaleY:0.6427,x:272.45,y:153.15},0).wait(1).to({scaleX:0.6478,scaleY:0.6478,x:274.2,y:152.95},0).wait(1).to({scaleX:0.6529,scaleY:0.6529,x:275.95,y:152.8},0).wait(1).to({scaleX:0.6581,scaleY:0.6581,x:277.7,y:152.65},0).wait(1).to({scaleX:0.6633,scaleY:0.6633,x:279.5,y:152.45},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,x:281.25,y:152.25},0).wait(1).to({scaleX:0.6736,scaleY:0.6736,x:282.95,y:152.1},0).wait(1).to({scaleX:0.6786,scaleY:0.6786,x:284.7,y:151.95},0).wait(1).to({scaleX:0.6835,scaleY:0.6835,x:286.35,y:151.75},0).wait(1).to({scaleX:0.6883,scaleY:0.6883,x:287.95,y:151.6},0).wait(1).to({scaleX:0.6929,scaleY:0.6929,x:289.55,y:151.45},0).wait(1).to({scaleX:0.6973,scaleY:0.6973,x:291.05,y:151.35},0).wait(1).to({scaleX:0.7016,scaleY:0.7016,x:292.5,y:151.15},0).wait(1).to({scaleX:0.7057,scaleY:0.7057,x:293.9,y:151.05},0).wait(1).to({scaleX:0.7095,scaleY:0.7095,x:295.2,y:150.9},0).wait(1).to({scaleX:0.7132,scaleY:0.7132,x:296.45,y:150.75},0).wait(1).to({scaleX:0.7166,scaleY:0.7166,x:297.65,y:150.65},0).wait(1).to({scaleX:0.7199,scaleY:0.7199,x:298.75,y:150.55},0).wait(1).to({scaleX:0.7229,scaleY:0.7229,x:299.75,y:150.45},0).wait(1).to({scaleX:0.7257,scaleY:0.7257,x:300.75,y:150.35},0).wait(1).to({scaleX:0.7284,scaleY:0.7284,x:301.6,y:150.25},0).wait(1).to({scaleX:0.7308,scaleY:0.7308,x:302.45,y:150.15},0).wait(1).to({scaleX:0.733,scaleY:0.733,x:303.2,y:150.1},0).wait(1).to({scaleX:0.7351,scaleY:0.7351,x:303.85,y:150.05},0).wait(1).to({scaleX:0.7369,scaleY:0.7369,x:304.5,y:150},0).wait(1).to({scaleX:0.7386,scaleY:0.7386,x:305.05,y:149.9},0).wait(1).to({scaleX:0.7401,scaleY:0.7401,x:305.6,y:149.85},0).wait(1).to({scaleX:0.7414,scaleY:0.7414,x:306.05,y:149.8},0).wait(1).to({scaleX:0.7426,scaleY:0.7426,x:306.45},0).wait(1).to({scaleX:0.7436,scaleY:0.7436,x:306.8,y:149.75},0).wait(1).to({scaleX:0.7445,scaleY:0.7445,x:307.1},0).wait(1).to({scaleX:0.7453,scaleY:0.7453,x:307.35,y:149.7},0).wait(1).to({scaleX:0.7458,scaleY:0.7458,x:307.55,y:149.65},0).wait(1).to({scaleX:0.7463,scaleY:0.7463,x:307.7,y:149.7},0).wait(1).to({regX:42.1,regY:26.4,scaleX:0.7466,scaleY:0.7466,x:307.75,y:149.55},0).wait(79));

	// square shadow
	this.instance_18 = new lib.squareshadow();
	this.instance_18.setTransform(248.05,156.75,0.4651,0.4621,0,0,0,70.9,48.1);
	this.instance_18.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(27).to({regX:71.2,regY:48.4,scaleX:0.3475,scaleY:0.2831,x:249.5,y:156},30,cjs.Ease.quadInOut).to({_off:true},1).wait(161));

	// screen
	this.instance_19 = new lib.WordUI();
	this.instance_19.setTransform(178.55,155.6,0.8368,0.8368,0,0,0,151,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(70).to({regY:96,y:155.7},0).wait(11).to({regY:95.9,y:155.6},0).wait(1).to({regY:96,scaleX:0.8374,scaleY:0.8374,x:178.6,y:155.65},0).wait(1).to({scaleX:0.8382,scaleY:0.8382,x:178.7,y:155.6},0).wait(1).to({scaleX:0.8393,scaleY:0.8393,x:178.9,y:155.55},0).wait(1).to({scaleX:0.8406,scaleY:0.8406,x:179.1},0).wait(1).to({scaleX:0.8421,scaleY:0.8421,x:179.3,y:155.45},0).wait(1).to({scaleX:0.8439,scaleY:0.8439,x:179.55,y:155.4},0).wait(1).to({scaleX:0.846,scaleY:0.846,x:179.85,y:155.3},0).wait(1).to({scaleX:0.8483,scaleY:0.8483,x:180.2,y:155.25},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:180.55,y:155.15},0).wait(1).to({scaleX:0.8539,scaleY:0.8539,x:181,y:155},0).wait(1).to({scaleX:0.8571,scaleY:0.8571,x:181.4,y:154.9},0).wait(1).to({scaleX:0.8607,scaleY:0.8607,x:181.95,y:154.75},0).wait(1).to({scaleX:0.8645,scaleY:0.8645,x:182.5,y:154.65},0).wait(1).to({scaleX:0.8687,scaleY:0.8687,x:183.1,y:154.5},0).wait(1).to({scaleX:0.8732,scaleY:0.8732,x:183.75,y:154.3},0).wait(1).to({scaleX:0.8781,scaleY:0.8781,x:184.45,y:154.15},0).wait(1).to({scaleX:0.8832,scaleY:0.8832,x:185.15,y:153.95},0).wait(1).to({scaleX:0.8887,scaleY:0.8887,x:185.95,y:153.7},0).wait(1).to({scaleX:0.8946,scaleY:0.8946,x:186.8,y:153.55},0).wait(1).to({scaleX:0.9007,scaleY:0.9007,x:187.65,y:153.25},0).wait(1).to({scaleX:0.9071,scaleY:0.9071,x:188.55,y:153.05},0).wait(1).to({scaleX:0.9137,scaleY:0.9137,x:189.5,y:152.8},0).wait(1).to({scaleX:0.9206,scaleY:0.9206,x:190.5,y:152.55},0).wait(1).to({scaleX:0.9278,scaleY:0.9278,x:191.55,y:152.25},0).wait(1).to({scaleX:0.935,scaleY:0.935,x:192.55,y:152},0).wait(1).to({scaleX:0.9425,scaleY:0.9425,x:193.6,y:151.75},0).wait(1).to({scaleX:0.95,scaleY:0.95,x:194.7,y:151.45},0).wait(1).to({scaleX:0.9575,scaleY:0.9575,x:195.8,y:151.15},0).wait(1).to({scaleX:0.9651,scaleY:0.9651,x:196.85,y:150.9},0).wait(1).to({scaleX:0.9726,scaleY:0.9726,x:197.9,y:150.6},0).wait(1).to({scaleX:0.98,scaleY:0.98,x:199,y:150.35},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:200.05,y:150.05},0).wait(1).to({scaleX:0.9945,scaleY:0.9945,x:201.05,y:149.75},0).wait(1).to({scaleX:1.0014,scaleY:1.0014,x:202,y:149.55},0).wait(1).to({scaleX:1.0081,scaleY:1.0081,x:203,y:149.3},0).wait(1).to({scaleX:1.0146,scaleY:1.0146,x:203.9,y:149.05},0).wait(1).to({scaleX:1.0208,scaleY:1.0208,x:204.8,y:148.8},0).wait(1).to({scaleX:1.0267,scaleY:1.0267,x:205.65,y:148.55},0).wait(1).to({scaleX:1.0323,scaleY:1.0323,x:206.45,y:148.35},0).wait(1).to({scaleX:1.0377,scaleY:1.0377,x:207.2,y:148.15},0).wait(1).to({scaleX:1.0427,scaleY:1.0427,x:207.95,y:148},0).wait(1).to({scaleX:1.0474,scaleY:1.0474,x:208.6,y:147.8},0).wait(1).to({scaleX:1.0518,scaleY:1.0518,x:209.2,y:147.6},0).wait(1).to({scaleX:1.0559,scaleY:1.0559,x:209.8,y:147.5},0).wait(1).to({scaleX:1.0597,scaleY:1.0597,x:210.35,y:147.35},0).wait(1).to({scaleX:1.0633,scaleY:1.0633,x:210.85,y:147.2},0).wait(1).to({scaleX:1.0665,scaleY:1.0665,x:211.35,y:147.1},0).wait(1).to({scaleX:1.0695,scaleY:1.0695,x:211.75,y:146.95},0).wait(1).to({scaleX:1.0722,scaleY:1.0722,x:212.15,y:146.9},0).wait(1).to({scaleX:1.0746,scaleY:1.0746,x:212.45,y:146.8},0).wait(1).to({scaleX:1.0768,scaleY:1.0768,x:212.8,y:146.7},0).wait(1).to({scaleX:1.0788,scaleY:1.0788,x:213.1,y:146.65},0).wait(1).to({scaleX:1.0805,scaleY:1.0805,x:213.3,y:146.6},0).wait(1).to({scaleX:1.082,scaleY:1.082,x:213.55,y:146.5},0).wait(1).to({scaleX:1.0833,scaleY:1.0833,x:213.7},0).wait(1).to({scaleX:1.0843,scaleY:1.0843,x:213.9,y:146.45},0).wait(1).to({scaleX:1.0852,scaleY:1.0852,x:214},0).wait(1).to({scaleX:1.0858,scaleY:1.0858,x:214.1,y:146.4},0).wait(1).to({regY:95.9,scaleX:1.0863,scaleY:1.0863,x:214.2,y:146.3},0).wait(79));

	// screen shadow
	this.instance_20 = new lib.shadow_1();
	this.instance_20.setTransform(179.9,132.35,0.888,0.888,0,0,0,180.6,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(70).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(11).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(1).to({regX:176.7,regY:127.5,scaleX:0.8886,scaleY:0.8886,x:176.5,y:139.1},0).wait(1).to({scaleX:0.8895,scaleY:0.8895,x:176.6,y:139.05},0).wait(1).to({scaleX:0.8906,scaleY:0.8906,x:176.75,y:139},0).wait(1).to({scaleX:0.892,scaleY:0.892,x:176.95,y:138.9},0).wait(1).to({scaleX:0.8936,scaleY:0.8936,x:177.2,y:138.85},0).wait(1).to({scaleX:0.8955,scaleY:0.8955,x:177.45,y:138.75},0).wait(1).to({scaleX:0.8977,scaleY:0.8977,x:177.7,y:138.6},0).wait(1).to({scaleX:0.9002,scaleY:0.9002,x:178.05,y:138.45},0).wait(1).to({scaleX:0.903,scaleY:0.903,x:178.4,y:138.35},0).wait(1).to({scaleX:0.9061,scaleY:0.9061,x:178.8,y:138.15},0).wait(1).to({scaleX:0.9095,scaleY:0.9095,x:179.25,y:138},0).wait(1).to({scaleX:0.9133,scaleY:0.9133,x:179.75,y:137.8},0).wait(1).to({scaleX:0.9174,scaleY:0.9174,x:180.3,y:137.55},0).wait(1).to({scaleX:0.9218,scaleY:0.9218,x:180.9,y:137.35},0).wait(1).to({scaleX:0.9266,scaleY:0.9266,x:181.55,y:137.1},0).wait(1).to({scaleX:0.9317,scaleY:0.9317,x:182.25,y:136.8},0).wait(1).to({scaleX:0.9372,scaleY:0.9372,x:182.95,y:136.5},0).wait(1).to({scaleX:0.9431,scaleY:0.9431,x:183.75,y:136.2},0).wait(1).to({scaleX:0.9492,scaleY:0.9492,x:184.55,y:135.9},0).wait(1).to({scaleX:0.9557,scaleY:0.9557,x:185.4,y:135.55},0).wait(1).to({scaleX:0.9625,scaleY:0.9625,x:186.3,y:135.15},0).wait(1).to({scaleX:0.9696,scaleY:0.9696,x:187.2,y:134.8},0).wait(1).to({scaleX:0.9769,scaleY:0.9769,x:188.2,y:134.4},0).wait(1).to({scaleX:0.9845,scaleY:0.9845,x:189.2,y:134},0).wait(1).to({scaleX:0.9922,scaleY:0.9922,x:190.2,y:133.6},0).wait(1).to({scaleX:1.0001,scaleY:1.0001,x:191.25,y:133.15},0).wait(1).to({scaleX:1.008,scaleY:1.008,x:192.3,y:132.75},0).wait(1).to({scaleX:1.016,scaleY:1.016,x:193.4,y:132.35},0).wait(1).to({scaleX:1.0241,scaleY:1.0241,x:194.45,y:131.9},0).wait(1).to({scaleX:1.032,scaleY:1.032,x:195.5,y:131.55},0).wait(1).to({scaleX:1.0399,scaleY:1.0399,x:196.55,y:131.1},0).wait(1).to({scaleX:1.0477,scaleY:1.0477,x:197.55,y:130.7},0).wait(1).to({scaleX:1.0552,scaleY:1.0552,x:198.55,y:130.3},0).wait(1).to({scaleX:1.0626,scaleY:1.0626,x:199.5,y:129.9},0).wait(1).to({scaleX:1.0697,scaleY:1.0697,x:200.45,y:129.55},0).wait(1).to({scaleX:1.0766,scaleY:1.0766,x:201.4,y:129.15},0).wait(1).to({scaleX:1.0832,scaleY:1.0832,x:202.25,y:128.8},0).wait(1).to({scaleX:1.0895,scaleY:1.0895,x:203.1,y:128.45},0).wait(1).to({scaleX:1.0954,scaleY:1.0954,x:203.85,y:128.15},0).wait(1).to({scaleX:1.1011,scaleY:1.1011,x:204.6,y:127.85},0).wait(1).to({scaleX:1.1064,scaleY:1.1064,x:205.35,y:127.55},0).wait(1).to({scaleX:1.1114,scaleY:1.1114,x:206,y:127.3},0).wait(1).to({scaleX:1.1161,scaleY:1.1161,x:206.6,y:127.05},0).wait(1).to({scaleX:1.1205,scaleY:1.1205,x:207.2,y:126.8},0).wait(1).to({scaleX:1.1245,scaleY:1.1245,x:207.75,y:126.6},0).wait(1).to({scaleX:1.1283,scaleY:1.1283,x:208.2,y:126.4},0).wait(1).to({scaleX:1.1317,scaleY:1.1317,x:208.65,y:126.25},0).wait(1).to({scaleX:1.1348,scaleY:1.1348,x:209.1,y:126.05},0).wait(1).to({scaleX:1.1377,scaleY:1.1377,x:209.5,y:125.9},0).wait(1).to({scaleX:1.1403,scaleY:1.1403,x:209.85,y:125.75},0).wait(1).to({scaleX:1.1426,scaleY:1.1426,x:210.1,y:125.65},0).wait(1).to({scaleX:1.1447,scaleY:1.1447,x:210.4,y:125.55},0).wait(1).to({scaleX:1.1465,scaleY:1.1465,x:210.65,y:125.45},0).wait(1).to({scaleX:1.1481,scaleY:1.1481,x:210.85,y:125.35},0).wait(1).to({scaleX:1.1495,scaleY:1.1495,x:211,y:125.25},0).wait(1).to({scaleX:1.1506,scaleY:1.1506,x:211.15,y:125.2},0).wait(1).to({scaleX:1.1515,scaleY:1.1515,x:211.3,y:125.15},0).wait(1).to({scaleX:1.1522,scaleY:1.1522,x:211.4,y:125.1},0).wait(1).to({regX:180.6,regY:119.9,scaleX:1.1527,scaleY:1.1527,x:216,y:116.25},0).wait(79));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.9,-72.1,1909.3000000000002,395.9);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-30.35,2.5,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Am6B5IAAjyIN1AAIAADyg");
	this.shape.setTransform(-59.375,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-10.1,88.7,24.299999999999997), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(46.05,220.4,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(117.1,217.4,1.1404,1.1404,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(188.25,111.45,1,1,0,0,0,197.1,130.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(284.3,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-17.3,-3.3,369.8,255.4), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		//var ribbon = mc.ribbon;
		
		
		
		this.runBanner = function() {
			
			this.tl1 = gsap.timeline();
						
				exportRoot.tl1.from(screen, 1.5, { alpha: 0, x: "+=250",y: "+=250", ease:Power3.easeOut,
					onStart: function() {screen.gotoAndPlay(1);},
					onComplete: function() {exportRoot.tl1.pause();}
				}, "+=0.5");
				
				
				exportRoot.tl1.to(screen, 1.5, {x: "+=7",y: "+=58",scaleX: "0.8",scaleY: "0.8", ease:Power3.easeInOut}, "+=0.1");
		
			
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "-=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.pause();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(132.7,121.7,219.8,130.39999999999998);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1.png?1628512275017", id:"M365_FY21Q3ConsOpt_USA_300x250_BAN_WordCoauthor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;