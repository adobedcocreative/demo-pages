(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[612,709,138,108],[612,492,268,215],[752,709,138,108],[612,819,138,108],[752,819,138,108],[741,0,138,108],[0,492,610,374],[0,0,739,490],[741,220,120,111],[741,110,138,108]]}
];


// symbols:



(lib.Aimes = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Excel = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Outlook = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Powerpoint = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ScreenNoShadow111 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ScreenShadow = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Word_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Word_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Powerpoint();
	this.instance.setTransform(101.1,112.35,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word_1, new cjs.Rectangle(101.1,112.4,231.00000000000003,180.70000000000002), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCX8MAAAkv3MCZbAAAMAAAEv3g");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-972.3,982,1944.6999999999998);


(lib.tile_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.Screen_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.ScreenShadow();
	this.instance.setTransform(28.1,-45.55,1.4999,1.4999,-0.7881);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_Shadow, new cjs.Rectangle(28.1,-60.8,1118.4,750.0999999999999), null);


(lib.Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.ScreenNoShadow111();
	this.instance.setTransform(121,48.3,1.504,1.504,-0.9487);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen, new cjs.Rectangle(121,33.1,926.5999999999999,577.6), null);


(lib.Powerpoint_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Outlook_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.OneDrive_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Excel_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,600), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Aimes_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Aimes_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Wordcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Powerpoint();
	this.instance.setTransform(101,111,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Powerpoint_Shadow();
	this.instance_1.setTransform(211.1,235,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Wordcopy2, new cjs.Rectangle(83.7,111,254.60000000000002,226.2), null);


(lib.Wordcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Word_Shadow();
	this.instance.setTransform(211.9,232.15,0.95,0.95,0,0,0,134.1,107.5);
	this.instance.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Wordcopy, new cjs.Rectangle(84.5,130.1,254.60000000000002,204.20000000000002), null);


(lib.Teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Aimes();
	this.instance.setTransform(96.75,90.55,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Aimes_Shadow();
	this.instance_1.setTransform(211.15,212.1,0.95,0.95,0,0,0,134,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Teams, new cjs.Rectangle(83.9,90.6,254.6,223.70000000000002), null);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_119 = function() {
		//exportRoot.tlmove.play()
	}
	this.frame_207 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(119).call(this.frame_119).wait(88).call(this.frame_207).wait(1));

	// Word
	this.instance = new lib.Word_1();
	this.instance.setTransform(-143.8,-215.15,0.0754,0.0754,0,0,0,220.8,196.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(185).to({_off:false},0).to({regY:196.5,scaleX:0.5889,scaleY:0.5889,x:-8.25,y:-255.1},22,cjs.Ease.cubicOut).wait(1));

	// Word Shadow
	this.instance_1 = new lib.Wordcopy();
	this.instance_1.setTransform(-143.8,-215.15,0.0754,0.0754,0,0,0,220.8,196.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(185).to({_off:false},0).to({regY:196.5,scaleX:0.5889,scaleY:0.5889,x:-8.25,y:-255.1},22,cjs.Ease.cubicOut).wait(1));

	// Screen
	this.instance_2 = new lib.Screen();
	this.instance_2.setTransform(504.5,592.55,1,1,0,0,0,581.6,357.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:161.5,y:43.15},119).wait(1).to({regX:584.3,regY:321.9,x:161.8,y:2.65},0).wait(1).to({x:159.35,y:-2.05},0).wait(1).to({x:156.85,y:-6.85},0).wait(1).to({x:154.3,y:-11.7},0).wait(1).to({x:151.75,y:-16.6},0).wait(1).to({x:149.15,y:-21.55},0).wait(1).to({x:146.55,y:-26.5},0).wait(1).to({x:143.95,y:-31.55},0).wait(1).to({x:141.3,y:-36.55},0).wait(1).to({x:138.7,y:-41.6},0).wait(1).to({x:136.05,y:-46.6},0).wait(1).to({x:133.45,y:-51.6},0).wait(1).to({x:130.85,y:-56.5},0).wait(1).to({x:128.35,y:-61.4},0).wait(1).to({x:125.85,y:-66.15},0).wait(1).to({x:123.4,y:-70.85},0).wait(1).to({x:121,y:-75.4},0).wait(1).to({x:118.7,y:-79.85},0).wait(1).to({x:116.45,y:-84.1},0).wait(1).to({x:114.3,y:-88.2},0).wait(1).to({x:112.25,y:-92.15},0).wait(1).to({x:110.25,y:-95.95},0).wait(1).to({x:108.4,y:-99.55},0).wait(1).to({x:106.6,y:-103},0).wait(1).to({x:104.9,y:-106.25},0).wait(1).to({x:103.3,y:-109.3},0).wait(1).to({x:101.75,y:-112.2},0).wait(1).to({x:100.35,y:-114.95},0).wait(1).to({x:99,y:-117.5},0).wait(1).to({x:97.75,y:-119.9},0).wait(1).to({x:96.55,y:-122.15},0).wait(1).to({x:95.45,y:-124.3},0).wait(1).to({x:94.4,y:-126.25},0).wait(1).to({x:93.45,y:-128.1},0).wait(1).to({x:92.55,y:-129.8},0).wait(1).to({x:91.7,y:-131.4},0).wait(1).to({x:90.95,y:-132.9},0).wait(1).to({x:90.25,y:-134.25},0).wait(1).to({x:89.55,y:-135.55},0).wait(1).to({x:88.95,y:-136.7},0).wait(1).to({x:88.4,y:-137.8},0).wait(1).to({x:87.9,y:-138.75},0).wait(1).to({x:87.4,y:-139.65},0).wait(1).to({x:86.95,y:-140.5},0).wait(1).to({x:86.6,y:-141.25},0).wait(1).to({regX:581.6,regY:357.8,x:83.5,y:-106.05},0).wait(1).to({regX:584.3,regY:321.9,scaleX:0.9979,scaleY:0.9979,x:87.2,y:-142.35},0).wait(1).to({scaleX:0.9951,scaleY:0.9951,x:88.5,y:-142.95},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:90.1,y:-143.6},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:92.05,y:-144.5},0).wait(1).to({scaleX:0.9824,scaleY:0.9824,x:94.35,y:-145.55},0).wait(1).to({scaleX:0.9766,scaleY:0.9766,x:96.95,y:-146.7},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:99.95,y:-148},0).wait(1).to({scaleX:0.9627,scaleY:0.9627,x:103.35,y:-149.5},0).wait(1).to({scaleX:0.9544,scaleY:0.9544,x:107.1,y:-151.2},0).wait(1).to({scaleX:0.9454,scaleY:0.9454,x:111.25,y:-153.05},0).wait(1).to({scaleX:0.9355,scaleY:0.9355,x:115.75,y:-155.05},0).wait(1).to({scaleX:0.9249,scaleY:0.9249,x:120.65,y:-157.2},0).wait(1).to({scaleX:0.9135,scaleY:0.9135,x:125.85,y:-159.5},0).wait(1).to({scaleX:0.9015,scaleY:0.9015,x:131.35,y:-162},0).wait(1).to({scaleX:0.8889,scaleY:0.8889,x:137.15,y:-164.55},0).wait(1).to({scaleX:0.8758,scaleY:0.8758,x:143.1,y:-167.2},0).wait(1).to({scaleX:0.8625,scaleY:0.8625,x:149.2,y:-169.9},0).wait(1).to({scaleX:0.849,scaleY:0.849,x:155.4,y:-172.65},0).wait(1).to({scaleX:0.8355,scaleY:0.8355,x:161.6,y:-175.4},0).wait(1).to({scaleX:0.8222,scaleY:0.8222,x:167.7,y:-178.1},0).wait(1).to({scaleX:0.8091,scaleY:0.8091,x:173.65,y:-180.75},0).wait(1).to({scaleX:0.7965,scaleY:0.7965,x:179.45,y:-183.3},0).wait(1).to({scaleX:0.7843,scaleY:0.7843,x:185.05,y:-185.8},0).wait(1).to({scaleX:0.7728,scaleY:0.7728,x:190.3,y:-188.15},0).wait(1).to({scaleX:0.762,scaleY:0.762,x:195.25,y:-190.35},0).wait(1).to({scaleX:0.7518,scaleY:0.7518,x:199.95,y:-192.4},0).wait(1).to({scaleX:0.7424,scaleY:0.7424,x:204.25,y:-194.35},0).wait(1).to({scaleX:0.7337,scaleY:0.7337,x:208.2,y:-196.05},0).wait(1).to({scaleX:0.7258,scaleY:0.7258,x:211.85,y:-197.7},0).wait(1).to({scaleX:0.7186,scaleY:0.7186,x:215.1,y:-199.2},0).wait(1).to({scaleX:0.7122,scaleY:0.7122,x:218.05,y:-200.45},0).wait(1).to({scaleX:0.7064,scaleY:0.7064,x:220.7,y:-201.65},0).wait(1).to({scaleX:0.7013,scaleY:0.7013,x:223,y:-202.7},0).wait(1).to({scaleX:0.6969,scaleY:0.6969,x:225.1,y:-203.6},0).wait(1).to({scaleX:0.6931,scaleY:0.6931,x:226.8,y:-204.35},0).wait(1).to({scaleX:0.6898,scaleY:0.6898,x:228.3,y:-205},0).wait(1).to({scaleX:0.6872,scaleY:0.6872,x:229.5,y:-205.55},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:230.45,y:-206},0).wait(1).to({scaleX:0.6834,scaleY:0.6834,x:231.25,y:-206.3},0).wait(1).to({scaleX:0.6823,scaleY:0.6823,x:231.7,y:-206.55},0).wait(1).to({scaleX:0.6817,scaleY:0.6817,x:232.05,y:-206.65},0).wait(1).to({regX:581.7,regY:357.6,scaleX:0.6815,scaleY:0.6815,x:230.3,y:-182.3},0).wait(1));

	// Screen Shadow
	this.instance_3 = new lib.Screen_Shadow();
	this.instance_3.setTransform(504.5,592.55,1,1,0,0,0,581.6,357.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:161.5,y:43.15},119).wait(1).to({regX:587.3,regY:314.3,x:164.8,y:-4.95},0).wait(1).to({x:162.35,y:-9.65},0).wait(1).to({x:159.85,y:-14.45},0).wait(1).to({x:157.3,y:-19.3},0).wait(1).to({x:154.75,y:-24.2},0).wait(1).to({x:152.15,y:-29.15},0).wait(1).to({x:149.55,y:-34.1},0).wait(1).to({x:146.95,y:-39.15},0).wait(1).to({x:144.3,y:-44.15},0).wait(1).to({x:141.7,y:-49.2},0).wait(1).to({x:139.05,y:-54.2},0).wait(1).to({x:136.45,y:-59.2},0).wait(1).to({x:133.85,y:-64.1},0).wait(1).to({x:131.35,y:-69},0).wait(1).to({x:128.85,y:-73.75},0).wait(1).to({x:126.4,y:-78.45},0).wait(1).to({x:124,y:-83},0).wait(1).to({x:121.7,y:-87.45},0).wait(1).to({x:119.45,y:-91.7},0).wait(1).to({x:117.3,y:-95.8},0).wait(1).to({x:115.25,y:-99.75},0).wait(1).to({x:113.25,y:-103.55},0).wait(1).to({x:111.4,y:-107.15},0).wait(1).to({x:109.6,y:-110.6},0).wait(1).to({x:107.9,y:-113.85},0).wait(1).to({x:106.3,y:-116.9},0).wait(1).to({x:104.75,y:-119.8},0).wait(1).to({x:103.35,y:-122.55},0).wait(1).to({x:102,y:-125.1},0).wait(1).to({x:100.75,y:-127.5},0).wait(1).to({x:99.55,y:-129.75},0).wait(1).to({x:98.45,y:-131.9},0).wait(1).to({x:97.4,y:-133.85},0).wait(1).to({x:96.45,y:-135.7},0).wait(1).to({x:95.55,y:-137.4},0).wait(1).to({x:94.7,y:-139},0).wait(1).to({x:93.95,y:-140.5},0).wait(1).to({x:93.25,y:-141.85},0).wait(1).to({x:92.55,y:-143.15},0).wait(1).to({x:91.95,y:-144.3},0).wait(1).to({x:91.4,y:-145.4},0).wait(1).to({x:90.9,y:-146.35},0).wait(1).to({x:90.4,y:-147.25},0).wait(1).to({x:89.95,y:-148.1},0).wait(1).to({x:89.6,y:-148.85},0).wait(1).to({regX:581.6,regY:357.8,x:83.5,y:-106.05},0).wait(1).to({regX:587.3,regY:314.3,scaleX:0.9979,scaleY:0.9979,x:90.2,y:-149.95},0).wait(1).to({scaleX:0.9951,scaleY:0.9951,x:91.5,y:-150.5},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:93.1,y:-151.15},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:95,y:-152},0).wait(1).to({scaleX:0.9824,scaleY:0.9824,x:97.3,y:-153},0).wait(1).to({scaleX:0.9766,scaleY:0.9766,x:99.85,y:-154.1},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:102.85,y:-155.35},0).wait(1).to({scaleX:0.9627,scaleY:0.9627,x:106.2,y:-156.85},0).wait(1).to({scaleX:0.9544,scaleY:0.9544,x:109.95,y:-158.45},0).wait(1).to({scaleX:0.9454,scaleY:0.9454,x:114.1,y:-160.2},0).wait(1).to({scaleX:0.9355,scaleY:0.9355,x:118.6,y:-162.15},0).wait(1).to({scaleX:0.9249,scaleY:0.9249,x:123.4,y:-164.2},0).wait(1).to({scaleX:0.9135,scaleY:0.9135,x:128.6,y:-166.45},0).wait(1).to({scaleX:0.9015,scaleY:0.9015,x:134.05,y:-168.85},0).wait(1).to({scaleX:0.8889,scaleY:0.8889,x:139.8,y:-171.3},0).wait(1).to({scaleX:0.8758,scaleY:0.8758,x:145.7,y:-173.85},0).wait(1).to({scaleX:0.8625,scaleY:0.8625,x:151.8,y:-176.45},0).wait(1).to({scaleX:0.849,scaleY:0.849,x:157.95,y:-179.1},0).wait(1).to({scaleX:0.8355,scaleY:0.8355,x:164.1,y:-181.75},0).wait(1).to({scaleX:0.8222,scaleY:0.8222,x:170.15,y:-184.35},0).wait(1).to({scaleX:0.8091,scaleY:0.8091,x:176.05,y:-186.9},0).wait(1).to({scaleX:0.7965,scaleY:0.7965,x:181.85,y:-189.4},0).wait(1).to({scaleX:0.7843,scaleY:0.7843,x:187.4,y:-191.75},0).wait(1).to({scaleX:0.7728,scaleY:0.7728,x:192.6,y:-194},0).wait(1).to({scaleX:0.762,scaleY:0.762,x:197.55,y:-196.1},0).wait(1).to({scaleX:0.7518,scaleY:0.7518,x:202.2,y:-198.1},0).wait(1).to({scaleX:0.7424,scaleY:0.7424,x:206.45,y:-199.95},0).wait(1).to({scaleX:0.7337,scaleY:0.7337,x:210.4,y:-201.65},0).wait(1).to({scaleX:0.7258,scaleY:0.7258,x:214,y:-203.25},0).wait(1).to({scaleX:0.7186,scaleY:0.7186,x:217.25,y:-204.65},0).wait(1).to({scaleX:0.7122,scaleY:0.7122,x:220.2,y:-205.85},0).wait(1).to({scaleX:0.7064,scaleY:0.7064,x:222.8,y:-207.05},0).wait(1).to({scaleX:0.7013,scaleY:0.7013,x:225.15,y:-208.05},0).wait(1).to({scaleX:0.6969,scaleY:0.6969,x:227.15,y:-208.85},0).wait(1).to({scaleX:0.6931,scaleY:0.6931,x:228.9,y:-209.6},0).wait(1).to({scaleX:0.6898,scaleY:0.6898,x:230.4,y:-210.25},0).wait(1).to({scaleX:0.6872,scaleY:0.6872,x:231.55,y:-210.75},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:232.55,y:-211.2},0).wait(1).to({scaleX:0.6834,scaleY:0.6834,x:233.3,y:-211.5},0).wait(1).to({scaleX:0.6823,scaleY:0.6823,x:233.75,y:-211.75},0).wait(1).to({scaleX:0.6817,scaleY:0.6817,x:234.1,y:-211.85},0).wait(1).to({regX:581.7,regY:357.6,scaleX:0.6815,scaleY:0.6815,x:230.3,y:-182.3},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-470,-524.6,1539.4,1448.7);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Powerpoint_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(90.65,113.5,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(204.05,231.2,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint_1, new cjs.Rectangle(76.7,113.5,254.60000000000002,219.89999999999998), null);


(lib.Outlook_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Outlook();
	this.instance.setTransform(97.4,110.5,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_1, new cjs.Rectangle(84.5,110.5,254.60000000000002,223.7), null);


(lib.OneDrive_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.OneDrive();
	this.instance.setTransform(97.4,110.5,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3 copy
	this.instance_1 = new lib.OneDrive_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive_1, new cjs.Rectangle(84.5,110.5,254.60000000000002,223.7), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		exportRoot.mainMC.icons.play()
	}
	this.frame_86 = function() {
		exportRoot.tl1.play()
		exportRoot.mainMC.screen.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(17).call(this.frame_86).wait(14).call(this.frame_100).wait(10));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(83));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(83));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({scaleX:2.2,scaleY:2.2,x:24.2,y:-515.55},41,cjs.Ease.quadInOut).to({_off:true},1).wait(9));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCX8MAAAkv3MCZbAAAMAAAEv3g");
	this.shape.setTransform(299.85,339.425);

	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,339.4);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},59).to({state:[{t:this.instance_2}]},41).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({_off:false},0).to({alpha:0},41,cjs.Ease.cubicInOut).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-632.9,982,1944.6999999999998);


(lib.icon_teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.Excel_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel();
	this.instance.setTransform(111.85,124.45,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Excel_Shadow();
	this.instance_1.setTransform(226.25,246,0.95,0.95,0,0,0,134,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_1, new cjs.Rectangle(99,124.5,254.60000000000002,223.7), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,600,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,600), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(3,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ArOCeIAAk7IWdAAIAAE7g");
	this.shape.setTransform(-31.725,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.6,-16.5,143.8,31.6), null);


(lib.laptop_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_219 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(219).call(this.frame_219).wait(1));

	// OneDrive
	this.instance = new lib.OneDrive_1();
	this.instance.setTransform(337.85,167.2,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-196.1,y:-785.4},179).wait(1).to({regX:211.8,regY:222.3,x:-207.6,y:-765},0).wait(1).to({x:-210.5,y:-770.25},0).wait(1).to({x:-213.45,y:-775.6},0).wait(1).to({x:-216.45,y:-781},0).wait(1).to({x:-219.5,y:-786.55},0).wait(1).to({x:-222.6,y:-792.15},0).wait(1).to({x:-225.75,y:-797.9},0).wait(1).to({x:-229,y:-803.75},0).wait(1).to({x:-232.3,y:-809.75},0).wait(1).to({x:-235.7,y:-815.85},0).wait(1).to({x:-239.15,y:-822.1},0).wait(1).to({x:-242.65,y:-828.5},0).wait(1).to({x:-246.3,y:-835.05},0).wait(1).to({x:-250,y:-841.75},0).wait(1).to({x:-253.8,y:-848.65},0).wait(1).to({x:-257.7,y:-855.7},0).wait(1).to({x:-261.7,y:-862.95},0).wait(1).to({x:-265.8,y:-870.45},0).wait(1).to({x:-270.05,y:-878.15},0).wait(1).to({x:-274.45,y:-886.05},0).wait(1).to({x:-278.95,y:-894.2},0).wait(1).to({x:-283.6,y:-902.65},0).wait(1).to({x:-288.45,y:-911.4},0).wait(1).to({x:-293.4,y:-920.4},0).wait(1).to({x:-298.55,y:-929.75},0).wait(1).to({x:-303.95,y:-939.45},0).wait(1).to({x:-309.5,y:-949.5},0).wait(1).to({x:-315.25,y:-959.95},0).wait(1).to({x:-321.25,y:-970.85},0).wait(1).to({x:-327.5,y:-982.2},0).wait(1).to({x:-334.05,y:-994},0).wait(1).to({x:-340.85,y:-1006.3},0).wait(1).to({x:-347.95,y:-1019.2},0).wait(1).to({x:-355.35,y:-1032.6},0).wait(1).to({x:-363.1,y:-1046.65},0).wait(1).to({x:-371.2,y:-1061.35},0).wait(1).to({x:-379.7,y:-1076.65},0).wait(1).to({x:-388.5,y:-1092.65},0).wait(1).to({regX:220.5,regY:196.8,x:-389.05,y:-1134.85},0).to({_off:true},1).wait(1));

	// Outlook
	this.instance_1 = new lib.Outlook_1();
	this.instance_1.setTransform(313.95,355.4,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-220,y:-597.2},179).wait(1).to({regX:211.8,regY:222.3,x:-231.5,y:-576.8},0).wait(1).to({x:-234.4,y:-582.05},0).wait(1).to({x:-237.35,y:-587.4},0).wait(1).to({x:-240.35,y:-592.8},0).wait(1).to({x:-243.4,y:-598.35},0).wait(1).to({x:-246.5,y:-603.95},0).wait(1).to({x:-249.65,y:-609.7},0).wait(1).to({x:-252.9,y:-615.55},0).wait(1).to({x:-256.2,y:-621.55},0).wait(1).to({x:-259.6,y:-627.65},0).wait(1).to({x:-263.05,y:-633.9},0).wait(1).to({x:-266.55,y:-640.3},0).wait(1).to({x:-270.2,y:-646.85},0).wait(1).to({x:-273.9,y:-653.55},0).wait(1).to({x:-277.7,y:-660.45},0).wait(1).to({x:-281.6,y:-667.5},0).wait(1).to({x:-285.6,y:-674.75},0).wait(1).to({x:-289.7,y:-682.25},0).wait(1).to({x:-293.95,y:-689.95},0).wait(1).to({x:-298.35,y:-697.85},0).wait(1).to({x:-302.85,y:-706},0).wait(1).to({x:-307.5,y:-714.45},0).wait(1).to({x:-312.35,y:-723.2},0).wait(1).to({x:-317.3,y:-732.2},0).wait(1).to({x:-322.45,y:-741.55},0).wait(1).to({x:-327.85,y:-751.25},0).wait(1).to({x:-333.4,y:-761.3},0).wait(1).to({x:-339.15,y:-771.75},0).wait(1).to({x:-345.15,y:-782.65},0).wait(1).to({x:-351.4,y:-794},0).wait(1).to({x:-357.95,y:-805.8},0).wait(1).to({x:-364.75,y:-818.1},0).wait(1).to({x:-371.85,y:-831},0).wait(1).to({x:-379.25,y:-844.4},0).wait(1).to({x:-387,y:-858.45},0).wait(1).to({x:-395.1,y:-873.15},0).wait(1).to({x:-403.6,y:-888.45},0).wait(1).to({x:-412.4,y:-904.45},0).wait(1).to({regX:220.5,regY:196.8,x:-412.95,y:-946.65},0).to({_off:true},1).wait(1));

	// Aimes
	this.instance_2 = new lib.Teams();
	this.instance_2.setTransform(511.6,312.75,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-38.6,y:-639.85},179).wait(1).to({regX:211.1,regY:202.4,x:-50.8,y:-639.35},0).wait(1).to({x:-53.7,y:-644.6},0).wait(1).to({x:-56.65,y:-649.95},0).wait(1).to({x:-59.65,y:-655.35},0).wait(1).to({x:-62.7,y:-660.9},0).wait(1).to({x:-65.8,y:-666.5},0).wait(1).to({x:-68.95,y:-672.25},0).wait(1).to({x:-72.2,y:-678.1},0).wait(1).to({x:-75.5,y:-684.1},0).wait(1).to({x:-78.9,y:-690.2},0).wait(1).to({x:-82.35,y:-696.45},0).wait(1).to({x:-85.85,y:-702.85},0).wait(1).to({x:-89.5,y:-709.4},0).wait(1).to({x:-93.2,y:-716.1},0).wait(1).to({x:-97,y:-723},0).wait(1).to({x:-100.9,y:-730.05},0).wait(1).to({x:-104.9,y:-737.3},0).wait(1).to({x:-109,y:-744.8},0).wait(1).to({x:-113.25,y:-752.5},0).wait(1).to({x:-117.65,y:-760.4},0).wait(1).to({x:-122.15,y:-768.55},0).wait(1).to({x:-126.8,y:-777},0).wait(1).to({x:-131.65,y:-785.75},0).wait(1).to({x:-136.6,y:-794.75},0).wait(1).to({x:-141.75,y:-804.1},0).wait(1).to({x:-147.15,y:-813.8},0).wait(1).to({x:-152.7,y:-823.85},0).wait(1).to({x:-158.45,y:-834.3},0).wait(1).to({x:-164.45,y:-845.2},0).wait(1).to({x:-170.7,y:-856.55},0).wait(1).to({x:-177.25,y:-868.35},0).wait(1).to({x:-184.05,y:-880.65},0).wait(1).to({x:-191.15,y:-893.55},0).wait(1).to({x:-198.55,y:-906.95},0).wait(1).to({x:-206.3,y:-921},0).wait(1).to({x:-214.4,y:-935.7},0).wait(1).to({x:-222.9,y:-951},0).wait(1).to({x:-231.7,y:-967},0).wait(1).to({regX:220.5,regY:196.8,x:-231.55,y:-989.3},0).to({_off:true},1).wait(1));

	// Word
	this.instance_3 = new lib.Powerpoint_1();
	this.instance_3.setTransform(498.4,491.3,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-35.55,y:-461.3},179).wait(1).to({regX:203.9,regY:223.4,x:-54.95,y:-439.8},0).wait(1).to({x:-57.85,y:-445.05},0).wait(1).to({x:-60.8,y:-450.4},0).wait(1).to({x:-63.8,y:-455.8},0).wait(1).to({x:-66.85,y:-461.35},0).wait(1).to({x:-69.95,y:-466.95},0).wait(1).to({x:-73.1,y:-472.7},0).wait(1).to({x:-76.35,y:-478.55},0).wait(1).to({x:-79.65,y:-484.55},0).wait(1).to({x:-83.05,y:-490.65},0).wait(1).to({x:-86.5,y:-496.9},0).wait(1).to({x:-90,y:-503.3},0).wait(1).to({x:-93.65,y:-509.85},0).wait(1).to({x:-97.35,y:-516.55},0).wait(1).to({x:-101.15,y:-523.45},0).wait(1).to({x:-105.05,y:-530.5},0).wait(1).to({x:-109.05,y:-537.75},0).wait(1).to({x:-113.15,y:-545.25},0).wait(1).to({x:-117.4,y:-552.95},0).wait(1).to({x:-121.8,y:-560.85},0).wait(1).to({x:-126.3,y:-569},0).wait(1).to({x:-130.95,y:-577.45},0).wait(1).to({x:-135.8,y:-586.2},0).wait(1).to({x:-140.75,y:-595.2},0).wait(1).to({x:-145.9,y:-604.55},0).wait(1).to({x:-151.3,y:-614.25},0).wait(1).to({x:-156.85,y:-624.3},0).wait(1).to({x:-162.6,y:-634.75},0).wait(1).to({x:-168.6,y:-645.65},0).wait(1).to({x:-174.85,y:-657},0).wait(1).to({x:-181.4,y:-668.8},0).wait(1).to({x:-188.2,y:-681.1},0).wait(1).to({x:-195.3,y:-694},0).wait(1).to({x:-202.7,y:-707.4},0).wait(1).to({x:-210.45,y:-721.45},0).wait(1).to({x:-218.55,y:-736.15},0).wait(1).to({x:-227.05,y:-751.45},0).wait(1).to({x:-235.85,y:-767.45},0).wait(1).to({regX:220.5,regY:196.8,x:-228.5,y:-810.75},0).to({_off:true},1).wait(1));

	// Excel
	this.instance_4 = new lib.Excel_1();
	this.instance_4.setTransform(677.9,412.35,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:143.95,y:-540.25},179).wait(1).to({regX:226.2,regY:236.3,x:146.85,y:-505.85},0).wait(1).to({x:143.95,y:-511.1},0).wait(1).to({x:141,y:-516.45},0).wait(1).to({x:138,y:-521.85},0).wait(1).to({x:134.95,y:-527.4},0).wait(1).to({x:131.85,y:-533},0).wait(1).to({x:128.7,y:-538.75},0).wait(1).to({x:125.45,y:-544.6},0).wait(1).to({x:122.15,y:-550.6},0).wait(1).to({x:118.75,y:-556.7},0).wait(1).to({x:115.3,y:-562.95},0).wait(1).to({x:111.8,y:-569.35},0).wait(1).to({x:108.15,y:-575.9},0).wait(1).to({x:104.45,y:-582.6},0).wait(1).to({x:100.65,y:-589.5},0).wait(1).to({x:96.75,y:-596.55},0).wait(1).to({x:92.75,y:-603.8},0).wait(1).to({x:88.65,y:-611.3},0).wait(1).to({x:84.4,y:-619},0).wait(1).to({x:80,y:-626.9},0).wait(1).to({x:75.5,y:-635.05},0).wait(1).to({x:70.85,y:-643.5},0).wait(1).to({x:66,y:-652.25},0).wait(1).to({x:61.05,y:-661.25},0).wait(1).to({x:55.9,y:-670.6},0).wait(1).to({x:50.5,y:-680.3},0).wait(1).to({x:44.95,y:-690.35},0).wait(1).to({x:39.2,y:-700.8},0).wait(1).to({x:33.2,y:-711.7},0).wait(1).to({x:26.95,y:-723.05},0).wait(1).to({x:20.4,y:-734.85},0).wait(1).to({x:13.6,y:-747.15},0).wait(1).to({x:6.5,y:-760.05},0).wait(1).to({x:-0.9,y:-773.45},0).wait(1).to({x:-8.65,y:-787.5},0).wait(1).to({x:-16.75,y:-802.2},0).wait(1).to({x:-25.25,y:-817.5},0).wait(1).to({x:-34.05,y:-833.5},0).wait(1).to({regX:220.5,regY:196.8,x:-49,y:-889.7},0).to({_off:true},1).wait(1));

	// PowerPoint
	this.instance_5 = new lib.Wordcopy2();
	this.instance_5.setTransform(698.85,608.5,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:161.85,y:-339.8},179).wait(1).to({regX:211,regY:224.1,x:149.6,y:-317.5},0).wait(1).to({x:146.75,y:-322.65},0).wait(1).to({x:143.85,y:-327.85},0).wait(1).to({x:140.9,y:-333.15},0).wait(1).to({x:137.9,y:-338.6},0).wait(1).to({x:134.85,y:-344.1},0).wait(1).to({x:131.7,y:-349.7},0).wait(1).to({x:128.55,y:-355.45},0).wait(1).to({x:125.3,y:-361.3},0).wait(1).to({x:121.95,y:-367.3},0).wait(1).to({x:118.55,y:-373.4},0).wait(1).to({x:115.1,y:-379.7},0).wait(1).to({x:111.55,y:-386.1},0).wait(1).to({x:107.9,y:-392.65},0).wait(1).to({x:104.15,y:-399.4},0).wait(1).to({x:100.3,y:-406.3},0).wait(1).to({x:96.4,y:-413.45},0).wait(1).to({x:92.3,y:-420.75},0).wait(1).to({x:88.15,y:-428.3},0).wait(1).to({x:83.85,y:-436.05},0).wait(1).to({x:79.4,y:-444.05},0).wait(1).to({x:74.8,y:-452.3},0).wait(1).to({x:70.1,y:-460.85},0).wait(1).to({x:65.2,y:-469.65},0).wait(1).to({x:60.1,y:-478.85},0).wait(1).to({x:54.85,y:-488.3},0).wait(1).to({x:49.4,y:-498.2},0).wait(1).to({x:43.7,y:-508.4},0).wait(1).to({x:37.8,y:-519.1},0).wait(1).to({x:31.65,y:-530.15},0).wait(1).to({x:25.2,y:-541.75},0).wait(1).to({x:18.5,y:-553.8},0).wait(1).to({x:11.55,y:-566.4},0).wait(1).to({x:4.25,y:-579.55},0).wait(1).to({x:-3.4,y:-593.3},0).wait(1).to({x:-11.35,y:-607.65},0).wait(1).to({x:-19.7,y:-622.7},0).wait(1).to({x:-28.35,y:-638.35},0).wait(1).to({regX:220.5,regY:196.8,x:-27.95,y:-682},0).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-548.9,-1221.1,1564.1,2079.1);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// icons
	this.icons = new lib.laptop_anim();
	this.icons.name = "icons";
	this.icons.setTransform(319.3,515.65,0.85,0.85,0,0,0,283.9,24.8);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	// screen
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(319.3,515.65,0.85,0.85,0,0,0,283.9,24.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,196,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(233.45,554.55,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(278.2,554.8,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// BG
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-1,0,987.9,1280), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var phone = mc.phone
		
		/*mc.cta.alpha=0
		mc.replay_btn.alpha=0*/
		
		this.runBanner = function() {
			
			this.tl1 = new TimelineLite();
						
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "+=0", alpha: 0, ease:Power4.easeIn}, "+=1.8");
				if (i!=0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "+=0", alpha: 0, ease:Power4.easeIn}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=1.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
				
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149,300,837.9,980);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1582111259985", id:"O365_FY20Q4_Cons_USA_300x600_BAN_PPT_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;