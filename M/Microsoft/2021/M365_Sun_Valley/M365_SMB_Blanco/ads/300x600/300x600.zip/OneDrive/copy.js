// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	bannerData.headline1 = ['<#2f2f2f>Store','22.5px',120,290,'28.5','350', 'center'];
	bannerData.headline2 = ['<#2f2f2f>up','22.5px',165,290,'28.5','350', 'center'];
	bannerData.headline3 = ['<#2f2f2f>to','22.5px',195,290,'28.5','350', 'center'];
	bannerData.headline4 = ['<#2f2f2f>1 TB','22.5px',83,290,'28.5','350', 'center'];
	bannerData.headline5 = ['<#2f2f2f>in','22.5px',118,290,'28.5','350', 'center'];
	bannerData.headline6 = ['<#2f2f2f>the','22.5px',150,290,'28.5','350', 'center'];
	bannerData.headline7 = ['<#2f2f2f>cloud','22.5px',200,290,'28.5','350', 'center'];
	bannerData.headline8 = ['<#2f2f2f>Sync','22.5px',150,290,'28.5','350', 'center'];
	bannerData.headline9 = ['<#2f2f2f>to','22.5px',150,290,'28.5','350', 'center'];
	bannerData.headline10 = ['<#2f2f2f>your','22.5px',150,290,'28.5','350', 'center'];
	bannerData.headline11 = ['<#2f2f2f>desktop','22.5px',150,290,'28.5','350', 'center'];

	bannerData.headline12 = ['<#2f2f2f>Feel confident knowing|your business is secured|in the cloud','22.5px',31,70,'24','350', 'left'];


	bannerData.CTA = ['<#FFFFFF>TRY NOW','12px',0,0,'50','300', 'center'];
	
	bannerData.CTAarrowVisible = [true, 0,0]
