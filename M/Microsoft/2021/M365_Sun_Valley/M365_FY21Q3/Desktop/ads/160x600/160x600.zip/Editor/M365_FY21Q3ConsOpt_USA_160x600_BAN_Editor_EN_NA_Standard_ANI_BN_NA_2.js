(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1", frames: [[574,684,283,76],[352,914,303,67],[352,826,320,86],[0,684,350,300],[352,684,220,140],[0,0,926,682],[796,762,72,74],[674,762,120,111],[657,914,200,70]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Image34pngcopy = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Image36 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Image34 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.interfaceCreateAPostShadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.interfaceDropdownShadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.newBG = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.quill = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.WordEditorScreen1 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white_bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(147.1,224.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white_bg, new cjs.Rectangle(67.1,-75.2,160,600), null);


(lib.top_blue = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0378B4").s().p("A3bF9IAAr5MAu3AAAIAAL5g");
	this.shape.setTransform(150,38.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_blue, new cjs.Rectangle(0,0,300,76.2), null);


(lib.textWrong3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALARAAQAVAAgBgPQAAgEgCgDQgBgDgDgCIgIgFIgIgDIgNgGQgFgCgEgDQgDgEgCgEQgBgEAAgHQAAgHADgFQADgGAGgEQAGgEAGgCQAIgCAGAAQAOAAALAFIAAARQgMgIgOAAIgIACQgEABgDACQgDABgBADQgCACAAAEQAAAEACADIAEAEIAIAFIAIADIAMAGQAGACADAEQAFADACAFQACAEAAAHQAAAHgDAGQgEAFgGAEQgGAFgHABQgIACgGAAQgRAAgMgHg");
	this.shape.setTransform(101.15,19.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AggApQgNgOAAgbQAAgXAOgPQAOgQATAAQAVAAALANQAMANAAAZIAAAHIhJAAQAAARAJALQAJAJAPAAQASAAAOgMIAAAQQgNAKgXAAQgVAAgNgOgAAcgJQAAgPgHgIQgHgIgMAAQgLAAgIAIQgIAJgCAOIA3AAIAAAAg");
	this.shape_1.setTransform(91.225,19.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AgIBOIAAibIAQAAIAACbg");
	this.shape_2.setTransform(83.15,16.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgbA2IAAhpIARAAIAAAWQAFgLAGgGQAHgGAJgBQAHABAEABIAAARQgFgDgJAAQgKAAgHALQgGAKgBAQIAAA2g");
	this.shape_3.setTransform(72,19.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgqAJIAAg+IAQAAIAAA7QAAAiAZAAQAMAAAHgJQAIgKAAgOIAAg8IARAAIAABoIgRAAIAAgQIAAAAQgKATgVAAQgmAAABgtg");
	this.shape_4.setTransform(61.55,19.525);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgkApQgPgQAAgYQAAgZAPgPQAPgPAXAAQAYAAAMAPQANAOABAZQgBAZgOAPQgNAPgYAAQgXAAgNgOgAgYgcQgKAKAAASQAAAUAKAKQAJALAPAAQARAAAJgLQAJgLAAgTQAAgTgJgKQgJgLgRAAQgPAAgJAMg");
	this.shape_5.setTransform(49.55,19.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgcBiIAAgPQAJAEAGAAQAWAAAAglIAAhmIARAAIAABkQAAAZgLAOQgKAOgSABQgIgBgHgDgAAKhSQgDgDAAgEQAAgFADgDQADgEAEAAQAFAAADAEQAEADAAAFQAAAEgEADQgDADgFABQgEAAgDgEg");
	this.shape_6.setTransform(39.15,19.45);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AAbA2IAAg7QAAgigZAAQgLAAgJAKQgHAJgBAPIAAA7IgRAAIAAhoIARAAIAAARQAMgUAWAAQARAAAKALQAJAMgBAVIAAA/g");
	this.shape_7.setTransform(32.55,19.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AglApQgOgQABgYQAAgZAOgPQAPgPAXAAQAYAAANAPQAMAOAAAZQAAAZgNAPQgPAPgXAAQgXAAgOgOgAgYgcQgJAKAAASQAAAUAJAKQAJALAQAAQAQAAAJgLQAJgLgBgTQABgTgJgKQgJgLgQAAQgQAAgJAMg");
	this.shape_8.setTransform(20.35,19.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgsBKIAAiSIApAAQASgBAMAKQALAJAAAPQAAANgHAJQgHAJgMAEIAAAAQAPACAJAIQAJAKAAAPQAAATgNAMQgOAMgUAAgAgbA6IAXAAQAOAAAJgIQAIgGAAgNQAAgagiAAIgUAAgAgbgJIARAAQAOAAAIgHQAIgHAAgMQAAgWgbAAIgUAAg");
	this.shape_9.setTransform(8.675,17.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong3_4, new cjs.Rectangle(0,0,107.7,59.8), null);


(lib.textWrong3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALAQAAQAWAAAAgPQgBgEgCgDQgBgDgDgCIgIgFIgIgDIgMgGQgGgCgDgDQgEgEgCgEQgCgEABgHQgBgHAEgFQADgGAGgEQAFgEAIgCQAHgCAGAAQAOAAALAFIAAARQgLgIgQAAIgHACQgEABgDACQgDABgBADQgBACAAAEQAAAEABADIAEAEIAHAFIAIADIAOAGQAFACAEAEQAEADABAFQADAEAAAHQAAAHgEAGQgDAFgGAEQgFAFgIABQgIACgGAAQgRAAgMgHg");
	this.shape.setTransform(75.25,19.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALAQAAQAWAAAAgPQAAgEgDgDQgBgDgDgCIgIgFIgJgDIgLgGQgGgCgDgDQgEgEgCgEQgCgEABgHQAAgHADgFQADgGAGgEQAFgEAIgCQAHgCAGAAQAOAAALAFIAAARQgMgIgPAAIgHACQgEABgDACQgCABgCADQgCACABAEQgBAEACADIAEAEIAHAFIAIADIAOAGQAFACAEAEQADADACAFQADAEAAAHQAAAHgEAGQgDAFgGAEQgGAFgHABQgHACgIAAQgQAAgMgHg");
	this.shape_1.setTransform(66.35,19.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AgIBNIAAhoIAQAAIAABogAgHg5QgDgDAAgFQAAgEADgEQADgDAEAAQAEAAAEADQADAEAAAEQAAAFgDADQgEADgEAAQgEAAgDgDg");
	this.shape_2.setTransform(59.325,16.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AA6A2IAAg8QAAgRgGgIQgFgIgNAAQgLAAgHAKQgHAKgBAOIAAA7IgQAAIAAg+QABgfgYAAQgMAAgGAKQgIAJABAPIAAA7IgRAAIAAhoIARAAIAAAQQALgTAVAAQALAAAIAGQAHAGADAKQAMgWAXAAQAjAAgBArIAABAg");
	this.shape_3.setTransform(47.85,19.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgfAuQgJgHAAgOQAAgdAjgFIAegEQAAgbgWAAQgSAAgPANIAAgRQAPgKAUAAQAlAAAAAnIAABEIgRAAIAAgRIgBAAQgLATgUAAQgQAAgIgJgAAAADQgLACgGAEQgGAEAAALQAAAHAFAFQAGAFAJAAQALAAAJgJQAIgJAAgNIAAgKg");
	this.shape_4.setTransform(33.1,19.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong3_2, new cjs.Rectangle(26,0,55.7,31.9), null);


(lib.textWrong3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALAQAAQAWAAAAgPQgBgEgCgDQgBgDgDgCIgIgFIgIgDIgMgGQgGgCgDgDQgEgEgCgEQgCgEABgHQgBgHAEgFQADgGAGgEQAFgEAIgCQAHgCAGAAQAOAAALAFIAAARQgLgIgQAAIgHACQgEABgDABQgDACgBADQgBACAAAEQAAAEABADIAEAEIAHAFIAIADIAOAGQAFACAEAEQAEADABAFQADAEAAAHQAAAHgEAGQgDAFgGAEQgFAFgIABQgIACgGAAQgRAAgMgHg");
	this.shape.setTransform(75.25,47.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALAQAAQAWAAAAgPQAAgEgDgDQgBgDgDgCIgIgFIgJgDIgLgGQgGgCgDgDQgEgEgCgEQgCgEABgHQAAgHADgFQADgGAGgEQAFgEAIgCQAHgCAGAAQAOAAALAFIAAARQgMgIgPAAIgHACQgEABgDABQgCACgCADQgCACABAEQgBAEACADIAEAEIAHAFIAIADIAOAGQAFACAEAEQADADACAFQADAEAAAHQAAAHgEAGQgDAFgGAEQgGAFgHABQgHACgIAAQgQAAgMgHg");
	this.shape_1.setTransform(66.35,47.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AgIBNIAAhoIAQAAIAABogAgHg5QgDgDAAgFQAAgEADgEQADgDAEAAQAEAAAEADQADAEAAAEQAAAFgDADQgEADgEAAQgEAAgDgDg");
	this.shape_2.setTransform(59.325,44.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AA6A2IAAg8QAAgRgGgIQgFgIgNAAQgLAAgHAKQgHAKgBAOIAAA7IgQAAIAAg+QABgfgYAAQgMAAgGAKQgIAJABAPIAAA7IgRAAIAAhoIARAAIAAAQQALgTAVAAQALAAAIAGQAHAGADAKQAMgWAXAAQAjAAgBArIAABAg");
	this.shape_3.setTransform(47.85,47.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgfAuQgJgHAAgOQAAgdAjgFIAegEQAAgbgWAAQgSAAgPANIAAgRQAPgKAUAAQAlAAAAAnIAABEIgRAAIAAgRIgBAAQgLATgUAAQgQAAgIgJgAAAADQgLACgGADQgGAFAAALQAAAHAFAFQAGAFAJAAQALAAAJgJQAIgJAAgNIAAgKg");
	this.shape_4.setTransform(33.1,47.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALARAAQAVAAgBgPQAAgEgCgDQgBgDgDgCIgIgFIgIgDIgNgGQgFgCgEgDQgDgEgCgEQgBgEAAgHQAAgHADgFQADgGAGgEQAGgEAGgCQAIgCAGAAQAOAAALAFIAAARQgMgIgOAAIgIACQgEABgDACQgDABgBADQgCACAAAEQAAAEACADIAEAEIAIAFIAIADIAMAGQAGACADAEQAFADACAFQACAEAAAHQAAAHgDAGQgEAFgGAEQgGAFgHABQgIACgGAAQgRAAgMgHg");
	this.shape_5.setTransform(101.15,19.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AggApQgNgOAAgbQAAgXAOgPQAOgQATAAQAVAAALANQAMANAAAZIAAAHIhJAAQAAARAJALQAJAJAPAAQASAAAOgMIAAAQQgNAKgXAAQgVAAgNgOgAAcgJQAAgPgHgIQgHgIgMAAQgLAAgIAIQgIAJgCAOIA3AAIAAAAg");
	this.shape_6.setTransform(91.225,19.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AgIBOIAAibIAQAAIAACbg");
	this.shape_7.setTransform(83.15,16.875);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AgbA2IAAhpIARAAIAAAWQAFgLAGgGQAHgGAJgBQAHABAEABIAAARQgFgDgJAAQgKAAgHALQgGAKgBAQIAAA2g");
	this.shape_8.setTransform(72,19.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgqAJIAAg+IAQAAIAAA7QAAAiAZAAQAMAAAHgJQAIgKAAgOIAAg8IARAAIAABoIgRAAIAAgQIAAAAQgKATgVAAQgmAAABgtg");
	this.shape_9.setTransform(61.55,19.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4B4A4A").s().p("AgkApQgPgQAAgYQAAgZAPgPQAPgPAXAAQAYAAAMAPQANAOABAZQgBAZgOAPQgNAPgYAAQgXAAgNgOgAgYgcQgKAKAAASQAAAUAKAKQAJALAPAAQARAAAJgLQAJgLAAgTQAAgTgJgKQgJgLgRAAQgPAAgJAMg");
	this.shape_10.setTransform(49.55,19.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4B4A4A").s().p("AgcBiIAAgPQAJAEAGAAQAWAAAAglIAAhmIARAAIAABkQAAAZgLAOQgKAOgSABQgIgBgHgDgAAKhSQgDgDAAgEQAAgFADgDQADgEAEAAQAFAAADAEQAEADAAAFQAAAEgEADQgDADgFABQgEAAgDgEg");
	this.shape_11.setTransform(39.15,19.45);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4B4A4A").s().p("AAbA2IAAg7QAAgigZAAQgLAAgJAKQgHAJgBAPIAAA7IgRAAIAAhoIARAAIAAARQAMgUAWAAQARAAAKALQAJAMgBAVIAAA/g");
	this.shape_12.setTransform(32.55,19.275);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4B4A4A").s().p("AglApQgOgQABgYQAAgZAOgPQAPgPAXAAQAYAAANAPQAMAOAAAZQAAAZgNAPQgPAPgXAAQgXAAgOgOgAgYgcQgJAKAAASQAAAUAJAKQAJALAQAAQAQAAAJgLQAJgLgBgTQABgTgJgKQgJgLgQAAQgQAAgJAMg");
	this.shape_13.setTransform(20.35,19.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#4B4A4A").s().p("AgsBKIAAiSIApAAQASgBAMAKQALAJAAAPQAAANgHAJQgHAJgMAEIAAAAQAPACAJAIQAJAKAAAPQAAATgNAMQgOAMgUAAgAgbA6IAXAAQAOAAAJgIQAIgGAAgNQAAgagiAAIgUAAgAgbgJIARAAQAOAAAIgHQAIgHAAgMQAAgWgbAAIgUAAg");
	this.shape_14.setTransform(8.675,17.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong3, new cjs.Rectangle(0.1,0,107.5,59.8), null);


(lib.post_button = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAnApQgIgFgCgLIAPAAQADALAQAAQAQAAAAgJQAAgEgEgDQgEgCgLgBQgcgEAAgPQAAgIAGgGQAIgGAOAAQAQAAAIAHQAGAFABAIIgOAAQgDgKgOABQgOAAAAAHQAAAEAEABQADACALABQARADAHAGQAFAFAAAIQAAAKgHAEQgIAHgQAAQgOAAgJgGgAguAlQgJgLAAgOQAAgOAJgJQAKgLARAAQARAAAJALQAJAKAAANQAAAPgKAKQgJAKgRAAQgQAAgKgKgAgjgEQgGAGAAAKQAAAJAGAHQAGAHAKAAQAKAAAGgHQAEgGAAgKQAAgKgFgGQgGgGgKAAQgKAAgFAGgAB5ApQgEgEAAgKIAAgkIgNAAIAAgLIANAAIAAgVIAPAAIAAAVIARAAIAAALIgRAAIAAAhQAAAGABACQACACAFABIAHgBIAAALIgLABQgLgBgEgEgAiUAtIAAhbIAsAAQARAAAJAIQAIAHAAANQAAANgJAGQgJAIgPAAIgeAAIAAAkgAiFgCIAcAAQAUAAAAgQQAAgPgUgBIgcAAg");
	this.shape.setTransform(36.4256,19.5503);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AlADBQgrAAAAgyIAAkeQAAgwArgBIJ/AAQAtABAAAwIAAEeQAAAygtAAg");
	this.shape_1.setTransform(36.4,19.25);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.post_button, new cjs.Rectangle(0,0,72.8,38.5), null);


(lib.overlayBar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,102,204,0.349)").s().p("ArABGIAAiLIWBAAIAACLg");
	this.shape.setTransform(70.5,7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlayBar, new cjs.Rectangle(0,0,141,14), null);


(lib.textWrong2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgHBHQgDgDAAgFQAAgEADgEQADgDAEAAQAFAAADADQADAEAAAEQAAAFgDADQgDADgFAAQgEAAgDgDgAgGAfIgChoIARAAIgCBog");
	this.shape.setTransform(131.875,17.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALARAAQAVAAgBgPQAAgEgCgDQgBgDgDgCIgIgFIgIgDIgNgGQgFgCgEgDQgDgEgCgEQgBgEAAgHQAAgHADgFQADgGAGgEQAGgEAGgCQAIgCAGAAQAOAAALAFIAAARQgMgIgOAAIgIACQgEABgDACQgDABgBADQgCACAAAEQAAAEACADIAEAEIAIAFIAIADIAMAGQAGACADAEQAFADACAFQACAEAAAHQAAAHgDAGQgEAFgGAEQgGAFgHABQgIACgGAAQgRAAgMgHg");
	this.shape_1.setTransform(124.55,19.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AglApQgOgQABgYQAAgZAOgPQAOgPAYAAQAYAAANAPQANAOgBAZQABAZgOAPQgOAPgYAAQgXAAgOgOgAgYgcQgJAKAAASQAAAUAJAKQAJALAQAAQAQAAAJgLQAJgLgBgTQABgTgJgKQgJgLgQAAQgQAAgJAMg");
	this.shape_2.setTransform(113.85,19.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgoBHIAAgRQASAKAQAAQAmAAAAgpIAAgMIgBAAQgMAVgXAAQgUAAgLgPQgMgOAAgWQAAgbANgQQAMgQAWAAQAVAAAKARIABAAIAAgOIAQAAIAABfQAAA7g2AAQgTgBgPgHgAgVg0QgJAMAAAUQAAASAIAJQAJAKANAAQAOABAJgKQAJgKAAgQIAAgPQAAgMgJgKQgIgJgNABQgPAAgIALg");
	this.shape_3.setTransform(101.175,21.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AggApQgNgOAAgbQAAgXAOgPQAOgQATAAQAVAAALANQAMANAAAZIAAAHIhJAAQAAARAJALQAJAJAPAAQASAAAOgMIAAAQQgNAKgXAAQgVAAgNgOgAAcgJQAAgPgHgIQgHgIgMAAQgLAAgIAIQgIAJgCAOIA3AAIAAAAg");
	this.shape_4.setTransform(89.975,19.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgIBNIAAhoIAQAAIAABogAgHg5QgDgDAAgFQAAgEADgEQADgDAEAAQAEAAAEADQADAEAAAEQAAAFgDADQgEADgEAAQgEAAgDgDg");
	this.shape_5.setTransform(81.925,16.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AA6A2IAAg8QAAgRgGgIQgFgIgNAAQgLAAgHAKQgIAKAAAOIAAA7IgQAAIAAg+QAAgfgXAAQgMAAgGAKQgIAJABAPIAAA7IgSAAIAAhoIASAAIAAAQQALgTAWAAQAKAAAIAGQAHAGADAKQAMgWAXAAQAjAAAAArIAABAg");
	this.shape_6.setTransform(70.45,19.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AgfAuQgKgHABgOQgBgdAkgFIAegEQAAgbgWAAQgRAAgQANIAAgRQAQgKATAAQAlAAgBAnIAABEIgQAAIAAgRIgBAAQgKATgVAAQgQAAgIgJgAAAADQgLACgGAEQgGAEAAALQAAAHAFAFQAGAFAJAAQALAAAJgJQAIgJAAgNIAAgKg");
	this.shape_7.setTransform(55.7,19.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AgfAuQgJgHAAgOQAAgdAigFIAfgEQAAgbgWAAQgRAAgQANIAAgRQAPgKAUAAQAkAAABAnIAABEIgRAAIAAgRIAAAAQgMATgUAAQgQAAgIgJgAAAADQgLACgGAEQgGAEAAALQAAAHAFAFQAGAFAJAAQALAAAJgJQAIgJAAgNIAAgKg");
	this.shape_8.setTransform(39.3,19.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgIBOIAAibIAQAAIAACbg");
	this.shape_9.setTransform(31.75,16.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4B4A4A").s().p("AglApQgOgQABgYQAAgZAOgPQAPgPAXAAQAYAAANAPQAMAOAAAZQAAAZgNAPQgPAPgXAAQgXAAgOgOgAgYgcQgJAKAAASQAAAUAJAKQAJALAQAAQAQAAAJgLQAJgLgBgTQABgTgJgKQgJgLgQAAQgQAAgJAMg");
	this.shape_10.setTransform(23.05,19.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4B4A4A").s().p("AAmBKIAAhEIhLAAIAABEIgRAAIAAiSIARAAIAABAIBLAAIAAhAIARAAIAACSg");
	this.shape_11.setTransform(9.475,17.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong2, new cjs.Rectangle(0,0,137.1,31.9), null);


(lib.textWrong1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALAQAAQAWAAgBgPQAAgEgCgDQgBgDgDgCIgIgFIgIgDIgNgGQgFgCgEgDQgDgEgCgEQgBgEAAgHQgBgHAEgFQADgGAGgEQAGgEAGgCQAIgCAGAAQAOAAALAFIAAARQgMgIgOAAIgIACQgEABgDACQgDABgBADQgBACAAAEQAAAEABADIAEAEIAHAFIAJADIAMAGQAGACADAEQAFADABAFQADAEAAAHQAAAHgEAGQgDAFgGAEQgFAFgIABQgIACgGAAQgRAAgMgHg");
	this.shape.setTransform(114.3,19.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgkBBQgLgOAAgZQAAgaANgOQANgQAVAAQAVAAAKARIABAAIAAhBIAQAAIAACbIgQAAIAAgSIgBAAQgMAUgXAAQgUAAgMgOgAgVgEQgJAKAAATQAAATAIAKQAJALANAAQAOAAAJgLQAJgJAAgQIAAgPQAAgNgJgIQgIgJgNAAQgPAAgIAMg");
	this.shape_1.setTransform(103.225,17);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AAbA2IAAg7QAAgigYAAQgMAAgJAKQgHAJgBAPIAAA7IgRAAIAAhoIARAAIAAARQAMgUAWAAQARAAAJALQAKAMgBAVIAAA/g");
	this.shape_2.setTransform(91.6,19.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgIBNIAAhoIAQAAIAABogAgHg5QgDgDAAgFQAAgEADgEQADgDAEAAQAEAAAEADQADAEAAAEQAAAFgDADQgEADgEAAQgEAAgDgDg");
	this.shape_3.setTransform(83.075,16.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AggApQgNgOAAgbQAAgXAOgPQAOgQATAAQAVAAALANQAMANAAAZIAAAHIhJAAQAAARAJALQAJAJAPAAQASAAAOgMIAAAQQgNAKgXAAQgVAAgNgOgAAcgJQAAgPgHgIQgHgIgMAAQgLAAgIAIQgIAJgCAOIA3AAIAAAAg");
	this.shape_4.setTransform(75.125,19.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgaA2IAAhpIARAAIAAAWQADgLAGgGQAIgGAJgBQAHABAEABIAAARQgFgDgIAAQgLAAgGALQgIAKABAQIAAA2g");
	this.shape_5.setTransform(67,19.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgNBPIAAhaIgSAAIAAgOIASAAIAAgRQAAgRAKgJQAIgKAOAAQAIAAAFACIAAAPQgFgDgHAAQgRAAAAAXIAAAQIAYAAIAAAOIgYAAIAABag");
	this.shape_6.setTransform(59.725,16.775);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AglApQgOgQABgYQAAgZAOgPQAOgPAYAAQAYAAANAPQANAOgBAZQABAZgOAPQgOAPgYAAQgXAAgOgOgAgYgcQgJAKAAASQAAAUAJAKQAJALAQAAQAQAAAJgLQAJgLgBgTQABgTgJgKQgJgLgQAAQgQAAgJAMg");
	this.shape_7.setTransform(44.1,19.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AgIBOIAAibIAQAAIAACbg");
	this.shape_8.setTransform(35.45,16.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgIBOIAAibIAQAAIAACbg");
	this.shape_9.setTransform(30.4,16.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4B4A4A").s().p("AggApQgNgOAAgbQAAgXAOgPQAOgQATAAQAVAAALANQAMANAAAZIAAAHIhJAAQAAARAJALQAJAJAPAAQASAAAOgMIAAAQQgNAKgXAAQgVAAgNgOgAAcgJQAAgPgHgIQgHgIgMAAQgLAAgIAIQgIAJgCAOIA3AAIAAAAg");
	this.shape_10.setTransform(22.475,19.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4B4A4A").s().p("AAmBKIAAhEIhLAAIAABEIgRAAIAAiSIARAAIAABAIBLAAIAAhAIARAAIAACSg");
	this.shape_11.setTransform(9.475,17.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong1, new cjs.Rectangle(0,0,120.9,31.9), null);


(lib.textCorrect2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgHBHQgDgDAAgFQAAgEADgEQADgDAEAAQAFAAADADQADAEAAAEQAAAFgDADQgDADgFAAQgEAAgDgDgAgGAfIgChoIARAAIgCBog");
	this.shape.setTransform(72.275,17.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALARAAQAUAAAAgPQAAgEgBgDQgCgDgEgCIgHgFIgJgDIgMgGQgFgCgEgDQgDgEgCgEQgCgEAAgHQAAgHAEgFQADgGAGgEQAGgEAGgCQAIgCAHAAQANAAALAFIAAARQgLgIgPAAIgIACQgEABgCACQgDABgCADQgBACgBAEQABAEABADIAFAEIAHAFIAIADIAMAGQAGACADAEQAEADADAFQACAEAAAHQAAAHgDAGQgEAFgGAEQgFAFgIABQgIACgHAAQgQAAgMgHg");
	this.shape_1.setTransform(64.95,19.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AglApQgNgQAAgYQAAgZAOgPQAOgPAYAAQAYAAANAPQANAOgBAZQAAAZgOAPQgOAPgXAAQgXAAgOgOgAgYgcQgKAKAAASQAAAUAKAKQAKALAOAAQARAAAJgLQAIgLAAgTQAAgTgIgKQgJgLgRAAQgOAAgKAMg");
	this.shape_2.setTransform(54.25,19.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgoBHIAAgRQASAKAQAAQAmAAAAgpIAAgMIgBAAQgMAVgXAAQgUAAgLgPQgMgOAAgWQAAgbANgQQAMgQAWAAQAVAAAKARIABAAIAAgOIAQAAIAABfQAAA7g2AAQgTgBgPgHgAgVg0QgJAMAAAUQAAASAIAJQAJAKANAAQAOABAJgKQAJgKAAgQIAAgPQAAgMgJgKQgIgJgNABQgPAAgIALg");
	this.shape_3.setTransform(41.575,21.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgIBNIAAhoIAQAAIAABogAgHg5QgDgDAAgFQAAgEADgEQADgDAEAAQAEAAAEADQADAEAAAEQAAAFgDADQgEADgEAAQgEAAgDgDg");
	this.shape_4.setTransform(33.275,16.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AA6A2IAAg8QAAgRgFgIQgGgIgMAAQgLAAgIAKQgIAKABAOIAAA7IgQAAIAAg+QgBgfgXAAQgLAAgIAKQgGAJgBAPIAAA7IgRAAIAAhoIARAAIAAAQQAMgTAWAAQAKAAAIAGQAHAGADAKQAMgWAXAAQAiAAABArIAABAg");
	this.shape_5.setTransform(21.8,19.275);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AggAuQgIgHgBgOQABgdAigFIAfgEQAAgbgWAAQgSAAgPANIAAgRQAQgKASAAQAlAAAAAnIAABEIgQAAIAAgRIAAAAQgLATgVAAQgPAAgKgJgAAAADQgLACgGAEQgGAEAAALQAAAHAGAFQAFAFAJAAQAMAAAIgJQAIgJAAgNIAAgKg");
	this.shape_6.setTransform(7.05,19.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textCorrect2, new cjs.Rectangle(0,0,77.5,31.9), null);


(lib.textCorrect1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgiAwIAAgSQAOALAQAAQAWAAAAgPQAAgEgCgDQgCgDgEgCIgHgFIgJgDIgLgGQgGgCgDgDQgEgEgCgEQgBgEgBgHQABgHADgFQADgGAGgEQAFgEAIgCQAHgCAGAAQAOAAALAFIAAARQgMgIgPAAIgHACQgEABgCACQgEABgBADQgCACABAEQgBAEACADIAFAEIAGAFIAIADIAOAGQAFACAEAEQADADACAFQADAEAAAHQAAAHgEAGQgDAFgGAEQgGAFgHABQgHACgIAAQgQAAgMgHg");
	this.shape.setTransform(60.6,19.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgkBBQgLgOAAgZQAAgaANgOQANgQAVAAQAVAAAKARIABAAIAAhBIAQAAIAACbIgQAAIAAgSIgBAAQgMAUgXAAQgUAAgMgOgAgVgEQgJAKAAATQAAATAIAKQAJALANAAQAOAAAJgLQAJgJAAgQIAAgPQAAgNgJgIQgIgJgNAAQgPAAgIAMg");
	this.shape_1.setTransform(49.525,17);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AAbA2IAAg7QAAgigYAAQgMAAgIAKQgIAJAAAPIAAA7IgRAAIAAhoIARAAIAAARQALgUAWAAQASAAAIALQAJAMAAAVIAAA/g");
	this.shape_2.setTransform(37.9,19.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AggApQgNgOAAgbQAAgXAOgPQAOgQATAAQAVAAALANQAMANAAAZIAAAHIhJAAQAAARAJALQAJAJAPAAQASAAAOgMIAAAQQgNAKgXAAQgVAAgNgOgAAcgJQAAgPgHgIQgHgIgMAAQgLAAgIAIQgIAJgCAOIA3AAIAAAAg");
	this.shape_3.setTransform(26.475,19.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgIBNIAAhoIAQAAIAABogAgHg5QgDgDAAgFQAAgEADgEQADgDAEAAQAEAAAEADQADAEAAAEQAAAFgDADQgEADgEAAQgEAAgDgDg");
	this.shape_4.setTransform(18.425,16.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgaA2IAAhpIARAAIAAAWQADgLAHgGQAHgGAJgBQAHABAEABIAAARQgFgDgIAAQgLAAgGALQgIAKABAQIAAA2g");
	this.shape_5.setTransform(13,19.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgNBPIAAhaIgSAAIAAgOIASAAIAAgRQAAgRAKgJQAIgKAOAAQAIAAAFACIAAAPQgFgDgHAAQgRAAAAAXIAAAQIAYAAIAAAOIgYAAIAABag");
	this.shape_6.setTransform(5.725,16.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textCorrect1, new cjs.Rectangle(0,0,67.2,31.9), null);


(lib.interfaceDropdown = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#707070").ss(1,1,1).p("ArEmTIWJAAIAAMnI2JAAg");
	this.shape.setTransform(70.875,40.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ArEGUIAAsnIWJAAIAAMng");
	this.shape_1.setTransform(70.875,40.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropdown, new cjs.Rectangle(-1,-1,143.8,82.8), null);


(lib.interfaceClosebtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,1,1).p("AAAAAIBABAAAAAAIg/BAABAg/IhAA/Ag/g/IA/A/");
	this.shape.setTransform(4.55,4.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceClosebtn, new cjs.Rectangle(-2.8,-2.8,14.7,14.7), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tile_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.mask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.interfaceTextRedHighlight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FAEAEA").s().p("ArXDUIAAmnIWvAAIAAGng");
	this.shape.setTransform(59.475,24.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("ArXALIAAgUIWvAAIAAAUg");
	this.shape_1.setTransform(59.475,46.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceTextRedHighlight, new cjs.Rectangle(-13.3,3.2,145.60000000000002,44.5), null);


(lib.interfaceQuill = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.quill();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceQuill, new cjs.Rectangle(0,0,72,74), null);


(lib.interfaceDropdownShadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.interfaceDropdownShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropdownShadow_1, new cjs.Rectangle(0,0,220,140), null);


(lib.interfaceBrowserWindowAngled = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.newBG();
	this.instance.setTransform(-100.25,-122.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceBrowserWindowAngled, new cjs.Rectangle(-100.2,-122.7,926,682), null);


(lib.Createpost = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ACQAyIAAhMIALAAIABAJQAFgLAOAAQALAAAHAIQAIAIAAAMQAAAMgJAIQgHAIgMAAQgMAAgFgJIAAAfgACfgMQgEAEAAAIQAAAIAEAFQAFAGAIgBQAHAAAFgFQAFgGAAgHQAAgHgFgFQgEgGgIAAQgIAAgFAGgAEjAYQgHgFgCgJIAMAAQADAKANgBQANABAAgIQAAgDgDgCQgDgDgKAAQgWgEAAgLQAAgGAFgFQAGgFAMgBQAMABAHAFQAFAFABAGIgMAAQgCgIgMAAQgKAAAAAHQAAADACABIALADQAOACAGADQAEAEABAHQAAAIgHAEQgGAFgNAAQgLAAgHgEgADcATQgHgHAAgMQAAgLAHgIQAJgJANAAQANAAAIAJQAIAIAAALQAAAMgIAHQgIAJgNAAQgNAAgJgJgADlgMQgEAEAAAIQAAAHAEAGQAFAGAIgBQAIABAEgGQAFgFAAgIQAAgHgFgFQgEgGgIAAQgJAAgEAGgAAqAXQgFgGAAgGQAAgRAcAAIAMAAIAAgDQAAgKgMAAQgMAAgBAIIgMAAQABgGAFgEQAGgHANAAQAYABAAASIABAjIgMAAIgBgHQgEAJgPAAQgLAAgFgFgAAwAKQAAAEADACQAEADAFAAQASAAgBgQIAAgCIgMAAQgRAAAAAJgAg6ATQgHgIAAgLQAAgMAIgHQAHgJAOAAQAOAAAHAJQAHAIAAALIAAADIgtAAQAAAGAFAFQAFAFAHAAQAKAAAFgIIAMAAQgGARgVAAQgOAAgIgJgAgVgEQAAgGgDgDQgFgGgHAAQgIAAgEAFQgEADAAAHIAfAAIAAAAgAisAXQgFgGAAgGQAAgRAcAAIAMAAIAAgDQAAgKgNAAQgLAAgBAIIgMAAQABgGAFgEQAGgHAMAAQAZABAAASIABAjIgLAAIgCgHQgEAJgPAAQgLAAgFgFgAimAKQAAAEAEACQACADAHAAQAQAAAAgQIAAgCIgMAAQgRAAAAAJgAjvATQgGgIAAgLQAAgMAHgHQAIgJANAAQAOAAAIAJQAGAIAAALIAAADIgsAAQAAAGAEAFQAGAFAHAAQAKAAAEgIIAMAAQgGARgUAAQgOAAgJgJgAjJgEQAAgGgDgDQgFgGgIAAQgHAAgFAFQgEADAAAHIAgAAIAAAAgAlxAQQgKgKAAgQQAAgQALgLQAKgLATAAQAOAAAKAHQAIAHACAJIgNAAQgFgOgRABQgMgBgHAJQgHAHAAANQAAALAHAIQAHAJAMAAQAKAAAFgDQAEgEADgHIANAAQgHAYgcAAQgTAAgKgMgAFlAXQgDgEAAgHIAAgdIgKAAIAAgJIAKAAIAAgRIAMAAIAAARIAOAAIAAAJIgOAAIAAAaIACAHQACACADAAIAGgBIAAAJIgJABQgJAAgEgEgAhiAXQgDgEAAgHIAAgdIgLAAIAAgJIALAAIAAgRIAMAAIAAARIANAAIAAAJIgNAAIAAAaIABAHQACACAEAAIAFgBIAAAJIgJABQgJAAgDgEgAkgAaIAAg0IALAAIABAMQACgGAGgEQAFgDAIgBIAAALQgKAAgFAGQgHAFABALIAAAVg");
	this.shape.setTransform(60.4343,11.6714,1.5106,1.7033);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Createpost, new cjs.Rectangle(0,0,117.9,22), null);


(lib.CaT = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A2bD2IAAnrMAs3AAAIAAHrg");
	mask.setTransform(150.4,31.4);

	// Layer_1
	this.instance = new lib.Image36();
	this.instance.setTransform(2.4,3.65,0.9707,0.9707);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F1F1F1").s().p("Eg4PAEqIAApTMBwfAAAIAAJTg");
	this.shape.setTransform(159.7,36.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CaT, new cjs.Rectangle(-200.3,6.8,720,59.8), null);


(lib.Bottom2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Image34pngcopy();
	this.instance.setTransform(9.2,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Bottom2, new cjs.Rectangle(9.2,0,283,76), null);


(lib.Bottom = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Image34();
	this.instance.setTransform(0.05,-0.2,0.885,0.885);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Bottom, new cjs.Rectangle(0.1,-0.2,283.2,76.10000000000001), null);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.interfaceCreateAPostShadow();
	this.instance.setTransform(0,0,1,1.952);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,350,585.6), null);


(lib.X = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.interfaceClosebtn();
	this.instance.setTransform(6.3,6.3,1,1,0,0,0,4.5,4.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.X, new cjs.Rectangle(-0.7,-0.7,14.2,14.2), null);


(lib.shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg();
	this.instance.setTransform(175,-0.5,1,1,0,0,0,175,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,350,585.6), null);


(lib.interfaceDropDownText3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0378B4").s().p("AgGAOIAAgaIAEAAIAAAFIACgEIAEgCIADABIAAAEIgDgBQgDAAgBACQgCAEAAADIAAAOg");
	this.shape.setTransform(133.725,70.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AgJALQgDgEgBgHQAAgGAEgEQAEgDAGAAQAGAAADADQADAEABAGQgBAGgDAEQgEAEgGAAQgFAAgEgDgAgFgHQgDADAAAEQAAAFADADQACADAEAAQAEAAACgDQACgDAAgFQAAgEgCgDQgCgDgEAAQgEAAgCADg");
	this.shape_1.setTransform(130.95,70.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0378B4").s().p("AgCAKIAAgPIgFAAIAAgEIAFAAIAAgHIAEgBIAAAIIAGAAIAAAEIgGAAIAAAOIAAAEQAAAAABABQAAAAAAAAQABAAAAAAQABABAAAAIADgBIAAADIgEABQgGAAAAgIg");
	this.shape_2.setTransform(128.45,70);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0378B4").s().p("AgBAUIAAgaIADAAIAAAagAgBgOIgBgCIABgDIABAAIACAAIABADIgBACIgCABIgBgBg");
	this.shape_3.setTransform(126.925,69.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0378B4").s().p("AgJARQgDgEAAgGQAAgHAEgDQADgEAFAAQAGAAACAEIAAgRIAFAAIAAAoIgFAAIAAgFQgDAGgFAAQgFgBgEgDgAgFgBQgCADAAAEQAAAFACADQACADADAAQAEAAACgDQACgCAAgFIAAgDQAAgEgCgBQgCgCgEgBQgDAAgCADg");
	this.shape_4.setTransform(124.575,69.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0378B4").s().p("AgJATIAAglIASAAIAAAEIgOAAIAAANIANAAIAAADIgNAAIAAANIAPAAIAAAEg");
	this.shape_5.setTransform(121.825,69.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0378B4").s().p("AgCAKIAAgPIgFAAIAAgEIAFAAIAAgHIADgBIAAAIIAHAAIAAAEIgHAAIAAAOIABAEQAAAAABABQAAAAAAAAQABAAAAAAQABABABAAIACgBIAAADIgEABQgGAAAAgIg");
	this.shape_6.setTransform(117.85,70);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0378B4").s().p("AgDAVIAAgXIgEAAIAAgEIAEAAIAAgEQAAgFADgCQABgDAEAAIADABIAAAEIgDgBQgEAAAAAGIAAAEIAGAAIAAAEIgGAAIAAAXg");
	this.shape_7.setTransform(116.125,69.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0378B4").s().p("AgJALQgEgEABgHQAAgGADgEQAEgDAFAAQAHAAADADQADAEABAGQgBAGgDAEQgEAEgGAAQgFAAgEgDgAgFgHQgDADAAAEQAAAFADADQACADADAAQAEAAADgDQACgDAAgFQAAgEgCgDQgDgDgEAAQgDAAgCADg");
	this.shape_8.setTransform(113.65,70.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0378B4").s().p("AgIANIAAgFQAEADADAAQAGAAAAgEIgBgCIgBgBIgDgBIgBgBIgDgCIgDgBIgBgCIAAgCIAAgEIADgCIADgCIADAAIAHABIAAAEQgEgCgDAAIgCABIgBAAIgBACIAAABIAAACIABABIABABIACABIAEABIACABIABADIABACIgBAEIgCACIgDACIgEAAQgEAAgDgBg");
	this.shape_9.setTransform(110.95,70.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0378B4").s().p("AgJALQgEgEABgHQAAgGADgEQAEgDAFAAQAHAAADADQAEAEAAAGQAAAGgEAEQgEAEgGAAQgFAAgEgDgAgGgHQgCADAAAEQAAAFACADQADADADAAQAFAAACgDQACgDAAgFQAAgEgCgDQgCgDgFAAQgDAAgDADg");
	this.shape_10.setTransform(108.15,70.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0378B4").s().p("AgGAOIAAgaIAEAAIAAAFIACgEIAEgCIADABIAAAEIgDgBQgDAAgBACQgCAEAAADIAAAOg");
	this.shape_11.setTransform(105.925,70.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0378B4").s().p("AgGALQgDgEAAgGQAAgGADgEQAFgEAFAAIAGABIAAAEQgDgCgEAAQgDAAgCADQgDADAAAEQAAAFADADQACADADAAQAEAAADgDIAAAEQgDACgFAAQgEAAgEgDg");
	this.shape_12.setTransform(103.55,70.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0378B4").s().p("AgBAUIAAgaIADAAIAAAagAgBgOIgBgCIABgDIABAAIACAAIABADIgBACIgCABIgBgBg");
	this.shape_13.setTransform(101.625,69.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0378B4").s().p("AAPATIAAgZIAAgHIgBAEIgNAcIgBAAIgNgcIgBgEIgBAAIABAHIAAAZIgFAAIAAglIAGAAIAMAaIABAEIAAAAIACgFIAMgZIAGAAIAAAlg");
	this.shape_14.setTransform(98.525,69.825);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAIAlIAAgdQABgKgJABQgDAAgCABQgCADgBAFIAAAdIgPAAIAAhJIAPAAIAAAgQAHgJAIAAQARAAAAAUIAAAeg");
	this.shape_15.setTransform(39.75,66.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgCIgEgBIgFgCIgEgCIgCgEIgBgGQAAgDACgDIAFgGIAHgCIAHgBIAHABIAGABIAAALIgGgCIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAGQAAAEgCADIgFAGIgHACIgIABQgIAAgHgDg");
	this.shape_16.setTransform(34.575,67.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgCAAgEQAAgEADgCQACgCADAAQAEAAADACQACACAAAEQAAAEgCACQgDACgEAAQgDAAgCgCg");
	this.shape_17.setTransform(30.975,66.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCAEQgCACAAAGIAAAbIgPAAIAAgcQAAgLgIAAQgEAAgCADQgCADAAAGIAAAbIgQAAIAAgyIAQAAIAAAIQACgDAFgDQAEgCAFgBQAKAAAEAJQAFgJALAAQARABAAATIAAAfg");
	this.shape_18.setTransform(25.025,67.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgSAWQgDgEAAgHQAAgOAQgBIANgCQAAgJgIABQgJAAgIAEIAAgLIAJgDIAJgBQAVAAABAVIAAAdIgPAAIAAgHQgFAIgJAAQgIAAgEgEgAAAADQgHAAgBAHQAAAAABABQAAAAAAABQAAAAABABQAAAAAAAAQACACAEAAQACAAAEgCQACgEAAgFIAAgCg");
	this.shape_19.setTransform(17.6,67.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgCIgEAAIgFgDIgEgCIgCgEIgBgGQAAgDACgEIAFgEIAHgDIAHgBIAHABIAGABIAAAMIgGgDIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAFQAAAFgCADIgFAGIgHACIgIABQgIAAgHgDg");
	this.shape_20.setTransform(38.925,51.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgCIgEAAIgFgDIgEgCIgCgEIgBgGQAAgDACgEIAFgEIAHgDIAHgBIAHABIAGABIAAAMIgGgDIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAFQAAAFgCADIgFAGIgHACIgIABQgIAAgHgDg");
	this.shape_21.setTransform(34.575,51.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgCAAgEQAAgEADgCQACgCADAAQAEAAADACQACACAAAEQAAAEgCACQgDACgEAAQgDAAgCgCg");
	this.shape_22.setTransform(30.975,50);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCAEQgCACAAAGIAAAbIgPAAIAAgdQAAgKgIAAQgEAAgCADQgCADAAAGIAAAbIgQAAIAAgyIAQAAIAAAIQACgDAFgDQAEgCAFgBQAKAAAEAJQAFgJALAAQARABAAATIAAAfg");
	this.shape_23.setTransform(25.025,51.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgSAWQgDgEAAgHQAAgOAQgBIANgCQAAgIgIAAQgJAAgIAEIAAgLIAJgDIAJgBQAVAAABAVIAAAdIgPAAIAAgHQgFAIgJAAQgIAAgEgEgAAAADQgHABgBAFQAAABABABQAAAAAAABQAAAAABABQAAAAAAABQACABAEAAQACAAAEgCQACgDAAgFIAAgDg");
	this.shape_24.setTransform(17.6,51.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgSAYIAAgNIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgBIgEgBIgFgDIgEgCIgCgEIgBgGQAAgDACgEIAFgEIAHgDIAHgBIAHABIAGABIAAALIgGgCIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAFQAAAFgCADIgFAGIgHACIgIABQgIAAgHgCg");
	this.shape_25.setTransform(34.575,35.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgCAAgEQAAgEADgCQACgCADAAQAEAAADACQACACAAAEQAAAEgCACQgDACgEAAQgDAAgCgCg");
	this.shape_26.setTransform(30.975,34.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCAEQgCACAAAGIAAAbIgPAAIAAgdQAAgKgIAAQgEAAgCADQgCADAAAGIAAAbIgQAAIAAgyIAQAAIAAAJQACgEAFgDQAEgCAFgBQAKAAAEAKQAFgKALAAQARABAAATIAAAfg");
	this.shape_27.setTransform(25.025,35.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgSAWQgDgEAAgHQAAgOAQgBIANgCQAAgIgIAAQgJAAgIAEIAAgLIAJgDIAJgBQAVAAABAVIAAAdIgPAAIAAgHQgFAIgJAAQgIAAgEgEgAAAADQgHABgBAFQAAABABABQAAAAAAABQAAAAABABQAAAAAAABQACABAEAAQACAAAEgCQACgDAAgFIAAgDg");
	this.shape_28.setTransform(17.6,35.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#A7A4A4").s().p("AgPATQgGgGAAgNQAAgKAHgIQAGgHAJAAQAKAAAGAGQAFAHAAALIAAADIgiAAQgBAIAFAFQAEAEAHAAQAIAAAHgFIAAAHQgHAFgKAAQgKAAgGgHgAAOgEQgBgGgDgFQgDgDgGAAQgFAAgEADQgDAFgBAGIAaAAIAAAAg");
	this.shape_29.setTransform(68,16.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#A7A4A4").s().p("AANAlIAAgdQAAgOgMAAQgFgBgEAFQgEADAAAIIAAAcIgIAAIAAhJIAIAAIAAAgIABAAQAFgJAKAAQARAAAAATIAAAfg");
	this.shape_30.setTransform(62.575,15.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#A7A4A4").s().p("AgWAlIAAhIIAIAAIAAAJIABAAQAFgKALAAQAJAAAFAHQAGAGAAAMQAAALgGAHQgGAIgLAAQgIAAgFgIIgBAAIAAAegAgKgZQgEAGAAAHIAAAGQAAAGAEAEQAEAEAGAAQAHAAAEgFQAEgEAAgKQAAgJgEgFQgEgEgHAAQgGAAgEAEg");
	this.shape_31.setTransform(56.95,17.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#A7A4A4").s().p("AgPAWQgEgDAAgIQAAgMARgDIAOgCQAAgNgLABQgIAAgHAFIAAgHQAHgFAJAAQASAAAAASIAAAgIgIAAIAAgIIgBAAQgFAJgJAAQgHAAgFgEgAAAABQgFABgDACQgDACAAAFQAAAEADACQADADAEgBQAFAAAEgDQAEgFAAgHIAAgEg");
	this.shape_32.setTransform(51.225,16.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#A7A4A4").s().p("AgMAZIAAgwIAIAAIAAAKIAAAAQACgFADgDQADgDAFAAIAEABIAAAIQgCgCgEAAQgFAAgCAFQgEAFAAAHIAAAZg");
	this.shape_33.setTransform(47.45,16.55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#A7A4A4").s().p("AgTAiIAAgIQAJAEAIAAQARAAAAgTIAAgGIAAAAQgGAKgKAAQgKAAgFgHQgGgGAAgLQAAgMAGgIQAGgHAKAAQAKAAAFAIIAAAAIAAgHIAIAAIAAAtQAAAbgZAAQgKAAgHgDgAgKgYQgEAFAAAKQAAAIAEAEQAEAFAGAAQAHAAAEgFQAEgDAAgIIAAgHQAAgGgEgEQgEgFgGAAQgGAAgFAGg");
	this.shape_34.setTransform(42.275,17.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#A7A4A4").s().p("AgRATQgHgHAAgMQAAgLAHgHQAHgHALAAQALAAAGAHQAHAHAAALQAAAMgHAHQgHAHgLAAQgKAAgHgHgAgLgNQgEAFAAAIQAAAJAEAGQAFAEAGAAQAIAAAEgEQAEgGAAgJQAAgIgEgGQgEgEgIAAQgGgBgFAGg");
	this.shape_35.setTransform(36.575,16.6);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#A7A4A4").s().p("AANAlIAAgdQAAgOgMAAQgFgBgEAFQgEADAAAIIAAAcIgIAAIAAhJIAIAAIAAAgIABAAQAFgJAKAAQARAAAAATIAAAfg");
	this.shape_36.setTransform(30.875,15.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#A7A4A4").s().p("AgFASIAAgcIgJAAIAAgHIAJAAIAAgMIAHgDIAAAPIANAAIAAAHIgNAAIAAAbQAAAFACACQABADAEgBQADAAADgBIAAAHQgDABgFAAQgMAAAAgPg");
	this.shape_37.setTransform(26.325,15.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A7A4A4").s().p("AgMAZIAAgwIAIAAIAAAKIABAAQABgFACgDQAEgDAFAAIAEABIAAAIQgCgCgEAAQgFAAgCAFQgEAFAAAHIAAAZg");
	this.shape_38.setTransform(23,16.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#A7A4A4").s().p("AgRATQgHgHAAgMQAAgLAHgHQAHgHALAAQALAAAGAHQAHAHAAALQAAAMgHAHQgHAHgLAAQgKAAgHgHgAgLgNQgEAFAAAIQAAAJAEAGQAFAEAGAAQAIAAAEgEQAEgGAAgJQAAgIgEgGQgEgEgIAAQgGgBgFAGg");
	this.shape_39.setTransform(17.975,16.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg
	this.instance = new lib.interfaceDropdown();
	this.instance.setTransform(70.9,40.4,1,1,0,0,0,70.9,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.interfaceDropdownShadow_1();
	this.instance_1.setTransform(71.05,41.05,0.7455,0.7455,0,0,0,110,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropDownText3, new cjs.Rectangle(-10.9,-11.1,164,104.3), null);


(lib.interfaceDropDownText2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0378B4").s().p("AgIASIAAgiIAGAAIAAAHQABgEABgCQADgCADAAIADABIAAAFIgEgBQgEAAgBAEQgCADAAAFIAAASg");
	this.shape.setTransform(133.325,69.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AgMANQgEgEAAgIQAAgJAEgFQAGgEAHAAQAHAAAFAEQAEAGAAAHQAAAIgFAFQgEAGgIgBQgHABgFgGgAgHgJQgDAEgBAFQABAGADAEQADADAEAAQAFAAAEgDQACgEAAgGQAAgFgCgEQgEgEgFAAQgEAAgDAEg");
	this.shape_1.setTransform(129.8,69.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0378B4").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_2.setTransform(126.625,69.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0378B4").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgSIgBgDIABgDIACgBIADABIABADIgBADIgDAAIgCAAg");
	this.shape_3.setTransform(124.65,68.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0378B4").s().p("AgLAVQgEgEAAgIQAAgJAEgEQAFgFAGAAQAHgBADAHIAAgXIAGAAIAAA0IgGAAIAAgHQgDAIgIgBQgHABgDgGgAgHgBQgDADAAAGQAAAGADAEQADADAEAAQAFAAADgDQACgDAAgGIAAgEQAAgFgCgBQgDgDgFgBQgDAAgEAEg");
	this.shape_4.setTransform(121.65,68.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0378B4").s().p("AgMAZIAAgxIAYAAIAAAFIgTAAIAAARIARAAIAAAEIgRAAIAAARIAUAAIAAAGg");
	this.shape_5.setTransform(118.15,69);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0378B4").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_6.setTransform(113.125,69.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0378B4").s().p("AgEAaIAAgdIgFAAIAAgFIAFAAIAAgFQAAgGAEgDQACgDAEAAIAFAAIAAAFIgFgBQgFAAAAAIIAAAFIAIAAIAAAFIgIAAIAAAdg");
	this.shape_7.setTransform(110.9,68.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0378B4").s().p("AgMANQgEgEAAgIQAAgJAEgFQAGgEAHAAQAHAAAFAEQAEAGAAAHQAAAIgFAFQgEAGgIgBQgHABgFgGgAgHgJQgDAEgBAFQABAGADAEQADADAEAAQAFAAAEgDQADgEAAgGQAAgFgDgEQgEgEgFAAQgEAAgDAEg");
	this.shape_8.setTransform(107.75,69.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0378B4").s().p("AgLAQIAAgGQAFADAFAAQAHAAAAgEIgBgCIgCgDIgCgBIgCgBIgEgCIgDgBIgCgDIgBgDQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIADgEIAEgCIAEAAQAEAAAEABIAAAGQgEgDgFAAIgCABIgCABIgBACIgBABIABACIABACIACACIACABIAFABIADACIACACIABAEQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDAEIgEACIgEAAQgGAAgEgCg");
	this.shape_9.setTransform(104.275,69.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0378B4").s().p("AgMANQgEgEAAgIQAAgJAEgFQAFgEAHAAQAJAAAEAEQAEAGAAAHQAAAIgEAFQgFAGgIgBQgHABgFgGgAgIgJQgDAEAAAFQAAAGADAEQAEADAEAAQAFAAADgDQAEgEAAgGQAAgFgEgEQgDgEgFAAQgEAAgEAEg");
	this.shape_10.setTransform(100.7,69.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0378B4").s().p("AgIASIAAgiIAGAAIAAAHQABgEABgCQADgCADAAIADABIAAAFIgEgBQgEAAgBAEQgCADAAAFIAAASg");
	this.shape_11.setTransform(97.825,69.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0378B4").s().p("AgHANQgFgFAAgHQAAgIAFgFQAEgFAIAAQAFAAADABIAAAGQgEgDgEAAQgFABgDAEQgDADgBAGQABAFADAEQADADAEAAQAFAAAEgDIAAAGQgEACgGAAQgGABgEgGg");
	this.shape_12.setTransform(94.8,69.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0378B4").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgSIgBgDIABgDIACgBIADABIAAADIAAADIgDAAIgCAAg");
	this.shape_13.setTransform(92.35,68.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0378B4").s().p("AATAZIAAghIABgJIgCAFIgQAlIgCAAIgRglIgBgFIgBAAIABAJIAAAhIgGAAIAAgxIAIAAIAOAhIACAHIADgHIAPghIAHAAIAAAxg");
	this.shape_14.setTransform(88.4,69);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgUAaIAAgNQAEACAEABIAIABQAEAAACgBQABAAAAgBQABAAAAAAQAAgBABAAQAAgBAAAAIgBgDIgDgDIgEgBIgEgBIgGgDIgEgCIgCgEIgBgHQAAgEACgEQACgCADgCQAEgDAEgBIAIgBIAHAAIAIADIAAAMIgHgCIgHgBIgEAAIgBABIgCACIgBABIABADIADACIACABIAEACIAGACIAFADIADAEQABACAAAEQAAAFgCADQgCADgEACQgDADgFABIgIABQgJAAgIgDg");
	this.shape_15.setTransform(58.375,65.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgSAWQgHgIAAgNQAAgNAIgIQAIgIAKAAQAMAAAHAHQAGAIAAALIAAAHIgjAAQABAMAOAAQAJAAAGgEIAAAMQgHAEgMAAQgNAAgHgHgAALgEQAAgMgKAAQgDAAgDADQgDAEgBAFIAUAAIAAAAg");
	this.shape_16.setTransform(52.975,65.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgaAFIAAggIARAAIAAAeQAAAMAJAAQAEAAACgDQADgDAAgGIAAgeIARAAIAAA2IgRAAIAAgJIAAAAQgGAKgKAAQgTAAAAgXg");
	this.shape_17.setTransform(46.6,65.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgWAmIAAgOQAIAFAIAAQAIAAAFgFQAFgFgBgHIAAgFQgFAKgLAAQgLAAgFgIQgHgHAAgMQABgOAGgIQAHgIAMAAQAJAAAEAIIAAgHIARAAIAAAwQAAAPgJAJQgIAIgQAAQgLAAgGgDgAgHgXQgDAFAAAIQAAAHACADQADAEAFAAQAFAAADgEQAEgEAAgGIAAgFQAAgFgDgDQgEgEgFAAQgEAAgDAEg");
	this.shape_18.setTransform(39.75,66.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgIApIAAg3IAQAAIAAA3gAgGgZQgDgDAAgDQAAgEADgCQADgCADAAQAEAAADACQADACAAAEQAAAEgDACQgDADgEAAQgDAAgDgDg");
	this.shape_19.setTransform(34.975,64.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AAbAcIAAgeQAAgMgJAAQgEAAgDAEQgCADAAAFIAAAeIgQAAIAAgeQAAgMgJAAQgEAAgDADQgDAEAAAGIAAAdIgRAAIAAg2IARAAIAAAJIABAAQACgFAFgCQAFgDAFAAQALAAAEAKQAHgKAMAAQASAAAAAWIAAAhg");
	this.shape_20.setTransform(28.425,65.625);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgUAYQgEgEAAgIQAAgPATgCIAOgCQAAgJgJAAQgKAAgJAFIAAgMIAKgEIALgBQAXAAAAAYIAAAgIgQAAIAAgIIgBAAQgFAJgKAAQgIAAgFgFgAAAADQgJABAAAGQABADACACQACACADAAQAEAAADgEQADgDAAgFIAAgDg");
	this.shape_21.setTransform(20.25,65.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgUAaIAAgOQAEADAEABIAIACQAEAAACgCQABAAAAgBQABAAAAAAQAAgBABAAQAAgBAAgBIgBgCIgDgCIgEgCIgEgBIgGgDIgEgCIgCgFIgBgGQAAgEACgDQACgEADgCQAEgCAEgBIAIgBIAHABIAIACIAAAMIgHgCIgHgBIgEAAIgBABIgCABIgBACIABADIADACIACABIAEABIAGADIAFADIADADQABADAAAEQAAAEgCAEQgCAEgEABQgDADgFABIgIABQgJAAgIgDg");
	this.shape_22.setTransform(61.425,48.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgSAVQgHgHAAgNQAAgNAIgIQAIgIAKAAQAMAAAHAHQAGAIAAALIAAAHIgjAAQABAMAOAAQAJAAAGgFIAAANQgHAEgMAAQgNAAgHgIgAALgFQAAgMgKABQgDgBgDAEQgDAEgBAEIAUAAIAAAAg");
	this.shape_23.setTransform(56.025,48.8);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgVAVQgIgIAAgNQAAgNAIgHQAIgIANAAQAOAAAIAIQAIAHAAANQAAANgIAIQgIAIgOAAQgNAAgIgIgAgIgLQgEAFAAAGQAAAQAMAAQAMAAAAgQQAAgPgMAAQgFAAgDAEg");
	this.shape_24.setTransform(46.675,48.8);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgWAmIAAgOQAIAFAIAAQAIAAAFgFQAFgFgBgHIAAgFQgFAKgLAAQgLAAgFgIQgHgHAAgMQABgOAGgIQAHgIAMAAQAJAAAEAIIAAgHIARAAIAAAwQAAAPgJAJQgIAIgQAAQgLAAgGgDgAgHgXQgDAFAAAIQAAAHACADQADAEAFAAQAFAAADgEQAEgEAAgGIAAgFQAAgFgDgDQgEgEgFAAQgEAAgDAEg");
	this.shape_25.setTransform(39.75,50.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgIApIAAg2IAQAAIAAA2gAgGgZQgDgDAAgDQAAgEADgCQADgDADABQAEgBADADQADACAAAEQAAAEgDACQgDADgEAAQgDAAgDgDg");
	this.shape_26.setTransform(34.975,47.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAbAcIAAgeQAAgMgJAAQgEAAgDAEQgCADAAAFIAAAeIgQAAIAAgeQAAgMgJAAQgEAAgDADQgDAEAAAGIAAAdIgRAAIAAg2IARAAIAAAJIABAAQACgFAFgCQAFgDAFAAQALAAAEAKQAHgKAMAAQASAAAAAWIAAAhg");
	this.shape_27.setTransform(28.425,48.725);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgUAYQgEgEAAgIQAAgPATgDIAOgBQAAgKgJABQgKAAgJAFIAAgMIAKgDIALgCQAXAAAAAXIAAAhIgQAAIAAgIIgBAAQgFAJgKAAQgIAAgFgFgAAAACQgJACAAAGQABADACACQACACADAAQAEAAADgEQADgDAAgFIAAgDg");
	this.shape_28.setTransform(20.25,48.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgUAaIAAgOQAEADAEABIAIACQAEgBACgBQABAAAAgBQABAAAAAAQAAgBABAAQAAgBAAgBIgBgDIgDgBIgEgBIgEgCIgGgDIgEgCIgCgFIgBgFQAAgFACgDQACgDADgDQAEgCAEgBIAIgBIAHABIAIACIAAAMIgHgDIgHgBIgEABIgBABIgCABIgBADIABACIADACIACABIAEABIAGADIAFADIADADQABADAAADQAAAFgCAEQgCAEgEACQgDACgFABIgIABQgJAAgIgDg");
	this.shape_29.setTransform(52.475,31.9);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgVAVQgIgIAAgNQAAgMAIgIQAIgIANAAQAOAAAIAIQAIAIAAAMQAAANgIAIQgIAIgOAAQgNAAgIgIgAgIgKQgEAEAAAGQAAAQAMAAQAMAAAAgQQAAgPgMAAQgFAAgDAFg");
	this.shape_30.setTransform(46.675,31.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgWAmIAAgOQAIAFAIAAQAIAAAFgFQAFgFgBgHIAAgFQgFAKgLAAQgLAAgFgIQgHgHAAgMQABgOAGgIQAHgIAMAAQAJAAAEAIIAAgHIARAAIAAAwQAAAPgJAJQgIAIgQAAQgLAAgGgDgAgHgXQgDAFAAAIQAAAHACADQADAEAFAAQAFAAADgEQAEgEAAgGIAAgFQAAgFgDgDQgEgEgFAAQgEAAgDAEg");
	this.shape_31.setTransform(39.75,33.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgIAoIAAg1IAQAAIAAA1gAgGgYQgDgEAAgDQAAgEADgCQADgCADgBQAEABADACQADACAAAEQAAAEgDADQgDACgEAAQgDAAgDgCg");
	this.shape_32.setTransform(34.975,30.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AAbAcIAAgeQAAgMgJAAQgEAAgDAEQgCADAAAFIAAAeIgQAAIAAgeQAAgMgJAAQgEAAgDADQgDAEAAAGIAAAdIgRAAIAAg2IARAAIAAAJIABAAQACgFAFgCQAFgDAFAAQALAAAEAKQAHgKAMAAQASAAAAAWIAAAhg");
	this.shape_33.setTransform(28.425,31.825);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgUAZQgEgFAAgIQAAgPATgDIAOgCQAAgJgJAAQgKAAgJAHIAAgNIAKgDIALgCQAXAAAAAXIAAAgIgQAAIAAgIIgBAAQgFAKgKAAQgIAAgFgEgAAAACQgJACAAAGQABADACACQACACADAAQAEAAADgEQADgDAAgFIAAgEg");
	this.shape_34.setTransform(20.25,31.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#A7A4A4").s().p("AgQAZQgFgFAAgHQAAgPASgCIAQgDQAAgOgMABQgJgBgIAIIAAgJQAJgGAJAAQAUAAAAAUIAAAjIgJAAIAAgIQgGAKgKAAQgJAAgEgEgAAAABQgGACgDACQgDACAAAFQAAAEADADQADADAFAAQAFAAAEgFQAFgFAAgHIAAgFg");
	this.shape_35.setTransform(62.475,15);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#A7A4A4").s().p("AgFApIAAg2IAHAAIAAA2gAgKgXIALgSIAJAAIgMASg");
	this.shape_36.setTransform(58.65,13.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#A7A4A4").s().p("AgGApIAAguIgJAAIAAgIIAJAAIAAgJQAAgIAEgFQAEgFAIAAIAGABIAAAIQgCgCgDAAQgJAAAAAMIAAAIIAMAAIAAAIIgMAAIAAAug");
	this.shape_37.setTransform(55.7,13.625);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A7A4A4").s().p("AgQAZQgFgFAAgHQAAgPASgCIAQgDQAAgOgMABQgJgBgIAIIAAgJQAJgGAJAAQAUAAAAAUIAAAjIgJAAIAAgIQgGAKgKAAQgJAAgEgEgAAAABQgGACgDACQgDACAAAFQAAAEADADQADADAFAAQAFAAAEgFQAFgFAAgHIAAgFg");
	this.shape_38.setTransform(50.875,15);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#A7A4A4").s().p("AgNAcIAAg2IAIAAIAAAMIABAAQACgHACgCQAEgEAFAAIAFABIAAAJQgCgCgEAAQgGAAgDAGQgEAFAAAIIAAAcg");
	this.shape_39.setTransform(46.725,14.95);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#A7A4A4").s().p("AgUAlIAAgJQAJAGAIAAQAUAAAAgWIAAgGQgHALgLAAQgLAAgGgIQgGgHgBgLQAAgOAHgJQAHgIALAAQALAAAGAJIAAgIIAJAAIAAAyQAAAegcAAQgLAAgHgEgAgKgbQgGAGAAALQABAJAEAFQAFAFAGAAQAIAAAEgFQAEgEABgJIAAgIQgBgGgEgFQgEgFgHAAQgHAAgEAGg");
	this.shape_40.setTransform(41,16.225);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#A7A4A4").s().p("AgTAVQgHgIAAgNQAAgMAHgIQAIgIAMAAQAMAAAHAIQAHAIAAAMQAAANgHAIQgIAIgMAAQgMAAgHgIgAgMgPQgFAGAAAJQAAAKAFAGQAFAFAHABQAJAAAEgGQAFgGAAgKQAAgJgFgGQgEgGgJABQgHAAgFAFg");
	this.shape_41.setTransform(34.775,15);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#A7A4A4").s().p("AgFAUIAAgfIgKAAIAAgIIAKAAIAAgNIAHgDIAAAQIAOAAIAAAIIgOAAIAAAeQAAAFACADQACACAEAAQADAAADgCIAAAIQgDABgGAAQgNAAABgQg");
	this.shape_42.setTransform(29.8,14.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#A7A4A4").s().p("AgNAcIAAg2IAIAAIAAAMIABAAQACgHACgCQAEgEAFAAIAFABIAAAJQgCgCgEAAQgGAAgDAGQgEAFAAAIIAAAcg");
	this.shape_43.setTransform(26.175,14.95);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#A7A4A4").s().p("AgTAVQgHgIAAgNQAAgMAHgIQAIgIAMAAQAMAAAHAIQAHAIAAAMQAAANgHAIQgIAIgMAAQgMAAgHgIgAgMgPQgFAGAAAJQAAAKAFAGQAFAFAHABQAJAAAEgGQAFgGAAgKQAAgJgFgGQgEgGgJABQgHAAgFAFg");
	this.shape_44.setTransform(20.675,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg
	this.instance = new lib.interfaceDropdown();
	this.instance.setTransform(70.9,40.4,1,1,0,0,0,70.9,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.interfaceDropdownShadow_1();
	this.instance_1.setTransform(71.05,41.05,0.7455,0.7455,0,0,0,110,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropDownText2, new cjs.Rectangle(-10.9,-11.1,164,104.3), null);


(lib.interfaceDropDownText1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0378B4").s().p("AgIASIAAgiIAGAAIAAAHQABgEABgCQADgCADAAIADABIAAAFIgEgBQgEAAgBAEQgCADAAAFIAAASg");
	this.shape.setTransform(133.325,69.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AgMANQgEgEAAgIQAAgJAEgFQAGgEAHAAQAHAAAFAEQAEAGAAAHQAAAIgFAFQgEAGgIgBQgHABgFgGgAgHgJQgDAEgBAFQABAGADAEQADADAEAAQAFAAAEgDQACgEAAgGQAAgFgCgEQgEgEgFAAQgEAAgDAEg");
	this.shape_1.setTransform(129.8,69.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0378B4").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_2.setTransform(126.625,69.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0378B4").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgSIgBgDIABgDIACgBIADABIABADIgBADIgDAAIgCAAg");
	this.shape_3.setTransform(124.65,68.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0378B4").s().p("AgLAVQgEgEAAgIQAAgJAEgEQAFgFAGAAQAHgBADAHIAAgXIAGAAIAAA0IgGAAIAAgHQgDAIgIgBQgHABgDgGgAgHgBQgDADAAAGQAAAGADAEQADADAEAAQAFAAADgDQACgDAAgGIAAgEQAAgFgCgBQgDgDgFgBQgDAAgEAEg");
	this.shape_4.setTransform(121.65,68.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0378B4").s().p("AgMAZIAAgxIAYAAIAAAFIgTAAIAAARIARAAIAAAEIgRAAIAAARIAUAAIAAAGg");
	this.shape_5.setTransform(118.15,69);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0378B4").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_6.setTransform(113.125,69.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0378B4").s().p("AgEAaIAAgdIgFAAIAAgFIAFAAIAAgFQAAgGAEgDQACgDAEAAIAFAAIAAAFIgFgBQgFAAAAAIIAAAFIAIAAIAAAFIgIAAIAAAdg");
	this.shape_7.setTransform(110.9,68.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0378B4").s().p("AgMANQgEgEAAgIQAAgJAEgFQAGgEAHAAQAHAAAFAEQAEAGAAAHQAAAIgFAFQgEAGgIgBQgHABgFgGgAgHgJQgDAEgBAFQABAGADAEQADADAEAAQAFAAAEgDQADgEAAgGQAAgFgDgEQgEgEgFAAQgEAAgDAEg");
	this.shape_8.setTransform(107.75,69.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0378B4").s().p("AgLAQIAAgGQAFADAFAAQAHAAAAgEIgBgCIgCgDIgCgBIgCgBIgEgCIgDgBIgCgDIgBgDQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAIADgEIAEgCIAEAAQAEAAAEABIAAAGQgEgDgFAAIgCABIgCABIgBACIgBABIABACIABACIACACIACABIAFABIADACIACACIABAEQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDAEIgEACIgEAAQgGAAgEgCg");
	this.shape_9.setTransform(104.275,69.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0378B4").s().p("AgMANQgEgEAAgIQAAgJAEgFQAFgEAHAAQAJAAAEAEQAEAGAAAHQAAAIgEAFQgFAGgIgBQgHABgFgGgAgIgJQgDAEAAAFQAAAGADAEQAEADAEAAQAFAAADgDQAEgEAAgGQAAgFgEgEQgDgEgFAAQgEAAgEAEg");
	this.shape_10.setTransform(100.7,69.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0378B4").s().p("AgIASIAAgiIAGAAIAAAHQABgEABgCQADgCADAAIADABIAAAFIgEgBQgEAAgBAEQgCADAAAFIAAASg");
	this.shape_11.setTransform(97.825,69.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0378B4").s().p("AgHANQgFgFAAgHQAAgIAFgFQAEgFAIAAQAFAAADABIAAAGQgEgDgEAAQgFABgDAEQgDADgBAGQABAFADAEQADADAEAAQAFAAAEgDIAAAGQgEACgGAAQgGABgEgGg");
	this.shape_12.setTransform(94.8,69.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0378B4").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgSIgBgDIABgDIACgBIADABIAAADIAAADIgDAAIgCAAg");
	this.shape_13.setTransform(92.35,68.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0378B4").s().p("AATAZIAAghIABgJIgCAFIgQAlIgCAAIgRglIgBgFIgBAAIABAJIAAAhIgGAAIAAgxIAIAAIAOAhIACAHIADgHIAPghIAHAAIAAAxg");
	this.shape_14.setTransform(88.4,69);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgUAaIAAgOQAEADAEABIAIABQAEAAACgBQABAAAAgBQABAAAAAAQAAgBABAAQAAgBAAgBIgBgDIgDgBIgEgBIgEgCIgGgDIgEgCIgCgFIgBgFQAAgFACgDQACgEADgCQAEgCAEgBIAIgBIAHABIAIABIAAAOIgHgEIgHgBIgEABIgBABIgCABIgBADIABACIADACIACABIAEABIAGADIAFACIADAFQABACAAADQAAAFgCAEQgCAEgEACQgDACgFABIgIABQgJAAgIgDg");
	this.shape_15.setTransform(39.625,65.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgWAiQgFgHAAgNQAAgOAGgHQAHgJALAAQAKABAEAHIAAggIASAAIAABQIgSAAIAAgHQgFAIgLABQgKAAgHgIgAgHABQgDAEAAAJQAAAHADAEQADADAEAAQAGABADgFQADgEAAgGIAAgFQAAgGgDgDQgDgDgFABQgFgBgDAEg");
	this.shape_16.setTransform(33.6,64.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAKAcIAAgdQAAgNgKAAQgDAAgDADQgDAEAAAFIAAAeIgRAAIAAg2IARAAIAAAJIABAAQAGgKAKAAQATAAAAAXIAAAgg");
	this.shape_17.setTransform(27.075,65.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgIAoIAAg2IAQAAIAAA2gAgGgYQgDgDAAgEQAAgEADgCQADgCADgBQAEABADACQADACAAAEQAAAEgDADQgDACgEAAQgDAAgDgCg");
	this.shape_18.setTransform(22.175,64);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgKApIAAgpIgJAAIAAgNIAJAAIAAgHQAAgJAGgGQAFgFALAAIAIABIAAANIgGgBQgIAAAAAIIAAAGIAMAAIAAANIgMAAIAAApg");
	this.shape_19.setTransform(18.675,63.925);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgVAiQgHgHAAgOQAAgNAHgHQAHgJALABQAKAAAFAIIAAghIARAAIAABQIgRAAIAAgIQgHAKgKgBQgKAAgGgHgAgHABQgDAEgBAIQAAAIADADQADAFAFAAQAFAAADgFQAEgEAAgHIAAgEQAAgFgEgEQgCgCgGgBQgEABgDADg");
	this.shape_20.setTransform(37.25,47.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgSAWQgHgIAAgNQAAgNAIgIQAIgIAKAAQAMAAAHAHQAGAIAAALIAAAHIgjAAQABAMAOAAQAJAAAGgEIAAAMQgHAEgMAAQgNAAgHgHgAALgEQAAgNgKAAQgDAAgDAEQgDAEgBAFIAUAAIAAAAg");
	this.shape_21.setTransform(31.075,48.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgIAoIAAg2IAQAAIAAA2gAgGgZQgDgDAAgDQAAgEADgCQADgDADAAQAEAAADADQADACAAAEQAAAEgDACQgDADgEAAQgDAAgDgDg");
	this.shape_22.setTransform(26.525,47.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgRAcIAAg2IARAAIAAAKIAAAAQADgLALAAIAEABIAAAQQgDgDgEAAQgGAAgDAFQgCAEAAAFIAAAbg");
	this.shape_23.setTransform(23.1,48.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgKApIAAgpIgJAAIAAgNIAJAAIAAgHQAAgJAGgGQAFgFALAAIAIABIAAANIgGgBQgIAAAAAIIAAAGIAMAAIAAANIgMAAIAAApg");
	this.shape_24.setTransform(18.675,47.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgUAaIAAgOQAEADAEABIAIACQAEAAACgCQABAAAAgBQABAAAAAAQAAgBABAAQAAgBAAgBIgBgCIgDgCIgEgCIgEgBIgGgDIgEgCIgCgFIgBgGQAAgEACgDQACgEADgCQAEgCAEgBIAIgBIAHABIAIACIAAAMIgHgCIgHgBIgEAAIgBABIgCABIgBACIABADIADACIACABIAEABIAGADIAFADIADADQABADAAAEQAAAEgCAEQgCAEgEABQgDADgFABIgIABQgJAAgIgDg");
	this.shape_25.setTransform(49.925,31.7);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgVAiQgHgHAAgOQAAgNAIgHQAGgIAMgBQAJAAAFAJIAAgiIAQAAIAABRIgQAAIAAgIQgHAJgKAAQgKABgGgIgAgHABQgDAFAAAHQAAAHACAFQAEADAEAAQAFAAADgEQAEgEAAgHIAAgEQAAgFgEgEQgCgDgGAAQgEAAgDAEg");
	this.shape_26.setTransform(43.9,30.45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAKAcIAAgdQAAgNgKAAQgDAAgDADQgDAEAAAFIAAAeIgRAAIAAg2IARAAIAAAJIABAAQAGgKAKAAQATAAAAAXIAAAgg");
	this.shape_27.setTransform(37.375,31.625);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgSAVQgHgHAAgNQAAgNAIgIQAIgIAKAAQAMAAAHAHQAGAIAAALIAAAHIgjAAQABAMAOAAQAJAAAGgFIAAANQgHAEgMAAQgNAAgHgIgAALgFQAAgMgKABQgDgBgDAEQgDAEgBAEIAUAAIAAAAg");
	this.shape_28.setTransform(31.075,31.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgIApIAAg2IAQAAIAAA2gAgGgZQgDgDAAgDQAAgEADgCQADgDADABQAEgBADADQADACAAAEQAAAEgDACQgDADgEAAQgDAAgDgDg");
	this.shape_29.setTransform(26.525,30.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgRAcIAAg2IARAAIAAAKIAAAAQADgLALAAIAEAAIAAARQgDgCgEAAQgGAAgDADQgCAFAAAFIAAAbg");
	this.shape_30.setTransform(23.1,31.65);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgKApIAAgpIgJAAIAAgNIAJAAIAAgHQAAgJAGgGQAFgFALAAIAIABIAAANIgGgBQgIAAAAAIIAAAGIAMAAIAAANIgMAAIAAApg");
	this.shape_31.setTransform(18.675,30.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#A7A4A4").s().p("AgUAlIAAgJQAJAGAIAAQAUAAAAgWIAAgGQgHALgLAAQgLAAgGgIQgGgHgBgLQAAgOAHgJQAHgIALAAQALAAAGAJIAAgIIAJAAIAAAyQAAAegcAAQgLAAgHgEgAgKgbQgGAGAAALQABAJAEAFQAFAFAGAAQAIAAAEgFQAEgEABgJIAAgIQgBgGgEgFQgEgFgHAAQgHAAgEAGg");
	this.shape_32.setTransform(50.45,16.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#A7A4A4").s().p("AAOAcIAAgeQAAgSgNAAQgFAAgFAFQgEAFAAAIIAAAeIgJAAIAAg2IAJAAIAAAJIAAAAQAGgKALAAQAJAAAFAGQAFAGAAALIAAAgg");
	this.shape_33.setTransform(44.375,14.825);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#A7A4A4").s().p("AgDAoIAAg2IAHAAIAAA2gAgDgdQAAgBgBAAQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBAAAAQABgBAAgBQAAAAAAAAQABgBAAAAQABgBAAAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAABAAAAQABAAAAABQABAAAAABQAAAAAAAAQABABAAABQAAAAAAABIgCAEQAAAAgBAAQAAABAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAgBQAAAAgBAAg");
	this.shape_34.setTransform(39.875,13.625);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#A7A4A4").s().p("AgDApIAAhRIAHAAIAABRg");
	this.shape_35.setTransform(37.225,13.575);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#A7A4A4").s().p("AgDApIAAhRIAHAAIAABRg");
	this.shape_36.setTransform(34.575,13.575);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#A7A4A4").s().p("AgQAVQgHgHAAgOQAAgMAHgHQAIgJAJAAQALAAAGAHQAGAHAAANIAAADIglAAQgBAJAFAGQAFAEAHAAQAKAAAIgFIAAAIQgIAFgMAAQgLAAgGgIgAAPgFQAAgHgDgEQgEgFgHABQgFgBgEAFQgFAFAAAGIAcAAIAAAAg");
	this.shape_37.setTransform(30.4,14.9);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A7A4A4").s().p("AgYApIAAhQIAIAAIAAAKIABAAQAGgLAMAAQAKAAAGAIQAGAHAAANQAAAMgGAIQgHAJgMAAQgKAAgFgKIgBAAIAAAigAgLgbQgFAFAAAJIAAAHQAAAGAFAFQAEAEAHAAQAHAAAFgFQAEgGAAgLQAAgJgEgFQgEgGgHABQgHgBgFAGg");
	this.shape_38.setTransform(24.475,16.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#A7A4A4").s().p("AgRAaIAAgKQAHAGAJgBQAKAAAAgHIgBgEIgCgDIgEgCIgEgCIgHgDIgEgCIgDgFIgBgFQAAgEACgCQABgEADgCIAHgDIAHgBQAHAAAGACIAAAJQgGgDgIAAIgEAAIgDACIgCACIgBAEIABADIACACIAEACIAEADIAGACIAFADIADAEIABAGQAAAEgBADIgFAFIgHADIgHABQgJAAgGgDg");
	this.shape_39.setTransform(18.775,14.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg
	this.instance = new lib.interfaceDropdown();
	this.instance.setTransform(70.9,40.4,1,1,0,0,0,70.9,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.interfaceDropdownShadow_1();
	this.instance_1.setTransform(71.05,41.05,0.7455,0.7455,0,0,0,110,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropDownText1, new cjs.Rectangle(-10.9,-11.1,164,104.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.icon_teams = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_59 = function() {
		exportRoot.mainMC.interfaceAnimation.writingInterface.play();
	}
	this.frame_71 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(59).call(this.frame_59).wait(12).call(this.frame_71).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgYKBJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_15 = new cjs.Graphics().p("EgYYBJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_16 = new cjs.Graphics().p("EgZBBJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_17 = new cjs.Graphics().p("EgaGBJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_18 = new cjs.Graphics().p("EgbmBJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_19 = new cjs.Graphics().p("EgdhBJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_20 = new cjs.Graphics().p("Egf4BJpIAAr+MBB+AAAIAAL+g");
	var mask_graphics_21 = new cjs.Graphics().p("Egg+BJpIAAr+MBB9AAAIAAL+g");
	var mask_graphics_22 = new cjs.Graphics().p("Egg+BJpIAAr+MBB9AAAIAAL+g");
	var mask_graphics_23 = new cjs.Graphics().p("Egg+BJpIAAr+MBB9AAAIAAL+g");
	var mask_graphics_24 = new cjs.Graphics().p("Egg+BJpIAAr+MBB9AAAIAAL+g");
	var mask_graphics_25 = new cjs.Graphics().p("Egg+BJpIAAr+MBB9AAAIAAL+g");
	var mask_graphics_26 = new cjs.Graphics().p("Egg+BJpIAAr+MBB9AAAIAAL+g");
	var mask_graphics_59 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_60 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_61 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_62 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_63 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_64 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_65 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_66 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_67 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_68 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_69 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_70 = new cjs.Graphics().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	var mask_graphics_71 = new cjs.Graphics().p("Eg3mCYPMAAAkwdMBRWAAAMAAAEwdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:267.5754,y:471.3024}).wait(1).to({graphics:mask_graphics_15,x:266.2043,y:471.3024}).wait(1).to({graphics:mask_graphics_16,x:262.0907,y:471.3024}).wait(1).to({graphics:mask_graphics_17,x:255.2348,y:471.3024}).wait(1).to({graphics:mask_graphics_18,x:245.6365,y:471.3024}).wait(1).to({graphics:mask_graphics_19,x:233.2959,y:471.3024}).wait(1).to({graphics:mask_graphics_20,x:218.2129,y:471.3024}).wait(1).to({graphics:mask_graphics_21,x:195.1136,y:471.3024}).wait(1).to({graphics:mask_graphics_22,x:170.4324,y:471.3024}).wait(1).to({graphics:mask_graphics_23,x:151.2358,y:471.3024}).wait(1).to({graphics:mask_graphics_24,x:137.524,y:471.3024}).wait(1).to({graphics:mask_graphics_25,x:129.2969,y:471.3024}).wait(1).to({graphics:mask_graphics_26,x:126.5546,y:471.3024}).wait(1).to({graphics:null,x:0,y:0}).wait(32).to({graphics:mask_graphics_59,x:74.625,y:907.675}).wait(1).to({graphics:mask_graphics_60,x:74.425,y:907.675}).wait(1).to({graphics:mask_graphics_61,x:71.375,y:907.675}).wait(1).to({graphics:mask_graphics_62,x:58.175,y:907.625}).wait(1).to({graphics:mask_graphics_63,x:22.675,y:907.575}).wait(1).to({graphics:mask_graphics_64,x:-52.225,y:907.425}).wait(1).to({graphics:mask_graphics_65,x:-188.425,y:907.175}).wait(1).to({graphics:mask_graphics_66,x:-324.625,y:906.925}).wait(1).to({graphics:mask_graphics_67,x:-399.525,y:906.775}).wait(1).to({graphics:mask_graphics_68,x:-435.025,y:906.725}).wait(1).to({graphics:mask_graphics_69,x:-448.225,y:906.675}).wait(1).to({graphics:mask_graphics_70,x:-451.275,y:906.675}).wait(1).to({graphics:mask_graphics_71,x:-355.9014,y:906.6889}).wait(1));

	// logo text
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-235.3,900.15,3.548,3.548,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:19.6},12,cjs.Ease.quadInOut).wait(46));

	// widows icon
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(74.65,904.45,0.2144,0.2144,0,0,0,-39.4,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-40,regY:1.4,scaleX:3.548,scaleY:3.548,x:74.55,y:904.4},14,cjs.Ease.quadOut).to({x:-122.7},12,cjs.Ease.quadInOut).to({_off:true},1).wait(45));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgoqCYPMAAAkwdMBRVAAAMAAAEwdg");
	this.shape.setTransform(74.625,907.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60).to({x:74.425},0).wait(1).to({x:71.375},0).wait(1).to({x:58.175,y:907.625},0).wait(1).to({x:22.675,y:907.575},0).wait(1).to({x:-52.225,y:907.425},0).wait(1).to({x:-188.425,y:907.175},0).wait(1).to({x:-324.625,y:906.925},0).wait(1).to({x:-399.525,y:906.775},0).wait(1).to({x:-435.025,y:906.725},0).wait(1).to({x:-448.225,y:906.675},0).wait(1).to({x:-451.275},0).wait(1).to({x:-451.475},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-711.8,-67.6,1046.8,1949.6);


(lib.writitngInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.gotoAndStop();
	}
	this.frame_301 = function() {
		exportRoot.mainMC.interfaceAnimation.gotoAndPlay();
	}
	this.frame_339 = function() {
		this.gotoAndStop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(301).call(this.frame_301).wait(38).call(this.frame_339).wait(26));

	// quill
	this.instance = new lib.interfaceQuill();
	this.instance.setTransform(193.9,225.1,0.5,0.5,53.9834,0,0,52.1,6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({regX:52,regY:6.2,scaleX:0.52,scaleY:0.52,rotation:0,x:159.25,y:260.55,alpha:1},14,cjs.Ease.quartInOut).wait(9).to({regX:2.1,regY:70.2,x:133.3,y:293.85},0).to({regY:70.4,scaleX:0.4766,scaleY:0.4766,rotation:-3.4635,x:132.7,y:295.1},2).to({regY:70.2,scaleX:0.52,scaleY:0.52,rotation:0,x:133.3,y:293.85},3).wait(11).to({regY:70.1,x:170.85,y:290.05},16,cjs.Ease.cubicInOut).wait(52).to({regY:70.2,x:135.4,y:295.4},15,cjs.Ease.cubicInOut).wait(11).to({regY:70.4,scaleX:0.4766,scaleY:0.4766,rotation:-3.4635,x:134.8,y:296.65},2).to({regY:70.2,scaleX:0.52,scaleY:0.52,rotation:0,x:135.4,y:295.4},3).wait(11).to({regY:70.1,x:151.5,y:299.75},16,cjs.Ease.quadInOut).wait(53).to({x:132.4,y:291.65},15,cjs.Ease.quadInOut).wait(19).to({regY:70.2,scaleX:0.4621,scaleY:0.4621,x:193.2,y:117.8},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// DropdownOverlay
	this.instance_1 = new lib.overlayBar();
	this.instance_1.setTransform(147.4,291.55,0.9996,0.9996,0,0,0,70.7,7.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(58).to({_off:false},0).to({alpha:1},2).wait(14).to({alpha:0},2).to({_off:true},1).wait(91).to({_off:false,y:294.55},0).to({alpha:1},2).wait(14).to({alpha:0},2).to({_off:true},1).wait(178));

	// dropdown3
	this.instance_2 = new lib.interfaceDropDownText3();
	this.instance_2.setTransform(79.75,262.15,0.0551,0.0551,0,0,0,1.8,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(267).to({_off:false},0).to({regX:1.9,scaleX:1,scaleY:1,x:79.8},10,cjs.Ease.quartInOut).wait(24).to({regY:0.1,y:262.2},0).to({regX:0.2,regY:1,scaleX:0.8876,scaleY:0.8876,x:120.7,y:101.65},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// dropdown2
	this.instance_3 = new lib.interfaceDropDownText2();
	this.instance_3.setTransform(76.8,263.5,0.0771,0.0771,0,0,0,1.3,1.3);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(157).to({_off:false},0).to({regX:0.1,regY:0.8,scaleX:1,scaleY:1,y:263.4},10,cjs.Ease.quartInOut).wait(19).to({regX:1.3,regY:1.3,scaleX:0.0771,scaleY:0.0771,y:263.5},10,cjs.Ease.quartInOut).to({_off:true},1).wait(168));

	// dropdown1
	this.instance_4 = new lib.interfaceDropDownText1();
	this.instance_4.setTransform(77.9,262.7,0.05,0.05,0,0,0,2,3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(46).to({_off:false},0).to({regX:1.5,regY:2.1,scaleX:1,scaleY:1},10,cjs.Ease.quartInOut).wait(19).to({regX:2,regY:3,scaleX:0.05,scaleY:0.05},10,cjs.Ease.quartInOut).to({_off:true},1).wait(279));

	// Layer_2 copy
	this.instance_5 = new lib.textWrong3_4();
	this.instance_5.setTransform(148.75,233.1,1,1,0,0,0,53.2,35.2);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(248).to({_off:false},0).wait(53).to({scaleX:1.1354,scaleY:1.1354,x:82.5,y:103.7},39,cjs.Ease.quartInOut).to({_off:true},20).wait(5));

	// Layer_2
	this.instance_6 = new lib.textWrong3_2();
	this.instance_6.setTransform(148.8,261.05,1,1,0,0,0,53.2,35.2);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(258).to({_off:false},0).wait(43).to({scaleX:1.1354,scaleY:1.1354,x:178.75,y:102.4},39,cjs.Ease.quartInOut).to({_off:true},20).wait(5));

	// text3 mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_230 = new cjs.Graphics().p("AGyR/IAAj4IBwAAIAAD4g");
	var mask_graphics_232 = new cjs.Graphics().p("AF2R/IAAj4IDpAAIAAD4g");
	var mask_graphics_233 = new cjs.Graphics().p("AE5RcIAAiyIFiAAIAACyg");
	var mask_graphics_235 = new cjs.Graphics().p("AEfR1IAAjkIGXAAIAADkg");
	var mask_graphics_236 = new cjs.Graphics().p("ADiR9IAAj0IIQAAIAAD0g");
	var mask_graphics_237 = new cjs.Graphics().p("ACnR6IAAjuIKHAAIAADug");
	var mask_graphics_238 = new cjs.Graphics().p("ABgR6IAAjuIMUAAIAADug");
	var mask_graphics_242 = new cjs.Graphics().p("ABJR2IAAjmINDAAIAADmg");
	var mask_graphics_243 = new cjs.Graphics().p("AASR/IAAj4IOwAAIAAD4g");
	var mask_graphics_244 = new cjs.Graphics().p("Ag1R8IAAjyIQ/AAIAADyg");
	var mask_graphics_248 = new cjs.Graphics().p("AoUUAIAAjlIStAAIAADlg");
	var mask_graphics_250 = new cjs.Graphics().p("AHcUEIAAjtIC+AAIAADtg");
	var mask_graphics_251 = new cjs.Graphics().p("AF9UEIAAjsIF9AAIAADsg");
	var mask_graphics_252 = new cjs.Graphics().p("AFnUAIAAjlIGoAAIAADlg");
	var mask_graphics_253 = new cjs.Graphics().p("AE4UCIAAjoIIKAAIAADog");
	var mask_graphics_254 = new cjs.Graphics().p("AEKUCIAAjoIJoAAIAADog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(230).to({graphics:mask_graphics_230,x:54.6372,y:115.0621}).wait(2).to({graphics:mask_graphics_232,x:60.6622,y:115.0621}).wait(1).to({graphics:mask_graphics_233,x:66.7095,y:111.6122}).wait(2).to({graphics:mask_graphics_235,x:69.3569,y:114.0733}).wait(1).to({graphics:mask_graphics_236,x:75.4371,y:114.9407}).wait(1).to({graphics:mask_graphics_237,x:81.3525,y:114.631}).wait(1).to({graphics:mask_graphics_238,x:88.4141,y:114.5566}).wait(4).to({graphics:mask_graphics_242,x:90.7574,y:114.2098}).wait(1).to({graphics:mask_graphics_243,x:96.218,y:115.0523}).wait(1).to({graphics:mask_graphics_244,x:103.4042,y:114.7547}).wait(4).to({graphics:mask_graphics_248,x:66.5483,y:128.0349}).wait(2).to({graphics:mask_graphics_250,x:66.5732,y:128.407}).wait(1).to({graphics:mask_graphics_251,x:76.187,y:128.382}).wait(1).to({graphics:mask_graphics_252,x:78.291,y:128.0349}).wait(1).to({graphics:mask_graphics_253,x:83.4493,y:128.1839}).wait(1).to({graphics:mask_graphics_254,x:88.2336,y:128.1839}).wait(111));

	// text3
	this.instance_7 = new lib.textWrong3();
	this.instance_7.setTransform(148.75,233.1,1,1,0,0,0,53.2,35.2);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(230).to({_off:false},0).wait(18).to({_off:true},10).wait(107));

	// text friend mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_184 = new cjs.Graphics().p("AmkCnIAAgPINJAAIAAAPgAGlCYItJAAIAAk+INJAAIAAE+g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(184).to({graphics:mask_1_graphics_184,x:169.3085,y:219.7557}).wait(41).to({graphics:null,x:0,y:0}).wait(140));

	// text amigos
	this.instance_8 = new lib.textCorrect2();
	this.instance_8.setTransform(210.05,189.2,1,1,0,0,0,83,18.6);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(184).to({_off:false},0).to({y:219.15},13,cjs.Ease.quartInOut).to({_off:true},28).wait(140));

	// text amigos misspelled
	this.instance_9 = new lib.textWrong2();
	this.instance_9.setTransform(161.3,219.2,1,1,0,0,0,83,18.6);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(184).to({_off:false},0).to({y:253.45},13,cjs.Ease.quartInOut).to({_off:true},28).wait(140));

	// text2 mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_120 = new cjs.Graphics().p("AFJSEIAAj1ICTAAIAAD1g");
	var mask_2_graphics_123 = new cjs.Graphics().p("AELSEIAAj1IEQAAIAAD1g");
	var mask_2_graphics_124 = new cjs.Graphics().p("ADySEIAAj1IFBAAIAAD1g");
	var mask_2_graphics_126 = new cjs.Graphics().p("AC9SEIAAj1IGrAAIAAD1g");
	var mask_2_graphics_128 = new cjs.Graphics().p("ABvSEIAAj1IJIAAIAAD1g");
	var mask_2_graphics_133 = new cjs.Graphics().p("AATSEIAAj1IL/AAIAAD1g");
	var mask_2_graphics_135 = new cjs.Graphics().p("AgHSEIAAj1IM0AAIAAD1g");
	var mask_2_graphics_136 = new cjs.Graphics().p("Ag8SEIAAj1IOeAAIAAD1g");
	var mask_2_graphics_139 = new cjs.Graphics().p("Ah9SEIAAj1IQhAAIAAD1g");
	var mask_2_graphics_140 = new cjs.Graphics().p("Ai4SEIAAj1ISXAAIAAD1g");
	var mask_2_graphics_141 = new cjs.Graphics().p("AjlSEIAAj1ITxAAIAAD1g");
	var mask_2_graphics_143 = new cjs.Graphics().p("AkBSEIAAj1IUoAAIAAD1g");
	var mask_2_graphics_144 = new cjs.Graphics().p("AkCSEIAAj1IUrAAIAAD1g");
	var mask_2_graphics_184 = new cjs.Graphics().p("AC1SEIAAj1IG/AAIAAD1g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(120).to({graphics:mask_2_graphics_120,x:47.6249,y:115.5749}).wait(3).to({graphics:mask_2_graphics_123,x:53.899,y:115.5749}).wait(1).to({graphics:mask_2_graphics_124,x:56.3315,y:115.5749}).wait(2).to({graphics:mask_2_graphics_126,x:61.6373,y:115.5749}).wait(2).to({graphics:mask_2_graphics_128,x:69.4562,y:115.5749}).wait(5).to({graphics:mask_2_graphics_133,x:78.6018,y:115.5749}).wait(2).to({graphics:mask_2_graphics_135,x:81.3283,y:115.5749}).wait(1).to({graphics:mask_2_graphics_136,x:86.6357,y:115.5749}).wait(3).to({graphics:mask_2_graphics_139,x:93.1605,y:115.5749}).wait(1).to({graphics:mask_2_graphics_140,x:99.067,y:115.5749}).wait(1).to({graphics:mask_2_graphics_141,x:103.5848,y:115.5749}).wait(2).to({graphics:mask_2_graphics_143,x:106.3244,y:115.5749}).wait(1).to({graphics:mask_2_graphics_144,x:106.4632,y:115.5749}).wait(40).to({graphics:mask_2_graphics_184,x:62.8359,y:115.5749}).wait(41).to({graphics:null,x:0,y:0}).wait(140));

	// text2
	this.instance_10 = new lib.textWrong2();
	this.instance_10.setTransform(161.4,219.2,0.9999,1,0,0,0,83.1,18.6);
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(120).to({_off:false},0).to({_off:true},105).wait(140));

	// text friend mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_73 = new cjs.Graphics().p("AmGCrIAAgQIMNAAIAAAQgAGHCbIsNAAIAAlFIMNAAIAAFFg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(73).to({graphics:mask_3_graphics_73,x:176.3428,y:219.321}).wait(42).to({graphics:null,x:0,y:0}).wait(250));

	// text friend
	this.instance_11 = new lib.textCorrect1();
	this.instance_11.setTransform(181.75,189.4,1,1,0,0,0,41.8,18.6);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(73).to({_off:false},0).to({y:220.6},13,cjs.Ease.quartInOut).to({_off:true},29).wait(250));

	// text friend misspelled
	this.instance_12 = new lib.textWrong1();
	this.instance_12.setTransform(159.6,220.7,1,1,0,0,0,73.9,18.6);
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(73).to({_off:false},0).to({y:258.4},13,cjs.Ease.quartInOut).to({_off:true},29).wait(250));

	// text1 mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_12 = new cjs.Graphics().p("AGOSaQgaAAAAgUIAAlyQAAgUAaAAIBVAAQAbAAAAAUIAAFyQAAAUgbAAg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AFqSaQgwAAAAgUIAAlyQAAgUAwAAICeAAQAwAAAAAUIAAFyQAAAUgwAAg");
	var mask_4_graphics_15 = new cjs.Graphics().p("AhfDNQg8AAABgUIAAlxQgBgUA8AAIC/AAQA7AAAAAUIAAFxQAAAUg7AAg");
	var mask_4_graphics_17 = new cjs.Graphics().p("AFOSaQhDAAAAgUIAAlyQAAgUBDAAIDXAAQBCAAAAAUIAAFyQAAAUhCAAg");
	var mask_4_graphics_19 = new cjs.Graphics().p("AijDNQhnAAABgUIAAlxQgBgUBnAAIFIAAQBmAAAAAUIAAFxQAAAUhmAAg");
	var mask_4_graphics_24 = new cjs.Graphics().p("Ai7DNQh1AAAAgUIAAlxQAAgUB1AAIF3AAQB1AAAAAUIAAFxQAAAUh1AAg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AjQDNQiCAAAAgUIAAlxQAAgUCCAAIGiAAQCBAAAAAUIAAFxQAAAUiBAAg");
	var mask_4_graphics_28 = new cjs.Graphics().p("ADHSaQiWAAAAgUIAAlyQAAgUCWAAIHlAAQCWAAAAAUIAAFyQAAAUiWAAg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AC3SaQigAAAAgUIAAlyQAAgUCgAAIIGAAQCfAAAAAUIAAFyQAAAUifAAg");
	var mask_4_graphics_32 = new cjs.Graphics().p("ACTSaQi3AAAAgUIAAlyQAAgUC3AAIJPAAQC1AAAAAUIAAFyQAAAUi1AAg");
	var mask_4_graphics_34 = new cjs.Graphics().p("ABvSaQjMAAAAgUIAAlyQAAgUDMAAIKWAAQDMAAAAAUIAAFyQAAAUjMAAg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AlpDNQjiAAAAgUIAAlxQAAgUDiAAILVAAQDgAAAAAUIAAFxQAAAUjgAAg");
	var mask_4_graphics_73 = new cjs.Graphics().p("AGTSaQjfAAAAgUIAAlyQAAgUDfAAIEsAAIAAGag");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_4_graphics_12,x:50.9625,y:117.7768}).wait(1).to({graphics:mask_4_graphics_13,x:56.8125,y:117.7768}).wait(2).to({graphics:mask_4_graphics_15,x:103.8,y:215.05}).wait(2).to({graphics:mask_4_graphics_17,x:61.4875,y:117.7768}).wait(2).to({graphics:mask_4_graphics_19,x:114.9,y:215.05}).wait(5).to({graphics:mask_4_graphics_24,x:118.825,y:215.05}).wait(2).to({graphics:mask_4_graphics_26,x:122.2,y:215.05}).wait(2).to({graphics:mask_4_graphics_28,x:83.3625,y:117.7768}).wait(2).to({graphics:mask_4_graphics_30,x:86.0125,y:117.7768}).wait(2).to({graphics:mask_4_graphics_32,x:91.925,y:117.7768}).wait(2).to({graphics:mask_4_graphics_34,x:97.6875,y:117.7768}).wait(2).to({graphics:mask_4_graphics_36,x:147.075,y:215.05}).wait(37).to({graphics:mask_4_graphics_73,x:70.2625,y:117.7768}).wait(42).to({graphics:null,x:0,y:0}).wait(250));

	// text1
	this.instance_13 = new lib.textWrong1();
	this.instance_13.setTransform(159.6,220.4,1,1,0,0,0,73.9,18.6);
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(12).to({_off:false},0).wait(61).to({_off:true},42).wait(250));

	// red text hightlight
	this.instance_14 = new lib.interfaceTextRedHighlight();
	this.instance_14.setTransform(176.3,219.7,0.5373,0.799,0,0,0,59.3,24.7);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(37).to({_off:false},0).wait(38).to({regX:47.2,regY:17.2,x:169.8,y:213.7},0).to({alpha:0},7).to({_off:true},1).wait(62).to({_off:false,regX:47.6,scaleX:0.5785,scaleY:0.7909,x:162.45,y:214.05,alpha:1},0).wait(41).to({regX:47.4,scaleX:0.5786,x:162.35},0).to({regX:47.5,scaleX:0.5788,x:162.45,alpha:0},7).to({_off:true},1).wait(60).to({_off:false,regX:47.6,regY:17.5,scaleX:0.4971,scaleY:0.5964,x:144.6,y:238.9,alpha:1},0).wait(47).to({regY:17.6,scaleX:0.4524,scaleY:0.6646,x:171.15,y:79.35},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// buttons
	this.instance_15 = new lib.post_button();
	this.instance_15.setTransform(145.15,534.05,0.8771,0.8771,0,0,0,36.5,19.2);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1).to({_off:false},0).wait(300).to({regX:36.7,regY:19.3,scaleX:0.4348,scaleY:0.4348,x:269.85,y:202.05},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// X
	this.instance_16 = new lib.X();
	this.instance_16.setTransform(214.9,20.35,1,1,0,0,0,6.4,6.4);
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(1).to({_off:false},0).wait(300).to({regX:6.5,regY:6.5,scaleX:0.5896,scaleY:0.5896,x:272.45,y:13.8},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// Create Post
	this.instance_17 = new lib.Createpost();
	this.instance_17.setTransform(144.6,69.55,1,1,0,0,0,57.2,12.9);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(1).to({_off:false},0).wait(300).to({regX:57.3,regY:12.8,scaleX:0.5748,scaleY:0.5748,x:51.25,y:15.35},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// top_blue
	this.instance_18 = new lib.top_blue();
	this.instance_18.setTransform(150,2.7,1,1.1778,0,0,0,150,0.8);
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(1).to({_off:false},0).wait(300).to({scaleX:0.9772,scaleY:0.3438,x:155.3,y:1.35},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// Avatar
	this.instance_19 = new lib.WordEditorScreen1();
	this.instance_19.setTransform(17.6,32.75,0.5175,0.5175);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(301).to({_off:false},0).to({_off:true},40).wait(24));

	// bg
	this.instance_20 = new lib.Bottom();
	this.instance_20.setTransform(148.35,463.45,0.5703,0.5703,0,0,0,141.7,38.1);
	this.instance_20._off = true;

	this.instance_21 = new lib.Bottom2();
	this.instance_21.setTransform(138.05,403.8,0.5835,0.5835,0,0,0,141.8,38.1);
	this.instance_21._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(2).to({_off:false},0).wait(300).to({regX:141.6,regY:37.9,x:148.25,y:463.2},0).wait(1).to({scaleX:0.5704,scaleY:0.5704,x:148.2,y:462.9},0).wait(1).to({scaleX:0.5705,scaleY:0.5705,x:148.15,y:462.35},0).wait(1).to({scaleX:0.5707,scaleY:0.5707,x:148,y:461.6},0).wait(1).to({scaleX:0.5709,scaleY:0.5709,x:147.8,y:460.55},0).wait(1).to({scaleX:0.5712,scaleY:0.5712,x:147.6,y:459.15},0).wait(1).to({scaleX:0.5716,scaleY:0.5716,x:147.25,y:457.4},0).wait(1).to({scaleX:0.5721,scaleY:0.5721,x:146.85,y:455.25},0).wait(1).to({scaleX:0.5727,scaleY:0.5727,x:146.4,y:452.55},0).wait(1).to({scaleX:0.5734,scaleY:0.5734,x:145.85,y:449.25},0).wait(1).to({scaleX:0.5743,scaleY:0.5743,x:145.1,y:445.2},0).wait(1).to({scaleX:0.5754,scaleY:0.5754,x:144.25,y:440.3},0).wait(1).to({scaleX:0.5767,scaleY:0.5767,x:143.2,y:434.2},0).wait(1).to({scaleX:0.5784,scaleY:0.5784,x:141.9,y:426.5},0).wait(1).to({scaleX:0.5806,scaleY:0.5806,x:140.15,y:416.7},0).to({_off:true},1).wait(48));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(317).to({_off:false},0).wait(1).to({regX:150.7,regY:38,scaleX:0.5825,scaleY:0.5825,x:138.4,y:383.9},0).wait(1).to({scaleX:0.5811,scaleY:0.5811,x:131.65,y:356.05},0).wait(1).to({scaleX:0.5795,scaleY:0.5795,x:123.35,y:321.9},0).wait(1).to({scaleX:0.578,scaleY:0.578,x:116.1,y:292.3},0).wait(1).to({scaleX:0.577,scaleY:0.577,x:110.9,y:270.9},0).wait(1).to({scaleX:0.5762,scaleY:0.5762,x:107.15,y:255.35},0).wait(1).to({scaleX:0.5756,scaleY:0.5756,x:104.25,y:243.55},0).wait(1).to({scaleX:0.5752,scaleY:0.5752,x:102,y:234.3},0).wait(1).to({scaleX:0.5748,scaleY:0.5748,x:100.15,y:226.85},0).wait(1).to({scaleX:0.5745,scaleY:0.5745,x:98.7,y:220.8},0).wait(1).to({scaleX:0.5742,scaleY:0.5742,x:97.5,y:215.7},0).wait(1).to({scaleX:0.574,scaleY:0.574,x:96.45,y:211.55},0).wait(1).to({scaleX:0.5739,scaleY:0.5739,x:95.65,y:208.1},0).wait(1).to({scaleX:0.5737,scaleY:0.5737,x:94.9,y:205.2},0).wait(1).to({scaleX:0.5736,scaleY:0.5736,x:94.35,y:202.8},0).wait(1).to({scaleX:0.5735,scaleY:0.5735,x:93.85,y:200.8},0).wait(1).to({scaleX:0.5734,scaleY:0.5734,x:93.45,y:199.2},0).wait(1).to({x:93.15,y:197.95},0).wait(1).to({scaleX:0.5733,scaleY:0.5733,x:92.9,y:196.95},0).wait(1).to({x:92.7,y:196.2},0).wait(1).to({x:92.6,y:195.75},0).wait(1).to({scaleX:0.5732,scaleY:0.5732,x:92.55,y:195.45},0).wait(1).to({regX:141.7,regY:38.2,x:87.45},0).to({_off:true},1).wait(24));

	// CaT
	this.instance_22 = new lib.CaT();
	this.instance_22.setTransform(148.45,584.9,0.5542,0.5542,0,0,0,151.5,33.5);
	this.instance_22._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(1).to({_off:false},0).wait(300).to({regX:151.7,regY:33.8,scaleX:0.4061,scaleY:0.4061,x:152.55,y:231.35},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// interface cover
	this.instance_23 = new lib.white_bg();
	this.instance_23.setTransform(151.3,307.1,1,1,0,0,0,149.8,230.9);
	this.instance_23._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(1).to({_off:false},0).wait(300).to({regY:231.2,scaleX:1.8235,scaleY:0.3986,x:160.5,y:127.45},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	// shadow
	this.instance_24 = new lib.shadow();
	this.instance_24.setTransform(150.85,1.15,0.552,1.0656,0,0,0,175.1,-0.4);
	this.instance_24._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(1).to({_off:false},0).wait(300).to({regX:175,x:150.8},0).to({regX:174.8,scaleX:0.9733,scaleY:0.491,x:154.95,y:-20.05},39,cjs.Ease.quartInOut).to({_off:true},1).wait(24));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-46.5,-19.8,399.1,645.4);


(lib.interfaceAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.gotoAndStop();
	}
	this.frame_4 = function() {
		exportRoot.tl1.play()
	}
	this.frame_38 = function() {
		this.gotoAndStop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(34).call(this.frame_38).wait(1));

	// create a post
	this.writingInterface = new lib.writitngInterface();
	this.writingInterface.name = "writingInterface";
	this.writingInterface.setTransform(81.55,124.2,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.writingInterface).to({regX:0,regY:0,scaleX:0.4195,scaleY:0.3893,skewX:-28.9975,skewY:-17.0206,x:38.9,y:296.7},38,cjs.Ease.quartInOut).wait(1));

	// browser
	this.instance = new lib.interfaceBrowserWindowAngled();
	this.instance.setTransform(76.7,297.05,0.7016,0.7016,0,0,0,362.9,219.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:362.8,regY:219.8,scaleX:0.5087,scaleY:0.5087,x:111.7,y:310.7},37,cjs.Ease.quartInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-248.2,0,649.7,535.4);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(3,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ApuCXIAAktITdAAIAAEtg");
	this.shape.setTransform(-19.3,-0.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-81.6,-15.5,124.69999999999999,30.2), null);


(lib.tiletop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tiletop, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58,21,0.3087,0.3087);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(103.45,570.7,1,1,0,0,0,1.6,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(138.15,570.7,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(143.15,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// interfaceAnim
	this.interfaceAnimation = new lib.interfaceAnim();
	this.interfaceAnimation.name = "interfaceAnimation";

	this.timeline.addTween(cjs.Tween.get(this.interfaceAnimation).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// logo
	this.logo1 = new lib.logo();
	this.logo1.name = "logo1";
	this.logo1.setTransform(16.35,15.95,1.0608,1.0608,0,0,0,-52.2,-23.5);

	this.timeline.addTween(cjs.Tween.get(this.logo1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,0,178.7,601.9), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.6)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.6)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		
		
		
		this.runBanner = function() {
			
			this.tl1 = gsap.timeline();
			
				//exportRoot.tl1.to(mc.bg, .1, { alpha:0,	ease:Quart.easeInOut}, "=0");
						
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=0.3");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				//exportRoot.tl1.from(mc.logo1, 0.1, { alpha: 0,	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.pause();		
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(11.5,299.2,167.2,302.7);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#F5F5F5",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1.png?1629471289409", id:"M365_FY21Q3ConsOpt_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;