(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_160x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1", frames: [[0,0,833,536],[835,0,267,656]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.screen = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.survey = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_160x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(491.0046,408.3802);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,982,816.8);


(lib.share = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRAZIAAgJQAHAFAJAAQAKAAAAgIIgBgDIgCgDIgFgCIgDgCIgHgDIgEgCIgDgEIgBgGQAAgEACgDQACgDACgBIAHgDIAHgBQAHAAAFACIAAAJQgFgEgJAAIgDAAIgDACIgDACIAAADIAAAEIADACIAEACIAEACIAGADIAFADIACAEQACACAAADQAAAEgCADIgEAFIgHADIgHABQgJAAgGgDg");
	this.shape.setTransform(73.15,15.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgGAUIAAgfIgJAAIAAgHIAJAAIAAgOIAIgDIAAARIAOAAIAAAHIgOAAIAAAdQAAAFACADQACADAEgBQADAAADgBIAAAHQgEABgFABQgNAAAAgQg");
	this.shape_1.setTransform(68.925,14.45);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgDAoIAAhPIAHAAIAABPg");
	this.shape_2.setTransform(65.825,13.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWAFIAAggIAJAAIAAAeQAAARANAAQAFAAAFgEQAEgFAAgIIAAgeIAIAAIAAA1IgIAAIAAgIIgBAAQgFAKgKAAQgUAAAAgXg");
	this.shape_3.setTransform(61.4,15.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgRAZIAAgJQAHAFAIAAQALAAAAgIIgBgDIgCgDIgEgCIgFgCIgGgDIgEgCIgDgEIgBgGQAAgEACgDQABgDADgBIAHgDIAHgBQAHAAAFACIAAAJQgFgEgIAAIgEAAIgDACIgDACIAAADIAAAEIADACIADACIAFACIAGADIAFADIACAEQACACAAADQAAAEgCADIgEAFIgHADIgIABQgIAAgGgDg");
	this.shape_4.setTransform(56.15,15.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQAVQgGgIgBgNQAAgMAIgIQAHgHAKAAQAKAAAGAGQAGAHgBAMIAAAEIglAAQAAAJAGAFQAEAFAHAAQAJAAAIgGIAAAIQgHAFgMAAQgLAAgGgHgAgIgQQgEAFgCAHIAdAAQAAgIgEgEQgEgEgFAAQgGAAgEAEg");
	this.shape_5.setTransform(51.05,15.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AARAmIgNgVIgDgFIgDgEIgEgCIgEAAIgHAAIAAAgIgJAAIAAhLIAWAAIAIABQAFACADACQADADACADQACAEAAAFIgBAIIgEAFIgFAEIgIADIAEACIADACIACAEIADAEIAOAXgAgRgBIAMAAIAFgBIAFgDIADgFIABgGQAAgGgEgDQgEgEgGAAIgMAAg");
	this.shape_6.setTransform(45.75,14.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgQAVQgGgIgBgNQAAgMAHgIQAIgHAKAAQAKAAAGAGQAGAHgBAMIAAAEIglAAQAAAJAGAFQAEAFAHAAQAJAAAIgGIAAAIQgHAFgMAAQgKAAgHgHgAgIgQQgFAFgBAHIAdAAQAAgIgEgEQgEgEgFAAQgGAAgEAEg");
	this.shape_7.setTransform(36.3,15.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgNAcIAAg1IAIAAIAAAKQACgFADgDQAEgEAFABIAFABIAAAJQgCgCgEAAQgGgBgDAGQgDAFgBAIIAAAcg");
	this.shape_8.setTransform(32.15,15.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgQAYQgEgFAAgHQgBgOATgCIAOgCQAAgOgLAAQgIAAgIAGIAAgIQAIgFAJAAQAUAAgBAUIAAAiIgJAAIAAgJQgFAKgKAAQgIAAgFgEgAAAABQgGABgCACQgDACAAAGQAAAEADACQACADAFAAQAGAAAEgFQADgEAAgHIAAgFg");
	this.shape_9.setTransform(26.95,15.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAOAoIAAgfQAAgQgNAAQgFAAgFAFQgEAEAAAHIAAAfIgIAAIAAhPIAIAAIAAAjQAHgKAKAAQASAAAAAVIAAAhg");
	this.shape_10.setTransform(21.375,13.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgHAnIgGgBIgFgBIgEgCIAAgLIAEADIAGACIAFACIAFAAQAIAAAEgDQAEgDAAgGQAAgDgCgCIgDgEIgGgEIgGgDIgHgDIgGgFIgEgGQgCgDAAgEQAAgFADgEQACgEADgCQAEgDAFgBIAIgBQAMAAAFADIAAAKQgHgFgKAAIgFABIgFABIgEAEIgBAFIABAFIADAEIAFAEIAGADIAIADIAGAFQADADABADQACADAAAFQAAAFgCAEQgCAEgEACQgEADgFABIgJABIgEAAg");
	this.shape_11.setTransform(15.425,14.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F7579").s().p("Am3CQIAAkfINvAAIAAEfg");
	this.shape_12.setTransform(43.9752,14.4311);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.share, new cjs.Rectangle(0,0,88,28.9), null);


(lib.screen_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.screen();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,833,536);


(lib.resultcomponent = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAFATQgCgCAAgGQAAgFACgDQADgDAFAAQAEAAADADQADACAAAGQAAAFgDADQgDADgFAAQgEAAgDgDgAAIAGQgBACAAADQAAAEABACQABABAAAAQABAAAAABQABAAAAAAQABAAABAAQACAAACgDQACgCAAgDQAAgDgCgCQAAgBgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBABgAgPAWIAagqIAEAAIgaAqgAgTgBQgDgEAAgFQAAgFADgDQADgDAEAAQAFAAADADQACADAAAFQAAAFgDADQgDACgEAAQgFAAgCgBgAgQgQQgCACAAAEQAAAEACACQAAAAABABQAAAAABAAQAAABABAAQAAAAABAAQADAAACgCQABgDAAgDQAAgEgBgCQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAgBgBAAQgBAAAAABQgBAAAAAAQgBAAAAABQgBAAAAAAg");
	this.shape.setTransform(315.925,376.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgUAiIAAgJQAHAFAKAAIAFgBIAGgDIADgEIABgFQABgPgUAAIgFAAIAAgGIAFAAQARAAAAgNQAAgMgMAAQgJgBgGAGIAAgIQAHgEAKAAQADgBAEACQADABADACIAEAGQACADgBAEQAAAOgOAEIAAABIAGAAQAEACACACQACACABADQACADAAAEQAAAEgCAFIgFAHIgIADQgFACgEAAQgKAAgHgDg");
	this.shape_1.setTransform(310.55,374.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgTAhIAAgIQAHAEAIAAIAGgBIAFgDQADgCABgDQABgDAAgDQAAgHgFgEQgEgDgIAAIgEAAIgDAAIgDAAIgDAAIADgkIAgAAIAAAIIgZAAIgCAVIAEAAIADAAQAFAAAEABIAIAEQADACACAEQABAEAAAFQAAAGgBAEQgCAEgDADQgEADgFACQgEACgFAAQgKAAgFgEg");
	this.shape_2.setTransform(305.125,374.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAFATQgCgDAAgFQAAgFACgDQADgDAFAAQAEAAADADQADADAAAFQAAAFgDADQgDADgFAAQgEAAgDgDgAAIAFQgBACAAAEQAAAEABACQABAAAAABQABAAAAAAQABABAAAAQABAAABAAQACAAACgCQACgDAAgDQAAgEgCgCQAAAAgBAAQAAgBgBAAQAAAAgBAAQgBgBAAAAQgBAAgBABQAAAAgBAAQAAAAgBABQAAAAgBAAgAgPAWIAagrIAEAAIgaArgAgTgCQgDgDAAgEQAAgGADgDQADgDAEAAQAFAAADADQACADAAAFQAAAFgDADQgDACgEAAQgFAAgCgCgAgQgPQgCACAAADQAAAEACACQAAABABAAQAAAAABABQAAAAABAAQABAAAAAAQADAAACgDQABgCAAgDQAAgDgBgCQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQgBAAAAABQgBAAAAABg");
	this.shape_3.setTransform(351.875,375.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgLAkIADgNIAEgNIAEgMIAFgLIAFgJIADgGIgjAAIAAgHIAtAAIAAAEIgEAIIgFAKIgFALIgGAMIgDANIgDANg");
	this.shape_4.setTransform(346.6,374.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAIAkIAAgRIghAAIAAgHIAKgLIAJgMIAHgMIAHgMIAIAAIAAAvIAKAAIAAAHIgKAAIAAARgAABgLIgFAJIgGAHIgFAHIAXAAIAAgjIgHAMg");
	this.shape_5.setTransform(340.875,374.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5E5584").s().p("AABEvQiihJgpjNQgCgZAAgbQAShwBDhOQBvh+DVAKIgyFKIAAFRIgSABQhBAAhHggg");
	this.shape_6.setTransform(312.0779,375.3446,1.0191,1.0191);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F7579").s().p("AivgEIAylKQDTAsBBCeQAhBOgKBFQgGC7isBWQhWAqhVAFg");
	this.shape_7.setTransform(348.8872,375.4568,1.0191,1.0191);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#5E5584").s().p("AgZAfQgJgLAAgUQAAgRAKgMQALgMAPAAQAPAAAJAKQAJAKAAATIAAAFIg3AAQgBAOAIAHQAGAHAMAAQANAAALgJIAAAMQgKAIgSAAQgPAAgLgLgAgMgYQgHAHgBAKIAqAAQgBgLgEgGQgGgGgKAAQgHAAgGAGg");
	this.shape_8.setTransform(346.2,291.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5E5584").s().p("AgGAoIgehPIANAAIAVA5QACAGAAAFIACgLIAWg5IAOAAIghBPg");
	this.shape_9.setTransform(338.25,291.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#5E5584").s().p("AgGA6IAAhPIAMAAIAABPgAgFgrQgCgCAAgEQAAgEACgCQACgCADgBQADABADACQACACAAAEQAAADgCADQgDACgDAAQgDAAgCgCg");
	this.shape_10.setTransform(332.525,289.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#5E5584").s().p("AgJAeIAAgvIgNAAIAAgLIANAAIAAgTIAMgFIAAAYIAUAAIAAALIgUAAIAAAsQAAAIADAEQADADAGAAQAFAAADgCIAAAKQgEADgIAAQgUAAAAgXg");
	this.shape_11.setTransform(327.775,290.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5E5584").s().p("AgSAfQgLgMAAgRQAAgTAMgMQAKgMASAAQALAAAIAEIAAANQgJgGgKAAQgLAAgIAJQgIAIAAAOQAAAOAIAIQAHAIAMAAQAKAAAJgHIAAAMQgJAGgNAAQgQAAgKgLg");
	this.shape_12.setTransform(321.5,291.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5E5584").s().p("AAjA4IgLgfIgvAAIgLAfIgPAAIArhvIANAAIArBvgAgBgiIgSAvIAmAAIgSgvIgBgHIAAAAIgBAHg");
	this.shape_13.setTransform(312.55,290.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_14.setTransform(340.075,307.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#131313").s().p("AgUAEIAAgeIAHAAIAAAdQAAAQANAAQAFAAAEgEQAEgEAAgIIAAgdIAIAAIAAA0IgIAAIAAgJIAAAAQgFAKgKAAQgSAAAAgXg");
	this.shape_15.setTransform(334.75,307.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_16.setTransform(330.025,306.525);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#131313").s().p("AgPAXQgFgEAAgHQAAgNASgDIAOgCQAAgNgLAAQgIAAgIAGIAAgIQAIgFAJAAQATAAAAATIAAAhIgJAAIAAgIQgFAJgKAAQgIAAgEgEgAAAACQgFAAgDACQgDADAAAFQAAAEADACQACACAFAAQAFAAAEgEQAEgEAAgHIAAgFg");
	this.shape_17.setTransform(325.525,307.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_18.setTransform(321.175,306.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#131313").s().p("AgHAmIgFgBIgFgBIgEgCIAAgKIAEACIAFADIAGABIAFAAQAGAAAEgDQAEgDAAgFQAAgDgBgCIgEgEIgFgEIgGgDIgHgDIgGgFIgEgFIgBgHQAAgFACgEQACgDAEgDQAEgCAEgBIAIgCQALAAAFADIAAAKQgGgFgKAAIgFABIgFACIgEADQgBACAAADIABAFIADAEIAFADIAGADIAHAEIAGAEQADADACADQABADAAAEQAAAGgCADQgCAEgEADIgIADIgJABIgEAAg");
	this.shape_19.setTransform(317.075,306.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#5E5584").s().p("AgeA0IAAgNQALAHAMAAQAGAAAEgCQAEgCAEgDQADgDACgEQACgFAAgFQAAgMgHgFQgHgGgOAAIgEAAIgGAAIgEAAIgFABIAFg4IAyAAIAAALIgnAAIgDAiIAFgBIAGAAQAHAAAIACQAHACAFAFQAEAEADAFQACAHAAAIQAAAIgCAGQgEAIgEAEQgGAFgHACQgIADgHAAQgQAAgHgFg");
	this.shape_20.setTransform(353.25,225.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#5E5584").s().p("AgPA2QgGgDgFgIQgEgHgDgKQgCgKAAgOQAAgOACgKQACgMAGgHQAEgJAHgDQAIgEAIAAQAiAAABA5QgBANgCALQgCAMgFAHQgFAHgHAEQgHAEgIAAQgJAAgGgEgAgWABQAAAuAXAAQAWAAAAgvQAAgugWAAQgXAAAAAvg");
	this.shape_21.setTransform(344.45,225.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#5E5584").s().p("AgFAnQgDgCAAgEQAAgDADgDQACgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgCgDgAgFgaQgDgCAAgEQAAgEADgCQACgDADAAQADAAADADQADACAAAEQAAAEgDACQgDADgDAAQgDAAgCgDg");
	this.shape_22.setTransform(338.425,227.275);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#5E5584").s().p("AAHA5IAAhgIgFAEIgFAEIgIADIgHADIAAgNIAJgDIAJgFIAHgFIAIgFIAEAAIAABxg");
	this.shape_23.setTransform(331.775,225.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#5E5584").s().p("AgPA2QgHgDgEgIQgFgHgCgKQgCgKgBgOQABgOACgKQADgMAEgHQAFgJAIgDQAHgEAHAAQAkAAgBA5QABANgDALQgDAMgEAHQgFAHgHAEQgHAEgIAAQgJAAgGgEgAgWABQAAAuAWAAQAYAAAAgvQgBgugWAAQgXAAAAAvg");
	this.shape_24.setTransform(323.7,225.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#5E5584").s().p("AgFAnQgDgCAAgEQAAgDADgDQACgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgCgDgAgFgaQgDgCAAgEQAAgEADgCQACgDADAAQADAAADADQADACAAAEQAAAEgDACQgDADgDAAQgDAAgCgDg");
	this.shape_25.setTransform(317.675,227.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#5E5584").s().p("AgPA2QgGgDgFgIQgEgHgDgKQgCgKAAgOQAAgOACgKQADgMAFgHQAEgJAHgDQAIgEAIAAQAiAAABA5QgBANgCALQgCAMgFAHQgFAHgHAEQgHAEgIAAQgJAAgGgEgAgWABQAAAuAXAAQAWAAAAgvQAAgugWAAQgXAAAAAvg");
	this.shape_26.setTransform(311.6,225.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#5E5584").s().p("AgPA2QgHgDgEgIQgEgHgDgKQgCgKAAgOQAAgOACgKQADgMAFgHQAEgJAHgDQAIgEAIAAQAiAAABA5QAAANgDALQgDAMgEAHQgFAHgHAEQgHAEgIAAQgJAAgGgEgAgWABQAAAuAXAAQAWAAAAgvQABgugXAAQgXAAAAAvg");
	this.shape_27.setTransform(302.95,225.7);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_28.setTransform(353.175,254.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_29.setTransform(348.675,253.675);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_30.setTransform(344.225,254.375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#131313").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_31.setTransform(340.175,253.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#131313").s().p("AgXAnIAAhLIAJAAIAAAJQAFgLAMAAQAJAAAGAHQAGAHAAAMQAAAMgHAIQgFAIgMAAQgJAAgFgJIAAAggAgKgaQgFAFABAIIAAAHQAAAGADAEQAEAFAHAAQAHAAAEgGQAEgFAAgKQAAgJgDgFQgFgFgHAAQgGAAgEAFg");
	this.shape_32.setTransform(336.05,255.525);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#131313").s().p("AAcAbIAAgdQAAgJgCgEQgCgEgHAAQgGAAgDAFQgEAFAAAHIAAAdIgHAAIAAgeQAAgQgMAAQgGAAgDAFQgEAFABAHIAAAdIgJAAIAAgzIAJAAIAAAIQAFgKAKAAQAGAAAEADQADADABAFQAHgLALAAQARAAAAAWIAAAfg");
	this.shape_33.setTransform(328.35,254.325);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#131313").s().p("AgSAUQgHgHAAgMQAAgMAHgIQAIgHALAAQALAAAHAHQAHAHAAAMQAAAMgHAIQgIAHgLAAQgLAAgHgHgAgMgOQgEAGAAAIQAAAKAEAFQAFAFAHAAQAIAAAFgFQAEgFAAgKQAAgJgEgFQgFgFgIAAQgHAAgFAFg");
	this.shape_34.setTransform(320.775,254.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#131313").s().p("AgMAUQgGgHAAgMQgBgMAIgHQAHgIAMAAQAHAAAEACIAAAJQgFgEgHAAQgHAAgFAGQgFAFAAAJQAAAJAFAFQAEAFAIAAQAHAAAFgEIAAAIQgFADgJAAQgKAAgHgHg");
	this.shape_35.setTransform(315.3,254.375);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#131313").s().p("AgSAUQgHgHAAgMQAAgMAHgIQAIgHALAAQALAAAHAHQAHAHAAAMQAAAMgHAIQgIAHgLAAQgLAAgHgHgAgMgOQgEAGAAAIQAAAKAEAFQAFAFAHAAQAIAAAFgFQAEgFAAgKQAAgJgEgFQgFgFgIAAQgHAAgFAFg");
	this.shape_36.setTransform(306.925,254.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_37.setTransform(302.125,253.675);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_38.setTransform(355.875,242.575);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#131313").s().p("AAdAbIAAgdQAAgJgDgEQgDgEgGAAQgGAAgDAFQgEAFAAAHIAAAdIgHAAIAAgeQAAgQgMAAQgGAAgDAFQgDAFgBAHIAAAdIgIAAIAAgzIAIAAIAAAIQAGgKAKAAQAGAAAEADQADADACAFQAFgLAMAAQARAAAAAWIAAAfg");
	this.shape_39.setTransform(348.65,242.525);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#131313").s().p("AgEAmIAAgzIAIAAIAAAzgAgDgcQAAAAgBgBQAAAAAAAAQAAgBAAgBQgBAAAAgBIACgEQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAABQAAAAgBAAQAAABgBAAQAAABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBg");
	this.shape_40.setTransform(342.85,241.375);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_41.setTransform(339.725,241.875);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_42.setTransform(332.475,242.575);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#131313").s().p("AgUAkIAAgJQAKAFAHAAQATAAgBgVIAAgGQgGALgLAAQgJAAgGgHQgGgHAAgLQAAgNAHgIQAFgIALAAQALAAAEAIIAAgGIAJAAIAAAvQAAAcgbAAQgJAAgIgDgAgKgZQgEAGgBAKQABAIADAEQAFAGAGAAQAHAAAFgGQADgDAAgIIAAgIQAAgGgDgEQgEgFgHAAQgHAAgEAGg");
	this.shape_43.setTransform(326.45,243.75);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#131313").s().p("AgPAXQgFgEAAgHQAAgNASgDIAOgCQAAgNgLAAQgIAAgIAGIAAgIQAIgFAJAAQATAAAAATIAAAhIgJAAIAAgIQgFAJgKAAQgIAAgEgEgAAAACQgFAAgDACQgDADAAAFQAAAEADACQACACAFAAQAFAAAEgEQAEgEAAgHIAAgFg");
	this.shape_44.setTransform(320.775,242.575);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#131313").s().p("AgNAaIAAgyIAJAAIAAAKQACgFADgDQADgDAEAAIAFAAIAAAJQgBgCgFAAQgFAAgDAFQgDAFAAAIIAAAag");
	this.shape_45.setTransform(316.8,242.55);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_46.setTransform(311.925,242.575);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#131313").s().p("AgDAaIgUgzIAJAAIANAkIABAIIACgHIAOglIAIAAIgUAzg");
	this.shape_47.setTransform(306.7,242.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#131313").s().p("AAXAkIgHgUIgfAAIgHAUIgKAAIAchIIAIAAIAdBIgAAAgWIgLAeIAXAAIgLgeIgBgFIAAAFg");
	this.shape_48.setTransform(301,241.55);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#5E5584").s().p("AgfA0IAAgOQALAJAOAAQAGAAAEgCQAFgBAEgDQADgDABgDQACgEAAgFQABgXgfAAIgJAAIAAgKIAJAAQAbABAAgVQAAgTgVAAQgMAAgKAIIAAgNQAKgGAQAAQAFAAAGACQAGACAEADQAEAEACAFQACAFAAAGQAAAWgWAGIAAABQAGAAAEABQAFACAEAEQADADADAFQACAEAAAHQAAAHgEAGQgCAGgFAEQgGAFgHACQgHADgIAAQgQAAgJgGg");
	this.shape_49.setTransform(331.35,165.65);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#5E5584").s().p("AgfA1IAAgPQALAIANAAQAGAAADgCQAFgCAEgDQAEgDACgEQABgFAAgFQAAgMgHgFQgHgGgNAAIgGAAIgEAAIgFAAIgEABIADg4IAzAAIAAALIgoAAIgCAiIAGgBIAEAAQAIAAAIACQAGADAFAEQAFAEADAGQACAGAAAIQAAAIgDAGQgDAIgFAEQgFAFgHACQgHADgIAAQgQAAgIgEg");
	this.shape_50.setTransform(322.95,165.75);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_51.setTransform(350.575,183.275);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_52.setTransform(345.625,183.275);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_53.setTransform(340.675,183.275);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#131313").s().p("AANAbIAAgdQAAgRgMAAQgFAAgEAFQgEAFAAAHIAAAdIgJAAIAAgzIAJAAIAAAIQAGgKAKAAQAIAAAFAGQAFAFAAALIAAAfg");
	this.shape_54.setTransform(335.525,183.225);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#131313").s().p("AgSAUQgHgHAAgMQAAgMAHgIQAIgHALAAQALAAAHAHQAHAHAAAMQAAAMgHAIQgIAHgLAAQgLAAgHgHgAgMgOQgEAGAAAIQAAAKAEAFQAFAFAHAAQAIAAAFgFQAEgFAAgKQAAgJgEgFQgFgFgIAAQgHAAgFAFg");
	this.shape_55.setTransform(329.425,183.275);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#131313").s().p("AgXAnIAAhLIAIAAIAAAJQAHgLAKAAQALAAAGAHQAFAHAAAMQAAAMgGAIQgHAIgLAAQgJAAgGgJIAAAggAgKgaQgEAFgBAIIAAAHQAAAGAFAEQAEAFAGAAQAHAAAEgGQAFgFAAgKQgBgJgEgFQgDgFgIAAQgGAAgEAFg");
	this.shape_56.setTransform(323.5,184.425);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_57.setTransform(318.075,183.275);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_58.setTransform(313.125,183.275);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#131313").s().p("AAQAlIgMgVIgDgFIgDgDIgDgCIgFgBIgHAAIAAAgIgIAAIAAhJIAWAAIAIACIAHADQADADABAEQACADAAAFIgBAHIgDAGIgGADIgGADIADABIACADIADAEIADADIANAXgAgRgCIAMAAIAFgBIAFgCIADgFIABgFQAAgHgEgCQgEgEgGAAIgMAAg");
	this.shape_59.setTransform(307.975,182.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#F4F4F4").s().p("AtNNbIAA61IabAAIAAa1g");
	this.shape_60.setTransform(328.55,238.85);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#131313").s().p("AgdAyIAAgKIAGABQAJAAAEgKIAFgNIgbhEIANAAIASA0IABAGIAAAAIACgGIATg0IAMAAIggBPQgIAWgPAAIgHgBg");
	this.shape_61.setTransform(374.875,133.275);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#131313").s().p("AgVAbQgJgJAAgRQAAgQAKgKQAJgKANAAQANAAAIAJQAHAIAAAQIAAAFIgwAAQAAALAGAHQAHAGAJAAQAMAAAKgHIAAAKQgJAGgQABQgNAAgJgKgAgLgUQgFAFgCAJIAlAAQAAgJgFgGQgEgFgIAAQgIAAgFAGg");
	this.shape_62.setTransform(367.95,131.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#131313").s().p("AgFAjIgbhFIANAAIASAyIABAJIACgJIATgyIAMAAIgcBFg");
	this.shape_63.setTransform(360.95,131.625);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#131313").s().p("AgRAjIAAhEIALAAIAAAOQADgHAEgEQAEgEAHgBIAGABIAAAMQgDgCgFAAQgIAAgDAGQgFAIAAAKIAAAjg");
	this.shape_64.setTransform(355.15,131.55);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#131313").s().p("AgcAGIAAgoIALAAIAAAmQAAAWARAAQAHAAAFgGQAGgGAAgKIAAgmIALAAIAABEIgLAAIAAgLIgBAAQgHANgNAAQgZgBAAgdg");
	this.shape_65.setTransform(348.225,131.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#131313").s().p("AgKAyIgHgBIgGgCIgGgCIAAgOIAGAEIAHADIAHACIAHAAQAJAAAFgEQAGgEAAgHQAAgEgCgDIgFgFIgHgFIgIgFIgKgEQgEgCgDgEQgEgDgBgEQgCgEAAgFQAAgHADgFQACgFAFgDQAFgDAGgCIALgBQAPAAAGADIAAANQgIgGgOAAIgGABQgEAAgDACIgFAFQgBADAAAEQAAADABADQABADADACIAHAEIAIAFIAKAEIAIAHIAGAHQACAFAAAFQAAAHgDAFQgDAFgFADQgFAEgGABIgMABIgGAAg");
	this.shape_66.setTransform(340.725,130.225);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#131313").s().p("AANAzIgeghIAAAhIgLAAIAAhlIALAAIAABAIAdgfIAOAAIgfAgIAiAkg");
	this.shape_67.setTransform(330.175,129.95);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#131313").s().p("AgQAbQgJgKAAgPQAAgRAKgKQAKgKAPAAQAJgBAHAEIAAALQgIgFgIAAQgKAAgHAIQgHAIAAALQAAAMAHAHQAGAHAKAAQAJAAAIgGIAAALQgIAEgLABQgOAAgJgKg");
	this.shape_68.setTransform(323.025,131.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#131313").s().p("AgVAfQgFgGAAgIQgBgTAXgDIAUgDQAAgSgOAAQgMAAgKAJIAAgMQAKgGANAAQAZAAAAAaIAAAsIgMAAIAAgLIAAAAQgHANgNAAQgKgBgHgFgAAAACQgHABgEADQgEADAAAGQAAAGADADQAFADAFAAQAIAAAFgGQAGgFgBgKIAAgGg");
	this.shape_69.setTransform(316,131.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#131313").s().p("AgUApIAAAKIgLAAIAAhmIALAAIAAAtQAIgOAQAAQAMAAAIAKQAIAJAAAPQAAARgIALQgJAKgPAAQgMAAgIgLgAgOgDQgGAFAAALIAAAJQAAAJAGAGQAFAGAJAAQAJAAAGgIQAFgIABgNQAAgMgGgGQgFgGgKAAQgIAAgGAHg");
	this.shape_70.setTransform(308.95,130.025);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#131313").s().p("AgXArQgIgJAAgQQAAgSAJgJQAIgLAOAAQAPAAAGAMIAAgrIALAAIAABmIgLAAIAAgMQgIANgPAAQgNAAgIgJgAgNgDQgHAHABANQAAAMAFAHQAFAHAJAAQAJAAAHgHQAFgGAAgLIAAgKQAAgIgFgFQgGgGgJAAQgJAAgFAHg");
	this.shape_71.setTransform(300.3,130.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#131313").s().p("AgVAbQgJgJABgRQgBgQAKgKQAJgKAMAAQAOAAAIAJQAIAIgBAQIAAAFIgwAAQAAALAHAHQAFAGAKAAQAMAAAKgHIAAAKQgKAGgPABQgOAAgIgKgAgLgUQgGAFgBAJIAlAAQAAgJgFgGQgEgFgJAAQgGAAgGAGg");
	this.shape_72.setTransform(292.9,131.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#131313").s().p("AgVAbQgIgJAAgRQgBgQAKgKQAJgKANAAQAOAAAHAJQAIAIAAAQIAAAFIgxAAQABALAFAHQAHAGAJAAQALAAAKgHIAAAKQgIAGgQABQgNAAgJgKgAgLgUQgGAFgBAJIAlAAQAAgJgFgGQgFgFgHAAQgIAAgFAGg");
	this.shape_73.setTransform(285.65,131.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#131313").s().p("AgYAxIAAhhIAxAAIAAALIgmAAIAAAhIAjAAIAAAKIgjAAIAAArg");
	this.shape_74.setTransform(278.925,130.225);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#131313").s().p("AgHAZIAAgoIgMAAIAAgJIAMAAIAAgRIAKgEIAAAVIARAAIAAAJIgRAAIAAAmQAAAHACADQADADAFAAQAEAAADgCIAAAKQgEACgGAAQgRAAAAgVg");
	this.shape_75.setTransform(386.425,112.175);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#131313").s().p("AASAkIAAgnQAAgWgQAAQgIAAgFAGQgGAGAAAKIAAAnIgLAAIAAhFIALAAIAAAMQAIgOAOAAQAMAAAGAIQAGAHAAAOIAAAqg");
	this.shape_76.setTransform(380.275,113.025);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#131313").s().p("AgVAbQgJgKAAgRQAAgPAKgKQAJgLANAAQANAAAIAJQAHAKABAPIAAAFIgxAAQABAMAFAGQAHAGAJAAQALAAAKgIIAAALQgIAGgQAAQgOAAgIgJgAgLgUQgGAGgBAIIAlAAQAAgJgFgFQgFgGgHAAQgIAAgFAGg");
	this.shape_77.setTransform(372.7,113.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#131313").s().p("AgFAjIgahFIALAAIASAyIACAJIADgJIASgyIAMAAIgcBFg");
	this.shape_78.setTransform(365.75,113.125);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#131313").s().p("AgZAxIAAhhIAxAAIAAALIgmAAIAAAgIAjAAIAAAJIgjAAIAAAiIAoAAIAAALg");
	this.shape_79.setTransform(359.225,111.725);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#131313").s().p("AgHAZIAAgoIgMAAIAAgJIAMAAIAAgRIAKgEIAAAVIARAAIAAAJIgRAAIAAAmQAAAHACADQADADAFAAQAEAAADgCIAAAKQgEACgGAAQgRAAAAgVg");
	this.shape_80.setTransform(349.125,112.175);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#131313").s().p("AASAkIAAgnQAAgWgQAAQgIAAgFAGQgGAGAAAKIAAAnIgLAAIAAhFIALAAIAAAMQAIgOAOAAQAMAAAGAIQAGAHAAAOIAAAqg");
	this.shape_81.setTransform(342.925,113.025);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#131313").s().p("AgVAbQgIgKAAgRQAAgPAJgKQAJgLAMAAQAPAAAHAJQAIAKAAAPIAAAFIgxAAQAAAMAHAGQAFAGAKAAQALAAAKgIIAAALQgJAGgPAAQgNAAgJgJgAgLgUQgFAGgCAIIAlAAQAAgJgFgFQgEgGgJAAQgGAAgGAGg");
	this.shape_82.setTransform(335.4,113.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#131313").s().p("AAmAkIAAgnQAAgMgDgFQgEgFgIAAQgHAAgFAGQgFAHAAAJIAAAnIgLAAIAAgpQAAgUgPAAQgIAAgFAGQgEAGAAAKIAAAnIgLAAIAAhFIALAAIAAALQAHgNAPAAQAHAAAFAEQAEAEACAHQAIgPAPAAQAXAAAAAdIAAAqg");
	this.shape_83.setTransform(325.725,113.025);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#131313").s().p("AASAkIAAgnQAAgWgQAAQgIAAgFAGQgGAGAAAKIAAAnIgLAAIAAhFIALAAIAAAMQAIgOAOAAQAMAAAGAIQAGAHAAAOIAAAqg");
	this.shape_84.setTransform(315.825,113.025);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#131313").s().p("AgFAzIAAhFIAKAAIAABFgAgEgmQgCgBAAgDQAAgEACgBQACgDACAAQADAAACADQACABAAAEQAAADgCABQgCACgDAAQgCAAgCgCg");
	this.shape_85.setTransform(310.125,111.5);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#131313").s().p("AgVAfQgFgFgBgJQAAgTAXgDIAUgDQAAgSgOAAQgMAAgKAIIAAgKQAKgIANAAQAZAAAAAaIAAAtIgMAAIAAgLIAAAAQgHAMgNAAQgKABgHgGgAAAACQgHABgEADQgEADAAAHQAAAFADADQAEADAGAAQAIAAAFgFQAGgGgBgJIAAgHg");
	this.shape_86.setTransform(304.65,113.1);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#131313").s().p("AgHAZIAAgoIgMAAIAAgJIAMAAIAAgRIAKgEIAAAVIARAAIAAAJIgRAAIAAAmQAAAHACADQADADAFAAQAEAAADgCIAAAKQgEACgGAAQgRAAAAgVg");
	this.shape_87.setTransform(298.875,112.175);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#131313").s().p("AgRAkIAAhFIALAAIAAAOQADgHADgEQAFgFAGABIAHABIAAALQgDgCgGAAQgGAAgEAHQgFAGAAALIAAAkg");
	this.shape_88.setTransform(294.25,113.05);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#131313").s().p("AgVAbQgJgKAAgRQAAgPAKgKQAJgLANAAQANAAAIAJQAHAKAAAPIAAAFIgwAAQABAMAFAGQAHAGAJAAQALAAALgIIAAALQgKAGgPAAQgOAAgIgJgAgLgUQgGAGgBAIIAlAAQAAgJgFgFQgFgGgHAAQgIAAgFAGg");
	this.shape_89.setTransform(287.75,113.1);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#131313").s().p("AgHAZIAAgoIgMAAIAAgJIAMAAIAAgRIAKgEIAAAVIARAAIAAAJIgRAAIAAAmQAAAHACADQADADAFAAQAEAAADgCIAAAKQgEACgGAAQgRAAAAgVg");
	this.shape_90.setTransform(281.775,112.175);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#131313").s().p("AASAkIAAgnQAAgWgQAAQgIAAgFAGQgGAGAAAKIAAAnIgLAAIAAhFIALAAIAAAMQAIgOAOAAQAMAAAGAIQAGAHAAAOIAAAqg");
	this.shape_91.setTransform(275.575,113.025);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#131313").s().p("AgZAxIAAhhIAxAAIAAALIgmAAIAAAgIAjAAIAAAJIgjAAIAAAiIAoAAIAAALg");
	this.shape_92.setTransform(268.425,111.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(244,100.2,169.10000000000002,309.40000000000003);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5,32);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.IV = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAMAbIgLgmIgBgEIAAAEIgLAmIgJAAIgQg1IAJAAIAKAoIABAEIAAAAIABgEIANgoIAHAAIALAoIABAEIABAAIAAgEIALgoIAIAAIgQA1g");
	this.shape.setTransform(76,15.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgQAVQgGgIAAgNQgBgMAIgIQAHgHAKAAQAKAAAGAGQAFAHAAAMIAAAEIgkAAQAAAJAEAFQAFAFAHAAQAJAAAIgGIAAAIQgHAFgMAAQgKAAgHgHgAgIgQQgEAFgBAHIAcAAQgBgIgDgEQgEgEgFAAQgGAAgEAEg");
	this.shape_1.setTransform(69.3,15.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgDAoIAAg1IAHAAIAAA1gAgDgdQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEIADgCQAAAAABABQAAAAABAAQAAAAABAAQAAABABAAQAAABABAAQAAABAAAAQABAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_2.setTransform(65.175,13.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAmIgchLIAKAAIAVA7IABAHIACgHIAVg7IAJAAIgcBLg");
	this.shape_3.setTransform(60.5,14.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgDAoIAAhPIAHAAIAABPg");
	this.shape_4.setTransform(52.875,13.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgQAYQgEgFAAgHQgBgOATgCIAOgCQAAgOgLAAQgIAAgIAGIAAgIQAIgFAJAAQAUAAgBAUIAAAiIgJAAIAAgJQgFAKgKAAQgIAAgFgEgAAAABQgFABgDACQgDACAAAGQAAAEADACQACADAFAAQAGAAAEgFQADgEAAgHIAAgFg");
	this.shape_5.setTransform(48.65,15.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgWAFIAAggIAJAAIAAAeQAAARANAAQAFAAAFgEQAEgFAAgIIAAgeIAIAAIAAA1IgIAAIAAgIIgBAAQgFAKgKAAQgUAAAAgXg");
	this.shape_6.setTransform(42.95,15.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSAhQgGgHAAgMQAAgOAHgHQAGgIALAAQALAAAFAJIAAgiIAJAAIAABPIgJAAIAAgJQgGALgLAAQgLAAgGgIgAgKgCQgFAFAAAKQAAAJAFAGQADAFAHAAQAHAAAEgFQAFgFAAgIIAAgIQAAgHgEgDQgFgFgGAAQgHAAgEAGg");
	this.shape_7.setTransform(36.6,13.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgDAoIAAg1IAHAAIAAA1gAgDgdQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEIADgCQAAAAABABQAAAAABAAQAAAAABAAQAAABABAAQAAABABAAQAAABAAAAQABAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_8.setTransform(32.325,13.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgEAbIgUg1IAJAAIAOAmIABAIIACgHIAOgnIAJAAIgVA1g");
	this.shape_9.setTransform(28.425,15.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgDAoIAAg1IAHAAIAAA1gAgDgdQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEIADgCQAAAAABABQABAAAAAAQAAAAABAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBABAAAAQgBAAAAABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_10.setTransform(24.575,13.95);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgSAhQgGgHAAgMQAAgOAHgHQAHgIAKAAQALAAAFAJIAAgiIAJAAIAABPIgJAAIAAgJQgGALgMAAQgKAAgGgIgAgLgCQgEAFAAAKQAAAJAEAGQAFAFAGAAQAHAAAFgFQAEgFAAgIIAAgIQAAgHgEgDQgEgFgHAAQgHAAgFAGg");
	this.shape_11.setTransform(19.9,13.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAOAcIAAgfQAAgQgNAAQgFAAgFAEQgEAFAAAHIAAAfIgIAAIAAg1IAIAAIAAAJQAGgLALABQAJgBAFAGQAEAFAAALIAAAhg");
	this.shape_12.setTransform(13.925,15.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgDAmIAAhLIAHAAIAABLg");
	this.shape_13.setTransform(9.45,14.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#5E5584").s().p("Am3CQIAAkfINvAAIAAEfg");
	this.shape_14.setTransform(43.9752,14.4311);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.IV, new cjs.Rectangle(0,0,88,28.9), null);


(lib.cursor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgQIAhlMgrLArMIgNgIMAAAis/MB3BB29Mg7dAAAMAbGBBFIxWIqg");
	this.shape.setTransform(8.6,9.55,0.0152,0.014,-15.0037,0,0,-65.4,34.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#131313").s().p("EgDYB1CIjCnRMgVRgzXMgpNApNIpLJJMAAAjhDQAAgKADgOIAGgWIAQAWQAJAMAIAIMAzNAzNUAkgAkkAtrAtqIVRVQQAKAKAQANIAbAVIgIANMhFVAAAMAYwA7bMgkGASEIggAWgEACJBmIIRWorMgbGhBEMA7cAAAMh3Ah29MAAACs/IAMAIMArLgrMg");
	this.shape_1.setTransform(9.2,9.8,0.0152,0.014,-15.0037,0,0,-80.7,99.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.4,19.6);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,96,170,0.498)").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAEAAACADQACACAAACQAAADgCADQgCACgEAAQgCAAgCgCg");
	this.shape.setTransform(9.25,9.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,96,170,0.498)").s().p("AgNAPQgGgHAAgIQAAgGAGgHQAGgGAHAAQAIAAAGAGQAGAHAAAGQAAAIgGAHQgGAFgIAAQgHAAgGgFg");
	this.shape_1.setTransform(9.25,9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(102,96,170,0.498)").s().p("AgVAXQgKgJAAgOQAAgLAKgKQAJgKAMAAQANAAAJAKQAKAKAAALQAAAOgKAJQgJAJgNAAQgMAAgJgJg");
	this.shape_2.setTransform(9.25,9.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,96,170,0.498)").s().p("AgeAgQgNgOAAgSQAAgQANgOQAMgNASAAQASAAANANQANAOAAAQQAAASgNAOQgNAMgSAAQgSAAgMgMg");
	this.shape_3.setTransform(9.25,9.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(102,96,170,0.498)").s().p("AgnAoQgQgQAAgYQAAgVAQgSQARgQAWAAQAWAAARAQQARASAAAVQAAAYgRAQQgRAQgWAAQgWAAgRgQg");
	this.shape_4.setTransform(9.25,9.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(102,96,170,0.498)").s().p("AgiAjQgOgPAAgUQAAgTAOgPQAOgOAUAAQATAAAOAOQAQAPAAATQAAAUgQAPQgOAOgTAAQgUAAgOgOg");
	this.shape_5.setTransform(9.25,9.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,96,170,0.498)").s().p("AgdAeQgMgMAAgSQAAgPAMgOQANgMAQAAQARAAAMAMQANAOAAAPQAAASgNAMQgMAMgRAAQgQAAgNgMg");
	this.shape_6.setTransform(9.225,9.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(102,96,170,0.498)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQALgKANAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgNAAgLgKg");
	this.shape_7.setTransform(9.225,9.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(102,96,170,0.498)").s().p("AgTAUQgIgIAAgMQAAgKAIgJQAIgIALAAQALAAAIAIQAJAJAAAKQAAAMgJAIQgIAIgLAAQgLAAgIgIg");
	this.shape_8.setTransform(9.225,9.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(102,96,170,0.498)").s().p("AgOAPQgGgGAAgJQAAgHAGgHQAGgGAIAAQAIAAAGAGQAHAHAAAHQAAAJgHAGQgGAGgIAAQgIAAgGgGg");
	this.shape_9.setTransform(9.225,9.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(102,96,170,0.498)").s().p("AgIAKQgFgEAAgGQAAgEAFgEQAEgFAEAAQAGAAAEAFQADAEAAAEQAAAGgDAEQgEAEgGgBQgEABgEgEg");
	this.shape_10.setTransform(9.2,9.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(102,96,170,0.498)").s().p("AgEAFQgBgCAAgDQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQABABAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAADgCACQAAAAAAABQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAg");
	this.shape_11.setTransform(9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[]},1).wait(6));

	// Layer_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(102,96,170,0.498)").s().p("AgLALQgEgEAAgHQAAgFAEgGQAGgEAFAAQAHAAAEAEQAFAGAAAFQAAAHgFAEQgEAFgHAAQgFAAgGgFg");
	this.shape_12.setTransform(9.2,9.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(102,96,170,0.498)").s().p("AgUAVQgHgJAAgMQAAgLAHgJQAJgHALAAQALAAAJAHQAJAJAAALQAAAMgJAJQgJAIgLAAQgLAAgJgIg");
	this.shape_13.setTransform(9.2,9.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(102,96,170,0.498)").s().p("AgdAdQgLgMgBgRQABgQALgNQANgLAQgBQAQABANALQAMANAAAQQAAARgMAMQgNAMgQAAQgQAAgNgMg");
	this.shape_14.setTransform(9.2,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(102,96,170,0.498)").s().p("AgmAnQgPgQAAgXQAAgUAPgSQARgPAVAAQAWAAAPAPQARASAAAUQAAAXgRAQQgPAPgWAAQgVAAgRgPg");
	this.shape_15.setTransform(9.2,9.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(102,96,170,0.498)").s().p("AgvAvQgTgTAAgcQAAgaATgVQAUgTAbAAQAaAAAUATQAUAVAAAaQAAAcgUATQgUATgaAAQgbAAgUgTg");
	this.shape_16.setTransform(9.2,9.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(102,96,170,0.498)").s().p("Ag4A4QgWgXAAghQAAgeAWgaQAYgWAgAAQAgAAAXAWQAZAaAAAeQAAAhgZAXQgXAYggAAQggAAgYgYg");
	this.shape_17.setTransform(9.2,9.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(102,96,170,0.498)").s().p("AhBBCQgagcAAgmQAAgjAageQAbgaAmAAQAkAAAbAaQAdAeAAAjQAAAmgdAcQgbAagkAAQgmAAgbgag");
	this.shape_18.setTransform(9.2,9.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(102,96,170,0.498)").s().p("Ag8A8QgYgYAAgkQAAggAYgcQAagYAiAAQAiAAAYAYQAbAcAAAgQAAAkgbAYQgYAZgiAAQgiAAgagZg");
	this.shape_19.setTransform(9.2,9.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(102,96,170,0.498)").s().p("Ag2A4QgXgXAAghQAAgeAXgYQAWgXAgAAQAfAAAXAXQAYAYAAAeQAAAhgYAXQgXAWgfAAQggAAgWgWg");
	this.shape_20.setTransform(9.2,9.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(102,96,170,0.498)").s().p("AgyAyQgUgUAAgeQAAgbAUgXQAWgUAcAAQAcAAAUAUQAXAXAAAbQAAAegXAUQgUAVgcAAQgcAAgWgVg");
	this.shape_21.setTransform(9.2,9.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(102,96,170,0.498)").s().p("AgsAuQgTgTAAgbQAAgZATgTQASgTAaAAQAaAAASATQAUATAAAZQAAAbgUATQgSASgaAAQgaAAgSgSg");
	this.shape_22.setTransform(9.2,9.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(102,96,170,0.498)").s().p("AgoAoQgQgQAAgYQAAgVAQgTQARgQAXAAQAWAAARAQQASATAAAVQAAAYgSAQQgRARgWAAQgXAAgRgRg");
	this.shape_23.setTransform(9.2,9.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(102,96,170,0.498)").s().p("AgiAkQgPgPAAgVQAAgSAPgQQAOgPAUAAQAUAAAPAPQAPAQAAASQAAAVgPAPQgPAOgUAAQgUAAgOgOg");
	this.shape_24.setTransform(9.2,9.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(102,96,170,0.498)").s().p("AgeAeQgMgMAAgSQAAgQAMgOQANgMARAAQARAAAMAMQAOAOAAAQQAAASgOAMQgMANgRAAQgRAAgNgNg");
	this.shape_25.setTransform(9.2,9.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(102,96,170,0.498)").s().p("AgYAaQgLgLAAgPQAAgNALgLQAKgLAOAAQAOAAAKALQAMALAAANQAAAPgMALQgKAKgOAAQgOAAgKgKg");
	this.shape_26.setTransform(9.2,9.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(102,96,170,0.498)").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape_27.setTransform(9.2,9.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(102,96,170,0.498)").s().p("AgOAPQgHgFAAgKQAAgHAHgHQAGgHAIAAQAIAAAHAHQAHAHAAAHQAAAKgHAFQgHAHgIAAQgIAAgGgHg");
	this.shape_28.setTransform(9.2,9.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(102,96,170,0.498)").s().p("AgJALQgFgEAAgHQAAgFAFgEQAEgFAFAAQAGAAAFAFQAEAEAAAFQAAAHgEAEQgFAEgGAAQgFAAgEgEg");
	this.shape_29.setTransform(9.2,9.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(102,96,170,0.498)").s().p("AgFAFQgCgCAAgDQAAgCACgDQACgCADAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgDAAgCgDg");
	this.shape_30.setTransform(9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.4,18.4);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0A4D3").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80.025,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160.1,600);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.result = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F7579").s().p("AmHD3IAAntIMPAAIAAHtgAlfDPIK/AAIAAllIlgCwIAAAAIlfixgAlfjEIFfCyIFgixIAAgLIq/AAg");
	this.shape.setTransform(74.7572,516.2974,0.1674,0.1674);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9E9E9").s().p("AnhHiQjHjIAAkaQAAkZDHjIQDIjIEZAAQEaAADIDIQDHDIAAEZQAAEajHDIQjIDIkaAAQkZAAjIjIg");
	this.shape_1.setTransform(74.7572,516.3015,0.1674,0.1674);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F7579").s().p("AheACICpipIAVAWIiUCTICPCQIgVAWg");
	this.shape_2.setTransform(39.3737,516.2955,0.1673,0.1673);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F7579").s().p("AheCSICTiTIiQiQIAWgWICkCmIioCpg");
	this.shape_3.setTransform(48.5918,516.2955,0.1673,0.1673);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F7579").s().p("AhxEnIDBpYIAiALIjCJXg");
	this.shape_4.setTransform(43.9869,516.2955,0.1673,0.1673);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9E9E9").s().p("AnhHiQjHjIAAkaQAAkZDHjIQDIjIEZAAQEbAADHDIQDHDIAAEZQAAEajHDIQjHDIkbAAQkZAAjIjIg");
	this.shape_5.setTransform(44.0093,516.3015,0.1674,0.1674);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F7579").s().p("AgOBQIAAifIAdAAIAACfg");
	this.shape_6.setTransform(16.295,519.7209,0.1673,0.1673);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F7579").s().p("AgOBsIAAjWIAdAAIAADWg");
	this.shape_7.setTransform(18.6455,520.1768,0.1673,0.1673);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F7579").s().p("AgOBsIAAjWIAdAAIAADWg");
	this.shape_8.setTransform(14.0783,520.1768,0.1673,0.1673);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F7579").s().p("AiLAPIAAgdIEXAAIAAAdg");
	this.shape_9.setTransform(16.295,517.0233,0.1673,0.1673);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F7579").s().p("AibCcIAAk3IE3AAIAAE3gAh8B+ID5AAIAAj6Ij5AAg");
	this.shape_10.setTransform(16.295,513.2172,0.1673,0.1673);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F7579").s().p("AiaCcIAAk3IE1AAIAAE3gAh9B9ID6AAIAAj5Ij6AAg");
	this.shape_11.setTransform(10.2054,519.3738,0.1673,0.1673);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F7579").s().p("AiaCcIAAk3IE1AAIAAE3gAh9B+ID6AAIAAj6Ij6AAg");
	this.shape_12.setTransform(10.2054,513.2172,0.1673,0.1673);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E9E9E9").s().p("AnhHiQjIjIABkaQgBkZDIjIQDIjIEZAAQEbAADHDIQDHDIABEZQgBEajHDIQjHDIkbAAQkZAAjIjIg");
	this.shape_13.setTransform(13.2655,516.3015,0.1674,0.1674);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhmCyQg2AAgtgeQgsgdgUgxQgPghAAglQAAgkAPghQAUgxAsgdQAtgeA2AAIAdAAQAEANAAAMQAAAMgEANIgdAAQghAAgcAQQgcAPgSAbQgVAgAAAlQAAAlAVAhQASAaAcAQQAcAQAhAAIDNAAQA1AAAlgmQAmglAAg1QAAg0gmgmQglglg1AAIgiAAIABgZQAAgNgBgMIAiAAQBKAAA0A0QA0A0AABJQAABKg0A0Qg0A0hKAAg");
	this.shape_14.setTransform(-15.2364,517.5753,0.1673,0.1673);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABKCyQgEgNAAgMQAAgMAEgNIAdAAQAhAAAcgQQAcgQASgaQAVghAAglQAAglgVggQgSgbgcgPQgcgQghAAIjNAAQg1AAglAmQgmAlAAA0QAAA1AmAlQAlAmA1AAIAiAAQgBAMAAANIABAZIgiAAQhKAAg0g0Qg0g0AAhKQAAhJA0g0QA0g0BKAAIDNAAQA2AAAtAeQAsAdAUAxQAPAhAAAkQAAAlgPAhQgUAxgsAdQgtAeg2AAg");
	this.shape_15.setTransform(-19.5694,515.0157,0.1673,0.1673);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F7579").s().p("AnhHiQjIjIAAkaQAAkZDIjIQDHjIEaAAQEaAADIDIQDIDIgBEZQABEajIDIQjIDIkaAAQkaAAjHjIg");
	this.shape_16.setTransform(-17.3945,516.3015,0.1674,0.1674);

	this.components = new lib.resultcomponent("synched",0);
	this.components.name = "components";
	this.components.setTransform(-214.95,160.2,1,1,0,0,0,86.6,129.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.components},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.5,131,169.1,396.70000000000005);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(64.45,10.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(16.425,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(5.125,16.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(16.425,5.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(5.125,5.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(0,0,132.4,21.6), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_86 = function() {
		exportRoot.tlMain.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(86).call(this.frame_86).wait(14).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(80.35,300.6,0.0633,0.0633,0,0,0,-38.7,3.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-39.9,regY:1.4,scaleX:1.0625,scaleY:1.0625,x:80.3,y:300.55},13,cjs.Ease.quadOut).to({regX:-39.8,x:21.2},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AitYYIAAjlITwAAIAADlg");
	var mask_graphics_15 = new cjs.Graphics().p("AixYYIAAjlITwAAIAADlg");
	var mask_graphics_16 = new cjs.Graphics().p("Ai9YYIAAjlITvAAIAADlg");
	var mask_graphics_17 = new cjs.Graphics().p("AjSYYIAAjlITwAAIAADlg");
	var mask_graphics_18 = new cjs.Graphics().p("AjuYYIAAjlITvAAIAADlg");
	var mask_graphics_19 = new cjs.Graphics().p("AkUYYIAAjlITwAAIAADlg");
	var mask_graphics_20 = new cjs.Graphics().p("AlBYYIAAjlITwAAIAADlg");
	var mask_graphics_21 = new cjs.Graphics().p("AluYYIAAjlITvAAIAADlg");
	var mask_graphics_22 = new cjs.Graphics().p("AmTYYIAAjlITvAAIAADlg");
	var mask_graphics_23 = new cjs.Graphics().p("AmwYYIAAjlITvAAIAADlg");
	var mask_graphics_24 = new cjs.Graphics().p("AnFYYIAAjlITwAAIAADlg");
	var mask_graphics_25 = new cjs.Graphics().p("AnRYYIAAjlITwAAIAADlg");
	var mask_graphics_26 = new cjs.Graphics().p("AnVYYIAAjlITwAAIAADlg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:109.0881,y:155.9949}).wait(1).to({graphics:mask_graphics_15,x:108.6763,y:155.9949}).wait(1).to({graphics:mask_graphics_16,x:107.441,y:155.9949}).wait(1).to({graphics:mask_graphics_17,x:105.3821,y:155.9949}).wait(1).to({graphics:mask_graphics_18,x:102.4998,y:155.9949}).wait(1).to({graphics:mask_graphics_19,x:98.7939,y:155.9949}).wait(1).to({graphics:mask_graphics_20,x:94.2644,y:155.9949}).wait(1).to({graphics:mask_graphics_21,x:89.735,y:155.9949}).wait(1).to({graphics:mask_graphics_22,x:86.0291,y:155.9949}).wait(1).to({graphics:mask_graphics_23,x:83.1467,y:155.9949}).wait(1).to({graphics:mask_graphics_24,x:81.0878,y:155.9949}).wait(1).to({graphics:mask_graphics_25,x:79.8525,y:155.9949}).wait(1).to({graphics:mask_graphics_26,x:79.4881,y:155.9949}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-66.65,289.4,1.0625,1.0625,0,0,0,0.1,0.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({regX:0.2,x:9.8,y:289.55},12,cjs.Ease.quadInOut).wait(33).to({alpha:0},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(0.05,1,0.1649,0.7361,0,0,0,0.3,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({startPosition:0},0).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.7,161.9,601.1999999999999);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.uigraphics = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		//this.survey.cache(-105,-104,422,419,2);
		//this.result_page.components.cache(-71,-112,342,578,2);
	}
	this.frame_454 = function() {
		this.stop();
		exportRoot.tlMain.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(454).call(this.frame_454).wait(1));

	// cursor
	this.cursor = new lib.cursor("synched",0);
	this.cursor.name = "cursor";
	this.cursor.setTransform(54.6,256.9,1.9135,1.9135,0,0,0,9.2,9.8);

	this.timeline.addTween(cjs.Tween.get(this.cursor).to({x:1.45,y:265.4},42,cjs.Ease.quadInOut).wait(27).to({startPosition:0},0).to({x:1.25,y:360.35},31,cjs.Ease.quadInOut).wait(40).to({startPosition:0},0).to({x:81.5,y:245.35},39,cjs.Ease.quadInOut).to({x:62.7,y:271.5},207,cjs.Ease.quadInOut).to({x:45.9,y:490.5},41,cjs.Ease.quadInOut).wait(28));

	// click
	this.instance = new lib.click("synched",0,false);
	this.instance.setTransform(-16.75,246.8,1.1389,1.1389,0,0,0,9.2,9.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(46).to({_off:false},0).wait(62).to({x:-18.55,y:342.6},0).wait(327).to({regY:9.2,scaleX:1.5,scaleY:1.5,x:26.05,y:475.1},0).wait(20));

	// clicked copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6760AA").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape.setTransform(-16.8,246.7);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6760AA").s().p("AglH8QgMgMAAgRQAAgQAMgNQAMgMARAAQAQAAALAMQANANAAAQQAAARgNAMQgLAMgQAAQgRAAgMgMgAgTnBQgMgMAAgRQAAgQAMgNQAMgMAQAAQARAAALAMQANANAAAQQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_1.setTransform(-17.7,294.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(103,96,170,0.996)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_2.setTransform(-18.6,342.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(103,96,170,0.992)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_3.setTransform(-18.6,342.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(103,96,170,0.988)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_4.setTransform(-18.6,342.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(103,96,170,0.98)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_5.setTransform(-18.6,342.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(103,96,170,0.969)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_6.setTransform(-18.6,342.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(103,96,170,0.953)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_7.setTransform(-18.6,342.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(103,96,170,0.933)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_8.setTransform(-18.6,342.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(103,96,170,0.91)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_9.setTransform(-18.6,342.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(103,96,170,0.878)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_10.setTransform(-18.6,342.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(103,96,170,0.843)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_11.setTransform(-18.6,342.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(103,96,170,0.796)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_12.setTransform(-18.6,342.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(103,96,170,0.737)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_13.setTransform(-18.6,342.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(103,96,170,0.671)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_14.setTransform(-18.6,342.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(103,96,170,0.592)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_15.setTransform(-18.6,342.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(103,96,170,0.502)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_16.setTransform(-18.6,342.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(103,96,170,0.408)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_17.setTransform(-18.6,342.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(103,96,170,0.329)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_18.setTransform(-18.6,342.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(103,96,170,0.263)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_19.setTransform(-18.6,342.5);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(103,96,170,0.204)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_20.setTransform(-18.6,342.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(103,96,170,0.157)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_21.setTransform(-18.6,342.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(103,96,170,0.122)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_22.setTransform(-18.6,342.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(103,96,170,0.09)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_23.setTransform(-18.6,342.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(103,96,170,0.067)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_24.setTransform(-18.6,342.5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(103,96,170,0.047)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_25.setTransform(-18.6,342.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(103,96,170,0.031)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_26.setTransform(-18.6,342.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(103,96,170,0.02)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_27.setTransform(-18.6,342.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(103,96,170,0.012)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_28.setTransform(-18.6,342.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(103,96,170,0.008)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_29.setTransform(-18.6,342.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(103,96,170,0.004)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_30.setTransform(-18.6,342.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(103,96,170,0)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_31.setTransform(-18.6,342.5);
	this.shape_31._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},55).to({state:[{t:this.shape_1}]},62).to({state:[{t:this.shape}]},76).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[]},19).wait(203));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(55).to({_off:false},0).to({_off:true},62).wait(76).to({_off:false,x:-18.6,y:342.5},0).wait(5).to({_off:true},1).wait(256));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(228).to({_off:false},0).wait(5).to({_off:true},19).wait(203));

	// clicked
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#6760AA").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_32.setTransform(-16.8,246.7);
	this.shape_32._off = true;

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#6760AA").s().p("AglH8QgMgMAAgRQAAgQAMgNQAMgMARAAQAQAAALAMQANANAAAQQAAARgNAMQgLAMgQAAQgRAAgMgMgAgTnBQgMgMAAgRQAAgQAMgNQAMgMAQAAQARAAALAMQANANAAAQQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_33.setTransform(-17.7,294.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(103,96,170,0.996)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_34.setTransform(-16.8,246.7);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(103,96,170,0.992)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_35.setTransform(-16.8,246.7);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(103,96,170,0.988)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_36.setTransform(-16.8,246.7);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(103,96,170,0.98)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_37.setTransform(-16.8,246.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(103,96,170,0.969)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_38.setTransform(-16.8,246.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(103,96,170,0.953)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_39.setTransform(-16.8,246.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(103,96,170,0.933)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_40.setTransform(-16.8,246.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(103,96,170,0.91)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_41.setTransform(-16.8,246.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(103,96,170,0.878)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_42.setTransform(-16.8,246.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(103,96,170,0.843)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_43.setTransform(-16.8,246.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(103,96,170,0.796)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_44.setTransform(-16.8,246.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(103,96,170,0.737)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_45.setTransform(-16.8,246.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(103,96,170,0.671)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_46.setTransform(-16.8,246.7);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(103,96,170,0.592)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_47.setTransform(-16.8,246.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(103,96,170,0.502)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_48.setTransform(-16.8,246.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(103,96,170,0.408)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_49.setTransform(-16.8,246.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(103,96,170,0.329)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_50.setTransform(-16.8,246.7);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(103,96,170,0.263)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_51.setTransform(-16.8,246.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(103,96,170,0.204)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_52.setTransform(-16.8,246.7);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(103,96,170,0.157)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_53.setTransform(-16.8,246.7);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(103,96,170,0.122)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_54.setTransform(-16.8,246.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(103,96,170,0.09)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_55.setTransform(-16.8,246.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(103,96,170,0.067)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_56.setTransform(-16.8,246.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(103,96,170,0.047)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_57.setTransform(-16.8,246.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(103,96,170,0.031)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_58.setTransform(-16.8,246.7);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(103,96,170,0.02)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_59.setTransform(-16.8,246.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(103,96,170,0.012)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_60.setTransform(-16.8,246.7);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(103,96,170,0.008)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_61.setTransform(-16.8,246.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(103,96,170,0.004)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_62.setTransform(-16.8,246.7);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("rgba(103,96,170,0)").s().p("AgcAdQgMgMAAgRQAAgPAMgNQAMgMAQAAQARAAALAMQANANAAAPQAAARgNAMQgLAMgRAAQgQAAgMgMg");
	this.shape_63.setTransform(-16.8,246.7);
	this.shape_63._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_32}]},55).to({state:[{t:this.shape_33}]},62).to({state:[{t:this.shape_32}]},76).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[]},19).wait(203));
	this.timeline.addTween(cjs.Tween.get(this.shape_32).wait(55).to({_off:false},0).to({_off:true},62).wait(76).to({_off:false},0).wait(5).to({_off:true},1).wait(256));
	this.timeline.addTween(cjs.Tween.get(this.shape_63).wait(228).to({_off:false},0).wait(5).to({_off:true},19).wait(203));

	// share
	this.instance_1 = new lib.share();
	this.instance_1.setTransform(-105.6,478.65,1,1,0,0,0,44,14.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(387).to({_off:false},0).to({x:26.1},40,cjs.Ease.quartOut).wait(28));

	// IV
	this.instance_2 = new lib.IV();
	this.instance_2.setTransform(26.15,478.8,1,1,0,0,0,44,14.4);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(193).to({_off:false},0).to({alpha:1},40,cjs.Ease.quartInOut).to({_off:true},194).wait(28));

	// result
	this.result_page = new lib.result("synched",0);
	this.result_page.name = "result_page";
	this.result_page.setTransform(110.8,86.05,1.029,1.029,0,0,0,105.7,89.4);
	this.result_page.alpha = 0;
	this.result_page._off = true;

	this.timeline.addTween(cjs.Tween.get(this.result_page).wait(193).to({_off:false},0).to({alpha:1},40,cjs.Ease.quartInOut).wait(222));

	// result BG
	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("rgba(255,255,255,0)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_64.setTransform(29.275,326.375);
	this.shape_64._off = true;

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("rgba(255,255,255,0.004)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_65.setTransform(29.275,326.375);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("rgba(255,255,255,0.008)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_66.setTransform(29.275,326.375);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("rgba(255,255,255,0.012)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_67.setTransform(29.275,326.375);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("rgba(255,255,255,0.02)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_68.setTransform(29.275,326.375);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("rgba(255,255,255,0.031)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_69.setTransform(29.275,326.375);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("rgba(255,255,255,0.047)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_70.setTransform(29.275,326.375);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("rgba(255,255,255,0.067)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_71.setTransform(29.275,326.375);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("rgba(255,255,255,0.09)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_72.setTransform(29.275,326.375);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("rgba(255,255,255,0.122)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_73.setTransform(29.275,326.375);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("rgba(255,255,255,0.157)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_74.setTransform(29.275,326.375);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("rgba(255,255,255,0.204)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_75.setTransform(29.275,326.375);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("rgba(255,255,255,0.263)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_76.setTransform(29.275,326.375);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("rgba(255,255,255,0.329)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_77.setTransform(29.275,326.375);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.408)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_78.setTransform(29.275,326.375);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("rgba(255,255,255,0.502)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_79.setTransform(29.275,326.375);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("rgba(255,255,255,0.592)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_80.setTransform(29.275,326.375);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("rgba(255,255,255,0.671)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_81.setTransform(29.275,326.375);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("rgba(255,255,255,0.737)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_82.setTransform(29.275,326.375);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("rgba(255,255,255,0.796)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_83.setTransform(29.275,326.375);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("rgba(255,255,255,0.843)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_84.setTransform(29.275,326.375);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("rgba(255,255,255,0.878)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_85.setTransform(29.275,326.375);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("rgba(255,255,255,0.91)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_86.setTransform(29.275,326.375);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("rgba(255,255,255,0.933)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_87.setTransform(29.275,326.375);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("rgba(255,255,255,0.953)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_88.setTransform(29.275,326.375);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("rgba(255,255,255,0.969)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_89.setTransform(29.275,326.375);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("rgba(255,255,255,0.98)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_90.setTransform(29.275,326.375);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("rgba(255,255,255,0.988)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_91.setTransform(29.275,326.375);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("rgba(255,255,255,0.992)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_92.setTransform(29.275,326.375);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("rgba(255,255,255,0.996)").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_93.setTransform(29.275,326.375);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("Atqe+MAAAg97IbVAAMAAAA97g");
	this.shape_94.setTransform(29.275,326.375);
	this.shape_94._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_64}]},193).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_94}]},1).wait(222));
	this.timeline.addTween(cjs.Tween.get(this.shape_64).wait(193).to({_off:false},0).wait(5).to({_off:true},1).wait(256));
	this.timeline.addTween(cjs.Tween.get(this.shape_94).wait(228).to({_off:false},0).wait(227));

	// survey copy
	this.instance_3 = new lib.survey();
	this.instance_3.setTransform(-52.2,128.3,0.5992,0.5992);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({_off:true},233).wait(222));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-149.6,75.6,369.6,461.4);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-2.15,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ApXCwIAAleISvAAIAAFeg");
	this.shape.setTransform(-38.825,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-98.8,-17.7,120,35.099999999999994), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo intro
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(0.1,0,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.5,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(143.2,4.05,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt_CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(101.65,570.95,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(143.05,570.5,0.8205,0.8205,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// screen
	this.screen = new lib.screen_1("synched",0);
	this.screen.name = "screen";
	this.screen.setTransform(9.5,278.55,0.439,0.439,0,0,0,247.1,146.5);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// UI graphics
	this.ui = new lib.uigraphics();
	this.ui.name = "ui";
	this.ui.setTransform(74,302.85,1,1,0,0,0,21.9,224);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// bg_img
	this.bg = new lib.bg("synched",0);
	this.bg.name = "bg";
	this.bg.setTransform(79.95,300,1,1,0,0,0,80,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	// still logo
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(15.8,15.85,0.747,0.7471,0,0,0,-0.1,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-98.9,0,365.6,601.9), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_160x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		mc.visible = false;
		mc.replay_btn.alpha=0;
		//mc.ui.shadow = new createjs.Shadow("#000000", 0, 5, 6);
		mc.screen.cache(-248,-146,990,584,2);
		
		
		this.runBanner = function() {
			
				mc.visible = true;
				mc.replay_btn.alpha=1;
			
				this.tlMain = gsap.timeline({default:{duration:0.4, ease:"power4.inOut"}});
				this.tlMain.pause();
				mc.logo_intro.play();
			
		//1st frame
				this.tlMain.from(mc.ui,{duration:0.6, y:"+=200", alpha:0, onStart:function(){mc.ui.gotoAndPlay();}});
				this.tlMain.from([exportRoot.headline1a,exportRoot.headline1b],{y:"+=10", alpha:0, stagger:0.2}, "<");
				this.tlMain.to([exportRoot.headline1a,exportRoot.headline1b],{y:"-=10", alpha:0},"+=1");
		//2nd frame	
				
				this.tlMain.from([exportRoot.headline2a,exportRoot.headline2b, exportRoot.headline2c],{y:"+=10", alpha:0, stagger:0.15});
				this.tlMain.to([exportRoot.headline2a,exportRoot.headline2b,exportRoot.headline2c],{y:"-=10", alpha:0},"+=2");
		//3rd frame
				this.tlMain.from([exportRoot.headline3a,exportRoot.headline3b, exportRoot.headline3c],{y:"+=10", alpha:0, stagger:0.15});
				this.tlMain.to([exportRoot.headline3a,exportRoot.headline3b,exportRoot.headline3c],{y:"-=10", alpha:0},"+=2");
		//4th frame
				this.tlMain.from([exportRoot.headline4a,exportRoot.headline4b, exportRoot.headline4c],{
					y:"+=10", 
					alpha:0, 
					stagger:0.15,
					onComplete: function (){exportRoot.tlMain.pause();}
				});
				this.tlMain.to([exportRoot.headline4a,exportRoot.headline4b,exportRoot.headline4c],{y:"-=10", alpha:0});
				
				//last frame
				this.tlMain.to([mc.ui,mc.bg],{alpha:0},"<");
				this.tlMain.from(mc.screen, {duration:1, x:"+=80", y:"+=145", alpha:0});
				this.tlMain.from(exportRoot.headline5,{x:"-=150", alpha:0, stagger:0.15},"<0.45");
				this.tlMain.from(exportRoot.headline6,{x:"-=150", alpha:0, stagger:0.15},"<0.7");
				
				this.tlMain.from([mc.cta,mc.txtCta], { alpha:0, duration: 0.6, x: "+=150"}, "-=0.45");
				this.tlMain.from(mc.replay_btn, { alpha: 0, onStart:function(){exportRoot.isReplay = true;}});
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,0.9996,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-18.9,300,285.7,301.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_160x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1.png?1628512818802", id:"M365_FY21Q3ConsOpt_USA_160x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;