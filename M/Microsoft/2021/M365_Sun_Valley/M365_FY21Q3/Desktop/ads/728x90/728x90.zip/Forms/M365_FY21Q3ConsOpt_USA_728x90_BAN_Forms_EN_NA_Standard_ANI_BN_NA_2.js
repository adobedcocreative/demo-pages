(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1", frames: [[0,538,157,235],[159,538,96,235],[835,0,494,696],[0,0,833,536]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BG22x = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.BG2x = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.FormsUI300x6002x = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.screen = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(491.0046,408.3802);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,982,816.8);


(lib.survey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.FormsUI300x6002x();
	this.instance.setTransform(-9,-14.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-14,247,348);


(lib.screen_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.screen();
	this.instance.setTransform(-0.55,-13.55,0.595,0.595);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-13.5,495.6,318.9);


(lib.resultcomponent = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9E9E9").s().p("Ah7g9ID3AAIh8B7g");
	this.shape.setTransform(43.6452,242.2825,0.1665,0.1665);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3F7579").s().p("AmHD3IAAntIMPAAIAAHtgAlfDPIK/AAIAAllIlgCwIAAAAIlfixgAlfjEIFfCyIFgixIAAgLIq/AAg");
	this.shape_1.setTransform(135.3001,257.6586,0.1665,0.1665);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#E9E9E9").s().p("AnhHiQjHjIAAkaQAAkZDHjIQDIjIEZAAQEaAADIDIQDHDIAAEZQAAEajHDIQjIDIkaAAQkZAAjIjIg");
	this.shape_2.setTransform(135.3001,257.6628,0.1665,0.1665);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F7579").s().p("AheACICpipIAVAWIiUCTICPCQIgVAWg");
	this.shape_3.setTransform(100.113,257.6583,0.1664,0.1664);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F7579").s().p("AheCSICTiTIiQiQIAWgWICkCmIioCpg");
	this.shape_4.setTransform(109.2824,257.6583,0.1664,0.1664);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F7579").s().p("AhxEnIDBpYIAiALIjCJXg");
	this.shape_5.setTransform(104.7018,257.6583,0.1664,0.1664);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#E9E9E9").s().p("AnhHiQjHjIAAkaQAAkZDHjIQDIjIEZAAQEbAADHDIQDHDIAAEZQAAEajHDIQjHDIkbAAQkZAAjIjIg");
	this.shape_6.setTransform(104.7176,257.6628,0.1665,0.1665);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F7579").s().p("AgOBQIAAifIAdAAIAACfg");
	this.shape_7.setTransform(77.1565,261.0655,0.1664,0.1664);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F7579").s().p("AgOBsIAAjWIAdAAIAADWg");
	this.shape_8.setTransform(79.4945,261.519,0.1664,0.1664);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F7579").s().p("AgOBsIAAjWIAdAAIAADWg");
	this.shape_9.setTransform(74.9515,261.519,0.1664,0.1664);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F7579").s().p("AiLAPIAAgdIEXAAIAAAdg");
	this.shape_10.setTransform(77.1565,258.3822,0.1664,0.1664);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F7579").s().p("AibCcIAAk3IE3AAIAAE3gAh8B+ID5AAIAAj6Ij5AAg");
	this.shape_11.setTransform(77.1565,254.5963,0.1664,0.1664);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F7579").s().p("AiaCcIAAk3IE1AAIAAE3gAh9B9ID6AAIAAj5Ij6AAg");
	this.shape_12.setTransform(71.099,260.7203,0.1664,0.1664);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3F7579").s().p("AiaCcIAAk3IE1AAIAAE3gAh9B+ID6AAIAAj6Ij6AAg");
	this.shape_13.setTransform(71.099,254.5963,0.1664,0.1664);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#E9E9E9").s().p("AnhHiQjIjIABkaQgBkZDIjIQDIjIEZAAQEbAADHDIQDHDIABEZQgBEajHDIQjHDIkbAAQkZAAjIjIg");
	this.shape_14.setTransform(74.1393,257.6628,0.1665,0.1665);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhmCyQg2AAgtgeQgsgdgUgxQgPghAAglQAAgkAPghQAUgxAsgdQAtgeA2AAIAdAAQAEANAAAMQAAAMgEANIgdAAQghAAgcAQQgcAPgSAbQgVAgAAAlQAAAlAVAhQASAaAcAQQAcAQAhAAIDNAAQA1AAAlgmQAmglAAg1QAAg0gmgmQglglg1AAIgiAAIABgZQAAgNgBgMIAiAAQBKAAA0A0QA0A0AABJQAABKg0A0Qg0A0hKAAg");
	this.shape_15.setTransform(45.7919,258.9313,0.1664,0.1664);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("ABKCyQgEgNAAgMQAAgMAEgNIAdAAQAhAAAcgQQAcgQASgaQAVghAAglQAAglgVggQgSgbgcgPQgcgQghAAIjNAAQg1AAglAmQgmAlAAA0QAAA1AmAlQAlAmA1AAIAiAAQgBAMAAANIABAZIgiAAQhKAAg0g0Qg0g0AAhKQAAhJA0g0QA0g0BKAAIDNAAQA2AAAtAeQAsAdAUAxQAPAhAAAkQAAAlgPAhQgUAxgsAdQgtAeg2AAg");
	this.shape_16.setTransform(41.4818,256.3852,0.1664,0.1664);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3F7579").s().p("AnhHiQjIjIAAkaQAAkZDIjIQDHjIEaAAQEaAADIDIQDIDIgBEZQABEajIDIQjIDIkaAAQkaAAjHjIg");
	this.shape_17.setTransform(43.6441,257.6628,0.1665,0.1665);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgLAOQgEgFAAgJQAAgHAFgGQAFgFAGAAQAHAAAEAEQAEAGAAAIIAAABIgZAAQAAAHADACQADAEAFAAQAGAAAFgEIAAAGQgFADgIAAQgGAAgFgFgAgFgKQgDADgBAFIATAAQAAgGgDgCQgCgDgEAAQgDAAgDADg");
	this.shape_18.setTransform(148.525,208.75);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgIASIAAgjIAFAAIAAAIIABAAQABgEABgCQADgCADAAIADAAIAAAGQAAAAgBAAQAAgBAAAAQgBAAgBAAQAAAAgBAAQgEAAgBADQgDAEAAAFIAAASg");
	this.shape_19.setTransform(145.675,208.725);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgKAQQgDgDAAgEQAAgKAMgBIAKgCQAAgJgIAAQgFAAgGAFIAAgHQAGgDAGAAQAMAAAAANIAAAXIgFAAIAAgGIgBAAQgDAHgHAAQgFAAgDgDgAAAABQgDABgCABQgCACAAADQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACADAAQADAAADgDQADgDAAgFIAAgDg");
	this.shape_20.setTransform(142.225,208.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAJAbIAAgVQAAgKgJAAQgDAAgDADQgCACAAAFIAAAVIgGAAIAAg1IAGAAIAAAYIAAAAQAEgHAGAAQANAAAAAOIAAAWg");
	this.shape_21.setTransform(138.55,207.875);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgFAaIgDgBIgEgBIgCgBIAAgHIACACIAEACIAEAAIADABQAFAAACgCQADgCAAgEIgBgEIgCgCIgEgDIgEgCIgFgCIgEgDIgCgEIgBgFQAAgDABgDIAEgEIAGgCIAFgBQAIAAADACIAAAGQgEgDgHAAIgDABIgEABIgCACIgBAEIABADIACADIADACIAEACIAFACIAEAEIADAEIABAFQAAADgBADIgEAEIgGACIgGABIgDAAg");
	this.shape_22.setTransform(134.575,208.025);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3F7579").s().p("AmhCEIAAkHINDAAIAAEHg");
	this.shape_23.setTransform(141.7228,208.896,0.6964,0.6964);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAEANQgCgCAAgEQAAgDACgCQACgCADAAQADAAACACQABABAAAEQAAADgCADQgBACgDAAQgBAAgBAAQgBAAAAAAQgBgBAAAAQgBgBAAAAgAAGAEIgBADIABAFIADABQAAAAABgBQAAAAABAAQAAAAAAAAQABgBAAAAIABgEIgBgDQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAABAAAAQgBAAAAABgAgKAPIASgdIADAAIgSAdgAgNgBQgBgCAAgDQAAgEABgCQACgCAEAAQADAAABACQACACAAADQAAADgCADQgCABgDAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAgBgBgAgLgLIgBAFIABADIAEABQAAAAAAAAQABAAAAAAQABAAAAAAQAAgBAAAAIABgDIgBgFQAAAAAAAAQAAAAgBgBQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBAAg");
	this.shape_24.setTransform(134.65,111.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgNAXIAAgHQAFAEAGABIAEgBIAEgCIACgDIABgEQAAgKgNAAIgEAAIAAgDIAEAAQALAAAAgJQAAgJgIAAQgGAAgEADIAAgFQAFgDAGAAIAFACIAEACIADADIABAFQAAAKgKACIAAABIAFAAIADADIADADIAAAEIgBAGIgDAGIgGADIgGAAQgHAAgEgCg");
	this.shape_25.setTransform(130.975,110.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgNAXIAAgGQAFADAGAAIADgBIAEgCIACgEIABgDQAAgFgDgDQgDgCgGAAIgCAAIgCAAIgCAAIgCAAIACgYIAVAAIAAAFIgRAAIgBAOIADAAIACAAIAGABQADABADACIACAEQACADAAADQAAAEgCADQAAADgDABIgGADQgDACgCAAQgIAAgDgCg");
	this.shape_26.setTransform(127.3,110.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAEANQgCgCAAgDQAAgEACgCQACgCADAAQADAAACABQACACgBAEQAAAEgBACQgCACgEAAQAAAAgBAAQgBAAAAgBQgBAAAAAAQgBgBAAAAgAAGAEIgBAEIABADIADACQABAAAAgBQAAAAABAAQAAAAAAAAQABgBAAAAIABgDIgBgEQAAgBgBAAQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAABgAgKAPIASgdIADAAIgSAdgAgMgBQgCgCAAgEQAAgDACgCQABgCADAAQAEAAABACQACACAAADQAAADgCADQgCABgDAAQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAgBAAAAgAgLgKIgBADIABAFIADABQABAAAAgBQABAAAAAAQABAAAAAAQAAgBABAAIABgEIgBgDQgBgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBABg");
	this.shape_27.setTransform(159.2,110.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgHAZIACgJIACgJIADgIIAEgIIADgGIACgDIgXAAIAAgGIAdAAIAAAEIgCAEIgEAHIgDAIIgDAIIgDAJIgBAJg");
	this.shape_28.setTransform(155.6,109.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAGAZIAAgMIgXAAIAAgFIAHgIIAHgHIAEgJIAEgIIAGAAIAAAgIAGAAIAAAFIgGAAIAAAMgAAAgIIgCAHIgFAEIgDAFIAQAAIAAgYIgGAIg");
	this.shape_29.setTransform(151.7,109.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#5E5584").s().p("AABEvQiihJgpjNQgCgZAAgbQAShwBDhOQBvh+DVAKIgyFKIAAFRIgSABQhBAAhHggg");
	this.shape_30.setTransform(131.9177,110.4026,0.6963,0.6963);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#3F7579").s().p("AivgEIAylKQDTAsBBCeQAhBOgKBFQgGC7isBWQhWAqhVAFg");
	this.shape_31.setTransform(157.0672,110.4793,0.6963,0.6963);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#5E5584").s().p("AgPAUQgHgHAAgMQAAgMAHgIQAHgIAKABQAJgBAHAHQAFAHAAALIAAAEIglAAQABAJAFAFQAEAEAHAAQAJABAIgHIAAAIQgIAGgLAAQgKAAgGgIgAgIgPQgEAEgBAHIAbAAQABgIgEgDQgDgEgHgBQgFAAgEAFg");
	this.shape_32.setTransform(61.4,144.65);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#5E5584").s().p("AgDAbIgVg0IAKAAIANAlIABAIIACgIIAOglIAJAAIgVA0g");
	this.shape_33.setTransform(56.125,144.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#5E5584").s().p("AgDAnIAAg0IAHAAIAAA0gAgDgcQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABgBQAAAAABAAQAAAAABgBQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAAAQAAABABAAQAAABABAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAABAAAAQAAABAAAAQgBAAAAABIgEABQAAAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAg");
	this.shape_34.setTransform(52.35,143.425);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#5E5584").s().p("AgFATIAAgeIgKAAIAAgHIAKAAIAAgNIAHgDIAAAQIAOAAIAAAHIgOAAIAAAdQAAAFACACQACADAEAAQAEAAACgCIAAAHQgEACgEAAQgNAAAAgQg");
	this.shape_35.setTransform(49.2,143.925);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#5E5584").s().p("AgMAUQgHgHAAgLQAAgNAIgHQAHgIAMAAQAHAAAFACIAAAJQgGgEgHgBQgHABgFAFQgFAGAAAJQAAAJAFAFQAFAFAHAAQAHAAAGgEIAAAIQgGADgJABQgKAAgHgIg");
	this.shape_36.setTransform(45.025,144.65);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#5E5584").s().p("AAXAlIgIgVIgeAAIgHAVIgKAAIAdhJIAHAAIAdBJgAgBgWIgLAeIAZAAIgMgeIgBgFIgBAFg");
	this.shape_37.setTransform(39.15,143.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#131313").s().p("AgLAQIAAgGQAFAEAFgBQAHAAAAgEIgBgCIgBgDIgDgBIgCgBIgEgCIgDgBIgCgDIgBgDQAAgBAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIADgDIAEgCIAEAAQAEgBAEACIAAAGQgEgDgFAAIgCAAIgCABIgBACIgBACIABACIABACIACABIADACIAEABIADACIACACIABAEQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBAAIgDAEIgEACIgEABQgGgBgEgCg");
	this.shape_38.setTransform(57.275,155.1);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#131313").s().p("AgOADIAAgUIAGAAIAAATQAAALAIAAQADAAADgDQADgDAAgFIAAgTIAFAAIAAAiIgFAAIAAgFQgDAGgHAAQgNAAAAgPg");
	this.shape_39.setTransform(53.75,155.15);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#131313").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_40.setTransform(50.625,154.625);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#131313").s().p("AgKAQQgDgDAAgFQAAgIAMgDIAJgBQAAgJgHAAQgFAAgFAFIAAgGQAEgEAHABQAMgBAAANIAAAXIgGAAIAAgGQgEAGgFABQgGAAgDgDgAAAABQgDAAgCACQgCABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABAAAAQACABAEAAQADAAACgDQADgCAAgFIAAgDg");
	this.shape_41.setTransform(47.55,155.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#131313").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_42.setTransform(44.675,154.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#131313").s().p("AgFAZIgDAAIgDgBIgDgBIAAgHIADABIADACIAEABIAEAAQAEAAADgCQACgCAAgEIgBgDIgCgCIgEgDIgDgDIgGgBIgDgDIgDgEIgBgEQAAgEACgCIAEgEIAFgDIAFgBQAIABADABIAAAGQgEgCgIAAIgCAAIgEACIgCABIgBAEIABADIACADIAEACIADADIAFABIAEADIADAEIABAFQAAADgBADIgFAFIgFACIgFABIgEgBg");
	this.shape_43.setTransform(41.9,154.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#5E5584").s().p("AgUAiIAAgJQAIAFAIAAIAGgBIAFgDQADgCABgDQABgDAAgEQAAgHgFgEQgFgDgIAAIgDAAIgDAAIgDAAIgDAAIACglIAhAAIAAAIIgaAAIgBAWIADgBIAEAAQAFAAAEACQAFABADADIAFAGQACAEAAAGQAAAFgCAEQgCAFgDADQgEADgFACQgEACgFAAQgLAAgFgEg");
	this.shape_44.setTransform(66.475,99.475);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#5E5584").s().p("AgJAkQgFgDgDgFQgDgEgCgHQgBgGAAgKQAAgJABgHQACgHAEgFQACgFAFgDQAFgCAFAAQAXAAAAAlQAAAJgCAHQgBAIgDAEQgDAFgFADQgFADgFgBQgFABgEgDgAgPABQAAAeAPAAQAQAAAAgfQAAgegQAAQgOAAgBAfg");
	this.shape_45.setTransform(60.7,99.4);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#5E5584").s().p("AgDAaIgCgEQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQAAAAABAAQAAAAABABQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAgAgDgRQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAQAAABABAAQAAAAABABQAAAAAAABQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_46.setTransform(56.725,100.45);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#5E5584").s().p("AAEAmIAAg/IgDACIgDACIgFADIgFACIAAgJIAGgCIAGgDIAFgDIAEgEIAEAAIAABLg");
	this.shape_47.setTransform(52.275,99.325);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#5E5584").s().p("AgKAkQgEgDgDgFQgDgEgBgHQgCgGAAgKQAAgJACgHQABgHADgFQADgFAFgDQAFgCAFAAQAXAAAAAlQAAAJgBAHQgCAIgEAEQgDAFgEADQgFADgFgBQgFABgFgDgAgPABQABAeAOAAQAQAAAAgfQgBgegPAAQgPAAAAAfg");
	this.shape_48.setTransform(46.95,99.4);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#5E5584").s().p("AgDAaIgCgEQAAgBAAAAQAAgBABAAQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAABABQABAAAAAAQAAAAABABQAAAAABABQAAAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQAAAAgBAAQgBAAAAAAQgBABAAAAQAAAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAgAgDgRQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEQAAAAABgBQAAAAABAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQABAAAAAAQAAABABAAQAAAAABABQAAAAAAABQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAABQAAAAgBAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_49.setTransform(42.975,100.45);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#5E5584").s().p("AgKAkQgEgDgDgFQgDgEgBgHQgCgGAAgKQAAgJACgHQABgHADgFQAEgFAEgDQAFgCAFAAQAXAAAAAlQAAAJgBAHQgCAIgEAEQgDAFgEADQgFADgFgBQgFABgFgDgAgOABQAAAeAOAAQAPAAAAgfQAAgegPAAQgOAAAAAfg");
	this.shape_50.setTransform(38.95,99.4);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#5E5584").s().p("AgJAkQgFgDgDgFQgDgEgCgHQgBgGAAgKQAAgJABgHQACgHADgFQADgFAFgDQAFgCAFAAQAXAAAAAlQAAAJgCAHQgBAIgDAEQgDAFgFADQgFADgFgBQgFABgEgDgAgPABQAAAeAPAAQAQAAAAgfQAAgegQAAQgOAAgBAfg");
	this.shape_51.setTransform(33.25,99.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#131313").s().p("AgKAOQgEgFAAgJQAAgHAEgGQAFgEAGgBQAHAAADAFQAEAFAAAHIAAADIgYAAQABAFADAEQADADAEAAQAGAAAFgEIAAAFQgFAEgHAAQgHgBgEgEgAgFgKQgDADgBAEIASAAQAAgEgCgDQgCgCgEgBQgDABgDACg");
	this.shape_52.setTransform(66.875,121.05);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#131313").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_53.setTransform(63.875,120.575);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#131313").s().p("AgKAOQgEgFAAgJQAAgHAEgGQAFgEAGgBQAHAAADAFQAEAFAAAHIAAADIgYAAQABAFADAEQADADAEAAQAGAAAFgEIAAAFQgFAEgHAAQgHgBgEgEgAgFgKQgDADgBAEIASAAQAAgEgCgDQgCgCgEgBQgDABgDACg");
	this.shape_54.setTransform(60.925,121.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#131313").s().p("AgCAaIAAgzIAFAAIAAAzg");
	this.shape_55.setTransform(58.2,120.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#131313").s().p("AgPAaIAAgyIAGAAIAAAGQAEgHAHAAQAHAAADAFQAEAEAAAJQAAAHgEAFQgEAGgIAAQgGAAgDgGIAAAVgAgGgRQgDAEAAAFIAAAEQAAAEACADQADADAEAAQAFAAADgEQADgDAAgGQAAgGgDgEQgDgDgFAAQgDAAgDADg");
	this.shape_56.setTransform(55.375,121.8);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#131313").s().p("AATASIAAgTQAAgGgCgCQgBgDgEAAQgEAAgCADQgDAEAAAEIAAATIgEAAIAAgUQAAgKgJAAQgDAAgDADQgCADAAAFIAAATIgGAAIAAgiIAGAAIAAAGQADgHAIAAQADAAADACQACACABAEQADgIAJAAQALAAAAAPIAAAUg");
	this.shape_57.setTransform(50.2,121);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#131313").s().p("AgMAOQgEgFAAgIQAAgJAEgFQAFgEAHgBQAIABAFAEQAEAFAAAIQAAAIgFAGQgEAEgIABQgHgBgFgEgAgIgJQgDAEAAAFQAAAGAEAEQADADAEABQAGgBACgDQADgEAAgGQAAgFgDgEQgCgDgGgBQgEABgEADg");
	this.shape_58.setTransform(45.125,121.05);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#131313").s().p("AgIAOQgEgFAAgIQAAgIAFgFQAEgGAIAAQAEAAAEACIAAAGQgEgCgEgBQgFABgDADQgDAEgBAGQABAGADADQADADAFABQAEAAAEgDIAAAFQgEADgGAAQgGgBgFgEg");
	this.shape_59.setTransform(41.45,121.05);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#131313").s().p("AgMAOQgEgFAAgIQAAgJAEgFQAFgEAHgBQAIABAFAEQAEAFAAAIQAAAIgFAGQgEAEgIABQgHgBgFgEgAgIgJQgDAEAAAFQAAAGAEAEQADADAEABQAGgBACgDQADgEAAgGQAAgFgDgEQgCgDgGgBQgEABgEADg");
	this.shape_60.setTransform(35.875,121.05);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#131313").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_61.setTransform(32.675,120.575);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#131313").s().p("AgKAOQgEgGAAgIQAAgHAEgFQAFgGAGABQAHAAADAEQAEAEAAAJIAAABIgYAAQABAGADADQADADAEABQAGgBAFgEIAAAGQgFADgHAAQgHAAgEgEgAgFgKQgDADgBAFIASAAQAAgFgCgDQgCgCgEAAQgDAAgDACg");
	this.shape_62.setTransform(68.775,110.75);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#131313").s().p("AAUASIAAgTQAAgGgDgDQgBgCgEAAQgEAAgDADQgCADAAAFIAAATIgFAAIAAgUQABgKgJAAQgEAAgCADQgCADAAAFIAAATIgGAAIAAgiIAGAAIAAAFQAEgGAHAAQADAAADACQACACABADQADgHAIAAQAMAAAAAOIAAAVg");
	this.shape_63.setTransform(63.9,110.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#131313").s().p("AgCAaIAAgiIAFAAIAAAigAgCgSIgBgDIABgDIACgBIACABQABABAAAAQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAQAAABgBAAIgCABIgCgBg");
	this.shape_64.setTransform(60.025,109.925);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#131313").s().p("AgDANIAAgUIgGAAIAAgFIAGAAIAAgIIAEgCIAAAKIAJAAIAAAFIgJAAIAAATQAAADACACQAAAAAAAAQABABAAAAQABAAAAAAQABAAABAAIADgBIAAAFQgCABgDAAQgIAAAAgKg");
	this.shape_65.setTransform(57.925,110.275);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#131313").s().p("AgKAOQgEgGAAgIQAAgHAEgFQAFgGAGABQAHAAADAEQAEAEAAAJIAAABIgYAAQABAGADADQADADAEABQAGgBAFgEIAAAGQgFADgHAAQgHAAgEgEgAgFgKQgDADgBAFIASAAQAAgFgCgDQgCgCgEAAQgDAAgDACg");
	this.shape_66.setTransform(53.025,110.75);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#131313").s().p("AgNAYIAAgGQAGADAGAAQAMAAgBgNIAAgEQgEAHgGAAQgHAAgEgFQgEgFAAgHQAAgJAEgFQAEgFAHAAQAHAAADAFIAAgEIAGAAIAAAfQAAATgRAAQgHAAgFgCgAgHgRQgCAEAAAHQAAAGACACQADAEAEAAQAFAAADgEQACgCAAgFIAAgFQABgFgDgCQgDgDgFAAQgDAAgEADg");
	this.shape_67.setTransform(49,111.525);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#131313").s().p("AgKAQQgDgDAAgFQAAgIAMgCIAJgCQAAgJgHABQgGAAgFADIAAgFQAFgDAGAAQANgBAAANIAAAXIgGAAIAAgGQgEAGgFAAQgGAAgDgCgAAAABQgDABgCABQgCABAAAEQAAABAAAAQAAABAAAAQABABAAAAQAAABAAAAQADACADAAQADgBADgDQACgDAAgEIAAgDg");
	this.shape_68.setTransform(45.15,110.75);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#131313").s().p("AgIASIAAgiIAGAAIAAAHQABgDABgCQADgDADAAIADABIAAAFIgEgBQgEABgBADQgCADAAAFIAAASg");
	this.shape_69.setTransform(42.525,110.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#131313").s().p("AgKAOQgEgGAAgIQAAgHAEgFQAFgGAGABQAHAAADAEQAEAEAAAJIAAABIgYAAQABAGADADQADADAEABQAGgBAFgEIAAAGQgFADgHAAQgHAAgEgEgAgFgKQgDADgBAFIASAAQAAgFgCgDQgCgCgEAAQgDAAgDACg");
	this.shape_70.setTransform(39.225,110.75);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#131313").s().p("AgCASIgOgjIAGAAIAJAZIABAFIABgFIAJgZIAGAAIgOAjg");
	this.shape_71.setTransform(35.7,110.75);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#131313").s().p("AAPAZIgFgPIgUAAIgFAPIgGAAIATgwIAFAAIATAwgAAAgOIgIAUIAQAAIgHgUIgBgEIAAAEg");
	this.shape_72.setTransform(31.875,110.05);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#5E5584").s().p("AgUAiIAAgJQAHAGAKAAIAGgBIAFgDIAEgEIABgGQAAgPgUAAIgGAAIAAgGIAGAAQARAAAAgOQAAgMgNAAQgIAAgHAFIAAgIQAIgEAJAAQAEgBAEACIAGADIAEAGQACAEAAAEQAAAOgPAEIAAABIAHAAIAGAEIADAFIABAHQAAAFgBAEQgCAFgEACQgDADgFABQgFACgFAAQgKAAgGgEg");
	this.shape_73.setTransform(52.425,58.65);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#5E5584").s().p("AgUAiIAAgJQAIAFAIAAIAGgBIAFgDQADgCABgDQABgDAAgEQAAgHgFgEQgFgDgIAAIgDAAIgDAAIgDAAIgDAAIACglIAhAAIAAAIIgaAAIgBAWIADgBIAEAAQAFAAAEACQAFABADADIAFAGQACAEAAAGQAAAFgCAEQgCAFgDADQgEADgFACQgEACgFAAQgLAAgFgEg");
	this.shape_74.setTransform(46.875,58.725);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#131313").s().p("AgLAQIAAgGQAFADAFABQAHAAAAgGIgBgCIgBgBIgDgCIgCgBIgEgCIgDgBIgCgDIgBgEQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIADgDIAEgCIAEgBQAEAAAEACIAAAGQgEgDgFABIgCAAIgCAAIgBACIgBACIABADIABABIACACIADAAIAEACIADACIACADIABADQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBABIgDADIgEABIgEABQgGAAgEgCg");
	this.shape_75.setTransform(65.325,70.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#131313").s().p("AgKAOQgEgFAAgJQAAgHAEgFQAFgFAGgBQAHAAADAFQAEAFAAAHIAAADIgYAAQABAFADAEQADADAEAAQAGAAAFgFIAAAGQgFADgHAAQgHAAgEgEgAgFgKQgDADgBAFIASAAQAAgFgCgDQgCgDgEABQgDgBgDADg");
	this.shape_76.setTransform(62.025,70.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#131313").s().p("AgLAQIAAgGQAFADAFABQAHAAAAgGIgBgCIgBgBIgDgCIgCgBIgEgCIgDgBIgCgDIgBgEQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIADgDIAEgCIAEgBQAEAAAEACIAAAGQgEgDgFABIgCAAIgCAAIgBACIgBACIABADIABABIACACIADAAIAEACIADACIACADIABADQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBABIgDADIgEABIgEABQgGAAgEgCg");
	this.shape_77.setTransform(58.675,70.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#131313").s().p("AAJASIAAgTQAAgLgIAAQgDAAgDADQgDADAAAFIAAATIgGAAIAAgiIAGAAIAAAGQAEgHAHAAQAGAAADAEQADAEAAAGIAAAVg");
	this.shape_78.setTransform(55.175,70.05);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#131313").s().p("AgMAOQgEgFAAgJQAAgHAEgFQAFgFAHgBQAIABAFAFQAEAEAAAIQAAAIgFAGQgEAEgIAAQgHAAgFgEgAgIgJQgDADAAAGQAAAGAEAEQADADAEABQAGgBACgDQADgEAAgGQAAgGgDgDQgCgDgGAAQgEAAgEADg");
	this.shape_79.setTransform(51.125,70.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#131313").s().p("AgPAaIAAgyIAGAAIAAAGQAEgHAHAAQAHAAADAFQAEAEAAAJQAAAHgEAFQgEAGgIAAQgGAAgDgGIAAAVgAgGgRQgDADAAAGIAAAEQAAAEACADQADADAEAAQAFAAADgEQADgDAAgGQAAgHgDgDQgDgDgFAAQgDAAgDADg");
	this.shape_80.setTransform(47.125,70.85);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#131313").s().p("AgLAQIAAgGQAFADAFABQAHAAAAgGIgBgCIgBgBIgDgCIgCgBIgEgCIgDgBIgCgDIgBgEQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIADgDIAEgCIAEgBQAEAAAEACIAAAGQgEgDgFABIgCAAIgCAAIgBACIgBACIABADIABABIACACIADAAIAEACIADACIACADIABADQAAABAAAAQAAABgBAAQAAABAAAAQAAABgBABIgDADIgEABIgEABQgGAAgEgCg");
	this.shape_81.setTransform(43.475,70.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#131313").s().p("AgKAOQgEgFAAgJQAAgHAEgFQAFgFAGgBQAHAAADAFQAEAFAAAHIAAADIgYAAQABAFADAEQADADAEAAQAGAAAFgFIAAAGQgFADgHAAQgHAAgEgEgAgFgKQgDADgBAFIASAAQAAgFgCgDQgCgDgEABQgDgBgDADg");
	this.shape_82.setTransform(40.125,70.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#131313").s().p("AALAYIgIgNIgDgEIgBgCIgCgBIgDgBIgFAAIAAAVIgGAAIAAgvIAPAAIAFAAIAFACIADAFIABAFIAAAFIgDAEIgDACIgFACIAAAAIADABIABABIABADIACADIAJAOgAgLgBIAIAAIADgBIADgBIADgDIAAgEQAAgEgCgCQgDgCgEgBIgIAAg");
	this.shape_83.setTransform(36.7,69.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#F4F4F4").s().p("ArINVIAA6pIWQAAIAAapg");
	this.shape_84.setTransform(49.6204,109.9512,0.6964,0.6964);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AAJASIgIgZIAAgDIgBADIgHAZIgGAAIgLgjIAGAAIAHAaIABADIABgDIAIgaIAEAAIAIAaIABADIAAgDIAIgaIAFAAIgLAjg");
	this.shape_85.setTransform(64,208.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgLAOQgEgFAAgJQAAgHAFgGQAFgFAGAAQAHAAAEAEQAEAGAAAIIAAABIgZAAQAAAGADAEQADADAFAAQAGAAAFgEIAAAGQgFADgIAAQgGAAgFgFgAgFgKQgDADgBAEIATAAQAAgFgDgCQgCgDgEAAQgDAAgDADg");
	this.shape_86.setTransform(59.575,208.2);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgTIgBgDIABgCIACgBIADABIABACIgBADQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCgBg");
	this.shape_87.setTransform(56.775,207.375);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgCAZIgTgxIAHAAIAOAnIAAAEIAAAAIABgEIAPgnIAGAAIgTAxg");
	this.shape_88.setTransform(53.625,207.475);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgCAbIAAg1IAFAAIAAA1g");
	this.shape_89.setTransform(48.575,207.325);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgKAQQgDgDAAgEQAAgJAMgDIAKgBQAAgJgIAAQgFAAgGAFIAAgHQAGgDAGAAQAMAAAAANIAAAXIgFAAIAAgGIgBAAQgDAHgHAAQgFAAgDgDgAAAABQgDAAgCACQgCACAAADQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQACACADAAQADAAADgDQADgDAAgFIAAgDg");
	this.shape_90.setTransform(45.725,208.2);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgOADIAAgVIAGAAIAAAUQAAAMAIAAQAEAAACgDQADgDAAgGIAAgUIAGAAIAAAjIgGAAIAAgFQgEAHgGgBQgNAAAAgPg");
	this.shape_91.setTransform(41.95,208.25);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgLAWQgEgFAAgIQgBgJAFgEQAEgGAHAAQAHAAAEAGIAAAAIAAgWIAFAAIAAA0IgFAAIAAgGIAAAAQgFAHgHAAQgGAAgEgFgAgGgBQgEADAAAHQABAGACAEQADADAEAAQAFAAADgDQADgEAAgFIAAgFQAAgFgDgCQgDgDgFAAQgDAAgDAEg");
	this.shape_92.setTransform(37.7,207.375);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgTIgBgDIABgCIACgBIADABIABACIgBADQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCgBg");
	this.shape_93.setTransform(34.825,207.375);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgCASIgOgjIAHAAIAJAZIAAAFIAAAAIABgEIAKgaIAGAAIgOAjg");
	this.shape_94.setTransform(32.225,208.2);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgCAaIAAgjIAFAAIAAAjgAgCgTIgBgDIABgCIACgBIADABIABACIgBADQgBAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCgBg");
	this.shape_95.setTransform(29.625,207.375);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AgLAWQgFgFAAgIQABgJAEgEQAEgGAHAAQAIAAACAGIABAAIAAgWIAGAAIAAA0IgGAAIAAgGIgBAAQgEAHgGAAQgIAAgDgFgAgHgBQgCADAAAHQgBAGADAEQADADAEAAQAFAAADgDQADgEAAgFIAAgFQAAgFgDgCQgDgDgFAAQgDAAgEAEg");
	this.shape_96.setTransform(26.5,207.375);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AAJASIAAgTQAAgLgJAAQgCAAgEACQgDAEABAFIAAATIgGAAIAAgjIAGAAIAAAGIAAAAQAEgHAGAAQAHAAACAFQAEADAAAIIAAAUg");
	this.shape_97.setTransform(22.55,208.15);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgCAZIAAgxIAFAAIAAAxg");
	this.shape_98.setTransform(19.5,207.475);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#5E5584").s().p("AmhCEIAAkHINDAAIAAEHg");
	this.shape_99.setTransform(42.2905,208.3388,0.6964,0.6964);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#131313").s().p("AgZAqIAAgIIAGABQAHAAADgIIAFgMIgXg5IALAAIAQAsIAAAEIAAAAIABgEIARgsIAKAAIgbBDQgHASgNAAIgGgBg");
	this.shape_100.setTransform(132.225,29.8);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#131313").s().p("AgSAXQgHgIAAgPQAAgNAIgIQAIgJALAAQALAAAHAHQAGAIAAAOIAAADIgpAAQAAAKAFAFQAGAGAHAAQAKAAAJgGIAAAIQgIAGgNAAQgLAAgIgIgAgJgSQgFAFgBAIIAfAAQAAgIgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_101.setTransform(126.275,28.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#131313").s().p("AgEAdIgXg5IAKAAIAQAqIABAHIACgHIAPgqIAKAAIgXA5g");
	this.shape_102.setTransform(120.4,28.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#131313").s().p("AgOAeIAAg6IAJAAIAAAMIABAAQACgGACgDQAEgEAGAAIAFAAIAAAKQgCgCgFAAQgGABgDAFQgEAGAAAJIAAAeg");
	this.shape_103.setTransform(115.45,28.35);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#131313").s().p("AgYAFIAAgiIAKAAIAAAgQAAATAOAAQAGAAAFgFQAEgFAAgIIAAghIAJAAIAAA6IgJAAIAAgKIgBAAQgFALgMAAQgUAAgBgZg");
	this.shape_104.setTransform(109.55,28.475);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#131313").s().p("AgIAqIgGgBIgGgBIgEgCIAAgLIAEADIAGACIAHABIAFABQAIAAAFgDQAEgEAAgGQAAgDgCgDIgDgEIgHgEIgHgEIgIgDIgGgGIgFgGQgBgDAAgFQAAgFACgFQADgDAEgDQAEgDAGgCQAEgBAFAAQAMAAAGADIAAALQgIgFgLAAIgGABIgFACIgEAEQgBACgBADIABAGQACADACABIAFAEIAHAEIAJAEIAHAFIAEAGQACAEAAAFQAAAFgCAFQgDAEgEADQgEADgFAAQgGACgFAAIgEgBg");
	this.shape_105.setTransform(103.15,27.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#131313").s().p("AALAsIgYgdIgBAAIAAAdIgKAAIAAhXIAKAAIAAA3IABAAIAXgaIANAAIgbAbIAdAfg");
	this.shape_106.setTransform(94.2,26.975);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#131313").s().p("AgNAXQgIgJAAgNQAAgNAIgJQAJgJANAAQAHAAAGADIAAAJQgGgEgIAAQgIAAgGAGQgFAHAAAJQAAALAFAGQAFAGAJAAQAHAAAHgFIAAAJQgHAEgJAAQgMAAgHgIg");
	this.shape_107.setTransform(88.125,28.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#131313").s().p("AgRAaQgGgEAAgIQAAgQAUgDIARgCQAAgPgMAAQgKAAgIAHIAAgKQAIgFAKAAQAWAAgBAWIAAAlIgJAAIAAgJQgHALgLAAQgIAAgFgFgAAAABQgGABgDADQgEACAAAGQAAAFAEACQACADAGAAQAGAAAFgFQAEgFAAgHIAAgGg");
	this.shape_108.setTransform(82.2,28.4);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#131313").s().p("AgQAjIgBAAIAAAIIgJAAIAAhXIAJAAIAAAnIABAAQAHgMAMAAQALAAAHAJQAGAIAAALQAAAPgHAKQgHAJgNgBQgKABgGgKgAgMgDQgFAFAAAIIAAAJQAAAHAFAGQAFAEAHAAQAIAAAFgGQAFgHAAgMQAAgJgFgFQgFgFgHAAQgIAAgFAFg");
	this.shape_109.setTransform(76.175,27.05);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#131313").s().p("AgTAkQgHgHAAgOQAAgPAHgIQAIgJALAAQAMAAAGAKIAAglIAJAAIAABXIgJAAIAAgKQgHALgNAAQgLABgGgJgAgMgCQgEAFAAAMQAAAJAEAGQAFAHAHgBQAIABAFgHQAFgFAAgJIAAgIQAAgIgFgDQgFgGgHABQgIAAgFAGg");
	this.shape_110.setTransform(68.825,27.05);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#131313").s().p("AgSAXQgHgIAAgPQAAgNAIgIQAIgJALAAQALAAAHAHQAGAIAAAOIAAADIgpAAQAAAKAFAFQAGAGAHAAQAKAAAJgGIAAAIQgIAGgNAAQgLAAgIgIgAgJgSQgFAFgBAIIAfAAQAAgIgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_111.setTransform(62.475,28.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#131313").s().p("AgSAXQgHgIAAgPQAAgNAIgIQAIgJALAAQALAAAHAHQAGAIAAAOIAAADIgpAAQAAAKAFAFQAGAGAHAAQAKAAAJgGIAAAIQgIAGgNAAQgLAAgIgIgAgJgSQgFAFgBAIIAfAAQAAgIgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_112.setTransform(56.275,28.4);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#131313").s().p("AgUApIAAhSIApAAIAAAJIgfAAIAAAdIAcAAIAAAIIgcAAIAAAkg");
	this.shape_113.setTransform(50.55,27.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#131313").s().p("AgGAWIAAgiIgKAAIAAgIIAKAAIAAgPIAIgDIAAASIAPAAIAAAIIgPAAIAAAgQAAAGACADQACACAFAAQAEAAACgCIAAAIQgDACgGAAQgOAAAAgRg");
	this.shape_114.setTransform(142.025,9.8);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#131313").s().p("AAQAeIAAghQAAgSgPAAQgFAAgFAFQgFAFAAAIIAAAhIgKAAIAAg6IAKAAIAAAKIAAAAQAHgLALAAQALAAAEAGQAFAGABAMIAAAjg");
	this.shape_115.setTransform(136.75,10.525);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#131313").s().p("AgSAXQgHgIAAgPQAAgNAIgIQAIgJALAAQALAAAHAIQAGAHAAANIAAAFIgpAAQAAAJAFAFQAGAGAHAAQAKAAAJgHIAAAJQgIAGgNAAQgLAAgIgIgAgJgSQgFAGgBAHIAfAAQAAgIgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_116.setTransform(130.275,10.6);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#131313").s().p("AgFAeIgVg6IAKAAIAOAqIACAIIACgIIAQgqIAKAAIgYA6g");
	this.shape_117.setTransform(124.4,10.6);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#131313").s().p("AgVAqIAAhTIApAAIAAAJIgfAAIAAAcIAcAAIAAAHIgcAAIAAAeIAhAAIAAAJg");
	this.shape_118.setTransform(118.85,9.4);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#131313").s().p("AgGAWIAAgiIgKAAIAAgIIAKAAIAAgPIAIgDIAAASIAPAAIAAAIIgPAAIAAAgQAAAGACADQACACAFAAQAEAAACgCIAAAIQgDACgGAAQgOAAAAgRg");
	this.shape_119.setTransform(110.275,9.8);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#131313").s().p("AAQAeIAAghQgBgSgOAAQgFAAgFAFQgFAFAAAIIAAAhIgKAAIAAg6IAKAAIAAAKIABAAQAGgLAMAAQAJAAAFAGQAGAGAAAMIAAAjg");
	this.shape_120.setTransform(105,10.525);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#131313").s().p("AgSAXQgHgIAAgPQAAgNAIgIQAIgJALAAQALAAAHAIQAGAHAAANIAAAFIgpAAQAAAJAFAFQAGAGAHAAQAKAAAJgHIAAAJQgIAGgNAAQgLAAgIgIgAgJgSQgFAGgBAHIAfAAQAAgIgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_121.setTransform(98.525,10.6);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#131313").s().p("AAgAeIAAghQAAgKgCgEQgEgEgGAAQgHAAgEAFQgEAGAAAHIAAAhIgIAAIAAgiQAAgRgOAAQgGAAgFAFQgDAFAAAIIAAAhIgKAAIAAg6IAKAAIAAAJIAAAAQAGgKAMAAQAGAAAFADQADADACAGQAHgMANAAQATAAAAAYIAAAjg");
	this.shape_122.setTransform(90.35,10.525);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#131313").s().p("AAQAeIAAghQgBgSgOAAQgFAAgFAFQgFAFAAAIIAAAhIgKAAIAAg6IAKAAIAAAKIAAAAQAHgLAMAAQAJAAAFAGQAGAGAAAMIAAAjg");
	this.shape_123.setTransform(81.95,10.525);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#131313").s().p("AgEArIAAg6IAIAAIAAA6gAgEggQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAQABgBAAAAQAAgBAAAAQABgBABAAQAAAAABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAAAQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAgBgBg");
	this.shape_124.setTransform(77.15,9.225);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#131313").s().p("AgRAaQgFgFgBgHQABgQATgCIARgDQAAgPgMAAQgKAAgJAHIAAgKQAJgFAKAAQAWAAAAAWIAAAmIgKAAIAAgJQgHAKgKAAQgKAAgEgFgAAAABQgGACgDACQgDACAAAGQAAAFADACQACADAGAAQAGAAAEgFQAFgFAAgHIAAgGg");
	this.shape_125.setTransform(72.5,10.6);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#131313").s().p("AgGAWIAAgiIgKAAIAAgIIAKAAIAAgPIAIgDIAAASIAPAAIAAAIIgPAAIAAAgQAAAGACADQACACAFAAQAEAAACgCIAAAIQgDACgGAAQgOAAAAgRg");
	this.shape_126.setTransform(67.625,9.8);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#131313").s().p("AgOAeIAAg6IAJAAIAAAMIABAAQACgGACgDQAEgEAGAAIAFAAIAAALQgCgDgFAAQgGAAgDAGQgEAGAAAJIAAAeg");
	this.shape_127.setTransform(63.7,10.55);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#131313").s().p("AgSAXQgHgIAAgPQAAgNAIgIQAIgJALAAQALAAAHAIQAGAHAAANIAAAFIgpAAQAAAJAFAFQAGAGAHAAQAKAAAJgHIAAAJQgIAGgNAAQgLAAgIgIgAgJgSQgFAGgBAHIAfAAQAAgIgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_128.setTransform(58.125,10.6);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#131313").s().p("AgGAWIAAgiIgKAAIAAgIIAKAAIAAgPIAIgDIAAASIAPAAIAAAIIgPAAIAAAgQAAAGACADQACACAFAAQAEAAACgCIAAAIQgDACgGAAQgOAAAAgRg");
	this.shape_129.setTransform(53.075,9.8);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#131313").s().p("AAPAeIAAghQAAgSgNAAQgHAAgEAFQgFAFAAAIIAAAhIgJAAIAAg6IAJAAIAAAKIAAAAQAHgLALAAQAKAAAGAGQAEAGAAAMIAAAjg");
	this.shape_130.setTransform(47.8,10.525);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#131313").s().p("AgVAqIAAhTIApAAIAAAJIggAAIAAAcIAeAAIAAAHIgeAAIAAAeIAiAAIAAAJg");
	this.shape_131.setTransform(41.7,9.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.6,170.9,269.6);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5,32);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.cursor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgQIAhlMgrLArMIgNgIMAAAis/MB3BB29Mg7dAAAMAbGBBFIxWIqg");
	this.shape.setTransform(8.6,9.55,0.0152,0.014,-15.0037,0,0,-65.4,34.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#131313").s().p("EgDYB1CIjCnRMgVRgzXMgpNApNIpLJJMAAAjhDQAAgKADgOIAGgWIAQAWQAJAMAIAIMAzNAzNUAkgAkkAtrAtqIVRVQQAKAKAQANIAbAVIgIANMhFVAAAMAYwA7bMgkGASEIggAWgEACJBmIIRWorMgbGhBEMA7cAAAMh3Ah29MAAACs/IAMAIMArLgrMg");
	this.shape_1.setTransform(9.2,9.8,0.0152,0.014,-15.0037,0,0,-80.7,99.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.4,19.6);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,96,170,0.498)").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAEAAACADQACACAAACQAAADgCADQgCACgEAAQgCAAgCgCg");
	this.shape.setTransform(9.25,9.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,96,170,0.498)").s().p("AgNAPQgGgHAAgIQAAgGAGgHQAGgGAHAAQAIAAAGAGQAGAHAAAGQAAAIgGAHQgGAFgIAAQgHAAgGgFg");
	this.shape_1.setTransform(9.25,9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(102,96,170,0.498)").s().p("AgVAXQgKgJAAgOQAAgLAKgKQAJgKAMAAQANAAAJAKQAKAKAAALQAAAOgKAJQgJAJgNAAQgMAAgJgJg");
	this.shape_2.setTransform(9.25,9.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,96,170,0.498)").s().p("AgeAgQgNgOAAgSQAAgQANgOQAMgNASAAQASAAANANQANAOAAAQQAAASgNAOQgNAMgSAAQgSAAgMgMg");
	this.shape_3.setTransform(9.25,9.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(102,96,170,0.498)").s().p("AgnAoQgQgQAAgYQAAgVAQgSQARgQAWAAQAWAAARAQQARASAAAVQAAAYgRAQQgRAQgWAAQgWAAgRgQg");
	this.shape_4.setTransform(9.25,9.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(102,96,170,0.498)").s().p("AgiAjQgOgPAAgUQAAgTAOgPQAOgOAUAAQATAAAOAOQAQAPAAATQAAAUgQAPQgOAOgTAAQgUAAgOgOg");
	this.shape_5.setTransform(9.25,9.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,96,170,0.498)").s().p("AgdAeQgMgMAAgSQAAgPAMgOQANgMAQAAQARAAAMAMQANAOAAAPQAAASgNAMQgMAMgRAAQgQAAgNgMg");
	this.shape_6.setTransform(9.225,9.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(102,96,170,0.498)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQALgKANAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgNAAgLgKg");
	this.shape_7.setTransform(9.225,9.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(102,96,170,0.498)").s().p("AgTAUQgIgIAAgMQAAgKAIgJQAIgIALAAQALAAAIAIQAJAJAAAKQAAAMgJAIQgIAIgLAAQgLAAgIgIg");
	this.shape_8.setTransform(9.225,9.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(102,96,170,0.498)").s().p("AgOAPQgGgGAAgJQAAgHAGgHQAGgGAIAAQAIAAAGAGQAHAHAAAHQAAAJgHAGQgGAGgIAAQgIAAgGgGg");
	this.shape_9.setTransform(9.225,9.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(102,96,170,0.498)").s().p("AgIAKQgFgEAAgGQAAgEAFgEQAEgFAEAAQAGAAAEAFQADAEAAAEQAAAGgDAEQgEAEgGgBQgEABgEgEg");
	this.shape_10.setTransform(9.2,9.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(102,96,170,0.498)").s().p("AgEAFQgBgCAAgDQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQABABAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAADgCACQAAAAAAABQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAg");
	this.shape_11.setTransform(9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[]},1).wait(6));

	// Layer_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(102,96,170,0.498)").s().p("AgLALQgEgEAAgHQAAgFAEgGQAGgEAFAAQAHAAAEAEQAFAGAAAFQAAAHgFAEQgEAFgHAAQgFAAgGgFg");
	this.shape_12.setTransform(9.2,9.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(102,96,170,0.498)").s().p("AgUAVQgHgJAAgMQAAgLAHgJQAJgHALAAQALAAAJAHQAJAJAAALQAAAMgJAJQgJAIgLAAQgLAAgJgIg");
	this.shape_13.setTransform(9.2,9.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(102,96,170,0.498)").s().p("AgdAdQgLgMgBgRQABgQALgNQANgLAQgBQAQABANALQAMANAAAQQAAARgMAMQgNAMgQAAQgQAAgNgMg");
	this.shape_14.setTransform(9.2,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(102,96,170,0.498)").s().p("AgmAnQgPgQAAgXQAAgUAPgSQARgPAVAAQAWAAAPAPQARASAAAUQAAAXgRAQQgPAPgWAAQgVAAgRgPg");
	this.shape_15.setTransform(9.2,9.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(102,96,170,0.498)").s().p("AgvAvQgTgTAAgcQAAgaATgVQAUgTAbAAQAaAAAUATQAUAVAAAaQAAAcgUATQgUATgaAAQgbAAgUgTg");
	this.shape_16.setTransform(9.2,9.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(102,96,170,0.498)").s().p("Ag4A4QgWgXAAghQAAgeAWgaQAYgWAgAAQAgAAAXAWQAZAaAAAeQAAAhgZAXQgXAYggAAQggAAgYgYg");
	this.shape_17.setTransform(9.2,9.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(102,96,170,0.498)").s().p("AhBBCQgagcAAgmQAAgjAageQAbgaAmAAQAkAAAbAaQAdAeAAAjQAAAmgdAcQgbAagkAAQgmAAgbgag");
	this.shape_18.setTransform(9.2,9.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(102,96,170,0.498)").s().p("Ag8A8QgYgYAAgkQAAggAYgcQAagYAiAAQAiAAAYAYQAbAcAAAgQAAAkgbAYQgYAZgiAAQgiAAgagZg");
	this.shape_19.setTransform(9.2,9.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(102,96,170,0.498)").s().p("Ag2A4QgXgXAAghQAAgeAXgYQAWgXAgAAQAfAAAXAXQAYAYAAAeQAAAhgYAXQgXAWgfAAQggAAgWgWg");
	this.shape_20.setTransform(9.2,9.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(102,96,170,0.498)").s().p("AgyAyQgUgUAAgeQAAgbAUgXQAWgUAcAAQAcAAAUAUQAXAXAAAbQAAAegXAUQgUAVgcAAQgcAAgWgVg");
	this.shape_21.setTransform(9.2,9.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(102,96,170,0.498)").s().p("AgsAuQgTgTAAgbQAAgZATgTQASgTAaAAQAaAAASATQAUATAAAZQAAAbgUATQgSASgaAAQgaAAgSgSg");
	this.shape_22.setTransform(9.2,9.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(102,96,170,0.498)").s().p("AgoAoQgQgQAAgYQAAgVAQgTQARgQAXAAQAWAAARAQQASATAAAVQAAAYgSAQQgRARgWAAQgXAAgRgRg");
	this.shape_23.setTransform(9.2,9.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(102,96,170,0.498)").s().p("AgiAkQgPgPAAgVQAAgSAPgQQAOgPAUAAQAUAAAPAPQAPAQAAASQAAAVgPAPQgPAOgUAAQgUAAgOgOg");
	this.shape_24.setTransform(9.2,9.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(102,96,170,0.498)").s().p("AgeAeQgMgMAAgSQAAgQAMgOQANgMARAAQARAAAMAMQAOAOAAAQQAAASgOAMQgMANgRAAQgRAAgNgNg");
	this.shape_25.setTransform(9.2,9.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(102,96,170,0.498)").s().p("AgYAaQgLgLAAgPQAAgNALgLQAKgLAOAAQAOAAAKALQAMALAAANQAAAPgMALQgKAKgOAAQgOAAgKgKg");
	this.shape_26.setTransform(9.2,9.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(102,96,170,0.498)").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape_27.setTransform(9.2,9.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(102,96,170,0.498)").s().p("AgOAPQgHgFAAgKQAAgHAHgHQAGgHAIAAQAIAAAHAHQAHAHAAAHQAAAKgHAFQgHAHgIAAQgIAAgGgHg");
	this.shape_28.setTransform(9.2,9.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(102,96,170,0.498)").s().p("AgJALQgFgEAAgHQAAgFAFgEQAEgFAFAAQAGAAAFAFQAEAEAAAFQAAAHgEAEQgFAEgGAAQgFAAgEgEg");
	this.shape_29.setTransform(9.2,9.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(102,96,170,0.498)").s().p("AgFAFQgCgCAAgDQAAgCACgDQACgCADAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgDAAgCgDg");
	this.shape_30.setTransform(9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.4,18.4);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.BG22x();
	this.instance.setTransform(649.5,-27.25,0.5,0.5);

	this.instance_1 = new lib.BG2x();
	this.instance_1.setTransform(0,-27.25,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0A4D3").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,-27.2,728,117.5), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.result = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.components = new lib.resultcomponent("synched",0);
	this.components.name = "components";
	this.components.setTransform(101.85,146,1,1,0,0,0,86.6,129.4);

	this.timeline.addTween(cjs.Tween.get(this.components).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(15.3,16,170.79999999999998,269.6);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(64.45,10.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(16.425,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(5.125,16.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(16.425,5.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(5.125,5.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(0,0,132.4,21.6), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_86 = function() {
		exportRoot.tlMain.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(86).call(this.frame_86).wait(14).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(363.8,45.15,0.0349,0.0349,0,0,0,-40.1,1.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,scaleX:1.5098,scaleY:1.5099,y:45.1},13,cjs.Ease.quadOut).to({x:279.65},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("APqEzIAAlFIcFAAIAAFFg");
	var mask_graphics_15 = new cjs.Graphics().p("APkEzIAAlFIcFAAIAAFFg");
	var mask_graphics_16 = new cjs.Graphics().p("APSEzIAAlFIcGAAIAAFFg");
	var mask_graphics_17 = new cjs.Graphics().p("AO1EzIAAlFIcFAAIAAFFg");
	var mask_graphics_18 = new cjs.Graphics().p("AOMEzIAAlFIcFAAIAAFFg");
	var mask_graphics_19 = new cjs.Graphics().p("ANYEzIAAlFIcFAAIAAFFg");
	var mask_graphics_20 = new cjs.Graphics().p("AMXEzIAAlFIcFAAIAAFFg");
	var mask_graphics_21 = new cjs.Graphics().p("ALXEzIAAlFIcFAAIAAFFg");
	var mask_graphics_22 = new cjs.Graphics().p("AKiEzIAAlFIcGAAIAAFFg");
	var mask_graphics_23 = new cjs.Graphics().p("AJ5EzIAAlFIcGAAIAAFFg");
	var mask_graphics_24 = new cjs.Graphics().p("AJcEzIAAlFIcFAAIAAFFg");
	var mask_graphics_25 = new cjs.Graphics().p("AJLEzIAAlFIcFAAIAAFFg");
	var mask_graphics_26 = new cjs.Graphics().p("AJFEzIAAlFIcFAAIAAFFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:279.8959,y:30.6727}).wait(1).to({graphics:mask_graphics_15,x:279.3111,y:30.6727}).wait(1).to({graphics:mask_graphics_16,x:277.557,y:30.6727}).wait(1).to({graphics:mask_graphics_17,x:274.6333,y:30.6727}).wait(1).to({graphics:mask_graphics_18,x:270.5403,y:30.6727}).wait(1).to({graphics:mask_graphics_19,x:265.2777,y:30.6727}).wait(1).to({graphics:mask_graphics_20,x:258.8458,y:30.6727}).wait(1).to({graphics:mask_graphics_21,x:252.4138,y:30.6727}).wait(1).to({graphics:mask_graphics_22,x:247.1513,y:30.6727}).wait(1).to({graphics:mask_graphics_23,x:243.0582,y:30.6727}).wait(1).to({graphics:mask_graphics_24,x:240.1346,y:30.6727}).wait(1).to({graphics:mask_graphics_25,x:238.3804,y:30.6727}).wait(1).to({graphics:mask_graphics_26,x:237.8209,y:30.6727}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(154.9,29,1.5098,1.5099,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:263.55,y:29.15},12,cjs.Ease.quadInOut).wait(33).to({alpha:0},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(0.05,0.05,0.7414,0.1102,0,0,0,0.1,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({startPosition:0},0).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.uigraphics = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.survey.cache(-105,-104,422,419,2);
		//this.result_page.components.cache(-71,-112,342,578,2);
	}
	this.frame_485 = function() {
		this.stop();
		exportRoot.tlMain.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(485).call(this.frame_485).wait(1));

	// cursor
	this.cursor = new lib.cursor("synched",0);
	this.cursor.name = "cursor";
	this.cursor.setTransform(169.3,39.5,2.1299,2.1299,0,0,0,9.2,9.9);

	this.timeline.addTween(cjs.Tween.get(this.cursor).to({x:99.3,y:54.5},39,cjs.Ease.quadIn).to({regY:9.8,scaleX:2.13,scaleY:2.13,x:62.65,y:50.75},42,cjs.Ease.quadOut).wait(27).to({startPosition:0},0).to({x:63.55,y:50.9},51,cjs.Ease.quadInOut).wait(34).to({startPosition:0},0).to({x:178.6,y:29.9},36,cjs.Ease.quadInOut).wait(81).to({startPosition:0},0).to({y:55.9},25,cjs.Ease.quadIn).wait(85).to({startPosition:0},0).to({x:197.6,y:61.1},40,cjs.Ease.quadInOut).wait(26));

	// click
	this.instance = new lib.click("synched",0,false);
	this.instance.setTransform(43.35,31.3,2.75,2.75,0,0,0,9.2,9.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(85).to({_off:false},0).wait(82).to({startPosition:0},0).wait(299).to({x:178,y:40.1},0).wait(20));

	// clicked
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6660AA").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape.setTransform(43.325,31.375);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,96,170,0.996)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_1.setTransform(43.325,31.375);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(102,96,170,0.992)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_2.setTransform(43.325,31.375);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,96,170,0.988)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_3.setTransform(43.325,31.375);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(102,96,170,0.98)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_4.setTransform(43.325,31.375);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(102,96,170,0.969)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_5.setTransform(43.325,31.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,96,170,0.953)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_6.setTransform(43.325,31.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(102,96,170,0.933)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_7.setTransform(43.325,31.375);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(102,96,170,0.91)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_8.setTransform(43.325,31.375);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(102,96,170,0.878)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_9.setTransform(43.325,31.375);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(102,96,170,0.843)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_10.setTransform(43.325,31.375);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(102,96,170,0.796)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_11.setTransform(43.325,31.375);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(102,96,170,0.737)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_12.setTransform(43.325,31.375);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(102,96,170,0.671)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_13.setTransform(43.325,31.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(102,96,170,0.592)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_14.setTransform(43.325,31.375);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(102,96,170,0.502)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_15.setTransform(43.325,31.375);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(102,96,170,0.408)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_16.setTransform(43.325,31.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(102,96,170,0.329)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_17.setTransform(43.325,31.375);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(102,96,170,0.263)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_18.setTransform(43.325,31.375);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(102,96,170,0.204)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_19.setTransform(43.325,31.375);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(102,96,170,0.157)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_20.setTransform(43.325,31.375);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(102,96,170,0.122)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_21.setTransform(43.325,31.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(102,96,170,0.09)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_22.setTransform(43.325,31.375);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(102,96,170,0.067)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_23.setTransform(43.325,31.375);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(102,96,170,0.047)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_24.setTransform(43.325,31.375);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(102,96,170,0.031)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_25.setTransform(43.325,31.375);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(102,96,170,0.02)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_26.setTransform(43.325,31.375);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(102,96,170,0.012)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_27.setTransform(43.325,31.375);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(102,96,170,0.008)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_28.setTransform(43.325,31.375);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(102,96,170,0.004)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_29.setTransform(43.325,31.375);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(102,96,170,0)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQAKgKAOAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgOAAgKgKg");
	this.shape_30.setTransform(43.325,31.375);
	this.shape_30._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},103).to({state:[{t:this.shape}]},5).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},26).to({state:[{t:this.shape}]},67).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_30}]},1).wait(194));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(103).to({_off:false},0).wait(6).to({y:31.325},0).wait(1).to({y:31.125},0).wait(1).to({y:30.775},0).wait(1).to({y:30.325},0).wait(1).to({y:29.775},0).wait(1).to({y:29.075},0).wait(1).to({y:28.225},0).wait(1).to({y:27.275},0).wait(1).to({y:26.175},0).wait(1).to({y:24.975},0).wait(1).to({y:23.625},0).wait(1).to({y:22.125},0).wait(1).to({y:20.525},0).wait(1).to({y:18.825},0).wait(1).to({y:16.975},0).wait(1).to({y:14.975},0).wait(1).to({y:12.875},0).wait(1).to({y:10.625},0).wait(1).to({y:8.225},0).wait(1).to({y:5.725},0).wait(1).to({y:3.125},0).wait(1).to({y:0.375},0).wait(1).to({y:-2.525},0).wait(1).to({y:-5.525},0).wait(1).to({y:-8.675},0).wait(1).to({y:-11.925},0).wait(1).to({y:-15.075},0).wait(1).to({y:-18.075},0).wait(1).to({y:-20.975},0).wait(1).to({y:-23.725},0).wait(1).to({y:-26.325},0).wait(1).to({y:-28.825},0).wait(1).to({y:-31.225},0).wait(1).to({y:-33.475},0).wait(1).to({y:-35.575},0).wait(1).to({y:-37.575},0).wait(1).to({y:-39.425},0).wait(1).to({y:-41.125},0).wait(1).to({y:-42.725},0).wait(1).to({y:-44.225},0).wait(1).to({y:-45.575},0).wait(1).to({y:-46.775},0).wait(1).to({y:-47.875},0).wait(1).to({y:-48.825},0).wait(1).to({y:-49.675},0).wait(1).to({y:-50.375},0).wait(1).to({y:-50.925},0).wait(1).to({y:-51.375},0).wait(1).to({y:-51.725},0).wait(1).to({y:-51.925},0).wait(1).to({y:-51.975},0).wait(26).to({y:31.375},0).wait(72).to({_off:true},1).wait(228));
	this.timeline.addTween(cjs.Tween.get(this.shape_30).wait(287).to({_off:false},0).wait(199));

	// result mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AweN/IAA79MAg9AAAIAAb9g");
	mask.setTransform(105.5,89.5);

	// result
	this.result_page = new lib.result("synched",0);
	this.result_page.name = "result_page";
	this.result_page.setTransform(119.2,75.75,1.1278,1.1278,0,0,0,105.7,89.4);
	this.result_page.alpha = 0;
	this.result_page._off = true;

	var maskedShapeInstanceList = [this.result_page];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.result_page).wait(252).to({_off:false},0).to({alpha:1},40,cjs.Ease.quartInOut).wait(43).to({startPosition:0},0).to({y:-109.75},115,cjs.Ease.quadOut).wait(36));

	// result BG
	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(255,255,255,0)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_31.setTransform(114.45,75.65);
	this.shape_31._off = true;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0.004)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_32.setTransform(114.45,75.65);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0.008)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_33.setTransform(114.45,75.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.012)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_34.setTransform(114.45,75.65);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.02)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_35.setTransform(114.45,75.65);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.031)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_36.setTransform(114.45,75.65);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.047)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_37.setTransform(114.45,75.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.067)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_38.setTransform(114.45,75.65);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.09)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_39.setTransform(114.45,75.65);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.122)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_40.setTransform(114.45,75.65);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.157)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_41.setTransform(114.45,75.65);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.204)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_42.setTransform(114.45,75.65);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.263)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_43.setTransform(114.45,75.65);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.329)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_44.setTransform(114.45,75.65);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.408)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_45.setTransform(114.45,75.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.502)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_46.setTransform(114.45,75.65);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.592)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_47.setTransform(114.45,75.65);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.671)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_48.setTransform(114.45,75.65);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.737)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_49.setTransform(114.45,75.65);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.796)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_50.setTransform(114.45,75.65);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.843)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_51.setTransform(114.45,75.65);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.878)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_52.setTransform(114.45,75.65);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.91)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_53.setTransform(114.45,75.65);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.933)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_54.setTransform(114.45,75.65);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.953)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_55.setTransform(114.45,75.65);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.969)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_56.setTransform(114.45,75.65);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.98)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_57.setTransform(114.45,75.65);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.988)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_58.setTransform(114.45,75.65);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.992)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_59.setTransform(114.45,75.65);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.996)").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_60.setTransform(114.45,75.65);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("Ax4NlIAA7IMAjwAAAIAAbIg");
	this.shape_61.setTransform(114.45,75.65);
	this.shape_61._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_31}]},252).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_61}]},1).wait(194));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(252).to({_off:false},0).wait(5).to({_off:true},1).wait(228));
	this.timeline.addTween(cjs.Tween.get(this.shape_61).wait(287).to({_off:false},0).wait(199));

	// survey
	this.survey = new lib.survey("synched",0);
	this.survey.name = "survey";
	this.survey.setTransform(104.5,103.8,1,1,0,0,0,104.5,103.8);

	this.timeline.addTween(cjs.Tween.get(this.survey).wait(39).to({startPosition:0},0).to({y:41.5},42,cjs.Ease.quadOut).wait(27).to({startPosition:0},0).to({y:-41.85},51,cjs.Ease.quadInOut).wait(327));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9,-159.7,247,493.7);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-0.55,-0.15,0.8125,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ApvCeIAAk7ITfAAIAAE7g");
	this.shape.setTransform(-38.5281,-0.9156,0.9559,1.0938);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-98.1,-18.2,119.19999999999999,34.599999999999994), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(713.65,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.5,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Logo intro
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(0.1,0,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// txt_CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(669.1,60.95,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(710.75,60.6,0.8205,0.8205,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// screen
	this.screen = new lib.screen_1("synched",0);
	this.screen.name = "screen";
	this.screen.setTransform(215.4,66.45,0.695,0.695,0,0,0,247.7,145.9);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// UI graphics
	this.ui = new lib.uigraphics();
	this.ui.name = "ui";
	this.ui.setTransform(259.5,114.8,1,1,0,0,0,104.5,103.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// bg img
	this.bg = new lib.bg();
	this.bg.name = "bg";
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	// still logo
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(15.95,16.2,0.6777,0.6777,0,0,0,-0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(363.9999,45.0001,2.4267,0.36);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-1069.8,728,1414.8), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		mc.visible = false;
		mc.replay_btn.alpha=0;
		//mc.ui.shadow = new createjs.Shadow("#000000", 0, 5, 6);
		mc.screen.cache(-248,-146,990,584,2);
		
		
		this.runBanner = function() {
			
				mc.visible = true;
				mc.replay_btn.alpha=1;
			
				this.tlMain = gsap.timeline({default:{duration:0.4, ease:"power4.inOut"}});
				this.tlMain.pause();
				mc.logo_intro.play();
			
		//1st frame
				this.tlMain.from(mc.ui,{duration:0.6, y:"+=200", alpha:0, onStart:function(){mc.ui.gotoAndPlay();}});
				this.tlMain.from([exportRoot.headline1a,exportRoot.headline1b],{y:"+=10", alpha:0, stagger:0.2}, "<");
				this.tlMain.to([exportRoot.headline1a,exportRoot.headline1b],{y:"-=10", alpha:0},"+=2");
		//2nd frame	
				
				this.tlMain.from([exportRoot.headline2a,exportRoot.headline2b, exportRoot.headline2c],{y:"+=10", alpha:0, stagger:0.15});
				this.tlMain.to([exportRoot.headline2a,exportRoot.headline2b,exportRoot.headline2c],{y:"-=10", alpha:0},"+=2");
		//3rd frame
				this.tlMain.from([exportRoot.headline3a,exportRoot.headline3b, exportRoot.headline3c],{y:"+=10", alpha:0, stagger:0.15});
				this.tlMain.to([exportRoot.headline3a,exportRoot.headline3b,exportRoot.headline3c],{y:"-=10", alpha:0},"+=2");
		//4th frame
				this.tlMain.from([exportRoot.headline4a,exportRoot.headline4b, exportRoot.headline4c],{
					y:"+=10", 
					alpha:0, 
					stagger:0.15,
					onComplete: function (){exportRoot.tlMain.pause();}
				});
				this.tlMain.to([exportRoot.headline4a,exportRoot.headline4b,exportRoot.headline4c],{y:"-=10", alpha:0});
				
				//last frame
				this.tlMain.to([mc.bg,mc.ui],{alpha:0},"<");
				this.tlMain.from(mc.screen, {duration:1, x:"+=80", y:"+=145", alpha:0});
				this.tlMain.from(exportRoot.headline5,{x:"+=80", alpha:0, stagger:0.15},"<0.45");
				this.tlMain.from(exportRoot.headline6,{x:"+=80", alpha:0, stagger:0.15},"<0.45");
				
				this.tlMain.from([mc.cta,mc.txtCta], { alpha:0, duration: 0.6, x: "+=350"}, "-=0.45");
				this.tlMain.from(mc.replay_btn, { alpha: 0, onStart:function(){exportRoot.isReplay = true;}});
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,0.9996,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,0.7,364,344.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1.png?1629462557391", id:"M365_FY21Q3ConsOpt_USA_728x90_BAN_Forms_EN_NA_Standard_ANI_BN_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;