(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1", frames: [[602,684,350,300],[602,986,220,140],[0,0,926,682],[928,0,72,74],[824,986,120,111],[0,684,600,444]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.interfaceCreateAPostShadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.interfaceDropdownShadow = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.newBGpngcopy = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.quill = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.UIBG3 = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIbg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.UIBG3();
	this.instance.setTransform(0.1,27.6,0.507,0.507);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,304.3,282.5);


(lib.textWrong3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgpA6IAAgWQARANATAAQAaAAAAgSQAAgFgCgDIgGgHQgEgCgGgCIgKgFIgOgHQgGgCgFgEQgEgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAHgEQAGgFAJgCQAIgCAJgBQAQABANAFIAAAVQgOgKgSABQgFgBgEACQgEABgEACQgDADgBADQgCADAAAEQAAAFACADQABADADADIAIAFIALAEIAOAHQAIACAEAEQAEAEADAGQACAFAAAIQAAAJgEAHQgEAHgGAFQgIAEgIACQgJADgJAAQgTAAgPgIg");
	this.shape.setTransform(188.4,22.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgpA6IAAgWQARANATAAQAaAAAAgSQAAgFgCgDIgGgHQgEgCgGgCIgKgFIgOgHQgGgCgFgEQgEgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAGgEQAIgFAIgCQAJgCAIgBQAQABANAFIAAAVQgOgKgSABQgEgBgFACQgEABgDACQgEADgCADQgBADAAAEQAAAFABADQACADAEADIAHAFIALAEIAOAHQAIACAEAEQAEAEADAGQADAFAAAIQAAAJgFAHQgDAHgIAFQgHAEgIACQgJADgJAAQgTAAgPgIg");
	this.shape_1.setTransform(177.8,22.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AgJBbIAAh8IATAAIAAB8gAgIhEQgEgEAAgFQAAgGAEgEQADgDAFAAQAFAAAFADQADAEAAAGQAAAFgDAEQgFAEgFAAQgFAAgDgEg");
	this.shape_2.setTransform(169.4,19.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("ABEBAIAAhHQAAgUgGgKQgGgJgPAAQgNAAgJAMQgJAMAAAQIAABGIgTAAIAAhJQAAglgdAAQgNAAgIALQgJALAAASIAABGIgUAAIAAh8IAUAAIAAAUIABAAQANgXAZAAQANAAAKAHQAIAIAEALQAOgaAbAAQAqAAAAAzIAABMg");
	this.shape_3.setTransform(155.725,22.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgmA3QgKgJAAgQQAAgjApgFIAkgGQAAgfgZAAQgWAAgSAPIAAgVQASgMAXAAQAsAAAAAvIAABQIgUAAIAAgTIAAAAQgNAWgYABQgTAAgLgLgAAAAEQgOACgHAEQgHAGAAAMQAAAJAHAGQAGAGALAAQAOAAAKgLQAJgLAAgPIAAgMg");
	this.shape_4.setTransform(138.125,22.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgoA6IAAgWQAQANAUAAQAZAAAAgSQAAgFgCgDIgGgHQgEgCgFgCIgKgFIgPgHQgGgCgEgEQgFgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAGgEQAIgFAIgCQAIgCAJgBQAQABANAFIAAAVQgOgKgSABQgEgBgFACQgEABgDACQgEADgCADQgCADAAAEQAAAFACADQACADAEADIAIAFIAKAEIAPAHQAGACAFAEQAFAEACAGQACAFAAAIQABAJgEAHQgFAHgHAFQgGAEgJACQgJADgJAAQgTAAgOgIg");
	this.shape_5.setTransform(120.05,22.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgmAxQgPgSAAgfQgBgcASgSQAQgTAXAAQAZABANAQQANAQABAcIAAAJIhYAAQABAVAKALQAMAMARAAQAWAAARgPIAAATQgRANgbAAQgZAAgPgRgAgUgmQgKALgDAQIBDAAQAAgRgIgKQgJgJgOAAQgNgBgKAKg");
	this.shape_6.setTransform(108.2,22.75);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AgJBcIAAi3IATAAIAAC3g");
	this.shape_7.setTransform(98.6,19.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AgfA/IAAh8IAUAAIAAAaIAAAAQAEgNAIgHQAJgIALAAQAIABAEABIAAAVQgGgEgKgBQgNAAgHANQgIAMAAAUIAAA/g");
	this.shape_8.setTransform(85.3,22.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgzAKIAAhJIAUAAIAABHQAAAnAeAAQAOAAAKgLQAJgKAAgSIAAhHIAUAAIAAB8IgUAAIAAgUIAAAAQgNAXgZAAQgtAAAAg2g");
	this.shape_9.setTransform(72.8,22.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4B4A4A").s().p("AgsAwQgRgRAAgeQAAgeASgSQARgRAcgBQAcAAAQASQAQARAAAeQAAAdgRATQgRASgcAAQgbgBgRgRgAgdgjQgLAOAAAVQAAAXALANQAMANASAAQATAAALgNQAKgMAAgYQAAgWgKgNQgLgMgTAAQgTgBgLANg");
	this.shape_10.setTransform(58.525,22.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4B4A4A").s().p("AghB1IAAgTQAJAFAIAAQAbAAAAgrIAAh6IAUAAIAAB3QAAAegNARQgMARgWAAQgJAAgIgEgAAMhiQgEgDAAgGQAAgGAEgDQADgEAGAAQAFAAAEAEQAEADAAAGQAAAFgEAEQgEAEgFAAQgGAAgDgEg");
	this.shape_11.setTransform(46.125,22.825);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#4B4A4A").s().p("AAgBAIAAhGQAAgogdAAQgOAAgKAMQgKAKAAASIAABGIgUAAIAAh8IAUAAIAAAVIABAAQAOgYAaAAQAUAAALANQALANAAAZIAABMg");
	this.shape_12.setTransform(38.225,22.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#4B4A4A").s().p("AgsAwQgRgRAAgeQAAgeASgSQARgRAcgBQAcAAAQASQAQARAAAeQAAAdgRATQgRASgcAAQgbgBgRgRgAgdgjQgLAOAAAVQAAAXALANQAMANASAAQATAAALgNQAKgMAAgYQAAgWgKgNQgLgMgTAAQgTgBgLANg");
	this.shape_13.setTransform(23.675,22.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#4B4A4A").s().p("Ag1BXIAAitIAyAAQAWgBANALQANAMAAARQAAAPgIALQgIAMgOAEIAAABQASABAKALQALALAAASQAAAXgQAOQgQAOgYgBgAggBFIAcAAQARAAAKgJQAKgIAAgPQAAgfgqAAIgXAAgAgggMIAVAAQAQABAJgJQAKgHAAgPQAAgaghAAIgXAAg");
	this.shape_14.setTransform(9.675,20.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong3, new cjs.Rectangle(0,0,195.8,37.3), null);


(lib.overlayBar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,102,204,0.349)").s().p("AoUBGIAAiLIQpAAIAACLg");
	this.shape.setTransform(53.3,-4.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlayBar, new cjs.Rectangle(0,-11.8,106.6,14), null);


(lib.interfaceTextRedHighlight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FAEAEA").s().p("AnVCcIAAk3IOrAAIAAE3g");
	this.shape.setTransform(47,17.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FF0000").s().p("AnVAGIAAgLIOrAAIAAALg");
	this.shape_1.setTransform(47,33.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceTextRedHighlight, new cjs.Rectangle(0,1.8,94,32.5), null);


(lib.interfaceShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.interfaceCreateAPostShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceShadow, new cjs.Rectangle(0,0,350,300), null);


(lib.interfaceQuill = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.quill();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceQuill, new cjs.Rectangle(0,0,72,74), null);


(lib.interfaceDropdownShadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.interfaceDropdownShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropdownShadow_1, new cjs.Rectangle(0,0,220,140), null);


(lib.textWrong2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgJBVQgDgEAAgGQAAgFADgEQAFgEAEgBQAFABAEAEQAFAEAAAFQAAAGgFAEQgEADgFAAQgEAAgFgDgAgIAlIgCh8IAUAAIgCB8g");
	this.shape.setTransform(156.85,20.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgpA6IAAgWQARANATAAQAaAAAAgSQAAgFgCgDIgGgHQgEgCgGgCIgKgFIgOgHQgGgCgFgEQgEgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAGgEQAIgFAIgCQAJgCAIgBQAQABANAFIAAAVQgOgKgSABQgEgBgFACQgEABgDACQgEADgBADQgCADAAAEQAAAFACADQABADAEADIAHAFIALAEIAOAHQAIACAEAEQAEAEADAGQADAFAAAIQAAAJgFAHQgDAHgHAFQgIAEgIACQgJADgJAAQgTAAgPgIg");
	this.shape_1.setTransform(148.1,22.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AgsAwQgRgRAAgeQAAgeASgSQARgRAcgBQAcAAAQASQAQARAAAeQAAAdgRATQgRASgcAAQgbgBgRgRgAgdgjQgLAOAAAVQAAAXALANQAMANASAAQATAAALgNQAKgMAAgYQAAgWgKgNQgLgMgTAAQgTgBgLANg");
	this.shape_2.setTransform(135.375,22.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgwBVIAAgUQAVALAUAAQAtAAAAgxIAAgNIgBAAQgOAYgcAAQgXgBgOgQQgPgRAAgbQAAggAQgTQAPgSAagBQAZAAAMAVIABAAIAAgSIAUAAIAAByQAABFhBABQgXgBgSgIgAgag+QgKAOAAAYQAAAUAKAMQAKANAQAAQARAAAKgNQALgLAAgSIAAgSQAAgQgKgKQgKgKgPAAQgSAAgLANg");
	this.shape_3.setTransform(120.275,25.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgmAxQgQgSAAgfQABgcAQgSQARgTAYAAQAYABAOAQQAMAQAAAcIAAAJIhWAAQAAAVALALQAKAMASAAQAWAAARgPIAAATQgQANgbAAQgaAAgPgRgAgUgmQgKALgCAQIBCAAQAAgRgIgKQgJgJgOAAQgNgBgKAKg");
	this.shape_4.setTransform(106.9,22.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgJBbIAAh8IATAAIAAB8gAgIhEQgEgEAAgFQAAgGAEgEQADgDAFAAQAGAAAEADQADAEAAAGQAAAFgDAEQgEAEgGAAQgFAAgDgEg");
	this.shape_5.setTransform(97.3,19.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("ABEBAIAAhHQAAgUgGgKQgGgJgPAAQgNAAgJAMQgJAMAAAQIAABGIgTAAIAAhJQAAglgdAAQgNAAgIALQgJALAAASIAABGIgUAAIAAh8IAUAAIAAAUIABAAQANgXAZAAQANAAAKAHQAIAIAEALQAOgaAbAAQAqAAAAAzIAABMg");
	this.shape_6.setTransform(83.625,22.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AgmA3QgKgJAAgQQAAgjApgFIAkgGQAAgfgZAAQgWAAgSAPIAAgVQASgMAXAAQAsAAAAAvIAABQIgUAAIAAgTIAAAAQgNAWgYABQgTAAgLgLgAAAAEQgOACgHAEQgHAGAAAMQAAAJAHAGQAGAGALAAQAOAAAKgLQAJgLAAgPIAAgMg");
	this.shape_7.setTransform(66.025,22.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AgmA3QgKgJAAgQQAAgjApgFIAkgGQAAgfgZAAQgWAAgSAPIAAgVQASgMAXAAQAsAAAAAvIAABQIgUAAIAAgTIAAAAQgNAWgYABQgTAAgLgLgAAAAEQgOACgHAEQgHAGAAAMQAAAJAHAGQAGAGALAAQAOAAAKgLQAJgLAAgPIAAgMg");
	this.shape_8.setTransform(46.475,22.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgJBcIAAi3IATAAIAAC3g");
	this.shape_9.setTransform(37.45,19.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4B4A4A").s().p("AgsAwQgRgRAAgeQAAgeASgSQARgRAcgBQAcAAAQASQAQARAAAeQAAAdgRATQgRASgcAAQgbgBgRgRgAgdgjQgLAOAAAVQAAAXALANQAMANASAAQATAAALgNQAKgMAAgYQAAgWgKgNQgLgMgTAAQgTgBgLANg");
	this.shape_10.setTransform(27.075,22.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4B4A4A").s().p("AAtBXIAAhQIhZAAIAABQIgVAAIAAitIAVAAIAABMIBZAAIAAhMIAVAAIAACtg");
	this.shape_11.setTransform(10.875,20.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong2, new cjs.Rectangle(0,0,162.6,37.3), null);


(lib.textWrong1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgoA6IAAgWQAQANAUAAQAZAAAAgSQAAgFgCgDIgGgHQgEgCgFgCIgKgFIgPgHQgHgCgDgEQgFgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAHgEQAGgFAJgCQAIgCAJgBQAQABANAFIAAAVQgOgKgSABQgEgBgFACQgFABgCACQgEADgCADQgCADAAAEQAAAFACADQACADAEADIAIAFIAKAEIAPAHQAGACAFAEQAEAEADAGQADAFgBAIQAAAJgDAHQgFAHgHAFQgGAEgJACQgJADgJAAQgTAAgOgIg");
	this.shape.setTransform(135.9,22.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgqBNQgPgRAAgdQAAgeAQgSQAQgTAZAAQAZAAAMAVIABAAIAAhOIAUAAIAAC4IgUAAIAAgVIgBAAQgOAYgcAAQgXAAgOgRgAgagFQgKAMAAAXQAAAWAKANQAKAMAQAAQARAAAKgMQALgMAAgTIAAgSQAAgPgKgJQgKgLgQAAQgRAAgLAOg");
	this.shape_1.setTransform(122.725,19.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AAgBAIAAhGQAAgogdAAQgOAAgKAMQgKAKAAASIAABGIgUAAIAAh8IAUAAIAAAVIABAAQAOgYAaAAQAUAAALANQALANAAAZIAABMg");
	this.shape_2.setTransform(108.875,22.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgJBbIAAh8IATAAIAAB8gAgIhEQgEgEAAgFQAAgGAEgEQAEgDAEAAQAGAAAEADQADAEAAAGQAAAFgDAEQgEAEgGAAQgEAAgEgEg");
	this.shape_3.setTransform(98.65,19.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgmAxQgQgSAAgfQABgcARgSQAQgTAXAAQAZABAOAQQANAQgBAcIAAAJIhXAAQABAVALALQAKAMASAAQAVAAASgPIAAATQgRANgbAAQgZAAgPgRgAgUgmQgKALgDAQIBDAAQAAgRgIgKQgIgJgPAAQgNgBgKAKg");
	this.shape_4.setTransform(89.15,22.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AggA/IAAh8IAUAAIAAAaIABAAQAEgNAIgHQAIgIALAAQAJABADABIAAAVQgFgEgJgBQgNAAgIANQgJAMAAAUIAAA/g");
	this.shape_5.setTransform(79.5,22.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgPBeIAAhrIgWAAIAAgRIAWAAIAAgVQAAgTALgMQAKgLARAAQAJAAAGACIAAASQgGgDgIAAQgVAAAAAaIAAAUIAeAAIAAARIgeAAIAABrg");
	this.shape_6.setTransform(70.825,19.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4B4A4A").s().p("AgsAwQgRgRAAgeQAAgeASgSQARgRAcgBQAcAAAQASQAQARAAAeQAAAdgRATQgRASgcAAQgbgBgRgRgAgdgjQgLAOAAAVQAAAXALANQAMANASAAQATAAALgNQAKgMAAgYQAAgWgKgNQgLgMgTAAQgTgBgLANg");
	this.shape_7.setTransform(52.225,22.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4B4A4A").s().p("AgJBcIAAi3IATAAIAAC3g");
	this.shape_8.setTransform(41.9,19.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4B4A4A").s().p("AgJBcIAAi3IATAAIAAC3g");
	this.shape_9.setTransform(35.85,19.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4B4A4A").s().p("AgmAxQgQgSAAgfQABgcAQgSQARgTAYAAQAYABAOAQQAMAQAAAcIAAAJIhWAAQAAAVALALQALAMARAAQAWAAARgPIAAATQgQANgbAAQgaAAgPgRgAgUgmQgKALgCAQIBCAAQAAgRgIgKQgJgJgOAAQgNgBgKAKg");
	this.shape_10.setTransform(26.35,22.75);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4B4A4A").s().p("AAtBXIAAhQIhZAAIAABQIgVAAIAAitIAVAAIAABMIBZAAIAAhMIAVAAIAACtg");
	this.shape_11.setTransform(10.875,20.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textWrong1, new cjs.Rectangle(0,0,143.3,37.3), null);


(lib.textCorrect2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgIBVQgFgEAAgGQAAgFAFgEQAEgEAEgBQAGABAEAEQADAEAAAFQAAAGgDAEQgEADgGAAQgEAAgEgDgAgHAlIgCh8IATAAIgCB8g");
	this.shape.setTransform(85.8,20.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgoA6IAAgWQAQANATAAQAaAAAAgSQAAgFgCgDIgGgHQgEgCgFgCIgKgFIgPgHQgHgCgEgEQgEgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAHgEQAGgFAJgCQAJgCAIgBQAQABANAFIAAAVQgOgKgSABQgEgBgFACQgFABgDACQgDADgBADQgDADAAAEQAAAFADADQABADADADIAIAFIALAEIAPAHQAGACAFAEQAEAEADAGQADAFgBAIQAAAJgDAHQgFAHgGAFQgIAEgIACQgJADgJAAQgTAAgOgIg");
	this.shape_1.setTransform(77.05,22.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AgsAwQgRgRAAgeQAAgeASgSQARgRAcgBQAcAAAQASQAQARAAAeQAAAdgRATQgRASgcAAQgbgBgRgRgAgdgjQgLAOAAAVQAAAXALANQAMANASAAQATAAALgNQAKgMAAgYQAAgWgKgNQgLgMgTAAQgTgBgLANg");
	this.shape_2.setTransform(64.325,22.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgwBVIAAgUQAVALAUAAQAtAAAAgxIAAgNIgBAAQgOAYgcAAQgXgBgOgQQgPgRAAgbQAAggAQgTQAPgSAagBQAZAAAMAVIABAAIAAgSIAUAAIAAByQAABFhBABQgXgBgSgIgAgag+QgKAOAAAYQAAAUAKAMQAKANAQAAQARAAAKgNQALgLAAgSIAAgSQAAgQgKgKQgKgKgPAAQgSAAgLANg");
	this.shape_3.setTransform(49.225,25.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgJBbIAAh8IATAAIAAB8gAgIhEQgEgEAAgFQAAgGAEgEQADgDAFAAQAFAAAEADQAEAEAAAGQAAAFgEAEQgEAEgFAAQgFAAgDgEg");
	this.shape_4.setTransform(39.3,19.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("ABEBAIAAhHQAAgUgGgKQgGgJgPAAQgNAAgJAMQgJAMAAAQIAABGIgTAAIAAhJQAAglgdAAQgNAAgIALQgJALAAASIAABGIgUAAIAAh8IAUAAIAAAUIABAAQANgXAZAAQANAAAKAHQAIAIAEALQAOgaAbAAQAqAAAAAzIAABMg");
	this.shape_5.setTransform(25.625,22.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgmA3QgKgJAAgQQAAgjApgFIAkgGQAAgfgZAAQgWAAgSAPIAAgVQASgMAXAAQAsAAAAAvIAABQIgUAAIAAgTIAAAAQgNAWgYABQgTAAgLgLgAAAAEQgOACgHAEQgHAGAAAMQAAAJAHAGQAGAGALAAQAOAAAKgLQAJgLAAgPIAAgMg");
	this.shape_6.setTransform(8.025,22.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textCorrect2, new cjs.Rectangle(0,0,91.6,37.3), null);


(lib.textCorrect1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4B4A4A").s().p("AgpA6IAAgWQARANATAAQAaAAAAgSQAAgFgCgDIgGgHQgEgCgGgCIgKgFIgOgHQgGgCgFgEQgEgEgCgGQgCgFAAgIQAAgIAEgHQAEgHAHgEQAGgFAJgCQAIgCAJgBQAQABANAFIAAAVQgOgKgSABQgFgBgEACQgEABgEACQgDADgBADQgCADAAAEQAAAFACADQABADADADIAIAFIALAEIAOAHQAIACAEAEQAEAEADAGQACAFAAAIQAAAJgEAHQgEAHgGAFQgIAEgIACQgJADgJAAQgTAAgPgIg");
	this.shape.setTransform(71.85,22.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4B4A4A").s().p("AgqBNQgPgRAAgdQAAgeAQgSQAQgTAZAAQAZAAAMAVIABAAIAAhOIAUAAIAAC4IgUAAIAAgVIgBAAQgOAYgcAAQgXAAgOgRgAgagFQgKAMAAAXQAAAWAKANQAKAMAQAAQARAAAKgMQALgMAAgTIAAgSQAAgPgKgJQgKgLgQAAQgRAAgLAOg");
	this.shape_1.setTransform(58.675,19.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4B4A4A").s().p("AAgBAIAAhGQAAgogdAAQgOAAgKAMQgKAKAAASIAABGIgUAAIAAh8IAUAAIAAAVIABAAQAOgYAaAAQAUAAALANQALANAAAZIAABMg");
	this.shape_2.setTransform(44.825,22.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4B4A4A").s().p("AgmAxQgPgSAAgfQAAgcAQgSQARgTAYAAQAYABANAQQAOAQAAAcIAAAJIhXAAQAAAVAKALQAMAMARAAQAVAAASgPIAAATQgQANgbAAQgaAAgPgRgAgUgmQgKALgCAQIBCAAQAAgRgIgKQgIgJgPAAQgNgBgKAKg");
	this.shape_3.setTransform(31.15,22.75);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4B4A4A").s().p("AgJBbIAAh8IATAAIAAB8gAgIhEQgEgEAAgFQAAgGAEgEQAEgDAEAAQAGAAADADQAEAEAAAGQAAAFgEAEQgDAEgGAAQgEAAgEgEg");
	this.shape_4.setTransform(21.55,19.875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4B4A4A").s().p("AgfA/IAAh8IAUAAIAAAaIAAAAQAEgNAIgHQAJgIALAAQAIABAEABIAAAVQgGgEgKgBQgNAAgHANQgIAMAAAUIAAA/g");
	this.shape_5.setTransform(15.1,22.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4B4A4A").s().p("AgPBeIAAhrIgWAAIAAgRIAWAAIAAgVQAAgTALgMQAKgLARAAQAJAAAGACIAAASQgGgDgIAAQgVAAAAAaIAAAUIAeAAIAAARIgeAAIAABrg");
	this.shape_6.setTransform(6.425,19.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.textCorrect1, new cjs.Rectangle(0,0,79.3,37.3), null);


(lib.interfaceDropdown = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#707070").ss(1,1,1).p("ArEmTIWJAAIAAMnI2JAAg");
	this.shape.setTransform(70.875,40.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ArEGUIAAsnIWJAAIAAMng");
	this.shape_1.setTransform(70.875,40.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropdown, new cjs.Rectangle(-1,-1,143.8,82.8), null);


(lib.interfaceClosebtn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AAAAAIgsAtAgsgsIAsAsAAtgsIgtAsIAtAt");
	this.shape.setTransform(4.5,4.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceClosebtn, new cjs.Rectangle(-1,-1,11,11), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tile_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.mask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.interfaceWhiteBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A1GM4IAA5vMAqMAAAIAAZvg");
	this.shape.setTransform(135.05,82.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceWhiteBg, new cjs.Rectangle(0,0,270.1,164.8), null);


(lib.interfaceReference = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,285,249.5);


(lib.interfaceBrowserWindowAngled = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.newBGpngcopy();
	this.instance.setTransform(-100.6,-121.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceBrowserWindowAngled, new cjs.Rectangle(-100.6,-121.4,926,682), null);


(lib.interfaceVector = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// interface elements vector
	this.instance = new lib.interfaceClosebtn();
	this.instance.setTransform(537.55,18.1,0.6111,0.8919,0,0,0,0.1,0.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AU7SRIgBgFIAAgXIgFAAIAAgFIAFAAIAAgKIAHAAIAAAKIAFAAIAAAFIgFAAIAAAVIAAADIABABIAEgBIAAAFIgFABQgFAAgBgCgAUWSQQgFgDAAgGIAGgBQAAAEAEACQACACAEAAQAHAAAAgGQABgDgHgBIgKgDQgGgCABgGQAAgFADgCQAEgDAFAAQAFAAAEADQAGADAAAFIgHABQAAgDgCgCQgCgCgEAAQgHAAAAAFQAAADAGABIALADQAFADABAFQgBAFgEADQgEADgGAAQgGAAgEgDgATsSOQgEgFAAgIQAAgIAEgFQAFgFAIAAQAHAAAEAFQAFAFAAAIQAAAIgFAFQgEAFgHAAQgIAAgFgFgATwR4QgCAEAAAFQAAAFACAEQACAEAHAAQAFAAADgEQACgEAAgFQAAgFgCgEQgDgEgFAAQgHAAgCAEgAS7SSIAAgyIAZAAQAEAAAEADQAEAEAAAHQAAAHgEAEQgEADgFAAIgSAAIAAAWgATBR3IAPAAQAKAAAAgJQAAgIgJAAIgQAAgAwkxRIAAgyIAFAAIAAAFQACgDADgBQADgCADAAQAFAAADADQAEACACAEQABAFAAAFQAAAFgBAFQgCAEgEADQgEACgEAAQgDAAgCgBIgFgEIAAASgAwcx7QgDADAAAHQAAAHADAEQAEADADAAQAEAAAEgDQACgEAAgHQAAgHgCgEQgEgDgEAAQgDAAgEAEgAvUxhQgEgDAAgGIAGgBQABAEACACQACACAEAAQAEAAACgCQABAAAAgBQABAAAAAAQAAgBAAgBQABAAAAgBQAAAAgBgBQAAAAAAgBQAAAAgBAAQAAgBgBAAIgFgCIgKgDQgCgBgCgDQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBIADgDIAEgCIAFgBIAHABQAEACACACIABAFIgGABQAAgDgCgBQgCgCgDAAQgFAAgBACQgBAAAAAAQgBABAAAAQAAAAAAABQAAAAAAABIABACIABACIAGABIAKADIADADQACACAAAEQAAADgCACQgCADgDACQgEABgEAAQgHAAgEgDgAv7xjQgEgFAAgJQAAgKAFgFQAFgEAHAAQAIAAAEAFQAFAFAAAJQAAAHgDAEQgBAEgFACQgEACgEAAQgIAAgFgFgAv2x7QgDADAAAHQAAAHADAEQADADAFAAQAEAAADgDQAEgEAAgHQAAgHgEgDQgDgEgEAAQgFAAgDAEgAxexhQgCgDAAgEIABgFIADgEIAFgCIAFgBIALgCIAAgBQAAgEgCgCQgDgCgEAAQgEAAgCACQgCABgBAEIgGgBQAAgEACgCQACgCAEgCIAIgBIAIABIAEADIABAEIABAGIAAAIIAAALIACAEIgGAAIgBgEQgEADgDABQgDABgEAAQgGAAgEgDgAxSxvIgEACIgDACIgBADQAAAAAAABQAAAAAAABQABAAAAABQAAAAABABQACABADAAQAEAAACgBQADgCACgDIABgGIAAgCIgLACgAyWxjQgFgFAAgJQAAgJAFgFQAFgFAHAAQAHAAAFAFQAEAFAAAJIAAACIgaAAQAAAGADADQADADAEAAQAEAAACgCQACgCACgDIAGAAQgBAGgFADQgDADgHAAQgHAAgFgFgAyRx8QgDADAAAFIAUAAQAAgFgDgCQgCgEgFAAQgEAAgDADgAzTxhQgCgDAAgEIABgFIADgEIAFgCIAFgBIALgCIAAgBQAAgEgCgCQgDgCgEAAQgEAAgCACQgCABgBAEIgGgBQAAgEACgCQACgCAEgCIAIgBIAIABIAEADIABAEIABAGIAAAIIAAALIACAEIgGAAIgBgEQgEADgDABQgDABgEAAQgGAAgEgDgAzHxvIgEACIgDACIgBADQAAAAAAABQAAAAAAABQABAAAAABQAAAAABABQACABADAAQAEAAADgBQACgCACgDIABgGIAAgCIgLACgAz4xjQgFgFAAgJQABgJAEgFQAFgFAHAAQAIAAAFAFQAEAFAAAJIAAACIgbAAQAAAGAEADQADADAEAAQADAAACgCQADgCABgDIAHAAQgCAGgEADQgEADgGAAQgIAAgFgFgAzyx8QgEADAAAFIAUAAQAAgFgCgCQgDgEgFAAQgDAAgDADgA07xhQgFgDgDgHQgDgGAAgHQAAgIAEgGQADgGAFgDQAGgDAGAAQAHAAAGAEQAFAEACAHIgHABQgCgFgCgDQgEgCgFAAQgGAAgDADQgEACgCAFQgBAFgBAFQABAGABAFQACAFAEACQAEACAFAAQAFAAAEgDQAEgDABgGIAHABQgCAJgGAEQgFAEgIAAQgIAAgFgDgAuuxfQgBAAAAgBQgBAAAAAAQAAgBgBAAQAAgBAAAAQgBgCAAgFIAAgVIgEAAIAAgFIAEAAIAAgJIAHgEIAAANIAGAAIAAAFIgGAAIAAAVIAAADIABACIACAAIADAAIABAFIgFABIgFgBgAyoxfQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAQgCgCAAgFIAAgVIgEAAIAAgFIAEAAIAAgJIAHgEIAAANIAGAAIAAAFIgGAAIAAAVIAAADIABACIADAAIACAAIABAFIgFABIgFgBgA0SxfIAAgkIAGAAIAAAFIADgFIAFgBQADAAADACIgDAGQAAgBgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAgBAAQAAAAgBABIgCADIgBAHIAAATg");
	this.shape.setTransform(395.45,136.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AQoTVQgVAAAAgXIAAiKQAAgYAVAAIE0AAQAVAAAAAYIAACKQAAAXgVAAgAT0RpIAFAAIAAAXIABAFQABACAEAAIAGgBIAAgFIgEABIgCgBIAAgDIAAgVIAGAAIAAgFIgGAAIAAgKIgGAAIAAAKIgFAAgATPR7QABAGAFADQADADAHAAQAFAAAFgDQAEgDAAgFQAAgFgFgDIgMgDQgFgBAAgDQAAgFAHAAQADAAACACQADACAAADIAGgBQAAgFgFgDQgFgDgEAAQgGAAgDADQgEACAAAFQAAAGAGACIAKADQAGABAAADQAAAGgHAAQgFAAgCgCQgDgCAAgEgASrRoQgFAFAAAIQAAAIAFAFQAEAFAIAAQAHAAAFgFQAEgFAAgIQAAgIgEgFQgFgFgHAAQgIAAgEAFgAR5SGIAGAAIAAgWIASAAQAFAAAEgDQAFgEAAgHQAAgHgFgEQgDgDgFAAIgZAAgASuR+QgCgEAAgFQAAgFACgEQADgEAGAAQAFAAADAEQACAEAAAFQAAAFgCAEQgDAEgFAAQgGAAgDgEgAR/RrIAAgRIARAAQAJAAAAAIQAAAJgKAAgA3bw0IAAigMAu3AAAIAACggAxlxdIAGAAIAAgSIAEAEQACABAEAAQADAAAFgCQADgDACgEQACgFAAgFQAAgFgCgFQgCgEgDgCQgEgDgEAAQgEAAgDACQgCABgCADIAAgFIgFAAgAwax2QABAGAEADQAEADAGAAQAFAAADgBQADgCADgDQACgCAAgDQgBgEgBgCIgEgDIgKgDIgFgBIgCgCIgBgCQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAAAAAQABgCAFAAQAEAAACACQABABABADIAGgBIgCgFQgBgCgEgCIgHgBIgGABIgEACIgCADQgBABAAAAQAAABgBAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQABABAAAAQAAABABAAQABADACABIAKADIAGACQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABgBABQAAAAAAAAQgBABAAAAQgCACgFAAQgDAAgDgCQgCgCgBgEgAw7yMQgFAFgBAKQABAJAEAFQAEAFAIAAQAFAAAEgCQAEgCACgEQACgEABgHQAAgJgGgFQgEgFgIAAQgGAAgFAEgAyKyJQABACAAAEIAAABIgKACIgGABIgEACIgEAEIgBAFQAAAEADADQADADAHAAQADAAADgBQADgBAEgDIABAEIAGAAIgBgEIAAgLIAAgIIgBgGIgBgEIgFgDIgIgBIgIABQgDACgCACQgCACgBAEIAGABQABgEACgBQACgCAEAAQAFAAADACgAzYyLQgEAFAAAJQgBAJAFAFQAFAFAIAAQAGAAAEgDQAFgDABgGIgGAAQgCADgDACQgCACgDAAQgEAAgDgDQgDgDgBgGIAbAAIAAgCQAAgJgEgFQgFgFgHAAQgIAAgFAFgAz/yJQABACAAAEIAAABIgKACIgGABIgEACIgEAEIgBAFQAAAEADADQADADAHAAQADAAADgBQADgBAEgDIABAEIAGAAIgBgEIAAgLIAAgIIgBgGIgBgEIgFgDIgIgBIgIABQgDACgCACQgCACgBAEIAGABQABgEACgBQACgCAEAAQAFAAADACgA05yLQgFAFAAAJQAAAJAEAFQAFAFAJAAQAFAAAEgDQAFgDACgGIgHAAQgCADgCACQgCACgDAAQgFAAgDgDQgDgDAAgGIAbAAIAAgCQAAgJgFgFQgFgFgHAAQgIAAgEAFgA18ybQgFADgDAGQgDAGAAAIQAAAHACAGQAEAHAEADQAFADAIAAQAJAAAFgEQAFgEADgJIgIgBQAAAGgFADQgEADgFAAQgEAAgFgCQgEgCgBgFQgCgFAAgGQAAgFACgFQABgFAEgCQADgDAGAAQAGAAADACQADADACAFIAHgBQgCgHgFgEQgGgEgIAAQgGAAgGADgAv4yKIAFAAIAAAVQAAAFABACQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAIAGABIAEgBIgBgFIgCAAIgCAAIgCgCIAAgDIAAgVIAGAAIAAgFIgGAAIAAgNIgGAEIAAAJIgFAAgAzyyKIAFAAIAAAVQAAAFABACQAAAAAAABQABAAAAABQAAAAABAAQAAABAAAAIAGABIAEgBIgBgFIgCAAIgCAAIgBgCIAAgDIAAgVIAFAAIAAgFIgFAAIAAgNIgHAEIAAAJIgFAAgA1TxrIAFAAIAAgTIABgHIADgDQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQABAAAAABIADgGQgEgCgDAAIgEABIgEAFIAAgFIgFAAgAw4xyQgCgEAAgHQAAgHACgDQAEgEAEAAQAFAAADAEQADADAAAHQAAAHgDAEQgDADgFAAQgEAAgEgDgAxdxyQgDgEAAgHQAAgHADgDQADgEAEAAQAEAAADADQADAEAAAHQAAAHgDAEQgDADgEAAQgEAAgDgDgAyaxwQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAIABgDIADgCIAFgCIAKgCIAAACIgBAGQgBADgDACQgCABgEAAQgEAAgCgBgA0PxwQAAgBAAAAQgBgBAAAAQAAgBAAAAQgBgBAAAAIABgDIADgCIAFgCIAKgCIAAACIgBAGQgBADgDACQgCABgEAAQgEAAgCgBgAzVyAQAAgFADgDQACgDAFAAQAFAAACAEQACACABAFgA03yAQAAgFADgDQADgDAEAAQAFAAADAEQABACABAFg");
	this.shape_1.setTransform(402,137.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	// bg outline vector
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#707070").ss(1,1,1).p("A3gzgMAvBAAAMAAAAnBMgvBAAAg");
	this.shape_2.setTransform(402,138.825);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	// bg white vector
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A3gDJIAAmRMAvBAAAIAAGRg");
	this.shape_3.setTransform(402,34.075);

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceVector, new cjs.Rectangle(250.5,13,303,251.7), null);


(lib.interfaceDropDownText3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// microsoft editor
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0378B4").s().p("AgHAPIAAgdIAFAAIAAAGIAAAAQABgDABgBQABgBAAAAQABAAAAgBQABAAABAAQAAAAABAAIADAAIAAAFIgEgBQgDAAgBADQgCADAAAEIAAAPg");
	this.shape.setTransform(102.275,55.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_1.setTransform(99.275,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0378B4").s().p("AgDALIAAgRIgFAAIAAgEIAFAAIAAgHIAEgCIAAAJIAIAAIAAAEIgIAAIAAAQIABAFIADABIAEgBIAAAEIgFABQgHAAAAgJg");
	this.shape_2.setTransform(96.525,55.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0378B4").s().p("AgBAWIAAgdIADAAIAAAdgAgBgPIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_3.setTransform(94.775,55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0378B4").s().p("AgKATQgDgFAAgHQAAgGAEgEQAEgFAFABQAGgBADAFIAAgTIAFAAIAAAsIgFAAIAAgFQgEAFgGAAQgFAAgEgDgAgFgBQgDADAAAFQAAAGACACQADAEADAAQAEAAACgDQADgDAAgEIAAgFQAAgEgCgBQgDgCgEgBQgDAAgCADg");
	this.shape_4.setTransform(92.175,55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0378B4").s().p("AgKAVIAAgpIAUAAIAAAFIgPAAIAAANIAOAAIAAAEIgOAAIAAAPIAQAAIAAAEg");
	this.shape_5.setTransform(89.125,55.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0378B4").s().p("AgDALIAAgRIgFAAIAAgEIAFAAIAAgHIAEgCIAAAJIAIAAIAAAEIgIAAIAAAQIABAFIADABIAEgBIAAAEIgFABQgHAAAAgJg");
	this.shape_6.setTransform(84.775,55.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0378B4").s().p("AgDAXIAAgZIgFAAIAAgFIAFAAIAAgEQAAgFADgDQACgCADAAIAEAAIAAAEIgDgBQgFABAAAGIAAAEIAHAAIAAAFIgHAAIAAAZg");
	this.shape_7.setTransform(82.8,54.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_8.setTransform(80.125,55.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0378B4").s().p("AgJAOIAAgFQAEADAEAAQAGAAAAgFIAAgCIgCgBIgCgBIgCgBIgDgCIgDgBIgCgCIAAgDIABgEIACgCIAFgCIACAAIAHABIAAAEQgDgCgEAAIgCAAIgBABIgBACIgBACIABACIABABIABABIACABIAEABIACACIACACIABADIgBAEIgCADIgFABIgDAAQgEABgEgCg");
	this.shape_9.setTransform(77.1,55.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_10.setTransform(74.075,55.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0378B4").s().p("AgHAPIAAgdIAFAAIAAAGIAAAAQABgDABgBQABgBAAAAQABAAAAgBQABAAABAAQAAAAABAAIADAAIAAAFIgEgBQgDAAgBADQgCADAAAEIAAAPg");
	this.shape_11.setTransform(71.575,55.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0378B4").s().p("AgGAMQgEgFAAgHQAAgFAEgFQAEgFAGABQAEAAADABIAAAEQgDgCgEAAQgEAAgDADQgDAEAAAEQAAAGADACQADAEAEAAQAEAAADgDIAAAFQgDABgFAAQgGAAgDgDg");
	this.shape_12.setTransform(68.975,55.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0378B4").s().p("AgBAWIAAgdIADAAIAAAdgAgBgPIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_13.setTransform(66.825,55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0378B4").s().p("AARAVIAAgbIAAgJIAAAAIgBAEIgPAgIgBAAIgPgfIgBgFIAAAJIAAAbIgEAAIAAgpIAGAAIANAdIABAEIACgFIANgcIAGAAIAAApg");
	this.shape_14.setTransform(63.4,55.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// text
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AAIAlIAAgcQABgLgJAAQgDABgCACQgDACAAAGIAAAcIgPAAIAAhJIAPAAIAAAfQAHgIAIAAQARAAAAATIAAAfg");
	this.shape_15.setTransform(30.85,53.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgSAYIAAgNIAIAEIAHABIAFgBQABgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgBIgEgBIgFgDIgEgCIgCgEIgBgFQAAgEACgEIAFgEIAHgEIAHAAIAHAAIAGACIAAAMIgGgDIgHgBIgCAAIgCABIgBACIgBACIABACIACABIACACIAEABIAFADIAFABIACAEIABAFQAAAFgCAEIgFAFIgHADIgIAAQgIAAgHgCg");
	this.shape_16.setTransform(25.625,54.95);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgDAAgDQAAgDADgCQACgDADAAQAEAAADADQACACAAADQAAADgCADQgDACgEAAQgDAAgCgCg");
	this.shape_17.setTransform(21.975,53.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAYAZIAAgbQAAgLgIAAQgEAAgCADQgCAEAAAEIAAAbIgPAAIAAgcQAAgKgIAAQgEAAgCADQgCAEAAAEIAAAbIgQAAIAAgwIAQAAIAAAIQACgEAFgDQAEgCAFAAQAKAAAEAJQAFgJALAAQARgBAAAVIAAAdg");
	this.shape_18.setTransform(16.025,54.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgSAWQgEgEAAgHQABgNARgDIAMgCQAAgHgIgBQgIABgJAFIAAgMIAJgDIAJgBQAWAAAAAVIAAAdIgPAAIAAgHQgFAIgJAAQgHAAgFgEgAAAACQgIACABAFQAAABAAABQAAAAAAABQAAAAABABQAAAAABABQABACADAAQAEAAACgEQADgDAAgEIAAgEg");
	this.shape_19.setTransform(8.55,54.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAIgCgCIgDgCIgEgBIgFgCIgEgCIgCgEIgBgFQAAgFACgCIAFgGIAHgCIAHgBIAHABIAGABIAAALIgGgCIgHgBIgCAAIgCABIgBABIgBACIABADIACACIACABIAEABIAFACIAFACIACAEIABAGQAAAEgCAEIgFAEIgHAEIgIAAQgIAAgHgDg");
	this.shape_20.setTransform(30.025,40.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAIgCgCIgDgCIgEgBIgFgCIgEgCIgCgEIgBgFQAAgFACgCIAFgGIAHgCIAHgBIAHABIAGABIAAALIgGgCIgHgBIgCAAIgCABIgBABIgBACIABADIACACIACABIAEABIAFACIAFACIACAEIABAGQAAAEgCAEIgFAEIgHAEIgIAAQgIAAgHgDg");
	this.shape_21.setTransform(25.625,40.7);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgDAAgDQAAgEADgBQACgDADAAQAEAAADADQACABAAAEQAAADgCADQgDACgEAAQgDAAgCgCg");
	this.shape_22.setTransform(21.975,39.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCADQgCAEAAAFIAAAbIgPAAIAAgcQAAgLgIAAQgEAAgCADQgCAEAAAFIAAAbIgQAAIAAgyIAQAAIAAAIQACgEAFgCQAEgDAFAAQAKABAEAIQAFgIALgBQARAAAAAVIAAAeg");
	this.shape_23.setTransform(16.025,40.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgSAWQgEgEAAgHQABgOARgCIAMgBQAAgJgIAAQgIAAgJAGIAAgMIAJgDIAJgBQAWAAAAAVIAAAdIgPAAIAAgHQgFAIgJAAQgHAAgFgEgAAAADQgIAAABAHQAAAAAAABQAAAAAAABQAAAAABABQAAAAABAAQABACADAAQAEAAACgDQADgCAAgGIAAgCg");
	this.shape_24.setTransform(8.55,40.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgCIgEAAIgFgDIgEgCIgCgEIgBgGQAAgDACgEIAFgEIAHgDIAHgBIAHABIAGABIAAALIgGgCIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAFQAAAFgCADIgFAGIgHACIgIABQgIAAgHgDg");
	this.shape_25.setTransform(25.625,26.45);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgCAAgEQAAgEADgCQACgCADAAQAEAAADACQACACAAAEQAAAEgCACQgDACgEAAQgDAAgCgCg");
	this.shape_26.setTransform(21.975,25.25);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCAEQgCACAAAGIAAAbIgPAAIAAgdQAAgKgIAAQgEAAgCADQgCADAAAGIAAAbIgQAAIAAgyIAQAAIAAAJQACgEAFgDQAEgCAFAAQAKgBAEAKQAFgKALABQARAAAAATIAAAfg");
	this.shape_27.setTransform(16.025,26.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgSAWQgEgEAAgHQABgOARgBIAMgCQAAgIgIAAQgIAAgJAEIAAgLIAJgDIAJgBQAWAAAAAVIAAAdIgPAAIAAgHQgFAIgJAAQgHAAgFgEgAAAADQgIABABAFQAAABAAABQAAAAAAABQAAAAABABQAAAAABABQABABADAAQAEAAACgCQADgDAAgFIAAgDg");
	this.shape_28.setTransform(8.55,26.45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#A7A4A4").s().p("AgPATQgGgHAAgMQAAgKAHgIQAHgHAIAAQAKAAAFAGQAGAGAAAMIAAADIgjAAQABAIAEAFQAEAFAHgBQAIABAIgGIAAAHQgIAFgKAAQgKAAgGgHgAgHgPQgFAFgBAGIAaAAQAAgGgCgFQgEgDgGAAQgEAAgEADg");
	this.shape_29.setTransform(59.05,12.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#A7A4A4").s().p("AANAlIAAgdQAAgOgMAAQgFAAgEAEQgEADAAAIIAAAcIgIAAIAAhJIAIAAIAAAgIABAAQAFgJAKAAQARAAAAATIAAAfg");
	this.shape_30.setTransform(53.625,11);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#A7A4A4").s().p("AgWAlIAAhIIAIAAIAAAJIAAAAQAGgKAKAAQAKAAAGAHQAFAGAAAMQAAALgGAHQgGAIgKAAQgJAAgGgIIAAAAIAAAegAgJgZQgFAFAAAIIAAAHQAAAFAEAEQAEAFAGgBQAGABAFgGQAEgEAAgKQAAgJgEgFQgEgEgGAAQgHAAgDAEg");
	this.shape_31.setTransform(48,13.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#A7A4A4").s().p("AgPAWQgEgDAAgIQAAgNARgBIAOgDQAAgNgLABQgIgBgHAHIAAgIQAHgFAJAAQASAAAAASIAAAgIgIAAIAAgIIgBAAQgFAJgJAAQgHAAgFgEgAAAABQgFABgDACQgDACAAAFQAAAEADACQADADAEgBQAFAAAEgDQAEgFAAgGIAAgFg");
	this.shape_32.setTransform(42.225,12.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#A7A4A4").s().p("AgMAZIAAgwIAIAAIAAAKIABAAQABgGACgDQAEgCAEAAIAFABIAAAIQgCgCgEAAQgFAAgDAFQgDAEAAAIIAAAZg");
	this.shape_33.setTransform(38.4,12.15);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#A7A4A4").s().p("AgTAiIAAgIQAJAEAIAAQARAAAAgTIAAgGIAAAAQgGAKgKAAQgKAAgFgHQgGgGAAgLQAAgMAGgIQAGgHAKAAQAKAAAFAIIAAAAIAAgHIAIAAIAAAtQAAAbgZAAQgKAAgHgDgAgKgYQgEAFAAAKQAAAIAEAEQAEAFAGAAQAHAAAEgFQAEgDAAgIIAAgHQAAgGgEgEQgEgFgGAAQgGAAgFAGg");
	this.shape_34.setTransform(33.225,13.325);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#A7A4A4").s().p("AgRATQgHgHAAgMQAAgLAHgHQAHgHALAAQALAAAGAHQAHAGAAAMQAAAMgHAHQgHAHgLAAQgKAAgHgHgAgLgNQgEAFAAAIQAAAJAEAGQAFAEAGAAQAIAAAEgEQAEgGAAgJQAAgIgEgGQgEgEgIAAQgGAAgFAFg");
	this.shape_35.setTransform(27.575,12.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#A7A4A4").s().p("AANAlIAAgdQAAgOgMAAQgFAAgEAEQgEADAAAIIAAAcIgIAAIAAhJIAIAAIAAAgIABAAQAFgJAKAAQARAAAAATIAAAfg");
	this.shape_36.setTransform(21.875,11);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#A7A4A4").s().p("AgFASIAAgcIgJAAIAAgHIAJAAIAAgMIAHgDIAAAPIANAAIAAAHIgNAAIAAAbQAAAFACACQABADAEgBQADAAADgCIAAAIQgDABgFAAQgMAAAAgPg");
	this.shape_37.setTransform(17.275,11.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A7A4A4").s().p("AgMAZIAAgwIAIAAIAAAKIAAAAQACgGACgDQAEgCAFAAIAEABIAAAIQgCgCgEAAQgFAAgCAFQgEAEAAAIIAAAZg");
	this.shape_38.setTransform(13.9,12.15);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#A7A4A4").s().p("AgRATQgHgHAAgMQAAgLAHgHQAHgHALAAQALAAAGAHQAHAGAAAMQAAAMgHAHQgHAHgLAAQgKAAgHgHgAgLgNQgEAFAAAIQAAAJAEAGQAFAEAGAAQAIAAAEgEQAEgGAAgJQAAgIgEgGQgEgEgIAAQgGAAgFAFg");
	this.shape_39.setTransform(8.925,12.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]}).wait(1));

	// bg
	this.instance = new lib.interfaceDropdown();
	this.instance.setTransform(53.8,31.4,0.7567,0.7663,0,0,0,70.7,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.interfaceDropdownShadow_1();
	this.instance_1.setTransform(54,32,0.564,0.5712,0,0,0,109.8,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropDownText3, new cjs.Rectangle(-7.9,-8,124.10000000000001,80), null);


(lib.interfaceDropDownText2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgSAYIAAgNIAIAEIAHABIAFgBQABgBAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgBIgEgBIgFgDIgEgCIgCgEIgBgFQAAgEACgEIAFgEIAHgEIAHAAIAHAAIAGACIAAAMIgGgDIgHgBIgCAAIgCABIgBACIgBACIABACIACABIACACIAEABIAFADIAFABIACAEIABAFQAAAFgCAEIgFAFIgHADIgIAAQgIAAgHgCg");
	this.shape.setTransform(42.275,54.95);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgRATQgGgGAAgMQAAgLAHgIQAHgHAKAAQALAAAGAHQAGAGAAALIAAAGIggAAQABAKAMABQAJAAAFgFIAAAMQgGADgMAAQgKAAgIgHgAgFgLQgCADgBAEIARAAQAAgLgIAAQgDAAgDAEg");
	this.shape_1.setTransform(37.4,54.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgXAEIAAgcIAPAAIAAAbQAAALAIAAQAEAAACgDQADgDAAgFIAAgbIAPAAIAAAwIgPAAIAAgHQgGAJgJgBQgRABAAgWg");
	this.shape_2.setTransform(31.575,55);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgUAiIAAgNQAHAFAIAAQAHAAAFgEQADgEAAgHIAAgEQgFAIgJAAQgKAAgFgHQgGgHAAgKQAAgNAGgHQAGgHALAAQAIAAAEAHIAAgGIAQAAIAAArQAAAOgIAIQgIAHgOAAQgLAAgFgDgAgHgVQgCAEgBAIQABAGACADQAEADADAAQAFAAADgDQADgDAAgGIAAgEQAAgFgDgDQgDgEgFAAQgDAAgEAEg");
	this.shape_3.setTransform(25.35,56.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgDAAgDQAAgDADgCQACgDADAAQAEAAADADQACACAAADQAAADgCADQgDACgEAAQgDAAgCgCg");
	this.shape_4.setTransform(20.975,53.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAYAZIAAgbQAAgLgIAAQgEAAgCADQgCAEAAAEIAAAbIgPAAIAAgcQAAgKgIAAQgEAAgCADQgCAEAAAEIAAAbIgQAAIAAgwIAQAAIAAAIQACgEAFgDQAEgCAFAAQAKAAAEAJQAFgJALAAQARgBAAAVIAAAdg");
	this.shape_5.setTransform(15.025,54.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgSAWQgDgEAAgHQAAgNARgDIAMgCQAAgHgIgBQgIABgJAFIAAgMIAJgDIAJgBQAWAAAAAVIAAAdIgPAAIAAgHQgFAIgJAAQgHAAgFgEgAAAACQgIACAAAFQAAABABABQAAAAAAABQAAAAABABQAAAAABABQABACADAAQAEAAACgEQADgDAAgEIAAgEg");
	this.shape_6.setTransform(7.55,54.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBAAIgCgCIgDgCIgEgBIgFgCIgEgCIgCgEIgBgFQAAgFACgCIAFgGIAHgCIAHgBIAHABIAGABIAAALIgGgCIgHgBIgCAAIgCABIgBABIgBACIABADIACACIACABIAEABIAFACIAFACIACAEIABAGQAAAEgCAEIgFAEIgHAEIgIAAQgIAAgHgDg");
	this.shape_7.setTransform(45.075,40.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgRAUQgGgHAAgMQAAgLAHgIQAHgHAKAAQALAAAGAHQAGAGAAALIAAAFIggAAQABALAMAAQAJAAAFgEIAAALQgGAEgMAAQgLAAgHgGgAgEgMQgDAEgBAEIARAAQAAgLgIAAQgDAAgCADg");
	this.shape_8.setTransform(40.2,40.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgTATQgHgHAAgMQAAgLAHgHQAIgHALAAQANAAAHAHQAHAHAAALQAAAMgHAHQgIAHgMAAQgLAAgIgHgAgIgJQgCADAAAGQgBAOALAAQALAAAAgOQABgNgMgBQgFAAgDAFg");
	this.shape_9.setTransform(31.65,40.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgUAiIAAgNQAHAFAIAAQAHAAAFgEQADgEAAgHIAAgEQgFAIgJAAQgKAAgFgHQgGgHAAgKQAAgNAGgHQAGgHALAAQAIAAAEAHIAAgGIAQAAIAAArQAAAOgIAIQgIAHgOAAQgLAAgFgDgAgHgVQgCAEgBAIQABAGACADQAEADADAAQAFAAADgDQADgDAAgGIAAgEQAAgFgDgDQgDgEgFAAQgDAAgEAEg");
	this.shape_10.setTransform(25.35,41.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgDAAgDQAAgEADgBQACgDADAAQAEAAADADQACABAAAEQAAADgCADQgDACgEAAQgDAAgCgCg");
	this.shape_11.setTransform(20.975,39.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCADQgCAEAAAFIAAAbIgPAAIAAgcQAAgLgIAAQgEAAgCADQgCAEAAAFIAAAbIgQAAIAAgyIAQAAIAAAIQACgEAFgCQAEgDAFAAQAKABAEAIQAFgIALgBQARAAAAAVIAAAeg");
	this.shape_12.setTransform(15.025,40.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgSAWQgDgEAAgHQAAgOARgCIAMgBQAAgJgIAAQgIAAgJAGIAAgMIAJgDIAJgBQAWAAAAAVIAAAdIgPAAIAAgHQgFAIgJAAQgHAAgFgEgAAAADQgIAAAAAHQAAAAABABQAAAAAAABQAAAAABABQAAAAABAAQABACADAAQAEAAACgDQADgCAAgGIAAgCg");
	this.shape_13.setTransform(7.55,40.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgCIgEAAIgFgDIgEgCIgCgEIgBgGQAAgDACgEIAFgEIAHgDIAHgBIAHABIAGABIAAALIgGgCIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAFQAAAFgCADIgFAGIgHACIgIABQgIAAgHgDg");
	this.shape_14.setTransform(36.925,26.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgTATQgHgHAAgMQAAgLAHgHQAIgHALAAQANAAAHAHQAHAHAAALQAAAMgHAHQgIAHgMAAQgLAAgIgHgAgIgKQgCAEAAAGQgBAPALgBQALAAAAgOQABgOgMABQgFAAgDADg");
	this.shape_15.setTransform(31.65,26.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgUAiIAAgNQAHAFAIAAQAHAAAFgEQADgEAAgHIAAgEQgFAIgJAAQgKAAgFgHQgGgHAAgKQAAgNAGgHQAGgHALAAQAIAAAEAHIAAgGIAQAAIAAArQAAAOgIAIQgIAHgOAAQgLAAgFgDgAgHgVQgCAEgBAIQABAGACADQAEADADAAQAFAAADgDQADgDAAgGIAAgEQAAgFgDgDQgDgEgFAAQgDAAgEAEg");
	this.shape_16.setTransform(25.35,27.575);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgCAAgEQAAgEADgCQACgCADAAQAEAAADACQACACAAAEQAAAEgCACQgDACgEAAQgDAAgCgCg");
	this.shape_17.setTransform(20.975,25.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAYAaIAAgcQAAgLgIAAQgEAAgCAEQgCACAAAGIAAAbIgPAAIAAgdQAAgKgIAAQgEAAgCADQgCADAAAGIAAAbIgQAAIAAgyIAQAAIAAAJQACgEAFgDQAEgCAFAAQAKgBAEAKQAFgKALABQARAAAAATIAAAfg");
	this.shape_18.setTransform(15.025,26.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgSAWQgDgEAAgHQAAgOARgBIAMgCQAAgIgIAAQgIAAgJAEIAAgLIAJgDIAJgBQAWAAAAAVIAAAdIgPAAIAAgHQgFAIgJAAQgHAAgFgEgAAAADQgIABAAAFQAAABABABQAAAAAAABQAAAAABABQAAAAABABQABABADAAQAEAAACgCQADgDAAgFIAAgDg");
	this.shape_19.setTransform(7.55,26.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#A7A4A4").s().p("AgPAWQgEgDAAgIQAAgNARgBIAOgDQAAgNgLABQgIgBgHAHIAAgIQAHgFAJAAQASAAAAASIAAAgIgIAAIAAgIIgBAAQgFAJgJAAQgHAAgFgEgAAAABQgFABgDACQgDACAAAFQAAAEADACQADADAEgBQAFAAAEgDQAEgFAAgGIAAgFg");
	this.shape_20.setTransform(46.125,12.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#A7A4A4").s().p("AgFAmIAAgxIAHAAIAAAxgAgIgVIAJgQIAIAAIgLAQg");
	this.shape_21.setTransform(42.7,10.925);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#A7A4A4").s().p("AgGAlIAAgpIgIAAIAAgHIAIAAIAAgIQAAgJAFgEQADgEAHgBIAGABIAAAIQgCgCgDAAQgJAAAAALIAAAIIAMAAIAAAHIgMAAIAAApg");
	this.shape_22.setTransform(39.925,10.95);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#A7A4A4").s().p("AgPAWQgEgDAAgIQAAgNARgBIAOgDQAAgNgLABQgIgBgHAHIAAgIQAHgFAJAAQASAAAAASIAAAgIgIAAIAAgIIgBAAQgFAJgJAAQgHAAgFgEgAAAABQgFABgDACQgDACAAAFQAAAEADACQADADAEgBQAFAAAEgDQAEgFAAgGIAAgFg");
	this.shape_23.setTransform(35.475,12.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#A7A4A4").s().p("AgMAZIAAgwIAIAAIAAAKIABAAQABgGACgDQAEgCAEAAIAFABIAAAIQgCgCgEAAQgFAAgDAFQgDAEAAAIIAAAZg");
	this.shape_24.setTransform(31.65,12.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#A7A4A4").s().p("AgTAiIAAgIQAJAEAIAAQARAAAAgTIAAgGIAAAAQgGAKgKAAQgKAAgFgHQgGgGAAgLQAAgMAGgIQAGgHAKAAQAKAAAFAIIAAAAIAAgHIAIAAIAAAtQAAAbgZAAQgKAAgHgDgAgKgYQgEAFAAAKQAAAIAEAEQAEAFAGAAQAHAAAEgFQAEgDAAgIIAAgHQAAgGgEgEQgEgFgGAAQgGAAgFAGg");
	this.shape_25.setTransform(26.475,13.325);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#A7A4A4").s().p("AgRATQgHgHAAgMQAAgLAHgHQAHgHALAAQALAAAGAHQAHAGAAAMQAAAMgHAHQgHAHgLAAQgKAAgHgHgAgLgNQgEAFAAAIQAAAJAEAGQAFAEAGAAQAIAAAEgEQAEgGAAgJQAAgIgEgGQgEgEgIAAQgGAAgFAFg");
	this.shape_26.setTransform(20.825,12.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#A7A4A4").s().p("AgFASIAAgcIgJAAIAAgHIAJAAIAAgMIAHgDIAAAPIANAAIAAAHIgNAAIAAAbQAAAFACACQABADAEgBQADAAADgCIAAAIQgDABgFAAQgMAAAAgPg");
	this.shape_27.setTransform(16.275,11.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#A7A4A4").s().p("AgMAZIAAgwIAIAAIAAAKIAAAAQACgGADgDQADgCAFAAIAEABIAAAIQgCgCgEAAQgFAAgCAFQgEAEAAAIIAAAZg");
	this.shape_28.setTransform(12.9,12.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#A7A4A4").s().p("AgRATQgHgHAAgMQAAgLAHgHQAHgHALAAQALAAAGAHQAHAGAAAMQAAAMgHAHQgHAHgLAAQgKAAgHgHgAgLgNQgEAFAAAIQAAAJAEAGQAFAEAGAAQAIAAAEgEQAEgGAAgJQAAgIgEgGQgEgEgIAAQgGAAgFAFg");
	this.shape_29.setTransform(7.925,12.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// microsoft editor
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#0378B4").s().p("AgHAPIAAgdIAFAAIAAAGIAAAAQABgDABgBQABgBAAAAQABAAAAgBQABAAABAAQAAAAABAAIADAAIAAAFIgEgBQgDAAgBADQgCADAAAEIAAAPg");
	this.shape_30.setTransform(102.275,55.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_31.setTransform(99.275,55.7);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#0378B4").s().p("AgDALIAAgRIgFAAIAAgEIAFAAIAAgHIAEgCIAAAJIAIAAIAAAEIgIAAIAAAQIABAFIADABIAEgBIAAAEIgFABQgHAAAAgJg");
	this.shape_32.setTransform(96.525,55.275);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#0378B4").s().p("AgBAWIAAgdIADAAIAAAdgAgBgPIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_33.setTransform(94.775,55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#0378B4").s().p("AgKATQgDgFAAgHQAAgGAEgEQAEgFAFABQAGgBADAFIAAgTIAFAAIAAAsIgFAAIAAgFQgEAFgGAAQgFAAgEgDgAgFgBQgDADAAAFQAAAGACACQADAEADAAQAEAAACgDQADgDAAgEIAAgFQAAgEgCgBQgDgCgEgBQgDAAgCADg");
	this.shape_34.setTransform(92.175,55);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#0378B4").s().p("AgKAVIAAgpIAUAAIAAAFIgPAAIAAANIAOAAIAAAEIgOAAIAAAPIAQAAIAAAEg");
	this.shape_35.setTransform(89.125,55.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#0378B4").s().p("AgDALIAAgRIgFAAIAAgEIAFAAIAAgHIAEgCIAAAJIAIAAIAAAEIgIAAIAAAQIABAFIADABIAEgBIAAAEIgFABQgHAAAAgJg");
	this.shape_36.setTransform(84.775,55.275);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#0378B4").s().p("AgDAXIAAgZIgFAAIAAgFIAFAAIAAgEQAAgFADgDQACgCADAAIAEAAIAAAEIgDgBQgFABAAAGIAAAEIAHAAIAAAFIgHAAIAAAZg");
	this.shape_37.setTransform(82.8,54.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_38.setTransform(80.125,55.7);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#0378B4").s().p("AgJAOIAAgFQAEADAEAAQAGAAAAgFIAAgCIgCgBIgCgBIgCgBIgDgCIgDgBIgCgCIAAgDIABgEIACgCIAFgCIACAAIAHABIAAAEQgDgCgEAAIgCAAIgBABIgBACIgBACIABACIABABIABABIACABIAEABIACACIACACIABADIgBAEIgCADIgFABIgDAAQgEABgEgCg");
	this.shape_39.setTransform(77.1,55.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_40.setTransform(74.075,55.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#0378B4").s().p("AgHAPIAAgdIAFAAIAAAGIAAAAQABgDABgBQABgBAAAAQABAAAAgBQABAAABAAQAAAAABAAIADAAIAAAFIgEgBQgDAAgBADQgCADAAAEIAAAPg");
	this.shape_41.setTransform(71.575,55.675);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#0378B4").s().p("AgGAMQgEgFAAgHQAAgFAEgFQAEgFAGABQAEAAADABIAAAEQgDgCgEAAQgEAAgDADQgDAEAAAEQAAAGADACQADAEAEAAQAEAAADgDIAAAFQgDABgFAAQgGAAgDgDg");
	this.shape_42.setTransform(68.975,55.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#0378B4").s().p("AgBAWIAAgdIADAAIAAAdgAgBgPIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_43.setTransform(66.825,55);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#0378B4").s().p("AARAVIAAgbIAAgJIAAAAIgBAEIgPAgIgBAAIgPgfIgBgFIAAAJIAAAbIgEAAIAAgpIAGAAIANAdIABAEIACgFIANgcIAGAAIAAApg");
	this.shape_44.setTransform(63.4,55.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30}]}).wait(1));

	// bg
	this.instance = new lib.interfaceDropdown();
	this.instance.setTransform(53.8,31.4,0.7567,0.7663,0,0,0,70.7,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.interfaceDropdownShadow_1();
	this.instance_1.setTransform(54,32,0.564,0.5712,0,0,0,109.8,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropDownText2, new cjs.Rectangle(-7.9,-8,124.10000000000001,80), null);


(lib.interfaceDropDownText1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0378B4").s().p("AgHAPIAAgdIAFAAIAAAGIAAAAQABgDABgBQABgBAAAAQABAAAAgBQABAAABAAQAAAAABAAIADAAIAAAFIgEgBQgDAAgBADQgCADAAAEIAAAPg");
	this.shape.setTransform(102.275,55.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_1.setTransform(99.275,55.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0378B4").s().p("AgDALIAAgRIgFAAIAAgEIAFAAIAAgHIAEgCIAAAJIAIAAIAAAEIgIAAIAAAQIABAFIADABIAEgBIAAAEIgFABQgHAAAAgJg");
	this.shape_2.setTransform(96.525,55.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0378B4").s().p("AgBAWIAAgdIADAAIAAAdgAgBgPIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_3.setTransform(94.775,55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0378B4").s().p("AgKATQgDgFAAgHQAAgGAEgEQAEgFAFABQAGgBADAFIAAgTIAFAAIAAAsIgFAAIAAgFQgEAFgGAAQgFAAgEgDgAgFgBQgDADAAAFQAAAGACACQADAEADAAQAEAAACgDQADgDAAgEIAAgFQAAgEgCgBQgDgCgEgBQgDAAgCADg");
	this.shape_4.setTransform(92.175,55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0378B4").s().p("AgKAVIAAgpIAUAAIAAAFIgPAAIAAANIAOAAIAAAEIgOAAIAAAPIAQAAIAAAEg");
	this.shape_5.setTransform(89.125,55.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0378B4").s().p("AgDALIAAgRIgFAAIAAgEIAFAAIAAgHIAEgCIAAAJIAIAAIAAAEIgIAAIAAAQIABAFIADABIAEgBIAAAEIgFABQgHAAAAgJg");
	this.shape_6.setTransform(84.775,55.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0378B4").s().p("AgDAXIAAgZIgFAAIAAgFIAFAAIAAgEQAAgFADgDQACgCADAAIAEAAIAAAEIgDgBQgFABAAAGIAAAEIAHAAIAAAFIgHAAIAAAZg");
	this.shape_7.setTransform(82.8,54.95);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_8.setTransform(80.125,55.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0378B4").s().p("AgJAOIAAgFQAEADAEAAQAGAAAAgFIAAgCIgCgBIgCgBIgCgBIgDgCIgDgBIgCgCIAAgDIABgEIACgCIAFgCIACAAIAHABIAAAEQgDgCgEAAIgCAAIgBABIgBACIgBACIABACIABABIABABIACABIAEABIACACIACACIABADIgBAEIgCADIgFABIgDAAQgEABgEgCg");
	this.shape_9.setTransform(77.1,55.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0378B4").s().p("AgKAMQgEgFAAgHQAAgGAEgFQAEgDAGAAQAHAAAEADQAEAEAAAHQAAAHgEAFQgFADgGAAQgGAAgEgDgAgGgIQgDADAAAFQAAAFADADQACAEAEAAQAFAAACgEQADgDAAgFQAAgFgDgDQgCgDgFAAQgEAAgCADg");
	this.shape_10.setTransform(74.075,55.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0378B4").s().p("AgHAPIAAgdIAFAAIAAAGIAAAAQABgDABgBQABgBAAAAQABAAAAgBQABAAABAAQAAAAABAAIADAAIAAAFIgEgBQgDAAgBADQgCADAAAEIAAAPg");
	this.shape_11.setTransform(71.575,55.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0378B4").s().p("AgGAMQgEgFAAgHQAAgFAEgFQAEgFAGABQAEAAADABIAAAEQgDgCgEAAQgEAAgDADQgDAEAAAEQAAAGADACQADAEAEAAQAEAAADgDIAAAFQgDABgFAAQgGAAgDgDg");
	this.shape_12.setTransform(68.975,55.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0378B4").s().p("AgBAWIAAgdIADAAIAAAdgAgBgPIgBgCIABgDIABgBIACABIABADIgBACIgCABIgBgBg");
	this.shape_13.setTransform(66.825,55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0378B4").s().p("AARAVIAAgbIAAgJIAAAAIgBAEIgPAgIgBAAIgPgfIgBgFIAAAJIAAAbIgEAAIAAgpIAGAAIANAdIABAEIACgFIANgcIAGAAIAAApg");
	this.shape_14.setTransform(63.4,55.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgUAfQgFgGAAgMQAAgNAGgGQAHgIAKABQAIgBAFAHIAAgeIAPAAIAABJIgPAAIAAgGQgGAHgJAAQgJABgHgHgAgGABQgDAEgBAHQABAHADAEQADADADAAQAFAAADgEQADgDAAgHIAAgEQAAgEgDgEQgDgCgEAAQgFAAgCADg");
	this.shape_15.setTransform(21.7,53.8);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AAJAZIAAgbQAAgLgJAAQgDAAgCADQgDADAAAFIAAAbIgPAAIAAgwIAPAAIAAAIQAGgJAJAAQARAAAAAUIAAAdg");
	this.shape_16.setTransform(15.775,54.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgDAAgDQAAgDADgCQACgDADAAQAEAAADADQACACAAADQAAADgCADQgDACgEAAQgDAAgCgCg");
	this.shape_17.setTransform(11.275,53.75);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgJAlIAAglIgIAAIAAgLIAIAAIAAgHQAAgIAFgFQAFgGAKABIAHAAIAAAMIgFgBQgIAAABAIIAAAGIALAAIAAALIgLAAIAAAlg");
	this.shape_18.setTransform(8.05,53.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgUAfQgFgHAAgMQAAgMAGgGQAHgIAKAAQAIAAAFAHIAAgdIAPAAIAABJIgPAAIAAgIQgGAJgJgBQgJAAgHgGgAgGABQgEAEAAAHQAAAHAEADQADAEADAAQAFAAADgEQADgEAAgGIAAgDQAAgFgDgEQgDgCgFAAQgDAAgDADg");
	this.shape_19.setTransform(25.1,39.55);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgRAUQgGgHAAgMQAAgLAHgIQAHgHAKAAQALAAAGAHQAGAGAAALIAAAFIggAAQABALAMAAQAJAAAFgEIAAALQgGAEgMAAQgLAAgHgGgAgEgMQgDAEgBAEIARAAQAAgLgIAAQgDAAgCADg");
	this.shape_20.setTransform(19.5,40.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgDAAgDQAAgEADgBQACgDADAAQAEAAADADQACABAAAEQAAADgCADQgDACgEAAQgDAAgCgCg");
	this.shape_21.setTransform(15.325,39.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAKQADgLAKAAIADABIAAAOQgCgBgEAAQgFAAgDADQgCAFAAAEIAAAZg");
	this.shape_22.setTransform(12.125,40.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgJAmIAAgmIgIAAIAAgMIAIAAIAAgFQAAgJAFgGQAFgEAKAAIAHABIAAALIgFgBQgIAAABAIIAAAFIALAAIAAAMIgLAAIAAAmg");
	this.shape_23.setTransform(8.05,39.45);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgSAXIAAgMIAIADIAHABIAFgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAAAgBgBIgCgBIgDgCIgEAAIgFgDIgEgCIgCgEIgBgGQAAgDACgEIAFgEIAHgDIAHgBIAHABIAGABIAAALIgGgCIgHAAIgCAAIgCABIgBABIgBABIABADIACACIACABIAEABIAFACIAFACIACAEIABAFQAAAFgCADIgFAGIgHACIgIABQgIAAgHgDg");
	this.shape_24.setTransform(36.625,26.45);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgUAfQgFgHAAgMQAAgMAGgGQAHgHAKAAQAIAAAFAGIAAgeIAPAAIAABKIgPAAIAAgHQgGAHgJABQgJgBgHgGgAgGABQgDAEgBAHQABAHADADQADAEADAAQAFAAADgEQADgEAAgGIAAgDQAAgGgDgCQgDgDgEAAQgFAAgCADg");
	this.shape_25.setTransform(31.15,25.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AAJAaIAAgbQAAgMgJAAQgDAAgCADQgDADAAAFIAAAcIgPAAIAAgyIAPAAIAAAJQAGgKAJABQARgBAAAVIAAAeg");
	this.shape_26.setTransform(25.225,26.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgRAUQgGgHAAgMQAAgMAHgHQAHgHAKAAQALAAAGAGQAGAHAAALIAAAGIggAAQABALAMgBQAJAAAFgDIAAALQgGADgMAAQgLAAgHgGgAgEgMQgDADgBAFIARAAQAAgLgIAAQgDAAgCADg");
	this.shape_27.setTransform(19.5,26.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgHAlIAAgxIAPAAIAAAxgAgFgWQgDgCAAgEQAAgEADgCQACgCADAAQAEAAADACQACACAAAEQAAAEgCACQgDACgEAAQgDAAgCgCg");
	this.shape_28.setTransform(15.325,25.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgPAaIAAgyIAPAAIAAAKQADgKAKAAIADAAIAAAPQgCgCgEAAQgFAAgDAEQgCAEAAAEIAAAZg");
	this.shape_29.setTransform(12.125,26.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgJAmIAAgmIgIAAIAAgMIAIAAIAAgGQAAgIAFgFQAFgFAKgBIAHABIAAANIgFgCQgIAAABAIIAAAFIALAAIAAAMIgLAAIAAAmg");
	this.shape_30.setTransform(8.05,25.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#A7A4A4").s().p("AgTAiIAAgIQAJAEAIAAQARAAAAgTIAAgGIAAAAQgGAKgKAAQgKAAgFgHQgGgGAAgLQAAgMAGgIQAGgHAKAAQAKAAAFAIIAAAAIAAgHIAIAAIAAAtQAAAbgZAAQgKAAgHgDgAgKgYQgEAFAAAKQAAAIAEAEQAEAFAGAAQAHAAAEgFQAEgDAAgIIAAgHQAAgGgEgEQgEgFgGAAQgGAAgFAGg");
	this.shape_31.setTransform(36.925,13.325);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#A7A4A4").s().p("AANAZIAAgbQAAgQgMAAQgFAAgEAFQgEAEAAAHIAAAbIgIAAIAAgwIAIAAIAAAIIABAAQAFgJAKAAQAIAAAFAEQAEAGAAAKIAAAdg");
	this.shape_32.setTransform(31.375,12.15);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#A7A4A4").s().p("AgDAkIAAgwIAHAAIAAAwgAgDgbQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQAAAAAAABQABAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQAAAAgBgBg");
	this.shape_33.setTransform(27.325,11.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#A7A4A4").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_34.setTransform(24.9,11);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#A7A4A4").s().p("AgDAlIAAhJIAHAAIAABJg");
	this.shape_35.setTransform(22.5,11);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#A7A4A4").s().p("AgPATQgGgHAAgMQAAgKAHgIQAHgHAIAAQAKAAAGAGQAFAGAAAMIAAADIgjAAQAAAIAFAFQAFAFAGgBQAIABAIgGIAAAHQgIAFgKAAQgJAAgHgHgAgHgPQgEAFgCAGIAaAAQAAgGgDgFQgDgDgGAAQgFAAgDADg");
	this.shape_36.setTransform(18.75,12.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#A7A4A4").s().p("AgWAlIAAhIIAIAAIAAAJIAAAAQAGgKAKAAQAKAAAGAHQAFAGAAAMQAAALgGAHQgGAIgKAAQgJAAgGgIIAAAAIAAAegAgJgZQgFAFAAAIIAAAHQAAAFAEAEQAEAFAGgBQAGABAFgGQAEgEAAgKQAAgJgEgFQgEgEgGAAQgHAAgDAEg");
	this.shape_37.setTransform(13.35,13.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#A7A4A4").s().p("AgQAXIAAgIQAHAEAIAAQAJABAAgIIAAgDIgDgCIgEgCIgDgCIgGgDIgEgCIgDgEIgBgEQAAgEACgDIAFgEIAGgDIAGgBQAGAAAGACIAAAIQgGgDgIAAIgCAAIgEABIgCADIAAADIAAADIACACIAEACIADACIAGACIAFACIADAFIABAEQgBAEgBADQgCADgDACIgFADIgHAAQgIAAgGgDg");
	this.shape_38.setTransform(8.15,12.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bg
	this.instance = new lib.interfaceDropdown();
	this.instance.setTransform(53.8,31.4,0.7567,0.7663,0,0,0,70.7,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.interfaceDropdownShadow_1();
	this.instance_1.setTransform(54,32,0.564,0.5712,0,0,0,109.8,70);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.interfaceDropDownText1, new cjs.Rectangle(-7.9,-8,124.10000000000001,80), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.icon_teams = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_59 = function() {
		exportRoot.mainMC.interfaceAnimation.writingInterface.play();
	}
	this.frame_77 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(59).call(this.frame_59).wait(18).call(this.frame_77).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhLAKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg4AKbIAAwnMBbuAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("Af+KbIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AefKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcaKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZuKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWcKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATLKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQfKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOaKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("AM7KbIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMBKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("ALuKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_59 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_60 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwYAAAMAAAAtZg");
	var mask_graphics_61 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwYAAAMAAAAtZg");
	var mask_graphics_62 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwYAAAMAAAAtZg");
	var mask_graphics_63 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_64 = new cjs.Graphics().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	var mask_graphics_65 = new cjs.Graphics().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	var mask_graphics_66 = new cjs.Graphics().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	var mask_graphics_67 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_68 = new cjs.Graphics().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	var mask_graphics_69 = new cjs.Graphics().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	var mask_graphics_70 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_71 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_72 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_73 = new cjs.Graphics().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	var mask_graphics_74 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_75 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_76 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	var mask_graphics_77 = new cjs.Graphics().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.3539,y:66.7095}).wait(1).to({graphics:mask_graphics_15,x:797.448,y:66.7095}).wait(1).to({graphics:mask_graphics_16,x:791.7303,y:66.7095}).wait(1).to({graphics:mask_graphics_17,x:782.2008,y:66.7095}).wait(1).to({graphics:mask_graphics_18,x:768.8595,y:66.7095}).wait(1).to({graphics:mask_graphics_19,x:751.7063,y:66.7095}).wait(1).to({graphics:mask_graphics_20,x:730.7414,y:66.7095}).wait(1).to({graphics:mask_graphics_21,x:709.7765,y:66.7095}).wait(1).to({graphics:mask_graphics_22,x:692.6233,y:66.7095}).wait(1).to({graphics:mask_graphics_23,x:679.282,y:66.7095}).wait(1).to({graphics:mask_graphics_24,x:669.7525,y:66.7095}).wait(1).to({graphics:mask_graphics_25,x:664.0348,y:66.7095}).wait(1).to({graphics:mask_graphics_26,x:662.1289,y:66.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(32).to({graphics:mask_graphics_59,x:993.1,y:78.675}).wait(1).to({graphics:mask_graphics_60,x:992.95,y:78.675}).wait(1).to({graphics:mask_graphics_61,x:990.25,y:78.675}).wait(1).to({graphics:mask_graphics_62,x:978.55,y:78.675}).wait(1).to({graphics:mask_graphics_63,x:947.1,y:78.675}).wait(1).to({graphics:mask_graphics_64,x:880.75,y:78.675}).wait(1).to({graphics:mask_graphics_65,x:760.15,y:78.675}).wait(1).to({graphics:mask_graphics_66,x:561.5,y:78.675}).wait(1).to({graphics:mask_graphics_67,x:256.8,y:78.675}).wait(1).to({graphics:mask_graphics_68,x:-186.4,y:78.675}).wait(1).to({graphics:mask_graphics_69,x:-629.55,y:78.675}).wait(1).to({graphics:mask_graphics_70,x:-934.25,y:78.675}).wait(1).to({graphics:mask_graphics_71,x:-1132.9,y:78.675}).wait(1).to({graphics:mask_graphics_72,x:-1253.5,y:78.675}).wait(1).to({graphics:mask_graphics_73,x:-1319.85,y:78.675}).wait(1).to({graphics:mask_graphics_74,x:-1351.3,y:78.675}).wait(1).to({graphics:mask_graphics_75,x:-1363,y:78.675}).wait(1).to({graphics:mask_graphics_76,x:-1365.7,y:78.675}).wait(1).to({graphics:mask_graphics_77,x:-1365.9,y:78.675}).wait(1));

	// logo text
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(527.65,74.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:882.05},12,cjs.Ease.quadInOut).wait(52));

	// widows icon
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(988.7,80.95,0.1152,0.1152,0,0,0,-39.9,1.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:988.4,y:80.35},14,cjs.Ease.quadInOut).to({x:684.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(51));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("Ei4MAWtMAAAgtZMFwZAAAMAAAAtZg");
	this.shape.setTransform(993.1,78.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F5F5F5").s().p("Ei4MAWtMAAAgtZMFwYAAAMAAAAtZg");
	this.shape_1.setTransform(992.95,78.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F5F5F5").s().p("Ei4LAWtMAAAgtZMFwXAAAMAAAAtZg");
	this.shape_2.setTransform(880.75,78.675);
	this.shape_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},59).to({state:[{t:this.shape_1,p:{x:992.95}}]},1).to({state:[{t:this.shape_1,p:{x:990.25}}]},1).to({state:[{t:this.shape_1,p:{x:978.55}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(59).to({_off:true},1).wait(3).to({_off:false,x:947.1},0).to({_off:true},1).wait(3).to({_off:false,x:256.8},0).to({_off:true},1).wait(2).to({_off:false,x:-934.25},0).wait(1).to({x:-1132.9},0).wait(1).to({x:-1253.5},0).to({_off:true},1).wait(1).to({_off:false,x:-1351.3},0).wait(1).to({x:-1363},0).wait(1).to({x:-1365.7},0).wait(1).to({x:-1365.9},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(64).to({_off:false},0).wait(1).to({x:760.15},0).wait(1).to({x:561.5},0).to({_off:true},1).wait(1).to({_off:false,x:-186.4},0).wait(1).to({x:-629.55},0).to({_off:true},1).wait(3).to({_off:false,x:-1319.85},0).to({_off:true},1).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2544.7,-66.6,4716.7,290.6);


(lib.writitngInterface = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.gotoAndStop();
	}
	this.frame_284 = function() {
		exportRoot.mainMC.interfaceAnimation.gotoAndPlay();
	}
	this.frame_307 = function() {
		this.gotoAndStop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(284).call(this.frame_284).wait(23).call(this.frame_307).wait(1));

	// quill
	this.instance = new lib.interfaceQuill();
	this.instance.setTransform(407.05,63.95,0.3669,0.3669,53.9831,0,0,52.1,6);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49).to({_off:false},0).to({regY:6.2,rotation:0,x:467.45,y:27.45,alpha:1},14,cjs.Ease.quartInOut).wait(9).to({regX:2,regY:70.2,x:449.1,y:50.9},0).to({scaleX:0.3364,scaleY:0.3364,rotation:-3.4643,x:448.65,y:51.7},2).to({scaleX:0.3669,scaleY:0.3669,rotation:0,x:449.1,y:50.9},3).wait(11).to({regY:70,x:504.35,y:33.25},16,cjs.Ease.cubicInOut).wait(52).to({regY:70.2,x:453.1,y:49.3},15,cjs.Ease.cubicInOut).wait(11).to({scaleX:0.3364,scaleY:0.3364,rotation:-3.4643,x:452.65,y:50.1},2).to({scaleX:0.3669,scaleY:0.3669,rotation:0,x:453.1,y:49.3},3).wait(11).to({regY:70,x:504.35,y:33.25},16,cjs.Ease.quadInOut).wait(53).to({regY:70.2,x:460.3,y:46.1},15,cjs.Ease.quadInOut).wait(14).to({x:431,y:156},11,cjs.Ease.quadInOut).wait(1));

	// DropdownOverlay
	this.instance_1 = new lib.overlayBar();
	this.instance_1.setTransform(475,59.5,1,1,0,0,0,70.5,7);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(58).to({_off:false},0).to({alpha:1},2).wait(14).to({alpha:0},2).to({_off:true},1).wait(91).to({_off:false},0).to({alpha:1},2).wait(14).to({alpha:0},2).to({_off:true},1).wait(121));

	// dropdown3
	this.instance_2 = new lib.interfaceDropDownText3();
	this.instance_2.setTransform(464,23,0.0327,0.0327);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(267).to({_off:false},0).to({regY:0.8,scaleX:1,scaleY:1,x:426,y:23.05},10,cjs.Ease.quartInOut).wait(19).to({x:370.9,y:129.85},11,cjs.Ease.quadInOut).wait(1));

	// dropdown2
	this.instance_3 = new lib.interfaceDropDownText2();
	this.instance_3.setTransform(404,23.05,0.0457,0.0457,0,0,0,0,1.1);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(157).to({_off:false},0).to({regY:0.8,scaleX:1,scaleY:1},10,cjs.Ease.quartInOut).wait(19).to({regY:1.1,scaleX:0.0457,scaleY:0.0457},10,cjs.Ease.quartInOut).to({_off:true},1).wait(111));

	// dropdown1
	this.instance_4 = new lib.interfaceDropDownText1();
	this.instance_4.setTransform(404,23.05,0.0392,0.0392,0,0,0,0,1.3);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(46).to({_off:false},0).to({regY:0.8,scaleX:1,scaleY:1},10,cjs.Ease.quartInOut).wait(19).to({regY:1.3,scaleX:0.0392,scaleY:0.0392},10,cjs.Ease.quartInOut).to({_off:true},1).wait(222));

	// text3 mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_230 = new cjs.Graphics().p("ASkGJIAAlSIDIAAIAAFSg");
	var mask_graphics_232 = new cjs.Graphics().p("ARpGJIAAlSIE+AAIAAFSg");
	var mask_graphics_233 = new cjs.Graphics().p("AQ2FaIAAj0IGkAAIAAD0g");
	var mask_graphics_235 = new cjs.Graphics().p("AQaFxIAAkjIHcAAIAAEjg");
	var mask_graphics_236 = new cjs.Graphics().p("APgFxIAAkjIJQAAIAAEjg");
	var mask_graphics_237 = new cjs.Graphics().p("AOpFxIAAkjIK+AAIAAEjg");
	var mask_graphics_238 = new cjs.Graphics().p("AODFxIAAkjIMKAAIAAEjg");
	var mask_graphics_242 = new cjs.Graphics().p("ANVFxIAAkjINmAAIAAEjg");
	var mask_graphics_243 = new cjs.Graphics().p("AMiFxIAAkjIPMAAIAAEjg");
	var mask_graphics_244 = new cjs.Graphics().p("AL4FxIAAkjIQgAAIAAEjg");
	var mask_graphics_248 = new cjs.Graphics().p("AKZFxIAAkjITeAAIAAEjg");
	var mask_graphics_250 = new cjs.Graphics().p("AJGFxIAAkjIWEAAIAAEjg");
	var mask_graphics_251 = new cjs.Graphics().p("AIvFxIAAkjIWyAAIAAEjg");
	var mask_graphics_252 = new cjs.Graphics().p("AIEFxIAAkjIYIAAIAAEjg");
	var mask_graphics_253 = new cjs.Graphics().p("AHeFxIAAkjIZUAAIAAEjg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(230).to({graphics:mask_graphics_230,x:138.7577,y:39.2893}).wait(2).to({graphics:mask_graphics_232,x:144.7159,y:39.2893}).wait(1).to({graphics:mask_graphics_233,x:149.756,y:34.5688}).wait(2).to({graphics:mask_graphics_235,x:152.55,y:36.9368}).wait(1).to({graphics:mask_graphics_236,x:158.3887,y:36.9368}).wait(1).to({graphics:mask_graphics_237,x:163.9365,y:36.9368}).wait(1).to({graphics:mask_graphics_238,x:167.7431,y:36.9368}).wait(4).to({graphics:mask_graphics_242,x:172.2865,y:36.9368}).wait(1).to({graphics:mask_graphics_243,x:177.3599,y:36.9368}).wait(1).to({graphics:mask_graphics_244,x:181.6085,y:36.9368}).wait(4).to({graphics:mask_graphics_248,x:191.0703,y:36.9368}).wait(2).to({graphics:mask_graphics_250,x:199.3729,y:36.9368}).wait(1).to({graphics:mask_graphics_251,x:201.7258,y:36.9368}).wait(1).to({graphics:mask_graphics_252,x:205.9798,y:36.9368}).wait(1).to({graphics:mask_graphics_253,x:209.8391,y:36.9368}).wait(43).to({graphics:null,x:0,y:0}).wait(12));

	// text3
	this.instance_5 = new lib.textWrong3();
	this.instance_5.setTransform(342.95,59.9,0.7867,0.7867,0,0,0,99.6,18.8);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(230).to({_off:false},0).wait(66).to({scaleX:1,scaleY:1,x:364.95,y:105.85},11,cjs.Ease.quadInOut).wait(1));

	// text friend mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_184 = new cjs.Graphics().p("AmgCAIAAgKINBAAIAAAKgAGhB2ItBAAIAAj1INBAAIAAD1g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(184).to({graphics:mask_1_graphics_184,x:353.0286,y:61.9303}).wait(41).to({graphics:null,x:0,y:0}).wait(83));

	// text amigos
	this.instance_6 = new lib.textCorrect2();
	this.instance_6.setTransform(375.5,36.25,0.7867,0.7867,0,0,0,83,18.7);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(184).to({_off:false},0).to({regY:18.8,y:59.9},13,cjs.Ease.quartInOut).to({_off:true},28).wait(83));

	// text amigos misspelled
	this.instance_7 = new lib.textWrong2();
	this.instance_7.setTransform(329.9,59.9,0.7867,0.7867,0,0,0,83,18.8);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(184).to({_off:false},0).to({y:83.5},13,cjs.Ease.quartInOut).to({_off:true},28).wait(83));

	// text2 mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_120 = new cjs.Graphics().p("ATWGJIAAlSIBfAAIAAFSg");
	var mask_2_graphics_123 = new cjs.Graphics().p("ASTGJIAAlSIDlAAIAAFSg");
	var mask_2_graphics_124 = new cjs.Graphics().p("ARUGJIAAlSIFjAAIAAFSg");
	var mask_2_graphics_126 = new cjs.Graphics().p("ARAGJIAAlSIGLAAIAAFSg");
	var mask_2_graphics_128 = new cjs.Graphics().p("AQNGJIAAlSIHxAAIAAFSg");
	var mask_2_graphics_133 = new cjs.Graphics().p("AOzGJIAAlSIKlAAIAAFSg");
	var mask_2_graphics_135 = new cjs.Graphics().p("ANcGJIAAlSINTAAIAAFSg");
	var mask_2_graphics_136 = new cjs.Graphics().p("ANFGJIAAlSIOBAAIAAFSg");
	var mask_2_graphics_139 = new cjs.Graphics().p("AMUGJIAAlSIPjAAIAAFSg");
	var mask_2_graphics_140 = new cjs.Graphics().p("ALcGJIAAlSIRTAAIAAFSg");
	var mask_2_graphics_141 = new cjs.Graphics().p("AKgGJIAAlSITLAAIAAFSg");
	var mask_2_graphics_143 = new cjs.Graphics().p("AJ1GJIAAlSIUhAAIAAFSg");
	var mask_2_graphics_144 = new cjs.Graphics().p("AJcGJIAAlSIVTAAIAAFSg");
	var mask_2_graphics_184 = new cjs.Graphics().p("AQJGJIAAlSIH+AAIAAFSg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(120).to({graphics:mask_2_graphics_120,x:133.2703,y:39.2893}).wait(3).to({graphics:mask_2_graphics_123,x:139.9575,y:39.2893}).wait(1).to({graphics:mask_2_graphics_124,x:146.2792,y:39.2893}).wait(2).to({graphics:mask_2_graphics_126,x:148.2738,y:39.2893}).wait(2).to({graphics:mask_2_graphics_128,x:153.3691,y:39.2893}).wait(5).to({graphics:mask_2_graphics_133,x:162.3661,y:39.2893}).wait(2).to({graphics:mask_2_graphics_135,x:171.1019,y:39.2893}).wait(1).to({graphics:mask_2_graphics_136,x:173.4069,y:39.2893}).wait(3).to({graphics:mask_2_graphics_139,x:178.2664,y:39.2893}).wait(1).to({graphics:mask_2_graphics_140,x:183.8597,y:39.2893}).wait(1).to({graphics:mask_2_graphics_141,x:189.8519,y:39.2893}).wait(2).to({graphics:mask_2_graphics_143,x:194.1939,y:39.2893}).wait(1).to({graphics:mask_2_graphics_144,x:196.6558,y:39.2893}).wait(40).to({graphics:mask_2_graphics_184,x:154.3396,y:39.2893}).wait(41).to({graphics:null,x:0,y:0}).wait(83));

	// text2
	this.instance_8 = new lib.textWrong2();
	this.instance_8.setTransform(329.9,59.9,0.7867,0.7867,0,0,0,83,18.8);
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(120).to({_off:false},0).to({_off:true},105).wait(83));

	// text friend mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_73 = new cjs.Graphics().p("AlxCAIAAgKILjAAIAAAKgAFyB2IrjAAIAAj1ILjAAIAAD1g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(73).to({graphics:mask_3_graphics_73,x:350.6755,y:61.9303}).wait(42).to({graphics:null,x:0,y:0}).wait(193));

	// text friend
	this.instance_9 = new lib.textCorrect1();
	this.instance_9.setTransform(348.2,36.2,0.7867,0.7867,0,0,0,41.8,18.7);
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(73).to({_off:false},0).to({y:59.8},13,cjs.Ease.quartInOut).to({_off:true},29).wait(193));

	// text friend misspelled
	this.instance_10 = new lib.textWrong1();
	this.instance_10.setTransform(322.75,59.9,0.7867,0.7867,0,0,0,73.9,18.8);
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(73).to({_off:false},0).to({y:83.5},13,cjs.Ease.quartInOut).to({_off:true},29).wait(193));

	// text1 mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_12 = new cjs.Graphics().p("AhCChQgpAAAAgPIAAkjQAAgPApAAICFAAQApAAAAAPIAAEjQAAAPgpAAg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AhhChQg9AAAAgPIAAkjQAAgPA9AAIDEAAQA8AAAAAPIAAEjQAAAPg8AAg");
	var mask_4_graphics_15 = new cjs.Graphics().p("AhxChQhGAAAAgPIAAkjQAAgPBGAAIDjAAQBGAAAAAPIAAEjQAAAPhGAAg");
	var mask_4_graphics_17 = new cjs.Graphics().p("Ah/ChQhPAAAAgPIAAkjQAAgPBPAAID/AAQBPAAAAAPIAAEjQAAAPhPAAg");
	var mask_4_graphics_19 = new cjs.Graphics().p("AihChQhmAAAAgPIAAkjQAAgPBmAAIFFAAQBkAAAAAPIAAEjQAAAPhkAAg");
	var mask_4_graphics_24 = new cjs.Graphics().p("AjQChQiCAAAAgPIAAkjQAAgPCCAAIGhAAQCCAAAAAPIAAEjQAAAPiCAAg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AjmChQiPAAAAgPIAAkjQAAgPCPAAIHNAAQCOAAAAAPIAAEjQAAAPiOAAg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AkEChQiiAAAAgPIAAkjQAAgPCiAAIIKAAQChAAAAAPIAAEjQAAAPihAAg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AkTChQisAAAAgPIAAkjQAAgPCsAAIIoAAQCrAAAAAPIAAEjQAAAPirAAg");
	var mask_4_graphics_32 = new cjs.Graphics().p("Ak0ChQjBAAAAgPIAAkjQAAgPDBAAIJrAAQC/AAAAAPIAAEjQAAAPi/AAg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AlZChQjWAAAAgPIAAkjQAAgPDWAAIK0AAQDVAAAAAPIAAEjQAAAPjVAAg");
	var mask_4_graphics_36 = new cjs.Graphics().p("Al2ChQjpAAAAgPIAAkjQAAgPDpAAILvAAQDnAAAAAPIAAEjQAAAPjnAAg");
	var mask_4_graphics_73 = new cjs.Graphics().p("AgoChQjpAAAAgPIAAkjQAAgPDpAAIE6AAIAAFBg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_4_graphics_12,x:269.5,y:62.925}).wait(1).to({graphics:mask_4_graphics_13,x:274.625,y:62.925}).wait(2).to({graphics:mask_4_graphics_15,x:277.125,y:62.925}).wait(2).to({graphics:mask_4_graphics_17,x:279.425,y:62.925}).wait(2).to({graphics:mask_4_graphics_19,x:285.15,y:62.925}).wait(5).to({graphics:mask_4_graphics_24,x:292.675,y:62.925}).wait(2).to({graphics:mask_4_graphics_26,x:296.2,y:62.925}).wait(2).to({graphics:mask_4_graphics_28,x:301.175,y:62.925}).wait(2).to({graphics:mask_4_graphics_30,x:303.6,y:62.925}).wait(2).to({graphics:mask_4_graphics_32,x:309.05,y:62.925}).wait(2).to({graphics:mask_4_graphics_34,x:314.85,y:62.925}).wait(2).to({graphics:mask_4_graphics_36,x:319.7,y:62.925}).wait(37).to({graphics:mask_4_graphics_73,x:286.3,y:62.925}).wait(42).to({graphics:null,x:0,y:0}).wait(193));

	// text1
	this.instance_11 = new lib.textWrong1();
	this.instance_11.setTransform(322.75,59.9,0.7867,0.7867,0,0,0,73.9,18.8);
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(12).to({_off:false},0).wait(61).to({_off:true},42).wait(193));

	// red text hightlight
	this.instance_12 = new lib.interfaceTextRedHighlight();
	this.instance_12.setTransform(348.4,61.3,0.7365,0.7867,0,0,0,47.1,17.2);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(37).to({_off:false},0).wait(38).to({alpha:0},7).to({_off:true},1).wait(62).to({_off:false,scaleX:0.9371,x:352.3,alpha:1},0).wait(41).to({alpha:0},7).to({_off:true},1).wait(60).to({_off:false,regX:47.3,regY:17.3,scaleX:0.6109,x:394.5,y:61.35,alpha:1},0).wait(42).to({regX:47.4,regY:17.4,scaleX:0.7762,scaleY:0.9997,x:428.45,y:107.1,alpha:0},11,cjs.Ease.quadInOut).wait(1));

	// interface bio reveal
	this.instance_13 = new lib.interfaceWhiteBg();
	this.instance_13.setTransform(393.1,131.85,1,1,0,0,0,135.1,82.4);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(1).to({_off:false},0).wait(295).to({scaleY:0.7599,y:151.65},11,cjs.Ease.quadInOut).wait(1));

	// Layer_2
	this.uiBG = new lib.UIbg("synched",0);
	this.uiBG.name = "uiBG";
	this.uiBG.setTransform(400.2,154.95,0.9881,0.9881,0,0,0,150.1,141.5);
	this.uiBG.alpha = 0;
	this.uiBG._off = true;

	this.timeline.addTween(cjs.Tween.get(this.uiBG).wait(296).to({_off:false},0).to({alpha:1},11,cjs.Ease.quadInOut).wait(1));

	// interface vector
	this.instance_14 = new lib.interfaceVector();
	this.instance_14.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(1).to({_off:false},0).wait(307));

	// interface bitmap
	this.instance_15 = new lib.interfaceReference();
	this.instance_15.setTransform(402,139,1,1,0,0,0,150,125);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(1).to({_off:false},0).wait(307));

	// shadow
	this.instance_16 = new lib.interfaceShadow();
	this.instance_16.setTransform(402,138,1,1,0,0,0,175,150);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(296).to({_off:false},0).to({alpha:1},11,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-12,728,300);


(lib.interfaceAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.gotoAndStop();
	}
	this.frame_4 = function() {
		exportRoot.tl1.play()
	}
	this.frame_38 = function() {
		this.gotoAndStop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(34).call(this.frame_38).wait(1));

	// create a post
	this.writingInterface = new lib.writitngInterface();
	this.writingInterface.name = "writingInterface";
	this.writingInterface.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.writingInterface).to({regX:151.5,regY:128.2,scaleX:0.304,scaleY:0.279,skewX:-28.9974,skewY:-17.026,x:157.5,y:69.45},38,cjs.Ease.quartInOut).wait(1));

	// browser
	this.instance = new lib.interfaceBrowserWindowAngled();
	this.instance.setTransform(253.95,207.05,0.7016,0.7016,0,0,0,362.9,219.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:363,regY:219.4,scaleX:0.376,scaleY:0.376,x:222.5,y:42.75},37,cjs.Ease.quartInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-71.2,-85.4,649.7,531.7);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-19,0.85,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-62.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("AoKCXIAAktIQVAAIAAEtg");
	this.shape.setTransform(-51.375,-0.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-15.5,104.7,30.2), null);


(lib.tiletop = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tiletop, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58,21,0.3087,0.3087);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(662.8,59.75,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(726.95,60,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(710.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// logo
	this.logo1 = new lib.logo();
	this.logo1.name = "logo1";
	this.logo1.setTransform(16.25,15.95,1.0608,1.0608,0,0,0,-52.2,-23.5);

	this.timeline.addTween(cjs.Tween.get(this.logo1).wait(1));

	// interfaceAnim
	this.interfaceAnimation = new lib.interfaceAnim();
	this.interfaceAnimation.name = "interfaceAnimation";

	this.timeline.addTween(cjs.Tween.get(this.interfaceAnimation).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,0,728.4,90.2), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.6)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.6)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		
		
		
		this.runBanner = function() {
			
			this.tl1 = gsap.timeline();
			
				//exportRoot.tl1.to(mc.bg, .1, { alpha:0,	ease:Quart.easeInOut}, "=0");
						
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=0.3");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				//exportRoot.tl1.from(mc.logo1, 0.1, { alpha: 0,	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.pause();		
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,45,364.4,45.2);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 30,
	color: "#F5F5F5",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1.png?1631633081624", id:"M365_FY21Q3ConsOpt_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_BN_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;