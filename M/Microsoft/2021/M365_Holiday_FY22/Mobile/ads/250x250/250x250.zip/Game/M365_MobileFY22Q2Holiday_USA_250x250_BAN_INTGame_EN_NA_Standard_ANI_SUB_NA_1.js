(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1", frames: [[809,1218,168,123],[463,702,256,256],[0,1281,125,125],[809,1343,113,113],[258,1104,200,258],[127,1281,123,123],[0,702,256,319],[632,1218,175,127],[721,702,256,256],[463,960,256,256],[721,960,256,256],[258,702,203,400],[0,0,965,700],[460,1218,170,204],[632,1347,128,94],[0,1023,256,256]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Excel2x = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Excel_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.flake01 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.flake02 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.flake03 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.GoldSparkle1 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.JuniperGiftTall2x = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive2x = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.PowerPoint_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.pptmobile = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ppt = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.TreeGiftLightNeutral2x = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Word2x = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Word_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wordicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word_256x256();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordicon, new cjs.Rectangle(0,0,128,128), null);


(lib.word = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.word, new cjs.Rectangle(0,0,64,47), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.tree = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.TreeGiftLightNeutral2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tree, new cjs.Rectangle(0,0,85,102), null);


(lib.sparkle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.GoldSparkle1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sparkle, new cjs.Rectangle(0,0,61.5,61.5), null);


(lib.Score = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.score_num.textBaseline = "alphabetic";
		this.time_num.textBaseline = "alphabetic";
		//this.score_num.y+=26;
		this.time_num.y+=22;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.time_num = new cjs.Text(":10", "20px 'Segoe Pro'", "#007C6A");
	this.time_num.name = "time_num";
	this.time_num.textAlign = "right";
	this.time_num.lineHeight = 29;
	this.time_num.parent = this;
	this.time_num.setTransform(181.3009,-83.25);

	this.timeline.addTween(cjs.Tween.get(this.time_num).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Score, new cjs.Rectangle(-1,-85.2,184.3,147.9), null);


(lib.rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("ArVOpIAA9RIWrAAIAAdRg");
	this.shape.setTransform(0.025,-297.2666,1,1.3344);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-422.2,145.3,250);


(lib.pptmobile_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pptmobile();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptmobile_1, new cjs.Rectangle(0,0,101.5,200), null);


(lib.ppticon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PowerPoint_256x256();
	this.instance.setTransform(-13.95,-13.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ppticon, new cjs.Rectangle(-13.9,-13.9,128,128), null);


(lib.ppt_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ppt();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ppt_1, new cjs.Rectangle(0,0,482.5,350), null);


(lib.pencil2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// flake
	this.instance = new lib.flake01();
	this.instance.setTransform(0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,37.5,37.5);


(lib.outlookicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Outlook_256x256();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlookicon, new cjs.Rectangle(0,0,128,128), null);


(lib.onedriveicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.OneDrive_256x256();
	this.instance.setTransform(-14,-14,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.onedriveicon, new cjs.Rectangle(-14,-14,128,128), null);


(lib.onedrive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.OneDrive2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.onedrive, new cjs.Rectangle(0,0,87.5,63.5), null);


(lib.cta_arrowcopyblu = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#007C6A").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrowcopyblu, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_Grey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(54.875,54.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(17.1,54.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(54.875,17.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(17.1,17.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(215.625,34.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727272").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(432.275,36.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#727272").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(400.7,35.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#727272").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(368.475,35.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(54.875,54.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(17.1,54.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_10.setTransform(54.875,17.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_11.setTransform(17.1,17.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_12.setTransform(215.625,34.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_13.setTransform(432.275,36.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_14.setTransform(400.7,35.975);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_15.setTransform(368.475,35.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Grey, new cjs.Rectangle(0,0,445.5,72), null);


(lib.flap = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#007C6A").s().p("AljAjIAAhFILHAAIAABFg");
	this.shape.setTransform(35.6,3.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,71.2,7);


(lib.excelicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel_256x256();
	this.instance.setTransform(-14,-14,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excelicon, new cjs.Rectangle(-14,-14,128,128), null);


(lib.excel = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel, new cjs.Rectangle(0,0,84,61.5), null);


(lib.boximage = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.JuniperGiftTall2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,128,159.5);


(lib.BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");
	this.shape.setTransform(124.9976,124.9878,0.7812,0.5208);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG, new cjs.Rectangle(0,0,250,250), null);


(lib.banana = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.flake03();
	this.instance.setTransform(0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.banana, new cjs.Rectangle(0,0,60,77.4), null);


(lib.arrowcopyblue = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#007C6A").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowcopyblue, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.apple2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.flake02();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.apple2, new cjs.Rectangle(0,0,56.5,56.5), null);


(lib.togetherMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// ribbon mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlWCwIAAgUIABgeIAAgBQALh1BYhWQBlhhCNAAQCOAABkBhQBZBWALB1IAAABIABAeIgBAUg");
	var mask_graphics_1 = new cjs.Graphics().p("AlECwIgCAAIgQAAIAAgTIAAgBQAAgPABgPIAAgBQAEgxATgrQAYg8A0gzQA/g8BOgXQAwgOA1AAQBwAABWA9QAXAQAVAUQAeAeAWAhQAMASAJAUIACADQAUAvAFA0IAAABIABAeIgBAUg");
	var mask_graphics_2 = new cjs.Graphics().p("AlECvIgCAAIgQAAIAAgSIAAgBQAAgPABgPIAAgBQAEgxATgsQAYg7A0gzQA/g8BOgWQAwgOA1gBQBwABBWA8QAXAQAVAUQAeAeAWAhQAMARAJAVIACADQAUAuAFA1IAAABIABAeIgBATg");
	var mask_graphics_3 = new cjs.Graphics().p("AlDCvIgDAAIgPAAIgBgSIAAgBQAAgPACgPIAAgBQAEgxASgrQAZg8A0gyQA+g8BPgXQAwgOA1AAQBwAABWA8QAXAQAVAVQAeAdAVAhQAMASAKAUIABADQAUAvAFA0IAAABIABAeIgBATg");
	var mask_graphics_4 = new cjs.Graphics().p("AlDCuIgDAAIgPAAIgBgSIAAgBQAAgPACgPIAAgBQAEgxASgrQAag7A0gyQA+g8BOgXQAxgNA1AAQBvAABXA7QAWAQAWAVQAeAdAUAhQANASAKAUIABADQATAuAEA0IAAABIACAeIgBATg");
	var mask_graphics_5 = new cjs.Graphics().p("AlDCtIgDAAIgPAAIAAgSIAAgCQAAgPABgPIAAAAQAFgxATgqQAZg7A0gyQA/g6BOgXQAwgOA0AAQBxAABVA8QAYAPAUAUQAfAdAVAhQAMASAJAUIABADQAUAuAEAzIAAABIAAAeIgBATg");
	var mask_graphics_6 = new cjs.Graphics().p("AlCCrIgDAAIgPAAIAAgTIAAgBQAAgPACgPIAAAAQAEgwAUgqQAZg6A1gxQA+g6BOgXQAwgNA1AAQBvAABWA6QAXAQAVAUQAfAdAUAgQAMASAJAUIACADQASAtADAzIAAABQABAPgBAOIgBATg");
	var mask_graphics_7 = new cjs.Graphics().p("AlCCoIgDAAIgOgBIAAgSIAAgBQgBgPADgOIAAgBQAFgvAUgpQAag5A1gwQA+g5BOgWQAwgNA0AAQBwAABWA5QAXAPAVAUQAfAcAUAgQALATAJATIABADQARAsACAyIAAABIAAAdIgBASg");
	var mask_graphics_8 = new cjs.Graphics().p("AlBCkIgCAAIgPAAIAAgTIAAgBQAAgPACgOIAAgBQAGguAVgoQAbg3A1guQA+g4BOgVQAwgNA0AAQBvAABWA3QAXAPAVATQAgAcASAfQALATAIATIACADQAPArABAxIAAAAIgBAcIgBASg");
	var mask_graphics_9 = new cjs.Graphics().p("AlACgIgDgBIgNgBIgBgSIAAgBQAAgPADgOIAAgBQAGgsAXgnQAbg1A2gtQA+g1BOgVQAvgMA0gBQBuAABWA2QAXAOAVASQAhAbASAgIASAlIABADQANAqAAAvIAAABIgCAaIgCASg");
	var mask_graphics_10 = new cjs.Graphics().p("Ak/CaIgDgBQgGAAgHgCIgBgSIAAgBQAAgOAEgOIAAgBQAHgqAYglQAdgzA1grQA/gzBOgUQAvgMAzAAQBuAABVAzQAYAOAUARQAjAaAQAfIAQAlIABADQALAogCAtIAAABIgDAZIgDARg");
	var mask_graphics_11 = new cjs.Graphics().p("Ak/CSIgCAAIgNgDIAAgSIAAgBQgBgOAFgNIAAgBQAIgpAagiQAegwA2goQA/gxBNgSQAwgLAyAAQBtgBBVAwQAXANAVAQQAkAZAOAeQAHAUAIARIABADQAIAlgFArIAAAAIgEAZIgDAPg");
	var mask_graphics_12 = new cjs.Graphics().p("Ak+CKIgDgBQgFAAgGgDIgBgSIAAgBQgBgOAGgNIAAAAQAKgnAcggQAggsA2glQA/gtBNgRQAvgKAyAAQBsgBBUAsQAYAMAVAPQAlAXANAeQAFAUAHAQIABADQAEAjgHAnIAAABIgGAWIgEAPg");
	var mask_graphics_13 = new cjs.Graphics().p("AlAB/IgCgBQgFAAgFgEIgBgSIAAAAQgBgOAHgMIAAgBQALgjAfgdQAigoA3giQA+goBOgQQAvgJAwAAQBrgBBUAoQAYAKAUAOQAoAVAKAdQAEAVAGAPIABADQAAAfgLAkIAAABIgIAUIgFANg");
	var mask_graphics_14 = new cjs.Graphics().p("AlCBzIgCgBQgFgBgFgEIgBgSIAAAAQAAgOAIgLIAAgBQAMggAjgZQAkgjA4gdQA+gkBOgNQAugJAwAAQBpgBBTAjQAYAJAVAMQApATAIAcQACAWAFANIABADQgFAcgPAfIAAABIgKASIgGALg");
	var mask_graphics_15 = new cjs.Graphics().p("AlFBlIgBgBQgEgBgFgFIgBgSIAAAAQgBgOAKgKIAAgBQAOgcAngVQAmgcA5gZQA/geBNgMQAtgHAvAAQBogBBSAdQAZAHAUALQAsAQAFAbQgBAWAFAMIAAADQgLAXgTAbIAAAAIgMAQIgIAJg");
	var mask_graphics_16 = new cjs.Graphics().p("AlIBWIgCgDQgDAAgDgHIgCgRIAAgBQgBgNALgJIABAAQAQgZArgOQApgXA6gUQA/gXBNgJQAsgGAuAAQBngCBRAWQAZAGAUAJQAvANACAZQgFAYAEAJIAAADQgRATgYAVIgBABIgPAMIgJAIg");
	var mask_graphics_17 = new cjs.Graphics().p("AlOBEIgBgDQgCgBgEgIIgBgRIAAAAQgBgNANgIIABAAQASgSAwgLQAsgPA7gNQBAgQBMgHQAsgEAtAAQBlgCBPAPQAZADAUAGQAzAKgCAYQgIAZACAHIABADIg3AcIgBABIgSAIIgMAGg");
	var mask_graphics_18 = new cjs.Graphics().p("AlVAvIAAgDQgCgBgCgJIgCgRQgBgMAPgGIABAAQAWgOA1gEQAwgHA8gGQBAgIBLgEIBXgCQBigCBPAGQAaABATADQA3AHgHAWQgLAaABAFIAAADIhGAPIgBAAIgVAEIgOADg");
	var mask_graphics_19 = new cjs.Graphics().p("AlcAcIgBgEIgEgcQgDgaBpAFQBoAFCUAAQCUAABtgGQBugGgQAcQgQAbAAACIAAADg");
	var mask_graphics_20 = new cjs.Graphics().p("AgfATIAAglIA/AAIAAAlg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:63.95,y:16.725}).wait(1).to({graphics:mask_graphics_1,x:63.95,y:16.725}).wait(1).to({graphics:mask_graphics_2,x:63.95,y:16.75}).wait(1).to({graphics:mask_graphics_3,x:63.925,y:16.775}).wait(1).to({graphics:mask_graphics_4,x:63.9,y:16.875}).wait(1).to({graphics:mask_graphics_5,x:63.85,y:17}).wait(1).to({graphics:mask_graphics_6,x:63.7833,y:17.2}).wait(1).to({graphics:mask_graphics_7,x:63.6833,y:17.475}).wait(1).to({graphics:mask_graphics_8,x:63.55,y:17.85}).wait(1).to({graphics:mask_graphics_9,x:63.425,y:18.325}).wait(1).to({graphics:mask_graphics_10,x:63.2654,y:18.925}).wait(1).to({graphics:mask_graphics_11,x:63.1069,y:19.6747}).wait(1).to({graphics:mask_graphics_12,x:62.9926,y:20.5497}).wait(1).to({graphics:mask_graphics_13,x:62.9982,y:21.5747}).wait(1).to({graphics:mask_graphics_14,x:63.0735,y:22.7746}).wait(1).to({graphics:mask_graphics_15,x:63.1952,y:24.1733}).wait(1).to({graphics:mask_graphics_16,x:63.3208,y:25.7952}).wait(1).to({graphics:mask_graphics_17,x:63.7002,y:27.593}).wait(1).to({graphics:mask_graphics_18,x:64.1326,y:29.6089}).wait(1).to({graphics:mask_graphics_19,x:64.6473,y:31.5457}).wait(1).to({graphics:mask_graphics_20,x:64,y:-6.1}).wait(60));

	// ribbon
	this.instance = new lib.boximage("synched",0);
	this.instance.setTransform(64,79.8,1,1,0,0,0,64,79.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},49).wait(31));

	// mask 1 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AkkC2IAulpIIbgsIAAHxg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AkxCcIAyloIIwgsIAAHxg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Ak9CcIAzlnIJIgtIAAHxg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AlKCbIA3lmIJegtIAAHxg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AlWCaIA5lkIJ0guIAAHxg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AljCZIA8ljIKLguIAAHxg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AlwCYIA/lhIKhgvIAAHxg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Al8CXIBClgIK3gvIAAHxg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AmICWIBEleILNgwIAAHxg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AmWCVIBIldILkgwIAAHxg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AmiCVIBLldIL6gwIAAHxg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AmuCUIBMlbIMRgxIAAHxg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Am7CTIBQlZIMngyIAAHxg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AnICSIBTlYIM+gyIAAHxg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AnUCSIBVlXINUgzIAAHxg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AnhCRIBZlWINqgzIAAHxg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AnuCQIBclUIOAg0IAAHxg");
	var mask_1_graphics_17 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_18 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_19 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_20 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_21 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_22 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_23 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_24 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_25 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_26 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_27 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_28 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_29 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_30 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_31 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_32 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_33 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_34 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_35 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_36 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_37 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_38 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_39 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_40 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_41 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_42 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_43 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_44 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_45 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_46 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_47 = new cjs.Graphics().p("An6CPIBelTIOXg0IAAHxg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AI8CoIBelTIOYg0IAAHxg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:27.1013,y:27.4004}).wait(1).to({graphics:mask_1_graphics_1,x:32.2,y:29.9}).wait(1).to({graphics:mask_1_graphics_2,x:37.325,y:29.9}).wait(1).to({graphics:mask_1_graphics_3,x:42.425,y:29.9}).wait(1).to({graphics:mask_1_graphics_4,x:47.525,y:29.9}).wait(1).to({graphics:mask_1_graphics_5,x:52.625,y:29.9}).wait(1).to({graphics:mask_1_graphics_6,x:57.75,y:29.9}).wait(1).to({graphics:mask_1_graphics_7,x:62.85,y:29.9}).wait(1).to({graphics:mask_1_graphics_8,x:67.95,y:29.9}).wait(1).to({graphics:mask_1_graphics_9,x:73.05,y:29.9}).wait(1).to({graphics:mask_1_graphics_10,x:78.15,y:29.9}).wait(1).to({graphics:mask_1_graphics_11,x:83.25,y:29.9}).wait(1).to({graphics:mask_1_graphics_12,x:88.375,y:29.9}).wait(1).to({graphics:mask_1_graphics_13,x:93.475,y:29.9}).wait(1).to({graphics:mask_1_graphics_14,x:98.575,y:29.9}).wait(1).to({graphics:mask_1_graphics_15,x:103.675,y:29.9}).wait(1).to({graphics:mask_1_graphics_16,x:108.8,y:29.9}).wait(1).to({graphics:mask_1_graphics_17,x:113.9,y:29.9}).wait(1).to({graphics:mask_1_graphics_18,x:118.8,y:29.9}).wait(1).to({graphics:mask_1_graphics_19,x:123.75,y:29.9}).wait(1).to({graphics:mask_1_graphics_20,x:128.65,y:29.9}).wait(1).to({graphics:mask_1_graphics_21,x:133.6,y:29.9}).wait(1).to({graphics:mask_1_graphics_22,x:138.5,y:29.9}).wait(1).to({graphics:mask_1_graphics_23,x:143.45,y:29.9}).wait(1).to({graphics:mask_1_graphics_24,x:148.35,y:29.9}).wait(1).to({graphics:mask_1_graphics_25,x:153.3,y:29.9}).wait(1).to({graphics:mask_1_graphics_26,x:158.2,y:29.9}).wait(1).to({graphics:mask_1_graphics_27,x:163.15,y:29.9}).wait(1).to({graphics:mask_1_graphics_28,x:168.05,y:29.9}).wait(1).to({graphics:mask_1_graphics_29,x:173,y:29.9}).wait(1).to({graphics:mask_1_graphics_30,x:177.9,y:29.9}).wait(1).to({graphics:mask_1_graphics_31,x:182.85,y:29.9}).wait(1).to({graphics:mask_1_graphics_32,x:187.75,y:29.9}).wait(1).to({graphics:mask_1_graphics_33,x:192.7,y:29.9}).wait(1).to({graphics:mask_1_graphics_34,x:197.6,y:29.9}).wait(1).to({graphics:mask_1_graphics_35,x:202.55,y:29.9}).wait(1).to({graphics:mask_1_graphics_36,x:207.45,y:29.9}).wait(1).to({graphics:mask_1_graphics_37,x:212.4,y:29.9}).wait(1).to({graphics:mask_1_graphics_38,x:217.3,y:29.9}).wait(1).to({graphics:mask_1_graphics_39,x:222.25,y:29.9}).wait(1).to({graphics:mask_1_graphics_40,x:227.15,y:29.9}).wait(1).to({graphics:mask_1_graphics_41,x:232.1,y:29.9}).wait(1).to({graphics:mask_1_graphics_42,x:237,y:29.9}).wait(1).to({graphics:mask_1_graphics_43,x:241.95,y:29.9}).wait(1).to({graphics:mask_1_graphics_44,x:246.85,y:29.9}).wait(1).to({graphics:mask_1_graphics_45,x:251.8,y:29.9}).wait(1).to({graphics:mask_1_graphics_46,x:256.7,y:29.9}).wait(1).to({graphics:mask_1_graphics_47,x:261.65,y:29.9}).wait(1).to({graphics:mask_1_graphics_48,x:158.6243,y:27.4004}).wait(32));

	// ribbon tie 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E8D07A").ss(3,1,1).p("As9BEIFkABQB0gCARgDQARgCBigRQBmgJBXAVQBfAYCKgMQBygJBsgeQB9ghEehF");
	this.shape.setTransform(153.025,23.9389);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},49).wait(31));

	// box mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AqRJ8IAAz3IUjAAIAAT3g");
	var mask_2_graphics_24 = new cjs.Graphics().p("AqRJ8IAAz3IUjAAIAAT3g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:64.725,y:98.375}).wait(24).to({graphics:mask_2_graphics_24,x:64.725,y:98.375}).wait(56));

	// box
	this.instance_1 = new lib.boximage("synched",0);
	this.instance_1.setTransform(64,79.8,1,1,0,0,0,64,79.8);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(24).to({startPosition:0},0).wait(56));

	// flap r
	this.instance_2 = new lib.flap("synched",0);
	this.instance_2.setTransform(127.4,39.2,0.8873,1,180,0,0,0.1,3.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(24).to({_off:false},0).to({regY:3.6,scaleX:0.6088,scaleY:0.9286,rotation:327.1325,x:119.9,y:41.65},23,cjs.Ease.quadInOut).wait(33));

	// flap l
	this.instance_3 = new lib.flap("synched",0);
	this.instance_3.setTransform(0.15,39.2,0.8873,1,0,0,0,0.2,3.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(24).to({_off:false},0).to({regX:-0.2,regY:3.4,scaleX:0.609,scaleY:0.9285,rotation:-145.1582,x:6.75,y:42.7},23,cjs.Ease.quadInOut).wait(33));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-193,-11.4,430.5,170.9);


(lib.play = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// button
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#007C6A").s().p("AmfCNIAAkZIM/AAIAAEZg");
	this.shape.setTransform(-0.85,8.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BG
	this.instance = new lib.BG();
	this.instance.setTransform(12.35,181.25,0.4249,0.6044,0,0,0,159.7,240.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.5,-5.8,106.2,193);


(lib.msLogoGrey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Microsoft365_logo_Grey.ai
	this.logoGrey = new lib.logo_Grey();
	this.logoGrey.name = "logoGrey";
	this.logoGrey.setTransform(222.8,36,1,1,0,0,0,222.8,36);

	this.timeline.addTween(cjs.Tween.get(this.logoGrey).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoGrey, new cjs.Rectangle(0,0,445.5,72), null);


(lib.cta_arrowmocopyblue = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrowcopyblue();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrowcopyblue();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.icongroup3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.i_flake02 = new lib.apple2();
	this.i_flake02.name = "i_flake02";
	this.i_flake02.setTransform(209.3,-34.8,1,1,0,0,0,25,26.9);

	this.i_flake01 = new lib.pencil2("synched",0);
	this.i_flake01.name = "i_flake01";
	this.i_flake01.setTransform(114.8,-32.6,1,1,0,0,0,19,33.5);

	this.i_flake03 = new lib.banana();
	this.i_flake03.name = "i_flake03";
	this.i_flake03.setTransform(248.75,-65.6,1,1,0,0,0,25,34.5);

	this.i_ppt = new lib.ppticon();
	this.i_ppt.name = "i_ppt";
	this.i_ppt.setTransform(70.7,-35.15,1,1,0,0,0,50,50);

	this.i_onedrive = new lib.onedriveicon();
	this.i_onedrive.name = "i_onedrive";
	this.i_onedrive.setTransform(153.6,-27.35,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.i_onedrive},{t:this.i_ppt},{t:this.i_flake03},{t:this.i_flake01},{t:this.i_flake02}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.8,-100.1,277,136.8);


(lib.icongroup2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.i_flake01 = new lib.pencil2("synched",0);
	this.i_flake01.name = "i_flake01";
	this.i_flake01.setTransform(59.25,-27.75,1,1,0,0,0,18.8,18.8);

	this.i_flake03 = new lib.banana();
	this.i_flake03.name = "i_flake03";
	this.i_flake03.setTransform(89.4,-66.6,1,1,0,0,0,25,34.5);

	this.i_flake02 = new lib.apple2();
	this.i_flake02.name = "i_flake02";
	this.i_flake02.setTransform(195.25,-34.1,1,1,0,0,0,25,26.9);

	this.i_excel = new lib.excelicon();
	this.i_excel.name = "i_excel";
	this.i_excel.setTransform(250.65,-36.25,1,1,0,0,0,50,50);

	this.i_onedrive = new lib.onedriveicon();
	this.i_onedrive.name = "i_onedrive";
	this.i_onedrive.setTransform(123.2,-27.8,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.i_onedrive},{t:this.i_excel},{t:this.i_flake02},{t:this.i_flake03},{t:this.i_flake01}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icongroup2, new cjs.Rectangle(40.5,-101.1,274.2,137.3), null);


(lib.icongroup1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// i_word
	this.i_word = new lib.wordicon();
	this.i_word.name = "i_word";
	this.i_word.setTransform(186.15,-34.25,1,1,0,0,0,64,64);

	this.timeline.addTween(cjs.Tween.get(this.i_word).wait(1));

	// i_ppt
	this.i_ppt = new lib.ppticon();
	this.i_ppt.name = "i_ppt";
	this.i_ppt.setTransform(267.4,-34.25,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.i_ppt).wait(1));

	// i_excel
	this.i_excel = new lib.excelicon();
	this.i_excel.name = "i_excel";
	this.i_excel.setTransform(92.8,-33.6,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.i_excel).wait(1));

	// i_outlook
	this.i_outlook = new lib.outlookicon();
	this.i_outlook.name = "i_outlook";
	this.i_outlook.setTransform(57,-33.8,1,1,0,0,0,64,64);

	this.timeline.addTween(cjs.Tween.get(this.i_outlook).wait(1));

	// pencil2
	this.i_flake01 = new lib.pencil2("synched",0);
	this.i_flake01.name = "i_flake01";
	this.i_flake01.setTransform(103.1,-35.5,1,1,0,0,0,19,33.5);

	this.timeline.addTween(cjs.Tween.get(this.i_flake01).wait(1));

	// i_banana
	this.i_flake03 = new lib.banana();
	this.i_flake03.name = "i_flake03";
	this.i_flake03.setTransform(154.75,-64.7,1,1,0,0,0,25,34.5);

	this.timeline.addTween(cjs.Tween.get(this.i_flake03).wait(1));

	// i_apple2
	this.i_flake02 = new lib.apple2();
	this.i_flake02.name = "i_flake02";
	this.i_flake02.setTransform(224.8,-35.9,1,1,0,0,0,25,26.9);

	this.timeline.addTween(cjs.Tween.get(this.i_flake02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icongroup1, new cjs.Rectangle(-7,-99.2,338.5,129.6), null);


(lib.arrowMainblu = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrowcopyblu();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmocopyblue();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.anim_Bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ppt
	this.pptM = new lib.pptmobile_1();
	this.pptM.name = "pptM";
	this.pptM.setTransform(63.05,159.2,0.336,0.336,0,0,0,50.9,100.2);

	this.ppt = new lib.ppt_1();
	this.ppt.name = "ppt";
	this.ppt.setTransform(142.05,145.35,0.269,0.269,0,0,0,241.3,175.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ppt},{t:this.pptM}]}).wait(1));

	// UIs
	this.onedrive = new lib.onedrive();
	this.onedrive.name = "onedrive";
	this.onedrive.setTransform(254.2,173,0.8112,0.8112,0,0,0,43.8,31.8);
	this.onedrive.alpha = 0.6016;

	this.excel = new lib.excel();
	this.excel.name = "excel";
	this.excel.setTransform(239.6,58.85,0.8131,0.8131,0,0,0,42,30.8);
	this.excel.alpha = 0.6016;

	this.word = new lib.word();
	this.word.name = "word";
	this.word.setTransform(21,91.15,0.7141,0.7141,0,0,0,32,23.6);
	this.word.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.word},{t:this.excel},{t:this.onedrive}]}).wait(1));

	// sparkles
	this.sparkle03 = new lib.sparkle();
	this.sparkle03.name = "sparkle03";
	this.sparkle03.setTransform(193.45,27.75,0.15,0.15,0,0,0,31,31);

	this.sparkle02 = new lib.sparkle();
	this.sparkle02.name = "sparkle02";
	this.sparkle02.setTransform(185.5,9.7,0.1,0.1,0,0,0,31,31);

	this.sparkle01 = new lib.sparkle();
	this.sparkle01.name = "sparkle01";
	this.sparkle01.setTransform(171.85,22.4,0.3317,0.3317,0,0,0,30.8,30.8);

	this.sparkle06 = new lib.sparkle();
	this.sparkle06.name = "sparkle06";
	this.sparkle06.setTransform(47.5,147.6,0.0798,0.0798,0,0,0,31.3,31.9);

	this.sparkle05 = new lib.sparkle();
	this.sparkle05.name = "sparkle05";
	this.sparkle05.setTransform(43.3,138,0.0532,0.0532,0,0,0,31.9,31.9);

	this.sparkle04 = new lib.sparkle();
	this.sparkle04.name = "sparkle04";
	this.sparkle04.setTransform(36.05,144.75,0.1766,0.1766,0,0,0,31.2,30.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.sparkle04},{t:this.sparkle05},{t:this.sparkle06},{t:this.sparkle01},{t:this.sparkle02},{t:this.sparkle03}]}).wait(1));

	// others
	this.tree = new lib.tree();
	this.tree.name = "tree";
	this.tree.setTransform(18.7,158.6,0.937,0.937,0,0,0,42.2,51.1);

	this.timeline.addTween(cjs.Tween.get(this.tree).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.anim_Bg, new cjs.Rectangle(-20.8,6.6,310.5,199.70000000000002), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(76.75,1.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#007C6A").s().p("A4/DcIAAm4MAx/AAAIAAG4g");
	this.shape.setTransform(-45,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-205,-21,320,44.1), null);


(lib.icons = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon6
	this.icons6 = new lib.icongroup1();
	this.icons6.name = "icons6";
	this.icons6.setTransform(174.5,173.7,1,1,0,0,0,174.5,173.7);

	this.timeline.addTween(cjs.Tween.get(this.icons6).wait(1));

	// icon5
	this.icons5 = new lib.icongroup3();
	this.icons5.name = "icons5";
	this.icons5.setTransform(154,184.2,1,1,0,0,0,154,184.2);

	this.timeline.addTween(cjs.Tween.get(this.icons5).wait(1));

	// icon4
	this.icons4 = new lib.icongroup2();
	this.icons4.name = "icons4";
	this.icons4.setTransform(168.1,201.6,1,1,0,0,0,168.1,201.6);

	this.timeline.addTween(cjs.Tween.get(this.icons4).wait(1));

	// icon3
	this.icons3 = new lib.icongroup3();
	this.icons3.name = "icons3";
	this.icons3.setTransform(154,184.2,1,1,0,0,0,154,184.2);

	this.timeline.addTween(cjs.Tween.get(this.icons3).wait(1));

	// icon2
	this.icons2 = new lib.icongroup2();
	this.icons2.name = "icons2";
	this.icons2.setTransform(168.1,201.6,1,1,0,0,0,168.1,201.6);

	this.timeline.addTween(cjs.Tween.get(this.icons2).wait(1));

	// icon1
	this.icons1 = new lib.icongroup1();
	this.icons1.name = "icons1";
	this.icons1.setTransform(174.5,173.7,1,1,0,0,0,174.5,173.7);

	this.timeline.addTween(cjs.Tween.get(this.icons1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-7,-101.1,338.5,137.8), null);


(lib.cta1st = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMainblu();
	this.arrow.name = "arrow";
	this.arrow.setTransform(288.2,-225.45,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(171.9492,-331.6051,0.8333,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta1st, new cjs.Rectangle(47,-456.6,250,250.00000000000003), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bg copy
	this.bg_fade = new lib.BG();
	this.bg_fade.name = "bg_fade";
	this.bg_fade.setTransform(160,240,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.bg_fade).wait(1));

	// logoGrey
	this.logoGrey = new lib.msLogoGrey();
	this.logoGrey.name = "logoGrey";
	this.logoGrey.setTransform(16,16.15,0.223,0.223);

	this.timeline.addTween(cjs.Tween.get(this.logoGrey).wait(1));

	// CTA final
	this.txtPlayAgain = new lib.cta();
	this.txtPlayAgain.name = "txtPlayAgain";
	this.txtPlayAgain.setTransform(17.6,228.85,1,1,0,0,0,0.7,0.1);

	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(223.8,228.55,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txtCta},{t:this.txtPlayAgain}]}).wait(1));

	// CTA_BG final
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(156.95,227);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// track object
	this.trackObject = new lib.rectangle("synched",0);
	this.trackObject.name = "trackObject";
	this.trackObject.setTransform(125,422.6,0.6825,1);
	this.trackObject.alpha = 0.0117;

	this.timeline.addTween(cjs.Tween.get(this.trackObject).wait(1));

	// time
	this.score_MC = new lib.Score();
	this.score_MC.name = "score_MC";
	this.score_MC.setTransform(60.45,88.9);

	this.timeline.addTween(cjs.Tween.get(this.score_MC).wait(1));

	// gameMain
	this.gameMain = new lib.togetherMC();
	this.gameMain.name = "gameMain";
	this.gameMain.setTransform(127.8,226.35,0.6876,0.6874,0,0,0,67.8,119.4);

	this.timeline.addTween(cjs.Tween.get(this.gameMain).wait(1));

	// icons
	this.icons = new lib.icons();
	this.icons.name = "icons";
	this.icons.setTransform(137.45,217.8,1,1,0,0,0,175.2,217.8);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// play now txt
	this.playTxt = new lib.cta();
	this.playTxt.name = "playTxt";
	this.playTxt.setTransform(124.85,116.35,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.playTxt).wait(1));

	// play btn
	this.playBtn = new lib.play("synched",0);
	this.playBtn.name = "playBtn";
	this.playBtn.setTransform(126.65,107.6);

	this.timeline.addTween(cjs.Tween.get(this.playBtn).wait(1));

	// CTA 1st
	this.txtLearn = new lib.cta();
	this.txtLearn.name = "txtLearn";
	this.txtLearn.setTransform(233,229.45,1,1,0,0,0,0.7,0.1);

	this.cta1 = new lib.cta1st();
	this.cta1.name = "cta1";
	this.cta1.setTransform(-46.95,456.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cta1},{t:this.txtLearn}]}).wait(1));

	// frameAnim
	this.finalFrame = new lib.anim_Bg();
	this.finalFrame.name = "finalFrame";
	this.finalFrame.setTransform(160,240,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.finalFrame).wait(1));

	// bg
	this.instance = new lib.BG();
	this.instance.setTransform(160,240,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-619.3,-101.1,913,395.9), null);


// stage content:
(lib.M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		initFrame0();
		animFrame0();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(77,23.9,216.7,270.90000000000003);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 250,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1.png?1634903260061", id:"M365_MobileFY22Q2Holiday_USA_250x250_BAN_INTGame_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;