(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[0,0,378,293],[256,295,60,62],[318,295,53,23],[0,295,254,206]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bg_img2x = function() {
	this.initialize(ss["M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Editor_256x256 = function() {
	this.initialize(ss["M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.finalUI_noeditorbox_sm = function() {
	this.initialize(ss["M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ui2x = function() {
	this.initialize(ss["M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.word_text = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.finalUI_noeditorbox_sm();
	this.instance.setTransform(-165,-8.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.word_text, new cjs.Rectangle(-165,-8.5,26.5,11.5), null);


(lib.underline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#322DA8").s().p("AibAFIAAgJIE3AAIAAAJg");
	this.shape.setTransform(15.7,13.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.underline, new cjs.Rectangle(0.1,12.9,31.2,1), null);


(lib.UIshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("At/LSIAAxhIhNAAIAAlCIEpAAIAADSIZwAAIAATRg");
	this.shape.setTransform(97.275,72.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIshadow, new cjs.Rectangle(0,0,194.6,144.4), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg"); //Changed Color to #FFFFFF from #F2F2F2
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.text_2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("its seasons are the opposite \nof what we have here.", "6px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 86;
	this.txt.parent = this;
	this.txt.setTransform(4,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_2_2, new cjs.Rectangle(2,0,89.6,22.6), null);


(lib.text_1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("its seasons is the opposite \nof what we have here.", "6px 'Segoe Pro'");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 82;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text_1_2, new cjs.Rectangle(0,0,86.4,22.6), null);


(lib.spellcheck_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C5B9EF").s().p("AidA8IAAh3IE7AAIAAB3g");
	this.shape.setTransform(15.75,6.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.spellcheck_box, new cjs.Rectangle(0,0,31.5,12.1), null);


(lib.PWCE_Text = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.txt1 = new cjs.Text("Possible Word Choice Error", "7px 'Segoe Pro'", "#7E8283");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 11;
	this.txt1.lineWidth = 97;
	this.txt1.parent = this;
	this.txt1.setTransform(0,1.65);

	this.txt3 = new cjs.Text("Ignore ...", "9px 'Segoe Pro'");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 14;
	this.txt3.lineWidth = 37;
	this.txt3.parent = this;
	this.txt3.setTransform(0,29.25);

	this.txt2 = new cjs.Text("are the", "9px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 14;
	this.txt2.lineWidth = 31;
	this.txt2.parent = this;
	this.txt2.setTransform(0,15.0002);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt2},{t:this.txt3},{t:this.txt1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PWCE_Text, new cjs.Rectangle(-2,-0.3,101.1,43.699999999999996), null);


(lib.PWCE_Selected_C = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#373535").s().p("AiqCrQhHhHAAhkQAAhjBHhHQBHhHBjAAQBkAABHBHQBHBHAABjQAABkhHBHQhHBHhkAAQhjAAhHhHg");
	this.shape.setTransform(110.4824,7.6994,0.0234,0.0227);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#373535").s().p("AirCrQhHhHAAhkQAAhjBHhHQBHhHBkAAQBkAABIBHQBGBHAABjQAABkhGBHQhIBHhkAAQhkAAhHhHg");
	this.shape_1.setTransform(107.5095,7.6994,0.0234,0.0227);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#373535").s().p("AiqCrQhHhHAAhkQAAhjBHhHQBGhHBkAAQBkAABHBHQBHBHABBjQgBBkhHBHQhHBHhkAAQhjAAhHhHg");
	this.shape_2.setTransform(104.536,7.6994,0.0234,0.0227);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F4F6F6").s().p("ApXA8IAAh3ISvAAIAAB3g");
	this.shape_3.setTransform(60,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PWCE_Selected_C, new cjs.Rectangle(0,0,120,12), null);


(lib.PWCE_BG_C = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApXDrIAAnVISvAAIAAHVg");
	this.shape.setTransform(60,23.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PWCE_BG_C, new cjs.Rectangle(0,0,120,47), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Editor_256x256();
	this.instance.setTransform(0,0,0.5722,0.5722);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon, new cjs.Rectangle(0,0,34.4,35.5), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg_img2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,189,146.5), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AobDGIAAmMIQ3AAIAAGMg");
	this.shape.setTransform(51.925,13.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-2,-6.4,107.9,39.699999999999996), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.ui = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2 copy
	this.text = new lib.word_text();
	this.text.name = "text";
	this.text.setTransform(218.9,86.55,1,1,0,0,0,20.4,10.1);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// Layer_1
	this.instance = new lib.ui2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Shadow
	this.instance_1 = new lib.UIshadow();
	this.instance_1.setTransform(68.1,51.05,0.475,0.475,0,0,0,97.5,72.2);
	this.instance_1.alpha = 0.3008;
	this.instance_1.filters = [new cjs.BlurFilter(14, 14, 1)];
	this.instance_1.cache(-2,-2,199,148);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127,103);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18,17,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.1,0,32.2,30.9);


(lib.PWCE_Selected = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.selected.cache(0,0,120,13,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.selected = new lib.PWCE_Selected_C();
	this.selected.name = "selected";
	this.selected.setTransform(59.5,6.05,0.995,0.9756,0,0,0,59.8,6.2);

	this.timeline.addTween(cjs.Tween.get(this.selected).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PWCE_Selected, new cjs.Rectangle(0,0,119.4,11.7), null);


(lib.PWCE_BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,120,47,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.PWCE_BG_C();
	this.bg.name = "bg";
	this.bg.setTransform(60.05,23.4,1.0025,1.0011,0,0,0,59.9,23.4);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PWCE_BG, new cjs.Rectangle(0,0,120.3,47.1), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_71 = function() {
		exportRoot.startAnim();
	}
	this.frame_113 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(71).call(this.frame_71).wait(42).call(this.frame_113).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(87));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).wait(16));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(15));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(87));

	// Layer_6
	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(84).to({startPosition:0},0).to({alpha:0},29,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.animation_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_133 = function() {
		this.stop();
	}
	this.frame_134 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(133).call(this.frame_133).wait(1).call(this.frame_134).wait(1));

	// text_line
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(0.5,2,1).p("AAAgVIAAAr");
	this.shape.setTransform(178.4027,33.9756);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(3).to({x:180.9028},0).wait(2).to({x:183.3028},0).wait(2).to({x:184.3028},0).wait(1).to({x:187.3029},0).wait(1).to({x:190.3029},0).wait(1).to({x:193.303},0).wait(1).to({x:195.853},0).wait(2).to({x:199.353},0).wait(1).to({x:202.7031},0).wait(1).to({x:205.2031},0).wait(1).to({x:206.4532},0).wait(1).to({x:210.7032},0).wait(1).to({x:211.7032},0).wait(1).to({x:214.5533},0).wait(1).to({x:217.5533},0).wait(1).to({x:220.8034},0).wait(1).to({x:222.3034},0).wait(1).to({x:225.9535},0).wait(1).to({x:232.9536},0).wait(1).to({x:236.4536},0).wait(1).to({x:239.0037},0).wait(1).to({x:240.4537},0).wait(1).to({x:242.4537},0).wait(1).to({x:245.4538},0).wait(1).to({x:250.4538},0).wait(1).to({x:252.9539},0).wait(1).to({x:178.9,y:41.875},0).wait(1).to({x:181.9028,y:41.8756},0).wait(1).to({x:185.2028},0).wait(1).to({x:189.6029},0).wait(1).to({x:193.103},0).wait(1).to({x:196.103},0).wait(1).to({x:198.703},0).wait(1).to({x:199.5031},0).wait(1).to({x:203.7531},0).wait(2).to({x:207.1532},0).wait(1).to({x:208.5532},0).wait(1).to({x:212.1032},0).wait(1).to({x:214.9533},0).wait(2).to({x:217.9533},0).wait(1).to({x:221.0534},0).wait(2).to({x:223.2534},0).wait(1).to({x:226.0535},0).wait(1).to({x:229.1535},0).wait(1).to({x:231.4035},0).wait(1).to({x:234.3036},0).wait(1).to({x:235.9536},0).to({_off:true},12).wait(12).to({_off:false},0).to({_off:true},10).wait(9).to({_off:false},0).to({_off:true},6).wait(30));

	// mask_line1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AB0C5IAAhRIMIAAIAABRg");
	var mask_graphics_4 = new cjs.Graphics().p("ACAC5IAAhRIMHAAIAABRg");
	var mask_graphics_6 = new cjs.Graphics().p("ACMC5IAAhRIMHAAIAABRg");
	var mask_graphics_9 = new cjs.Graphics().p("ACgC5IAAhRIMHAAIAABRg");
	var mask_graphics_10 = new cjs.Graphics().p("ACwC5IAAhRIMHAAIAABRg");
	var mask_graphics_11 = new cjs.Graphics().p("AC+C5IAAhRIMHAAIAABRg");
	var mask_graphics_12 = new cjs.Graphics().p("ADLC5IAAhRIMIAAIAABRg");
	var mask_graphics_14 = new cjs.Graphics().p("ADdC5IAAhRIMHAAIAABRg");
	var mask_graphics_15 = new cjs.Graphics().p("ADtC5IAAhRIMIAAIAABRg");
	var mask_graphics_16 = new cjs.Graphics().p("AD6C5IAAhRIMHAAIAABRg");
	var mask_graphics_18 = new cjs.Graphics().p("AEWC5IAAhRIMHAAIAABRg");
	var mask_graphics_20 = new cjs.Graphics().p("AEpC5IAAhRIMHAAIAABRg");
	var mask_graphics_21 = new cjs.Graphics().p("AE5C5IAAhRIMHAAIAABRg");
	var mask_graphics_22 = new cjs.Graphics().p("AFJC5IAAhRIMHAAIAABRg");
	var mask_graphics_24 = new cjs.Graphics().p("AFiC5IAAhRIMHAAIAABRg");
	var mask_graphics_25 = new cjs.Graphics().p("AGFC5IAAhRIMHAAIAABRg");
	var mask_graphics_26 = new cjs.Graphics().p("AGWC5IAAhRIMHAAIAABRg");
	var mask_graphics_27 = new cjs.Graphics().p("AGjC5IAAhRIMHAAIAABRg");
	var mask_graphics_28 = new cjs.Graphics().p("AGpC5IAAhRIMIAAIAABRg");
	var mask_graphics_29 = new cjs.Graphics().p("AG0C4IAAhSIMIAAIAABSg");
	var mask_graphics_30 = new cjs.Graphics().p("AHDC4IAAhSIMIAAIAABSg");
	var mask_graphics_31 = new cjs.Graphics().p("AHdC4IAAhSIMHAAIAABSg");
	var mask_graphics_32 = new cjs.Graphics().p("AHuC4IAAhSIMIAAIAABSg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:89.1616,y:18.525}).wait(3).to({graphics:mask_graphics_4,x:90.2866,y:18.525}).wait(2).to({graphics:mask_graphics_6,x:91.5366,y:18.525}).wait(3).to({graphics:mask_graphics_9,x:93.5366,y:18.525}).wait(1).to({graphics:mask_graphics_10,x:95.1366,y:18.525}).wait(1).to({graphics:mask_graphics_11,x:96.5366,y:18.525}).wait(1).to({graphics:mask_graphics_12,x:97.8616,y:18.525}).wait(2).to({graphics:mask_graphics_14,x:99.6116,y:18.525}).wait(1).to({graphics:mask_graphics_15,x:101.2616,y:18.525}).wait(1).to({graphics:mask_graphics_16,x:102.5116,y:18.525}).wait(2).to({graphics:mask_graphics_18,x:105.2866,y:18.525}).wait(2).to({graphics:mask_graphics_20,x:107.1866,y:18.525}).wait(1).to({graphics:mask_graphics_21,x:108.8116,y:18.525}).wait(1).to({graphics:mask_graphics_22,x:110.3866,y:18.525}).wait(2).to({graphics:mask_graphics_24,x:112.8866,y:18.525}).wait(1).to({graphics:mask_graphics_25,x:116.3866,y:18.525}).wait(1).to({graphics:mask_graphics_26,x:118.1366,y:18.525}).wait(1).to({graphics:mask_graphics_27,x:119.3866,y:18.525}).wait(1).to({graphics:mask_graphics_28,x:120.0616,y:18.525}).wait(1).to({graphics:mask_graphics_29,x:121.1616,y:18.375}).wait(1).to({graphics:mask_graphics_30,x:122.6616,y:18.375}).wait(1).to({graphics:mask_graphics_31,x:125.2116,y:18.375}).wait(1).to({graphics:mask_graphics_32,x:126.9616,y:18.375}).wait(102).to({graphics:null,x:0,y:0}).wait(1));

	// txt1_2 copy
	this.text_2 = new lib.text_1_2();
	this.text_2.name = "text_2";
	this.text_2.setTransform(218.5,45,1,1,0,0,0,43.5,11);
	this.text_2._off = true;

	var maskedShapeInstanceList = [this.text_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text_2).wait(1).to({_off:false},0).to({_off:true},133).wait(1));

	// mask_line2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_33 = new cjs.Graphics().p("ACEDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_34 = new cjs.Graphics().p("ACQDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_35 = new cjs.Graphics().p("ACcDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_36 = new cjs.Graphics().p("ACnDjIAAhRIMIAAIAABRg");
	var mask_1_graphics_37 = new cjs.Graphics().p("ACzDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AC/DjIAAhRIMHAAIAABRg");
	var mask_1_graphics_39 = new cjs.Graphics().p("ADLDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_40 = new cjs.Graphics().p("ADXDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_41 = new cjs.Graphics().p("ADiDjIAAhRIMIAAIAABRg");
	var mask_1_graphics_42 = new cjs.Graphics().p("ADuDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AD6DjIAAhRIMHAAIAABRg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AEGDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AESDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AEdDjIAAhRIMIAAIAABRg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AEpDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AE1DjIAAhRIMHAAIAABRg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AFBDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AFMDjIAAhRIMIAAIAABRg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AFYDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AFkDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AFwDjIAAhRIMHAAIAABRg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AF8DjIAAhRIMHAAIAABRg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AGHDjIAAhRIMIAAIAABRg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AGTDjIAAhRIMHAAIAABRg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(33).to({graphics:mask_1_graphics_33,x:90.7366,y:22.725}).wait(1).to({graphics:mask_1_graphics_34,x:91.9149,y:22.725}).wait(1).to({graphics:mask_1_graphics_35,x:93.0931,y:22.725}).wait(1).to({graphics:mask_1_graphics_36,x:94.2714,y:22.725}).wait(1).to({graphics:mask_1_graphics_37,x:95.4497,y:22.725}).wait(1).to({graphics:mask_1_graphics_38,x:96.6279,y:22.725}).wait(1).to({graphics:mask_1_graphics_39,x:97.8062,y:22.725}).wait(1).to({graphics:mask_1_graphics_40,x:98.9844,y:22.725}).wait(1).to({graphics:mask_1_graphics_41,x:100.1627,y:22.725}).wait(1).to({graphics:mask_1_graphics_42,x:101.341,y:22.725}).wait(1).to({graphics:mask_1_graphics_43,x:102.5192,y:22.725}).wait(1).to({graphics:mask_1_graphics_44,x:103.6975,y:22.725}).wait(1).to({graphics:mask_1_graphics_45,x:104.8757,y:22.725}).wait(1).to({graphics:mask_1_graphics_46,x:106.054,y:22.725}).wait(1).to({graphics:mask_1_graphics_47,x:107.2323,y:22.725}).wait(1).to({graphics:mask_1_graphics_48,x:108.4105,y:22.725}).wait(1).to({graphics:mask_1_graphics_49,x:109.5888,y:22.725}).wait(1).to({graphics:mask_1_graphics_50,x:110.767,y:22.725}).wait(1).to({graphics:mask_1_graphics_51,x:111.9453,y:22.725}).wait(1).to({graphics:mask_1_graphics_52,x:113.1236,y:22.725}).wait(1).to({graphics:mask_1_graphics_53,x:114.3018,y:22.725}).wait(1).to({graphics:mask_1_graphics_54,x:115.4801,y:22.725}).wait(1).to({graphics:mask_1_graphics_55,x:116.6583,y:22.725}).wait(1).to({graphics:mask_1_graphics_56,x:117.8366,y:22.725}).wait(78).to({graphics:null,x:0,y:0}).wait(1));

	// txt1_2
	this.text_2_1 = new lib.text_1_2();
	this.text_2_1.name = "text_2_1";
	this.text_2_1.setTransform(218.5,45,1,1,0,0,0,43.5,11);
	this.text_2_1._off = true;

	var maskedShapeInstanceList = [this.text_2_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.text_2_1).wait(33).to({_off:false},0).to({_off:true},101).wait(1));

	// txt
	this.text_2_3 = new lib.text_2_2();
	this.text_2_3.name = "text_2_3";
	this.text_2_3.setTransform(218.3,45.3,1,1,0,0,0,45.3,11.3);
	this.text_2_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text_2_3).wait(134).to({_off:false},0).wait(1));

	// purple_box
	this.spellchecker = new lib.spellcheck_box();
	this.spellchecker.name = "spellchecker";
	this.spellchecker.setTransform(206.85,33.35,0.0002,0.4839,0,0,0,0,6.2);
	this.spellchecker._off = true;

	this.timeline.addTween(cjs.Tween.get(this.spellchecker).wait(99).to({_off:false},0).to({regX:0.1,regY:6.1,scaleX:0.4744,x:206.9,y:33.3},12,cjs.Ease.quadInOut).wait(23).to({regY:6.2,scaleX:0.6017,y:33.35},0).wait(1));

	// underline
	this.underline = new lib.underline();
	this.underline.name = "underline";
	this.underline.setTransform(206.7,36.9,0.008,0.4839,0,0,0,0,13.5);
	this.underline._off = true;

	this.timeline.addTween(cjs.Tween.get(this.underline).wait(50).to({_off:false},0).to({regX:0.2,scaleX:0.4813,x:206.85},21,cjs.Ease.quadInOut).wait(63).to({scaleX:0.6102},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(175,27.7,89.60000000000002,28.900000000000002);


(lib.PWCE_BOX = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.PWCE_Text();
	this.instance.setTransform(133.1,49.5,0.9981,1.0119,0,0,0,53.2,16.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// selected
	this.selected = new lib.PWCE_Selected();
	this.selected.name = "selected";
	this.selected.setTransform(134.1,45.3,1.0033,0.9756,0,0,0,59.9,6.2);

	this.timeline.addTween(cjs.Tween.get(this.selected).wait(1));

	// BG
	this.instance_1 = new lib.PWCE_BG();
	this.instance_1.setTransform(134.05,47.4,1.0025,1.0011,0,0,0,59.9,23.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PWCE_BOX, new cjs.Rectangle(74,24,120.6,52.400000000000006), null);


(lib.pop_ups = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.Icon();
	this.icon.name = "icon";
	this.icon.setTransform(74,23,0.9898,1.0141,0,0,0,0,35.5);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// PWCE_Box
	this.inner = new lib.PWCE_BOX();
	this.inner.name = "inner";
	this.inner.setTransform(57.6,25.45,0.9742,0.9728,0,0,0,131.2,50.5);

	this.timeline.addTween(cjs.Tween.get(this.inner).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_ups, new cjs.Rectangle(-9.9,-13,129.3,207.7), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-13.2,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-102.6,-20,107.89999999999999,39.7), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.25,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(673.3,53.5,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(673.5,54.1,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Pop_ups
	this.pop_ups = new lib.pop_ups();
	this.pop_ups.name = "pop_ups";
	this.pop_ups.setTransform(261.5,50.75,0.772,0.772,0,0,0,60,23.7);

	this.timeline.addTween(cjs.Tween.get(this.pop_ups).wait(1));

	// UI
	this.UI = new lib.ui("synched",0);
	this.UI.name = "UI";
	this.UI.setTransform(279.15,91.35,1,1,0,0,0,126,99);

	this.timeline.addTween(cjs.Tween.get(this.UI).wait(1));

	// Animation large
	this.text = new lib.animation_2();
	this.text.name = "text";
	this.text.setTransform(198.05,20.05,1.4,1.4,0,0,0,177.2,41.2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

	// bg image
	this.bg_img = new lib.bg();
	this.bg_img.name = "bg_img";
	this.bg_img.setTransform(281,109.8,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg_img).wait(1));

	// bg color
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-15.2,729.4,146.5), null);


// stage content:
(lib.M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
		
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		var text = mc.text
		var PWCE = mc.pop_ups.inner
		var pen = mc.pop_ups.icon
		
		//var score = mc.pop_ups.score
		
		var sc = mc.text.spellchecker
		var ul = mc.text.underline
		
		var txt2 = mc.text.text_2_3
		
		var selected = mc.pop_ups.inner.selected
		
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				this.tl1.from(exportRoot.headline1,{duration:0.8, x: "+=100", alpha: 0, stagger: 0.1, ease:Power4.easeOut}, "<+.5");
				this.tl1.from(exportRoot.headline2,{duration:0.8, x: "+=100", alpha: 0, stagger: 0.1, ease:Power4.easeOut}, ">-.7");
		
					
				this.tl1.from(text,{duration:1.5,  ease:Power4.easeOut, onStart:function(){mc.text.play(0);}}, ">+0.4");
				
				this.tl1.from(PWCE,{duration:1,scale: 0,  ease:Power4.easeOut}, ">+1");
				this.tl1.from(pen,{duration:0.7,scale: 0,  ease:Power4.easeOut}, ">-0.2");
				this.tl1.from(pen,{duration:1,x: "+=50",  ease:Power2.easeOut}, "<+.2");
		//click		
				this.tl1.to(pen,{duration:0.1,rotation:+5,scale:.95,  ease:Power2.easeOut}, "<+1");
				this.tl1.to(pen,{duration:0.1,rotation:-5,scale:1,  ease:Power2.easeOut, onStart:function(){mc.text.play(135);}}, ">.1");
				this.tl1.from(selected,{duration:0.1 ,alpha: 0,  ease:Power2.easeOut}, ">-0.2");
				
		//UI transition
				this.tl1.to([mc.bg_img,txt2, sc,ul], {duration:1, alpha:0, ease:Power4.easeInOut},">+1.5");
				this.tl1.to(mc.pop_ups, {duration:1, x:"-=118", ease:Power2.easeInOut}, "<")
						.to(mc.pop_ups, {duration:1.2, y:"+=16", ease:Power2.easeInOut}, "<")
						.from(mc.UI,{duration:1.75, x: "+=160", alpha:0,  ease:Power4.easeInOut}, "<-0.2")
		//	popup out
				this.tl1.to(mc.pop_ups,{duration:1,scale: 0, x: "+=60", ease:Power4.easeIn}, ">+1")
						.to(mc.UI, {duration:1.75, x:"-=4", y:"+=3", ease:Power4.easeInOut},"<");
				this.tl1.to(mc.UI.text,{duration:0.5, alpha:0, ease:Power4.easeIn}, "<+0.6")				
			
				this.tl1.from(mc.cta , 0.8, { x: "+=150", ease:Power4.easeOut}, "<+.9");
				this.tl1.from(mc.txtCta, 0.8, { x: "+=150", alpha: 0, ease:Power4.easeOut}, "<0");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
				
				exportRoot.tl1.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
		
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(314,7.4,415.4,123.9);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1625248490595", id:"M365_Editor_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;