(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1", frames: [[152,107,136,114],[165,0,134,74],[0,0,163,105],[0,107,150,113],[67,256,19,20],[0,223,168,31],[170,223,30,38],[0,256,27,34],[29,256,36,15]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.base_sm = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.bg_sm = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Creators_bg_728x90_sm = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.FinalScreen_728x90_medium = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Newsticker = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.pagePeelSml = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.photo1_sm = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.photo2_sm = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.photo3_sm = function() {
	this.initialize(ss["M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("At/LSIAAxhIhNAAIAAlCIEpAAIAADSIZwAAIAATRg");
	this.shape.setTransform(97.275,72.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIshadow, new cjs.Rectangle(0,0,194.6,144.4), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pagePeelSml();
	this.instance.setTransform(-83.9,-15.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.9,-15.6,168,31);


(lib.sticker = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Newsticker();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sticker, new cjs.Rectangle(0,0,19,20), null);


(lib.screen_overlay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(85,85,85,0.557)").s().p("AugNKQg8AAAAg8IAA4bQAAg8A8AAIdBAAQA8AAAAA8IAAYbQAAA8g8AAg");
	this.shape.setTransform(98.9015,84.2013);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_overlay, new cjs.Rectangle(0,0,197.8,168.4), null);


(lib.powerpointUI_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.bg_sm();
	this.instance.setTransform(-0.9,0.2,1.25,1.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.powerpointUI_mc, new cjs.Rectangle(-1.3,0,167.9,93), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.box_Cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("ArtTiMAAAgnDIXbAAMAAAAnDg");
	this.shape.setTransform(75,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_Cache, new cjs.Rectangle(0,0,150,250), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AobDGIAAmMIQ3AAIAAGMg");
	this.shape.setTransform(51.925,13.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-2,-6.4,107.9,39.699999999999996), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18,17,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.1,0,32.2,30.9);


(lib.photo3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_40 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(40).call(this.frame_40).wait(1));

	// Layer_3
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(0.2,23.85,0.263,0.0495,-90,0,0,0.2,-14.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2619,scaleY:0.0651,x:1.3,y:23.75},0).wait(1).to({scaleX:0.2582,scaleY:0.115,x:2.55,y:23.4},0).wait(1).to({scaleX:0.2512,scaleY:0.2095,x:5,y:22.8},0).wait(1).to({regX:0,regY:-15.2,scaleX:0.2473,scaleY:0.2612,x:2.65,y:22.5},0).wait(22).to({startPosition:0},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2476,scaleY:0.2574,x:6.4},0).wait(1).to({scaleX:0.2482,scaleY:0.2486,x:6.25,y:22.55},0).wait(1).to({scaleX:0.2494,scaleY:0.2336,x:5.85,y:22.65},0).wait(1).to({scaleX:0.2511,scaleY:0.2107,x:5.25,y:22.75},0).wait(1).to({scaleX:0.2535,scaleY:0.178,x:4.35,y:22.95},0).wait(1).to({scaleX:0.2567,scaleY:0.1355,x:3.2,y:23.25},0).wait(1).to({scaleX:0.26,scaleY:0.0906,x:2,y:23.5},0).wait(1).to({scaleX:0.2623,scaleY:0.0593,x:1.2,y:23.7},0).wait(1).to({regX:0.2,regY:-14.2,scaleX:0.263,scaleY:0.0495,x:0.2,y:23.85},0).to({_off:true},1).wait(5));

	// panelMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_1 = new cjs.Graphics().p("AkoEoIgBAAIiTAAIABh2QABiCACg+QACg4AGhnIAGhqQABgNBCgCQAfgCAfABIAAAAILnAAIAAJPg");
	var mask_graphics_2 = new cjs.Graphics().p("An4EkIgBAAIj7AAIABh0QABiBAEg9QADg3AKhlIALhpQACgMBwgDQA2gCA1ABIAAAAIT1ABIAAJGg");
	var mask_graphics_3 = new cjs.Graphics().p("AuBEcIgCAAInAAAIABhxQADh9AGg8QAGg1AShjIAUhlQACgMDJgDQBggCBfABIAAAAMAjYAABIAAI2g");
	var mask_graphics_4 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_26 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_27 = new cjs.Graphics().p("AxIEYIgDAAIokAAIAChvQADh8AIg6QAIg1AWhhIAYhkQACgMD2gDQB1gBB0ABIAAAAMArSAAAIAAIug");
	var mask_graphics_28 = new cjs.Graphics().p("AwkEZIgCAAIoSAAIAChwQADh7AIg7QAHg1AVhhIAXhlQADgMDtgDQBxgBBxABIAAAAMAp1AAAIAAIwg");
	var mask_graphics_29 = new cjs.Graphics().p("AvlEaIgDAAInyAAIABhwQADh8AIg7QAGg2AVhhIAVhlQADgMDfgDQBrgBBpABIAAAAMAnYAAAIAAIyg");
	var mask_graphics_30 = new cjs.Graphics().p("AuGEcIgCAAInDAAIAChxQACh9AHg7QAGg2AShiIAUhmQACgMDKgDQBggBBgABIAAAAMAjmAAAIAAI2g");
	var mask_graphics_31 = new cjs.Graphics().p("Ar+EfIgBAAIl/AAIABhyQACh/AGg8QAFg2AQhjIAQhnQACgMCsgDQBRgBBSABIAAAAIeMAAIAAI8g");
	var mask_graphics_32 = new cjs.Graphics().p("ApNEjIgBAAIkmAAIABh0QACiAAEg9QAEg3AMhkIANhoQABgMCEgDQA/gCA+ABIAAAAIXNABIAAJDg");
	var mask_graphics_33 = new cjs.Graphics().p("AmSEmIgBAAIjIAAIAAh1QACiBADg+QACg4AIhlIAJhqQABgMBagDQArgBAqABIAAAAIP0AAIAAJKg");
	var mask_graphics_34 = new cjs.Graphics().p("AkQEpIAAAAIiHAAIAAh2QABiDACg+QACg4AFhnIAGhqQABgNA8gDQAdgBAdABIAAAAIKqAAIAAJQg");
	var mask_graphics_35 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_36 = new cjs.Graphics().p("AjsEqIAAAAIh1AAIAAh3QABiDACg/IAGifIAFhrQABgMA0gDQAZgCAZABIAAAAIJOAAIAAJTg");
	var mask_graphics_37 = new cjs.Graphics().p("Aj6EsIAAAAIh8AAIAAh4QABiEACg/IAHigIAFhrQABgNA3gDQAbgBAaABIAAAAIJxAAIAAJWg");
	var mask_graphics_38 = new cjs.Graphics().p("AkVEvIgBAAIiJAAIABh5QAAiFAChAQACg5AGhpIAGhsQAAgNA+gDQAdgCAdABIAAAAIK2AAIAAJdg");
	var mask_graphics_39 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QAAiIADhAQACg6AGhrIAHhuQABgNBFgDQAigBAhABIAAAAIMRAAIAAJmg");
	var mask_graphics_40 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_1,x:44.6389,y:29.6201}).wait(1).to({graphics:mask_graphics_2,x:76.3943,y:29.2043}).wait(1).to({graphics:mask_graphics_3,x:136.5342,y:28.4169}).wait(1).to({graphics:mask_graphics_4,x:169.5201,y:28.0106}).wait(22).to({graphics:mask_graphics_26,x:169.5201,y:28.0106}).wait(1).to({graphics:mask_graphics_27,x:167.1132,y:28.0422}).wait(1).to({graphics:mask_graphics_28,x:161.5475,y:28.1151}).wait(1).to({graphics:mask_graphics_29,x:151.999,y:28.2401}).wait(1).to({graphics:mask_graphics_30,x:137.3865,y:28.4316}).wait(1).to({graphics:mask_graphics_31,x:116.5493,y:28.7045}).wait(1).to({graphics:mask_graphics_32,x:89.468,y:29.0593}).wait(1).to({graphics:mask_graphics_33,x:60.8946,y:29.4336}).wait(1).to({graphics:mask_graphics_34,x:40.9662,y:29.6946}).wait(1).to({graphics:mask_graphics_35,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_36,x:35.287,y:29.7504}).wait(1).to({graphics:mask_graphics_37,x:37.0091,y:29.7504}).wait(1).to({graphics:mask_graphics_38,x:40.4077,y:29.7504}).wait(1).to({graphics:mask_graphics_39,x:44.973,y:29.7504}).wait(1).to({graphics:mask_graphics_40,x:46.8644,y:29.7504}).wait(1));

	// Layer_4
	this.instance_1 = new lib.photo3_sm();
	this.instance_1.setTransform(-0.65,0,1.4597,1.4597);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(41));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,0,52.6,46);


(lib.photo1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		//this.stop()
	}
	this.frame_62 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(62).call(this.frame_62).wait(1));

	// Layer_4
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(0.2,23.85,0.263,0.0495,-90,0,0,0.2,-14.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,scaleY:0.0507,x:0.9,y:23.8},0).wait(1).to({scaleX:0.2628,scaleY:0.053,x:0.95},0).wait(1).to({scaleX:0.2625,scaleY:0.0563,x:1.05},0).wait(1).to({scaleX:0.2622,scaleY:0.0608,x:1.15,y:23.75},0).wait(1).to({scaleX:0.2618,scaleY:0.0667,x:1.3,y:23.7},0).wait(1).to({scaleX:0.2612,scaleY:0.0741,x:1.5,y:23.65},0).wait(1).to({scaleX:0.2605,scaleY:0.0833,x:1.75,y:23.6},0).wait(1).to({scaleX:0.2597,scaleY:0.0944,x:2.05,y:23.55},0).wait(1).to({scaleX:0.2587,scaleY:0.1075,x:2.35,y:23.45},0).wait(1).to({scaleX:0.2576,scaleY:0.123,x:2.75,y:23.35},0).wait(1).to({scaleX:0.2563,scaleY:0.1409,x:3.2,y:23.25},0).wait(1).to({scaleX:0.2548,scaleY:0.1609,x:3.75,y:23.1},0).wait(1).to({scaleX:0.2532,scaleY:0.1825,x:4.3,y:23},0).wait(1).to({scaleX:0.2515,scaleY:0.2042,x:4.85,y:22.85},0).wait(1).to({scaleX:0.2501,scaleY:0.2242,x:5.35,y:22.7},0).wait(1).to({scaleX:0.2488,scaleY:0.2407,x:5.8,y:22.65},0).wait(1).to({scaleX:0.248,scaleY:0.2524,x:6.05,y:22.6},0).wait(1).to({scaleX:0.2475,scaleY:0.2591,x:6.2,y:22.55},0).wait(1).to({regX:0,regY:-15.2,scaleX:0.2473,scaleY:0.2612,x:2.65,y:22.5},0).wait(21).to({startPosition:0},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2476,scaleY:0.2574,x:6.4},0).wait(1).to({scaleX:0.2482,scaleY:0.2486,x:6.25,y:22.55},0).wait(1).to({scaleX:0.2494,scaleY:0.2336,x:5.85,y:22.65},0).wait(1).to({scaleX:0.2511,scaleY:0.2107,x:5.25,y:22.75},0).wait(1).to({scaleX:0.2535,scaleY:0.178,x:4.35,y:22.95},0).wait(1).to({scaleX:0.2567,scaleY:0.1355,x:3.2,y:23.25},0).wait(1).to({scaleX:0.26,scaleY:0.0906,x:2,y:23.5},0).wait(1).to({scaleX:0.2623,scaleY:0.0593,x:1.2,y:23.7},0).wait(1).to({regX:0.2,regY:-14.2,scaleX:0.263,scaleY:0.0495,x:0.2,y:23.85},0).to({_off:true},1).wait(5));

	// panelMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");
	var mask_graphics_1 = new cjs.Graphics().p("AlHE1IgBAAIiiAAIABh7QABiIAChBQACg7AHhrIAHhuQABgNBIgDQAjgCAiABIAAAAIMzAAIAAJpg");
	var mask_graphics_2 = new cjs.Graphics().p("AlCE1IgBAAIifAAIAAh7QABiIADhBQACg6AGhrIAHhvQABgNBHgDQAjgBAhABIAAAAIMmAAIAAJog");
	var mask_graphics_3 = new cjs.Graphics().p("Ak5EzIgBAAIibAAIABh6QABiIAChAQACg6AGhrIAHhuQABgNBFgDQAigBAgABIAAAAIMQAAIAAJlg");
	var mask_graphics_4 = new cjs.Graphics().p("AkrEyIAAAAIiUAAIAAh6QABiHAChAQACg6AGhqIAGhtQABgNBDgDQAfgBAgABIAAAAILrAAIAAJig");
	var mask_graphics_5 = new cjs.Graphics().p("AkXEvIAAAAIiKAAIAAh5QABiFAChAQACg5AFhpIAGhtQABgNA+gDQAdgBAeABIAAAAIK5AAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("Aj/EsIAAAAIh/AAIAAh3QABiFACg/IAHigIAFhsQABgNA5gDQAbgBAbABIAAAAIJ+AAIAAJXg");
	var mask_graphics_7 = new cjs.Graphics().p("AjtEqIAAAAIh2AAIABh3QAAiDACg/IAGifIAGhrQAAgNA1gCQAZgCAZABIAAAAIJRAAIAAJTg");
	var mask_graphics_8 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_9 = new cjs.Graphics().p("AjsEpIgBAAIh1AAIABh2QAAiDACg/IAGifIAFhqQABgNA1gDQAZgBAYABIAAAAIJQAAIAAJRg");
	var mask_graphics_10 = new cjs.Graphics().p("Aj1EpIgBAAIh6AAIABh2QAAiDACg/IAHieIAFhrQABgNA2gCQAagCAaABIAAAAIJnAAIAAJRg");
	var mask_graphics_11 = new cjs.Graphics().p("AkDEpIgBAAIiAAAIAAh2QABiDACg+IAHifIAFhrQABgMA5gDQAcgCAbACIAAgBIKKABIAAJQg");
	var mask_graphics_12 = new cjs.Graphics().p("AkWEpIgBAAIiKAAIAAh3QABiCACg+QACg5AGhmIAGhqQAAgNA+gDQAegBAdABIAAAAIK6AAIAAJQg");
	var mask_graphics_13 = new cjs.Graphics().p("AkvEoIAAAAIiXAAIABh2QAAiCADg+QACg4AGhnIAGhqQABgMBEgDQAggCAgABIAAAAIL4AAIAAJPg");
	var mask_graphics_14 = new cjs.Graphics().p("AlOEnIAAAAIimAAIAAh1QABiCADg+QACg4AHhmIAHhqQABgNBKgDQAjgBAkABIAAAAINGAAIAAJNg");
	var mask_graphics_15 = new cjs.Graphics().p("Al0EnIgBAAIi5AAIABh2QABiCADg9QACg4AIhmIAIhpQABgNBTgDQAngBAnABIAAAAIOnAAIAAJMg");
	var mask_graphics_16 = new cjs.Graphics().p("AmiEmIgBAAIjQAAIABh1QABiCADg9QADg4AIhlIAJhqQABgMBegDQAsgBAsABIAAAAIQcAAIAAJKg");
	var mask_graphics_17 = new cjs.Graphics().p("AnZElIgBAAIjrAAIAAh1QACiBADg9QADg4AKhlIAKhpQABgMBqgDQAygBAyABIAAAAISnAAIAAJIg");
	var mask_graphics_18 = new cjs.Graphics().p("AoZEjIgBAAIkMAAIAAh0QACiAAEg9QAEg3AKhlIAMhoQABgNB5gCQA5gCA5ABIAAAAIVJAAIAAJFg");
	var mask_graphics_19 = new cjs.Graphics().p("ApkEiIgBAAIkxAAIABh0QACh/AEg9QAEg3ANhkIANhoQABgMCJgDQBBgBBBABIAAAAIYGAAIAAJCg");
	var mask_graphics_20 = new cjs.Graphics().p("Aq3EgIgCAAIlaAAIABhzQACh/AFg8QAEg2AOhkIAQhnQABgNCcgCQBKgCBJABIAAAAIbZAAIAAI/g");
	var mask_graphics_21 = new cjs.Graphics().p("AsREeIgCAAImHAAIABhyQACh+AGg8QAFg2AQhjIARhnQACgMCwgCQBTgCBTABIAAAAIe9AAIAAI7g");
	var mask_graphics_22 = new cjs.Graphics().p("AtrEdIgCAAIm1AAIABhyQACh9AHg8QAGg2ARhiIAThmQADgMDEgDQBdgBBdABIAAAAMAihAAAIAAI4g");
	var mask_graphics_23 = new cjs.Graphics().p("Au/EbIgCAAInfAAIABhxQADh8AHg8QAHg1AThiIAVhlQACgMDXgDQBmgBBmABIAAAAMAl0AAAIAAI0g");
	var mask_graphics_24 = new cjs.Graphics().p("AwDEaIgDAAIoBAAIAChxQADh8AHg7QAHg1AVhhIAWhlQADgMDmgDQBtgBBtABIAAAAMAoiAAAIAAIyg");
	var mask_graphics_25 = new cjs.Graphics().p("Aw0EZIgCAAIoaAAIAChwQADh8AIg6QAHg2AWhhIAXhkQADgMDxgDQBygBBzABIAAAAMAqdAAAIAAIwg");
	var mask_graphics_26 = new cjs.Graphics().p("AxQEYIgCAAIooAAIAChvQADh8AIg6QAIg1AWhhIAYhkQADgMD3gDQB2gBB1ABIAAAAMArjAAAIAAIug");
	var mask_graphics_27 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_48 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_49 = new cjs.Graphics().p("AxIEYIgDAAIokAAIAChvQADh8AIg6QAIg1AWhhIAYhkQACgMD2gDQB1gBB0ABIAAAAMArSAAAIAAIug");
	var mask_graphics_50 = new cjs.Graphics().p("AwkEZIgCAAIoSAAIAChwQADh7AIg7QAHg1AVhhIAXhlQADgMDtgDQBxgBBxABIAAAAMAp1AAAIAAIwg");
	var mask_graphics_51 = new cjs.Graphics().p("AvlEaIgDAAInyAAIABhwQADh8AIg7QAGg2AVhhIAVhlQADgMDfgDQBrgBBpABIAAAAMAnYAAAIAAIyg");
	var mask_graphics_52 = new cjs.Graphics().p("AuGEcIgCAAInDAAIAChxQACh9AHg7QAGg2AShiIAUhmQACgMDKgDQBggBBgABIAAAAMAjmAAAIAAI2g");
	var mask_graphics_53 = new cjs.Graphics().p("Ar+EfIgBAAIl/AAIABhyQACh/AGg8QAFg2AQhjIAQhnQACgMCsgDQBRgBBSABIAAAAIeMAAIAAI8g");
	var mask_graphics_54 = new cjs.Graphics().p("ApNEjIgBAAIkmAAIABh0QACiAAEg9QAEg3AMhkIANhoQABgMCEgDQA/gCA+ABIAAAAIXNABIAAJDg");
	var mask_graphics_55 = new cjs.Graphics().p("AmSEmIgBAAIjIAAIAAh1QACiBADg+QACg4AIhlIAJhqQABgMBagDQArgBAqABIAAAAIP0AAIAAJKg");
	var mask_graphics_56 = new cjs.Graphics().p("AkQEpIAAAAIiHAAIAAh2QABiDACg+QACg4AFhnIAGhqQABgNA8gDQAdgBAdABIAAAAIKqAAIAAJQg");
	var mask_graphics_57 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_58 = new cjs.Graphics().p("AjsEqIAAAAIh1AAIAAh3QABiDACg/IAGifIAFhrQABgMA0gDQAZgCAZABIAAAAIJOAAIAAJTg");
	var mask_graphics_59 = new cjs.Graphics().p("Aj6EsIAAAAIh8AAIAAh4QABiEACg/IAHigIAFhrQABgNA3gDQAbgBAaABIAAAAIJxAAIAAJWg");
	var mask_graphics_60 = new cjs.Graphics().p("AkVEvIgBAAIiJAAIABh5QAAiFAChAQACg5AGhpIAGhsQAAgNA+gDQAdgCAdABIAAAAIK2AAIAAJdg");
	var mask_graphics_61 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QAAiIADhAQACg6AGhrIAHhuQABgNBFgDQAigBAhABIAAAAIMRAAIAAJmg");
	var mask_graphics_62 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:46.8644,y:29.7504}).wait(1).to({graphics:mask_graphics_1,x:46.6008,y:29.7504}).wait(1).to({graphics:mask_graphics_2,x:45.9648,y:29.7504}).wait(1).to({graphics:mask_graphics_3,x:44.844,y:29.7504}).wait(1).to({graphics:mask_graphics_4,x:43.0919,y:29.7504}).wait(1).to({graphics:mask_graphics_5,x:40.5971,y:29.7504}).wait(1).to({graphics:mask_graphics_6,x:37.6512,y:29.7504}).wait(1).to({graphics:mask_graphics_7,x:35.3973,y:29.7504}).wait(1).to({graphics:mask_graphics_8,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_9,x:35.4835,y:29.7399}).wait(1).to({graphics:mask_graphics_10,x:36.9013,y:29.7214}).wait(1).to({graphics:mask_graphics_11,x:39.0162,y:29.6937}).wait(1).to({graphics:mask_graphics_12,x:41.9071,y:29.6558}).wait(1).to({graphics:mask_graphics_13,x:45.6652,y:29.6066}).wait(1).to({graphics:mask_graphics_14,x:50.3954,y:29.5447}).wait(1).to({graphics:mask_graphics_15,x:56.2164,y:29.4685}).wait(1).to({graphics:mask_graphics_16,x:63.2582,y:29.3763}).wait(1).to({graphics:mask_graphics_17,x:71.6529,y:29.2664}).wait(1).to({graphics:mask_graphics_18,x:81.5121,y:29.1373}).wait(1).to({graphics:mask_graphics_19,x:92.878,y:28.9885}).wait(1).to({graphics:mask_graphics_20,x:105.631,y:28.8215}).wait(1).to({graphics:mask_graphics_21,x:119.3507,y:28.6418}).wait(1).to({graphics:mask_graphics_22,x:133.1924,y:28.4606}).wait(1).to({graphics:mask_graphics_23,x:145.9492,y:28.2936}).wait(1).to({graphics:mask_graphics_24,x:156.4209,y:28.1565}).wait(1).to({graphics:mask_graphics_25,x:163.862,y:28.059}).wait(1).to({graphics:mask_graphics_26,x:168.1194,y:28.0033}).wait(1).to({graphics:mask_graphics_27,x:169.5201,y:28.0106}).wait(21).to({graphics:mask_graphics_48,x:169.5201,y:28.0106}).wait(1).to({graphics:mask_graphics_49,x:167.1132,y:28.0422}).wait(1).to({graphics:mask_graphics_50,x:161.5475,y:28.1151}).wait(1).to({graphics:mask_graphics_51,x:151.999,y:28.2401}).wait(1).to({graphics:mask_graphics_52,x:137.3865,y:28.4316}).wait(1).to({graphics:mask_graphics_53,x:116.5493,y:28.7045}).wait(1).to({graphics:mask_graphics_54,x:89.468,y:29.0593}).wait(1).to({graphics:mask_graphics_55,x:60.8946,y:29.4336}).wait(1).to({graphics:mask_graphics_56,x:40.9662,y:29.6946}).wait(1).to({graphics:mask_graphics_57,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_58,x:35.287,y:29.7504}).wait(1).to({graphics:mask_graphics_59,x:37.0091,y:29.7504}).wait(1).to({graphics:mask_graphics_60,x:40.4077,y:29.7504}).wait(1).to({graphics:mask_graphics_61,x:44.973,y:29.7504}).wait(1).to({graphics:mask_graphics_62,x:46.8644,y:29.7504}).wait(1));

	// Layer_2
	this.instance_1 = new lib.photo1_sm();
	this.instance_1.setTransform(0.1,0.1,1.27,1.27);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(63));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38.2,48.4);


(lib.photo_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		//this.stop()
	}
	this.frame_53 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(53).call(this.frame_53).wait(1));

	// Layer_5
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(0.2,23.85,0.263,0.0495,-90,0,0,0.2,-14.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,scaleY:0.0507,x:0.9,y:23.8},0).wait(1).to({scaleX:0.2628,scaleY:0.053,x:0.95},0).wait(1).to({scaleX:0.2625,scaleY:0.0563,x:1.05},0).wait(1).to({scaleX:0.2622,scaleY:0.0608,x:1.15,y:23.75},0).wait(1).to({scaleX:0.2618,scaleY:0.0667,x:1.3,y:23.7},0).wait(1).to({scaleX:0.2612,scaleY:0.0741,x:1.5,y:23.65},0).wait(1).to({scaleX:0.2605,scaleY:0.0833,x:1.75,y:23.6},0).wait(1).to({scaleX:0.2597,scaleY:0.0944,x:2.05,y:23.55},0).wait(1).to({scaleX:0.2587,scaleY:0.1075,x:2.35,y:23.45},0).wait(1).to({scaleX:0.2576,scaleY:0.123,x:2.75,y:23.35},0).wait(1).to({scaleX:0.2563,scaleY:0.1409,x:3.2,y:23.25},0).wait(1).to({scaleX:0.2548,scaleY:0.1609,x:3.75,y:23.1},0).wait(1).to({scaleX:0.2532,scaleY:0.1825,x:4.3,y:23},0).wait(1).to({scaleX:0.2515,scaleY:0.2042,x:4.85,y:22.85},0).wait(1).to({scaleX:0.2501,scaleY:0.2242,x:5.35,y:22.7},0).wait(1).to({scaleX:0.2488,scaleY:0.2407,x:5.8,y:22.65},0).wait(1).to({scaleX:0.248,scaleY:0.2524,x:6.05,y:22.6},0).wait(1).to({scaleX:0.2475,scaleY:0.2591,x:6.2,y:22.55},0).wait(1).to({regX:0,regY:-15.2,scaleX:0.2473,scaleY:0.2612,x:2.65,y:22.5},0).wait(12).to({startPosition:0},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2476,scaleY:0.2574,x:6.4},0).wait(1).to({scaleX:0.2482,scaleY:0.2486,x:6.25,y:22.55},0).wait(1).to({scaleX:0.2494,scaleY:0.2336,x:5.85,y:22.65},0).wait(1).to({scaleX:0.2511,scaleY:0.2107,x:5.25,y:22.75},0).wait(1).to({scaleX:0.2535,scaleY:0.178,x:4.35,y:22.95},0).wait(1).to({scaleX:0.2567,scaleY:0.1355,x:3.2,y:23.25},0).wait(1).to({scaleX:0.26,scaleY:0.0906,x:2,y:23.5},0).wait(1).to({scaleX:0.2623,scaleY:0.0593,x:1.2,y:23.7},0).wait(1).to({regX:0.2,regY:-14.2,scaleX:0.263,scaleY:0.0495,x:0.2,y:23.85},0).to({_off:true},1).wait(5));

	// panelMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");
	var mask_graphics_1 = new cjs.Graphics().p("AlHE1IgBAAIiiAAIABh7QABiIAChBQACg7AHhrIAHhuQABgNBIgDQAjgCAiABIAAAAIMzAAIAAJpg");
	var mask_graphics_2 = new cjs.Graphics().p("AlCE1IgBAAIifAAIAAh7QABiIADhBQACg6AGhrIAHhvQABgNBHgDQAjgBAhABIAAAAIMmAAIAAJog");
	var mask_graphics_3 = new cjs.Graphics().p("Ak5EzIgBAAIibAAIABh6QABiIAChAQACg6AGhrIAHhuQABgNBFgDQAigBAgABIAAAAIMQAAIAAJlg");
	var mask_graphics_4 = new cjs.Graphics().p("AkrEyIAAAAIiUAAIAAh6QABiHAChAQACg6AGhqIAGhtQABgNBDgDQAfgBAgABIAAAAILrAAIAAJig");
	var mask_graphics_5 = new cjs.Graphics().p("AkXEvIAAAAIiKAAIAAh5QABiFAChAQACg5AFhpIAGhtQABgNA+gDQAdgBAeABIAAAAIK5AAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("Aj/EsIAAAAIh/AAIAAh3QABiFACg/IAHigIAFhsQABgNA5gDQAbgBAbABIAAAAIJ+AAIAAJXg");
	var mask_graphics_7 = new cjs.Graphics().p("AjtEqIAAAAIh2AAIABh3QAAiDACg/IAGifIAGhrQAAgNA1gCQAZgCAZABIAAAAIJRAAIAAJTg");
	var mask_graphics_8 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_9 = new cjs.Graphics().p("AjsEpIgBAAIh1AAIABh2QAAiDACg/IAGifIAFhqQABgNA1gDQAZgBAYABIAAAAIJQAAIAAJRg");
	var mask_graphics_10 = new cjs.Graphics().p("Aj1EpIgBAAIh6AAIABh2QAAiDACg/IAHieIAFhrQABgNA2gCQAagCAaABIAAAAIJnAAIAAJRg");
	var mask_graphics_11 = new cjs.Graphics().p("AkDEpIgBAAIiAAAIAAh2QABiDACg+IAHifIAFhrQABgMA5gDQAcgCAbACIAAgBIKKABIAAJQg");
	var mask_graphics_12 = new cjs.Graphics().p("AkWEpIgBAAIiKAAIAAh3QABiCACg+QACg5AGhmIAGhqQAAgNA+gDQAegBAdABIAAAAIK6AAIAAJQg");
	var mask_graphics_13 = new cjs.Graphics().p("AkvEoIAAAAIiXAAIABh2QAAiCADg+QACg4AGhnIAGhqQABgMBEgDQAggCAgABIAAAAIL4AAIAAJPg");
	var mask_graphics_14 = new cjs.Graphics().p("AlOEnIAAAAIimAAIAAh1QABiCADg+QACg4AHhmIAHhqQABgNBKgDQAjgBAkABIAAAAINGAAIAAJNg");
	var mask_graphics_15 = new cjs.Graphics().p("Al0EnIgBAAIi5AAIABh2QABiCADg9QACg4AIhmIAIhpQABgNBTgDQAngBAnABIAAAAIOnAAIAAJMg");
	var mask_graphics_16 = new cjs.Graphics().p("AmiEmIgBAAIjQAAIABh1QABiCADg9QADg4AIhlIAJhqQABgMBegDQAsgBAsABIAAAAIQcAAIAAJKg");
	var mask_graphics_17 = new cjs.Graphics().p("AnZElIgBAAIjrAAIAAh1QACiBADg9QADg4AKhlIAKhpQABgMBqgDQAygBAyABIAAAAISnAAIAAJIg");
	var mask_graphics_18 = new cjs.Graphics().p("AoZEjIgBAAIkMAAIAAh0QACiAAEg9QAEg3AKhlIAMhoQABgNB5gCQA5gCA5ABIAAAAIVJAAIAAJFg");
	var mask_graphics_19 = new cjs.Graphics().p("ApkEiIgBAAIkxAAIABh0QACh/AEg9QAEg3ANhkIANhoQABgMCJgDQBBgBBBABIAAAAIYGAAIAAJCg");
	var mask_graphics_20 = new cjs.Graphics().p("Aq3EgIgCAAIlaAAIABhzQACh/AFg8QAEg2AOhkIAQhnQABgNCcgCQBKgCBJABIAAAAIbZAAIAAI/g");
	var mask_graphics_21 = new cjs.Graphics().p("AsREeIgCAAImHAAIABhyQACh+AGg8QAFg2AQhjIARhnQACgMCwgCQBTgCBTABIAAAAIe9AAIAAI7g");
	var mask_graphics_22 = new cjs.Graphics().p("AtrEdIgCAAIm1AAIABhyQACh9AHg8QAGg2ARhiIAThmQADgMDEgDQBdgBBdABIAAAAMAihAAAIAAI4g");
	var mask_graphics_23 = new cjs.Graphics().p("Au/EbIgCAAInfAAIABhxQADh8AHg8QAHg1AThiIAVhlQACgMDXgDQBmgBBmABIAAAAMAl0AAAIAAI0g");
	var mask_graphics_24 = new cjs.Graphics().p("AwDEaIgDAAIoBAAIAChxQADh8AHg7QAHg1AVhhIAWhlQADgMDmgDQBtgBBtABIAAAAMAoiAAAIAAIyg");
	var mask_graphics_25 = new cjs.Graphics().p("Aw0EZIgCAAIoaAAIAChwQADh8AIg6QAHg2AWhhIAXhkQADgMDxgDQBygBBzABIAAAAMAqdAAAIAAIwg");
	var mask_graphics_26 = new cjs.Graphics().p("AxQEYIgCAAIooAAIAChvQADh8AIg6QAIg1AWhhIAYhkQADgMD3gDQB2gBB1ABIAAAAMArjAAAIAAIug");
	var mask_graphics_27 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_39 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_40 = new cjs.Graphics().p("AxIEYIgDAAIokAAIAChvQADh8AIg6QAIg1AWhhIAYhkQACgMD2gDQB1gBB0ABIAAAAMArSAAAIAAIug");
	var mask_graphics_41 = new cjs.Graphics().p("AwkEZIgCAAIoSAAIAChwQADh7AIg7QAHg1AVhhIAXhlQADgMDtgDQBxgBBxABIAAAAMAp1AAAIAAIwg");
	var mask_graphics_42 = new cjs.Graphics().p("AvlEaIgDAAInyAAIABhwQADh8AIg7QAGg2AVhhIAVhlQADgMDfgDQBrgBBpABIAAAAMAnYAAAIAAIyg");
	var mask_graphics_43 = new cjs.Graphics().p("AuGEcIgCAAInDAAIAChxQACh9AHg7QAGg2AShiIAUhmQACgMDKgDQBggBBgABIAAAAMAjmAAAIAAI2g");
	var mask_graphics_44 = new cjs.Graphics().p("Ar+EfIgBAAIl/AAIABhyQACh/AGg8QAFg2AQhjIAQhnQACgMCsgDQBRgBBSABIAAAAIeMAAIAAI8g");
	var mask_graphics_45 = new cjs.Graphics().p("ApNEjIgBAAIkmAAIABh0QACiAAEg9QAEg3AMhkIANhoQABgMCEgDQA/gCA+ABIAAAAIXNABIAAJDg");
	var mask_graphics_46 = new cjs.Graphics().p("AmSEmIgBAAIjIAAIAAh1QACiBADg+QACg4AIhlIAJhqQABgMBagDQArgBAqABIAAAAIP0AAIAAJKg");
	var mask_graphics_47 = new cjs.Graphics().p("AkQEpIAAAAIiHAAIAAh2QABiDACg+QACg4AFhnIAGhqQABgNA8gDQAdgBAdABIAAAAIKqAAIAAJQg");
	var mask_graphics_48 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_49 = new cjs.Graphics().p("AjsEqIAAAAIh1AAIAAh3QABiDACg/IAGifIAFhrQABgMA0gDQAZgCAZABIAAAAIJOAAIAAJTg");
	var mask_graphics_50 = new cjs.Graphics().p("Aj6EsIAAAAIh8AAIAAh4QABiEACg/IAHigIAFhrQABgNA3gDQAbgBAaABIAAAAIJxAAIAAJWg");
	var mask_graphics_51 = new cjs.Graphics().p("AkVEvIgBAAIiJAAIABh5QAAiFAChAQACg5AGhpIAGhsQAAgNA+gDQAdgCAdABIAAAAIK2AAIAAJdg");
	var mask_graphics_52 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QAAiIADhAQACg6AGhrIAHhuQABgNBFgDQAigBAhABIAAAAIMRAAIAAJmg");
	var mask_graphics_53 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:46.8644,y:29.7504}).wait(1).to({graphics:mask_graphics_1,x:46.6008,y:29.7504}).wait(1).to({graphics:mask_graphics_2,x:45.9648,y:29.7504}).wait(1).to({graphics:mask_graphics_3,x:44.844,y:29.7504}).wait(1).to({graphics:mask_graphics_4,x:43.0919,y:29.7504}).wait(1).to({graphics:mask_graphics_5,x:40.5971,y:29.7504}).wait(1).to({graphics:mask_graphics_6,x:37.6512,y:29.7504}).wait(1).to({graphics:mask_graphics_7,x:35.3973,y:29.7504}).wait(1).to({graphics:mask_graphics_8,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_9,x:35.4835,y:29.7399}).wait(1).to({graphics:mask_graphics_10,x:36.9013,y:29.7214}).wait(1).to({graphics:mask_graphics_11,x:39.0162,y:29.6937}).wait(1).to({graphics:mask_graphics_12,x:41.9071,y:29.6558}).wait(1).to({graphics:mask_graphics_13,x:45.6652,y:29.6066}).wait(1).to({graphics:mask_graphics_14,x:50.3954,y:29.5447}).wait(1).to({graphics:mask_graphics_15,x:56.2164,y:29.4685}).wait(1).to({graphics:mask_graphics_16,x:63.2582,y:29.3763}).wait(1).to({graphics:mask_graphics_17,x:71.6529,y:29.2664}).wait(1).to({graphics:mask_graphics_18,x:81.5121,y:29.1373}).wait(1).to({graphics:mask_graphics_19,x:92.878,y:28.9885}).wait(1).to({graphics:mask_graphics_20,x:105.631,y:28.8215}).wait(1).to({graphics:mask_graphics_21,x:119.3507,y:28.6418}).wait(1).to({graphics:mask_graphics_22,x:133.1924,y:28.4606}).wait(1).to({graphics:mask_graphics_23,x:145.9492,y:28.2936}).wait(1).to({graphics:mask_graphics_24,x:156.4209,y:28.1565}).wait(1).to({graphics:mask_graphics_25,x:163.862,y:28.059}).wait(1).to({graphics:mask_graphics_26,x:168.1194,y:28.0033}).wait(1).to({graphics:mask_graphics_27,x:169.5201,y:28.0106}).wait(12).to({graphics:mask_graphics_39,x:169.5201,y:28.0106}).wait(1).to({graphics:mask_graphics_40,x:167.1132,y:28.0422}).wait(1).to({graphics:mask_graphics_41,x:161.5475,y:28.1151}).wait(1).to({graphics:mask_graphics_42,x:151.999,y:28.2401}).wait(1).to({graphics:mask_graphics_43,x:137.3865,y:28.4316}).wait(1).to({graphics:mask_graphics_44,x:116.5493,y:28.7045}).wait(1).to({graphics:mask_graphics_45,x:89.468,y:29.0593}).wait(1).to({graphics:mask_graphics_46,x:60.8946,y:29.4336}).wait(1).to({graphics:mask_graphics_47,x:40.9662,y:29.6946}).wait(1).to({graphics:mask_graphics_48,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_49,x:35.287,y:29.7504}).wait(1).to({graphics:mask_graphics_50,x:37.0091,y:29.7504}).wait(1).to({graphics:mask_graphics_51,x:40.4077,y:29.7504}).wait(1).to({graphics:mask_graphics_52,x:44.973,y:29.7504}).wait(1).to({graphics:mask_graphics_53,x:46.8644,y:29.7504}).wait(1));

	// Layer_3
	this.instance_1 = new lib.photo2_sm();
	this.instance_1.setTransform(-0.05,-0.05,1.42,1.42);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38.3,48.3);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.final_screen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.FinalScreen_728x90_medium();
	this.instance.setTransform(78.9,57.3,0.67,0.67);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Shadow
	this.instance_1 = new lib.UIshadow();
	this.instance_1.setTransform(130.45,95.05,0.4982,0.4982,0,0,0,97.7,72.5);
	this.instance_1.alpha = 0.3008;
	this.instance_1.filters = [new cjs.BlurFilter(14, 14, 1)];
	this.instance_1.cache(-2,-2,199,148);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.final_screen, new cjs.Rectangle(74.8,52,115.00000000000001,90), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_91 = function() {
		exportRoot.startAnim();
	}
	this.frame_104 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(91).call(this.frame_91).wait(13).call(this.frame_104).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(78));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).wait(7));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(78));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},81).to({state:[{t:this.instance_3}]},23).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(81).to({_off:false},0).to({alpha:0},23,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.box_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.box.cache(0,0,150,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.box = new lib.box_Cache();
	this.box.name = "box";
	this.box.setTransform(75,125,1,1,0,0,0,75,125);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_c, new cjs.Rectangle(0,0,150,250), null);


(lib.base = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.overlay = new lib.screen_overlay();
	this.overlay.name = "overlay";
	this.overlay.setTransform(101.2,83.85,1,1,0,0,0,98.9,84.2);

	this.timeline.addTween(cjs.Tween.get(this.overlay).wait(1));

	// Layer_3
	this.instance = new lib.base_sm();
	this.instance.setTransform(0.8,0.65,1.4599,1.46);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.base, new cjs.Rectangle(0,-0.3,200.1,168.4), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_239 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(239).call(this.frame_239).wait(1));

	// New sticker
	this.instance = new lib.sticker();
	this.instance.setTransform(278.5,144.05,0.1526,0.1526,0,0,0,9.5,10.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(198).to({_off:false},0).to({regX:9.7,scaleX:2.0424,scaleY:2.0424,x:279.15,y:144.7},14,cjs.Ease.sineInOut).to({regX:9.5,regY:10,scaleX:1,scaleY:1,x:278.5,y:144},15,cjs.Ease.sineInOut).wait(13));

	// photo 3 copy
	this.instance_1 = new lib.photo3();
	this.instance_1.setTransform(399.5,77.35,1.8593,2.1596,-3.0133,0,0,26.1,11.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(152).to({_off:false},0).to({regX:26.3,regY:11.1,scaleX:2.2678,scaleY:2.5582,rotation:1.2256,x:360.55,y:-18.05},12,cjs.Ease.quadOut).wait(5).to({regX:25.6,regY:23,scaleX:2.2615,scaleY:2.5504,rotation:1.2194,x:357.85,y:13.2},0).wait(1).to({scaleX:2.241,scaleY:2.5252,rotation:1.1996,x:356.55,y:15.7},0).wait(1).to({scaleX:2.2043,scaleY:2.4802,rotation:1.1642,x:354.2,y:20.3},0).wait(1).to({scaleX:2.15,scaleY:2.4134,rotation:1.1117,x:350.75,y:27.05},0).wait(1).to({scaleX:2.0774,scaleY:2.3241,rotation:1.0415,x:346.15,y:36.05},0).wait(1).to({scaleX:1.9879,scaleY:2.2142,rotation:0.955,x:340.45,y:47.15},0).wait(1).to({scaleX:1.8858,scaleY:2.0887,rotation:0.8563,x:333.95,y:59.85},0).wait(1).to({scaleX:1.777,scaleY:1.955,rotation:0.7511,x:327,y:73.35},0).wait(1).to({scaleX:1.6682,scaleY:1.8212,rotation:0.6459,x:320.05,y:86.9},0).wait(1).to({scaleX:1.5647,scaleY:1.6941,rotation:0.5459,x:313.45,y:99.75},0).wait(1).to({scaleX:1.47,scaleY:1.5776,rotation:0.4543,x:307.4,y:111.55},0).wait(1).to({scaleX:1.3854,scaleY:1.4736,rotation:0.3725,x:302,y:122.05},0).wait(1).to({scaleX:1.3113,scaleY:1.3826,rotation:0.3009,x:297.25,y:131.25},0).wait(1).to({scaleX:1.2473,scaleY:1.304,rotation:0.239,x:293.2,y:139.2},0).wait(1).to({scaleX:1.1927,scaleY:1.2368,rotation:0.1862,x:289.65,y:146},0).wait(1).to({scaleX:1.1466,scaleY:1.1801,rotation:0.1417,x:286.7,y:151.7},0).wait(1).to({scaleX:1.1082,scaleY:1.1329,rotation:0.1045,x:284.2,y:156.5},0).wait(1).to({scaleX:1.0767,scaleY:1.0942,rotation:0.0741,x:282.15,y:160.4},0).wait(1).to({scaleX:1.0515,scaleY:1.0632,rotation:0.0497,x:280.6,y:163.5},0).wait(1).to({scaleX:1.0319,scaleY:1.0392,rotation:0.0308,x:279.3,y:165.95},0).wait(1).to({scaleX:1.0174,scaleY:1.0213,rotation:0.0168,x:278.4,y:167.75},0).wait(1).to({scaleX:1.0075,scaleY:1.0092,rotation:0.0072,x:277.75,y:169},0).wait(1).to({scaleX:1.0018,scaleY:1.0022,rotation:0.0018,x:277.4,y:169.7},0).wait(1).to({regX:26,regY:11,scaleX:1,scaleY:1,rotation:0,x:278,y:158},0).wait(48));

	// maskPhoto3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_141 = new cjs.Graphics().p("AoglPIQOgPQgCABAaFYIAbFXIwNANg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(141).to({graphics:mask_graphics_141,x:399.8,y:75.4}).wait(11).to({graphics:null,x:0,y:0}).wait(88));

	// photo 3
	this.instance_2 = new lib.photo3();
	this.instance_2.setTransform(502.55,74.15,1.8593,2.1596,-3.0133,0,0,26.1,11.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(141).to({_off:false},0).to({x:400.3,y:80},11,cjs.Ease.none).to({_off:true},1).wait(87));

	// photo 2 copy
	this.instance_3 = new lib.photo_2();
	this.instance_3.setTransform(436.65,78.65,0.9499,1.067,0,-5.0007,-0.5117,19.3,23.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(97).to({_off:false},0).wait(1).to({regX:19.1,regY:24.1,scaleX:0.9629,scaleY:1.08,skewX:-5.2774,skewY:-0.8252,x:435.1,y:75.65},0).wait(1).to({scaleX:0.9773,scaleY:1.0946,skewX:-5.5857,skewY:-1.1744,x:433.5,y:72},0).wait(1).to({scaleX:0.9933,scaleY:1.1107,skewX:-5.9275,skewY:-1.5617,x:431.75,y:67.95},0).wait(1).to({scaleX:1.011,scaleY:1.1285,skewX:-6.3049,skewY:-1.9892,x:429.9,y:63.55},0).wait(1).to({scaleX:1.0304,scaleY:1.1481,skewX:-6.7199,skewY:-2.4594,x:427.8,y:58.6},0).wait(1).to({scaleX:1.0517,scaleY:1.1696,skewX:-7.1747,skewY:-2.9747,x:425.45,y:53.15},0).wait(1).to({scaleX:1.075,scaleY:1.193,skewX:-7.6715,skewY:-3.5375,x:423,y:47.35},0).wait(1).to({scaleX:1.1003,scaleY:1.2186,skewX:-8.2125,skewY:-4.1504,x:420.25,y:40.9},0).wait(1).to({scaleX:1.1278,scaleY:1.2463,skewX:-8.7997,skewY:-4.8157,x:417.3,y:34},0).wait(1).to({scaleX:1.1575,scaleY:1.2763,skewX:-9.4349,skewY:-5.5353,x:414.1,y:26.5},0).wait(1).to({scaleX:1.1896,scaleY:1.3086,skewX:-10.1197,skewY:-6.3111,x:410.65,y:18.4},0).wait(1).to({scaleX:1.224,scaleY:1.3433,skewX:-10.8549,skewY:-7.144,x:406.95,y:9.7},0).wait(1).to({scaleX:1.2608,scaleY:1.3804,skewX:-11.6409,skewY:-8.0345,x:402.95,y:0.4},0).wait(1).to({regX:19.4,regY:23.8,scaleX:1.2999,scaleY:1.4198,skewX:-12.4769,skewY:-8.9816,x:399,y:-10},0).wait(1).to({regX:19.1,regY:24.1,scaleX:1.2989,scaleY:1.4137,skewX:-11.0152,skewY:-7.6749,x:392.65,y:-16.5},0).wait(1).to({scaleX:1.2978,scaleY:1.4073,skewX:-9.4712,skewY:-6.2946,x:385.2,y:-21.85},0).wait(1).to({scaleX:1.2967,scaleY:1.4005,skewX:-7.8556,skewY:-4.8503,x:372.9,y:-24.8},0).wait(1).to({scaleX:1.2955,scaleY:1.3935,skewX:-6.1833,skewY:-3.3554,x:361.9,y:-25.2},0).wait(1).to({scaleX:1.2943,scaleY:1.3864,skewX:-4.4723,skewY:-1.8258,x:351.5,y:-23.5},0).wait(1).to({scaleX:1.2931,scaleY:1.3791,skewX:-2.7429,skewY:-0.2798,x:342.1,y:-17.75},0).wait(1).to({scaleX:1.2918,scaleY:1.3719,skewX:-1.0162,skewY:1.2638,x:335.8,y:-6.9},0).wait(1).to({scaleX:1.2906,scaleY:1.3648,skewX:0.6872,skewY:2.7866,x:333.45,y:5.3},0).wait(1).to({scaleX:1.2894,scaleY:1.3578,skewX:2.3489,skewY:4.2721,x:333.05,y:20.15},0).wait(1).to({scaleX:1.2883,scaleY:1.3511,skewX:3.9537,skewY:5.7067,x:333.7,y:32.8},0).wait(1).to({scaleX:1.2872,scaleY:1.3447,skewX:5.4898,skewY:7.0799,x:334.65,y:44.3},0).wait(1).to({scaleX:1.2862,scaleY:1.3386,skewX:6.9489,skewY:8.3843,x:335.7,y:56.3},0).wait(1).to({scaleX:1.2852,scaleY:1.3328,skewX:8.3263,skewY:9.6156,x:336.3,y:64.7},0).wait(1).to({scaleX:1.2843,scaleY:1.3274,skewX:9.6196,skewY:10.7718,x:336.6,y:71.95},0).wait(1).to({scaleX:1.2834,scaleY:1.3224,skewX:10.8288,skewY:11.8527,x:336.55,y:79.45},0).wait(1).to({scaleX:1.2826,scaleY:1.3177,skewX:11.9552,skewY:12.8597,x:336.15,y:85.35},0).wait(1).to({scaleX:1.2819,scaleY:1.3133,skewX:13.0015,skewY:13.795,x:335.4,y:90.75},0).wait(1).to({scaleX:1.2812,scaleY:1.3092,skewX:13.9708,skewY:14.6615,x:334.05,y:95.8},0).wait(1).to({scaleX:1.2806,scaleY:1.3054,skewX:14.8667,skewY:15.4624,x:332.15,y:100.5},0).wait(1).to({regX:19.4,regY:23.9,scaleX:1.28,scaleY:1.302,skewX:15.693,skewY:16.2012,x:329.8,y:104.45},0).wait(1).to({regX:19.1,regY:24.1,scaleX:1.2468,scaleY:1.2662,skewX:13.8316,skewY:14.2794,x:325.55,y:106.65},0).wait(1).to({scaleX:1.2164,scaleY:1.2334,skewX:12.1288,skewY:12.5215,x:322.15,y:108.55},0).wait(1).to({scaleX:1.1887,scaleY:1.2035,skewX:10.575,skewY:10.9174,x:319,y:110.3},0).wait(1).to({scaleX:1.1634,scaleY:1.1763,skewX:9.1608,skewY:9.4575,x:316.1,y:111.9},0).wait(1).to({scaleX:1.1405,scaleY:1.1516,skewX:7.8777,skewY:8.1327,x:313.5,y:113.35},0).wait(1).to({scaleX:1.1199,scaleY:1.1293,skewX:6.7173,skewY:6.9348,x:311.2,y:114.7},0).wait(1).to({scaleX:1.1012,scaleY:1.1092,skewX:5.6722,skewY:5.8559,x:309.05,y:115.8},0).wait(1).to({scaleX:1.0845,scaleY:1.0912,skewX:4.7354,skewY:4.8887,x:307.2,y:116.85},0).wait(1).to({scaleX:1.0696,scaleY:1.0751,skewX:3.9003,skewY:4.0266,x:305.55,y:117.8},0).wait(1).to({scaleX:1.0564,scaleY:1.0609,skewX:3.161,skewY:3.2633,x:304,y:118.65},0).wait(1).to({scaleX:1.0448,scaleY:1.0484,skewX:2.5119,skewY:2.5932,x:302.7,y:119.35},0).wait(1).to({scaleX:1.0348,scaleY:1.0375,skewX:1.9479,skewY:2.0109,x:301.55,y:120},0).wait(1).to({scaleX:1.0262,scaleY:1.0282,rotation:1.4643,skewX:0,skewY:0,x:300.55,y:120.5},0).wait(1).to({scaleX:1.0189,scaleY:1.0204,rotation:1.0567,x:299.75,y:121},0).wait(1).to({scaleX:1.0129,scaleY:1.0139,rotation:0.721,x:299.1,y:121.4},0).wait(1).to({scaleX:1.0081,scaleY:1.0088,rotation:0.4536,x:298.55,y:121.65},0).wait(1).to({scaleX:1.0045,scaleY:1.0049,rotation:0.2509,x:298.15,y:121.9},0).wait(1).to({scaleX:1.002,scaleY:1.0021,rotation:0.1097,x:297.85,y:122.05},0).wait(1).to({scaleX:1.0005,scaleY:1.0005,rotation:0.027,x:297.7,y:122.1},0).wait(1).to({regX:19,regY:24,scaleX:1,scaleY:1,rotation:0,x:297.95,y:122},0).wait(89));

	// maskPhoto2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_89 = new cjs.Graphics().p("Ab5h0IGwgFQgBABAaFXIAbFYImvADg");
	var mask_1_graphics_97 = new cjs.Graphics().p("Ab5h0IGwgFQgBABAaFXIAbFYImvADg");
	var mask_1_graphics_98 = new cjs.Graphics().p("AauiQIH9gFQgBABAaFlIAaFmIn9ADg");
	var mask_1_graphics_99 = new cjs.Graphics().p("AZjisIJMgGQgCABAZF0IAZF0IpLADg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AYYjJIKagFQgBABAXGBIAXGDIqZACg");
	var mask_1_graphics_101 = new cjs.Graphics().p("AXOjlILpgFQgCABAVGPIAWGQIrnADg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AWFkAIM3gGQgCABATGdIATGeIs1ADg");
	var mask_1_graphics_103 = new cjs.Graphics().p("AU8kcIOGgGQgCABAPGrIARGsIuDADg");
	var mask_1_graphics_104 = new cjs.Graphics().p("AT0k3IPUgGQgCABANG5IANG5IvRADg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(89).to({graphics:mask_1_graphics_89,x:226.8502,y:56.9755}).wait(8).to({graphics:mask_1_graphics_97,x:226.8502,y:56.9755}).wait(1).to({graphics:mask_1_graphics_98,x:226.9598,y:56.9693}).wait(1).to({graphics:mask_1_graphics_99,x:227.0509,y:56.9592}).wait(1).to({graphics:mask_1_graphics_100,x:227.1237,y:56.945}).wait(1).to({graphics:mask_1_graphics_101,x:227.1782,y:56.9261}).wait(1).to({graphics:mask_1_graphics_102,x:227.2144,y:56.9022}).wait(1).to({graphics:mask_1_graphics_103,x:227.2325,y:56.8728}).wait(1).to({graphics:mask_1_graphics_104,x:227.2259,y:56.9014}).wait(1).to({graphics:null,x:0,y:0}).wait(135));

	// photo 2
	this.instance_4 = new lib.photo_2();
	this.instance_4.setTransform(471.3,78.85,0.9499,1.067,0,-4.0004,-0.5035,19.2,23.8);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(90).to({_off:false},0).wait(1).to({regX:19.1,regY:24.1,skewX:-4.0402,skewY:-0.5038,x:469.85,y:79.15},0).wait(1).to({skewX:-4.1197,skewY:-0.5045,x:467.1},0).wait(1).to({skewX:-4.2452,skewY:-0.5055,x:462.7},0).wait(1).to({scaleY:1.0669,skewX:-4.4207,skewY:-0.5069,x:456.65},0).wait(1).to({scaleY:1.067,skewX:-4.6378,skewY:-0.5087,x:449.1},0).wait(1).to({skewX:-4.8569,skewY:-0.5105,x:441.5,y:79.1},0).wait(1).to({regX:19.3,regY:23.8,skewX:-5.0007,skewY:-0.5117,x:436.6,y:78.85},0).to({_off:true},1).wait(142));

	// photo 2 copy 4
	this.instance_5 = new lib.photo1();
	this.instance_5.setTransform(436.65,78.65,0.9499,1.067,0,-5.0007,-0.5117,19.3,23.8);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(51).to({_off:false},0).wait(1).to({regX:19.1,regY:24.2,scaleX:0.9527,scaleY:1.0697,skewX:-4.95,skewY:-0.482,x:436,y:78.8},0).wait(1).to({scaleX:0.9571,scaleY:1.0741,skewX:-4.8672,skewY:-0.4336,x:434.8,y:77.8},0).wait(1).to({scaleX:0.9633,scaleY:1.0803,skewX:-4.7509,skewY:-0.3656,x:433.2,y:75.8},0).wait(1).to({scaleX:0.9714,scaleY:1.0883,skewX:-4.5995,skewY:-0.2771,x:431.8,y:73.25},0).wait(1).to({scaleX:0.9814,scaleY:1.0983,skewX:-4.4114,skewY:-0.1671,x:430.65,y:70.8},0).wait(1).to({scaleX:0.9935,scaleY:1.1103,skewX:-4.1851,skewY:-0.0348,x:429.55,y:68.25},0).wait(1).to({scaleX:1.0077,scaleY:1.1245,skewX:-3.9189,skewY:0.1209,x:428.55,y:65.55},0).wait(1).to({scaleX:1.0241,scaleY:1.1408,skewX:-3.6112,skewY:0.3008,x:427.4,y:62.15},0).wait(1).to({scaleX:1.0428,scaleY:1.1595,skewX:-3.2603,skewY:0.506,x:425.35,y:56.7},0).wait(1).to({scaleX:1.0639,scaleY:1.1805,skewX:-2.8648,skewY:0.7373,x:423.1,y:51.1},0).wait(1).to({scaleX:1.0875,scaleY:1.204,skewX:-2.4233,skewY:0.9954,x:420.9,y:45.85},0).wait(1).to({scaleX:1.1136,scaleY:1.23,skewX:-1.9346,skewY:1.2812,x:418.65,y:40.75},0).wait(1).to({scaleX:1.1422,scaleY:1.2585,skewX:-1.3977,skewY:1.5952,x:416.4,y:35.55},0).wait(1).to({scaleX:1.1735,scaleY:1.2896,skewX:-0.8121,skewY:1.9376,x:414.25,y:30.75},0).wait(1).to({scaleX:1.2073,scaleY:1.3234,skewX:-0.1775,skewY:2.3087,x:412.2,y:26.25},0).wait(1).to({scaleX:1.2438,scaleY:1.3597,skewX:0.5055,skewY:2.7081,x:409.85,y:21.2},0).wait(1).to({scaleX:1.2828,scaleY:1.3985,skewX:1.2361,skewY:3.1353,x:407.2,y:15.8},0).wait(1).to({scaleX:1.3241,scaleY:1.4398,skewX:2.0123,skewY:3.5892,x:404.1,y:9.65},0).wait(1).to({scaleX:1.3679,scaleY:1.4833,skewX:2.8314,skewY:4.0682,x:400.2,y:3.25},0).wait(1).to({scaleX:1.4137,scaleY:1.5289,skewX:3.6897,skewY:4.5701,x:395.85,y:-2.45},0).wait(1).to({scaleX:1.4614,scaleY:1.5764,skewX:4.5828,skewY:5.0923,x:390.3,y:-7.9},0).wait(1).to({scaleX:1.5106,scaleY:1.6254,skewX:5.505,skewY:5.6316,x:382.7,y:-12.4},0).wait(1).to({regX:19.6,regY:23.5,scaleX:1.561,scaleY:1.6757,skewX:6.4499,skewY:6.1841,x:373.4,y:-15.85},0).wait(1).to({regX:19.1,regY:24.2,scaleX:1.5312,scaleY:1.6392,skewX:5.6627,skewY:5.4703,x:362.5,y:-15.6},0).wait(1).to({scaleX:1.5013,scaleY:1.6023,skewX:4.869,skewY:4.7505,x:353.15,y:-14.75},0).wait(1).to({scaleX:1.4712,scaleY:1.5654,rotation:4.0744,skewX:0,skewY:0,x:344.25,y:-11.8},0).wait(1).to({scaleX:1.4414,scaleY:1.5288,rotation:3.2849,x:335.95,y:-6.4},0).wait(1).to({scaleX:1.4119,scaleY:1.4926,rotation:0,skewX:2.506,skewY:2.6077,x:328.9,y:0.25},0).wait(1).to({scaleX:1.3831,scaleY:1.4571,skewX:1.7428,skewY:1.9157,x:322.95,y:7.45},0).wait(1).to({scaleX:1.3551,scaleY:1.4227,skewX:1.0001,skewY:1.2422,x:318,y:15.3},0).wait(1).to({scaleX:1.3279,scaleY:1.3893,skewX:0.2819,skewY:0.5909,x:314.15,y:23.55},0).wait(1).to({scaleX:1.3018,scaleY:1.3573,skewX:-0.4085,skewY:-0.0351,x:311.15,y:32.45},0).wait(1).to({scaleX:1.2769,scaleY:1.3267,skewX:-1.0682,skewY:-0.6334,x:308.9,y:41.9},0).wait(1).to({scaleX:1.2532,scaleY:1.2975,skewX:-1.6953,skewY:-1.2021,x:307.4,y:50.4},0).wait(1).to({scaleX:1.2308,scaleY:1.27,skewX:-2.2883,skewY:-1.7398,x:305.75,y:62.7},0).wait(1).to({scaleX:1.2098,scaleY:1.2441,skewX:-2.8463,skewY:-2.2458,x:304.5,y:72.2},0).wait(1).to({scaleX:1.19,scaleY:1.2199,skewX:-3.3688,skewY:-2.7196,x:303.65,y:77.75},0).wait(1).to({regX:19.6,regY:23.7,scaleX:1.1716,scaleY:1.1972,skewX:-3.8557,skewY:-3.1612,x:303.2,y:82.2},0).wait(1).to({regX:19.1,regY:24.2,scaleX:1.151,scaleY:1.1736,skewX:-3.3935,skewY:-2.7822,x:297.35,y:87.55},0).wait(1).to({scaleX:1.132,scaleY:1.1517,skewX:-2.9646,skewY:-2.4306,x:292.45,y:92},0).wait(1).to({scaleX:1.1143,scaleY:1.1314,skewX:-2.5685,skewY:-2.1058,x:287.9,y:96},0).wait(1).to({scaleX:1.0981,scaleY:1.1128,skewX:-2.2045,skewY:-1.8074,x:283.75,y:99.8},0).wait(1).to({scaleX:1.0833,scaleY:1.0958,skewX:-1.8716,skewY:-1.5345,x:279.95,y:103.2},0).wait(1).to({scaleX:1.0699,scaleY:1.0803,skewX:-1.5691,skewY:-1.2864,x:276.45,y:106.35},0).wait(1).to({scaleX:1.0577,scaleY:1.0663,skewX:-1.2959,skewY:-1.0625,x:273.35,y:109.15},0).wait(1).to({scaleX:1.0468,scaleY:1.0538,skewX:-1.0511,skewY:-0.8618,x:270.55,y:111.65},0).wait(1).to({scaleX:1.0371,scaleY:1.0427,skewX:-0.8337,skewY:-0.6835,x:268.05,y:113.9},0).wait(1).to({scaleX:1.0286,scaleY:1.0329,skewX:-0.6428,skewY:-0.527,x:265.9,y:115.85},0).wait(1).to({scaleX:1.0213,scaleY:1.0245,skewX:-0.4773,skewY:-0.3913,x:263.95,y:117.55},0).wait(1).to({scaleX:1.015,scaleY:1.0173,skewX:-0.3364,skewY:-0.2758,x:262.4,y:119},0).wait(1).to({scaleX:1.0098,scaleY:1.0112,rotation:-0.2191,skewX:0,skewY:0,x:261.05,y:120.2},0).wait(1).to({scaleX:1.0056,scaleY:1.0064,rotation:-0.1245,x:259.95,y:121.15},0).wait(1).to({scaleX:1.0023,scaleY:1.0027,rotation:-0.0517,x:259.1,y:121.95},0).wait(1).to({regX:19,regY:24,scaleX:1,scaleY:1,rotation:0,x:259,y:122},0).wait(135));

	// maskPhoto2 copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_43 = new cjs.Graphics().p("Ab5h0IGwgFQgBABAaFXIAbFYImvADg");
	var mask_2_graphics_51 = new cjs.Graphics().p("Ab5h0IGwgFQgBABAaFXIAbFYImvADg");
	var mask_2_graphics_52 = new cjs.Graphics().p("AauiQIH9gFQgBABAaFlIAaFmIn9ADg");
	var mask_2_graphics_53 = new cjs.Graphics().p("AZjisIJMgGQgCABAZF0IAZF0IpLADg");
	var mask_2_graphics_54 = new cjs.Graphics().p("AYYjJIKagFQgBABAXGBIAXGDIqZACg");
	var mask_2_graphics_55 = new cjs.Graphics().p("AXOjlILpgFQgCABAVGPIAWGQIrnADg");
	var mask_2_graphics_56 = new cjs.Graphics().p("AWFkAIM3gGQgCABATGdIATGeIs1ADg");
	var mask_2_graphics_57 = new cjs.Graphics().p("AU8kcIOGgGQgCABAPGrIARGsIuDADg");
	var mask_2_graphics_58 = new cjs.Graphics().p("AT0k3IPUgGQgCABANG5IANG5IvRADg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(43).to({graphics:mask_2_graphics_43,x:226.8502,y:56.9755}).wait(8).to({graphics:mask_2_graphics_51,x:226.8502,y:56.9755}).wait(1).to({graphics:mask_2_graphics_52,x:226.9598,y:56.9693}).wait(1).to({graphics:mask_2_graphics_53,x:227.0509,y:56.9592}).wait(1).to({graphics:mask_2_graphics_54,x:227.1237,y:56.945}).wait(1).to({graphics:mask_2_graphics_55,x:227.1782,y:56.9261}).wait(1).to({graphics:mask_2_graphics_56,x:227.2144,y:56.9022}).wait(1).to({graphics:mask_2_graphics_57,x:227.2325,y:56.8728}).wait(1).to({graphics:mask_2_graphics_58,x:227.2259,y:56.9014}).wait(1).to({graphics:null,x:0,y:0}).wait(181));

	// photo 2 copy 5
	this.instance_6 = new lib.photo1();
	this.instance_6.setTransform(471.3,78.85,0.9499,1.067,0,-4.0004,-0.5035,19.2,23.8);
	this.instance_6._off = true;

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(43).to({_off:false},0).wait(1).to({regX:19.1,regY:24.2,skewX:-4.0332,skewY:-0.5037,x:470.05,y:79.25},0).wait(1).to({skewX:-4.0957,skewY:-0.5043,x:467.9},0).wait(1).to({skewX:-4.1924,skewY:-0.5051,x:464.6},0).wait(1).to({skewX:-4.3268,skewY:-0.5062,x:459.9},0).wait(1).to({scaleY:1.0669,skewX:-4.4984,skewY:-0.5076,x:453.95},0).wait(1).to({scaleY:1.067,skewX:-4.6949,skewY:-0.5092,x:447.1},0).wait(1).to({skewX:-4.8808,skewY:-0.5107,x:440.7},0).wait(1).to({regX:19.3,regY:23.8,skewX:-5.0007,skewY:-0.5117,x:436.6,y:78.85},0).to({_off:true},1).wait(188));

	// maskPhoto1 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_41 = new cjs.Graphics().p("AX+lUIGvgFQgBABAaFYIAbFXImvADg");
	var mask_3_graphics_54 = new cjs.Graphics().p("AX+lUIGvgFQgBABAaFYIAbFXImvADg");
	var mask_3_graphics_55 = new cjs.Graphics().p("AWyliIH+gFQgBABAZFmIAaFlIn9ADg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AVnlwIJMgFQgBABAYF0IAZF0IpLACg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AUcl+IKbgFQgCABAXGCIAXGCIqYACg");
	var mask_3_graphics_58 = new cjs.Graphics().p("ATSmLILpgGQgCABAVGQIAWGPIrnADg");
	var mask_3_graphics_59 = new cjs.Graphics().p("ASJmZIM3gGQgCABATGeIATGdIs1ADg");
	var mask_3_graphics_60 = new cjs.Graphics().p("ARBmnIOFgGQgCABAQGsIARGrIuEADg");
	var mask_3_graphics_61 = new cjs.Graphics().p("AP5m0IPUgHQgDACANG5IAOG4IvSAEg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(41).to({graphics:mask_3_graphics_41,x:201.6752,y:1.3255}).wait(13).to({graphics:mask_3_graphics_54,x:201.6752,y:1.3255}).wait(1).to({graphics:mask_3_graphics_55,x:201.7848,y:-0.1145}).wait(1).to({graphics:mask_3_graphics_56,x:201.8759,y:-1.5535}).wait(1).to({graphics:mask_3_graphics_57,x:201.9487,y:-2.9911}).wait(1).to({graphics:mask_3_graphics_58,x:202.0032,y:-4.4275}).wait(1).to({graphics:mask_3_graphics_59,x:202.0394,y:-5.8623}).wait(1).to({graphics:mask_3_graphics_60,x:202.0575,y:-7.2955}).wait(1).to({graphics:mask_3_graphics_61,x:202.0509,y:-8.5986}).wait(1).to({graphics:null,x:0,y:0}).wait(178));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_174 = new cjs.Graphics().p("AX+PhIAA0UIAcAAIAAUUg");
	var mask_4_graphics_175 = new cjs.Graphics().p("AX5PhIAA0UIAjAAIAAUUg");
	var mask_4_graphics_176 = new cjs.Graphics().p("AXqPgIAA0SIA3AAIAAUSg");
	var mask_4_graphics_177 = new cjs.Graphics().p("AXSPgIAA0RIBXAAIAAURg");
	var mask_4_graphics_178 = new cjs.Graphics().p("AWwPfIAA0OICEAAIAAUOg");
	var mask_4_graphics_179 = new cjs.Graphics().p("AWGPfIAA0MIC8AAIAAUMg");
	var mask_4_graphics_180 = new cjs.Graphics().p("AVUPeIAA0IID/AAIAAUIg");
	var mask_4_graphics_181 = new cjs.Graphics().p("AUaPdIAA0EIFMAAIAAUEg");
	var mask_4_graphics_182 = new cjs.Graphics().p("ATbPcIAA0AIGgAAIAAUAg");
	var mask_4_graphics_183 = new cjs.Graphics().p("ASWPaIAAz6IH8AAIAAT6g");
	var mask_4_graphics_184 = new cjs.Graphics().p("ARNPZIAAz2IJdAAIAAT2g");
	var mask_4_graphics_185 = new cjs.Graphics().p("AQAPYIAAzxILEAAIAATxg");
	var mask_4_graphics_186 = new cjs.Graphics().p("AOyPWIAAzqIMsAAIAATqg");
	var mask_4_graphics_187 = new cjs.Graphics().p("ANkPVIAAzlIOUAAIAATlg");
	var mask_4_graphics_188 = new cjs.Graphics().p("AMWPUIAAzgIP8AAIAATgg");
	var mask_4_graphics_189 = new cjs.Graphics().p("ALKPSIAAzaIRhAAIAATag");
	var mask_4_graphics_190 = new cjs.Graphics().p("AKAPRIAAzVITEAAIAATVg");
	var mask_4_graphics_191 = new cjs.Graphics().p("AI7PQIAAzRIUgAAIAATRg");
	var mask_4_graphics_192 = new cjs.Graphics().p("AH8PPIAAzMIV0AAIAATMg");
	var mask_4_graphics_193 = new cjs.Graphics().p("AHDPOIAAzIIXAAAIAATIg");
	var mask_4_graphics_194 = new cjs.Graphics().p("AGQPNIAAzFIYDAAIAATFg");
	var mask_4_graphics_195 = new cjs.Graphics().p("AFmPMIAAzCIY7AAIAATCg");
	var mask_4_graphics_196 = new cjs.Graphics().p("AFFPLIAAy/IZoAAIAAS/g");
	var mask_4_graphics_197 = new cjs.Graphics().p("AEsPLIAAy+IaJAAIAAS+g");
	var mask_4_graphics_198 = new cjs.Graphics().p("AEePLIAAy9IacAAIAAS9g");
	var mask_4_graphics_199 = new cjs.Graphics().p("AEZPLIAAy9IajAAIAAS9g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(174).to({graphics:mask_4_graphics_174,x:156.2488,y:99.2749}).wait(1).to({graphics:mask_4_graphics_175,x:156.4131,y:99.2661}).wait(1).to({graphics:mask_4_graphics_176,x:156.9035,y:99.2399}).wait(1).to({graphics:mask_4_graphics_177,x:157.7121,y:99.1968}).wait(1).to({graphics:mask_4_graphics_178,x:158.8264,y:99.1373}).wait(1).to({graphics:mask_4_graphics_179,x:160.2286,y:99.0624}).wait(1).to({graphics:mask_4_graphics_180,x:161.8967,y:98.9734}).wait(1).to({graphics:mask_4_graphics_181,x:163.8044,y:98.8716}).wait(1).to({graphics:mask_4_graphics_182,x:165.9216,y:98.7586}).wait(1).to({graphics:mask_4_graphics_183,x:168.2148,y:98.6362}).wait(1).to({graphics:mask_4_graphics_184,x:170.648,y:98.5063}).wait(1).to({graphics:mask_4_graphics_185,x:173.1827,y:98.371}).wait(1).to({graphics:mask_4_graphics_186,x:175.7791,y:98.2324}).wait(1).to({graphics:mask_4_graphics_187,x:178.396,y:98.0927}).wait(1).to({graphics:mask_4_graphics_188,x:180.9923,y:97.9541}).wait(1).to({graphics:mask_4_graphics_189,x:183.5271,y:97.8188}).wait(1).to({graphics:mask_4_graphics_190,x:185.9602,y:97.689}).wait(1).to({graphics:mask_4_graphics_191,x:188.2535,y:97.5666}).wait(1).to({graphics:mask_4_graphics_192,x:190.3707,y:97.4535}).wait(1).to({graphics:mask_4_graphics_193,x:192.2783,y:97.3517}).wait(1).to({graphics:mask_4_graphics_194,x:193.9464,y:97.2627}).wait(1).to({graphics:mask_4_graphics_195,x:195.3487,y:97.1878}).wait(1).to({graphics:mask_4_graphics_196,x:196.4629,y:97.1284}).wait(1).to({graphics:mask_4_graphics_197,x:197.2716,y:97.0852}).wait(1).to({graphics:mask_4_graphics_198,x:197.762,y:97.059}).wait(1).to({graphics:mask_4_graphics_199,x:197.9763,y:97.0502}).wait(41));

	// bg
	this.instance_7 = new lib.powerpointUI_mc();
	this.instance_7.setTransform(311.5,133.5,1,1,0,0,0,83.5,46.5);
	this.instance_7._off = true;

	var maskedShapeInstanceList = [this.instance_7];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(174).to({_off:false},0).wait(66));

	// base path anim copy
	this.base = new lib.base();
	this.base.name = "base";
	this.base.setTransform(439.3,76.55,0.1237,0.157,-3.7559,0,0,103.2,83.9);

	this.timeline.addTween(cjs.Tween.get(this.base).wait(1).to({regX:100.5,scaleX:0.1293,scaleY:0.1637,rotation:-3.755,x:438.1,y:76.5},0).wait(1).to({regX:102.6,regY:83.4,scaleX:0.1368,scaleY:0.1727,rotation:-3.7538,x:437.4,y:76.4},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.139,scaleY:0.1747,rotation:-3.7439,x:436,y:76.35},0).wait(1).to({regX:102.9,regY:83.7,scaleX:0.1416,scaleY:0.1772,rotation:-3.7317,x:434.9,y:76.05},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.1447,scaleY:0.1802,rotation:-3.7168,x:433.55,y:75.75},0).wait(1).to({regX:103,regY:83.6,scaleX:0.1484,scaleY:0.1838,rotation:-3.6992,x:432.75,y:75.35},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.1527,scaleY:0.1879,rotation:-3.6797,x:431,y:74.85},0).wait(1).to({regX:103.5,regY:83.7,scaleX:0.1576,scaleY:0.1926,rotation:-3.6573,x:429.95,y:74.15},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.1632,scaleY:0.1979,rotation:-3.6313,x:427.75,y:73.25},0).wait(1).to({regX:103.6,regY:83.5,scaleX:0.1695,scaleY:0.204,rotation:-3.6017,x:426.4,y:72.2},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.1767,scaleY:0.2109,rotation:-3.5696,x:423.9,y:70.85},0).wait(1).to({regX:103.7,regY:83.5,scaleX:0.1848,scaleY:0.2186,rotation:-3.5334,x:422.3,y:69.1},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.1938,scaleY:0.2273,rotation:-3.4933,x:419.6,y:66.85},0).wait(1).to({regX:103.8,regY:83.5,scaleX:0.2039,scaleY:0.2369,rotation:-3.4484,x:417.85,y:64.15},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.2151,scaleY:0.2477,rotation:-3.3989,x:414.9,y:61.05},0).wait(1).to({scaleX:0.2277,scaleY:0.2598,rotation:-3.3438,x:412.3,y:57.5},0).wait(1).to({regX:103.8,regY:83.7,scaleX:0.2417,scaleY:0.2732,rotation:-3.2824,x:410.25,y:53.45},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.2572,scaleY:0.2881,rotation:-3.2148,x:406.3,y:49.3},0).wait(1).to({scaleX:0.2746,scaleY:0.3047,rotation:-3.1395,x:402.9,y:44.55},0).wait(1).to({regX:104,scaleX:0.2938,scaleY:0.3232,rotation:-3.0557,x:400.05,y:39.3},0).wait(1).to({regX:100.5,scaleX:0.3153,scaleY:0.3438,rotation:-2.9626,x:393.75,y:34.25},0).wait(1).to({scaleX:0.3392,scaleY:0.3666,rotation:-2.859,x:387.95,y:28.7},0).wait(1).to({regX:104.1,regY:83.7,scaleX:0.3657,scaleY:0.392,rotation:-2.7439,x:382.65,y:22.5},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.3951,scaleY:0.4202,rotation:-2.617,x:372.55,y:17.7},0).wait(1).to({regX:104.2,regY:83.7,scaleX:0.4274,scaleY:0.4512,rotation:-2.4772,x:364.55,y:12.15},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.4627,scaleY:0.485,rotation:-2.3238,x:351.55,y:9},0).wait(1).to({regX:104.2,regY:83.7,scaleX:0.5006,scaleY:0.5213,rotation:-2.159,x:341.2,y:5.25},0).to({scaleX:0.5405,scaleY:0.5596,rotation:-1.9861,x:327.5,y:4.4},1).wait(1).to({regX:100.5,regY:83.9,scaleX:0.5815,scaleY:0.5989,rotation:-1.8089,x:312.65,y:9.25},0).wait(1).to({regX:104.2,regY:83.7,scaleX:0.6224,scaleY:0.638,rotation:-1.6322,x:302.15,y:13.7},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.662,scaleY:0.676,rotation:-1.4611,x:292.65,y:24.85},0).wait(1).to({scaleX:0.6993,scaleY:0.7118,rotation:-1.2997,x:285.75,y:35.2},0).wait(1).to({regX:104.2,regY:83.7,scaleX:0.7338,scaleY:0.7449,rotation:-1.1503,x:282.2,y:44.55},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.7653,scaleY:0.775,rotation:-1.0144,x:278.9,y:55.4},0).wait(1).to({scaleX:0.7937,scaleY:0.8023,rotation:-0.8917,x:278.35,y:64.95},0).wait(1).to({regX:104.2,regY:83.6,scaleX:0.8192,scaleY:0.8267,rotation:-0.7815,x:280.9,y:73.3},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.842,scaleY:0.8486,rotation:-0.6829,x:279.7,y:81},0).wait(1).to({scaleX:0.8624,scaleY:0.8681,rotation:-0.5949,x:281.35,y:87.65},0).wait(1).to({regX:104.4,regY:83.6,scaleX:0.8805,scaleY:0.8855,rotation:-0.5164,x:286.15,y:93.25},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.8967,scaleY:0.901,rotation:-0.447,x:285.1,y:98.45},0).wait(1).to({regX:104.4,regY:83.6,scaleX:0.9111,scaleY:0.9148,rotation:-0.3851,x:290.7,y:102.55},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.9239,scaleY:0.9271,rotation:-0.3303,x:289.9,y:106.4},0).wait(1).to({regX:104.4,regY:83.7,scaleX:0.9353,scaleY:0.938,rotation:-0.2815,x:296.05,y:109.35},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.9455,scaleY:0.9477,rotation:-0.2374,x:294.65,y:111.95},0).wait(1).to({regX:104.5,regY:83.7,scaleX:0.9544,scaleY:0.9563,rotation:-0.1984,x:300.55,y:113.9},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.9623,scaleY:0.9638,rotation:-0.164,x:298.8,y:115.6},0).wait(1).to({scaleX:0.9692,scaleY:0.9705,rotation:-0.1338,x:300.65,y:116.9},0).wait(1).to({regX:104.5,regY:83.7,scaleX:0.9752,scaleY:0.9762,rotation:-0.1075,x:306.15,y:117.85},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.9805,scaleY:0.9813,rotation:-0.0847,x:303.9,y:118.65},0).wait(1).to({scaleX:0.985,scaleY:0.9856,rotation:-0.0652,x:305.35,y:119.2},0).wait(1).to({regX:104.5,regY:83.7,scaleX:0.9888,scaleY:0.9892,rotation:-0.0486,x:310.45,y:119.4},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.992,scaleY:0.9923,rotation:-0.0349,x:307.2,y:119.75},0).wait(1).to({scaleX:0.9946,scaleY:0.9948,rotation:-0.0237,x:307.85,y:119.9},0).wait(1).to({regX:104.6,regY:83.8,scaleX:0.9967,scaleY:0.9968,rotation:-0.0149,x:312.35},0).wait(1).to({regX:100.5,regY:83.9,scaleX:0.9982,scaleY:0.9983,rotation:-0.0078,x:308.25,y:119.65},0).wait(1).to({scaleX:0.9993,scaleY:0.9993,rotation:-0.0029,x:308.3,y:119.45},0).wait(1).to({regX:102.3,regY:83.2,scaleX:0.9999,scaleY:0.9999,rotation:0,x:312.4,y:119.25},0).to({regX:100,regY:84,scaleX:1,scaleY:1,x:311,y:120},1).wait(182));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(194.3,-71.9,318.90000000000003,278.4);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-13.2,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-102.6,-20,107.89999999999999,39.7), null);


(lib.white_boxes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// box_1
	this.box_1 = new lib.box_c();
	this.box_1.name = "box_1";
	this.box_1.setTransform(150,45.5,1.2,0.3642,0,0,0,75,125);

	this.timeline.addTween(cjs.Tween.get(this.box_1).wait(1));

	// box_2
	this.box_2 = new lib.box_c();
	this.box_2.name = "box_2";
	this.box_2.setTransform(150,45.5,1.2,0.3642,0,0,0,75,125);
	this.box_2.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.box_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white_boxes, new cjs.Rectangle(60,0,180,91.1), null);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A0fUDMAAAgoFMAo/AAAMAAAAoFg");
	mask.setTransform(150.075,118.25);

	// UI anim
	this.anim = new lib.anim();
	this.anim.name = "anim";
	this.anim.setTransform(116.3,59,0.5,0.5,0,0,0,387.8,7.9);

	var maskedShapeInstanceList = [this.anim];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// Layer_4
	this.instance = new lib.Creators_bg_728x90_sm();
	this.instance.setTransform(15.35,15.15,1.61,1.61);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(15.1,9.8,263,208.6), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.25,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(673.3,54.7,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(673.5,54.1,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// final screen
	this.endUI = new lib.final_screen();
	this.endUI.name = "endUI";
	this.endUI.setTransform(215.5,45.35,1,1,0,0,0,125,94.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// White_box
	this.boxes = new lib.white_boxes();
	this.boxes.name = "boxes";
	this.boxes.setTransform(157.5,125,1,1,0,0,0,75,125);

	this.timeline.addTween(cjs.Tween.get(this.boxes).wait(1));

	// bg image
	this.bg = new lib.bg();
	this.bg.name = "bg";
	this.bg.setTransform(219.95,52.05,0.62,0.62,0,0,0,136.6,105.8);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	// bg
	this.box_1 = new lib.box_c();
	this.box_1.name = "box_1";
	this.box_1.setTransform(363.8,45.25,4.8635,0.3642,0,0,0,74.9,125);

	this.timeline.addTween(cjs.Tween.get(this.box_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-0.4,-19.8,729.8,159.10000000000002), null);


// stage content:
(lib.M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
		
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		var box1 = mc.boxes.box_1
		var box2 = mc.boxes.box_2
		var anim = mc.bg.anim
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
		
				this.tl1.from(exportRoot.headline1,{duration:0.8, x: "+=50", alpha: 0, stagger: 0.1, ease:Power4.easeOut}, "+0.4");
				this.tl1.from(exportRoot.headline2,{duration:0.8, x: "+=50", alpha: 0, stagger: 0.1, ease:Power4.easeOut}, ">-0.6");
				
				this.tl1.from(exportRoot,{duration:0.3, onComplete:function(){ anim.play();}})
				this.tl1.to(anim.base.overlay,{duration:0.5, alpha: 0,  ease:Power4.easeInOut}, "<+0.2");		
		
				this.tl1.from(box2,{duration:1, x: "+=170",  ease:Power4.easeOut}, "+9.3");
				this.tl1.from(box1,{duration:1, x: "+=170",  ease:Power4.easeOut}, ">-.8");		
				//this.tl1.to(mc.bg,{duration:1.2, x: "-=200", alpha: 0, ease:Power4.easeIn}, "+7.8");		
				this.tl1.from(mc.endUI,{duration:1.2, x: "+=60", alpha: 0, ease:Power4.easeOut}, "<+0.5");		
			
			
				this.tl1.from(mc.cta , 0.8, { x: "+=160", ease:Power4.easeOut}, ">-0.6");
				this.tl1.from(mc.txtCta, 0.8, { x: "+=160", alpha: 0, ease:Power4.easeOut}, ">-0.8");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				
				exportRoot.tl1.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
		
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(363.6,25.2,365.79999999999995,114.10000000000001);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1.png?1633418254627", id:"M365_Creators_AUS_728x90_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;