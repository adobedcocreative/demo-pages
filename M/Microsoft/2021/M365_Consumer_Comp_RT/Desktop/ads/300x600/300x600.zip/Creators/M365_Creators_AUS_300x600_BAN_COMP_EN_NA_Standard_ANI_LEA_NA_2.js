(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1", frames: [[0,0,343,257],[290,259,200,168],[345,0,167,93],[0,259,288,218],[290,429,168,31],[385,136,52,22],[460,429,38,48],[345,95,38,48],[385,95,40,39]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._300x600_BG = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.base = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.bg = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.FinalScreen_lg1 = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.pagePeelSml = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.photo3 = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.photo1 = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.photo2 = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.PurpleSticker = function() {
	this.initialize(ss["M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIshadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("At/LSIAAxhIhNAAIAAlCIEpAAIAADSIZwAAIAATRg");
	this.shape.setTransform(97.275,72.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIshadow, new cjs.Rectangle(0,0,194.6,144.4), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pagePeelSml();
	this.instance.setTransform(-83.9,-15.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.9,-15.6,168,31);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCX8MAAAkv3MCZbAAAMAAAEv3g");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-972.3,982,1944.6999999999998);


(lib.sticker = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PurpleSticker();
	this.instance.setTransform(-0.3,0.55,0.48,0.48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sticker, new cjs.Rectangle(-0.3,0,19.3,20), null);


(lib.screen_overlay = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(85,85,85,0.557)").s().p("AugNKQg8AAAAg8IAA4bQAAg8A8AAIdBAAQA8AAAAA8IAAYbQAAA8g8AAg");
	this.shape.setTransform(98.9015,84.2013);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_overlay, new cjs.Rectangle(0,0,197.8,168.4), null);


(lib.powerpointUI_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bg();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.powerpointUI_mc, new cjs.Rectangle(0,0,167,93), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,600), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.box_Cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A1HTxMAAAgnhMAqPAAAMAAAAnhg");
	this.shape.setTransform(135.175,123.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_Cache, new cjs.Rectangle(0,-2.9,270.4,253), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("ApgDXIAAmtITBAAIAAGtg");
	this.shape.setTransform(46.375,12.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-14.5,-8.6,121.8,43), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.photo3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_49 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(49).call(this.frame_49).wait(2));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_12 = new cjs.Graphics().p("AkCBtIAAjZIIFAAIAADZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_graphics_12,x:26.225,y:11.1}).wait(33).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_3
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(0.2,23.85,0.263,0.0495,-90,0,0,0.2,-14.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2628,scaleY:0.0527,x:0.95,y:23.8},0).wait(1).to({scaleX:0.2623,scaleY:0.0598,x:1.15,y:23.75},0).wait(1).to({scaleX:0.2614,scaleY:0.0717,x:1.45,y:23.7},0).wait(1).to({scaleX:0.2601,scaleY:0.0897,x:1.9,y:23.55},0).wait(1).to({scaleX:0.2582,scaleY:0.115,x:2.55,y:23.4},0).wait(1).to({scaleX:0.2557,scaleY:0.1487,x:3.4,y:23.2},0).wait(1).to({scaleX:0.2527,scaleY:0.189,x:4.45,y:22.95},0).wait(1).to({scaleX:0.2498,scaleY:0.2279,x:5.45,y:22.75},0).wait(1).to({scaleX:0.2479,scaleY:0.2533,x:6.05,y:22.55},0).wait(1).to({regX:0,regY:-15.2,scaleX:0.2473,scaleY:0.2612,x:2.65,y:22.5},0).wait(13).to({startPosition:0},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2476,scaleY:0.2574,x:6.4},0).wait(1).to({scaleX:0.2482,scaleY:0.2486,x:6.25,y:22.55},0).wait(1).to({scaleX:0.2494,scaleY:0.2336,x:5.85,y:22.65},0).wait(1).to({scaleX:0.2511,scaleY:0.2107,x:5.25,y:22.75},0).wait(1).to({scaleX:0.2535,scaleY:0.178,x:4.35,y:22.95},0).wait(1).to({scaleX:0.2567,scaleY:0.1355,x:3.2,y:23.25},0).wait(1).to({scaleX:0.26,scaleY:0.0906,x:2,y:23.5},0).wait(1).to({scaleX:0.2623,scaleY:0.0593,x:1.2,y:23.7},0).wait(1).to({regX:0.2,regY:-14.2,scaleX:0.263,scaleY:0.0495,x:0.2,y:23.85},0).to({_off:true},1).wait(6));

	// panelMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_9 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QABiIAChAQACg6AGhrIAHhuQABgNBGgDQAhgBAhABIAAAAIMRAAIAAJmg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AkYEvIAAAAIiLAAIAAh4QABiGAChAQACg5AGhpIAGhtQAAgNA/gDQAdgBAeABIAAAAIK8AAIAAJdg");
	var mask_1_graphics_11 = new cjs.Graphics().p("Aj8EsIgBAAIh9AAIABh3QAAiFACg/IAHigIAFhsQABgMA4gDQAbgCAaABIAAAAIJ4AAIAAJXg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Aj0EpIgBAAIh5AAIAAh2QABiDACg/IAGifIAGhqQAAgNA3gCQAagCAZABIAAAAIJkAAIAAJRg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AkSEpIAAAAIiJAAIABh3QABiCACg+QABg5AGhmIAGhqQABgNA9gDQAdgBAdABIAAAAIKvAAIAAJQg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AlEEoIAAAAIihAAIAAh2QABiCACg+QADg4AGhnIAHhpQABgNBIgDQAigBAjABIAAAAIMtAAIAAJOg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AmOEmIgBAAIjHAAIABh1QABiCADg9QADg4AIhmIAIhpQABgMBZgDQArgCAqABIAAAAIPqAAIAAJLg");
	var mask_1_graphics_17 = new cjs.Graphics().p("An4EkIgBAAIj7AAIABh0QABiBAEg9QADg3AKhlIALhpQACgMBwgDQA2gCA1ABIAAAAIT1ABIAAJGg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AqEEhIgBAAIlCAAIABhzQACh/AFg9QAEg3ANhkIAOhnQACgNCQgCQBEgCBFABIAAAAIZXAAIAAJBg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AssEeIgCAAImWAAIAChyQACh+AGg8QAGg2AQhjIAShmQACgMC1gDQBXgBBWABIAAAAMAgBAAAIAAI6g");
	var mask_1_graphics_20 = new cjs.Graphics().p("AvOEbIgCAAInnAAIAChxQADh8AHg8QAGg1AUhiIAVhlQADgMDagDQBogBBnABIAAAAMAmbAAAIAAI0g");
	var mask_1_graphics_21 = new cjs.Graphics().p("Aw4EZIgCAAIocAAIAChwQADh8AIg6QAHg2AWhgIAYhlQACgMDygCQBzgCBzABIAAAAMAqmAAAIAAIwg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_1_graphics_35 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_1_graphics_36 = new cjs.Graphics().p("AxIEYIgDAAIokAAIAChvQADh8AIg6QAIg1AWhhIAYhkQACgMD2gDQB1gBB0ABIAAAAMArSAAAIAAIug");
	var mask_1_graphics_37 = new cjs.Graphics().p("AwkEZIgCAAIoSAAIAChwQADh7AIg7QAHg1AVhhIAXhlQADgMDtgDQBxgBBxABIAAAAMAp1AAAIAAIwg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AvlEaIgDAAInyAAIABhwQADh8AIg7QAGg2AVhhIAVhlQADgMDfgDQBrgBBpABIAAAAMAnYAAAIAAIyg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AuGEcIgCAAInDAAIAChxQACh9AHg7QAGg2AShiIAUhmQACgMDKgDQBggBBgABIAAAAMAjmAAAIAAI2g");
	var mask_1_graphics_40 = new cjs.Graphics().p("Ar+EfIgBAAIl/AAIABhyQACh/AGg8QAFg2AQhjIAQhnQACgMCsgDQBRgBBSABIAAAAIeMAAIAAI8g");
	var mask_1_graphics_41 = new cjs.Graphics().p("ApNEjIgBAAIkmAAIABh0QACiAAEg9QAEg3AMhkIANhoQABgMCEgDQA/gCA+ABIAAAAIXNABIAAJDg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AmSEmIgBAAIjIAAIAAh1QACiBADg+QACg4AIhlIAJhqQABgMBagDQArgBAqABIAAAAIP0AAIAAJKg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkQEpIAAAAIiHAAIAAh2QABiDACg+QACg4AFhnIAGhqQABgNA8gDQAdgBAdABIAAAAIKqAAIAAJQg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AjsEqIAAAAIh1AAIAAh3QABiDACg/IAGifIAFhrQABgMA0gDQAZgCAZABIAAAAIJOAAIAAJTg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Aj6EsIAAAAIh8AAIAAh4QABiEACg/IAHigIAFhrQABgNA3gDQAbgBAaABIAAAAIJxAAIAAJWg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AkVEvIAAAAIiKAAIABh5QAAiFAChAQACg5AGhpIAGhsQAAgNA+gDQAdgCAeABIAAAAIK1AAIAAJdg");
	var mask_1_graphics_48 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QABiIAChAQACg6AGhrIAHhuQABgNBGgDQAhgBAhABIAAAAIMRAAIAAJmg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_1_graphics_9,x:44.9351,y:29.7504}).wait(1).to({graphics:mask_1_graphics_10,x:40.7363,y:29.7504}).wait(1).to({graphics:mask_1_graphics_11,x:37.2966,y:29.7504}).wait(1).to({graphics:mask_1_graphics_12,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_1_graphics_13,x:36.7293,y:29.7236}).wait(1).to({graphics:mask_1_graphics_14,x:41.2626,y:29.6643}).wait(1).to({graphics:mask_1_graphics_15,x:48.8675,y:29.5647}).wait(1).to({graphics:mask_1_graphics_16,x:60.2864,y:29.4152}).wait(1).to({graphics:mask_1_graphics_17,x:76.3943,y:29.2043}).wait(1).to({graphics:mask_1_graphics_18,x:97.8279,y:28.9236}).wait(1).to({graphics:mask_1_graphics_19,x:123.5404,y:28.587}).wait(1).to({graphics:mask_1_graphics_20,x:148.2589,y:28.2633}).wait(1).to({graphics:mask_1_graphics_21,x:164.4291,y:28.0516}).wait(1).to({graphics:mask_1_graphics_22,x:169.5201,y:28.0106}).wait(13).to({graphics:mask_1_graphics_35,x:169.5201,y:28.0106}).wait(1).to({graphics:mask_1_graphics_36,x:167.1132,y:28.0422}).wait(1).to({graphics:mask_1_graphics_37,x:161.5475,y:28.1151}).wait(1).to({graphics:mask_1_graphics_38,x:151.999,y:28.2401}).wait(1).to({graphics:mask_1_graphics_39,x:137.3865,y:28.4316}).wait(1).to({graphics:mask_1_graphics_40,x:116.5493,y:28.7045}).wait(1).to({graphics:mask_1_graphics_41,x:89.468,y:29.0593}).wait(1).to({graphics:mask_1_graphics_42,x:60.8946,y:29.4336}).wait(1).to({graphics:mask_1_graphics_43,x:40.9662,y:29.6946}).wait(1).to({graphics:mask_1_graphics_44,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_1_graphics_45,x:35.2865,y:29.7504}).wait(1).to({graphics:mask_1_graphics_46,x:37.0072,y:29.7504}).wait(1).to({graphics:mask_1_graphics_47,x:40.4028,y:29.7504}).wait(1).to({graphics:mask_1_graphics_48,x:44.9351,y:29.7504}).wait(1).to({graphics:null,x:0,y:0}).wait(2));

	// Layer_1
	this.instance_1 = new lib.photo3();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,52,22.1);


(lib.photo1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		//this.stop()
	}
	this.frame_62 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(62).call(this.frame_62).wait(1));

	// Layer_4
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(0.2,23.85,0.263,0.0495,-90,0,0,0.2,-14.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,scaleY:0.0507,x:0.9,y:23.8},0).wait(1).to({scaleX:0.2628,scaleY:0.053,x:0.95},0).wait(1).to({scaleX:0.2625,scaleY:0.0563,x:1.05},0).wait(1).to({scaleX:0.2622,scaleY:0.0608,x:1.15,y:23.75},0).wait(1).to({scaleX:0.2618,scaleY:0.0667,x:1.3,y:23.7},0).wait(1).to({scaleX:0.2612,scaleY:0.0741,x:1.5,y:23.65},0).wait(1).to({scaleX:0.2605,scaleY:0.0833,x:1.75,y:23.6},0).wait(1).to({scaleX:0.2597,scaleY:0.0944,x:2.05,y:23.55},0).wait(1).to({scaleX:0.2587,scaleY:0.1075,x:2.35,y:23.45},0).wait(1).to({scaleX:0.2576,scaleY:0.123,x:2.75,y:23.35},0).wait(1).to({scaleX:0.2563,scaleY:0.1409,x:3.2,y:23.25},0).wait(1).to({scaleX:0.2548,scaleY:0.1609,x:3.75,y:23.1},0).wait(1).to({scaleX:0.2532,scaleY:0.1825,x:4.3,y:23},0).wait(1).to({scaleX:0.2515,scaleY:0.2042,x:4.85,y:22.85},0).wait(1).to({scaleX:0.2501,scaleY:0.2242,x:5.35,y:22.7},0).wait(1).to({scaleX:0.2488,scaleY:0.2407,x:5.8,y:22.65},0).wait(1).to({scaleX:0.248,scaleY:0.2524,x:6.05,y:22.6},0).wait(1).to({scaleX:0.2475,scaleY:0.2591,x:6.2,y:22.55},0).wait(1).to({regX:0,regY:-15.2,scaleX:0.2473,scaleY:0.2612,x:2.65,y:22.5},0).wait(21).to({startPosition:0},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2476,scaleY:0.2574,x:6.4},0).wait(1).to({scaleX:0.2482,scaleY:0.2486,x:6.25,y:22.55},0).wait(1).to({scaleX:0.2494,scaleY:0.2336,x:5.85,y:22.65},0).wait(1).to({scaleX:0.2511,scaleY:0.2107,x:5.25,y:22.75},0).wait(1).to({scaleX:0.2535,scaleY:0.178,x:4.35,y:22.95},0).wait(1).to({scaleX:0.2567,scaleY:0.1355,x:3.2,y:23.25},0).wait(1).to({scaleX:0.26,scaleY:0.0906,x:2,y:23.5},0).wait(1).to({scaleX:0.2623,scaleY:0.0593,x:1.2,y:23.7},0).wait(1).to({regX:0.2,regY:-14.2,scaleX:0.263,scaleY:0.0495,x:0.2,y:23.85},0).to({_off:true},1).wait(5));

	// panelMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");
	var mask_graphics_1 = new cjs.Graphics().p("AlHE1IgBAAIiiAAIABh7QABiIAChBQACg7AHhrIAHhuQABgNBIgDQAjgCAiABIAAAAIMzAAIAAJpg");
	var mask_graphics_2 = new cjs.Graphics().p("AlCE1IgBAAIifAAIAAh7QABiIADhBQACg6AGhrIAHhvQABgNBHgDQAjgBAhABIAAAAIMmAAIAAJog");
	var mask_graphics_3 = new cjs.Graphics().p("Ak5EzIgBAAIibAAIABh6QABiIAChAQACg6AGhrIAHhuQABgNBFgDQAigBAgABIAAAAIMQAAIAAJlg");
	var mask_graphics_4 = new cjs.Graphics().p("AkrEyIAAAAIiUAAIAAh6QABiHAChAQACg6AGhqIAGhtQABgNBDgDQAfgBAgABIAAAAILrAAIAAJig");
	var mask_graphics_5 = new cjs.Graphics().p("AkXEvIAAAAIiKAAIAAh5QABiFAChAQACg5AFhpIAGhtQABgNA+gDQAdgBAeABIAAAAIK5AAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("Aj/EsIAAAAIh/AAIAAh3QABiFACg/IAHigIAFhsQABgNA5gDQAbgBAbABIAAAAIJ+AAIAAJXg");
	var mask_graphics_7 = new cjs.Graphics().p("AjtEqIAAAAIh2AAIABh3QAAiDACg/IAGifIAGhrQAAgNA1gCQAZgCAZABIAAAAIJRAAIAAJTg");
	var mask_graphics_8 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_9 = new cjs.Graphics().p("AjsEpIgBAAIh1AAIABh2QAAiDACg/IAGifIAFhqQABgNA1gDQAZgBAYABIAAAAIJQAAIAAJRg");
	var mask_graphics_10 = new cjs.Graphics().p("Aj1EpIgBAAIh6AAIABh2QAAiDACg/IAHieIAFhrQABgNA2gCQAagCAaABIAAAAIJnAAIAAJRg");
	var mask_graphics_11 = new cjs.Graphics().p("AkDEpIgBAAIiAAAIAAh2QABiDACg+IAHifIAFhrQABgMA5gDQAcgCAbACIAAgBIKKABIAAJQg");
	var mask_graphics_12 = new cjs.Graphics().p("AkWEpIgBAAIiKAAIAAh3QABiCACg+QACg5AGhmIAGhqQAAgNA+gDQAegBAdABIAAAAIK6AAIAAJQg");
	var mask_graphics_13 = new cjs.Graphics().p("AkvEoIAAAAIiXAAIABh2QAAiCADg+QACg4AGhnIAGhqQABgMBEgDQAggCAgABIAAAAIL4AAIAAJPg");
	var mask_graphics_14 = new cjs.Graphics().p("AlOEnIAAAAIimAAIAAh1QABiCADg+QACg4AHhmIAHhqQABgNBKgDQAjgBAkABIAAAAINGAAIAAJNg");
	var mask_graphics_15 = new cjs.Graphics().p("Al0EnIgBAAIi5AAIABh2QABiCADg9QACg4AIhmIAIhpQABgNBTgDQAngBAnABIAAAAIOnAAIAAJMg");
	var mask_graphics_16 = new cjs.Graphics().p("AmiEmIgBAAIjQAAIABh1QABiCADg9QADg4AIhlIAJhqQABgMBegDQAsgBAsABIAAAAIQcAAIAAJKg");
	var mask_graphics_17 = new cjs.Graphics().p("AnZElIgBAAIjrAAIAAh1QACiBADg9QADg4AKhlIAKhpQABgMBqgDQAygBAyABIAAAAISnAAIAAJIg");
	var mask_graphics_18 = new cjs.Graphics().p("AoZEjIgBAAIkMAAIAAh0QACiAAEg9QAEg3AKhlIAMhoQABgNB5gCQA5gCA5ABIAAAAIVJAAIAAJFg");
	var mask_graphics_19 = new cjs.Graphics().p("ApkEiIgBAAIkxAAIABh0QACh/AEg9QAEg3ANhkIANhoQABgMCJgDQBBgBBBABIAAAAIYGAAIAAJCg");
	var mask_graphics_20 = new cjs.Graphics().p("Aq3EgIgCAAIlaAAIABhzQACh/AFg8QAEg2AOhkIAQhnQABgNCcgCQBKgCBJABIAAAAIbZAAIAAI/g");
	var mask_graphics_21 = new cjs.Graphics().p("AsREeIgCAAImHAAIABhyQACh+AGg8QAFg2AQhjIARhnQACgMCwgCQBTgCBTABIAAAAIe9AAIAAI7g");
	var mask_graphics_22 = new cjs.Graphics().p("AtrEdIgCAAIm1AAIABhyQACh9AHg8QAGg2ARhiIAThmQADgMDEgDQBdgBBdABIAAAAMAihAAAIAAI4g");
	var mask_graphics_23 = new cjs.Graphics().p("Au/EbIgCAAInfAAIABhxQADh8AHg8QAHg1AThiIAVhlQACgMDXgDQBmgBBmABIAAAAMAl0AAAIAAI0g");
	var mask_graphics_24 = new cjs.Graphics().p("AwDEaIgDAAIoBAAIAChxQADh8AHg7QAHg1AVhhIAWhlQADgMDmgDQBtgBBtABIAAAAMAoiAAAIAAIyg");
	var mask_graphics_25 = new cjs.Graphics().p("Aw0EZIgCAAIoaAAIAChwQADh8AIg6QAHg2AWhhIAXhkQADgMDxgDQBygBBzABIAAAAMAqdAAAIAAIwg");
	var mask_graphics_26 = new cjs.Graphics().p("AxQEYIgCAAIooAAIAChvQADh8AIg6QAIg1AWhhIAYhkQADgMD3gDQB2gBB1ABIAAAAMArjAAAIAAIug");
	var mask_graphics_27 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_48 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_49 = new cjs.Graphics().p("AxIEYIgDAAIokAAIAChvQADh8AIg6QAIg1AWhhIAYhkQACgMD2gDQB1gBB0ABIAAAAMArSAAAIAAIug");
	var mask_graphics_50 = new cjs.Graphics().p("AwkEZIgCAAIoSAAIAChwQADh7AIg7QAHg1AVhhIAXhlQADgMDtgDQBxgBBxABIAAAAMAp1AAAIAAIwg");
	var mask_graphics_51 = new cjs.Graphics().p("AvlEaIgDAAInyAAIABhwQADh8AIg7QAGg2AVhhIAVhlQADgMDfgDQBrgBBpABIAAAAMAnYAAAIAAIyg");
	var mask_graphics_52 = new cjs.Graphics().p("AuGEcIgCAAInDAAIAChxQACh9AHg7QAGg2AShiIAUhmQACgMDKgDQBggBBgABIAAAAMAjmAAAIAAI2g");
	var mask_graphics_53 = new cjs.Graphics().p("Ar+EfIgBAAIl/AAIABhyQACh/AGg8QAFg2AQhjIAQhnQACgMCsgDQBRgBBSABIAAAAIeMAAIAAI8g");
	var mask_graphics_54 = new cjs.Graphics().p("ApNEjIgBAAIkmAAIABh0QACiAAEg9QAEg3AMhkIANhoQABgMCEgDQA/gCA+ABIAAAAIXNABIAAJDg");
	var mask_graphics_55 = new cjs.Graphics().p("AmSEmIgBAAIjIAAIAAh1QACiBADg+QACg4AIhlIAJhqQABgMBagDQArgBAqABIAAAAIP0AAIAAJKg");
	var mask_graphics_56 = new cjs.Graphics().p("AkQEpIAAAAIiHAAIAAh2QABiDACg+QACg4AFhnIAGhqQABgNA8gDQAdgBAdABIAAAAIKqAAIAAJQg");
	var mask_graphics_57 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_58 = new cjs.Graphics().p("AjsEqIAAAAIh1AAIAAh3QABiDACg/IAGifIAFhrQABgMA0gDQAZgCAZABIAAAAIJOAAIAAJTg");
	var mask_graphics_59 = new cjs.Graphics().p("Aj6EsIAAAAIh8AAIAAh4QABiEACg/IAHigIAFhrQABgNA3gDQAbgBAaABIAAAAIJxAAIAAJWg");
	var mask_graphics_60 = new cjs.Graphics().p("AkVEvIgBAAIiJAAIABh5QAAiFAChAQACg5AGhpIAGhsQAAgNA+gDQAdgCAdABIAAAAIK2AAIAAJdg");
	var mask_graphics_61 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QAAiIADhAQACg6AGhrIAHhuQABgNBFgDQAigBAhABIAAAAIMRAAIAAJmg");
	var mask_graphics_62 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:46.8644,y:29.7504}).wait(1).to({graphics:mask_graphics_1,x:46.6008,y:29.7504}).wait(1).to({graphics:mask_graphics_2,x:45.9648,y:29.7504}).wait(1).to({graphics:mask_graphics_3,x:44.844,y:29.7504}).wait(1).to({graphics:mask_graphics_4,x:43.0919,y:29.7504}).wait(1).to({graphics:mask_graphics_5,x:40.5971,y:29.7504}).wait(1).to({graphics:mask_graphics_6,x:37.6512,y:29.7504}).wait(1).to({graphics:mask_graphics_7,x:35.3973,y:29.7504}).wait(1).to({graphics:mask_graphics_8,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_9,x:35.4835,y:29.7399}).wait(1).to({graphics:mask_graphics_10,x:36.9013,y:29.7214}).wait(1).to({graphics:mask_graphics_11,x:39.0162,y:29.6937}).wait(1).to({graphics:mask_graphics_12,x:41.9071,y:29.6558}).wait(1).to({graphics:mask_graphics_13,x:45.6652,y:29.6066}).wait(1).to({graphics:mask_graphics_14,x:50.3954,y:29.5447}).wait(1).to({graphics:mask_graphics_15,x:56.2164,y:29.4685}).wait(1).to({graphics:mask_graphics_16,x:63.2582,y:29.3763}).wait(1).to({graphics:mask_graphics_17,x:71.6529,y:29.2664}).wait(1).to({graphics:mask_graphics_18,x:81.5121,y:29.1373}).wait(1).to({graphics:mask_graphics_19,x:92.878,y:28.9885}).wait(1).to({graphics:mask_graphics_20,x:105.631,y:28.8215}).wait(1).to({graphics:mask_graphics_21,x:119.3507,y:28.6418}).wait(1).to({graphics:mask_graphics_22,x:133.1924,y:28.4606}).wait(1).to({graphics:mask_graphics_23,x:145.9492,y:28.2936}).wait(1).to({graphics:mask_graphics_24,x:156.4209,y:28.1565}).wait(1).to({graphics:mask_graphics_25,x:163.862,y:28.059}).wait(1).to({graphics:mask_graphics_26,x:168.1194,y:28.0033}).wait(1).to({graphics:mask_graphics_27,x:169.5201,y:28.0106}).wait(21).to({graphics:mask_graphics_48,x:169.5201,y:28.0106}).wait(1).to({graphics:mask_graphics_49,x:167.1132,y:28.0422}).wait(1).to({graphics:mask_graphics_50,x:161.5475,y:28.1151}).wait(1).to({graphics:mask_graphics_51,x:151.999,y:28.2401}).wait(1).to({graphics:mask_graphics_52,x:137.3865,y:28.4316}).wait(1).to({graphics:mask_graphics_53,x:116.5493,y:28.7045}).wait(1).to({graphics:mask_graphics_54,x:89.468,y:29.0593}).wait(1).to({graphics:mask_graphics_55,x:60.8946,y:29.4336}).wait(1).to({graphics:mask_graphics_56,x:40.9662,y:29.6946}).wait(1).to({graphics:mask_graphics_57,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_58,x:35.287,y:29.7504}).wait(1).to({graphics:mask_graphics_59,x:37.0091,y:29.7504}).wait(1).to({graphics:mask_graphics_60,x:40.4077,y:29.7504}).wait(1).to({graphics:mask_graphics_61,x:44.973,y:29.7504}).wait(1).to({graphics:mask_graphics_62,x:46.8644,y:29.7504}).wait(1));

	// Layer_1
	this.instance_1 = new lib.photo1();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(63));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38,48);


(lib.photo_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		//this.stop()
	}
	this.frame_53 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(53).call(this.frame_53).wait(1));

	// Layer_5
	this.instance = new lib.Tween2("synched",0);
	this.instance.setTransform(0.2,23.85,0.263,0.0495,-90,0,0,0.2,-14.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(8).to({_off:false},0).wait(1).to({regX:0.1,regY:-0.1,scaleY:0.0507,x:0.9,y:23.8},0).wait(1).to({scaleX:0.2628,scaleY:0.053,x:0.95},0).wait(1).to({scaleX:0.2625,scaleY:0.0563,x:1.05},0).wait(1).to({scaleX:0.2622,scaleY:0.0608,x:1.15,y:23.75},0).wait(1).to({scaleX:0.2618,scaleY:0.0667,x:1.3,y:23.7},0).wait(1).to({scaleX:0.2612,scaleY:0.0741,x:1.5,y:23.65},0).wait(1).to({scaleX:0.2605,scaleY:0.0833,x:1.75,y:23.6},0).wait(1).to({scaleX:0.2597,scaleY:0.0944,x:2.05,y:23.55},0).wait(1).to({scaleX:0.2587,scaleY:0.1075,x:2.35,y:23.45},0).wait(1).to({scaleX:0.2576,scaleY:0.123,x:2.75,y:23.35},0).wait(1).to({scaleX:0.2563,scaleY:0.1409,x:3.2,y:23.25},0).wait(1).to({scaleX:0.2548,scaleY:0.1609,x:3.75,y:23.1},0).wait(1).to({scaleX:0.2532,scaleY:0.1825,x:4.3,y:23},0).wait(1).to({scaleX:0.2515,scaleY:0.2042,x:4.85,y:22.85},0).wait(1).to({scaleX:0.2501,scaleY:0.2242,x:5.35,y:22.7},0).wait(1).to({scaleX:0.2488,scaleY:0.2407,x:5.8,y:22.65},0).wait(1).to({scaleX:0.248,scaleY:0.2524,x:6.05,y:22.6},0).wait(1).to({scaleX:0.2475,scaleY:0.2591,x:6.2,y:22.55},0).wait(1).to({regX:0,regY:-15.2,scaleX:0.2473,scaleY:0.2612,x:2.65,y:22.5},0).wait(12).to({startPosition:0},0).wait(1).to({regX:0.1,regY:-0.1,scaleX:0.2476,scaleY:0.2574,x:6.4},0).wait(1).to({scaleX:0.2482,scaleY:0.2486,x:6.25,y:22.55},0).wait(1).to({scaleX:0.2494,scaleY:0.2336,x:5.85,y:22.65},0).wait(1).to({scaleX:0.2511,scaleY:0.2107,x:5.25,y:22.75},0).wait(1).to({scaleX:0.2535,scaleY:0.178,x:4.35,y:22.95},0).wait(1).to({scaleX:0.2567,scaleY:0.1355,x:3.2,y:23.25},0).wait(1).to({scaleX:0.26,scaleY:0.0906,x:2,y:23.5},0).wait(1).to({scaleX:0.2623,scaleY:0.0593,x:1.2,y:23.7},0).wait(1).to({regX:0.2,regY:-14.2,scaleX:0.263,scaleY:0.0495,x:0.2,y:23.85},0).to({_off:true},1).wait(5));

	// panelMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");
	var mask_graphics_1 = new cjs.Graphics().p("AlHE1IgBAAIiiAAIABh7QABiIAChBQACg7AHhrIAHhuQABgNBIgDQAjgCAiABIAAAAIMzAAIAAJpg");
	var mask_graphics_2 = new cjs.Graphics().p("AlCE1IgBAAIifAAIAAh7QABiIADhBQACg6AGhrIAHhvQABgNBHgDQAjgBAhABIAAAAIMmAAIAAJog");
	var mask_graphics_3 = new cjs.Graphics().p("Ak5EzIgBAAIibAAIABh6QABiIAChAQACg6AGhrIAHhuQABgNBFgDQAigBAgABIAAAAIMQAAIAAJlg");
	var mask_graphics_4 = new cjs.Graphics().p("AkrEyIAAAAIiUAAIAAh6QABiHAChAQACg6AGhqIAGhtQABgNBDgDQAfgBAgABIAAAAILrAAIAAJig");
	var mask_graphics_5 = new cjs.Graphics().p("AkXEvIAAAAIiKAAIAAh5QABiFAChAQACg5AFhpIAGhtQABgNA+gDQAdgBAeABIAAAAIK5AAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("Aj/EsIAAAAIh/AAIAAh3QABiFACg/IAHigIAFhsQABgNA5gDQAbgBAbABIAAAAIJ+AAIAAJXg");
	var mask_graphics_7 = new cjs.Graphics().p("AjtEqIAAAAIh2AAIABh3QAAiDACg/IAGifIAGhrQAAgNA1gCQAZgCAZABIAAAAIJRAAIAAJTg");
	var mask_graphics_8 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_9 = new cjs.Graphics().p("AjsEpIgBAAIh1AAIABh2QAAiDACg/IAGifIAFhqQABgNA1gDQAZgBAYABIAAAAIJQAAIAAJRg");
	var mask_graphics_10 = new cjs.Graphics().p("Aj1EpIgBAAIh6AAIABh2QAAiDACg/IAHieIAFhrQABgNA2gCQAagCAaABIAAAAIJnAAIAAJRg");
	var mask_graphics_11 = new cjs.Graphics().p("AkDEpIgBAAIiAAAIAAh2QABiDACg+IAHifIAFhrQABgMA5gDQAcgCAbACIAAgBIKKABIAAJQg");
	var mask_graphics_12 = new cjs.Graphics().p("AkWEpIgBAAIiKAAIAAh3QABiCACg+QACg5AGhmIAGhqQAAgNA+gDQAegBAdABIAAAAIK6AAIAAJQg");
	var mask_graphics_13 = new cjs.Graphics().p("AkvEoIAAAAIiXAAIABh2QAAiCADg+QACg4AGhnIAGhqQABgMBEgDQAggCAgABIAAAAIL4AAIAAJPg");
	var mask_graphics_14 = new cjs.Graphics().p("AlOEnIAAAAIimAAIAAh1QABiCADg+QACg4AHhmIAHhqQABgNBKgDQAjgBAkABIAAAAINGAAIAAJNg");
	var mask_graphics_15 = new cjs.Graphics().p("Al0EnIgBAAIi5AAIABh2QABiCADg9QACg4AIhmIAIhpQABgNBTgDQAngBAnABIAAAAIOnAAIAAJMg");
	var mask_graphics_16 = new cjs.Graphics().p("AmiEmIgBAAIjQAAIABh1QABiCADg9QADg4AIhlIAJhqQABgMBegDQAsgBAsABIAAAAIQcAAIAAJKg");
	var mask_graphics_17 = new cjs.Graphics().p("AnZElIgBAAIjrAAIAAh1QACiBADg9QADg4AKhlIAKhpQABgMBqgDQAygBAyABIAAAAISnAAIAAJIg");
	var mask_graphics_18 = new cjs.Graphics().p("AoZEjIgBAAIkMAAIAAh0QACiAAEg9QAEg3AKhlIAMhoQABgNB5gCQA5gCA5ABIAAAAIVJAAIAAJFg");
	var mask_graphics_19 = new cjs.Graphics().p("ApkEiIgBAAIkxAAIABh0QACh/AEg9QAEg3ANhkIANhoQABgMCJgDQBBgBBBABIAAAAIYGAAIAAJCg");
	var mask_graphics_20 = new cjs.Graphics().p("Aq3EgIgCAAIlaAAIABhzQACh/AFg8QAEg2AOhkIAQhnQABgNCcgCQBKgCBJABIAAAAIbZAAIAAI/g");
	var mask_graphics_21 = new cjs.Graphics().p("AsREeIgCAAImHAAIABhyQACh+AGg8QAFg2AQhjIARhnQACgMCwgCQBTgCBTABIAAAAIe9AAIAAI7g");
	var mask_graphics_22 = new cjs.Graphics().p("AtrEdIgCAAIm1AAIABhyQACh9AHg8QAGg2ARhiIAThmQADgMDEgDQBdgBBdABIAAAAMAihAAAIAAI4g");
	var mask_graphics_23 = new cjs.Graphics().p("Au/EbIgCAAInfAAIABhxQADh8AHg8QAHg1AThiIAVhlQACgMDXgDQBmgBBmABIAAAAMAl0AAAIAAI0g");
	var mask_graphics_24 = new cjs.Graphics().p("AwDEaIgDAAIoBAAIAChxQADh8AHg7QAHg1AVhhIAWhlQADgMDmgDQBtgBBtABIAAAAMAoiAAAIAAIyg");
	var mask_graphics_25 = new cjs.Graphics().p("Aw0EZIgCAAIoaAAIAChwQADh8AIg6QAHg2AWhhIAXhkQADgMDxgDQBygBBzABIAAAAMAqdAAAIAAIwg");
	var mask_graphics_26 = new cjs.Graphics().p("AxQEYIgCAAIooAAIAChvQADh8AIg6QAIg1AWhhIAYhkQADgMD3gDQB2gBB1ABIAAAAMArjAAAIAAIug");
	var mask_graphics_27 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_39 = new cjs.Graphics().p("AxYEYIgCAAIosAAIABhvQAEh8AIg6QAHg1AXhhIAYhkQADgMD5gDQB3gBB2ABIAAAAMAr5AAAIAAIug");
	var mask_graphics_40 = new cjs.Graphics().p("AxIEYIgDAAIokAAIAChvQADh8AIg6QAIg1AWhhIAYhkQACgMD2gDQB1gBB0ABIAAAAMArSAAAIAAIug");
	var mask_graphics_41 = new cjs.Graphics().p("AwkEZIgCAAIoSAAIAChwQADh7AIg7QAHg1AVhhIAXhlQADgMDtgDQBxgBBxABIAAAAMAp1AAAIAAIwg");
	var mask_graphics_42 = new cjs.Graphics().p("AvlEaIgDAAInyAAIABhwQADh8AIg7QAGg2AVhhIAVhlQADgMDfgDQBrgBBpABIAAAAMAnYAAAIAAIyg");
	var mask_graphics_43 = new cjs.Graphics().p("AuGEcIgCAAInDAAIAChxQACh9AHg7QAGg2AShiIAUhmQACgMDKgDQBggBBgABIAAAAMAjmAAAIAAI2g");
	var mask_graphics_44 = new cjs.Graphics().p("Ar+EfIgBAAIl/AAIABhyQACh/AGg8QAFg2AQhjIAQhnQACgMCsgDQBRgBBSABIAAAAIeMAAIAAI8g");
	var mask_graphics_45 = new cjs.Graphics().p("ApNEjIgBAAIkmAAIABh0QACiAAEg9QAEg3AMhkIANhoQABgMCEgDQA/gCA+ABIAAAAIXNABIAAJDg");
	var mask_graphics_46 = new cjs.Graphics().p("AmSEmIgBAAIjIAAIAAh1QACiBADg+QACg4AIhlIAJhqQABgMBagDQArgBAqABIAAAAIP0AAIAAJKg");
	var mask_graphics_47 = new cjs.Graphics().p("AkQEpIAAAAIiHAAIAAh2QABiDACg+QACg4AFhnIAGhqQABgNA8gDQAdgBAdABIAAAAIKqAAIAAJQg");
	var mask_graphics_48 = new cjs.Graphics().p("AjnEqIAAAAIhzAAIAAh3QABiDACg/IAGifIAFhqQAAgNA0gDQAYgBAZABIAAAAIJCAAIAAJSg");
	var mask_graphics_49 = new cjs.Graphics().p("AjsEqIAAAAIh1AAIAAh3QABiDACg/IAGifIAFhrQABgMA0gDQAZgCAZABIAAAAIJOAAIAAJTg");
	var mask_graphics_50 = new cjs.Graphics().p("Aj6EsIAAAAIh8AAIAAh4QABiEACg/IAHigIAFhrQABgNA3gDQAbgBAaABIAAAAIJxAAIAAJWg");
	var mask_graphics_51 = new cjs.Graphics().p("AkVEvIgBAAIiJAAIABh5QAAiFAChAQACg5AGhpIAGhsQAAgNA+gDQAdgCAdABIAAAAIK2AAIAAJdg");
	var mask_graphics_52 = new cjs.Graphics().p("Ak6E0IAAAAIicAAIABh7QAAiIADhAQACg6AGhrIAHhuQABgNBFgDQAigBAhABIAAAAIMRAAIAAJmg");
	var mask_graphics_53 = new cjs.Graphics().p("AlJE1IgBAAIijAAIAAh7QABiIADhBQACg7AHhrIAHhvQABgNBJgDQAjgBAiABIAAAAIM4AAIAAJpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:46.8644,y:29.7504}).wait(1).to({graphics:mask_graphics_1,x:46.6008,y:29.7504}).wait(1).to({graphics:mask_graphics_2,x:45.9648,y:29.7504}).wait(1).to({graphics:mask_graphics_3,x:44.844,y:29.7504}).wait(1).to({graphics:mask_graphics_4,x:43.0919,y:29.7504}).wait(1).to({graphics:mask_graphics_5,x:40.5971,y:29.7504}).wait(1).to({graphics:mask_graphics_6,x:37.6512,y:29.7504}).wait(1).to({graphics:mask_graphics_7,x:35.3973,y:29.7504}).wait(1).to({graphics:mask_graphics_8,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_9,x:35.4835,y:29.7399}).wait(1).to({graphics:mask_graphics_10,x:36.9013,y:29.7214}).wait(1).to({graphics:mask_graphics_11,x:39.0162,y:29.6937}).wait(1).to({graphics:mask_graphics_12,x:41.9071,y:29.6558}).wait(1).to({graphics:mask_graphics_13,x:45.6652,y:29.6066}).wait(1).to({graphics:mask_graphics_14,x:50.3954,y:29.5447}).wait(1).to({graphics:mask_graphics_15,x:56.2164,y:29.4685}).wait(1).to({graphics:mask_graphics_16,x:63.2582,y:29.3763}).wait(1).to({graphics:mask_graphics_17,x:71.6529,y:29.2664}).wait(1).to({graphics:mask_graphics_18,x:81.5121,y:29.1373}).wait(1).to({graphics:mask_graphics_19,x:92.878,y:28.9885}).wait(1).to({graphics:mask_graphics_20,x:105.631,y:28.8215}).wait(1).to({graphics:mask_graphics_21,x:119.3507,y:28.6418}).wait(1).to({graphics:mask_graphics_22,x:133.1924,y:28.4606}).wait(1).to({graphics:mask_graphics_23,x:145.9492,y:28.2936}).wait(1).to({graphics:mask_graphics_24,x:156.4209,y:28.1565}).wait(1).to({graphics:mask_graphics_25,x:163.862,y:28.059}).wait(1).to({graphics:mask_graphics_26,x:168.1194,y:28.0033}).wait(1).to({graphics:mask_graphics_27,x:169.5201,y:28.0106}).wait(12).to({graphics:mask_graphics_39,x:169.5201,y:28.0106}).wait(1).to({graphics:mask_graphics_40,x:167.1132,y:28.0422}).wait(1).to({graphics:mask_graphics_41,x:161.5475,y:28.1151}).wait(1).to({graphics:mask_graphics_42,x:151.999,y:28.2401}).wait(1).to({graphics:mask_graphics_43,x:137.3865,y:28.4316}).wait(1).to({graphics:mask_graphics_44,x:116.5493,y:28.7045}).wait(1).to({graphics:mask_graphics_45,x:89.468,y:29.0593}).wait(1).to({graphics:mask_graphics_46,x:60.8946,y:29.4336}).wait(1).to({graphics:mask_graphics_47,x:40.9662,y:29.6946}).wait(1).to({graphics:mask_graphics_48,x:34.6924,y:29.7503}).wait(1).to({graphics:mask_graphics_49,x:35.287,y:29.7504}).wait(1).to({graphics:mask_graphics_50,x:37.0091,y:29.7504}).wait(1).to({graphics:mask_graphics_51,x:40.4077,y:29.7504}).wait(1).to({graphics:mask_graphics_52,x:44.973,y:29.7504}).wait(1).to({graphics:mask_graphics_53,x:46.8644,y:29.7504}).wait(1));

	// Layer_1
	this.instance_1 = new lib.photo2();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,38,48);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.bg_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg_sub.cache(0,0,300,600,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg_sub = new lib.bg_sub();
	this.bg_sub.name = "bg_sub";
	this.bg_sub.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_1, new cjs.Rectangle(0,0,300,600), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		//exportRoot.tlicons.play()
	}
	this.frame_67 = function() {
		exportRoot.tl1.play()
		//exportRoot.mainMC.screen.play()
	}
	this.frame_81 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(17).call(this.frame_67).wait(14).call(this.frame_81).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(55));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(55));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(31).to({alpha:0},24,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCX8MAAAkv3MCZbAAAMAAAEv3g");
	this.shape.setTransform(299.85,339.425);

	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,339.4);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},57).to({state:[{t:this.instance_2}]},24).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(57).to({_off:false},0).to({alpha:0},24,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-632.9,982,1944.6999999999998);


(lib.final_screen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.FinalScreen_lg1();
	this.instance.setTransform(3.9,9.5,0.83,0.83);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Shadow
	this.instance_1 = new lib.UIshadow();
	this.instance_1.setTransform(127.3,98.2,1.2131,1.2131,0,0,0,97.3,72.2);
	this.instance_1.alpha = 0.3008;
	this.instance_1.filters = [new cjs.BlurFilter(14, 14, 1)];
	this.instance_1.cache(-2,-2,199,148);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.final_screen, new cjs.Rectangle(2.3,3.6,254,193), null);


(lib.box_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.box.cache(0,0,275,255,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.box = new lib.box_Cache();
	this.box.name = "box";
	this.box.setTransform(139.7,125,1,1,0,0,0,139.7,125);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_c, new cjs.Rectangle(0,-2.9,270.4,253), null);


(lib.base_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.overlay = new lib.screen_overlay();
	this.overlay.name = "overlay";
	this.overlay.setTransform(101.2,83.85,1,1,0,0,0,98.9,84.2);

	this.timeline.addTween(cjs.Tween.get(this.overlay).wait(1));

	// Layer_1
	this.instance = new lib.base();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.base_1, new cjs.Rectangle(0,-0.3,200.1,168.4), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_252 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(252).call(this.frame_252).wait(12));

	// New sticker
	this.instance = new lib.sticker();
	this.instance.setTransform(215.8,25.2,0.1526,0.1526,0,0,0,9.5,10.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(213).to({_off:false},0).to({regX:9.7,scaleX:2.0424,scaleY:2.0424,x:216.45,y:25.85},10,cjs.Ease.sineOut).wait(2).to({regX:9.5,regY:10,scaleX:1,scaleY:1,x:215.8,y:25.15},14,cjs.Ease.sineInOut).to({_off:true},14).wait(11));

	// photo 3 copy
	this.instance_1 = new lib.photo3_1();
	this.instance_1.setTransform(219.75,-125.7,1.3201,1.5333,-3.0132,0,0,26.2,11.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(154).to({_off:false},0).to({regX:26.3,regY:11.1,scaleX:2.2678,scaleY:2.5582,rotation:4.195,x:234.4,y:-183.3},17,cjs.Ease.sineInOut).wait(3).to({regX:26,regY:11,scaleX:2.2644,scaleY:2.5539,rotation:4.1912,x:233.65,y:-182.9},0).wait(1).to({scaleX:2.2538,scaleY:2.5405,rotation:4.1796,x:233.5,y:-180.8},0).wait(1).to({scaleX:2.2356,scaleY:2.5177,rotation:4.1599,x:233.15,y:-177.15},0).wait(1).to({scaleX:2.2099,scaleY:2.4853,rotation:4.1319,x:232.75,y:-172},0).wait(1).to({scaleX:2.1765,scaleY:2.4433,rotation:4.0957,x:232.25,y:-165.4},0).wait(1).to({scaleX:2.1359,scaleY:2.3921,rotation:4.0515,x:231.55,y:-157.3},0).wait(1).to({scaleX:2.0884,scaleY:2.3324,rotation:3.9999,x:230.7,y:-147.85},0).wait(1).to({scaleX:2.0351,scaleY:2.2653,rotation:3.9419,x:229.9,y:-137.25},0).wait(1).to({scaleX:1.9769,scaleY:2.1921,rotation:3.8787,x:228.9,y:-125.7},0).wait(1).to({scaleX:1.9153,scaleY:2.1145,rotation:3.8117,x:227.85,y:-113.45},0).wait(1).to({scaleX:1.8516,scaleY:2.0343,rotation:3.7424,x:226.85,y:-100.7},0).wait(1).to({scaleX:1.7871,scaleY:1.9532,rotation:3.6724,x:225.7,y:-87.95},0).wait(1).to({scaleX:1.7233,scaleY:1.8728,rotation:3.603,x:224.65,y:-75.25},0).wait(1).to({scaleX:1.6612,scaleY:1.7946,rotation:3.5354,x:223.65,y:-62.9},0).wait(1).to({scaleX:1.6016,scaleY:1.7196,rotation:3.4706,x:222.65,y:-51.05},0).wait(1).to({scaleX:1.5452,scaleY:1.6486,rotation:3.4093,x:221.7,y:-39.8},0).wait(1).to({scaleX:1.4924,scaleY:1.5822,rotation:3.352,x:220.85,y:-29.35},0).wait(1).to({scaleX:1.4436,scaleY:1.5207,rotation:3.2989,x:220,y:-19.6},0).wait(1).to({scaleX:1.3988,scaleY:1.4644,rotation:3.2502,x:219.3,y:-10.7},0).wait(1).to({scaleX:1.3581,scaleY:1.4132,rotation:3.206,x:218.6,y:-2.65},0).wait(1).to({scaleX:1.3215,scaleY:1.3671,rotation:3.1662,x:217.95,y:4.65},0).wait(1).to({scaleX:1.2889,scaleY:1.326,rotation:3.1307,x:217.45,y:11.2},0).wait(1).to({scaleX:1.2601,scaleY:1.2898,rotation:3.0994,x:217,y:16.8},0).wait(1).to({scaleX:1.235,scaleY:1.2582,rotation:3.0721,x:216.55,y:21.8},0).wait(1).to({scaleX:1.2134,scaleY:1.231,rotation:3.0487,x:216.2,y:26.15},0).wait(1).to({scaleX:1.1952,scaleY:1.2081,rotation:3.0289,x:215.9,y:29.75},0).wait(1).to({scaleX:1.1803,scaleY:1.1893,rotation:3.0126,x:215.65,y:32.7},0).wait(1).to({regX:26.4,regY:11.2,scaleX:1.1683,scaleY:1.1743,rotation:2.9996,x:215.75,y:35.2},0).wait(1).to({regX:26,regY:11,scaleX:1.1406,scaleY:1.1456,rotation:2.5055,x:215.25,y:35.6},0).wait(1).to({scaleX:1.1155,scaleY:1.1196,rotation:2.0583,x:215.15,y:36.15},0).wait(1).to({scaleX:1.093,scaleY:1.0963,rotation:1.6573,x:215.05,y:36.7},0).wait(1).to({scaleX:1.0731,scaleY:1.0756,rotation:1.3017,y:37.2},0).wait(1).to({scaleX:1.0556,scaleY:1.0576,rotation:0.9908,x:215,y:37.6},0).wait(1).to({scaleX:1.0406,scaleY:1.0421,rotation:0.7236,x:214.95,y:37.95},0).wait(1).to({scaleX:1.0281,scaleY:1.0291,rotation:0.4996,x:214.9,y:38.25},0).wait(1).to({scaleX:1.0179,scaleY:1.0185,rotation:0.3179,x:214.85,y:38.5},0).wait(1).to({scaleX:1.01,scaleY:1.0104,rotation:0.1778,y:38.7},0).wait(1).to({scaleX:1.0044,scaleY:1.0046,rotation:0.0786,y:38.85},0).wait(1).to({scaleX:1.0011,scaleY:1.0011,rotation:0.0195,y:38.9},0).wait(1).to({scaleX:1,scaleY:1,rotation:0,x:215.3,y:39.15},0).to({_off:true},40).wait(11));

	// maskPhoto3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_137 = new cjs.Graphics().p("AhErsIQOgQQgBABAaFYIAbFYIwNANg");
	var mask_graphics_138 = new cjs.Graphics().p("Ag4rsIQNgQQgBABAaFYIAbFYIwNANg");
	var mask_graphics_139 = new cjs.Graphics().p("AgtrsIQNgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_140 = new cjs.Graphics().p("AgirsIQOgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_141 = new cjs.Graphics().p("AgXrsIQOgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_142 = new cjs.Graphics().p("AgLrsIQNgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_143 = new cjs.Graphics().p("AAArsIQNgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_144 = new cjs.Graphics().p("AAKrsIQOgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_145 = new cjs.Graphics().p("AAVrsIQPgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_146 = new cjs.Graphics().p("AAgrsIQPgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_147 = new cjs.Graphics().p("AAsrsIQOgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_148 = new cjs.Graphics().p("AA3rsIQOgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_149 = new cjs.Graphics().p("ABFr1IQPgPQgBABAaFYIAaFYIwNANg");
	var mask_graphics_150 = new cjs.Graphics().p("ABTr9IQPgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_151 = new cjs.Graphics().p("ABisFIQOgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_152 = new cjs.Graphics().p("ABwsOIQPgPQgBABAaFYIAaFYIwNANg");
	var mask_graphics_153 = new cjs.Graphics().p("AB+sWIQPgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_154 = new cjs.Graphics().p("ACNsfIQOgPQgBABAaFYIAbFYIwOANg");
	var mask_graphics_155 = new cjs.Graphics().p("ACbsnIQPgPQgBABAaFYIAaFYIwOANg");
	var mask_graphics_156 = new cjs.Graphics().p("ACpsvIQPgQQgBABAaFYIAaFYIwNANg");
	var mask_graphics_157 = new cjs.Graphics().p("AC4s4IQOgPQgBABAaFYIAbFYIwOANg");
	var mask_graphics_158 = new cjs.Graphics().p("ADGtAIQOgQQgBABAaFYIAbFYIwOANg");
	var mask_graphics_159 = new cjs.Graphics().p("ADUtJIQPgPQgBABAaFYIAaFYIwNANg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(137).to({graphics:mask_graphics_137,x:102.1527,y:-76.4756}).wait(1).to({graphics:mask_graphics_138,x:103.2732,y:-76.4756}).wait(1).to({graphics:mask_graphics_139,x:104.3936,y:-76.4756}).wait(1).to({graphics:mask_graphics_140,x:105.5141,y:-76.4756}).wait(1).to({graphics:mask_graphics_141,x:106.6345,y:-76.4756}).wait(1).to({graphics:mask_graphics_142,x:107.755,y:-76.4756}).wait(1).to({graphics:mask_graphics_143,x:108.8754,y:-76.4756}).wait(1).to({graphics:mask_graphics_144,x:109.9959,y:-76.4756}).wait(1).to({graphics:mask_graphics_145,x:111.1163,y:-76.4756}).wait(1).to({graphics:mask_graphics_146,x:112.2368,y:-76.4756}).wait(1).to({graphics:mask_graphics_147,x:113.3572,y:-76.4756}).wait(1).to({graphics:mask_graphics_148,x:114.4777,y:-76.4756}).wait(1).to({graphics:mask_graphics_149,x:115.9095,y:-77.3142}).wait(1).to({graphics:mask_graphics_150,x:117.3413,y:-78.1529}).wait(1).to({graphics:mask_graphics_151,x:118.7732,y:-78.9915}).wait(1).to({graphics:mask_graphics_152,x:120.205,y:-79.8301}).wait(1).to({graphics:mask_graphics_153,x:121.6368,y:-80.6688}).wait(1).to({graphics:mask_graphics_154,x:123.0686,y:-81.5074}).wait(1).to({graphics:mask_graphics_155,x:124.5004,y:-82.346}).wait(1).to({graphics:mask_graphics_156,x:125.9322,y:-83.1847}).wait(1).to({graphics:mask_graphics_157,x:127.3641,y:-84.0233}).wait(1).to({graphics:mask_graphics_158,x:128.7959,y:-84.8619}).wait(1).to({graphics:mask_graphics_159,x:130.228,y:-85.7006}).wait(1).to({graphics:null,x:0,y:0}).wait(104));

	// photo 3
	this.instance_2 = new lib.photo3_1();
	this.instance_2.setTransform(283.9,-128,1.3201,1.5333,-3.0132,0,0,26.2,11.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(137).to({_off:false},0).to({x:220.3,y:-123.85},11,cjs.Ease.none).to({_off:true},6).wait(110));

	// maskPhoto2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_89 = new cjs.Graphics().p("ANSr6IDvgMIAZFtIAZFrIjuAKg");
	var mask_1_graphics_101 = new cjs.Graphics().p("ANSr6IDvgMIAZFtIAZFrIjuAKg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(89).to({graphics:mask_1_graphics_89,x:113.926,y:-77.5159}).wait(12).to({graphics:mask_1_graphics_101,x:113.926,y:-77.5159}).wait(1).to({graphics:null,x:0,y:0}).wait(162));

	// photo 2
	this.instance_3 = new lib.photo_2();
	this.instance_3.setTransform(256.6,-121.2,0.9499,1.067,0,-5.0007,-0.5117,19.3,23.8);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(91).to({_off:false},0).wait(1).to({regX:19,regY:24,scaleX:0.95,x:255.35,y:-121},0).wait(1).to({x:253.7},0).wait(1).to({x:251.2},0).wait(1).to({x:247.8,y:-121.05},0).wait(1).to({x:243.4},0).wait(1).to({x:238.05,y:-121.1},0).wait(1).to({x:232,y:-121.15},0).wait(1).to({x:225.7,y:-121.2},0).wait(1).to({x:220.25,y:-121.25},0).wait(1).to({regX:19.3,regY:23.8,scaleX:0.9499,x:217,y:-121.5},0).to({regX:19.4,regY:23.7,scaleX:1.4908,scaleY:1.629,skewX:1.9754,skewY:2.6692,x:218.7,y:-149.3},15,cjs.Ease.sineInOut).wait(1).to({regX:19,regY:24,scaleX:1.4905,scaleY:1.6285,skewX:1.9457,skewY:2.6392,x:218.1,y:-148.6},0).wait(1).to({scaleX:1.4894,scaleY:1.6268,skewX:1.8513,skewY:2.5438,x:218.25,y:-147.9},0).wait(1).to({scaleX:1.4875,scaleY:1.6237,skewX:1.6829,skewY:2.3737,x:218.45,y:-146.6},0).wait(1).to({scaleX:1.4845,scaleY:1.6192,skewX:1.4296,skewY:2.1177,x:218.8,y:-144.6},0).wait(1).to({scaleX:1.4803,scaleY:1.6128,skewX:1.0781,skewY:1.7627,x:219.2,y:-141.9},0).wait(1).to({scaleX:1.4749,scaleY:1.6043,skewX:0.6131,skewY:1.2928,x:219.85,y:-138.25},0).wait(1).to({scaleX:1.468,scaleY:1.5935,skewX:0.0164,skewY:0.6901,x:220.65,y:-133.6},0).wait(1).to({scaleX:1.4592,scaleY:1.5799,skewX:-0.7315,skewY:-0.0656,x:221.6,y:-127.85},0).wait(1).to({scaleX:1.4484,scaleY:1.5633,skewX:-1.6501,skewY:-0.9936,x:222.8,y:-120.75},0).wait(1).to({scaleX:1.4356,scaleY:1.5433,skewX:-2.7532,skewY:-2.1081,x:224.25,y:-112.15},0).wait(1).to({scaleX:1.4205,scaleY:1.5199,skewX:-4.0405,skewY:-3.4087,x:225.9,y:-102.15},0).wait(1).to({scaleX:1.4036,scaleY:1.4937,skewX:-5.4856,skewY:-4.8686,x:227.8,y:-90.95},0).wait(1).to({scaleX:1.3855,scaleY:1.4657,skewX:-7.0289,skewY:-6.4278,x:229.8,y:-79},0).wait(1).to({scaleX:1.3673,scaleY:1.4375,skewX:-8.5874,skewY:-8.0024,x:231.85,y:-66.9},0).wait(1).to({scaleX:1.3498,scaleY:1.4104,skewX:-10.0789,skewY:-9.5092,x:233.8,y:-55.35},0).wait(1).to({scaleX:1.3339,scaleY:1.3856,skewX:-11.4453,skewY:-10.8897,x:235.6,y:-44.75},0).wait(1).to({scaleX:1.3197,scaleY:1.3636,skewX:-12.6591,skewY:-12.116,x:237.1,y:-35.35},0).wait(1).to({scaleX:1.3073,scaleY:1.3444,skewX:-13.7158,skewY:-13.1836,x:238.55,y:-27.15},0).wait(1).to({scaleX:1.2966,scaleY:1.3279,skewX:-14.6242,skewY:-14.1013,x:239.75,y:-20.1},0).wait(1).to({scaleX:1.2876,scaleY:1.3139,skewX:-15.3984,skewY:-14.8835,x:240.7,y:-14.15},0).wait(1).to({regX:19.4,regY:23.9,scaleX:1.2799,scaleY:1.302,skewX:-16.0535,skewY:-15.5453,x:241.95,y:-9.65},0).to({regX:19,regY:24,scaleX:1,scaleY:1,skewX:0,skewY:0,x:235.25,y:3.15},20,cjs.Ease.quadOut).to({_off:true},96).wait(11));

	// maskPhoto1 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_41 = new cjs.Graphics().p("ANVr4IDsgMIAYFrIAaFqIjrAKg");
	var mask_2_graphics_54 = new cjs.Graphics().p("ANVr4IDsgMIAYFrIAaFqIjrAKg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(41).to({graphics:mask_2_graphics_41,x:113.8896,y:-77.2915}).wait(13).to({graphics:mask_2_graphics_54,x:113.8896,y:-77.2915}).wait(1).to({graphics:null,x:0,y:0}).wait(209));

	// photo1 copy
	this.instance_4 = new lib.photo1_1();
	this.instance_4.setTransform(254.4,-117.55,0.9499,1.067,0,-4.0004,-0.5035,19.2,23.8);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(44).to({_off:false},0).to({regX:19.3,skewX:-5.0007,skewY:-0.5117,x:216.1},10,cjs.Ease.none).to({regX:19.4,regY:23.7,scaleX:1.8608,scaleY:1.9466,skewX:2.7024,skewY:2.4434,x:219.3,y:-164.7},17,cjs.Ease.sineInOut).wait(1).to({regX:19,regY:24,scaleX:1.8567,scaleY:1.942,skewX:2.6254,skewY:2.3677,x:218.3,y:-163.2},0).wait(1).to({scaleX:1.8498,scaleY:1.9344,skewX:2.4982,skewY:2.2427,x:217.95,y:-161.55},0).wait(1).to({scaleX:1.8401,scaleY:1.9235,skewX:2.3177,skewY:2.0655,x:217.45,y:-159.3},0).wait(1).to({scaleX:1.8272,scaleY:1.9093,skewX:2.0807,skewY:1.8327,x:216.75,y:-156.3},0).wait(1).to({scaleX:1.8112,scaleY:1.8914,skewX:1.7843,skewY:1.5416,x:215.9,y:-152.55},0).wait(1).to({scaleX:1.7918,scaleY:1.87,skewX:1.4259,skewY:1.1896,x:214.85,y:-148.05},0).wait(1).to({scaleX:1.7689,scaleY:1.8445,skewX:1.0034,skewY:0.7746,x:213.65,y:-142.75},0).wait(1).to({scaleX:1.7425,scaleY:1.8153,skewX:0.5156,skewY:0.2956,x:212.2,y:-136.6},0).wait(1).to({scaleX:1.7126,scaleY:1.782,skewX:-0.037,skewY:-0.2472,x:210.65,y:-129.6},0).wait(1).to({scaleX:1.6792,scaleY:1.7451,skewX:-0.6525,skewY:-0.8517,x:208.85,y:-121.8},0).wait(1).to({scaleX:1.6428,scaleY:1.7046,skewX:-1.3264,skewY:-1.5136,x:206.85,y:-113.3},0).wait(1).to({scaleX:1.6035,scaleY:1.661,skewX:-2.0517,skewY:-2.2259,x:204.75,y:-104.2},0).wait(1).to({scaleX:1.562,scaleY:1.6149,skewX:-2.8183,skewY:-2.9789,x:202.5,y:-94.55},0).wait(1).to({scaleX:1.5189,scaleY:1.5671,skewX:-3.6138,skewY:-3.7602,x:200.2,y:-84.45},0).wait(1).to({scaleX:1.4751,scaleY:1.5185,skewX:-4.4234,skewY:-4.5554,x:197.85,y:-74.3},0).wait(1).to({scaleX:1.4313,scaleY:1.4699,skewX:-5.2316,skewY:-5.3491,x:195.5,y:-64.1},0).wait(1).to({scaleX:1.3885,scaleY:1.4224,skewX:-6.0228,skewY:-6.1262,x:193.25,y:-54.1},0).wait(1).to({scaleX:1.3474,scaleY:1.3767,skewX:-6.7828,skewY:-6.8727,x:191,y:-44.5},0).wait(1).to({scaleX:1.3086,scaleY:1.3337,skewX:-7.4997,skewY:-7.5768,x:188.95,y:-35.5},0).wait(1).to({scaleX:1.2726,scaleY:1.2937,skewX:-8.1641,skewY:-8.2294,x:187,y:-27.1},0).wait(1).to({regX:19.6,regY:23.9,scaleX:1.2398,scaleY:1.2573,skewX:-8.7698,skewY:-8.8242,x:185.8,y:-20.05},0).to({regX:19,regY:24,scaleX:1,scaleY:1,skewX:0,skewY:0,x:196.3,y:3.15},11,cjs.Ease.quadOut).to({_off:true},150).wait(11));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_195 = new cjs.Graphics().p("ATEKKIAA0TIAdAAIAAUTg");
	var mask_3_graphics_196 = new cjs.Graphics().p("AS/KKIAA0TIAkAAIAAUTg");
	var mask_3_graphics_197 = new cjs.Graphics().p("ASwKKIAA0TIA4AAIAAUTg");
	var mask_3_graphics_198 = new cjs.Graphics().p("ASYKJIAA0RIBYAAIAAURg");
	var mask_3_graphics_199 = new cjs.Graphics().p("AR3KIIAA0PICEAAIAAUPg");
	var mask_3_graphics_200 = new cjs.Graphics().p("ARMKGIAA0LIC9AAIAAULg");
	var mask_3_graphics_201 = new cjs.Graphics().p("AQaKFIAA0JID/AAIAAUJg");
	var mask_3_graphics_202 = new cjs.Graphics().p("APhKDIAA0FIFMAAIAAUFg");
	var mask_3_graphics_203 = new cjs.Graphics().p("AOhKAIAAz/IGhAAIAAT/g");
	var mask_3_graphics_204 = new cjs.Graphics().p("ANcJ+IAAz7IH9AAIAAT7g");
	var mask_3_graphics_205 = new cjs.Graphics().p("AMTJ7IAAz1IJeAAIAAT1g");
	var mask_3_graphics_206 = new cjs.Graphics().p("ALHJ5IAAzxILDAAIAATxg");
	var mask_3_graphics_207 = new cjs.Graphics().p("AJ5J2IAAzrIMrAAIAATrg");
	var mask_3_graphics_208 = new cjs.Graphics().p("AIqJzIAAzlIOUAAIAATlg");
	var mask_3_graphics_209 = new cjs.Graphics().p("AHcJwIAAzfIP8AAIAATfg");
	var mask_3_graphics_210 = new cjs.Graphics().p("AGQJuIAAzbIRiAAIAATbg");
	var mask_3_graphics_211 = new cjs.Graphics().p("AFHJrIAAzVITDAAIAATVg");
	var mask_3_graphics_212 = new cjs.Graphics().p("AECJpIAAzRIUfAAIAATRg");
	var mask_3_graphics_213 = new cjs.Graphics().p("ADCJmIAAzLIV0AAIAATLg");
	var mask_3_graphics_214 = new cjs.Graphics().p("ACJJkIAAzHIXAAAIAATHg");
	var mask_3_graphics_215 = new cjs.Graphics().p("ABXJjIAAzFIYDAAIAATFg");
	var mask_3_graphics_216 = new cjs.Graphics().p("AAtJhIAAzBIY7AAIAATBg");
	var mask_3_graphics_217 = new cjs.Graphics().p("AALJgIAAy/IZoAAIAAS/g");
	var mask_3_graphics_218 = new cjs.Graphics().p("AgMJfIAAy9IaHAAIAAS9g");
	var mask_3_graphics_219 = new cjs.Graphics().p("AgbJfIAAy9IabAAIAAS9g");
	var mask_3_graphics_220 = new cjs.Graphics().p("AgfJfIAAy9IahAAIAAS9g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(195).to({graphics:mask_3_graphics_195,x:124.8988,y:14.6499}).wait(1).to({graphics:mask_3_graphics_196,x:125.0631,y:14.6497}).wait(1).to({graphics:mask_3_graphics_197,x:125.5535,y:14.6491}).wait(1).to({graphics:mask_3_graphics_198,x:126.3621,y:14.6481}).wait(1).to({graphics:mask_3_graphics_199,x:127.4764,y:14.6468}).wait(1).to({graphics:mask_3_graphics_200,x:128.8786,y:14.6451}).wait(1).to({graphics:mask_3_graphics_201,x:130.5467,y:14.6431}).wait(1).to({graphics:mask_3_graphics_202,x:132.4544,y:14.6409}).wait(1).to({graphics:mask_3_graphics_203,x:134.5716,y:14.6384}).wait(1).to({graphics:mask_3_graphics_204,x:136.8648,y:14.6356}).wait(1).to({graphics:mask_3_graphics_205,x:139.298,y:14.6327}).wait(1).to({graphics:mask_3_graphics_206,x:141.8327,y:14.6297}).wait(1).to({graphics:mask_3_graphics_207,x:144.4291,y:14.6266}).wait(1).to({graphics:mask_3_graphics_208,x:147.046,y:14.6235}).wait(1).to({graphics:mask_3_graphics_209,x:149.6423,y:14.6204}).wait(1).to({graphics:mask_3_graphics_210,x:152.1771,y:14.6174}).wait(1).to({graphics:mask_3_graphics_211,x:154.6102,y:14.6145}).wait(1).to({graphics:mask_3_graphics_212,x:156.9035,y:14.6118}).wait(1).to({graphics:mask_3_graphics_213,x:159.0207,y:14.6092}).wait(1).to({graphics:mask_3_graphics_214,x:160.9283,y:14.607}).wait(1).to({graphics:mask_3_graphics_215,x:162.5964,y:14.605}).wait(1).to({graphics:mask_3_graphics_216,x:163.9987,y:14.6033}).wait(1).to({graphics:mask_3_graphics_217,x:165.1129,y:14.602}).wait(1).to({graphics:mask_3_graphics_218,x:165.9216,y:14.601}).wait(1).to({graphics:mask_3_graphics_219,x:166.412,y:14.6004}).wait(1).to({graphics:mask_3_graphics_220,x:166.6263,y:14.6002}).wait(44));

	// bg
	this.instance_5 = new lib.powerpointUI_mc();
	this.instance_5.setTransform(248.8,14.65,1,1,0,0,0,83.5,46.5);
	this.instance_5._off = true;

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(195).to({_off:false},0).wait(69));

	// Layer_3
	this.base = new lib.base_1();
	this.base.name = "base";
	this.base.setTransform(213.45,-119.05,0.1049,0.1404,-3.0154,0,0,104,82.2);

	this.timeline.addTween(cjs.Tween.get(this.base).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1062,scaleY:0.1416,rotation:-3.0106,x:212.75,y:-118.95},0).wait(1).to({scaleX:0.108,scaleY:0.1433,rotation:-3.0042,x:212.45,y:-119.15},0).wait(1).to({regX:104.3,regY:82,scaleX:0.1102,scaleY:0.1454,rotation:-2.996,x:212.4,y:-119.7},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1129,scaleY:0.148,rotation:-2.9869,x:211.55},0).wait(1).to({regX:104.9,regY:81.7,scaleX:0.1161,scaleY:0.1511,rotation:-2.976,x:211.45,y:-120.4},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1199,scaleY:0.1547,rotation:-2.9608,x:210.2},0).wait(1).to({regX:105.4,regY:81.7,scaleX:0.1243,scaleY:0.159,rotation:-2.9431,x:210,y:-121.3},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1294,scaleY:0.1639,rotation:-2.9259,x:208.35,y:-121.4},0).wait(1).to({regX:105.5,regY:81.4,scaleX:0.1352,scaleY:0.1694,rotation:-2.9062,x:207.95,y:-122.45},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1418,scaleY:0.1757,rotation:-2.8824,x:205.85},0).wait(1).to({regX:105.8,regY:81.5,scaleX:0.1492,scaleY:0.1829,rotation:-2.8555,x:205.2,y:-123.6},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1575,scaleY:0.1909,rotation:-2.8269,x:202.65,y:-123.5},0).wait(1).to({scaleX:0.1669,scaleY:0.1998,rotation:-2.7948,x:200.65,y:-124},0).wait(1).to({regX:106,regY:81.5,scaleX:0.1773,scaleY:0.2099,rotation:-2.759,x:199.45,y:-125.1},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.1889,scaleY:0.221,rotation:-2.7191,x:195.95,y:-124.5},0).wait(1).to({regX:106.2,regY:81.5,scaleX:0.2019,scaleY:0.2335,rotation:-2.6747,x:194.25,y:-125},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.2163,scaleY:0.2473,rotation:-2.6263,x:190.2,y:-122.9},0).wait(1).to({regX:106.4,regY:81.3,scaleX:0.2324,scaleY:0.2628,rotation:-2.5725,x:188.45,y:-122},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.2503,scaleY:0.28,rotation:-2.5118,x:184.1,y:-118.7},0).wait(1).to({regX:106.4,regY:81,scaleX:0.2702,scaleY:0.2991,rotation:-2.4442,x:182.5,y:-116.65},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.2924,scaleY:0.3204,rotation:-2.3699,x:177.65,y:-111.9},0).wait(1).to({regX:106.7,regY:81,scaleX:0.3171,scaleY:0.3441,rotation:-2.2872,x:176.2,y:-108.8},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.3445,scaleY:0.3705,rotation:-2.1946,x:171.6,y:-102.15},0).wait(1).to({regX:106.7,regY:80.9,scaleX:0.3749,scaleY:0.3996,rotation:-2.0921,x:171.2,y:-97.35},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.4083,scaleY:0.4317,rotation:-1.9795,x:167.95,y:-88.7},0).wait(1).to({regX:106.8,regY:80.8,scaleX:0.4447,scaleY:0.4667,rotation:-1.8568,x:169.9,y:-82.15},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.4839,scaleY:0.5043,rotation:-1.726,x:168.6,y:-72.1},0).wait(1).to({regX:107,regY:80.7,scaleX:0.5252,scaleY:0.5439,rotation:-1.5882,x:173.85,y:-64.95},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.5675,scaleY:0.5846,rotation:-1.4463,x:174.25,y:-54.65},0).wait(1).to({regX:107,regY:80.8,scaleX:0.6098,scaleY:0.6252,rotation:-1.3049,x:182.3,y:-48.35},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.6507,scaleY:0.6645,rotation:-1.1683,x:183.2,y:-38.95},0).wait(1).to({regX:107,regY:80.8,scaleX:0.6892,scaleY:0.7015,rotation:-1.0394,x:192.7,y:-34.35},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.7249,scaleY:0.7358,rotation:-0.9202,x:193.05,y:-26.3},0).wait(1).to({regX:107,regY:80.7,scaleX:0.7575,scaleY:0.767,rotation:-0.8116,x:203,y:-23.6},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.7869,scaleY:0.7953,rotation:-0.7129,x:202.5,y:-16.8},0).wait(1).to({regX:107,regY:80.7,scaleX:0.8132,scaleY:0.8206,rotation:-0.6244,x:212.25,y:-15.7},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.8368,scaleY:0.8432,rotation:-0.5454,x:210.6,y:-9.9},0).wait(1).to({regX:107,regY:80.6,scaleX:0.8578,scaleY:0.8634,rotation:-0.4749,x:220.15,y:-10.05},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.8766,scaleY:0.8814,rotation:-0.4123,x:217.55,y:-5},0).wait(1).to({scaleX:0.8933,scaleY:0.8975,rotation:-0.3565,x:220.5,y:-3.15},0).wait(1).to({regX:107.2,regY:80.6,scaleX:0.9081,scaleY:0.9118,rotation:-0.3068,x:229.55,y:-4.5},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.9214,scaleY:0.9245,rotation:-0.2626,x:225.6,y:-0.25},0).wait(1).to({regX:107.2,regY:80.6,scaleX:0.9332,scaleY:0.9358,rotation:-0.2233,x:234.45,y:-2.35},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.9436,scaleY:0.9458,rotation:-0.1879,x:229.85,y:1.65},0).wait(1).to({regX:107.2,regY:80.6,scaleX:0.9528,scaleY:0.9547,rotation:-0.1566,x:238.4,y:-0.85},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.961,scaleY:0.9625,rotation:-0.1296,x:233.3,y:2.85},0).wait(1).to({scaleX:0.9681,scaleY:0.9694,rotation:-0.1059,x:234.7,y:3.3},0).wait(1).to({regX:107.3,regY:80.6,scaleX:0.9744,scaleY:0.9754,rotation:-0.0851,x:242.95,y:0.4},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.9798,scaleY:0.9806,rotation:-0.0673,x:237.05,y:3.9},0).wait(1).to({scaleX:0.9845,scaleY:0.9851,rotation:-0.0519,x:237.95,y:4.15},0).wait(1).to({regX:107.3,regY:80.5,scaleX:0.9884,scaleY:0.9889,rotation:-0.0389,x:245.9,y:1},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.9917,scaleY:0.992,rotation:-0.0277,x:239.45,y:4.45},0).wait(1).to({scaleX:0.9944,scaleY:0.9946,rotation:-0.0186,x:240.05,y:4.5},0).wait(1).to({regX:107.3,regY:80.5,scaleX:0.9965,scaleY:0.9967,rotation:-0.0114,x:247.65,y:1.2},0).wait(1).to({regX:100.1,regY:83.9,scaleX:0.9981,scaleY:0.9982,rotation:-0.0067,x:240.8,y:4.6},0).wait(1).to({regX:107.4,regY:80.5,scaleX:0.9992,scaleY:0.9993,rotation:-0.0035,x:248.3,y:1.2},0).wait(208));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(114.2,-215.9,250.40000000000003,304.7);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-13.2,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-115.1,-22.2,121.8,43), null);


(lib.white_boxes = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// box_1
	this.box_1 = new lib.box_c();
	this.box_1.name = "box_1";
	this.box_1.setTransform(143.5,45.6,1.1133,1.0285,0,0,0,75,125);

	this.timeline.addTween(cjs.Tween.get(this.box_1).wait(1));

	// box_2
	this.box_2 = new lib.box_c();
	this.box_2.name = "box_2";
	this.box_2.setTransform(143.5,45.6,1.1133,1.0285,0,0,0,75,125);
	this.box_2.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.box_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white_boxes, new cjs.Rectangle(60,-85.9,301,260.20000000000005), null);


(lib.bg_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3YUFMAAAgoJMAuxAAAMAAAAoJg");
	mask.setTransform(150.275,345.525);

	// UI anim
	this.anim = new lib.anim();
	this.anim.name = "anim";
	this.anim.setTransform(200.4,499.9,0.67,0.67,0,0,0,364.8,151.2);

	var maskedShapeInstanceList = [this.anim];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// Layer_2
	this.instance = new lib._300x600_BG();
	this.instance.setTransform(0,217);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_2, new cjs.Rectangle(0.6,-10,299.4,484), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,196,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(233.2,548.1,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(246.15,548.25,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// final screen
	this.endUI = new lib.final_screen();
	this.endUI.name = "endUI";
	this.endUI.setTransform(157.75,320.25,1,1,0,0,0,125,94.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// White_box
	this.boxes = new lib.white_boxes();
	this.boxes.name = "boxes";
	this.boxes.setTransform(14,425.7,1,1.0025,0,0,0,75,125);

	this.timeline.addTween(cjs.Tween.get(this.boxes).wait(1));

	// bg image
	this.bg = new lib.bg_2();
	this.bg.name = "bg";
	this.bg.setTransform(136.3,106,1,1,0,0,0,136.3,106);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	// logo small
	this.logoSmall = new lib.MSFT_Logo_anim();
	this.logoSmall.name = "logoSmall";
	this.logoSmall.setTransform(66.55,24.05,0.746,0.746,0,0,0,15.5,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logoSmall).wait(1));

	// bg
	this.bg_1 = new lib.bg_1();
	this.bg_1.name = "bg_1";
	this.bg_1.setTransform(146,302.9,1,1,0,0,0,146,302.9);

	this.timeline.addTween(cjs.Tween.get(this.bg_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-1,0,344,600.9), null);


// stage content:
(lib.M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
		
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		var box1 = mc.boxes.box_1
		var box2 = mc.boxes.box_2
		var anim = mc.bg.anim
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
			
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, x: "+=50", alpha: 0, stagger: 0.1, ease:Power4.easeOut}, "+0.4");
				this.tl1.from(exportRoot.headline2,{duration:0.8, x: "+=50", alpha: 0, stagger: 0.1, ease:Power4.easeOut}, ">-0.6");
				
				this.tl1.from(exportRoot,{duration:0.3, onComplete:function(){ anim.play();}})
				this.tl1.to(anim.base.overlay,{duration:0.7, alpha: 0,  ease:Power4.easeInOut}, "<+0.2");		
				
		
				this.tl1.to(mc.bg,{duration:1.2, x: "-=35", alpha: 0, ease:Power4.easeInOut}, "+9.8");		
				this.tl1.from(box2,{duration:1, x: "+=300",  ease:Power4.easeOut}, ">-.8");
				this.tl1.from(box1,{duration:1, x: "+=300",  ease:Power4.easeOut}, ">-.8");					
				this.tl1.from(mc.endUI,{duration:1.2, x: "+=300",  ease:Power4.easeOut}, "<+0.5");	
				
				
			
				this.tl1.from(mc.cta , 0.8, { x: "+=160", ease:Power4.easeOut}, ">-0.6");
				this.tl1.from(mc.txtCta, 0.8, { x: "+=160", alpha: 0, ease:Power4.easeOut}, ">-0.8");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				
				exportRoot.tl1.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
		
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(149,300,194,300.9);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1.png?1633418745811", id:"M365_Creators_AUS_300x600_BAN_COMP_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;