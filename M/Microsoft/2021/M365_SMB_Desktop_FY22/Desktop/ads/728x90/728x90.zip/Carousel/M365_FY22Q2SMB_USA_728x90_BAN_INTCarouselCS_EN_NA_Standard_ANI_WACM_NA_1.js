(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CliftonCoffee_728x90 = function() {
	this.initialize(img.CliftonCoffee_728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,461,307);


(lib.HouseOfLilac_728x90 = function() {
	this.initialize(img.HouseOfLilac_728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,445,231);


(lib.ThinkUp_728x90 = function() {
	this.initialize(img.ThinkUp_728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,446,246);


(lib.TonysChoco_728x90 = function() {
	this.initialize(img.TonysChoco_728x90);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,429,286);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.video = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.navdot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgUAVQgJgJAAgMQAAgLAJgJQAJgJALAAQAMAAAJAJQAJAJAAALQAAAMgJAJQgJAJgMAAQgLAAgJgJg");
	this.shape.setTransform(-0.05,-0.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AhPBNIAAiZICfAAIAACZg");
	this.shape_1.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-7.7,16,15.4);


(lib.navarrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgrAdQgDAAgCgDQgCgCAAgDQAAgDACgCIAugqQACgCADAAQACAAADACIApAqQACACAAADQAAADgCACQgCADgDAAQgDAAgCgDIglgkIgoAlQgCACgDAAIAAAAg");
	this.shape.setTransform(9.0247,5.6751);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AheA7IAAh1IC9AAIAAB1g");
	this.shape_1.setTransform(9.5,5.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,19,11.9);


(lib.mute4_wht = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,2,0,3).p("AACguQgGAEgHAHQgJALgDANQgBAFAAAGQAAAHABAGQADAMAIAKQAFAIAGADAAXgaQgEACgEAEQgJAIABAMQAAANAHAIQADAFAEAB");
	this.shape.setTransform(-6.3219,0.3549);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.9,-7.5,16.7,15.5);


(lib.mute4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,2,0,3).p("AACguQgGAEgHAHQgJALgDANQgBAFAAAGQAAAHABAGQADAMAIAKQAFAIAGADAAXgaQgEACgEAEQgJAIABAMQAAANAHAIQADAFAEAB");
	this.shape.setTransform(-6.3219,0.3549);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.9,-7.5,16.7,15.5);


(lib.mute3_wht = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1.5,2,0,3).p("AAXgaQgEACgEAEQgJAIABAMQAAANAHAIQADAFAEABAACguQgGAEgHAHQgJALgDANQgBAFAAAGQAAAHABAGQADAMAIAKQAFAIAGAD");
	this.shape.setTransform(-6.3219,0.3549);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.9,-7.5,16.7,15.5);


(lib.mute3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,2,0,3).p("AACguQgGAEgHAHQgJALgDANQgBAFAAAGQAAAHABAGQADAMAIAKQAFAIAGADAAXgaQgEACgEAEQgJAIABAMQAAANAHAIQADAFAEAB");
	this.shape.setTransform(-6.3219,0.3549);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.9,-7.5,16.7,15.5);


(lib.mute2_wht = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,2,0,3).p("AgSATIASgTIgTgSAAUASIgUgSIASgT");
	this.shape.setTransform(-7.0247,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.4,-7.5,17.2,15.5);


(lib.mute2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,0,3).p("AAUASIgUgSIASgTAgSATIASgTIgTgS");
	this.shape.setTransform(-7.0247,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.4,-7.5,17.2,15.5);


(lib.mute_1_wht = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,2,0,3).p("AgSATIASgTIgTgSAAUASIgUgSIASgT");
	this.shape.setTransform(-7.0247,0.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.4,-7.5,17.2,15.5);


(lib.mute_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,0,3).p("AAUASIgUgSIASgTAgSATIASgTIgTgS");
	this.shape.setTransform(-7.0247,0.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgohNIA5AyIAYAAIAAA3IgYAAIg5Ayg");
	this.shape_1.setTransform(2.65,0.225);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.4,-7.5,17.2,15.5);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2128,21.2128,0.3866,0.3866);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6103,21.2128,0.3866,0.3866);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2128,6.6103,0.3866,0.3866);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6103,6.6103,0.3866,0.3866);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AGoBSQgJgKAAgTIAAg9IgqAAIAABhIgdAAIAAhhIgUAAIAAgXIAUAAIAAgQQAAgTANgMQANgMASAAIAJABIAHABIAAAZIgEgDIgIgBQgJAAgFAFQgFAHAAAKIAAAOIAqAAIAAgbIAcgIIAAAjIAdAAIAAAXIgdAAIAAA3QABAMAEAEQADAFAJAAIAGgCIAGgDIAAAYIgJADIgMABQgSAAgJgJgADXBLQgRgQAAgdQAAgdARgRQARgSAeAAQAcABAPAQQAQARABAbQAAAdgRASQgRARgdAAQgcAAgQgQgADsAAQgIAKAAATQAAATAIAJQAJALAPAAQAQAAAJgLQAHgJAAgUQAAgTgIgJQgIgKgQABQgPgBgJAKgAB6BaIgQgFIAAgcQAIAFAJADQAKAEAGAAQAJAAAFgDQAFgDAAgGQAAgGgFgEQgEgEgOgFQgPgHgHgHQgGgJgBgNQAAgOANgLQANgLAVAAIAOACIANAEIAAAaIgNgGQgIgDgHAAQgIAAgEADQgFAEAAAEQAAAGAEADQADADAOAGQARAHAGAJQAIAIAAAMQgBARgNAKQgMAKgXAAIgQgBgAgMBLQgRgQAAgdQAAgdARgRQAPgSAfAAQAcABAQAQQAPARAAAbQAAAegQARQgSARgcAAQgdAAgOgQgAAIAAQgIAKAAATQAAATAIAJQAIALARAAQAPAAAHgLQAJgJAAgUQAAgSgJgKQgIgKgPABQgQgBgIAKgAjGBKQgRgQAAgaQAAgdARgSQARgTAeAAQAJAAAIACQAIACAFAEIAAAaQgHgEgHgDQgGgDgHABQgSAAgJAJQgLALAAASQAAATAKAJQAKALAQAAQAHAAAHgDQAIgDAHgFIAAAaQgHAEgIADIgTABQgbAAgQgRgAhkBZIAAh4IAcAAIAAAUIAAAAQAEgKAIgGQAIgFALgBIAGABIAFABIAAAdIgHgEQgEgBgGAAQgKAAgIAIQgHAIAAATIAAA9gAkHBZIAAh4IAcAAIAAB4gAk/BZIAAiDIAAAAIg0CDIgTAAIg2iDIAAAAIAACDIgbAAIAAinIApAAIAxB7IABAAIAyh7IAoAAIAACngAkFg1QgFgFAAgHQAAgHAFgFQAGgFAGABQAHgBAGAFQAEAFAAAHQAAAHgEAFQgGAEgHAAQgHAAgFgEg");
	this.shape_4.setTransform(83.4,13.45);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1029,14.0517,0.3866,0.3866);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.8971,13.9067,0.3866,0.3866);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.44,13.9067,0.3866,0.3866);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.img4_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.HouseOfLilac_728x90();
	this.instance.setTransform(0,0,0.836,0.8398);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4_sub, new cjs.Rectangle(0,0,372,194), null);


(lib.img3_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ThinkUp_728x90();
	this.instance.setTransform(0,0,0.8341,0.8333);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3_sub, new cjs.Rectangle(0,0,372,205.5), null);


(lib.img2_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.TonysChoco_728x90();
	this.instance.setTransform(0,0,0.8345,0.8339);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2_sub, new cjs.Rectangle(0,0,358,238.5), null);


(lib.img1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.CliftonCoffee_728x90();
	this.instance.setTransform(0,0,0.8373,0.8338);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1_sub, new cjs.Rectangle(0,0,386,256), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.clicktagbutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("EAnTAHCIAAuDIRlAAIAAODgEgx7AHCIAAlFIm8AAIAAo+MBcYAAAIAAODg");
	this.shape.setTransform(364,45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(363.9931,44.9963,2.4266,0.36);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG, new cjs.Rectangle(0,0,728,90), null);


(lib.barofloadingbar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0278D4").s().p("AqKAvIAAhdIUVAAIAABdg");
	this.shape.setTransform(65.05,4.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.barofloadingbar, new cjs.Rectangle(0,0,130.1,9.5), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.aHit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ai9ClIAAlJIF7AAIAAFJg");
	this.shape.setTransform(-19,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aHit, new cjs.Rectangle(-38,-16.5,38,33), null);


(lib.nav = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.arrow_down = new lib.navarrow();
	this.arrow_down.name = "arrow_down";
	this.arrow_down.setTransform(9.7,97.3,1,1,180,0,0,4.4,2.1);
	this.arrow_down.shadow = new cjs.Shadow("rgba(0,0,0,0)",0,3,5);
	new cjs.ButtonHelper(this.arrow_down, 0, 1, 2, false, new lib.navarrow(), 3);

	this.arrow_up = new lib.navarrow();
	this.arrow_up.name = "arrow_up";
	this.arrow_up.setTransform(0.55,-1.2,1,1,0,0,0,4.4,2.1);
	this.arrow_up.shadow = new cjs.Shadow("rgba(0,0,0,0)",0,3,5);
	new cjs.ButtonHelper(this.arrow_up, 0, 1, 2, false, new lib.navarrow(), 3);

	this.dot_1 = new lib.navdot();
	this.dot_1.name = "dot_1";
	this.dot_1.setTransform(5.2,21.4);
	this.dot_1.alpha = 0.3984;
	this.dot_1.shadow = new cjs.Shadow("rgba(0,0,0,0)",0,3,5);
	new cjs.ButtonHelper(this.dot_1, 0, 1, 2, false, new lib.navdot(), 3);

	this.dot_4 = new lib.navdot();
	this.dot_4.name = "dot_4";
	this.dot_4.setTransform(5.2,76.2);
	this.dot_4.alpha = 0.3984;
	this.dot_4.shadow = new cjs.Shadow("rgba(0,0,0,0)",0,3,5);
	new cjs.ButtonHelper(this.dot_4, 0, 1, 2, false, new lib.navdot(), 3);

	this.dot_3 = new lib.navdot();
	this.dot_3.name = "dot_3";
	this.dot_3.setTransform(5.2,57.35);
	this.dot_3.alpha = 0.3984;
	this.dot_3.shadow = new cjs.Shadow("rgba(0,0,0,0)",0,3,5);
	new cjs.ButtonHelper(this.dot_3, 0, 1, 2, false, new lib.navdot(), 3);

	this.dot_2 = new lib.navdot();
	this.dot_2.name = "dot_2";
	this.dot_2.setTransform(5.2,40.3);
	this.dot_2.alpha = 0.3984;
	this.dot_2.shadow = new cjs.Shadow("rgba(0,0,0,0)",0,3,5);
	new cjs.ButtonHelper(this.dot_2, 0, 1, 2, false, new lib.navdot(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.dot_2},{t:this.dot_3},{t:this.dot_4},{t:this.dot_1},{t:this.arrow_up},{t:this.arrow_down}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6,-3.5,26,113.4);


(lib.mute_btn_wht = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out_mute:0,over_mute:1,out_muteOff:2,over_muteOff:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_2
	this.instance = new lib.aHit();
	this.instance.setTransform(-18.5,16.5,1,1,0,0,0,-19,0);
	this.instance.alpha = 0.0117;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Layer 6
	this.instance_1 = new lib.mute_1_wht("synched",0);
	this.instance_1.setTransform(-18,17,1.754,1.754);

	this.instance_2 = new lib.mute2_wht("synched",0);
	this.instance_2.setTransform(-18,17,1.754,1.754);
	this.instance_2.alpha = 0.5;

	this.instance_3 = new lib.mute3_wht("synched",0);
	this.instance_3.setTransform(-18,17,1.754,1.754);

	this.instance_4 = new lib.mute4_wht("synched",0);
	this.instance_4.setTransform(-18,17,1.754,1.754);
	this.instance_4.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true,alpha:0.5},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.5,0,38,33);


(lib.mute_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"out_mute":0,"over_mute":1,"out_muteOff":2,"over_muteOff":3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_2
	this.instance = new lib.aHit();
	this.instance.setTransform(-18.5,16.5,1,1,0,0,0,-19,0);
	this.instance.alpha = 0.0117;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4));

	// Layer 6
	this.instance_1 = new lib.mute_1("synched",0);
	this.instance_1.setTransform(-18,17,1.754,1.754);
	this.instance_1.alpha = 0.5;

	this.instance_2 = new lib.mute2("synched",0);
	this.instance_2.setTransform(-18,17,1.754,1.754);

	this.instance_3 = new lib.mute3("synched",0);
	this.instance_3.setTransform(-18,17,1.754,1.754);
	this.instance_3.alpha = 0.5;

	this.instance_4 = new lib.mute4("synched",0);
	this.instance_4.setTransform(-18,17,1.754,1.754);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true,alpha:1},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.5,0,38,33);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.loadingbar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bar
	this.instance = new lib.barofloadingbar();
	this.instance.setTransform(0,0,0.75,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("AqKAvIAAhdIUVAAIAABdg");
	this.shape.setTransform(65.05,4.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.loadingbar, new cjs.Rectangle(0,0,130.1,9.5), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
		this.alpha=0;
	}
	this.frame_30 = function() {
		this.alpha=1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1).call(this.frame_30).wait(30));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_1 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_2 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_3 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_4 = new cjs.Graphics().p("A7mDIIAAmQMA3NAAAIAAGQg");
	var mask_graphics_5 = new cjs.Graphics().p("A7iDJIAAmSMA3FAAAIAAGSg");
	var mask_graphics_6 = new cjs.Graphics().p("A7aDLIAAmVMA21AAAIAAGVg");
	var mask_graphics_7 = new cjs.Graphics().p("A7NDNIAAmZMA2bAAAIAAGZg");
	var mask_graphics_8 = new cjs.Graphics().p("A66DRIAAmhMA11AAAIAAGhg");
	var mask_graphics_9 = new cjs.Graphics().p("A6dDXIAAmtMA07AAAIAAGtg");
	var mask_graphics_10 = new cjs.Graphics().p("A51DfIAAm9MAzrAAAIAAG9g");
	var mask_graphics_11 = new cjs.Graphics().p("A4/DpIAAnRMAx/AAAIAAHRg");
	var mask_graphics_12 = new cjs.Graphics().p("A35D3IAAntMAvzAAAIAAHtg");
	var mask_graphics_13 = new cjs.Graphics().p("A2eEJIAAoRMAs9AAAIAAIRg");
	var mask_graphics_14 = new cjs.Graphics().p("A0sEfIAAo9MApZAAAIAAI9g");
	var mask_graphics_15 = new cjs.Graphics().p("AylE5IAApxMAlLAAAIAAJxg");
	var mask_graphics_16 = new cjs.Graphics().p("AwzFPIAAqdMAhnAAAIAAKdg");
	var mask_graphics_17 = new cjs.Graphics().p("AvYFhIAArBIexAAIAALBg");
	var mask_graphics_18 = new cjs.Graphics().p("AuSFvIAArdIclAAIAALdg");
	var mask_graphics_19 = new cjs.Graphics().p("AtcF5IAArxIa5AAIAALxg");
	var mask_graphics_20 = new cjs.Graphics().p("As0GBIAAsBIZpAAIAAMBg");
	var mask_graphics_21 = new cjs.Graphics().p("AsXGHIAAsNIYwAAIAAMNg");
	var mask_graphics_22 = new cjs.Graphics().p("AsEGLIAAsVIYJAAIAAMVg");
	var mask_graphics_23 = new cjs.Graphics().p("Ar3GNIAAsZIXvAAIAAMZg");
	var mask_graphics_24 = new cjs.Graphics().p("ArvGOIAAsbIXfAAIAAMbg");
	var mask_graphics_25 = new cjs.Graphics().p("ArrGPIAAseIXXAAIAAMeg");
	var mask_graphics_26 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_27 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_28 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_29 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_30 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_31 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_32 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_33 = new cjs.Graphics().p("ArrGPIAAseIXWAAIAAMeg");
	var mask_graphics_34 = new cjs.Graphics().p("AruGPIAAsdIXdAAIAAMdg");
	var mask_graphics_35 = new cjs.Graphics().p("Ar1GOIAAsaIXrAAIAAMag");
	var mask_graphics_36 = new cjs.Graphics().p("AsAGLIAAsVIYBAAIAAMVg");
	var mask_graphics_37 = new cjs.Graphics().p("AsRGIIAAsPIYjAAIAAMPg");
	var mask_graphics_38 = new cjs.Graphics().p("AsqGDIAAsFIZWAAIAAMFg");
	var mask_graphics_39 = new cjs.Graphics().p("AtNF8IAAr3IabAAIAAL3g");
	var mask_graphics_40 = new cjs.Graphics().p("At8FzIAArlIb5AAIAALlg");
	var mask_graphics_41 = new cjs.Graphics().p("Au6FnIAArNId1AAIAALNg");
	var mask_graphics_42 = new cjs.Graphics().p("AwJFYIAAqvMAgTAAAIAAKvg");
	var mask_graphics_43 = new cjs.Graphics().p("AxtFEIAAqHMAjbAAAIAAKHg");
	var mask_graphics_44 = new cjs.Graphics().p("AzpEsIAApXMAnTAAAIAAJXg");
	var mask_graphics_45 = new cjs.Graphics().p("A1kEUIAAonMArJAAAIAAIng");
	var mask_graphics_46 = new cjs.Graphics().p("A3IEAIAAn/MAuRAAAIAAH/g");
	var mask_graphics_47 = new cjs.Graphics().p("A4XDxIAAnhMAwvAAAIAAHhg");
	var mask_graphics_48 = new cjs.Graphics().p("A5VDlIAAnJMAyrAAAIAAHJg");
	var mask_graphics_49 = new cjs.Graphics().p("A6EDcIAAm3MA0JAAAIAAG3g");
	var mask_graphics_50 = new cjs.Graphics().p("A6nDVIAAmpMA1PAAAIAAGpg");
	var mask_graphics_51 = new cjs.Graphics().p("A7ADQIAAmfMA2AAAAIAAGfg");
	var mask_graphics_52 = new cjs.Graphics().p("A7RDNIAAmZMA2jAAAIAAGZg");
	var mask_graphics_53 = new cjs.Graphics().p("A7cDKIAAmUMA25AAAIAAGUg");
	var mask_graphics_54 = new cjs.Graphics().p("A7jDJIAAmRMA3HAAAIAAGRg");
	var mask_graphics_55 = new cjs.Graphics().p("A7mDIIAAmQMA3OAAAIAAGQg");
	var mask_graphics_56 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_57 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_58 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_59 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:186,y:29}).wait(1).to({graphics:mask_graphics_1,x:186,y:29}).wait(1).to({graphics:mask_graphics_2,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_3,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_4,x:185.6,y:29}).wait(1).to({graphics:mask_graphics_5,x:185.025,y:29}).wait(1).to({graphics:mask_graphics_6,x:183.95,y:29}).wait(1).to({graphics:mask_graphics_7,x:182.225,y:29.025}).wait(1).to({graphics:mask_graphics_8,x:179.55,y:29.025}).wait(1).to({graphics:mask_graphics_9,x:175.65,y:29.075}).wait(1).to({graphics:mask_graphics_10,x:170.225,y:29.125}).wait(1).to({graphics:mask_graphics_11,x:162.9,y:29.175}).wait(1).to({graphics:mask_graphics_12,x:153.275,y:29.25}).wait(1).to({graphics:mask_graphics_13,x:140.925,y:29.325}).wait(1).to({graphics:mask_graphics_14,x:125.375,y:29.425}).wait(1).to({graphics:mask_graphics_15,x:107.125,y:29.55}).wait(1).to({graphics:mask_graphics_16,x:91.575,y:29.675}).wait(1).to({graphics:mask_graphics_17,x:79.225,y:29.75}).wait(1).to({graphics:mask_graphics_18,x:69.625,y:29.825}).wait(1).to({graphics:mask_graphics_19,x:62.275,y:29.875}).wait(1).to({graphics:mask_graphics_20,x:56.85,y:29.925}).wait(1).to({graphics:mask_graphics_21,x:52.95,y:29.975}).wait(1).to({graphics:mask_graphics_22,x:50.275,y:29.975}).wait(1).to({graphics:mask_graphics_23,x:48.55,y:30}).wait(1).to({graphics:mask_graphics_24,x:47.475,y:30}).wait(1).to({graphics:mask_graphics_25,x:46.9,y:30}).wait(1).to({graphics:mask_graphics_26,x:46.65,y:30}).wait(1).to({graphics:mask_graphics_27,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_28,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_29,x:46.4757,y:30.0005}).wait(1).to({graphics:mask_graphics_30,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_31,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_32,x:46.625,y:30}).wait(1).to({graphics:mask_graphics_33,x:46.85,y:30}).wait(1).to({graphics:mask_graphics_34,x:47.375,y:29.975}).wait(1).to({graphics:mask_graphics_35,x:48.275,y:30}).wait(1).to({graphics:mask_graphics_36,x:49.825,y:29.975}).wait(1).to({graphics:mask_graphics_37,x:52.15,y:29.95}).wait(1).to({graphics:mask_graphics_38,x:55.55,y:29.95}).wait(1).to({graphics:mask_graphics_39,x:60.275,y:29.925}).wait(1).to({graphics:mask_graphics_40,x:66.675,y:29.85}).wait(1).to({graphics:mask_graphics_41,x:75.075,y:29.8}).wait(1).to({graphics:mask_graphics_42,x:85.85,y:29.725}).wait(1).to({graphics:mask_graphics_43,x:99.425,y:29.625}).wait(1).to({graphics:mask_graphics_44,x:116.25,y:29.5}).wait(1).to({graphics:mask_graphics_45,x:133.075,y:29.375}).wait(1).to({graphics:mask_graphics_46,x:146.65,y:29.275}).wait(1).to({graphics:mask_graphics_47,x:157.425,y:29.2}).wait(1).to({graphics:mask_graphics_48,x:165.825,y:29.15}).wait(1).to({graphics:mask_graphics_49,x:172.225,y:29.075}).wait(1).to({graphics:mask_graphics_50,x:176.95,y:29.05}).wait(1).to({graphics:mask_graphics_51,x:180.35,y:29.05}).wait(1).to({graphics:mask_graphics_52,x:182.675,y:29.025}).wait(1).to({graphics:mask_graphics_53,x:184.225,y:29}).wait(1).to({graphics:mask_graphics_54,x:185.125,y:29.025}).wait(1).to({graphics:mask_graphics_55,x:185.65,y:29}).wait(1).to({graphics:mask_graphics_56,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_57,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_58,x:186,y:29}).wait(1).to({graphics:mask_graphics_59,x:186,y:29}).wait(1));

	// Layer_1
	this.instance = new lib.img4_sub();
	this.instance.setTransform(0,-62.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-0.1,scaleX:0.4425,scaleY:0.4425,x:-34.8,y:-11.25},29,cjs.Ease.quartInOut).to({regY:0,scaleX:1,scaleY:1,x:0,y:-62.1},30,cjs.Ease.quartInOut).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A9DEiIAApDMA6HAAAIAAJDg");
	this.shape.setTransform(186,29);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A9CEiIAApDMA6FAAAIAAJDg");
	this.shape_1.setTransform(185.85,29);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6BAAAIAAJEg");
	this.shape_2.setTransform(185.6,29);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A88EjIAApFMA55AAAIAAJFg");
	this.shape_3.setTransform(185,29);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A80EkIAApHMA5oAAAIAAJHg");
	this.shape_4.setTransform(183.95,29.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A8mEmIAApLMA5NAAAIAAJLg");
	this.shape_5.setTransform(182.2,29.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A8SEpIAApSMA4lAAAIAAJSg");
	this.shape_6.setTransform(179.525,29.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("A70EuIAApbMA3pAAAIAAJbg");
	this.shape_7.setTransform(175.65,29.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("A7LE0IAApnMA2XAAAIAAJng");
	this.shape_8.setTransform(170.225,29.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A6TE9IAAp5MA0nAAAIAAJ5g");
	this.shape_9.setTransform(162.9,29.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("A5JFIIAAqPMAyTAAAIAAKPg");
	this.shape_10.setTransform(153.275,29.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A3rFWIAAqrMAvXAAAIAAKrg");
	this.shape_11.setTransform(140.95,29.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("A10FoIAArOMArpAAAIAALOg");
	this.shape_12.setTransform(125.375,29.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AzpF8IAAr3MAnTAAAIAAL3g");
	this.shape_13.setTransform(107.125,29.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AxyGOIAAsbMAjlAAAIAAMbg");
	this.shape_14.setTransform(91.55,29.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AwUGdIAAs5MAgpAAAIAAM5g");
	this.shape_15.setTransform(79.225,29.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AvKGnIAAtOIeWAAIAANOg");
	this.shape_16.setTransform(69.6,29.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AuTGwIAAtfIcmAAIAANfg");
	this.shape_17.setTransform(62.3,29.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AtpG2IAAtrIbTAAIAANrg");
	this.shape_18.setTransform(56.85,29.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AtLG6IAAt0IaXAAIAAN0g");
	this.shape_19.setTransform(52.975,29.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("As3G+IAAt7IZvAAIAAN7g");
	this.shape_20.setTransform(50.3,29.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AspHAIAAt/IZTAAIAAN/g");
	this.shape_21.setTransform(48.55,29.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AsiHBIAAuBIZEAAIAAOBg");
	this.shape_22.setTransform(47.5,30);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AsdHCIAAuCIY7AAIAAOCg");
	this.shape_23.setTransform(46.9,30);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AsbHCIAAuDIY3AAIAAODg");
	this.shape_24.setTransform(46.65,30);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AsaHCIAAuDIY1AAIAAODg");
	this.shape_25.setTransform(46.525,30);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AsgHBIAAuBIZCAAIAAOBg");
	this.shape_26.setTransform(47.35,30);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AsoHAIAAt/IZRAAIAAN/g");
	this.shape_27.setTransform(48.275,30);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AszG+IAAt7IZnAAIAAN7g");
	this.shape_28.setTransform(49.825,29.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AtFG8IAAt3IaLAAIAAN3g");
	this.shape_29.setTransform(52.15,29.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AtfG4IAAtvIa/AAIAANvg");
	this.shape_30.setTransform(55.55,29.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AuDGyIAAtjIcHAAIAANjg");
	this.shape_31.setTransform(60.275,29.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Au0GrIAAtVIdpAAIAANVg");
	this.shape_32.setTransform(66.65,29.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Av0GhIAAtBIfpAAIAANBg");
	this.shape_33.setTransform(75.075,29.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AxGGVIAAspMAiNAAAIAAMpg");
	this.shape_34.setTransform(85.85,29.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AyuGFIAAsJMAldAAAIAAMJg");
	this.shape_35.setTransform(99.425,29.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("A0uFyIAArjMApeAAAIAALjg");
	this.shape_36.setTransform(116.25,29.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("A2vFfIAAq9MAtfAAAIAAK9g");
	this.shape_37.setTransform(133.075,29.375);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("A4WFPIAAqdMAwtAAAIAAKdg");
	this.shape_38.setTransform(146.65,29.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("A5pFDIAAqFMAzTAAAIAAKFg");
	this.shape_39.setTransform(157.425,29.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("A6pE5IAApxMA1TAAAIAAJxg");
	this.shape_40.setTransform(165.85,29.15);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("A7aEyIAApjMA21AAAIAAJjg");
	this.shape_41.setTransform(172.225,29.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("A7+EsIAApXMA39AAAIAAJXg");
	this.shape_42.setTransform(176.95,29.075);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("A8YEoIAApQMA4xAAAIAAJQg");
	this.shape_43.setTransform(180.35,29.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("A8qEmIAApLMA5VAAAIAAJLg");
	this.shape_44.setTransform(182.675,29.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("A81EkIAApHMA5rAAAIAAJHg");
	this.shape_45.setTransform(184.225,29);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("A88EjIAApFMA56AAAIAAJFg");
	this.shape_46.setTransform(185.15,29);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6CAAAIAAJEg");
	this.shape_47.setTransform(185.65,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:185.85}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23,p:{x:46.9}}]},1).to({state:[{t:this.shape_24,p:{x:46.65}}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_24,p:{x:46.625}}]},1).to({state:[{t:this.shape_23,p:{x:46.85}}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_1,p:{x:185.875}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({x:185.975},0).to({_off:true},1).wait(54).to({_off:false},0).wait(1).to({x:186},0).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(27).to({_off:false},0).wait(1).to({x:46.5},0).wait(3).to({x:46.525},0).to({_off:true},1).wait(28));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-444.1,-15,816.1,818.5);


(lib.img3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
		this.alpha=0;
	}
	this.frame_30 = function() {
		this.alpha=1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1).call(this.frame_30).wait(30));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_1 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_2 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_3 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_4 = new cjs.Graphics().p("A7mDIIAAmQMA3NAAAIAAGQg");
	var mask_graphics_5 = new cjs.Graphics().p("A7iDJIAAmSMA3FAAAIAAGSg");
	var mask_graphics_6 = new cjs.Graphics().p("A7aDLIAAmVMA21AAAIAAGVg");
	var mask_graphics_7 = new cjs.Graphics().p("A7NDNIAAmZMA2bAAAIAAGZg");
	var mask_graphics_8 = new cjs.Graphics().p("A66DRIAAmhMA11AAAIAAGhg");
	var mask_graphics_9 = new cjs.Graphics().p("A6dDXIAAmtMA07AAAIAAGtg");
	var mask_graphics_10 = new cjs.Graphics().p("A51DfIAAm9MAzrAAAIAAG9g");
	var mask_graphics_11 = new cjs.Graphics().p("A4/DpIAAnRMAx/AAAIAAHRg");
	var mask_graphics_12 = new cjs.Graphics().p("A35D3IAAntMAvzAAAIAAHtg");
	var mask_graphics_13 = new cjs.Graphics().p("A2eEJIAAoRMAs9AAAIAAIRg");
	var mask_graphics_14 = new cjs.Graphics().p("A0sEfIAAo9MApZAAAIAAI9g");
	var mask_graphics_15 = new cjs.Graphics().p("AylE5IAApxMAlLAAAIAAJxg");
	var mask_graphics_16 = new cjs.Graphics().p("AwzFPIAAqdMAhnAAAIAAKdg");
	var mask_graphics_17 = new cjs.Graphics().p("AvYFhIAArBIexAAIAALBg");
	var mask_graphics_18 = new cjs.Graphics().p("AuSFvIAArdIclAAIAALdg");
	var mask_graphics_19 = new cjs.Graphics().p("AtcF5IAArxIa5AAIAALxg");
	var mask_graphics_20 = new cjs.Graphics().p("As0GBIAAsBIZpAAIAAMBg");
	var mask_graphics_21 = new cjs.Graphics().p("AsXGHIAAsNIYwAAIAAMNg");
	var mask_graphics_22 = new cjs.Graphics().p("AsEGLIAAsVIYJAAIAAMVg");
	var mask_graphics_23 = new cjs.Graphics().p("Ar3GNIAAsZIXvAAIAAMZg");
	var mask_graphics_24 = new cjs.Graphics().p("ArvGOIAAsbIXfAAIAAMbg");
	var mask_graphics_25 = new cjs.Graphics().p("ArrGPIAAseIXXAAIAAMeg");
	var mask_graphics_26 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_27 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_28 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_29 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_30 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_31 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_32 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_33 = new cjs.Graphics().p("ArrGPIAAseIXWAAIAAMeg");
	var mask_graphics_34 = new cjs.Graphics().p("AruGPIAAsdIXdAAIAAMdg");
	var mask_graphics_35 = new cjs.Graphics().p("Ar1GOIAAsaIXrAAIAAMag");
	var mask_graphics_36 = new cjs.Graphics().p("AsAGLIAAsVIYBAAIAAMVg");
	var mask_graphics_37 = new cjs.Graphics().p("AsRGIIAAsPIYjAAIAAMPg");
	var mask_graphics_38 = new cjs.Graphics().p("AsqGDIAAsFIZWAAIAAMFg");
	var mask_graphics_39 = new cjs.Graphics().p("AtNF8IAAr3IabAAIAAL3g");
	var mask_graphics_40 = new cjs.Graphics().p("At8FzIAArlIb5AAIAALlg");
	var mask_graphics_41 = new cjs.Graphics().p("Au6FnIAArNId1AAIAALNg");
	var mask_graphics_42 = new cjs.Graphics().p("AwJFYIAAqvMAgTAAAIAAKvg");
	var mask_graphics_43 = new cjs.Graphics().p("AxtFEIAAqHMAjbAAAIAAKHg");
	var mask_graphics_44 = new cjs.Graphics().p("AzpEsIAApXMAnTAAAIAAJXg");
	var mask_graphics_45 = new cjs.Graphics().p("A1kEUIAAonMArJAAAIAAIng");
	var mask_graphics_46 = new cjs.Graphics().p("A3IEAIAAn/MAuRAAAIAAH/g");
	var mask_graphics_47 = new cjs.Graphics().p("A4XDxIAAnhMAwvAAAIAAHhg");
	var mask_graphics_48 = new cjs.Graphics().p("A5VDlIAAnJMAyrAAAIAAHJg");
	var mask_graphics_49 = new cjs.Graphics().p("A6EDcIAAm3MA0JAAAIAAG3g");
	var mask_graphics_50 = new cjs.Graphics().p("A6nDVIAAmpMA1PAAAIAAGpg");
	var mask_graphics_51 = new cjs.Graphics().p("A7ADQIAAmfMA2AAAAIAAGfg");
	var mask_graphics_52 = new cjs.Graphics().p("A7RDNIAAmZMA2jAAAIAAGZg");
	var mask_graphics_53 = new cjs.Graphics().p("A7cDKIAAmUMA25AAAIAAGUg");
	var mask_graphics_54 = new cjs.Graphics().p("A7jDJIAAmRMA3HAAAIAAGRg");
	var mask_graphics_55 = new cjs.Graphics().p("A7mDIIAAmQMA3OAAAIAAGQg");
	var mask_graphics_56 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_57 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_58 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_59 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:186,y:29}).wait(1).to({graphics:mask_graphics_1,x:186,y:29}).wait(1).to({graphics:mask_graphics_2,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_3,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_4,x:185.6,y:29}).wait(1).to({graphics:mask_graphics_5,x:185.025,y:29}).wait(1).to({graphics:mask_graphics_6,x:183.95,y:29}).wait(1).to({graphics:mask_graphics_7,x:182.225,y:29.025}).wait(1).to({graphics:mask_graphics_8,x:179.55,y:29.025}).wait(1).to({graphics:mask_graphics_9,x:175.65,y:29.075}).wait(1).to({graphics:mask_graphics_10,x:170.225,y:29.125}).wait(1).to({graphics:mask_graphics_11,x:162.9,y:29.175}).wait(1).to({graphics:mask_graphics_12,x:153.275,y:29.25}).wait(1).to({graphics:mask_graphics_13,x:140.925,y:29.325}).wait(1).to({graphics:mask_graphics_14,x:125.375,y:29.425}).wait(1).to({graphics:mask_graphics_15,x:107.125,y:29.55}).wait(1).to({graphics:mask_graphics_16,x:91.575,y:29.675}).wait(1).to({graphics:mask_graphics_17,x:79.225,y:29.75}).wait(1).to({graphics:mask_graphics_18,x:69.625,y:29.825}).wait(1).to({graphics:mask_graphics_19,x:62.275,y:29.875}).wait(1).to({graphics:mask_graphics_20,x:56.85,y:29.925}).wait(1).to({graphics:mask_graphics_21,x:52.95,y:29.975}).wait(1).to({graphics:mask_graphics_22,x:50.275,y:29.975}).wait(1).to({graphics:mask_graphics_23,x:48.55,y:30}).wait(1).to({graphics:mask_graphics_24,x:47.475,y:30}).wait(1).to({graphics:mask_graphics_25,x:46.9,y:30}).wait(1).to({graphics:mask_graphics_26,x:46.65,y:30}).wait(1).to({graphics:mask_graphics_27,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_28,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_29,x:46.4757,y:30.0005}).wait(1).to({graphics:mask_graphics_30,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_31,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_32,x:46.625,y:30}).wait(1).to({graphics:mask_graphics_33,x:46.85,y:30}).wait(1).to({graphics:mask_graphics_34,x:47.375,y:29.975}).wait(1).to({graphics:mask_graphics_35,x:48.275,y:30}).wait(1).to({graphics:mask_graphics_36,x:49.825,y:29.975}).wait(1).to({graphics:mask_graphics_37,x:52.15,y:29.95}).wait(1).to({graphics:mask_graphics_38,x:55.55,y:29.95}).wait(1).to({graphics:mask_graphics_39,x:60.275,y:29.925}).wait(1).to({graphics:mask_graphics_40,x:66.675,y:29.85}).wait(1).to({graphics:mask_graphics_41,x:75.075,y:29.8}).wait(1).to({graphics:mask_graphics_42,x:85.85,y:29.725}).wait(1).to({graphics:mask_graphics_43,x:99.425,y:29.625}).wait(1).to({graphics:mask_graphics_44,x:116.25,y:29.5}).wait(1).to({graphics:mask_graphics_45,x:133.075,y:29.375}).wait(1).to({graphics:mask_graphics_46,x:146.65,y:29.275}).wait(1).to({graphics:mask_graphics_47,x:157.425,y:29.2}).wait(1).to({graphics:mask_graphics_48,x:165.825,y:29.15}).wait(1).to({graphics:mask_graphics_49,x:172.225,y:29.075}).wait(1).to({graphics:mask_graphics_50,x:176.95,y:29.05}).wait(1).to({graphics:mask_graphics_51,x:180.35,y:29.05}).wait(1).to({graphics:mask_graphics_52,x:182.675,y:29.025}).wait(1).to({graphics:mask_graphics_53,x:184.225,y:29}).wait(1).to({graphics:mask_graphics_54,x:185.125,y:29.025}).wait(1).to({graphics:mask_graphics_55,x:185.65,y:29}).wait(1).to({graphics:mask_graphics_56,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_57,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_58,x:186,y:29}).wait(1).to({graphics:mask_graphics_59,x:186,y:29}).wait(1));

	// Layer_1
	this.instance = new lib.img3_sub();
	this.instance.setTransform(0,-23.7,1.0001,1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-0.1,scaleX:0.4275,scaleY:0.4273,x:-33,y:-11.6},29,cjs.Ease.quartInOut).to({regY:0,scaleX:1.0001,scaleY:1,x:0,y:-23.7},30,cjs.Ease.quartInOut).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A9DEiIAApDMA6HAAAIAAJDg");
	this.shape.setTransform(186,29);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A9CEiIAApDMA6FAAAIAAJDg");
	this.shape_1.setTransform(185.85,29);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6BAAAIAAJEg");
	this.shape_2.setTransform(185.6,29);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A88EjIAApFMA55AAAIAAJFg");
	this.shape_3.setTransform(185,29);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A80EkIAApHMA5oAAAIAAJHg");
	this.shape_4.setTransform(183.95,29.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A8mEmIAApLMA5NAAAIAAJLg");
	this.shape_5.setTransform(182.2,29.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A8SEpIAApSMA4lAAAIAAJSg");
	this.shape_6.setTransform(179.525,29.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("A70EuIAApbMA3pAAAIAAJbg");
	this.shape_7.setTransform(175.65,29.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("A7LE0IAApnMA2XAAAIAAJng");
	this.shape_8.setTransform(170.225,29.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A6TE9IAAp5MA0nAAAIAAJ5g");
	this.shape_9.setTransform(162.9,29.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("A5JFIIAAqPMAyTAAAIAAKPg");
	this.shape_10.setTransform(153.275,29.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A3rFWIAAqrMAvXAAAIAAKrg");
	this.shape_11.setTransform(140.95,29.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("A10FoIAArOMArpAAAIAALOg");
	this.shape_12.setTransform(125.375,29.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AzpF8IAAr3MAnTAAAIAAL3g");
	this.shape_13.setTransform(107.125,29.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AxyGOIAAsbMAjlAAAIAAMbg");
	this.shape_14.setTransform(91.55,29.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AwUGdIAAs5MAgpAAAIAAM5g");
	this.shape_15.setTransform(79.225,29.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AvKGnIAAtOIeWAAIAANOg");
	this.shape_16.setTransform(69.6,29.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AuTGwIAAtfIcmAAIAANfg");
	this.shape_17.setTransform(62.3,29.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AtpG2IAAtrIbTAAIAANrg");
	this.shape_18.setTransform(56.85,29.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AtLG6IAAt0IaXAAIAAN0g");
	this.shape_19.setTransform(52.975,29.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("As3G+IAAt7IZvAAIAAN7g");
	this.shape_20.setTransform(50.3,29.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AspHAIAAt/IZTAAIAAN/g");
	this.shape_21.setTransform(48.55,29.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AsiHBIAAuBIZEAAIAAOBg");
	this.shape_22.setTransform(47.5,30);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AsdHCIAAuCIY7AAIAAOCg");
	this.shape_23.setTransform(46.9,30);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AsbHCIAAuDIY3AAIAAODg");
	this.shape_24.setTransform(46.65,30);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AsaHCIAAuDIY1AAIAAODg");
	this.shape_25.setTransform(46.525,30);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AsgHBIAAuBIZCAAIAAOBg");
	this.shape_26.setTransform(47.35,30);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AsoHAIAAt/IZRAAIAAN/g");
	this.shape_27.setTransform(48.275,30);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AszG+IAAt7IZnAAIAAN7g");
	this.shape_28.setTransform(49.825,29.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AtFG8IAAt3IaLAAIAAN3g");
	this.shape_29.setTransform(52.15,29.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AtfG4IAAtvIa/AAIAANvg");
	this.shape_30.setTransform(55.55,29.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AuDGyIAAtjIcHAAIAANjg");
	this.shape_31.setTransform(60.275,29.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Au0GrIAAtVIdpAAIAANVg");
	this.shape_32.setTransform(66.65,29.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Av0GhIAAtBIfpAAIAANBg");
	this.shape_33.setTransform(75.075,29.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AxGGVIAAspMAiNAAAIAAMpg");
	this.shape_34.setTransform(85.85,29.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AyuGFIAAsJMAldAAAIAAMJg");
	this.shape_35.setTransform(99.425,29.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("A0uFyIAArjMApeAAAIAALjg");
	this.shape_36.setTransform(116.25,29.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("A2vFfIAAq9MAtfAAAIAAK9g");
	this.shape_37.setTransform(133.075,29.375);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("A4WFPIAAqdMAwtAAAIAAKdg");
	this.shape_38.setTransform(146.65,29.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("A5pFDIAAqFMAzTAAAIAAKFg");
	this.shape_39.setTransform(157.425,29.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("A6pE5IAApxMA1TAAAIAAJxg");
	this.shape_40.setTransform(165.85,29.15);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("A7aEyIAApjMA21AAAIAAJjg");
	this.shape_41.setTransform(172.225,29.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("A7+EsIAApXMA39AAAIAAJXg");
	this.shape_42.setTransform(176.95,29.075);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("A8YEoIAApQMA4xAAAIAAJQg");
	this.shape_43.setTransform(180.35,29.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("A8qEmIAApLMA5VAAAIAAJLg");
	this.shape_44.setTransform(182.675,29.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("A81EkIAApHMA5rAAAIAAJHg");
	this.shape_45.setTransform(184.225,29);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("A88EjIAApFMA56AAAIAAJFg");
	this.shape_46.setTransform(185.15,29);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6CAAAIAAJEg");
	this.shape_47.setTransform(185.65,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:185.85}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23,p:{x:46.9}}]},1).to({state:[{t:this.shape_24,p:{x:46.65}}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_24,p:{x:46.625}}]},1).to({state:[{t:this.shape_23,p:{x:46.85}}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_1,p:{x:185.875}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({x:185.975},0).to({_off:true},1).wait(54).to({_off:false},0).wait(1).to({x:186},0).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(27).to({_off:false},0).wait(1).to({x:46.5},0).wait(3).to({x:46.525},0).to({_off:true},1).wait(28));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-444.1,-15,816.1,818.5);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
		this.alpha=0;
	}
	this.frame_30 = function() {
		this.alpha=1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1).call(this.frame_30).wait(30));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_1 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_2 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_3 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_4 = new cjs.Graphics().p("A7mDIIAAmQMA3NAAAIAAGQg");
	var mask_graphics_5 = new cjs.Graphics().p("A7iDJIAAmSMA3FAAAIAAGSg");
	var mask_graphics_6 = new cjs.Graphics().p("A7aDLIAAmVMA21AAAIAAGVg");
	var mask_graphics_7 = new cjs.Graphics().p("A7NDNIAAmZMA2bAAAIAAGZg");
	var mask_graphics_8 = new cjs.Graphics().p("A66DRIAAmhMA11AAAIAAGhg");
	var mask_graphics_9 = new cjs.Graphics().p("A6dDXIAAmtMA07AAAIAAGtg");
	var mask_graphics_10 = new cjs.Graphics().p("A51DfIAAm9MAzrAAAIAAG9g");
	var mask_graphics_11 = new cjs.Graphics().p("A4/DpIAAnRMAx/AAAIAAHRg");
	var mask_graphics_12 = new cjs.Graphics().p("A35D3IAAntMAvzAAAIAAHtg");
	var mask_graphics_13 = new cjs.Graphics().p("A2eEJIAAoRMAs9AAAIAAIRg");
	var mask_graphics_14 = new cjs.Graphics().p("A0sEfIAAo9MApZAAAIAAI9g");
	var mask_graphics_15 = new cjs.Graphics().p("AylE5IAApxMAlLAAAIAAJxg");
	var mask_graphics_16 = new cjs.Graphics().p("AwzFPIAAqdMAhnAAAIAAKdg");
	var mask_graphics_17 = new cjs.Graphics().p("AvYFhIAArBIexAAIAALBg");
	var mask_graphics_18 = new cjs.Graphics().p("AuSFvIAArdIclAAIAALdg");
	var mask_graphics_19 = new cjs.Graphics().p("AtcF5IAArxIa5AAIAALxg");
	var mask_graphics_20 = new cjs.Graphics().p("As0GBIAAsBIZpAAIAAMBg");
	var mask_graphics_21 = new cjs.Graphics().p("AsXGHIAAsNIYwAAIAAMNg");
	var mask_graphics_22 = new cjs.Graphics().p("AsEGLIAAsVIYJAAIAAMVg");
	var mask_graphics_23 = new cjs.Graphics().p("Ar3GNIAAsZIXvAAIAAMZg");
	var mask_graphics_24 = new cjs.Graphics().p("ArvGOIAAsbIXfAAIAAMbg");
	var mask_graphics_25 = new cjs.Graphics().p("ArrGPIAAseIXXAAIAAMeg");
	var mask_graphics_26 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_27 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_28 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_29 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_30 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_31 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_32 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_33 = new cjs.Graphics().p("ArrGPIAAseIXWAAIAAMeg");
	var mask_graphics_34 = new cjs.Graphics().p("AruGPIAAsdIXdAAIAAMdg");
	var mask_graphics_35 = new cjs.Graphics().p("Ar1GOIAAsaIXrAAIAAMag");
	var mask_graphics_36 = new cjs.Graphics().p("AsAGLIAAsVIYBAAIAAMVg");
	var mask_graphics_37 = new cjs.Graphics().p("AsRGIIAAsPIYjAAIAAMPg");
	var mask_graphics_38 = new cjs.Graphics().p("AsqGDIAAsFIZWAAIAAMFg");
	var mask_graphics_39 = new cjs.Graphics().p("AtNF8IAAr3IabAAIAAL3g");
	var mask_graphics_40 = new cjs.Graphics().p("At8FzIAArlIb5AAIAALlg");
	var mask_graphics_41 = new cjs.Graphics().p("Au6FnIAArNId1AAIAALNg");
	var mask_graphics_42 = new cjs.Graphics().p("AwJFYIAAqvMAgTAAAIAAKvg");
	var mask_graphics_43 = new cjs.Graphics().p("AxtFEIAAqHMAjbAAAIAAKHg");
	var mask_graphics_44 = new cjs.Graphics().p("AzpEsIAApXMAnTAAAIAAJXg");
	var mask_graphics_45 = new cjs.Graphics().p("A1kEUIAAonMArJAAAIAAIng");
	var mask_graphics_46 = new cjs.Graphics().p("A3IEAIAAn/MAuRAAAIAAH/g");
	var mask_graphics_47 = new cjs.Graphics().p("A4XDxIAAnhMAwvAAAIAAHhg");
	var mask_graphics_48 = new cjs.Graphics().p("A5VDlIAAnJMAyrAAAIAAHJg");
	var mask_graphics_49 = new cjs.Graphics().p("A6EDcIAAm3MA0JAAAIAAG3g");
	var mask_graphics_50 = new cjs.Graphics().p("A6nDVIAAmpMA1PAAAIAAGpg");
	var mask_graphics_51 = new cjs.Graphics().p("A7ADQIAAmfMA2AAAAIAAGfg");
	var mask_graphics_52 = new cjs.Graphics().p("A7RDNIAAmZMA2jAAAIAAGZg");
	var mask_graphics_53 = new cjs.Graphics().p("A7cDKIAAmUMA25AAAIAAGUg");
	var mask_graphics_54 = new cjs.Graphics().p("A7jDJIAAmRMA3HAAAIAAGRg");
	var mask_graphics_55 = new cjs.Graphics().p("A7mDIIAAmQMA3OAAAIAAGQg");
	var mask_graphics_56 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_57 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_58 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_59 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:186,y:29}).wait(1).to({graphics:mask_graphics_1,x:186,y:29}).wait(1).to({graphics:mask_graphics_2,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_3,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_4,x:185.6,y:29}).wait(1).to({graphics:mask_graphics_5,x:185.025,y:29}).wait(1).to({graphics:mask_graphics_6,x:183.95,y:29}).wait(1).to({graphics:mask_graphics_7,x:182.225,y:29.025}).wait(1).to({graphics:mask_graphics_8,x:179.55,y:29.025}).wait(1).to({graphics:mask_graphics_9,x:175.65,y:29.075}).wait(1).to({graphics:mask_graphics_10,x:170.225,y:29.125}).wait(1).to({graphics:mask_graphics_11,x:162.9,y:29.175}).wait(1).to({graphics:mask_graphics_12,x:153.275,y:29.25}).wait(1).to({graphics:mask_graphics_13,x:140.925,y:29.325}).wait(1).to({graphics:mask_graphics_14,x:125.375,y:29.425}).wait(1).to({graphics:mask_graphics_15,x:107.125,y:29.55}).wait(1).to({graphics:mask_graphics_16,x:91.575,y:29.675}).wait(1).to({graphics:mask_graphics_17,x:79.225,y:29.75}).wait(1).to({graphics:mask_graphics_18,x:69.625,y:29.825}).wait(1).to({graphics:mask_graphics_19,x:62.275,y:29.875}).wait(1).to({graphics:mask_graphics_20,x:56.85,y:29.925}).wait(1).to({graphics:mask_graphics_21,x:52.95,y:29.975}).wait(1).to({graphics:mask_graphics_22,x:50.275,y:29.975}).wait(1).to({graphics:mask_graphics_23,x:48.55,y:30}).wait(1).to({graphics:mask_graphics_24,x:47.475,y:30}).wait(1).to({graphics:mask_graphics_25,x:46.9,y:30}).wait(1).to({graphics:mask_graphics_26,x:46.65,y:30}).wait(1).to({graphics:mask_graphics_27,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_28,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_29,x:46.4757,y:30.0005}).wait(1).to({graphics:mask_graphics_30,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_31,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_32,x:46.625,y:30}).wait(1).to({graphics:mask_graphics_33,x:46.85,y:30}).wait(1).to({graphics:mask_graphics_34,x:47.375,y:29.975}).wait(1).to({graphics:mask_graphics_35,x:48.275,y:30}).wait(1).to({graphics:mask_graphics_36,x:49.825,y:29.975}).wait(1).to({graphics:mask_graphics_37,x:52.15,y:29.95}).wait(1).to({graphics:mask_graphics_38,x:55.55,y:29.95}).wait(1).to({graphics:mask_graphics_39,x:60.275,y:29.925}).wait(1).to({graphics:mask_graphics_40,x:66.675,y:29.85}).wait(1).to({graphics:mask_graphics_41,x:75.075,y:29.8}).wait(1).to({graphics:mask_graphics_42,x:85.85,y:29.725}).wait(1).to({graphics:mask_graphics_43,x:99.425,y:29.625}).wait(1).to({graphics:mask_graphics_44,x:116.25,y:29.5}).wait(1).to({graphics:mask_graphics_45,x:133.075,y:29.375}).wait(1).to({graphics:mask_graphics_46,x:146.65,y:29.275}).wait(1).to({graphics:mask_graphics_47,x:157.425,y:29.2}).wait(1).to({graphics:mask_graphics_48,x:165.825,y:29.15}).wait(1).to({graphics:mask_graphics_49,x:172.225,y:29.075}).wait(1).to({graphics:mask_graphics_50,x:176.95,y:29.05}).wait(1).to({graphics:mask_graphics_51,x:180.35,y:29.05}).wait(1).to({graphics:mask_graphics_52,x:182.675,y:29.025}).wait(1).to({graphics:mask_graphics_53,x:184.225,y:29}).wait(1).to({graphics:mask_graphics_54,x:185.125,y:29.025}).wait(1).to({graphics:mask_graphics_55,x:185.65,y:29}).wait(1).to({graphics:mask_graphics_56,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_57,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_58,x:186,y:29}).wait(1).to({graphics:mask_graphics_59,x:186,y:29}).wait(1));

	// Layer_1
	this.instance = new lib.img2_sub();
	this.instance.setTransform(7.3,-39.2,1,0.9999,0,0,0,0.1,-0.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0,regY:0,scaleX:0.4274,scaleY:0.4273,x:-33,y:-11.15},29,cjs.Ease.quartInOut).to({regX:0.1,regY:-0.1,scaleX:1,scaleY:0.9999,x:7.3,y:-39.2},30,cjs.Ease.quartInOut).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A9DEiIAApDMA6HAAAIAAJDg");
	this.shape.setTransform(186,29);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A9CEiIAApDMA6FAAAIAAJDg");
	this.shape_1.setTransform(185.85,29);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6BAAAIAAJEg");
	this.shape_2.setTransform(185.6,29);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A88EjIAApFMA55AAAIAAJFg");
	this.shape_3.setTransform(185,29);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A80EkIAApHMA5oAAAIAAJHg");
	this.shape_4.setTransform(183.95,29.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A8mEmIAApLMA5NAAAIAAJLg");
	this.shape_5.setTransform(182.2,29.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A8SEpIAApSMA4lAAAIAAJSg");
	this.shape_6.setTransform(179.525,29.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("A70EuIAApbMA3pAAAIAAJbg");
	this.shape_7.setTransform(175.65,29.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("A7LE0IAApnMA2XAAAIAAJng");
	this.shape_8.setTransform(170.225,29.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A6TE9IAAp5MA0nAAAIAAJ5g");
	this.shape_9.setTransform(162.9,29.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("A5JFIIAAqPMAyTAAAIAAKPg");
	this.shape_10.setTransform(153.275,29.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A3rFWIAAqrMAvXAAAIAAKrg");
	this.shape_11.setTransform(140.95,29.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("A10FoIAArOMArpAAAIAALOg");
	this.shape_12.setTransform(125.375,29.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AzpF8IAAr3MAnTAAAIAAL3g");
	this.shape_13.setTransform(107.125,29.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AxyGOIAAsbMAjlAAAIAAMbg");
	this.shape_14.setTransform(91.55,29.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AwUGdIAAs5MAgpAAAIAAM5g");
	this.shape_15.setTransform(79.225,29.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AvKGnIAAtOIeWAAIAANOg");
	this.shape_16.setTransform(69.6,29.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AuTGwIAAtfIcmAAIAANfg");
	this.shape_17.setTransform(62.3,29.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AtpG2IAAtrIbTAAIAANrg");
	this.shape_18.setTransform(56.85,29.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AtLG6IAAt0IaXAAIAAN0g");
	this.shape_19.setTransform(52.975,29.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("As3G+IAAt7IZvAAIAAN7g");
	this.shape_20.setTransform(50.3,29.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AspHAIAAt/IZTAAIAAN/g");
	this.shape_21.setTransform(48.55,29.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AsiHBIAAuBIZEAAIAAOBg");
	this.shape_22.setTransform(47.5,30);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AsdHCIAAuCIY7AAIAAOCg");
	this.shape_23.setTransform(46.9,30);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AsbHCIAAuDIY3AAIAAODg");
	this.shape_24.setTransform(46.65,30);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AsaHCIAAuDIY1AAIAAODg");
	this.shape_25.setTransform(46.525,30);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AsgHBIAAuBIZCAAIAAOBg");
	this.shape_26.setTransform(47.35,30);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AsoHAIAAt/IZRAAIAAN/g");
	this.shape_27.setTransform(48.275,30);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AszG+IAAt7IZnAAIAAN7g");
	this.shape_28.setTransform(49.825,29.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AtFG8IAAt3IaLAAIAAN3g");
	this.shape_29.setTransform(52.15,29.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AtfG4IAAtvIa/AAIAANvg");
	this.shape_30.setTransform(55.55,29.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AuDGyIAAtjIcHAAIAANjg");
	this.shape_31.setTransform(60.275,29.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Au0GrIAAtVIdpAAIAANVg");
	this.shape_32.setTransform(66.65,29.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Av0GhIAAtBIfpAAIAANBg");
	this.shape_33.setTransform(75.075,29.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AxGGVIAAspMAiNAAAIAAMpg");
	this.shape_34.setTransform(85.85,29.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AyuGFIAAsJMAldAAAIAAMJg");
	this.shape_35.setTransform(99.425,29.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("A0uFyIAArjMApeAAAIAALjg");
	this.shape_36.setTransform(116.25,29.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("A2vFfIAAq9MAtfAAAIAAK9g");
	this.shape_37.setTransform(133.075,29.375);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("A4WFPIAAqdMAwtAAAIAAKdg");
	this.shape_38.setTransform(146.65,29.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("A5pFDIAAqFMAzTAAAIAAKFg");
	this.shape_39.setTransform(157.425,29.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("A6pE5IAApxMA1TAAAIAAJxg");
	this.shape_40.setTransform(165.85,29.15);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("A7aEyIAApjMA21AAAIAAJjg");
	this.shape_41.setTransform(172.225,29.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("A7+EsIAApXMA39AAAIAAJXg");
	this.shape_42.setTransform(176.95,29.075);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("A8YEoIAApQMA4xAAAIAAJQg");
	this.shape_43.setTransform(180.35,29.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("A8qEmIAApLMA5VAAAIAAJLg");
	this.shape_44.setTransform(182.675,29.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("A81EkIAApHMA5rAAAIAAJHg");
	this.shape_45.setTransform(184.225,29);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("A88EjIAApFMA56AAAIAAJFg");
	this.shape_46.setTransform(185.15,29);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6CAAAIAAJEg");
	this.shape_47.setTransform(185.65,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:185.85}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23,p:{x:46.9}}]},1).to({state:[{t:this.shape_24,p:{x:46.65}}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_24,p:{x:46.625}}]},1).to({state:[{t:this.shape_23,p:{x:46.85}}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_1,p:{x:185.875}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({x:185.975},0).to({_off:true},1).wait(54).to({_off:false},0).wait(1).to({x:186},0).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(27).to({_off:false},0).wait(1).to({x:46.5},0).wait(3).to({x:46.525},0).to({_off:true},1).wait(28));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-33,-15,405,90);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
		this.alpha=0;
	}
	this.frame_30 = function() {
		this.alpha=1;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1).call(this.frame_30).wait(30));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_1 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_2 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_3 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_4 = new cjs.Graphics().p("A7mDIIAAmQMA3NAAAIAAGQg");
	var mask_graphics_5 = new cjs.Graphics().p("A7iDJIAAmSMA3FAAAIAAGSg");
	var mask_graphics_6 = new cjs.Graphics().p("A7aDLIAAmVMA21AAAIAAGVg");
	var mask_graphics_7 = new cjs.Graphics().p("A7NDNIAAmZMA2bAAAIAAGZg");
	var mask_graphics_8 = new cjs.Graphics().p("A66DRIAAmhMA11AAAIAAGhg");
	var mask_graphics_9 = new cjs.Graphics().p("A6dDXIAAmtMA07AAAIAAGtg");
	var mask_graphics_10 = new cjs.Graphics().p("A51DfIAAm9MAzrAAAIAAG9g");
	var mask_graphics_11 = new cjs.Graphics().p("A4/DpIAAnRMAx/AAAIAAHRg");
	var mask_graphics_12 = new cjs.Graphics().p("A35D3IAAntMAvzAAAIAAHtg");
	var mask_graphics_13 = new cjs.Graphics().p("A2eEJIAAoRMAs9AAAIAAIRg");
	var mask_graphics_14 = new cjs.Graphics().p("A0sEfIAAo9MApZAAAIAAI9g");
	var mask_graphics_15 = new cjs.Graphics().p("AylE5IAApxMAlLAAAIAAJxg");
	var mask_graphics_16 = new cjs.Graphics().p("AwzFPIAAqdMAhnAAAIAAKdg");
	var mask_graphics_17 = new cjs.Graphics().p("AvYFhIAArBIexAAIAALBg");
	var mask_graphics_18 = new cjs.Graphics().p("AuSFvIAArdIclAAIAALdg");
	var mask_graphics_19 = new cjs.Graphics().p("AtcF5IAArxIa5AAIAALxg");
	var mask_graphics_20 = new cjs.Graphics().p("As0GBIAAsBIZpAAIAAMBg");
	var mask_graphics_21 = new cjs.Graphics().p("AsXGHIAAsNIYwAAIAAMNg");
	var mask_graphics_22 = new cjs.Graphics().p("AsEGLIAAsVIYJAAIAAMVg");
	var mask_graphics_23 = new cjs.Graphics().p("Ar3GNIAAsZIXvAAIAAMZg");
	var mask_graphics_24 = new cjs.Graphics().p("ArvGOIAAsbIXfAAIAAMbg");
	var mask_graphics_25 = new cjs.Graphics().p("ArrGPIAAseIXXAAIAAMeg");
	var mask_graphics_26 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_27 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_28 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_29 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_30 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_31 = new cjs.Graphics().p("AroGQIAAsfIXRAAIAAMfg");
	var mask_graphics_32 = new cjs.Graphics().p("ArpGQIAAsfIXTAAIAAMfg");
	var mask_graphics_33 = new cjs.Graphics().p("ArrGPIAAseIXWAAIAAMeg");
	var mask_graphics_34 = new cjs.Graphics().p("AruGPIAAsdIXdAAIAAMdg");
	var mask_graphics_35 = new cjs.Graphics().p("Ar1GOIAAsaIXrAAIAAMag");
	var mask_graphics_36 = new cjs.Graphics().p("AsAGLIAAsVIYBAAIAAMVg");
	var mask_graphics_37 = new cjs.Graphics().p("AsRGIIAAsPIYjAAIAAMPg");
	var mask_graphics_38 = new cjs.Graphics().p("AsqGDIAAsFIZWAAIAAMFg");
	var mask_graphics_39 = new cjs.Graphics().p("AtNF8IAAr3IabAAIAAL3g");
	var mask_graphics_40 = new cjs.Graphics().p("At8FzIAArlIb5AAIAALlg");
	var mask_graphics_41 = new cjs.Graphics().p("Au6FnIAArNId1AAIAALNg");
	var mask_graphics_42 = new cjs.Graphics().p("AwJFYIAAqvMAgTAAAIAAKvg");
	var mask_graphics_43 = new cjs.Graphics().p("AxtFEIAAqHMAjbAAAIAAKHg");
	var mask_graphics_44 = new cjs.Graphics().p("AzpEsIAApXMAnTAAAIAAJXg");
	var mask_graphics_45 = new cjs.Graphics().p("A1kEUIAAonMArJAAAIAAIng");
	var mask_graphics_46 = new cjs.Graphics().p("A3IEAIAAn/MAuRAAAIAAH/g");
	var mask_graphics_47 = new cjs.Graphics().p("A4XDxIAAnhMAwvAAAIAAHhg");
	var mask_graphics_48 = new cjs.Graphics().p("A5VDlIAAnJMAyrAAAIAAHJg");
	var mask_graphics_49 = new cjs.Graphics().p("A6EDcIAAm3MA0JAAAIAAG3g");
	var mask_graphics_50 = new cjs.Graphics().p("A6nDVIAAmpMA1PAAAIAAGpg");
	var mask_graphics_51 = new cjs.Graphics().p("A7ADQIAAmfMA2AAAAIAAGfg");
	var mask_graphics_52 = new cjs.Graphics().p("A7RDNIAAmZMA2jAAAIAAGZg");
	var mask_graphics_53 = new cjs.Graphics().p("A7cDKIAAmUMA25AAAIAAGUg");
	var mask_graphics_54 = new cjs.Graphics().p("A7jDJIAAmRMA3HAAAIAAGRg");
	var mask_graphics_55 = new cjs.Graphics().p("A7mDIIAAmQMA3OAAAIAAGQg");
	var mask_graphics_56 = new cjs.Graphics().p("A7oDIIAAmPMA3RAAAIAAGPg");
	var mask_graphics_57 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_58 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");
	var mask_graphics_59 = new cjs.Graphics().p("A7pDIIAAmPMA3TAAAIAAGPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:186,y:29}).wait(1).to({graphics:mask_graphics_1,x:186,y:29}).wait(1).to({graphics:mask_graphics_2,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_3,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_4,x:185.6,y:29}).wait(1).to({graphics:mask_graphics_5,x:185.025,y:29}).wait(1).to({graphics:mask_graphics_6,x:183.95,y:29}).wait(1).to({graphics:mask_graphics_7,x:182.225,y:29.025}).wait(1).to({graphics:mask_graphics_8,x:179.55,y:29.025}).wait(1).to({graphics:mask_graphics_9,x:175.65,y:29.075}).wait(1).to({graphics:mask_graphics_10,x:170.225,y:29.125}).wait(1).to({graphics:mask_graphics_11,x:162.9,y:29.175}).wait(1).to({graphics:mask_graphics_12,x:153.275,y:29.25}).wait(1).to({graphics:mask_graphics_13,x:140.925,y:29.325}).wait(1).to({graphics:mask_graphics_14,x:125.375,y:29.425}).wait(1).to({graphics:mask_graphics_15,x:107.125,y:29.55}).wait(1).to({graphics:mask_graphics_16,x:91.575,y:29.675}).wait(1).to({graphics:mask_graphics_17,x:79.225,y:29.75}).wait(1).to({graphics:mask_graphics_18,x:69.625,y:29.825}).wait(1).to({graphics:mask_graphics_19,x:62.275,y:29.875}).wait(1).to({graphics:mask_graphics_20,x:56.85,y:29.925}).wait(1).to({graphics:mask_graphics_21,x:52.95,y:29.975}).wait(1).to({graphics:mask_graphics_22,x:50.275,y:29.975}).wait(1).to({graphics:mask_graphics_23,x:48.55,y:30}).wait(1).to({graphics:mask_graphics_24,x:47.475,y:30}).wait(1).to({graphics:mask_graphics_25,x:46.9,y:30}).wait(1).to({graphics:mask_graphics_26,x:46.65,y:30}).wait(1).to({graphics:mask_graphics_27,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_28,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_29,x:46.4757,y:30.0005}).wait(1).to({graphics:mask_graphics_30,x:46.5,y:30}).wait(1).to({graphics:mask_graphics_31,x:46.525,y:30}).wait(1).to({graphics:mask_graphics_32,x:46.625,y:30}).wait(1).to({graphics:mask_graphics_33,x:46.85,y:30}).wait(1).to({graphics:mask_graphics_34,x:47.375,y:29.975}).wait(1).to({graphics:mask_graphics_35,x:48.275,y:30}).wait(1).to({graphics:mask_graphics_36,x:49.825,y:29.975}).wait(1).to({graphics:mask_graphics_37,x:52.15,y:29.95}).wait(1).to({graphics:mask_graphics_38,x:55.55,y:29.95}).wait(1).to({graphics:mask_graphics_39,x:60.275,y:29.925}).wait(1).to({graphics:mask_graphics_40,x:66.675,y:29.85}).wait(1).to({graphics:mask_graphics_41,x:75.075,y:29.8}).wait(1).to({graphics:mask_graphics_42,x:85.85,y:29.725}).wait(1).to({graphics:mask_graphics_43,x:99.425,y:29.625}).wait(1).to({graphics:mask_graphics_44,x:116.25,y:29.5}).wait(1).to({graphics:mask_graphics_45,x:133.075,y:29.375}).wait(1).to({graphics:mask_graphics_46,x:146.65,y:29.275}).wait(1).to({graphics:mask_graphics_47,x:157.425,y:29.2}).wait(1).to({graphics:mask_graphics_48,x:165.825,y:29.15}).wait(1).to({graphics:mask_graphics_49,x:172.225,y:29.075}).wait(1).to({graphics:mask_graphics_50,x:176.95,y:29.05}).wait(1).to({graphics:mask_graphics_51,x:180.35,y:29.05}).wait(1).to({graphics:mask_graphics_52,x:182.675,y:29.025}).wait(1).to({graphics:mask_graphics_53,x:184.225,y:29}).wait(1).to({graphics:mask_graphics_54,x:185.125,y:29.025}).wait(1).to({graphics:mask_graphics_55,x:185.65,y:29}).wait(1).to({graphics:mask_graphics_56,x:185.875,y:29}).wait(1).to({graphics:mask_graphics_57,x:185.975,y:29}).wait(1).to({graphics:mask_graphics_58,x:186,y:29}).wait(1).to({graphics:mask_graphics_59,x:186,y:29}).wait(1));

	// Layer_1
	this.instance = new lib.img1_sub();
	this.instance.setTransform(-6.95,-38.6,1,0.9998,0,0,0,-0.1,-0.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0,regY:0,scaleX:0.4125,scaleY:0.4124,x:-33,y:-15.05},29,cjs.Ease.quartInOut).to({scaleX:1,scaleY:1,x:-6.9,y:-38.6},30,cjs.Ease.quartInOut).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A9DEiIAApDMA6HAAAIAAJDg");
	this.shape.setTransform(186,29);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A9CEiIAApDMA6FAAAIAAJDg");
	this.shape_1.setTransform(185.85,29);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6BAAAIAAJEg");
	this.shape_2.setTransform(185.6,29);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("A88EjIAApFMA55AAAIAAJFg");
	this.shape_3.setTransform(185,29);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("A80EkIAApHMA5oAAAIAAJHg");
	this.shape_4.setTransform(183.95,29.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("A8mEmIAApLMA5NAAAIAAJLg");
	this.shape_5.setTransform(182.2,29.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("A8SEpIAApSMA4lAAAIAAJSg");
	this.shape_6.setTransform(179.525,29.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("A70EuIAApbMA3pAAAIAAJbg");
	this.shape_7.setTransform(175.65,29.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("A7LE0IAApnMA2XAAAIAAJng");
	this.shape_8.setTransform(170.225,29.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A6TE9IAAp5MA0nAAAIAAJ5g");
	this.shape_9.setTransform(162.9,29.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("A5JFIIAAqPMAyTAAAIAAKPg");
	this.shape_10.setTransform(153.275,29.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A3rFWIAAqrMAvXAAAIAAKrg");
	this.shape_11.setTransform(140.95,29.325);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("A10FoIAArOMArpAAAIAALOg");
	this.shape_12.setTransform(125.375,29.45);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AzpF8IAAr3MAnTAAAIAAL3g");
	this.shape_13.setTransform(107.125,29.55);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AxyGOIAAsbMAjlAAAIAAMbg");
	this.shape_14.setTransform(91.55,29.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AwUGdIAAs5MAgpAAAIAAM5g");
	this.shape_15.setTransform(79.225,29.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AvKGnIAAtOIeWAAIAANOg");
	this.shape_16.setTransform(69.6,29.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AuTGwIAAtfIcmAAIAANfg");
	this.shape_17.setTransform(62.3,29.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AtpG2IAAtrIbTAAIAANrg");
	this.shape_18.setTransform(56.85,29.925);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AtLG6IAAt0IaXAAIAAN0g");
	this.shape_19.setTransform(52.975,29.95);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("As3G+IAAt7IZvAAIAAN7g");
	this.shape_20.setTransform(50.3,29.975);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AspHAIAAt/IZTAAIAAN/g");
	this.shape_21.setTransform(48.55,29.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AsiHBIAAuBIZEAAIAAOBg");
	this.shape_22.setTransform(47.5,30);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AsdHCIAAuCIY7AAIAAOCg");
	this.shape_23.setTransform(46.9,30);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AsbHCIAAuDIY3AAIAAODg");
	this.shape_24.setTransform(46.65,30);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AsaHCIAAuDIY1AAIAAODg");
	this.shape_25.setTransform(46.525,30);
	this.shape_25._off = true;

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AsgHBIAAuBIZCAAIAAOBg");
	this.shape_26.setTransform(47.35,30);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AsoHAIAAt/IZRAAIAAN/g");
	this.shape_27.setTransform(48.275,30);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AszG+IAAt7IZnAAIAAN7g");
	this.shape_28.setTransform(49.825,29.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AtFG8IAAt3IaLAAIAAN3g");
	this.shape_29.setTransform(52.15,29.95);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AtfG4IAAtvIa/AAIAANvg");
	this.shape_30.setTransform(55.55,29.925);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AuDGyIAAtjIcHAAIAANjg");
	this.shape_31.setTransform(60.275,29.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Au0GrIAAtVIdpAAIAANVg");
	this.shape_32.setTransform(66.65,29.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Av0GhIAAtBIfpAAIAANBg");
	this.shape_33.setTransform(75.075,29.775);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AxGGVIAAspMAiNAAAIAAMpg");
	this.shape_34.setTransform(85.85,29.725);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AyuGFIAAsJMAldAAAIAAMJg");
	this.shape_35.setTransform(99.425,29.625);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("A0uFyIAArjMApeAAAIAALjg");
	this.shape_36.setTransform(116.25,29.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("A2vFfIAAq9MAtfAAAIAAK9g");
	this.shape_37.setTransform(133.075,29.375);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("A4WFPIAAqdMAwtAAAIAAKdg");
	this.shape_38.setTransform(146.65,29.275);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("A5pFDIAAqFMAzTAAAIAAKFg");
	this.shape_39.setTransform(157.425,29.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("A6pE5IAApxMA1TAAAIAAJxg");
	this.shape_40.setTransform(165.85,29.15);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("A7aEyIAApjMA21AAAIAAJjg");
	this.shape_41.setTransform(172.225,29.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("A7+EsIAApXMA39AAAIAAJXg");
	this.shape_42.setTransform(176.95,29.075);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("A8YEoIAApQMA4xAAAIAAJQg");
	this.shape_43.setTransform(180.35,29.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("A8qEmIAApLMA5VAAAIAAJLg");
	this.shape_44.setTransform(182.675,29.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("A81EkIAApHMA5rAAAIAAJHg");
	this.shape_45.setTransform(184.225,29);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("A88EjIAApFMA56AAAIAAJFg");
	this.shape_46.setTransform(185.15,29);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("A9AEiIAApEMA6CAAAIAAJEg");
	this.shape_47.setTransform(185.65,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:185.85}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23,p:{x:46.9}}]},1).to({state:[{t:this.shape_24,p:{x:46.65}}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_24,p:{x:46.625}}]},1).to({state:[{t:this.shape_23,p:{x:46.85}}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_1,p:{x:185.875}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({x:185.975},0).to({_off:true},1).wait(54).to({_off:false},0).wait(1).to({x:186},0).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(27).to({_off:false},0).wait(1).to({x:46.5},0).wait(3).to({x:46.525},0).to({_off:true},1).wait(28));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-444.1,-15,816.1,818.5);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_84 = function() {
		exportRoot.tlAnim.play();
	}
	this.frame_99 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(15).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhLAKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg4AKbIAAwnMBbuAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("Af+KbIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AefKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcaKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZuKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWcKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATLKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQfKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOaKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("AM7KbIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMBKbIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("ALuKbIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.3539,y:66.7095}).wait(1).to({graphics:mask_graphics_15,x:797.448,y:66.7095}).wait(1).to({graphics:mask_graphics_16,x:791.7303,y:66.7095}).wait(1).to({graphics:mask_graphics_17,x:782.2008,y:66.7095}).wait(1).to({graphics:mask_graphics_18,x:768.8595,y:66.7095}).wait(1).to({graphics:mask_graphics_19,x:751.7063,y:66.7095}).wait(1).to({graphics:mask_graphics_20,x:730.7414,y:66.7095}).wait(1).to({graphics:mask_graphics_21,x:709.7765,y:66.7095}).wait(1).to({graphics:mask_graphics_22,x:692.6233,y:66.7095}).wait(1).to({graphics:mask_graphics_23,x:679.282,y:66.7095}).wait(1).to({graphics:mask_graphics_24,x:669.7525,y:66.7095}).wait(1).to({graphics:mask_graphics_25,x:664.0348,y:66.7095}).wait(1).to({graphics:mask_graphics_26,x:662.1289,y:66.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// logo text
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(527.65,74.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:882.05},12,cjs.Ease.quadInOut).wait(39).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// widows icon
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(988.7,80.95,0.1152,0.1152,0,0,0,-39.9,1.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:988.4,y:80.35},14,cjs.Ease.quadInOut).to({x:684.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei5lAXjMAAAgvFMFzLAAAMAAAAvFg");
	this.shape.setTransform(995.825,77.775);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(996,77.6,2.4272,0.3639,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-192,-73.1,2375.6,301.6);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.slides = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.slide4 = new lib.img4();
	this.slide4.name = "slide4";
	this.slide4.setTransform(0,195);

	this.slide3 = new lib.img3();
	this.slide3.name = "slide3";
	this.slide3.setTransform(0,130);

	this.slide2 = new lib.img2();
	this.slide2.name = "slide2";
	this.slide2.setTransform(0,65);

	this.slide1 = new lib.img1();
	this.slide1.name = "slide1";

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.slide1},{t:this.slide2},{t:this.slide3},{t:this.slide4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slides, new cjs.Rectangle(-6.8,-38.5,386,365.4), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-26.65,2.6,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnnB5IAAjyIPPAAIAADyg");
	this.shape.setTransform(-54.4314,2.2886,0.9397,1.0297);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-100.3,-10.2,91.8,25), null);


(lib.superslide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub_slides = new lib.slides();
	this.sub_slides.name = "sub_slides";
	this.sub_slides.setTransform(194,15);

	this.timeline.addTween(cjs.Tween.get(this.sub_slides).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.superslide, new cjs.Rectangle(187.2,-23.5,386.00000000000006,365.4), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// click tag
	this.click_tag = new lib.clicktagbutton();
	this.click_tag.name = "click_tag";
	this.click_tag.setTransform(150.2,125,1,1,0,0,0,150.2,125);
	new cjs.ButtonHelper(this.click_tag, 0, 1, 2, false, new lib.clicktagbutton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.click_tag).wait(1));

	// intro logo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// logo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(65.85,24.45,0.5764,0.5764,0,0,0,86.5,14.7);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// sound icon
	this.mute_btn_wht = new lib.mute_btn_wht();
	this.mute_btn_wht.name = "mute_btn_wht";
	this.mute_btn_wht.setTransform(25.55,71.05,0.7758,0.7758,0,0,180,-18.6,16.6);

	this.mute_btn_blk = new lib.mute_btn();
	this.mute_btn_blk.name = "mute_btn_blk";
	this.mute_btn_blk.setTransform(25.55,71.05,0.7758,0.7758,0,0,180,-18.6,16.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF3366").s().p("AhaCdIAAk5IC1AAIAAE5g");
	this.shape.setTransform(-9.025,73.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.mute_btn_blk},{t:this.mute_btn_wht}]}).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(637.05,59.85,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(739.4,57.4,1.136,1.136,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// nav
	this.nav = new lib.nav("synched",0);
	this.nav.name = "nav";
	this.nav.setTransform(601.85,45.4,0.7517,0.7517,0,0,0,4.5,48);

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1));

	// loading bar
	this.loading_bar = new lib.loadingbar();
	this.loading_bar.name = "loading_bar";
	this.loading_bar.setTransform(182.85,219.95,1,1,0,0,0,65,4.7);

	this.timeline.addTween(cjs.Tween.get(this.loading_bar).wait(1));

	// Video
	this.aVid = new lib.video();
	this.aVid.name = "aVid";

	this.timeline.addTween(cjs.Tween.get(this.aVid).wait(1));

	// images
	this.slides = new lib.superslide();
	this.slides.name = "slides";

	this.timeline.addTween(cjs.Tween.get(this.slides).wait(1));

	// BG
	this.bg = new lib.BG();
	this.bg.name = "bg";

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-18.1,-233.9,750.1,575.8), null);


// stage content:
(lib.M365_FY22Q2SMB_USA_728x90_BAN_INTCarouselCS_EN_NA_Standard_ANI_WACM_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		frame0();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9968,0.9997,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(346,21.5,383.70000000000005,320.2);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/CliftonCoffee_728x90.jpg?1636723548585", id:"CliftonCoffee_728x90"},
		{src:"images/HouseOfLilac_728x90.jpg?1636723548585", id:"HouseOfLilac_728x90"},
		{src:"images/ThinkUp_728x90.jpg?1636723548585", id:"ThinkUp_728x90"},
		{src:"images/TonysChoco_728x90.jpg?1636723548585", id:"TonysChoco_728x90"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;