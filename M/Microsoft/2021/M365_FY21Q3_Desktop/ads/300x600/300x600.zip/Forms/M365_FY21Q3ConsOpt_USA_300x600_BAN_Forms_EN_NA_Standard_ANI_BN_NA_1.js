(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q3ConsOpt_USA_300x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_1_atlas_1", frames: [[0,0,833,536],[835,0,450,648]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.screen = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.survey = function() {
	this.initialize(ss["M365_FY21Q3ConsOpt_USA_300x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(491.0046,408.3802);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,982,816.8);


(lib.screen_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.screen();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,833,536);


(lib.resultcomponent = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgQAVQgHgIABgNQAAgMAGgIQAIgHAJAAQALAAAGAGQAFAHABAMIAAAEIglAAQAAAJAEAFQAFAFAHAAQAJAAAIgGIAAAIQgHAFgMAAQgLAAgGgHgAgIgQQgFAFAAAHIAcAAQgBgIgDgEQgDgEgHAAQgFAAgEAEg");
	this.shape.setTransform(172.5,399.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgNAbIAAg1IAJAAIAAALQACgFACgDQAEgDAEgBIAGABIAAAJQgDgBgEAAQgFAAgDAFQgDAFAAAIIAAAbg");
	this.shape_1.setTransform(168.3,399.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPAYQgFgFgBgHQAAgOASgCIAPgCQABgOgLAAQgJAAgIAGIAAgIQAIgFAJAAQATAAAAAUIAAAiIgJAAIAAgJQgFAKgKAAQgIAAgEgEgAAAABQgGABgCACQgEACAAAGQAAAEAEACQACADAFAAQAFAAAFgFQADgEAAgHIAAgFg");
	this.shape_2.setTransform(163.1,399.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAOAoIAAgfQAAgQgNAAQgFAAgFAFQgEAEAAAHIAAAfIgIAAIAAhPIAIAAIAAAjQAHgKAKAAQASAAAAAVIAAAhg");
	this.shape_3.setTransform(157.525,397.95);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgHAnIgGgBIgFgBIgEgCIAAgLIAEADIAGACIAFACIAFAAQAIAAAEgDQAEgDAAgGQAAgDgCgCIgDgEIgGgEIgGgDIgHgDIgGgFIgEgGQgCgDAAgEQAAgFADgEQACgEADgCQAEgDAFgBIAIgBQAMAAAFADIAAAKQgHgFgKAAIgFABIgFABIgEAEIgBAFIABAFIADAEIAFAEIAGADIAIADIAGAFQADADABADQACADAAAFQAAAFgCAEQgCAEgEACQgEADgFABIgJABIgEAAg");
	this.shape_4.setTransform(151.625,398.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#3F7579").s().p("Am3CQIAAkfINvAAIAAEfg");
	this.shape_5.setTransform(162.0252,398.4811);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAFAUQgCgDAAgFQAAgGADgDQADgDAFAAQAEAAADADQADADgBAFQAAAGgCADQgDADgFAAQgFAAgDgDgAAJAGQgCACAAAEQAAADABACQADACADAAQAAAAABAAQAAAAABAAQAAgBABAAQABAAAAgBQACgCAAgEQAAgEgCgCQAAAAgBgBQAAAAgBAAQAAAAgBgBQgBAAAAAAQgDAAgCADgAgPAXIAbgsIAEAAIgbAsgAgUgCQgDgDABgFQAAgGACgDQADgDAFAAQAFAAADADQACADAAAFQAAAGgDADQgDACgFAAQgEAAgDgCgAgQgQQgDACAAAEQAAADADADQAAAAAAABQABAAAAAAQABAAABABQAAAAABAAQACAAADgDQABgCAAgEQAAgDgBgCQgBgBAAAAQgBAAAAgBQgBAAgBAAQAAAAgBAAQgBAAAAAAQgBAAgBAAQAAABgBAAQAAAAAAABg");
	this.shape_6.setTransform(151.2,252.725);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgUAiIAAgJQAHAGAKAAIAGgBIAFgDIAEgEIABgGQAAgPgUAAIgGAAIAAgGIAGAAQARAAAAgOQAAgNgNAAQgIAAgHAGIAAgJQAHgEAKAAIAIABIAHAEQACACABAEQACADAAAEQAAAPgPAEIAHABIAFAEIAFAFIABAHQAAAFgCAEQgCAEgDADQgEADgFACQgFACgEAAQgMAAgFgFg");
	this.shape_7.setTransform(145.6,251.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUAjIAAgJQAIAFAHAAIAHgBIAGgEQACgCABgDQABgDAAgEQAAgHgEgEQgGgDgIAAIgDAAIgDAAIgEAAIgCAAIACglIAiAAIAAAIIgaAAIgCAWIADgBIAEAAQAFAAAFACQAEABAEADQACACACAFQACAEAAAFQAAAFgCAFQgCAEgDADQgDAEgFABQgGACgFAAQgKAAgFgDg");
	this.shape_8.setTransform(140,251.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAGAUQgDgDAAgFQAAgGADgDQADgDAEAAQAGAAACADQADADAAAFQgBAGgDADQgDADgEAAQgEAAgDgDgAAJAGQgCACAAAEQAAADACACQABACADAAQABAAABAAQAAAAABAAQAAgBABAAQAAAAABgBQACgCgBgEQABgEgCgCQAAAAgBgBQAAAAgBAAQAAAAgBgBQgBAAgBAAQgCAAgCADgAgQAXIAcgsIAFAAIgcAsgAgUgCQgDgDAAgFQAAgGAEgDQACgDAFAAQAFAAACADQADADAAAFQAAAGgDADQgCACgGAAQgEAAgDgCgAgRgQQgBACAAAEQAAADABADQABAAAAABQABAAAAAAQABAAABABQAAAAABAAQACAAACgDQACgCAAgEQAAgDgCgCQAAgBAAAAQgBAAAAgBQgBAAgBAAQAAAAgBAAQgBAAAAAAQgBAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape_9.setTransform(188.5,251.825);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgLAlIADgNIAEgOIAEgLIAGgMIAEgKIAEgFIglAAIAAgIIAvAAIAAAEIgEAIIgFAKIgGAMIgFAMIgEAOIgCANg");
	this.shape_10.setTransform(182.975,250.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAJAlIAAgRIgjAAIAAgIIAKgMIAKgLIAHgNIAHgMIAJAAIAAAwIAKAAIAAAIIgKAAIAAARgAABgLIgFAKIgGAHIgGAGIAZAAIAAgkIgIANg");
	this.shape_11.setTransform(177.075,250.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#5E5584").s().p("AABEvQiihJgpjNQgCgZAAgbQAShwBDhOQBvh+DVAKIgyFKIAAFRIgSABQhBAAhHggg");
	this.shape_12.setTransform(146.8821,251.395,1.058,1.058);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#3F7579").s().p("AivgEIAylKQDTAsBBCeQAhBOgKBFQgGC7isBWQhWAqhVAFg");
	this.shape_13.setTransform(185.0934,251.5115,1.058,1.058);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#5E5584").s().p("AgZAfQgJgLAAgTQAAgTAKgLQALgMAPAAQAPAAAJAKQAJAKAAASIAAAGIg3AAQgBANAIAIQAGAHAMAAQANAAALgJIAAAMQgKAIgSAAQgPAAgLgLgAgMgXQgHAGgBALIAqAAQgBgMgFgGQgFgGgKAAQgHAAgGAHg");
	this.shape_14.setTransform(42.45,305.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#5E5584").s().p("AgGAoIgehPIANAAIAVA5QACAHAAAFIACgLIAWg6IAOAAIghBPg");
	this.shape_15.setTransform(34.5,305.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#5E5584").s().p("AgGA7IAAhPIAMAAIAABPgAgFgrQgCgDAAgDQAAgEACgCQACgCADAAQADAAADACQACACAAAEQAAADgCACQgDADgDAAQgDAAgCgCg");
	this.shape_16.setTransform(28.775,303.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5E5584").s().p("AgJAeIAAgvIgNAAIAAgLIANAAIAAgTIAMgFIAAAYIAUAAIAAALIgUAAIAAAsQAAAIADAEQADADAGAAQAFAAADgCIAAAKQgEADgIAAQgUAAAAgXg");
	this.shape_17.setTransform(24.025,304.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#5E5584").s().p("AgSAfQgLgLAAgSQAAgTAMgMQAKgMASAAQALAAAIAEIAAANQgJgGgKAAQgLAAgIAIQgIAKAAANQAAAOAIAIQAHAIAMAAQAKAAAJgHIAAANQgJAFgNAAQgQAAgKgLg");
	this.shape_18.setTransform(17.75,305.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#5E5584").s().p("AAjA4IgLgfIgvAAIgLAfIgPAAIArhvIANAAIArBvgAgBgiIgSAvIAmAAIgSgvIgBgIIAAAAIgBAIg");
	this.shape_19.setTransform(8.8,304.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_20.setTransform(36.325,321.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#131313").s().p("AgUAFIAAgeIAHAAIAAAcQAAARANAAQAFAAAFgFQADgFAAgGIAAgdIAIAAIAAAyIgIAAIAAgIIAAAAQgFAKgKgBQgSABAAgWg");
	this.shape_21.setTransform(31,321.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_22.setTransform(26.275,320.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#131313").s().p("AgPAXQgFgEAAgHQAAgNASgDIAOgCQAAgNgLAAQgIAAgIAGIAAgIQAIgFAJAAQATAAAAATIAAAhIgJAAIAAgIQgFAJgKAAQgIAAgEgEgAAAACQgFAAgDACQgDADAAAFQAAAEADACQACACAFAAQAFAAAEgEQAEgEAAgHIAAgFg");
	this.shape_23.setTransform(21.775,321.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_24.setTransform(17.425,320.525);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#131313").s().p("AgHAmIgFgBIgFgBIgEgCIAAgKIAEACIAFADIAGABIAFAAQAGAAAEgDQAEgDAAgFQAAgDgBgCIgEgEIgFgEIgGgDIgHgDIgGgFIgEgFIgBgHQAAgFACgEQACgDAEgDQAEgCAEgBIAIgCQALAAAFADIAAAKQgGgFgKAAIgFABIgFACIgEADQgBACAAADIABAFIADAEIAFADIAGADIAHAEIAGAEQADADACADQABADAAAEQAAAGgCADQgCAEgEADIgIADIgJABIgEAAg");
	this.shape_25.setTransform(13.325,320.175);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#5E5584").s().p("AgfA1IAAgPQAMAIAMAAQAGAAAEgCQAEgCAEgDQAEgDABgFQACgEAAgGQAAgKgHgHQgIgFgNAAIgEAAIgGABIgEAAIgFAAIAFg4IAyAAIAAAMIgoAAIgCAgIAFAAIAGAAQAIAAAHADQAHACAFAEQAEADADAHQADAGgBAIQAAAIgCAHQgDAGgFAFQgGAFgHADQgIACgHAAQgQAAgIgEg");
	this.shape_26.setTransform(50.05,237);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#5E5584").s().p("AgPA3QgGgFgFgGQgEgIgDgKQgDgLABgNQgBgOADgLQADgLAFgIQAEgIAHgDQAHgEAIAAQAkAAAAA5QgBAOgCAKQgCALgFAIQgFAHgHAEQgHAEgIAAQgIAAgHgDgAgWACQAAAtAXAAQAXAAgBguQAAgvgWAAQgXAAAAAwg");
	this.shape_27.setTransform(41.25,236.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#5E5584").s().p("AgFAnQgDgCAAgEQAAgDADgDQACgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgCgDgAgFgaQgDgCAAgEQAAgEADgCQACgDADAAQADAAADADQADACAAAEQAAAEgDACQgDADgDAAQgDAAgCgDg");
	this.shape_28.setTransform(35.225,238.475);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#5E5584").s().p("AAHA5IAAhgIgFAEIgFAEIgIADIgHADIAAgNIAJgDIAJgFIAHgFIAIgFIAEAAIAABxg");
	this.shape_29.setTransform(28.575,236.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#5E5584").s().p("AgPA3QgGgFgFgGQgFgIgCgKQgCgLgBgNQABgOACgLQACgLAFgIQAFgIAIgDQAHgEAHAAQAjAAAAA5QAAAOgCAKQgDALgEAIQgFAHgHAEQgHAEgIAAQgJAAgGgDgAgWACQAAAtAWAAQAYAAAAguQAAgvgXAAQgXAAAAAwg");
	this.shape_30.setTransform(20.5,236.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#5E5584").s().p("AgFAnQgDgCAAgEQAAgDADgDQACgDADAAQADAAADADQADADAAADQAAAEgDACQgDADgDAAQgDAAgCgDgAgFgaQgDgCAAgEQAAgEADgCQACgDADAAQADAAADADQADACAAAEQAAAEgDACQgDADgDAAQgDAAgCgDg");
	this.shape_31.setTransform(14.475,238.475);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#5E5584").s().p("AgPA3QgGgFgFgGQgEgIgDgKQgDgLABgNQgBgOADgLQADgLAFgIQAEgIAHgDQAHgEAJAAQAjAAAAA5QgBAOgCAKQgCALgFAIQgFAHgHAEQgHAEgIAAQgIAAgHgDgAgWACQAAAtAXAAQAXAAgBguQAAgvgWAAQgXAAAAAwg");
	this.shape_32.setTransform(8.4,236.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#5E5584").s().p("AgPA3QgGgFgFgGQgEgIgDgKQgCgLAAgNQAAgOACgLQADgLAFgIQAEgIAHgDQAIgEAIAAQAiAAABA5QgBAOgCAKQgCALgFAIQgFAHgHAEQgHAEgIAAQgJAAgGgDgAgWACQAAAtAXAAQAWAAAAguQAAgvgWAAQgXAAAAAwg");
	this.shape_33.setTransform(-0.25,236.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_34.setTransform(49.175,266.375);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_35.setTransform(44.675,265.675);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_36.setTransform(40.225,266.375);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#131313").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_37.setTransform(36.175,265.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#131313").s().p("AgXAnIAAhLIAJAAIAAAJQAFgLAMAAQAJAAAHAHQAFAHAAAMQAAAMgGAIQgHAIgLAAQgJAAgFgJIAAAggAgKgaQgEAFAAAIIAAAHQAAAGADAEQAFAFAGAAQAHAAAEgGQAFgFgBgKQAAgJgDgFQgEgFgHAAQgHAAgEAFg");
	this.shape_38.setTransform(32.05,267.525);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#131313").s().p("AAcAbIAAgdQABgJgDgEQgCgEgHAAQgFAAgEAFQgEAFAAAHIAAAdIgHAAIAAgeQAAgQgMAAQgGAAgDAFQgDAFAAAHIAAAdIgJAAIAAgzIAJAAIAAAIQAFgKALAAQAFAAAEADQADADABAFQAHgLALAAQARAAAAAWIAAAfg");
	this.shape_39.setTransform(24.35,266.325);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#131313").s().p("AgSAUQgHgHAAgMQAAgMAHgIQAIgHALAAQALAAAHAHQAHAHAAAMQAAAMgHAIQgIAHgLAAQgLAAgHgHgAgMgOQgEAGAAAIQAAAKAEAFQAFAFAHAAQAIAAAFgFQAEgFAAgKQAAgJgEgFQgFgFgIAAQgHAAgFAFg");
	this.shape_40.setTransform(16.775,266.375);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#131313").s().p("AgLAUQgIgHABgMQAAgMAHgHQAHgIAMAAQAGAAAFACIAAAJQgFgEgHAAQgHAAgFAGQgFAFAAAJQAAAJAFAFQAEAFAIAAQAGAAAGgEIAAAIQgGADgHAAQgLAAgGgHg");
	this.shape_41.setTransform(11.3,266.375);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#131313").s().p("AgSAUQgHgHAAgMQAAgMAHgIQAIgHALAAQALAAAHAHQAHAHAAAMQAAAMgHAIQgIAHgLAAQgLAAgHgHgAgMgOQgEAGAAAIQAAAKAEAFQAFAFAHAAQAIAAAFgFQAEgFAAgKQAAgJgEgFQgFgFgIAAQgHAAgFAFg");
	this.shape_42.setTransform(2.925,266.375);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_43.setTransform(-1.875,265.675);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_44.setTransform(51.875,254.575);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#131313").s().p("AAdAbIAAgdQgBgJgCgEQgDgEgGAAQgFAAgEAFQgEAFAAAHIAAAdIgHAAIAAgeQAAgQgMAAQgFAAgEAFQgEAFAAAHIAAAdIgIAAIAAgzIAIAAIAAAIQAGgKAKAAQAGAAAEADQADADACAFQAFgLAMAAQARAAAAAWIAAAfg");
	this.shape_45.setTransform(44.65,254.525);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#131313").s().p("AgDAmIAAgzIAHAAIAAAzgAgDgcQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAgBIABgEQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAAAQgBABAAAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBg");
	this.shape_46.setTransform(38.85,253.375);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#131313").s().p("AgFATIAAgeIgJAAIAAgHIAJAAIAAgNIAHgCIAAAPIANAAIAAAHIgNAAIAAAdQAAAFACACQACACAEAAQADAAACgBIAAAHQgDABgEAAQgNAAAAgPg");
	this.shape_47.setTransform(35.725,253.875);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_48.setTransform(28.475,254.575);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#131313").s().p("AgTAjIAAgIQAIAFAJAAQASAAAAgVIAAgFQgGAKgLAAQgKgBgGgGQgGgHAAgLQAAgNAGgIQAHgIAKAAQAKAAAGAJIAAgIIAIAAIAAAvQAAAdgaAAQgKAAgHgEgAgKgZQgEAFgBAKQAAAJAFAFQAEAEAGAAQAHAAAEgEQAFgFAAgHIAAgIQAAgGgFgFQgEgEgGAAQgHAAgEAGg");
	this.shape_49.setTransform(22.45,255.75);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#131313").s().p("AgPAXQgFgEAAgHQAAgNASgDIAOgCQAAgNgLAAQgIAAgIAGIAAgIQAIgFAJAAQATAAAAATIAAAhIgJAAIAAgIQgFAJgKAAQgIAAgEgEgAAAACQgFAAgDACQgDADAAAFQAAAEADACQACACAFAAQAFAAAEgEQAEgEAAgHIAAgFg");
	this.shape_50.setTransform(16.775,254.575);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#131313").s().p("AgNAbIAAg0IAJAAIAAALQACgGADgDQADgCAFAAIAEAAIAAAJQgCgCgDAAQgGAAgCAFQgEAFAAAIIAAAbg");
	this.shape_51.setTransform(12.8,254.55);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_52.setTransform(7.925,254.575);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#131313").s().p("AgEAaIgTgzIAJAAIANAlIABAHIACgHIANglIAJAAIgUAzg");
	this.shape_53.setTransform(2.7,254.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#131313").s().p("AAXAlIgHgVIgfAAIgHAVIgJAAIAchIIAIAAIAcBIgAgBgWIgKAfIAYAAIgMgfIgBgFIgBAFg");
	this.shape_54.setTransform(-3,253.55);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#5E5584").s().p("AgfA0IAAgOQALAJAPAAQAFAAAEgBQAFgCAEgDQACgCACgEQACgFAAgEQABgXgfAAIgJAAIAAgKIAJAAQAbABAAgVQAAgTgVAAQgMAAgKAIIAAgNQAKgGAPAAQAGAAAGACQAGACAEADQAEAEACAFQACAFAAAFQAAAXgWAGIAAABQAGAAAEACQAFACAEADQAEADACAFQACAEAAAHQAAAHgDAGQgDAGgFAEQgGAFgHACQgHADgIAAQgQAAgJgGg");
	this.shape_55.setTransform(29.05,175.45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#5E5584").s().p("AgfA1IAAgPQALAIAMAAQAHAAADgCQAFgCAEgDQAEgDACgEQABgFAAgGQAAgKgHgGQgIgGgMAAIgGAAIgEABIgFAAIgEAAIADg4IAzAAIAAALIgoAAIgCAiIAGgBIAEAAQAIAAAIADQAHACAEAEQAFADADAHQACAGAAAIQAAAIgDAGQgCAHgGAFQgFAFgHACQgHADgJAAQgPAAgIgEg");
	this.shape_56.setTransform(20.65,175.55);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_57.setTransform(48.275,193.075);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_58.setTransform(43.325,193.075);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_59.setTransform(38.375,193.075);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#131313").s().p("AANAbIAAgdQAAgRgMAAQgFAAgEAFQgEAFAAAHIAAAdIgJAAIAAgzIAJAAIAAAIQAGgKAKAAQAIAAAFAGQAFAFAAALIAAAfg");
	this.shape_60.setTransform(33.225,193.025);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#131313").s().p("AgSAUQgHgHAAgMQAAgMAHgIQAIgHALAAQALAAAHAHQAHAHAAAMQAAAMgHAIQgIAHgLAAQgLAAgHgHgAgMgOQgEAGAAAIQAAAKAEAFQAFAFAHAAQAIAAAFgFQAEgFAAgKQAAgJgEgFQgFgFgIAAQgHAAgFAFg");
	this.shape_61.setTransform(27.125,193.075);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#131313").s().p("AgXAnIAAhLIAIAAIAAAJQAGgLALAAQALAAAFAHQAGAHAAAMQAAAMgHAIQgGAIgLAAQgJAAgGgJIAAAggAgKgaQgFAFAAAIIAAAHQAAAGAFAEQAEAFAGAAQAHAAAEgGQAEgFABgKQAAgJgFgFQgDgFgIAAQgGAAgEAFg");
	this.shape_62.setTransform(21.2,194.225);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#131313").s().p("AgQAYIAAgJQAGAFAJAAQAKAAAAgHIgBgDIgDgDIgEgCIgDgCIgGgDIgFgCIgCgEIgBgFQAAgEABgDIAFgEIAGgDIAHgBQAGAAAGACIAAAJQgGgEgHAAIgEAAIgDACIgCACIgBADIABAEIACACIAEACIADACIAGACIAFADIADAEIABAFQAAAEgCADIgEAFQgDACgEABIgGAAQgJAAgFgDg");
	this.shape_63.setTransform(15.775,193.075);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#131313").s().p("AgQAUQgGgHAAgNQAAgLAHgHQAHgIAJAAQAKAAAGAGQAGAHAAAMIAAADIgkAAQAAAJAFAFQAEAEAHAAQAJAAAHgFIAAAHQgHAFgLAAQgKAAgHgHgAgIgPQgEAEgBAHIAbAAQAAgHgDgEQgEgEgGAAQgFAAgEAEg");
	this.shape_64.setTransform(10.825,193.075);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#131313").s().p("AAQAkIgMgUIgDgFIgDgDIgDgCIgFgBIgHAAIAAAfIgIAAIAAhIIAWAAIAIABIAHAEQADADABAEQACADAAAFIgBAHIgDAGIgGADIgGADIADACIACACIADAEIADADIANAWgAgRgCIAMAAIAFgBIAFgCIADgFIABgFQAAgHgEgCQgEgEgGAAIgMAAg");
	this.shape_65.setTransform(5.675,192.05);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#F4F4F4").s().p("ArgN5IAA7xIXBAAIAAbxg");
	this.shape_66.setTransform(23.7027,249.8288);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AANAbIgLgmIgBgEIgBAEIgMAmIgJAAIgQg1IAJAAIAMAoIAAAEIABAAIABgEIAMgoIAHAAIALAoIABAEIABAAIAAgEIALgoIAJAAIgRA1g");
	this.shape_67.setTransform(44.2,399.5);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgQAVQgHgIABgNQAAgMAGgIQAIgHAJAAQALAAAGAGQAFAHABAMIAAAEIglAAQAAAJAEAFQAFAFAHAAQAJAAAIgGIAAAIQgHAFgMAAQgLAAgGgHgAgIgQQgFAFAAAHIAcAAQgBgIgDgEQgDgEgHAAQgFAAgEAEg");
	this.shape_68.setTransform(37.5,399.525);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgDAoIAAg1IAHAAIAAA1gAgDgdQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEIADgCQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_69.setTransform(33.375,398.25);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgEAmIgbhLIAKAAIAUA7IABAHIACgHIAVg7IAKAAIgcBLg");
	this.shape_70.setTransform(28.7,398.425);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgDAoIAAhPIAHAAIAABPg");
	this.shape_71.setTransform(21.075,398.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgPAYQgFgFgBgHQAAgOASgCIAPgCQABgOgLAAQgJAAgIAGIAAgIQAIgFAKAAQASAAAAAUIAAAiIgJAAIAAgJQgFAKgKAAQgIAAgEgEgAAAABQgGABgCACQgEACAAAGQAAAEAEACQACADAFAAQAFAAAFgFQADgEAAgHIAAgFg");
	this.shape_72.setTransform(16.85,399.525);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgVAFIAAggIAIAAIAAAeQAAARANAAQAGAAADgEQAFgFAAgIIAAgeIAJAAIAAA1IgJAAIAAgIIAAAAQgGAKgKAAQgUAAABgXg");
	this.shape_73.setTransform(11.15,399.575);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgSAhQgGgHAAgMQAAgOAHgHQAGgIALAAQALAAAFAJIAAgiIAJAAIAABPIgJAAIAAgJQgGALgLAAQgLAAgGgIgAgKgCQgFAFAAAKQAAAJAFAGQAEAFAGAAQAHAAAEgFQAFgFAAgIIAAgIQAAgHgEgDQgFgFgGAAQgHAAgEAGg");
	this.shape_74.setTransform(4.8,398.275);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgDAoIAAg1IAHAAIAAA1gAgDgdQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEIADgCQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_75.setTransform(0.525,398.25);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgEAbIgUg1IAJAAIAOAmIABAIIACgHIAOgnIAJAAIgVA1g");
	this.shape_76.setTransform(-3.375,399.5);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgDAoIAAg1IAHAAIAAA1gAgDgdQgBAAAAgBQAAAAAAgBQgBAAAAgBQAAAAAAgBIACgEIADgCQAAAAABABQABAAAAAAQABAAAAAAQAAABABAAQAAABABAAQAAABAAAAQAAAAABABQAAAAAAABQAAABAAAAQgBABAAAAQAAABAAAAQgBABAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQgBAAAAAAQAAAAAAAAQgBAAAAAAQgBgBAAAAQgBAAAAgBg");
	this.shape_77.setTransform(-7.225,398.25);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgSAhQgGgHAAgMQAAgOAHgHQAGgIALAAQALAAAFAJIAAgiIAJAAIAABPIgJAAIAAgJQgGALgMAAQgKAAgGgIgAgLgCQgEAFAAAKQAAAJAEAGQAEAFAHAAQAHAAAFgFQAEgFAAgIIAAgIQAAgHgEgDQgFgFgGAAQgHAAgFAGg");
	this.shape_78.setTransform(-11.9,398.275);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AAOAcIAAgfQAAgQgNAAQgFAAgFAEQgEAFAAAHIAAAfIgIAAIAAg1IAIAAIAAAJQAGgLALABQAJgBAFAGQAEAFAAALIAAAhg");
	this.shape_79.setTransform(-17.875,399.45);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgDAmIAAhLIAIAAIAABLg");
	this.shape_80.setTransform(-22.35,398.425);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#5E5584").s().p("Am3CQIAAkfINvAAIAAEfg");
	this.shape_81.setTransform(12.1752,398.7311);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#131313").s().p("AgmBAIAAgNIAJACQAKAAAGgNIAHgRIgjhYIAQAAIAYBEIABAHIABAAIABgHIAZhEIAPAAIgpBnQgKAcgTAAQgGgBgEgBg");
	this.shape_82.setTransform(148.45,125.65);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#131313").s().p("AgbAiQgLgMAAgWQAAgTAMgNQAMgNAQgBQARAAAKAMQAKALAAAUIAAAHIg+AAQAAAPAIAHQAHAJANgBQAPABAMgKIAAANQgLAJgUgBQgRAAgLgMgAgOgaQgHAHgCALIAvAAQAAgMgGgHQgGgGgKgBQgJAAgHAIg");
	this.shape_83.setTransform(139.575,123.55);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#131313").s().p("AgGAsIgjhYIARAAIAWBAIACANIABAAQAAgHACgFIAYhBIAOAAIgjBYg");
	this.shape_84.setTransform(130.7,123.55);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#131313").s().p("AgWAtIAAhYIAOAAIAAATIAAAAQAEgKAEgFQAHgFAIAAQAFAAADABIAAAPQgDgDgIAAQgIAAgFAJQgHAIAAAOIAAAtg");
	this.shape_85.setTransform(123.35,123.475);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#131313").s().p("AgkAIIAAg1IAOAAIAAAyQAAAcAWAAQAJAAAHgHQAHgIAAgMIAAgzIAOAAIAABYIgOAAIAAgNIgBAAQgIAPgSAAQggABAAgmg");
	this.shape_86.setTransform(114.475,123.65);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#131313").s().p("AgNBAIgJgBIgIgDIgHgDIAAgRIAHAFIAJADIAJACIAJABQAMAAAHgFQAGgFAAgJQAAgFgCgEIgGgHIgJgGIgLgGIgMgFIgKgIQgEgEgCgFQgDgFAAgHQAAgIAEgHQAEgGAGgEQAGgEAIgCQAIgCAHAAQASAAAIAEIAAARQgLgIgRAAQgEAAgEABQgFABgEACQgEADgCADQgCAEAAAFQAAAEABAEIAGAGIAIAGIALAGIAMAGQAGADAFAFQAEAEADAGQADAFAAAHQAAAJgEAGQgEAHgGAEQgGAEgIACQgIABgIAAIgHAAg");
	this.shape_87.setTransform(104.925,121.775);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#131313").s().p("AARBCIgmgrIgBAAIAAArIgOAAIAAiDIAOAAIAABTIABAAIAkgoIATAAIgpAqIAsAug");
	this.shape_88.setTransform(91.475,121.425);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#131313").s().p("AgVAiQgLgMAAgUQAAgVAMgNQANgOAUAAQALABAJAEIAAAOQgKgGgLgBQgMAAgJALQgJAJAAAPQAAAPAIAJQAJAKAMgBQAMAAAKgHIAAAOQgKAFgOAAQgSAAgMgMg");
	this.shape_89.setTransform(82.325,123.55);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#131313").s().p("AgaAoQgIgIAAgLQAAgYAdgEIAagEQgBgWgRgBQgPAAgNAMIAAgPQANgJAPAAQAgAAAAAiIAAA4IgOAAIAAgNQgKAPgRAAQgNAAgHgGgAAAADQgKABgEADQgFAEgBAJQAAAGAFAFQAFADAHAAQAKAAAHgHQAGgHABgMIAAgIg");
	this.shape_90.setTransform(73.45,123.55);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#131313").s().p("AgZA0IgBAAIAAANIgOAAIAAiDIAOAAIAAA7IABAAQAKgSATAAQARAAAKAMQAKAMAAATQAAAWgLANQgLAOgTAAQgQAAgJgPgAgSgEQgIAHAAANIAAANQAAALAIAHQAHAIALAAQAMAAAHgKQAHgKAAgSQAAgOgHgIQgGgIgMAAQgMAAgHAJg");
	this.shape_91.setTransform(64.475,121.525);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#131313").s().p("AgeA3QgKgMAAgVQAAgWALgMQALgNASAAQASAAAIAOIABAAIAAg3IAOAAIAACDIgOAAIAAgPIgBAAQgKARgTAAQgRAAgKgMgAgSgEQgHAJAAARQAAAPAHAJQAHAJALAAQAMAAAHgJQAIgIAAgNIAAgNQAAgLgHgHQgIgHgKAAQgMAAgIAJg");
	this.shape_92.setTransform(53.425,121.525);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#131313").s().p("AgbAiQgLgMAAgWQAAgTAMgNQAMgNAQgBQARAAAKAMQAKALAAAUIAAAHIg+AAQAAAPAIAHQAHAJANgBQAPABAMgKIAAANQgLAJgUgBQgRAAgLgMgAgOgaQgHAHgCALIAvAAQAAgMgGgHQgGgGgKgBQgJAAgHAIg");
	this.shape_93.setTransform(43.925,123.55);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#131313").s().p("AgbAiQgLgMAAgWQAAgTAMgNQAMgNAQgBQARAAAKAMQAKALAAAUIAAAHIg+AAQAAAPAIAHQAHAJANgBQAPABAMgKIAAANQgLAJgUgBQgRAAgLgMgAgOgaQgHAHgCALIAvAAQAAgMgGgHQgGgGgKgBQgJAAgHAIg");
	this.shape_94.setTransform(34.625,123.55);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#131313").s().p("AgeA+IAAh7IA+AAIAAANIgwAAIAAArIAsAAIAAAMIgsAAIAAA3g");
	this.shape_95.setTransform(26,121.775);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#131313").s().p("AgKAhIAAg0IgPAAIAAgNIAPAAIAAgVIAOgEIAAAZIAWAAIAAANIgWAAIAAAxQAAAJACAEQAEADAHAAQAFAAAEgCIAAALQgFADgIABQgWAAgBgag");
	this.shape_96.setTransform(163.25,100.85);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#131313").s().p("AAXAtIAAgxQAAgcgVAAQgKAAgHAHQgHAIAAANIAAAxIgOAAIAAhYIAOAAIAAAPIABAAQAKgQASgBQAOAAAIAKQAIAJAAASIAAA1g");
	this.shape_97.setTransform(155.375,101.95);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#131313").s().p("AgbAiQgLgMAAgWQAAgTAMgNQAMgNAQgBQARAAAKAMQAKALAAAUIAAAHIg+AAQAAAPAIAHQAHAJANgBQAPABAMgLIAAAOQgLAJgUAAQgRAAgLgNgAgOgaQgHAHgCALIAvAAQAAgLgGgIQgGgGgKAAQgJgBgHAIg");
	this.shape_98.setTransform(145.675,102.05);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#131313").s().p("AgGAsIgihYIAQAAIAWBAIACAMIABAAQAAgGACgFIAXhBIAPAAIgjBYg");
	this.shape_99.setTransform(136.8,102.05);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#131313").s().p("AggA+IAAh7IA+AAIAAANIgvAAIAAApIAsAAIAAANIgsAAIAAArIAyAAIAAANg");
	this.shape_100.setTransform(128.475,100.275);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#131313").s().p("AgJAhIAAg0IgQAAIAAgNIAQAAIAAgVIAMgEIAAAZIAXAAIAAANIgXAAIAAAxQAAAJAEAEQADADAHAAQAFAAAEgCIAAALQgFADgIABQgXAAABgag");
	this.shape_101.setTransform(115.6,100.85);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#131313").s().p("AAXAtIAAgxQAAgcgVAAQgKAAgHAHQgHAIAAANIAAAxIgOAAIAAhYIAOAAIAAAPIABAAQAKgQASgBQAOAAAIAKQAIAJAAASIAAA1g");
	this.shape_102.setTransform(107.725,101.95);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#131313").s().p("AgbAiQgLgMAAgWQAAgTAMgNQAMgNAQgBQARAAAKAMQAKALAAAUIAAAHIg+AAQAAAPAIAHQAHAJANgBQAPABAMgLIAAAOQgLAJgUAAQgRAAgLgNgAgOgaQgHAHgCALIAvAAQAAgLgGgIQgGgGgKAAQgJgBgHAIg");
	this.shape_103.setTransform(98.025,102.05);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#131313").s().p("AAxAtIAAgxQAAgPgFgHQgFgHgKABQgJgBgGAJQgHAIAAAMIAAAxIgNAAIAAgzQAAgagVAAQgIAAgHAHQgGAIAAANIAAAxIgOAAIAAhYIAOAAIAAAPIABAAQAJgRASAAQAJAAAHAGQAGAFACAIQAKgTATAAQAeAAAAAlIAAA1g");
	this.shape_104.setTransform(85.75,101.95);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#131313").s().p("AAXAtIAAgxQAAgcgVAAQgKAAgHAHQgHAIAAANIAAAxIgOAAIAAhYIAOAAIAAAPIABAAQAKgQASgBQAOAAAIAKQAIAJAAASIAAA1g");
	this.shape_105.setTransform(73.075,101.95);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#131313").s().p("AgGBBIAAhYIANAAIAABYgAgGgwQgCgDAAgEQAAgEACgCQADgDADAAQAEAAADADQACACAAAEQAAAEgCADQgDACgEAAQgDAAgDgCg");
	this.shape_106.setTransform(65.825,100);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#131313").s().p("AgaAoQgIgIAAgLQAAgYAdgEIAZgEQABgWgTAAQgOAAgNALIAAgPQANgJAPAAQAgAAAAAiIAAA4IgPAAIAAgNQgJAQgRAAQgNgBgHgGgAAAADQgJABgGADQgEAEAAAJQgBAGAFAFQAEADAJAAQAJAAAHgHQAGgHAAgMIAAgIg");
	this.shape_107.setTransform(58.9,102.05);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#131313").s().p("AgKAhIAAg0IgPAAIAAgNIAPAAIAAgVIAOgEIAAAZIAWAAIAAANIgWAAIAAAxQAAAJADAEQADADAHAAQAFAAAEgCIAAALQgFADgIABQgXAAAAgag");
	this.shape_108.setTransform(51.55,100.85);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#131313").s().p("AgWAtIAAhYIAOAAIAAATIABAAQACgKAGgFQAGgFAHAAQAHAAACABIAAAPQgDgDgIAAQgJAAgFAJQgGAIAAAOIAAAtg");
	this.shape_109.setTransform(45.65,101.975);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#131313").s().p("AgbAiQgLgMAAgWQAAgTAMgNQAMgNAQgBQARAAAKAMQAKALAAAUIAAAHIg+AAQAAAPAIAHQAHAJANgBQAPABAMgLIAAAOQgLAJgUAAQgRAAgLgNgAgOgaQgHAHgCALIAvAAQAAgLgGgIQgGgGgKAAQgJgBgHAIg");
	this.shape_110.setTransform(37.325,102.05);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#131313").s().p("AgJAhIAAg0IgQAAIAAgNIAQAAIAAgVIAMgEIAAAZIAXAAIAAANIgXAAIAAAxQAAAJAEAEQADADAHAAQAFAAAEgCIAAALQgFADgIABQgXAAABgag");
	this.shape_111.setTransform(29.65,100.85);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#131313").s().p("AAXAtIAAgxQAAgcgVAAQgKAAgHAHQgHAIAAANIAAAxIgOAAIAAhYIAOAAIAAAPIABAAQAKgQASgBQAOAAAIAKQAIAJAAASIAAA1g");
	this.shape_112.setTransform(21.775,101.95);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#131313").s().p("AggA+IAAh7IA+AAIAAANIgvAAIAAApIAsAAIAAANIgsAAIAAArIAyAAIAAANg");
	this.shape_113.setTransform(12.575,100.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50,86,256,327.2);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5,32);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.cursor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgQIAhlMgrLArMIgNgIMAAAis/MB3BB29Mg7dAAAMAbGBBFIxWIqg");
	this.shape.setTransform(8.6,9.55,0.0152,0.014,-15.0037,0,0,-65.4,34.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#131313").s().p("EgDYB1CIjCnRMgVRgzXMgpNApNIpLJJMAAAjhDQAAgKADgOIAGgWIAQAWQAJAMAIAIMAzNAzNUAkgAkkAtrAtqIVRVQQAKAKAQANIAbAVIgIANMhFVAAAMAYwA7bMgkGASEIggAWgEACJBmIIRWorMgbGhBEMA7cAAAMh3Ah29MAAACs/IAMAIMArLgrMg");
	this.shape_1.setTransform(9.2,9.8,0.0152,0.014,-15.0037,0,0,-80.7,99.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.4,19.6);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.click = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(102,96,170,0.498)").s().p("AgEAGQgDgDAAgDQAAgCADgCQACgDACAAQAEAAACADQACACAAACQAAADgCADQgCACgEAAQgCAAgCgCg");
	this.shape.setTransform(9.25,9.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(102,96,170,0.498)").s().p("AgNAPQgGgHAAgIQAAgGAGgHQAGgGAHAAQAIAAAGAGQAGAHAAAGQAAAIgGAHQgGAFgIAAQgHAAgGgFg");
	this.shape_1.setTransform(9.25,9.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(102,96,170,0.498)").s().p("AgVAXQgKgJAAgOQAAgLAKgKQAJgKAMAAQANAAAJAKQAKAKAAALQAAAOgKAJQgJAJgNAAQgMAAgJgJg");
	this.shape_2.setTransform(9.25,9.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(102,96,170,0.498)").s().p("AgeAgQgNgOAAgSQAAgQANgOQAMgNASAAQASAAANANQANAOAAAQQAAASgNAOQgNAMgSAAQgSAAgMgMg");
	this.shape_3.setTransform(9.25,9.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(102,96,170,0.498)").s().p("AgnAoQgQgQAAgYQAAgVAQgSQARgQAWAAQAWAAARAQQARASAAAVQAAAYgRAQQgRAQgWAAQgWAAgRgQg");
	this.shape_4.setTransform(9.25,9.25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(102,96,170,0.498)").s().p("AgiAjQgOgPAAgUQAAgTAOgPQAOgOAUAAQATAAAOAOQAQAPAAATQAAAUgQAPQgOAOgTAAQgUAAgOgOg");
	this.shape_5.setTransform(9.25,9.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(102,96,170,0.498)").s().p("AgdAeQgMgMAAgSQAAgPAMgOQANgMAQAAQARAAAMAMQANAOAAAPQAAASgNAMQgMAMgRAAQgQAAgNgMg");
	this.shape_6.setTransform(9.225,9.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(102,96,170,0.498)").s().p("AgYAZQgKgKAAgPQAAgNAKgLQALgKANAAQAOAAAKAKQALALAAANQAAAPgLAKQgKAKgOAAQgNAAgLgKg");
	this.shape_7.setTransform(9.225,9.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(102,96,170,0.498)").s().p("AgTAUQgIgIAAgMQAAgKAIgJQAIgIALAAQALAAAIAIQAJAJAAAKQAAAMgJAIQgIAIgLAAQgLAAgIgIg");
	this.shape_8.setTransform(9.225,9.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(102,96,170,0.498)").s().p("AgOAPQgGgGAAgJQAAgHAGgHQAGgGAIAAQAIAAAGAGQAHAHAAAHQAAAJgHAGQgGAGgIAAQgIAAgGgGg");
	this.shape_9.setTransform(9.225,9.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(102,96,170,0.498)").s().p("AgIAKQgFgEAAgGQAAgEAFgEQAEgFAEAAQAGAAAEAFQADAEAAAEQAAAGgDAEQgEAEgGgBQgEABgEgEg");
	this.shape_10.setTransform(9.2,9.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(102,96,170,0.498)").s().p("AgEAFQgBgCAAgDQAAAAAAAAQAAgBAAAAQAAgBABAAQAAgBAAgBQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAAAAAQABABAAABQABAAAAABQAAAAAAABQAAAAAAAAQAAADgCACQAAAAAAABQgBAAAAAAQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAQgBgBgBAAg");
	this.shape_11.setTransform(9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[]},1).wait(6));

	// Layer_1
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(102,96,170,0.498)").s().p("AgLALQgEgEAAgHQAAgFAEgGQAGgEAFAAQAHAAAEAEQAFAGAAAFQAAAHgFAEQgEAFgHAAQgFAAgGgFg");
	this.shape_12.setTransform(9.2,9.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(102,96,170,0.498)").s().p("AgUAVQgHgJAAgMQAAgLAHgJQAJgHALAAQALAAAJAHQAJAJAAALQAAAMgJAJQgJAIgLAAQgLAAgJgIg");
	this.shape_13.setTransform(9.2,9.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(102,96,170,0.498)").s().p("AgdAdQgLgMgBgRQABgQALgNQANgLAQgBQAQABANALQAMANAAAQQAAARgMAMQgNAMgQAAQgQAAgNgMg");
	this.shape_14.setTransform(9.2,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(102,96,170,0.498)").s().p("AgmAnQgPgQAAgXQAAgUAPgSQARgPAVAAQAWAAAPAPQARASAAAUQAAAXgRAQQgPAPgWAAQgVAAgRgPg");
	this.shape_15.setTransform(9.2,9.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(102,96,170,0.498)").s().p("AgvAvQgTgTAAgcQAAgaATgVQAUgTAbAAQAaAAAUATQAUAVAAAaQAAAcgUATQgUATgaAAQgbAAgUgTg");
	this.shape_16.setTransform(9.2,9.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(102,96,170,0.498)").s().p("Ag4A4QgWgXAAghQAAgeAWgaQAYgWAgAAQAgAAAXAWQAZAaAAAeQAAAhgZAXQgXAYggAAQggAAgYgYg");
	this.shape_17.setTransform(9.2,9.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(102,96,170,0.498)").s().p("AhBBCQgagcAAgmQAAgjAageQAbgaAmAAQAkAAAbAaQAdAeAAAjQAAAmgdAcQgbAagkAAQgmAAgbgag");
	this.shape_18.setTransform(9.2,9.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(102,96,170,0.498)").s().p("Ag8A8QgYgYAAgkQAAggAYgcQAagYAiAAQAiAAAYAYQAbAcAAAgQAAAkgbAYQgYAZgiAAQgiAAgagZg");
	this.shape_19.setTransform(9.2,9.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(102,96,170,0.498)").s().p("Ag2A4QgXgXAAghQAAgeAXgYQAWgXAgAAQAfAAAXAXQAYAYAAAeQAAAhgYAXQgXAWgfAAQggAAgWgWg");
	this.shape_20.setTransform(9.2,9.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(102,96,170,0.498)").s().p("AgyAyQgUgUAAgeQAAgbAUgXQAWgUAcAAQAcAAAUAUQAXAXAAAbQAAAegXAUQgUAVgcAAQgcAAgWgVg");
	this.shape_21.setTransform(9.2,9.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(102,96,170,0.498)").s().p("AgsAuQgTgTAAgbQAAgZATgTQASgTAaAAQAaAAASATQAUATAAAZQAAAbgUATQgSASgaAAQgaAAgSgSg");
	this.shape_22.setTransform(9.2,9.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(102,96,170,0.498)").s().p("AgoAoQgQgQAAgYQAAgVAQgTQARgQAXAAQAWAAARAQQASATAAAVQAAAYgSAQQgRARgWAAQgXAAgRgRg");
	this.shape_23.setTransform(9.2,9.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(102,96,170,0.498)").s().p("AgiAkQgPgPAAgVQAAgSAPgQQAOgPAUAAQAUAAAPAPQAPAQAAASQAAAVgPAPQgPAOgUAAQgUAAgOgOg");
	this.shape_24.setTransform(9.2,9.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(102,96,170,0.498)").s().p("AgeAeQgMgMAAgSQAAgQAMgOQANgMARAAQARAAAMAMQAOAOAAAQQAAASgOAMQgMANgRAAQgRAAgNgNg");
	this.shape_25.setTransform(9.2,9.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(102,96,170,0.498)").s().p("AgYAaQgLgLAAgPQAAgNALgLQAKgLAOAAQAOAAAKALQAMALAAANQAAAPgMALQgKAKgOAAQgOAAgKgKg");
	this.shape_26.setTransform(9.2,9.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(102,96,170,0.498)").s().p("AgUAVQgIgJAAgMQAAgLAIgJQAJgIALAAQAMAAAIAIQAJAJAAALQAAAMgJAJQgIAIgMAAQgLAAgJgIg");
	this.shape_27.setTransform(9.2,9.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(102,96,170,0.498)").s().p("AgOAPQgHgFAAgKQAAgHAHgHQAGgHAIAAQAIAAAHAHQAHAHAAAHQAAAKgHAFQgHAHgIAAQgIAAgGgHg");
	this.shape_28.setTransform(9.2,9.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(102,96,170,0.498)").s().p("AgJALQgFgEAAgHQAAgFAFgEQAEgFAFAAQAGAAAFAFQAEAEAAAFQAAAHgEAEQgFAEgGAAQgFAAgEgEg");
	this.shape_29.setTransform(9.2,9.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(102,96,170,0.498)").s().p("AgFAFQgCgCAAgDQAAgCACgDQACgCADAAQADAAACACQADADAAACQAAADgDACQgCADgDAAQgDAAgCgDg");
	this.shape_30.setTransform(9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12}]}).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.4,18.4);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A0A4D2").s().p("AwKM/IAA59MAgWAAAIAAZ9g");
	this.shape.setTransform(150.0031,300.0054,1.4486,3.6123);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,300,600), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.result = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F7579").s().p("AmHD3IAAntIMPAAIAAHtgAlfDPIK/AAIAAllIlgCwIAAAAIlfixgAlfjEIFfCyIFgixIAAgLIq/AAg");
	this.shape.setTransform(164.3763,492.4945,0.251,0.251);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E9E9E9").s().p("AnhHiQjHjIAAkaQAAkZDHjIQDIjIEZAAQEaAADIDIQDHDIAAEZQAAEajHDIQjIDIkaAAQkZAAjIjIg");
	this.shape_1.setTransform(164.3763,492.5008,0.251,0.251);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F7579").s().p("AheACICpipIAVAWIiUCTICPCQIgVAWg");
	this.shape_2.setTransform(111.3105,492.4933,0.2509,0.2509);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#3F7579").s().p("AheCSICTiTIiQiQIAWgWICkCmIioCpg");
	this.shape_3.setTransform(125.1376,492.4933,0.2509,0.2509);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#3F7579").s().p("AhxEnIDBpYIAiALIjCJXg");
	this.shape_4.setTransform(118.2304,492.4933,0.2509,0.2509);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9E9E9").s().p("AnhHiQjHjIAAkaQAAkZDHjIQDIjIEZAAQEbAADHDIQDHDIAAEZQAAEajHDIQjHDIkbAAQkZAAjIjIg");
	this.shape_5.setTransform(118.2573,492.5008,0.251,0.251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#3F7579").s().p("AgOBQIAAifIAdAAIAACfg");
	this.shape_6.setTransform(76.6925,497.6314,0.2509,0.2509);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#3F7579").s().p("AgOBsIAAjWIAdAAIAADWg");
	this.shape_7.setTransform(80.2183,498.3152,0.2509,0.2509);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#3F7579").s().p("AgOBsIAAjWIAdAAIAADWg");
	this.shape_8.setTransform(73.3675,498.3152,0.2509,0.2509);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#3F7579").s().p("AiLAPIAAgdIEXAAIAAAdg");
	this.shape_9.setTransform(76.6925,493.5849,0.2509,0.2509);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#3F7579").s().p("AibCcIAAk3IE3AAIAAE3gAh8B+ID5AAIAAj6Ij5AAg");
	this.shape_10.setTransform(76.6925,487.8759,0.2509,0.2509);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#3F7579").s().p("AiaCcIAAk3IE1AAIAAE3gAh9B9ID6AAIAAj5Ij6AAg");
	this.shape_11.setTransform(67.5581,497.1107,0.2509,0.2509);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#3F7579").s().p("AiaCcIAAk3IE1AAIAAE3gAh9B+ID6AAIAAj6Ij6AAg");
	this.shape_12.setTransform(67.5581,487.8759,0.2509,0.2509);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#E9E9E9").s().p("AnhHiQjIjIABkaQgBkZDIjIQDIjIEZAAQEbAADHDIQDHDIABEZQgBEajHDIQjHDIkbAAQkZAAjIjIg");
	this.shape_13.setTransform(72.1445,492.5008,0.251,0.251);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhmCyQg2AAgtgeQgsgdgUgxQgPghAAglQAAgkAPghQAUgxAsgdQAtgeA2AAIAdAAQAEANAAAMQAAAMgEANIgdAAQghAAgcAQQgcAPgSAbQgVAgAAAlQAAAlAVAhQASAaAcAQQAcAQAhAAIDNAAQA1AAAlgmQAmglAAg1QAAg0gmgmQglglg1AAIgiAAIABgZQAAgNgBgMIAiAAQBKAAA0A0QA0A0AABJQAABKg0A0Qg0A0hKAAg");
	this.shape_14.setTransform(29.3955,494.413,0.2509,0.2509);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABKCyQgEgNAAgMQAAgMAEgNIAdAAQAhAAAcgQQAcgQASgaQAVghAAglQAAglgVggQgSgbgcgPQgcgQghAAIjNAAQg1AAglAmQgmAlAAA0QAAA1AmAlQAlAmA1AAIAiAAQgBAMAAANIABAZIgiAAQhKAAg0g0Qg0g0AAhKQAAhJA0g0QA0g0BKAAIDNAAQA2AAAtAeQAsAdAUAxQAPAhAAAkQAAAlgPAhQgUAxgsAdQgtAeg2AAg");
	this.shape_15.setTransform(22.8959,490.5735,0.2509,0.2509);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3F7579").s().p("AnhHiQjIjIAAkaQAAkZDIjIQDHjIEaAAQEaAADIDIQDIDIgBEZQABEajIDIQjIDIkaAAQkaAAjHjIg");
	this.shape_16.setTransform(26.1572,492.5008,0.251,0.251);

	this.components = new lib.resultcomponent("synched",0);
	this.components.name = "components";
	this.components.setTransform(101.85,146,1,1,0,0,0,86.6,129.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.components},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.7,102.6,256,407);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(64.45,10.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(16.425,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(5.125,16.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(16.425,5.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(5.125,5.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(0,0,132.4,21.6), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_86 = function() {
		exportRoot.tlMain.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(86).call(this.frame_86).wait(14).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(150.35,299.25,0.09,0.09,0,0,0,-39.5,1.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:1.5098,scaleY:1.5099,x:150.25},13,cjs.Ease.quadOut).to({x:66.1},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AhBYpIAAlFIcEAAIAAFFg");
	var mask_graphics_15 = new cjs.Graphics().p("AhHYpIAAlFIcEAAIAAFFg");
	var mask_graphics_16 = new cjs.Graphics().p("AhYYpIAAlFIcEAAIAAFFg");
	var mask_graphics_17 = new cjs.Graphics().p("Ah1YpIAAlFIcEAAIAAFFg");
	var mask_graphics_18 = new cjs.Graphics().p("AieYpIAAlFIcEAAIAAFFg");
	var mask_graphics_19 = new cjs.Graphics().p("AjTYpIAAlFIcEAAIAAFFg");
	var mask_graphics_20 = new cjs.Graphics().p("AkTYpIAAlFIcEAAIAAFFg");
	var mask_graphics_21 = new cjs.Graphics().p("AlUYpIAAlFIcEAAIAAFFg");
	var mask_graphics_22 = new cjs.Graphics().p("AmIYpIAAlFIcEAAIAAFFg");
	var mask_graphics_23 = new cjs.Graphics().p("AmxYpIAAlFIcEAAIAAFFg");
	var mask_graphics_24 = new cjs.Graphics().p("AnOYpIAAlFIcEAAIAAFFg");
	var mask_graphics_25 = new cjs.Graphics().p("AngYpIAAlFIcEAAIAAFFg");
	var mask_graphics_26 = new cjs.Graphics().p("AnmYpIAAlFIcEAAIAAFFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:173.1209,y:157.7477}).wait(1).to({graphics:mask_graphics_15,x:172.5361,y:157.7477}).wait(1).to({graphics:mask_graphics_16,x:170.782,y:157.7477}).wait(1).to({graphics:mask_graphics_17,x:167.8583,y:157.7477}).wait(1).to({graphics:mask_graphics_18,x:163.7653,y:157.7477}).wait(1).to({graphics:mask_graphics_19,x:158.5027,y:157.7477}).wait(1).to({graphics:mask_graphics_20,x:152.0708,y:157.7477}).wait(1).to({graphics:mask_graphics_21,x:145.6388,y:157.7477}).wait(1).to({graphics:mask_graphics_22,x:140.3763,y:157.7477}).wait(1).to({graphics:mask_graphics_23,x:136.2832,y:157.7477}).wait(1).to({graphics:mask_graphics_24,x:133.3596,y:157.7477}).wait(1).to({graphics:mask_graphics_25,x:131.6054,y:157.7477}).wait(1).to({graphics:mask_graphics_26,x:131.0459,y:157.7477}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-58.65,283.15,1.5098,1.5099,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:50,y:283.3},12,cjs.Ease.quadInOut).wait(33).to({alpha:0},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(0.05,1,0.3055,0.7361,0,0,0,0.1,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({startPosition:0},0).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.7,300,601.1999999999999);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.uigraphics = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		//this.survey.cache(-105,-104,422,419,2);
		//this.result_page.components.cache(-71,-112,342,578,2);
	}
	this.frame_454 = function() {
		this.stop();
		exportRoot.tlMain.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(454).call(this.frame_454).wait(1));

	// cursor
	this.cursor = new lib.cursor("synched",0);
	this.cursor.name = "cursor";
	this.cursor.setTransform(204.15,181.25,1.9135,1.9135,0,0,0,9.2,9.8);

	this.timeline.addTween(cjs.Tween.get(this.cursor).to({x:19.45,y:221.7},42,cjs.Ease.quadInOut).wait(27).to({startPosition:0},0).to({x:17.95,y:334.7},31,cjs.Ease.quadInOut).wait(84).to({startPosition:0},0).to({x:205.95,y:184.05},44,cjs.Ease.quadInOut).to({x:184.95,y:206.05},161,cjs.Ease.quadIn).to({x:202.35,y:436.35},40,cjs.Ease.quadInOut).wait(26));

	// click
	this.instance = new lib.click("synched",0,false);
	this.instance.setTransform(1.8,203.95,1.5,1.5,0,0,0,9.2,9.2);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(46).to({_off:false},0).wait(62).to({x:1.7,y:318.3},0).wait(327).to({x:184.75,y:417.5},0).wait(20));

	// clicked
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6760AA").s().p("AglAmQgQgPAAgXQAAgVAQgRQAPgPAWAAQAWAAAPAPQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQg");
	this.shape.setTransform(1.85,204.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6760AA").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_1.setTransform(1.85,261.225);
	this.shape_1._off = true;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(103,96,170,0.996)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_2.setTransform(1.85,261.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(103,96,170,0.992)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_3.setTransform(1.85,261.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(103,96,170,0.988)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_4.setTransform(1.85,261.225);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(103,96,170,0.98)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_5.setTransform(1.85,261.225);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("rgba(103,96,170,0.969)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_6.setTransform(1.85,261.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(103,96,170,0.953)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_7.setTransform(1.85,261.225);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("rgba(103,96,170,0.933)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_8.setTransform(1.85,261.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("rgba(103,96,170,0.91)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_9.setTransform(1.85,261.225);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("rgba(103,96,170,0.878)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_10.setTransform(1.85,261.225);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("rgba(103,96,170,0.843)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_11.setTransform(1.85,261.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("rgba(103,96,170,0.796)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_12.setTransform(1.85,261.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("rgba(103,96,170,0.737)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_13.setTransform(1.85,261.225);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("rgba(103,96,170,0.671)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_14.setTransform(1.85,261.225);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("rgba(103,96,170,0.592)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_15.setTransform(1.85,261.225);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("rgba(103,96,170,0.502)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_16.setTransform(1.85,261.225);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("rgba(103,96,170,0.408)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_17.setTransform(1.85,261.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("rgba(103,96,170,0.329)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_18.setTransform(1.85,261.225);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("rgba(103,96,170,0.263)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_19.setTransform(1.85,261.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(103,96,170,0.204)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_20.setTransform(1.85,261.225);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(103,96,170,0.157)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_21.setTransform(1.85,261.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(103,96,170,0.122)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_22.setTransform(1.85,261.225);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("rgba(103,96,170,0.09)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_23.setTransform(1.85,261.225);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("rgba(103,96,170,0.067)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_24.setTransform(1.85,261.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("rgba(103,96,170,0.047)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_25.setTransform(1.85,261.225);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("rgba(103,96,170,0.031)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_26.setTransform(1.85,261.225);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("rgba(103,96,170,0.02)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_27.setTransform(1.85,261.225);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("rgba(103,96,170,0.012)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_28.setTransform(1.85,261.225);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("rgba(103,96,170,0.008)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_29.setTransform(1.85,261.225);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("rgba(103,96,170,0.004)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_30.setTransform(1.85,261.225);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("rgba(103,96,170,0)").s().p("AglJgQgQgPAAgXQAAgVAQgRQAPgQAWAAQAWAAAPAQQARARAAAVQAAAXgRAPQgPAQgWAAQgWAAgPgQgAgloTQgQgQAAgWQAAgWAQgRQAPgPAWAAQAWAAAPAPQARARAAAWQAAAWgRAQQgPAQgWAAQgWAAgPgQg");
	this.shape_31.setTransform(1.85,261.225);
	this.shape_31._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},55).to({state:[{t:this.shape_1}]},62).to({state:[{t:this.shape_1}]},76).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_31}]},1).wait(222));
	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(117).to({_off:false},0).wait(81).to({_off:true},1).wait(256));
	this.timeline.addTween(cjs.Tween.get(this.shape_31).wait(228).to({_off:false},0).wait(227));

	// result
	this.result_page = new lib.result("synched",0);
	this.result_page.name = "result_page";
	this.result_page.setTransform(110.8,82.45,1.029,1.029,0,0,0,105.7,89.4);
	this.result_page.alpha = 0;
	this.result_page._off = true;

	this.timeline.addTween(cjs.Tween.get(this.result_page).wait(193).to({_off:false},0).to({alpha:1},40,cjs.Ease.quartInOut).wait(222));

	// result BG
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("rgba(255,255,255,0)").s().p("AweN/IAA79MAg9AAAIAAb9g");
	this.shape_32.setTransform(98.9467,298.2244,1.4208,2.4885);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("rgba(255,255,255,0)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_33.setTransform(98.95,298.225);
	this.shape_33._off = true;

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("rgba(255,255,255,0.004)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_34.setTransform(98.95,298.225);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.008)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_35.setTransform(98.95,298.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("rgba(255,255,255,0.012)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_36.setTransform(98.95,298.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("rgba(255,255,255,0.02)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_37.setTransform(98.95,298.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("rgba(255,255,255,0.031)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_38.setTransform(98.95,298.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(255,255,255,0.047)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_39.setTransform(98.95,298.225);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("rgba(255,255,255,0.067)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_40.setTransform(98.95,298.225);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("rgba(255,255,255,0.09)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_41.setTransform(98.95,298.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("rgba(255,255,255,0.122)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_42.setTransform(98.95,298.225);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("rgba(255,255,255,0.157)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_43.setTransform(98.95,298.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("rgba(255,255,255,0.204)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_44.setTransform(98.95,298.225);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("rgba(255,255,255,0.263)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_45.setTransform(98.95,298.225);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("rgba(255,255,255,0.329)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_46.setTransform(98.95,298.225);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("rgba(255,255,255,0.408)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_47.setTransform(98.95,298.225);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("rgba(255,255,255,0.502)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_48.setTransform(98.95,298.225);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("rgba(255,255,255,0.592)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_49.setTransform(98.95,298.225);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("rgba(255,255,255,0.671)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_50.setTransform(98.95,298.225);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("rgba(255,255,255,0.737)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_51.setTransform(98.95,298.225);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(255,255,255,0.796)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_52.setTransform(98.95,298.225);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("rgba(255,255,255,0.843)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_53.setTransform(98.95,298.225);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("rgba(255,255,255,0.878)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_54.setTransform(98.95,298.225);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("rgba(255,255,255,0.91)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_55.setTransform(98.95,298.225);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("rgba(255,255,255,0.933)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_56.setTransform(98.95,298.225);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("rgba(255,255,255,0.953)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_57.setTransform(98.95,298.225);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("rgba(255,255,255,0.969)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_58.setTransform(98.95,298.225);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("rgba(255,255,255,0.98)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_59.setTransform(98.95,298.225);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("rgba(255,255,255,0.988)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_60.setTransform(98.95,298.225);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("rgba(255,255,255,0.992)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_61.setTransform(98.95,298.225);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("rgba(255,255,255,0.996)").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_62.setTransform(98.95,298.225);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("EgXaAizMAAAhFlMAu1AAAMAAABFlg");
	this.shape_63.setTransform(98.95,298.225);
	this.shape_63._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_32}]},193).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_63}]},1).wait(222));
	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(194).to({_off:false},0).wait(4).to({_off:true},1).wait(256));
	this.timeline.addTween(cjs.Tween.get(this.shape_63).wait(228).to({_off:false},0).wait(227));

	// survey copy
	this.instance_1 = new lib.survey();
	this.instance_1.setTransform(-57.85,75.8,0.6981,0.6981);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},233).wait(222));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.8,75.5,314.1,452.70000000000005);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-2.15,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("AqpDUIAAmnIVTAAIAAGng");
	this.shape.setTransform(-47.15,-1.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-115.4,-22.3,136.5,42.400000000000006), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo intro
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(0.1,0,1,1,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.5,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(284.3,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt_CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(47,552.2,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(94.65,551.85,0.8205,0.8205,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// screen
	this.screen = new lib.screen_1("synched",0);
	this.screen.name = "screen";
	this.screen.setTransform(60.6,248.55,0.77,0.77,0,0,0,247.2,146.3);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// UI graphics
	this.ui = new lib.uigraphics();
	this.ui.name = "ui";
	this.ui.setTransform(151.5,302.85,1,1,0,0,0,99.4,224);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// bg img
	this.bg = new lib.bg();
	this.bg.name = "bg";
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	// still logo
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(31.65,32.1,0.747,0.7471,0,0,0,-0.1,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu0MAAAhdnMAu3AAAMAAABdng");
	this.shape.setTransform(150,299.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-129.7,0,641.4,607), null);


// stage content:
(lib.M365_FY21Q3ConsOpt_USA_300x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		mc.visible = false;
		mc.replay_btn.alpha=0;
		//mc.ui.shadow = new createjs.Shadow("#000000", 0, 5, 6);
		mc.screen.cache(-248,-146,990,584,2);
		
		
		this.runBanner = function() {
			
				mc.visible = true;
				mc.replay_btn.alpha=1;
			
				this.tlMain = gsap.timeline({default:{duration:0.4, ease:"power4.inOut"}});
				this.tlMain.pause();
				mc.logo_intro.play();
			
		//1st frame
				this.tlMain.from(mc.ui,{duration:0.6, y:"+=200", alpha:0, onStart:function(){mc.ui.gotoAndPlay();}});
				this.tlMain.from([exportRoot.headline1a,exportRoot.headline1b],{y:"+=10", alpha:0, stagger:0.2}, "<");
				this.tlMain.to([exportRoot.headline1a,exportRoot.headline1b],{y:"-=10", alpha:0},"+=1");
		//2nd frame	
				
				this.tlMain.from([exportRoot.headline2a,exportRoot.headline2b, exportRoot.headline2c],{y:"+=10", alpha:0, stagger:0.15});
				this.tlMain.to([exportRoot.headline2a,exportRoot.headline2b,exportRoot.headline2c],{y:"-=10", alpha:0},"+=2");
		//3rd frame
				this.tlMain.from([exportRoot.headline3a,exportRoot.headline3b, exportRoot.headline3c],{y:"+=10", alpha:0, stagger:0.15});
				this.tlMain.to([exportRoot.headline3a,exportRoot.headline3b,exportRoot.headline3c],{y:"-=10", alpha:0},"+=2");
		//4th frame
				this.tlMain.from([exportRoot.headline4a,exportRoot.headline4b, exportRoot.headline4c],{
					y:"+=10", 
					alpha:0, 
					stagger:0.15,
					onComplete: function (){exportRoot.tlMain.pause();}
				});
				this.tlMain.to([exportRoot.headline4a,exportRoot.headline4b,exportRoot.headline4c],{y:"-=10", alpha:0});
				
				//last frame
				this.tlMain.to([mc.ui,mc.bg],{alpha:0},"<");
				this.tlMain.from(mc.screen, {duration:1, x:"+=80", y:"+=145", alpha:0});
				this.tlMain.from(exportRoot.headline5,{x:"-=150", alpha:0, stagger:0.15},"<0.45");
				this.tlMain.from(exportRoot.headline6,{x:"-=150", alpha:0, stagger:0.15},"<0.45");
				
				this.tlMain.from([mc.cta,mc.txtCta], { alpha:0, duration: 0.6, x: "-=350"}, "-=0.45");
				this.tlMain.from(mc.replay_btn, { alpha: 0, onStart:function(){exportRoot.isReplay = true;}});
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,0.9996,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(20.3,300,491.4,306.79999999999995);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q3ConsOpt_USA_300x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_1_atlas_1.png?1611759305792", id:"M365_FY21Q3ConsOpt_USA_300x600_BAN_Forms_EN_NA_Standard_ANI_BN_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;