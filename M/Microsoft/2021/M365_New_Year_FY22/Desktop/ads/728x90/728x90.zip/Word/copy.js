// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT, FONT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	bannerData.headline1 = ["<#505050>Chasing dreams","18.2px",476, 34,"18","350", "center", "Segoe Pro"];
	bannerData.headline2 = ["<#505050>still takes formatting","18.2px",478, 34,"18","350", "center", "Segoe Pro"];
	bannerData.headline3 = ["<#505050>Be a bolder you this year","18.2px",469, 34,"18","350", "center", "Segoe Pro"];
		
	bannerData.CTA = ["<#ffffff>Learn more","9.2px",0,0,"50","300", "left", "Segoe Pro"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
