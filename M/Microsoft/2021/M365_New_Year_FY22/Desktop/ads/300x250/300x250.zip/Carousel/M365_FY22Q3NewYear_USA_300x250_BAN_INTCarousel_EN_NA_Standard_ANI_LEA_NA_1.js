(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[0,0,1607,118],[0,120,1607,118],[0,240,1607,118],[0,360,1607,118],[0,480,1607,118],[0,600,1607,118],[0,720,1607,118],[0,840,1607,118],[0,960,1607,118],[0,1080,1607,118],[0,1200,1607,118],[0,1320,1607,118],[0,1440,1607,118],[0,1560,1607,118],[0,1680,1607,118],[0,1800,1607,118],[0,1920,1607,118],[0,2040,1607,118],[0,2160,1607,118],[0,2280,1607,118],[0,2400,1607,118],[0,2520,1607,118],[0,2640,1607,118],[0,2760,1607,118],[0,2880,1607,118]]},
		{name:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2", frames: [[0,0,1607,118],[0,120,1607,118],[0,240,1607,118],[0,360,1607,118],[0,480,1607,118],[0,600,1607,118],[0,720,1607,118],[0,840,1607,118],[0,960,1607,118],[0,1080,1607,118],[0,1200,1607,118],[0,1320,1607,118],[0,1440,1607,118],[0,1560,1607,118],[0,1680,1607,118],[0,1800,1607,118],[0,1920,1607,118],[0,2040,1607,118],[0,2160,1607,118],[0,2280,1607,118],[0,2400,1607,118],[0,2520,1607,118],[0,2640,1607,118],[0,2760,1607,118],[0,2880,1607,118]]},
		{name:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3", frames: [[0,0,1607,118],[0,120,1607,118],[0,240,1607,118],[0,360,1607,118],[0,480,1607,118],[0,600,1607,118],[0,720,1607,118],[0,840,1607,118],[0,960,1607,118],[0,1080,1607,118],[0,1200,1607,118],[0,1320,1607,118],[0,1440,1607,118],[0,1560,1607,118],[0,1680,1607,118],[0,1800,1607,118],[0,1920,1607,118],[0,2040,1607,118],[0,2160,1607,118],[0,2280,1607,118],[0,2400,1607,118],[0,2520,1607,118],[0,2640,1607,118],[0,2760,1607,118],[0,2880,1607,118]]},
		{name:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4", frames: [[0,0,1607,118],[0,120,1607,118],[0,240,1607,118],[0,360,1607,118],[0,480,1607,118],[0,600,1607,118],[0,720,1607,118],[0,840,1607,118],[0,960,1607,118],[0,1080,1607,118],[0,1200,1607,118],[0,1320,1607,118],[0,1440,1607,118],[0,1560,1607,118],[0,1680,1607,118],[0,1800,1607,118],[0,1920,1607,118],[0,2040,1607,118],[0,2160,1607,118],[0,2280,1607,118],[0,2400,1607,118],[0,2520,1607,118],[0,2640,1607,118],[0,2760,1607,118],[0,2880,1607,118]]},
		{name:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5", frames: [[365,2400,359,268],[0,2400,363,268],[0,2670,361,268],[726,2400,359,268],[726,2670,420,62],[1087,2400,420,62],[1087,2464,420,62],[1087,2528,420,62],[1087,2592,420,62],[1148,2656,420,62],[1148,2720,420,62],[726,2734,420,62],[1148,2784,420,62],[726,2798,420,62],[1148,2848,420,62],[726,2862,420,62],[1148,2912,420,62],[726,2926,420,62],[0,0,1607,118],[0,120,1607,118],[0,240,1607,118],[0,360,1607,118],[0,480,1607,118],[0,600,1607,118],[0,720,1607,118],[0,840,1607,118],[0,960,1607,118],[0,1080,1607,118],[0,1200,1607,118],[0,1320,1607,118],[0,1440,1607,118],[0,1560,1607,118],[0,1680,1607,118],[0,1800,1607,118],[0,1920,1607,118],[0,2040,1607,118],[0,2160,1607,118],[0,2280,1607,118],[363,2670,361,268]]},
		{name:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6", frames: [[422,1920,111,217],[535,1920,111,217],[648,1920,111,217],[0,0,420,62],[0,64,420,62],[0,128,420,62],[0,192,420,62],[0,256,420,62],[0,320,420,62],[0,384,420,62],[0,448,420,62],[0,512,420,62],[0,576,420,62],[0,640,420,62],[0,704,420,62],[0,768,420,62],[0,832,420,62],[0,896,420,62],[0,960,420,62],[0,1024,420,62],[0,1088,420,62],[0,1152,420,62],[0,1216,420,62],[0,1280,420,62],[0,1344,420,62],[0,1408,420,62],[0,1472,420,62],[0,1536,420,62],[0,1600,420,62],[0,1664,420,62],[0,1728,420,62],[0,1792,420,62],[0,1856,420,62],[0,1920,420,62],[0,1984,420,62],[0,2048,420,62],[0,2112,420,62],[0,2176,420,62],[0,2240,420,62],[0,2304,420,62],[0,2368,420,62],[0,2432,420,62],[0,2496,420,62],[0,2560,420,62],[0,2624,420,62],[0,2688,420,62],[0,2752,420,62],[0,2816,420,62],[0,2880,420,62],[422,0,420,62],[422,64,420,62],[422,128,420,62],[422,192,420,62],[422,256,420,62],[422,320,420,62],[422,384,420,62],[422,448,420,62],[422,512,420,62],[422,576,420,62],[422,640,420,62],[422,704,420,62],[422,768,420,62],[422,832,420,62],[422,896,420,62],[422,960,420,62],[422,1024,420,62],[422,1088,420,62],[422,1152,420,62],[422,1216,420,62],[422,1280,420,62],[422,1344,420,62],[422,1408,420,62],[422,1472,420,62],[422,1536,420,62],[422,1600,420,62],[422,1664,420,62],[422,1728,420,62],[422,1792,420,62],[422,1856,420,62],[761,1920,111,217]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.EONEDRIVE_DESKTOP_LOGO_FRONT_NOLOGO_01 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.EXCEL_DESKTOP_LOGO_FRONT_01 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.EXCEL_MOBILE_LOGO_FRONT_NOLOGO_01 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.LINKEDINEDITOR_DESKTOP_LOGO_FRONT_01 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ONEDRIVE_DESKTOP_LOGO_FRONT_01 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.PPT_Coach_Mobile_Front_NoLogo_07 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.PPT_Rehearse_Desktop_Front_06 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom0 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom10 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom100 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom102 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom104 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom106 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom108 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom110 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom112 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom114 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom116 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom118 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom12 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom120 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom122 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom124 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom126 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom128 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom130 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom132 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom134 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom136 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom138 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom14 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom140 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom142 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom144 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom146 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom148 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom150 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom152 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom154 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom156 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom158 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom16 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom160 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom162 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom164 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom166 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom168 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom170 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom172 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom174 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom176 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom178 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom18 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom2 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom20 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom22 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom24 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom26 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom28 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom30 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom32 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom34 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom36 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom38 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom4 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom40 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom42 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom44 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom46 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom48 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom50 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom52 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom54 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom56 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom58 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom6 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom60 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom62 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom64 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom66 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom68 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom70 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom72 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom74 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom76 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom78 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom8 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom80 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom82 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom84 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom86 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom88 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom90 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom92 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom94 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom96 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.ribbonbottom98 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop0 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop10 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop100 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop102 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop104 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop106 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop108 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop110 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop112 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop114 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop116 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop118 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop12 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop120 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop122 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop124 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop126 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop128 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop130 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop132 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop134 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop136 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop138 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop14 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop140 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop142 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop144 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop146 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop148 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop150 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop152 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop154 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop156 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop158 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop16 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop160 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop162 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop164 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop166 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop168 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop170 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop172 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop174 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop176 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop178 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop18 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop180 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop182 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop184 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop186 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop188 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop190 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop192 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop194 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop196 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop198 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop2 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop20 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop200 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop202 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop204 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop206 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop208 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop210 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop212 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop214 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop216 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop218 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop22 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop220 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop222 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop224 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop226 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop228 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop230 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop232 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop234 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop236 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop238 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop24 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop26 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop28 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop30 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop32 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop34 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop36 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop38 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop4 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop40 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop42 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop44 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop46 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop48 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop50 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop52 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop54 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop56 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop58 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop6 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop60 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop62 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop64 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop66 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop68 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop70 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop72 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop74 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop76 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop78 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop8 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop80 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop82 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop84 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop86 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop88 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop90 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop92 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop94 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop96 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.ribbontop98 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Word_Desktop_Front_02 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.Word_Mobile_Front_NoLogo_02 = function() {
	this.initialize(ss["M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.slideworld = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Word_Mobile_Front_NoLogo_02();
	this.instance.setTransform(155.55,20.9,0.41,0.41);

	this.instance_1 = new lib.Word_Desktop_Front_02();
	this.instance_1.setTransform(0,0,0.41,0.41);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slideworld, new cjs.Rectangle(0,0,210.3,116), null);


(lib.slideppt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPT_Rehearse_Desktop_Front_06();
	this.instance.setTransform(0,0,0.41,0.41);

	this.instance_1 = new lib.PPT_Coach_Mobile_Front_NoLogo_07();
	this.instance_1.setTransform(155.55,20.95,0.41,0.41);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slideppt, new cjs.Rectangle(0,0,209.1,116), null);


(lib.slideonedrive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ONEDRIVE_DESKTOP_LOGO_FRONT_01();
	this.instance.setTransform(0,0,0.41,0.41);

	this.instance_1 = new lib.EONEDRIVE_DESKTOP_LOGO_FRONT_NOLOGO_01();
	this.instance_1.setTransform(155.55,20.95,0.41,0.41);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slideonedrive, new cjs.Rectangle(0,0,214,120.1), null);


(lib.slideexcel = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EXCEL_MOBILE_LOGO_FRONT_NOLOGO_01();
	this.instance.setTransform(155.55,20.95,0.41,0.41);

	this.instance_1 = new lib.EXCEL_DESKTOP_LOGO_FRONT_01();
	this.instance_1.setTransform(0,0,0.41,0.41);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slideexcel, new cjs.Rectangle(0,0,209.5,117.3), null);


(lib.slideeditor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.LINKEDINEDITOR_DESKTOP_LOGO_FRONT_01();
	this.instance.setTransform(25.55,0,0.41,0.41);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slideeditor, new cjs.Rectangle(17.3,0,157.1,122), null);


(lib.roundnav = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#185ABD").ss(1.5,0,0,4).p("AAACoQhFAAgxgxQgxgxAAhGQAAhFAxgxQAxgxBFAAQBGAAAxAxQAxAxAABFQAABGgxAxQgxAxhGAAg");
	this.shape.setTransform(16.75,16.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah2B3QgwgygBhFQABhEAwgyQAygwBEgBQBFABAyAwQAwAyAABEQAABFgwAyQgyAwhFAAQhEAAgygwg");
	this.shape_1.setTransform(16.75,16.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,35.5,35.5);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.emptybutton = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("A3bTiIAAvnIEVAAIAAn2IkVAAIAAvmMAu3AAAIAAPmIkkAAIAAH2IEkAAIAAPng");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.empty = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ribbonback = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ribbonbottom0();

	this.instance_1 = new lib.ribbonbottom2();

	this.instance_2 = new lib.ribbonbottom4();

	this.instance_3 = new lib.ribbonbottom6();

	this.instance_4 = new lib.ribbonbottom8();

	this.instance_5 = new lib.ribbonbottom10();

	this.instance_6 = new lib.ribbonbottom12();

	this.instance_7 = new lib.ribbonbottom14();

	this.instance_8 = new lib.ribbonbottom16();

	this.instance_9 = new lib.ribbonbottom18();

	this.instance_10 = new lib.ribbonbottom20();

	this.instance_11 = new lib.ribbonbottom22();

	this.instance_12 = new lib.ribbonbottom24();

	this.instance_13 = new lib.ribbonbottom26();

	this.instance_14 = new lib.ribbonbottom28();

	this.instance_15 = new lib.ribbonbottom30();

	this.instance_16 = new lib.ribbonbottom32();

	this.instance_17 = new lib.ribbonbottom34();

	this.instance_18 = new lib.ribbonbottom36();

	this.instance_19 = new lib.ribbonbottom38();

	this.instance_20 = new lib.ribbonbottom40();

	this.instance_21 = new lib.ribbonbottom42();

	this.instance_22 = new lib.ribbonbottom44();

	this.instance_23 = new lib.ribbonbottom46();

	this.instance_24 = new lib.ribbonbottom48();

	this.instance_25 = new lib.ribbonbottom50();

	this.instance_26 = new lib.ribbonbottom52();

	this.instance_27 = new lib.ribbonbottom54();

	this.instance_28 = new lib.ribbonbottom56();

	this.instance_29 = new lib.ribbonbottom58();

	this.instance_30 = new lib.ribbonbottom60();

	this.instance_31 = new lib.ribbonbottom62();

	this.instance_32 = new lib.ribbonbottom64();

	this.instance_33 = new lib.ribbonbottom66();

	this.instance_34 = new lib.ribbonbottom68();

	this.instance_35 = new lib.ribbonbottom70();

	this.instance_36 = new lib.ribbonbottom72();

	this.instance_37 = new lib.ribbonbottom74();

	this.instance_38 = new lib.ribbonbottom76();

	this.instance_39 = new lib.ribbonbottom78();

	this.instance_40 = new lib.ribbonbottom80();

	this.instance_41 = new lib.ribbonbottom82();

	this.instance_42 = new lib.ribbonbottom84();

	this.instance_43 = new lib.ribbonbottom86();

	this.instance_44 = new lib.ribbonbottom88();

	this.instance_45 = new lib.ribbonbottom90();

	this.instance_46 = new lib.ribbonbottom92();

	this.instance_47 = new lib.ribbonbottom94();

	this.instance_48 = new lib.ribbonbottom96();

	this.instance_49 = new lib.ribbonbottom98();

	this.instance_50 = new lib.ribbonbottom100();

	this.instance_51 = new lib.ribbonbottom102();

	this.instance_52 = new lib.ribbonbottom104();

	this.instance_53 = new lib.ribbonbottom106();

	this.instance_54 = new lib.ribbonbottom108();

	this.instance_55 = new lib.ribbonbottom110();

	this.instance_56 = new lib.ribbonbottom112();

	this.instance_57 = new lib.ribbonbottom114();

	this.instance_58 = new lib.ribbonbottom116();

	this.instance_59 = new lib.ribbonbottom118();

	this.instance_60 = new lib.ribbonbottom120();

	this.instance_61 = new lib.ribbonbottom122();

	this.instance_62 = new lib.ribbonbottom124();

	this.instance_63 = new lib.ribbonbottom126();

	this.instance_64 = new lib.ribbonbottom128();

	this.instance_65 = new lib.ribbonbottom130();

	this.instance_66 = new lib.ribbonbottom132();

	this.instance_67 = new lib.ribbonbottom134();

	this.instance_68 = new lib.ribbonbottom136();

	this.instance_69 = new lib.ribbonbottom138();

	this.instance_70 = new lib.ribbonbottom140();

	this.instance_71 = new lib.ribbonbottom142();

	this.instance_72 = new lib.ribbonbottom144();

	this.instance_73 = new lib.ribbonbottom146();

	this.instance_74 = new lib.ribbonbottom148();

	this.instance_75 = new lib.ribbonbottom150();

	this.instance_76 = new lib.ribbonbottom152();

	this.instance_77 = new lib.ribbonbottom154();

	this.instance_78 = new lib.ribbonbottom156();

	this.instance_79 = new lib.ribbonbottom158();

	this.instance_80 = new lib.ribbonbottom160();

	this.instance_81 = new lib.ribbonbottom162();

	this.instance_82 = new lib.ribbonbottom164();

	this.instance_83 = new lib.ribbonbottom166();

	this.instance_84 = new lib.ribbonbottom168();

	this.instance_85 = new lib.ribbonbottom170();

	this.instance_86 = new lib.ribbonbottom172();

	this.instance_87 = new lib.ribbonbottom174();

	this.instance_88 = new lib.ribbonbottom176();

	this.instance_89 = new lib.ribbonbottom178();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_16}]},2).to({state:[{t:this.instance_17}]},2).to({state:[{t:this.instance_18}]},2).to({state:[{t:this.instance_19}]},2).to({state:[{t:this.instance_20}]},2).to({state:[{t:this.instance_21}]},2).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},2).to({state:[{t:this.instance_25}]},2).to({state:[{t:this.instance_26}]},2).to({state:[{t:this.instance_27}]},2).to({state:[{t:this.instance_28}]},2).to({state:[{t:this.instance_29}]},2).to({state:[{t:this.instance_30}]},2).to({state:[{t:this.instance_31}]},2).to({state:[{t:this.instance_32}]},2).to({state:[{t:this.instance_33}]},2).to({state:[{t:this.instance_34}]},2).to({state:[{t:this.instance_35}]},2).to({state:[{t:this.instance_36}]},2).to({state:[{t:this.instance_37}]},2).to({state:[{t:this.instance_38}]},2).to({state:[{t:this.instance_39}]},2).to({state:[{t:this.instance_40}]},2).to({state:[{t:this.instance_41}]},2).to({state:[{t:this.instance_42}]},2).to({state:[{t:this.instance_43}]},2).to({state:[{t:this.instance_44}]},2).to({state:[{t:this.instance_45}]},2).to({state:[{t:this.instance_46}]},2).to({state:[{t:this.instance_47}]},2).to({state:[{t:this.instance_48}]},2).to({state:[{t:this.instance_49}]},2).to({state:[{t:this.instance_50}]},2).to({state:[{t:this.instance_51}]},2).to({state:[{t:this.instance_52}]},2).to({state:[{t:this.instance_53}]},2).to({state:[{t:this.instance_54}]},2).to({state:[{t:this.instance_55}]},2).to({state:[{t:this.instance_56}]},2).to({state:[{t:this.instance_57}]},2).to({state:[{t:this.instance_58}]},2).to({state:[{t:this.instance_59}]},2).to({state:[{t:this.instance_60}]},2).to({state:[{t:this.instance_61}]},2).to({state:[{t:this.instance_62}]},2).to({state:[{t:this.instance_63}]},2).to({state:[{t:this.instance_64}]},2).to({state:[{t:this.instance_65}]},2).to({state:[{t:this.instance_66}]},2).to({state:[{t:this.instance_67}]},2).to({state:[{t:this.instance_68}]},2).to({state:[{t:this.instance_69}]},2).to({state:[{t:this.instance_70}]},2).to({state:[{t:this.instance_71}]},2).to({state:[{t:this.instance_72}]},2).to({state:[{t:this.instance_73}]},2).to({state:[{t:this.instance_74}]},2).to({state:[{t:this.instance_75}]},2).to({state:[{t:this.instance_76}]},2).to({state:[{t:this.instance_77}]},2).to({state:[{t:this.instance_78}]},2).to({state:[{t:this.instance_79}]},2).to({state:[{t:this.instance_80}]},2).to({state:[{t:this.instance_81}]},2).to({state:[{t:this.instance_82}]},2).to({state:[{t:this.instance_83}]},2).to({state:[{t:this.instance_84}]},2).to({state:[{t:this.instance_85}]},2).to({state:[{t:this.instance_86}]},2).to({state:[{t:this.instance_87}]},2).to({state:[{t:this.instance_88}]},2).to({state:[{t:this.instance_89}]},2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,420,62);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.625,5.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.675,5.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.625,-5.625);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.675,-5.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ribbontop0();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.ribbontop2();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.ribbontop4();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.instance_3 = new lib.ribbontop6();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.ribbontop8();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.ribbontop10();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.instance_6 = new lib.ribbontop12();
	this.instance_6.setTransform(0,0,0.5,0.5);

	this.instance_7 = new lib.ribbontop14();
	this.instance_7.setTransform(0,0,0.5,0.5);

	this.instance_8 = new lib.ribbontop16();
	this.instance_8.setTransform(0,0,0.5,0.5);

	this.instance_9 = new lib.ribbontop18();
	this.instance_9.setTransform(0,0,0.5,0.5);

	this.instance_10 = new lib.ribbontop20();
	this.instance_10.setTransform(0,0,0.5,0.5);

	this.instance_11 = new lib.ribbontop22();
	this.instance_11.setTransform(0,0,0.5,0.5);

	this.instance_12 = new lib.ribbontop24();
	this.instance_12.setTransform(0,0,0.5,0.5);

	this.instance_13 = new lib.ribbontop26();
	this.instance_13.setTransform(0,0,0.5,0.5);

	this.instance_14 = new lib.ribbontop28();
	this.instance_14.setTransform(0,0,0.5,0.5);

	this.instance_15 = new lib.ribbontop30();
	this.instance_15.setTransform(0,0,0.5,0.5);

	this.instance_16 = new lib.ribbontop32();
	this.instance_16.setTransform(0,0,0.5,0.5);

	this.instance_17 = new lib.ribbontop34();
	this.instance_17.setTransform(0,0,0.5,0.5);

	this.instance_18 = new lib.ribbontop36();
	this.instance_18.setTransform(0,0,0.5,0.5);

	this.instance_19 = new lib.ribbontop38();
	this.instance_19.setTransform(0,0,0.5,0.5);

	this.instance_20 = new lib.ribbontop40();
	this.instance_20.setTransform(0,0,0.5,0.5);

	this.instance_21 = new lib.ribbontop42();
	this.instance_21.setTransform(0,0,0.5,0.5);

	this.instance_22 = new lib.ribbontop44();
	this.instance_22.setTransform(0,0,0.5,0.5);

	this.instance_23 = new lib.ribbontop46();
	this.instance_23.setTransform(0,0,0.5,0.5);

	this.instance_24 = new lib.ribbontop48();
	this.instance_24.setTransform(0,0,0.5,0.5);

	this.instance_25 = new lib.ribbontop50();
	this.instance_25.setTransform(0,0,0.5,0.5);

	this.instance_26 = new lib.ribbontop52();
	this.instance_26.setTransform(0,0,0.5,0.5);

	this.instance_27 = new lib.ribbontop54();
	this.instance_27.setTransform(0,0,0.5,0.5);

	this.instance_28 = new lib.ribbontop56();
	this.instance_28.setTransform(0,0,0.5,0.5);

	this.instance_29 = new lib.ribbontop58();
	this.instance_29.setTransform(0,0,0.5,0.5);

	this.instance_30 = new lib.ribbontop60();
	this.instance_30.setTransform(0,0,0.5,0.5);

	this.instance_31 = new lib.ribbontop62();
	this.instance_31.setTransform(0,0,0.5,0.5);

	this.instance_32 = new lib.ribbontop64();
	this.instance_32.setTransform(0,0,0.5,0.5);

	this.instance_33 = new lib.ribbontop66();
	this.instance_33.setTransform(0,0,0.5,0.5);

	this.instance_34 = new lib.ribbontop68();
	this.instance_34.setTransform(0,0,0.5,0.5);

	this.instance_35 = new lib.ribbontop70();
	this.instance_35.setTransform(0,0,0.5,0.5);

	this.instance_36 = new lib.ribbontop72();
	this.instance_36.setTransform(0,0,0.5,0.5);

	this.instance_37 = new lib.ribbontop74();
	this.instance_37.setTransform(0,0,0.5,0.5);

	this.instance_38 = new lib.ribbontop76();
	this.instance_38.setTransform(0,0,0.5,0.5);

	this.instance_39 = new lib.ribbontop78();
	this.instance_39.setTransform(0,0,0.5,0.5);

	this.instance_40 = new lib.ribbontop80();
	this.instance_40.setTransform(0,0,0.5,0.5);

	this.instance_41 = new lib.ribbontop82();
	this.instance_41.setTransform(0,0,0.5,0.5);

	this.instance_42 = new lib.ribbontop84();
	this.instance_42.setTransform(0,0,0.5,0.5);

	this.instance_43 = new lib.ribbontop86();
	this.instance_43.setTransform(0,0,0.5,0.5);

	this.instance_44 = new lib.ribbontop88();
	this.instance_44.setTransform(0,0,0.5,0.5);

	this.instance_45 = new lib.ribbontop90();
	this.instance_45.setTransform(0,0,0.5,0.5);

	this.instance_46 = new lib.ribbontop92();
	this.instance_46.setTransform(0,0,0.5,0.5);

	this.instance_47 = new lib.ribbontop94();
	this.instance_47.setTransform(0,0,0.5,0.5);

	this.instance_48 = new lib.ribbontop96();
	this.instance_48.setTransform(0,0,0.5,0.5);

	this.instance_49 = new lib.ribbontop98();
	this.instance_49.setTransform(0,0,0.5,0.5);

	this.instance_50 = new lib.ribbontop100();
	this.instance_50.setTransform(0,0,0.5,0.5);

	this.instance_51 = new lib.ribbontop102();
	this.instance_51.setTransform(0,0,0.5,0.5);

	this.instance_52 = new lib.ribbontop104();
	this.instance_52.setTransform(0,0,0.5,0.5);

	this.instance_53 = new lib.ribbontop106();
	this.instance_53.setTransform(0,0,0.5,0.5);

	this.instance_54 = new lib.ribbontop108();
	this.instance_54.setTransform(0,0,0.5,0.5);

	this.instance_55 = new lib.ribbontop110();
	this.instance_55.setTransform(0,0,0.5,0.5);

	this.instance_56 = new lib.ribbontop112();
	this.instance_56.setTransform(0,0,0.5,0.5);

	this.instance_57 = new lib.ribbontop114();
	this.instance_57.setTransform(0,0,0.5,0.5);

	this.instance_58 = new lib.ribbontop116();
	this.instance_58.setTransform(0,0,0.5,0.5);

	this.instance_59 = new lib.ribbontop118();
	this.instance_59.setTransform(0,0,0.5,0.5);

	this.instance_60 = new lib.ribbontop120();
	this.instance_60.setTransform(0,0,0.5,0.5);

	this.instance_61 = new lib.ribbontop122();
	this.instance_61.setTransform(0,0,0.5,0.5);

	this.instance_62 = new lib.ribbontop124();
	this.instance_62.setTransform(0,0,0.5,0.5);

	this.instance_63 = new lib.ribbontop126();
	this.instance_63.setTransform(0,0,0.5,0.5);

	this.instance_64 = new lib.ribbontop128();
	this.instance_64.setTransform(0,0,0.5,0.5);

	this.instance_65 = new lib.ribbontop130();
	this.instance_65.setTransform(0,0,0.5,0.5);

	this.instance_66 = new lib.ribbontop132();
	this.instance_66.setTransform(0,0,0.5,0.5);

	this.instance_67 = new lib.ribbontop134();
	this.instance_67.setTransform(0,0,0.5,0.5);

	this.instance_68 = new lib.ribbontop136();
	this.instance_68.setTransform(0,0,0.5,0.5);

	this.instance_69 = new lib.ribbontop138();
	this.instance_69.setTransform(0,0,0.5,0.5);

	this.instance_70 = new lib.ribbontop140();
	this.instance_70.setTransform(0,0,0.5,0.5);

	this.instance_71 = new lib.ribbontop142();
	this.instance_71.setTransform(0,0,0.5,0.5);

	this.instance_72 = new lib.ribbontop144();
	this.instance_72.setTransform(0,0,0.5,0.5);

	this.instance_73 = new lib.ribbontop146();
	this.instance_73.setTransform(0,0,0.5,0.5);

	this.instance_74 = new lib.ribbontop148();
	this.instance_74.setTransform(0,0,0.5,0.5);

	this.instance_75 = new lib.ribbontop150();
	this.instance_75.setTransform(0,0,0.5,0.5);

	this.instance_76 = new lib.ribbontop152();
	this.instance_76.setTransform(0,0,0.5,0.5);

	this.instance_77 = new lib.ribbontop154();
	this.instance_77.setTransform(0,0,0.5,0.5);

	this.instance_78 = new lib.ribbontop156();
	this.instance_78.setTransform(0,0,0.5,0.5);

	this.instance_79 = new lib.ribbontop158();
	this.instance_79.setTransform(0,0,0.5,0.5);

	this.instance_80 = new lib.ribbontop160();
	this.instance_80.setTransform(0,0,0.5,0.5);

	this.instance_81 = new lib.ribbontop162();
	this.instance_81.setTransform(0,0,0.5,0.5);

	this.instance_82 = new lib.ribbontop164();
	this.instance_82.setTransform(0,0,0.5,0.5);

	this.instance_83 = new lib.ribbontop166();
	this.instance_83.setTransform(0,0,0.5,0.5);

	this.instance_84 = new lib.ribbontop168();
	this.instance_84.setTransform(0,0,0.5,0.5);

	this.instance_85 = new lib.ribbontop170();
	this.instance_85.setTransform(0,0,0.5,0.5);

	this.instance_86 = new lib.ribbontop172();
	this.instance_86.setTransform(0,0,0.5,0.5);

	this.instance_87 = new lib.ribbontop174();
	this.instance_87.setTransform(0,0,0.5,0.5);

	this.instance_88 = new lib.ribbontop176();
	this.instance_88.setTransform(0,0,0.5,0.5);

	this.instance_89 = new lib.ribbontop178();
	this.instance_89.setTransform(0,0,0.5,0.5);

	this.instance_90 = new lib.ribbontop180();
	this.instance_90.setTransform(0,0,0.5,0.5);

	this.instance_91 = new lib.ribbontop182();
	this.instance_91.setTransform(0,0,0.5,0.5);

	this.instance_92 = new lib.ribbontop184();
	this.instance_92.setTransform(0,0,0.5,0.5);

	this.instance_93 = new lib.ribbontop186();
	this.instance_93.setTransform(0,0,0.5,0.5);

	this.instance_94 = new lib.ribbontop188();
	this.instance_94.setTransform(0,0,0.5,0.5);

	this.instance_95 = new lib.ribbontop190();
	this.instance_95.setTransform(0,0,0.5,0.5);

	this.instance_96 = new lib.ribbontop192();
	this.instance_96.setTransform(0,0,0.5,0.5);

	this.instance_97 = new lib.ribbontop194();
	this.instance_97.setTransform(0,0,0.5,0.5);

	this.instance_98 = new lib.ribbontop196();
	this.instance_98.setTransform(0,0,0.5,0.5);

	this.instance_99 = new lib.ribbontop198();
	this.instance_99.setTransform(0,0,0.5,0.5);

	this.instance_100 = new lib.ribbontop200();
	this.instance_100.setTransform(0,0,0.5,0.5);

	this.instance_101 = new lib.ribbontop202();
	this.instance_101.setTransform(0,0,0.5,0.5);

	this.instance_102 = new lib.ribbontop204();
	this.instance_102.setTransform(0,0,0.5,0.5);

	this.instance_103 = new lib.ribbontop206();
	this.instance_103.setTransform(0,0,0.5,0.5);

	this.instance_104 = new lib.ribbontop208();
	this.instance_104.setTransform(0,0,0.5,0.5);

	this.instance_105 = new lib.ribbontop210();
	this.instance_105.setTransform(0,0,0.5,0.5);

	this.instance_106 = new lib.ribbontop212();
	this.instance_106.setTransform(0,0,0.5,0.5);

	this.instance_107 = new lib.ribbontop214();
	this.instance_107.setTransform(0,0,0.5,0.5);

	this.instance_108 = new lib.ribbontop216();
	this.instance_108.setTransform(0,0,0.5,0.5);

	this.instance_109 = new lib.ribbontop218();
	this.instance_109.setTransform(0,0,0.5,0.5);

	this.instance_110 = new lib.ribbontop220();
	this.instance_110.setTransform(0,0,0.5,0.5);

	this.instance_111 = new lib.ribbontop222();
	this.instance_111.setTransform(0,0,0.5,0.5);

	this.instance_112 = new lib.ribbontop224();
	this.instance_112.setTransform(0,0,0.5,0.5);

	this.instance_113 = new lib.ribbontop226();
	this.instance_113.setTransform(0,0,0.5,0.5);

	this.instance_114 = new lib.ribbontop228();
	this.instance_114.setTransform(0,0,0.5,0.5);

	this.instance_115 = new lib.ribbontop230();
	this.instance_115.setTransform(0,0,0.5,0.5);

	this.instance_116 = new lib.ribbontop232();
	this.instance_116.setTransform(0,0,0.5,0.5);

	this.instance_117 = new lib.ribbontop234();
	this.instance_117.setTransform(0,0,0.5,0.5);

	this.instance_118 = new lib.ribbontop236();
	this.instance_118.setTransform(0,0,0.5,0.5);

	this.instance_119 = new lib.ribbontop238();
	this.instance_119.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_16}]},2).to({state:[{t:this.instance_17}]},2).to({state:[{t:this.instance_18}]},2).to({state:[{t:this.instance_19}]},2).to({state:[{t:this.instance_20}]},2).to({state:[{t:this.instance_21}]},2).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},2).to({state:[{t:this.instance_25}]},2).to({state:[{t:this.instance_26}]},2).to({state:[{t:this.instance_27}]},2).to({state:[{t:this.instance_28}]},2).to({state:[{t:this.instance_29}]},2).to({state:[{t:this.instance_30}]},2).to({state:[{t:this.instance_31}]},2).to({state:[{t:this.instance_32}]},2).to({state:[{t:this.instance_33}]},2).to({state:[{t:this.instance_34}]},2).to({state:[{t:this.instance_35}]},2).to({state:[{t:this.instance_36}]},2).to({state:[{t:this.instance_37}]},2).to({state:[{t:this.instance_38}]},2).to({state:[{t:this.instance_39}]},2).to({state:[{t:this.instance_40}]},2).to({state:[{t:this.instance_41}]},2).to({state:[{t:this.instance_42}]},2).to({state:[{t:this.instance_43}]},2).to({state:[{t:this.instance_44}]},2).to({state:[{t:this.instance_45}]},2).to({state:[{t:this.instance_46}]},2).to({state:[{t:this.instance_47}]},2).to({state:[{t:this.instance_48}]},2).to({state:[{t:this.instance_49}]},2).to({state:[{t:this.instance_50}]},2).to({state:[{t:this.instance_51}]},2).to({state:[{t:this.instance_52}]},2).to({state:[{t:this.instance_53}]},2).to({state:[{t:this.instance_54}]},2).to({state:[{t:this.instance_55}]},2).to({state:[{t:this.instance_56}]},2).to({state:[{t:this.instance_57}]},2).to({state:[{t:this.instance_58}]},2).to({state:[{t:this.instance_59}]},2).to({state:[{t:this.instance_60}]},2).to({state:[{t:this.instance_61}]},2).to({state:[{t:this.instance_62}]},2).to({state:[{t:this.instance_63}]},2).to({state:[{t:this.instance_64}]},2).to({state:[{t:this.instance_65}]},2).to({state:[{t:this.instance_66}]},2).to({state:[{t:this.instance_67}]},2).to({state:[{t:this.instance_68}]},2).to({state:[{t:this.instance_69}]},2).to({state:[{t:this.instance_70}]},2).to({state:[{t:this.instance_71}]},2).to({state:[{t:this.instance_72}]},2).to({state:[{t:this.instance_73}]},2).to({state:[{t:this.instance_74}]},2).to({state:[{t:this.instance_75}]},2).to({state:[{t:this.instance_76}]},2).to({state:[{t:this.instance_77}]},2).to({state:[{t:this.instance_78}]},2).to({state:[{t:this.instance_79}]},2).to({state:[{t:this.instance_80}]},2).to({state:[{t:this.instance_81}]},2).to({state:[{t:this.instance_82}]},2).to({state:[{t:this.instance_83}]},2).to({state:[{t:this.instance_84}]},2).to({state:[{t:this.instance_85}]},2).to({state:[{t:this.instance_86}]},2).to({state:[{t:this.instance_87}]},2).to({state:[{t:this.instance_88}]},2).to({state:[{t:this.instance_89}]},2).to({state:[{t:this.instance_90}]},2).to({state:[{t:this.instance_91}]},2).to({state:[{t:this.instance_92}]},2).to({state:[{t:this.instance_93}]},2).to({state:[{t:this.instance_94}]},2).to({state:[{t:this.instance_95}]},2).to({state:[{t:this.instance_96}]},2).to({state:[{t:this.instance_97}]},2).to({state:[{t:this.instance_98}]},2).to({state:[{t:this.instance_99}]},2).to({state:[{t:this.instance_100}]},2).to({state:[{t:this.instance_101}]},2).to({state:[{t:this.instance_102}]},2).to({state:[{t:this.instance_103}]},2).to({state:[{t:this.instance_104}]},2).to({state:[{t:this.instance_105}]},2).to({state:[{t:this.instance_106}]},2).to({state:[{t:this.instance_107}]},2).to({state:[{t:this.instance_108}]},2).to({state:[{t:this.instance_109}]},2).to({state:[{t:this.instance_110}]},2).to({state:[{t:this.instance_111}]},2).to({state:[{t:this.instance_112}]},2).to({state:[{t:this.instance_113}]},2).to({state:[{t:this.instance_114}]},2).to({state:[{t:this.instance_115}]},2).to({state:[{t:this.instance_116}]},2).to({state:[{t:this.instance_117}]},2).to({state:[{t:this.instance_118}]},2).to({state:[{t:this.instance_119}]},2).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,803.5,62);


(lib.ctabg2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","rgba(0,0,0,0.157)"],[0,1],-4.1,4.7,-4.1,-16.7).s().p("A3eCqIAAlTMAu9AAAIAAFTg");
	this.shape.setTransform(150.3,16.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#185ABD").s().p("A3fCtIAAlZMAu/AAAIAAFZg");
	this.shape_1.setTransform(150.4,17.325);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctabg2, new cjs.Rectangle(0,0,300.8,34.7), null);


(lib.arrownav = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#185ABD").ss(3,0,0,4).p("AAoBBIhEg7IBEhH");
	this.shape.setTransform(2.9008,6.6011);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.1,-1.5,10.5,16.1);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.sub_slide = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.slide5 = new lib.slideonedrive();
	this.slide5.name = "slide5";
	this.slide5.setTransform(1185.15,58,0.9995,1,0,0,0,105.2,58);

	this.slide4 = new lib.slideexcel();
	this.slide4.name = "slide4";
	this.slide4.setTransform(915.15,58,0.9995,1,0,0,0,105.2,58);

	this.slide3 = new lib.slideeditor();
	this.slide3.name = "slide3";
	this.slide3.setTransform(645.15,58,0.9995,1,0,0,0,105.2,58);

	this.slide1 = new lib.slideworld();
	this.slide1.name = "slide1";
	this.slide1.setTransform(105.05,58.1,0.9986,1,0,0,0,105.2,58.1);

	this.slide2 = new lib.slideppt();
	this.slide2.name = "slide2";
	this.slide2.setTransform(375.15,58,0.9995,1,0,0,0,105.2,58);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.slide2},{t:this.slide1},{t:this.slide3},{t:this.slide4},{t:this.slide5}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sub_slide, new cjs.Rectangle(0,0,1281,109.9), null);


(lib.slides = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub_slides = new lib.sub_slide();
	this.sub_slides.name = "sub_slides";

	this.timeline.addTween(cjs.Tween.get(this.sub_slides).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.slides, new cjs.Rectangle(0,0,1281,109.9), null);


(lib.ribbonFron = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop;
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EggaANSIAA6jMBA1AAAIAAajg");
	var mask_graphics_1 = new cjs.Graphics().p("EhAhANSIAA6jMCBDAAAIAAajg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:207.525,y:38}).wait(1).to({graphics:mask_graphics_1,x:413,y:32}).wait(1));

	// long_ribbon_b
	this.bg = new lib.bg();
	this.bg.name = "bg";
	var bgFilter_1 = new cjs.ColorFilter(0.99,0.99,0.99,1,0.24,0.9,1.89,0);
	this.bg.filters = [bgFilter_1, new cjs.ColorMatrixFilter(new cjs.ColorMatrix(1, 0, 0, 0))];
	this.bg.cache(-2,-2,808,66);

	var maskedShapeInstanceList = [this.bg];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(2));
	this.timeline.addTween(cjs.Tween.get(bgFilter_1).wait(2));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.bg, startFrame:0, endFrame:2, x:-2, y:-2, w:808, h:66});
	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,807,63);


(lib.nav = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.arrow = new lib.arrownav("synched",0);
	this.arrow.name = "arrow";
	this.arrow.setTransform(22.1,16.95,1,1,0,0,0,3.1,6.5);

	this.circle = new lib.roundnav("synched",0);
	this.circle.name = "circle";
	this.circle.setTransform(16.8,16.8,1,1,0,0,0,16.8,16.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("AiwDQIAAmfIFhAAIAAGfg");
	this.shape.setTransform(15.75,16.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.circle},{t:this.arrow}]}).to({state:[{t:this.shape}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,-4.6,36.5,41.6);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer_4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer_2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.375,7.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.675,7.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.375,-4.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.675,-4.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.tl1.play();
	}
	this.frame_98 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(33).call(this.frame_98).wait(1));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8595,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(72));

	// Layer_3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(39).to({scaleX:2.4401,scaleY:2.4401,x:-13.1,y:7.15},33,cjs.Ease.cubicInOut).wait(1));

	// Layer_2
	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},14,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(72));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(301.475,344.45);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(301.45,344.45);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,978.8,828.1);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer_1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.ctabg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(178.4,17.5,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Layer_1
	this.CTAbg = new lib.ctabg2();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(150.4,17.3,1,1,0,0,0,150.4,17.3);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ctabg, new cjs.Rectangle(0,0,300.8,34.7), null);


(lib.mainMc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// mainHint
	this.click_tag = new lib.emptybutton();
	this.click_tag.name = "click_tag";
	this.click_tag.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.click_tag, 0, 1, 2, false, new lib.emptybutton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.click_tag).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// nav
	this.nav_l = new lib.nav();
	this.nav_l.name = "nav_l";
	this.nav_l.setTransform(4.7,125.4,1,1,0,0,0,16.8,16.8);
	new cjs.ButtonHelper(this.nav_l, 0, 1, 2, false, new lib.nav(), 3);

	this.nav_r = new lib.nav();
	this.nav_r.name = "nav_r";
	this.nav_r.setTransform(295.4,125.3,1,1,180,0,0,16.8,16.8);
	new cjs.ButtonHelper(this.nav_r, 0, 1, 2, false, new lib.nav(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.nav_r},{t:this.nav_l}]}).wait(1));

	// front_ribbon
	this.frontRibbon = new lib.ribbonFron();
	this.frontRibbon.name = "frontRibbon";
	this.frontRibbon.setTransform(369.05,188.3,1,1,0,0,0,400,29.5);

	this.timeline.addTween(cjs.Tween.get(this.frontRibbon).wait(1));
	this.frontRibbon.addEventListener("tick", AdobeAn.handleFilterCache);

	// txt_cta
	this.txtCta = new lib.empty();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(111.9,233.45);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA
	this.cta = new lib.ctabg();
	this.cta.name = "cta";
	this.cta.setTransform(149.9,233.3,1,1,0,0,0,150.4,17.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// UIs
	this.slides = new lib.slides();
	this.slides.name = "slides";
	this.slides.setTransform(50,90);

	this.timeline.addTween(cjs.Tween.get(this.slides).wait(1));

	// txt
	this.txt = new lib.empty();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// back_ribbon
	this.backRibbon = new lib.ribbonback();
	this.backRibbon.name = "backRibbon";
	this.backRibbon.setTransform(-43.9,158.3,1,1,0,0,0,0.1,1);
	var backRibbonFilter_1 = new cjs.ColorFilter(0.99,0.99,0.99,1,0.48,0.9,1.89,0);
	this.backRibbon.filters = [backRibbonFilter_1, new cjs.ColorMatrixFilter(new cjs.ColorMatrix(1, 0, 0, 0))];
	this.backRibbon.cache(-2,-2,424,66);

	this.timeline.addTween(cjs.Tween.get(this.backRibbon).wait(1));
	this.timeline.addTween(cjs.Tween.get(backRibbonFilter_1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this.filterCacheList = [];
	this.filterCacheList.push({instance: this.backRibbon, startFrame:0, endFrame:1, x:-2, y:-2, w:424, h:66});
	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMc, new cjs.Rectangle(-1024.6,-293.9,2355.6,575.7), null);


// stage content:
(lib.M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		frame0();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMc
	this.mainMC = new lib.mainMc();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));
	this.mainMC.addEventListener("tick", AdobeAn.handleFilterCache);

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(106,124.5,1225,157.3);
// library properties:
lib.properties = {
	id: 'D0E66AC471084800A5CC2BC376D5D8CF',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1638804094519", id:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"},
		{src:"images/M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2.png?1638804094519", id:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"},
		{src:"images/M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3.png?1638804094519", id:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_3"},
		{src:"images/M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4.png?1638804094520", id:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_4"},
		{src:"images/M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5.png?1638804094520", id:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_5"},
		{src:"images/M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6.png?1638804094521", id:"M365_FY22Q3NewYear_USA_300x250_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_6"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['D0E66AC471084800A5CC2BC376D5D8CF'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;