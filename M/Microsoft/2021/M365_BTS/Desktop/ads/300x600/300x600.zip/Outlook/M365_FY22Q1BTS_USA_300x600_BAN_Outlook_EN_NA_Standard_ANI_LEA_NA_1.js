(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[395,502,130,199],[527,641,143,145],[0,0,750,500],[752,0,272,182],[672,679,218,73],[672,754,218,73],[752,184,164,288],[752,474,196,203],[0,502,393,268],[527,502,182,137]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BudgetMeeting_lg = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ExcelLogo = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_CU = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_FinalFrame = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.NewMeeting_lg_sh = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.NewSkypeMeeting_lg_sh = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.OutlookBTSCalendarMobile = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.tileShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.VirtualMeeting_lg = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,559.07,1,2.3503);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414.1,978.7,1946.3000000000002);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.OutlookLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelLogo();
	this.instance.setTransform(-8.45,-28.5,0.8782,0.8782);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OutlookLogo, new cjs.Rectangle(-8.4,-28.5,125.60000000000001,127.4), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-48.0247,6.0253);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-59.3249,6.0253);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-48.0247,-5.2749);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-59.3249,-5.2749);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-64.4,-10.4,132.4,21.6), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.mail_lines_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A6CB1QgrAAgegfQgfgeAAgtQAAgpAfgfQAegeArAAIADAAQFBACJugEIR9gNIAJAAQPbgLDxAAQArAAAfAeQAfAfAAAsQAAAqgfAfQgfAfgrgBQkUAAuvAMIgoABQ0eAPnlgBIkWgBg");
	this.shape.setTransform(34.4412,47.6946,0.1945,0.1945);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("A0LBnQgrAAgeggQgfgeAAgrQACgsAegdQAfgeAqgBQJTAGVsgDIJWgBQArAAAgAfQAeAfAAAqQAAArgeAgQggAegrAAI3GACQrFAAmLgEg");
	this.shape_1.setTransform(41.7339,31.7381,0.1945,0.1945);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AN3B0IACgEQmJgRlVgBQmTAArOATQgrABgggdQgggdgBgrIAAgDQgBgqAdggQAegfAsgBQLxgUGjACQFRABG2AUQArACAeAgQAdAggCAqQgCArgeAdQgeAdgrAAg");
	this.shape_2.setTransform(47.9726,17.0536,0.1945,0.1945);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("An1BgIgDAAQgqgHgagjQgZgjAGgqQAHgrAkgaQAjgZArAHQBUAND6AAQCXAAFJgHICOgDQAsAAAfAeQAfAeABAsQABAqgeAfQgfAggrAAIiOADQlgAHiKAAIg8ABQiXAAiUgRg");
	this.shape_3.setTransform(57.3474,2.2121,0.1945,0.1945);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mail_lines_sub, new cjs.Rectangle(0,0,68.9,50), null);


(lib.line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AH2FDQhmgViBhpQgdgXjEi1QiLiChmg9QiKhTiGgEIAAAAQjegGkcB8QhcAohgA1IAAAAQgxAbgwAcQgJAGgKgDQgKgDgGgJQgFgIADgKQACgKAJgGQAxgcAygcIAAAAQBig2BegpQEoiBDnAHIAAAAQCTADCWBbQBpA/CQCHQDCCyAdAXQB1BgBdAUQDkAwEXiYQCNhNBehYQAIgGAKABQALAAAHAHQAHAIgBAKQAAAKgIAHQhiBbiTBRQjgB6jCAAQhAAAg8gNg");
	this.shape.setTransform(127.2216,31.1607);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_sub, new cjs.Rectangle(-2.5,-2.5,259.5,67.3), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.letter_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmxFoQgRAAgPgGQgPgHgMgMQgKgLgGgOQgGgPAAgPIAAovQAAgPAGgOQAFgOALgLQALgNAPgGQAQgHARAAINjAAQAPAAAPAFQAOAGALAKQAMAMAHAPQAGAPAAARIAAIvQABAPgGAPQgGAOgLALQgLAMgQAHQgPAGgQAAgAm8E/QAFABAGAAINjAAQAFAAAFgBIlvkBIhAA3QgGAFgHAAQgGAAgGgFIhAg4gAFbiuIjwDQIFuEAIACgKIAAovQgBgGgCgGgAnakXIAAIvQAAAFACAFIFtj/IjvjOIh/h1IgBAJgAm+k9IB/B0IE/EVIFJkgIByhqIgJgBItjAAQgGAAgHACg");
	this.shape.setTransform(51.4519,36.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letter_sub, new cjs.Rectangle(0,0,102.9,72.1), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8INMAl5AAAAy8hKMAl5AAAAy8BLMAl5AAAAy8DhMAl5AAAAy8F3MAl5AAAAy8oMMAl5AAAAy8l2MAl5AAAAy8jgMAl5AAA");
	this.shape.setTransform(121.25,52.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-1,-1,244.5,107), null);


(lib.fileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tileShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fileShadow, new cjs.Rectangle(0,0,196,203), null);


(lib.file4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.NewSkypeMeeting_lg_sh();
	this.instance.setTransform(35.25,60.1,0.6691,0.6691);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file4, new cjs.Rectangle(35.3,60,148.10000000000002,52), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.VirtualMeeting_lg();
	this.instance.setTransform(-0.1,-0.05,0.809,0.809);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(-2.4,-2.4,170,133.4), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.NewMeeting_lg_sh();
	this.instance.setTransform(21.35,62.2,0.68,0.68);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file1, new cjs.Rectangle(0,61.2,196,74.3), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.ExcelUI_FinalFrame();
	this.instance.setTransform(0,0,1.3786,1.3785);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(0,0,375,250.9), null);


(lib.ms_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_8.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_9.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_10.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_11.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_1, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.calendar_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A5ndQQijAAhyhkQh0hmAAiOMAAAgwBQABiHBshfQBuhgCagBMAz3AAAQCaABBuBgQBtBfAACHMAAAAwBQAACOhzBmQhzBkiiAAgANqadIL+AAQBPABA3gxQA2gwABhFIAAqiIu7AAgAncadIR6AAIAAtHIx6AAgA8jX4QAABFA3AwQA3AxBOgBIO/AAIAAtHIx7AAgANqKiIO7AAIAAtGIu7AAgAncKiIR6AAIAAtGIx6AAgA8jKiIR7AAIAAtGIx7AAgANqlXIO7AAIAAtIIu7AAgAnclXIR6AAIAAtIIx6AAgA8jlXIR7AAIAAtIIx7AAgA7u51QgxArgEBBIAAC3MA5IAAAIAAi3QgFhBgxgrQgygrhBAEMgz3AAAIgKgBQg7AAguAog");
	this.shape.setTransform(53.7185,49.4897,0.2643,0.2643);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.calendar_sub, new cjs.Rectangle(0,0,107.5,99), null);


(lib.bang_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABTDbQgDgBgCgEQgCgEABgEQACgDAEgCIBRgmIgrgQIABAAIg1gTQgEgBgCgDQgCgEABgEQABgDADgDQBPgzAggaIg9AHIhHAJQgDAAgEgCQgDgCgBgDQgBgDACgEIA4iHIhxBjQgDACgEAAQgDAAgDgCQgDgDAAgEIgDieIhICbQgCAEgEABQgDACgEgCQgEgBgBgEIgzh/QgFAfgEAzQgDApAAAiQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEQAAgjADgpQAGhVANghQABgCACgCQADgCADAAQADAAADACQACACABACQANAkAoBjIBQitQABgDADgCQAEgCADABQADABADADQACACAAAEIADCzICBhxQADgCADAAQAEAAADACQADACABADQABAEgCADIhCCeIA2gHQBLgJAQAAQAEAAACACQADADABAEQAAAEgCADQgPAVhnBEIAhAMIAAAAQA5AVAIAFQAEADAAADQACAEgCADQgBADgEACIhlAvIgEABIgEgBg");
	this.shape.setTransform(20.5024,21.0027);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_sub, new cjs.Rectangle(-1,-1,43,44), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzCHIAAkNIPnAAIAAENg");
	this.shape.setTransform(50,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,0,100,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.OutlookBTSCalendarMobile();
	this.instance.setTransform(27.55,-20.15,0.5739,0.5739);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(3.4,-27.1,121.8,201), null);


(lib.squiggle_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-270,-70,540,140,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.line_sub();
	this.line.name = "line";
	this.line.setTransform(127.2,31.2,1,1,0,0,0,127.2,31.2);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squiggle_line, new cjs.Rectangle(-2.5,-2.5,259.5,67.3), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(0.1,17.4,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1,-1.1,11.7,24.400000000000002), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.85,6.1,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(9.75,17.7,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,0.5,11.700000000000001,23.1), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.timeline.addTween(cjs.Tween.get(this.ms).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.mail_lines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.lines.cache(0,0,70,70,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lines = new lib.mail_lines_sub();
	this.lines.name = "lines";
	this.lines.setTransform(34.5,24.95,1,1,0,0,0,34.5,25);

	this.timeline.addTween(cjs.Tween.get(this.lines).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mail_lines, new cjs.Rectangle(0,0,68.9,50), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_106 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(106).call(this.frame_106).wait(2));

	// Layer_3 copy 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_73 = new cjs.Graphics().p("ASEEJQgChEgBhgQAAhhAChEQAChEADAAIA/AAQADAAACBEQADBEAABgQABBhgCBEQgCBEgEAAIg+ABQgDAAgDhFg");
	var mask_graphics_74 = new cjs.Graphics().p("AR7EKQgEhEgBhgQgBhhAChEQAChDAEAAIBQgBQAEAAAEBDQADBEABBhQABBggCBEQgCBFgEAAIhQABQgEAAgDhFg");
	var mask_graphics_75 = new cjs.Graphics().p("ARvELQgEhDgChhQgChgAChEQAChEAFAAIBkgCQAFAAAFBEQAFBEACBgQACBggCBEQgDBFgFAAIhkACIAAAAQgFAAgFhFg");
	var mask_graphics_76 = new cjs.Graphics().p("ARiENQgGhEgDhgQgDhgADhEQAChEAGAAIB8gEQAGAAAGBEQAHBDADBhQADBggDBEQgCBFgHAAIh7AEIAAAAQgGAAgHhFg");
	var mask_graphics_77 = new cjs.Graphics().p("ARTEPQgIhDgEhhQgEhgADhEQADhEAHAAICWgGQAIgBAIBEQAIBDAEBhQAEBggDBEQgCBFgIAAIiWAGIAAAAQgHAAgJhEg");
	var mask_graphics_78 = new cjs.Graphics().p("ARDERQgKhDgGhgQgFhhADhEQADhEAJAAIC0gKQAJAAAKBDQAKBEAFBgQAGBggDBEQgDBFgJABIi0AJIAAAAQgJAAgKhEg");
	var mask_graphics_79 = new cjs.Graphics().p("AQwEUQgMhDgGhgQgHhhADhEQADhEALgBIDVgOQALgBAMBEQAMBEAGBfQAHBggDBEQgDBGgLAAIjVAOIAAAAQgLAAgMhDg");
	var mask_graphics_80 = new cjs.Graphics().p("AQcEXQgPhDgHhgQgIhgADhFQADhEANgBID5gUQAMgBAPBDQAOBEAIBfQAIBggDBEQgEBFgMABIj5AVIAAAAQgNAAgOhDg");
	var mask_graphics_81 = new cjs.Graphics().p("AQGEaQgRhCgJhgQgKhgAEhFQADhEAPgCIEfgcQAPgCARBDQARBDAKBfQAJBggEBFQgDBGgPABIkfAcIgBAAQgOAAgRhCg");
	var mask_graphics_82 = new cjs.Graphics().p("APvEeQgUhCgLhgQgLhgAEhFQAEhEAQgCIFJgnQARgCAUBCQAUBDALBfQALBggEBFQgEBGgRACIlJAmIAAAAQgRAAgThBg");
	var mask_graphics_83 = new cjs.Graphics().p("APWEiQgWhCgNhfQgNhgAEhFQAEhFATgDIF1gyQATgDAWBCQAXBCANBfQANBfgEBFQgFBGgTADIl0AyIgBAAQgTAAgWg/g");
	var mask_graphics_84 = new cjs.Graphics().p("AO9EmQgahBgPhfQgOhgAEhFQAFhFAVgEIGihBQAVgDAaBBQAZBBAPBfQAPBfgFBFQgEBHgVADImiBBIgCAAQgVAAgYg+g");
	var mask_graphics_85 = new cjs.Graphics().p("AOjEqQgdhAgRhfQgQhfAEhFQAFhGAYgEIHQhSQAYgEAdA/QAcBBARBeQARBfgFBGQgFBHgXAEInRBSIgDAAQgWAAgbg9g");
	var mask_graphics_86 = new cjs.Graphics().p("AOIEvQgfg/gThfQgTheAFhGQAFhHAagFIIAhlQAagFAgA+QAgBAATBeQASBfgFBGQgFBHgaAFIoABlIgEABQgYAAgeg7g");
	var mask_graphics_87 = new cjs.Graphics().p("ANuE0Qgjg+gVheQgVhfAGhGQAFhHAdgGIIvh7QAcgHAjA+QAjA/AVBeQAVBdgGBHQgFBIgdAGIovB7IgFABQgaAAggg5g");
	var mask_graphics_88 = new cjs.Graphics().p("ANUE5Qgmg9gXheQgXheAGhHQAGhHAfgHIJdiTQAfgIAmA9QAmA9AXBeQAXBdgGBHQgGBIgfAIIpdCTIgHAAQgcAAgig2g");
	var mask_graphics_89 = new cjs.Graphics().p("AM7E9Qgpg7gZhdQgZhdAGhIQAGhIAhgJIKLisQAhgJApA8QApA8AZBdQAZBcgHBIQgFBJghAJIqLCsIgJABQgdAAgkg1g");
	var mask_graphics_90 = new cjs.Graphics().p("AMiFCQgrg6gbhcQgahdAFhJQAHhIAjgKIK2jHQAjgKAsA6QAsA7AbBdQAbBbgHBJQgGBJgjAKIq2DHQgFACgFAAQggAAgmgzg");
	var mask_graphics_91 = new cjs.Graphics().p("AMMFHQgvg4gchdQgdhcAGhKQAHhIAmgLILejjQAmgLAuA4QAvA6AdBcQAcBcgHBIQgGBKglAMIrfDiQgGACgHAAQggAAgngwg");
	var mask_graphics_92 = new cjs.Graphics().p("AL2FMQgwg3gfhcQgehbAGhLQAHhJAogNIMFj+QAngNAxA3QAyA4AeBcQAeBcgHBIQgGBLgoANIsED+QgIADgIAAQghAAgpgug");
	var mask_graphics_93 = new cjs.Graphics().p("ALjFQQgzg1gghcQgghbAGhLQAHhJAqgOIMokaQApgPAzA2QA0A3AgBbQAgBbgHBJQgGBLgqAPIsoEaQgIADgJAAQgjAAgpgsg");
	var mask_graphics_94 = new cjs.Graphics().p("ALRFVQg1g1gihaQghhbAGhMQAHhKArgPINJk1QArgQA1A0QA3A2AhBaQAhBbgHBLQgGBLgrAPItJE1QgJAEgLAAQgjAAgqgpg");
	var mask_graphics_95 = new cjs.Graphics().p("ALBFeQg4gzgihaQgjhaAGhMQAIhLAsgRINmlPQAsgRA4AzQA4A0AjBaQAjBagIBMQgGBLgtARItlFPQgLAEgMAAQgkAAgqgng");
	var mask_graphics_96 = new cjs.Graphics().p("AKzFsQg6gygkhaQgkhZAHhNQAHhLAugTIOAlnQAtgSA6AyQA6AyAkBaQAkBZgHBNQgHBLguATIt/FnQgNAFgNAAQgkAAgqglg");
	var mask_graphics_97 = new cjs.Graphics().p("AKmF4Qg7gxglhZQglhZAGhNQAIhMAvgTIOXl+QAugUA7AxQA8AyAlBZQAmBZgIBMQgGBNgvATIuXF+QgOAGgOAAQgkAAgrgkg");
	var mask_graphics_98 = new cjs.Graphics().p("AKbGEQg9gwgmhZQgmhYAHhOQAHhNAwgUIOsmTQAvgUA9AvQA9AxAmBZQAmBYgHBNQgHBOgwAUIurGTQgOAGgQAAQgkAAgrgig");
	var mask_graphics_99 = new cjs.Graphics().p("AKRGOQg+gvgnhYQgnhYAHhOQAHhOAxgUIO9mmQAxgWA+AvQA/AwAnBYQAmBYgHBOQgHBOgwAUIu+GmQgPAHgQAAQglAAgrghg");
	var mask_graphics_100 = new cjs.Graphics().p("AKJGYQg/gugohYQgnhYAGhPQAIhOAxgWIPNm2QAxgWA/AuQBAAvAnBXQAoBYgIBOQgGBPgyAWIvMG2QgQAHgRAAQglAAgrgfg");
	var mask_graphics_101 = new cjs.Graphics().p("AKCGgQhAgugohXQgphYAHhPQAHhOAzgXIPZnFQAygXBAAuQBAAuApBXQAoBYgHBOQgHBPgyAXIvZHFQgRAHgSAAQglAAgrgeg");
	var mask_graphics_102 = new cjs.Graphics().p("AJ8GnQhAgtgphYQgphXAGhPQAIhOAzgYIPjnRQAzgYBAAtQBCAtApBYQApBXgIBOQgGBPgzAYIvkHRQgRAIgTAAQglAAgrgdg");
	var mask_graphics_103 = new cjs.Graphics().p("AJ3GsQhBgsgphXQgphXAGhQQAIhOAzgZIPsnbQAzgYBBAsQBCAtAqBXQApBXgHBPQgHBPgzAZIvsHbQgSAIgUAAQglAAgrgdg");
	var mask_graphics_104 = new cjs.Graphics().p("AJ0GxQhCgsgphXQgqhXAHhQQAHhOA0gZIPynjQA0gZBBAsQBDAsAqBXQApBXgHBPQgHBQgzAYIvzHjQgSAJgVAAQgkAAgrgcg");
	var mask_graphics_105 = new cjs.Graphics().p("AJxG0QhCgsgqhXQgphWAGhQQAIhPAzgZIP4npQA0gZBCAsQBCAsAqBXQAqBXgHBOQgHBQg0AZIv3HpQgTAJgUAAQglAAgrgcg");
	var mask_graphics_106 = new cjs.Graphics().p("AKbG2QhCgrgqhXQgqhXAGhQQAIhPA0gZIP6ntQA0gZBDAsQBDAsAqBWQAqBXgIBPQgGBQg0AZIv7HtQgTAJgVAAQgkAAgrgcg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(73).to({graphics:mask_graphics_73,x:123.12,y:33.3615}).wait(1).to({graphics:mask_graphics_74,x:124.164,y:33.4781}).wait(1).to({graphics:mask_graphics_75,x:125.3977,y:33.614}).wait(1).to({graphics:mask_graphics_76,x:126.8244,y:33.7693}).wait(1).to({graphics:mask_graphics_77,x:128.4467,y:33.9439}).wait(1).to({graphics:mask_graphics_78,x:130.2651,y:34.1374}).wait(1).to({graphics:mask_graphics_79,x:132.2773,y:34.3488}).wait(1).to({graphics:mask_graphics_80,x:134.4771,y:34.5772}).wait(1).to({graphics:mask_graphics_81,x:136.8537,y:34.8208}).wait(1).to({graphics:mask_graphics_82,x:139.3907,y:35.0777}).wait(1).to({graphics:mask_graphics_83,x:142.0661,y:35.3454}).wait(1).to({graphics:mask_graphics_84,x:144.8517,y:35.6212}).wait(1).to({graphics:mask_graphics_85,x:147.7143,y:35.902}).wait(1).to({graphics:mask_graphics_86,x:150.6164,y:36.1848}).wait(1).to({graphics:mask_graphics_87,x:153.5183,y:36.4662}).wait(1).to({graphics:mask_graphics_88,x:156.3798,y:36.7434}).wait(1).to({graphics:mask_graphics_89,x:159.163,y:37.0136}).wait(1).to({graphics:mask_graphics_90,x:161.8342,y:37.2744}).wait(1).to({graphics:mask_graphics_91,x:164.3651,y:37.5238}).wait(1).to({graphics:mask_graphics_92,x:166.7342,y:37.76}).wait(1).to({graphics:mask_graphics_93,x:168.9267,y:37.982}).wait(1).to({graphics:mask_graphics_94,x:170.9338,y:38.1888}).wait(1).to({graphics:mask_graphics_95,x:172.7527,y:37.8331}).wait(1).to({graphics:mask_graphics_96,x:174.3846,y:37.0111}).wait(1).to({graphics:mask_graphics_97,x:175.8343,y:36.2324}).wait(1).to({graphics:mask_graphics_98,x:177.1089,y:35.5083}).wait(1).to({graphics:mask_graphics_99,x:178.217,y:34.8472}).wait(1).to({graphics:mask_graphics_100,x:179.1678,y:34.2555}).wait(1).to({graphics:mask_graphics_101,x:179.9709,y:33.7374}).wait(1).to({graphics:mask_graphics_102,x:180.6358,y:33.2954}).wait(1).to({graphics:mask_graphics_103,x:181.1713,y:32.9305}).wait(1).to({graphics:mask_graphics_104,x:181.5857,y:32.6425}).wait(1).to({graphics:mask_graphics_105,x:181.8868,y:32.4302}).wait(1).to({graphics:mask_graphics_106,x:186.4419,y:28.1818}).wait(2));

	// Layer_12
	this.instance = new lib.squiggle_line();
	this.instance.setTransform(176.45,5.8,1.3604,1.3604,-0.0096,0,0,127.2,31.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(73).to({_off:false},0).wait(35));

	// Layer_3 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_46 = new cjs.Graphics().p("AIYCCIhrgJQgGgBACg8QABg7AIhTQAHhUAJg7QAJg7AGABIBrAJQAFAAgBA8QgCA8gHBUQgHBTgKA6QgJA7gFAAIAAAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AIhCEIh+gMQgGAAABg9QABg7AIhTQAIhTALg8QAKg6AGAAIB+AMQAGABgBA7QgBA9gIBTQgIBTgLA6QgKA7gGAAIAAAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AIrCHIiUgQQgHgBABg8QABg6AJhUQAJhTALg8QAMg6AHABICUAQQAIAAgBA8QgBA8gJBUQgJBSgMA7QgLA6gIAAIAAAAg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AI3CLIitgVQgJgBABg8QAAg7AKhTQAKhTANg7QANg6AJABICuAUQAJABgBA7QgBA9gJBTQgKBTgOA6QgNA6gIAAIgBAAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AJFCPIjLgaQgKgBAAg9QABg6AKhUQALhTAPg6QAPg6ALABIDLAbQAKABAAA8QgBA8gKBTQgLBTgPA5QgPA5gKAAIgBAAg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AJVCWIjsgiQgMgCAAg9QAAg6AMhTQAMhTARg6QARg6AMACIDsAiQAMACAAA7QAAA9gMBTQgMBSgRA5QgRA5gLAAIgBAAg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AJmCeIkRgsQgNgCgBg9QAAg7ANhSQANhTAUg6QATg4AOACIERAsQANACABA8QAAA8gNBTQgNBSgUA5QgSA3gOAAIgBAAg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AJ5CoIk5g3QgQgDgBg9QAAg7AOhTQAPhSAWg5QAWg4APADIE5A3QAQADABA8QABA9gPBTQgOBRgWA4QgVA2gPAAIgCAAg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AKOC1IllhGQgSgEgBg9QgBg7AQhSQAQhTAZg4QAYg3ASAEIFkBGQASAEACA8QABA9gQBSQgQBRgZA4QgXA0gRAAIgCAAg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AKjDFImShYQgUgFgCg9QgCg8AShSQAShRAbg3QAbg3AVAFIGSBYQAVAEABA9QACA9gSBRQgSBSgbA2QgZAzgUAAIgDAAg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AK6DYInDhtQgWgGgDg+QgCg8AThRQAUhRAeg2QAfg1AXAFIHCBtQAXAGADA9QACA+gUBQQgTBRgfA1QgbAxgVAAIgFAAg");
	var mask_1_graphics_57 = new cjs.Graphics().p("ALSDuIn1iGQgagHgCg+QgDg8AVhRQAWhRAhg0QAhg0AaAHIH1CFQAaAHACA9QADA/gVBPQgWBRghA0QgeAugXAAIgGAAg");
	var mask_1_graphics_58 = new cjs.Graphics().p("ALqEHIooihQgcgIgEg/QgDg9AXhQQAYhQAkg0QAlgyAcAIIIpCiQAcAIADA+QADA+gXBQQgXBQglAyQgfAsgaAAIgIgBg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AMDEgIpcjBQgfgKgEg/QgEg+AZhPQAahPAngyQAogxAfAKIJcDBQAfAKAEA+QAEA/gZBPQgaBPgnAxQgiAqgbAAQgFAAgFgCg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AMbEvIqPjjQgigLgEhBQgEg+AbhPQAbhOArgwQArgvAhAMIKQDjQAiALAEBAQAEA/gbBPQgbBOgrAvQgjAngcAAQgHAAgHgDg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AMzFAIrCkIQgkgOgEhAQgFhAAdhOQAdhOAuguQAugtAkAOILCEIQAkAOAFA/QAFBBgdBOQgeBOguAtQgjAjgeAAQgJAAgIgDg");
	var mask_1_graphics_62 = new cjs.Graphics().p("ANKFSIrykwQgmgQgFhBQgGhBAfhNQAfhMAygsQAxgrAmAPILyEwQAnAQAFBAQAFBCgfBNQgfBMgxArQglAhgeAAQgLAAgKgEg");
	var mask_1_graphics_63 = new cjs.Graphics().p("ANgFkIsglZQgogRgGhCQgGhCAhhMQAhhMA0gqQA0gpApASIMgFZQAoARAGBCQAGBCghBMQghBMg0ApQglAegfAAQgNAAgMgGg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AN0F3ItKmCQgqgUgGhEQgGhCAihLQAjhMA2gnQA3gnArAUINKGCQArAUAGBDQAGBDgiBMQgjBLg3AmQglAbgfAAQgQAAgOgHg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AOHGKItxmsQgsgWgGhFQgHhEAkhKQAkhKA5gmQA6gkAtAWINxGtQAtAVAGBEQAGBFgkBKQgkBKg6AlQgkAXgfAAQgTAAgQgIg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AOYGdIuVnWQgugYgGhGQgGhEAlhKQAlhJA8gkQA8giAvAYIOUHWQAvAYAHBFQAGBGgmBJQglBJg8AjQgkAVgfAAQgVAAgTgKg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AOnGvIuzn+QgxgbgGhGQgHhFAnhJQAmhIA+giQA+ggAxAaIO1H/QAwAaAGBFQAHBHgnBIQgnBJg+AgQgjATgfAAQgXAAgWgMg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AO1HBIvQomQgygcgHhHQgGhGAohIQAohIA/gfQBAgfAyAdIPSIlQAxAcAHBGQAHBHgpBIQgoBIhAAeQgiARgeAAQgaAAgYgNg");
	var mask_1_graphics_69 = new cjs.Graphics().p("APBHRIvppKQgzgegHhIQgHhHAqhHQAphHBBgdQBCgdAzAeIPqJKQAzAeAHBHQAHBIgqBHQgpBHhCAcQghAPgdAAQgdAAgagPg");
	var mask_1_graphics_70 = new cjs.Graphics().p("APMHgIv/prQg1gggGhJQgHhHAqhHQArhGBCgcQBDgbA1AgIQAJrQA0AgAHBIQAHBJgrBGQgrBGhDAbQgfANgdAAQgfAAgcgRg");
	var mask_1_graphics_71 = new cjs.Graphics().p("APVHuIwSqKQg1ghgHhKQgHhIAshGQArhFBDgbQBFgZA1AhIQTKKQA1AiAHBIQAHBJgrBGQgsBGhEAZQgfAMgbAAQgiAAgegTg");
	var mask_1_graphics_72 = new cjs.Graphics().p("APdH7IwiqmQg2gjgHhKQgHhJAshFQAshFBFgZQBGgYA2AjIQjKmQA2AiAHBJQAHBKgtBFQgsBFhGAYQgdALgaAAQglAAgfgUg");
	var mask_1_graphics_73 = new cjs.Graphics().p("APjIGIwvq/Qg3gkgHhKQgHhKAthEQAthFBGgYQBHgWA2AkIQxK+QA3AkAGBJQAHBLgtBFQgtBEhGAXQgcAJgaAAQgnAAghgVg");
	var mask_1_graphics_74 = new cjs.Graphics().p("APpIPIw7rTQg3glgHhLQgHhKAthEQAuhFBGgWQBIgWA3AlIQ8LUQA3AlAHBKQAHBLgtBEQguBEhHAWQgcAIgYAAQgpAAgigXg");
	var mask_1_graphics_75 = new cjs.Graphics().p("APtIXIxErlQg4gmgGhLQgHhLAuhEQAuhDBHgWQBIgVA4AmIRFLmQA4AlAHBLQAHBLgvBEQguBEhIAUQgaAIgYAAQgqAAgkgYg");
	var mask_1_graphics_76 = new cjs.Graphics().p("APxIeIxMr0Qg4gngHhMQgGhKAuhEQAvhDBHgVQBJgUA4AmIRNL1QA4AmAGBLQAHBMguBDQgvBEhIAUQgaAHgYAAQgrAAgkgZg");
	var mask_1_graphics_77 = new cjs.Graphics().p("AP0IjIxRr/Qg5gogHhMQgGhLAuhDQAvhDBIgVQBJgTA5AnIRSMAQA4AnAHBLQAHBMgvBDQgvBEhJATQgZAHgXAAQgsAAglgag");
	var mask_1_graphics_78 = new cjs.Graphics().p("AP2InIxVsIQg5gogHhMQgHhLAvhDQAvhDBJgUQBJgTA5AoIRWMIQA4AnAHBLQAHBMgvBEQgvBDhJATQgZAGgXAAQgtAAglgag");
	var mask_1_graphics_79 = new cjs.Graphics().p("AP+IpIxYsNQg5gogHhMQgHhLAwhDQAvhDBIgUQBKgTA5AoIRYMOQA5AoAHBLQAHBMgvBDQgvBDhKATQgZAGgWAAQgtAAgmgbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(46).to({graphics:mask_1_graphics_46,x:57.6152,y:-28.4435}).wait(1).to({graphics:mask_1_graphics_47,x:58.9285,y:-28.4712}).wait(1).to({graphics:mask_1_graphics_48,x:60.4884,y:-28.5013}).wait(1).to({graphics:mask_1_graphics_49,x:62.3019,y:-28.5329}).wait(1).to({graphics:mask_1_graphics_50,x:64.3733,y:-28.5644}).wait(1).to({graphics:mask_1_graphics_51,x:66.7036,y:-28.5942}).wait(1).to({graphics:mask_1_graphics_52,x:69.2893,y:-28.6202}).wait(1).to({graphics:mask_1_graphics_53,x:72.1211,y:-28.6403}).wait(1).to({graphics:mask_1_graphics_54,x:75.1834,y:-28.6524}).wait(1).to({graphics:mask_1_graphics_55,x:78.4527,y:-28.6545}).wait(1).to({graphics:mask_1_graphics_56,x:81.8977,y:-28.6447}).wait(1).to({graphics:mask_1_graphics_57,x:85.4787,y:-28.6217}).wait(1).to({graphics:mask_1_graphics_58,x:89.1491,y:-28.5851}).wait(1).to({graphics:mask_1_graphics_59,x:92.8565,y:-28.1087}).wait(1).to({graphics:mask_1_graphics_60,x:96.5461,y:-26.3757}).wait(1).to({graphics:mask_1_graphics_61,x:100.1631,y:-24.4772}).wait(1).to({graphics:mask_1_graphics_62,x:103.6566,y:-22.4415}).wait(1).to({graphics:mask_1_graphics_63,x:106.9822,y:-20.3037}).wait(1).to({graphics:mask_1_graphics_64,x:110.1046,y:-18.103}).wait(1).to({graphics:mask_1_graphics_65,x:112.9982,y:-15.8804}).wait(1).to({graphics:mask_1_graphics_66,x:115.6471,y:-13.6759}).wait(1).to({graphics:mask_1_graphics_67,x:118.0449,y:-11.5263}).wait(1).to({graphics:mask_1_graphics_68,x:120.1925,y:-9.4641}).wait(1).to({graphics:mask_1_graphics_69,x:122.0967,y:-7.5167}).wait(1).to({graphics:mask_1_graphics_70,x:123.7687,y:-5.7057}).wait(1).to({graphics:mask_1_graphics_71,x:125.2221,y:-4.0476}).wait(1).to({graphics:mask_1_graphics_72,x:126.4719,y:-2.554}).wait(1).to({graphics:mask_1_graphics_73,x:127.5335,y:-1.2322}).wait(1).to({graphics:mask_1_graphics_74,x:128.4218,y:-0.0859}).wait(1).to({graphics:mask_1_graphics_75,x:129.1509,y:0.8841}).wait(1).to({graphics:mask_1_graphics_76,x:129.7338,y:1.6793}).wait(1).to({graphics:mask_1_graphics_77,x:130.1818,y:2.3032}).wait(1).to({graphics:mask_1_graphics_78,x:130.5053,y:2.7606}).wait(1).to({graphics:mask_1_graphics_79,x:131.3736,y:4.096}).wait(29));

	// Layer_11
	this.instance_1 = new lib.squiggle_line();
	this.instance_1.setTransform(176.45,5.8,1.3604,1.3604,-0.0096,0,0,127.2,31.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(46).to({_off:false},0).wait(62));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_7 = new cjs.Graphics().p("AApBmQgbgjgkgzQglgygYglQgZglACgBIAlgaQACgCAbAjQAbAkAkAzQAlAyAYAkQAZAmgCABIglAaIAAAAQgDAAgagig");
	var mask_2_graphics_8 = new cjs.Graphics().p("AApBmQgbgigkgzQglgygZgmQgYglACgBIAlgbQACgBAbAjQAbAjAkAzQAlAyAYAlQAZAmgCABIglAbIAAAAQgDAAgagjg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AAoBnQgbgjgkgzQgkgygZglQgZglACgCIAngbQACgBAbAjQAbAjAkAzQAkAyAZAlQAZAlgCACIgnAbIAAAAQgDAAgagig");
	var mask_2_graphics_10 = new cjs.Graphics().p("AAnBoQgbgjgkgzQglgygYgmQgZgkACgCIApgdQACgBAbAjQAbAjAkAzQAlAyAYAlQAZAlgDACIgoAdIAAAAQgDAAgagig");
	var mask_2_graphics_11 = new cjs.Graphics().p("AAlBpQgbgjgkgzQgkgygZglQgYglACgCIArgfQACgBAbAjQAcAjAkAzQAkAyAYAlQAZAlgCACIgrAfIAAAAQgDAAgbgig");
	var mask_2_graphics_12 = new cjs.Graphics().p("AAjBqQgbgigkgzQgkgygZgmQgYglADgCIAughQACgCAcAjQAbAjAkAzQAkAyAYAmQAZAlgDACIguAhIAAAAQgEAAgagig");
	var mask_2_graphics_13 = new cjs.Graphics().p("AAgBsQgbgigkgzQgkgzgYglQgYgmADgBIAyglQADgBAbAiQAcAjAkAzQAkAzAYAlQAYAmgDABIgyAlIgBAAQgDAAgbgig");
	var mask_2_graphics_14 = new cjs.Graphics().p("AAdBvQgcgjgjgzQgkgygYgmQgYgmADgCIA4goQADgCAcAjQAcAjAjAzQAkAyAYAmQAYAmgDACIg4AoIAAAAQgEAAgbghg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AAZBxQgbgigkg0QgkgygYgmQgXgmADgCIA+gsQAEgCAbAiQAcAjAkA0QAkAyAXAlQAYAngDACIg+AsIgBAAQgEAAgbghg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AAVB0QgbgigkgzQglgzgXgmQgXgmAEgCIBFgyQAEgCAcAiQAbAjAkAzQAlAzAWAmQAYAmgEACIhFAyIgBAAQgFAAgaghg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AAQB4QgbgjglgzQgkgygXgnQgWgmAEgDIBOg2QAEgDAcAiQAbAjAlAzQAkAyAWAmQAXAngEADIhOA2IAAABQgGAAgaggg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AAKB7QgbgigkgzQgkgzgXgmQgWgnAFgDIBXg9QAEgDAdAiQAbAjAkAzQAkAzAWAmQAXAngFADIhXA9IgBAAQgGAAgaggg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AAECAQgcgigkg0QgkgygWgoQgVgmAFgEIBhhEQAFgDAdAiQAcAiAkA0QAkAyAVAnQAWAngFAEIhhBEIgBAAQgHAAgagfg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AgDCEQgdghgjg0QgkgzgVgnQgVgnAFgEIBuhMQAFgDAcAhQAeAiAjA0QAkAzAVAnQAVAngFAEIhuBMIgBAAQgHAAgagfg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AgLCJQgdghgjg0Qgkg0gVgnQgUgnAGgEIB7hUQAGgEAcAhQAeAiAjA0QAkAzAUAnQAVAogGAEIh6BUIgCABQgIAAgagfg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AgTCPQgeghgjg0Qgjg0gVgoQgUgnAHgFICJhdQAHgFAdAiQAeAhAjA0QAjA0AUAnQAVAogHAFIiJBdIgCABQgJAAgZgeg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AgdCVQgeghgjg0Qgjg0gUgoQgTgoAIgGICZhmQAHgFAdAhQAfAhAjA0QAjA0ATAoQAUAogIAGIiYBmIgDABQgIAAgbgdg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AgnCbQgfgggjg1Qgig0gTgoQgTgpAJgGICphxQAIgFAfAgQAfAhAjA1QAiA0ATAoQATApgJAGIipBxIgDABQgKAAgagdg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AgzCiQgfgggig1Qgjg0gSgpQgRgpAJgHIC8h8QAJgGAfAgQAgAhAiA1QAjA0ARAoQASAqgJAHIi8B8IgDABQgLAAgbgcg");
	var mask_2_graphics_26 = new cjs.Graphics().p("Ag/CpQgggggig0Qgig1gRgpQgRgqALgHIDPiIQALgHAgAgQAgAhAiA0QAiA1ARApQARAqgLAHIjPCIIgFABQgMAAgagbg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AhMCxQgggggig1Qgig0gQgqQgQgrAMgHIDliVQAMgHAgAgQAhAgAiA1QAiA0APAqQAQArgMAHIjlCVQgCABgDAAQgNAAgagag");
	var mask_2_graphics_28 = new cjs.Graphics().p("AhbC5Qghggghg0Qgig1gPgsQgOgqANgIID9iiQANgIAgAgQAiAgAhA0QAiA1AOAsQAPAqgNAIIj8CiQgDABgEAAQgNAAgbgZg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AhqDBQgigfghg1Qghg1gOgsQgNgrAOgJIEWivQAOgJAiAfQAiAgAhA1QAhA1AOAsQAOArgPAJIkWCvQgDACgEAAQgPAAgagZg");
	var mask_2_graphics_30 = new cjs.Graphics().p("Ah7DKQgigfghg1Qghg2gNgsQgMgsAQgKIEyi9QAPgJAjAeQAiAgAhA1QAhA2AMAsQANAsgQAKIkyC9QgDACgFAAQgPAAgbgYg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AiNDTQgjgeggg2Qghg2gLgtQgLgsARgLIFPjMQARgKAjAeQAkAfAgA2QAhA2ALAtQALAsgRALIlPDMQgEACgGAAQgQAAgbgXg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AigDcQgjgeghg2Qggg2gKguQgJgtATgLIFujbQATgLAjAeQAlAfAgA2QAgA2AJAtQAKAugTALIluDbQgFADgGAAQgRAAgbgXg");
	var mask_2_graphics_33 = new cjs.Graphics().p("Ai0DmQgkgeggg2Qggg2gIgvQgIguAUgMIGPjqQAVgMAlAeQAlAeAfA2QAgA2AIAvQAIAugUAMImPDqQgGADgHAAQgSAAgbgVg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AjJDvQgmgdgfg2Qgfg3gHgwQgGgvAWgMIGyj5QAWgNAmAdQAmAeAfA2QAgA3AGAvQAGAwgWAMImyD5QgGAEgJAAQgSAAgbgVg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AjgD5Qgmgdgfg3Qgfg2gFgxQgEgwAYgOIHXkIQAYgNAnAcQAnAeAeA3QAfA2AFAwQAFAxgYANInXEJQgIAEgJAAQgUAAgbgUg");
	var mask_2_graphics_36 = new cjs.Graphics().p("Aj3EDQgogdgeg3Qgeg3gEgxQgCgxAagOIH+kYQAagPAnAdQAoAdAfA3QAeA3ADAxQADAxgaAOIn+EYQgJAFgKAAQgUAAgbgTg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AkQEMQgpgcgdg3Qgeg3gCgzQAAgxAcgPIImkoQAcgPApAcQApAdAeA3QAeA4ABAxQABAygcAPIonEoQgJAFgMAAQgVAAgbgTg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AkqEWQgpgcgeg4Qgdg3ABgzQABgzAegQIJRk2QAegQAqAcQAqAcAdA4QAdA3gBAzQAAAzgeAQIpRE2QgLAGgMAAQgWAAgcgSg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AlEEfQgrgcgdg4Qgcg4ACgzQADgzAhgRIJ8lFQAggRArAcQAsAcAcA4QAdA4gDAzQgDAzggARIp8FFQgMAGgOAAQgXAAgbgRg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AlfEnQgsgbgcg4Qgcg4AEg0QAFg0AjgSIKolTQAjgRAsAbQAtAcAcA4QAcA4gFA0QgFA0giASIqpFTQgNAGgPAAQgYAAgbgRg");
	var mask_2_graphics_41 = new cjs.Graphics().p("Al6EwQgugbgbg5Qgcg4AHg1QAHg1AlgSILVlgQAlgSAtAbQAuAbAcA5QAbA4gHA1QgGA1glASIrVFgQgPAHgQAAQgZAAgbgQg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AmWE3Qgugbgbg4Qgbg5AIg2QAKg1AngSIMCltQAngSAuAaQAwAcAbA4QAaA5gJA1QgIA2gnATIsCFsQgQAHgRAAQgaAAgcgQg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AmxE+Qgvgagbg5Qgag5AKg3QAMg1ApgUIMul3QAqgTAvAbQAxAbAaA4QAaA5gLA2QgKA2gqAUIsuF3QgRAIgSAAQgaAAgdgQg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AnLFEQgxgagag5QgZg5AMg3QANg3AsgTINZmBQAsgUAxAaQAxAbAaA5QAaA6gNA2QgNA3grATItaGCQgSAIgUAAQgaAAgdgQg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AnkFKQgygagag6QgZg5AOg4QAPg2AugUIODmKQAugVAyAbQAzAaAZA6QAZA5gPA3QgOA3guAVIuDGJQgUAJgUAAQgbAAgdgPg");
	var mask_2_graphics_46 = new cjs.Graphics().p("An8FPQgzgagZg6QgZg6AQg3QARg4AwgUIOqmSQAwgUAzAaQA0AbAYA5QAZA6gRA3QgQA4gwAUIuqGSQgVAJgVAAQgcAAgdgPg");
	var mask_2_graphics_47 = new cjs.Graphics().p("AoTFTQg0gagYg6QgYg6ARg4QATg4AygUIPOmYQAygVA0AaQA1AaAYA6QAZA6gTA4QgSA4gxAVIvPGXQgWAKgXAAQgcAAgegPg");
	var mask_2_graphics_48 = new cjs.Graphics().p("AonFWQg1gagYg6QgYg6AUg4QAUg4AzgVIPwmdQA0gWA0AaQA2AbAYA6QAYA6gUA4QgTA4g0AVIvwGdQgXAKgXAAQgdAAgegPg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(7).to({graphics:mask_2_graphics_7,x:-4.6488,y:3.7495}).wait(1).to({graphics:mask_2_graphics_8,x:-4.6239,y:3.7346}).wait(1).to({graphics:mask_2_graphics_9,x:-4.5477,y:3.689}).wait(1).to({graphics:mask_2_graphics_10,x:-4.4183,y:3.6118}).wait(1).to({graphics:mask_2_graphics_11,x:-4.2337,y:3.5019}).wait(1).to({graphics:mask_2_graphics_12,x:-3.9918,y:3.3585}).wait(1).to({graphics:mask_2_graphics_13,x:-3.69,y:3.1805}).wait(1).to({graphics:mask_2_graphics_14,x:-3.3259,y:2.967}).wait(1).to({graphics:mask_2_graphics_15,x:-2.8967,y:2.7172}).wait(1).to({graphics:mask_2_graphics_16,x:-2.3996,y:2.4303}).wait(1).to({graphics:mask_2_graphics_17,x:-1.8314,y:2.1054}).wait(1).to({graphics:mask_2_graphics_18,x:-1.1887,y:1.7421}).wait(1).to({graphics:mask_2_graphics_19,x:-0.4681,y:1.3398}).wait(1).to({graphics:mask_2_graphics_20,x:0.3343,y:0.8981}).wait(1).to({graphics:mask_2_graphics_21,x:1.2224,y:0.4167}).wait(1).to({graphics:mask_2_graphics_22,x:2.2004,y:-0.1043}).wait(1).to({graphics:mask_2_graphics_23,x:3.2727,y:-0.6647}).wait(1).to({graphics:mask_2_graphics_24,x:4.4439,y:-1.2641}).wait(1).to({graphics:mask_2_graphics_25,x:5.7186,y:-1.9017}).wait(1).to({graphics:mask_2_graphics_26,x:7.1017,y:-2.5762}).wait(1).to({graphics:mask_2_graphics_27,x:8.5981,y:-3.286}).wait(1).to({graphics:mask_2_graphics_28,x:10.2123,y:-4.0291}).wait(1).to({graphics:mask_2_graphics_29,x:11.9489,y:-4.8027}).wait(1).to({graphics:mask_2_graphics_30,x:13.8119,y:-5.6034}).wait(1).to({graphics:mask_2_graphics_31,x:15.8049,y:-6.4272}).wait(1).to({graphics:mask_2_graphics_32,x:17.9303,y:-7.2692}).wait(1).to({graphics:mask_2_graphics_33,x:20.1893,y:-8.1237}).wait(1).to({graphics:mask_2_graphics_34,x:22.5813,y:-8.9841}).wait(1).to({graphics:mask_2_graphics_35,x:25.1035,y:-9.8428}).wait(1).to({graphics:mask_2_graphics_36,x:27.7502,y:-10.6917}).wait(1).to({graphics:mask_2_graphics_37,x:30.5122,y:-11.5217}).wait(1).to({graphics:mask_2_graphics_38,x:33.3796,y:-12.3235}).wait(1).to({graphics:mask_2_graphics_39,x:36.3365,y:-13.0876}).wait(1).to({graphics:mask_2_graphics_40,x:39.3551,y:-13.8047}).wait(1).to({graphics:mask_2_graphics_41,x:42.4075,y:-14.4665}).wait(1).to({graphics:mask_2_graphics_42,x:45.4612,y:-15.0662}).wait(1).to({graphics:mask_2_graphics_43,x:48.4799,y:-15.5985}).wait(1).to({graphics:mask_2_graphics_44,x:51.4247,y:-16.061}).wait(1).to({graphics:mask_2_graphics_45,x:54.256,y:-16.4534}).wait(1).to({graphics:mask_2_graphics_46,x:56.9353,y:-16.7783}).wait(1).to({graphics:mask_2_graphics_47,x:59.4271,y:-17.0403}).wait(1).to({graphics:mask_2_graphics_48,x:57.1166,y:-15.2156}).wait(60));

	// Layer_5
	this.instance_2 = new lib.squiggle_line();
	this.instance_2.setTransform(176.45,5.8,1.3604,1.3604,-0.0096,0,0,127.2,31.1);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(7).to({_off:false},0).wait(101));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-39.9,353,91.6);


(lib.letter = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.letter.cache(0,0,110,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.letter = new lib.letter_sub();
	this.letter.name = "letter";
	this.letter.setTransform(51.5,36,1,1,0,0,0,51.5,36);

	this.timeline.addTween(cjs.Tween.get(this.letter).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letter, new cjs.Rectangle(0,0,102.9,72.1), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.gridpiece();
	this.instance.setTransform(384.6,468.7,1.47,1.47,90,0,0,125.8,52.4);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(208.5,468.7,1.47,1.47,90,0,0,125.8,52.4);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(304.35,546.2,1.47,1.47,0,0,0,125.8,52.6);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(304.35,369.9,1.47,1.47,0,0,0,125.8,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(118.7,283.1,358,357.9), null);


(lib.file3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.BudgetMeeting_lg();
	this.instance.setTransform(6.65,8.8,0.7004,0.7004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(62.1,89.75,0.4698,0.7124,0,0,0,98,101.6);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file3, new cjs.Rectangle(4,4.8,113,160), null);


(lib.MSFT_Logo_anim_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms1.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms1 = new lib.ms_1();
	this.ms1.name = "ms1";
	this.ms1.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_1, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_98 = function() {
		this.stop()
		//exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(33).call(this.frame_98).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSVBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgSoBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgThBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVBBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXGBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZyBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdDBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggVBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjABK7IAAwoMBbtAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglGBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmlBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgneBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("EgnxBK7IAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.6789,y:479.5095}).wait(1).to({graphics:mask_graphics_15,x:467.773,y:479.5095}).wait(1).to({graphics:mask_graphics_16,x:462.0553,y:479.5095}).wait(1).to({graphics:mask_graphics_17,x:452.5258,y:479.5095}).wait(1).to({graphics:mask_graphics_18,x:439.1845,y:479.5095}).wait(1).to({graphics:mask_graphics_19,x:422.0313,y:479.5095}).wait(1).to({graphics:mask_graphics_20,x:401.0664,y:479.5095}).wait(1).to({graphics:mask_graphics_21,x:380.1015,y:479.5095}).wait(1).to({graphics:mask_graphics_22,x:362.9483,y:479.5095}).wait(1).to({graphics:mask_graphics_23,x:349.607,y:479.5095}).wait(1).to({graphics:mask_graphics_24,x:340.0775,y:479.5095}).wait(1).to({graphics:mask_graphics_25,x:334.3598,y:479.5095}).wait(1).to({graphics:mask_graphics_26,x:332.4539,y:479.5095}).wait(1).to({graphics:null,x:0,y:0}).wait(72));

	// logo text
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-131.7,900.05,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	this.instance_1 = new lib.MSFT_Logo_anim_1();
	this.instance_1.setTransform(39.6,58.5,2.4059,2.4059,0,0,0,0.1,0.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance}]},12).to({state:[{t:this.instance}]},39).to({state:[{t:this.instance_1}]},33).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.7},12,cjs.Ease.quadInOut).wait(39).to({_off:true,regY:0.5,scaleX:2.4059,scaleY:2.4059,x:39.6,y:58.5},33,cjs.Ease.cubicInOut).wait(1));

	// widows icon
	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(299.1,905.95,0.2981,0.2981,0,0,0,-39.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:299.05},14,cjs.Ease.quadOut).to({x:24.8},12,cjs.Ease.quadInOut).to({_off:true},1).wait(72));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(301.4796,905.1707,1,2.3542);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(301.45,344.45);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,978.8,1949.6);


(lib.calendar_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.calendar.cache(0,0,110,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.calendar = new lib.calendar_sub();
	this.calendar.name = "calendar";
	this.calendar.setTransform(53.7,49.5,1,1,0,0,0,53.7,49.5);

	this.timeline.addTween(cjs.Tween.get(this.calendar).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.calendar_icon, new cjs.Rectangle(0,0,107.5,99), null);


(lib.bang_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bang.cache(-60,-60,120,120,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bang = new lib.bang_sub();
	this.bang.name = "bang";
	this.bang.setTransform(20.5,21,1,1,0,0,0,20.5,21);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_icon, new cjs.Rectangle(-1,-1,43,44), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AjOGEQiihkgri5QgqivBYiaIAKgRIMNHiIgKARQhkCTiwAqQg4ANg2AAQh7AAhxhGg");
	var mask_graphics_1 = new cjs.Graphics().p("Aj0FYQiQh9gNi+QgMizBwiKIANgPIKzJbIgNAOQh6CCi0AMIgjABQinAAiChxg");
	var mask_graphics_2 = new cjs.Graphics().p("AAoHHQi9gSh5iTQh5iTASi8QASi0CFh2IAPgNIJHLEIgPANQh6BdiWAAQgYAAgZgDg");
	var mask_graphics_3 = new cjs.Graphics().p("AgCG5Qi4gxhfikQhgilAxi3QAvivCWheIARgKIHMMaIgRAKQhlA1hsAAQg8AAg+gRg");
	var mask_graphics_4 = new cjs.Graphics().p("AgnGgQithOhEiyQhDixBOiuQBLilCkhEIASgIIFENbIgSAHQhJAYhIAAQhfAAhdgqg");
	var mask_graphics_5 = new cjs.Graphics().p("AhFF8Qiehpgli7Qgmi6BqieQBkiXCsgoIATgFIC0OEIgTAEQgmAGgmAAQiEAAh1hOg");
	var mask_graphics_6 = new cjs.Graphics().p("AhbFPQiLiCgGi+QgGi9CBiLQB7iECxgMIAUgCIAeOWIgTABQiygBiDh8g");
	var mask_graphics_7 = new cjs.Graphics().p("AB5HHQiugehuiPQh0iXAYi8QAZi9CXhzQCPhvCxASIATACIh4OOIgTgDg");
	var mask_graphics_8 = new cjs.Graphics().p("AAMG9Qing6hWigQhZioA3i1QA3i2CohaQCfhVCrAuIATAFIkLNuIgSgFg");
	var mask_graphics_9 = new cjs.Graphics().p("AhbGsQichVg6irQg+izBVirQBUirC0g9QCqg6CjBJIARAIImWM3IgRgIg");
	var mask_graphics_10 = new cjs.Graphics().p("Ai7GWQiMhtgdizQgfi7BviaQBvibC7gfQCygdCUBjIAQAKIoXLqIgQgLg");
	var mask_graphics_11 = new cjs.Graphics().p("AkPF7Qh5iCABi1QAAi9CHiHQCGiGC+AAQC1AACBB6IAOANIqJKIIgOgOg");
	var mask_graphics_12 = new cjs.Graphics().p("AlVFdQhiiUAeizQAfi6CbhvQCbhvC7AgQCyAdBsCNIAMAQIrrIVIgLgQg");
	var mask_graphics_13 = new cjs.Graphics().p("AmME8QhIiiA6irQA+i0CrhUQCrhTCzA9QCrA6BUCdIAJARIs4GUIgJgRg");
	var mask_graphics_14 = new cjs.Graphics().p("AmyEYQgtisBWieQBaioC2g2QC1g3CoBaQCfBVA5CoIAGASItuEJIgGgTg");
	var mask_graphics_15 = new cjs.Graphics().p("AnHDzQgQixBuiOQB1iWC8gZQC8gYCXB0QCPBuAdCvIADATIuOB2IgDgUg");
	var mask_graphics_16 = new cjs.Graphics().p("AnKDRIAAgTQANiyCFh6QCLiBC9AGQC/AHCBCLQB7CEAACyIAAATg");
	var mask_graphics_17 = new cjs.Graphics().p("AnGBhIAEgTQApirCXhkQCfhqC5AmQC7AmBpCfQBkCVgdCwIgEATg");
	var mask_graphics_18 = new cjs.Graphics().p("Am8gKIAHgSQBFijClhKQCuhOCxBDQCyBEBOCuQBKCkg6CoIgGASg");
	var mask_graphics_19 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_20 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_21 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_22 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_23 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_24 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_25 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_26 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_27 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_28 = new cjs.Graphics().p("AmshwIAKgRQBfiWCvguQC3gxCkBgQClBgAxC3QAuCvhVCcIgJARg");
	var mask_graphics_29 = new cjs.Graphics().p("AmthsIAKgRQBeiXCvgvQC2gyClBfQCmBfAxC3QAwCuhTCdIgJARg");
	var mask_graphics_30 = new cjs.Graphics().p("AmvheIAJgRQBaiZCugzQC1g2CoBaQCnBbA2C2QA0CthQCfIgJARg");
	var mask_graphics_31 = new cjs.Graphics().p("Am0hDIAJgSQBTidCrg7QCzg9CrBTQCsBTA+C0QA6CqhICjIgIARg");
	var mask_graphics_32 = new cjs.Graphics().p("Am6gZIAHgSQBJiiCnhHQCvhJCwBHQCwBIBKCwQBGClg9CnIgHASg");
	var mask_graphics_33 = new cjs.Graphics().p("AnBAkIAFgTQA6inCfhWQCnhaC2A2QC2A3BaCoQBWCegtCsIgFATg");
	var mask_graphics_34 = new cjs.Graphics().p("AnIB7IADgTQAjitCThqQCahvC7AeQC8AeBvCbQBqCRgWCxIgDATg");
	var mask_graphics_35 = new cjs.Graphics().p("AnLDZQAEiyB+iAQCFiJC+gDQC+gDCICFQCCB9AJCyIABATIuWANIgBgTg");
	var mask_graphics_36 = new cjs.Graphics().p("Am7EMQgjiuBdiZQBjijC5gtQC4guCjBjQCaBeAwCqIAGATIt8DaIgFgTg");
	var mask_graphics_37 = new cjs.Graphics().p("Al5FJQhSieAwitQAyi4ClheQCmheC2AyQCvAwBdCXIAKAQIsdHHIgKgRg");
	var mask_graphics_38 = new cjs.Graphics().p("Aj1GFQh/h8gKi0QgKi9CAiOQB/iNC9gKQC1gKCIByIAPANIpmKqIgPgNg");
	var mask_graphics_39 = new cjs.Graphics().p("Ag3GyQihhLhEioQhHiwBKiuQBKiwCwhHQCnhECmBAIASAHIllNNIgSgIg");
	var mask_graphics_40 = new cjs.Graphics().p("ACVHJQivgXh0iKQh6iSARi9QARi+CSh6QCJh0CyAKIATABIhROTIgUgCg");
	var mask_graphics_41 = new cjs.Graphics().p("AhHF5Qidhsgii7Qgji6BsidQBniVCtgmIATgEICmOHIgTADQgkAGgiAAQiIAAh2hTg");
	var mask_graphics_42 = new cjs.Graphics().p("AgdGpQixhGhLivQhMivBHiwQBDioCghLIASgJIFqNLIgRAIQhSAghRAAQhWAAhUgjg");
	var mask_graphics_43 = new cjs.Graphics().p("AANHBQi6glhpieQhqieAli6QAjixCQhoIAQgLIH+L7IgQAKQhuBEh8AAQguAAgxgKg");
	var mask_graphics_44 = new cjs.Graphics().p("AA1HKQi9gJiAiNQiAiOAKi9QAIi0CAh8IAOgNIJoKnIgOANQh/BrikAAIgagBg");
	var mask_graphics_45 = new cjs.Graphics().p("Aj0FZQiQh9gNi+QgMizBwiKIANgPIKzJbIgNAPQh6CBi0AMIgjACQinAAiChyg");
	var mask_graphics_46 = new cjs.Graphics().p("AjgFzQibhvgei8QgdixBjiUIALgQILoIZIgLAPQhtCMizAdQgoAHgnAAQiNAAh5hYg");
	var mask_graphics_47 = new cjs.Graphics().p("AjOGEQiihkgri5QgqivBYiaIAKgRIMNHiIgKARQhkCTiwAqQg4ANg2AAQh7AAhxhGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:7.965,y:45.8021}).wait(1).to({graphics:mask_graphics_1,x:5.8912,y:45.7473}).wait(1).to({graphics:mask_graphics_2,x:3.3074,y:45.7505}).wait(1).to({graphics:mask_graphics_3,x:0.2956,y:45.8022}).wait(1).to({graphics:mask_graphics_4,x:-2.9989,y:45.8355}).wait(1).to({graphics:mask_graphics_5,x:-6.4732,y:45.8339}).wait(1).to({graphics:mask_graphics_6,x:-10.068,y:45.7067}).wait(1).to({graphics:mask_graphics_7,x:-7.7711,y:45.5416}).wait(1).to({graphics:mask_graphics_8,x:-4.0564,y:44.7951}).wait(1).to({graphics:mask_graphics_9,x:-0.5004,y:43.5091}).wait(1).to({graphics:mask_graphics_10,x:2.8068,y:41.697}).wait(1).to({graphics:mask_graphics_11,x:5.7321,y:39.3187}).wait(1).to({graphics:mask_graphics_12,x:8.1372,y:36.5061}).wait(1).to({graphics:mask_graphics_13,x:10.0161,y:33.3348}).wait(1).to({graphics:mask_graphics_14,x:11.3638,y:29.8897}).wait(1).to({graphics:mask_graphics_15,x:12.1396,y:26.2636}).wait(1).to({graphics:mask_graphics_16,x:12.3142,y:24.1922}).wait(1).to({graphics:mask_graphics_17,x:12.7218,y:27.972}).wait(1).to({graphics:mask_graphics_18,x:13.7112,y:31.6223}).wait(1).to({graphics:mask_graphics_19,x:15.0845,y:34.9414}).wait(1).to({graphics:mask_graphics_20,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_21,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_22,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_23,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_24,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_25,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_26,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_27,x:15.0845,y:34.9416}).wait(1).to({graphics:mask_graphics_28,x:15.0845,y:34.9414}).wait(1).to({graphics:mask_graphics_29,x:15.0057,y:34.7966}).wait(1).to({graphics:mask_graphics_30,x:14.7565,y:34.3221}).wait(1).to({graphics:mask_graphics_31,x:14.3277,y:33.4387}).wait(1).to({graphics:mask_graphics_32,x:13.7322,y:32.0332}).wait(1).to({graphics:mask_graphics_33,x:13.0281,y:29.9507}).wait(1).to({graphics:mask_graphics_34,x:12.3656,y:26.9955}).wait(1).to({graphics:mask_graphics_35,x:12.087,y:23.6405}).wait(1).to({graphics:mask_graphics_36,x:11.4344,y:28.7225}).wait(1).to({graphics:mask_graphics_37,x:9.119,y:34.5791}).wait(1).to({graphics:mask_graphics_38,x:4.5953,y:40.1945}).wait(1).to({graphics:mask_graphics_39,x:-1.9234,y:44.1832}).wait(1).to({graphics:mask_graphics_40,x:-8.8622,y:45.8479}).wait(1).to({graphics:mask_graphics_41,x:-6.8834,y:45.9516}).wait(1).to({graphics:mask_graphics_42,x:-2.0852,y:45.9536}).wait(1).to({graphics:mask_graphics_43,x:1.5427,y:45.9045}).wait(1).to({graphics:mask_graphics_44,x:4.1658,y:45.8599}).wait(1).to({graphics:mask_graphics_45,x:5.9873,y:45.8618}).wait(1).to({graphics:mask_graphics_46,x:7.2362,y:45.8863}).wait(1).to({graphics:mask_graphics_47,x:7.965,y:45.8021}).wait(1));

	// Layer_1
	this.instance = new lib.bang_icon();
	this.instance.setTransform(20.3,30.6,1.1072,1.1072,0,0,0,20.6,21.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,6.2,47.6,48.699999999999996);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AqGOxQhygxgth0QguhzAxhzQAzhyBzguMAjdgN9QB0guByAxQBzAyAtB0QAuB0gzByQgwBxh0AuMgjdAN/Qg3AWg3AAQg9AAg8gbg");
	var mask_graphics_54 = new cjs.Graphics().p("AqKOzQhxgxguh0Qguh0AxhzQAzhyBzgtMAjegN+QBzguByAyQBzAyAuB0QAtBzgyByQgxByh0AuMgjdAN+Qg3AWg3AAQg9AAg8gag");
	var mask_graphics_55 = new cjs.Graphics().p("AqYO4Qhygxgth0QguhzAxhzQAzhyBzguMAjegN9QBzguByAxQBzAyAuB0QAtB0gyByQgxByh0AtMgjdAN/Qg3AWg3AAQg9AAg8gbg");
	var mask_graphics_56 = new cjs.Graphics().p("Aq2PEQhxgxguh0Qguh0AxhyQAzhyB0guMAjdgN+QBzgtByAxQBzAyAuB0QAtB0gyByQgxBxh0AuMgjdAN/Qg3AVg3AAQg9AAg8gag");
	var mask_graphics_57 = new cjs.Graphics().p("ArqPZQhygxgth0Qguh0AxhzQAzhyBzgtMAjdgN+QB0guByAyQBzAyAtB0QAuBzgyByQgxByh0AuMgjdAN+Qg3AWg3AAQg9AAg8gag");
	var mask_graphics_58 = new cjs.Graphics().p("AsxP1Qhxgxguh0Qguh0AxhzQAzhyB0gtMAjdgN+QBzguByAyQBzAyAuB0QAtBzgyByQgxByh0AuMgjdAN+Qg3AWg3AAQg9AAg8gag");
	var mask_graphics_59 = new cjs.Graphics().p("At1QQQhygxgth0Qguh0AxhzQAzhyBzgtMAjdgN+QB0guByAyQBzAyAuBzQAtB0gyByQgxByh0AuMgjdAN+Qg3AWg3AAQg9AAg8gag");
	var mask_graphics_60 = new cjs.Graphics().p("AurQlQhygxguh0Qgth0AxhyQAyhyB0guMAjdgN+QB0gtBxAxQB0AyAtB0QAuB0gzBxQgxByhzAuMgjdAN/Qg4AVg3AAQg8AAg8gag");
	var mask_graphics_61 = new cjs.Graphics().p("AvVQ2QhxgyguhzQguh0AxhzQAzhyB0gtMAjdgN+QBzguByAyQBzAyAuBzQAtB0gyBxQgxBzh0AtMgjdAN/Qg3AWg3AAQg9AAg8gag");
	var mask_graphics_62 = new cjs.Graphics().p("Av1RCQhxgxguh0QguhzAxhzQAzhyB0guMAjdgN+QBzgtByAxQBzAyAuB0QAtB0gyBxQgxByh0AuMgjdAN/Qg3AWg3AAQg9AAg8gbg");
	var mask_graphics_63 = new cjs.Graphics().p("AwORMQhxgxguh0Qgth0AwhyQAzhyB0guMAjdgN+QB0gtBxAxQBzAyAuB0QAuB0gzBxQgxByh0AuMgjdAN/Qg3AVg3AAQg8AAg9gag");
	var mask_graphics_64 = new cjs.Graphics().p("AwhRUQhygxgth0Qguh0AxhzQAyhyB0gtMAjdgN+QB0guBxAyQB0AyAtB0QAuBzgzBxQgwBzh0AuMgjdAN+Qg3AWg4AAQg8AAg8gag");
	var mask_graphics_65 = new cjs.Graphics().p("AwxRaQhxgxguh0Qgth0AwhzQAzhyB0gtMAjdgN+QB0gtBxAxQBzAyAuB0QAuBzgzBxQgxBzh0AuMgjdAN+Qg3AWg3AAQg8AAg9gag");
	var mask_graphics_66 = new cjs.Graphics().p("Aw9RfQhxgyguhzQgth0AwhzQAzhyB0gtMAjdgN+QB0guBxAyQBzAyAuBzQAuB0gzBxQgxBzh0AtMgjdAN/Qg3AWg3AAQg8AAg9gag");
	var mask_graphics_67 = new cjs.Graphics().p("AxGRiQhygxgth0QguhzAxhzQAzhyBzguMAjegN9QBzguByAxQBzAyAuB0QAtB0gyBxQgxBzh0AtMgjdAN/Qg3AWg3AAQg9AAg8gbg");
	var mask_graphics_68 = new cjs.Graphics().p("AxNRlQhygxgth0Qguh0AxhyQAzhyBzguMAjegN+QBzgtByAxQBzAyAuB0QAtB0gyBxQgxByh0AuMgjdAN/Qg3AVg3AAQg9AAg8gag");
	var mask_graphics_69 = new cjs.Graphics().p("AxSRnQhygxgth0Qguh0AxhyQAzhyBzguMAjdgN+QB0gtByAxQBzAyAuB0QAtB0gyBxQgxByh0AuMgjdAN/Qg3AVg3AAQg9AAg8gag");
	var mask_graphics_70 = new cjs.Graphics().p("AxVRpQhygyguh0QgthzAxhzQAyhyB0guMAjdgN9QB0guBxAxQB0AyAtB0QAuB0gzBxQgxBzhzAtMgjdAN/Qg4AWg3AAQg8AAg8gag");
	var mask_graphics_71 = new cjs.Graphics().p("AxXRpQhygxgth0Qguh0AxhyQAyhyB0guMAjdgN+QB0gtBxAxQB0AyAtB0QAuB0gzBxQgxByhzAuMgjdAN/Qg4AVg3AAQg8AAg8gag");
	var mask_graphics_72 = new cjs.Graphics().p("AxXRoQhxgxguh0QguhzAxhzQAzhyB0guMAjdgN9QBzguByAxQBzAyAuB0QAtB0gyBxQgxByh0AuMgjdAN/Qg3AWg3AAQg9AAg8gbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:204.5067,y:97.1571}).wait(1).to({graphics:mask_graphics_54,x:204.1255,y:97.3084}).wait(1).to({graphics:mask_graphics_55,x:202.7251,y:97.862}).wait(1).to({graphics:mask_graphics_56,x:199.7429,y:99.041}).wait(1).to({graphics:mask_graphics_57,x:194.5119,y:101.109}).wait(1).to({graphics:mask_graphics_58,x:187.4385,y:103.9054}).wait(1).to({graphics:mask_graphics_59,x:180.6157,y:106.6027}).wait(1).to({graphics:mask_graphics_60,x:175.1857,y:108.7494}).wait(1).to({graphics:mask_graphics_61,x:171.0361,y:110.3899}).wait(1).to({graphics:mask_graphics_62,x:167.8422,y:111.6525}).wait(1).to({graphics:mask_graphics_63,x:165.3531,y:112.6366}).wait(1).to({graphics:mask_graphics_64,x:163.3976,y:113.4097}).wait(1).to({graphics:mask_graphics_65,x:161.8585,y:114.0181}).wait(1).to({graphics:mask_graphics_66,x:160.6536,y:114.4944}).wait(1).to({graphics:mask_graphics_67,x:159.7231,y:114.8623}).wait(1).to({graphics:mask_graphics_68,x:159.0222,y:115.1394}).wait(1).to({graphics:mask_graphics_69,x:158.5167,y:115.3393}).wait(1).to({graphics:mask_graphics_70,x:158.1798,y:115.4724}).wait(1).to({graphics:mask_graphics_71,x:157.9901,y:115.5474}).wait(1).to({graphics:mask_graphics_72,x:158.0317,y:115.4571}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(103.25,183.95,1.0125,1.0125,0.4896,0,0,42.4,17.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("ARAMXMgklgKgQh3gjg9hsQg8htAjh3QAih3Bsg9QBug8B3AiMAklAKgQB3AiA8BsQA9BugjB3QgiB4htA7QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("ARAMcMgklgKhQh3gig9htQg8hsAjh3QAih4Bsg9QBug7B3AiMAklAKfQB3AjA8BsQA9BugjB3QgiB3htA8QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_46 = new cjs.Graphics().p("ARAMpMgklgKhQh3gig9htQg8hsAjh3QAih4Bsg9QBug7B3AiMAklAKfQB3AjA8BsQA9BtgjB4QgiB3htA8QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_47 = new cjs.Graphics().p("ARAM9MgklgKhQh3gig9huQg8hrAjh3QAih4Bsg9QBug7B3AiMAklAKgQB3AiA8BsQA9BugjB3QgiB3htA8QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_48 = new cjs.Graphics().p("ARANWMgklgKgQh3gig9huQg8hrAjh4QAih3Bsg9QBug8B3AjMAklAKfQB3AiA8BsQA9BugjB4QgiB3htA7QhGAohKAAQgpAAgrgNg");
	var mask_1_graphics_49 = new cjs.Graphics().p("ARANzMgklgKhQh3gig9huQg8hrAjh3QAih4Bsg9QBug7B3AiMAklAKfQB3AjA8BsQA9BtgjB4QgiB3htA8QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_50 = new cjs.Graphics().p("ARAOPMgklgKhQh3gig9huQg8hrAjh3QAih4Bsg9QBug7B3AiMAklAKgQB3AiA8BsQA9BugjB3QgiB4htA7QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_51 = new cjs.Graphics().p("ARAOoMgklgKgQh3gig9huQg8hsAjh3QAih3Bsg9QBug8B3AjMAklAKfQB3AiA8BsQA9BugjB4QgiB3htA7QhGAohKAAQgpAAgrgNg");
	var mask_1_graphics_52 = new cjs.Graphics().p("ARAO9MgklgKhQh3gig9huQg8hsAjh2QAih4Bsg9QBug7B3AiMAklAKfQB3AjA8BsQA9BtgjB4QgiB3htA8QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_53 = new cjs.Graphics().p("ARAPKMgklgKhQh3gig9huQg8hsAjh2QAih4Bsg9QBug7B3AiMAklAKfQB3AjA8BsQA9BtgjB4QgiB3htA8QhGAnhKAAQgpAAgrgMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("ARAPOMgklgKgQh3gjg9htQg8htAjh2QAih3Bsg9QBug8B3AiMAklAKgQB3AiA8BsQA9BugjB3QgiB4htA7QhGAnhKAAQgpAAgrgMg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-97.6892,y:80.3436}).wait(1).to({graphics:mask_1_graphics_45,x:-94.5451,y:80.7915}).wait(1).to({graphics:mask_1_graphics_46,x:-85.4204,y:82.0905}).wait(1).to({graphics:mask_1_graphics_47,x:-71.2083,y:84.1138}).wait(1).to({graphics:mask_1_graphics_48,x:-53.3,y:86.6633}).wait(1).to({graphics:mask_1_graphics_49,x:-33.4486,y:89.4894}).wait(1).to({graphics:mask_1_graphics_50,x:-13.5972,y:92.3155}).wait(1).to({graphics:mask_1_graphics_51,x:4.3111,y:94.865}).wait(1).to({graphics:mask_1_graphics_52,x:18.5231,y:96.8882}).wait(1).to({graphics:mask_1_graphics_53,x:27.6478,y:98.1872}).wait(1).to({graphics:mask_1_graphics_54,x:30.3608,y:98.6436}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(88.2,150.2,1.0125,1.0125,0.4896,0,0,57.5,16.6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AquJaQhrg/gfh4Qgfh4A+hsQBAhrB5gfMAk3gJiQB5gfBqA/QBsA/AgB5QAfB4hABrQg/Bsh4AeMgk4AJjQgnAKgmAAQhPAAhIgrg");
	var mask_2_graphics_39 = new cjs.Graphics().p("ArQJjQhqg/gfh4Qgfh5A+hrQBAhrB4gfMAk4gJiQB4gfBrA+QBsBAAfB4QAfB5hABrQg+Bqh4AgMgk4AJiQgoALgmAAQhOAAhJgrg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AstJ7Qhrg+gfh5Qgfh4A+hsQBAhrB5gfMAk3gJiQB5gfBqA/QBsA/AgB5QAfB4hABrQg/Brh4AfMgk4AJjQgnAKgmAAQhPAAhIgrg");
	var mask_2_graphics_41 = new cjs.Graphics().p("Au1KfQhqg/gfh4Qgfh5A+hsQBAhrB4gfMAk4gJiQB4gfBrA/QBsBAAfB4QAfB4hABrQg+Brh4AfMgk4AJjQgnAKgnAAQhOAAhJgqg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AxLLGQhqg/gfh4Qggh5A/hrQBAhrB4ggMAk4gJhQB4ggBrA/QBsBAAfB4QAfB5hABqQg+Brh4AfMgk4AJjQgoALgmAAQhOAAhJgrg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AzSLpQhrg/gfh4Qgfh4A/hsQBAhrB4gfMAk4gJiQB4gfBrA+QBsBAAfB5QAfB4hABqQg+Bsh5AfMgk3AJjQgoAKgmAAQhOAAhJgrg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0wMCQhqg/gfh5Qgfh4A+hsQBAhrB4gfMAk4gJiQB4gfBrA/QBsBAAfB4QAfB4hABqQg+Bsh4AfMgk4AJjQgoAKgmAAQhOAAhJgqg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A00MJQhrg+gfh5Qgfh4A+hsQBAhrB4gfMAk4gJiQB4gfBrA/QBsBAAfB4QAfB4hABqQg+Bsh4AfMgk4AJjQgnAKgnAAQhOAAhIgrg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:212.7811,y:64.497}).wait(1).to({graphics:mask_2_graphics_39,x:209.4413,y:65.3694}).wait(1).to({graphics:mask_2_graphics_40,x:200.08,y:67.8124}).wait(1).to({graphics:mask_2_graphics_41,x:186.5525,y:71.3426}).wait(1).to({graphics:mask_2_graphics_42,x:171.5382,y:75.2608}).wait(1).to({graphics:mask_2_graphics_43,x:158.0107,y:78.791}).wait(1).to({graphics:mask_2_graphics_44,x:148.6494,y:81.2339}).wait(1).to({graphics:mask_2_graphics_45,x:142.5588,y:82.022}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(91.5,117.15,1.0125,1.0125,0.4896,0,0,60.5,16.9);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("ARiIzMglIgIcQh6gbhDhqQhBhoAbh6QAch5BphDQBphCB6AcMAlJAIcQB5AbBCBoQBDBrgcB5QgcB5hpBCQhLAvhTAAQghAAgkgIg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARiIzMglJgIcQh5gbhDhqQhChoAch6QAch5BphDQBphCB6AcMAlJAIcQB5AbBCBoQBDBrgcB5QgbB5hqBCQhLAvhSAAQgiAAgkgIg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARiIzMglJgIcQh5gbhDhqQhChoAch6QAch5BphDQBphCB6AcMAlJAIcQB5AbBCBoQBDBrgcB5QgbB5hqBCQhLAvhSAAQgiAAgkgIg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARiIzMglJgIcQh5gbhDhqQhChoAch6QAch5BphDQBphCB6AcMAlJAIcQB5AbBCBoQBDBrgcB5QgbB5hqBCQhLAvhTAAQghAAgkgIg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARiIzMglIgIcQh6gbhDhqQhChoAch6QAch5BphDQBphCB6AcMAlJAIcQB5AbBCBoQBDBrgcB5QgbB5hqBCQhLAvhTAAQghAAgkgIg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARiJKMglJgIcQh5gchDhpQhChoAch6QAch5BphDQBphCB6AcMAlJAIbQB5AcBCBoQBDBrgcB5QgbB5hqBCQhLAvhTAAQghAAgkgIg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARiJjMglIgIcQh6gchDhpQhChoAch6QAch5BphDQBphCB6AcMAlJAIbQB5AcBCBoQBDBrgcB5QgbB5hqBCQhLAvhTAAQghAAgkgIg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARiJ4MglJgIdQh5gbhDhpQhChpAch5QAch5BphEQBphBB6AbMAlJAIcQB5AbBCBpQBDBqgcB5QgbB6hqBBQhLAwhSAAQgiAAgkgIg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARiKFMglIgIcQh6gchDhpQhChpAch5QAch5BphDQBphCB6AcMAlJAIbQB5AbBCBpQBDBqgcB6QgbB5hqBBQhLAwhSAAQgiAAgkgIg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARiKJMglIgIcQh6gchDhpQhBhpAbh5QAch5BphEQBqhBB5AbMAlJAIcQB5AbBCBpQBDBqgcB5QgcB6hpBBQhLAwhTAAQghAAgkgIg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-93.1864,y:43.7591}).wait(1).to({graphics:mask_3_graphics_32,x:-89.2539,y:44.6834}).wait(1).to({graphics:mask_3_graphics_33,x:-77.9306,y:47.3447}).wait(1).to({graphics:mask_3_graphics_34,x:-60.5824,y:51.422}).wait(1).to({graphics:mask_3_graphics_35,x:-39.3016,y:56.4235}).wait(1).to({graphics:mask_3_graphics_36,x:-16.6551,y:59.4399}).wait(1).to({graphics:mask_3_graphics_37,x:4.6256,y:61.9407}).wait(1).to({graphics:mask_3_graphics_38,x:21.9739,y:63.9793}).wait(1).to({graphics:mask_3_graphics_39,x:33.2971,y:65.31}).wait(1).to({graphics:mask_3_graphics_40,x:36.5636,y:65.696}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(92.5,87.35,1.0125,1.0125,0.4896,0,0,59.8,13.6);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("ArdHjQhnhHgYh7QgYh8BHhpQBIhoB8gXMAl+gHPQB7gYBoBHQBqBIAXB8QAYB7hIBoQhGBph8AXMgl+AHPQgfAGgeAAQhZAAhQg2g");
	var mask_4_graphics_20 = new cjs.Graphics().p("ArgHjQhohHgYh7QgXh8BGhpQBIhoB8gXMAl+gHPQB8gYBoBHQBpBIAXB8QAYB7hIBoQhGBph8AXMgl+AHPQgfAGgdAAQhaAAhPg2g");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArsHjQhohHgXh8QgYh7BGhqQBIhmB8gYMAl9gHPQB8gXBoBGQBpBIAYB8QAXB7hIBoQhGBph8AXMgl9AHPQgfAGgdAAQhaAAhPg2g");
	var mask_4_graphics_22 = new cjs.Graphics().p("AsDHjQhohHgYh8QgXh8BGhpQBIhmB8gYMAl8gHPQB8gXBnBGQBqBIAXB8QAYB8hIBoQhGBoh8AXMgl8AHPQgfAGgdAAQhaAAhPg2g");
	var mask_4_graphics_23 = new cjs.Graphics().p("AspHiQhohGgXh8QgYh8BGhpQBIhmB8gYMAl6gHOQB7gYBoBHQBpBHAYB8QAXB8hHBoQhHBoh7AXMgl6AHOQgfAGgeAAQhZAAhPg2g");
	var mask_4_graphics_24 = new cjs.Graphics().p("AtjHiQhohHgXh7QgYh8BGhpQBIhmB7gYMAl4gHOQB7gXBoBGQBpBIAXB7QAYB8hIBoQhGBnh8AYMgl3AHOQgeAFgeAAQhZAAhPg1g");
	var mask_4_graphics_25 = new cjs.Graphics().p("Au2HhQhnhGgYh8QgXh7BGhpQBHhmB8gYMAlygHNQB8gXBnBGQBpBHAXB8QAYB7hIBoQhGBnh7AYMglzAHNQgeAGgeAAQhZAAhPg2g");
	var mask_4_graphics_26 = new cjs.Graphics().p("AweHgQhnhGgXh7QgYh7BGhpQBIhmB7gYMAltgHLQB7gYBoBGQBoBHAYB7QAXB8hHBnQhGBnh7AYMgluAHMQgeAFgeAAQhZAAhPg1g");
	var mask_4_graphics_27 = new cjs.Graphics().p("AyHHfQhnhGgYh7QgXh7BGhoQBHhmB7gXMAlogHLQB7gYBnBGQBoBHAYB7QAXB7hHBnQhGBnh7AYMgloAHKQgeAGgeAAQhZAAhOg1g");
	var mask_4_graphics_28 = new cjs.Graphics().p("AzgHeQhnhGgXh7QgYh6BGhoQBHhmB7gXMAljgHKQB7gYBmBGQBpBHAXB7QAXB6hHBnQhFBnh7AXMglkAHKQgeAGgdAAQhZAAhOg1g");
	var mask_4_graphics_29 = new cjs.Graphics().p("A0kHdQhnhGgXh6QgXh6BFhoQBHhmB7gXMAlggHKQB6gXBnBGQBoBHAXB6QAXB6hHBnQhFBnh6AXMglhAHKQgeAFgdAAQhZAAhOg1g");
	var mask_4_graphics_30 = new cjs.Graphics().p("A1WHdQhmhGgXh6QgYh7BGhnQBHhmB6gXMAlegHJQB6gXBmBFQBoBHAYB6QAXB7hHBmQhGBnh6AXMgldAHJQgfAGgdAAQhYAAhPg1g");
	var mask_4_graphics_31 = new cjs.Graphics().p("A1XHcQhmhFgYh6QgXh7BFhnQBHhmB6gXMAlcgHJQB6gXBnBGQBoBGAXB7QAXB6hHBmQhFBnh6AXMglcAHJQgeAFgeAAQhYAAhOg1g");
	var mask_4_graphics_32 = new cjs.Graphics().p("A1WHcQhnhFgXh7QgXh6BFhnQBHhmB6gXMAlbgHIQB6gYBmBGQBoBHAXB6QAXB6hHBmQhFBnh6AXMglaAHIQgfAGgdAAQhYAAhOg1g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:217.507,y:23.584}).wait(1).to({graphics:mask_4_graphics_20,x:217.1311,y:23.726}).wait(1).to({graphics:mask_4_graphics_21,x:215.859,y:24.2063}).wait(1).to({graphics:mask_4_graphics_22,x:213.4068,y:25.132}).wait(1).to({graphics:mask_4_graphics_23,x:209.3667,y:26.6572}).wait(1).to({graphics:mask_4_graphics_24,x:203.1983,y:28.9858}).wait(1).to({graphics:mask_4_graphics_25,x:194.4267,y:32.2971}).wait(1).to({graphics:mask_4_graphics_26,x:183.4443,y:36.4431}).wait(1).to({graphics:mask_4_graphics_27,x:172.2304,y:40.6764}).wait(1).to({graphics:mask_4_graphics_28,x:162.7793,y:44.2443}).wait(1).to({graphics:mask_4_graphics_29,x:155.5894,y:46.9586}).wait(1).to({graphics:mask_4_graphics_30,x:150.3295,y:48.9442}).wait(1).to({graphics:mask_4_graphics_31,x:143.159,y:50.3672}).wait(1).to({graphics:mask_4_graphics_32,x:138.1138,y:51.3342}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(96.3,60.75,1.0125,1.0125,0.4896,0,0,63.4,13.8);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.8,0,191.70000000000002,231.6);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.pptLogo = new lib.OutlookLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(50,36.45,1,1,0,0,0,53,32.6);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(-5.8,172.3,1,1,0,0,0,84.2,49);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	//  files 1 - 2
	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(182.55,178.85,1,1,0,0,0,73.5,54.2);

	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(171.75,106.4,1,1,0,0,0,80.5,77);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file1},{t:this.file2}]}).wait(1));

	// file 3
	this.file3 = new lib.file3();
	this.file3.name = "file3";
	this.file3.setTransform(229.4,235.2,1.7,1.7,0,0,0,50.1,70.2);

	this.timeline.addTween(cjs.Tween.get(this.file3).wait(1));

	// file 4
	this.file4 = new lib.file4();
	this.file4.name = "file4";
	this.file4.setTransform(234.7,93.2,1.7,1.7,0,0,0,100.5,74.8);

	this.timeline.addTween(cjs.Tween.get(this.file4).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(225.85,146,1,1,0,0,0,187.5,125.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.ExcelUI_CU();
	this.instance.setTransform(38.35,20.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-62.4,-464.5,502.7,1003.8), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhfJGQgHAAgHgGIgGgHIg9hZQgKgRgOgJQgPgKgXgCIo3AAIAAv/IZLAAIAASLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:210.875,y:79.025}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(205.5,150.3,1,1,0,0,0,205.5,150.3);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.4,-24.7,475.79999999999995,415.8);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-7.9,1,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Poplines
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-119.5,-1.35,1.078,1.078,0,0,0,5,11.5);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(22.35,-0.9,1.0781,1.0781,0,0,0,4.8,11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.popRight},{t:this.popLeft}]}).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-107.45,-17.35,1.1779,1.2899,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-125.8,-17.2,154.5,34.9), null);


(lib.Icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_64 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(64).call(this.frame_64).wait(1));

	// calendar
	this.calendar = new lib.calendar_icon();
	this.calendar.name = "calendar";
	this.calendar.setTransform(70.8,59.7,0.0251,1,0,0,0,53.8,49.5);
	this.calendar._off = true;

	this.timeline.addTween(cjs.Tween.get(this.calendar).wait(49).to({_off:false},0).to({scaleX:1},7,cjs.Ease.quadOut).wait(9));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("ApxG8IImpdIEYAAIAAJdg");
	var mask_graphics_2 = new cjs.Graphics().p("ApvG8IImpdIEXAAIAAJdg");
	var mask_graphics_3 = new cjs.Graphics().p("ApsG8IImpdIEYAAIAAJdg");
	var mask_graphics_4 = new cjs.Graphics().p("AplG8IImpdIEXAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("ApcG8IImpdIEYAAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("ApQG8IImpdIEXAAIAAJdg");
	var mask_graphics_7 = new cjs.Graphics().p("ApCG8IImpdIEXAAIAAJdg");
	var mask_graphics_8 = new cjs.Graphics().p("AoxG8IImpdIEXAAIAAJdg");
	var mask_graphics_9 = new cjs.Graphics().p("AoeG8IIlpdIEZAAIAAJdg");
	var mask_graphics_10 = new cjs.Graphics().p("AoIG7IIlpcIEZAAIAAJcg");
	var mask_graphics_11 = new cjs.Graphics().p("AnvG7IIlpcIEYAAIAAJcg");
	var mask_graphics_12 = new cjs.Graphics().p("AnUG7IIlpcIEZAAIAAJcg");
	var mask_graphics_13 = new cjs.Graphics().p("Am2G7IIlpcIEYAAIAAJcg");
	var mask_graphics_14 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_15 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_16 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_17 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_18 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_19 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_20 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_21 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_22 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_23 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_24 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_25 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_26 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_27 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_28 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_29 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_30 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_31 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_32 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_33 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_34 = new cjs.Graphics().p("AlsG7IIlpcIEZAAIAAJcg");
	var mask_graphics_35 = new cjs.Graphics().p("Ak+G8IIlpdIEZAAIAAJdg");
	var mask_graphics_36 = new cjs.Graphics().p("AkaG8IIlpdIEYAAIAAJdg");
	var mask_graphics_37 = new cjs.Graphics().p("AkBG8IIlpdIEZAAIAAJdg");
	var mask_graphics_38 = new cjs.Graphics().p("AjxG8IIlpdIEYAAIAAJdg");
	var mask_graphics_39 = new cjs.Graphics().p("AjsG8IIlpdIEYAAIAAJdg");
	var mask_graphics_42 = new cjs.Graphics().p("AjsG8IIlpdIEYAAIAAJdg");
	var mask_graphics_49 = new cjs.Graphics().p("AjsG8IIlpdIEYAAIAAJdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-62.575,y:44.3755}).wait(1).to({graphics:mask_graphics_2,x:-62.4454,y:44.3751}).wait(1).to({graphics:mask_graphics_3,x:-62.0566,y:44.3741}).wait(1).to({graphics:mask_graphics_4,x:-61.4086,y:44.3723}).wait(1).to({graphics:mask_graphics_5,x:-60.5014,y:44.3699}).wait(1).to({graphics:mask_graphics_6,x:-59.335,y:44.3668}).wait(1).to({graphics:mask_graphics_7,x:-57.9094,y:44.363}).wait(1).to({graphics:mask_graphics_8,x:-56.2246,y:44.3584}).wait(1).to({graphics:mask_graphics_9,x:-54.2806,y:44.3532}).wait(1).to({graphics:mask_graphics_10,x:-52.0773,y:44.3473}).wait(1).to({graphics:mask_graphics_11,x:-49.6149,y:44.3407}).wait(1).to({graphics:mask_graphics_12,x:-46.8933,y:44.3334}).wait(1).to({graphics:mask_graphics_13,x:-43.9125,y:44.3255}).wait(1).to({graphics:mask_graphics_14,x:-40.3377,y:44.3175}).wait(1).to({graphics:mask_graphics_15,x:-34.8945,y:44.3102}).wait(1).to({graphics:mask_graphics_16,x:-29.9697,y:44.3036}).wait(1).to({graphics:mask_graphics_17,x:-25.5633,y:44.2977}).wait(1).to({graphics:mask_graphics_18,x:-21.6752,y:44.2925}).wait(1).to({graphics:mask_graphics_19,x:-18.3056,y:44.288}).wait(1).to({graphics:mask_graphics_20,x:-15.4544,y:44.2841}).wait(1).to({graphics:mask_graphics_21,x:-13.1216,y:44.281}).wait(1).to({graphics:mask_graphics_22,x:-11.3072,y:44.2786}).wait(1).to({graphics:mask_graphics_23,x:-10.0112,y:44.2769}).wait(1).to({graphics:mask_graphics_24,x:-9.2336,y:44.2758}).wait(1).to({graphics:mask_graphics_25,x:-8.9744,y:44.2755}).wait(1).to({graphics:mask_graphics_26,x:-8.9744,y:44.2755}).wait(1).to({graphics:mask_graphics_27,x:-7.9554,y:44.2766}).wait(1).to({graphics:mask_graphics_28,x:-4.8986,y:44.2802}).wait(1).to({graphics:mask_graphics_29,x:0.196,y:44.2861}).wait(1).to({graphics:mask_graphics_30,x:7.3286,y:44.2944}).wait(1).to({graphics:mask_graphics_31,x:16.499,y:44.305}).wait(1).to({graphics:mask_graphics_32,x:27.7073,y:44.3181}).wait(1).to({graphics:mask_graphics_33,x:40.444,y:44.3329}).wait(1).to({graphics:mask_graphics_34,x:46.5889,y:44.3459}).wait(1).to({graphics:mask_graphics_35,x:51.1742,y:44.3565}).wait(1).to({graphics:mask_graphics_36,x:54.7404,y:44.3648}).wait(1).to({graphics:mask_graphics_37,x:57.2878,y:44.3707}).wait(1).to({graphics:mask_graphics_38,x:58.8162,y:44.3743}).wait(1).to({graphics:mask_graphics_39,x:59.3256,y:44.3755}).wait(3).to({graphics:mask_graphics_42,x:59.3256,y:44.3755}).wait(7).to({graphics:mask_graphics_49,x:59.3256,y:44.3755}).wait(16));

	// lines
	this.instance = new lib.mail_lines();
	this.instance.setTransform(-4.6,60.75,1,1,0,0,0,34.5,25);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(25).to({alpha:0},13).wait(26));

	// letter
	this.letter = new lib.letter();
	this.letter.name = "letter";
	this.letter.setTransform(12.4,52.7,1,1,0,0,0,51.5,36);

	this.timeline.addTween(cjs.Tween.get(this.letter).to({x:87.1},24,cjs.Ease.quadInOut).wait(9).to({scaleX:1.0387,scaleY:1.361,x:70.65,y:59.7},9,cjs.Ease.quadIn).to({regX:51.1,scaleX:0.0313,x:70.6},7,cjs.Ease.quadIn).to({_off:true},1).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.1,10.2,177.6,99);


(lib.Anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(432.35,206,1.3236,1.3236,-102.8471,0,0,14.7,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(446.8,196.1,1.3236,1.3236,-133.8472,0,0,14.7,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(454.6,181.35,1.3237,1.3237,-173.8511,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(342.7,83.1,1.363,1.363,86.0019,0,0,14.9,-0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(326.65,89.3,1.363,1.363,55.0028,0,0,14.9,-0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(318,102.45,1.3631,1.3631,14.9998,0,0,15,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(-61,176.95);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	// ODIcon
	this.ODIcon = new lib.Icon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(333.4,180.65,0.9186,0.9186,0,0,0,17.9,98.4);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Anim, new cjs.Rectangle(281,60.7,195.3,166.7), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(143.1,550.7,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(149.45,550.15,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(66.15,341.5,1,1,0,0,0,120.7,187.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(252.1,223.4,1,1,0,0,0,3.5,39.7);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.Anim();
	this.anim.name = "anim";
	this.anim.setTransform(299.5,311.7,1,1,0,0,0,205.2,143.5);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// Grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(125.2,56.7,1,1,0,0,0,126,52.5);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(12.2,145.9,1.5309,1.5309);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-116.9,-0.5,687.5,645.7), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		//mc.logo.visible = false;
		mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut});
				this.tl1.from(exportRoot,{duration:0.1, onStart:function(){ mc.anim.line1.play();}}, "<.3");			
		
				this.tl1.to(mc.anim,{duration:1.5, x: "-=310", ease:Power3.easeInOut}, "+=1");
				this.tl1.to(mc.grid,{duration:1.5, x: "-=254", ease:Power3.easeInOut}, "<");
		
				this.tl1.to([exportRoot.intro1, exportRoot.intro2],{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<");
		
				//icon
				this.tl1.from(mc.anim.ODIcon,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut, onStart:function(){mc.anim.ODIcon.play(),mc.anim.ODIcon.play();}}, "<+1");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">+.7");
		
				//chart transition
				this.tl1.to(mc.anim,{duration:1.2, scaleX: 2, scaleY: 2, alpha: 0, ease:Power4.easeInOut}, ">");		
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, alpha: 0, ease:Power4.easeInOut}, "<.1");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=0", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
				
				this.tl1.from(mc.ui.ui.file1,{duration:.6, x:"-=60", y:"-=50", scaleX:.4, scaleY:.4, ease:Power4.easeInOut}, ">+.1");
				
				this.tl1.from(mc.ui.ui.file2,{duration:.6, x:"+=12", y:"-=17", scaleX:.43, scaleY:.43, ease:Power4.easeInOut}, ">-.4");
				
			
				this.tl1.to([mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.1, alpha:0}, ">");
				this.tl1.to(mc.anim, {duration:.1, y:"-=70"}, "<");
		
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=16", y:"+=3", scaleX: .63, scaleY: .63, ease:Power3.easeInOut}, ">+.6");
		
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=140", y:"-=130", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.4");
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
				
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"+=0", y:"+=0", scaleX:.28, scaleY:.28, ease:Power3.easeIn}, ">-1");
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
				this.tl1.to(mc.ui.ui.file2,{duration:.7, x:"-=0", y:"-=0", scaleX:.28, scaleY:.28, ease:Power3.easeIn}, "<-.5");
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");				
				
				this.tl1.from(mc.ui.ui.file3,{duration:.6, x:"+=85", y:"-=27", scaleX:.33, scaleY:.33, ease:Power3.easeInOut}, "<-.2");
				this.tl1.from(mc.ui.ui.file3.fileShadow,{duration:.6, x:"+=85", y:"-=27", alpha:0, scaleX:.33, scaleY:.33, ease:Power3.easeInOut}, "<-.2");
				
				this.tl1.from(mc.ui.ui.file4,{duration:.6, x:"-=70", y:"-=90", scaleX:.37, scaleY:.37, alpha:0, ease:Power3.easeInOut}, ">-.4");
		
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"+=25", y:"+=60", scaleX: .59, scaleY: .59, ease:Power3.easeInOut}, ">+1.3");
				this.tl1.to(mc.grid ,{duration:1.2, x:"+=3", y:"-=2", scaleX: 1, scaleY: 1, ease:Power3.easeInOut}, ">-1.2");
				this.tl1.to(mc.anim,{duration:1.2,  scaleX: 0.2, scaleY: 0.2, alpha:1, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"+=25", y:"+=60", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.to(mc.ui.ui.file4,{duration:1, scaleX:.3, scaleY:.3, y:"-=80", alpha:0, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file3,{duration:1, scaleX:.3, scaleY:.3, y:"-=80", alpha:0, ease:Power4.easeInOut}, "<");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ui.ad1,{duration:2, x:"-=120", y:"+=20",  ease:Power3.easeInOut, onStart:function(){mc.ui.ui.ad1.visible=true;}});
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(33.1,299.5,537.5,345.70000000000005);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622830100331", id:"M365_FY22Q1BTS_USA_300x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;