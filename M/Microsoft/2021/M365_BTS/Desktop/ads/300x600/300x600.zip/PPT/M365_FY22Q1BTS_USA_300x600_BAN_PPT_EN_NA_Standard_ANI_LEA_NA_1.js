(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[752,320,102,105],[0,860,316,228],[752,0,195,318],[0,502,583,356],[585,770,393,268],[0,0,750,500],[585,502,400,266]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Group242x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Group60 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.popup1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,559.07,1,2.3503);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414.1,978.7,1946.3000000000002);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pptLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group242x();
	this.instance.setTransform(-12.25,-9.8,1.0793,1.0793);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptLogo, new cjs.Rectangle(-12.2,-9.8,110.10000000000001,113.39999999999999), null);


(lib.outlines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AsRJJQgYAAgQgRQgHgHgEgIQgGgLAAgOIAAwfQAAgXARgRQAQgRAYAAIYjAAQAYAAAQARQARARAAAXIAACYQAAAXgQARQgRARgYAAQgXAAgRgRQgRgQAAgYIAAhfI2xAAIAAOtIKEAAQAYAAARARQAQAQAAAYQAAAOgGALQgEAIgGAHQgRARgYAAg");
	this.shape.setTransform(113.4263,86.1261);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AxCNPQgYAAgRgRQgQgRAAgXIAA4rQAAgXAQgRQARgRAYAAMAiGAAAQAXAAARARQAQARAAAXIAAOPQABAXgRARQgRARgXAAQgYAAgRgRQgQgRAAgXIAAtWMggUAAAIAAW5IQDAAQAXAAARAQQAQARAAAYQAAAXgQARQgRARgXAAg");
	this.shape_1.setTransform(114.8257,84.675);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlines, new cjs.Rectangle(0,0,229.7,169.4), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2204,21.2204,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6126,21.2204,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2204,6.6126,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6126,6.6126,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1623,14.0567,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9521,13.9117,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.4906,13.9117,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Microphone = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiaA5QgXAAgRgQQgRgSAAgXQAAgWARgRQARgRAXAAIE1AAQAXAAARARQARARAAAWQAAAXgRASQgRAQgXAAg");
	this.shape.setTransform(50.4777,126.5529);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgoCCQgQgRAAgYIAAixQAAgYAQgQQASgRAWAAQAYAAAQARQARAQAAAYIAACxQAAAXgRASQgQAQgYAAQgWAAgSgQg");
	this.shape_1.setTransform(50.5027,113.1527);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ai8ERQiDAAhdhcQhchdAAiBIAAiuQAAgYARgRQARgQAXAAQAXAAASAQQAQARAAAYIAACuQAABSA7A7QA7A7BUAAIF5AAQBUAAA7g7QA7g7AAhSIAAiuQAAgYAQgRQARgQAYAAQAYAAAQAQQARARAAAYIAACuQgBCBhbBdQhdBciDAAg");
	this.shape_2.setTransform(50.5027,79.9272);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiFGlQg1AAgmgmQgmglAAg1IAApJQAAg1AmglQAmgmA1AAIELAAQA2AAAlAmQAmAlAAA1IAAJJQAAA1gmAlQgmAmg1AAg");
	this.shape_3.setTransform(50.4777,42.1016);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Microphone, new cjs.Rectangle(0,0,101,132.3), null);


(lib.linec = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#231F20").s().p("AnSFmIAAAAQlSgjiLgqQiyg4gLhmQgLg3BDhIQAjgnBdhIIAAAAQBXhFAcgfIAAABQAhgkgFgUQghg5iMAJQh/AJkPBGIAAAAIkJBFQiJAjhXAOQhZANhogRIAAAAQgzgIgigKQgMgEgFgLQgGgLADgMQAEgMALgGQALgGAMAEQAfAKAuAHQBdAPBRgMQBVgNCGgiIEHhFIABAAQEWhICDgJQDAgNAnBfIABABQAbAxhBBIIAAAAQgfAhhcBJIAAAAQhXBEghAjQgsAvACAgQAPBECFApQCIApFJAjQFDAhHagSIAAAAQHPgRFog3QDvglGDhlQDCgzCSgsQAMgEALAGQALAGAEAMQADAMgFALQgGALgMAEQiTAsjEAzQmGBmjyAlQlrA4nSARIgBAAQijAGiTAAQkYAAjXgWg");
	this.shape.setTransform(213.4999,35.0182);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.linec, new cjs.Rectangle(-3,-3,433.1,76.1), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8INMAl5AAAAy8hKMAl5AAAAy8BLMAl5AAAAy8DhMAl5AAAAy8F3MAl5AAAAy8oMMAl5AAAAy8l2MAl5AAAAy8jgMAl5AAA");
	this.shape.setTransform(121.25,52.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-1,-1,244.5,107), null);


(lib.greenLineC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7A9E3E").s().p("AtpM9QAAlRCDk0QB+koDljlQDmjmEoh+QE0iDFRAAQApAAAxADIAAF8Qg0gDgmAAQkDAAjuBlQjlBhiwCxQixCwhhDlQhlDuAAEDg");
	this.shape.setTransform(34.5388,32.7699,0.3953,0.3953);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.greenLineC, new cjs.Rectangle(0,0,69.1,65.6), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group60();
	this.instance.setTransform(105.8,59.05,0.9188,0.9188);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(105.8,59.1,290.4,209.50000000000003), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS();
	this.instance.setTransform(38.35,20.45,0.94,0.94);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(38.4,20.5,376,250), null);


(lib.ms_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_1, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.blankchart_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F0EFEF").s().p("AT+M9QAAkDhljuQhhjlixiwQixixjlhhQjthlkEAAQkCAAjuBlQjlBhixCxQixCwhhDlQhlDuAAEDIl8AAQAAlRCDk0QB+koDljlQDmjmEph+QE0iDFQAAQFRAAE0CDQEpB+DmDmQDlDlB+EoQCDE0AAFRg");
	this.shape.setTransform(65.5198,32.7648,0.3952,0.3952);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blankchart_c, new cjs.Rectangle(0,0,131.1,65.6), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AjJQnQiehigri1QgpisBWiXIAKgQIL7HYIgKAQQhhCRisAoQg3ANg1AAQh4AAhuhEg");
	var mask_graphics_1 = new cjs.Graphics().p("AjvP8QiMh7gNi5QgMixBuiHIAMgOIKkJPIgMAOQh4B+iwAMIgiACQikAAh/hvg");
	var mask_graphics_2 = new cjs.Graphics().p("AAnRoQi4gRh3iQQh2iQASi5QARiwCChzIAOgNII7K2IgPAMQh3BbiTAAQgYAAgYgDg");
	var mask_graphics_3 = new cjs.Graphics().p("AgCRbQi0gwhdihQhdihAvi0QAuirCThcIAQgKIHCMJIgRAKQhiA0hqAAQg7AAg8gQg");
	var mask_graphics_4 = new cjs.Graphics().p("AgmRCQiphMhCiuQhCivBMipQBJihChhDIARgHIE9NIIgSAHQhHAYhHAAQhcAAhbgqg");
	var mask_graphics_5 = new cjs.Graphics().p("AhDQfQibhngli3Qgki2BnibQBiiTCogoIATgEICwNxIgTAEQglAGglAAQiCAAhxhNg");
	var mask_graphics_6 = new cjs.Graphics().p("AhZPyQiIh/gGi6QgGi6B/iIQB4iBCtgMIATgBIAeOCIgTABQiugBiAh5g");
	var mask_graphics_7 = new cjs.Graphics().p("AB2RnQiqgdhsiMQhxiTAYi5QAYi5CUhxQCLhsCtARIATACIh1N7IgTgDg");
	var mask_graphics_8 = new cjs.Graphics().p("AALRdQijg5hTibQhYilA2iyQA2iyCkhYQCbhTCoAtIASAFIkENcIgTgGg");
	var mask_graphics_9 = new cjs.Graphics().p("AhZRNQiZhTg5inQg7iwBSinQBSinCxg8QCmg4CfBHIARAIImNMmIgRgJg");
	var mask_graphics_10 = new cjs.Graphics().p("Ai2Q4QiKhqgcivQgfi3BtiYQBtiXC2geQCvgdCQBhIAQAKIoLLaIgPgLg");
	var mask_graphics_11 = new cjs.Graphics().p("AkJQfQh2iAAAixQABi6CDiDQCEiEC5AAQCxABB/B2IAOANIp7J7IgOgNg");
	var mask_graphics_12 = new cjs.Graphics().p("AlNQBQhgiRAdivQAfi3CXhsQCYhsC2AeQCuAdBqCKIAMAPIraIKIgLgPg");
	var mask_graphics_13 = new cjs.Graphics().p("AmDPgQhHieA6ioQA8iwCnhSQCnhSCvA8QCnA5BSCaIAJARIsmGLIgIgRg");
	var mask_graphics_14 = new cjs.Graphics().p("AmoO+QgsipBTibQBZikCyg2QCxg2CkBYQCcBUA3ClIAGASItbEDIgFgSg");
	var mask_graphics_15 = new cjs.Graphics().p("Am9OZQgQitBsiMQByiTC5gYQC3gYCUByQCMBsAcCsIADASIt6BzIgDgTg");
	var mask_graphics_16 = new cjs.Graphics().p("AnAN4IABgTQAMitCCh5QCIh/C5AHQC6AHB/CIQB4CBAACuIAAATg");
	var mask_graphics_17 = new cjs.Graphics().p("Am8MLIAEgTQAoipCUhiQCbhmC1AkQC3AlBnCbQBhCUgcCrIgEATg");
	var mask_graphics_18 = new cjs.Graphics().p("AmyKhIAGgSQBEigCihIQCphMCtBCQCuBCBNCqQBIChg4ClIgHASg");
	var mask_graphics_19 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_20 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_21 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_22 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_23 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_24 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_25 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_26 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_27 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_28 = new cjs.Graphics().p("AmiI9IAJgRQBdiSCrguQCzgvChBeQChBeAvCzQAtCrhSCZIgJARg");
	var mask_graphics_29 = new cjs.Graphics().p("AmjJBIAJgQQBciUCrguQCygxCiBdQCiBcAwC0QAvCqhSCaIgJARg");
	var mask_graphics_30 = new cjs.Graphics().p("AmmJPIAJgRQBZiVCpgzQCyg1CjBZQCkBZA1CyQAyCqhNCbIgJARg");
	var mask_graphics_31 = new cjs.Graphics().p("AmqJpIAIgRQBSiaCng5QCvg9CnBSQCoBRA8CwQA6CnhHCfIgIARg");
	var mask_graphics_32 = new cjs.Graphics().p("AmwKSIAHgSQBHieCjhFQCshICrBGQCtBGBICsQBECjg8CjIgGASg");
	var mask_graphics_33 = new cjs.Graphics().p("Am3LOIAFgSQA4ilCchTQCkhZCxA2QCyA1BYCkQBUCcgsCoIgFASg");
	var mask_graphics_34 = new cjs.Graphics().p("Am+MkIADgTQAjiqCPhoQCXhsC2AdQC4AeBtCXQBoCPgWCtIgDASg");
	var mask_graphics_35 = new cjs.Graphics().p("AnAOAQAEiuB7h/QCBiFC7gDQC5gDCFCCQB/B7AICtIABATIuBAOIAAgTg");
	var mask_graphics_36 = new cjs.Graphics().p("AmxOyQgjiqBciYQBgifC1gsQC0gsCfBgQCXBcAvCnIAFATItnDVIgFgSg");
	var mask_graphics_37 = new cjs.Graphics().p("AlwPtQhRiaAvirQAxizCihcQChhdCzAyQCqAuBcCUIAJAQIsLG9IgJgQg");
	var mask_graphics_38 = new cjs.Graphics().p("AjvQoQh9h5gJixQgKi6B9iKQB8iKC5gKQCwgKCGBwIAOANIpYKbIgOgMg");
	var mask_graphics_39 = new cjs.Graphics().p("Ag2RUQidhKhDikQhGisBJirQBJisCshGQCjhCCiA+IASAHIldM7IgSgHg");
	var mask_graphics_40 = new cjs.Graphics().p("ACSRqQisgWhxiIQh3iOAQi6QARi5CPh4QCGhxCuAKIATABIhQN/IgTgCg");
	var mask_graphics_41 = new cjs.Graphics().p("AhGQcQiZhpghi4Qgii3BqiZQBkiRCpgmIASgEICjN0IgTAEQgiAFgiAAQiFAAh0hRg");
	var mask_graphics_42 = new cjs.Graphics().p("AgdRLQishFhKirQhKirBFitQBCikCdhKIARgIIFiM5IgRAIQhQAfhQAAQhTAAhTgig");
	var mask_graphics_43 = new cjs.Graphics().p("AANRjQi2glhniaQhoibAli3QAiitCNhmIAQgLIHyLrIgQALQhrBCh5AAQguAAgvgJg");
	var mask_graphics_44 = new cjs.Graphics().p("AA0RrQi5gJh9iKQh9iKAJi6QAJiwB8h6IAOgNIJbKaIgPANQh7BoihAAIgZgBg");
	var mask_graphics_45 = new cjs.Graphics().p("AjvP9QiMh7gNi5QgMixBuiHIAMgOIKkJOIgMAPQh4B+iwAMIgiACQikAAh/hvg");
	var mask_graphics_46 = new cjs.Graphics().p("AjbQWQiXhtgei3QgcivBhiQIALgQILXIOIgLAPQhrCJiuAcQgoAHgmAAQiJAAh3hWg");
	var mask_graphics_47 = new cjs.Graphics().p("AjJQnQiehigri1QgpisBWiXIAKgQIL7HYIgKAQQhhCRisAoQg3ANg1AAQh4AAhuhEg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:19.8428,y:113.1134}).wait(1).to({graphics:mask_graphics_1,x:17.8129,y:113.0648}).wait(1).to({graphics:mask_graphics_2,x:15.2833,y:113.0726}).wait(1).to({graphics:mask_graphics_3,x:12.3343,y:113.1271}).wait(1).to({graphics:mask_graphics_4,x:9.1082,y:113.163}).wait(1).to({graphics:mask_graphics_5,x:5.7058,y:113.1642}).wait(1).to({graphics:mask_graphics_6,x:2.1853,y:113.1628}).wait(1).to({graphics:mask_graphics_7,x:4.4252,y:112.9931}).wait(1).to({graphics:mask_graphics_8,x:8.0514,y:112.2633}).wait(1).to({graphics:mask_graphics_9,x:11.5229,y:110.9613}).wait(1).to({graphics:mask_graphics_10,x:14.7517,y:109.1223}).wait(1).to({graphics:mask_graphics_11,x:17.6079,y:106.7956}).wait(1).to({graphics:mask_graphics_12,x:19.9565,y:104.0437}).wait(1).to({graphics:mask_graphics_13,x:21.792,y:100.9407}).wait(1).to({graphics:mask_graphics_14,x:23.1093,y:97.5697}).wait(1).to({graphics:mask_graphics_15,x:23.8688,y:94.0215}).wait(1).to({graphics:mask_graphics_16,x:24.042,y:91.994}).wait(1).to({graphics:mask_graphics_17,x:24.4446,y:95.6867}).wait(1).to({graphics:mask_graphics_18,x:25.4174,y:99.2528}).wait(1).to({graphics:mask_graphics_19,x:26.8137,y:102.509}).wait(1).to({graphics:mask_graphics_20,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_21,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_22,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_23,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_24,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_25,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_26,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_27,x:26.8138,y:102.5092}).wait(1).to({graphics:mask_graphics_28,x:26.8137,y:102.509}).wait(1).to({graphics:mask_graphics_29,x:26.7365,y:102.3674}).wait(1).to({graphics:mask_graphics_30,x:26.4925,y:101.9032}).wait(1).to({graphics:mask_graphics_31,x:26.0724,y:101.0391}).wait(1).to({graphics:mask_graphics_32,x:25.489,y:99.6644}).wait(1).to({graphics:mask_graphics_33,x:24.7988,y:97.6274}).wait(1).to({graphics:mask_graphics_34,x:24.1487,y:94.737}).wait(1).to({graphics:mask_graphics_35,x:23.8731,y:91.4544}).wait(1).to({graphics:mask_graphics_36,x:23.231,y:96.4211}).wait(1).to({graphics:mask_graphics_37,x:20.9623,y:102.1448}).wait(1).to({graphics:mask_graphics_38,x:16.5338,y:107.6322}).wait(1).to({graphics:mask_graphics_39,x:10.1545,y:111.539}).wait(1).to({graphics:mask_graphics_40,x:3.3648,y:113.1606}).wait(1).to({graphics:mask_graphics_41,x:5.2944,y:113.2529}).wait(1).to({graphics:mask_graphics_42,x:9.9816,y:113.2528}).wait(1).to({graphics:mask_graphics_43,x:13.5253,y:113.2031}).wait(1).to({graphics:mask_graphics_44,x:16.0873,y:113.1582}).wait(1).to({graphics:mask_graphics_45,x:17.866,y:113.159}).wait(1).to({graphics:mask_graphics_46,x:19.0854,y:113.1821}).wait(1).to({graphics:mask_graphics_47,x:19.8428,y:113.1134}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjMATQAAgiADgqQAGhTAMgfQAOAnAvB1IBajCIAEDJICRh/IhJCuIBHgIQBLgKAPAAQgQAWh1BMIA1ATQA3AUAIAFIhlAv");
	this.shape.setTransform(31.742,166.4832,1.0825,1.0825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(8.6,142.8,46.4,47.39999999999998);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzCHIAAkNIPnAAIAAENg");
	this.shape.setTransform(50,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,0,100,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Group332x();
	this.instance.setTransform(29.95,22.35,0.5367,0.5367);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(30,6.1,104.6,186.9), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms1.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms1 = new lib.ms();
	this.ms1.name = "ms1";
	this.ms1.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.line_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.linec = new lib.linec();
	this.linec.name = "linec";
	this.linec.setTransform(213.5,35,1,1,0,0,0,213.5,35);

	this.timeline.addTween(cjs.Tween.get(this.linec).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_c, new cjs.Rectangle(-3,-3,433.1,76.1), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.gridpiece();
	this.instance.setTransform(384.6,468.7,1.47,1.47,90,0,0,125.8,52.4);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(208.5,468.7,1.47,1.47,90,0,0,125.8,52.4);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(304.35,546.2,1.47,1.47,0,0,0,125.8,52.6);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(304.35,369.9,1.47,1.47,0,0,0,125.8,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(118.7,283.1,358,357.9), null);


(lib.green_bar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.glc.cache(0,0,75,70,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.glc = new lib.greenLineC();
	this.glc.name = "glc";
	this.glc.setTransform(34.6,32.8,1,1,0,0,0,34.6,32.8);

	this.timeline.addTween(cjs.Tween.get(this.glc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.green_bar, new cjs.Rectangle(0,0,69.1,65.6), null);


(lib.MSFT_Logo_anim_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms_1();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_4.setTransform(-34.3747,7.0753);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_5.setTransform(-45.6749,7.0753);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_6.setTransform(-34.3747,-4.2249);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_7.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_1, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSVBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgSoBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgThBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVBBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXGBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZyBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdDBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggVBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjABK7IAAwoMBbtAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglGBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmlBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgneBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("EgnxBK7IAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.6789,y:479.5095}).wait(1).to({graphics:mask_graphics_15,x:467.773,y:479.5095}).wait(1).to({graphics:mask_graphics_16,x:462.0553,y:479.5095}).wait(1).to({graphics:mask_graphics_17,x:452.5258,y:479.5095}).wait(1).to({graphics:mask_graphics_18,x:439.1845,y:479.5095}).wait(1).to({graphics:mask_graphics_19,x:422.0313,y:479.5095}).wait(1).to({graphics:mask_graphics_20,x:401.0664,y:479.5095}).wait(1).to({graphics:mask_graphics_21,x:380.1015,y:479.5095}).wait(1).to({graphics:mask_graphics_22,x:362.9483,y:479.5095}).wait(1).to({graphics:mask_graphics_23,x:349.607,y:479.5095}).wait(1).to({graphics:mask_graphics_24,x:340.0775,y:479.5095}).wait(1).to({graphics:mask_graphics_25,x:334.3598,y:479.5095}).wait(1).to({graphics:mask_graphics_26,x:332.4539,y:479.5095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// logo text
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-131.7,900.05,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	this.instance_1 = new lib.MSFT_Logo_anim_1();
	this.instance_1.setTransform(39.6,58.5,2.4059,2.4059,0,0,0,0.1,0.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance}]},12).to({state:[{t:this.instance}]},39).to({state:[{t:this.instance_1}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.7},12,cjs.Ease.quadInOut).wait(39).to({_off:true,regY:0.5,scaleX:2.4059,scaleY:2.4059,x:39.6,y:58.5},33,cjs.Ease.cubicInOut).wait(2));

	// widows icon
	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(299.1,905.95,0.2981,0.2981,0,0,0,-39.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:299.05},14,cjs.Ease.quadOut).to({x:24.8},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(301.4796,905.1707,1,2.3542);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(301.45,344.45);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,978.8,1949.6);


(lib.collabIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_13
	this.outlines = new lib.outlines();
	this.outlines.name = "outlines";
	this.outlines.setTransform(-77.1,154.6,1,1,0,0,0,-0.4,168.9);

	this.timeline.addTween(cjs.Tween.get(this.outlines).wait(1));

	// mic
	this.mic = new lib.Microphone();
	this.mic.name = "mic";
	this.mic.setTransform(102.65,117.8,1,1,0,0,0,50.5,66.1);

	this.timeline.addTween(cjs.Tween.get(this.mic).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabIcon, new cjs.Rectangle(-76.7,-14.3,229.89999999999998,198.3), null);


(lib.blank_chart = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.blankchart.cache(0,0,135,70)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.blankchart = new lib.blankchart_c();
	this.blankchart.name = "blankchart";
	this.blankchart.setTransform(65.5,32.8,1,1,0,0,0,65.5,32.8);

	this.timeline.addTween(cjs.Tween.get(this.blankchart).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blank_chart, new cjs.Rectangle(0,0,131.1,65.6), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("ApGNCQhvgsgwhuQgwhuArhwQAthwBvgwMAhvgOqQBugwBvArQBxAtAwBuQAvBugsBwQgsBwhuAwMghvAOrQg5AZg6AAQg1AAg3gWg");
	var mask_graphics_54 = new cjs.Graphics().p("ApJNEQhwgsgvhuQgwhuArhxQAthvBugwMAhvgOrQBugwBvAsQBxAsAwBuQAwBvgtBvQgrBxhuAwMghvAOqQg6AZg5AAQg2AAg2gVg");
	var mask_graphics_55 = new cjs.Graphics().p("ApXNKQhvgsgwhuQgwhuAshxQAshvBvgwMAhvgOrQBugwBvAsQBxAsAwBuQAwBugtBwQgsBwhuAwMghvAOrQg5AZg6AAQg1AAg3gVg");
	var mask_graphics_56 = new cjs.Graphics().p("ApzNWQhvgsgwhuQgwhuArhwQAthwBugwMAhvgOrQBugwBvAsQBxAsAwBvQAwBugtBvQgrBxhuAwMghvAOqQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_57 = new cjs.Graphics().p("AqlNsQhvgsgwhuQgwhuArhxQAthvBvgwMAhvgOrQBugwBvAsQBxAsAwBuQAvBugsBwQgsBwhuAwMghvAOrQg5AZg6AAQg1AAg3gVg");
	var mask_graphics_58 = new cjs.Graphics().p("AroOJQhvgsgwhuQgwhuArhwQAthwBugwMAhvgOrQBugwBwAsQBwAsAwBvQAwBugtBvQgrBxhuAwMghvAOqQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_59 = new cjs.Graphics().p("AspOlQhvgsgwhuQgwhuArhwQAthwBugwMAhvgOrQBvgwBvAsQBxAtAwBuQAvBugtBwQgrBwhuAwMghvAOrQg5AYg6AAQg2AAg2gVg");
	var mask_graphics_60 = new cjs.Graphics().p("AtcO8QhwgsgvhuQgwhuArhxQAthvBugwMAhvgOrQBugwBvAsQBxAsAwBuQAwBugtBwQgrBwhuAvMghvAOsQg6AZg5AAQg2AAg2gVg");
	var mask_graphics_61 = new cjs.Graphics().p("AuEPNQhvgsgwhuQgwhuArhxQAthvBugwMAhvgOrQBvgwBvAsQBxAsAvBuQAwBvgtBvQgrBxhuAuMghvAOsQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_62 = new cjs.Graphics().p("AuiPaQhvgsgwhuQgwhuArhwQAthwBugwMAhvgOrQBugwBvAsQBxAtAwBuQAwBugtBvQgrBxhuAvMghvAOrQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_63 = new cjs.Graphics().p("Au6PkQhvgrgwhvQgwhuArhwQAthwBugwMAhvgOqQBvgwBvArQBxAtAvBuQAwBugtBwQgrBvhuAwMghvAOsQg5AZg6AAQg2AAg2gWg");
	var mask_graphics_64 = new cjs.Graphics().p("AvMPsQhwgrgvhuQgwhvArhwQAthwBugwMAhvgOqQBugwBvArQBxAtAwBuQAwBugtBwQgrBvhuAwMghvAOsQg6AZg5AAQg2AAg2gWg");
	var mask_graphics_65 = new cjs.Graphics().p("AvbPzQhvgsgwhuQgwhuArhxQAthvBugwMAhvgOrQBugwBvAsQBxAsAwBuQAwBvgtBvQgrBwhuAvMghvAOsQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_66 = new cjs.Graphics().p("AvnP4QhvgsgwhuQgvhuArhxQAthvBugwMAhvgOrQBugwBvAsQBxAsAwBuQAwBugtBwQgrBwhvAvMghvAOsQg5AZg6AAQg1AAg3gVg");
	var mask_graphics_67 = new cjs.Graphics().p("AvvP8QhwgsgvhuQgwhuArhxQAthvBugwMAhvgOrQBugwBvAsQBxAsAwBuQAwBugtBwQgrBvhuAwMghvAOsQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_68 = new cjs.Graphics().p("Av2P+QhvgrgwhuQgwhvArhwQAthwBugvMAhvgOrQBugwBwAsQBwAsAwBuQAwBugtBwQgrBvhuAwMghvAOsQg5AZg6AAQg2AAg2gWg");
	var mask_graphics_69 = new cjs.Graphics().p("Av7QBQhvgsgwhuQgwhuArhxQAthvBvgwMAhugOrQBvgwBvAsQBxAsAwBuQAvBugtBwQgrBvhuAwMghvAOsQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_70 = new cjs.Graphics().p("Av+QCQhvgsgwhuQgwhuArhwQAthwBugwMAhvgOrQBugwBwAsQBwAtAwBuQAwBugtBvQgrBwhuAwMghvAOrQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_71 = new cjs.Graphics().p("AwAQDQhvgsgwhuQgwhuArhxQAthvBvgwMAhugOrQBvgwBvAsQBxAsAwBuQAvBvgtBvQgrBwhuAvMghvAOsQg5AZg6AAQg2AAg2gVg");
	var mask_graphics_72 = new cjs.Graphics().p("AwAQDQhvgsgwhuQgwhuArhxQAthvBvgwMAhvgOrQBugwBvAsQBxAsAwBuQAvBvgsBvQgsBwhuAvMghvAOsQg5AZg6AAQg1AAg3gVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:197.5268,y:85.5608}).wait(1).to({graphics:mask_graphics_54,x:197.1641,y:85.7189}).wait(1).to({graphics:mask_graphics_55,x:195.8334,y:86.2985}).wait(1).to({graphics:mask_graphics_56,x:192.9995,y:87.5327}).wait(1).to({graphics:mask_graphics_57,x:188.0287,y:89.6976}).wait(1).to({graphics:mask_graphics_58,x:181.3071,y:92.6249}).wait(1).to({graphics:mask_graphics_59,x:174.8236,y:95.4486}).wait(1).to({graphics:mask_graphics_60,x:169.6637,y:97.6959}).wait(1).to({graphics:mask_graphics_61,x:165.7205,y:99.4132}).wait(1).to({graphics:mask_graphics_62,x:162.6855,y:100.735}).wait(1).to({graphics:mask_graphics_63,x:160.3201,y:101.7652}).wait(1).to({graphics:mask_graphics_64,x:158.4619,y:102.5745}).wait(1).to({graphics:mask_graphics_65,x:156.9994,y:103.2114}).wait(1).to({graphics:mask_graphics_66,x:155.8544,y:103.7101}).wait(1).to({graphics:mask_graphics_67,x:154.9702,y:104.0952}).wait(1).to({graphics:mask_graphics_68,x:154.3041,y:104.3853}).wait(1).to({graphics:mask_graphics_69,x:153.8238,y:104.5945}).wait(1).to({graphics:mask_graphics_70,x:153.5036,y:104.7339}).wait(1).to({graphics:mask_graphics_71,x:153.3234,y:104.8124}).wait(1).to({graphics:mask_graphics_72,x:153.3268,y:104.8108}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(103.65,162.6,0.9775,0.9775,-1.5099,0,0,42.2,17.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AQvLDMgjpgI6Qh0gdg/hoQg9hlAdh1QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB1QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AQvLGMgjpgI6Qh0gdg/hnQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB0QgdB1hnA9QhGArhNAAQgjAAglgKg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AQvLRMgjpgI6Qh0gdg/hnQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB0QgdB1hnA9QhGArhNAAQgjAAglgKg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AQvLjMgjpgI6Qh0gdg/hoQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB1QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AQvL4MgjpgI6Qh0gdg/hoQg9hlAdh0QAdh1Bng+QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB0QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AQvMQMgjpgI6Qh0gdg/hoQg9hlAdh0QAdh1Bng+QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB0QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AQvMoMgjpgI6Qh0gdg/hoQg9hmAdhzQAdh1Bng+QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB0QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AQvM+MgjpgI6Qh0gdg/hoQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BmQA+BogdB1QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AQvNPMgjpgI6Qh0gdg/hoQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BnQA+BngdB1QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AQvNaMgjpgI6Qh0gdg/hoQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BnQA+BngdB1QgdB0hnA9QhGArhNAAQgjAAglgJg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AQvNeMgjpgI6Qh0gdg/hoQg9hmAdh0QAdh0Bng/QBng9B0AdMAjpAI5QB0AdA+BnQA+BogdB0QgdB0hnA9QhGArhNAAQgjAAglgJg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-93.2397,y:71.5772}).wait(1).to({graphics:mask_1_graphics_45,x:-90.1737,y:71.9563}).wait(1).to({graphics:mask_1_graphics_46,x:-81.2758,y:73.0566}).wait(1).to({graphics:mask_1_graphics_47,x:-67.417,y:74.7704}).wait(1).to({graphics:mask_1_graphics_48,x:-49.9539,y:76.9298}).wait(1).to({graphics:mask_1_graphics_49,x:-30.5959,y:79.3236}).wait(1).to({graphics:mask_1_graphics_50,x:-11.2379,y:81.7174}).wait(1).to({graphics:mask_1_graphics_51,x:6.2252,y:83.8769}).wait(1).to({graphics:mask_1_graphics_52,x:20.084,y:85.5907}).wait(1).to({graphics:mask_1_graphics_53,x:28.9819,y:86.691}).wait(1).to({graphics:mask_1_graphics_54,x:31.7603,y:87.1022}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(87.85,130.55,0.9775,0.9775,-1.5099,0,0,57.2,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("Ap8JNQhpg5gihzQgihzA4hqQA7hpBzgjMAjPgKcQB0giBoA5QBrA6AiBzQAiBzg6BpQg5BrhzAiMgjPAKcQgrAMgqAAQhGAAhDgkg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AqcJNQhpg5gihzQgihzA4hqQA7hpBzgjMAjQgKcQBzgiBoA5QBrA6AiBzQAiBzg6BpQg5BrhzAiMgjPAKcQgrAMgqAAQhGAAhDgkg");
	var mask_2_graphics_40 = new cjs.Graphics().p("Ar1JNQhpg5gihzQgjhzA5hqQA6hpBzgjMAjQgKcQBzgiBpA5QBrA6AiBzQAiBzg6BpQg5BrhzAiMgjQAKcQgrAMgpAAQhGAAhDgkg");
	var mask_2_graphics_41 = new cjs.Graphics().p("At3JNQhpg5gihzQgihzA5hqQA6hpBzgjMAjQgKcQBzgiBpA5QBqA6AiBzQAjBzg7BpQg4BrhzAiMgjQAKcQgrAMgpAAQhHAAhDgkg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AwGJsQhpg4gih0QgihzA4hqQA6hpBzgiMAjQgKcQBzgiBpA5QBrA5AiB0QAiBzg6BpQg5BqhzAiMgjQAKcQgqANgqAAQhGAAhDglg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AyIKTQhog5gjhzQgihzA5hqQA6hpBzgjMAjQgKcQBzgiBpA5QBrA6AiBzQAiBzg6BpQg5BrhzAhMgjQAKdQgrAMgpAAQhGAAhEgkg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AzhKuQhpg5gihzQgihzA4hqQA7hqBzgiMAjQgKcQBzgiBpA5QBqA6AiBzQAiBzg6BpQg4Bph0AiMgjPAKeQgrAMgqAAQhGAAhDgkg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AzyK3Qhpg5gihzQgjhzA5hrQA6hpBzgiMAjQgKcQBzgiBpA5QBrA6AiBzQAiBzg6BpQg5BphzAiMgjQAKdQgrANgpAAQhGAAhDgkg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:204.9669,y:45.2753}).wait(1).to({graphics:mask_2_graphics_39,x:201.774,y:47.1829}).wait(1).to({graphics:mask_2_graphics_40,x:192.8279,y:52.5281}).wait(1).to({graphics:mask_2_graphics_41,x:179.9004,y:60.252}).wait(1).to({graphics:mask_2_graphics_42,x:165.552,y:65.6822}).wait(1).to({graphics:mask_2_graphics_43,x:152.6245,y:69.5442}).wait(1).to({graphics:mask_2_graphics_44,x:143.6784,y:72.2168}).wait(1).to({graphics:mask_2_graphics_45,x:139.0035,y:73.1074}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(90.1,98.55,0.9775,0.9775,-1.5099,0,0,60.4,16.7);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AROH6MgkHgG6Qh2gWhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AWMAkIAG6QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AROH6MgkIgG6Qh1gWhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AWMAkIAG6QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AROH6MgkIgG6Qh1gWhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AWMAkIAG6QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AROH6MgkIgG6Qh1gWhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AWMAkIAG6QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AROH6MgkIgG6Qh1gWhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AWMAkIAG6QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AROH6MgkIgG6Qh1gWhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AWMAkIAG6QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AROIDMgkIgG5Qh1gWhFhkQhDhiAXh2QAWh2BjhFQBkhCB2AWMAkIAG5QB1AXBEBhQBEBlgXB2QgWB2hkBCQhLA0hVAAQgcAAgdgGg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AROIUMgkIgG5Qh1gXhFhjQhDhjAXh2QAWh1BjhFQBkhDB2AXMAkIAG5QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLA0hVAAQgcAAgdgGg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AROIfMgkIgG5Qh1gXhFhjQhDhjAXh2QAWh1BjhFQBkhDB2AXMAkIAG5QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AROIiMgkHgG5Qh2gXhFhjQhDhjAXh2QAWh2BjhEQBkhDB2AXMAkIAG5QB1AWBEBiQBEBkgXB2QgWB2hkBDQhLAzhVAAQgcAAgdgFg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-90.7371,y:34.1585}).wait(1).to({graphics:mask_3_graphics_32,x:-86.9141,y:34.9177}).wait(1).to({graphics:mask_3_graphics_33,x:-75.9062,y:37.1039}).wait(1).to({graphics:mask_3_graphics_34,x:-59.041,y:40.4532}).wait(1).to({graphics:mask_3_graphics_35,x:-38.3529,y:44.5618}).wait(1).to({graphics:mask_3_graphics_36,x:-16.337,y:48.9341}).wait(1).to({graphics:mask_3_graphics_37,x:4.3512,y:52.0806}).wait(1).to({graphics:mask_3_graphics_38,x:21.2163,y:53.7553}).wait(1).to({graphics:mask_3_graphics_39,x:32.2242,y:54.8484}).wait(1).to({graphics:mask_3_graphics_40,x:35.8129,y:55.1382}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(90,69.75,0.9775,0.9775,-1.5099,0,0,59.6,13.4);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("Aq1IBQhmhBgbh2Qgbh3BAhoQBChnB3gaMAkZgIQQB2gbBnBAQBoBCAbB3QAbB2hCBnQhABoh3AaMgkZAIRQgiAHgiAAQhRAAhKgug");
	var mask_4_graphics_20 = new cjs.Graphics().p("Aq4IBQhnhBgbh2Qgah3BAhoQBChnB2gaMAkZgIQQB3gbBmBAQBoBCAbB3QAbB2hCBnQhABoh3AaMgkYAIQQgjAIghAAQhRAAhKgug");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArEIBQhmhBgbh3Qgbh2BAhoQBChnB3gaMAkYgIQQB3gbBmBAQBoBCAbB3QAbB2hCBnQhABoh3AaMgkYAIQQgiAIgiAAQhRAAhKgug");
	var mask_4_graphics_22 = new cjs.Graphics().p("AraIAQhmhAgbh3Qgbh2BAhoQBChnB3gaMAkXgIQQB2gbBnBBQBoBBAbB3QAbB2hCBnQhABoh3AaMgkXAIQQgjAIghAAQhRAAhKgvg");
	var mask_4_graphics_23 = new cjs.Graphics().p("Ar+IAQhnhAgah3Qgbh3BAhnQBChnB2gaMAkVgIQQB3gaBmBAQBoBBAbB3QAbB3hCBmQhABoh3AaMgkVAIQQgiAHgiAAQhRAAhJgug");
	var mask_4_graphics_24 = new cjs.Graphics().p("As2H/QhmhAgbh2Qgbh3BAhnQBChnB2gaMAkSgIPQB3gbBmBBQBoBBAbB2QAbB3hCBmQhABoh3AaMgkSAIPQgiAIghAAQhRAAhKgvg");
	var mask_4_graphics_25 = new cjs.Graphics().p("AuFH/QhmhBgbh2Qgbh2BAhnQBChnB2gaMAkOgIOQB2gbBmBBQBoBBAbB2QAbB2hCBnQhABnh2AaMgkOAIOQgjAIghAAQhRAAhJgug");
	var mask_4_graphics_26 = new cjs.Graphics().p("AvoH9QhmhAgbh2Qgbh2BAhnQBChmB1gaMAkKgINQB2gbBlBBQBoBBAaB2QAbB2hBBmQhABnh2AaMgkJAINQgiAIgiAAQhQAAhJgvg");
	var mask_4_graphics_27 = new cjs.Graphics().p("AxOH8QhlhAgbh1Qgbh2BAhnQBBhmB2gaMAkEgIMQB2gaBlBAQBnBBAbB1QAbB2hCBmQg/Bnh2AaMgkEAIMQgiAHghAAQhRAAhJgug");
	var mask_4_graphics_28 = new cjs.Graphics().p("AyjH7QhlhAgbh1Qgbh2BAhmQBBhmB1gZMAkAgILQB1gbBmBAQBnBBAaB1QAbB2hBBlQhABnh1AaMgkAAILQgiAHghAAQhQAAhJgug");
	var mask_4_graphics_29 = new cjs.Graphics().p("AzkH7QhlhAgbh1Qgbh2BAhmQBBhmB1gZMAj9gILQB1gaBlA/QBnBBAaB2QAbB1hBBlQg/Bnh2AaMgj8AIKQgiAIghAAQhQAAhJgug");
	var mask_4_graphics_30 = new cjs.Graphics().p("A0UH6QhlhAgah1Qgbh1BAhmQBBhmB1gZMAj5gIKQB2gbBlBAQBmBBAbB1QAbB1hBBmQhABmh1AaMgj6AIJQgiAIghAAQhQAAhJgug");
	var mask_4_graphics_31 = new cjs.Graphics().p("A0XH6QhlhAgbh1Qgah1A/hnQBBhlB1gZMAj4gIKQB1gaBlA/QBnBBAbB1QAaB1hBBmQg/Bmh1AaMgj4AIJQgiAIghAAQhQAAhJgug");
	var mask_4_graphics_32 = new cjs.Graphics().p("A0WH5Qhlg/gbh1Qgah1A/hnQBBhlB1gZMAj3gIJQB1gbBlBAQBmBAAbB1QAaB1hABmQhABmh1AZMgj3AIJQgiAIghAAQhPAAhJgug");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:208.875,y:1.9812}).wait(1).to({graphics:mask_4_graphics_20,x:208.5161,y:2.1432}).wait(1).to({graphics:mask_4_graphics_21,x:207.2967,y:2.6909}).wait(1).to({graphics:mask_4_graphics_22,x:204.946,y:3.7467}).wait(1).to({graphics:mask_4_graphics_23,x:201.0732,y:5.4863}).wait(1).to({graphics:mask_4_graphics_24,x:195.1602,y:8.1422}).wait(1).to({graphics:mask_4_graphics_25,x:186.7518,y:11.9189}).wait(1).to({graphics:mask_4_graphics_26,x:176.224,y:16.6475}).wait(1).to({graphics:mask_4_graphics_27,x:165.4744,y:21.4758}).wait(1).to({graphics:mask_4_graphics_28,x:156.4146,y:25.5451}).wait(1).to({graphics:mask_4_graphics_29,x:149.5224,y:28.6409}).wait(1).to({graphics:mask_4_graphics_30,x:144.4803,y:30.9056}).wait(1).to({graphics:mask_4_graphics_31,x:137.7953,y:32.5285}).wait(1).to({graphics:mask_4_graphics_32,x:132.9592,y:33.6315}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(92.65,43.95,0.9775,0.9775,-1.5099,0,0,63.1,13.6);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.1,186,211.2);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-8.2,1.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Poplines
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-119.5,-1.35,1.078,1.078,0,0,0,5,11.5);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(22.35,-0.9,1.0781,1.0781,0,0,0,4.8,11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.popRight},{t:this.popLeft}]}).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-106.85,-17.05,1.1779,1.2899,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-125.8,-16.9,154.5,34.9), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_46 = new cjs.Graphics().p("AEMEMIqIgoQghgCgUg4QgUg3AFhNQAEhLAbg1QAbg1AhACIKIAoQAhACAUA3QAUA3gFBNQgEBMgbA1QgaAzgfAAIgDAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AEpEOIqfgpQgigCgVg4QgVg4AEhNQAFhMAbg1QAcg1AiACIKfAoQAiACAVA4QAVA4gFBNQgEBNgcA0QgaA0ghAAIgCAAg");
	var mask_graphics_48 = new cjs.Graphics().p("AFJEQIq4gpQgkgDgWg4QgWg4AFhOQAEhMAdg2QAcg1AkACIK4ApQAjACAWA4QAWA4gEBNQgFBOgdA1QgbA0giAAIgCAAg");
	var mask_graphics_49 = new cjs.Graphics().p("AFgESIrVgqQglgCgXg5QgXg5AFhOQAEhNAdg2QAeg1AlACILVAqQAlACAXA4QAXA4gFBOQgEBOgeA2QgcA0gjAAIgDAAg");
	var mask_graphics_50 = new cjs.Graphics().p("AFwEUIr1grQgmgCgZg5QgYg5AFhPQAEhOAeg2QAfg2AnACIL1ArQAmACAYA5QAZA5gFBOQgEBPgfA2QgdA0glAAIgDAAg");
	var mask_graphics_51 = new cjs.Graphics().p("AGCEXIsYgsQgpgCgag6QgZg6AEhPQAFhOAfg3QAgg2ApACIMYArQApADAZA5QAaA5gEBQQgFBPggA2QgeA1gnAAIgDAAg");
	var mask_graphics_52 = new cjs.Graphics().p("AGWEaItAgtQgqgCgcg7Qgag6AEhQQAEhPAhg3QAhg3ArACINAAtQAqACAbA6QAbA6gEBQQgEBQghA2QggA2goAAIgEAAg");
	var mask_graphics_53 = new cjs.Graphics().p("AGsEdItrguQgtgCgdg7Qgdg7AFhRQAEhPAig5QAjg3AtACINrAuQAtACAdA7QAdA6gFBRQgEBRgjA3QghA2gqAAIgEAAg");
	var mask_graphics_54 = new cjs.Graphics().p("AHEEgIubguQgvgCgfg8Qgeg8AEhRQAEhRAkg5QAkg4AwADIObAuQAvACAeA7QAfA7gEBSQgEBSgkA4QgjA2gtAAIgEAAg");
	var mask_graphics_55 = new cjs.Graphics().p("AHfEjIvQguQgygCggg9Qghg8AEhTQAEhSAmg5QAmg5AyADIPQAuQAyADAgA7QAhA8gEBTQgEBTgnA4QgkA3gvAAIgEAAg");
	var mask_graphics_56 = new cjs.Graphics().p("AH8EnIwJgvQg1gCgjg+Qgig8AEhUQAEhTAng6QApg6A0ADIQJAvQA1ACAiA9QAjA8gEBUQgEBUgoA5QgmA4gyAAIgEAAg");
	var mask_graphics_57 = new cjs.Graphics().p("AIbErIxGgvQg4gCglg/Qglg9ADhVQAEhUAqg7QAqg6A4ACIRGAvQA4ACAlA9QAlA+gDBVQgEBVgqA6QgpA5g1AAIgEAAg");
	var mask_graphics_58 = new cjs.Graphics().p("AI8EuIyIguQg7gCgohAQgng+ADhWQAEhVAsg8QAsg7A8ACISIAuQA7ADAnA+QAoA+gDBXQgEBWgsA7QgrA6g4AAIgFgBg");
	var mask_graphics_59 = new cjs.Graphics().p("AJgEyIzPgtQg/gDgqhAQgqg/ADhYQADhWAvg9QAvg8A/ACITPAuQA/ACAqA/QAqBAgDBXQgDBYgvA8QgtA6g8AAIgFAAg");
	var mask_graphics_60 = new cjs.Graphics().p("AKGE2I0agsQhDgDgthBQgthAADhZQADhYAxg+QAyg9BDACIUaAtQBDACAsBAQAuBAgDBZQgDBZgyA9QgvA8hAAAIgFAAg");
	var mask_graphics_61 = new cjs.Graphics().p("AKuE6I1pgrQhGgCgxhCQgwhBADhbQADhZA0hAQA0g+BHADIVpAqQBGACAwBCQAxBBgDBaQgDBbg0A+QgyA9hEAAIgFAAg");
	var mask_graphics_62 = new cjs.Graphics().p("ALYE9I27goQhLgCgzhDQgzhCAChcQADhbA2hBQA3g/BLACIW7AoQBLACAzBDQAzBCgCBcQgDBcg3A/Qg1A/hIAAIgEgBg");
	var mask_graphics_63 = new cjs.Graphics().p("AMCFBI4OgmQhPgBg3hFQg2hDACheQAChcA5hCQA6hABQACIYOAlQBPACA2BDQA3BDgCBeQgCBeg6BAQg4BAhMAAIgFAAg");
	var mask_graphics_64 = new cjs.Graphics().p("AMuFEI5kgiQhUgCg6hFQg5hEAChfQAChfA8hCQA9hCBTACIZkAhQBUACA5BEQA6BFgCBfQgCBfg9BCQg6BBhRAAIgEAAg");
	var mask_graphics_65 = new cjs.Graphics().p("ANZFHI65geQhYgBg9hHQg9hFAChhQABhgA/hEQBAhDBYACIa5AdQBYACA8BFQA+BGgCBgQgBBhhABDQg+BDhVAAIgEAAg");
	var mask_graphics_66 = new cjs.Graphics().p("AOEFJI8OgZQhcgBhAhHQhAhGABhjQABhhBChGQBDhEBcABIcOAZQBcABA/BGQBBBIgBBhQgBBjhDBEQhBBEhaAAIgDAAg");
	var mask_graphics_67 = new cjs.Graphics().p("AOuFLI9ggTQhggBhEhJQhDhHABhkQABhjBEhGQBGhGBgABIdgAUQBgABBDBHQBEBIgBBjQgBBkhFBFQhEBGheAAIgDAAg");
	var mask_graphics_68 = new cjs.Graphics().p("APXFNI+wgOQhlgBhHhJQhGhIABhlQABhlBHhIQBIhHBkABIewAOQBlABBGBIQBHBJgBBkQgBBmhIBGQhGBIhjAAIgCAAg");
	var mask_graphics_69 = new cjs.Graphics().p("AP+FOI/9gIQhoAAhKhKQhJhJAAhnQABhmBJhJQBLhIBoAAIf9AIQBoABBJBIQBKBKAABmQgBBnhKBIQhKBJhnAAIgBAAg");
	var mask_graphics_70 = new cjs.Graphics().p("AQjFPMghFgACQhsAAhOhLQhLhJAAhpQAAhnBMhKQBNhKBsABMAhFAACQBsAABMBJQBNBLAABnQAABohNBKQhMBKhsAAIAAAAg");
	var mask_graphics_71 = new cjs.Graphics().p("A0DEHQhPhKAAhqQAAhpBOhLQBPhLBwAAMAiKgAEQBwAABOBKQBQBLAABpQAABqhPBKQhOBMhwAAMgiKAAEIgBAAQhvAAhPhLg");
	var mask_graphics_72 = new cjs.Graphics().p("A0pEKQhRhLAAhrQgBhqBRhMQBRhMBzAAMAjLgAKQBzgBBRBLQBSBMAABqQABBrhSBLQhQBNhzAAMgjLAAKIgBAAQhyAAhShLg");
	var mask_graphics_73 = new cjs.Graphics().p("A1MENQhThMgBhsQgBhqBThOQBThNB2AAMAkHgAQQB2gBBUBLQBUBNABBrQABBshUBMQhSBOh2ABMgkHAAQIgDAAQh0AAhUhMg");
	var mask_graphics_74 = new cjs.Graphics().p("A1tEQQhVhMgBhtQgBhsBUhPQBWhNB4gCMAlAgAVQB5gBBVBLQBXBNABBsQABBuhVBNQhVBPh4ABMglAAAWIgDAAQh3AAhWhMg");
	var mask_graphics_75 = new cjs.Graphics().p("A2LESQhXhMgChuQgBhtBWhQQBXhOB8gCMAlzgAbQB8gBBXBMQBaBOABBtQABBuhXBOQhWBPh8ACMglzAAbIgFAAQh4AAhYhMg");
	var mask_graphics_76 = new cjs.Graphics().p("A2nEVQhZhNgChvQgBhuBXhQQBZhQB+gBMAmkgAhQB+gCBZBNQBbBOACBuQABBvhYBPQhYBQh+ACMgmkAAhIgFAAQh7AAhZhMg");
	var mask_graphics_77 = new cjs.Graphics().p("A3BEXQhbhNgChwQgBhvBYhRQBbhQCAgCMAnRgAmQCAgCBbBNQBdBPACBuQABBwhaBQQhZBRiAACMgnRAAmIgGAAQh8AAhbhMg");
	var mask_graphics_78 = new cjs.Graphics().p("A3ZEZQhdhOgChwQgBhwBahSQBchQCCgDMAn6gArQCCgCBdBOQBfBPACBvQABBxhbBQQhbBSiCACMgn6AArIgHABQh+AAhchNg");
	var mask_graphics_79 = new cjs.Graphics().p("A3vEbQhehOgChxQgChxBbhSQBdhSCEgCMAohgAwQCEgCBeBOQBgBPACBwQACBxhdBSQhbBSiEADMgohAAvIgHABQiAAAhdhNg");
	var mask_graphics_80 = new cjs.Graphics().p("A4DEcQhghOgChyQgChxBchTQBfhSCGgCMApDgA0QCGgDBfBOQBiBQACBwQACByheBSQhdBUiGACMgpDAA0IgIAAQiBAAhehNg");
	var mask_graphics_81 = new cjs.Graphics().p("A4VEeQhhhOgDhzQgChxBdhUQBghTCHgDMApjgA4QCIgDBhBPQBiBQADBxQACBzhfBSQheBUiHADMgpjAA4IgJAAQiCAAhfhNg");
	var mask_graphics_82 = new cjs.Graphics().p("A4mEgQhihPgDhzQgDhyBfhVQBghTCJgDMAqAgA8QCJgDBjBPQBjBQADByQADBzhhBTQheBUiJADMgqAAA8IgKABQiDAAhghNg");
	var mask_graphics_83 = new cjs.Graphics().p("A42EhQhjhPgDh0QgChyBfhVQBhhUCLgDMAqagA/QCLgEBjBPQBlBRADByQACB0hhBTQhfBViLADMgqaABAIgLAAQiEAAhhhNg");
	var mask_graphics_84 = new cjs.Graphics().p("A5EEiQhkhPgDh0QgChzBghVQBihUCLgEMAqzgBDQCMgDBkBPQBmBRADBzQACB0hhBUQhhBViLADMgqzABDIgLAAQiFAAhihNg");
	var mask_graphics_85 = new cjs.Graphics().p("A5QEjQhlhPgDh1QgDhzBhhWQBihUCNgEMArJgBFQCNgEBlBPQBmBRADBzQADB1hiBUQhhBWiNADMgrJABGIgMAAQiFAAhihNg");
	var mask_graphics_86 = new cjs.Graphics().p("A5cEkQhmhPgDh1QgDh0BihWQBjhVCOgDMArcgBJQCOgEBmBQQBoBRADBzQADB1hkBVQhhBWiOAEMgrcABIIgNAAQiGAAhjhNg");
	var mask_graphics_87 = new cjs.Graphics().p("A5mElQhnhQgDh1QgDh0BihWQBkhVCPgEMArugBLQCPgEBmBQQBpBRADB0QADB1hkBVQhiBWiPAEMgruABLIgNAAQiGAAhkhNg");
	var mask_graphics_88 = new cjs.Graphics().p("A5vEmQhnhQgEh1QgDh1BjhWQBkhWCQgEMAr+gBNQCPgEBnBQQBpBRAEB0QADB2hlBVQhiBXiQAEMgr+ABNIgNAAQiHAAhkhNg");
	var mask_graphics_89 = new cjs.Graphics().p("A53EnQhohQgDh2QgEh1BkhXQBkhVCQgEMAsNgBQQCQgEBoBQQBpBRADB2QAEB1hlBVQhjBXiQAEMgsNABQIgNAAQiIAAhkhNg");
	var mask_graphics_90 = new cjs.Graphics().p("A5+EnQhphQgDh2QgDh1BjhXQBlhWCRgEMAsZgBRQCQgEBpBQQBqBRADB2QADB1hlBWQhjBXiRAEMgsZABRIgOAAQiIAAhkhNg");
	var mask_graphics_91 = new cjs.Graphics().p("A6FEoQhohQgEh2QgDh2BkhXQBlhWCSgEMAsjgBTQCRgEBpBQQBqBRAEB2QADB2hlBWQhkBXiSAEMgsjABTIgOAAQiJAAhlhNg");
	var mask_graphics_92 = new cjs.Graphics().p("A6KEoQhphQgDh2QgEh2BkhXQBmhWCSgFMAssgBUQCSgEBpBQQBrBSADB2QAEB1hmBXQhkBXiSAEMgssABUIgPABQiJAAhlhOg");
	var mask_graphics_93 = new cjs.Graphics().p("A6OEpQhqhRgDh2QgEh1BlhYQBmhWCSgFMAs0gBVQCSgEBqBQQBrBRADB3QAEB1hmBXQhlBXiSAFMgs0ABVIgPAAQiJAAhlhNg");
	var mask_graphics_94 = new cjs.Graphics().p("A6SEpQhqhQgDh3QgEh1BlhYQBmhXCTgEMAs6gBWQCTgFBpBRQBsBRADB3QAEB1hmBXQhlBYiTAEMgs6ABWIgPAAQiJAAhmhNg");
	var mask_graphics_95 = new cjs.Graphics().p("A6VEpQhqhQgDh3QgEh1BlhYQBmhXCTgEMAtAgBXQCTgFBpBRQBsBRADB3QAEB2hmBWQhlBYiTAEMgtAABXIgPABQiJAAhmhOg");
	var mask_graphics_96 = new cjs.Graphics().p("A6XEpQhqhQgEh3QgDh1BkhYQBnhXCTgEMAtEgBYQCTgEBqBQQBrBSAEB2QADB2hmBXQhlBYiTAEMgtEABXIgPABQiJAAhmhOg");
	var mask_graphics_97 = new cjs.Graphics().p("A6ZEpQhqhQgEh3QgDh1BlhYQBmhXCUgFMAtGgBXQCTgFBqBRQBsBRAEB3QADB2hmBWQhlBYiUAFMgtGABYIgPAAQiKAAhmhOg");
	var mask_graphics_98 = new cjs.Graphics().p("A6aEqQhqhRgEh3QgDh1BlhYQBnhXCTgFMAtIgBYQCTgEBqBQQBsBSAEB3QADB1hmBXQhlBYiUAFMgtIABYIgPAAQiKAAhmhNg");
	var mask_graphics_99 = new cjs.Graphics().p("A6aEtQhqhRgEh2QgEh2BmhYQBmhXCUgEMAtIgBZQCTgEBqBQQBsBSAEB3QADB2hmBWQhlBYiTAFMgtJABYIgPAAQiKAAhmhNg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(46).to({graphics:mask_graphics_46,x:-45.0292,y:26.7965}).wait(1).to({graphics:mask_graphics_47,x:-44.739,y:26.9748}).wait(1).to({graphics:mask_graphics_48,x:-44.4113,y:27.1734}).wait(1).to({graphics:mask_graphics_49,x:-42.7799,y:27.3929}).wait(1).to({graphics:mask_graphics_50,x:-39.9634,y:27.6336}).wait(1).to({graphics:mask_graphics_51,x:-36.8318,y:27.8957}).wait(1).to({graphics:mask_graphics_52,x:-33.3649,y:28.1791}).wait(1).to({graphics:mask_graphics_53,x:-29.5426,y:28.4832}).wait(1).to({graphics:mask_graphics_54,x:-25.346,y:28.807}).wait(1).to({graphics:mask_graphics_55,x:-20.7581,y:29.1491}).wait(1).to({graphics:mask_graphics_56,x:-15.7659,y:29.5071}).wait(1).to({graphics:mask_graphics_57,x:-10.3623,y:29.8779}).wait(1).to({graphics:mask_graphics_58,x:-4.5488,y:30.2575}).wait(1).to({graphics:mask_graphics_59,x:1.6618,y:30.6408}).wait(1).to({graphics:mask_graphics_60,x:8.2425,y:31.0219}).wait(1).to({graphics:mask_graphics_61,x:15.1503,y:31.3943}).wait(1).to({graphics:mask_graphics_62,x:22.3252,y:31.7511}).wait(1).to({graphics:mask_graphics_63,x:29.6918,y:32.0858}).wait(1).to({graphics:mask_graphics_64,x:37.1632,y:32.3923}).wait(1).to({graphics:mask_graphics_65,x:44.6467,y:32.6662}).wait(1).to({graphics:mask_graphics_66,x:52.051,y:32.9045}).wait(1).to({graphics:mask_graphics_67,x:59.2923,y:33.1063}).wait(1).to({graphics:mask_graphics_68,x:66.2998,y:33.272}).wait(1).to({graphics:mask_graphics_69,x:73.0181,y:33.4036}).wait(1).to({graphics:mask_graphics_70,x:79.4078,y:33.5041}).wait(1).to({graphics:mask_graphics_71,x:85.4443,y:33.7752}).wait(1).to({graphics:mask_graphics_72,x:91.1153,y:34.1266}).wait(1).to({graphics:mask_graphics_73,x:96.4188,y:34.4534}).wait(1).to({graphics:mask_graphics_74,x:101.3599,y:34.7565}).wait(1).to({graphics:mask_graphics_75,x:105.9489,y:35.0367}).wait(1).to({graphics:mask_graphics_76,x:110.1995,y:35.2952}).wait(1).to({graphics:mask_graphics_77,x:114.1275,y:35.5331}).wait(1).to({graphics:mask_graphics_78,x:117.7495,y:35.7518}).wait(1).to({graphics:mask_graphics_79,x:121.0824,y:35.9523}).wait(1).to({graphics:mask_graphics_80,x:124.1428,y:36.1359}).wait(1).to({graphics:mask_graphics_81,x:126.947,y:36.3037}).wait(1).to({graphics:mask_graphics_82,x:129.5102,y:36.4567}).wait(1).to({graphics:mask_graphics_83,x:131.847,y:36.5959}).wait(1).to({graphics:mask_graphics_84,x:133.9709,y:36.7221}).wait(1).to({graphics:mask_graphics_85,x:135.8948,y:36.8362}).wait(1).to({graphics:mask_graphics_86,x:137.6303,y:36.939}).wait(1).to({graphics:mask_graphics_87,x:139.1886,y:37.0311}).wait(1).to({graphics:mask_graphics_88,x:140.5796,y:37.1133}).wait(1).to({graphics:mask_graphics_89,x:141.813,y:37.186}).wait(1).to({graphics:mask_graphics_90,x:142.8973,y:37.2499}).wait(1).to({graphics:mask_graphics_91,x:143.8408,y:37.3055}).wait(1).to({graphics:mask_graphics_92,x:144.6508,y:37.3531}).wait(1).to({graphics:mask_graphics_93,x:145.3344,y:37.3933}).wait(1).to({graphics:mask_graphics_94,x:145.898,y:37.4264}).wait(1).to({graphics:mask_graphics_95,x:146.3475,y:37.4528}).wait(1).to({graphics:mask_graphics_96,x:146.6887,y:37.4728}).wait(1).to({graphics:mask_graphics_97,x:146.9265,y:37.4868}).wait(1).to({graphics:mask_graphics_98,x:147.066,y:37.495}).wait(1).to({graphics:mask_graphics_99,x:147.1327,y:37.8241}).wait(1));

	// Layer_2 copy 2
	this.instance = new lib.line_c();
	this.instance.setTransform(97.35,22.5,1,1,0,0,0,213.5,35);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(46).to({_off:false},0).wait(54));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_28 = new cjs.Graphics().p("AATB8QgXgKgXgZQgWgZgIgZQgIgZAMgKIDijOQAMgKAYAKQAYAKAXAZQAWAYAIAaQAIAZgMAKIjjDOQgGAFgJAAQgJAAgMgFg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AABCMQgXgJgXgZQgXgZgHgaQgHgZAMgLIDyjcQAMgLAZAKQAZAJAWAZQAXAZAHAaQAHAZgMALIjzDcQgGAGgLAAQgIAAgMgFg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AgTCfQgZgJgXgYQgWgZgHgaQgHgaAOgNIEDjrQANgMAaAJQAZAJAWAZQAXAZAHAaQAGAagNAMIkEDrQgIAHgLAAQgIAAgLgEg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AgrC1QgagIgXgZQgWgZgGgaQgGgbAOgNIEYj+QAOgNAaAIQAaAJAXAYQAWAZAGAbQAGAbgOANIkYD+QgJAIgNAAQgIAAgKgEg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AhGDMQgbgIgWgZQgXgYgFgcQgFgbAPgOIEukTQAQgOAbAIQAbAIAWAZQAXAYAFAcQAFAbgQAOIkuETQgKAJgOAAQgIAAgKgDg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AhjDZQgcgHgWgZQgXgZgEgcQgEgcARgPIFGkpQAQgPAcAHQAcAHAWAZQAXAZAEAcQAEAcgQAPIlGEoQgMALgRAAQgHAAgJgCg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AiBDmQgdgGgXgYQgWgZgDgdQgEgeASgQIFgk/QASgQAdAGQAcAGAXAYQAWAZAEAdQADAegSAQIlgE/QgNAMgTAAQgHAAgHgCg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AihD1QgegGgWgYQgXgZgCgeQgDgeAUgSIF6lXQATgSAeAGQAdAFAXAYQAWAZADAeQACAegTASIl6FXQgPAOgVAAIgNgBg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AjCEDQgegEgXgZQgXgZgBgfQgBgfAVgTIGVlvQAUgTAfAEQAfAEAWAZQAXAZABAfQABAfgUATImVFvQgRAQgYAAIgLgBg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AjXESQgggEgWgZQgXgYAAggQAAggAWgUIGwmJQAWgUAgADQAfAEAXAZQAWAYABAgQAAAggWAUImwGJQgTARgaAAIgJAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AjnEgQghgCgWgZQgXgZABghQABggAXgWIHMmhQAXgWAhADQAgACAXAZQAWAZAAAhQgBAggXAWInMGhQgVATgcAAIgHAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Aj3EuQghgBgXgZQgXgZACghQACgiAZgXIHmm5QAZgXAiACQAhABAXAZQAWAZgBAhQgCAigZAXInmG5QgYAVgeAAIgFAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AkGE8QgjAAgWgZQgXgZADgjQACgiAbgYIIAnRQAagYAjABQAiAAAXAZQAWAZgCAjQgDAigaAYIoAHRQgaAXghAAIgCAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AlPExQgWgZAEgjQADgjAbgZIIZnpQAcgYAkgBQAjAAAWAZQAXAZgDAjQgEAjgcAZIoZHpQgbAYgjABIgBAAQgjAAgXgZg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AldE+QgXgZAFgkQAEgkAcgaIIxn9QAdgaAkgBQAkgBAXAZQAWAZgEAkQgEAkgdAaIoxH9QgcAagkABIgDAAQgjAAgVgYg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AlrFLQgWgZAFglQAFglAdgbIJHoRQAegbAlgCQAlgBAXAYQAWAZgFAlQgFAlgeAbIpHIRQgdAbglACIgFAAQgiAAgVgXg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Al3FWQgXgZAGglQAGgmAegcIJbojQAfgcAmgCQAmgDAWAZQAXAZgGAlQgGAmgfAcIpbIjQgeAcgmACIgGABQgiAAgUgXg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AmDFgQgWgZAHgmQAGgmAggdIJsozQAggdAngDQAmgDAWAZQAXAZgGAmQgHAmggAdIpsIzQggAdgmADIgIAAQghAAgVgWg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AmMFpQgXgZAHgmQAHgnAhgdIJ8pDQAggdAogDQAmgEAXAZQAXAZgHAmQgIAnggAdIp8JDQghAdgnADIgJABQghAAgTgWg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AmVFxQgWgZAIgnQAHgnAhgeIKKpPQAhgeAogEQAngDAWAZQAXAYgHAnQgIAnghAeIqKJPQghAegnAEIgLAAQggAAgUgVg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(28).to({graphics:mask_1_graphics_28,x:28.9288,y:-20.8254}).wait(1).to({graphics:mask_1_graphics_29,x:28.8588,y:-20.7589}).wait(1).to({graphics:mask_1_graphics_30,x:28.7788,y:-20.6824}).wait(1).to({graphics:mask_1_graphics_31,x:28.6912,y:-20.5982}).wait(1).to({graphics:mask_1_graphics_32,x:28.5984,y:-20.3558}).wait(1).to({graphics:mask_1_graphics_33,x:28.5028,y:-18.9403}).wait(1).to({graphics:mask_1_graphics_34,x:28.4064,y:-17.4438}).wait(1).to({graphics:mask_1_graphics_35,x:28.3111,y:-15.8885}).wait(1).to({graphics:mask_1_graphics_36,x:28.2184,y:-14.2965}).wait(1).to({graphics:mask_1_graphics_37,x:26.9652,y:-12.6896}).wait(1).to({graphics:mask_1_graphics_38,x:25.1929,y:-11.0894}).wait(1).to({graphics:mask_1_graphics_39,x:23.4494,y:-9.5162}).wait(1).to({graphics:mask_1_graphics_40,x:21.7574,y:-7.9896}).wait(1).to({graphics:mask_1_graphics_41,x:20.1371,y:-6.5276}).wait(1).to({graphics:mask_1_graphics_42,x:18.6068,y:-5.1467}).wait(1).to({graphics:mask_1_graphics_43,x:17.183,y:-3.8618}).wait(1).to({graphics:mask_1_graphics_44,x:15.8807,y:-2.6864}).wait(1).to({graphics:mask_1_graphics_45,x:14.7128,y:-1.6323}).wait(1).to({graphics:mask_1_graphics_46,x:13.6905,y:-0.7095}).wait(1).to({graphics:mask_1_graphics_47,x:14.0984,y:-1.0854}).wait(53));

	// Layer_2 copy
	this.instance_1 = new lib.line_c();
	this.instance_1.setTransform(97.35,22.5,1,1,0,0,0,213.5,35);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(28).to({_off:false},0).wait(72));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("ArjBlQgNgagGgpQgGgnAEgdQAEgeAMgCIDpgiQAMgCAMAbQANAbAGAoQAGAngEAeQgEAegMABIjpAjIgBAAQgLAAgMgag");
	var mask_2_graphics_10 = new cjs.Graphics().p("ArkBmQgMgbgGgoQgGgoAEgdQAEgeAMgCIDqgjQAMgBANAbQANAbAGAoQAGAngFAdQgEAegMACIjqAjIgBAAQgMAAgMgZg");
	var mask_2_graphics_11 = new cjs.Graphics().p("ArjBlQgNgagGgoQgGgoAFgdQAEgeAMgCIDwgkQANgBAMAaQANAcAGAoQAGAngEAdQgFAegMACIjwAkIgBAAQgMAAgMgag");
	var mask_2_graphics_12 = new cjs.Graphics().p("AriBlQgNgagGgpQgGgnAFgeQAFgdAMgCID7glQAMgCANAbQAOAbAGAoQAGAngFAeQgFAdgNACIj6AmIgBAAQgMAAgNgag");
	var mask_2_graphics_13 = new cjs.Graphics().p("ArgBlQgOgbgGgoQgGgnAGgeQAFgdAOgCIEJgoQAOgCANAbQAOAbAGAoQAGAngFAeQgGAegNACIkKAnIgBAAQgNAAgNgZg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AreBlQgOgbgGgoQgGgnAGgeQAGgeAPgCIEfgrQAOgCAPAbQAOAbAGAoQAGAngGAeQgGAegOACIkfArIgCAAQgOAAgOgZg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AraBlQgQgbgGgoQgGgnAHgeQAIgeAQgDIE6gvQAQgCAQAaQAQAbAGAoQAGAngIAeQgHAfgQACIk7AvIgCAAQgPAAgOgYg");
	var mask_2_graphics_16 = new cjs.Graphics().p("ArWBkQgRgagGgoQgGgnAIgfQAJgeASgDIFfg0QASgDARAbQARAaAGAoQAGAogJAeQgIAegSADIlfA0IgDAAQgRAAgPgYg");
	var mask_2_graphics_17 = new cjs.Graphics().p("ArRBnQgSgagGgoQgGgnAKgfQAKgeAUgDIGMg7QAVgDASAaQATAaAGAoQAGAngKAfQgKAegVADImMA7IgEABQgSAAgRgYg");
	var mask_2_graphics_18 = new cjs.Graphics().p("ArKBsQgVgagGgoQgGgoAMgeQANgfAXgDIHEhEQAXgDAUAaQAVAaAGAoQAGAogNAeQgLAfgYADInDBEIgGAAQgUAAgSgXg");
	var mask_2_graphics_19 = new cjs.Graphics().p("ArCByQgXgagGgoQgGgoAOgeQAPgfAagEIIHhOQAagEAXAaQAXAaAGAoQAGAogOAeQgPAfgaAEIoHBOIgHAAQgWAAgUgWg");
	var mask_2_graphics_20 = new cjs.Graphics().p("Aq5B5QgagZgGgoQgGgpARgeQASggAegEIJVhZQAegFAaAZQAZAZAGAoQAGApgRAeQgRAggeAEIpVBZIgJABQgZAAgWgVg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AqvCAQgcgYgGgoQgGgoAUggQAVggAigFIKshmQAigFAdAYQAdAZAGAoQAGAogUAfQgVAhgiAFIqsBmIgMABQgcAAgYgVg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AqkCIQgggYgGgoQgGgoAYggQAYggAogGIMIh0QAogGAgAYQAhAZAGAoQAGAogYAfQgYAhgoAGIsIB0IgQABQgeAAgbgUg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AqYCRQgkgYgGgoQgGgoAbghQAcggAsgHINniCQAtgHAjAYQAkAYAGAoQAGAogbAhQgbAggtAHItnCCIgTABQghAAgcgSg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AqOCZQgmgXgGgoQgGgoAegiQAfghAxgHIPBiQQAxgHAnAXQAnAXAGAoQAGAogfAiQgeAhgxAHIvBCQQgMACgLAAQgkAAgegSg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AqECgQgpgXgGgoQgGgoAhgiQAighA1gIIQUicQA1gIAqAXQAqAXAGAoQAGAogiAiQghAhg1AIIwUCcQgOACgNAAQglAAgggRg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AqGCmQgsgWgGgoQgGgoAkgjQAkghA5gIIReinQA5gJAsAWQAtAXAGAoQAGAogkAiQgkAig5AIIxeCnQgPADgPAAQgnAAghgRg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AqrCsQgvgWgGgoQgGgoAmgjQAngiA8gJISeiwQA8gJAvAWQAvAWAGAoQAGAognAjQgmAig8AJIyeCwQgRADgRAAQgoAAghgQg");
	var mask_2_graphics_28 = new cjs.Graphics().p("ArMCxQgwgWgGgoQgGgoAogjQApgjA/gIITUi5QA/gKAxAWQAxAWAGAoQAGAogpAjQgoAjg/AIIzUC5QgTADgSAAQgpAAgjgPg");
	var mask_2_graphics_29 = new cjs.Graphics().p("ArnC1QgzgVgGgoQgGgoAqgkQArgjBBgJIUEjAQBBgKAzAWQAzAVAGAoQAGAogrAkQgqAjhBAJI0EDAQgUADgTAAQgqAAgjgPg");
	var mask_2_graphics_30 = new cjs.Graphics().p("Ar/C5QgzgWgGgoQgGgoArgjQAsgkBDgKIUsjFQBDgKA0AVQA0AWAGAoQAGAogsAjQgrAkhDAKI0sDFQgVADgUAAQgrAAgkgOg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:-76.2435,y:12.7165}).wait(10).to({graphics:mask_2_graphics_10,x:-76.2717,y:12.7224}).wait(1).to({graphics:mask_2_graphics_11,x:-76.2202,y:12.7087}).wait(1).to({graphics:mask_2_graphics_12,x:-76.1286,y:12.6841}).wait(1).to({graphics:mask_2_graphics_13,x:-75.9914,y:12.6471}).wait(1).to({graphics:mask_2_graphics_14,x:-75.8025,y:12.5959}).wait(1).to({graphics:mask_2_graphics_15,x:-75.5543,y:12.5283}).wait(1).to({graphics:mask_2_graphics_16,x:-75.2382,y:12.4417}).wait(1).to({graphics:mask_2_graphics_17,x:-74.8449,y:11.9902}).wait(1).to({graphics:mask_2_graphics_18,x:-74.365,y:11.3009}).wait(1).to({graphics:mask_2_graphics_19,x:-73.792,y:10.4729}).wait(1).to({graphics:mask_2_graphics_20,x:-73.1263,y:9.5066}).wait(1).to({graphics:mask_2_graphics_21,x:-72.3819,y:8.4218}).wait(1).to({graphics:mask_2_graphics_22,x:-71.5889,y:7.2629}).wait(1).to({graphics:mask_2_graphics_23,x:-70.7897,y:6.0925}).wait(1).to({graphics:mask_2_graphics_24,x:-70.0261,y:4.9723}).wait(1).to({graphics:mask_2_graphics_25,x:-69.3271,y:3.9459}).wait(1).to({graphics:mask_2_graphics_26,x:-67.612,y:3.0341}).wait(1).to({graphics:mask_2_graphics_27,x:-62.5484,y:2.2401}).wait(1).to({graphics:mask_2_graphics_28,x:-58.1957,y:1.5575}).wait(1).to({graphics:mask_2_graphics_29,x:-54.4862,y:0.9758}).wait(1).to({graphics:mask_2_graphics_30,x:-52.2126,y:0.7928}).wait(70));

	// Layer_2
	this.instance_2 = new lib.line_c();
	this.instance_2.setTransform(97.35,22.5,1,1,0,0,0,213.5,35);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-119.1,-15.5,433,76.1);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_42 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(42).call(this.frame_42).wait(1));

	// Layer_6
	this.text = new cjs.Text("0", "22px 'Segoe Pro Semibold'", "#505050");
	this.text.textAlign = "center";
	this.text.lineHeight = 32;
	this.text.lineWidth = 36;
	this.text.parent = this;
	this.text.setTransform(206.6509,145.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(10).to({text:"2"},0).wait(1).to({text:"5"},0).wait(1).to({text:"8"},0).wait(1).to({text:"13"},0).wait(1).to({text:"19"},0).wait(1).to({text:"26"},0).wait(1).to({text:"34"},0).wait(1).to({text:"43"},0).wait(1).to({text:"52"},0).wait(1).to({text:"61"},0).wait(1).to({text:"78"},0).wait(1).to({text:"93"},0).wait(1).to({text:"100"},0).wait(1).to({text:"106"},0).wait(1).to({text:"112"},0).wait(1).to({text:"117"},0).wait(1).to({text:"121"},0).wait(1).to({text:"125"},0).wait(1).to({text:"128"},0).wait(1).to({text:"131"},0).wait(2).to({text:"133"},0).wait(2).to({text:"135"},0).wait(2).to({text:"138"},0).wait(2).to({text:"139"},0).wait(6));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_2 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_3 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_4 = new cjs.Graphics().p("ACeQwQjgjWgIk2IAAgFIXYglIAAAFQAIE2jVDhQjWDgk3AIIgVAAQkoAAjZjOg");
	var mask_graphics_5 = new cjs.Graphics().p("ACcQvQjfjWgHk2IAAgFIXYgjIAAAFQAIE2jWDhQjXDgk2AHIgUAAQkpAAjajPg");
	var mask_graphics_6 = new cjs.Graphics().p("ACaQtQjejXgGk2IAAgFIXYgdIABAFQAFE2jWDgQjYDfk2AGIgRAAQkrAAjajRg");
	var mask_graphics_7 = new cjs.Graphics().p("ACXQqQjdjZgEk2IAAgFIXZgTIAAAFQAEE2jZDfQjYDdk3AEIgLAAQkvAAjajUg");
	var mask_graphics_8 = new cjs.Graphics().p("ACSQlQjbjbgBk2IAAgFIXZgFIAAAFQABE2jbDdQjbDbk2ABIgDAAQk0AAjbjZg");
	var mask_graphics_9 = new cjs.Graphics().p("AKaT+Qk2gDjZjdQjZjeAEk2IAAgFIXZAPIAAAFQgEE2jdDaQjaDVkxAAIgJAAg");
	var mask_graphics_10 = new cjs.Graphics().p("AKNT+Qk2gJjWjhQjUjhAJk3IAAgFIXYAqIAAAFQgIE3jhDVQjZDMknAAIgYAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AJ8T9Qk2gPjQjmQjPjnAQk2IAAgFIXXBMIAAAFQgQE2jmDQQjWDBkbAAIgrgBg");
	var mask_graphics_12 = new cjs.Graphics().p("AJnT8Qk1gZjJjsQjJjsAZk1IAAgFIXUB3IAAAFQgZE1jrDKQjTCykMAAQghAAgigCg");
	var mask_graphics_13 = new cjs.Graphics().p("AJOT5Qk0gjjBjzQjAjzAjk0IABgFIXPCqIAAAFQgkE1jyDBQjOCjj8AAQguAAgwgGg");
	var mask_graphics_14 = new cjs.Graphics().p("AIxT1Qkygwi3j7Qi2j7AxkzIAAgFIXHDpIgBAFQgwEzj6C3QjHCQjpAAQg+AAhAgKg");
	var mask_graphics_15 = new cjs.Graphics().p("AIQTuQkwg/iqkEQipkDA/kwIABgFIW6ExIgBAFQhAEwkDCqQi9B8jUAAQhQAAhSgRg");
	var mask_graphics_16 = new cjs.Graphics().p("AHrTjQkshQibkNQiakNBRksIABgEIWmGFIgBAFQhREskNCbQiwBli+AAQhjAAhngcg");
	var mask_graphics_17 = new cjs.Graphics().p("AHCTVQklhliJkWQiIkXBlklIABgFIWJHlIgCAEQhkEmkXCJQigBOilAAQh6AAh9gqg");
	var mask_graphics_18 = new cjs.Graphics().p("AGXTAQkdh6hzkgQhzkgB6keIACgEIVgJPIgBAEQh7EekgBzQiLA3iLAAQiUAAiTg/g");
	var mask_graphics_19 = new cjs.Graphics().p("AFqSkQkRiShZkpQhakpCRkSIADgEIUpLDIgDAEQiSESkpBaQhxAihtAAQizAAiqhbg");
	var mask_graphics_20 = new cjs.Graphics().p("AE/R/QkCisg9kwQg8kwCrkDIADgEITeM/IgDAFQisECkwA9QhPAQhMAAQjYAAi/iAg");
	var mask_graphics_21 = new cjs.Graphics().p("AEWRPQjujHgck1Qgbk1DGjuIADgEIR+PBIgDAEQjIDuk0AcQglADglAAQkIAAjRivg");
	var mask_graphics_22 = new cjs.Graphics().p("AL9T9Qk2gKjUjiQjVjiAKk2QAJk2DijUIAEgDIQCRDIgEADQjYDMkmAAIgagBg");
	var mask_graphics_23 = new cjs.Graphics().p("ALGT1Qkzgvi4j7Qi3j5AukzQAvkzD6i3IAEgDIN4S2IgEADQjICTjsAAQg7AAg+gJg");
	var mask_graphics_24 = new cjs.Graphics().p("AKYTjQkrhPickNQickMBPksQBQksEMibIAEgCILxUOIgFADQiyBnjAAAQhhAAhlgbg");
	var mask_graphics_25 = new cjs.Graphics().p("AJzTNQkihsiCkbQiBkZBskjQBskiEaiBIAFgDIJwVRIgFADQiaBGicAAQiDAAiEgxg");
	var mask_graphics_26 = new cjs.Graphics().p("AJVS0QkYiFhokkQhpkkCFkZQCEkXElhpIAFgCIH4WCIgFACQiBAuh/AAQigAAidhKg");
	var mask_graphics_27 = new cjs.Graphics().p("AI+SaQkNiahSksQhSkrCZkNQCakNErhSIAFgBIGMWjIgFACQhoAchlAAQi8AAiwhjg");
	var mask_graphics_28 = new cjs.Graphics().p("AIsSAQkDisg+kwQg+kwCrkCQCrkCExg+IAFgBIErW6IgFABQhRARhOAAQjWAAi+h9g");
	var mask_graphics_29 = new cjs.Graphics().p("AIeRnQj4i6gtkzQgskzC5j5QC6j3EzgtIAFAAIDXXJIgFABQg8AJg5AAQjvAAjIiWg");
	var mask_graphics_30 = new cjs.Graphics().p("AITRQQjvjGgdk1Qgdk0DFjwQDGjuE1gdIAFAAICNXSIgFAAQgoAEgmAAQkGAAjQisg");
	var mask_graphics_31 = new cjs.Graphics().p("AILQ8QjmjQgRk2QgQk2DQjmQDPjmE2gQIAFAAIBPXXIgFAAIgtABQkaAAjWjAg");
	var mask_graphics_32 = new cjs.Graphics().p("AIFQqQjfjYgFk2QgGk2DXjfQDYjfE2gFIAFAAIAbXZIgFAAIgQAAQksAAjajSg");
	var mask_graphics_33 = new cjs.Graphics().p("AQIT8Qk3gEjZjdQjYjeADk3QADk2DejYQDejZE2AEIAFAAIgQXZIgFAAg");
	var mask_graphics_34 = new cjs.Graphics().p("APuT7Qk2gKjUjiQjUjjALk3QAKk1DjjTQDijUE3AKIAFAAIgzXZIgFgBg");
	var mask_graphics_35 = new cjs.Graphics().p("APaT7Qk2gQjQjmQjPjnAQk2QAQk1DmjPQDmjQE2AQIAFAAIhNXXIgFAAg");
	var mask_graphics_36 = new cjs.Graphics().p("APLT7Qk2gVjNjoQjMjqAUk1QAVk2DojMQDqjME1AUIAFAAIhhXWIgFAAg");
	var mask_graphics_37 = new cjs.Graphics().p("APAT6Qk1gXjLjrQjKjrAXk1QAXk2DrjJQDrjLE2AYIAFAAIhwXVIgFgBg");
	var mask_graphics_38 = new cjs.Graphics().p("AO5T6Qk1gZjJjsQjJjtAZk1QAZk1DsjIQDtjJE1AZIAFAAIh5XVIgFgBg");
	var mask_graphics_39 = new cjs.Graphics().p("AO1T6Qk2gajIjtQjHjtAak2QAak1DtjHQDujIE1AaIAFABIh/XTIgFAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AOzT6Qk2gbjHjtQjIjuAbk1QAbk1DujHQDtjHE2AbIAFAAIiCXTIgFAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AOyT6Qk2gbjHjuQjHjuAbk1QAbk1DujGQDujIE1AcIAFAAIiDXTIgFAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AOxT6Qk1gbjHjuQjHjuAbk1QAbk1DujGQDtjIE2AcIAFAAIiEXTIgFAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:142.2699,y:127.8343}).wait(2).to({graphics:mask_graphics_2,x:142.2699,y:127.8343}).wait(1).to({graphics:mask_graphics_3,x:142.2704,y:127.8349}).wait(1).to({graphics:mask_graphics_4,x:142.2702,y:127.8348}).wait(1).to({graphics:mask_graphics_5,x:142.2695,y:127.8345}).wait(1).to({graphics:mask_graphics_6,x:142.2682,y:127.834}).wait(1).to({graphics:mask_graphics_7,x:142.2662,y:127.8333}).wait(1).to({graphics:mask_graphics_8,x:142.2637,y:127.8327}).wait(1).to({graphics:mask_graphics_9,x:142.2616,y:127.8328}).wait(1).to({graphics:mask_graphics_10,x:142.2496,y:127.8346}).wait(1).to({graphics:mask_graphics_11,x:142.2169,y:127.8391}).wait(1).to({graphics:mask_graphics_12,x:142.1487,y:127.8474}).wait(1).to({graphics:mask_graphics_13,x:142.0242,y:127.8603}).wait(1).to({graphics:mask_graphics_14,x:141.8153,y:127.8778}).wait(1).to({graphics:mask_graphics_15,x:141.4854,y:127.8985}).wait(1).to({graphics:mask_graphics_16,x:140.9878,y:127.9189}).wait(1).to({graphics:mask_graphics_17,x:140.2651,y:127.9332}).wait(1).to({graphics:mask_graphics_18,x:139.2483,y:127.934}).wait(1).to({graphics:mask_graphics_19,x:137.8571,y:127.9136}).wait(1).to({graphics:mask_graphics_20,x:136.0012,y:127.8686}).wait(1).to({graphics:mask_graphics_21,x:133.5835,y:127.8092}).wait(1).to({graphics:mask_graphics_22,x:130.5055,y:127.774}).wait(1).to({graphics:mask_graphics_23,x:127.0581,y:127.7881}).wait(1).to({graphics:mask_graphics_24,x:123.6803,y:127.8065}).wait(1).to({graphics:mask_graphics_25,x:120.4703,y:127.8041}).wait(1).to({graphics:mask_graphics_26,x:117.4932,y:127.7796}).wait(1).to({graphics:mask_graphics_27,x:114.7879,y:127.7409}).wait(1).to({graphics:mask_graphics_28,x:112.3729,y:127.6971}).wait(1).to({graphics:mask_graphics_29,x:110.2524,y:127.656}).wait(1).to({graphics:mask_graphics_30,x:108.4199,y:127.6222}).wait(1).to({graphics:mask_graphics_31,x:106.8618,y:127.5979}).wait(1).to({graphics:mask_graphics_32,x:105.56,y:127.5828}).wait(1).to({graphics:mask_graphics_33,x:105.3227,y:127.5755}).wait(1).to({graphics:mask_graphics_34,x:106.1797,y:127.5566}).wait(1).to({graphics:mask_graphics_35,x:106.8466,y:127.5283}).wait(1).to({graphics:mask_graphics_36,x:107.3474,y:127.4993}).wait(1).to({graphics:mask_graphics_37,x:107.706,y:127.4744}).wait(1).to({graphics:mask_graphics_38,x:107.9462,y:127.4558}).wait(1).to({graphics:mask_graphics_39,x:108.0919,y:127.4437}).wait(1).to({graphics:mask_graphics_40,x:108.1667,y:127.4373}).wait(1).to({graphics:mask_graphics_41,x:108.1942,y:127.4349}).wait(1).to({graphics:mask_graphics_42,x:108.1732,y:127.4316}).wait(1));

	// green_chart
	this.instance = new lib.green_bar();
	this.instance.setTransform(209.7,179.85,1,1,0,0,0,65.5,65.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(43));

	// blank_chart
	this.instance_1 = new lib.blank_chart();
	this.instance_1.setTransform(209.7,146.85,1,1,0,0,0,65.5,32.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(43));

	// Layer_1
	this.instance_2 = new lib.popup1();
	this.instance_2.setTransform(97.6,87.65,0.3957,0.3957);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(43));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(97.6,87.7,230.70000000000002,140.8);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(416.65,40.5,1.3176,1.3176,-102.8469,0,0,14.7,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(431.7,30.55,1.3175,1.3175,-133.8471,0,0,14.6,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(438.25,14.85,1.3177,1.3177,-173.8523,0,0,14.8,-0.1);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(320.3,-84.35,1.3568,1.3568,86.0024,0,0,14.8,-0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(303.75,-77.8,1.3568,1.3568,55.0034,0,0,14.8,-0.2);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(293.75,-64.8,1.3569,1.3569,14.9991,0,0,15.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// PPT_Icon
	this.ODIcon = new lib.collabIcon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(304.9,14.6,0.5341,0.5341,0,0,0,-75.4,149.2);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(144.5,23.6,1,1,0,0,0,144.5,23.6);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-153.6,-168,881.2,1097.1), null);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pptLogo
	this.pptLogo = new lib.pptLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(58.6,33,1,1,0,0,0,58.6,33);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(-32.1,143.6,1,1,0,0,0,76.7,69.8);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	// files
	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(233.2,155.5,1,1,0,0,0,213.8,157.9);

	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(204.35,167,1,1,0,0,0,217.5,176.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file2},{t:this.file1}]}).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(226.8,153.5,1,1,0,0,0,226.8,153.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x();
	this.instance.setTransform(38.35,20.5,0.4987,0.4987);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-78.8,-459.8,513.5,999.4000000000001), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AHMJGQgHAAgHgGIgGgHIg9hZQgKgRgOgJQgPgKgXgCIo2AAIAAv/IZLAAIAASLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:136.2271,y:-8.3745}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(189.65,74.95,0.7935,0.7935,0,0,0,205.5,150.3);

	var maskedShapeInstanceList = [this.ui];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.9,-52.1,391.29999999999995,242.29999999999998);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(143.1,550.7,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(149.45,550.15,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(150.95,362.55,1,1,0,0,0,206.7,147.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(81.65,38.25,0.57,0.57,0,0,0,86.2,11.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(273.5,216.1,1,1,0,0,0,31.9,173.9);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(228.5,332.8,1,1,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// Grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(126,52.5,1,1,0,0,0,126,52.5);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(12.2,145.9,1.5309,1.5309);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-91.7,-0.5,646.8000000000001,641.5), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.anim.line1.play();}});
				
				this.tl1.to(mc.anim,{duration:1.5, x: "-=310", ease:Power3.easeInOut}, "+=.4");
				this.tl1.to(mc.grid,{duration:1.5, x: "-=254", ease:Power3.easeInOut}, "<");
		
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<");
		
				//icon
				this.tl1.from(mc.anim.ODIcon.outlines,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut}, ">+.1");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">-.1");
		
				//chart transition
				this.tl1.to(mc.anim, {duration:.6, y:"+=0-", ease:Power2.easeInOut}, ">");
				this.tl1.to(mc.ui, {duration:.6, y:"+=75", ease:Power2.easeInOut}, ">");
		
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=75", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
				
				this.tl1.from(mc.ui.ui.file1,{duration:.6, x:"+=12", y:"-=47", scaleX:.35, scaleY:.35, ease:Power4.easeInOut, onComplete:function(){mc.ui.ui.file1.play(10);}}, ">+0.1");
						//this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, ease:Power4.easeOut, onComplete:function(){mc.highlights.play();}});
		
		
				this.tl1.to([mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.1, alpha:0}, ">+.6");
				this.tl1.to(mc.anim, {duration:.1, y:"-=70"}, ">+.3");
		
				this.tl1.to(mc.ui.ui,{duration:1, x:"+=6", y:"+=10", scaleX: .63, scaleY: .63, ease:Power3.easeInOut}, ">+.4");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"+=6", y:"+=10", alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"+=12", y:"-=47", scaleX:.37, scaleY:.37, ease:Power3.easeIn}, ">-1");
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
		
		
				this.tl1.from(mc.ui.ui.file2,{duration:.6, y:"+=05",x:"-=70", scaleX:.28, scaleY:.34, ease:Power4.easeInOut}, "<-.3");
				
				
				this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<-.5");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<-0");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=150", y:"-=150", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.1");
		
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
		
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"+=22", y:"+=70", scaleX: .6
					, scaleY: .6, ease:Power3.easeInOut}, ">+0.6");
				this.tl1.to(mc.ui.ui.pptLogo,{duration:1.2, scaleX: 1.1, scaleY: 1.1, ease:Power3.easeInOut}, ">-1.2");
				this.tl1.to(mc.anim,{duration:1.2, x:"+=40", y:"-=0", scaleX: .8, scaleY: .8, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"+=22", y:"+=70", scaleX: .6, scaleY: .6, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				
				this.tl1.to(mc.ui.ui.file2,{duration:.7,  y:"+=5",x:"-=70", scaleX:.29, scaleY:.35, ease:Power3.easeInOut}, ">-1");
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.3");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
		
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
					//		this.tl1.from(mc.finalFrameMC,{duration:.4, alpha:0, ease:Power3.easeOut}, "+=0");						
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ui.ad1,{duration:2, x:"-=120", y:"+=20",  ease:Power3.easeInOut, onStart:function(){mc.ui.ui.ad1.visible=true;}});
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(58.3,299.5,496.8,341.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622722574791", id:"M365_FY22Q1BTS_USA_300x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;