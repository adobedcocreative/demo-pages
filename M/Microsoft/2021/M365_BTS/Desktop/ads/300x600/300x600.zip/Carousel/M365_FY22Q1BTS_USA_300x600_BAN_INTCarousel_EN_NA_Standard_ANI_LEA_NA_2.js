(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1", frames: [[697,0,294,97],[343,272,343,239],[343,0,352,270],[697,99,166,166],[0,0,341,284],[0,286,335,233],[0,521,113,111],[865,99,103,181],[115,521,113,111],[697,267,103,181],[337,513,335,233],[0,634,113,111],[802,282,103,181],[674,513,335,233],[115,634,113,109],[907,282,103,181]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.angledShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.DesignerInWordPerennialsLargerRatio2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.EditorDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.EditorIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.EditorSocial2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ExcelDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ExcelIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ExcelMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Group242x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.PPTDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.PPTIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.PPTMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,559.07,1,2.3503);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414.1,978.7,1946.3000000000002);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707070").s().p("AgaAaQgKgMAAgOQAAgOAKgMQAMgKAOAAQAOAAAMAKQALAMgBAOQABAOgLAMQgMALgOgBQgOABgMgLg");
	this.shape.setTransform(0.05,0.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgZAZQgLgKAAgPQAAgOALgLQALgLAOAAQAPAAAKALQAMALAAAOQAAAPgMAKQgKAMgPAAQgOAAgLgMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.scribble5_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AK3NZQoEhlnPicIABABQvqlPgimUQhKjXBljMQBkjNDXhKQDXhKDNBkQDMBlBLDXQBGgnEQBbIABAAQGPCGG7BXQDfAtB/C8QB/C9gsDfQgsDfi9B/QiNBfifAAQg3AAg5gMg");
	this.shape.setTransform(135.147,86.872);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_2Sub, new cjs.Rectangle(0,0,270.3,173.8), null);


(lib.scribble5_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AtcOEQjigciNizQiNizAbjgQg+n4Q2mUQENhkEwhQIAAAAQEghMC7gYQDhgeC1CLQC2CKAeDhQAeDhiKC1QiLC1jhAfQiGASjQA3Qj5BBjaBRQj0BchBhUQgbDii0CNQiXB2i2AAQgjAAgkgEg");
	this.shape.setTransform(134.6501,90.4499);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_1Sub, new cjs.Rectangle(0,0,269.3,180.9), null);


(lib.scribble4_5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AnOIOQhtgYg9hdQg9hfAYhsQAYhtBdg9IMsoMQBeg9BtAYQBtAXA9BeQA9BegYBtQgYBthdA9IssIMQhEAshLAAQgeAAgegHg");
	this.shape.setTransform(67.688,53.3149);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_5Sub, new cjs.Rectangle(0,0,135.4,106.6), null);


(lib.scribble4_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AJAEUIyFgMQhwgChOhQQhOhQABhuQABhwBQhOQBQhOBwABISFAMQBwACBOBQQBOBQgBBuQgBBwhQBOQhPBNhuAAIgDAAg");
	this.shape.setTransform(84.8992,27.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_4Sub, new cjs.Rectangle(0,0,169.8,55.3), null);


(lib.scribble4_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ApLI0Qhsgdg4hhQg5hhAdhrQAdhsBgg4IQNpdQBhg4BsAdQBsAcA4BhQA4BhgcBsQgdBrhgA5IwNJcQhBAlhFAAQgjAAgkgJg");
	this.shape.setTransform(78.9638,57.3388);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_3Sub, new cjs.Rectangle(0,0,157.9,114.7), null);


(lib.scribble4_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AJuETIzggKQhvgBhPhPQhOhQABhuQAAhwBQhPQBQhOBwAAITgAKQBvABBOBQQBPBPgBBvQgBBvhPBPQhQBOhuAAIgCAAg");
	this.shape.setTransform(89.4245,27.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_2Sub, new cjs.Rectangle(0,0,178.9,55), null);


(lib.scribble4_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArDIHQhngpgthnQgthmAphoQAohoBmgtITCoWQBngtBoApQBnApAuBmQAsBngoBoQgpBnhmAuIzCIWQg2AXg2AAQgxAAgygTg");
	this.shape.setTransform(87.9875,53.8125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_1Sub, new cjs.Rectangle(0,0,176,107.7), null);


(lib.scribble3_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AbTSEQjBghhzigQgaglgigPQgogIg5gDIgDAAIjQgEQl4gKkShnIAAAAQmMiLl/l4IAAAAQmpmfmTg9Qh9gMiPAYQhsARinAjQjBAoikhtQilhsgojAQgojABtilQBsikDAgoQC+goB7gUQEYguD1AcQKxA4K8KuIAAAAQDcDXDeBXIABAAQCSAyDJAFIABAAIDSAEIAKABQCqAGB1AeQFwBRD0FZQBxChghDBQghDBihByQh8BZiRAAQgpAAgsgIg");
	this.shape.setTransform(230.211,116.3692);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3_1Sub, new cjs.Rectangle(0,0,460.5,232.8), null);


(lib.scribble2_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("A6ieNQkLhKiKjxQiJjyBJkKQA9jdA7iGIAAAAQB9kkDOjyIABgBQICp6Q/j3IAAABQDbgzCEhnQBHhKA6h6IABgBIABgCQA9iKAfhBIABgCQBXi1BShoIABgBQEhmRIegyQESgZDWCxQDWCxAaEUQAaETixDWQiXC1jdAvQgcA7g1B3QgEAFgCAIQi9GRkBDdIAAABQlZFGpfCKIgBAAQpHCEkkE3QhMBZgtBqIgBABQgcBFgfBxQhKEKjxCKQidBZioAAQhaAAhdgag");
	this.shape.setTransform(219.3304,195.8844);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2_1Sub, new cjs.Rectangle(0,0,438.7,391.8), null);


(lib.scribble1_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AFcF1QmngwmEhvQh3gjg9hsQg8hsAih3QAih3Btg9QBsg8B4AiQFVBiF1AqQB7APBOBhQBNBigOB6QgPB7hhBNQhTBBhkAAQgSAAgTgCg");
	this.shape.setTransform(68.2062,37.5211);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_2Sub, new cjs.Rectangle(0,0,136.4,75.1), null);


(lib.scribble1_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArRFgQhsg9gih3Qgjh3A9hsQA8hsB3gjQI9ikKKgbQB7gGBcBVQBcBUAFB8QAFB6hUBcQhVBch7AFQpAAYn7CRQgrANgpAAQhKAAhGgng");
	this.shape.setTransform(87.6876,39.0698);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_1Sub, new cjs.Rectangle(0,0,175.4,78.1), null);


(lib.option_hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AhPBRIAAihICfAAIAAAuIAAA6IAAA5g");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-8.1,16,16.2);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.222,21.222,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6132,21.222,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.222,6.6132,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6132,6.6132,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1754,14.0578,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9643,13.9128,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.5018,13.9128,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.img5Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorSocial2x();
	this.instance.setTransform(0,-142,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub3, new cjs.Rectangle(0,-142,170.5,142), null);


(lib.img5Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorIcon2x();
	this.instance.setTransform(0,-83,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub2, new cjs.Rectangle(0,-83,83,139), null);


(lib.img5Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorDesktop2x();
	this.instance.setTransform(0,-135,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub1, new cjs.Rectangle(0,-135,176,135), null);


(lib.img4Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveDesktop2x();
	this.instance.setTransform(-35.15,-24.45,0.73,0.73);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub3, new cjs.Rectangle(-35.1,-24.4,244.5,170.1), null);


(lib.img4Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveIcon2x();
	this.instance.setTransform(-15.25,-15,0.77,0.77);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub2, new cjs.Rectangle(-15.2,-15,87,85.5), null);


(lib.img4Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveMobile2x();
	this.instance.setTransform(-1.05,-1.8,0.52,0.52);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub1, new cjs.Rectangle(-1,-1.8,53.5,94.1), null);


(lib.img3Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelDesktop2x();
	this.instance.setTransform(-35.2,-24.45,0.73,0.73);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub3, new cjs.Rectangle(-35.2,-24.4,244.60000000000002,170.1), null);


(lib.img3Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelIcon2x();
	this.instance.setTransform(-15.25,-15,0.77,0.77);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub2, new cjs.Rectangle(-15.2,-15,87,85.5), null);


(lib.img3Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ExcelMobile2x();
	this.instance.setTransform(-1.05,-1.8,0.52,0.52);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub1, new cjs.Rectangle(-1,-1.8,53.5,94.1), null);


(lib.img2Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTDesktop2x();
	this.instance.setTransform(-35.15,-24.45,0.73,0.73);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub3, new cjs.Rectangle(-35.1,-24.4,244.5,170.1), null);


(lib.img2Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTIcon2x();
	this.instance.setTransform(-15.25,-14.7,0.77,0.77);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub2, new cjs.Rectangle(-15.2,-14.7,87,84), null);


(lib.img2Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTMobile2x();
	this.instance.setTransform(-1.05,-1.8,0.52,0.52);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub1, new cjs.Rectangle(-1,-1.8,53.5,94.1), null);


(lib.img1Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.DesignerInWordPerennialsLargerRatio2x();
	this.instance.setTransform(-37.6,-26.2,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub3, new cjs.Rectangle(-37.6,-26.2,247,172.1), null);


(lib.img1Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group242x();
	this.instance.setTransform(-15.1,-14.85,0.77,0.77);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub2, new cjs.Rectangle(-15.1,-14.8,87,85.39999999999999), null);


(lib.img1Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group332x();
	this.instance.setTransform(-1.05,-1.8,0.52,0.52);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub1, new cjs.Rectangle(-1,-1.8,53.5,94.1), null);


(lib.gridSubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Az/AAMAn/AAA");
	this.shape.setTransform(128,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridSubSub, new cjs.Rectangle(-1,-1,258,2), null);


(lib.ms_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_1, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.doodle5_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AggBEQgEgCgCgEIgyhtQgDgGADgGQACgGAGgCQAFgDAGACQAGACADAGIAqBdIBVg7QAFgEAGACQAGABAEAFQADAFgBAGQgBAGgFAEIhkBFQgDACgFAAQgEAAgEgCg");
	this.shape.setTransform(9.0293,6.9932);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_3Sub, new cjs.Rectangle(0,0,18.1,14), null);


(lib.doodle5_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhJBLQgGgCgCgFQgDgGACgGQAdhLA9gjQAUgMAVgFIABAAQAKgEAIAAQAGgBAFAEQAEAEABAHQAAAGgEAFQgEAEgGABIgMADIgBAAQgRAEgRAKQg0AdgZBCQgCAFgFADIgGABIgGgBg");
	this.shape.setTransform(8.371,7.6347);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_2Sub, new cjs.Rectangle(0,0,16.8,15.3), null);


(lib.doodle5_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah6CMQgHgCgDgFQgEgFACgGQAdifByhDQA6giA1gBQAGAAAFAEQAEAEAAAGQAAAGgEAFQgEAFgGAAQguABgzAeQhmA9gbCRQgBAGgFADQgEADgEAAIgDAAg");
	this.shape.setTransform(13.5545,14.0111);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_1Sub, new cjs.Rectangle(0,0,27.1,28), null);


(lib.doodle4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,out:30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150.0023,299.9992,1,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.doodle3_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgaA2QgEgDgCgEIglhQQgDgGADgGQACgGAGgCQAFgDAGACQAGACADAGIAdBAIA7goQAFgEAHABQAGABADAFQAEAFgBAHQgCAGgFACIhKA0QgDADgFAAQgEAAgEgCg");
	this.shape.setTransform(7.1043,5.5682);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_4Sub, new cjs.Rectangle(0,0,14.2,11.2), null);


(lib.doodle3_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3A7QgGgCgCgFQgDgGACgGQAWg4AvgbIAAAAQAOgJAQgEQAJgDAGgBQAGAAAFAEQAEADABAHQABAGgEAFQgEAEgGABIgIADIgBAAQgMADgMAHIAAAAQgmAVgSAvQgCAFgFADIgGACIgGgCg");
	this.shape.setTransform(6.5963,6.0597);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_3Sub, new cjs.Rectangle(0,0,13.2,12.1), null);


(lib.doodle3_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhbBsQgHgCgDgFQgEgFACgGQAWh4BWgzQAsgZAogBQAGAAAFAEQAEAEAAAGQAAAGgEAFQgEAFgGAAQghABglAVQhKAtgUBqQgBAGgFADQgEADgEAAIgDAAg");
	this.shape.setTransform(10.4545,10.8111);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_2Sub, new cjs.Rectangle(0,0,20.9,21.6), null);


(lib.doodle3_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAsB5QgDgBgBgDQgBgDABgDQABgDADgBIAogSIgTgIIAAABIgcgKQgDgBgCgCQgBgDABgDQAAgDADgBQAkgYASgOIgaADIgnAFQgCAAgDgBQgCgCgBgCQgBgDABgDIAbg/Ig1AuIgFACQgDAAgCgCQgDgCAAgCIgBhNIgjBLQgBADgDABQgDABgDgBQgDgBgBgDIgYg+QgDAPgBAWIgCApQAAADgCACQgCACgDAAQgEAAgCgCQgCgDAAgDIACgoIAAgBQADguAHgRQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIADAEIAbBEIAphaQABAAAAgBQAAAAABgBQAAAAABgBQAAAAAAAAQADgCACABQADABACACQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIACBdIBCg6QACgCADAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIADAEQABACgBADIgjBRIAagDIAxgFQADAAADACQACABAAADQABADgCADQgIALg1AkIAOAEQAfAMAFADIADAEIgBAGIgEADIg2AaIgDAAIgDAAg");
	this.shape.setTransform(11.855,12.13);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_1Sub, new cjs.Rectangle(0,0,23.7,24.3), null);


(lib.doodle2_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiAB0QgDgCAAgDQAAgEACgCQACgCAEAAIA/gDQADAAACACQACACAAAEQAAADgCACQgCACgDAAIg/ADQgDAAgCgCgAg7A5IhEgtQgDgCAAgDQgBgDACgDQABgBADgBQADgBADACIBEAsQACACABADQABADgCACQgCADgDABIgBAAIgEgBgAgJAKQgDAAgCgDIhLhqQgCgDAAgDQABgDADgCQACgCADABQADAAACADIBMBsQABABAAADQgBADgCACIgEABIgCAAgAAwgKQgDgCgBgDIgPhcQgBgDACgDQACgDADAAQADgBADACQACACABADIAPBdQABACgCADQgCADgDAAIgBAAIgEgBgABugLQgDgBgBgDQgCgCABgDIAMg1QAAgDADgBQACgCAEABQACAAACADQACACgBAEIgMA0IgDAFIgEABIgCAAg");
	this.shape.setTransform(13.1563,11.745);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle2_2Sub, new cjs.Rectangle(0,0,26.3,23.5), null);


(lib.doodle1_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgXBCQgEgDgCgDIg8hoQgDgGACgGQACgGAFgDQAFgDAGACQAGACADAFIAzBYIBPhCQAFgEAGABQAGAAAEAFQAEAFAAAGQgBAGgEAEIhdBOQgEADgEAAIgCABQgEAAgDgCg");
	this.shape.setTransform(9.1778,6.755);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_3Sub, new cjs.Rectangle(0,0,18.4,13.5), null);


(lib.doodle1_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAOB4IhDgrQgDgCgBgDQgBgDACgDQACgDACAAQADgCADACIBDAsQADACABACQABAEgCACQgCADgCABIgCAAIgEgBgAgjAEQgDgBgCgCQgCgBAAgDQAAgDACgCQADgCADAAIBaAFQACAAADACQACACAAADQgBADgCACQgBACgEAAgAg4g7QgDAAgCgDQgCgCABgEQABgDACgBIBCgvQADgCADABQACAAACADQACADgBADQAAADgDACIhBAuIgFABIgBAAg");
	this.shape.setTransform(19.67,11.0271);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_2Sub, new cjs.Rectangle(13.4,-1.1,12.6,24.3), null);


(lib.doodle1_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkwDaQgHgBgEgEQgEgFABgGQAak9ENhPQBagbBuAEQBLADA4AOQAGACADAFQADAGgBAGQgCAGgFADQgGADgFgCQg2gNhHgDQhpgEhVAaQj6BKgYEnQgBAGgEAEQgFAEgFAAIgBAAg");
	this.shape.setTransform(31.9222,21.8015);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_1Sub, new cjs.Rectangle(0,0,63.9,43.6), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzClIAAlJIPnAAIAAFJg");
	this.shape.setTransform(50,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,-3,100,33), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.angledShadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.angledShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.angledShadow_1, new cjs.Rectangle(0,0,294,97), null);


(lib.scribble5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,271,174,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble5_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(135.2,86.9,1,1,0,0,0,135.2,86.9);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_2, new cjs.Rectangle(0,0,270.3,173.8), null);


(lib.scribble5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,270,181,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble5_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(134.7,90.5,1,1,0,0,0,134.7,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_1, new cjs.Rectangle(0,0,269.3,180.9), null);


(lib.scribble5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_11 = new cjs.Graphics().p("EAwIAgRMhp7geOQlahjiolZQimlVBumDQBvmCFBjPQFFjJFZBjMBp7AeNQFaBjCmFVQCoFahuGCQhvGDlEDJQjaCMjkAAQhuAAhvggg");
	var mask_graphics_12 = new cjs.Graphics().p("EAwgAgYMhp7geOQlahjiolZQillVBumDQBumCFCjPQFEjJFaBjMBp7AeNQFaBjClFVQCoFahuGCQhuGDlEDJQjaCMjlAAQhtAAhwggg");
	var mask_graphics_13 = new cjs.Graphics().p("EAw0AgmMhp7geOQlahjiolZQimlVBvmCQBumDFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_14 = new cjs.Graphics().p("EAw0Ag+Mhp7geOQlahjiolZQimlVBvmDQBumCFCjOQFEjKFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_15 = new cjs.Graphics().p("EAw0AhhMhp7geOQlahjiolZQimlVBvmDQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_16 = new cjs.Graphics().p("EAw0AiRMhp7gePQlahiiolaQimlVBvmCQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_17 = new cjs.Graphics().p("EAw0AjOMhp7gePQlahiiolaQimlVBvmCQBumCFCjPQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDKQjaCLjkAAQhtAAhwgfg");
	var mask_graphics_18 = new cjs.Graphics().p("EAw0AkUMhp7gePQlahiiolaQimlVBvmCQBumCFCjPQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDKQjaCLjkAAQhtAAhwgfg");
	var mask_graphics_19 = new cjs.Graphics().p("EAw0AlbMhp7geOQlahjiolaQimlUBvmDQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_20 = new cjs.Graphics().p("EAw0AmcMhp7geOQlahjiolaQimlUBvmCQBumDFCjOQFEjJFaBiMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_21 = new cjs.Graphics().p("EAw0AnTMhp7geOQlahjiolaQimlUBvmCQBumDFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_22 = new cjs.Graphics().p("EAw0AoAMhp7gePQlahiiolbQimlUBvmCQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_23 = new cjs.Graphics().p("EAw0AoiMhp7geOQlahiiolbQimlUBvmCQBumCFCjPQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDKQjaCLjkAAQhtAAhwggg");
	var mask_graphics_24 = new cjs.Graphics().p("EAw0Ao9Mhp7geOQlahjiolaQimlUBvmDQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_25 = new cjs.Graphics().p("EAw0ApRMhp7gePQlahiiolbQimlUBvmCQBumCFCjPQFEjJFaBjMBp7AeNQFZBiCmFWQCoFahuGCQhuGClFDKQjaCMjkAAQhtAAhwggg");
	var mask_graphics_26 = new cjs.Graphics().p("EAw0ApfMhp7gePQlahiiolbQimlUBvmCQBumCFCjPQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDKQjaCLjkAAQhtAAhwgfg");
	var mask_graphics_27 = new cjs.Graphics().p("EAw0ApoMhp7gePQlahiiolbQimlUBvmCQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_28 = new cjs.Graphics().p("EAw0AptMhp7gePQlahiiolaQimlVBvmCQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_29 = new cjs.Graphics().p("EAw0ApuMhp7geOQlahjiolaQimlUBvmCQBumDFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhuAAhvggg");
	var mask_graphics_30 = new cjs.Graphics().p("EAw0AqfMhp7geOQlahjiolaQimlUBvmDQBumCFCjOQFEjKFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_31 = new cjs.Graphics().p("EAw0ArQMhp7gePQlahiiolbQimlVBvmBQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_32 = new cjs.Graphics().p("EAw0AsAMhp7geOQlahjiolaQimlVBvmBQBumDFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_33 = new cjs.Graphics().p("EAw0AsxMhp7geOQlahjiolaQimlVBvmCQBumCFCjOQFEjKFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_34 = new cjs.Graphics().p("EAw0AtiMhp7gePQlahiiolbQimlVBvmBQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_35 = new cjs.Graphics().p("EAw0AuSMhp7geOQlahjiolaQimlVBvmBQBumDFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_36 = new cjs.Graphics().p("EAw0AvDMhp7geOQlahjiolaQimlVBvmCQBumCFCjOQFEjKFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_37 = new cjs.Graphics().p("EAw0Av0Mhp7gePQlahiiolbQimlVBvmBQBumCFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_38 = new cjs.Graphics().p("EAw0AwkMhp7geOQlahjiolaQimlVBvmCQBumCFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_39 = new cjs.Graphics().p("EAw0AxVMhp7geOQlahjiolaQimlVBvmDQBumBFCjOQFEjKFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_40 = new cjs.Graphics().p("EAw0AyGMhp7gePQlahiiolbQimlVBvmCQBumBFCjPQFEjJFaBjMBp7AeNQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_41 = new cjs.Graphics().p("EAw0Ay2Mhp7geOQlahjiolaQimlVBvmCQBumCFCjOQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDJQjaCMjkAAQhuAAhvggg");
	var mask_graphics_42 = new cjs.Graphics().p("EAw0Ay9Mhp7geOQlahjiolaQimlVBvmCQBumCFCjOQFEjJFaBiMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhtAAhwggg");
	var mask_graphics_43 = new cjs.Graphics().p("EAw0AzMMhp7gePQlahiiolbQimlVBvmCQBumBFCjPQFEjJFaBiMBp7AeOQFZBiCmFVQCoFbhuGCQhuGClFDKQjaCLjkAAQhtAAhwgfg");
	var mask_graphics_44 = new cjs.Graphics().p("EAw3AzjMhp7gePQlahiiolaQimlWBvmCQBumBFCjPQFEjJFaBjMBp7AeNQFaBjClFVQCoFahuGCQhuGDlFDJQjZCMjlAAQhtAAhwggg");
	var mask_graphics_45 = new cjs.Graphics().p("EAy0A0FMhp7geOQlahjiolaQimlVBvmCQBumCFCjOQFEjKFaBjMBp7AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjZCMjlAAQhtAAhwggg");
	var mask_graphics_46 = new cjs.Graphics().p("EA1fA00Mhp7geOQlahjiolaQillVBumCQBumCFCjOQFEjKFaBjMBp7AeNQFaBjClFVQCoFahuGDQhuGClEDJQjaCMjlAAQhtAAhwggg");
	var mask_graphics_47 = new cjs.Graphics().p("EA45A1wMhp7geOQlahjiolaQimlVBumDQBvmBFBjOQFFjKFZBjMBp8AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhuAAhvggg");
	var mask_graphics_48 = new cjs.Graphics().p("EA8zA21Mhp7geOQlahjiolaQillVBumDQBumCFCjOQFEjJFaBjMBp7AeNQFaBjClFVQCoFahuGCQhuGDlEDJQjaCMjlAAQhtAAhwggg");
	var mask_graphics_49 = new cjs.Graphics().p("EBAzA37Mhp7geOQlahjiolaQimlVBumCQBvmDFBjNQFFjKFZBjMBp8AeNQFZBjCmFVQCoFahuGDQhuGClFDJQjaCMjkAAQhuAAhvggg");
	var mask_graphics_50 = new cjs.Graphics().p("EBEcA47Mhp7geOQlahjiolaQillVBumCQBumDFCjNQFEjJFaBiMBp7AeOQFaBiClFVQCoFbhuGCQhuGClEDJQjaCMjlAAQhtAAhwggg");
	var mask_graphics_51 = new cjs.Graphics().p("EBHhA5yMhp7gePQlZhiiplbQillVBumCQBumCFCjOQFEjJFaBiMBp7AeOQFaBiClFVQCpFbhvGCQhuGClEDKQjaCLjlAAQhtAAhwgfg");
	var mask_graphics_52 = new cjs.Graphics().p("EBKAA6dMhp7geOQlahjiolaQillVBumCQBumDFCjOQFEjIFaBiMBp7AeOQFaBiClFVQCoFbhuGCQhuGClEDJQjaCMjlAAQhtAAhwggg");
	var mask_graphics_53 = new cjs.Graphics().p("EBL8A6/Mhp7geOQlZhiiplbQillVBumCQBumCFCjPQFFjIFZBiMBp7AeOQFaBiCmFVQCoFbhvGCQhuGClEDKQjaCLjlAAQhtAAhwggg");
	var mask_graphics_54 = new cjs.Graphics().p("EBNbA7aMhp7gePQlZhiiplbQillVBumCQBumCFCjPQFEjIFaBiMBp7AeOQFaBiClFVQCpFbhvGCQhuGClEDKQjaCLjlAAQhtAAhwgfg");
	var mask_graphics_55 = new cjs.Graphics().p("EBOiA7tMhp7geOQlahjiolaQimlVBumDQBvmCFBjPQFFjIFZBiMBp8AeOQFZBjCmFVQCoFahuGCQhuGDlFDJQjaCMjkAAQhuAAhvggg");
	var mask_graphics_56 = new cjs.Graphics().p("EBPUA77Mhp8gePQlZhiiolbQimlVBumCQBumCFCjPQFFjIFZBiMBp7AeOQFaBiCmFVQCoFbhuGCQhvGClEDKQjaCLjlABQhtAAhvggg");
	var mask_graphics_57 = new cjs.Graphics().p("EBP0A8EMhp7gePQlZhiiplbQillVBumCQBumCFCjPQFEjIFaBiMBp7AeOQFaBiClFVQCpFbhvGCQhuGClEDKQjaCLjlABQhtAAhwggg");
	var mask_graphics_58 = new cjs.Graphics().p("EBQGA8JMhp7gePQlZhiiplbQillVBumCQBumCFCjPQFFjIFZBhMBp7AePQFaBiCmFVQCoFbhuGCQhvGClEDKQjaCLjlAAQhtAAhwgfg");
	var mask_graphics_59 = new cjs.Graphics().p("EBQKA8KMhp7gePQlZhiiplbQillVBumCQBumCFCjPQFEjIFaBiMBp7AeOQFaBiClFVQCoFbhuGCQhuGClEDKQjaCLjlAAQhtABhwggg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_graphics_11,x:-431.3616,y:209.6745}).wait(1).to({graphics:mask_graphics_12,x:-428.9278,y:210.3767}).wait(1).to({graphics:mask_graphics_13,x:-420.8454,y:211.8235}).wait(1).to({graphics:mask_graphics_14,x:-404.3852,y:214.1914}).wait(1).to({graphics:mask_graphics_15,x:-380.1245,y:217.6815}).wait(1).to({graphics:mask_graphics_16,x:-346.8611,y:222.4667}).wait(1).to({graphics:mask_graphics_17,x:-304.591,y:228.5476}).wait(1).to({graphics:mask_graphics_18,x:-255.9589,y:235.5438}).wait(1).to({graphics:mask_graphics_19,x:-206.3079,y:242.6865}).wait(1).to({graphics:mask_graphics_20,x:-160.9482,y:249.2118}).wait(1).to({graphics:mask_graphics_21,x:-122.6458,y:254.722}).wait(1).to({graphics:mask_graphics_22,x:-91.7901,y:259.1608}).wait(1).to({graphics:mask_graphics_23,x:-67.6491,y:262.6337}).wait(1).to({graphics:mask_graphics_24,x:-49.2155,y:265.2855}).wait(1).to({graphics:mask_graphics_25,x:-35.5464,y:267.2519}).wait(1).to({graphics:mask_graphics_26,x:-25.8525,y:268.6465}).wait(1).to({graphics:mask_graphics_27,x:-19.4979,y:269.5606}).wait(1).to({graphics:mask_graphics_28,x:-15.9747,y:270.0675}).wait(1).to({graphics:mask_graphics_29,x:-14.8768,y:270.2245}).wait(1).to({graphics:mask_graphics_30,x:19.3024,y:275.0921}).wait(1).to({graphics:mask_graphics_31,x:53.4816,y:279.9588}).wait(1).to({graphics:mask_graphics_32,x:87.6607,y:284.8254}).wait(1).to({graphics:mask_graphics_33,x:121.8399,y:289.6921}).wait(1).to({graphics:mask_graphics_34,x:156.0191,y:294.5588}).wait(1).to({graphics:mask_graphics_35,x:190.1982,y:299.4254}).wait(1).to({graphics:mask_graphics_36,x:224.3774,y:304.2921}).wait(1).to({graphics:mask_graphics_37,x:258.5566,y:309.1588}).wait(1).to({graphics:mask_graphics_38,x:292.7357,y:314.0255}).wait(1).to({graphics:mask_graphics_39,x:326.9149,y:318.8921}).wait(1).to({graphics:mask_graphics_40,x:361.0941,y:323.7588}).wait(1).to({graphics:mask_graphics_41,x:395.2733,y:328.6245}).wait(1).to({graphics:mask_graphics_42,x:400.2915,y:329.3154}).wait(1).to({graphics:mask_graphics_43,x:410.6455,y:330.739}).wait(1).to({graphics:mask_graphics_44,x:427.2725,y:333.069}).wait(1).to({graphics:mask_graphics_45,x:439.7611,y:336.5032}).wait(1).to({graphics:mask_graphics_46,x:456.8839,y:341.2116}).wait(1).to({graphics:mask_graphics_47,x:478.6431,y:347.1951}).wait(1).to({graphics:mask_graphics_48,x:503.6773,y:354.079}).wait(1).to({graphics:mask_graphics_49,x:529.2359,y:361.1072}).wait(1).to({graphics:mask_graphics_50,x:552.5855,y:367.528}).wait(1).to({graphics:mask_graphics_51,x:572.3023,y:372.9497}).wait(1).to({graphics:mask_graphics_52,x:588.1858,y:377.3174}).wait(1).to({graphics:mask_graphics_53,x:600.6127,y:380.7346}).wait(1).to({graphics:mask_graphics_54,x:610.1017,y:383.3439}).wait(1).to({graphics:mask_graphics_55,x:617.1381,y:385.2788}).wait(1).to({graphics:mask_graphics_56,x:622.1282,y:386.651}).wait(1).to({graphics:mask_graphics_57,x:625.3993,y:387.5505}).wait(1).to({graphics:mask_graphics_58,x:627.2129,y:388.0492}).wait(1).to({graphics:mask_graphics_59,x:627.5849,y:388.1495}).wait(1));

	// Layer_5
	this.instance = new lib.scribble5_2();
	this.instance.setTransform(199.6,398.25,1.5199,1.5199,-5.8641,0,0,135.1,87);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).wait(49));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgZ4AjTQlXihielxQielxB3lrQB9lpFKiOMBlSgrVQFKiNFYCgQFcCjCfFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCieAAQi1AAi7hXg");
	var mask_1_graphics_1 = new cjs.Graphics().p("EgZ+AjTQlYihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiaBCidAAQi2AAi6hXg");
	var mask_1_graphics_2 = new cjs.Graphics().p("EgaUAjTQlYihielxQielxB4lrQB9lpFKiOMBlRgrVQFLiNFXCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiZBCieAAQi1AAi7hXg");
	var mask_1_graphics_3 = new cjs.Graphics().p("Ega9AjTQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCieAAQi1AAi7hXg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Egb9AjTQlYihielxQielxB4lrQB9lpFKiOMBlRgrVQFLiNFXCgQFdCjCeFxQCeFyh8FoQh4FslKCNMhlSArVQiZBCieAAQi1AAi7hXg");
	var mask_1_graphics_5 = new cjs.Graphics().p("EgdcAjTQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCieAAQi1AAi7hXg");
	var mask_1_graphics_6 = new cjs.Graphics().p("EgfhAjTQlXihiflxQielxB4lrQB9lpFKiOMBlRgrVQFLiNFYCgQFcCjCfFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCieAAQi1AAi7hXg");
	var mask_1_graphics_7 = new cjs.Graphics().p("EgiUAjTQlYihielxQielxB4lrQB9lpFKiOMBlRgrVQFLiNFXCgQFdCjCeFxQCeFyh8FoQh4FslKCNMhlSArVQiZBCieAAQi1AAi7hXg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Egl1AjTQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_9 = new cjs.Graphics().p("EgpuAjTQlYihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiaBCidAAQi2AAi6hXg");
	var mask_1_graphics_10 = new cjs.Graphics().p("EgtfAjTQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_11 = new cjs.Graphics().p("EgwsAjTQlYihielxQielxB4lrQB9lpFKiOMBlRgrVQFLiNFXCgQFdCjCeFxQCeFyh8FoQh4FslKCNMhlSArVQiZBCieAAQi1AAi7hXg");
	var mask_1_graphics_12 = new cjs.Graphics().p("EgzRAjTQlXihielxQielxB3lrQB9lpFKiOMBlSgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCieAAQi1AAi7hXg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Eg1RAjTQlYihielxQielxB4lrQB9lpFKiOMBlRgrVQFLiNFXCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiZBCieAAQi1AAi7hXg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Eg20AjTQlXihielxQielxB3lrQB9lpFKiOMBlSgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCieAAQi1AAi7hXg");
	var mask_1_graphics_15 = new cjs.Graphics().p("Eg3RAjTQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Eg3QAjTQlYihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh4FslKCNMhlRArVQiaBCidAAQi2AAi6hXg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Eg3RAjTQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Eg3RAkPQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FpQh3FrlLCOMhlRArVQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Eg3RAlOQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCjCeFxQCeFxh9FpQh3FrlLCOMhlRArVQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Eg3RAmNQlXigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFxh9FpQh3FrlLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_21 = new cjs.Graphics().p("Eg3RAnMQlXigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYCgQFdCjCeFyQCeFxh9FpQh3FrlLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Eg3RAoLQlXigielyQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FpQh3FrlLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Eg3RApKQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_24 = new cjs.Graphics().p("Eg3RAqJQlXihielxQielxB3lsQB9loFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FslLCNMhlRArVQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Eg3RArIQlXihielxQielxB3lsQB9loFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FpQh3FrlLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Eg3RAsGQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FpQh3FrlLCNMhlRArWQiaBCidAAQi2AAi7hYg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Eg3RAtFQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCjCeFxQCeFxh9FpQh3FrlLCNMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Eg3RAuEQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFxh9FpQh3FqlLCOMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Eg3QAvDQlYigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFxh9FpQh4FqlKCNMhlRArWQiaBCidAAQi2AAi6hXg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Eg3RAvFQlXigielxQielxB3lsQB9loFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FpQh3FqlLCOMhlRArWQiaBCidAAQi2AAi7hYg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Eg3RAvNQlXigielxQielxB3lsQB9lpFLiNMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FpQh3FqlLCOMhlRArWQiaBCidAAQi2AAi7hYg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Eg3RAvcQlXigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFxh9FpQh3FqlLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Eg3RAvzQlXigielyQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FpQh3FqlLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_34 = new cjs.Graphics().p("Eg3RAwUQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FoQh3FrlLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Eg3RAxBQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCjCeFxQCeFxh9FpQh3FqlLCOMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_36 = new cjs.Graphics().p("Eg3RAx+QlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFxh9FpQh3FqlLCOMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Eg3RAzNQlXihielxQielxB3lsQB9loFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FnQh3FslLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Eg3RA0sQlXigielyQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFyh9FnQh3FslLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Eg3RA2UQlXigielxQielxB3lsQB9loFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FoQh3FrlLCOMhlRArWQiaBCidAAQi2AAi7hYg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Eg3RA37QlXigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYCgQFdCjCeFyQCeFxh9FoQh3FrlLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Eg3RA5WQlXihielxQielxB3lrQB9lpFLiOMBlRgrVQFKiNFYCgQFdCjCeFxQCeFxh9FoQh3FslLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_42 = new cjs.Graphics().p("Eg3RA6hQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiNFYCgQFdCjCeFxQCeFwh9FpQh3FrlLCOMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_43 = new cjs.Graphics().p("Eg3RA7eQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiNFYCgQFdCjCeFxQCeFwh9FpQh3FrlLCOMhlRArWQiaBCidAAQi2AAi7hYg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Eg3RA8PQlXigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFwh9FpQh3FrlLCNMhlRArWQiaBCidAAQi2AAi7hXg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Eg3RA81QlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiNFYCgQFdCjCeFxQCeFwh9FpQh3FrlLCOMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Eg3aA9TQlXigielxQielyB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCjCeFxQCeFwh9FpQh4FrlKCOMhlRArWQiaBBidAAQi2AAi7hXg");
	var mask_1_graphics_47 = new cjs.Graphics().p("Eg4PA9qQlXigielyQielxB3lrQB9lpFLiNMBlRgrVQFKiOFYChQFdCiCeFyQCeFwh9FpQh4FrlKCNMhlRArWQiaBCieAAQi1AAi7hXg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:600.9799,y:52.0453}).wait(1).to({graphics:mask_1_graphics_1,x:600.3249,y:52.6083}).wait(1).to({graphics:mask_1_graphics_2,x:598.1534,y:54.4654}).wait(1).to({graphics:mask_1_graphics_3,x:594.1002,y:57.9317}).wait(1).to({graphics:mask_1_graphics_4,x:587.669,y:63.4317}).wait(1).to({graphics:mask_1_graphics_5,x:578.2,y:71.5295}).wait(1).to({graphics:mask_1_graphics_6,x:564.8813,y:82.9196}).wait(1).to({graphics:mask_1_graphics_7,x:546.9647,y:98.2419}).wait(1).to({graphics:mask_1_graphics_8,x:524.515,y:117.4408}).wait(1).to({graphics:mask_1_graphics_9,x:499.5322,y:138.806}).wait(1).to({graphics:mask_1_graphics_10,x:475.5087,y:159.3508}).wait(1).to({graphics:mask_1_graphics_11,x:454.9667,y:176.9182}).wait(1).to({graphics:mask_1_graphics_12,x:438.4957,y:191.0042}).wait(1).to({graphics:mask_1_graphics_13,x:425.659,y:201.9821}).wait(1).to({graphics:mask_1_graphics_14,x:415.7988,y:210.4145}).wait(1).to({graphics:mask_1_graphics_15,x:403.7406,y:216.8035}).wait(1).to({graphics:mask_1_graphics_16,x:392.6513,y:221.5453}).wait(1).to({graphics:mask_1_graphics_17,x:363.1513,y:234.1222}).wait(1).to({graphics:mask_1_graphics_18,x:333.6513,y:240.6438}).wait(1).to({graphics:mask_1_graphics_19,x:304.1513,y:246.9322}).wait(1).to({graphics:mask_1_graphics_20,x:274.6513,y:253.2207}).wait(1).to({graphics:mask_1_graphics_21,x:245.1513,y:259.5092}).wait(1).to({graphics:mask_1_graphics_22,x:215.6513,y:265.7976}).wait(1).to({graphics:mask_1_graphics_23,x:186.1513,y:272.0861}).wait(1).to({graphics:mask_1_graphics_24,x:156.6513,y:278.3745}).wait(1).to({graphics:mask_1_graphics_25,x:127.1513,y:284.663}).wait(1).to({graphics:mask_1_graphics_26,x:97.6513,y:290.9515}).wait(1).to({graphics:mask_1_graphics_27,x:68.1513,y:297.2399}).wait(1).to({graphics:mask_1_graphics_28,x:38.6513,y:303.5284}).wait(1).to({graphics:mask_1_graphics_29,x:9.1513,y:309.815}).wait(1).to({graphics:mask_1_graphics_30,x:8.0195,y:310.0604}).wait(1).to({graphics:mask_1_graphics_31,x:4.3294,y:310.8545}).wait(1).to({graphics:mask_1_graphics_32,x:-2.4576,y:312.3149}).wait(1).to({graphics:mask_1_graphics_33,x:-13.0436,y:314.593}).wait(1).to({graphics:mask_1_graphics_34,x:-28.3407,y:317.8847}).wait(1).to({graphics:mask_1_graphics_35,x:-49.4969,y:322.4373}).wait(1).to({graphics:mask_1_graphics_36,x:-77.8096,y:328.5299}).wait(1).to({graphics:mask_1_graphics_37,x:-114.2839,y:336.3788}).wait(1).to({graphics:mask_1_graphics_38,x:-158.485,y:345.8905}).wait(1).to({graphics:mask_1_graphics_39,x:-207.1297,y:356.3583}).wait(1).to({graphics:mask_1_graphics_40,x:-254.7523,y:366.6062}).wait(1).to({graphics:mask_1_graphics_41,x:-296.938,y:375.6842}).wait(1).to({graphics:mask_1_graphics_42,x:-332.076,y:383.2455}).wait(1).to({graphics:mask_1_graphics_43,x:-360.4642,y:389.3544}).wait(1).to({graphics:mask_1_graphics_44,x:-383.0614,y:394.217}).wait(1).to({graphics:mask_1_graphics_45,x:-400.8681,y:398.0489}).wait(1).to({graphics:mask_1_graphics_46,x:-413.826,y:401.0332}).wait(1).to({graphics:mask_1_graphics_47,x:-419.1286,y:403.315}).wait(1).to({graphics:null,x:0,y:0}).wait(12));

	// Layer_2
	this.instance_1 = new lib.scribble5_1();
	this.instance_1.setTransform(199.3,314.1,1.52,1.52,0,0,0,134.6,90.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},48).wait(12));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18.1,0,435.70000000000005,600);


(lib.scribble4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,136,107,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_5Sub();
	this.sub.name = "sub";
	this.sub.setTransform(67.7,53.3,1,1,0,0,0,67.7,53.3);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_5, new cjs.Rectangle(0,0,135.4,106.6), null);


(lib.scribble4_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,170,56,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(84.9,27.6,1,1,0,0,0,84.9,27.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_4, new cjs.Rectangle(0,0,169.8,55.3), null);


(lib.scribble4_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,158,115,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(79,57.3,1,1,0,0,0,79,57.3);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_3, new cjs.Rectangle(0,0,157.9,114.7), null);


(lib.scribble4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,180,55,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(89.4,27.4,1,1,0,0,0,89.4,27.4);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_2, new cjs.Rectangle(0,0,178.9,55), null);


(lib.scribble4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,178,108,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(88,53.8,1,1,0,0,0,88,53.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_1, new cjs.Rectangle(0,0,176,107.7), null);


(lib.scribble4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("ACGdsQiigthgiVQhhiUAaimQAXimCEhWMAoSgaMQCDhVCjAtQCgAsBhCVQBhCUgYCmQgaCliDBVMgoTAaOQhWA4hkAAQgzAAg3gPg");
	var mask_graphics_22 = new cjs.Graphics().p("ABaeIQiigthgiUQhhiVAailQAXinCEhVMAoSgaMQCDhWCjAtQCgAtBhCUQBhCVgYCmQgaCliDBVMgoTAaNQhWA5hkAAQgzAAg3gQg");
	var mask_graphics_23 = new cjs.Graphics().p("AgjfaQijgthgiUQhhiVAailQAXinCEhVMAoSgaMQCDhWCjAtQCgAtBhCUQBhCVgYClQgaCmiDBVMgoTAaNQhXA5hjAAQgzAAg2gQg");
	var mask_graphics_24 = new cjs.Graphics().p("EgEJAhwQijgthhiVQhgiUAaimQAXimCEhWMAoRgaMQCEhVCjAtQCgAsBhCVQBgCTgXCnQgaCliDBWMgoTAaNQhWA4hjAAQgzAAg3gPg");
	var mask_graphics_25 = new cjs.Graphics().p("EgIKAkXQijgthhiVQhgiUAaimQAXimCEhVMAoRgaNQCEhVCjAtQCgAsBhCUQBgCUgXCnQgaCliDBWMgoSAaNQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_26 = new cjs.Graphics().p("EgK/AmNQijgthhiVQhhiUAaimQAYimCDhWMAoSgaNQCEhUCiAtQChArBgCVQBhCUgXCmQgaCmiEBVMgoSAaOQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_27 = new cjs.Graphics().p("EgMnAnQQijgthhiUQhgiVAaimQAXimCEhVMAoRgaNQCEhVCjAsQCgAsBhCVQBgCVgXCmQgaCliDBWMgoSAaNQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_28 = new cjs.Graphics().p("EgNZAnxQijgthhiVQhhiUAaimQAYimCDhWMAoSgaNQCEhVCiAtQChAsBhCVQBgCUgXCmQgaCmiEBWMgoRAaNQhXA4hjAAQg0AAg2gPg");
	var mask_graphics_29 = new cjs.Graphics().p("EgNoAn6QiigthhiUQhhiVAaimQAYimCDhVMAoSgaOQCDhVCjAtQChAsBgCVQBhCUgXCnQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg3gPg");
	var mask_graphics_30 = new cjs.Graphics().p("EgOFAoOQijgthhiVQhgiUAaimQAXimCDhWMAoSgaNQCEhVCjAtQCgAsBhCVQBgCUgXCmQgaCmiEBVMgoRAaOQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_31 = new cjs.Graphics().p("EgOjAohQijgthgiUQhhiVAailQAXinCEhVMAoRgaNQCEhWCjAtQCgAtBhCUQBhCVgYCmQgaCliDBWMgoSAaNQhXA5hjAAQgzAAg3gQg");
	var mask_graphics_32 = new cjs.Graphics().p("EgPBAo1QijgthgiVQhhiUAaimQAYimCDhVMAoSgaOQCDhVCjAtQChAsBgCVQBhCUgYCnQgaCliDBWMgoSAaNQhWA4hjAAQg0AAg3gPg");
	var mask_graphics_33 = new cjs.Graphics().p("EgPeApJQijgthhiVQhhiVAailQAYimCDhWMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCmiEBVMgoSAaNQhWA5hjAAQg0AAg2gPg");
	var mask_graphics_34 = new cjs.Graphics().p("EgP8ApcQijgthhiUQhgiVAailQAXinCEhVMAoRgaNQCEhWCjAtQCgAsBhCVQBgCVgXCmQgaCliDBWMgoSAaNQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_35 = new cjs.Graphics().p("EgQaApwQijgthgiVQhhiUAaimQAXimCEhWMAoSgaNQCDhVCjAtQCgAsBhCVQBhCUgYCmQgaCmiDBVMgoSAaOQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_36 = new cjs.Graphics().p("EgQ4AqDQiigthhiUQhhiVAailQAYimCDhWMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgYCmQgZCmiEBVMgoSAaNQhWA5hjAAQg0AAg3gQg");
	var mask_graphics_37 = new cjs.Graphics().p("EgRVAqXQijgthhiUQhgiVAZimQAYimCDhVMAoSgaOQCEhVCjAtQCgAsBhCVQBgCUgXCnQgaCliEBWMgoRAaNQhXA4hjAAQg0AAg2gPg");
	var mask_graphics_38 = new cjs.Graphics().p("EgRzAqrQijgthhiVQhgiUAaimQAXimCEhWMAoRgaNQCEhVCjAtQCgAsBhCUQBgCVgXCmQgaCmiDBVMgoSAaOQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_39 = new cjs.Graphics().p("EgSRAq+QijgthgiUQhhiVAailQAXinCEhVMAoSgaNQCDhWCjAtQCgAtBhCUQBhCVgYCmQgaCliDBWMgoSAaNQhWA5hkAAQgzAAg3gQg");
	var mask_graphics_40 = new cjs.Graphics().p("EgSuArSQijgthhiVQhhiUAaimQAYimCDhVMAoSgaOQCDhVCjAtQChAsBgCVQBhCUgXCnQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_41 = new cjs.Graphics().p("EgTMArmQijgthhiVQhgiVAailQAXimCDhWMAoSgaNQCEhWCjAtQCgAtBhCUQBgCVgXCmQgaCmiEBVMgoRAaNQhXA5hjAAQgzAAg3gPg");
	var mask_graphics_42 = new cjs.Graphics().p("EgTqAr5QijgthgiUQhhiVAailQAXinCEhVMAoSgaNQCDhWCjAtQCgAsBhCVQBhCVgYCmQgaCliDBWMgoSAaNQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_43 = new cjs.Graphics().p("EgUIAsNQijgthgiVQhhiUAaimQAYimCDhWMAoSgaNQCDhVCjAtQChAsBgCVQBhCUgYCmQgaCmiDBVMgoSAaOQhWA4hjAAQg0AAg3gPg");
	var mask_graphics_44 = new cjs.Graphics().p("EgUlAsgQijgthhiUQhhiVAailQAYimCDhWMAoSgaNQCEhWCiAtQChAtBgCUQBhCVgXCmQgaCmiEBVMgoRAaNQhXA5hjAAQg0AAg2gQg");
	var mask_graphics_45 = new cjs.Graphics().p("EgVDAs0QijgthhiUQhgiVAaimQAXimCEhVMAoRgaOQCEhVCjAtQCgAsBhCVQBgCUgXCnQgaCliDBWMgoSAaNQhXA4hjAAQgzAAg3gPg");
	var mask_graphics_46 = new cjs.Graphics().p("EgVDAtIQijgthhiVQhhiUAaimQAYimCDhWMAoSgaNQCDhVCjAtQChAsBgCUQBhCVgXCmQgaCmiEBVMgoSAaOQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_47 = new cjs.Graphics().p("EgVDAtbQijgthhiUQhhiVAailQAYinCDhVMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_48 = new cjs.Graphics().p("EgVDAtvQijgthhiVQhhiUAaimQAYimCDhWMAoSgaNQCDhVCjAtQChAsBgCVQBhCUgXCnQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_49 = new cjs.Graphics().p("EgVDAuCQijgthhiUQhhiVAaimQAYimCDhVMAoSgaOQCDhVCjAtQChAsBgCVQBhCUgXCnQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_50 = new cjs.Graphics().p("EgVDAuaQijgthhiVQhhiVAailQAYimCDhWMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCmiEBVMgoSAaNQhWA5hjAAQg0AAg2gPg");
	var mask_graphics_51 = new cjs.Graphics().p("EgVDAvaQijgthhiVQhhiVAailQAYimCDhWMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCmiEBVMgoSAaNQhWA5hjAAQg0AAg2gPg");
	var mask_graphics_52 = new cjs.Graphics().p("EgVDAxQQijgthhiUQhhiVAailQAYinCDhVMAoSgaNQCDhWCjAtQChAsBgCVQBhCVgXCmQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_53 = new cjs.Graphics().p("EgVDAzrQijgthhiVQhhiVAailQAYimCDhWMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCmiEBVMgoSAaNQhWA5hjAAQg0AAg2gPg");
	var mask_graphics_54 = new cjs.Graphics().p("EgVDA1uQijgthhiVQhhiUAaimQAYimCDhVMAoSgaOQCDhVCjAtQChAsBgCVQBhCUgXCnQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_55 = new cjs.Graphics().p("EgVDA3EQijgthhiUQhhiVAailQAYinCDhVMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCmiEBVMgoSAaNQhWA5hjAAQg0AAg2gQg");
	var mask_graphics_56 = new cjs.Graphics().p("EgVDA33QijgthhiVQhhiUAaimQAYimCDhWMAoSgaNQCDhVCjAtQChAsBgCVQBhCUgXCmQgaCmiEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_57 = new cjs.Graphics().p("EgVDA4QQijgthhiUQhhiVAaimQAYimCDhVMAoSgaOQCDhVCjAtQChAsBgCVQBhCUgXCnQgaCliEBWMgoSAaNQhWA4hjAAQg0AAg2gPg");
	var mask_graphics_58 = new cjs.Graphics().p("EgVDA4XQijgthhiUQhhiVAailQAYinCDhVMAoSgaNQCDhWCjAtQChAtBgCUQBhCVgXCmQgaCliEBWMgoSAaNQhWA5hjAAQg0AAg2gQg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:316.686,y:191.5024}).wait(1).to({graphics:mask_graphics_22,x:312.2863,y:194.3613}).wait(1).to({graphics:mask_graphics_23,x:299.6763,y:202.5561}).wait(1).to({graphics:mask_graphics_24,x:276.6627,y:217.5118}).wait(1).to({graphics:mask_graphics_25,x:250.9496,y:234.2217}).wait(1).to({graphics:mask_graphics_26,x:232.8228,y:246.0017}).wait(1).to({graphics:mask_graphics_27,x:222.4598,y:252.7362}).wait(1).to({graphics:mask_graphics_28,x:217.4283,y:256.006}).wait(1).to({graphics:mask_graphics_29,x:216.011,y:256.9274}).wait(1).to({graphics:mask_graphics_30,x:213.0384,y:258.8895}).wait(1).to({graphics:mask_graphics_31,x:210.0661,y:260.8519}).wait(1).to({graphics:mask_graphics_32,x:207.0937,y:262.8142}).wait(1).to({graphics:mask_graphics_33,x:204.1214,y:264.7766}).wait(1).to({graphics:mask_graphics_34,x:201.149,y:266.7389}).wait(1).to({graphics:mask_graphics_35,x:198.1766,y:268.7013}).wait(1).to({graphics:mask_graphics_36,x:195.2043,y:270.6636}).wait(1).to({graphics:mask_graphics_37,x:192.2319,y:272.626}).wait(1).to({graphics:mask_graphics_38,x:189.2596,y:274.5883}).wait(1).to({graphics:mask_graphics_39,x:186.2872,y:276.5507}).wait(1).to({graphics:mask_graphics_40,x:183.3148,y:278.513}).wait(1).to({graphics:mask_graphics_41,x:180.3425,y:280.4754}).wait(1).to({graphics:mask_graphics_42,x:177.3701,y:282.4377}).wait(1).to({graphics:mask_graphics_43,x:174.3977,y:284.4001}).wait(1).to({graphics:mask_graphics_44,x:171.4254,y:286.3624}).wait(1).to({graphics:mask_graphics_45,x:168.453,y:288.3248}).wait(1).to({graphics:mask_graphics_46,x:162.5448,y:290.2871}).wait(1).to({graphics:mask_graphics_47,x:156.6,y:292.2495}).wait(1).to({graphics:mask_graphics_48,x:150.6553,y:294.2118}).wait(1).to({graphics:mask_graphics_49,x:144.8551,y:296.1274}).wait(1).to({graphics:mask_graphics_50,x:137.714,y:298.473}).wait(1).to({graphics:mask_graphics_51,x:118.2387,y:304.8704}).wait(1).to({graphics:mask_graphics_52,x:82.114,y:316.737}).wait(1).to({graphics:mask_graphics_53,x:35.1091,y:332.1776}).wait(1).to({graphics:mask_graphics_54,x:-4.9032,y:345.3213}).wait(1).to({graphics:mask_graphics_55,x:-31.206,y:353.9615}).wait(1).to({graphics:mask_graphics_56,x:-46.5595,y:359.0049}).wait(1).to({graphics:mask_graphics_57,x:-54.2349,y:361.5262}).wait(1).to({graphics:mask_graphics_58,x:-56.445,y:362.2524}).wait(2));

	// Layer_10
	this.instance = new lib.scribble4_5();
	this.instance.setTransform(204.85,425.75,1.538,1.538,0,0,0,67.7,53.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({_off:false},0).wait(39));

	// Layer_4 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("EAX7Ag6MgwDgAzQidgChuiBQhsh+ADixQADiyBwh8QByh7CdACMAwDAA0QCdACBsB/QBuCAgDCxQgDCyhyB6QhuB7iZAAIgGgBg");
	var mask_1_graphics_16 = new cjs.Graphics().p("EAX7Ag8MgwDgA0QidgChuiBQhsh+ADixQADiyBwh8QByh7CdADMAwDAAzQCdACBsB/QBuCAgDCyQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("EAX7Ag/MgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EAX7AhDMgwDgAzQidgChuiBQhsh+ADiyQADixBwh8QByh7CdACMAwDAA0QCdACBsB/QBuCAgDCxQgDCyhyB6QhuB6iZAAIgGAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EAX7AhJMgwDgA0QidgChuiBQhsh+ADixQADiyBwh8QByh7CdADMAwDAAzQCdACBsB/QBuCAgDCxQgDCyhyB6QhuB7iZAAIgGAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EAX7AhNMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh6CdACMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EAX7AhQMgwDgAzQidgChuiBQhsh+ADiyQADixBwh9QByh6CdACMAwDAA0QCdACBsB/QBuCAgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EAX7AhRMgwDgAzQidgChuiBQhsh+ADixQADiyBwh8QByh7CdACMAwDAA0QCdACBsB/QBuCAgDCxQgDCyhyB6QhuB7iZAAIgGgBg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAX7AhSMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh6CdACMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAX7AhTMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAX7AhUMgwDgA0QidgChuiBQhsh+ADixQADiyBwh8QByh7CdADMAwDAAzQCdACBsB/QBuCAgDCyQgDCxhyB6QhuB7iZAAIgGAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAX7AhUMgwDgAzQidgDhuiAQhsh+ADiyQADixBwh9QByh6CdACMAwDAA0QCdACBsB/QBuCAgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAX7AhVMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAX7AhWMgwDgA0QidgChuiBQhsh+ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCAgDCyQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAX7AhWMgwDgAzQidgChuiBQhsh+ADiyQADixBwh8QByh7CdACMAwDAA0QCdACBsB/QBuCAgDCxQgDCyhyB6QhuB6iZAAIgGAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAX7AhXMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAX7AhYMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAX7AhZMgwDgA0QidgChuiBQhsh+ADixQADiyBwh8QByh7CdADMAwDAAzQCdACBsB/QBuCAgDCxQgDCyhyB6QhuB7iZAAIgGAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAX7AhZMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh6CdACMAwDAAzQCdADBsB/QBuCAgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAX7AhaMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAX7AhbMgwDgA0QidgChuiBQhsh+ADixQADixBwh9QByh7CdADMAwDAAzQCdACBsB/QBuCAgDCyQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAYNAhbMgwDgAzQidgDhuiAQhsh+ADiyQADixBxh9QByh6CcACMAwDAA0QCdACBsB/QBuCAgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAYoAhcMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAZCAhdMgwDgAzQidgDhuiBQhsh+ADixQADixBwh9QBzh7CcADMAwDAAzQCdADBsB+QBuCAgDCyQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAZcAhdMgwCgAzQidgChuiBQhsh+ADixQADiyBwh8QByh7CdACMAwDAA0QCcACBtB/QBuCAgDCxQgDCyhyB6QhuB7iZAAIgHgBg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAZ3AheMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh6CdACMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAaRAhfMgwDgAzQicgDhuiAQhsh/ADixQACixBxh9QByh7CdADMAwDAAzQCcADBtB+QBtCBgCCxQgDCxhyB7QhvB6iYAAIgHAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAasAhgMgwDgA0QidgChuiBQhsh+ADixQADiyBwh8QByh7CdADMAwDAAzQCdACBsB/QBuCAgDCyQgDCxhyB6QhuB7iZAAIgGAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAbGAhgMgwDgAzQicgDhuiAQhth+ADiyQADixBxh9QByh6CdACMAwCAA0QCdACBtB/QBtCAgDCxQgCCxhzB7QhuB6iYAAIgHAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAbhAhhMgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAc6AhjMgwDgAzQidgDhtiBQhth+ADixQADixBxh9QByh7CdADMAwCAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAguAhoMgwDgA0QicgChuiBQhsh+ADixQACixBxh9QByh7CdADMAwDAAzQCcADBtB+QBtCAgCCyQgDCxhyB7QhvB6iYAAIgHAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAl8AhuMgwDgAzQidgChuiBQhsh+ADiyQADixBwh9QBzh6CcACMAwDAA0QCdACBsB/QBuCAgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EArKAh1MgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAu+Ah6MgwDgAzQidgDhuiAQhsh/ADixQADixBwh9QByh7CdADMAwDAAzQCdADBsB+QBuCBgDCxQgDCxhyB7QhuB6iZAAIgGAAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAwXAh8MgwEgAzQibgDhuiBQhth+ADixQADixBxh9QByh7CcADMAwDAAzQCdADBsB+QBuCAgDCyQgDCxhyB7QhuB6iYAAIgHAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:-146.3119,y:210.6548}).wait(1).to({graphics:mask_1_graphics_16,x:-133.053,y:210.7687}).wait(1).to({graphics:mask_1_graphics_17,x:-95.9024,y:211.088}).wait(1).to({graphics:mask_1_graphics_18,x:-42.2182,y:211.5494}).wait(1).to({graphics:mask_1_graphics_19,x:17.3667,y:212.0615}).wait(1).to({graphics:mask_1_graphics_20,x:71.0509,y:212.5229}).wait(1).to({graphics:mask_1_graphics_21,x:108.2015,y:212.8422}).wait(1).to({graphics:mask_1_graphics_22,x:121.2881,y:212.9548}).wait(1).to({graphics:mask_1_graphics_23,x:126.579,y:213.0252}).wait(1).to({graphics:mask_1_graphics_24,x:131.8699,y:213.0956}).wait(1).to({graphics:mask_1_graphics_25,x:137.1608,y:213.1661}).wait(1).to({graphics:mask_1_graphics_26,x:142.4517,y:213.2365}).wait(1).to({graphics:mask_1_graphics_27,x:147.7426,y:213.307}).wait(1).to({graphics:mask_1_graphics_28,x:153.0335,y:213.3774}).wait(1).to({graphics:mask_1_graphics_29,x:158.3245,y:213.4479}).wait(1).to({graphics:mask_1_graphics_30,x:163.6154,y:213.5184}).wait(1).to({graphics:mask_1_graphics_31,x:168.9063,y:213.5888}).wait(1).to({graphics:mask_1_graphics_32,x:174.1972,y:213.6593}).wait(1).to({graphics:mask_1_graphics_33,x:179.4881,y:213.7297}).wait(1).to({graphics:mask_1_graphics_34,x:184.779,y:213.8002}).wait(1).to({graphics:mask_1_graphics_35,x:190.0699,y:213.8706}).wait(1).to({graphics:mask_1_graphics_36,x:193.5351,y:213.9411}).wait(1).to({graphics:mask_1_graphics_37,x:196.1806,y:214.0115}).wait(1).to({graphics:mask_1_graphics_38,x:198.826,y:214.082}).wait(1).to({graphics:mask_1_graphics_39,x:201.4715,y:214.1524}).wait(1).to({graphics:mask_1_graphics_40,x:204.1169,y:214.2229}).wait(1).to({graphics:mask_1_graphics_41,x:206.7624,y:214.2934}).wait(1).to({graphics:mask_1_graphics_42,x:209.4078,y:214.3638}).wait(1).to({graphics:mask_1_graphics_43,x:212.0533,y:214.4343}).wait(1).to({graphics:mask_1_graphics_44,x:214.6989,y:214.5048}).wait(1).to({graphics:mask_1_graphics_45,x:223.6382,y:214.6839}).wait(1).to({graphics:mask_1_graphics_46,x:248.0612,y:215.1735}).wait(1).to({graphics:mask_1_graphics_47,x:281.4238,y:215.8422}).wait(1).to({graphics:mask_1_graphics_48,x:314.7863,y:216.511}).wait(1).to({graphics:mask_1_graphics_49,x:339.2093,y:217.0005}).wait(1).to({graphics:mask_1_graphics_50,x:348.1489,y:217.1798}).wait(10));

	// Layer_9
	this.instance_1 = new lib.scribble4_4();
	this.instance_1.setTransform(178.3,382.4,1.538,1.538,0,0,0,84.9,27.7);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(45));

	// Layer_4 copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("AAMWMQiegzhaiYQhbiYAeimQAhikCHhQMApTgYjQCGhRCfAzQChA0BbCYQBaCYggClQgfCliGBQMgpVAYjQhSAxhbAAQg7AAg/gUg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AilX0QiegzhbiYQhaiZAeilQAgikCHhQMApTgYkQCHhQCfAzQChA0BaCYQBbCYghClQgeCliHBQMgpUAYjQhSAxhbAAQg7AAg/gUg");
	var mask_2_graphics_14 = new cjs.Graphics().p("ApRbuQiegzhbiYQhaiYAeilQAgilCHhQMApTgYjQCHhQCeAyQChA0BbCYQBbCZghCkQgeCkiHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_15 = new cjs.Graphics().p("Av9fpQiegzhbiYQhbiZAfilQAgikCHhQMApTgYkQCHhQCeAzQChA0BbCYQBaCXggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_16 = new cjs.Graphics().p("EgSvAhQQiegzhbiYQhaiZAeilQAgikCHhQMApTgYkQCHhQCeAzQChAzBbCZQBbCXghClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EgTBAhaQiegzhbiYQhaiYAeilQAhilCGhQMApTgYjQCHhQCfAyQChA0BaCYQBbCYghCkQgeCliHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EgTSAhlQifgzhaiZQhbiYAeilQAhikCHhRMApTgYjQCGhQCfAzQChAzBbCZQBaCXggCkQgfCmiGBQMgpUAYkQhSAxhbAAQg7AAg/gUg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EgTkAhvQifgzhaiYQhbiYAeimQAhikCHhQMApTgYjQCHhRCeAzQChA0BbCYQBaCXggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EgT2Ah5QiegyhbiZQhaiYAeilQAgilCHhQMApTgYjQCHhQCeAzQChAzBbCYQBbCYghCkQgeCliHBRMgpTAYkQhSAxhcAAQg7AAg/gVg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EgUIAiEQiegzhbiYQhaiZAeilQAgikCHhQMApTgYjQCHhRCfAzQChA0BaCXQBbCYghClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EgUZAiOQifgyhaiZQhbiYAeilQAhilCHhQMApTgYjQCGhQCfAzQChAzBaCXQBbCZghCkQgeCliGBQMgpUAYlQhSAwhbAAQg7AAg/gUg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EgUrAiZQifgzhaiYQhbiZAeilQAhikCHhQMApTgYkQCHhQCeAzQChA0BbCXQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EgU9AijQiegzhbiYQhbiYAfilQAgilCHhQMApTgYjQCHhQCeAyQChA0BbCXQBbCZghCkQgeCliHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EgVPAiuQiegzhbiYQhaiZAeilQAgikCHhRMApTgYjQCHhQCfAzQChAzBaCYQBbCYghCkQgeCmiHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EgVgAi4QifgzhaiYQhbiYAeimQAhikCGhQMApUgYjQCGhQCfAyQChA0BaCXQBbCZghCkQgeCliGBQMgpUAYkQhSAxhbAAQg7AAg/gUg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EgVyAjCQifgyhaiZQhbiYAeilQAhilCHhQMApTgYjQCHhQCeAzQChAzBbCYQBaCYggCkQgeCmiHBQMgpTAYkQhSAxhcAAQg7AAg/gVg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EgV1AjNQifgzhaiYQhbiZAeilQAhikCHhQMApTgYjQCHhRCeAzQChA0BbCXQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EgV1AjXQifgyhaiZQhbiYAeilQAhilCHhQMApTgYjQCHhQCeAzQChAzBbCYQBaCYggCkQgeCliHBRMgpTAYkQhSAxhcAAQg7AAg/gVg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EgV1AjiQifgzhaiYQhbiZAeilQAhikCHhQMApTgYkQCHhQCeAzQChA0BbCXQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EgV1AjsQifgzhaiYQhbiYAeilQAhilCHhQMApTgYjQCHhQCeAyQChA0BbCXQBaCZggCkQgeCliHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EgV1Aj3QifgzhaiYQhbiZAeilQAhikCHhQMApTgYkQCHhQCeAzQChAzBbCYQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EgV1AkBQifgzhaiYQhbiYAeimQAhikCHhQMApTgYjQCHhQCeAyQChA0BbCXQBaCZggCkQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EgV1AkMQifgzhaiZQhbiYAeilQAhikCHhRMApTgYjQCHhQCeAzQChAyBbCZQBaCYggCkQgeCmiHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EgV1AkWQifgzhaiYQhbiYAeimQAhikCHhQMApTgYjQCHhRCeAzQChAzBbCYQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EgV1AkgQifgyhaiZQhbiYAeilQAhilCHhQMApTgYjQCHhQCeAzQChAyBbCZQBaCYggCkQgeCliHBRMgpTAYkQhSAxhcAAQg7AAg/gVg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EgV1AkrQifgzhaiYQhbiZAeilQAhikCHhQMApTgYkQCHhQCeAzQChAzBbCYQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EgV1Ak1QifgyhaiZQhbiYAeilQAhilCHhQMApTgYkQCHhPCeAzQChAyBbCYQBaCZggCkQgeCliHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EgV1AlAQifgzhaiYQhbiZAeilQAhikCHhQMApTgYlQCHhPCeAyQChA0BbCYQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgV1AlKQifgzhaiYQhbiYAeilQAhilCHhQMApTgYkQCHhPCeAxQChA0BbCYQBaCZggCkQgeCliHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgV1AlVQifgyhaiZQhbiYAeilQAhilCHhQMApTgYkQCHhPCeAyQChAzBbCZQBaCYggCkQgeCliHBRMgpTAYkQhSAxhcAAQg7AAg/gVg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgV1Am+QifgzhaiYQhbiZAeilQAhikCHhQMApTgYlQCHhQCeAzQChAzBbCZQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgV1Aq5QifgzhaiYQhbiYAeilQAhilCHhQMApTgYkQCHhQCeAzQChAzBbCYQBaCZggCkQgeCliHBQMgpTAYlQhSAwhcAAQg7AAg/gUg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgV1Au1QifgzhaiYQhbiZAeilQAhikCHhQMApTgYkQCHhRCeAzQChA0BbCYQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgV1AwdQifgzhaiYQhbiZAeilQAhikCHhQMApTgYlQCHhQCeAzQChAzBbCZQBaCYggClQgeCliHBQMgpTAYkQhSAxhcAAQg7AAg/gUg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:312.5174,y:144.011}).wait(1).to({graphics:mask_2_graphics_13,x:294.7815,y:154.3872}).wait(1).to({graphics:mask_2_graphics_14,x:251.9661,y:179.4395}).wait(1).to({graphics:mask_2_graphics_15,x:209.1507,y:204.4918}).wait(1).to({graphics:mask_2_graphics_16,x:191.3674,y:214.786}).wait(1).to({graphics:mask_2_graphics_17,x:189.5903,y:215.8288}).wait(1).to({graphics:mask_2_graphics_18,x:187.8143,y:216.8725}).wait(1).to({graphics:mask_2_graphics_19,x:186.0383,y:217.9161}).wait(1).to({graphics:mask_2_graphics_20,x:184.2623,y:218.9598}).wait(1).to({graphics:mask_2_graphics_21,x:182.4863,y:220.0034}).wait(1).to({graphics:mask_2_graphics_22,x:180.7103,y:221.0471}).wait(1).to({graphics:mask_2_graphics_23,x:178.9343,y:222.0907}).wait(1).to({graphics:mask_2_graphics_24,x:177.1583,y:223.1344}).wait(1).to({graphics:mask_2_graphics_25,x:175.3823,y:224.178}).wait(1).to({graphics:mask_2_graphics_26,x:173.6064,y:225.2217}).wait(1).to({graphics:mask_2_graphics_27,x:171.8304,y:226.2653}).wait(1).to({graphics:mask_2_graphics_28,x:168.5842,y:227.309}).wait(1).to({graphics:mask_2_graphics_29,x:165.0322,y:228.3526}).wait(1).to({graphics:mask_2_graphics_30,x:161.4802,y:229.3963}).wait(1).to({graphics:mask_2_graphics_31,x:157.9283,y:230.4399}).wait(1).to({graphics:mask_2_graphics_32,x:154.3763,y:231.4836}).wait(1).to({graphics:mask_2_graphics_33,x:150.8243,y:232.5272}).wait(1).to({graphics:mask_2_graphics_34,x:147.2723,y:233.5709}).wait(1).to({graphics:mask_2_graphics_35,x:143.7203,y:234.6145}).wait(1).to({graphics:mask_2_graphics_36,x:140.1684,y:235.6582}).wait(1).to({graphics:mask_2_graphics_37,x:136.6164,y:236.7019}).wait(1).to({graphics:mask_2_graphics_38,x:133.0644,y:237.7455}).wait(1).to({graphics:mask_2_graphics_39,x:129.5124,y:238.7892}).wait(1).to({graphics:mask_2_graphics_40,x:125.9604,y:239.8328}).wait(1).to({graphics:mask_2_graphics_41,x:122.5079,y:240.961}).wait(1).to({graphics:mask_2_graphics_42,x:87.5881,y:251.3826}).wait(1).to({graphics:mask_2_graphics_43,x:3.2839,y:276.5447}).wait(1).to({graphics:mask_2_graphics_44,x:-81.0202,y:301.7067}).wait(1).to({graphics:mask_2_graphics_45,x:-115.7921,y:312.086}).wait(15));

	// Layer_8
	this.instance_2 = new lib.scribble4_3();
	this.instance_2.setTransform(169,334.95,1.538,1.538,0,0,0,79,57.4);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).wait(48));

	// Layer_4 copy (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_7 = new cjs.Graphics().p("AYAZvMgwDgAQQidAAhwiAQhth9ABixQABixBvh+QBwh8CdAAMAwDAAQQCdABBuB9QBvB/gBCxQgBCyhwB8QhuB9icAAIgCAAg");
	var mask_3_graphics_8 = new cjs.Graphics().p("AYAZwMgwDgAQQidgBhwh/Qhth9ABixQABixBuh+QBxh9CdABMAwDAAQQCdABBuB9QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_9 = new cjs.Graphics().p("AYAZyMgwDgAQQidAAhwiAQhth9ABixQABixBuh+QBxh8CdAAMAwDAAQQCdABBuB9QBvB/gBCxQgBCxhwB9QhuB9icAAIgCAAg");
	var mask_3_graphics_10 = new cjs.Graphics().p("AYAZ1MgwDgAQQidgBhwh/Qhth9ABixQABixBuh+QBxh8CdAAMAwDAAQQCdABBuB9QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_11 = new cjs.Graphics().p("AYAZ4MgwDgAQQidgBhwh/Qhth9ABixQABixBuh+QBxh9CdABMAwDAAQQCdABBuB9QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_12 = new cjs.Graphics().p("AYAZ6MgwDgAQQidAAhwiAQhth9ABixQABixBuh+QBxh8CdAAMAwDAAQQCdABBuB9QBvB/gBCxQgBCxhwB9QhuB9icAAIgCAAg");
	var mask_3_graphics_13 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBvh/QBwh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_16 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_18 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_19 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_20 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_22 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_23 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_24 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_25 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_26 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_27 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_28 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_29 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_30 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_31 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AYAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AYVZ7MgwEgAQQidgBhvh/Qhuh9ABixQABixBvh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhxB8QhuB+ibAAIgCAAg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AYqZ7MgwDgAQQidgBhvh/Qhuh9ABixQABixBvh/QBxh8CcABMAwEAAQQCdAABtB+QBwB/gBCxQgBCxhxB8QhuB+icAAIgCAAg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AZAZ7MgwDgAQQidgBhvh/Qhuh9ABixQABixBvh/QBwh8CdABMAwEAAQQCcAABuB+QBvB/AACxQgBCxhxB8QhuB+icAAIgCAAg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AafZ7MgwEgAQQidgBhvh/Qhuh9ABixQABixBvh/QBxh8CdABMAwDAAQQCdAABtB+QBwB/gBCxQgBCxhxB8QhuB+ibAAIgCAAg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AegZ7MgwDgAQQidgBhvh/Qhuh9ABixQABixBvh/QBwh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQAACxhxB8QhuB+icAAIgCAAg");
	var mask_3_graphics_39 = new cjs.Graphics().p("EAkAAZ7MgwDgAQQidgBhwh/Qhth9ABixQABixBuh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhuB+icAAIgCAAg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EApgAZ7MgwDgAQQidgBhwh/Qhth9ABixQAAixBvh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhvB+ibAAIgCAAg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EAtiAZ7MgwEgAQQidgBhvh/Qhuh9ABixQABixBvh/QBxh8CcABMAwEAAQQCdAABtB+QBwB/gBCxQgBCxhxB8QhuB+icAAIgBAAg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EAvAAZ7MgwEgAQQicgBhwh/Qhth9AAixQABixBvh/QBxh8CdABMAwDAAQQCdAABuB+QBvB/gBCxQgBCxhwB8QhvB+ibAAIgCAAg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(7).to({graphics:mask_3_graphics_7,x:-182.5618,y:164.6865}).wait(1).to({graphics:mask_3_graphics_8,x:-163.3432,y:164.7656}).wait(1).to({graphics:mask_3_graphics_9,x:-110.8369,y:164.9806}).wait(1).to({graphics:mask_3_graphics_10,x:-39.1119,y:165.2744}).wait(1).to({graphics:mask_3_graphics_11,x:32.6131,y:165.5681}).wait(1).to({graphics:mask_3_graphics_12,x:85.1195,y:165.7832}).wait(1).to({graphics:mask_3_graphics_13,x:104.3382,y:165.8615}).wait(1).to({graphics:mask_3_graphics_14,x:108.6968,y:165.8619}).wait(1).to({graphics:mask_3_graphics_15,x:113.0555,y:165.8619}).wait(1).to({graphics:mask_3_graphics_16,x:117.4142,y:165.8619}).wait(1).to({graphics:mask_3_graphics_17,x:121.7729,y:165.8619}).wait(1).to({graphics:mask_3_graphics_18,x:126.1316,y:165.8619}).wait(1).to({graphics:mask_3_graphics_19,x:130.4903,y:165.8619}).wait(1).to({graphics:mask_3_graphics_20,x:134.849,y:165.8619}).wait(1).to({graphics:mask_3_graphics_21,x:139.2077,y:165.8619}).wait(1).to({graphics:mask_3_graphics_22,x:143.5664,y:165.8619}).wait(1).to({graphics:mask_3_graphics_23,x:147.9251,y:165.8619}).wait(1).to({graphics:mask_3_graphics_24,x:152.2838,y:165.8619}).wait(1).to({graphics:mask_3_graphics_25,x:156.6425,y:165.8619}).wait(1).to({graphics:mask_3_graphics_26,x:161.0012,y:165.8619}).wait(1).to({graphics:mask_3_graphics_27,x:165.3599,y:165.8619}).wait(1).to({graphics:mask_3_graphics_28,x:169.7186,y:165.8619}).wait(1).to({graphics:mask_3_graphics_29,x:174.0773,y:165.8619}).wait(1).to({graphics:mask_3_graphics_30,x:178.436,y:165.8619}).wait(1).to({graphics:mask_3_graphics_31,x:182.7947,y:165.8619}).wait(1).to({graphics:mask_3_graphics_32,x:187.1534,y:165.8619}).wait(1).to({graphics:mask_3_graphics_33,x:191.5121,y:165.8619}).wait(1).to({graphics:mask_3_graphics_34,x:193.8032,y:165.8619}).wait(1).to({graphics:mask_3_graphics_35,x:195.9826,y:165.8619}).wait(1).to({graphics:mask_3_graphics_36,x:198.1602,y:165.8615}).wait(1).to({graphics:mask_3_graphics_37,x:207.5904,y:165.8619}).wait(1).to({graphics:mask_3_graphics_38,x:233.3494,y:165.8619}).wait(1).to({graphics:mask_3_graphics_39,x:268.5369,y:165.8619}).wait(1).to({graphics:mask_3_graphics_40,x:303.7244,y:165.8619}).wait(1).to({graphics:mask_3_graphics_41,x:329.4835,y:165.8619}).wait(1).to({graphics:mask_3_graphics_42,x:338.9102,y:165.8615}).wait(18));

	// Layer_5
	this.instance_3 = new lib.scribble4_2();
	this.instance_3.setTransform(152.75,287.55,1.538,1.538,0,0,0,89.4,27.5);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(7).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("Ah+P+QiXhGhIiiQhIiiAyigQA0igCPg/MAr7gTfQCPg/CYBFQCZBGBICiQBICig0CgQgxCgiPBAMgr9ATeQhEAehGAAQhNAAhRgkg");
	var mask_4_graphics_1 = new cjs.Graphics().p("AiRQGQiXhFhIiiQhIiiAyihQAzifCQhAMAr7gTeQCPhACYBFQCZBHBICiQBICig0CfQgxCgiQBAMgr8ATfQhEAehGAAQhNAAhRglg");
	var mask_4_graphics_2 = new cjs.Graphics().p("AjYQlQiXhFhIiiQhIiiAyigQA0igCPg/MAr7gTfQCPhACYBGQCaBGBHCiQBICig0CfQgxChiPA/Mgr9ATfQhEAehFAAQhOAAhRglg");
	var mask_4_graphics_3 = new cjs.Graphics().p("AlyRpQiXhFhIiiQhIiiAyigQA0igCPg/MAr7gTfQCQhACXBGQCaBGBICiQBHCigzCfQgyChiPA/Mgr7ATfQhFAehGAAQhOAAhRglg");
	var mask_4_graphics_4 = new cjs.Graphics().p("AqCTiQiYhFhHiiQhIiiAxihQA0ifCPhAMAr8gTeQCPhACXBFQCaBGBICiQBICig0CgQgyCgiPA/Mgr7ATfQhEAfhHAAQhNAAhRglg");
	var mask_4_graphics_5 = new cjs.Graphics().p("AvNV0QiYhFhHiiQhIiiAxihQA0ifCPhAMAr8gTeQCPhACXBFQCaBHBICiQBICig0CfQgyCgiPA/Mgr7ATgQhEAehHAAQhNAAhRglg");
	var mask_4_graphics_6 = new cjs.Graphics().p("AzHXjQiYhGhHiiQhIiiAxigQA0igCPg/MAr8gTfQCPg/CXBFQCaBGBICiQBICig0CfQgyCgiPBAMgr7ATfQhEAehHAAQhNAAhRgkg");
	var mask_4_graphics_7 = new cjs.Graphics().p("A1gYmQiYhFhIiiQhIiiAyigQA0igCPg/MAr7gTfQCQhACXBGQCaBGBICiQBHCigzCeQgyChiPA/Mgr7ATgQhEAehHAAQhOAAhQglg");
	var mask_4_graphics_8 = new cjs.Graphics().p("A24ZOQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBICig0CeQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_9 = new cjs.Graphics().p("A3MZXQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACYBFQCZBHBICiQBICig0CeQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_10 = new cjs.Graphics().p("A3gZgQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACYBFQCZBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_11 = new cjs.Graphics().p("A30ZpQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACYBFQCZBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_12 = new cjs.Graphics().p("A34ZyQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_13 = new cjs.Graphics().p("A34Z7QiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_14 = new cjs.Graphics().p("A34aEQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_15 = new cjs.Graphics().p("A34aNQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_16 = new cjs.Graphics().p("A34aWQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_17 = new cjs.Graphics().p("A34afQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_18 = new cjs.Graphics().p("A34aoQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_19 = new cjs.Graphics().p("A34axQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_20 = new cjs.Graphics().p("A34a6QiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_21 = new cjs.Graphics().p("A34bDQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_22 = new cjs.Graphics().p("A34bMQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_23 = new cjs.Graphics().p("A34bVQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_24 = new cjs.Graphics().p("A34beQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_25 = new cjs.Graphics().p("A34bnQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBHBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_26 = new cjs.Graphics().p("A34bwQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBGQCaBGBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_27 = new cjs.Graphics().p("A34b5QiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBGQCaBGBICiQBIChg0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_28 = new cjs.Graphics().p("A34cCQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBGQCaBGBIChQBICig0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_29 = new cjs.Graphics().p("A34cKQiXhFhIiiQhIiiAxigQA0igCQg/MAr7gTfQCPhACXBGQCaBGBIChQBICig0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A34cTQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBGBIChQBICig0CgQgxCgiQBAMgr7ATfQhEAfhGAAQhOAAhRglg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A34cyQiXhFhIiiQhIiiAxigQA0igCQg/MAr7gTfQCPhACXBGQCaBGBIChQBICig0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A34d3QiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTeQCPhACXBFQCaBGBIChQBICig0CgQgxCgiQBAMgr7ATfQhEAfhGAAQhOAAhRglg");
	var mask_4_graphics_33 = new cjs.Graphics().p("A34fwQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTfQCPg/CXBEQCaBHBICiQBICig0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_34 = new cjs.Graphics().p("EgX4AiDQiXhFhIiiQhIiiAxigQA0igCQg/MAr7gTgQCPhACXBGQCaBGBICiQBICig0CfQgxChiQA/Mgr7ATgQhEAehGAAQhOAAhRglg");
	var mask_4_graphics_35 = new cjs.Graphics().p("EgX4AjzQiXhGhIiiQhIiiAxigQA0ifCQhAMAr7gTgQCPg/CXBFQCaBGBICiQBICig0CgQgxCgiQBAMgr7ATfQhEAehGAAQhOAAhRgkg");
	var mask_4_graphics_36 = new cjs.Graphics().p("EgX4Ak3QiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTfQCPhACXBFQCaBGBICiQBICig0CgQgxCgiQBAMgr7ATfQhEAfhGAAQhOAAhRglg");
	var mask_4_graphics_37 = new cjs.Graphics().p("EgX4AlfQiXhFhIiiQhIiiAxihQA0ifCQhAMAr7gTfQCPhACXBFQCaBGBICiQBICig0CgQgxCgiQBAMgr7ATfQhEAfhGAAQhOAAhRglg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:319.7098,y:105.8405}).wait(1).to({graphics:mask_4_graphics_1,x:317.7998,y:106.6861}).wait(1).to({graphics:mask_4_graphics_2,x:310.7186,y:109.8156}).wait(1).to({graphics:mask_4_graphics_3,x:295.3278,y:116.6175}).wait(1).to({graphics:mask_4_graphics_4,x:268.0643,y:128.6665}).wait(1).to({graphics:mask_4_graphics_5,x:234.9654,y:143.2944}).wait(1).to({graphics:mask_4_graphics_6,x:209.9668,y:154.3425}).wait(1).to({graphics:mask_4_graphics_7,x:194.6373,y:161.1173}).wait(1).to({graphics:mask_4_graphics_8,x:185.8848,y:165.0905}).wait(1).to({graphics:mask_4_graphics_9,x:183.8868,y:165.992}).wait(1).to({graphics:mask_4_graphics_10,x:181.8875,y:166.8927}).wait(1).to({graphics:mask_4_graphics_11,x:179.8882,y:167.7933}).wait(1).to({graphics:mask_4_graphics_12,x:176.2958,y:168.694}).wait(1).to({graphics:mask_4_graphics_13,x:172.2972,y:169.5947}).wait(1).to({graphics:mask_4_graphics_14,x:168.2986,y:170.4953}).wait(1).to({graphics:mask_4_graphics_15,x:164.3,y:171.396}).wait(1).to({graphics:mask_4_graphics_16,x:160.3013,y:172.2967}).wait(1).to({graphics:mask_4_graphics_17,x:156.3027,y:173.1973}).wait(1).to({graphics:mask_4_graphics_18,x:152.3041,y:174.098}).wait(1).to({graphics:mask_4_graphics_19,x:148.3055,y:174.9987}).wait(1).to({graphics:mask_4_graphics_20,x:144.3069,y:175.8993}).wait(1).to({graphics:mask_4_graphics_21,x:140.3082,y:176.8}).wait(1).to({graphics:mask_4_graphics_22,x:136.3096,y:177.7007}).wait(1).to({graphics:mask_4_graphics_23,x:132.311,y:178.6013}).wait(1).to({graphics:mask_4_graphics_24,x:128.3124,y:179.502}).wait(1).to({graphics:mask_4_graphics_25,x:124.3138,y:180.4027}).wait(1).to({graphics:mask_4_graphics_26,x:120.3151,y:181.3033}).wait(1).to({graphics:mask_4_graphics_27,x:116.3165,y:182.204}).wait(1).to({graphics:mask_4_graphics_28,x:112.3179,y:183.1047}).wait(1).to({graphics:mask_4_graphics_29,x:108.2403,y:183.9155}).wait(1).to({graphics:mask_4_graphics_30,x:104.4297,y:184.7668}).wait(1).to({graphics:mask_4_graphics_31,x:90.3123,y:187.9174}).wait(1).to({graphics:mask_4_graphics_32,x:59.6284,y:194.7653}).wait(1).to({graphics:mask_4_graphics_33,x:5.2746,y:206.8958}).wait(1).to({graphics:mask_4_graphics_34,x:-60.713,y:221.6227}).wait(1).to({graphics:mask_4_graphics_35,x:-110.5516,y:232.7454}).wait(1).to({graphics:mask_4_graphics_36,x:-141.1132,y:239.5661}).wait(1).to({graphics:mask_4_graphics_37,x:-158.5597,y:243.5655}).wait(23));

	// Layer_2
	this.instance_4 = new lib.scribble4_1();
	this.instance_4.setTransform(149.8,244.15,1.538,1.538,0,0,0,88,53.9);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(60));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,308.9,507.6);


(lib.scribble3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,460,230,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble3_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(230.2,116.4,1,1,0,0,0,230.2,116.4);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3_1, new cjs.Rectangle(0,0,460.5,232.8), null);


(lib.scribble3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EAvBAs2Mh/xgydQmgikiVnhQiYnpDOoIQDNoHG6j4QG4j/GgClMB/xAycQGhClCXHpQCVHhjNIHQjNIIm4D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_2 = new cjs.Graphics().p("EAvVAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCVHhjOIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_3 = new cjs.Graphics().p("EAv6As2Mh/xgydQmhikiVnhQiXnpDNoIQDOoHG6j4QG3j/GhClMB/xAycQGhClCXHpQCVHhjNIHQjNIIm4D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_4 = new cjs.Graphics().p("EAwxAs2Mh/xgydQmhikiVnhQiXnpDNoIQDNoHG7j4QG3j/GhClMB/xAycQGhClCXHpQCVHhjNIHQjNIIm4D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_5 = new cjs.Graphics().p("EAx9As2Mh/xgydQmhikiUnhQiYnpDNoIQDOoHG6j4QG4j/GgClMB/xAycQGhClCXHpQCVHhjNIHQjNIIm4D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_6 = new cjs.Graphics().p("EAziAs2Mh/xgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/xAycQGhClCXHpQCVHhjOIHQjNIIm3D/QkKCVkBAAQiqAAimhCg");
	var mask_graphics_7 = new cjs.Graphics().p("EA1iAs2Mh/xgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/xAycQGhClCXHpQCVHhjNIHQjOIIm3D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_8 = new cjs.Graphics().p("EA4AAs2Mh/xgydQmhikiVnhQiXnpDNoIQDOoHG6j4QG3j/GhClMB/xAycQGhClCXHpQCVHhjNIHQjNIIm4D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_9 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_10 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_11 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_12 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_13 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_14 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_15 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_16 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_17 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_18 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_19 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_20 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_21 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_22 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_23 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_24 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_25 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_26 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_27 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_28 = new cjs.Graphics().p("EA4IAs2Mh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_29 = new cjs.Graphics().p("EA4IAtdMh/wgydQmhiliVnhQiXnpDNoHQDNoIG6j3QG4kAGhClMB/wAydQGhClCYHoQCUHhjNIIQjNIHm4EAQkJCUkBAAQiqAAinhBg");
	var mask_graphics_30 = new cjs.Graphics().p("EA4IAxeMh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_31 = new cjs.Graphics().p("EA4IAxfMh/wgycQmhiliVnhQiXnpDNoHQDNoIG6j4QG4j/GhClMB/wAydQGhCkCYHpQCUHhjNIIQjNIHm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_32 = new cjs.Graphics().p("EA4IAxkMh/wgydQmhiliVnhQiXnpDNoHQDNoIG6j3QG4kAGhClMB/wAydQGhClCYHoQCUHhjNIIQjNIHm4EAQkJCUkBAAQiqAAinhBg");
	var mask_graphics_33 = new cjs.Graphics().p("EA4IAxrMh/wgydQmhikiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_34 = new cjs.Graphics().p("EA4IAx2Mh/wgycQmhiliVnhQiXnpDNoHQDNoIG6j4QG4j/GhClMB/wAydQGhCkCYHpQCUHhjNIIQjNIHm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_35 = new cjs.Graphics().p("EA4IAyGMh/wgydQmhiliVnhQiXnoDNoIQDNoHG6j4QG4j/GhCkMB/wAydQGhClCYHoQCUHijNIHQjNIHm4EAQkJCVkBAAQiqAAinhCg");
	var mask_graphics_36 = new cjs.Graphics().p("EA4IAyaMh/wgydQmhikiVniQiXnoDNoIQDNoHG6j4QG4j/GhCkMB/wAydQGhClCYHoQCUHijNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_37 = new cjs.Graphics().p("EA4IAy0Mh/wgyeQmhikiVnhQiXnpDNoHQDNoIG6j3QG4kAGhClMB/wAydQGhCkCYHpQCUHhjNIIQjNIHm4D/QkJCVkBAAQiqAAinhBg");
	var mask_graphics_38 = new cjs.Graphics().p("EA4IAzTMh/wgydQmhikiVnhQiXnpDNoHQDNoIG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_39 = new cjs.Graphics().p("EA4IAz6Mh/wgyeQmhijiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_40 = new cjs.Graphics().p("EA4IA0pMh/wgyeQmhijiVnhQiXnpDNoIQDNoHG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_41 = new cjs.Graphics().p("EA4IA1hMh/wgydQmhiliVngQiXnpDNoHQDNoIG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_42 = new cjs.Graphics().p("EA4IA2jMh/wgydQmhiliVngQiXnpDNoHQDNoIG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_43 = new cjs.Graphics().p("EA4IA3wMh/wgyeQmhiliVngQiXnpDNoHQDNoIG6j3QG4kAGhClMB/wAydQGhCkCYHpQCUHhjNIIQjNIHm4D/QkJCVkBAAQiqAAinhBg");
	var mask_graphics_44 = new cjs.Graphics().p("EA4IA5FMh/wgydQmhiliVngQiXnpDNoHQDNoIG6j4QG4j/GhClMB/wAycQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_45 = new cjs.Graphics().p("EA6kA6iMh/wgydQmhiliVngQiXnpDNoHQDNoIG6j4QG4j/GhClMB/xAydQGgCkCYHpQCVHhjOIIQjNIHm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_46 = new cjs.Graphics().p("EA+YA8DMh/wgyeQmhikiVngQiXnpDNoIQDNoHG6j4QG4j/GhCkMB/wAydQGhClCYHpQCUHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_47 = new cjs.Graphics().p("EBCKA9jMh/wgyeQmhiliVnhQiYnnDOoIQDNoHG6j4QG4j/GhCkMB/wAydQGhClCXHoQCVHijNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_48 = new cjs.Graphics().p("EBFwA++Mh/xgyeQmhikiVniQiXnnDNoIQDNoHG6j4QG4j/GhCkMB/xAydQGhClCXHoQCVHijNIHQjOIIm3D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_49 = new cjs.Graphics().p("EBJDBARMh/xgydQmhiliVnhQiXnoDNoHQDNoIG6j3QG4kAGhClMB/xAydQGhCkCXHpQCVHhjOIIQjNIHm3D/QkKCVkBAAQiqAAimhCg");
	var mask_graphics_50 = new cjs.Graphics().p("EBMABBcMh/xgydQmhiliVnhQiXnoDNoHQDNoIG6j4QG4j/GhClMB/xAydQGhCkCXHpQCVHhjNIIQjOIHm3D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_51 = new cjs.Graphics().p("EBOnBCfMh/xgyeQmhiliVnhQiXnoDNoHQDNoIG6j3QG4kAGhClMB/xAydQGhCkCXHpQCVHhjNIIQjOIHm3EAQkKCUkAAAQirAAimhBg");
	var mask_graphics_52 = new cjs.Graphics().p("EBQ5BDZMh/xgyeQmhiliVnhQiXnoDNoHQDOoIG6j3QG3kAGhClMB/xAydQGhCkCXHpQCVHhjNIIQjNIHm4D/QkKCVkAAAQirAAimhBg");
	var mask_graphics_53 = new cjs.Graphics().p("EBS4BELMh/xgyeQmgikiVniQiYnnDOoIQDNoHG6j4QG4j/GgCkMB/xAydQGhClCXHoQCVHijNIHQjNIIm4D/QkKCVkAAAQiqAAinhCg");
	var mask_graphics_54 = new cjs.Graphics().p("EBUmBE3Mh/wgyeQmhiliVnhQiXnpDNoGQDNoIG6j3QG4kAGhClMB/wAydQGhCkCXHpQCVHhjNIIQjNIHm4EAQkJCUkBAAQiqAAinhBg");
	var mask_graphics_55 = new cjs.Graphics().p("EBWFBFcMh/wgydQmhiliVnhQiXnpDNoGQDNoIG6j4QG4j/GhClMB/wAydQGhCkCXHpQCVHhjNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_56 = new cjs.Graphics().p("EBXXBF9Mh/xgyeQmhiliUnhQiYnpDOoGQDNoHG6j4QG4kAGgClMB/xAydQGhClCXHoQCVHhjNIIQjNIHm4EAQkKCUkAAAQirAAimhBg");
	var mask_graphics_57 = new cjs.Graphics().p("EBYdBGYMh/xgydQmhiliVnhQiXnpDNoGQDOoIG6j4QG3j/GhClMB/xAydQGhCkCXHpQCVHhjNIIQjNIHm4D/QkKCVkAAAQirAAimhCg");
	var mask_graphics_58 = new cjs.Graphics().p("EBZYBGwMh/wgyeQmhikiVniQiXnoDNoHQDNoHG6j4QG4j/GhCkMB/wAydQGhClCXHoQCVHijNIHQjNIIm4D/QkJCVkBAAQiqAAinhCg");
	var mask_graphics_59 = new cjs.Graphics().p("EBaKBHEMh/wgyeQmhiliVnhQiXnoDNoHQDNoHG6j4QG4j/GhCkMB/wAydQGhClCXHoQCVHhjNIIQjNIHm4EAQkJCVkBAAQiqAAinhCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-579.8544,y:-1.2366}).wait(1).to({graphics:mask_graphics_2,x:-577.8163,y:0.3898}).wait(1).to({graphics:mask_graphics_3,x:-574.1716,y:3.2939}).wait(1).to({graphics:mask_graphics_4,x:-568.6803,y:7.6694}).wait(1).to({graphics:mask_graphics_5,x:-561.0618,y:13.7397}).wait(1).to({graphics:mask_graphics_6,x:-551.0059,y:21.7522}).wait(1).to({graphics:mask_graphics_7,x:-538.1976,y:31.9578}).wait(1).to({graphics:mask_graphics_8,x:-522.3771,y:44.5634}).wait(1).to({graphics:mask_graphics_9,x:-485.3823,y:59.6433}).wait(1).to({graphics:mask_graphics_10,x:-441.7898,y:77.0105}).wait(1).to({graphics:mask_graphics_11,x:-393.8665,y:96.103}).wait(1).to({graphics:mask_graphics_12,x:-343.9257,y:115.9993}).wait(1).to({graphics:mask_graphics_13,x:-294.6454,y:135.6324}).wait(1).to({graphics:mask_graphics_14,x:-248.3122,y:154.0914}).wait(1).to({graphics:mask_graphics_15,x:-206.3627,y:170.804}).wait(1).to({graphics:mask_graphics_16,x:-169.3908,y:185.5335}).wait(1).to({graphics:mask_graphics_17,x:-137.4059,y:198.2762}).wait(1).to({graphics:mask_graphics_18,x:-110.1038,y:209.1533}).wait(1).to({graphics:mask_graphics_19,x:-87.0524,y:218.3369}).wait(1).to({graphics:mask_graphics_20,x:-67.7959,y:226.0086}).wait(1).to({graphics:mask_graphics_21,x:-51.9038,y:232.34}).wait(1).to({graphics:mask_graphics_22,x:-38.9899,y:237.4848}).wait(1).to({graphics:mask_graphics_23,x:-28.7164,y:241.5778}).wait(1).to({graphics:mask_graphics_24,x:-20.7911,y:244.7352}).wait(1).to({graphics:mask_graphics_25,x:-14.9629,y:247.0571}).wait(1).to({graphics:mask_graphics_26,x:-11.0156,y:248.6297}).wait(1).to({graphics:mask_graphics_27,x:-8.7632,y:249.5271}).wait(1).to({graphics:mask_graphics_28,x:-8.0444,y:249.8134}).wait(1).to({graphics:mask_graphics_29,x:125.9306,y:297.4411}).wait(1).to({graphics:mask_graphics_30,x:259.9056,y:323.1768}).wait(1).to({graphics:mask_graphics_31,x:260.5895,y:323.3141}).wait(1).to({graphics:mask_graphics_32,x:262.746,y:323.7415}).wait(1).to({graphics:mask_graphics_33,x:266.5525,y:324.4959}).wait(1).to({graphics:mask_graphics_34,x:272.2172,y:325.6186}).wait(1).to({graphics:mask_graphics_35,x:279.9856,y:327.1581}).wait(1).to({graphics:mask_graphics_36,x:290.1476,y:329.1721}).wait(1).to({graphics:mask_graphics_37,x:303.0443,y:331.728}).wait(1).to({graphics:mask_graphics_38,x:319.0741,y:334.9049}).wait(1).to({graphics:mask_graphics_39,x:338.693,y:338.7931}).wait(1).to({graphics:mask_graphics_40,x:362.4018,y:343.4918}).wait(1).to({graphics:mask_graphics_41,x:390.7052,y:349.1012}).wait(1).to({graphics:mask_graphics_42,x:424.0185,y:355.7034}).wait(1).to({graphics:mask_graphics_43,x:462.4946,y:363.3288}).wait(1).to({graphics:mask_graphics_44,x:505.7719,y:371.9057}).wait(1).to({graphics:mask_graphics_45,x:537.1287,y:381.2135}).wait(1).to({graphics:mask_graphics_46,x:561.5185,y:390.8809}).wait(1).to({graphics:mask_graphics_47,x:585.6936,y:400.4632}).wait(1).to({graphics:mask_graphics_48,x:608.6541,y:409.5641}).wait(1).to({graphics:mask_graphics_49,x:629.7383,y:417.9213}).wait(1).to({graphics:mask_graphics_50,x:648.648,y:425.4165}).wait(1).to({graphics:mask_graphics_51,x:665.352,y:432.0375}).wait(1).to({graphics:mask_graphics_52,x:679.9696,y:437.8315}).wait(1).to({graphics:mask_graphics_53,x:692.6859,y:442.8719}).wait(1).to({graphics:mask_graphics_54,x:703.7015,y:447.2382}).wait(1).to({graphics:mask_graphics_55,x:713.2087,y:451.0065}).wait(1).to({graphics:mask_graphics_56,x:721.381,y:454.2458}).wait(1).to({graphics:mask_graphics_57,x:728.371,y:457.0164}).wait(1).to({graphics:mask_graphics_58,x:734.3104,y:459.3707}).wait(1).to({graphics:mask_graphics_59,x:739.31,y:461.3518}).wait(1));

	// Layer_2
	this.instance = new lib.scribble3_1();
	this.instance.setTransform(162.75,342.35,1.805,1.805,0,0,0,230.2,116.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-252.7,0,831.0999999999999,600);


(lib.scribble2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,438,410,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble2_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(219.3,195.9,1,1,0,0,0,219.3,195.9);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2_1, new cjs.Rectangle(0,0,438.7,391.8), null);


(lib.scribble2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EgPuApiQlzimj7mWQj8mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakTCrMhUfA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_2 = new cjs.Graphics().p("EgP/ApiQlzimj7mWQj8mXAPmaQAUmYETiqMBUfg0SQETiqFzCmQF5CoD7GXQD8GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQijAAi7hUg");
	var mask_graphics_3 = new cjs.Graphics().p("EgQcApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_4 = new cjs.Graphics().p("EgRJApiQlzimj7mWQj8mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF5CoD7GXQD8GWgUGYQgOGakUCrMhUfA0RQiKBWilAAQiiAAi7hUg");
	var mask_graphics_5 = new cjs.Graphics().p("EgSHApiQlzimj7mWQj8mXAPmaQAUmYETiqMBUfg0SQETiqFzCmQF5CoD7GXQD8GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQijAAi7hUg");
	var mask_graphics_6 = new cjs.Graphics().p("EgTYApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_7 = new cjs.Graphics().p("EgVAApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_8 = new cjs.Graphics().p("EgXBApiQlyimj8mWQj8mXAPmaQAUmYETiqMBUfg0SQETiqFzCmQF5CoD7GXQD8GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQijAAi7hUg");
	var mask_graphics_9 = new cjs.Graphics().p("EgZaApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_10 = new cjs.Graphics().p("EgcLApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakTCrMhUfA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_11 = new cjs.Graphics().p("EgfOApiQlyimj8mWQj8mXAPmaQAUmYETiqMBUfg0SQETiqFzCmQF5CoD7GXQD8GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQijAAi7hUg");
	var mask_graphics_12 = new cjs.Graphics().p("EgiYApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFyCmQF5CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_13 = new cjs.Graphics().p("EglgApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_14 = new cjs.Graphics().p("EgocApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFyCmQF5CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_15 = new cjs.Graphics().p("Egq4ApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_16 = new cjs.Graphics().p("Egq4ApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_17 = new cjs.Graphics().p("Egq4ApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_18 = new cjs.Graphics().p("Egq4ApiQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_19 = new cjs.Graphics().p("Egq4ApkQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGbkUCqMhUeA0RQiLBWikAAQiiAAi7hTg");
	var mask_graphics_20 = new cjs.Graphics().p("Egq4AqUQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_21 = new cjs.Graphics().p("Egq4Aq9Qlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGbkUCqMhUeA0RQiLBWikAAQiiAAi7hTg");
	var mask_graphics_22 = new cjs.Graphics().p("Egq4ArdQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_23 = new cjs.Graphics().p("Egq4Ar3Qlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_24 = new cjs.Graphics().p("Egq4AsLQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_25 = new cjs.Graphics().p("Egq4AsaQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUiqFzClQF4CpD8GWQD7GXgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_26 = new cjs.Graphics().p("Egq4AskQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUiqFzClQF4CpD8GWQD7GXgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_27 = new cjs.Graphics().p("Egq4AsqQlzimj8mXQj7mWAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCqMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_28 = new cjs.Graphics().p("Egq4AsrQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCqMhUeA0SQiLBVikAAQiiAAi7hTg");
	var mask_graphics_29 = new cjs.Graphics().p("Egq4AsrQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCqMhUeA0SQiLBVikAAQiiAAi7hTg");
	var mask_graphics_30 = new cjs.Graphics().p("Egq4AsrQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCqMhUeA0SQiLBVikAAQiiAAi7hTg");
	var mask_graphics_31 = new cjs.Graphics().p("Egq4AssQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_32 = new cjs.Graphics().p("Egq4AsyQlzimj8mXQj7mWAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCqMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_33 = new cjs.Graphics().p("Egq4As7Qlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_34 = new cjs.Graphics().p("Egq4AtKQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hTg");
	var mask_graphics_35 = new cjs.Graphics().p("Egq4AtdQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_36 = new cjs.Graphics().p("Egq4At2Qlzilj8mXQj7mWAOmbQAUmYEUiqMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_37 = new cjs.Graphics().p("Egq4AuXQlzimj8mXQj7mWAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCqMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_38 = new cjs.Graphics().p("Egq4Au/Qlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_39 = new cjs.Graphics().p("Egq4AvwQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzClQF4CpD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_40 = new cjs.Graphics().p("Egq4AwsQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGbkUCqMhUeA0RQiLBWikAAQiiAAi7hTg");
	var mask_graphics_41 = new cjs.Graphics().p("Egq4AxyQlzilj8mXQj7mWAOmbQAUmYEUiqMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_42 = new cjs.Graphics().p("Egq4AzGQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGYQgOGakUCrMhUeA0RQiLBWikAAQiiAAi7hUg");
	var mask_graphics_43 = new cjs.Graphics().p("Egq4A0mQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGYQgOGakUCqMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_44 = new cjs.Graphics().p("Egq4A2TQlzimj8mXQj7mWAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGbkUCpMhUeA0TQiLBWikAAQiiAAi7hUg");
	var mask_graphics_45 = new cjs.Graphics().p("Egq4A4JQlzimj8mXQj7mWAOmbQAUmYEUiqMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGYQgOGZkUCrMhUeA0SQiLBWikAAQiiAAi7hTg");
	var mask_graphics_46 = new cjs.Graphics().p("Egq4A6DQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGakUCqMhUeA0TQiLBVikAAQiiAAi7hTg");
	var mask_graphics_47 = new cjs.Graphics().p("Egq4A78Qlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGYQgOGZkUCqMhUeA0TQiLBWikAAQiiAAi7hUg");
	var mask_graphics_48 = new cjs.Graphics().p("Egq4A9vQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGXQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_49 = new cjs.Graphics().p("Egq4A/ZQlzimj8mXQj7mWAOmbQAUmXEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GXgUGWQgOGbkUCqMhUeA0TQiLBVikAAQiiAAi7hTg");
	var mask_graphics_50 = new cjs.Graphics().p("Egq4BA3Qlzilj8mXQj7mWAOmbQAUmYEUiqMBUeg0RQEUirFzCmQF4CoD8GXQD7GWgUGXQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_51 = new cjs.Graphics().p("Egq4BCLQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGXQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_52 = new cjs.Graphics().p("Egq4BDUQlzilj8mXQj7mWAOmbQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GWgUGXQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_53 = new cjs.Graphics().p("Egq4BEUQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GVgUGYQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_54 = new cjs.Graphics().p("Egq4BFLQlzimj8mWQj7mXAOmaQAUmYEUiqMBUeg0SQEUiqFzCmQF4CoD8GXQD7GVgUGYQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_55 = new cjs.Graphics().p("Egq4BF7Qlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GWgUGYQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_56 = new cjs.Graphics().p("Egq4BGkQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GWgUGYQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_57 = new cjs.Graphics().p("Egq4BHHQlzimj8mWQj7mXAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GWgUGYQgOGakUCrMhUeA0SQiLBWikAAQiiAAi7hUg");
	var mask_graphics_58 = new cjs.Graphics().p("Egq4BHlQlzimj8mXQj7mWAOmaQAUmYEUirMBUeg0RQEUirFzCmQF4CpD8GWQD7GWgUGXQgOGbkUCqMhUeA0TQiLBWikAAQiiAAi7hUg");
	var mask_graphics_59 = new cjs.Graphics().p("EgrABH9Qlyimj8mXQj8mWAPmaQAUmYETirMBUfg0RQETirFzCmQF5CpD7GWQD8GWgUGYQgOGakUCrMhUeA0SQiLBWikAAQiiAAi8hUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:534.3871,y:-4.6767}).wait(1).to({graphics:mask_graphics_2,x:532.7329,y:-2.6093}).wait(1).to({graphics:mask_graphics_3,x:529.7747,y:1.0824}).wait(1).to({graphics:mask_graphics_4,x:525.3177,y:6.6446}).wait(1).to({graphics:mask_graphics_5,x:519.1343,y:14.3613}).wait(1).to({graphics:mask_graphics_6,x:510.9725,y:24.5469}).wait(1).to({graphics:mask_graphics_7,x:500.5768,y:37.5203}).wait(1).to({graphics:mask_graphics_8,x:487.7364,y:53.5447}).wait(1).to({graphics:mask_graphics_9,x:472.3756,y:72.7145}).wait(1).to({graphics:mask_graphics_10,x:454.6849,y:94.7918}).wait(1).to({graphics:mask_graphics_11,x:435.2368,y:119.0624}).wait(1).to({graphics:mask_graphics_12,x:414.9699,y:144.3547}).wait(1).to({graphics:mask_graphics_13,x:394.971,y:169.3126}).wait(1).to({graphics:mask_graphics_14,x:376.1682,y:192.7779}).wait(1).to({graphics:mask_graphics_15,x:357.7118,y:214.0231}).wait(1).to({graphics:mask_graphics_16,x:327.704,y:232.7474}).wait(1).to({graphics:mask_graphics_17,x:301.7439,y:248.946}).wait(1).to({graphics:mask_graphics_18,x:279.5845,y:262.7731}).wait(1).to({graphics:mask_graphics_19,x:260.8752,y:274.3276}).wait(1).to({graphics:mask_graphics_20,x:245.2459,y:279.2038}).wait(1).to({graphics:mask_graphics_21,x:232.3473,y:283.2281}).wait(1).to({graphics:mask_graphics_22,x:221.8659,y:286.4982}).wait(1).to({graphics:mask_graphics_23,x:213.5275,y:289.0997}).wait(1).to({graphics:mask_graphics_24,x:207.095,y:291.1066}).wait(1).to({graphics:mask_graphics_25,x:202.3646,y:292.5824}).wait(1).to({graphics:mask_graphics_26,x:199.1609,y:293.5819}).wait(1).to({graphics:mask_graphics_27,x:197.3327,y:294.1523}).wait(1).to({graphics:mask_graphics_28,x:197.0524,y:294.2387}).wait(1).to({graphics:mask_graphics_29,x:197.0523,y:294.2406}).wait(1).to({graphics:mask_graphics_30,x:197.0524,y:294.2387}).wait(1).to({graphics:mask_graphics_31,x:196.5036,y:294.412}).wait(1).to({graphics:mask_graphics_32,x:194.7733,y:294.9524}).wait(1).to({graphics:mask_graphics_33,x:191.7191,y:295.9063}).wait(1).to({graphics:mask_graphics_34,x:187.174,y:297.3259}).wait(1).to({graphics:mask_graphics_35,x:180.9409,y:299.2727}).wait(1).to({graphics:mask_graphics_36,x:172.7874,y:301.8192}).wait(1).to({graphics:mask_graphics_37,x:162.4397,y:305.0512}).wait(1).to({graphics:mask_graphics_38,x:149.5781,y:309.0682}).wait(1).to({graphics:mask_graphics_39,x:133.8367,y:313.9847}).wait(1).to({graphics:mask_graphics_40,x:114.8138,y:319.9262}).wait(1).to({graphics:mask_graphics_41,x:92.1043,y:327.019}).wait(1).to({graphics:mask_graphics_42,x:65.3752,y:335.3674}).wait(1).to({graphics:mask_graphics_43,x:34.5037,y:345.0095}).wait(1).to({graphics:mask_graphics_44,x:-0.2201,y:355.8548}).wait(1).to({graphics:mask_graphics_45,x:-37.9027,y:367.6243}).wait(1).to({graphics:mask_graphics_46,x:-77.0413,y:379.8484}).wait(1).to({graphics:mask_graphics_47,x:-115.8354,y:391.965}).wait(1).to({graphics:mask_graphics_48,x:-152.6805,y:403.4729}).wait(1).to({graphics:mask_graphics_49,x:-186.5146,y:414.0403}).wait(1).to({graphics:mask_graphics_50,x:-216.8592,y:423.5179}).wait(1).to({graphics:mask_graphics_51,x:-243.6643,y:431.8899}).wait(1).to({graphics:mask_graphics_52,x:-267.1214,y:439.2163}).wait(1).to({graphics:mask_graphics_53,x:-287.5274,y:445.5897}).wait(1).to({graphics:mask_graphics_54,x:-305.2043,y:451.1108}).wait(1).to({graphics:mask_graphics_55,x:-320.4606,y:455.8758}).wait(1).to({graphics:mask_graphics_56,x:-333.5749,y:459.9718}).wait(1).to({graphics:mask_graphics_57,x:-344.7917,y:463.4751}).wait(1).to({graphics:mask_graphics_58,x:-354.3228,y:466.452}).wait(1).to({graphics:mask_graphics_59,x:-361.3097,y:468.8637}).wait(1));

	// Layer_2
	this.instance = new lib.scribble2_1();
	this.instance.setTransform(192.65,319.6,1.2073,1.2073,4.6944,0,0,219.2,196.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-90.4,0,566.5,600);


(lib.scribble1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,136,75,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble1_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(68.2,37.5,1,1,0,0,0,68.2,37.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_2, new cjs.Rectangle(0,0,136.4,75.1), null);


(lib.scribble1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,175,78,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble1_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(87.7,39.1,1,1,0,0,0,87.7,39.1);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_1, new cjs.Rectangle(0,0,175.4,78.1), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_13 = new cjs.Graphics().p("AV2eDMhHngSMQjqg7hgk1Qhik6Bgl7QBhl8DrjhQDpjmDqA7MBHnASLQDqA7BiE6QBgE1hgF8QhhF8jpDmQi6Cyi5AAQgxAAgxgMg");
	var mask_graphics_14 = new cjs.Graphics().p("AawfzMhEBgRRQjeg4hYkzQhak4Bhl7QBgl8DjjkQDhjoDeA5MBEBARQQDeA4BaE4QBYEzhhF8QhgF9jhDnQi2C2iyAAQgtAAgsgLg");
	var mask_graphics_15 = new cjs.Graphics().p("EAc2AhSMhA+gQfQjUg2hRkxQhTk2Bhl9QBgl7DcjlQDajqDUA2MBA+AQfQDUA2BSE2QBSExhhF8QhhF9jaDpQixC6itAAQgpAAgogLg");
	var mask_graphics_16 = new cjs.Graphics().p("EAblAiiMg+cgP3QjMg0hLkvQhNk1Bhl8QBgl7DWjnQDUjrDMA0MA+cAP1QDLA0BNE1QBLEvhgF9QhhF8jUDrQiuC8ioAAQgmAAglgJg");
	var mask_graphics_17 = new cjs.Graphics().p("EAaiAjjMg8WgPVQjFgyhHkvQhIkzBhl8QBgl7DRjoQDQjtDEAyMA8XAPUQDFAyBIE0QBGEuhgF8QhhF9jPDsQisC/ikAAQgjAAgjgJg");
	var mask_graphics_18 = new cjs.Graphics().p("EAZtAkXMg6sgO6QjAgxhCktQhEkzBgl8QBhl7DNjpQDLjtDAAwMA6sAO5QC/AxBEEyQBDEuhhF8QhgF8jMDuQipDAihAAQghAAghgIg");
	var mask_graphics_19 = new cjs.Graphics().p("EAZDAk/Mg5ZgOlQi7gvhAktQhBkyBhl8QBhl8DJjoQDJjvC7AwMA5ZAOkQC8AvBAEyQBAEthgF8QhhF8jJDuQinDCieAAQggAAgggIg");
	var mask_graphics_20 = new cjs.Graphics().p("EAYkAleMg4agOVQi5gvg9ksQg/kxBhl9QBgl8DIjpQDGjvC4AvMA4bAOUQC4AvA/ExQA9EshgF8QhhF9jGDuQimDDicAAQgfAAgfgHg");
	var mask_graphics_21 = new cjs.Graphics().p("EAYOAlzMg3ugOJQi2gvg8krQg9kxBhl8QBgl8DGjqQDFjvC2AuMA3uAOJQC2AuA8ExQA8EshgF8QhhF8jFDvQilDEiaAAQgeAAgegIg");
	var mask_graphics_22 = new cjs.Graphics().p("EAX/AmCMg3QgOCQi0gug7ksQg8kwBgl8QBhl8DFjqQDDjvC1AtMA3QAOCQC0AtA8ExQA7ErhhF8QhgF9jEDvQilDEiZAAQgeAAgdgHg");
	var mask_graphics_23 = new cjs.Graphics().p("EAX2AmLMg2+gN+Qizgtg7ksQg7kwBhl8QBgl8DEjqQDDjwC0AuMA2+AN8QCzAuA7EwQA6ErhgF9QhhF8jDDvQikDFiYAAQgeAAgdgHg");
	var mask_graphics_24 = new cjs.Graphics().p("EAXxAmPMg20gN7Qizgtg6ksQg7kwBhl8QBgl8DEjqQDDjwCzAuMA20AN6QCzAtA7EwQA6EshhF8QhgF8jDDwQikDFiYAAQgeAAgdgIg");
	var mask_graphics_25 = new cjs.Graphics().p("EAXvAmRMg2xgN6Qiygug6krQg7kwBhl8QBgl8DEjqQDDjwCyAtMA2xAN6QCzAtA7EwQA6ErhhF9QhhF8jCDvQikDFiYAAQgeAAgdgHg");
	var mask_graphics_26 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCzAuMA2wAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_27 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_28 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_29 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_30 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_31 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_32 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_33 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_34 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_35 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_36 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_37 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_38 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_39 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_40 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_41 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_42 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_43 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_44 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCyAuMA2xAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_45 = new cjs.Graphics().p("EAXvAmcMg2wgN6Qizgtg6ksQg7kwBhl8QBhl8DDjqQDDjwCzAuMA2wAN5QCzAtA6EwQA6ErhgF9QhhF8jDDvQijDFiZAAQgdAAgdgHg");
	var mask_graphics_46 = new cjs.Graphics().p("EAasAolMg8qgPaQjGgyhIkvQhIkzBgl8QBhl9DRjmQDQjsDGAyMA8rAPZQDGAyBJE0QBHEvhhF8QhgF8jQDsQisC+ilAAQgjAAgkgJg");
	var mask_graphics_47 = new cjs.Graphics().p("EAdZAqjMhCEgQyQjYg3hTkyQhVk2Bgl8QBhl9DejjQDcjpDYA3MBCEAQwQDXA3BVE3QBUEyhhF8QhgF8jdDpQizC4ivAAQgpAAgqgKg");
	var mask_graphics_48 = new cjs.Graphics().p("EAgpAsUMhG9gSBQjng7hfk0Qhgk6Bgl8QBhl8DpjiQDojlDnA7MBG9ASAQDnA6BgE6QBfE1hgF8QhhF8joDmQi5Czi4AAQgvAAgwgMg");
	var mask_graphics_49 = new cjs.Graphics().p("EAmqAt5MhLUgTHQj1g/hpk3Qhrk8Bhl9QBgl8D0jfQDyjiD1A+MBLUATHQD2A+BqE9QBpE3hgF8QhhF8jyDkQi+Cui/AAQg2AAg2gOg");
	var mask_graphics_50 = new cjs.Graphics().p("EAr+AvTMhPKgUHQkChBhyk6Qh0k+Bhl8QBgl9D9jcQD6jhEDBCMBPKAUFQEDBCBzE+QByE6hhF8QhgF8j7DiQjDCqjGAAQg6AAg8gPg");
	var mask_graphics_51 = new cjs.Graphics().p("EAwlAwgMhSggU8QkNhFh6k7Qh7lBBgl8QBhl8EEjbQEDjeENBEMBSgAU8QENBEB7FBQB6E7hhF8QhgF9kDDfQjGCnjLAAQhAAAhAgRg");
	var mask_graphics_52 = new cjs.Graphics().p("EA0eAxiMhVVgVrQkWhHiAk9QiClCBhl8QBgl8ELjZQEJjdEWBHMBVVAVpQEXBHCCFCQB/E9hgF9QhhF8kIDeQjKCjjQAAQhDAAhFgRg");
	var mask_graphics_53 = new cjs.Graphics().p("EA3qAyXMhXpgWQQkehIiFk/QiHlDBgl8QBhl9EQjXQEOjcEeBJMBXpAWPQEeBJCHFDQCGE/hhF8QhgF8kPDdQjLChjUAAQhHAAhIgTg");
	var mask_graphics_54 = new cjs.Graphics().p("EA6JAzBMhZcgWtQkkhKiJlAQiMlEBhl9QBgl8EVjWQESjbEkBKMBZcAWtQEkBKCLFEQCJFAhgF8QhhF8kSDcQjNCfjWAAQhKAAhLgTg");
	var mask_graphics_55 = new cjs.Graphics().p("EA76AzfMhaugXCQkohMiMlAQiPlFBhl8QBgl8EYjWQEVjaEoBLMBauAXCQEoBLCPFFQCMFAhhF8QhgF9kVDaQjPCejYAAQhMAAhNgTg");
	var mask_graphics_56 = new cjs.Graphics().p("EA8+AzxMhbfgXPQkrhMiOlBQiQlFBgl8QBhl9EZjVQEXjZEqBMMBbgAXNQErBMCQFGQCOFBhhF8QhgF8kXDaQjQCejYAAQhOAAhOgUg");
	var mask_graphics_57 = new cjs.Graphics().p("EA9VAz1MhbwgXTQkrhMiPlBQiRlGBhl8QBhl8EZjWQEYjZErBMMBbwAXSQEsBMCQFGQCPFBhgF8QhhF8kYDbQjPCdjZAAQhOAAhPgUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(13).to({graphics:mask_graphics_13,x:-356.5763,y:193.5233}).wait(1).to({graphics:mask_graphics_14,x:-299.5315,y:204.6484}).wait(1).to({graphics:mask_graphics_15,x:-238.0547,y:214.0671}).wait(1).to({graphics:mask_graphics_16,x:-167.5138,y:221.9214}).wait(1).to({graphics:mask_graphics_17,x:-109.7598,y:228.3529}).wait(1).to({graphics:mask_graphics_18,x:-63.5141,y:233.5035}).wait(1).to({graphics:mask_graphics_19,x:-27.4978,y:237.5152}).wait(1).to({graphics:mask_graphics_20,x:-0.4323,y:240.5301}).wait(1).to({graphics:mask_graphics_21,x:18.961,y:242.6905}).wait(1).to({graphics:mask_graphics_22,x:31.9609,y:244.1387}).wait(1).to({graphics:mask_graphics_23,x:39.8462,y:245.0172}).wait(1).to({graphics:mask_graphics_24,x:43.8953,y:245.4683}).wait(1).to({graphics:mask_graphics_25,x:45.3871,y:245.6345}).wait(1).to({graphics:mask_graphics_26,x:52.3676,y:246.7391}).wait(1).to({graphics:mask_graphics_27,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_28,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_29,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_30,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_31,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_32,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_33,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_34,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_35,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_36,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_37,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_38,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_39,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_40,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_41,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_42,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_43,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_44,x:52.3676,y:246.7397}).wait(1).to({graphics:mask_graphics_45,x:52.3676,y:246.7391}).wait(1).to({graphics:mask_graphics_46,x:142.1204,y:260.6368}).wait(1).to({graphics:mask_graphics_47,x:224.0683,y:273.3321}).wait(1).to({graphics:mask_graphics_48,x:293.0484,y:284.8236}).wait(1).to({graphics:mask_graphics_49,x:334.806,y:295.1098}).wait(1).to({graphics:mask_graphics_50,x:371.6606,y:304.1891}).wait(1).to({graphics:mask_graphics_51,x:403.6076,y:312.0604}).wait(1).to({graphics:mask_graphics_52,x:430.6439,y:318.7224}).wait(1).to({graphics:mask_graphics_53,x:452.767,y:324.1744}).wait(1).to({graphics:mask_graphics_54,x:469.9755,y:328.4156}).wait(1).to({graphics:mask_graphics_55,x:482.268,y:331.4454}).wait(1).to({graphics:mask_graphics_56,x:489.6438,y:333.2634}).wait(1).to({graphics:mask_graphics_57,x:492.1527,y:333.6595}).wait(1).to({graphics:null,x:0,y:0}).wait(2));

	// Layer_3
	this.instance = new lib.scribble1_2();
	this.instance.setTransform(61.35,359.1,2.7075,2.7075,0,0,0,68.2,37.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({_off:true},45).wait(2));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("A82XvQkYjkhJmBQhJmCCxk+QC1k7FGg9MBjzgS5QFFg+EZDkQEcDnBJGCQBJGBi1E6QixE/lGA+MhjzAS5QhEAMhDAAQj6AAjhi2g");
	var mask_1_graphics_2 = new cjs.Graphics().p("A89XyQkYjkhImCQhJmBCwk/QC1k6FFg9MBjmgS3QFFg9EXDkQEdDnBJGBQBJGCi1E6QixE+lFA+MhjlAS2QhFANhCAAQj6AAjhi2g");
	var mask_1_graphics_3 = new cjs.Graphics().p("A9RX6QkWjlhJmBQhJmBCvk/QCzk5FDg+MBi/gSvQFDg9EWDkQEbDoBJGBQBJGCi0E6QivE+lDA9Mhi+ASvQhDANhCAAQj5AAjgi3g");
	var mask_1_graphics_4 = new cjs.Graphics().p("A9yYHQkUjlhJmBQhJmCCtk9QCxk6E/g8MBh8gSjQFAg8EUDkQEYDoBJGCQBJGBixE6QisE9lAA9Mhh8ASiQhCANhBAAQj3AAjei4g");
	var mask_1_graphics_5 = new cjs.Graphics().p("A+hYZQkRjlhJmBQhJmCCqk9QCtk4E7g8MBgggSRQE7g8ERDmQEVDoBJGCQBJGBiuE5QipE9k7A8MhggASRQhAAMg/AAQj0AAjdi6g");
	var mask_1_graphics_6 = new cjs.Graphics().p("A/dYxQkMjlhJmCQhJmBClk9QCpk4E1g6MBepgR7QE1g6EMDmQERDpBJGCQBJGBipE4QimE9k0A6MhepAR7Qg+ALg9AAQjxAAjai7g");
	var mask_1_graphics_7 = new cjs.Graphics().p("EggmAZPQkIjnhJmCQhJmBCgk7QCkk3Eug5MBcYgRfQEtg5EHDmQEMDrBJGBQBJGCikE3QigE7kuA5MhcYARfQg7ALg5AAQjtAAjXi8g");
	var mask_1_graphics_8 = new cjs.Graphics().p("Egh9AZxQkBjohJmBQhJmCCZk6QCek2Elg3MBZsgQ/QElg3EBDoQEFDsBJGBQBJGBieE2QiZE7klA3MhZsAQ/Qg4AKg3AAQjoAAjTi/g");
	var mask_1_graphics_9 = new cjs.Graphics().p("EgjhAaZQj7jphJmCQhImBCSk5QCXk1Eag2MBWngQYQEag1D6DpQD+DtBJGCQBJGAiWE1QiTE5kbA2MhWmAQZQg0AKgzAAQjiAAjPjCg");
	var mask_1_graphics_10 = new cjs.Graphics().p("EglTAbHQjyjrhJmCQhJmBCLk4QCOkzEPg0MBTGgPtQEPg0DyDrQD2DvBJGBQBJGBiPEzQiKE4kPAzMhTGAPvQgwAJgvAAQjcAAjKjEg");
	var mask_1_graphics_11 = new cjs.Graphics().p("EgnSAb5QjpjthJmBQhJmBCBk2QCGkyECgxMBPLgO+QEDgxDpDtQDsDwBJGBQBJGBiFEyQiCE1kCAxMhPLAPAQgsAIgrAAQjTAAjFjIg");
	var mask_1_graphics_12 = new cjs.Graphics().p("EgpfAcxQjfjvhJmBQhJmBB4k0QB7kwD0gvMBK2gOJQD0gvDgDvQDiDyBJGBQBJGBh7EwQh4E0j0AuMhK2AOLQgnAHgnAAQjKAAi/jLg");
	var mask_1_graphics_13 = new cjs.Graphics().p("EgnOAduQjUjwhJmCQhJmBBskyQBwkuDlgrMBGGgNRQDlgrDUDxQDYD0BJGAQBJGChwEuQhtEyjlArMhGGANRQgiAHgjAAQjAAAi3jQg");
	var mask_1_graphics_14 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_15 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_16 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_17 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EgkMAeyQjJjzhJmBQhJmCBhkvQBkksDUgoMBA9gMSQDTgoDJDzQDLD3BJGAQBJGBhkEsQhhEwjUAoMhA8AMTQgeAFgdAAQi1AAivjUg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EgkPAe2QjIjzhJmBQhJmCBhkvQBkksDUgoMBBBgMTQDUgoDIDzQDMD2BJGBQBJGBhkEsQhhEvjVApMhBAAMTQgeAGgdAAQi2AAivjUg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgkWAfAQjJjyhJmCQhJmBBhkwQBlksDVgoMBBNgMVQDVgoDJDzQDMD2BJGAQBJGChlEsQhiEvjUApMhBNAMWQgeAFgeAAQi2AAivjUg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EgkjAfSQjJjyhJmCQhJmBBikwQBmksDVgoMBBigMZQDWgpDKDzQDND2BJGBQBJGBhmEsQhiEwjWAoMhBiAMaQgeAGgeAAQi3AAiwjUg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Egk0AfrQjLjyhImCQhJmBBjkwQBmksDYgpMBB/gMeQDXgpDLDyQDOD2BJGBQBJGBhnEtQhjEwjXAoMhB/AMgQgfAFgeAAQi4AAixjTg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EglKAgLQjMjyhJmBQhJmCBlkwQBoksDZgpMBClgMmQDZgpDMDyQDQD1BJGCQBIGBhnEtQhlEwjZApMhClAMmQgfAGgfAAQi5AAiyjTg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgllAgzQjOjyhJmCQhJmBBnkxQBpksDcgqMBDTgMuQDbgpDODyQDRD0BJGCQBJGBhpEtQhnEwjbAqMhDTAMvQggAGggAAQi6AAizjSg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgmFAhhQjQjyhJmBQhJmCBpkwQBrkuDfgqMBEJgM3QDegqDQDxQDTD0BJGCQBJGBhrEtQhpExjeAqMhEKAM5QggAGggAAQi9AAi0jRg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgmqAiWQjSjxhJmBQhJmCBrkxQBuktDhgrMBFIgNDQDigrDSDxQDVD0BJGBQBJGChuEtQhqEyjiAqMhFIANFQghAGgiAAQi+AAi2jRg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgnUAjTQjUjxhJmBQhJmCBtkxQBwkuDmgsMBGPgNQQDlgrDVDwQDYD0BJGBQBJGChxEuQhtExjlAsMhGQANRQgiAGgiAAQjBAAi4jPg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgoCAkXQjYjxhJmBQhJmBBwkzQB0kuDpgsMBHfgNfQDpgsDYDwQDaDzBJGBQBJGChzEuQhwEyjpAsMhHfANgQgkAHgjAAQjEAAi5jOg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Ego2AlhQjbjvhJmCQhImBBzkzQB2kvDugtMBI3gNvQDugtDaDvQDeDzBJGBQBJGCh3EvQhzEzjtAtMhI3ANwQglAHglAAQjHAAi7jOg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EgvgAmzQjejvhJmBQhJmBB3k0QB6kwDzgtMBKXgOBQDyguDeDuQDiDzBJGBQBJGCh6EvQh3E0jyAuMhKYAOBQgmAHgmAAQjKAAi+jMg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Eg0eAnuQjhjuhJmCQhJmBB6k0QB+kxD4gvMBMAgOTQD4gvDhDtQDmDyBJGBQBJGCh+EwQh7E0j4AvMhL/AOVQgpAIgnAAQjOAAjAjLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:578.3308,y:170.147}).wait(1).to({graphics:mask_1_graphics_2,x:576.0681,y:170.4301}).wait(1).to({graphics:mask_1_graphics_3,x:569.2828,y:171.2798}).wait(1).to({graphics:mask_1_graphics_4,x:557.9742,y:172.6959}).wait(1).to({graphics:mask_1_graphics_5,x:542.1424,y:174.6787}).wait(1).to({graphics:mask_1_graphics_6,x:521.7878,y:177.2284}).wait(1).to({graphics:mask_1_graphics_7,x:496.911,y:180.3452}).wait(1).to({graphics:mask_1_graphics_8,x:467.5126,y:184.0294}).wait(1).to({graphics:mask_1_graphics_9,x:433.5934,y:188.2814}).wait(1).to({graphics:mask_1_graphics_10,x:395.1547,y:193.1017}).wait(1).to({graphics:mask_1_graphics_11,x:352.1981,y:198.4907}).wait(1).to({graphics:mask_1_graphics_12,x:304.7257,y:204.449}).wait(1).to({graphics:mask_1_graphics_13,x:222.9094,y:210.9773}).wait(1).to({graphics:mask_1_graphics_14,x:133.2412,y:218.2352}).wait(1).to({graphics:mask_1_graphics_15,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_16,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_17,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_18,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_19,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_20,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_21,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_22,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_23,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_24,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_25,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_26,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_27,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_28,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_29,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_30,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_31,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_32,x:133.2412,y:218.2354}).wait(1).to({graphics:mask_1_graphics_33,x:133.2412,y:218.2352}).wait(1).to({graphics:mask_1_graphics_34,x:129.7238,y:218.5862}).wait(1).to({graphics:mask_1_graphics_35,x:119.1715,y:219.6386}).wait(1).to({graphics:mask_1_graphics_36,x:101.5843,y:221.3926}).wait(1).to({graphics:mask_1_graphics_37,x:76.9622,y:223.8482}).wait(1).to({graphics:mask_1_graphics_38,x:45.3053,y:227.0054}).wait(1).to({graphics:mask_1_graphics_39,x:6.6135,y:230.8641}).wait(1).to({graphics:mask_1_graphics_40,x:-39.1132,y:235.4243}).wait(1).to({graphics:mask_1_graphics_41,x:-91.8748,y:240.6859}).wait(1).to({graphics:mask_1_graphics_42,x:-151.6712,y:246.649}).wait(1).to({graphics:mask_1_graphics_43,x:-218.5026,y:253.3134}).wait(1).to({graphics:mask_1_graphics_44,x:-292.3689,y:260.679}).wait(1).to({graphics:mask_1_graphics_45,x:-336.3518,y:268.7459}).wait(1).to({graphics:mask_1_graphics_46,x:-368.471,y:274.4518}).wait(1).to({graphics:null,x:0,y:0}).wait(13));

	// Layer_2
	this.instance_1 = new lib.scribble1_1();
	this.instance_1.setTransform(114.15,313.4,2.7075,2.7075,0,0,0,87.7,39.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},46).wait(13));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-123.3,0,474.90000000000003,600);


(lib.Page_indicator_dot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {selected:1,deselected:17};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(19));

	// Layer_2
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(0,0,0.75,0.75);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.25,alpha:1},16,cjs.Ease.cubicInOut).to({scaleX:0.75,scaleY:0.75,alpha:0},18,cjs.Ease.cubicInOut).wait(1));

	// Layer_1
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(0,0,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.25,scaleY:1.25,alpha:0},16,cjs.Ease.cubicInOut).to({scaleX:0.75,scaleY:0.75,alpha:1},18,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.5,-4.5,9.2,9.2);


(lib.Page_indicator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AAUA7Ig1g2QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBQAAgCACgCIA1g2QABgCAEAAQAAAAABAAQABAAAAABQABAAAAAAQABABAAAAIAEAEQAEAFgEAEIguAtIAvAuQAEAEgEAFIgFAEQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQgEAAgBgCg");
	this.shape.setTransform(-3.7375,4.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D4").s().p("AAUA7Ig1g2QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBQAAgCACgCIA1g2QABgCAEAAQAAAAABAAQABAAAAABQABAAAAAAQABABAAAAIAEAEQAEAFgEAEIguAtIAvAuQAEAEgEAFIgFAEQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQgEAAgBgCg");
	this.shape_1.setTransform(88.6375,4.825,1,1,0,0,180);

	this.dot_5 = new lib.Page_indicator_dot();
	this.dot_5.name = "dot_5";
	this.dot_5.setTransform(73.2,4.8);

	this.dot_4 = new lib.Page_indicator_dot();
	this.dot_4.name = "dot_4";
	this.dot_4.setTransform(57.9,4.8);

	this.dot_3 = new lib.Page_indicator_dot();
	this.dot_3.name = "dot_3";
	this.dot_3.setTransform(42.6,4.8);

	this.dot_2 = new lib.Page_indicator_dot();
	this.dot_2.name = "dot_2";
	this.dot_2.setTransform(27.3,4.8);

	this.dot_1 = new lib.Page_indicator_dot();
	this.dot_1.name = "dot_1";
	this.dot_1.setTransform(12,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.dot_1},{t:this.dot_2},{t:this.dot_3},{t:this.dot_4},{t:this.dot_5},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_indicator, new cjs.Rectangle(-7.3,-1.2,99.6,12.1), null);


(lib.ms_logo_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.ms = new lib.ms_1();
	this.ms.name = "ms";
	this.ms.setTransform(64.25,10.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(16.425,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(5.125,16.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(16.425,5.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(5.125,5.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_logo_2, new cjs.Rectangle(0,0,132.2,21.6), null);


(lib.ms_logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(64.45,10.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(16.425,16.425);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(5.125,16.425);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(16.425,5.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(5.125,5.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_logo, new cjs.Rectangle(0,0,132.4,21.6), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-150,-20,300,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms_logo();
	this.ms.name = "ms";
	this.ms.setTransform(15.4,1.45,1,1,0,0,0,66.2,10.8);

	this.timeline.addTween(cjs.Tween.get(this.ms).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.img5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub1 = new lib.img5Sub2();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-55.95,379.3,1.4604,1.4604,0,0,0,22.4,-22);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	// Layer_2
	this.sub2Shadow = new lib.angledShadow_1();
	this.sub2Shadow.name = "sub2Shadow";
	this.sub2Shadow.setTransform(40.9,338.55,0.745,0.745,0,0,0,146.8,48.6);

	this.timeline.addTween(cjs.Tween.get(this.sub2Shadow).wait(1));

	// sub1
	this.sub2 = new lib.img5Sub1();
	this.sub2.name = "sub2";
	this.sub2.setTransform(-56.8,369.7,1.49,1.49,-2.9998,0,0,29.4,-5.9);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub2
	this.sub3 = new lib.img5Sub3();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-14.25,270.6,1.49,1.49,-2.9998,0,0,43.3,-15.4);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5, new cjs.Rectangle(-110.6,72.3,286.79999999999995,339.2), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img4Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-44.5,204,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img4Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(50,275,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img4Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-87,283.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4, new cjs.Rectangle(-114,161,287.4,199.7), null);


(lib.img3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img3Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-44.5,204,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img3Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(50,275,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img3Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-87,283.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3, new cjs.Rectangle(-114,161,287.4,199.7), null);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img2Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-44.5,204,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img2Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(50,275,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img2Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-87,283.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2, new cjs.Rectangle(-114,161.3,287.4,199.39999999999998), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img1Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-44.5,204,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img1Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(52,276,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img1Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-87,283.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(-114,161.2,289.4,200.7), null);


(lib.gridSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,-1,260,2,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.gridSubSub();
	this.sub.name = "sub";
	this.sub.setTransform(128,0,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridSub, new cjs.Rectangle(-0.5,-0.5,257,1), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridSub();
	this.instance.setTransform(128,120,1,1,0,0,0,128,0);

	this.instance_1 = new lib.gridSub();
	this.instance_1.setTransform(128,105,1,1,0,0,0,128,0);

	this.instance_2 = new lib.gridSub();
	this.instance_2.setTransform(128,90,1,1,0,0,0,128,0);

	this.instance_3 = new lib.gridSub();
	this.instance_3.setTransform(128,75,1,1,0,0,0,128,0);

	this.instance_4 = new lib.gridSub();
	this.instance_4.setTransform(128,60,1,1,0,0,0,128,0);

	this.instance_5 = new lib.gridSub();
	this.instance_5.setTransform(128,45,1,1,0,0,0,128,0);

	this.instance_6 = new lib.gridSub();
	this.instance_6.setTransform(128,30,1,1,0,0,0,128,0);

	this.instance_7 = new lib.gridSub();
	this.instance_7.setTransform(128,15,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_8 = new lib.gridSub();
	this.instance_8.setTransform(128,0,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,257,121), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(60.5,118.9,1,1,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(195,118.9,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(125.9,185.5,1,1,0,0,0,125.9,52.5);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(125.9,50.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-7.5,-7.5,264,261), null);


(lib.MSFT_Logo_anim_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.ms_1 = new lib.ms_logo_2();
	this.ms_1.name = "ms_1";
	this.ms_1.setTransform(15.3,1.45,1,1,0,0,0,66.1,10.8);

	this.timeline.addTween(cjs.Tween.get(this.ms_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_1, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		exportRoot.mainMC.logo.visible=false;
	}
	this.frame_65 = function() {
		exportRoot.animStart();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSVBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgSoBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgThBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVBBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXGBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZyBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdDBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggVBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjABK7IAAwoMBbtAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglGBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmlBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgneBK7IAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("EgnxBK7IAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.6789,y:479.5095}).wait(1).to({graphics:mask_graphics_15,x:467.773,y:479.5095}).wait(1).to({graphics:mask_graphics_16,x:462.0553,y:479.5095}).wait(1).to({graphics:mask_graphics_17,x:452.5258,y:479.5095}).wait(1).to({graphics:mask_graphics_18,x:439.1845,y:479.5095}).wait(1).to({graphics:mask_graphics_19,x:422.0313,y:479.5095}).wait(1).to({graphics:mask_graphics_20,x:401.0664,y:479.5095}).wait(1).to({graphics:mask_graphics_21,x:380.1015,y:479.5095}).wait(1).to({graphics:mask_graphics_22,x:362.9483,y:479.5095}).wait(1).to({graphics:mask_graphics_23,x:349.607,y:479.5095}).wait(1).to({graphics:mask_graphics_24,x:340.0775,y:479.5095}).wait(1).to({graphics:mask_graphics_25,x:334.3598,y:479.5095}).wait(1).to({graphics:mask_graphics_26,x:332.4539,y:479.5095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// logo text
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-131.7,900.05,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	this.instance_1 = new lib.MSFT_Logo_anim_1();
	this.instance_1.setTransform(39.6,58.5,2.4059,2.4059,0,0,0,0.1,0.5);

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},14).to({state:[{t:this.instance}]},12).to({state:[{t:this.instance}]},39).to({state:[{t:this.instance_1}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.7},12,cjs.Ease.quadInOut).wait(39).to({_off:true,regY:0.5,scaleX:2.4059,scaleY:2.4059,x:39.6,y:58.5},33,cjs.Ease.cubicInOut).wait(2));

	// widows icon
	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(299.1,905.95,0.2981,0.2981,0,0,0,-39.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:299.05},14,cjs.Ease.quadOut).to({x:24.8},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(301.4796,905.1707,1,2.3542);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(301.45,344.45);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,978.8,1949.6);


(lib.doodle5_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,18,14,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(9,7,1,1,0,0,0,9,7);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_3, new cjs.Rectangle(0,0,18.1,14), null);


(lib.doodle5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,17,16,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(8.3,7.6,1,1,0,0,0,8.3,7.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_2, new cjs.Rectangle(0,0,16.8,15.3), null);


(lib.doodle5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,28,28,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(13.6,14,1,1,0,0,0,13.6,14);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_1, new cjs.Rectangle(0,0,27.1,28), null);


(lib.doodle5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("EALhAmTQgPgEgOgNQgOgNgFgPQgFgOAHgIICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_21 = new cjs.Graphics().p("EALbAmZQgPgEgOgNQgOgOgFgOQgFgPAHgHICJiSQAHgIAPAEQAPAEAOANQAOANAFAPQAFAPgHAHIiJCSQgEAFgIAAIgKgBg");
	var mask_graphics_22 = new cjs.Graphics().p("EALMAmoQgPgEgOgNQgOgNgFgPQgFgOAHgIICIiSQAHgHAPAEQAPAEAOANQAOANAFAPQAFAOgHAIIiICSQgFAFgIAAIgJgCg");
	var mask_graphics_23 = new cjs.Graphics().p("EAK3Am9QgPgEgOgNQgOgNgFgOQgFgPAHgHICIiTQAHgHAPAEQAPAEAOANQAOANAFAPQAFAOgHAIIiICSQgFAFgIAAIgJgCg");
	var mask_graphics_24 = new cjs.Graphics().p("EAKiAnTQgPgEgOgNQgOgOgFgOQgFgPAHgHICIiSQAHgIAPAEQAPAEAOANQAOANAFAPQAFAPgHAHIiICSQgFAFgIAAIgJgBg");
	var mask_graphics_25 = new cjs.Graphics().p("EAKTAniQgPgEgPgNQgOgNgEgPQgGgOAHgIICJiSQAHgHAPAEQAPAEAOANQAOANAFAPQAFAOgHAIIiJCSQgEAFgIAAIgJgCg");
	var mask_graphics_26 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_27 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_28 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_29 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_30 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_31 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_32 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_33 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_34 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_35 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_36 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_37 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_38 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_39 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_40 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_41 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_42 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_43 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_44 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_45 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_46 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_47 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_48 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_49 = new cjs.Graphics().p("EAKNAnoQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_50 = new cjs.Graphics().p("EAKMAnpQgPgEgOgNQgOgNgFgPQgFgPAHgHICIiSQAHgIAPAEQAPAEAOANQAOAOAFAOQAFAPgHAHIiICSQgFAFgIAAIgJgBg");
	var mask_graphics_51 = new cjs.Graphics().p("EAKJAnsQgPgEgOgNQgOgNgFgPQgFgOAHgIICIiSQAHgHAPAEQAPAEAOANQAOANAFAOQAFAPgHAIIiJCSQgEAFgIAAIgJgCg");
	var mask_graphics_52 = new cjs.Graphics().p("EAKCAnzQgPgEgOgNQgOgNgFgPQgFgOAHgIICIiSQAHgHAPAEQAPAEAOANQAOANAFAOQAFAPgHAHIiICTQgFAFgIAAIgJgCg");
	var mask_graphics_53 = new cjs.Graphics().p("EAJ1An/QgPgEgOgNQgOgNgFgOQgFgPAHgHICJiTQAHgHAPAEQAPAEAOANQAOANAFAPQAFAOgHAIIiJCSQgEAFgIAAIgKgCg");
	var mask_graphics_54 = new cjs.Graphics().p("EAJkAoRQgPgEgOgNQgOgNgFgPQgFgOAHgIICIiSQAHgHAPAEQAPAEAOANQAOANAFAOQAFAPgHAHIiJCTQgEAFgIAAIgJgCg");
	var mask_graphics_55 = new cjs.Graphics().p("EAJTAoiQgPgEgOgNQgOgNgFgPQgGgOAHgIICJiSQAHgHAPAEQAPAEAOANQAOANAFAPQAFAOgHAIIiJCSQgEAFgIAAIgJgCg");
	var mask_graphics_56 = new cjs.Graphics().p("EAJHAouQgPgEgPgNQgOgNgEgOQgGgPAHgIICJiSQAHgHAPAEQAPAEAOANQAOANAFAPQAFAOgHAIIiJCSQgEAFgIAAIgJgCg");
	var mask_graphics_57 = new cjs.Graphics().p("EAI/Ao2QgPgEgOgNQgOgNgFgPQgFgOAHgIICIiSQAHgIAPAEQAPAEAOAOQAOANAFAOQAFAPgHAHIiICTQgFAEgIAAIgJgBg");
	var mask_graphics_58 = new cjs.Graphics().p("EAI6Ao7QgPgEgOgNQgOgOgFgOQgFgPAHgHICJiSQAHgIAPAEQAOAEAOANQAPANAFAPQAFAPgHAHIiJCSQgFAFgHAAIgKgBg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:89.9423,y:245.2377}).wait(1).to({graphics:mask_graphics_21,x:89.3796,y:245.807}).wait(1).to({graphics:mask_graphics_22,x:87.8423,y:247.3626}).wait(1).to({graphics:mask_graphics_23,x:85.7423,y:249.4876}).wait(1).to({graphics:mask_graphics_24,x:83.6423,y:251.6126}).wait(1).to({graphics:mask_graphics_25,x:82.105,y:253.1683}).wait(1).to({graphics:mask_graphics_26,x:81.5423,y:253.7377}).wait(1).to({graphics:mask_graphics_27,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_28,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_29,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_30,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_31,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_32,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_33,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_34,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_35,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_36,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_37,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_38,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_39,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_40,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_41,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_42,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_43,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_44,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_45,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_46,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_47,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_48,x:81.5423,y:253.7376}).wait(1).to({graphics:mask_graphics_49,x:81.5423,y:253.7377}).wait(1).to({graphics:mask_graphics_50,x:81.4505,y:253.8295}).wait(1).to({graphics:mask_graphics_51,x:81.1196,y:254.1603}).wait(1).to({graphics:mask_graphics_52,x:80.4254,y:254.8546}).wait(1).to({graphics:mask_graphics_53,x:79.1915,y:256.0885}).wait(1).to({graphics:mask_graphics_54,x:77.4233,y:257.8567}).wait(1).to({graphics:mask_graphics_55,x:75.7129,y:259.5671}).wait(1).to({graphics:mask_graphics_56,x:74.503,y:260.7769}).wait(1).to({graphics:mask_graphics_57,x:73.7335,y:261.5464}).wait(1).to({graphics:mask_graphics_58,x:73.2673,y:262.0127}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance = new lib.doodle5_2();
	this.instance.setTransform(153.7,497.35,1,1,0,0,0,8.3,7.6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("EALNAo7QgGgHAAgJQAAgJAGgHQAHgGAJAAQAJAAAGAGQAHAHAAAJQAAAJgHAHQgGAGgJAAQgJAAgHgGg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EALFAo8QgIgIAAgMQAAgMAIgJQAIgIAMAAQAMAAAJAIQAIAJAAAMQAAAMgIAIQgJAIgMAAQgMAAgIgIg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAKtApAQgPgOAAgUQAAgVAPgOQAOgOAUAAQAUAAAPAOQAOAOAAAVQAAAUgOAOQgPAOgUAAQgUAAgOgOg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAKDApHQgYgYAAgjQAAgiAYgZQAYgYAjAAQAiAAAZAYQAYAZAAAiQAAAjgYAYQgZAZgiAAQgjAAgYgZg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAJeApNQghghAAgvQAAgvAhghQAhghAvAAQAwAAAhAhQAiAhAAAvQAAAvgiAhQghAigwAAQgvAAghgig");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAJJApRQgngmAAg3QAAg2AngmQAmgnA3AAQA2AAAnAnQAmAmAAA2QAAA3gmAmQgnAng2AAQg3AAgmgng");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAI/ApTQgpgpAAg6QAAg5ApgpQApgpA5AAQA7AAApApQApApAAA5QAAA6gpApQgpApg7AAQg5AAgpgpg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAI8ApTQgpgpAAg7QAAg7ApgpQApgqA7AAQA7AAAqAqQApApAAA7QAAA7gpApQgqAqg7AAQg7AAgpgqg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAI9ApTQgpgpAAg7QAAg6ApgpQApgpA7AAQA6AAAqApQApApAAA6QAAA7gpApQgqApg6AAQg7AAgpgpg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAJBApSQgpgoAAg5QAAg5ApgpQAogoA5AAQA6AAAoAoQApApAAA5QAAA5gpAoQgoApg6AAQg5AAgogpg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAJIApRQgngmAAg3QAAg3AngmQAngnA2AAQA3AAAnAnQAnAmAAA3QAAA3gnAmQgnAng3AAQg2AAgngng");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAJUApPQgjgkAAgyQAAgyAjgkQAkgjAyAAQAzAAAkAjQAjAkAAAyQAAAygjAkQgkAjgzAAQgyAAgkgjg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAJoApMQgfgfAAgsQAAgsAfgfQAfgeArAAQAsAAAfAeQAfAfAAAsQAAAsgfAfQgfAfgsAAQgrAAgfgfg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAKBApHQgYgYAAgjQAAgjAYgZQAZgZAjAAQAjAAAZAZQAZAZAAAjQAAAjgZAYQgZAZgjAAQgjAAgZgZg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAKbApDQgTgTAAgaQAAgaATgTQASgSAbAAQAaAAATASQASATAAAaQAAAagSATQgTATgaAAQgbAAgSgTg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAKvApAQgOgOAAgTQAAgUAOgOQAOgNATAAQAUAAANANQAOAOAAAUQAAATgOAOQgNANgUAAQgTAAgOgNg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAK9Ao9QgKgKAAgPQAAgOAKgLQAKgKAPAAQAPAAAKAKQAKALAAAOQAAAPgKAKQgKALgPAAQgPAAgKgLg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EALHAo8QgIgIAAgMQAAgLAIgIQAIgIALAAQALAAAIAIQAIAIAAALQAAAMgIAIQgIAIgLAAQgLAAgIgIg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EALNAo7QgGgHAAgJQAAgJAGgHQAHgGAJAAQAJAAAGAGQAHAHAAAJQAAAJgHAHQgGAGgJAAQgJAAgHgGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:75.4749,y:262.4967}).wait(1).to({graphics:mask_1_graphics_23,x:75.8091,y:262.83}).wait(1).to({graphics:mask_1_graphics_24,x:76.8198,y:263.8377}).wait(1).to({graphics:mask_1_graphics_25,x:78.5444,y:265.5573}).wait(1).to({graphics:mask_1_graphics_26,x:80.0706,y:267.079}).wait(1).to({graphics:mask_1_graphics_27,x:80.9472,y:267.9531}).wait(1).to({graphics:mask_1_graphics_28,x:81.3572,y:268.3619}).wait(1).to({graphics:mask_1_graphics_29,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_30,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_31,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_32,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_33,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_34,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_35,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_36,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_37,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_38,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_39,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_40,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_41,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_42,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_43,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_44,x:81.4481,y:268.4524}).wait(1).to({graphics:mask_1_graphics_45,x:81.4047,y:268.4092}).wait(1).to({graphics:mask_1_graphics_46,x:81.2544,y:268.2593}).wait(1).to({graphics:mask_1_graphics_47,x:80.9546,y:267.9604}).wait(1).to({graphics:mask_1_graphics_48,x:80.4423,y:267.4496}).wait(1).to({graphics:mask_1_graphics_49,x:79.6469,y:266.6565}).wait(1).to({graphics:mask_1_graphics_50,x:78.5961,y:265.6088}).wait(1).to({graphics:mask_1_graphics_51,x:77.543,y:264.5587}).wait(1).to({graphics:mask_1_graphics_52,x:76.7154,y:263.7336}).wait(1).to({graphics:mask_1_graphics_53,x:76.131,y:263.1509}).wait(1).to({graphics:mask_1_graphics_54,x:75.7333,y:262.7543}).wait(1).to({graphics:mask_1_graphics_55,x:75.4749,y:262.4967}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_1 = new lib.doodle5_3();
	this.instance_1.setTransform(151.1,518.25,1,1,0,0,0,9,7);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_16 = new cjs.Graphics().p("EALzAm5QgYgHgWgVQgXgVgHgXQgJgXAMgMIDZjpQAMgMAXAGQAYAHAWAVQAXAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgHAAgIgCg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EALxAm7QgYgGgXgVQgWgVgIgXQgIgXALgMIDajpQALgMAYAGQAYAHAWAUQAWAVAJAYQAHAXgLAMIjaDpQgHAIgMAAQgHAAgIgDg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EALnAnGQgYgHgWgVQgXgVgIgXQgIgXALgMIDajpQALgMAYAGQAYAHAWAVQAXAVAIAXQAIAXgLAMIjaDpQgIAIgMAAQgHAAgIgCg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EALRAndQgYgGgWgVQgXgVgHgYQgJgXAMgMIDZjpQAMgMAXAHQAYAGAWAVQAXAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgHAAgIgCg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EAKtAoDQgYgGgWgVQgWgVgIgXQgIgYALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAYgLALIjaDqQgHAHgNAAQgGAAgJgCg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EAKNAolQgYgGgWgVQgXgVgHgXQgJgXAMgMIDZjpQALgMAYAGQAYAGAWAVQAXAVAIAYQAIAXgLAMIjaDpQgHAIgNAAQgHAAgIgDg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EAJ6Ao6QgYgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAYAGAWAVQAWAVAJAXQAHAXgLAMIjaDpQgHAIgMAAQgHAAgIgCg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAJvApFQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAJuApGQgYgGgWgVQgWgVgIgXQgIgXALgMIDajqQALgLAYAGQAXAGAXAVQAWAVAIAYQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgDg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAJqApLQgYgGgWgVQgXgVgHgXQgJgYAMgMIDZjpQAMgMAXAHQAYAGAWAVQAXAVAIAXQAIAXgLAMIjaDqQgHAHgNAAQgHAAgIgCg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAJiApVQgYgHgXgVQgWgVgIgXQgIgXALgMIDajpQALgMAYAGQAYAHAWAVQAWAVAJAXQAHAXgLAMIjaDpQgHAIgMAAQgHAAgIgCg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAJTAplQgYgGgWgVQgXgVgHgXQgJgYALgLIDajqQALgLAYAGQAYAGAWAVQAXAVAIAYQAIAXgLAMIjaDpQgHAIgNAAQgHAAgIgDg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAI9Ap/QgYgHgXgUQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgMAAQgHAAgIgCg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAIiAqdQgYgHgWgUQgXgVgHgYQgJgXAMgMIDZjpQAMgMAYAHQAXAGAWAVQAXAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgHAAgIgCg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAIMAq2QgYgGgWgVQgXgVgIgXQgIgYALgLIDajqQALgLAYAGQAYAGAWAVQAXAVAIAXQAIAYgLAMIjaDpQgIAHgMAAQgHAAgIgCg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAH8ArIQgXgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAXAGAXAVQAWAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgGAAgJgCg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAHyArUQgYgHgWgVQgXgVgHgXQgJgXAMgMIDZjpQAMgMAXAGQAYAHAWAVQAXAVAIAXQAIAXgLAMIjaDpQgHAIgNAAQgHAAgIgCg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAHsArbQgYgGgXgVQgWgVgIgYQgIgXALgMIDajpQALgMAYAHQAYAGAWAVQAWAVAJAXQAHAXgLAMIjaDpQgHAIgMAAQgHAAgIgCg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_2_graphics_16,x:101.4272,y:249.0992}).wait(1).to({graphics:mask_2_graphics_17,x:101.1761,y:249.3664}).wait(1).to({graphics:mask_2_graphics_18,x:100.2104,y:250.3944}).wait(1).to({graphics:mask_2_graphics_19,x:98.0261,y:252.7196}).wait(1).to({graphics:mask_2_graphics_20,x:94.446,y:256.5308}).wait(1).to({graphics:mask_2_graphics_21,x:91.2195,y:259.9654}).wait(1).to({graphics:mask_2_graphics_22,x:89.2868,y:262.0227}).wait(1).to({graphics:mask_2_graphics_23,x:88.2522,y:263.1242}).wait(1).to({graphics:mask_2_graphics_24,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_25,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_26,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_27,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_28,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_29,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_30,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_31,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_32,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_33,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_34,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_35,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_36,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_37,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_38,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_39,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_40,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_41,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_42,x:88.2521,y:263.1242}).wait(1).to({graphics:mask_2_graphics_43,x:88.2522,y:263.1242}).wait(1).to({graphics:mask_2_graphics_44,x:88.1352,y:263.2573}).wait(1).to({graphics:mask_2_graphics_45,x:87.723,y:263.7266}).wait(1).to({graphics:mask_2_graphics_46,x:86.8822,y:264.6839}).wait(1).to({graphics:mask_2_graphics_47,x:85.4144,y:266.355}).wait(1).to({graphics:mask_2_graphics_48,x:83.169,y:268.9114}).wait(1).to({graphics:mask_2_graphics_49,x:80.5287,y:271.9175}).wait(1).to({graphics:mask_2_graphics_50,x:78.3057,y:274.4484}).wait(1).to({graphics:mask_2_graphics_51,x:76.7512,y:276.2182}).wait(1).to({graphics:mask_2_graphics_52,x:75.7265,y:277.3848}).wait(1).to({graphics:mask_2_graphics_53,x:75.0772,y:278.1242}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_2 = new lib.doodle5_1();
	this.instance_2.setTransform(160.7,510.75,1,1,0,0,0,13.6,14);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.doodle3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,14,12,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(7.1,5.5,1,1,0,0,0,7.1,5.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_4, new cjs.Rectangle(0,0,14.2,11.2), null);


(lib.doodle3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,14,12,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(6.6,6,1,1,0,0,0,6.6,6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_3, new cjs.Rectangle(0,0,13.2,12.1), null);


(lib.doodle3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,21,22,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(10.5,10.8,1,1,0,0,0,10.5,10.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_2, new cjs.Rectangle(0,0,20.9,21.6), null);


(lib.doodle3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,24,24,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(11.8,12.1,1,1,0,0,0,11.8,12.1);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_1, new cjs.Rectangle(0,0,23.7,24.3), null);


(lib.doodle3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("AChVZQhthDgeh8Qgah3A6hnIAGgLIIOFEIgHALQhDBjh2AcQgmAJgkAAQhUAAhLgvg");
	var mask_graphics_10 = new cjs.Graphics().p("ACIU7QhhhUgJh/QgIh5BMhdIAIgKIHRGWIgIAKQhSBXh6AIIgXABQhxAAhXhNg");
	var mask_graphics_11 = new cjs.Graphics().p("AFIWGQiAgMhRhjQhRhjAMh/QAMh5BZhPIAKgJIGJHdIgKAIQhSA+hlAAQgRAAgQgBg");
	var mask_graphics_12 = new cjs.Graphics().p("AErV8Qh7gghAhvQhBhvAhh7QAfh2Bmg/IALgHIE1IWIgLAHQhEAkhIAAQgpAAgqgMg");
	var mask_graphics_13 = new cjs.Graphics().p("AETVrQh0g0guh4Qgth4A1h0QAyhvBuguIAMgFIDaJCIgMAEQgxARgwAAQhAAAg/gdg");
	var mask_graphics_14 = new cjs.Graphics().p("AEAVTQhrhHgZh9QgZh+BHhqQBDhlB1gcIAMgCIB6JdIgNADQgaAEgZAAQhZAAhPg1g");
	var mask_graphics_15 = new cjs.Graphics().p("ADyU0QhehXgEiAQgEiABXhdQBThZB3gIIANgBIAVJpIgNABQh3gBhZhTg");
	var mask_graphics_16 = new cjs.Graphics().p("AGBWFQh2gUhKhhQhNhlAQh/QARh/BlhNQBhhKB3ALIANABIhRJkIgNgBg");
	var mask_graphics_17 = new cjs.Graphics().p("AE4V+Qhxgng5hrQg8hxAlh7QAlh6Bxg8QBrg5BzAeIANAEIizJPIgNgEg");
	var mask_graphics_18 = new cjs.Graphics().p("ADzVzQhpg5gnhzQgph5A4hzQA5hzB5gpQBzgnBtAyIAMAFIkRIqIgMgGg");
	var mask_graphics_19 = new cjs.Graphics().p("ACzVlQhehKgUh4QgUh+BKhoQBLhoB+gUQB4gUBjBCIALAIIloH1IgLgHg");
	var mask_graphics_20 = new cjs.Graphics().p("AB7VTQhRhXAAh6QAAiABbhaQBbhbB/ABQB6AABXBRIAKAJIm2G0IgJgJg");
	var mask_graphics_21 = new cjs.Graphics().p("ABMU/QhChkAUh3QAVh/BohKQBphKB+AVQB3AUBJBeIAIALIn2FnIgIgLg");
	var mask_graphics_22 = new cjs.Graphics().p("AAnUpQgvhtAmhzQAph5Bzg4QBzg5B5ApQBzAoA4BpIAGAMIoqEQIgGgMg");
	var mask_graphics_23 = new cjs.Graphics().p("AANURQgdhzA5hrQA8hxB7glQB6glBxA9QBrA5AmByIAEAMIpPCyIgEgNg");
	var mask_graphics_24 = new cjs.Graphics().p("AAAT5QgKh3BJhgQBOhmB/gQQB/gQBlBOQBgBKAUB2IACANIplBPIgBgNg");
	var mask_graphics_25 = new cjs.Graphics().p("AgBTiIAAgNQAIh3BZhTQBdhXCAAFQCAAEBXBeQBTBZAAB3IAAANg");
	var mask_graphics_26 = new cjs.Graphics().p("AADSXIADgMQAch0BlhEQBqhGB+AZQB9AZBHBrQBDBlgUB2IgCANg");
	var mask_graphics_27 = new cjs.Graphics().p("AAQRPIAFgMQAvhuBvgyQB0g0B4AtQB3AuA1B0QAxBvgmBxIgEANg");
	var mask_graphics_28 = new cjs.Graphics().p("AAiQJIAHgMQBAhlB1gfQB8ggBuBAQBvBBAgB7QAfB2g4BpIgHALg");
	var mask_graphics_29 = new cjs.Graphics().p("AAiQJIAHgMQBAhlB1gfQB8ggBuBAQBvBBAgB7QAfB2g4BpIgHALg");
	var mask_graphics_30 = new cjs.Graphics().p("AAiQJIAHgMQBAhlB1gfQB8ggBuBAQBvBBAgB7QAfB2g4BpIgHALg");
	var mask_graphics_31 = new cjs.Graphics().p("AAiQJIAHgMQBAhlB1gfQB8ggBuBAQBvBBAgB7QAfB2g4BpIgHALg");
	var mask_graphics_32 = new cjs.Graphics().p("AAhQMIAGgMQBAhlB1ggQB7ghBvA/QBvBAAiB7QAgB1g4BqIgGALg");
	var mask_graphics_33 = new cjs.Graphics().p("AAdQVIAHgLQA8hnB1gjQB6gkBxA9QBwA9AlB6QAiB1g1BrIgGALg");
	var mask_graphics_34 = new cjs.Graphics().p("AAXQnIAGgMQA4hpBzgoQB5gpBzA4QBzA4AqB5QAnBzgwBtIgGALg");
	var mask_graphics_35 = new cjs.Graphics().p("AAPRDIAFgMQAxhtBwgvQB2gyB2AxQB3AwAxB2QAvBwgpBwIgEAMg");
	var mask_graphics_36 = new cjs.Graphics().p("AAFRtIAEgMQAmhyBrg5QBxg9B6AlQB7AlA9BwQA5BrgeB0IgDAMg");
	var mask_graphics_37 = new cjs.Graphics().p("AgDSoIACgMQAXh2BihHQBohLB+AVQB/AUBKBoQBIBigPB3IgCANg");
	var mask_graphics_38 = new cjs.Graphics().p("AgGToQACh4BUhXQBZhcCAgCQCAgBBcBZQBXBUAGB4IAAANIpoAJIAAgNg");
	var mask_graphics_39 = new cjs.Graphics().p("AADULQgXh1A+hoQBChuB9geQB8gfBtBDQBoA/AhBzIADAMIpYCTIgDgMg");
	var mask_graphics_40 = new cjs.Graphics().p("AAwU0Qg2hqAfh1QAhh8Bvg/QBwg/B7AhQB1AgA/BmIAHALIoZEyIgGgLg");
	var mask_graphics_41 = new cjs.Graphics().p("ACJVdQhVhUgHh5QgGiABVhfQBWhfB/gHQB6gGBbBNIAKAIImdHLIgKgIg");
	var mask_graphics_42 = new cjs.Graphics().p("AEJV7QhsgyguhxQgwh2Ayh2QAyh2B2gwQBxguBvArIANAFIjxI4IgMgFg");
	var mask_graphics_43 = new cjs.Graphics().p("AGUWLQh3gPhOheQhShiAMh/QALiABihSQBdhOB3AHIANABIg2JnIgNgBg");
	var mask_graphics_44 = new cjs.Graphics().p("AD/VVQhphJgYh9QgXh+BJhpQBFhkB1gaIAMgDIBwJgIgNACQgXADgXAAQhcAAhQg3g");
	var mask_graphics_45 = new cjs.Graphics().p("AEbV1Qh3gvgyh2Qgzh1Avh3QAthxBsgzIAMgFID0I3IgMAFQg2AVg3AAQg5AAg6gXg");
	var mask_graphics_46 = new cjs.Graphics().p("AE4WFQh9gZhHhqQhHhrAZh9QAXh3BhhGIALgHIFXIBIgLAHQhKAuhTAAQgfAAghgHg");
	var mask_graphics_47 = new cjs.Graphics().p("AFTWLQh/gHhWheQhWhfAGiAQAGh5BWhUIAJgJIGfHKIgKAJQhVBHhuAAIgSAAg");
	var mask_graphics_48 = new cjs.Graphics().p("ACLU/QhhhUgIiAQgIh5BLhdIAIgKIHRGWIgIAKQhSBXh5AIIgYABQhxAAhXhMg");
	var mask_graphics_49 = new cjs.Graphics().p("ACYVQQhnhLgVh+QgTh4BChjIAIgLIH0FpIgHALQhKBeh4ATQgbAFgaAAQhfAAhSg7g");
	var mask_graphics_50 = new cjs.Graphics().p("AChVZQhthDgeh8Qgah3A6hnIAGgLIIOFEIgHALQhDBjh2AcQgmAJgkAAQhUAAhLgvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:58.5562,y:141.6216}).wait(1).to({graphics:mask_graphics_10,x:57.1094,y:141.5641}).wait(1).to({graphics:mask_graphics_11,x:55.3554,y:141.5483}).wait(1).to({graphics:mask_graphics_12,x:53.3412,y:141.5681}).wait(1).to({graphics:mask_graphics_13,x:51.1211,y:141.5792}).wait(1).to({graphics:mask_graphics_14,x:48.7547,y:141.571}).wait(1).to({graphics:mask_graphics_15,x:46.3054,y:141.5657}).wait(1).to({graphics:mask_graphics_16,x:47.8588,y:141.4499}).wait(1).to({graphics:mask_graphics_17,x:50.3847,y:140.9541}).wait(1).to({graphics:mask_graphics_18,x:52.7843,y:140.0701}).wait(1).to({graphics:mask_graphics_19,x:54.9933,y:138.8217}).wait(1).to({graphics:mask_graphics_20,x:56.9523,y:137.2426}).wait(1).to({graphics:mask_graphics_21,x:58.6091,y:135.3751}).wait(1).to({graphics:mask_graphics_22,x:59.919,y:133.2695}).wait(1).to({graphics:mask_graphics_23,x:60.8472,y:130.9825}).wait(1).to({graphics:mask_graphics_24,x:61.3687,y:128.5756}).wait(1).to({graphics:mask_graphics_25,x:61.477,y:127.2136}).wait(1).to({graphics:mask_graphics_26,x:61.4808,y:129.7841}).wait(1).to({graphics:mask_graphics_27,x:61.4691,y:132.2672}).wait(1).to({graphics:mask_graphics_28,x:61.0258,y:134.3461}).wait(1).to({graphics:mask_graphics_29,x:61.0259,y:134.3462}).wait(1).to({graphics:mask_graphics_30,x:61.0259,y:134.3462}).wait(1).to({graphics:mask_graphics_31,x:61.0258,y:134.3461}).wait(1).to({graphics:mask_graphics_32,x:61.0272,y:134.25}).wait(1).to({graphics:mask_graphics_33,x:61.0308,y:133.9353}).wait(1).to({graphics:mask_graphics_34,x:61.0362,y:133.3494}).wait(1).to({graphics:mask_graphics_35,x:61.0408,y:132.4174}).wait(1).to({graphics:mask_graphics_36,x:61.0386,y:131.0364}).wait(1).to({graphics:mask_graphics_37,x:61.0233,y:129.0767}).wait(1).to({graphics:mask_graphics_38,x:61.0186,y:126.8586}).wait(1).to({graphics:mask_graphics_39,x:60.6023,y:130.3184}).wait(1).to({graphics:mask_graphics_40,x:59.0533,y:134.3054}).wait(1).to({graphics:mask_graphics_41,x:56.0165,y:138.1272}).wait(1).to({graphics:mask_graphics_42,x:51.7558,y:140.8468}).wait(1).to({graphics:mask_graphics_43,x:47.1461,y:141.9735}).wait(1).to({graphics:mask_graphics_44,x:48.5872,y:142.0303}).wait(1).to({graphics:mask_graphics_45,x:51.9158,y:142.0126}).wait(1).to({graphics:mask_graphics_46,x:54.3978,y:141.9565}).wait(1).to({graphics:mask_graphics_47,x:56.1855,y:141.9035}).wait(1).to({graphics:mask_graphics_48,x:57.449,y:141.8838}).wait(1).to({graphics:mask_graphics_49,x:58.3316,y:141.8823}).wait(1).to({graphics:mask_graphics_50,x:58.5562,y:141.6216}).wait(1).to({graphics:null,x:0,y:0}).wait(9));

	// Layer_1
	this.instance = new lib.doodle3_1();
	this.instance.setTransform(96.45,241.55,1.3737,1.3737,0,0,0,12,12.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({_off:true},42).wait(9));

	// Layer_14 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_20 = new cjs.Graphics().p("EALiAmWQgOgEgNgMQgNgMgEgOQgFgNAGgHIB/iIQAHgHAOAEQAOADANAMQANANAFANQAEAOgGAHIh/CIQgFAEgHAAIgJgBg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EALdAmbQgOgDgNgNQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANAEANAMQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EALPAmqQgOgEgNgMQgNgMgFgOQgFgOAHgHIB/iIQAGgHAOAEQAOAEANAMQANAMAFAOQAFAOgHAGIh/CJQgEAEgIAAIgIgBg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAK7Am+QgOgEgNgMQgNgNgFgNQgEgOAGgHIB/iIQAHgHAOAEQAOAEANAMQANAMAEAOQAFANgGAHIiACIQgEAFgHAAIgJgBg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAKoAnRQgOgEgNgMQgOgMgEgNQgFgOAHgHIB/iIQAGgHAOAEQAOADANANQANAMAFAOQAEANgGAHIh/CIQgEAFgIAAIgIgCg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAKZAngQgOgEgNgMQgNgMgEgOQgFgOAGgHIB/iIQAHgHAOAEQAOAEANAMQANAMAFAOQAEAOgGAGIiACJQgEAEgHAAIgJgBg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAKUAnlQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAKTAnmQgOgEgNgMQgNgMgEgOQgFgNAGgHIB/iIQAHgHAOAEQAOADANANQANAMAEANQAFAOgGAHIiACIQgEAEgHAAIgJgBg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAKQAnpQgOgEgNgMQgNgMgFgOQgEgNAGgHIB/iIQAHgHAOAEQANADAOANQANAMAEANQAFAOgHAHIh/CIQgEAEgHAAIgJgBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAKKAnwQgOgEgNgMQgNgNgFgNQgFgOAHgHIB/iIQAGgHAOAEQAOAEANAMQANAMAFAOQAEANgGAHIh/CIQgEAFgIAAIgIgBg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAJ+An7QgOgEgNgMQgNgMgFgOQgEgNAGgHIB/iIQAHgHAOAEQANADAOANQANAMAEANQAFAOgHAHIh/CIQgEAEgHAAIgJgBg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAJuAoMQgOgEgNgMQgOgNgEgNQgFgOAHgHIB/iIQAGgHAOAEQAOAEANAMQANAMAFAOQAEANgGAHIh/CIQgEAFgIAAIgIgBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAJeAobQgOgDgNgMQgNgNgFgNQgFgOAHgHIB/iIQAGgHAOAEQAOAEANAMQANAMAFAOQAEANgGAHIh/CIQgEAFgIAAIgIgCg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EAJSAonQgOgEgNgMQgNgMgEgOQgFgOAGgHIB/iIQAHgHAOAEQAOAEANAMQANAMAFAOQAEAOgGAGIh/CJQgFAEgHAAIgJgBg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EAJLAouQgOgEgNgMQgNgMgFgOQgEgNAGgHIB/iIQAHgHAOADQAOAEANAMQANANAEANQAFAOgGAHIiACIQgEAEgHAAIgJgBg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EAJHAoyQgOgEgNgMQgNgMgFgNQgEgOAGgHIB/iIQAHgHAOAEQANADANANQAOAMAEAOQAFANgHAHIh/CIQgEAFgHAAIgJgCg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_1_graphics_20,x:88.9469,y:245.5307}).wait(1).to({graphics:mask_1_graphics_21,x:88.4225,y:246.0599}).wait(1).to({graphics:mask_1_graphics_22,x:86.9897,y:247.5057}).wait(1).to({graphics:mask_1_graphics_23,x:85.0326,y:249.4808}).wait(1).to({graphics:mask_1_graphics_24,x:83.0754,y:251.4558}).wait(1).to({graphics:mask_1_graphics_25,x:81.6427,y:252.9016}).wait(1).to({graphics:mask_1_graphics_26,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_27,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_28,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_29,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_30,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_31,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_32,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_33,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_34,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_35,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_36,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_37,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_38,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_39,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_40,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_41,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_42,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_43,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_44,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_45,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_46,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_47,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_48,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_49,x:81.1219,y:253.4557}).wait(1).to({graphics:mask_1_graphics_50,x:81.0362,y:253.5411}).wait(1).to({graphics:mask_1_graphics_51,x:80.7273,y:253.8489}).wait(1).to({graphics:mask_1_graphics_52,x:80.0792,y:254.4948}).wait(1).to({graphics:mask_1_graphics_53,x:78.9273,y:255.6426}).wait(1).to({graphics:mask_1_graphics_54,x:77.2766,y:257.2875}).wait(1).to({graphics:mask_1_graphics_55,x:75.6799,y:258.8787}).wait(1).to({graphics:mask_1_graphics_56,x:74.5505,y:260.0042}).wait(1).to({graphics:mask_1_graphics_57,x:73.8321,y:260.72}).wait(1).to({graphics:mask_1_graphics_58,x:73.4219,y:261.1557}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance_1 = new lib.doodle3_3();
	this.instance_1.setTransform(153.65,497.5,1.2529,1.2529,0,0,0,6.6,6.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_22 = new cjs.Graphics().p("EALQAoyQgGgGAAgIQAAgJAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAJQAAAIgGAGQgGAGgJAAQgIAAgGgGg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EALIAozQgHgIAAgLQAAgLAHgIQAIgHALAAQALAAAIAHQAIAIAAALQAAALgIAIQgIAIgLAAQgLAAgIgIg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAKxAo2QgNgNAAgTQAAgTANgNQANgOATAAQATAAAOAOQANANAAATQAAATgNANQgOANgTAAQgTAAgNgNg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAKJAo7QgWgXAAggQAAggAWgXQAXgWAgAAQAhAAAWAWQAXAXAAAgQAAAggXAXQgWAXghAAQggAAgXgXg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAJmAo/QgegfAAgrQAAgsAegfQAggfArAAQAsAAAgAfQAfAfAAAsQAAArgfAfQggAfgsAAQgrAAgggfg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAJSApCQgjgkAAgyQAAgzAjgkQAkgjAzAAQAzAAAkAjQAkAkAAAzQAAAygkAkQgkAkgzAAQgzAAgkgkg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAJJApDQgmgmAAg1QAAg2AmgmQAmgmA2AAQA2AAAmAmQAmAmAAA2QAAA1gmAmQgmAmg2AAQg2AAgmgmg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAJIApJQgmgnAAg2QAAg3AmgmQAngnA3AAQA3AAAnAnQAmAmAAA3QAAA2gmAnQgnAng3AAQg3AAgngng");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAJJApJQgmgmAAg3QAAg2AmgmQAngnA2AAQA3AAAmAnQAnAmAAA2QAAA3gnAmQgmAmg3AAQg2AAgngmg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAJNApIQglglAAg1QAAg1AlgmQAmglA1AAQA1AAAmAlQAmAmAAA1QAAA1gmAlQgmAmg1AAQg1AAgmgmg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAJUApHQgkgkAAgyQAAgzAkgkQAkgkAzAAQAzAAAkAkQAkAkAAAzQAAAygkAkQgkAkgzAAQgzAAgkgkg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAJfApFQghghAAgvQAAguAhgiQAighAuAAQAwAAAhAhQAhAiAAAuQAAAvghAhQghAhgwAAQguAAgighg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAJxApCQgcgcAAgpQAAgpAcgdQAdgcApAAQApAAAdAcQAdAdAAApQAAApgdAcQgdAdgpAAQgpAAgdgdg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAKJAo+QgXgXAAggQAAghAXgXQAXgXAhAAQAhAAAXAXQAXAXAAAhQAAAggXAXQgXAXghAAQghAAgXgXg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAKhAo6QgRgRAAgYQAAgZARgRQASgRAYAAQAZAAARARQARARAAAZQAAAYgRARQgRASgZAAQgYAAgSgSg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAK0Ao3QgNgMAAgSQAAgSANgNQANgNASAAQASAAANANQANANAAASQAAASgNAMQgNANgSAAQgSAAgNgNg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EALBAo1QgJgJAAgOQAAgNAJgKQAKgKAOAAQANAAAKAKQAJAKAAANQAAAOgJAJQgKAKgNAAQgOAAgKgKg");
	var mask_2_graphics_54 = new cjs.Graphics().p("EALKAo0QgHgIAAgKQAAgLAHgHQAIgHAKAAQALAAAHAHQAIAHAAALQAAAKgIAIQgHAHgLAAQgKAAgIgHg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EALQAoyQgGgGAAgIQAAgJAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAJQAAAIgGAGQgGAGgJAAQgIAAgGgGg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_2_graphics_22,x:75.4982,y:261.5952}).wait(1).to({graphics:mask_2_graphics_23,x:75.7945,y:261.8747}).wait(1).to({graphics:mask_2_graphics_24,x:76.6907,y:262.7198}).wait(1).to({graphics:mask_2_graphics_25,x:78.2198,y:264.162}).wait(1).to({graphics:mask_2_graphics_26,x:79.573,y:265.4382}).wait(1).to({graphics:mask_2_graphics_27,x:80.3503,y:266.1712}).wait(1).to({graphics:mask_2_graphics_28,x:80.7138,y:266.514}).wait(1).to({graphics:mask_2_graphics_29,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_30,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_31,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_32,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_33,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_34,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_35,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_36,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_37,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_38,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_39,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_40,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_41,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_42,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_43,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_44,x:81.0307,y:267.1615}).wait(1).to({graphics:mask_2_graphics_45,x:80.9908,y:267.1217}).wait(1).to({graphics:mask_2_graphics_46,x:80.8525,y:266.9839}).wait(1).to({graphics:mask_2_graphics_47,x:80.5767,y:266.709}).wait(1).to({graphics:mask_2_graphics_48,x:80.1053,y:266.2392}).wait(1).to({graphics:mask_2_graphics_49,x:79.3735,y:265.5098}).wait(1).to({graphics:mask_2_graphics_50,x:78.4067,y:264.5462}).wait(1).to({graphics:mask_2_graphics_51,x:77.4377,y:263.5804}).wait(1).to({graphics:mask_2_graphics_52,x:76.6763,y:262.8216}).wait(1).to({graphics:mask_2_graphics_53,x:76.1386,y:262.2856}).wait(1).to({graphics:mask_2_graphics_54,x:75.7726,y:261.9209}).wait(1).to({graphics:mask_2_graphics_55,x:75.4982,y:261.5952}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_2 = new lib.doodle3_4();
	this.instance_2.setTransform(151.25,517.05,1.2529,1.2529,0,0,0,7.1,5.7);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_16 = new cjs.Graphics().p("EAL0Am5QgXgGgVgUQgUgTgIgWQgHgVAKgLIDLjZQAKgLAWAGQAWAFAVAUQAVATAIAWQAHAWgKALIjLDZQgHAHgMAAQgGAAgHgCg");
	var mask_3_graphics_17 = new cjs.Graphics().p("EALxAm7QgWgGgVgTQgVgUgHgVQgIgWALgLIDKjZQALgLAWAGQAWAGAVATQAVAUAHAWQAIAVgLALIjKDZQgHAHgMAAQgGAAgIgCg");
	var mask_3_graphics_18 = new cjs.Graphics().p("EALoAnFQgWgGgVgUQgVgTgHgWQgIgVALgLIDKjZQALgLAWAGQAWAGAVATQAVATAHAWQAIAWgLALIjKDZQgHAHgMAAQgGAAgIgCg");
	var mask_3_graphics_19 = new cjs.Graphics().p("EALUAnbQgWgGgVgUQgVgTgHgWQgIgWALgLIDKjZQALgLAWAGQAWAGAVAUQAUATAIAWQAHAVgKALIjLDZQgGAIgMAAQgGAAgIgCg");
	var mask_3_graphics_20 = new cjs.Graphics().p("EAKzAn+QgWgGgVgTQgVgUgHgWQgIgVAKgLIDLjZQAKgLAXAGQAWAGAUATQAVAUAIAVQAHAWgKALIjLDZQgHAHgLAAQgHAAgHgCg");
	var mask_3_graphics_21 = new cjs.Graphics().p("EAKVAoeQgWgGgVgTQgVgUgHgWQgIgVAKgLIDLjZQAKgLAXAGQAWAGAUATQAVAUAIAVQAHAWgKALIjLDZQgHAHgLAAQgGAAgIgCg");
	var mask_3_graphics_22 = new cjs.Graphics().p("EAKDAoxQgWgGgVgTQgVgUgHgVQgIgWAKgLIDLjZQAKgLAXAGQAWAGAVATQAUAUAIAVQAHAWgKALIjLDZQgHAHgLAAQgGAAgIgCg");
	var mask_3_graphics_23 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_24 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_25 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_26 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_27 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_28 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_29 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_30 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_31 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_32 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_33 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_34 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_35 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_36 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_37 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_38 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_39 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_43 = new cjs.Graphics().p("EAJ4Ao8QgWgGgVgUQgVgTgHgWQgIgWALgLIDLjZQAKgLAWAGQAWAGAVAUQAVATAHAWQAIAVgLAMIjKDYQgHAIgMAAQgGAAgIgCg");
	var mask_3_graphics_44 = new cjs.Graphics().p("EAJ3Ao9QgWgGgVgUQgVgTgHgWQgIgVALgLIDKjZQALgLAWAGQAWAFAVAUQAVATAHAWQAIAWgLALIjLDZQgGAHgMAAQgGAAgIgCg");
	var mask_3_graphics_45 = new cjs.Graphics().p("EAJzApBQgWgGgVgTQgVgUgHgVQgHgWAKgLIDLjZQAKgLAWAGQAWAGAVATQAVAUAHAVQAIAWgLALIjKDZQgHAHgMAAQgGAAgIgCg");
	var mask_3_graphics_46 = new cjs.Graphics().p("EAJsApKQgXgGgVgTQgUgUgIgVQgHgWAKgLIDLjZQAKgLAWAGQAWAGAVATQAVAUAIAVQAHAWgKALIjLDZQgHAHgMAAQgGAAgHgCg");
	var mask_3_graphics_47 = new cjs.Graphics().p("EAJeApaQgWgGgVgUQgVgTgHgWQgIgWAKgLIDLjZQAKgLAXAGQAWAGAUAUQAVATAIAWQAHAVgKAMIjLDYQgHAIgLAAQgHAAgHgCg");
	var mask_3_graphics_48 = new cjs.Graphics().p("EAJJApxQgWgGgVgTQgVgUgHgVQgIgWAKgLIDLjZQAKgLAXAGQAWAGAUATQAVAUAIAWQAHAVgKALIjLDZQgHAHgLAAQgHAAgHgCg");
	var mask_3_graphics_49 = new cjs.Graphics().p("EAIwAqNQgWgGgVgTQgVgUgHgVQgIgWALgLIDKjZQALgLAWAGQAWAGAVATQAVAUAHAWQAIAVgLALIjLDZQgGAHgMAAQgGAAgIgCg");
	var mask_3_graphics_50 = new cjs.Graphics().p("EAIbAqlQgWgGgVgUQgVgTgHgWQgHgVAKgLIDLjZQAKgLAWAGQAWAFAVAUQAVATAHAWQAIAWgLALIjKDZQgHAHgMAAQgGAAgIgCg");
	var mask_3_graphics_51 = new cjs.Graphics().p("EAINAq1QgWgGgVgTQgVgUgHgVQgIgWAKgLIDLjZQAKgLAXAGQAWAGAUATQAVAUAIAWQAHAVgKALIjLDZQgHAHgLAAQgGAAgIgCg");
	var mask_3_graphics_52 = new cjs.Graphics().p("EAIDArAQgWgGgVgTQgVgUgHgVQgIgWALgLIDLjZQAKgLAWAGQAWAGAVATQAVAUAHAVQAIAWgLALIjKDZQgHAHgMAAQgGAAgIgCg");
	var mask_3_graphics_53 = new cjs.Graphics().p("EAH+ArHQgWgGgVgTQgVgUgHgVQgIgWAKgLIDLjZQAKgLAXAGQAWAGAUATQAVAUAIAWQAHAVgKALIjLDZQgHAHgLAAQgHAAgHgCg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_3_graphics_16,x:99.6631,y:249.0912}).wait(1).to({graphics:mask_3_graphics_17,x:99.4302,y:249.34}).wait(1).to({graphics:mask_3_graphics_18,x:98.5344,y:250.297}).wait(1).to({graphics:mask_3_graphics_19,x:96.508,y:252.4617}).wait(1).to({graphics:mask_3_graphics_20,x:93.1867,y:256.0098}).wait(1).to({graphics:mask_3_graphics_21,x:90.1935,y:259.2074}).wait(1).to({graphics:mask_3_graphics_22,x:88.4006,y:261.1228}).wait(1).to({graphics:mask_3_graphics_23,x:87.3381,y:262.1662}).wait(1).to({graphics:mask_3_graphics_24,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_25,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_26,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_27,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_28,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_29,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_30,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_31,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_32,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_33,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_34,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_35,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_36,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_37,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_38,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_39,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_40,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_41,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_42,x:87.3381,y:262.1661}).wait(1).to({graphics:mask_3_graphics_43,x:87.3381,y:262.1662}).wait(1).to({graphics:mask_3_graphics_44,x:87.2289,y:262.2899}).wait(1).to({graphics:mask_3_graphics_45,x:86.8438,y:262.7262}).wait(1).to({graphics:mask_3_graphics_46,x:86.0584,y:263.6161}).wait(1).to({graphics:mask_3_graphics_47,x:84.6873,y:265.1696}).wait(1).to({graphics:mask_3_graphics_48,x:82.5898,y:267.5461}).wait(1).to({graphics:mask_3_graphics_49,x:80.1234,y:270.3406}).wait(1).to({graphics:mask_3_graphics_50,x:78.0469,y:272.6934}).wait(1).to({graphics:mask_3_graphics_51,x:76.5947,y:274.3387}).wait(1).to({graphics:mask_3_graphics_52,x:75.6375,y:275.4232}).wait(1).to({graphics:mask_3_graphics_53,x:75.0881,y:276.1412}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_3 = new lib.doodle3_2();
	this.instance_3.setTransform(160.2,509.95,1.2529,1.2529,0,0,0,10.6,10.8);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150.0023,299.9992,1,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.doodle2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,27,24,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle2_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(13.2,11.8,1,1,0,0,0,13.2,11.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle2_2, new cjs.Rectangle(0,0,26.3,23.5), null);


(lib.doodle2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_17 = new cjs.Graphics().p("ACoT5IgBAAQgZgZAAgkQAAgjAZgZIABgBQAZgYAjAAQAjAAAZAYIABABQAZAZAAAjQAAAkgZAZIgBAAQgZAZgjAAIAAAAQgjAAgZgZgADkTVQAKAAAHgIIAAAAQAHgHAAgKQAAgKgGgHIgBAAQgHgHgKAAQgKAAgHAHIAAAAQgHAHAAAKQAAAKAHAHIAAAAQAHAHAKABg");
	var mask_graphics_18 = new cjs.Graphics().p("ACjT6IAAgBQgagaAAglQAAgkAagbIAAAAQAbgaAkAAQAlAAAaAaIAAAAQAaAbAAAkQAAAlgaAaIAAABQgaAaglAAIAAAAQglAAgagagADiTUQALAAAHgIIAAAAQAIgHAAgLQAAgKgIgHIAAgBQgIgHgKAAQgKAAgIAHIAAABQgHAHAAAKQAAALAHAHIAAAAQAIAIAKAAg");
	var mask_graphics_19 = new cjs.Graphics().p("ACYT7IAAAAQgdgcAAgpQAAgpAdgdIAAAAQAdgcApAAQAoAAAdAcIAAAAQAdAdAAApQAAApgdAcIAAAAQgdAdgoAAIgBAAQgoAAgdgdgADeTSQALAAAJgJIAAABQAIgJAAgLQAAgMgIgIIgBAAQgIgIgLAAQgMAAgIAIIAAAAQgIAIAAAMQAAALAIAJIAAgBQAIAJAMAAg");
	var mask_graphics_20 = new cjs.Graphics().p("ACFT/IAAAAQgigiAAgvQAAgvAhgiIABgBQAiggAuAAQAwAAAhAgIABABQAhAiAAAvQAAAvgiAiIAAAAQghAhgwAAIAAAAQgvAAghghgADVTOQAOAAAKgJIAAAAQAJgKAAgNQAAgNgJgKIgBgBQgJgJgOAAQgNAAgJAJIgBABQgJAKAAANQAAANAJAKIAAAAQAKAJANAAg");
	var mask_graphics_21 = new cjs.Graphics().p("ABnUEIAAgBQgogoAAg5QAAg6AogoIABgBQAogoA5AAQA5AAApAoIABABQAoAoAAA6QAAA5gpAoIAAABQgpAog5AAIAAAAQg5AAgpgogADJTJQARAAAMgMIgBAAQAMgLAAgQQAAgRgLgLIgBgBQgMgLgQAAQgQAAgLALIgBABQgLALAAARQAAAQALALIAAAAQAMAMAQAAg");
	var mask_graphics_22 = new cjs.Graphics().p("ABDUKIAAAAQgxgyAAhFQAAhGAxgyIABAAQAxgxBFAAQBGAAAxAxIABAAQAxAyAABGQAABFgyAyIAAAAQgxAxhGAAIAAAAQhFAAgygxgAC6TCQAUAAAPgOIgBAAQAOgOAAgTQAAgUgNgOIgBgBQgOgNgUAAQgTAAgOANIgBABQgOAOAAAUQAAATAOAOIAAAAQAOAOAUAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AAhUQIAAgBQg5g5AAhSQAAhRA5g6IAAgBQA6g4BRAAQBRAAA6A4IABABQA5A6AABRQAABSg6A5IAAABQg6A5hRAAIgBAAQhQAAg6g5gACsS8QAXAAARgRIAAABQAQgQAAgYQAAgWgQgRIgBgBQgQgPgXAAQgXAAgQAPIgBABQgQARAAAWQAAAYAQAQIAAgBQARARAXAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AAGUUIAAAAQg/hAAAhbQAAhaA/hBIABgBQBAg+BaAAQBaAABAA+IABABQBABBAABaQAABbhABAIAAAAQhBBAhaAAIgBAAQhZAAhBhAgAChS3QAaAAATgSIgBAAQASgSAAgaQAAgZgRgTIgBgBQgTgRgZAAQgZAAgTARIgBABQgRATAAAZQAAAaASASIAAAAQASASAaAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AgLUXIgBAAQhEhFAAhhQAAhgBEhFIABgCQBEhDBgAAQBgAABFBDIACACQBEBFAABgQAABhhFBFIAAAAQhFBFhhAAIgBAAQhfAAhEhFgACZS0QAcAAAUgUIAAABQATgUAAgcQAAgbgTgUIgBgBQgUgSgbAAQgbAAgUASIgBABQgTAUAAAbQAAAcAUAUIgBgBQAUAUAcAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AgYUaIAAgBQhIhHAAhmQAAhlBHhIIABgBQBHhHBlAAQBkAABJBHIABABQBHBIAABlQAABmhIBHIAAABQhIBHhlAAIgBAAQhkAAhHhHgACUSyQAdAAAVgVIgBAAQAVgUAAgdQAAgcgUgVIgBgBQgVgTgcAAQgdAAgUATIgBABQgUAVAAAcQAAAdAUAUIAAAAQAVAUAdABg");
	var mask_graphics_27 = new cjs.Graphics().p("AggUbIAAgBQhKhJAAhoQAAhoBJhKIABgBQBJhIBnAAQBoAABKBIIABABQBJBKAABoQAABohKBJIAAABQhKBJhoAAIAAAAQhnAAhJhJgACQSwQAeAAAWgVIgBAAQAVgUAAgeQAAgdgUgVIgBgCQgVgTgeAAQgdAAgVATIgBACQgUAVAAAdQAAAeAVAUIAAAAQAVAVAdAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AgkUcIAAgBQhLhKAAhqQAAhpBKhLIABgBQBKhJBpAAQBpAABLBJIABABQBKBLAABpQAABqhLBKIAAABQhLBKhpAAIgBAAQhoAAhKhKgACPSvQAeAAAWgVIgBAAQAWgVAAgeQgBgdgUgWIgBgBQgWgUgdAAQgeAAgVAUIgBABQgVAWAAAdQAAAeAVAVIAAAAQAWAVAeAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AglUcIAAAAQhLhLAAhqQAAhpBKhMIACgBQBKhJBpAAQBpAABLBJIABABQBLBMAABpQAABqhLBLIAAAAQhMBLhpAAIgBAAQhoAAhLhLgACPSwQAeAAAWgWIAAABQAVgWAAgeQAAgdgVgWIgBgBQgVgUgeAAQgeAAgVAUIgBABQgVAWAAAdQAAAeAVAWIAAgBQAWAWAeAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AglUcIAAAAQhLhLAAhqQAAhpBKhMIACgBQBKhJBpAAQBpAABLBJIABABQBLBMAABpQAABqhLBLIAAAAQhMBLhpAAIgBAAQhoAAhLhLgACPSwQAeAAAWgWIAAABQAVgWAAgeQAAgdgVgWIgBgBQgVgUgeAAQgeAAgVAUIgBABQgVAWAAAdQAAAeAVAWIAAgBQAWAWAeAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AgrUdIAAAAQhMhMAAhsQAAhsBLhNIACgBQBLhLBrAAQBsAABMBLIACABQBLBNAABsQAABshMBMIAAAAQhNBMhsAAIAAAAQhrAAhMhMgACMSvQAfAAAXgWIgBAAQAWgWAAgeQAAgfgVgVIgBgCQgWgUgfAAQgeAAgWAUIgBACQgVAVAAAfQAAAeAWAWIgBAAQAXAWAeAAg");
	var mask_graphics_32 = new cjs.Graphics().p("Ag/UhIgBgBQhRhRAAhzQAAhzBRhRIABgCQBRhQByABQByAABSBPIABACQBRBRAABzQAABzhSBRIAAABQhSBRhyAAIgBAAQhyAAhQhRgACESrQAhAAAXgYIAAABQAXgXAAghQAAgggWgXIgCgCQgXgWggAAQggAAgYAWIgBACQgWAXAAAgQAAAhAXAXIgBgBQAYAYAhAAg");
	var mask_graphics_33 = new cjs.Graphics().p("AhpUoIAAgBQhbhbAAiBQgBiBBbhcIACgBQBchaB+AAQCBAABcBaIABABQBbBcAACBQAACBhbBbIgBABQhcBbiBAAIAAAAQh/AAhchbgABySkQAmgBAagaIAAABQAagaAAglQAAgkgZgaIgCgCQgagZglAAQgjABgbAYIgBACQgZAaAAAkQAAAlAaAaIgBgBQAbAaAkABg");
	var mask_graphics_34 = new cjs.Graphics().p("AivU0IgBgBQhshsAAiZQAAiZBshtIABgCQBthrCXABQCZAABtBqIABACQBsBtAACZQAACZhsBsIgBABQhtBsiZAAIgBAAQiWAAhthsgABVSXQAsAAAgggIgBABQAfgfAAgrQAAgrgegfIgBgCQgggdgrAAQgrAAgfAdIgBACQgdAfAAArQAAArAeAfIgBgBQAgAgArAAg");
	var mask_graphics_35 = new cjs.Graphics().p("AkdVHIAAgBQiHiHAAi/QgBi+CHiIIACgCQCIiFC8AAQC+AACHCFIACACQCHCIgBC+QAAC/iHCHIAAABQiICGi+AAIgCAAQi7AAiIiGgAAoSDQA3AAAngnIgBABQAngmgBg3QAAg1glgnIgCgCQgnglg1AAQg1ABgmAkIgCACQglAnAAA1QgBA3AnAmIgBgBQAnAnA2AAg");
	var mask_graphics_36 = new cjs.Graphics().p("AmZVgIgBgBQiqiqAAjxQAAjwCpirIACgCQCsioDtABQDvAACrCnIACACQCpCrAADwQAADxiqCqIgBABQirCpjvAAIgBAAQjtAAiripgAAARpQBFAAAxgxIAAABQAwgwAAhFQgBhDgugxIgDgDQgxguhDAAQhDAAgwAuIgDADQguAxgBBDQAABFAwAwIAAgBQAxAxBEAAg");
	var mask_graphics_37 = new cjs.Graphics().p("AnuV5IgBgCQjNjNAAkiQgBkhDMjPIADgDQDPjKEfAAQEgAADODKIAEADQDMDPgBEhQAAEijNDNIgBACQjODMkhAAIgBAAQkfAAjOjMgAAARPQBTAAA8g7IgBABQA6g6AAhTQAAhRg5g7IgDgDQg7g4hRAAQhQAAg7A4IgDADQg5A7AABRQAABTA6A6IgBgBQA8A6BSABg");
	var mask_graphics_38 = new cjs.Graphics().p("AoxWMIgBgBQjpjpAAlJQAAlJDnjqIAEgEQDqjkFGAAQFHAADqDkIAEAEQDnDqAAFJQAAFJjpDpIgBABQjrDolHAAIgCAAQlFAAjqjogAAAQ7QBegBBEhDIgBACQBChCAAheQgBhdg/hCIgEgEQhDg/hcAAQhbAAhDA/IgEAEQg/BCgBBdQAABeBCBCIgBgCQBEBDBdABg");
	var mask_graphics_39 = new cjs.Graphics().p("ApgWaIgBgCQj8j8AAllQgBlkD7j+IAEgEQD+j3FhABQFiAAD+D2IAEAEQD7D+gBFkQAAFlj8D8IgBACQj+D7ljAAIgCAAQlgAAj+j7gAAAQsQBmAABJhJIgBACQBIhIAAhmQgBhkhFhIIgEgEQhIhFhkABQhjAAhIBEIgEAEQhFBIgBBkQAABmBIBIIgBgCQBJBIBlABg");
	var mask_graphics_40 = new cjs.Graphics().p("AqAWkIgBgCQkKkKAAl3QAAl3EIkMIAEgEQELkEF0ABQF1AAELEDIAEAEQEIEMAAF3QAAF3kKEKIgBACQkLEIl2gBIgCAAQlzAAkLkHgAAAQiQBrAABOhNIgBACQBLhLAAhrQgBhqhIhMIgEgEQhNhIhpAAQhoAAhNBIIgEAEQhIBMgBBqQAABrBLBLIgBgCQBNBMBrABg");
	var mask_graphics_41 = new cjs.Graphics().p("AqVWrIgBgCQkSkSgBmEQAAmDERkVIAEgEQEUkMGAAAQGBAAEUEMIAEAEQEREVAAGDQgBGEkSESIgBACQkUERmCgBIgCAAQl/AAkUkQgAAAQdQBvgBBQhPIgBACQBNhOAAhuQAAhthLhPIgEgEQhQhLhsABQhsAAhPBKIgEAEQhLBPAABtQAABuBNBOIgBgCQBQBPBuABg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_graphics_17,x:31.3582,y:129.7737}).wait(1).to({graphics:mask_graphics_18,x:31.543,y:129.958}).wait(1).to({graphics:mask_graphics_19,x:31.9896,y:130.4037}).wait(1).to({graphics:mask_graphics_20,x:32.7886,y:131.2008}).wait(1).to({graphics:mask_graphics_21,x:33.9969,y:132.4064}).wait(1).to({graphics:mask_graphics_22,x:35.4794,y:133.8856}).wait(1).to({graphics:mask_graphics_23,x:36.8861,y:135.2891}).wait(1).to({graphics:mask_graphics_24,x:37.9849,y:136.3854}).wait(1).to({graphics:mask_graphics_25,x:38.7627,y:137.1615}).wait(1).to({graphics:mask_graphics_26,x:39.2818,y:137.6795}).wait(1).to({graphics:mask_graphics_27,x:39.6033,y:138.0003}).wait(1).to({graphics:mask_graphics_28,x:39.7732,y:138.1697}).wait(1).to({graphics:mask_graphics_29,x:39.8813,y:138.2777}).wait(1).to({graphics:mask_graphics_30,x:39.8813,y:138.2777}).wait(1).to({graphics:mask_graphics_31,x:40.1282,y:138.5241}).wait(1).to({graphics:mask_graphics_32,x:40.9843,y:139.3783}).wait(1).to({graphics:mask_graphics_33,x:42.691,y:141.0812}).wait(1).to({graphics:mask_graphics_34,x:45.6078,y:143.9915}).wait(1).to({graphics:mask_graphics_35,x:50.1364,y:148.5099}).wait(1).to({graphics:mask_graphics_36,x:54.1149,y:154.4793}).wait(1).to({graphics:mask_graphics_37,x:54.0914,y:160.462}).wait(1).to({graphics:mask_graphics_38,x:54.073,y:165.163}).wait(1).to({graphics:mask_graphics_39,x:54.0599,y:168.4831}).wait(1).to({graphics:mask_graphics_40,x:54.0511,y:170.7424}).wait(1).to({graphics:mask_graphics_41,x:54.2548,y:172.3335}).wait(1).to({graphics:null,x:0,y:0}).wait(18));

	// Layer_8
	this.instance = new lib.doodle2_2();
	this.instance.setTransform(49.6,242.65,1.1434,1.1434,0,0,0,13.2,11.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(17).to({_off:false},0).to({_off:true},25).wait(18));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.doodle1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,19,14,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle1_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(9.2,6.8,1,1,0,0,0,9.2,6.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_3, new cjs.Rectangle(0,0,18.4,13.5), null);


(lib.doodle1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,-5,29,34,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle1_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(14.5,16.6,1,1,0,0,0,14.5,16.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_2, new cjs.Rectangle(13.4,-1.1,12.6,24.3), null);


(lib.doodle1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,64,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle1_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(31.9,21.8,1,1,0,0,0,31.9,21.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_1, new cjs.Rectangle(0,0,63.9,43.6), null);


(lib.doodle1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_15 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_22 = new cjs.Graphics().p("ANHUJQgLgJgBgOQgBgOAJgLQAJgLAOgBQAPgCALAKQALAJABAOQABAOgJALQgJALgPABIgDABQgMAAgKgJg");
	var mask_graphics_23 = new cjs.Graphics().p("AM7UMQgOgMgCgSQgCgTAMgOQAMgOATgCQATgCAOAMQAOAMACATQACASgNAPQgMAOgSACIgFAAQgQAAgMgLg");
	var mask_graphics_24 = new cjs.Graphics().p("AMWUVQgZgVgCgfQgDggAUgZQAVgYAggDQAfgCAZAUQAYAVADAfQADAggVAYQgUAZggACIgIABQgbAAgVgSg");
	var mask_graphics_25 = new cjs.Graphics().p("ALWUjQgpgjgFg2QgEg2AigpQAjgqA2gFQA3gEApAiQAqAjAFA2QAFA2gjAqQgjAqg3AEIgNABQguAAglgfg");
	var mask_graphics_26 = new cjs.Graphics().p("AKeUwQg4gwgHhKQgGhJAvg5QAwg5BKgGQBKgHA5AwQA5AvAHBKQAGBKgwA5QgvA5hLAGIgRABQg/AAgzgqg");
	var mask_graphics_27 = new cjs.Graphics().p("AJ+U3QhBg3gHhVQgIhVA3hCQA3hBBVgHQBWgIBCA3QBBA3AIBVQAHBVg3BBQg3BChWAIIgUABQhJAAg6gxg");
	var mask_graphics_28 = new cjs.Graphics().p("AJvU6QhFg6gIhaQgIhbA6hFQA7hGBagIQBbgIBGA6QBGA7AIBbQAIBag7BFQg6BGhcAIIgVABQhNAAg+g0g");
	var mask_graphics_29 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgIQBdgJBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_30 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_31 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_32 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_33 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_34 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_35 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_36 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_37 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_38 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_39 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_40 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_41 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_42 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_43 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgJQBdgIBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_44 = new cjs.Graphics().p("AJuU7QhGg7gIhcQgIhcA7hHQA8hGBbgIQBdgJBHA7QBHA8AIBcQAIBcg8BGQg7BHhdAIIgVABQhPAAg/g0g");
	var mask_graphics_45 = new cjs.Graphics().p("AJwU6QhGg6gIhcQgIhbA7hHQA7hFBbgIQBcgJBHA7QBGA7AIBcQAIBbg7BGQg7BHhcAIIgWABQhOAAg+g1g");
	var mask_graphics_46 = new cjs.Graphics().p("AJ1U5QhEg5gIhaQgIhZA6hFQA6hFBZgHQBagIBFA5QBFA6AIBZQAIBag6BEQg6BFhaAIIgVABQhNAAg9gzg");
	var mask_graphics_47 = new cjs.Graphics().p("AKAU3QhBg3gIhWQgHhVA3hCQA3hCBWgHQBWgIBCA3QBCA4AHBVQAIBWg4BBQg3BChWAIIgUAAQhKAAg6gwg");
	var mask_graphics_48 = new cjs.Graphics().p("AKTUyQg8gygHhPQgHhPAyg9QAzg8BPgHQBQgHA9AzQA9AzAGBPQAHBOgzA9QgzA9hPAHIgTAAQhDAAg2gtg");
	var mask_graphics_49 = new cjs.Graphics().p("AKwUsQg1gsgGhFQgGhEAsg1QAtg1BEgGQBFgGA1AsQA1AtAGBEQAGBFgsA0QgtA1hFAGIgQABQg7AAgugng");
	var mask_graphics_50 = new cjs.Graphics().p("ALWUjQgqgjgFg3QgFg3AkgqQAjgqA3gFQA3gFArAjQAqAkAFA3QAFA3gkAqQgkAqg3AFIgNAAQgvAAglgfg");
	var mask_graphics_51 = new cjs.Graphics().p("AL8UaQgfgagEgpQgDgpAaggQAbggApgDQApgEAgAbQAgAaAEApQADAqgbAfQgaAggqAEIgJAAQgkAAgcgYg");
	var mask_graphics_52 = new cjs.Graphics().p("AMaUUQgXgUgDgeQgCgfATgXQAUgYAegCQAfgDAYAUQAXATADAfQACAegTAXQgUAYgfADIgHAAQgaAAgVgRg");
	var mask_graphics_53 = new cjs.Graphics().p("AMwUPQgSgPgCgXQgCgXAPgRQAPgSAWgCQAXgCASAPQASAPACAXQACAWgPASQgPASgXACIgFAAQgUAAgPgNg");
	var mask_graphics_54 = new cjs.Graphics().p("AM+ULQgNgLgCgSQgBgRALgOQALgNASgCQASgBANALQAOALABASQACASgLANQgMAOgSABIgEABQgPAAgMgLg");
	var mask_graphics_55 = new cjs.Graphics().p("ANHUJQgLgJgBgOQgBgOAJgLQAJgLAOgBQAPgCALAKQALAJABAOQABAOgJALQgJALgPABIgDABQgMAAgKgJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_22,x:89.6066,y:129.752}).wait(1).to({graphics:mask_graphics_23,x:90.112,y:130.2779}).wait(1).to({graphics:mask_graphics_24,x:91.6403,y:131.8681}).wait(1).to({graphics:mask_graphics_25,x:94.2482,y:134.5818}).wait(1).to({graphics:mask_graphics_26,x:96.556,y:136.9832}).wait(1).to({graphics:mask_graphics_27,x:97.8816,y:138.3626}).wait(1).to({graphics:mask_graphics_28,x:98.5015,y:139.0076}).wait(1).to({graphics:mask_graphics_29,x:99.0012,y:139.1215}).wait(1).to({graphics:mask_graphics_30,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_31,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_32,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_33,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_34,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_35,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_36,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_37,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_38,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_39,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_40,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_41,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_42,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_43,x:99.0014,y:139.1217}).wait(1).to({graphics:mask_graphics_44,x:99.0012,y:139.1215}).wait(1).to({graphics:mask_graphics_45,x:98.9336,y:139.0536}).wait(1).to({graphics:mask_graphics_46,x:98.6985,y:138.8176}).wait(1).to({graphics:mask_graphics_47,x:98.2299,y:138.3472}).wait(1).to({graphics:mask_graphics_48,x:97.4289,y:137.5432}).wait(1).to({graphics:mask_graphics_49,x:96.1854,y:136.2949}).wait(1).to({graphics:mask_graphics_50,x:94.5426,y:134.6458}).wait(1).to({graphics:mask_graphics_51,x:92.8961,y:132.993}).wait(1).to({graphics:mask_graphics_52,x:91.6023,y:131.6943}).wait(1).to({graphics:mask_graphics_53,x:90.6886,y:130.7771}).wait(1).to({graphics:mask_graphics_54,x:90.0668,y:130.153}).wait(1).to({graphics:mask_graphics_55,x:89.6066,y:129.752}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance = new lib.doodle1_3();
	this.instance.setTransform(178.45,249.4,1.5738,1.5738,0,0,0,9.2,6.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_9 = new cjs.Graphics().p("AWBWkIn2vHQgZgyAyhGQAyhHBhgyQBhgyBWAAQBXgBAaAxIH1PIQAaAxgzBHQgyBGhgAyQhhAyhXACQhWAAgagyg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AWCWiIn8vEQgagxAxhGQAzhHBggzQBggzBXgBQBXgBAZAxIH9PEQAaAxgyBHQgyBHhgAyQhgAzhXACIgDAAQhUAAgagxg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AWHWcIoTu4QgbgwAwhHQAwhJBfg1QBfg1BXgDQBXgEAbAxIITO4QAbAwgxBJQgvBHhfA1QhgA1hXAEIgIAAQhPAAgagug");
	var mask_1_graphics_12 = new cjs.Graphics().p("AWQWQIo+ufQgdgvAthKQAthKBdg5QBcg6BWgGQBXgIAdAvII+OfQAdAvgtBLQgtBKhdA5QhcA5hXAIIgUABQhFAAgagqg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AWdV8Ip/tzQghgtAohMQAnhOBYhAQBZhABVgNQBWgOAgAtIKANzQAgAtgnBOQgnBMhZBAQhYBAhWAOQgTADgQAAQg5AAgagjg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AWwVcIrcsnQglgpAehRQAfhRBRhJQBQhKBUgWQBUgXAlApILcMoQAmApgfBRQgfBRhRBJQhQBJhUAXQgdAIgYAAQgrAAgZgbg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AXHUuItRqsQgrgiARhVQAShVBEhVQBFhVBPgiQBPglArAjINRKsQAsAigSBWQgSBUhEBVQhEBVhQAkQgnARgfAAQgeAAgWgRg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AXdTxIvLnwQgxgaAAhWQAAhXAxhhQAyhhBGgyQBGgzAyAZIPKHwQAyAZAABYQAABWgyBgQgyBhhGA0QguAhgmAAQgTAAgQgIg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AXlSvIwikEQg2gNgUhUQgUhVAahqQAahpA5hBQA4hCA2ANIQjEEQA2ANAUBVQATBUgaBqQgaBpg4BDQgvA2gtAAQgKAAgJgDg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AXbR4IxBgaQg4gBglhOQgmhPADhtQAChsAqhMQAphNA4ACIRBAaQA4ABAmBPQAlBOgDBtQgDBsgpBNQgoBKg3AAIgCAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AEmRnQgzhGgQhsQgRhsAchRQAahTA3gJIQ2ilQA3gIAzBGQAyBGAQBsQARBrgbBTQgbBSg3AIIw2CmIgMABQgwAAgtg/g");
	var mask_1_graphics_20 = new cjs.Graphics().p("AEmSlQg9g/gehoQgfhpAQhUQAPhWA2gQIQVk1QA1gQA8BAQA8A+AeBoQAfBpgPBWQgQBUg2AQIwVE1QgLADgLAAQgrAAgvgyg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AEvTVQhCg5gphkQgphlAHhWQAHhXA0gVIPxmcQAzgVBCA5QBBA4AqBkQApBlgHBXQgIBWgzAVIvxGcQgOAGgPAAQgoAAgwgpg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AE8T5QhGg0gxhhQgwhiABhWQABhXAxgZIPQnlQAygZBGA0QBFAzAxBhQAwBiAABXQgCBWgxAZIvQHlQgQAJgTAAQglAAgvgjg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AFIUTQhJgxg1heQg2hfgDhWQgEhXAwgcIO1oYQAxgbBJAwQBHAwA2BeQA1BfAFBXQADBWgxAcIu1IYQgRAKgVAAQgkAAgugeg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AFKUWQhJgwg2heQg3hfgDhWQgFhXAwgbIOxofQAxgcBJAwQBIAvA2BeQA2BfAFBXQAEBWgwAcIuyIeQgSAKgVAAQgkABgtgeg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AFQUhQhKgug4hdQg5hdgFhWQgHhXAvgdIOlo0QAvgdBLAuQBJAuA4BdQA4BdAHBXQAGBWgwAdIukI0QgTALgWAAQgjAAgtgcg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AFdU3QhMgrg8hbQg9hagJhWQgLhWAugfIOLpdQAvgfBMArQBLAqA8BbQA9BaAKBXQAKBWgvAeIuLJdQgTANgZAAQghAAgsgYg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AF2VaQhPgmhDhWQhChWgQhVQgRhVAsgiINeqcQAsgiBPAmQBOAkBCBWQBDBWARBWQAPBVgsAiItdKbQgVAQgdAAQggAAgogSg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AGkWNQhTgchLhPQhMhOgYhTQgahTAogmIMRr0QAognBTAdQBRAcBMBOQBLBPAaBTQAYBTgoAmIsRL0QgXAWglAAQgbAAgigMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AH1XVQhWgQhWhCQhXhCglhOQgmhOAigsIKVtjQAigsBWAQQBUAPBXBCQBXBCAmBPQAlBOgiAsIqVNiQgZAhg1AAQgTAAgWgEg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AHCX9QhigvgzhFQg1hFAYgyIHcvVQAYgyBXgCQBWgCBiAwQBiAvA1BGQA0BFgYAyIncPUQgYAyhWACIgHAAQhUAAhfgug");
	var mask_1_graphics_47 = new cjs.Graphics().p("AJ0Z4QhqgYhCg4QhDg4AMg2ID0wmQAMg2BVgWQBUgVBqAZQBqAYBDA4QBCA3gNA3Ij0QmQgMA2hTAVQgoAKgsAAQgzAAg4gNg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AM5bUQhtgBhMgpQhNgoAAg4IAQxBQABg4BOgnQBNgmBtACQBtACBNAoQBMAogBA4IgPRCQgBA3hNAmQhLAmhoAAIgIgBg");
	var mask_1_graphics_49 = new cjs.Graphics().p("ALWcBQhTgagJg3Iisw0QgIg3BGg0QBGgyBrgSQBsgRBTAbQBRAbAJA3ICsQ0QAJA3hGAyQhGA0hsARQgpAHgmAAQg8AAgygRg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AMec3QhWgPgQg2Ik4wUQgQg1A/g8QA+g8BpgfQBogfBWAPQBVAQAPA1IE4QVQAQA1g+A7Qg/A9hoAfQhFAUg8AAQggAAgcgFg");
	var mask_1_graphics_51 = new cjs.Graphics().p("ANZdYQhXgHgVg0ImdvwQgVg0A5hCQA4hBBlgpQBkgqBXAHQBWAIAVAzIGdPxQAVAzg4BCQg5BChlApQhVAjhKAAIgbgBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AOGdrQhXAAgYgyInkvQQgZgyA0hGQAzhFBigxQBhgwBXAAQBXACAYAyIHkPQQAZAygzBFQg0BGhiAwQheAvhUAAIgGAAg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AM1dKIoVu2QgcgxAxhIQAvhIBfg1QBfg2BXgEQBWgDAcAxIIVO2QAcAxgwBHQgxBJheA1QhfA2hXACIgNABQhMAAgZgtg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_1_graphics_9,x:188.5024,y:149.3507}).wait(1).to({graphics:mask_1_graphics_10,x:188.497,y:149.0911}).wait(1).to({graphics:mask_1_graphics_11,x:188.4589,y:148.2225}).wait(1).to({graphics:mask_1_graphics_12,x:188.3084,y:146.5728}).wait(1).to({graphics:mask_1_graphics_13,x:187.8485,y:143.9042}).wait(1).to({graphics:mask_1_graphics_14,x:186.6611,y:139.9112}).wait(1).to({graphics:mask_1_graphics_15,x:183.9925,y:134.3231}).wait(1).to({graphics:mask_1_graphics_16,x:178.9633,y:127.3249}).wait(1).to({graphics:mask_1_graphics_17,x:171.7266,y:120.1543}).wait(1).to({graphics:mask_1_graphics_18,x:164.0273,y:114.4447}).wait(1).to({graphics:mask_1_graphics_19,x:157.5739,y:118.973}).wait(1).to({graphics:mask_1_graphics_20,x:152.6091,y:123.9226}).wait(1).to({graphics:mask_1_graphics_21,x:148.9009,y:127.8155}).wait(1).to({graphics:mask_1_graphics_22,x:146.1924,y:130.752}).wait(1).to({graphics:mask_1_graphics_23,x:144.2849,y:132.8699}).wait(1).to({graphics:mask_1_graphics_24,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_25,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_26,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_27,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_28,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_29,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_30,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_31,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_32,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_33,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_34,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_35,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_36,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_37,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_38,x:144.2848,y:132.8699}).wait(1).to({graphics:mask_1_graphics_39,x:144.2849,y:132.8699}).wait(1).to({graphics:mask_1_graphics_40,x:144.0325,y:133.1503}).wait(1).to({graphics:mask_1_graphics_41,x:143.1883,y:134.0923}).wait(1).to({graphics:mask_1_graphics_42,x:141.5846,y:135.8963}).wait(1).to({graphics:mask_1_graphics_43,x:138.9908,y:138.8485}).wait(1).to({graphics:mask_1_graphics_44,x:135.1129,y:143.3279}).wait(1).to({graphics:mask_1_graphics_45,x:129.6961,y:149.7034}).wait(1).to({graphics:mask_1_graphics_46,x:122.931,y:157.9197}).wait(1).to({graphics:mask_1_graphics_47,x:116.0177,y:166.8942}).wait(1).to({graphics:mask_1_graphics_48,x:110.5219,y:174.8555}).wait(1).to({graphics:mask_1_graphics_49,x:115.5172,y:180.9785}).wait(1).to({graphics:mask_1_graphics_50,x:120.3687,y:185.2375}).wait(1).to({graphics:mask_1_graphics_51,x:124.1775,y:188.0737}).wait(1).to({graphics:mask_1_graphics_52,x:127.0483,y:189.938}).wait(1).to({graphics:mask_1_graphics_53,x:129.0207,y:191.0805}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_1 = new lib.doodle1_1();
	this.instance_1.setTransform(225.55,223.85,1.5738,1.5738,0,0,0,31.9,21.8);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(9).to({_off:false},0).to({_off:true},45).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.bgScreens = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img5
	this.img5 = new lib.img5();
	this.img5.name = "img5";
	this.img5.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img5).wait(1));

	// img4
	this.img4 = new lib.img4();
	this.img4.name = "img4";
	this.img4.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img3
	this.img3 = new lib.img3();
	this.img3.name = "img3";
	this.img3.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img2
	this.img2 = new lib.img2();
	this.img2.name = "img2";
	this.img2.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgScreens, new cjs.Rectangle(-1,149.3,290.2,339.2), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.scribbleClip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// scribble5
	this.scribble5 = new lib.scribble5();
	this.scribble5.name = "scribble5";
	this.scribble5.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble5).wait(1));

	// scribble4
	this.scribble4 = new lib.scribble4();
	this.scribble4.name = "scribble4";
	this.scribble4.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble4).wait(1));

	// scribble3
	this.scribble3 = new lib.scribble3();
	this.scribble3.name = "scribble3";
	this.scribble3.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble3).wait(1));

	// scribble2
	this.scribble2 = new lib.scribble2();
	this.scribble2.name = "scribble2";
	this.scribble2.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble2).wait(1));

	// scribble1
	this.scribble1 = new lib.scribble1();
	this.scribble1.name = "scribble1";
	this.scribble1.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribbleClip, new cjs.Rectangle(-5.3,-210.1,1236.6,810.1), null);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_11 = new cjs.Graphics().p("AgcBFIAAAAQgHgHAAgJQgBgJAHgHIAAAAQAGgHAJAAQAJgBAGAGIAAABQAHAGABAJQAAAJgGAHIAAAAQgGAHgJAAIgBAAQgIAAgHgFgAgNA6QABAAABAAQAAAAABAAQAAAAABgBQAAAAABgBIAAAAQAAAAABgBQAAAAAAgBQAAAAABgBQAAgBAAAAQAAgBgBAAQAAgBAAgBQAAAAgBgBQAAAAAAgBIgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBABgBAAQAAAAAAABIgBAAQAAAAAAABQgBAAAAABQAAAAAAABQAAABAAAAQAAABAAABQAAAAAAABQABAAAAABQAAAAABABIAAAAQAAAAABABQAAAAABAAQABAAAAAAQABAAAAAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AgcBFIAAAAQgHgHAAgJQgBgKAGgHIABAAQAGgHAJAAQAKgBAGAHIAAAAQAHAGABAKQAAAJgGAHIgBAAQgFAHgJABIgCAAQgIAAgHgGgAgMA6QADAAABgCIAAAAQACgCAAgDQAAAAAAgBQAAAAgBgBQAAgBAAAAQAAgBgBAAIAAAAQgBgBAAAAQgBAAAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAQgBABAAAAQgBAAAAAAQgBABAAAAIAAAAQgBABAAAAQAAABgBABQAAAAAAABQAAAAAAABQAAADACACIAAAAQACABADAAg");
	var mask_graphics_13 = new cjs.Graphics().p("AgcBFIAAAAQgIgHgBgKQAAgLAHgHIAAAAQAHgIAKAAQALgBAHAHIAAAAQAHAHABALQAAAKgHAIIAAAAQgGAHgKABIgCAAQgJAAgHgHgAgLA6QADAAACgDIAAABQACgDAAgDQAAgDgCgCIgBAAQgCgCgDABQgDAAgCACIAAAAQgCACAAADQABADACACIAAAAQACACADAAg");
	var mask_graphics_14 = new cjs.Graphics().p("AgdBGIAAAAQgJgIgBgMQAAgMAIgJIAAAAQAIgJAMAAQALgBAJAIIAAAAQAJAIABAMQAAAMgIAJIAAAAQgIAJgLABIgCAAQgLAAgIgIgAgJA5QADAAADgDIAAAAQACgCAAgEQAAgDgDgCIAAgBQgCgCgEAAQgDABgDACIAAAAQgCADAAADQAAADADADIAAAAQACACAEAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AgeBIIAAAAQgLgKgBgPQAAgOAJgLIABAAQAKgLAOgBQAOAAAKAJIABABQAKAJABAPQABAPgKAKIAAABQgKAKgOABIgCAAQgNAAgKgJgAgGA4QAEgBACgDIAAAAQADgDAAgEQgBgEgCgDIAAAAQgDgDgEABQgEAAgDADIAAAAQgDADABAEQAAAEADADIAAAAQADADAEAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AggBKIAAAAQgNgNgBgSQgBgSAMgOIAAAAQANgMASgBQARgBAOALIAAAAQANANABASQABATgMANIAAAAQgNAOgRAAIgCAAQgRAAgNgLgAgCA2QAFgBADgDIAAAAQAEgEAAgFQgBgGgDgDIgBAAQgDgEgFABQgFAAgDADIAAABQgEAEAAAFQABAFADADIAAAAQAEAEAFAAg");
	var mask_graphics_17 = new cjs.Graphics().p("AglBNIAAAAQgSgQgBgXQgBgYAQgQIAAgBQAQgRAXgBQAXgBARAQIAAAAQASAPABAXQABAYgQARIAAAAQgQASgYABIgCAAQgVAAgQgPgAABAzQAGAAAFgFIAAAAQAEgFAAgHQAAgGgFgFIAAAAQgFgEgGAAQgGAAgFAFIAAAAQgEAFAAAHQAAAGAFAFIAAAAQAFAEAGAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AgwBRIAAAAQgXgVgBgeQgCgeAVgWIAAAAQAVgWAegBQAdgCAWAUIABABQAWAUABAdQACAfgVAWIAAAAQgVAXgeABIgDAAQgbAAgVgTgAABAwQAJgBAGgGIgBAAQAGgHAAgIQgBgJgGgGIAAAAQgGgFgIAAQgIAAgGAGIgBABQgFAGAAAJQABAIAGAGIAAAAQAGAGAIAAg");
	var mask_graphics_19 = new cjs.Graphics().p("Ag/BWIAAAAQgdgagCgoQgBgmAagdIAAAAQAbgdAngBQAmgCAdAaIAAAAQAdAbACAmQABAngaAdIAAAAQgbAdgnACIgEAAQgkAAgbgZgAABArQALgBAIgIIAAAAQAHgIAAgLQgBgLgIgHIAAAAQgIgHgKAAQgLABgIAIIAAAAQgHAHAAALQABALAIAIIAAAAQAIAHAKAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AhQBcIAAAAQglghgCgyQgDgxAiglIAAgBQAigkAxgCQAxgCAlAhIABAAQAkAiACAyQADAxgiAkIAAABQgiAkgyADIgFAAQgtAAgjgggAABAlQAPAAAKgLIgBAAQAKgKgBgOQAAgNgKgKIgBAAQgLgKgNABQgOABgJAKIgBAAQgJALABANQAAAOALAKIAAgBQAKAKANgBg");
	var mask_graphics_21 = new cjs.Graphics().p("AhjBuIgBAAQgtgqgDg9QgDg9AqguIAAAAQAqgtA9gDQA8gDAuApIABABQAtAqADA9QADA9gqAtIAAABQgqAtg9ADIgHAAQg4AAgrgngAACAqQASgBAMgNIgBABQAMgNgBgRQAAgRgNgMIgBgBQgNgLgQABQgRABgMAMIgBABQgLANABAQQAAARANAMIAAAAQANAMARgBg");
	var mask_graphics_22 = new cjs.Graphics().p("Ah2CDIAAAAQg2gygEhJQgDhIAxg2IABgBQAxg1BJgEQBIgDA2AwIABABQA2AyADBJQADBIgxA2IAAABQgyA1hJAEIgJAAQhCAAgzgugAACAyQAVgBAPgPIgBAAQAOgPgBgUQgBgVgOgOIgBgBQgQgNgTABQgVABgOAOIgBABQgNAQABATQABAVAPAOIAAAAQAPAOAUgBg");
	var mask_graphics_23 = new cjs.Graphics().p("AiHCVIAAAAQg+g4gDhUQgEhSA4g+IAAgBQA5g9BTgDQBSgEA+A3IAAABQA+A5AEBTQADBSg4A+IAAAAQg5A+hTADIgKABQhMAAg6g1gAACA5QAYgBARgSIAAABQAQgSgCgXQgBgXgRgQIgBgBQgRgPgXABQgXABgQARIgBABQgPARABAXQABAXARAQIAAAAQASAQAWgBg");
	var mask_graphics_24 = new cjs.Graphics().p("AiVCkIAAAAQhEg+gEhcQgEhbA9hEIABgBQA/hDBbgEQBagEBEA9IABABQBEA+AEBcQAEBbg+BEIAAAAQg+BEhcAEIgLAAQhUAAhAg6gAADA/QAagBASgUIAAABQASgUgCgZQgBgagTgSIgBAAQgTgRgZABQgaABgRATIgBABQgRATABAZQABAaATASIAAgBQAUASAZgBg");
	var mask_graphics_25 = new cjs.Graphics().p("AigCxIAAgBQhJhCgFhjQgEhiBChJIABgBQBDhIBigEQBhgFBKBBIABABQBIBEAFBiQAEBihCBJIgBAAQhDBJhiAEIgMABQhaAAhFg+gAADBEQAcgCAUgVIgBABQATgVgBgbQgBgcgUgTIgBgBQgVgSgbABQgcACgTATIgBABQgSAVABAbQABAcAVATIAAAAQAVATAbgBg");
	var mask_graphics_26 = new cjs.Graphics().p("AipC7IAAgBQhNhGgFhoQgFhnBGhOIABgBQBHhMBngFQBngEBNBFIACABQBMBGAFBoQAFBohHBNIAAAAQhHBNhoAFIgMAAQhfAAhJhBgAADBHQAegBAVgWIgBAAQAUgWgBgcQgCgegVgUIgBgBQgWgTgdABQgdACgUAVIgBABQgTAWABAcQACAeAVAUIAAgBQAWAVAdgCg");
	var mask_graphics_27 = new cjs.Graphics().p("AiwDCIAAAAQhQhJgFhtQgFhrBIhRIABgBQBKhPBsgFQBrgFBQBIIACABQBPBKAFBsQAFBshJBQIAAAAQhKBQhsAFIgNAAQhjAAhMhEgAADBKQAfgBAWgXIgBAAQAVgXgBgdQgCgfgWgVIgBgBQgXgUgeACQgeABgVAWIgBABQgUAXABAdQACAfAWAVIAAAAQAXAVAegCg");
	var mask_graphics_28 = new cjs.Graphics().p("Ai1DIIAAAAQhThMgFhwQgGhuBLhTIACgCQBMhRBugFQBvgFBTBKIABABQBSBMAFBwQAGBvhMBSIAAABQhMBShwAFIgNAAQhmAAhOhGgAADBNQAggCAWgYIAAABQAWgYgCgfQgBgfgXgWIgBgBQgYgUgfABQgfACgWAWIgBABQgUAYABAfQABAfAYAWIgBgBQAYAWAfgBg");
	var mask_graphics_29 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_30 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_31 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_32 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_33 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_34 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_35 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_36 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_37 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_38 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_39 = new cjs.Graphics().p("Ai5DNIgBgBQhUhNgGhyQgFhxBNhWIABgBQBOhTBxgFQBxgGBVBMIABABQBVBOAFByQAFByhNBUIgBABQhNBUhzAFIgNABQhpAAhPhIgAADBPQAhgCAXgZIAAABQAVgYgBggQgCgggXgWIgBgBQgZgVgfABQggACgWAXIgBABQgVAYABAgQACAgAYAWIgBAAQAZAWAfgBg");
	var mask_graphics_40 = new cjs.Graphics().p("Ai8DQIAAgBQhWhOgGh0QgFhzBOhWIABgCQBPhUBzgFQBygGBXBNIABABQBVBPAGB0QAFBzhOBWIgBABQhPBVhzAFIgPABQhpAAhRhJgAADBQQAigCAXgZIgBABQAXgZgCggQgCgggXgXIgCgBQgYgVggABQggACgXAXIgBABQgVAZABAgQACAhAYAWIAAgBQAYAXAggBg");
	var mask_graphics_41 = new cjs.Graphics().p("AjFDaIAAgBQhahSgGh6QgGh4BShaIABgCQBThYB4gGQB4gFBbBQIABACQBZBSAGB5QAFB5hSBaIAAABQhTBZh5AGIgPAAQhuAAhVhMgAAEBTQAjgBAXgaIAAAAQAXgZgBgiQgCgigZgYIgBgBQgagWghACQgiABgYAZIgBABQgWAaABAhQACAiAZAYIAAgBQAaAYAigCg");
	var mask_graphics_42 = new cjs.Graphics().p("AjWDtIgBgBQhhhZgHiEQgGiDBZhjIABgBQBahgCDgGQCDgGBiBXIABACQBiBZAGCEQAGCEhaBhIAAABQhaBhiEAGIgQABQh4AAhchTgAAEBbQAmgCAagcIAAAAQAZgcgCgkQgCglgbgaIgBgBQgcgYglABQgkACgaAbIgBABQgZAcACAkQACAmAbAZIAAAAQAcAZAlgBg");
	var mask_graphics_43 = new cjs.Graphics().p("AjzEMIAAgBQhvhlgHiVQgHiVBlhvIABgCQBmhtCUgGQCUgHBvBjIACABQBuBmAHCVQAHCVhlBvIgBABQhlBuiWAGIgSABQiIAAhphegAAEBnQArgCAeggIAAAAQAcgfgCgqQgCgqgegdIgCgBQgggcgpACQgqACgdAeIgBACQgcAgACApQACAqAfAdIAAgBQAgAdApgBg");
	var mask_graphics_44 = new cjs.Graphics().p("AkeE8IgBgBQiCh3gIiwQgJivB3iEIABgCQB4iACvgIQCvgICDB1IACABQCCB4AHCwQAICwh3CCIAAABQh4CCiwAIIgWABQiggBh7hugAAFB5QAzgDAjglIgBABQAiglgCgyQgDgxgkgiIgCgCQglgggxACQgxACgiAkIgCACQghAlADAxQACAyAlAiIgBgBQAmAiAxgCg");
	var mask_graphics_45 = new cjs.Graphics().p("AlcGAIgBgBQieiRgKjWQgKjVCPigIADgCQCSicDUgKQDUgJCfCNIADADQCeCRAJDWQAKDWiRCeIAAABQiSCejWAKIgbAAQjDAAiViGgAAGCTQA+gDAqguIAAABQApgtgDg8QgDg8gsgqIgCgCQgugng7ADQg8ADgqArIgCACQgnAuACA7QADA9AtApIgBgBQAuApA8gCg");
	var mask_graphics_46 = new cjs.Graphics().p("AmpHVIgBgBQjCixgMkGQgMkECvjDIADgDQCyi/EDgMQEEgLDDCtIADACQDBCzALEFQAMEFixDBIAAACQiyDBkGALIghABQjuAAi2ikgAAIC0QBLgEA0g4IgBABQAyg3gEhJQgDhKg1gzIgDgCQg4gwhJADQhJAEgzA0IgCADQgxA4AEBIQADBLA3AyIgBgBQA4AzBKgDg");
	var mask_graphics_47 = new cjs.Graphics().p("An5IsIAAgCQjmjRgPk3QgOk0DQjnIADgEQDUjiEzgOQE0gODnDNIADAEQDlDTAOE1QAOE2jSDmIAAABQjUDlk1AOIgoABQkaAAjZjDgAAJDVQBZgEA+hDIgBACQA7hBgEhYQgEhXg/g8IgEgDQhCg5hXAEQhWAEg8A+IgDAEQg6BCAEBWQAEBYBBA8IgBgCQBDA8BXgDg");
	var mask_graphics_48 = new cjs.Graphics().p("Ao7J1IgBgCQkEjsgRlgQgQleDskFIADgEQDvkAFcgQQFdgQEFDpIAEADQEDDvAQFfQAQFfjuEDIAAACQjvEDlfAQIgtABQk/AAj1jdgAAKDxQBlgFBGhLIgBACQBDhKgFhjQgFhjhHhEIgEgEQhLhAhiAFQhiAFhEBGIgDAEQhBBKAEBiQAEBkBKBEIgBgCQBLBEBjgEg");
	var mask_graphics_49 = new cjs.Graphics().p("ApuKtIgBgCQkbkCgSl/QgSl8EBkdIAEgEQEEkXF7gRQF7gREdD9IAEAEQEaEEARF9QARF+kCEbIgBACQkEEal+ARIgwABQlcAAkLjwgAALEGQBugFBMhSIgBACQBJhQgFhsQgGhshNhKIgFgEQhRhGhrAFQhqAGhLBMIgEAFQhGBRAFBqQAEBtBRBKIgCgDQBSBLBsgFg");
	var mask_graphics_50 = new cjs.Graphics().p("AqTLWIgBgCQkskRgTmWQgTmTEQkuIAEgFQEUknGRgSQGTgSEtEMIAEAEQErEUASGUQASGUkREsIgBACQkUErmUASIg0ABQlxAAkaj+gAAMEWQB1gGBPhWIgBACQBOhVgGhzQgFhyhThOIgEgEQhWhKhyAFQhxAFhOBSIgEAEQhLBWAFBxQAFBzBVBOIgBgCQBXBOBygEg");
	var mask_graphics_51 = new cjs.Graphics().p("AquLzIgBgCQk4kcgTmmQgUmkEbk6IAEgFQEfkyGhgTQGjgTE5EWIAFAFQE2EeATGlQAUGlkdE4IgBACQkfE2mkATIg2ABQmAAAkmkIgAAMEhQB6gGBThaIgBACQBQhYgGh3QgFh3hWhSIgFgEQhZhNh2AGQh2AFhRBVIgFAFQhNBZAFB1QAFB4BYBRIgBgCQBaBSB3gFg");
	var mask_graphics_52 = new cjs.Graphics().p("ArAMHIgBgCQlBkkgUmxQgUmvEilCIAFgFQEmk7GtgUQGugTFCEeIAFAEQE+EnAUGwQAUGwklFAIgBACQkmE/mwAUIg3ABQmLAAktkQgAANEpQB8gGBWhdIgCADQBThbgGh7QgGh5hYhUIgEgFQhdhPh5AGQh4AGhUBWIgFAFQhPBcAFB5QAFB7BbBTIgBgCQBdBUB6gFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_graphics_11,x:-3.6172,y:7.4422}).wait(1).to({graphics:mask_graphics_12,x:-3.651,y:7.4755}).wait(1).to({graphics:mask_graphics_13,x:-3.7611,y:7.584}).wait(1).to({graphics:mask_graphics_14,x:-3.9636,y:7.7835}).wait(1).to({graphics:mask_graphics_15,x:-4.2795,y:8.0947}).wait(1).to({graphics:mask_graphics_16,x:-4.736,y:8.5444}).wait(1).to({graphics:mask_graphics_17,x:-5.0611,y:9.1663}).wait(1).to({graphics:mask_graphics_18,x:-5.0917,y:9.9987}).wait(1).to({graphics:mask_graphics_19,x:-5.1312,y:11.0709}).wait(1).to({graphics:mask_graphics_20,x:-5.1791,y:12.3704}).wait(1).to({graphics:mask_graphics_21,x:-5.2317,y:12.7059}).wait(1).to({graphics:mask_graphics_22,x:-5.2833,y:12.7183}).wait(1).to({graphics:mask_graphics_23,x:-5.329,y:12.7293}).wait(1).to({graphics:mask_graphics_24,x:-5.367,y:12.7384}).wait(1).to({graphics:mask_graphics_25,x:-5.3977,y:12.7458}).wait(1).to({graphics:mask_graphics_26,x:-5.4222,y:12.7517}).wait(1).to({graphics:mask_graphics_27,x:-5.4415,y:12.7563}).wait(1).to({graphics:mask_graphics_28,x:-5.4565,y:12.76}).wait(1).to({graphics:mask_graphics_29,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_30,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_31,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_32,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_33,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_34,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_35,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_36,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_37,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_38,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_39,x:-5.1702,y:12.5012}).wait(1).to({graphics:mask_graphics_40,x:-5.1717,y:12.4997}).wait(1).to({graphics:mask_graphics_41,x:-5.1768,y:12.4945}).wait(1).to({graphics:mask_graphics_42,x:-5.1864,y:12.4844}).wait(1).to({graphics:mask_graphics_43,x:-5.2024,y:12.4678}).wait(1).to({graphics:mask_graphics_44,x:-5.2267,y:12.4425}).wait(1).to({graphics:mask_graphics_45,x:-5.2613,y:12.4065}).wait(1).to({graphics:mask_graphics_46,x:-5.3047,y:12.3615}).wait(1).to({graphics:mask_graphics_47,x:-5.3489,y:12.3155}).wait(1).to({graphics:mask_graphics_48,x:-5.3862,y:12.2767}).wait(1).to({graphics:mask_graphics_49,x:-5.4146,y:12.2472}).wait(1).to({graphics:mask_graphics_50,x:-5.4353,y:12.2256}).wait(1).to({graphics:mask_graphics_51,x:-5.4502,y:12.2101}).wait(1).to({graphics:mask_graphics_52,x:-5.2374,y:11.9546}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// Layer_2
	this.instance = new lib.doodle1_2();
	this.instance.setTransform(1.9,17.35,1,1,0,0,0,14.5,16.6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).to({_off:true},42).wait(7));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.3,13.4,24.2);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-13.2,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Poplines
	this.popLeft = new lib.popRight();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-114.2,0.2,1,1,0,0,180,4.8,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(14.8,0.2,1,1,0,0,0,4.8,11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.popRight},{t:this.popLeft}]}).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-99.1,-13.4,1,1,0,0,0,1.5,0.2);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-100.6,-16.6,100,33), null);


(lib.doodleClip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// doodle5
	this.doodle5 = new lib.doodle5();
	this.doodle5.name = "doodle5";
	this.doodle5.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle5).wait(1));

	// doodle4
	this.doodle4 = new lib.doodle4();
	this.doodle4.name = "doodle4";
	this.doodle4.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle4).wait(1));

	// doodle3
	this.doodle3 = new lib.doodle3();
	this.doodle3.name = "doodle3";
	this.doodle3.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle3).wait(1));

	// doodle2
	this.doodle2 = new lib.doodle2();
	this.doodle2.name = "doodle2";
	this.doodle2.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle2).wait(1));

	// doodle1
	this.doodle1 = new lib.doodle1();
	this.doodle1.name = "doodle1";
	this.doodle1.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodleClip, new cjs.Rectangle(0,0,300,600), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// navHits
	this.hit5 = new lib.option_hit();
	this.hit5.name = "hit5";
	this.hit5.setTransform(194.65,472.6,1.3315,3.789,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit5, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit4 = new lib.option_hit();
	this.hit4.name = "hit4";
	this.hit4.setTransform(173.4,472.6,1.3315,3.789,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit4, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(151.8,472.6,1.3315,3.789,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(130.5,472.6,1.3315,3.789,0,0,0,0,0.2);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(108.95,472.6,1.3315,3.789,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hitNext = new lib.option_hit();
	this.hitNext.name = "hitNext";
	this.hitNext.setTransform(225.5,472,2.51,3.942,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.hitNext, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hitPrev = new lib.option_hit();
	this.hitPrev.name = "hitPrev";
	this.hitPrev.setTransform(77.05,472.4,2.6286,3.9418,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hitPrev, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hitPrev},{t:this.hitNext},{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit4},{t:this.hit5}]}).wait(1));

	// hit
	this.hit = new lib.option_hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,300,18.7497,37.0375);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// introLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// nav
	this.nav = new lib.Page_indicator();
	this.nav.name = "nav";
	this.nav.setTransform(174.4,473.5,1.3941,1.3941,0,0,0,59.1,6.1);

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(169.1,135.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// CTA_txt
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(99.2,550.6,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(150.2,550.9,1.0746,1.0746,0,0,0,-50.7,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// bgScreens
	this.screens = new lib.bgScreens();
	this.screens.name = "screens";
	this.screens.setTransform(124,94.5,1,1,0,0,0,124,94.5);

	this.timeline.addTween(cjs.Tween.get(this.screens).wait(1));

	// doodle
	this.doodle = new lib.doodleClip();
	this.doodle.name = "doodle";
	this.doodle.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(27.45,347.65,1.49,1.49,0,0,0,125.8,52.8);
	this.grid.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.scribbleClip();
	this.scribble.name = "scribble";
	this.scribble.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-171.1,-210.1,1402.3999999999999,856.8000000000001), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
				
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "subh") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillSubHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 12
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillSubHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillSmallPrint = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var img1 = mc.screens.img1
		
		exportRoot.init_img1_x = mc.screens.img1.x;
		exportRoot.init_img2_x = mc.screens.img2.x;
		exportRoot.init_img3_x = mc.screens.img3.x;
		exportRoot.init_img4_x = mc.screens.img4.x;
		exportRoot.init_img5_x = mc.screens.img5.x;
		
		var init_headline_x 
		
		this.runBanner = function() {
			
				var maxNav = 5	
				mc.cta.alpha=1
			
				var nxt = mc.hitNext
				var prv = mc.hitPrev
				var hit1 = mc.hit1
				var hit2 = mc.hit2
				var hit3 = mc.hit3
				var hit4 = mc.hit4
				var hit5 = mc.hit5
				var hit6 = mc.hit6
			
				var initXpos = 0
				var initOffset = 325
					
				var subHeadPos = exportRoot.headline1.x
			
				var prevSelection = 0
				exportRoot.currentSelection = 1
			
				var nav = mc.nav
			
				hit1.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 1;
						amoAd.onInteraction('Dot1 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit2.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 2;
						amoAd.onInteraction('Dot2 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit3.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 3;
						amoAd.onInteraction('Dot3 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit4.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 4;
						amoAd.onInteraction('Dot4 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit5.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 5;
						amoAd.onInteraction('Dot5 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				nxt.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						exportRoot.animInProgress=true
						exportRoot.getSelectionId("next")
						amoAd.onInteraction('Next Click', exportRoot.currentSelection-1);
						exportRoot.gotoNextNav()
						exportRoot.scribbleAnim()
						exportRoot.nextScene();
					}
				});

				prv.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						exportRoot.animInProgress=true
						exportRoot.getSelectionId("prev")
						amoAd.onInteraction('Prev Click', exportRoot.currentSelection-1);
						exportRoot.gotoNextNav();
						exportRoot.scribbleAnim()
						exportRoot.prevScene();
					}
				});
				
				exportRoot.gotoNextNav = function() {
					for (var i=1;i<=maxNav;i++) {
						if (nav["dot_"+i].currentFrame > 15) nav["dot_"+i].gotoAndPlay("deselected")
					}
					nav["dot_"+exportRoot.currentSelection].gotoAndPlay("selected");			
				}
				
				exportRoot.getSelectionId = function(direction) {
					prevSelection = exportRoot.currentSelection
					if (direction == "next") {
						if (exportRoot.currentSelection == maxNav) {
							exportRoot.currentSelection = 1
						} else {
							exportRoot.currentSelection++
						}
					} else if (direction == "prev") {
						if (exportRoot.currentSelection == 1) {
							exportRoot.currentSelection = maxNav
						} else {
							exportRoot.currentSelection--
						}
					}
				}
				
				exportRoot.subHeadMoveCheck = function() {
				}
				
				exportRoot.scribbleAnim = function() {
						if (prevSelection > 0) {
							mc.scribble["scribble"+prevSelection].gotoAndPlay("out");
							mc.doodle["doodle"+prevSelection].gotoAndPlay("out");
							if (prevSelection==1 || prevSelection==2){
								mc.cta.popLeft.gotoAndPlay("out");
								mc.cta.popRight.gotoAndPlay("out");
								//alert("Hello");
							}
						}
						gsap.delayedCall(0.5,function(){
							mc.scribble["scribble"+exportRoot.currentSelection].gotoAndPlay("in");
							mc.doodle["doodle"+exportRoot.currentSelection].gotoAndPlay("in");
							if (exportRoot.currentSelection==1 || exportRoot.currentSelection==2){					
								mc.cta.popLeft.gotoAndPlay("in");
								mc.cta.popRight.gotoAndPlay("in");						
							}
						})
				}	
						
			exportRoot.tl0 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl0.add("left");
			exportRoot.tl0.add("mid");
			exportRoot.tl0.add("right");
			exportRoot.tl0.pause();
			
			exportRoot.tl1 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl1.add("right");
			exportRoot.tl1.from(mc.screens.img1.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl1.from(mc.screens.img1.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl1.from(mc.screens.img1.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl1.add("mid");
			exportRoot.tl1.to(mc.screens.img1.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl1.to(mc.screens.img1.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl1.to(mc.screens.img1.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl1.add("left");	
			exportRoot.tl1.pause();
			
			exportRoot.tl2 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl2.add("right");
			exportRoot.tl2.from(mc.screens.img2.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl2.from(mc.screens.img2.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl2.from(mc.screens.img2.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl2.add("mid");
			exportRoot.tl2.to(mc.screens.img2.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl2.to(mc.screens.img2.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl2.to(mc.screens.img2.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl2.add("left");
			exportRoot.tl2.pause();
			
			exportRoot.tl3 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl3.add("right");
			exportRoot.tl3.from(mc.screens.img3.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl3.from(mc.screens.img3.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl3.from(mc.screens.img3.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl3.add("mid");
			exportRoot.tl3.to(mc.screens.img3.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl3.to(mc.screens.img3.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl3.to(mc.screens.img3.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl3.add("left");
			exportRoot.tl3.pause();
			
			exportRoot.tl4 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl4.add("right");
			exportRoot.tl4.from(mc.screens.img4.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl4.from(mc.screens.img4.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl4.from(mc.screens.img4.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl4.add("mid");
			exportRoot.tl4.to(mc.screens.img4.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl4.to(mc.screens.img4.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl4.to(mc.screens.img4.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl4.add("left");
			exportRoot.tl4.pause();
			
			exportRoot.tl5 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl5.add("right");
			exportRoot.tl5.from(mc.screens.img5.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl5.from([mc.screens.img5.sub2, mc.screens.img5.sub2Shadow], 1, { x: "+=150", alpha: 0},"<");
			exportRoot.tl5.from(mc.screens.img5.sub3, 1, { x: "+=300", alpha: 0},"<");
			exportRoot.tl5.from(mc.screens.img5.sub2, .4, { rotation:"+=10"}, ">-.2");
			exportRoot.tl5.from(mc.screens.img5.sub3, .4, { rotation:"+=10"}, ">-.2");
			exportRoot.tl5.add("mid");
			exportRoot.tl5.to(mc.screens.img5.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl5.to([mc.screens.img5.sub2, mc.screens.img5.sub2Shadow], 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl5.to(mc.screens.img5.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl5.to(mc.screens.img5.sub2, .4, { rotation:"+=10"}, "<");
			exportRoot.tl5.to(mc.screens.img5.sub3, .4, { rotation:"+=10"}, "<+.2");
			exportRoot.tl5.add("left");
			exportRoot.tl5.pause();
			
				exportRoot.tlSubHeadMove = gsap.timeline();
		
				exportRoot.tlSubHeadMove.add("out");
				exportRoot.tlSubHeadMove.to(exportRoot.subheadline1, .5, { y: "-=24", ease:Power2.easeInOut});	
				exportRoot.tlSubHeadMove.add("in");
				
				exportRoot.tlSubHeadMove.pause();		
				
				init_headline_x = exportRoot.headline1[0].x
				
				exportRoot.nextScene = function() {
					exportRoot.subHeadMoveCheck(exportRoot.currentSelection);
								
					exportRoot.tlNext = gsap.timeline();
					exportRoot.tlNext.to(mc.screens["img"+exportRoot.currentSelection], 0, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]+initOffset/6, alpha: 0});		
					exportRoot.tlNext.to(exportRoot["headline"+exportRoot.currentSelection], 0, { x:init_headline_x+initOffset/3, alpha: 0});		
					
					if(prevSelection==0) {prevSelection=5;}
					exportRoot.tlNext.to(exportRoot["headline"+prevSelection], 0.6, { x:init_headline_x-initOffset/3, alpha: 0, ease:Power2.easeIn, stagger:0.03});
					exportRoot.tlNext.to(mc.screens["img"+prevSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]-initOffset/6, alpha: 0, ease:Power2.easeIn, onStart:function(){exportRoot["tl"+prevSelection].tweenFromTo("mid","left", {duration:0.6, ease:Power2.easeIn});}},"<+0.1");			
						
					exportRoot.tlNext.to(exportRoot["headline"+exportRoot.currentSelection], 0.6, { x:init_headline_x, alpha: 1, ease:Power2.easeOut, stagger:0.03},"<+0.3");
					exportRoot.tlNext.to(mc.screens["img"+exportRoot.currentSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"], alpha: 1, ease:Power2.easeOut, onStart:function(){exportRoot["tl"+exportRoot.currentSelection].tweenFromTo("right","mid", {duration:0.6, ease:Power2.easeOut});}, onComplete:function(){exportRoot.animInProgress=false;}},"<+0.2");
				}
				
				exportRoot.prevScene = function() {
					exportRoot.subHeadMoveCheck(exportRoot.currentSelection);
					
					exportRoot.tlBack = gsap.timeline();
					exportRoot.tlBack.to(mc.screens["img"+exportRoot.currentSelection], 0, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]-initOffset/6, alpha: 0});		
					exportRoot.tlBack.to(exportRoot["headline"+exportRoot.currentSelection], 0, { x:init_headline_x-initOffset/3, alpha: 0});		
					
					exportRoot.tlBack.to(mc.screens["img"+prevSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]+initOffset/6, alpha: 0, ease:Power2.easeIn, onStart:function(){exportRoot["tl"+prevSelection].tweenFromTo("mid","right", {duration:0.6, ease:Power2.easeIn});}});			
					exportRoot.tlBack.to(exportRoot["headline"+prevSelection], 0.6, { x:init_headline_x+initOffset/3, alpha: 0, ease:Power2.easeIn, stagger:0.03},"<+0.1");
						
					exportRoot.tlBack.to(mc.screens["img"+exportRoot.currentSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"], alpha: 1, ease:Power2.easeOut, onStart:function(){exportRoot["tl"+exportRoot.currentSelection].tweenFromTo("left","mid", {duration:0.6, ease:Power2.easeOut});}, onComplete:function(){exportRoot.animInProgress=false}},"<+0.3");
					exportRoot.tlBack.to(exportRoot["headline"+exportRoot.currentSelection], 0.6, { x:init_headline_x, alpha: 1, ease:Power2.easeOut, stagger:0.03},"<+0.2");
		
				}
				
				exportRoot.animStart = function() {
					exportRoot.tlText = gsap.timeline();			
					exportRoot.tlText.to([exportRoot.headline1,exportRoot.headline2,exportRoot.headline3,exportRoot.headline4,exportRoot.headline5,mc.screens.img1,mc.screens.img2,mc.screens.img3,mc.screens.img4,mc.screens.img5], 0, { alpha: 0, onStart:function(){exportRoot.nextScene(), exportRoot.gotoNextNav();}});
					exportRoot.tlText.to(exportRoot.subheadline1, 0, {x:"+=150", alpha: 0});
					exportRoot.tlText.to(exportRoot.subheadline1, .8, { x: "-=150", alpha: 1, ease:Power4.easeOut, stagger:0.05},">+.45");
					exportRoot.tlText.from(exportRoot.mainMC.nav, .8, { alpha:0, ease:Power4.easeOut},"<+.1");
					exportRoot.tlText.from([mc.cta,mc.txtCta], { duration: 0.8, y: "+=100", ease:Power4.easeOut, onStart:function(){mc.scribble.scribble1.play(),mc.doodle.doodle1.play(), mc.cta.popLeft.gotoAndPlay("in"), mc.cta.popRight.gotoAndPlay("in");}}, ">-0.6");
					//exportRoot.tlText.pause();
				}
					
				mc.logo_intro.gotoAndPlay(1);
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9968,0.9997,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-20.6,89.9,1248.1,556.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#DBDBDD",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1.png?1622718707018", id:"M365_FY22Q1BTS_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;