(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[88,392,79,64],[247,270,91,155],[669,252,93,158],[764,272,102,105],[0,392,86,63],[868,272,80,132],[950,272,48,47],[340,270,48,48],[340,320,46,47],[772,0,245,134],[0,270,245,120],[772,136,245,134],[395,0,375,250],[395,252,272,182],[0,0,393,268],[764,379,101,79]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Excel = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Group214 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Group225 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Group242x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Group25 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Layer2 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Layer4 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Layer5 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Layer62x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Layer72x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Layer82x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.SUR21_20H1_Surface_PPT_Collaboration_3x2_enUSNoPeople = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.UIFinalFrame = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("ApzNIQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwByhxAuMgi6AOGQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_54 = new cjs.Graphics().p("Ap3NKQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOFQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_55 = new cjs.Graphics().p("AqENPQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_56 = new cjs.Graphics().p("AqiNbQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_57 = new cjs.Graphics().p("ArVNwQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQByAwAuByQAvBygxBxQgwByhyAuMgi5AOFQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_58 = new cjs.Graphics().p("AsaOMQhxgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_59 = new cjs.Graphics().p("AtdOnQhxgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_60 = new cjs.Graphics().p("AuTO9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAvQBzAxAuByQAuBygxBxQgwBwhxAvMgi6AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_61 = new cjs.Graphics().p("Au8PNQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_62 = new cjs.Graphics().p("AvbPaQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQBzAwAuByQAuBygxBxQgwBxhyAuMgi5AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_63 = new cjs.Graphics().p("AvzPkQhxgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg6gZg");
	var mask_graphics_64 = new cjs.Graphics().p("AwHPsQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBxAvQByAxAuByQAuBygxBxQgvBwhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_65 = new cjs.Graphics().p("AwWPyQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBwAvQBzAxAuByQAuBygxBxQgvBwhyAuMgi6AOHQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_66 = new cjs.Graphics().p("AwiP3QhwgwguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAxAuByQAuBygxBwQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_67 = new cjs.Graphics().p("AwrP6QhwgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_68 = new cjs.Graphics().p("AwyP9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_69 = new cjs.Graphics().p("Aw3P/QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_70 = new cjs.Graphics().p("Aw6QAQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwBxhxAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_71 = new cjs.Graphics().p("Aw8QBQhwgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_72 = new cjs.Graphics().p("Aw8QBQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg6gZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:202.0962,y:86.5199}).wait(1).to({graphics:mask_graphics_54,x:201.7207,y:86.6713}).wait(1).to({graphics:mask_graphics_55,x:200.3452,y:87.2276}).wait(1).to({graphics:mask_graphics_56,x:197.4159,y:88.4121}).wait(1).to({graphics:mask_graphics_57,x:192.2778,y:90.4898}).wait(1).to({graphics:mask_graphics_58,x:185.33,y:93.2993}).wait(1).to({graphics:mask_graphics_59,x:178.6284,y:96.0092}).wait(1).to({graphics:mask_graphics_60,x:173.2948,y:98.166}).wait(1).to({graphics:mask_graphics_61,x:169.2189,y:99.8141}).wait(1).to({graphics:mask_graphics_62,x:166.0817,y:101.0827}).wait(1).to({graphics:mask_graphics_63,x:163.6368,y:102.0714}).wait(1).to({graphics:mask_graphics_64,x:161.716,y:102.8481}).wait(1).to({graphics:mask_graphics_65,x:160.2043,y:103.4594}).wait(1).to({graphics:mask_graphics_66,x:159.0208,y:103.938}).wait(1).to({graphics:mask_graphics_67,x:158.1068,y:104.3076}).wait(1).to({graphics:mask_graphics_68,x:157.4183,y:104.586}).wait(1).to({graphics:mask_graphics_69,x:156.9218,y:104.7867}).wait(1).to({graphics:mask_graphics_70,x:156.5909,y:104.9205}).wait(1).to({graphics:mask_graphics_71,x:156.4046,y:104.9959}).wait(1).to({graphics:mask_graphics_72,x:156.3462,y:105.0199}).wait(1));

	// Layer_3 copy 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FEF000").ss(60,1,1).p("AGkioItHFR");
	this.shape.setTransform(102.75,162.875);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AQ4K1MgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AQ4K6MgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AQ4LGMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AQ4LaMgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AQ4LyMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AQ4MNMgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AQ4MpMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AQ4NBMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AQ4NVMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB3QghB2hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AQ4NhMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AQ4NmMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-96.7896,y:70.4804}).wait(1).to({graphics:mask_1_graphics_45,x:-93.6755,y:70.912}).wait(1).to({graphics:mask_1_graphics_46,x:-84.6383,y:72.1637}).wait(1).to({graphics:mask_1_graphics_47,x:-70.5624,y:74.1133}).wait(1).to({graphics:mask_1_graphics_48,x:-52.8258,y:76.57}).wait(1).to({graphics:mask_1_graphics_49,x:-33.1646,y:79.2932}).wait(1).to({graphics:mask_1_graphics_50,x:-13.5033,y:82.0164}).wait(1).to({graphics:mask_1_graphics_51,x:4.2333,y:84.473}).wait(1).to({graphics:mask_1_graphics_52,x:18.3092,y:86.4226}).wait(1).to({graphics:mask_1_graphics_53,x:27.3464,y:87.6744}).wait(1).to({graphics:mask_1_graphics_54,x:30.4604,y:88.1054}).wait(19));

	// Layer_3 copy 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FEF000").ss(60,1,1).p("AI9CjIx5lF");
	this.shape_1.setTransform(87.5,129.75);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AqeI4Qhqg9gfh3Qggh2A8hrQA/hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_39 = new cjs.Graphics().p("Aq/I4Qhqg9gfh3Qggh2A9hrQA+hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AsbI4Qhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJuQB3ggBpA9QBsA+AgB3QAfB2g+BqQg9Brh2AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AugI7Qhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB3g+BqQg9Brh3AfMgkVAJvQgoAKgnAAQhLAAhHgpg");
	var mask_2_graphics_42 = new cjs.Graphics().p("Aw0JjQhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB2g+BqQg9Brh3AfMgkUAJvQgpALgnAAQhLAAhHgpg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Ay6KHQhqg9gfh3Qggh2A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBrA+AgB3QAgB2g/BqQg8Bqh3AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0WKgQhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJvQB3gfBqA9QBrA+AgB2QAfB3g+BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0fKpQhqg9ggh3Qgfh3A8hrQA/hqB2gfMAkVgJvQB3gfBqA9QBrA+AgB2QAgB3g/BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:210.152,y:47.6773}).wait(1).to({graphics:mask_2_graphics_39,x:206.8592,y:49.4475}).wait(1).to({graphics:mask_2_graphics_40,x:197.6331,y:54.4074}).wait(1).to({graphics:mask_2_graphics_41,x:184.3009,y:61.2431}).wait(1).to({graphics:mask_2_graphics_42,x:169.5032,y:65.2207}).wait(1).to({graphics:mask_2_graphics_43,x:156.171,y:68.8043}).wait(1).to({graphics:mask_2_graphics_44,x:146.9448,y:71.2843}).wait(1).to({graphics:mask_2_graphics_45,x:141.2573,y:72.1694}).wait(28));

	// Layer_3 copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FEF000").ss(60,1,1).p("AJcikIy3FJ");
	this.shape_2.setTransform(90.625,97);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARZIjMgkwgIBQh4gbhChnQhChnAah4QAah4BnhDQBohBB4AaMAkwAIBQB4AbBCBlQBDBpgbB4QgaB4hoBBQhKAxhTAAQggAAgigIg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-92.9368,y:26.509}).wait(1).to({graphics:mask_3_graphics_32,x:-89.047,y:27.3834}).wait(1).to({graphics:mask_3_graphics_33,x:-77.8467,y:29.9013}).wait(1).to({graphics:mask_3_graphics_34,x:-60.6868,y:33.759}).wait(1).to({graphics:mask_3_graphics_35,x:-39.6371,y:38.4911}).wait(1).to({graphics:mask_3_graphics_36,x:-17.2365,y:43.5269}).wait(1).to({graphics:mask_3_graphics_37,x:3.8132,y:48.259}).wait(1).to({graphics:mask_3_graphics_38,x:20.973,y:52.1166}).wait(1).to({graphics:mask_3_graphics_39,x:32.1733,y:54.6345}).wait(1).to({graphics:mask_3_graphics_40,x:36.0632,y:55.4651}).wait(33));

	// Layer_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FEF000").ss(60,1,1).p("AJVCCIypkE");
	this.shape_3.setTransform(91.3,67.45);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("ArPHpQhnhFgZh6QgYh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBoBGAZB6QAYB6hGBoQhEBnh7AZMglbAHdQggAHgeAAQhYAAhNg0g");
	var mask_4_graphics_20 = new cjs.Graphics().p("ArTHpQhnhFgYh6QgZh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBpBGAYB6QAYB6hGBoQhEBnh6AZMglcAHdQgfAHgfAAQhXAAhOg0g");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArfHpQhnhFgYh6QgYh6BEhpQBGhmB7gYMAlagHeQB7gYBnBEQBoBGAZB6QAYB7hGBnQhFBnh6AZMglbAHdQgfAGgfAAQhXAAhOgzg");
	var mask_4_graphics_22 = new cjs.Graphics().p("Ar1HoQhnhEgZh6QgYh7BFhoQBGhmB6gYMAlZgHeQB7gYBnBFQBoBFAYB7QAZB6hGBnQhFBnh6AZMglaAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_23 = new cjs.Graphics().p("AsbHoQhnhFgYh6QgYh6BEhoQBGhmB6gYMAlYgHdQB6gZBnBFQBoBGAZB6QAYB6hGBnQhEBnh6AYMglYAHdQggAHgeAAQhXAAhOg0g");
	var mask_4_graphics_24 = new cjs.Graphics().p("AtUHnQhnhEgYh6QgYh6BEhoQBGhmB6gYMAlVgHdQB5gYBnBFQBpBFAYB6QAYB6hGBnQhEBnh6AYMglVAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_25 = new cjs.Graphics().p("AulHnQhnhFgYh6QgZh5BFhoQBFhmB6gYMAlRgHcQB6gYBmBEQBoBGAZB6QAYB5hGBnQhEBnh6AYMglRAHcQgfAGgeAAQhXAAhNgzg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AwLHlQhnhEgYh5QgYh6BEhnQBGhmB5gYMAlLgHbQB6gYBmBFQBoBFAYB5QAZB6hGBmQhEBnh6AYMglLAHbQgfAGgfAAQhWAAhNg0g");
	var mask_4_graphics_27 = new cjs.Graphics().p("AxzHkQhnhEgYh5QgYh5BEhnQBGhmB5gYMAlGgHZQB5gZBmBFQBoBFAYB5QAYB5hFBmQhEBnh5AYMglHAHZQgfAHgeAAQhXAAhMg0g");
	var mask_4_graphics_28 = new cjs.Graphics().p("AzLHjQhmhEgYh4QgYh5BDhoQBGhlB5gYMAlBgHYQB5gZBmBFQBoBFAYB5QAYB4hFBnQhEBmh5AYMglCAHZQgfAGgeAAQhWAAhNg0g");
	var mask_4_graphics_29 = new cjs.Graphics().p("A0OHjQhmhEgYh5QgYh5BEhnQBFhlB5gYMAk+gHYQB5gYBmBEQBnBFAYB5QAYB5hFBmQhEBmh5AYMgk+AHYQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A0/HiQhlhEgYh4QgYh5BDhnQBFhlB5gYMAk8gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk8AHXQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A1CHiQhmhEgYh4QgYh5BEhnQBFhlB5gYMAk6gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk6AHXQggAGgeAAQhWAAhMgzg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A1BHiQhmhEgYh5QgYh4BEhnQBFhlB4gYMAk5gHWQB4gYBmBDQBnBFAYB5QAYB4hFBmQhEBmh4AYMgk5AHWQgfAHgeAAQhWAAhMgzg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:214.6102,y:3.3334}).wait(1).to({graphics:mask_4_graphics_20,x:214.2404,y:3.4806}).wait(1).to({graphics:mask_4_graphics_21,x:212.9875,y:3.9786}).wait(1).to({graphics:mask_4_graphics_22,x:210.5721,y:4.9385}).wait(1).to({graphics:mask_4_graphics_23,x:206.5928,y:6.5199}).wait(1).to({graphics:mask_4_graphics_24,x:200.5171,y:8.9344}).wait(1).to({graphics:mask_4_graphics_25,x:191.8775,y:12.3679}).wait(1).to({graphics:mask_4_graphics_26,x:181.0603,y:16.6668}).wait(1).to({graphics:mask_4_graphics_27,x:170.0151,y:21.0562}).wait(1).to({graphics:mask_4_graphics_28,x:160.7061,y:24.7557}).wait(1).to({graphics:mask_4_graphics_29,x:153.6244,y:27.57}).wait(1).to({graphics:mask_4_graphics_30,x:148.4436,y:29.629}).wait(1).to({graphics:mask_4_graphics_31,x:141.5638,y:31.1044}).wait(1).to({graphics:mask_4_graphics_32,x:136.4625,y:32.1336}).wait(41));

	// Layer_2
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FEF000").ss(60,1,1).p("AJ4iDIzvEH");
	this.shape_4.setTransform(94.8,41.2);
	this.shape_4._off = true;

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2,188,211.8);


(lib.woman_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ADzB+IAAh5QABgOgHgOQgGgOgNgIQg/gvhMgPQgEAAgEADQgfAbgpABQgngBgdgaQgFgFgIACQhIARg/AsQgMAIgHANQgHANAAANIAAB8IgQAAIAAh6QAAgSAJgSQAIgRARgLQBDguBRgSQAHgCAFAFQAPAQAVAHQAUAIAUgDQAegEAWgWQAHgIALADQBOARBCAuQARAMAJASQAKASgBAUIgBBvIAAAIg");
	this.shape.setTransform(25.9788,48.6729);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiuCyQgBgGADgEQAPgXAAgbIgDhgQgDg0AEgzQADgcARgYQASgXAagKQAhgPAlAAQAjAAAhAPQAWAKASAVQADACAEAAQAfgFAVARQASAPAEAdQAFAqgJAqIgPBFQgCAVAGAVQAIAUAPAPQADAEAAAGQgDAFgFABIg0AHIgBAAIgVgCQgRgCgMgLIgbgYQgFgCgEAAQgeAHgfgJQgGgBgDAEIgUATQgUARgXADIg8AHQgFAAgEgEgAA2hIQhBA3hWAGQgGAAgEAEQgFAFgBAFIABAUIABACQAHAvAmAcQAmAcAvgHQAsgIAcgjQAbgkgFgsQgBgYgTgOQgKgIgEgKQgGgLgEgOIgBAAg");
	this.shape_1.setTransform(25.9504,18.2257);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.woman_sub, new cjs.Rectangle(0,0,52,61.3), null);


(lib.userIcon3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer5();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.userIcon3, new cjs.Rectangle(0,0,46,47), null);


(lib.userIcon2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.userIcon2, new cjs.Rectangle(0,0,48,47), null);


(lib.userIcon1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer4();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.userIcon1, new cjs.Rectangle(0,0,48,48), null);


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdCXQMAAAkufMCY7AAAMAAAEufg");
	this.shape.setTransform(0.975,555.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.4,-412.3,978.8,1936);


(lib.pptLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group242x();
	this.instance.setTransform(0,0,0.82,0.82);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptLogo, new cjs.Rectangle(0,0,83.7,86.1), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(49.822,49.822,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(35.2132,49.822,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(49.822,35.2132,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(35.2132,35.2132,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(112.006,42.0513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(195.7754,42.6578,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(183.5643,42.5128,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(171.1018,42.5128,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(28.6,28.6,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.man_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkDB+IAAh5QAAgTAJgSQAJgRARgLQBCguBRgSQAHgCAFAFQAPAQAVAHQAUAIAVgDQAdgEAWgWQAIgIAKADQBOARBCAuQARAMAJASQAKASgBAUIAAB2IgQAAIAAh5QAAgOgHgNQgGgOgNgIQg+guhMgQQgFAAgEADQgYAVgeAGQgvAIglghQgIgGgJADQhHARg8ApQgNAJgIAOQgHAOABAPIAAB5g");
	this.shape.setTransform(25.9801,45.7338);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.5,0,1).p("AB6g0QgEAqgfAeQgDADgEADQgiAeguAAQgtAAgigeQgDgDgDgDQgjgigBgw");
	this.shape_1.setTransform(25.1125,22.7284);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ACCBTIgPgYIgJgPQgNgagZgOQgFgEgGAFQgkAcgTANQgVAQgaADIg6AIIgKAAIgYgBIgDAAQgDgBgBgDQgCgDABgCIALg+QARhBBIgUQAegKAeAFQAfAFAZATIAHACQAbABAUATQATATACAaQACAdgGAdIgGAgg");
	this.shape_2.setTransform(24.28,9.1388);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.man_sub, new cjs.Rectangle(0,0,52,58.3), null);


(lib.line_drawn_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape.setTransform(142.475,21.5678);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_drawn_sub, new cjs.Rectangle(-2,-2,289,47.2), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL7A/XMAAAh+tMCX3AAAMAAAB+tg");
	this.shape.setTransform(486,405.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(0,0,972,811), null);


(lib.iconArrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_27 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(27).call(this.frame_27).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_17 = new cjs.Graphics().p("AAOAVQgIgJAAgMQAAgLAIgIQAJgJAMAAQAMAAAJAJQAIAIAAALQAAAMgIAJQgJAIgMAAQgMAAgJgIg");
	var mask_graphics_18 = new cjs.Graphics().p("AgSAoQgQgRAAgXQAAgWAQgRQARgRAWAAQAYAAAQARQARARAAAWQAAAXgRARQgQARgYAAQgWAAgRgRg");
	var mask_graphics_19 = new cjs.Graphics().p("AgvA5QgYgXAAgiQAAghAYgXQAXgYAhAAQAhAAAYAYQAYAXAAAhQAAAigYAXQgYAYghAAQghAAgXgYg");
	var mask_graphics_20 = new cjs.Graphics().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	var mask_graphics_21 = new cjs.Graphics().p("AhVBWQgkgkAAgyQAAgxAkgkQAkgkAxAAQAyAAAkAkQAkAkAAAxQAAAygkAkQgkAkgyAAQgxAAgkgkg");
	var mask_graphics_22 = new cjs.Graphics().p("AhgBhQgpgoAAg5QAAg4ApgoQAogpA4AAQA5AAAoApQApAoAAA4QAAA5gpAoQgoApg5AAQg4AAgogpg");
	var mask_graphics_23 = new cjs.Graphics().p("AhqBrQgsgtAAg+QAAg9AsgtQAtgsA9AAQA+AAAtAsQAsAtAAA9QAAA+gsAtQgtAsg+AAQg9AAgtgsg");
	var mask_graphics_24 = new cjs.Graphics().p("AhxByQgvgvAAhDQAAhCAvgvQAvgvBCAAQBDAAAvAvQAvAvAABCQAABDgvAvQgvAvhDAAQhCAAgvgvg");
	var mask_graphics_25 = new cjs.Graphics().p("Ah2B3QgxgxAAhGQAAhFAxgxQAxgxBFAAQBGAAAxAxQAxAxAABFQAABGgxAxQgxAxhGAAQhFAAgxgxg");
	var mask_graphics_26 = new cjs.Graphics().p("Ah5B6QgzgzAAhHQAAhGAzgzQAzgzBGAAQBHAAAzAzQAzAzAABGQAABHgzAzQgzAzhHAAQhGAAgzgzg");
	var mask_graphics_27 = new cjs.Graphics().p("Ah6B7QgzgzAAhIQAAhHAzgzQAzgzBHAAQBIAAAzAzQAzAzAABHQAABIgzAzQgzAzhIAAQhHAAgzgzg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_graphics_17,x:6.4001,y:2.85}).wait(1).to({graphics:mask_graphics_18,x:7.7777,y:2.8501}).wait(1).to({graphics:mask_graphics_19,x:9.0103,y:2.8501}).wait(1).to({graphics:mask_graphics_20,x:9.9005,y:2.8502}).wait(1).to({graphics:mask_graphics_21,x:9.9006,y:2.8502}).wait(1).to({graphics:mask_graphics_22,x:9.9007,y:2.8502}).wait(1).to({graphics:mask_graphics_23,x:9.9008,y:2.8502}).wait(1).to({graphics:mask_graphics_24,x:9.9008,y:2.8502}).wait(1).to({graphics:mask_graphics_25,x:9.9009,y:2.8503}).wait(1).to({graphics:mask_graphics_26,x:9.9009,y:2.8503}).wait(1).to({graphics:mask_graphics_27,x:9.9009,y:2.8503}).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhNBRQgLgGgFgLQgGgKACgMQAJgqAagiQAOgTAQgNQAPgNAJgCQAKgCAKAFQALAEAFAKQAGAKAEAJIAHAUQAQAoAYALQAIAEADAHQAEAIgDAIQgDAIgIAEQgIAEgJgDQgNgGgKgIQgLgKgHgJQgOgTgIgWIgIgWIgOAQIgRAZQgIANgGAPQgEAJgCANQgBAMgHAFQgEAEgGAAIgGgBg");
	this.shape.setTransform(9.8181,8.2101);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(17).to({_off:false},0).wait(11));

	// Layer_3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Aljg2IAIgQQBJiPCag4QCgg6CcBIQCcBJA7ChQA3CZg+CUIgHAQg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Alhg7IAIgQQBKiOCag3QChg5CbBKQCcBKA5CiQA2CZhACUIgHAQg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AlbhLIAIgQQBOiMCcgyQCig0CZBOQCZBPA1CjQAyCbhFCRIgHAQg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AlRhoIAJgQQBWiHCegqQClgsCVBXQCUBXAsCmQAqCdhMCNIgJAQg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Ak/iTIAKgOQBhiAChgdQCogfCNBjQCNBiAeCoQAdChhXCHIgKAOg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AkijKIALgNQBvh1CjgKQCqgMCCByQCBBxALCrQALCjhmB8IgLANg");
	var mask_1_graphics_6 = new cjs.Graphics().p("Aj3kKIAOgLQB+hjChANQCsAOBvCDQBwCDgOCqQgNCjh3BsIgNAMg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Ai5lLIAPgIQCOhLCdAqQCmAtBVCVQBWCWgtClQgqCdiJBVIgPAJg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AhmmBIARgFQCagqCQBMQCYBPA0ClQAzCjhQCYQhMCRiXA1IgRAFg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AgBmdIARgBQCggDB6BtQCABzAJCsQAKCqhzCAQhtB6igAOIgRACg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AgvGUIgRgDICqsrIARAEQCcAnBZCJQBeCPgjCoQgkCoiQBeQhoBEh1AAQgjAAgmgHg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AiXFiIgQgHIF4rjIAPAIQCNBOAyCbQA1CjhOCZQhOCZijA2QhDAVhAAAQhWAAhTgng");
	var mask_1_graphics_12 = new cjs.Graphics().p("AjvEPIgNgLIIjpuIANALQB1BvAKCjQALCqhyCBQhxCBisALIgdABQiQAAhxhcg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AgvFCQihgbhhh/IgLgOIKjnhIAKAOQBYCGgbChQgcCpiMBkQhtBNh/AAQgjAAgmgGg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AiAEHQiZg7hGiRIgHgQIL2lOIAHAQQA7CVg7CYQg+CgidBFQhTAlhUAAQhKAAhLgdg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AjCDDQiMhVgriZIgFgRIMmjEIAEARQAgCdhVCLQhZCTioAoQg0ANgyAAQhtAAhlg+g");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aj2CZQh9hpgTifIgCgRIM6hGIACARQAIChhqB8QhvCDirAOQgUACgTAAQiTAAh0hig");
	var mask_1_graphics_17 = new cjs.Graphics().p("AACD7QirgIhzh/Qhuh4ACihIAAgRIM8AmIgBASQgNCfh5BuQh3BsieAAIgWAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AgoD2QiqgbhliLQhgiDATigIADgRIMyCCIgCARQgfCdiEBgQhuBPiBAAQgiAAgjgFg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:43.6916,y:-3.2463}).wait(1).to({graphics:mask_1_graphics_1,x:43.6907,y:-3.0744}).wait(1).to({graphics:mask_1_graphics_2,x:43.687,y:-2.5262}).wait(1).to({graphics:mask_1_graphics_3,x:43.677,y:-1.5563}).wait(1).to({graphics:mask_1_graphics_4,x:43.6565,y:-0.137}).wait(1).to({graphics:mask_1_graphics_5,x:43.6277,y:1.708}).wait(1).to({graphics:mask_1_graphics_6,x:43.627,y:3.832}).wait(1).to({graphics:mask_1_graphics_7,x:43.6656,y:5.9665}).wait(1).to({graphics:mask_1_graphics_8,x:43.6672,y:7.7598}).wait(1).to({graphics:mask_1_graphics_9,x:43.6097,y:8.7065}).wait(1).to({graphics:mask_1_graphics_10,x:43.6447,y:9.2304}).wait(1).to({graphics:mask_1_graphics_11,x:43.6674,y:11.0582}).wait(1).to({graphics:mask_1_graphics_12,x:43.6167,y:13.908}).wait(1).to({graphics:mask_1_graphics_13,x:43.6444,y:17.4449}).wait(1).to({graphics:mask_1_graphics_14,x:43.6867,y:21.142}).wait(1).to({graphics:mask_1_graphics_15,x:43.6761,y:24.6123}).wait(1).to({graphics:mask_1_graphics_16,x:43.6451,y:25.1137}).wait(1).to({graphics:mask_1_graphics_17,x:43.6003,y:25.1069}).wait(1).to({graphics:mask_1_graphics_18,x:43.3445,y:25.1275}).wait(10));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AARDiQiAgYhahdQgtgvgbg5Qgag2gGg8QgGg3APg0QACgIAHgFQAGgEAIABIAFACQAMAGACAOQABAGgCAFQgLAxAGAyQAFAyAXAsQA0BlBlA1QAvAaA1AKQAzAKAwgFQArgDApgQQAjgNAbgUQAJgGAKAAQAKgBAHAHQAHAGgBAJQgBAJgJAHQgiAaglANQgvATgxAFQgVACgUAAQglAAgkgHg");
	this.shape_1.setTransform(37.0325,26.4538);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(28));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,67.8,49.8);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIFinalFrame();
	this.instance.setTransform(0,0,1.3786,1.3785);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(0,0,375,250.9), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.comment3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer82x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.comment3, new cjs.Rectangle(0,0,123,67.3), null);


(lib.comment2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer72x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.comment2, new cjs.Rectangle(0,0,123,60), null);


(lib.comment1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer62x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.comment1, new cjs.Rectangle(0,0,123,67.3), null);


(lib.chart_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgBABIAAgBIADAAIAAABg");
	this.shape.setTransform(21.3012,0.8503);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AhuBXQgGAAgFgEQgEgEAAgHIAAiQQAAgGAEgEQAFgEAGAAIDeAAQAGAAAEAEQAEAEAAAGIAACQQAAAHgEAEQgEAEgGAAgAh4hIIAACQQAAAEADADQADADAEAAIDeAAQAJAAAAgKIAAiRIjwAAgABVhMIAEAAIAAgBIABAAIAAgEIgFAAIAAABIAAAAgABvhMIAAgBIgBgBIABgCIAAgBIgCACIgCgCIAAABIACACIgCABIAAABIACgCg");
	this.shape_1.setTransform(12.626,8.7255);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgCABIAAgBIAEAAIAAABg");
	this.shape_2.setTransform(19.1511,0.8003);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgBABIgBgBIABAAIADAAIABAAIgBABg");
	this.shape_3.setTransform(2.0759,3.7754);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgBABIgBgBIABAAIADAAIABAAIgBABg");
	this.shape_4.setTransform(2.0759,3.5754);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgBABIgBgBIABAAIADAAIABAAIgBABg");
	this.shape_5.setTransform(2.0759,3.3504);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgGAAQABgGAFAAQAHAAAAAGQAAAHgHAAQgFAAgBgHgAgFAAQABAFAEAAQAEAAABgEIgFAAIAAgBIAAgEQgFAAAAAEgAAFAAQAAgEgEAAIAAAEIAEAAIAAAAg");
	this.shape_6.setTransform(3.5009,3.5754);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_7.setTransform(1.7259,3.7754);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_8.setTransform(1.7259,3.7754);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_9.setTransform(1.7259,3.5754);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAAAAIAAAAIABAAIgBABg");
	this.shape_10.setTransform(1.7259,3.5754);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgRAKIAAgTIAiAAIAAATgAgOAIIAdAAIAAgPIgdAAg");
	this.shape_11.setTransform(3.0009,3.6254);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgQACQAAAAgBAAQAAAAgBAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAQABAAAAAAQABAAAAAAIAhAAQAAAAABAAQAAAAABAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQgBAAAAAAQgBAAAAAAg");
	this.shape_12.setTransform(19.0261,8.8505);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgCARIAAghQAAgBABAAQAAgBAAAAQAAAAABgBQAAAAAAAAQABAAAAAAQABABAAAAQAAAAAAABQAAAAABABIAAAhQgBABAAAAQAAABAAAAQAAAAgBABQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBg");
	this.shape_13.setTransform(17.3511,7.1254);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgZAaQgLgLAAgPQAAgOALgLQALgLAOAAQAPAAALALQALALAAAOQAAAPgLALQgLALgPAAQgOAAgLgLgAgWgVQgJAJAAAMQAAANAJAKQAKAJAMAAQANAAAKgJQAJgKAAgNQAAgMgJgJQgKgKgNAAQgMAAgKAKg");
	this.shape_14.setTransform(17.2511,8.8255);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgCAAQAAAAAAAAQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAAAQAAABAAABQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAgBAAgBg");
	this.shape_15.setTransform(8.176,9.9255);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgRAEQgFAAABgEQAAAAABgBQAAAAAAgBQABAAAAgBQABAAABAAIAjAAQAEAAAAADQAAABAAABQgBAAAAABQAAAAgBABQgBAAgBAAg");
	this.shape_16.setTransform(10.8169,9.9255);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgCAAQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_17.setTransform(8.176,8.8255);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgRAEQgEAAAAgEQAAgDAEAAIAjAAQABAAABAAQABABAAAAQABABAAAAQAAABAAAAQAAAEgEAAg");
	this.shape_18.setTransform(10.801,8.8255);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgCAAQAAAAAAgBQAAAAABgBQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAgBQAAAAAAgBg");
	this.shape_19.setTransform(8.176,7.7254);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgRAEQgEAAAAgEQAAgDAEAAIAjAAQABAAABAAQABABAAAAQABABAAAAQAAABAAAAQAAAEgEAAg");
	this.shape_20.setTransform(10.801,7.7254);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgRAKIAAgTIAiAAIAAATgAgOAJIAdAAIAAgQIgdAAg");
	this.shape_21.setTransform(3.0009,14.9255);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgRAKIAAgTIAiAAIAAATgAgOAIIAdAAIAAgPIgdAAg");
	this.shape_22.setTransform(3.0009,12.6755);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgRAKIAAgTIAiAAIAAATgAgOAIIAdAAIAAgPIgdAAg");
	this.shape_23.setTransform(3.0009,10.4255);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgRAKIAAgUIAiAAIAAAUgAgOAIIAdAAIAAgQIgdAAg");
	this.shape_24.setTransform(3.0009,8.1504);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AhVAwIAAhfICrAAIAABfgAhSAuIClAAIAAhbIilAAg");
	this.shape_25.setTransform(14.8261,8.7255);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgRAKIAAgTIAiAAIAAATgAgOAIIAdAAIAAgPIgdAAg");
	this.shape_26.setTransform(3.0009,5.8754);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_sub, new cjs.Rectangle(0,0,25.3,17.5), null);


(lib.bubbleR_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABXCVIg8g8IikAAQgFAAgDgDQgDgDAAgEIAAiNQAAgDACgEQAaggAJgqQADgIAIAAIDvAAQAEAAADADQADADAAAFIAADbQAAAEgDAEQgDADgEAAIgiAAIAAAzQAAAFgDADQgDADgEAAQgEAAgEgDgAh/g7IAAB/ICfAAQAEAAADADIAtAtIAAglQAAgFADgDQADgDAFAAIAhAAIAAjGIjcAAQgKAngZAgg");
	this.shape.setTransform(14.9265,15.1757);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bubbleR_sub, new cjs.Rectangle(0,0,29.9,30.4), null);


(lib.bubbleL_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhlCVQgDgEAAgEIAAg0IgiAAQgEAAgDgCQgDgEAAgFIAAjaQAAgEADgEQADgDAEAAIEUAAQAFAAADADQADAEAAAEIAAB/QAAAEgDADQgoAkgTA0QgCAIgIgBIhnAAIg8A8QgEADgEAAQgEAAgDgDgAh/BEIAhAAQAFAAADADQADAEAAADIAAAlIAtgsQADgDAEAAIBlAAQAUgzAmgkIAAhuIj/AAg");
	this.shape.setTransform(14.9256,15.2002);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bubbleL_sub, new cjs.Rectangle(0,0,29.9,30.4), null);


(lib.bub_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhGALQgEAAgDgDQgDgDgBgFQAAgDADgDQADgEAFAAICNAAQAKAAABAKQAAAKgKABg");
	this.shape.setTransform(8.2,1.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bub_line_sub, new cjs.Rectangle(0,0,16.4,2.2), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ai6E+QiShagninQgmieBQiMIAIgPILBGzIgJAPQhZCGifAlQgzAMgxAAQhvAAhmg/g");
	var mask_graphics_1 = new cjs.Graphics().p("AjdEWQiBhxgMiqQgLijBlh9IAMgNIJwIgIgMAOQhuB1ijALIgfABQiXAAh2hng");
	var mask_graphics_2 = new cjs.Graphics().p("AAkF7QiqgRhuiFQhtiEARiqQAPijB5hqIANgMIIPKAIgOALQhuBUiIAAQgWAAgWgCg");
	var mask_graphics_3 = new cjs.Graphics().p("AgCF1QimgthWiUQhWiVAsilQAqieCIhVIAPgKIGfLNIgPAJQhbAxhiAAQg2AAg4gPg");
	var mask_graphics_4 = new cjs.Graphics().p("AgjFsQidhHg8igQg9igBHidQBDiVCUg+IAQgGIElMHIgRAGQhCAWhBAAQhVAAhUgmg");
	var mask_graphics_5 = new cjs.Graphics().p("Ag+FVQiPhggiioQghioBfiPQBaiICcglIARgDICjMsIgSAEQgjAFghAAQh4AAhphGg");
	var mask_graphics_6 = new cjs.Graphics().p("AhSEvQh9h2gGirQgGirB1h+QBvh3CggLIASgBIAbM8IgRABQihgBh2hvg");
	var mask_graphics_7 = new cjs.Graphics().p("ABtGbQidgbhkiBQhoiJAWipQAXirCIhoQCAhkCgAQIASABIhsM2IgSgCg");
	var mask_graphics_8 = new cjs.Graphics().p("AALGSQiXg1hNiQQhRiXAyikQAyilCXhRQCPhNCbAqIARAEIjxMaIgQgFg");
	var mask_graphics_9 = new cjs.Graphics().p("AhSGCQiNhMg1ibQg3ihBMibQBMiaCjg3QCag0CSBCIAQAHIluLnIgQgIg");
	var mask_graphics_10 = new cjs.Graphics().p("AioFuQh/higbihQgcipBliMQBkiLCpgcQChgbCFBZIAPAKInjKhIgOgKg");
	var mask_graphics_11 = new cjs.Graphics().p("Aj0FWQhuh2ABikQAAiqB6h6QB5h5CrAAQCjAAB2BuIAMAMIpKJJIgMgMg");
	var mask_graphics_12 = new cjs.Graphics().p("Ak0E6QhYiGAbihQAcipCMhjQCMhkCoAcQChAbBiB/IALAOIqjHhIgKgOg");
	var mask_graphics_13 = new cjs.Graphics().p("AllEcQhCiTA1iZQA4ijCahMQCahMCiA4QCbA1BLCNIAIAQIroFtIgHgQg");
	var mask_graphics_14 = new cjs.Graphics().p("AmID7QgoibBNiPQBRiYClgxQCkgyCXBSQCQBNAzCXIAGARIsaDvIgFgRg");
	var mask_graphics_15 = new cjs.Graphics().p("AmbDZQgOigBjiAQBpiICrgWQCqgWCIBpQCBBjAaCeIADARIs3BqIgCgRg");
	var mask_graphics_16 = new cjs.Graphics().p("AmeC5IABgRQAMigB3hvQB+h1CrAGQCsAHB1B9QBvB3AACgIAAASg");
	var mask_graphics_17 = new cjs.Graphics().p("AmaBUIADgRQAmibCIhaQCPhfCoAiQCoAiBfCPQBbCHgbCfIgDARg");
	var mask_graphics_18 = new cjs.Graphics().p("AmRgMIAGgRQA/iTCVhDQCdhHCfA+QChA9BGCcQBDCUg0CYIgFARg");
	var mask_graphics_19 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_20 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_21 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_22 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_23 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_24 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_25 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_26 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_27 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_28 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_29 = new cjs.Graphics().p("AmDhkIAJgQQBViICdgrQClgtCVBWQCWBVAtCmQAqCdhLCOIgIAPg");
	var mask_graphics_30 = new cjs.Graphics().p("AmFhYIAIgPQBSiKCcgvQCkgxCXBSQCXBSAxClQAvCchICPIgIAQg");
	var mask_graphics_31 = new cjs.Graphics().p("AmKhAIAIgPQBMiOCag1QCig4CaBLQCbBMA4CiQA1CZhBCTIgIAQg");
	var mask_graphics_32 = new cjs.Graphics().p("AmPgaIAGgQQBCiSCXhAQCehCCfBBQCfBABDCfQA/CVg4CXIgGAQg");
	var mask_graphics_33 = new cjs.Graphics().p("AmWAdIAFgRQA0iWCQhOQCXhRCkAxQClAxBRCYQBOCOgpCcIgFARg");
	var mask_graphics_34 = new cjs.Graphics().p("AmcBtIADgSQAgicCEhgQCLhkCpAbQCqAbBlCMQBfCDgUCfIgCASg");
	var mask_graphics_35 = new cjs.Graphics().p("AmeDBQAEihBxh0QB4h7CsgCQCrgDB7B4QB1BxAICgIABARIs9ANIAAgSg");
	var mask_graphics_36 = new cjs.Graphics().p("AmQDwQggidBViLQBZiTCngoQCmgpCTBZQCLBVAsCZIAFARIsmDFIgEgRg");
	var mask_graphics_37 = new cjs.Graphics().p("AlUEoQhLiPAsicQAtimCVhVQCWhVCkAtQCeArBUCJIAJAPIrQGaIgIgPg");
	var mask_graphics_38 = new cjs.Graphics().p("AjdFeQhzhwgJijQgJiqBziAQBziACrgJQCjgJB7BoIANALIoqJoIgNgMg");
	var mask_graphics_39 = new cjs.Graphics().p("AgyGIQiRhEg9iXQhBifBDieQBDieCfhBQCXg9CWA6IAQAGIlDL7IgQgHg");
	var mask_graphics_40 = new cjs.Graphics().p("ACHGdQiegVhph9QhuiEAPiqQAPirCEhvQB8hoChAIIARACIhKM5IgRgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AhAFSQiOhigfipQgfioBiiOQBciGCcgiIARgEICWMvIgRADQggAFgeAAQh8AAhqhKg");
	var mask_graphics_42 = new cjs.Graphics().p("AgaFwQighAhEieQhEidBAifQA8iYCRhEIAQgIIFHL6IgQAGQhJAdhKAAQhNAAhMgfg");
	var mask_graphics_43 = new cjs.Graphics().p("AAMF1QiogihfiPQhgiPAhinQAgigCDheIAOgKIHMKxIgOAJQhkA9hvAAQgqAAgsgIg");
	var mask_graphics_44 = new cjs.Graphics().p("AAwF9QirgJhzh/Qh0iAAJiqQAIikBzhvIANgNIIsJmIgNAMQhyBgiVAAIgXAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AjdEXQiBhxgMirQgLijBlh8IAMgOIJwIhIgMANQhuB1ijALIgfABQiXAAh2hmg");
	var mask_graphics_46 = new cjs.Graphics().p("AjKEuQiMhkgbiqQgaigBZiGIAKgOIKgHlIgKAOQhjB+ihAaQglAGgiAAQiAAAhthPg");
	var mask_graphics_47 = new cjs.Graphics().p("Ai6E+QiShagninQgmieBQiMIAIgPILBGzIgJAPQhZCGifAlQgzAMgxAAQhvAAhmg/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:9.5024,y:38.1224}).wait(1).to({graphics:mask_graphics_1,x:7.6135,y:38.0779}).wait(1).to({graphics:mask_graphics_2,x:5.2629,y:38.0846}).wait(1).to({graphics:mask_graphics_3,x:2.5251,y:37.5085}).wait(1).to({graphics:mask_graphics_4,x:-0.4683,y:36.0962}).wait(1).to({graphics:mask_graphics_5,x:-3.6236,y:35.1784}).wait(1).to({graphics:mask_graphics_6,x:-6.8871,y:34.8094}).wait(1).to({graphics:mask_graphics_7,x:-4.8277,y:34.6532}).wait(1).to({graphics:mask_graphics_8,x:-1.4865,y:33.9695}).wait(1).to({graphics:mask_graphics_9,x:1.7135,y:32.7961}).wait(1).to({graphics:mask_graphics_10,x:4.6911,y:31.1679}).wait(1).to({graphics:mask_graphics_11,x:7.3263,y:29.087}).wait(1).to({graphics:mask_graphics_12,x:9.4947,y:26.5564}).wait(1).to({graphics:mask_graphics_13,x:11.1908,y:23.6979}).wait(1).to({graphics:mask_graphics_14,x:12.41,y:20.6279}).wait(1).to({graphics:mask_graphics_15,x:13.1157,y:17.4237}).wait(1).to({graphics:mask_graphics_16,x:13.2813,y:15.601}).wait(1).to({graphics:mask_graphics_17,x:13.6601,y:19.0037}).wait(1).to({graphics:mask_graphics_18,x:14.5666,y:22.2936}).wait(1).to({graphics:mask_graphics_19,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_20,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_21,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_22,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_23,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_24,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_25,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_26,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_27,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_28,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_29,x:15.8553,y:25.2113}).wait(1).to({graphics:mask_graphics_30,x:15.6307,y:24.7757}).wait(1).to({graphics:mask_graphics_31,x:15.2442,y:23.9669}).wait(1).to({graphics:mask_graphics_32,x:14.7076,y:22.6853}).wait(1).to({graphics:mask_graphics_33,x:14.073,y:20.7978}).wait(1).to({graphics:mask_graphics_34,x:13.4757,y:18.1342}).wait(1).to({graphics:mask_graphics_35,x:13.2241,y:15.0945}).wait(1).to({graphics:mask_graphics_36,x:12.6327,y:19.5826}).wait(1).to({graphics:mask_graphics_37,x:10.5355,y:24.7916}).wait(1).to({graphics:mask_graphics_38,x:6.4391,y:29.824}).wait(1).to({graphics:mask_graphics_39,x:0.5366,y:33.2908}).wait(1).to({graphics:mask_graphics_40,x:-5.7462,y:34.787}).wait(1).to({graphics:mask_graphics_41,x:-3.9737,y:35.1761}).wait(1).to({graphics:mask_graphics_42,x:0.3485,y:36.5027}).wait(1).to({graphics:mask_graphics_43,x:3.6166,y:38.1489}).wait(1).to({graphics:mask_graphics_44,x:5.9795,y:38.11}).wait(1).to({graphics:mask_graphics_45,x:7.6202,y:38.1132}).wait(1).to({graphics:mask_graphics_46,x:8.745,y:38.1366}).wait(1).to({graphics:mask_graphics_47,x:9.5024,y:38.1224}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjMATQAAgiADgqQAGhTAMgfQAOAnAvB1IBajCIAEDJICRh/IhJCuIBHgIQBLgKAPAAQgQAWh1BMIA1ATQA3AUAIAFIhlAv");
	this.shape.setTransform(20.5,21);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,43,44);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzCHIAAkNIPnAAIAAENg");
	this.shape.setTransform(50,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,0,100,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel();
	this.instance.setTransform(0,0,2.75,2.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add6, new cjs.Rectangle(0,0,217.3,176), null);


(lib.add5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(0,0,2.7499,2.7499);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add5, new cjs.Rectangle(0,0,277.8,217.3), null);


(lib.add4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group25();
	this.instance.setTransform(0,0,2.75,2.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add4, new cjs.Rectangle(0,0,236.5,173.3), null);


(lib.add3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group225();
	this.instance.setTransform(25.1,30.3,1.0164,1.0164);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add3, new cjs.Rectangle(0,0,121,203.5), null);


(lib.add2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group214();
	this.instance.setTransform(25.55,30.05,1.0794,1.0794);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add2, new cjs.Rectangle(0,0,123.8,206.3), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group332x();
	this.instance.setTransform(0,0,1.4,1.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(0,0,112,184.8), null);


(lib.UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// PPTIcon
	this.pptLogo = new lib.pptLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(14.65,12.1,1,1,0,0,0,53,32.6);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(187.5,125.5,1.01,1.01,0,0,0,187.5,125.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// comments
	this.comment3 = new lib.comment3();
	this.comment3.name = "comment3";
	this.comment3.setTransform(270.5,191.5,1,1,0,0,0,73.5,36.5);

	this.comment2 = new lib.comment2();
	this.comment2.name = "comment2";
	this.comment2.setTransform(272.9,142,1,1,0,0,0,75.5,33);

	this.comment1 = new lib.comment1();
	this.comment1.name = "comment1";
	this.comment1.setTransform(272,94,1,1,0,0,0,75,37);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.comment1},{t:this.comment2},{t:this.comment3}]}).wait(1));

	// userIcons
	this.userIcon3 = new lib.userIcon3();
	this.userIcon3.name = "userIcon3";
	this.userIcon3.setTransform(282.6,19.3,1,1,0,0,0,18.8,18.9);

	this.userIcon2 = new lib.userIcon2();
	this.userIcon2.name = "userIcon2";
	this.userIcon2.setTransform(246.8,18.7,1,1,0,0,0,20,18.3);

	this.userIcon1 = new lib.userIcon1();
	this.userIcon1.name = "userIcon1";
	this.userIcon1.setTransform(209,19,1,1,0,0,0,19.2,18.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.userIcon1},{t:this.userIcon2},{t:this.userIcon3}]}).wait(1));

	// UI
	this.instance = new lib.SUR21_20H1_Surface_PPT_Collaboration_3x2_enUSNoPeople();
	this.instance.setTransform(-1.8,-1.2,1.01,1.01);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// additionalTiles
	this.ad6 = new lib.add6();
	this.ad6.name = "ad6";
	this.ad6.setTransform(394.7,393,1.2131,1.2131,0,0,0,130,80.9);

	this.ad5 = new lib.add5();
	this.ad5.name = "ad5";
	this.ad5.setTransform(423.6,611.15,0.9311,0.9311,0,0,0,172.5,102);

	this.ad4 = new lib.add4();
	this.ad4.name = "ad4";
	this.ad4.setTransform(-31.3,411.85,1.2327,1.2327,0,0,0,131.8,67.5);

	this.ad3 = new lib.add3();
	this.ad3.name = "ad3";
	this.ad3.setTransform(259.55,421.65,0.7947,0.7947,0,0,0,88.8,94.4);

	this.ad2 = new lib.add2();
	this.ad2.name = "ad2";
	this.ad2.setTransform(-52.55,600.35,0.8113,0.8113,0,0,0,94,103.7);

	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(-45.65,146.8,1,1,0,0,0,76.7,69.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ad1},{t:this.ad2},{t:this.ad3},{t:this.ad4},{t:this.ad5},{t:this.ad6}]}).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(172.5,141,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI, new cjs.Rectangle(-257.7,-307.6,825.4000000000001,1026.1), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.man = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.man.cache(0,0,55,65,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// man
	this.man = new lib.man_sub();
	this.man.name = "man";
	this.man.setTransform(25.9,29.2,1,1,0,0,0,25.9,29.2);

	this.timeline.addTween(cjs.Tween.get(this.man).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.man, new cjs.Rectangle(0,0,52,58.3), null);


(lib.line_drawn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-290,-50,580,100,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.line_drawn_sub();
	this.line.name = "line";
	this.line.setTransform(142.5,21.6,1,1,0,0,0,142.5,21.6);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_drawn, new cjs.Rectangle(-2,-2,289,47.2), null);


(lib.iconWoman = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.woman.cache(0,0,55,65,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.woman = new lib.woman_sub();
	this.woman.name = "woman";
	this.woman.setTransform(25.9,30.6,1,1,0,0,0,25.9,30.6);

	this.timeline.addTween(cjs.Tween.get(this.woman).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconWoman, new cjs.Rectangle(0,0,52,61.3), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-250,-10,500,20,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSYBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgSrBKCIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgTlBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVEBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXJBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZ1BKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdHBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniBKCIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1BKCIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:473.8095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:473.8095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:473.8095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:473.8095}).wait(1).to({graphics:mask_graphics_18,x:438.8595,y:473.8095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:473.8095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:473.8095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:473.8095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:473.8095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:473.8095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:473.8095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:473.8095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:473.8095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-132.35,888.65,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:37.65,y:59.2},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(300.05,893.7,1,1,0,0,0,486,405.4);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(298.45,894.55,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdCf2MAAAk/rMCY7AAAMAAAE/rg");
	this.shape.setTransform(301.475,941.75);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(301.45,344.45);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-81.2,979.6999999999999,2046);


(lib.chart = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.chart.cache(0,0,30,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.chart = new lib.chart_sub();
	this.chart.name = "chart";
	this.chart.setTransform(12.6,8.7,1,1,0,0,0,12.6,8.7);

	this.timeline.addTween(cjs.Tween.get(this.chart).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart, new cjs.Rectangle(0,0,25.3,17.5), null);


(lib.bubbleR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bubble.cache(0,0,35,35,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bubble = new lib.bubbleR_sub();
	this.bubble.name = "bubble";
	this.bubble.setTransform(14.9,15.2,1,1,0,0,0,14.9,15.2);

	this.timeline.addTween(cjs.Tween.get(this.bubble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bubbleR, new cjs.Rectangle(0,0,29.9,30.4), null);


(lib.bubbleLine = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.line = new lib.bub_line_sub();
	this.line.name = "line";
	this.line.setTransform(8.2,1.1,1,1,0,0,0,8.2,1.1);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bubbleLine, new cjs.Rectangle(0,0,16.4,2.2), null);


(lib.bubbleL = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bubble.cache(0,0,35,35,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bubble = new lib.bubbleL_sub();
	this.bubble.name = "bubble";
	this.bubble.setTransform(14.9,15.2,1,1,0,0,0,14.9,15.2);

	this.timeline.addTween(cjs.Tween.get(this.bubble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bubbleL, new cjs.Rectangle(0,0,29.9,30.4), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-8.2,1.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Poplines
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-119.5,-1.35,1.078,1.078,0,0,0,5,11.5);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(22.35,-0.9,1.0781,1.0781,0,0,0,4.8,11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.popRight},{t:this.popLeft}]}).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-106.85,-17.05,1.1779,1.2899,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-125.8,-16.9,154.5,34.9), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_89 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_37 = new cjs.Graphics().p("AEnECImxgFQgWAAgPgkQgPgkAAg0QABgzAQgkQAQgkAWAAIGwAEQAWABAPAkQAQAkgBAzQAAA0gQAjQgQAlgWAAIAAAAg");
	var mask_graphics_38 = new cjs.Graphics().p("AExECInAgEQgXAAgQglQgQgkABg0QAAgzARglQAQgkAXAAIHAAEQAXAAAQAlQAQAlgBAzQAAAzgRAkQgQAlgXAAIAAAAg");
	var mask_graphics_39 = new cjs.Graphics().p("AE8ECInRgDQgYgBgQglQgRgkAAg0QABg0ARglQARgkAYAAIHRAEQAYAAAQAlQARAlAAAzQgBA0gRAkQgRAlgYAAIAAAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AFJECInlgDQgZAAgRglQgRglAAg0QAAg0ASglQASglAZAAIHlADQAYAAARAlQASAmAAA0QgBA0gSAkQgRAlgZAAIAAAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AFXEDIn6gDQgaAAgTgmQgSglABg0QAAg1ASglQATglAaAAIH7ADQAZAAASAlQATAlgBA1QAAA0gSAlQgTAmgaAAIAAAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AFnEDIoTgCQgbAAgTgmQgTglAAg1QAAg1ATgmQAUglAbAAIITACQAbAAATAlQATAmAAA1QAAA1gTAlQgUAmgbAAIAAAAg");
	var mask_graphics_43 = new cjs.Graphics().p("AF5EDIougBQgdAAgUgmQgUgmAAg1QAAg2AUgmQAVglAcAAIIuAAQAdAAAUAmQAUAmAAA2QAAA1gUAmQgVAmgcAAIAAAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AjzDdQgVgnAAg2QAAg2AVgmQAVglAeAAIJMAAQAeAAAWAlQAVAmAAA2QAAA2gVAmQgWAngeAAIpMAAQgeAAgVgmg");
	var mask_graphics_45 = new cjs.Graphics().p("AkCDdQgWgmAAg3QAAg3AWgnQAWglAggBIJtgBQAgAAAWAlQAXAnAAA3QAAA3gWAmQgWAnggABIptABIAAAAQggAAgXgng");
	var mask_graphics_46 = new cjs.Graphics().p("AkRDdQgYgmAAg4QgBg3AYgoQAYgmAhAAIKRgDQAiAAAYAmQAYAnAAA4QAAA3gYAnQgXAogiAAIqRADIAAAAQghAAgYgog");
	var mask_graphics_47 = new cjs.Graphics().p("AkjDeQgZgnAAg5QgBg4AZgoQAZgmAkgBIK4gEQAkgBAZAnQAaAoAAA4QAAA4gZAnQgYApgkAAIq4AFIgBAAQgjAAgagog");
	var mask_graphics_48 = new cjs.Graphics().p("Ak1DeQgbgngBg5QAAg5AagpQAbgnAlgBILjgHQAmAAAbAnQAbAoABA5QAAA5gaAoQgbApglABIrjAGIgBAAQglAAgbgog");
	var mask_graphics_49 = new cjs.Graphics().p("AlJDfQgdgoAAg6QgBg6AcgpQAcgoAogBIMQgJQAogBAdAnQAdApABA6QAAA6gcApQgbApgoABIsRAJIgBAAQgnAAgdgog");
	var mask_graphics_50 = new cjs.Graphics().p("AleDgQgfgpgBg7QgBg7AegqQAdgpArAAINBgNQArAAAeAnQAfAqABA6QABA7geAqQgdAqgrABItBAMIgBAAQgqAAgegog");
	var mask_graphics_51 = new cjs.Graphics().p("Al1DgQgggpgBg8QgCg7AfgsQAggpAtgBIN1gQQAtgBAgApQAiAqABA7QABA8ggAqQgfArgtABIt1AQIgBAAQgsAAghgpg");
	var mask_graphics_52 = new cjs.Graphics().p("AmMDhQgjgqgBg9QgCg8AhgsQAhgrAwgBIOrgUQAwgBAjAqQAjAqABA8QABA9ghArQghAsgwABIuqAVIgDAAQguAAgigqg");
	var mask_graphics_53 = new cjs.Graphics().p("AmlDiQglgrgBg9QgCg+AjgtQAjgrAzgCIPjgZQAygBAlArQAlAqACA+QACA9gkAtQgiAtgzABIvjAZIgDAAQgwAAglgqg");
	var mask_graphics_54 = new cjs.Graphics().p("Am+DjQgngsgBg+QgCg/AkguQAlgsA2gCIQcgeQA1gBAnArQAoArACA+QACA/glAtQglAug2ACIwbAeIgEAAQgzAAgngqg");
	var mask_graphics_55 = new cjs.Graphics().p("AnXDjQgpgrgChAQgChAAmgvQAngtA5gCIRVgjQA5gCApArQAqAsACBAQACA/gnAvQgmAug5ACIxVAkIgFAAQg2AAgogrg");
	var mask_graphics_56 = new cjs.Graphics().p("AnwDkQgrgsgDhBQgChBAogwQApguA8gCISPgqQA7gCAsAsQAsAsACBBQADBBgpAvQgoAwg8ACIyPAqIgFAAQg5AAgqgrg");
	var mask_graphics_57 = new cjs.Graphics().p("AoJDlQgtgtgDhCQgChCAqgxQAqgvA/gCITIgwQA+gCAuAsQAuAuADBBQADBCgrAwQgqAxg/ACIzIAwIgGAAQg6AAgtgrg");
	var mask_graphics_58 = new cjs.Graphics().p("AogDmQgwgtgDhDQgDhDAsgyQAsgwBCgDIT/g3QBBgCAwAtQAwAuADBCQADBDgsAxQgsAyhCADIz/A2IgHAAQg9AAgtgrg");
	var mask_graphics_59 = new cjs.Graphics().p("Ao4DnQgygugDhEQgDhEAugyQAugyBEgDIU0g9QBEgDAyAuQAzAuADBDQADBEguAyQguAzhEADI00A9IgIAAQg/AAgwgrg");
	var mask_graphics_60 = new cjs.Graphics().p("ApODnQg0gugDhFQgDhFAvgyQAwgzBHgEIVmhDQBHgEA0AuQA1AvADBEQADBFgwAzQgvA0hGADI1nBEIgKAAQhAAAgygsg");
	var mask_graphics_61 = new cjs.Graphics().p("ApiDoQg2gvgEhFQgDhGAwg0QAyg0BJgDIWXhLQBJgDA2AuQA2AvAEBFQAEBGgyA0QgxA0hJAEI2XBKIgKABQhDAAgygsg");
	var mask_graphics_62 = new cjs.Graphics().p("Ap2DpQg4gvgDhHQgEhHAyg0QAzg1BLgEIXEhQQBMgEA3AuQA5AwAEBGQADBGgzA1QgyA1hLAEI3EBRIgMAAQhEAAg0grg");
	var mask_graphics_63 = new cjs.Graphics().p("AqIDpQg6gvgEhHQgEhIA0g1QA0g1BOgFIXuhXQBNgEA6AvQA6AwAEBGQAEBIg0A1Qg0A2hNAFI3uBXIgNAAQhGAAg1gsg");
	var mask_graphics_64 = new cjs.Graphics().p("AqZDqQg7gwgEhIQgFhIA1g2QA2g2BPgFIYWhdQBPgFA7AwQA8AwAEBIQAFBIg2A2Qg1A3hPAEI4WBdIgOABQhHAAg2gsg");
	var mask_graphics_65 = new cjs.Graphics().p("AqpDqQg8gvgFhJQgEhJA2g3QA2g3BSgFIY6hiQBRgFA9AvQA9AxAEBJQAFBIg3A2Qg2A4hRAFI46BjIgQAAQhHAAg4gsg");
	var mask_graphics_66 = new cjs.Graphics().p("Aq4DrQg9gwgFhKQgFhJA3g3QA4g4BTgFIZchoQBTgGA+AwQA/AxAEBJQAFBJg4A4Qg3A4hTAFI5cBoIgQABQhJAAg5gsg");
	var mask_graphics_67 = new cjs.Graphics().p("ArFDrQg/gwgFhKQgFhKA4g4QA5g4BVgGIZ7htQBVgGA/AxQA/AxAFBKQAFBJg5A4Qg4A5hUAFI58BuIgRAAQhKAAg5gsg");
	var mask_graphics_68 = new cjs.Graphics().p("ArSDsQhAgxgFhKQgFhLA5g4QA6g5BWgGIaYhyQBWgGBAAwQBBAyAFBKQAGBKg6A5Qg5A5hWAGI6YByIgSABQhLAAg7gsg");
	var mask_graphics_69 = new cjs.Graphics().p("ArdDsQhBgwgFhLQgGhMA6g5QA7g5BXgGIazh3QBXgGBBAxQBDAxAFBLQAFBKg7A6Qg6A6hXAGI6yB3IgTAAQhMAAg7gsg");
	var mask_graphics_70 = new cjs.Graphics().p("AroDtQhCgxgFhMQgFhLA6g6QA8g5BYgHIbLh7QBZgGBCAxQBDAxAFBMQAGBKg8A6Qg6A6hZAHI7LB7IgTABQhNAAg8gsg");
	var mask_graphics_71 = new cjs.Graphics().p("ArxDtQhDgxgGhMQgFhMA7g6QA8g6BagGIbhiAQBagGBDAxQBEAxAGBMQAFBLg8A7Qg8A6hZAHI7hB/IgVABQhNAAg8gsg");
	var mask_graphics_72 = new cjs.Graphics().p("Ar6DtQhEgxgFhMQgGhNA8g6QA9g6BbgHIb1iDQBbgHBEAxQBFAyAFBNQAGBLg9A6Qg8A8hbAGI71CDIgVABQhOAAg9gsg");
	var mask_graphics_73 = new cjs.Graphics().p("AsCDuQhEgygGhMQgGhNA9g7QA9g6BcgHIcIiHQBbgHBFAyQBGAxAFBNQAGBMg9A7Qg9A7hcAHI8HCHIgWAAQhPAAg9grg");
	var mask_graphics_74 = new cjs.Graphics().p("AsJDuQhFgxgGhNQgGhNA9g7QA+g8BdgHIcYiJQBdgHBFAxQBGAyAGBNQAGBMg+A7Qg9A8hdAHI8YCKIgXABQhOAAg+gsg");
	var mask_graphics_75 = new cjs.Graphics().p("AsQDuQhFgxgGhOQgGhNA9g7QA/g8BdgHIcoiMQBdgHBGAxQBHAyAGBNQAGBNg/A7Qg9A8heAII8nCMIgXABQhPAAg/gsg");
	var mask_graphics_76 = new cjs.Graphics().p("AsVDuQhHgxgGhOQgGhNA+g8QA/g8BegHIc1iPQBegHBHAxQBHAyAGBOQAGBNg/A7Qg9A9hfAHI81CPIgXABQhQAAg+gsg");
	var mask_graphics_77 = new cjs.Graphics().p("AsbDuQhHgxgGhOQgGhOA+g7QBAg8BfgIIdBiRQBfgIBHAyQBIAyAGBOQAGBNg/A8Qg/A9hfAHI9BCRIgYABQhQAAg/gsg");
	var mask_graphics_78 = new cjs.Graphics().p("AsgDvQhHgygGhOQgGhOA+g8QBAg8BggIIdMiTQBfgIBIAyQBIAyAGBOQAGBNg/A8Qg/A9hfAII9NCTIgYABQhQAAhAgrg");
	var mask_graphics_79 = new cjs.Graphics().p("AskDvQhHgygHhOQgGhOA/g8QBAg9BggHIdWiWQBggIBIAyQBIAzAHBOQAGBNhAA8Qg/A+hgAHI9WCWIgZABQhQAAhAgsg");
	var mask_graphics_80 = new cjs.Graphics().p("AsnDvQhIgygHhOQgGhOA/g9QBBg8BggIIdeiXQBhgIBIAyQBJAyAGBPQAHBNhBA8Qg/A+hgAII9fCXIgZABQhRAAg/gsg");
	var mask_graphics_81 = new cjs.Graphics().p("AsrDvQhIgygGhOQgHhPBAg8QBAg9BhgIIdmiYQBhgIBIAyQBKAyAGBPQAGBOhAA8QhAA9hgAII9mCZIgaABQhRAAhAgsg");
	var mask_graphics_82 = new cjs.Graphics().p("AstDvQhJgygGhOQgHhPBAg8QBBg9BhgIIdsiaQBhgIBJAyQBJAyAHBPQAGBPhBA7Qg/A+hhAII9tCaIgZABQhRAAhAgsg");
	var mask_graphics_83 = new cjs.Graphics().p("AswDvQhIgygHhOQgGhPBAg9QBBg9BhgIIdxibQBigHBJAxQBKAzAGBPQAGBOhBA8Qg/A+hiAII9xCbIgaABQhSAAhAgsg");
	var mask_graphics_84 = new cjs.Graphics().p("AsxDvQhKgxgGhPQgGhPBAg9QBBg9BhgIId2icQBigIBJAyQBKAzAGBOQAHBPhBA8QhAA+hiAII92CcIgaABQhRAAhAgsg");
	var mask_graphics_85 = new cjs.Graphics().p("AszDvQhJgxgHhPQgGhPBAg9QBBg9BigIId6idQBhgIBJAyQBLAzAGBPQAHBOhCA9QhAA+hhAHI96CdIgaABQhSAAhAgsg");
	var mask_graphics_86 = new cjs.Graphics().p("As0DvQhJgxgHhPQgGhPBAg9QBBg9BigIId8ieQBigIBJAyQBLAzAGBPQAHBPhCA8QhAA+hiAII98CdIgaABQhSAAhAgsg");
	var mask_graphics_87 = new cjs.Graphics().p("As1DvQhJgxgHhPQgGhPBAg9QBBg+BigIId+idQBigIBKAyQBKAyAHBPQAGBPhBA9QhBA+hhAII9/CdIgaABQhSAAhAgsg");
	var mask_graphics_88 = new cjs.Graphics().p("As1DvQhKgxgGhPQgHhPBAg9QBCg+BigIId/idQBigIBJAyQBLAyAGBPQAHBPhCA8QhAA+hiAII9/CeIgaABQhSAAhAgsg");
	var mask_graphics_89 = new cjs.Graphics().p("AsyDxQhKgygGhPQgHhPBBg9QBBg9BigIIeAieQBigIBJAyQBLAzAGBOQAGBPhBA9QhAA+hiAII+ACeIgaABQhSAAhAgsg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(37).to({graphics:mask_graphics_37,x:34.9348,y:25.7574}).wait(1).to({graphics:mask_graphics_38,x:36.1171,y:25.7798}).wait(1).to({graphics:mask_graphics_39,x:37.4557,y:25.8032}).wait(1).to({graphics:mask_graphics_40,x:38.9622,y:25.8271}).wait(1).to({graphics:mask_graphics_41,x:40.6481,y:25.8506}).wait(1).to({graphics:mask_graphics_42,x:42.5256,y:25.873}).wait(1).to({graphics:mask_graphics_43,x:44.6072,y:25.893}).wait(1).to({graphics:mask_graphics_44,x:46.9051,y:25.9124}).wait(1).to({graphics:mask_graphics_45,x:49.4308,y:25.986}).wait(1).to({graphics:mask_graphics_46,x:52.1944,y:26.0656}).wait(1).to({graphics:mask_graphics_47,x:55.2033,y:26.1513}).wait(1).to({graphics:mask_graphics_48,x:58.4609,y:26.2428}).wait(1).to({graphics:mask_graphics_49,x:61.9648,y:26.3399}).wait(1).to({graphics:mask_graphics_50,x:65.7052,y:26.4419}).wait(1).to({graphics:mask_graphics_51,x:69.6631,y:26.548}).wait(1).to({graphics:mask_graphics_52,x:73.8089,y:26.6573}).wait(1).to({graphics:mask_graphics_53,x:78.1028,y:26.7683}).wait(1).to({graphics:mask_graphics_54,x:82.4959,y:26.8798}).wait(1).to({graphics:mask_graphics_55,x:86.9329,y:26.9901}).wait(1).to({graphics:mask_graphics_56,x:91.3567,y:27.098}).wait(1).to({graphics:mask_graphics_57,x:95.7121,y:27.202}).wait(1).to({graphics:mask_graphics_58,x:99.9505,y:27.3013}).wait(1).to({graphics:mask_graphics_59,x:104.032,y:27.3951}).wait(1).to({graphics:mask_graphics_60,x:107.9268,y:27.4829}).wait(1).to({graphics:mask_graphics_61,x:111.6148,y:27.5646}).wait(1).to({graphics:mask_graphics_62,x:115.0847,y:27.6401}).wait(1).to({graphics:mask_graphics_63,x:118.3323,y:27.7097}).wait(1).to({graphics:mask_graphics_64,x:121.3587,y:27.7736}).wait(1).to({graphics:mask_graphics_65,x:124.169,y:27.8321}).wait(1).to({graphics:mask_graphics_66,x:126.7709,y:27.8855}).wait(1).to({graphics:mask_graphics_67,x:129.1737,y:27.9342}).wait(1).to({graphics:mask_graphics_68,x:131.3876,y:27.9786}).wait(1).to({graphics:mask_graphics_69,x:133.4228,y:28.019}).wait(1).to({graphics:mask_graphics_70,x:135.29,y:28.0557}).wait(1).to({graphics:mask_graphics_71,x:136.9991,y:28.089}).wait(1).to({graphics:mask_graphics_72,x:138.5598,y:28.1191}).wait(1).to({graphics:mask_graphics_73,x:139.9813,y:28.1464}).wait(1).to({graphics:mask_graphics_74,x:141.272,y:28.171}).wait(1).to({graphics:mask_graphics_75,x:142.4401,y:28.1931}).wait(1).to({graphics:mask_graphics_76,x:143.493,y:28.2129}).wait(1).to({graphics:mask_graphics_77,x:144.4374,y:28.2306}).wait(1).to({graphics:mask_graphics_78,x:145.2799,y:28.2463}).wait(1).to({graphics:mask_graphics_79,x:146.0262,y:28.2602}).wait(1).to({graphics:mask_graphics_80,x:146.6819,y:28.2723}).wait(1).to({graphics:mask_graphics_81,x:147.252,y:28.2828}).wait(1).to({graphics:mask_graphics_82,x:147.7411,y:28.2918}).wait(1).to({graphics:mask_graphics_83,x:148.1537,y:28.2994}).wait(1).to({graphics:mask_graphics_84,x:148.4936,y:28.3056}).wait(1).to({graphics:mask_graphics_85,x:148.7645,y:28.3105}).wait(1).to({graphics:mask_graphics_86,x:148.97,y:28.3143}).wait(1).to({graphics:mask_graphics_87,x:149.1133,y:28.3169}).wait(1).to({graphics:mask_graphics_88,x:149.1972,y:28.3184}).wait(1).to({graphics:mask_graphics_89,x:149.5591,y:28.4659}).wait(1));

	// Layer_2 copy 2
	this.instance = new lib.line_drawn();
	this.instance.setTransform(145,20.75,1,1,1.0011,0,0,142.5,21.6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(37).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_19 = new cjs.Graphics().p("AGfBwQgRgGgQgPQgQgQgFgRQgHgQAIgHICQiRQAHgHARAGQAQAGAQAPQAQAQAGARQAGAQgHAHIiRCRQgEAEgHAAQgFAAgHgDg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AGTB2QgRgGgPgPQgQgQgGgRQgGgRAIgIICaiaQAIgHARAFQAQAGAQAPQAQAQAGARQAGARgIAIIiaCaQgFAEgHAAQgGAAgHgCg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AGGB9QgRgGgQgPQgQgQgFgRQgGgRAJgJIClilQAIgJASAFQARAGAQAPQAPAQAGARQAFARgIAJIimClQgFAFgJAAQgFAAgGgBg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AF3CEQgSgFgQgPQgQgQgFgSQgFgRAJgJICyizQAKgJARAFQASAFAQAPQAQAQAFASQAEARgJAJIiyCzQgGAGgKAAIgKgCg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AFmCNQgTgFgQgPQgPgQgFgSQgEgSAKgKIDAjBQAKgKASAEQASAFAQAPQAQAQAEASQAEASgJAKIjBDBQgGAHgLAAIgKgBg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AFTCWQgTgEgPgQQgQgQgEgSQgEgTALgLIDPjQQALgKATADQASAEAQAQQAQAPAEATQAEATgLALIjQDQQgHAIgNAAIgJgBg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AFACfQgUgDgPgQQgQgPgDgUQgEgTAMgLIDfjhQAMgLATADQAUADAPAQQAQAPAEAUQADATgMALIjfDhQgKAJgNAAIgIgBg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AEsCpQgUgCgQgQQgQgQgCgUQgDgUAMgMIDxjxQAMgNAUADQAUACAQAQQAPAQADAUQADAUgNAMIjwDxQgKAKgQAAIgGAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AEXCzQgVgCgPgPQgQgQgCgVQgCgUANgNIECkDQANgNAUACQAVACAQAPQAQAQACAVQABAUgNANIkBEDQgMALgRAAIgFAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AECC+QgVgCgQgPQgQgQgBgVQgBgVAOgPIETkUQAOgOAVABQAVACAQAPQAQAQABAVQABAVgOAPIkTEUQgNANgTAAIgDAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("ADtDIQgWgBgPgQQgQgPgBgWQgBgWAPgPIElklQAOgPAWAAQAWABAQAQQAQAPABAWQAAAWgPAPIkkElQgOAPgVAAIgCAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("ACyDCQgPgQAAgWQgBgWAQgQIE2k3QAPgQAXAAQAWAAAQAQQAQAQAAAWQAAAWgQAQIk1E3QgQAQgWAAIAAAAQgXAAgQgQg");
	var mask_1_graphics_31 = new cjs.Graphics().p("ACeDNQgQgQABgXQAAgXARgRIFGlHQAQgRAXgBQAXAAAQAPQAQAQAAAXQgBAXgRARIlGFHQgQARgXABIgCAAQgWAAgPgPg");
	var mask_1_graphics_32 = new cjs.Graphics().p("ACKDWQgQgPACgYQABgXARgSIFWlXQARgSAYgBQAXgBAQAQQAQAPgBAYQgBAXgSASIlVFXQgSASgXABIgEAAQgVAAgPgPg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AB4DgQgQgQACgYQABgYASgSIFllnQASgSAYgCQAYgCAQAQQAQAQgBAYQgCAYgSATIllFmQgSASgYACIgFAAQgVAAgOgOg");
	var mask_1_graphics_34 = new cjs.Graphics().p("ABmDpQgPgQACgZQACgYATgUIFyl0QATgTAZgCQAYgCAQAPQAQAQgCAZQgCAZgTATIlzF0QgSATgZACIgGAAQgVAAgOgNg");
	var mask_1_graphics_35 = new cjs.Graphics().p("ABXDxQgQgQADgZQACgZATgUIGAmBQATgUAZgCQAZgDAQAQQAQAPgCAZQgDAZgUAUIl/GBQgTAUgZACIgIABQgUAAgNgNg");
	var mask_1_graphics_36 = new cjs.Graphics().p("ABID4QgPgQADgaQADgZAUgUIGKmNQAUgUAagDQAZgDAQAPQAQAQgDAaQgDAZgUAUImLGNQgUAUgZADIgJABQgTAAgOgNg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AA8D+QgQgQAEgaQADgaAUgUIGVmXQAVgVAagDQAZgEAQAQQAQAQgDAaQgEAagUAUImVGXQgVAVgZADIgKABQgTAAgNgNg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AA2EDQgQgPAEgbQADgaAVgVIGdmfQAVgVAbgEQAagEAPAQQAQAQgDAaQgEAagVAVImdGfQgVAVgaAEIgKABQgUAAgMgNg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_1_graphics_19,x:58.6746,y:-11.2945}).wait(1).to({graphics:mask_1_graphics_20,x:58.6274,y:-10.6705}).wait(1).to({graphics:mask_1_graphics_21,x:58.5732,y:-9.9332}).wait(1).to({graphics:mask_1_graphics_22,x:58.5136,y:-9.0954}).wait(1).to({graphics:mask_1_graphics_23,x:58.4502,y:-8.1709}).wait(1).to({graphics:mask_1_graphics_24,x:58.3846,y:-7.1742}).wait(1).to({graphics:mask_1_graphics_25,x:58.3181,y:-6.1206}).wait(1).to({graphics:mask_1_graphics_26,x:58.2519,y:-5.0256}).wait(1).to({graphics:mask_1_graphics_27,x:58.1872,y:-3.9048}).wait(1).to({graphics:mask_1_graphics_28,x:58.1249,y:-2.7735}).wait(1).to({graphics:mask_1_graphics_29,x:58.0655,y:-1.6469}).wait(1).to({graphics:mask_1_graphics_30,x:58.0097,y:-0.5395}).wait(1).to({graphics:mask_1_graphics_31,x:57.9568,y:0.5353}).wait(1).to({graphics:mask_1_graphics_32,x:57.9079,y:1.5648}).wait(1).to({graphics:mask_1_graphics_33,x:57.8632,y:2.5371}).wait(1).to({graphics:mask_1_graphics_34,x:57.8229,y:3.4418}).wait(1).to({graphics:mask_1_graphics_35,x:57.787,y:4.2694}).wait(1).to({graphics:mask_1_graphics_36,x:57.7556,y:5.0116}).wait(1).to({graphics:mask_1_graphics_37,x:57.7286,y:5.6613}).wait(1).to({graphics:mask_1_graphics_38,x:58.1368,y:5.3099}).wait(52));

	// Layer_2 copy
	this.instance_1 = new lib.line_drawn();
	this.instance_1.setTransform(145,20.75,1,1,1.0011,0,0,142.5,21.6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(19).to({_off:false},0).wait(71));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhYBuQgJgSgFgaQgGgaACgUQACgUAIgBICYgfQAIgBAJARQAKARAFAaQAFAbgBAUQgCAUgIABIiYAfIgCAAQgHAAgJgQg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AhYBuQgJgSgFgaQgGgaACgUQACgUAIgBICagfQAIgCAJASQAJAQAGAbQAFAagCAUQgBAUgIACIiaAfIgBAAQgIAAgJgQg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AhXBuQgKgSgFgaQgFgaACgVQACgTAIgBICeggQAIgCAJASQAKARAFAaQAGAagCAUQgCAUgIACIieAgIgCAAQgHAAgJgQg");
	var mask_2_graphics_3 = new cjs.Graphics().p("AhYBuQgJgSgGgaQgFgbACgUQACgTAJgBIClgiQAJgCAKASQAJARAGAaQAFAagCAUQgCAUgJACIilAiIgCAAQgIAAgJgQg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AheBuQgKgSgGgaQgFgbACgUQADgTAJgCICxgkQAJgBAKARQALASAFAZQAFAagCAUQgDAVgJABIixAkIgCABQgIAAgJgQg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AhoBtQgKgRgGgaQgFgbADgUQADgTAKgCIDBgnQAKgCAKARQALARAGAaQAFAagDAUQgDAVgKACIjBAnIgCAAQgJAAgKgQg");
	var mask_2_graphics_6 = new cjs.Graphics().p("Ah0BtQgLgRgGgaQgFgbAEgUQAEgUALgCIDVgrQALgCAMARQALARAGAZQAFAbgEAUQgEAVgLACIjVArIgDAAQgKAAgKgPg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AiEBtQgMgRgGgbQgFgaAFgVQAFgTAMgDIDxgxQAMgCANARQAMARAGAZQAFAbgFAUQgFAVgMACIjxAxIgDABQgLAAgLgPg");
	var mask_2_graphics_8 = new cjs.Graphics().p("AiYBsQgNgQgGgbQgFgaAGgVQAGgUAOgDIETg4QAOgCAOAQQANARAGAbQAFAZgGAVQgGAVgOACIkTA4IgEABQgMAAgMgPg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AiwBsQgQgRgFgaQgFgbAHgVQAIgUAQgDIE9hAQAQgEAPARQAQAQAFAbQAFAZgIAVQgHAVgQAEIk9BAIgFAAQgOAAgMgNg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AjOBrQgRgQgFgbQgFgaAJgWQAKgUASgEIFvhKQATgEARAQQARAQAFAbQAFAagJAUQgKAWgSAEIlvBKIgHABQgPAAgOgNg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AjwBqQgTgQgFgaQgFgbALgWQAMgUAVgFIGphWQAVgEATAPQAUAQAFAaQAFAbgLAVQgMAWgVAEImpBWIgJABQgRAAgPgMg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AkVBpQgVgPgGgbQgFgaAOgXQAOgVAZgFIHnhjQAZgFAWAPQAVAPAGAbQAFAagOAXQgOAVgZAFInnBjIgNABQgSAAgQgLg");
	var mask_2_graphics_13 = new cjs.Graphics().p("Ak8BvQgXgPgGgaQgFgbAQgWQARgWAcgGIIphwQAdgGAXAPQAYAPAGAaQAFAbgRAWQgQAWgcAGIopBwQgIACgIAAQgTAAgSgLg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AlhB3QgagPgFgaQgGgaATgYQASgXAggFIJph+QAggGAaAOQAaAPAFAaQAGAagTAYQgSAXggAFIppB+QgKACgJAAQgVAAgSgKg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AmEB+QgcgOgFgbQgFgaAUgYQAVgXAigHIKliJQAigHAcAOQAdAOAFAbQAFAagUAYQgVAXgiAHIqlCJQgLACgLAAQgWAAgTgJg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AmjCEQgdgNgGgbQgFgaAWgZQAXgYAlgHILZiTQAlgHAeANQAeANAGAbQAFAagXAYQgWAZglAHIrZCTQgNADgNAAQgWAAgUgJg");
	var mask_2_graphics_17 = new cjs.Graphics().p("Am9CJQgggNgFgaQgGgbAYgYQAZgYAngIIMHicQAngIAgANQAgANAFAaQAGAbgZAYQgYAZgnAIIsHCbQgPAEgNAAQgXAAgUgJg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AnUCOQghgNgFgaQgGgbAagZQAZgYAqgJIMtijQAqgJAhANQAhANAFAaQAGAbgaAYQgZAZgqAJIstCjQgRAEgPAAQgXAAgUgIg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AnnCSQgjgNgFgaQgFgbAagZQAbgYArgJINPirQArgIAiAMQAjANAFAaQAFAbgbAYQgaAagrAIItPCrQgRADgQAAQgYAAgUgHg");
	var mask_2_graphics_20 = new cjs.Graphics().p("An4CVQgjgMgFgbQgGgaAcgZQAcgZAtgJINpixQAtgJAjANQAkAMAFAbQAGAagdAZQgbAZgtAJItpCxQgTADgRAAQgYAAgVgHg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:-10.7368,y:12.6329}).wait(1).to({graphics:mask_2_graphics_1,x:-10.7247,y:12.6288}).wait(1).to({graphics:mask_2_graphics_2,x:-10.6861,y:12.6159}).wait(1).to({graphics:mask_2_graphics_3,x:-10.476,y:12.5928}).wait(1).to({graphics:mask_2_graphics_4,x:-9.584,y:12.558}).wait(1).to({graphics:mask_2_graphics_5,x:-8.341,y:12.5096}).wait(1).to({graphics:mask_2_graphics_6,x:-6.6883,y:12.4454}).wait(1).to({graphics:mask_2_graphics_7,x:-4.5584,y:12.363}).wait(1).to({graphics:mask_2_graphics_8,x:-1.8786,y:12.2599}).wait(1).to({graphics:mask_2_graphics_9,x:1.4167,y:12.1339}).wait(1).to({graphics:mask_2_graphics_10,x:5.3604,y:11.9842}).wait(1).to({graphics:mask_2_graphics_11,x:9.9105,y:11.8129}).wait(1).to({graphics:mask_2_graphics_12,x:14.908,y:11.6266}).wait(1).to({graphics:mask_2_graphics_13,x:20.0783,y:10.7}).wait(1).to({graphics:mask_2_graphics_14,x:25.1098,y:9.6482}).wait(1).to({graphics:mask_2_graphics_15,x:29.7569,y:8.6767}).wait(1).to({graphics:mask_2_graphics_16,x:33.8895,y:7.8127}).wait(1).to({graphics:mask_2_graphics_17,x:37.4754,y:7.063}).wait(1).to({graphics:mask_2_graphics_18,x:40.5399,y:6.4222}).wait(1).to({graphics:mask_2_graphics_19,x:43.1329,y:5.8801}).wait(1).to({graphics:mask_2_graphics_20,x:44.8744,y:5.5434}).wait(70));

	// Layer_2
	this.instance_2 = new lib.line_drawn();
	this.instance_2.setTransform(145,20.75,1,1,1.0011,0,0,142.5,21.6);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-5.4,289.9,52.6);


(lib.iconCircle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(1));

	// Layer_2
	this.chart = new lib.chart();
	this.chart.name = "chart";
	this.chart.setTransform(18.3,17.9,1,1,0,0,0,12.6,8.7);

	this.timeline.addTween(cjs.Tween.get(this.chart).wait(20));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_10 = new cjs.Graphics().p("AjOBoIAAgJQAChQA6g5QA9g9BVAAQBWAAA9A9QA6A5ACBQIABAJg");
	var mask_graphics_11 = new cjs.Graphics().p("AiyhWIAFgHQA0g9BRgLQBUgKBEA0QBEA1ALBUQAKBRgvBBIgFAHg");
	var mask_graphics_12 = new cjs.Graphics().p("AhRi9IAIgDQBMgXBJAkQBNAlAcBSQAcBQgmBNQgkBKhLAcIgIADg");
	var mask_graphics_13 = new cjs.Graphics().p("AgqDMIgIgBIBHmYIAIABQBPARAvBDQAxBHgPBTQgPBVhGAxQg2Amg9AAQgPAAgQgCg");
	var mask_graphics_14 = new cjs.Graphics().p("Ah8ChIgIgEIDqlWIAHAFQBBAwAPBRQAQBTgxBHQgxBHhUAQQgVADgTAAQg5AAgyggg");
	var mask_graphics_15 = new cjs.Graphics().p("AgwC+QhRgNgxhAIgFgHIFRjwIAFAHQAsBDgNBQQgPBUhGAyQg2Ang/AAQgSAAgSgDg");
	var mask_graphics_16 = new cjs.Graphics().p("AhdCuQhKgjgehKIgEgJIGFiNIADAJQAZBMgjBJQgkBOhRAdQgkAOgiAAQgsAAgrgUg");
	var mask_graphics_17 = new cjs.Graphics().p("Ah7CZQhCgwgPhPIgBgIIGZg/IABAIQAJBPgwBCQgyBFhVAOQgSACgQAAQhBAAg3gog");
	var mask_graphics_18 = new cjs.Graphics().p("AiMCKQg8g3gGhQIgBgIIGegQIABAIQAABQg4A8Qg6A/hWADIgIAAQhQAAg8g3g");
	var mask_graphics_19 = new cjs.Graphics().p("AiSCEQg6g5gChQIAAgIIGeAAIAAAIQgDBQg6A5Qg9A9hWAAQhVAAg9g9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_graphics_10,x:17.75,y:7.525}).wait(1).to({graphics:mask_graphics_11,x:19.2615,y:13.8694}).wait(1).to({graphics:mask_graphics_12,x:19.2816,y:17.3052}).wait(1).to({graphics:mask_graphics_13,x:19.266,y:18.0722}).wait(1).to({graphics:mask_graphics_14,x:19.2686,y:19.3439}).wait(1).to({graphics:mask_graphics_15,x:19.267,y:19.3411}).wait(1).to({graphics:mask_graphics_16,x:18.4124,y:19.3575}).wait(1).to({graphics:mask_graphics_17,x:17.8949,y:19.3385}).wait(1).to({graphics:mask_graphics_18,x:17.767,y:19.3262}).wait(1).to({graphics:mask_graphics_19,x:17.75,y:19.325}).wait(1));

	// Layer_3 copy
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiBAoQg1g0AAhMIAAgFIAaAAIAAAFQAABBAuAtQAuAuBAAAQBBAAAuguQAugtABhBIAAgFIAZAAIAAAFQAABMg1A0Qg2A2hMAAQhLAAg2g2g");
	this.shape.setTransform(18.325,27.275);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10).to({_off:false},0).wait(10));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("AiSCEQg6g5gChQIAAgIIGeAAIAAAIQgDBQg6A5Qg9A9hWAAQhVAAg9g9g");
	var mask_1_graphics_2 = new cjs.Graphics().p("AgHDBQhWgDg6g/Qg4g8ABhQIAAgIIGdAQIAAAIQgGBQg8A3Qg8A3hQAAIgIAAg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AgeC/QhVgOgyhFQgwhCAJhPIABgIIGZA/IgBAIQgPBPhCAwQg3AohBAAQgQAAgSgCg");
	var mask_1_graphics_4 = new cjs.Graphics().p("Ag/C0QhRgdglhOQgihJAZhMIADgJIGFCNIgDAJQgfBKhKAjQgrAUgsAAQgiAAgkgOg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AhkCaQhGgygOhUQgOhQAthDIAFgHIFQDwIgFAHQgxBAhQANQgTADgSAAQg/AAg2gng");
	var mask_1_graphics_6 = new cjs.Graphics().p("AAHC+QhTgQgxhHQgxhHAQhTQAPhRBBgvIAHgGIDqFWIgIAFQgyAfg5AAQgUAAgVgDg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AggCoQhHgxgOhVQgPhTAxhHQAvhDBNgQIAJgCIBIGYIgJABQgPACgOAAQg/AAg1gmg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AgEDHQhLgcgkhKQgmhNAchQQAchSBNglQBIgkBNAXIAJADIiHGHIgHgDg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AiSChQgvhCAKhRQALhUBEg1QBEg0BUAKQBRALAzA9IAGAHIlHD9IgFgGg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AjOBoIAAgJQAChQA6g5QA9g9BVAAQBWAAA9A9QA6A5ACBQIABAJg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:17.75,y:19.325}).wait(1).to({graphics:mask_1_graphics_2,x:17.7441,y:19.3262}).wait(1).to({graphics:mask_1_graphics_3,x:17.6137,y:19.3385}).wait(1).to({graphics:mask_1_graphics_4,x:17.0916,y:19.3575}).wait(1).to({graphics:mask_1_graphics_5,x:15.7992,y:19.3411}).wait(1).to({graphics:mask_1_graphics_6,x:13.2246,y:19.3446}).wait(1).to({graphics:mask_1_graphics_7,x:9.1606,y:18.0802}).wait(1).to({graphics:mask_1_graphics_8,x:10.7021,y:17.3096}).wait(1).to({graphics:mask_1_graphics_9,x:15.5635,y:13.8694}).wait(1).to({graphics:mask_1_graphics_10,x:17.75,y:7.525}).wait(10));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("ACeBaQgCg/gsgsQgugthCAAQhAAAguAtQgtAsgBA/IgaAAQABhKA0gzQA2g2BLAAQBMAAA2A2QA0AzABBKg");
	this.shape_1.setTransform(18.325,8.95);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1).to({_off:false},0).wait(19));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,36.7,36.7);


(lib.iconBubbleR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.line2 = new lib.bubbleLine();
	this.line2.name = "line2";
	this.line2.setTransform(6.15,18.1,1.1128,1,0,0,0,0.1,1.1);

	this.line1 = new lib.bubbleLine();
	this.line1.name = "line1";
	this.line1.setTransform(6.15,13.9,1.125,1,0,0,0,0.1,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.line1},{t:this.line2}]}).wait(1));

	// Layer_1
	this.instance = new lib.bubbleR();
	this.instance.setTransform(14.9,15.2,1,1,0,0,0,14.9,15.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconBubbleR, new cjs.Rectangle(0,0,29.9,30.4), null);


(lib.iconBubbleL = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.line2 = new lib.bubbleLine();
	this.line2.name = "line2";
	this.line2.setTransform(5.25,18.1,0.9543,1,0,0,0,0,1.1);

	this.line1 = new lib.bubbleLine();
	this.line1.name = "line1";
	this.line1.setTransform(5.25,13.9,1,1,0,0,0,0,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.line1},{t:this.line2}]}).wait(1));

	// Layer_3
	this.instance = new lib.bubbleL();
	this.instance.setTransform(14.9,15.2,1,1,0,0,0,14.9,15.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconBubbleL, new cjs.Rectangle(0,0,29.9,30.4), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(180.35,119.8,1,1,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(60.6,119.8,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(125.9,172.5,1,1,0,0,0,125.9,52.5);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(125.9,52.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-0.5,-6.6,243.5,243.5), null);


(lib.collabIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// UI
	this.iconCircle = new lib.iconCircle();
	this.iconCircle.name = "iconCircle";
	this.iconCircle.setTransform(67.9,29.9,1,1,0,0,0,18.3,18.3);

	this.timeline.addTween(cjs.Tween.get(this.iconCircle).wait(1));

	// manBubble
	this.bubbleR = new lib.iconBubbleR();
	this.bubbleR.name = "bubbleR";
	this.bubbleR.setTransform(107.65,63.3,1,1,0,0,0,23.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.bubbleR).wait(1));

	// womanBubble
	this.bubbleL = new lib.iconBubbleL();
	this.bubbleL.name = "bubbleL";
	this.bubbleL.setTransform(30.8,29.4,1,1,0,0,0,5.9,29.4);

	this.timeline.addTween(cjs.Tween.get(this.bubbleL).wait(1));

	// arrow
	this.arrow = new lib.iconArrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(70.2,88.25,1,1,0,0,0,43.9,4.9);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// man
	this.man = new lib.man();
	this.man.name = "man";
	this.man.setTransform(109.5,119.3,1,1,0,0,0,25.9,54.4);

	this.timeline.addTween(cjs.Tween.get(this.man).wait(1));

	// woman
	this.woman = new lib.iconWoman();
	this.woman.name = "woman";
	this.woman.setTransform(25.9,86.8,1,1,0,0,0,25.9,56.4);

	this.timeline.addTween(cjs.Tween.get(this.woman).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabIcon, new cjs.Rectangle(0,0,135.6,133.1), null);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(430.15,60.85,0.9999,0.9999,-102.8482,0,0,14.8,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(441.85,53.4,0.9999,0.9999,-133.8481,0,0,14.8,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(447.75,41.9,1,1,-173.8499,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(295.9,-91.6,0.9999,0.9999,71.001,0,0,14.8,0);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(285,-82.85,1,1,40.0016,0,0,14.8,0);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(280.5,-70.85,1,1,0,0,0,14.9,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// collabIcon
	this.collabIcon = new lib.collabIcon();
	this.collabIcon.name = "collabIcon";
	this.collabIcon.setTransform(363.55,-20.55,1,1,0,0,0,67.8,66.5);

	this.timeline.addTween(cjs.Tween.get(this.collabIcon).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(7.75,18.65,1.1838,1.1838,3.4673);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(238.05,58.65,1.2782,1.2782,0,0,0,125.9,52.4);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-19.5,-260.8,512.9,555.3), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(143.3,550.7,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(149.45,550.15,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.UI();
	this.ui.name = "ui";
	this.ui.setTransform(135.8,286.55,0.7892,0.7892,0,0,0,169.8,125.2);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(252.6,229.95,1.1297,1.1297,0,0,0,3.6,39.9);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(184.1,331.25,1.162,1.162,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(34.95,177.1,1.2893,1.2893);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150.0023,299.9992,1,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-151.1,-4.1,719.7,758.9), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		mc.ui.ad1.visible = false;
		mc.ui.ad2.visible = false;
		mc.ui.ad3.visible = false;
		mc.ui.ad4.visible = false;
		mc.ui.ad5.visible = false;
		mc.ui.ad6.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();	
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.anim.line1.play();}});
				
				this.tl1.to(mc.anim,{duration:1.5, x: "-=300", ease:Power3.easeInOut}, "+=.1");
				this.tl1.to(mc.anim.grid,{duration:1.5, x: "+=37", ease:Power3.easeInOut}, "<");
		
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<");
		
				//icon
				this.tl1.from(mc.anim.collabIcon.man,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+1");
				this.tl1.from(mc.anim.collabIcon.woman,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+.2");
				this.tl1.from(mc.anim.collabIcon.arrow,{duration:.8, onStart:function(){mc.anim.collabIcon.arrow.play(), mc.anim.collabIcon.iconCircle.play();}}, "<");
				this.tl1.from(mc.anim.lineR1, {duration:.6, scaleX: 0, ease:Back.easeOut}, "<-.4");
				this.tl1.from(mc.anim.lineR2, {duration:.6, scaleX: 0, ease:Back.easeOut}, "<-.4");
				this.tl1.from(mc.anim.lineR3, {duration:.6, scaleX: 0, ease:Back.easeOut}, "<-.4");
				this.tl1.from(mc.anim.lineL1, {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.anim.lineL2, {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.anim.lineL3, {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.anim.collabIcon.iconCircle.chart,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+.2");
				this.tl1.from(mc.anim.collabIcon.bubbleL,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+.4");
				this.tl1.from([mc.anim.collabIcon.bubbleL.line1, mc.anim.collabIcon.bubbleL.line2],{duration:.6, scaleX: 0, stagger: 0.1, ease:Back.easeOut}, "<+.2");
				this.tl1.from(mc.anim.collabIcon.bubbleR,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+.2");
				this.tl1.from([mc.anim.collabIcon.bubbleR.line1, mc.anim.collabIcon.bubbleR.line2],{duration:.6, scaleX: 0, stagger: 0.1, ease:Back.easeOut}, "<+.2");
		
				//UI transition
				this.tl1.to(mc.anim.collabIcon.iconCircle.chart,{duration:1, x:"+=2", y:"+=22", scaleX: 4, scaleY: 4, ease:Power3.easeInOut});
				this.tl1.to(mc.anim.collabIcon.iconCircle.chart,{duration:.5, alpha:0, ease:Power3.easeIn}, "<");
		
				this.tl1.from(mc.ui,{duration:1, x:"+=14", y:"-=49", scaleX: .07, scaleY: .07, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.ui,{duration:.5, alpha:0, ease:Power3.easeOut}, "<");
		
				this.tl1.to([mc.anim.collabIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.2, alpha:0}, ">-.3");
				this.tl1.from([mc.ui.userIcon1, mc.ui.userIcon2, mc.ui.userIcon3],{duration:.6, scaleX: .5, scaleY: .5, alpha:0, stagger: 0.1, ease:Back.easeOut}, ">+.5");
				this.tl1.from([mc.ui.comment1, mc.ui.comment2, mc.ui.comment3],{duration:.01, alpha:0}, ">-.2");		
				this.tl1.from([mc.ui.comment1, mc.ui.comment2, mc.ui.comment3],{duration:.6, x:"+=150",scaleX: .5, scaleY: .8, stagger: 0.8, ease:Power3.easeOut}, "<");		
			
				
				this.tl1.to(mc.ui,{duration:1, x:"-=0", y:"+=7", scaleX: .61, scaleY: .61, ease:Power3.easeInOut}, ">+.2");
				this.tl1.from(mc.ui.UIShadow,{duration:1, x:"+=14", y:"+=17", alpha:0, ease:Power3.easeInOut}, "<");
				//this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.userIcon1,{duration:1, x:"+=67", y:"-=10", scaleX: .6, scaleY: .6, ease:Power3.easeInOut, onStart:function(){mc.ui.ad1.visible=true,mc.ui.ad2.visible=true,mc.ui.ad3.visible=true,mc.ui.ad4.visible=true,mc.ui.ad5.visible=true,mc.ui.ad6.visible=true;}}, "<");
				this.tl1.to(mc.ui.userIcon2,{duration:1, x:"+=54", y:"-=10", scaleX: .6, scaleY: .6, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.userIcon3,{duration:1, x:"+=39", y:"-=10", scaleX: .6, scaleY: .6, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.comment1,{duration:1, x:"+=69", y:"-=5", scaleX: .6, scaleY: .6, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.comment2,{duration:1, x:"+=69", y:"-=25", scaleX: .6, scaleY: .6, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.comment3,{duration:1, x:"+=69", y:"-=45", scaleX: .6, scaleY: .6, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.ui.pptLogo,{duration:.1, alpha:0}, "<");
				this.tl1.from(mc.ui.pptLogo,{duration:.5, x:"-=100", y:"-=100", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.4");
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.to(mc.ui,{duration:1.2, x:"+=22", y:"+=0", scaleX: .6, scaleY: .6, ease:Power3.easeInOut}, ">+.4");
				this.tl1.to(mc.anim,{duration:1.2, alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"-=30", y:"+=30", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.from(mc.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
		
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ad1,{duration:2, x:"-=120", y:"+=20",  ease:Power3.easeInOut});
				this.tl2.to(mc.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ad1,{duration:0, rotation:0}, ">+.5");
				this.tl2.from(mc.ui.ad2,{duration:2, x:"-=60", y:"+=60", ease:Power3.easeOut}, "<-0.5");
				this.tl2.to(mc.ui.ad2,{duration:0, rotation:"+=6"}, "<-1.3");
				this.tl2.to(mc.ui.ad2,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ad2,{duration:0, rotation:"+=4"}, ">+.5");
				this.tl2.to(mc.ui.ad2,{duration:0, rotation:0}, ">+.5");
				this.tl2.from(mc.ui.ad3,{duration:2, x:"+=220", y:"-=30", ease:Power3.easeOut}, "<-1.3");
				this.tl2.to(mc.ui.ad3,{duration:0, rotation:"-=10"}, "<-1.3");
				this.tl2.to(mc.ui.ad3,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ad3,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ad3,{duration:0, rotation:0}, ">+.5");
				this.tl2.from(mc.ui.ad4,{duration:2, x:"-=180", y:"+=80", ease:Power3.easeOut}, "<-1.1");
				this.tl2.to(mc.ui.ad4,{duration:0, rotation:"+=6"}, "<-1.1");
				this.tl2.to(mc.ui.ad4,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ad4,{duration:0, rotation:"+=4"}, ">+.5");
				this.tl2.to(mc.ui.ad4,{duration:0, rotation:0}, ">+.5");
				this.tl2.from(mc.ui.ad5,{duration:2, x:"+=150", y:"+=50", ease:Power3.easeOut}, "<-1.3");
				this.tl2.to(mc.ui.ad5,{duration:0, rotation:"-=10"}, "<-1.3");
				this.tl2.to(mc.ui.ad5,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ad5,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ad5,{duration:0, rotation:0}, ">+.5");
				this.tl2.from(mc.ui.ad6,{duration:2, x:"+=230", y:"-=90", ease:Power3.easeOut}, "<-1.3");
				this.tl2.to(mc.ui.ad6,{duration:0, rotation:"-=10"}, "<-1.3");
				this.tl2.to(mc.ui.ad6,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ad6,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ad6,{duration:0, rotation:0}, ">+.5");
				
				this.tl3 = gsap.timeline();
				this.tl3.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}});
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl3.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				exportRoot.tl3.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-1.8");
					this.tlMaster.to(exportRoot.tl3, {time:exportRoot.tl3.duration(), duration:exportRoot.tl3.duration(), 
					ease:Linear.easeNone},">-1.8");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-1.1,295.9,569.7,458.9);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622816103881", id:"M365_FY22Q1BTS_USA_300x600_BAN_Collab_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;