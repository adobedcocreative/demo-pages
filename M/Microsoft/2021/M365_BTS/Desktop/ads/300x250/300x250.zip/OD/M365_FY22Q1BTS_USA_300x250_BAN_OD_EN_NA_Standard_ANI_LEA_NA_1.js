(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[395,502,164,220],[886,644,80,132],[395,724,143,145],[727,644,157,166],[561,502,164,181],[561,685,141,184],[752,439,196,203],[752,255,272,182],[0,502,393,268],[752,0,220,253],[0,0,750,500]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BookReport = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Group592x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Layer12x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Layer22x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Layer32x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.tileShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.UIFinalFrame1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.university = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pptLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group592x();
	this.instance.setTransform(-8.6,-19.65,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptLogo, new cjs.Rectangle(-8.6,-19.6,114.39999999999999,116), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2229,21.2229,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6134,21.2229,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2229,6.6134,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6134,6.6134,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.182,14.0583,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9704,13.9133,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.5074,13.9133,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL7A/XMAAAh+tMCX3AAAMAAAB+tg");
	this.shape.setTransform(486,405.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(0,0,972,811), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.folder_front = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Am3F6QgVAAgJgPIgEgPIiYqRQgGgaARgVQAQgVAbAAIGyAAQAeAAAaAPQAaAPAPAaIAtBOQABADAEAAIGbAAQAfAAAYAUQAYASAHAeIBsHWIANA3QgCAGgEAFQgDAEgEADQgKAHgMAAgApPlRQgIAJADAMICaKYIQLAAIAEgBIh3oAQgFgUgQgMQgQgNgUAAImbAAQgKAAgHgEQgIgFgFgJIguhOQgLgTgTgLQgTgLgWAAImyAAQgMAAgIAKg");
	this.shape.setTransform(62.7967,37.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("Am6FcIiaqYQgCgMAIgJQAHgKANAAIGyAAQAVAAATALQAUALALATIAuBOQAEAJAJAFQAHAEAJAAIGcAAQAUAAAQANQAQAMAEAUIB3IAIgEABg");
	this.shape_1.setTransform(62.7202,37.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.folder_front, new cjs.Rectangle(0,0,125.6,75.6), null);


(lib.folder_bck = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AETHSIAAgeIAOAAIADAAQAFAAACgFIELsPIAAAAQAFgPgDgOQgCgPgJgMQgJgNgNgHQgOgHgPAAIt4AAQgdAAgXARQgYAQgJAcIheEQIgFAOIggAAIAFgOIBikaQAMgkAfgXQAfgWAnAAIN4AAQAXAAAUALQATAJAOATQANASADAWQADAXgHAVIkLMOQgDAMgKAHQgKAHgMAAgAEhGWIgBgCIABgIIAGheIDkqcQADgJgGgHQgFgHgJAAIt4AAQgPAAgLAIQgLAIgFANIg2CdIgfAAIA5inQAIgWATgOQATgNAYAAIN4AAQALgBALAGQAKAFAGAJQAHAJACAMQACALgEALIAAABIkFL/g");
	this.shape.setTransform(59.92,46.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AEdG0IAAgeIABAFIEGr/IAAgBQADgLgCgLQgBgMgHgJQgHgJgKgFQgKgGgMABIt4AAQgYAAgTANQgTAOgHAWIg6CnIgBAAIgiBlIgQAAIBekQQAJgcAXgQQAXgRAdAAIN4AAQAQAAANAHQAOAHAJANQAJAMACAPQACAOgFAPIAAAAIkLMPQgBAFgGAAg");
	this.shape_1.setTransform(60.2917,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.folder_bck, new cjs.Rectangle(0,0,119.9,93.2), null);


(lib.fileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tileShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fileShadow, new cjs.Rectangle(0,0,196,203), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIFinalFrame1();
	this.instance.setTransform(0,0,1.3786,1.3785);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(0,0,375,250.9), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.doodle_line6_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#010101").s().p("ApeE2IgLgCIAAAAQgqgLALhGQAKg/A8hbQA5hVBUhDIAAAAQBkhQCTg2QCshADigXQB8gMBWAEQBlAEB5AdQAGACADAFQADAFgBAGQgCAGgFADQgFAEgGgCQh2gchjgEQhUgEh5AMQjeAXipA+QiOA0hgBNIAAAAQhQA/g3BSQg3BVgKA6QgHAmAQAJIABAAIAAAAIAAAAIAFABQAGABAEAFQAEAFgBAGQAAAGgFAEQgFADgFAAIgBAAg");
	this.shape.setTransform(63.6115,29.5294);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line6_sub, new cjs.Rectangle(-1.5,-1.5,130.3,62.1), null);


(lib.doodle_line5_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#010101").s().p("AhtDDQgGgCgDgGQgDgGACgFQACgGAGgDQAFgDAGACQAUAEA0gsQBHg9AjhgQAdhSgog7QgEgFACgGQABgHAFgDQAFgEAGACQAGABAEAFQAxBGgjBiQglBohNBCQg6AwgfAAQgHAAgFgCg");
	this.shape.setTransform(12.0559,19.6969);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line5_sub, new cjs.Rectangle(0,0,24.2,39.4), null);


(lib.doodle_line3_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#010101").s().p("AlCDEQgWgJgEggIgBAAQgHgyBChWQAug8A/gsQBHg1BegdQBcgdBfAAQBpAAA8BFQAGAHAGAIQADAFAAAGQgBAGgFAEQgFADgGAAQgHgBgDgFIgLgOIAAAAQg0g6haAAQhaAAhYAcQhZAbhEAyIAAAAQg7AqgrA4Qg4BIADAqQACANAIAFQAFADACAGQACAFgCAGQgDAGgGACIgFAAIgGgBg");
	this.shape.setTransform(35.0899,19.7444);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line3_sub, new cjs.Rectangle(0,0,70.2,39.5), null);


(lib.doodle_line2_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#010101").s().p("AhHDIQgHgBgEgEQgEgFABgGQAAgHAFgEQAFgEAGABQARgBAbggQAggpAchFQAWg1AAgtQgBg+g3gZIAAAAQgRgJgVgDQgHgBgDgFQgEgFABgGQABgGAFgEQAFgDAGABQAaADAVALQBIAhABBRQAAAygYA7QgeBKgjAsIAAAAQglAsgbAAIgFAAg");
	this.shape.setTransform(8.6472,20.0082);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line2_sub, new cjs.Rectangle(0,0,17.3,40.1), null);


(lib.doodle_line1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#010101").s().p("AkBC3QgFgDgCgGQgBgGADgGQAwhUBVhVQCqitC9gEIABAAIAUACQAGAAAEAFQAEAGAAAGQgBAFgFAFQgFAEgGgBIgUgCQiwAFigCjQhSBSguBSQgDAFgGACIgEAAQgEAAgEgCg");
	this.shape.setTransform(26.5028,18.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line1_sub, new cjs.Rectangle(0,0,53,37), null);


(lib.cloud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ap1FwQhthrgBiZQgCiYBrhtQBrhuCagCQAvhIBHgyQBGgyBTgVQC5gwClBiQClBhAwC6QBBAEA5AfQBIAnArBGQAqBHABBSIAAACQAAB9hYBYQhYBYh9AAIsoAAIgCAAQiXAAhshrg");
	this.shape.setTransform(34.8084,22.2904,0.47,0.47);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cloud, new cjs.Rectangle(0,0,69.6,44.6), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ai6E+QiShagninQgmieBQiMIAIgPILBGzIgJAPQhZCGifAlQgzAMgxAAQhvAAhmg/g");
	var mask_graphics_1 = new cjs.Graphics().p("AjdEWQiBhxgMiqQgLijBlh9IAMgNIJwIgIgMAOQhuB1ijALIgfABQiXAAh2hng");
	var mask_graphics_2 = new cjs.Graphics().p("AAkF7QiqgRhuiFQhtiEARiqQAPijB5hqIANgMIIPKAIgOALQhuBUiIAAQgWAAgWgCg");
	var mask_graphics_3 = new cjs.Graphics().p("AgCF1QimgthWiUQhWiVAsilQAqieCIhVIAPgKIGfLNIgPAJQhbAxhiAAQg2AAg4gPg");
	var mask_graphics_4 = new cjs.Graphics().p("AgjFsQidhHg8igQg9igBHidQBDiVCUg+IAQgGIElMHIgRAGQhCAWhBAAQhVAAhUgmg");
	var mask_graphics_5 = new cjs.Graphics().p("Ag+FVQiPhggiioQghioBfiPQBaiICcglIARgDICjMsIgSAEQgjAFghAAQh4AAhphGg");
	var mask_graphics_6 = new cjs.Graphics().p("AhSEvQh9h2gGirQgGirB1h+QBvh3CggLIASgBIAbM8IgRABQihgBh2hvg");
	var mask_graphics_7 = new cjs.Graphics().p("ABtGbQidgbhkiBQhoiJAWipQAXirCIhoQCAhkCgAQIASABIhsM2IgSgCg");
	var mask_graphics_8 = new cjs.Graphics().p("AALGSQiXg1hNiQQhRiXAyikQAyilCXhRQCPhNCbAqIARAEIjxMaIgQgFg");
	var mask_graphics_9 = new cjs.Graphics().p("AhSGCQiNhMg1ibQg3ihBMibQBMiaCjg3QCag0CSBCIAQAHIluLnIgQgIg");
	var mask_graphics_10 = new cjs.Graphics().p("AioFuQh/higbihQgcipBliMQBkiLCpgcQChgbCFBZIAPAKInjKhIgOgKg");
	var mask_graphics_11 = new cjs.Graphics().p("Aj0FWQhuh2ABikQAAiqB6h6QB5h5CrAAQCjAAB2BuIAMAMIpKJJIgMgMg");
	var mask_graphics_12 = new cjs.Graphics().p("Ak0E6QhYiGAbihQAcipCMhjQCMhkCoAcQChAbBiB/IALAOIqjHhIgKgOg");
	var mask_graphics_13 = new cjs.Graphics().p("AllEcQhCiTA1iZQA4ijCahMQCahMCiA4QCbA1BLCNIAIAQIroFtIgHgQg");
	var mask_graphics_14 = new cjs.Graphics().p("AmID7QgoibBNiPQBRiYClgxQCkgyCXBSQCQBNAzCXIAGARIsaDvIgFgRg");
	var mask_graphics_15 = new cjs.Graphics().p("AmbDZQgOigBjiAQBpiICrgWQCqgWCIBpQCBBjAaCeIADARIs3BqIgCgRg");
	var mask_graphics_16 = new cjs.Graphics().p("AmeC5IABgRQAMigB3hvQB+h1CrAGQCsAHB1B9QBvB3AACgIAAASg");
	var mask_graphics_17 = new cjs.Graphics().p("AmaBUIADgRQAmibCIhaQCPhfCoAiQCoAiBfCPQBbCHgbCfIgDARg");
	var mask_graphics_18 = new cjs.Graphics().p("AmRgMIAGgRQA/iTCVhDQCdhHCfA+QChA9BGCcQBDCUg0CYIgFARg");
	var mask_graphics_19 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_20 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_21 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_22 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_23 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_24 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_25 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_26 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_27 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_28 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_29 = new cjs.Graphics().p("AmDhkIAJgQQBViICdgrQClgtCVBWQCWBVAtCmQAqCdhLCOIgIAPg");
	var mask_graphics_30 = new cjs.Graphics().p("AmFhYIAIgPQBSiKCcgvQCkgxCXBSQCXBSAxClQAvCchICPIgIAQg");
	var mask_graphics_31 = new cjs.Graphics().p("AmKhAIAIgPQBMiOCag1QCig4CaBLQCbBMA4CiQA1CZhBCTIgIAQg");
	var mask_graphics_32 = new cjs.Graphics().p("AmPgaIAGgQQBCiSCXhAQCehCCfBBQCfBABDCfQA/CVg4CXIgGAQg");
	var mask_graphics_33 = new cjs.Graphics().p("AmWAdIAFgRQA0iWCQhOQCXhRCkAxQClAxBRCYQBOCOgpCcIgFARg");
	var mask_graphics_34 = new cjs.Graphics().p("AmcBtIADgSQAgicCEhgQCLhkCpAbQCqAbBlCMQBfCDgUCfIgCASg");
	var mask_graphics_35 = new cjs.Graphics().p("AmeDBQAEihBxh0QB4h7CsgCQCrgDB7B4QB1BxAICgIABARIs9ANIAAgSg");
	var mask_graphics_36 = new cjs.Graphics().p("AmQDwQggidBViLQBZiTCngoQCmgpCTBZQCLBVAsCZIAFARIsmDFIgEgRg");
	var mask_graphics_37 = new cjs.Graphics().p("AlUEoQhLiPAsicQAtimCVhVQCWhVCkAtQCeArBUCJIAJAPIrQGaIgIgPg");
	var mask_graphics_38 = new cjs.Graphics().p("AjdFeQhzhwgJijQgJiqBziAQBziACrgJQCjgJB7BoIANALIoqJoIgNgMg");
	var mask_graphics_39 = new cjs.Graphics().p("AgyGIQiRhEg9iXQhBifBDieQBDieCfhBQCXg9CWA6IAQAGIlDL7IgQgHg");
	var mask_graphics_40 = new cjs.Graphics().p("ACHGdQiegVhph9QhuiEAPiqQAPirCEhvQB8hoChAIIARACIhKM5IgRgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AhAFSQiOhigfipQgfioBiiOQBciGCcgiIARgEICWMvIgRADQggAFgeAAQh8AAhqhKg");
	var mask_graphics_42 = new cjs.Graphics().p("AgaFwQighAhEieQhEidBAifQA8iYCRhEIAQgIIFHL6IgQAGQhJAdhKAAQhNAAhMgfg");
	var mask_graphics_43 = new cjs.Graphics().p("AAMF1QiogihfiPQhgiPAhinQAgigCDheIAOgKIHMKxIgOAJQhkA9hvAAQgqAAgsgIg");
	var mask_graphics_44 = new cjs.Graphics().p("AAwF9QirgJhzh/Qh0iAAJiqQAIikBzhvIANgNIIsJmIgNAMQhyBgiVAAIgXAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AjdEXQiBhxgMirQgLijBlh8IAMgOIJwIhIgMANQhuB1ijALIgfABQiXAAh2hmg");
	var mask_graphics_46 = new cjs.Graphics().p("AjKEuQiMhkgbiqQgaigBZiGIAKgOIKgHlIgKAOQhjB+ihAaQglAGgiAAQiAAAhthPg");
	var mask_graphics_47 = new cjs.Graphics().p("Ai6E+QiShagninQgmieBQiMIAIgPILBGzIgJAPQhZCGifAlQgzAMgxAAQhvAAhmg/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:9.5024,y:38.1224}).wait(1).to({graphics:mask_graphics_1,x:7.6135,y:38.0779}).wait(1).to({graphics:mask_graphics_2,x:5.2629,y:38.0846}).wait(1).to({graphics:mask_graphics_3,x:2.5251,y:37.5085}).wait(1).to({graphics:mask_graphics_4,x:-0.4683,y:36.0962}).wait(1).to({graphics:mask_graphics_5,x:-3.6236,y:35.1784}).wait(1).to({graphics:mask_graphics_6,x:-6.8871,y:34.8094}).wait(1).to({graphics:mask_graphics_7,x:-4.8277,y:34.6532}).wait(1).to({graphics:mask_graphics_8,x:-1.4865,y:33.9695}).wait(1).to({graphics:mask_graphics_9,x:1.7135,y:32.7961}).wait(1).to({graphics:mask_graphics_10,x:4.6911,y:31.1679}).wait(1).to({graphics:mask_graphics_11,x:7.3263,y:29.087}).wait(1).to({graphics:mask_graphics_12,x:9.4947,y:26.5564}).wait(1).to({graphics:mask_graphics_13,x:11.1908,y:23.6979}).wait(1).to({graphics:mask_graphics_14,x:12.41,y:20.6279}).wait(1).to({graphics:mask_graphics_15,x:13.1157,y:17.4237}).wait(1).to({graphics:mask_graphics_16,x:13.2813,y:15.601}).wait(1).to({graphics:mask_graphics_17,x:13.6601,y:19.0037}).wait(1).to({graphics:mask_graphics_18,x:14.5666,y:22.2936}).wait(1).to({graphics:mask_graphics_19,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_20,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_21,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_22,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_23,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_24,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_25,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_26,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_27,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_28,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_29,x:15.8553,y:25.2113}).wait(1).to({graphics:mask_graphics_30,x:15.6307,y:24.7757}).wait(1).to({graphics:mask_graphics_31,x:15.2442,y:23.9669}).wait(1).to({graphics:mask_graphics_32,x:14.7076,y:22.6853}).wait(1).to({graphics:mask_graphics_33,x:14.073,y:20.7978}).wait(1).to({graphics:mask_graphics_34,x:13.4757,y:18.1342}).wait(1).to({graphics:mask_graphics_35,x:13.2241,y:15.0945}).wait(1).to({graphics:mask_graphics_36,x:12.6327,y:19.5826}).wait(1).to({graphics:mask_graphics_37,x:10.5355,y:24.7916}).wait(1).to({graphics:mask_graphics_38,x:6.4391,y:29.824}).wait(1).to({graphics:mask_graphics_39,x:0.5366,y:33.2908}).wait(1).to({graphics:mask_graphics_40,x:-5.7462,y:34.787}).wait(1).to({graphics:mask_graphics_41,x:-3.9737,y:35.1761}).wait(1).to({graphics:mask_graphics_42,x:0.3485,y:36.5027}).wait(1).to({graphics:mask_graphics_43,x:3.6166,y:38.1489}).wait(1).to({graphics:mask_graphics_44,x:5.9795,y:38.11}).wait(1).to({graphics:mask_graphics_45,x:7.6202,y:38.1132}).wait(1).to({graphics:mask_graphics_46,x:8.745,y:38.1366}).wait(1).to({graphics:mask_graphics_47,x:9.5024,y:38.1224}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjMATQAAgiADgqQAGhTAMgfQAOAnAvB1IBajCIAEDJICRh/IhJCuIBHgIQBLgKAPAAQgQAWh1BMIA1ATQA3AUAIAFIhlAv");
	this.shape.setTransform(20.5,21);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,43,44);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzCHIAAkNIPnAAIAAENg");
	this.shape.setTransform(50,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,0,100,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group332x();
	this.instance.setTransform(-34,-29.6,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(-34,-29.6,160,264), null);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.folder.cache(0,0,130,80,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.folder = new lib.folder_front();
	this.folder.name = "folder";
	this.folder.setTransform(0,0,1,1,0,0,0,62.8,37.8);

	this.timeline.addTween(cjs.Tween.get(this.folder).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.8,-37.8,125.6,75.6);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.iconFolderBack = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.folder.cache(0,0,130,100,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.folder = new lib.folder_bck();
	this.folder.name = "folder";
	this.folder.setTransform(59.9,46.6,1,1,0,0,0,59.9,46.6);

	this.timeline.addTween(cjs.Tween.get(this.folder).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconFolderBack, new cjs.Rectangle(0,0,119.9,93.2), null);


(lib.iconFolder = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_35 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(35).call(this.frame_35).wait(1));

	// folderFront
	this.instance = new lib.Tween4("synched",0);
	this.instance.setTransform(62.95,93.2,1,1.0834,0,12.0418,0,0.2,37.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:71.3002,y:53.1491},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({regX:0.2,regY:37.8,x:62.95,y:93.2},0).wait(1).to({regX:0,regY:0,scaleY:1.0809,skewX:11.6821,x:71.0293,y:53.1887},0).wait(1).to({scaleY:1.0764,skewX:11.0269,x:70.5381,y:53.2655},0).wait(1).to({scaleY:1.0694,skewX:9.9954,x:69.7703,y:53.3985},0).wait(1).to({scaleY:1.0592,skewX:8.5188,x:68.6838,y:53.6143},0).wait(1).to({scaleY:1.0463,skewX:6.6255,x:67.3137,y:53.9335},0).wait(1).to({scaleY:1.032,skewX:4.5423,x:65.8376,y:54.3386},0).wait(1).to({scaleY:1.0187,skewX:2.5985,x:64.4918,y:54.7658},0).wait(1).to({scaleY:1.0076,skewX:0.991,x:63.4031,y:55.1537},0).wait(1).to({scaleY:0.9991,skewX:-0.2536,x:62.5758,y:55.475},0).wait(1).to({scaleY:0.9927,skewX:-1.1831,x:61.9671,y:55.7266},0).wait(1).to({scaleY:0.9881,skewX:-1.8564,x:61.5312,y:55.9149},0).wait(1).to({scaleY:0.9849,skewX:-2.3238,x:61.2311,y:56.0485},0).wait(1).to({scaleY:0.9828,skewX:-2.6247,x:61.039,y:56.1358},0).wait(1).to({scaleY:0.9817,skewX:-2.7889,x:60.9345,y:56.1839},0).wait(1).to({regX:0.1,regY:37.9,scaleY:0.9814,skewX:-2.8394,x:62.9,y:93.3},0).wait(1).to({regX:0,regY:0,scaleY:0.9832,skewX:-2.5574,x:61.1156,y:56.0663},0).wait(1).to({scaleY:0.9882,skewX:-1.806,x:61.5604,y:55.8482},0).wait(1).to({scaleY:0.9943,skewX:-0.8754,x:62.1182,y:55.5869},0).wait(1).to({scaleY:0.998,skewX:-0.316,x:62.4572,y:55.4345},0).wait(1).to({scaleY:0.9996,skewX:-0.0661,x:62.6096,y:55.3676},0).wait(1).to({regY:37.8,scaleY:1,skewX:0,x:62.8,y:93.2},0).wait(1));

	// folderBack
	this.instance_1 = new lib.iconFolderBack();
	this.instance_1.setTransform(94,93.2,1,1.093,0,-17.8671,0,60,93.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:59.9,regY:46.6,x:78.25,y:44.75},0).wait(13).to({regX:60,regY:93.2,x:94,y:93.2},0).wait(1).to({regX:59.9,regY:46.6,scaleY:1.0901,skewX:-17.3684,x:78.65,y:44.75},0).wait(1).to({scaleY:1.0849,skewX:-16.4601,x:79.45},0).wait(1).to({scaleY:1.0767,skewX:-15.0301,x:80.7},0).wait(1).to({scaleY:1.0649,skewX:-12.9828,x:82.45,y:44.9},0).wait(1).to({scaleY:1.0498,skewX:-10.3581,x:84.7,y:45.1},0).wait(1).to({scaleY:1.0332,skewX:-7.4699,x:87.05,y:45.55},0).wait(1).to({scaleY:1.0177,skewX:-4.7751,x:89.25,y:46},0).wait(1).to({scaleY:1.0049,skewX:-2.5466,x:91,y:46.5},0).wait(1).to({scaleY:0.9949,skewX:-0.821,x:92.3,y:46.85},0).wait(1).to({scaleY:0.9875,skewX:0.4677,x:93.25,y:47.2},0).wait(1).to({scaleY:0.9822,skewX:1.4011,x:94,y:47.45},0).wait(1).to({scaleY:0.9784,skewX:2.0491,x:94.45,y:47.65},0).wait(1).to({scaleY:0.976,skewX:2.4661,x:94.8,y:47.8},0).wait(1).to({scaleY:0.9747,skewX:2.6938,x:94.9,y:47.85},0).wait(1).to({regX:60,regY:93.2,scaleY:0.9743,skewX:2.7639,x:92.9,y:93.25},0).wait(1).to({regX:59.9,regY:46.6,scaleY:0.9769,skewX:2.4893,x:94.75,y:47.75},0).wait(1).to({scaleY:0.9837,skewX:1.7579,x:94.2,y:47.35},0).wait(1).to({scaleY:0.9921,skewX:0.8521,x:93.45,y:47},0).wait(1).to({scaleY:0.9972,skewX:0.3076,x:93.05,y:46.7},0).wait(1).to({scaleY:0.9994,skewX:0.0643,x:92.85,y:46.6},0).wait(1).to({regY:93.2,scaleY:1,skewX:0,y:93.2},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.4,-3.7,160.6,97);


(lib.iconCloud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.cloud.cache(0,0,75,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cloud = new lib.cloud();
	this.cloud.name = "cloud";
	this.cloud.setTransform(34.8,22.3,1,1,0,0,0,34.8,22.3);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconCloud, new cjs.Rectangle(0,0,69.6,44.6), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,250,10,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.file5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.BookReport();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(88.5,123.5,0.903,1.2168,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file5, new cjs.Rectangle(0,0,177,247), null);


(lib.file4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.university();
	this.instance.setTransform(0,0,0.377,0.377);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(52.15,61.2,0.5321,0.5321,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file4, new cjs.Rectangle(0,0,104.3,115.2), null);


(lib.file3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer22x();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(98,101.5,1,1,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file3, new cjs.Rectangle(0,0,196,203), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer32x();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(83,101.5,0.8468,1,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(0,0,166,203), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer12x();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(98,101.5,1,1,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file1, new cjs.Rectangle(0,0,196,203), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8595,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(300.05,337.5,1,1,0,0,0,486,405.4);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(301.475,344.45);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(301.45,344.45);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,978.8,828.1);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,300,250), null);


(lib.doodle_line6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-140,-70,280,140,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.doodle_line6_sub();
	this.line.name = "line";
	this.line.setTransform(63.6,29.5,1,1,0,0,0,63.6,29.5);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line6, new cjs.Rectangle(-1.5,-1.5,130.3,62.1), null);


(lib.doodle_line5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,40,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.doodle_line5_sub();
	this.line.name = "line";
	this.line.setTransform(10.6,18.2,1,1,0,0,0,12.1,19.7);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line5, new cjs.Rectangle(-1.5,-1.5,24.2,39.4), null);


(lib.doodle_line3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,80,40,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.doodle_line3_sub();
	this.line.name = "line";
	this.line.setTransform(33.55,18.3,1,1,0,0,0,35.1,19.8);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line3, new cjs.Rectangle(-1.5,-1.5,70.1,39.5), null);


(lib.doodle_line2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,30,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.doodle_line2_sub();
	this.line.name = "line";
	this.line.setTransform(7.2,18.55,1,1,0,0,0,8.7,20);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line2, new cjs.Rectangle(-1.5,-1.4,17.3,40), null);


(lib.doodle_line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,60,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.doodle_line1_sub();
	this.line.name = "line";
	this.line.setTransform(25,17,1,1,0,0,0,26.5,18.5);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle_line1, new cjs.Rectangle(-1.5,-1.5,53,37), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("ApzNIQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwByhxAuMgi6AOGQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_54 = new cjs.Graphics().p("Ap3NKQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOFQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_55 = new cjs.Graphics().p("AqENPQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_56 = new cjs.Graphics().p("AqiNbQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_57 = new cjs.Graphics().p("ArVNwQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQByAwAuByQAvBygxBxQgwByhyAuMgi5AOFQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_58 = new cjs.Graphics().p("AsaOMQhxgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_59 = new cjs.Graphics().p("AtdOnQhxgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_60 = new cjs.Graphics().p("AuTO9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAvQBzAxAuByQAuBygxBxQgwBwhxAvMgi6AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_61 = new cjs.Graphics().p("Au8PNQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_62 = new cjs.Graphics().p("AvbPaQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQBzAwAuByQAuBygxBxQgwBxhyAuMgi5AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_63 = new cjs.Graphics().p("AvzPkQhxgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg6gZg");
	var mask_graphics_64 = new cjs.Graphics().p("AwHPsQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBxAvQByAxAuByQAuBygxBxQgvBwhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_65 = new cjs.Graphics().p("AwWPyQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBwAvQBzAxAuByQAuBygxBxQgvBwhyAuMgi6AOHQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_66 = new cjs.Graphics().p("AwiP3QhwgwguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAxAuByQAuBygxBwQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_67 = new cjs.Graphics().p("AwrP6QhwgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_68 = new cjs.Graphics().p("AwyP9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_69 = new cjs.Graphics().p("Aw3P/QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_70 = new cjs.Graphics().p("Aw6QAQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwBxhxAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_71 = new cjs.Graphics().p("Aw8QBQhwgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_72 = new cjs.Graphics().p("Aw8QBQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg6gZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:202.0962,y:86.5199}).wait(1).to({graphics:mask_graphics_54,x:201.7207,y:86.6713}).wait(1).to({graphics:mask_graphics_55,x:200.3452,y:87.2276}).wait(1).to({graphics:mask_graphics_56,x:197.4159,y:88.4121}).wait(1).to({graphics:mask_graphics_57,x:192.2778,y:90.4898}).wait(1).to({graphics:mask_graphics_58,x:185.33,y:93.2993}).wait(1).to({graphics:mask_graphics_59,x:178.6284,y:96.0092}).wait(1).to({graphics:mask_graphics_60,x:173.2948,y:98.166}).wait(1).to({graphics:mask_graphics_61,x:169.2189,y:99.8141}).wait(1).to({graphics:mask_graphics_62,x:166.0817,y:101.0827}).wait(1).to({graphics:mask_graphics_63,x:163.6368,y:102.0714}).wait(1).to({graphics:mask_graphics_64,x:161.716,y:102.8481}).wait(1).to({graphics:mask_graphics_65,x:160.2043,y:103.4594}).wait(1).to({graphics:mask_graphics_66,x:159.0208,y:103.938}).wait(1).to({graphics:mask_graphics_67,x:158.1068,y:104.3076}).wait(1).to({graphics:mask_graphics_68,x:157.4183,y:104.586}).wait(1).to({graphics:mask_graphics_69,x:156.9218,y:104.7867}).wait(1).to({graphics:mask_graphics_70,x:156.5909,y:104.9205}).wait(1).to({graphics:mask_graphics_71,x:156.4046,y:104.9959}).wait(1).to({graphics:mask_graphics_72,x:156.3462,y:105.0199}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(102.75,162.9,1,1,0,0,0,42,16.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AQ4K1MgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AQ4K6MgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AQ4LGMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AQ4LaMgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AQ4LyMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AQ4MNMgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AQ4MpMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AQ4NBMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AQ4NVMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB3QghB2hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AQ4NhMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AQ4NmMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-96.7896,y:70.4804}).wait(1).to({graphics:mask_1_graphics_45,x:-93.6755,y:70.912}).wait(1).to({graphics:mask_1_graphics_46,x:-84.6383,y:72.1637}).wait(1).to({graphics:mask_1_graphics_47,x:-70.5624,y:74.1133}).wait(1).to({graphics:mask_1_graphics_48,x:-52.8258,y:76.57}).wait(1).to({graphics:mask_1_graphics_49,x:-33.1646,y:79.2932}).wait(1).to({graphics:mask_1_graphics_50,x:-13.5033,y:82.0164}).wait(1).to({graphics:mask_1_graphics_51,x:4.2333,y:84.473}).wait(1).to({graphics:mask_1_graphics_52,x:18.3092,y:86.4226}).wait(1).to({graphics:mask_1_graphics_53,x:27.3464,y:87.6744}).wait(1).to({graphics:mask_1_graphics_54,x:30.4604,y:88.1054}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(87.45,129.7,1,1,0,0,0,57.2,16.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AqeI4Qhqg9gfh3Qggh2A8hrQA/hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_39 = new cjs.Graphics().p("Aq/I4Qhqg9gfh3Qggh2A9hrQA+hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AsbI4Qhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJuQB3ggBpA9QBsA+AgB3QAfB2g+BqQg9Brh2AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AugI7Qhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB3g+BqQg9Brh3AfMgkVAJvQgoAKgnAAQhLAAhHgpg");
	var mask_2_graphics_42 = new cjs.Graphics().p("Aw0JjQhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB2g+BqQg9Brh3AfMgkUAJvQgpALgnAAQhLAAhHgpg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Ay6KHQhqg9gfh3Qggh2A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBrA+AgB3QAgB2g/BqQg8Bqh3AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0WKgQhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJvQB3gfBqA9QBrA+AgB2QAfB3g+BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0fKpQhqg9ggh3Qgfh3A8hrQA/hqB2gfMAkVgJvQB3gfBqA9QBrA+AgB2QAgB3g/BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:210.152,y:47.6773}).wait(1).to({graphics:mask_2_graphics_39,x:206.8592,y:49.4475}).wait(1).to({graphics:mask_2_graphics_40,x:197.6331,y:54.4074}).wait(1).to({graphics:mask_2_graphics_41,x:184.3009,y:61.2431}).wait(1).to({graphics:mask_2_graphics_42,x:169.5032,y:65.2207}).wait(1).to({graphics:mask_2_graphics_43,x:156.171,y:68.8043}).wait(1).to({graphics:mask_2_graphics_44,x:146.9448,y:71.2843}).wait(1).to({graphics:mask_2_graphics_45,x:141.2573,y:72.1694}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(90.65,97,1,1,0,0,0,60.4,16.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARZIjMgkwgIBQh4gbhChnQhChnAah4QAah4BnhDQBohBB4AaMAkwAIBQB4AbBCBlQBDBpgbB4QgaB4hoBBQhKAxhTAAQggAAgigIg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-92.9368,y:26.509}).wait(1).to({graphics:mask_3_graphics_32,x:-89.047,y:27.3834}).wait(1).to({graphics:mask_3_graphics_33,x:-77.8467,y:29.9013}).wait(1).to({graphics:mask_3_graphics_34,x:-60.6868,y:33.759}).wait(1).to({graphics:mask_3_graphics_35,x:-39.6371,y:38.4911}).wait(1).to({graphics:mask_3_graphics_36,x:-17.2365,y:43.5269}).wait(1).to({graphics:mask_3_graphics_37,x:3.8132,y:48.259}).wait(1).to({graphics:mask_3_graphics_38,x:20.973,y:52.1166}).wait(1).to({graphics:mask_3_graphics_39,x:32.1733,y:54.6345}).wait(1).to({graphics:mask_3_graphics_40,x:36.0632,y:55.4651}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(91.3,67.5,1,1,0,0,0,59.7,13.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("ArPHpQhnhFgZh6QgYh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBoBGAZB6QAYB6hGBoQhEBnh7AZMglbAHdQggAHgeAAQhYAAhNg0g");
	var mask_4_graphics_20 = new cjs.Graphics().p("ArTHpQhnhFgYh6QgZh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBpBGAYB6QAYB6hGBoQhEBnh6AZMglcAHdQgfAHgfAAQhXAAhOg0g");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArfHpQhnhFgYh6QgYh6BEhpQBGhmB7gYMAlagHeQB7gYBnBEQBoBGAZB6QAYB7hGBnQhFBnh6AZMglbAHdQgfAGgfAAQhXAAhOgzg");
	var mask_4_graphics_22 = new cjs.Graphics().p("Ar1HoQhnhEgZh6QgYh7BFhoQBGhmB6gYMAlZgHeQB7gYBnBFQBoBFAYB7QAZB6hGBnQhFBnh6AZMglaAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_23 = new cjs.Graphics().p("AsbHoQhnhFgYh6QgYh6BEhoQBGhmB6gYMAlYgHdQB6gZBnBFQBoBGAZB6QAYB6hGBnQhEBnh6AYMglYAHdQggAHgeAAQhXAAhOg0g");
	var mask_4_graphics_24 = new cjs.Graphics().p("AtUHnQhnhEgYh6QgYh6BEhoQBGhmB6gYMAlVgHdQB5gYBnBFQBpBFAYB6QAYB6hGBnQhEBnh6AYMglVAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_25 = new cjs.Graphics().p("AulHnQhnhFgYh6QgZh5BFhoQBFhmB6gYMAlRgHcQB6gYBmBEQBoBGAZB6QAYB5hGBnQhEBnh6AYMglRAHcQgfAGgeAAQhXAAhNgzg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AwLHlQhnhEgYh5QgYh6BEhnQBGhmB5gYMAlLgHbQB6gYBmBFQBoBFAYB5QAZB6hGBmQhEBnh6AYMglLAHbQgfAGgfAAQhWAAhNg0g");
	var mask_4_graphics_27 = new cjs.Graphics().p("AxzHkQhnhEgYh5QgYh5BEhnQBGhmB5gYMAlGgHZQB5gZBmBFQBoBFAYB5QAYB5hFBmQhEBnh5AYMglHAHZQgfAHgeAAQhXAAhMg0g");
	var mask_4_graphics_28 = new cjs.Graphics().p("AzLHjQhmhEgYh4QgYh5BDhoQBGhlB5gYMAlBgHYQB5gZBmBFQBoBFAYB5QAYB4hFBnQhEBmh5AYMglCAHZQgfAGgeAAQhWAAhNg0g");
	var mask_4_graphics_29 = new cjs.Graphics().p("A0OHjQhmhEgYh5QgYh5BEhnQBFhlB5gYMAk+gHYQB5gYBmBEQBnBFAYB5QAYB5hFBmQhEBmh5AYMgk+AHYQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A0/HiQhlhEgYh4QgYh5BDhnQBFhlB5gYMAk8gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk8AHXQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A1CHiQhmhEgYh4QgYh5BEhnQBFhlB5gYMAk6gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk6AHXQggAGgeAAQhWAAhMgzg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A1BHiQhmhEgYh5QgYh4BEhnQBFhlB4gYMAk5gHWQB4gYBmBDQBnBFAYB5QAYB4hFBmQhEBmh4AYMgk5AHWQgfAHgeAAQhWAAhMgzg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:214.6102,y:3.3334}).wait(1).to({graphics:mask_4_graphics_20,x:214.2404,y:3.4806}).wait(1).to({graphics:mask_4_graphics_21,x:212.9875,y:3.9786}).wait(1).to({graphics:mask_4_graphics_22,x:210.5721,y:4.9385}).wait(1).to({graphics:mask_4_graphics_23,x:206.5928,y:6.5199}).wait(1).to({graphics:mask_4_graphics_24,x:200.5171,y:8.9344}).wait(1).to({graphics:mask_4_graphics_25,x:191.8775,y:12.3679}).wait(1).to({graphics:mask_4_graphics_26,x:181.0603,y:16.6668}).wait(1).to({graphics:mask_4_graphics_27,x:170.0151,y:21.0562}).wait(1).to({graphics:mask_4_graphics_28,x:160.7061,y:24.7557}).wait(1).to({graphics:mask_4_graphics_29,x:153.6244,y:27.57}).wait(1).to({graphics:mask_4_graphics_30,x:148.4436,y:29.629}).wait(1).to({graphics:mask_4_graphics_31,x:141.5638,y:31.1044}).wait(1).to({graphics:mask_4_graphics_32,x:136.4625,y:32.1336}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(94.8,41.2,1,1,0,0,0,63.2,13.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2,188.1,211.9);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pptLogo
	this.pptLogo = new lib.pptLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(50,32.6,1,1,0,0,0,53,32.6);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(-24.65,171.85,1,1,0,0,0,76.7,69.8);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	// files
	this.file4 = new lib.file4();
	this.file4.name = "file4";
	this.file4.setTransform(136.75,122.15,0.845,0.845,0,0,0,46.6,61.1);

	this.file5 = new lib.file5();
	this.file5.name = "file5";
	this.file5.setTransform(318.55,229.7,1,1,0,0,0,82.4,90.8);

	this.file3 = new lib.file3();
	this.file3.name = "file3";
	this.file3.setTransform(312.65,113.75,0.5,0.5,0,0,0,82.1,90.5);

	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(134.6,205.6,0.5,0.5,0,0,0,70.5,92);

	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(199,110.5,0.5,0.5,0,0,0,78.5,83);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file1},{t:this.file2},{t:this.file3},{t:this.file5},{t:this.file4}]}).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(225.85,146,1,1,0,0,0,187.5,125.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x1();
	this.instance.setTransform(38.35,20.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-135.3,-115.8,618.1,501.7), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhNJGQgHAAgIgGIgGgHIg9hZQgKgRgOgJQgOgKgXgCIpJAAIAAv/IZLAAIAASLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:210.875,y:79.025}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(205.5,150.3,1,1,0,0,0,205.5,150.3);

	var maskedShapeInstanceList = [this.ui];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-135.3,-19.6,548.7,405.5);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-13.2,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Poplines
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.popRight},{t:this.popLeft}]}).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.6,143.7,27), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_156 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(156).call(this.frame_156).wait(7));

	// Layer_3 copy 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_109 = new cjs.Graphics().p("AJuGGQgeg1gmhOQgmhOgYg6QgXg5AFgCIBigwQAFgCAeA1QAfA2AmBOQAmBPAXA4QAYA6gFADIhiAvIAAAAQgGAAgeg0g");
	var mask_graphics_110 = new cjs.Graphics().p("AJrGHQgfg2gmhOQgmhOgXg6QgXg5AFgCIBogzQAGgDAeA2QAfA2AmBOQAmBOAXA5QAYA6gFACIhpAzIAAAAQgHAAgdgzg");
	var mask_graphics_111 = new cjs.Graphics().p("AJmGHQgeg1gmhPQgmhOgYg6QgWg5AFgDIBxg2QAGgDAeA1QAgA2AmBOQAmBOAXA5QAXA6gGADIhxA3IAAAAQgHAAgegzg");
	var mask_graphics_112 = new cjs.Graphics().p("AJhGHQgfg1gmhOQgmhPgXg6QgWg5AGgDIB6g8QAHgDAfA1QAgA2AmBOQAmBPAWA5QAXA6gGADIh7A8IgBAAQgHAAgegzg");
	var mask_graphics_113 = new cjs.Graphics().p("AJaGHQgfg1gmhOQgmhOgXg6QgWg6AHgDICHhBQAHgDAgAzQAgA2AmBOQAmBOAWA6QAWA6gHADIiHBCIgBAAQgIAAgegyg");
	var mask_graphics_114 = new cjs.Graphics().p("AJSGHQggg0gmhOQgmhPgWg6QgVg6AHgEICWhHQAIgEAgAzQAhA2AmBOQAmBOAVA6QAWA6gIAEIiVBJIgCAAQgIAAgfgyg");
	var mask_graphics_115 = new cjs.Graphics().p("AJJGHQghg0gmhOQgmhOgVg7QgVg6AJgEICmhQQAJgEAhAzQAhA1AmBOQAmBOAVA6QAVA7gIAEIinBRIgCABQgJAAgfgyg");
	var mask_graphics_116 = new cjs.Graphics().p("AI+GIQgig0gmhOQgmhPgUg7QgUg6AJgFIC7haQAKgEAhAzQAiA0AmBOQAmBPAUA6QAVA7gKAFIi7BbIgBAAQgLAAgfgwg");
	var mask_graphics_117 = new cjs.Graphics().p("AIxGIQgigzgmhPQgmhOgUg7QgTg7ALgFIDShlQAKgGAjAzQAiA0AmBOQAmBPAUA6QATA8gKAFIjSBmIgCABQgMAAgggwg");
	var mask_graphics_118 = new cjs.Graphics().p("AIjGIQgjgygmhPQgmhOgTg8QgSg7AMgGIDrhyQANgGAjAzQAjAzAnBOQAmBPASA7QATA8gMAGIjsByIgDABQgNAAgggvg");
	var mask_graphics_119 = new cjs.Graphics().p("AITGJQgkgzgmhOQgnhOgRg9QgRg7ANgHIEJiAQAOgGAkAyQAlAyAmBOQAmBPARA7QASA9gOAHIkJCAIgDABQgOAAghgtg");
	var mask_graphics_120 = new cjs.Graphics().p("AIBGJQgmgygmhOQgmhOgQg9QgQg8APgIIEqiQQAPgHAlAyQAmAxAmBPQAmBOAQA8QARA9gPAIIkqCQIgEABQgQAAghgsg");
	var mask_graphics_121 = new cjs.Graphics().p("AHtGKQgngxgmhPQgmhOgPg+QgPg9ARgIIFOihQARgJAnAyQAnAyAmBNQAmBOAPA9QAPA+gRAIIlOCiIgFACQgSAAghgrg");
	var mask_graphics_122 = new cjs.Graphics().p("AHXGKQgpgwgmhPQgmhOgOg+QgNg+ATgJIF2i1QATgJAoAwQApAyAmBNQAmBOANA+QAOA+gTAKIl2C1QgDACgDAAQgTAAgigqg");
	var mask_graphics_123 = new cjs.Graphics().p("AG/GLQgqgwgmhOQgmhPgMg/QgMg+AVgKIGgjKQAVgKAqAwQAqAwAmBNQAmBPAMA+QAMA/gVALImgDKQgDACgFAAQgUAAgjgog");
	var mask_graphics_124 = new cjs.Graphics().p("AGlGLQgrgvgmhOQgmhOgLhAQgKg/AYgMIHNjfQAXgMAsAvQAsAwAmBOQAmBOAKA/QAKBAgXALInNDhQgFACgFAAQgWAAgkgng");
	var mask_graphics_125 = new cjs.Graphics().p("AGLGMQgtgugmhPQgnhOgJhBQgIhAAagMIH8j3QAagMAtAuQAuAvAmBOQAmBNAIBAQAJBBgaANIn8D3QgFADgHAAQgXAAgkglg");
	var mask_graphics_126 = new cjs.Graphics().p("AFvGMQgvgtgmhOQgmhPgHhBQgGhBAcgOIItkOQAcgOAvAuQAvAuAmBOQAmBNAHBBQAHBCgcAOIotEPQgHADgHAAQgZAAglgkg");
	var mask_graphics_127 = new cjs.Graphics().p("AFTGNQgwgtgmhOQgmhOgGhDQgEhBAegPIJekmQAfgPAwAsQAxAuAmBOQAnBOAEBBQAGBCgfAPIpeEnQgHAEgJAAQgbAAglgig");
	var mask_graphics_128 = new cjs.Graphics().p("AE4GNQgygrgmhPQgnhOgDhDQgDhDAhgQIKOk9QAhgQAyArQAzAtAmBOQAmBOADBCQAEBDghAQIqOE+QgJAFgKAAQgcAAglghg");
	var mask_graphics_129 = new cjs.Graphics().p("AEdGOQg0grgmhOQgmhPgChEQgBhDAjgSIK9lTQAkgSAzArQA1ArAmBPQAmBOACBDQACBEgkARIq9FVQgKAFgLAAQgdAAgmgfg");
	var mask_graphics_130 = new cjs.Graphics().p("AEDGOQg2gqgmhOQgmhOAAhFQAAhFAmgSILqlqQAmgSA1AqQA3AqAmBPQAmBOAABEQAABEgmASIrqFrQgLAGgNAAQgeAAgmgeg");
	var mask_graphics_131 = new cjs.Graphics().p("ADqGOQg3gpgmhOQgmhOABhGQAChFAogUIMVl+QAogUA3AqQA4AqAmBOQAmBOgCBFQgBBFgoATIsVGAQgMAGgPAAQgfAAgmgdg");
	var mask_graphics_132 = new cjs.Graphics().p("ADTGPQg4gpgmhOQgmhOAChHQADhFArgVIM8mSQAqgVA5ApQA5ApAmBOQAmBPgDBFQgDBHgqATIs8GTQgOAHgQAAQggAAgmgbg");
	var mask_graphics_133 = new cjs.Graphics().p("AC9GPQg5gogmhOQgmhOADhHQAFhHAsgVINimkQAsgWA6AoQA7ApAmBOQAmBOgFBGQgEBHgsAWItiGkQgPAIgRAAQggAAgngbg");
	var mask_graphics_134 = new cjs.Graphics().p("ACpGPQg7gngmhOQgmhOAFhIQAGhHAugWIOFm2QAugWA7AnQA8AoAmBPQAmBOgGBHQgFBHguAXIuFG1QgQAIgSAAQghAAgngag");
	var mask_graphics_135 = new cjs.Graphics().p("ACXGQQg8gngmhOQgmhOAGhJQAHhHAwgXIOknFQAvgXA9AnQA9AnAmBOQAmBPgHBHQgHBIgvAXIukHFQgSAJgTAAQgiAAgmgZg");
	var mask_graphics_136 = new cjs.Graphics().p("ACGGYQg9gmgmhOQglhPAGhIQAIhIAxgYIPCnTQAxgYA9AmQA+AnAmBOQAmBPgIBIQgHBIgxAYIvCHTQgTAJgUAAQgiAAgmgYg");
	var mask_graphics_137 = new cjs.Graphics().p("AB2GgQg+gmgmhOQglhPAIhJQAJhIAygZIPcngQAygYA/AmQA/AmAmBOQAmBPgJBIQgJBJgyAZIvcHgQgUAJgVAAQgiAAgngXg");
	var mask_graphics_138 = new cjs.Graphics().p("ABoGnQg/gmgmhOQglhOAJhKQAKhJAzgZIP0nrQA0gaA/AmQBAAmAmBOQAmBOgKBJQgJBKg0AZIv0HsQgVAKgWAAQgiAAgngXg");
	var mask_graphics_139 = new cjs.Graphics().p("ABbGtQhAglglhOQgmhOAKhKQALhKA0gZIQKn3QA1gaBAAlQBBAmAmBOQAmBPgLBJQgKBKg0AZIwLH3QgWAKgXAAQgiAAgngWg");
	var mask_graphics_140 = new cjs.Graphics().p("ABQGzQhBglglhOQgmhOALhLQALhJA1gbIQfoAQA1gaBBAlQBCAlAmBOQAmBOgMBKQgLBKg1AbIwfIAQgWALgYAAQgjAAgmgWg");
	var mask_graphics_141 = new cjs.Graphics().p("ABFG4QhBgkglhPQgmhOALhKQAMhKA2gbIQxoJQA2gbBCAlQBCAkAmBPQAmBOgMBKQgMBLg2AaIwxIJQgXALgZAAQgiAAgngVg");
	var mask_graphics_142 = new cjs.Graphics().p("AA8G9QhBgkgmhPQgmhOALhLQANhKA4gbIRAoRQA3gbBCAkQBDAkAmBPQAmBOgNBKQgMBLg3AbIxBIRQgYAMgZAAQgjAAgmgVg");
	var mask_graphics_143 = new cjs.Graphics().p("AAzHBQhBgkgmhOQgmhOAMhMQANhKA5gcIROoYQA4gbBDAkQBDAkAmBOQAmBPgNBKQgMBLg5AcIxPIYQgZAMgaAAQgjAAgmgVg");
	var mask_graphics_144 = new cjs.Graphics().p("AArHFQhBgkgnhOQgmhPANhLQAOhLA5gbIRcofQA5gcBDAkQBDAkAmBOQAnBPgOBKQgNBMg5AcIxdIeQgZAMgaAAQgjAAgngUg");
	var mask_graphics_145 = new cjs.Graphics().p("AAlHIQhDgjgmhPQgmhOAOhMQAOhLA5gcIRookQA5gcBDAkQBFAkAmBOQAmBOgPBLQgNBMg5AcIxpIkQgZAMgbAAQgjAAgmgUg");
	var mask_graphics_146 = new cjs.Graphics().p("AAfHLQhDgjgmhPQgmhOAOhMQAOhLA6gcIRyopQA6gcBDAjQBFAkAmBOQAmBOgPBLQgNBMg6AcIxzIpQgZANgcAAQgjAAgmgUg");
	var mask_graphics_147 = new cjs.Graphics().p("AAZHNQhCgjgnhOQgmhOAOhMQAPhLA7gdIR6otQA7gdBEAjQBFAkAmBOQAmBOgPBMQgOBMg7AcIx7ItQgaANgcAAQgjAAgngUg");
	var mask_graphics_148 = new cjs.Graphics().p("AAVHQQhDgjgmhPQgmhOAOhMQAPhLA7gdISCoxQA7gdBEAjQBFAjAmBPQAnBOgQBLQgOBNg7AcIyDIxQgaANgdAAQgjAAgmgTg");
	var mask_graphics_149 = new cjs.Graphics().p("AARHRQhDgigmhPQgnhOAPhMQAPhMA8gcISIo1QA8gdBEAjQBGAjAmBPQAmBOgQBMQgOBMg8AdIyJI0QgbANgdAAQgjAAgmgUg");
	var mask_graphics_150 = new cjs.Graphics().p("AAOHTQhEgjgmhOQgmhOAPhMQAPhMA8gdISOo3QA8gdBEAjQBGAjAmBOQAmBOgQBMQgOBMg8AdIyPI3QgbANgdAAQgjAAgmgTg");
	var mask_graphics_151 = new cjs.Graphics().p("AALHUQhEgigmhPQgmhOAPhMQAQhMA8gdISSo5QA8gdBFAiQBGAjAmBPQAmBOgQBMQgPBMg7AdIyUI5QgbAOgdAAQgkAAgmgUg");
	var mask_graphics_152 = new cjs.Graphics().p("AAJHVQhEgigmhOQgmhPAPhMQAQhMA8gdISWo7QA8gdBFAiQBGAjAmBPQAmBOgQBMQgPBMg8AdIyXI7QgbANgeAAQgjAAgmgTg");
	var mask_graphics_153 = new cjs.Graphics().p("AAHHWQhEgigmhPQgmhOAPhMQAQhMA9gdISZo9QA8gdBFAiQBGAjAmBPQAmBOgQBMQgPBMg8AeIyaI8QgcANgdAAQgjAAgngTg");
	var mask_graphics_154 = new cjs.Graphics().p("AAGHXQhEgjgmhOQgmhOAPhNQAQhMA9gdISbo9QA8geBFAjQBGAjAmBOQAmBOgQBMQgPBNg8AdIycI9QgcAOgdAAQgjAAgngTg");
	var mask_graphics_155 = new cjs.Graphics().p("AAGHXQhEgignhPQgmhOAQhMQAQhMA8geISco+QA8gdBFAjQBHAjAmBOQAmBOgQBMQgQBNg8AdIydI+QgbANgeAAQgjAAgmgTg");
	var mask_graphics_156 = new cjs.Graphics().p("AADHXQhEgigmhPQgmhOAPhMQARhMA8geISco+QA9gdBFAjQBGAiAmBPQAmBOgQBMQgPBMg9AeIydI+QgcANgdAAQgjAAgngTg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(109).to({graphics:mask_graphics_109,x:75.6968,y:44.2307}).wait(1).to({graphics:mask_graphics_110,x:76.0543,y:44.2146}).wait(1).to({graphics:mask_graphics_111,x:76.5154,y:44.1939}).wait(1).to({graphics:mask_graphics_112,x:77.0895,y:44.1682}).wait(1).to({graphics:mask_graphics_113,x:77.7865,y:44.1373}).wait(1).to({graphics:mask_graphics_114,x:78.6175,y:44.1007}).wait(1).to({graphics:mask_graphics_115,x:79.5943,y:44.058}).wait(1).to({graphics:mask_graphics_116,x:80.7294,y:44.009}).wait(1).to({graphics:mask_graphics_117,x:82.0355,y:43.9531}).wait(1).to({graphics:mask_graphics_118,x:83.525,y:43.8903}).wait(1).to({graphics:mask_graphics_119,x:85.2087,y:43.8203}).wait(1).to({graphics:mask_graphics_120,x:87.0945,y:43.7432}).wait(1).to({graphics:mask_graphics_121,x:89.1858,y:43.6593}).wait(1).to({graphics:mask_graphics_122,x:91.4784,y:43.569}).wait(1).to({graphics:mask_graphics_123,x:93.9588,y:43.4734}).wait(1).to({graphics:mask_graphics_124,x:96.6025,y:43.3738}).wait(1).to({graphics:mask_graphics_125,x:99.3733,y:43.2718}).wait(1).to({graphics:mask_graphics_126,x:102.2257,y:43.1692}).wait(1).to({graphics:mask_graphics_127,x:105.1085,y:43.0681}).wait(1).to({graphics:mask_graphics_128,x:107.9705,y:42.9701}).wait(1).to({graphics:mask_graphics_129,x:110.7652,y:42.8766}).wait(1).to({graphics:mask_graphics_130,x:113.4547,y:42.7886}).wait(1).to({graphics:mask_graphics_131,x:116.0145,y:42.7068}).wait(1).to({graphics:mask_graphics_132,x:118.4229,y:42.6314}).wait(1).to({graphics:mask_graphics_133,x:120.6701,y:42.5623}).wait(1).to({graphics:mask_graphics_134,x:122.7533,y:42.4993}).wait(1).to({graphics:mask_graphics_135,x:124.6743,y:42.424}).wait(1).to({graphics:mask_graphics_136,x:126.4382,y:41.5579}).wait(1).to({graphics:mask_graphics_137,x:128.052,y:40.7662}).wait(1).to({graphics:mask_graphics_138,x:129.5238,y:40.0447}).wait(1).to({graphics:mask_graphics_139,x:130.862,y:39.3891}).wait(1).to({graphics:mask_graphics_140,x:132.0751,y:38.7952}).wait(1).to({graphics:mask_graphics_141,x:133.1713,y:38.2587}).wait(1).to({graphics:mask_graphics_142,x:134.1585,y:37.7758}).wait(1).to({graphics:mask_graphics_143,x:135.0439,y:37.3428}).wait(1).to({graphics:mask_graphics_144,x:135.8343,y:36.9564}).wait(1).to({graphics:mask_graphics_145,x:136.5361,y:36.6135}).wait(1).to({graphics:mask_graphics_146,x:137.155,y:36.3111}).wait(1).to({graphics:mask_graphics_147,x:137.6964,y:36.0467}).wait(1).to({graphics:mask_graphics_148,x:138.1651,y:35.8177}).wait(1).to({graphics:mask_graphics_149,x:138.5656,y:35.6222}).wait(1).to({graphics:mask_graphics_150,x:138.9021,y:35.4579}).wait(1).to({graphics:mask_graphics_151,x:139.1783,y:35.323}).wait(1).to({graphics:mask_graphics_152,x:139.3977,y:35.2159}).wait(1).to({graphics:mask_graphics_153,x:139.5636,y:35.1349}).wait(1).to({graphics:mask_graphics_154,x:139.6788,y:35.0787}).wait(1).to({graphics:mask_graphics_155,x:139.7461,y:35.0458}).wait(1).to({graphics:mask_graphics_156,x:139.5696,y:35.2283}).wait(7));

	// Layer_14
	this.instance = new lib.doodle_line6();
	this.instance.setTransform(212.1,38.85,1,1,0,0,0,63.6,29.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(111).to({_off:false},0).wait(52));

	// Layer_3 copy 3 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_88 = new cjs.Graphics().p("ANSCUIh5gKIh4gLIgzgFIABgHIAzAEIB4AKIB5ALIAyAFIgBAHIAAAAIgygEg");
	var mask_1_graphics_89 = new cjs.Graphics().p("ANSCVIh5gKIh4gLIgzgFIABgIIAzADIB4AKIB5ALIAyAFIgBAJIgBAAIgxgEg");
	var mask_1_graphics_90 = new cjs.Graphics().p("ANSCYIh5gKIh5gLIgygFIABgNIAzADIB4AKIB5ALIAxAFIgBANIgBAAIgwgDg");
	var mask_1_graphics_91 = new cjs.Graphics().p("ANRCcIh5gKIh4gLQgzgFAAgBIACgTQAAgBAzADIB4AKIB5ALQAyAFgBABIgBAUIgDAAIgvgDg");
	var mask_1_graphics_92 = new cjs.Graphics().p("ANQCiIh5gJIh4gMQgzgFAAgBIADgeQAAgBAzADIB4AJIB5AMQAyAFgBACIgCAdIgFAAIgtgCg");
	var mask_1_graphics_93 = new cjs.Graphics().p("ANPCqQgzgDhGgGQhHgGgygGQgygGAAgCIAEgpQAAgDAzADQAxADBHAGQBHAGAyAGQAyAGgBACIgDApQAAABgKAAIgogBg");
	var mask_1_graphics_94 = new cjs.Graphics().p("ANNCzQgygDhHgGQhGgGgygGQgygHAAgCIAFg4QAAgDAzACQAxADBHAGQBHAGAyAGQAxAGAAADIgFA4QAAACgPAAIgjgBg");
	var mask_1_graphics_95 = new cjs.Graphics().p("ANMC9QgzgChHgGQhGgGgygHQgygHABgEIAGhIQAAgEAzACQAyACBGAGQBHAGAyAHQAxAHAAAEIgGBIQAAACgYAAIgaAAg");
	var mask_1_graphics_96 = new cjs.Graphics().p("ANKDIQgzgBhGgGQhHgGgxgIQgzgIABgEIAIhbQAAgEAzABQAyABBGAGQBHAGAyAIQAxAHAAAFIgIBaQAAAEghAAIgRAAg");
	var mask_1_graphics_97 = new cjs.Graphics().p("ANIDUQgzgBhGgGQhHgGgxgIQgygIAAgGIAJhuQABgGAzAAQAyABBGAGQBHAGAyAIQAxAJAAAFIgJBuQgBAGgsAAIgGAAg");
	var mask_1_graphics_98 = new cjs.Graphics().p("ALMDbQhGgHgxgJQgygJAAgGIALiDQABgHAzgBQAyAABGAGQBHAGAyAJQAxAJAAAHIgLCDQgBAHgyAAIgHAAQgwAAhDgFg");
	var mask_1_graphics_99 = new cjs.Graphics().p("ALKDoQhGgGgygKQgygJABgIIANiZQABgIAzgBQAygBBHAGQBGAGAyAKQAxAJAAAIIgNCZQgBAIgyABIgSAAQgtAAg7gFg");
	var mask_1_graphics_100 = new cjs.Graphics().p("ALID2QhHgGgxgKQgygLABgJIAPivQABgJAzgCQAygCBHAGQBGAGAyALQAxAKAAAJIgPCvQgBAJgyACIgbABQgqAAg1gFg");
	var mask_1_graphics_101 = new cjs.Graphics().p("ALGEEQhHgGgxgLQgygMABgKIARjGQABgKAzgCQAygDBHAGQBGAGAyALQAxAMgBAKIgRDGQAAAKgzADIgiABQgnAAgwgFg");
	var mask_1_graphics_102 = new cjs.Graphics().p("ALDESQhGgGgxgMQgygMABgLIATjdQABgLAzgDQAygDBHAFQBHAGAxAMQAxANgBALIgTDcQgBALgyAEIgpABQglAAgsgEg");
	var mask_1_graphics_103 = new cjs.Graphics().p("ALBEgQhGgGgxgNQgygNABgNIAVjyQABgLAzgEQAygFBHAGQBHAGAxAMQAxAOgBAMIgVDyQgBAMgyAFQgWABgZAAQgiAAgpgDg");
	var mask_1_graphics_104 = new cjs.Graphics().p("AK/EtQhHgGgwgOQgygOABgNIAXkGQABgNAzgGQAzgFBGAGQBHAGAxAOQAxANgBANIgXEHQgBAOgyAFQgYACgcAAQggAAgmgDg");
	var mask_1_graphics_105 = new cjs.Graphics().p("AK9E5QhHgGgwgOQgygPABgOIAYkaQACgOAzgGQAzgGBGAGQBHAGAxAOQAxAPgBANIgYEbQgCAPgyAFQgZADgfAAQgeAAgkgDg");
	var mask_1_graphics_106 = new cjs.Graphics().p("AK7FFQhHgHgwgPQgygPACgPIAZksQACgPAzgHQAzgHBGAGQBHAHAxAPQAxAPgBAOIgaEtQgBAQgzAGQgbAEggAAQgdAAgigDg");
	var mask_1_graphics_107 = new cjs.Graphics().p("AK5FPQhGgGgxgQQgxgQABgQIAbk8QACgRAzgHQAzgHBGAGQBHAGAyAQQAwAQgBAQIgcE8QgBARgzAHQgbAEgiAAQgcAAghgDg");
	var mask_1_graphics_108 = new cjs.Graphics().p("AK4FYQhHgGgwgRQgygQACgRIAclLQACgRAzgHQAzgIBGAGQBHAGAyARQAwAQgBARIgdFLQgBAQgzAIQgdAEgjAAQgbAAgfgCg");
	var mask_1_graphics_109 = new cjs.Graphics().p("AK3FfQhHgGgxgRQgxgQACgSIAdlXQACgRAzgIQAzgIBHAGQBGAGAyAQQAwARgBASIgeFXQgBARgzAIQgeAFgjAAQgbAAgegDg");
	var mask_1_graphics_110 = new cjs.Graphics().p("AK2FlQhHgGgxgRQgxgRACgSIAelhQACgSAzgIQAzgIBHAGQBGAGAyARQAwARgBASIgfFgQgBASgzAJQgeAFglAAQgaAAgdgDg");
	var mask_1_graphics_111 = new cjs.Graphics().p("AK1FpQhHgGgwgRQgygRACgTIAflnQACgSAzgJQAzgJBHAGQBGAGAyASQAwARgBASIgfFoQgCASgzAJQgeAFglAAQgaAAgdgDg");
	var mask_1_graphics_112 = new cjs.Graphics().p("AK1FsQhHgGgxgSQgxgRACgTIAflrQACgTAzgJQAzgIBHAGQBGAGAyARQAwASgBASIggFsQgBASgzAJQgfAFglAAQgaAAgcgCg");
	var mask_1_graphics_113 = new cjs.Graphics().p("AK1FsQhHgGgwgSQgygRACgTIAfltQACgSA0gJQAygJBHAGQBHAGAxASQAxARgCATIggFtQgBASgzAJQgfAGglAAQgaAAgcgDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(88).to({graphics:mask_1_graphics_88,x:90.0519,y:15.1925}).wait(1).to({graphics:mask_1_graphics_89,x:90.0514,y:15.2716}).wait(1).to({graphics:mask_1_graphics_90,x:90.049,y:15.5084}).wait(1).to({graphics:mask_1_graphics_91,x:90.0452,y:15.901}).wait(1).to({graphics:mask_1_graphics_92,x:90.04,y:16.4457}).wait(1).to({graphics:mask_1_graphics_93,x:90.0333,y:17.1371}).wait(1).to({graphics:mask_1_graphics_94,x:90.0255,y:17.9672}).wait(1).to({graphics:mask_1_graphics_95,x:90.0165,y:18.9255}).wait(1).to({graphics:mask_1_graphics_96,x:90.0065,y:19.9986}).wait(1).to({graphics:mask_1_graphics_97,x:89.9957,y:21.1708}).wait(1).to({graphics:mask_1_graphics_98,x:89.9842,y:22.4242}).wait(1).to({graphics:mask_1_graphics_99,x:89.9723,y:23.7382}).wait(1).to({graphics:mask_1_graphics_100,x:89.9601,y:25.0905}).wait(1).to({graphics:mask_1_graphics_101,x:89.9478,y:26.4581}).wait(1).to({graphics:mask_1_graphics_102,x:89.9356,y:27.8184}).wait(1).to({graphics:mask_1_graphics_103,x:89.9237,y:29.149}).wait(1).to({graphics:mask_1_graphics_104,x:89.9123,y:30.4282}).wait(1).to({graphics:mask_1_graphics_105,x:89.9015,y:31.6352}).wait(1).to({graphics:mask_1_graphics_106,x:89.8916,y:32.7504}).wait(1).to({graphics:mask_1_graphics_107,x:89.8827,y:33.756}).wait(1).to({graphics:mask_1_graphics_108,x:89.8749,y:34.6358}).wait(1).to({graphics:mask_1_graphics_109,x:89.8683,y:35.3757}).wait(1).to({graphics:mask_1_graphics_110,x:89.8631,y:35.9638}).wait(1).to({graphics:mask_1_graphics_111,x:89.8593,y:36.3907}).wait(1).to({graphics:mask_1_graphics_112,x:89.857,y:36.6496}).wait(1).to({graphics:mask_1_graphics_113,x:89.9019,y:36.6572}).wait(50));

	// Layer_13
	this.instance_1 = new lib.doodle_line5();
	this.instance_1.setTransform(161.35,50.25,1,1,0,0,0,10.6,18.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({_off:false},0).wait(74));

	// Layer_3 copy 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_63 = new cjs.Graphics().p("AHiFSIg7hqIg5hqQgYgsABgBIARgJQABgBAYAsIA8BqIA5BqQAYAtgBAAIgRAJIAAAAQgBAAgZgrg");
	var mask_2_graphics_64 = new cjs.Graphics().p("AHiFSIg7hqIg6hqQgXgtAAAAIATgKQABgBAYAsIA7BqIA6BqQAYAtgBAAIgTAKIAAAAQgBAAgYgrg");
	var mask_2_graphics_65 = new cjs.Graphics().p("AHfFSIg6hqIg6hrQgXgsABAAIAWgMQABgBAZArIA7BqIA5BrQAYAsgBABIgWAMIAAAAQgCAAgZgrg");
	var mask_2_graphics_66 = new cjs.Graphics().p("AHcFSIg7hpIg5hsQgXgsABgBIAdgPQABgBAZArIA7BqIA5BrQAYAtgCAAIgcAQIAAAAQgCAAgZgrg");
	var mask_2_graphics_67 = new cjs.Graphics().p("AHXFSQgZgrgig+Qgig/gXgtQgXgsACgBIAmgVQACgBAZArQAaAsAiA+QAiA+AWAtQAXAtgCABIglAVIAAAAQgDAAgZgrg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AHRFSQgagrgig+Qghg+gXguQgWgtACgBIAxgaQADgCAZArQAaArAiA/QAiA+AWAtQAXAtgDABIgwAbIgBAAQgDAAgZgqg");
	var mask_2_graphics_69 = new cjs.Graphics().p("AHKFSQgagrgig+Qgig+gWguQgWgtAEgCIA+giQADgBAaAqQAbArAiA/QAhA+AWAtQAWAugDACIg/AhIAAAAQgEAAgZgpg");
	var mask_2_graphics_70 = new cjs.Graphics().p("AHBFSQgbgqghg/Qgig+gVguQgVguAEgCIBOgqQAEgCAbAqQAbArAhA+QAiA/AVAtQAVAugEACIhOArIgBAAQgEAAgagpg");
	var mask_2_graphics_71 = new cjs.Graphics().p("AG3FSQgbgqgig/Qghg+gVguQgUguAFgDIBgg0QAFgCAbAqQAcAqAhA/QAiA+AUAuQAVAugFADIhgA0IgBAAQgGAAgagog");
	var mask_2_graphics_72 = new cjs.Graphics().p("AGsFSQgcgqghg+Qgig/gTgvQgUguAGgDIB1g+QAGgEAbAqQAcAqAiA/QAhA+AUAvQAUAvgGADIh1A+IgBAAQgHAAgagng");
	var mask_2_graphics_73 = new cjs.Graphics().p("AGgFSQgcgqgig+Qghg/gTgvQgSgvAHgDICKhKQAHgDAcApQAdAqAiA+QAhA/ASAuQATAwgHADIiKBKIgBAAQgIAAgbgmg");
	var mask_2_graphics_74 = new cjs.Graphics().p("AGTFSQgdgpghg/Qghg/gSgvQgSgwAJgEIChhUQAIgFAeAoQAdAqAhA+QAiA/ARAvQASAwgIAEIiiBWIgCAAQgJAAgbglg");
	var mask_2_graphics_75 = new cjs.Graphics().p("AGGFSQgegpghg/Qghg+gRgxQgRgvAKgFIC6hiQAKgFAeAoQAeApAhA/QAhA/AQAvQARAxgJAFIi7BiIgCAAQgKAAgbgkg");
	var mask_2_graphics_76 = new cjs.Graphics().p("AF3FSQgfgpghg+Qggg/gQgxQgQgwALgGIDVhuQALgGAeAoQAgAoAgA/QAhA/AQAwQAPAxgKAGIjVBvIgDAAQgMAAgbgjg");
	var mask_2_graphics_77 = new cjs.Graphics().p("AFoFRQgggnggg/Qghg/gPgyQgOgwAMgHIDwh7QAMgGAgAnQAgAoAgA/QAhA/AOAwQAPAygMAGIjwB9IgEAAQgMAAgcgjg");
	var mask_2_graphics_78 = new cjs.Graphics().p("AFYFRQgggnghg/Qggg/gOgyQgNgxAOgHIELiJQAOgHAgAnQAhAnAhA/QAgA/AOAxQANAygOAHIkLCKIgFABQgOAAgcgig");
	var mask_2_graphics_79 = new cjs.Graphics().p("AFIFRQghgnggg/Qghg/gMgyQgMgyAPgIIEoiXQAPgHAiAnQAhAnAhA+QAgA/AMAyQAMAzgPAHIkoCYIgFABQgPAAgdghg");
	var mask_2_graphics_80 = new cjs.Graphics().p("AE4FRQgigmgghAQghg/gLgzQgLgyARgJIFFikQARgIAiAmQAjAnAgA/QAgA/ALAyQALAzgRAJIlFClQgDABgDAAQgQAAgdggg");
	var mask_2_graphics_81 = new cjs.Graphics().p("AEoFRQgkgmggg/QgfhAgLgzQgJgzASgKIFiixQASgJAjAmQAkAnAgA+QAgA/AJAzQAKA0gSAJIliCzQgDABgEAAQgSAAgcgfg");
	var mask_2_graphics_82 = new cjs.Graphics().p("AEXFRQgkgmggg/QgfhAgJg0QgJgzAUgKIF/i/QATgKAkAmQAlAmAfBAQAgA+AJA0QAJA0gUAKIl/C/QgEACgEAAQgTAAgdgeg");
	var mask_2_graphics_83 = new cjs.Graphics().p("AEHFRQglgmgfg/QgghAgIg0QgHg0AVgLIGbjLQAVgLAlAmQAlAmAgA/QAgA/AHA0QAIA0gVALImcDMQgEACgFAAQgUAAgdgdg");
	var mask_2_graphics_84 = new cjs.Graphics().p("AD3FQQgmglgfg/QgfhAgHg1QgGg0AWgLIG3jYQAWgLAmAlQAnAlAfBAQAfA/AGA0QAHA1gWALIm3DZQgFACgGAAQgUAAgegdg");
	var mask_2_graphics_85 = new cjs.Graphics().p("ADoFQQgngkgfhAQgfhAgGg1QgFg1AYgMIHSjjQAXgMAnAlQAnAlAfBAQAgA+AEA1QAGA2gYAMInRDkQgGADgGAAQgVAAgegdg");
	var mask_2_graphics_86 = new cjs.Graphics().p("ADZFQQgngkgfhAQgfhAgFg2QgEg1AZgNIHrjuQAZgMAoAkQAoAlAfBAQAfA/AEA1QAEA2gZAMInrDwQgGADgHAAQgWAAgegcg");
	var mask_2_graphics_87 = new cjs.Graphics().p("ADLFQQgogkgfhAQgfhAgDg2QgDg2AagNIIDj4QAbgNAoAkQApAkAfBAQAeBAADA1QAEA3gaAMIoED6QgHADgHAAQgXAAgegbg");
	var mask_2_graphics_88 = new cjs.Graphics().p("AC+FQQgpgkgfhAQgehAgDg3QgCg2AbgNIIbkCQAbgNApAjQApAlAfA/QAfBAACA2QADA3gcANIoaEDQgHADgJAAQgXAAgegag");
	var mask_2_graphics_89 = new cjs.Graphics().p("ACyFPQgqgjgehAQgfhAgCg3QgBg3AdgNIIvkLQAcgNAqAjQAqAkAfBAQAeBAABA1QACA4gcANIovEMQgIAEgJAAQgYAAgegbg");
	var mask_2_graphics_90 = new cjs.Graphics().p("ACnFPQgqgjgfhAQgehAgBg3QgBg3AegOIJCkTQAdgOAqAkQArAjAfBAQAeBAABA2QABA4geAOIpCETQgIAEgKAAQgXAAgfgag");
	var mask_2_graphics_91 = new cjs.Graphics().p("ACdFPQgrgjgehAQgehAgBg4QABg3AegOIJTkZQAegPArAjQArAkAeBAQAfBAgBA2QABA4gfAOIpSEaQgJAEgKAAQgYAAgfgZg");
	var mask_2_graphics_92 = new cjs.Graphics().p("ACVFPQgrgjgfhAQgehAAAg4QABg4AfgOIJhkfQAfgPAsAjQArAkAfBAQAeBAgBA3QAAA3gfAPIphEgQgKAEgKAAQgYAAgfgZg");
	var mask_2_graphics_93 = new cjs.Graphics().p("ACOFPQgsgjgehAQgehAABg4QABg4AggPIJtkjQAfgPAsAiQAsAkAeBAQAeBAgBA4QgBA3gfAPIptEkQgKAFgKAAQgZAAgfgZg");
	var mask_2_graphics_94 = new cjs.Graphics().p("ACIFPQgsgjgehAQgehAABg4QACg4AggPIJ3koQAggPAsAjQAsAjAeBAQAeBAgBA4QgBA4ghAPIp2EoQgKAEgLAAQgZAAgfgYg");
	var mask_2_graphics_95 = new cjs.Graphics().p("ACEFPQgsgjgehAQgehAABg5QACg4AhgPIJ9kqQAhgPAsAjQAtAjAeBAQAeBAgCA4QgCA4ggAPIp+ErQgJAEgLAAQgaAAgfgYg");
	var mask_2_graphics_96 = new cjs.Graphics().p("ACCFPQgsgjgehAQgehAABg5QACg4AhgPIKCkrQAggQAsAjQAtAjAeBAQAeBAgCA4QgBA4ghAPIqCEsQgKAFgLAAQgZAAgfgYg");
	var mask_2_graphics_97 = new cjs.Graphics().p("ACAFQQgsgjgehAQgehAABg5QADg4AggPIKDksQAhgQAsAjQAtAjAeBAQAeBAgCA4QgCA4ggAPIqDEtQgKAFgLAAQgaAAgfgYg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(63).to({graphics:mask_2_graphics_63,x:52.5014,y:38.1421}).wait(1).to({graphics:mask_2_graphics_64,x:52.5722,y:38.1364}).wait(1).to({graphics:mask_2_graphics_65,x:52.7841,y:38.1194}).wait(1).to({graphics:mask_2_graphics_66,x:53.1358,y:38.0914}).wait(1).to({graphics:mask_2_graphics_67,x:53.6251,y:38.0526}).wait(1).to({graphics:mask_2_graphics_68,x:54.249,y:38.0037}).wait(1).to({graphics:mask_2_graphics_69,x:55.0033,y:37.9452}).wait(1).to({graphics:mask_2_graphics_70,x:55.8831,y:37.8779}).wait(1).to({graphics:mask_2_graphics_71,x:56.8826,y:37.8027}).wait(1).to({graphics:mask_2_graphics_72,x:57.9948,y:37.7204}).wait(1).to({graphics:mask_2_graphics_73,x:59.2119,y:37.6319}).wait(1).to({graphics:mask_2_graphics_74,x:60.5251,y:37.5384}).wait(1).to({graphics:mask_2_graphics_75,x:61.9246,y:37.4408}).wait(1).to({graphics:mask_2_graphics_76,x:63.3997,y:37.3401}).wait(1).to({graphics:mask_2_graphics_77,x:64.9389,y:37.2374}).wait(1).to({graphics:mask_2_graphics_78,x:66.5298,y:37.1335}).wait(1).to({graphics:mask_2_graphics_79,x:68.1593,y:37.0296}).wait(1).to({graphics:mask_2_graphics_80,x:69.8139,y:36.9264}).wait(1).to({graphics:mask_2_graphics_81,x:71.4792,y:36.8248}).wait(1).to({graphics:mask_2_graphics_82,x:73.1409,y:36.7257}).wait(1).to({graphics:mask_2_graphics_83,x:74.784,y:36.6297}).wait(1).to({graphics:mask_2_graphics_84,x:76.3939,y:36.5376}).wait(1).to({graphics:mask_2_graphics_85,x:77.9558,y:36.45}).wait(1).to({graphics:mask_2_graphics_86,x:79.4552,y:36.3675}).wait(1).to({graphics:mask_2_graphics_87,x:80.878,y:36.2905}).wait(1).to({graphics:mask_2_graphics_88,x:82.2107,y:36.2196}).wait(1).to({graphics:mask_2_graphics_89,x:83.4407,y:36.155}).wait(1).to({graphics:mask_2_graphics_90,x:84.556,y:36.0973}).wait(1).to({graphics:mask_2_graphics_91,x:85.5458,y:36.0467}).wait(1).to({graphics:mask_2_graphics_92,x:86.4016,y:36.0034}).wait(1).to({graphics:mask_2_graphics_93,x:87.1136,y:35.9678}).wait(1).to({graphics:mask_2_graphics_94,x:87.6749,y:35.9398}).wait(1).to({graphics:mask_2_graphics_95,x:88.0798,y:35.9198}).wait(1).to({graphics:mask_2_graphics_96,x:88.3243,y:35.9077}).wait(1).to({graphics:mask_2_graphics_97,x:88.3151,y:35.9896}).wait(66));

	// Layer_12
	this.instance_2 = new lib.doodle_line3();
	this.instance_2.setTransform(135.65,42.45,1,1,0,0,0,33.5,18.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(63).to({_off:false},0).wait(100));

	// Layer_3 copy (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_40 = new cjs.Graphics().p("AEmBmIgJgwQAAgDArgKQAqgKA9gLQA9gMArgHQAsgFAAACIAJAvQABACgrAKQgrAKg9AMQg8AMgrAGQghAFgIAAIgEAAg");
	var mask_3_graphics_41 = new cjs.Graphics().p("AEmBmIgJgxQAAgCArgKQAqgKA9gMQA9gMArgGQAsgGAAADIAJAvQABADgrAKQgrAKg8AMQg9ALgrAHQggAFgJAAIgEgBg");
	var mask_3_graphics_42 = new cjs.Graphics().p("AEnBoIgKg0QgBgCArgLQArgKA9gMQA8gLAsgGQArgGABACIAKAzQAAACgqAKQgrALg9ALQg9AMgrAHQgfAEgJAAIgEAAg");
	var mask_3_graphics_43 = new cjs.Graphics().p("AEnBqIgLg4QAAgDArgKQAqgKA9gMQA9gMAsgFQArgHAAADIALA3QABADgrAKQgrALg8ALQg9AMgrAGQgfAFgJAAQgBAAgBAAQgBAAgBAAQAAAAAAgBQgBAAAAAAg");
	var mask_3_graphics_44 = new cjs.Graphics().p("AEoBtIgMg+QgBgDArgKQArgLA8gMQA9gLAsgGQArgGABAEIAMA8QAAAEgqAKQgrALg9AMQg8ALgsAGQgdAEgKAAQgFAAAAgBg");
	var mask_3_graphics_45 = new cjs.Graphics().p("AEpByIgOhGQAAgEAqgLQArgKA9gMQA8gLAsgGQArgGABAEIAOBFQAAADgqALQgrALg9AMQg8ALgsAGQgbAEgLAAQgGAAAAgBg");
	var mask_3_graphics_46 = new cjs.Graphics().p("AEqB3IgQhPQAAgEArgMQAqgLA8gMQA9gKAsgGQAsgFAAAEIAQBOQAAAEgqALQgrALg8AMQg9AMgsAFQgZADgLAAQgIAAAAgBg");
	var mask_3_graphics_47 = new cjs.Graphics().p("AErB9IgShaQAAgFAqgMQArgLA8gLQA9gMAsgFQAsgFAAAFIASBZQABAEgqAMQgrALg9AMQg9AMgrAFQgYADgLAAQgKAAAAgCg");
	var mask_3_graphics_48 = new cjs.Graphics().p("AEsCDIgUhmQgBgFArgNQAqgLA9gLQA9gMAsgFQArgEABAFIAUBlQABAGgqALQgrANg8ALQg9AMgsAFQgVACgLAAQgMAAgBgDg");
	var mask_3_graphics_49 = new cjs.Graphics().p("AEuCKIgXhzQgBgGArgNQAqgLA8gMQA9gMAsgEQAsgEABAGIAXBzQABAFgqANQgrANg9ALQg8AMgsAEIgdACQgQAAAAgEg");
	var mask_3_graphics_50 = new cjs.Graphics().p("AEvCSIgZiCQgBgHAqgMQAqgNA9gMQA9gMAsgDQAsgEABAHIAZCBQABAHgpANQgrANg9AMQg8AMgsADIgaACQgTAAgBgFg");
	var mask_3_graphics_51 = new cjs.Graphics().p("AExCbIgciTQgCgHArgNQApgOA9gLQA9gMAsgDQAsgDACAHIAcCSQABAHgpAOQgrAOg9ALQg8AMgsADIgXABQgWAAgBgFg");
	var mask_3_graphics_52 = new cjs.Graphics().p("AEzCkIggikQgBgHAqgOQApgPA9gLQA9gMAtgDQArgCACAIIAgCjQABAIgpAOQgrAOg8AMQg9AMgsACIgTABQgaAAgBgGg");
	var mask_3_graphics_53 = new cjs.Graphics().p("AE1CtIgji0QgCgJAqgPQAqgPA8gMQA9gMAtgBQAsgCACAJIAjC0QABAJgpAPQgqAPg9AMQg9ALgsACIgOAAQgfAAgBgHg");
	var mask_3_graphics_54 = new cjs.Graphics().p("AE3C2IgnjGQgCgKAqgPQAqgQA8gMQA9gLAtgCQAsgBACAKIAnDGQABAKgpAQQgqAPg9AMQg9AMgsABIgJAAQgkAAgBgJg");
	var mask_3_graphics_55 = new cjs.Graphics().p("AE5DAIgqjYQgDgMAqgQQApgQA9gMQA9gLAtgBQAsAAACALIAqDYQADALgqAQQgqAQg8AMQg9AMgsAAIgFAAQgoAAgCgKg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AFqDWQgtAAgCgMIgujsQgCgMApgRQApgQA9gMQA9gMAtAAQAsABADAMIAuDrQACAMgpAQQgqARg9AMQg7AMgsAAIgCAAg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AFsDhQgtgBgCgNIgyj+QgCgNApgRQApgSA9gLQA9gMAtAAQAtACACAMIAyD+QACANgpASQgqARg8AMQg4ALgrAAIgHAAg");
	var mask_3_graphics_58 = new cjs.Graphics().p("AFvDsQgugBgCgOIg1kRQgDgOApgSQApgSA9gMQA9gMAtACQAtABADAOIA1ERQACAOgpASQgpASg9AMQg1AKgpAAIgLAAg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AFxD3QgugCgCgPIg5kjQgDgPAqgTQAogSA9gMQA9gMAtACQAtACADAPIA5EjQACAPgoATQgqATg9AMQgyAKgoAAIgPgBg");
	var mask_3_graphics_60 = new cjs.Graphics().p("AFzECQgtgDgEgPIg8k2QgDgPAqgUQAogTA9gMQA9gMAtADQAtADADAQIA8E1QADAPgoAUQgpAUg9ALQgxAKgmAAIgTgBg");
	var mask_3_graphics_61 = new cjs.Graphics().p("AF1EMQgtgDgEgRIg/lGQgDgRApgUQAogUA9gMQA9gMAuAEQAtADADARIA/FHQAEAQgpAUQgpAVg9ALQguAJglAAIgXgBg");
	var mask_3_graphics_62 = new cjs.Graphics().p("AF3EWQgtgDgEgSIhClXQgEgSApgVQAogUA9gMQA9gMAuAEQAtAEADASIBDFXQADASgoAUQgpAVg9AMQgsAJgkAAIgagCg");
	var mask_3_graphics_63 = new cjs.Graphics().p("AF5EgQgugFgDgSIhGlnQgDgSAogWQApgVA9gMQA8gMAuAFQAuAFADASIBGFnQADASgoAWQgpAVg9AMQgrAIgjAAIgcgBg");
	var mask_3_graphics_64 = new cjs.Graphics().p("AF7EpQgugFgEgTIhIl2QgEgTApgWQAogWA9gMQA9gMAuAFQAtAGAEATIBIF2QAEATgoAVQgpAXg9ALQgpAIgjAAQgQAAgOgBg");
	var mask_3_graphics_65 = new cjs.Graphics().p("AF9ExQgugGgEgUIhLmDQgEgUApgWQAogXA8gLQA9gMAuAFQAuAGAEAUIBLGEQAEATgoAXQgpAWg9AMQgoAIgiAAQgRAAgPgCg");
	var mask_3_graphics_66 = new cjs.Graphics().p("AF+E4QgugGgEgUIhNmQQgEgVAogXQAogWA9gMQA9gMAuAGQAuAHAEAUIBNGQQAEAUgoAXQgoAXg9AMQgoAHghAAQgSAAgQgCg");
	var mask_3_graphics_67 = new cjs.Graphics().p("AGAE/QgvgHgEgVIhPmaQgEgVAogYQAogXA9gMQA9gLAuAGQAuAHAEAVIBPGaQAEAVgoAXQgoAYg9AMQgnAHggAAQgTAAgQgCg");
	var mask_3_graphics_68 = new cjs.Graphics().p("AGBFEQgugHgFgVIhRmkQgEgWAogXQAogYA9gLQA9gMAuAGQAuAIAEAVIBRGkQAEAWgnAXQgpAYg9ALQgmAIggAAQgTAAgRgDg");
	var mask_3_graphics_69 = new cjs.Graphics().p("AGCFJQgvgHgEgWIhTmsQgEgWAogYQAogYA9gLQA9gMAuAHQAuAHAEAWIBTGsQAEAWgnAYQgpAYg9ALQglAIggAAQgUAAgRgDg");
	var mask_3_graphics_70 = new cjs.Graphics().p("AGDFMQgvgHgEgWIhUmyQgFgWApgYQAngYA9gMQA9gMAuAHQAuAIAFAWIBUGyQAEAWgoAYQgoAYg9AMQglAHgfAAQgUAAgSgDg");
	var mask_3_graphics_71 = new cjs.Graphics().p("AGDFPQgugHgFgXIhVm2QgEgXAogYQAogYA9gMQA9gMAuAIQAuAHAEAXIBVG2QAFAXgoAYQgoAYg9AMQglAHgfAAQgVAAgSgDg");
	var mask_3_graphics_72 = new cjs.Graphics().p("AGDFRQgugIgEgWIhWm6QgEgWAogZQAogYA8gLQA9gMAvAHQAuAIAEAXIBWG5QAEAWgoAYQgoAZg9AMQgkAHggAAQgUAAgTgDg");
	var mask_3_graphics_73 = new cjs.Graphics().p("AGEFQQgvgIgEgWIhWm6QgEgXAogZQAogYA8gLQA9gMAvAHQAuAIAEAXIBWG6QAEAWgoAZQgoAYg9AMQgkAHgfAAQgVAAgSgDg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(40).to({graphics:mask_3_graphics_40,x:58.8294,y:10.2235}).wait(1).to({graphics:mask_3_graphics_41,x:58.8393,y:10.275}).wait(1).to({graphics:mask_3_graphics_42,x:58.8681,y:10.4288}).wait(1).to({graphics:mask_3_graphics_43,x:58.9159,y:10.6841}).wait(1).to({graphics:mask_3_graphics_44,x:58.9822,y:11.039}).wait(1).to({graphics:mask_3_graphics_45,x:59.0665,y:11.4909}).wait(1).to({graphics:mask_3_graphics_46,x:59.1679,y:12.0367}).wait(1).to({graphics:mask_3_graphics_47,x:59.2856,y:12.6721}).wait(1).to({graphics:mask_3_graphics_48,x:59.4185,y:13.3922}).wait(1).to({graphics:mask_3_graphics_49,x:59.5654,y:14.1914}).wait(1).to({graphics:mask_3_graphics_50,x:59.725,y:15.0631}).wait(1).to({graphics:mask_3_graphics_51,x:59.8959,y:15.9999}).wait(1).to({graphics:mask_3_graphics_52,x:60.0765,y:16.9939}).wait(1).to({graphics:mask_3_graphics_53,x:60.2652,y:18.0364}).wait(1).to({graphics:mask_3_graphics_54,x:60.4603,y:19.1181}).wait(1).to({graphics:mask_3_graphics_55,x:60.6601,y:20.2292}).wait(1).to({graphics:mask_3_graphics_56,x:60.8627,y:21.3601}).wait(1).to({graphics:mask_3_graphics_57,x:61.0663,y:22.5009}).wait(1).to({graphics:mask_3_graphics_58,x:61.2691,y:23.6396}).wait(1).to({graphics:mask_3_graphics_59,x:61.4692,y:24.7653}).wait(1).to({graphics:mask_3_graphics_60,x:61.6648,y:25.8676}).wait(1).to({graphics:mask_3_graphics_61,x:61.8541,y:26.9358}).wait(1).to({graphics:mask_3_graphics_62,x:62.0355,y:27.96}).wait(1).to({graphics:mask_3_graphics_63,x:62.2071,y:28.9305}).wait(1).to({graphics:mask_3_graphics_64,x:62.3676,y:29.8382}).wait(1).to({graphics:mask_3_graphics_65,x:62.5154,y:30.6747}).wait(1).to({graphics:mask_3_graphics_66,x:62.6492,y:31.4321}).wait(1).to({graphics:mask_3_graphics_67,x:62.7677,y:32.1034}).wait(1).to({graphics:mask_3_graphics_68,x:62.8699,y:32.6823}).wait(1).to({graphics:mask_3_graphics_69,x:62.9548,y:33.1635}).wait(1).to({graphics:mask_3_graphics_70,x:63.0217,y:33.5424}).wait(1).to({graphics:mask_3_graphics_71,x:63.0699,y:33.8156}).wait(1).to({graphics:mask_3_graphics_72,x:63.099,y:33.9806}).wait(1).to({graphics:mask_3_graphics_73,x:63.1154,y:33.8921}).wait(90));

	// Layer_11
	this.instance_3 = new lib.doodle_line2();
	this.instance_3.setTransform(111.2,42.2,1,1,0,0,0,7.2,18.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#010101").ss(3,1,1).p("AgJAAIATAB");
	this.shape.setTransform(106.5,23.6);

	var maskedShapeInstanceList = [this.instance_3,this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.instance_3}]},40).wait(123));

	// Layer_3 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_6 = new cjs.Graphics().p("AD6FHIgvhAIgthAQgSgcACgBIAbgTQABgBAUAaIAvA/IAtBBQASAbgBABIgbAUIAAAAQgCAAgUgZg");
	var mask_4_graphics_7 = new cjs.Graphics().p("AD6FHIgvhAIgthAQgSgcABgBIAcgTQABgBAUAaIAvA/IAtBBQASAbgBABIgbAUIAAAAQgDAAgTgZg");
	var mask_4_graphics_8 = new cjs.Graphics().p("AD6FHIgvhAIgthAQgSgcABgBIAcgUQABgBAUAaIAwBAIAsBAQATAcgCABIgcAUIAAAAQgCAAgTgZg");
	var mask_4_graphics_9 = new cjs.Graphics().p("AD5FHQgUgagbglIgthBQgSgcACgBIAdgUQABgBAUAZQAUAaAbAmQAbAlASAbQASAcgBABIgdAVIAAAAQgCAAgUgZg");
	var mask_4_graphics_10 = new cjs.Graphics().p("AD4FHQgUgagbglQgbgmgSgbQgSgcACgBIAfgWQABgBAUAaQAUAaAbAlQAbAmASAbQASAbgBACIgfAVIAAABQgCAAgUgZg");
	var mask_4_graphics_11 = new cjs.Graphics().p("AD3FHQgUgagbglQgbgmgSgbQgSgcACgBIAhgXQABgBAUAZQAVAaAbAmQAbAlARAbQASAcgBABIghAXIAAAAQgCAAgUgYg");
	var mask_4_graphics_12 = new cjs.Graphics().p("AD2FHQgUgagbglQgbgmgSgbQgSgcACgBIAjgZQACgBAUAZQAVAaAaAlQAbAmASAbQASAcgCABIgjAZIAAAAQgDAAgTgYg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AD0FHQgUgagbglQgbgmgSgbQgRgcACgBIAmgbQACgCAUAaQAVAZAbAmQAaAlASAcQASAbgCACIgmAbIgBAAQgCAAgUgYg");
	var mask_4_graphics_14 = new cjs.Graphics().p("ADyFHQgUgZgbgmQgbglgSgcQgRgcACgBIAqgeQACgCAUAaQAVAZAbAmQAbAlARAcQASAbgCACIgqAeIAAAAQgDAAgUgYg");
	var mask_4_graphics_15 = new cjs.Graphics().p("ADwFHQgVgZgbgmQgaglgSgcQgRgcACgBIAughQACgCAVAZQAVAaAbAlQAbAmARAbQASAcgDACIguAhIAAAAQgDAAgUgYg");
	var mask_4_graphics_16 = new cjs.Graphics().p("ADtFHQgUgZgbglQgbgmgSgcQgRgcADgCIAzgkQACgCAVAZQAVAaAbAlQAbAmARAbQARAcgCACIgzAlIAAAAQgEAAgUgYg");
	var mask_4_graphics_17 = new cjs.Graphics().p("ADrFHQgVgZgbglQgbgmgSgcQgQgcACgCIA5goQADgCAUAZQAWAZAbAlQAbAmAQAcQASAcgDACIg4AoIgBABQgEAAgTgYg");
	var mask_4_graphics_18 = new cjs.Graphics().p("ADnFHQgVgYgbgmQgbglgRgdQgQgcADgCIA+gtQADgCAVAZQAWAZAbAlQAbAmAQAcQARAcgDACIg+AtIgBAAQgEAAgUgXg");
	var mask_4_graphics_19 = new cjs.Graphics().p("ADkFHQgWgYgbgmQgbglgQgdQgRgcAEgCIBFgyQADgCAWAYQAVAZAbAmQAbAlARAcQAQAdgDACIhFAyIgBAAQgFAAgTgXg");
	var mask_4_graphics_20 = new cjs.Graphics().p("ADgFIQgWgZgbglQgbgmgQgdQgRgcAEgDIBNg3QAEgCAVAYQAWAZAbAlQAbAmAQAcQARAdgEADIhMA2IgBABQgGAAgTgWg");
	var mask_4_graphics_21 = new cjs.Graphics().p("ADbFIQgWgZgbglQgbglgQgdQgQgdAFgDIBUg9QAEgDAWAYQAXAZAbAlQAbAmAPAcQARAdgFADIhUA9IgBAAQgGAAgUgVg");
	var mask_4_graphics_22 = new cjs.Graphics().p("ADWFIQgWgYgbgmQgbglgQgdQgPgdAFgDIBdhEQAFgDAWAYQAXAYAbAmQAbAlAPAdQAQAdgFAEIhdBDIgCAAQgGAAgUgVg");
	var mask_4_graphics_23 = new cjs.Graphics().p("ADRFIQgXgYgaglQgbgmgQgdQgPgdAFgEIBnhKQAGgEAWAYQAXAYAbAlQAbAmAPAdQAQAdgFAEIhoBKIgBABQgHAAgUgVg");
	var mask_4_graphics_24 = new cjs.Graphics().p("ADLFIQgXgXgbgmQgaglgQgeQgOgdAFgEIByhSQAGgEAXAXQAXAYAbAlQAbAmAPAdQAPAegGAEIhxBSIgDAAQgHAAgUgUg");
	var mask_4_graphics_25 = new cjs.Graphics().p("ADFFIQgXgXgbglQgbgmgPgeQgOgdAGgFIB9haQAHgEAXAXQAYAXAbAmQAbAlAOAeQAPAegHAEIh9BaIgCABQgIAAgUgUg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AC/FJQgYgXgbgmQgbglgPgeQgNgeAHgFICJhjQAHgFAYAXQAYAXAbAlQAbAmAOAeQAOAegHAFIiJBjIgDABQgJAAgTgTg");
	var mask_4_graphics_27 = new cjs.Graphics().p("AC3FJQgYgXgbglQgbgmgOgeQgNgfAIgFICWhsQAIgGAYAXQAZAXAaAlQAbAmAOAeQAOAfgIAFIiWBsIgEABQgJAAgUgSg");
	var mask_4_graphics_28 = new cjs.Graphics().p("ACwFJQgZgWgbgmQgbglgNgfQgNgfAIgGICkh2QAJgGAZAWQAZAXAbAlQAbAmANAeQANAfgIAGIilB2IgEACQgJAAgUgSg");
	var mask_4_graphics_29 = new cjs.Graphics().p("ACoFJQgagWgbglQgbgmgMgfQgNgfAJgGICziBQAJgHAaAWQAaAWAaAmQAbAlANAfQANAfgJAHIi0CBQgCABgDAAQgKAAgTgRg");
	var mask_4_graphics_30 = new cjs.Graphics().p("ACfFJQgagVgbglQgbgmgMggQgMgfAKgHIDDiMQAKgHAaAVQAaAWAbAlQAbAmAMAfQAMAggKAHIjDCMQgCACgEAAQgKAAgUgRg");
	var mask_4_graphics_31 = new cjs.Graphics().p("ACWFKQgbgVgbgmQgbglgLggQgLggAKgIIDUiYQAKgIAbAVQAbAWAbAlQAbAmALAfQALAhgKAHIjTCYQgDACgEAAQgLAAgUgPg");
	var mask_4_graphics_32 = new cjs.Graphics().p("ACMFKQgbgVgbglQgbgmgLggQgKghALgIIDlijQALgIAbATQAcAVAbAlQAbAmAKAgQAMAhgMAIIjlCkQgDADgEAAQgMAAgUgPg");
	var mask_4_graphics_33 = new cjs.Graphics().p("ACCFKQgbgUgbglQgbgmgLghQgKghANgJID2iwQANgJAcAUQAcATAbAmQAbAlAKAhQAKAhgNAJIj2CxQgEADgFAAQgMAAgUgOg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AB4FKQgcgTgbgmQgbglgKgiQgJghANgKIEJi9QAOgKAcAUQAdAUAbAkQAbAlAJAiQAKAhgOAKIkJC+QgEAEgGAAQgNAAgTgOg");
	var mask_4_graphics_35 = new cjs.Graphics().p("ABtFKQgdgTgbglQgbgmgJgiQgIghAOgLIEcjLQAPgKAdATQAdATAbAlQAbAlAJAiQAJAigPAKIkcDMQgFAEgGAAQgNAAgUgNg");
	var mask_4_graphics_36 = new cjs.Graphics().p("ABjFLQgegTgbglQgbgmgIgiQgHgjAOgLIEvjZQAQgLAdATQAfATAbAkQAbAmAHAiQAJAigQAMIkvDZQgFAEgIAAQgNAAgTgLg");
	var mask_4_graphics_37 = new cjs.Graphics().p("ABYFLQgfgSgbgmQgbglgGgjQgHgjAPgMIFCjnQARgLAeASQAfASAbAlQAbAlAHAjQAIAjgQAMIlDDnQgGAFgJAAQgNAAgTgLg");
	var mask_4_graphics_38 = new cjs.Graphics().p("ABNFLQgfgSgbglQgagmgHgjQgHgjASgNIFUj0QASgNAfASQAgARAbAmQAbAkAGAkQAHAjgRANIlWD1QgHAFgKAAQgNAAgTgKg");
	var mask_4_graphics_39 = new cjs.Graphics().p("ABCFLQgfgRgbglQgagmgHgkQgFgkASgNIFnkCQATgNAgARQAgARAbAmQAbAlAGAjQAGAkgSANIlpEDQgIAGgKAAQgOAAgTgKg");
	var mask_4_graphics_40 = new cjs.Graphics().p("AA4FLQgggQgagmQgbglgGglQgFgkATgOIF6kPQATgOAhARQAhAQAbAmQAbAlAFAkQAFAkgTAOIl7EQQgIAGgMAAQgOAAgSgJg");
	var mask_4_graphics_41 = new cjs.Graphics().p("AAuFLQghgQgaglQgbgmgFglQgEgkAUgPIGLkcQAUgOAhAQQAiAQAbAmQAbAlAEAlQAFAkgUAOImMEdQgJAHgNAAQgOAAgSgJg");
	var mask_4_graphics_42 = new cjs.Graphics().p("AAlFLQgigPgagmQgbglgEgmQgEglAVgPIGcknQAVgQAhAQQAjAQAaAmQAbAlAEAlQAFAlgVAPImdEoQgKAIgNAAQgPAAgRgJg");
	var mask_4_graphics_43 = new cjs.Graphics().p("AAcFLQghgPgbglQgbgmgEgmQgDglAWgQIGqkyQAWgQAiAPQAjAQAbAlQAbAmADAlQAEAlgVAQImsEzQgLAIgOAAQgOAAgSgIg");
	var mask_4_graphics_44 = new cjs.Graphics().p("AAUFMQghgPgbgmQgbglgEgnQgDglAXgRIG5k8QAWgQAjAPQAjAPAbAlQAbAmADAmQADAmgWAPIm6E+QgLAIgPAAQgPAAgRgHg");
	var mask_4_graphics_45 = new cjs.Graphics().p("AANFMQgigPgbgmQgbglgDgmQgCgnAXgQIHFlGQAXgQAjAOQAkAPAbAmQAbAlACAnQADAmgXAQInGFGQgMAJgQAAQgOAAgRgHg");
	var mask_4_graphics_46 = new cjs.Graphics().p("AAIFLQgigOgbgmQgbglgDgnQgCgmAYgSIHQlMQAXgRAkAOQAkAPAbAlQAbAlACAnQADAngYARInRFNQgMAJgRAAQgOAAgRgHg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(6).to({graphics:mask_4_graphics_6,x:29.8863,y:35.1664}).wait(1).to({graphics:mask_4_graphics_7,x:29.898,y:35.1655}).wait(1).to({graphics:mask_4_graphics_8,x:29.9338,y:35.163}).wait(1).to({graphics:mask_4_graphics_9,x:29.9947,y:35.1587}).wait(1).to({graphics:mask_4_graphics_10,x:30.0818,y:35.1526}).wait(1).to({graphics:mask_4_graphics_11,x:30.196,y:35.1446}).wait(1).to({graphics:mask_4_graphics_12,x:30.3387,y:35.1346}).wait(1).to({graphics:mask_4_graphics_13,x:30.5109,y:35.1226}).wait(1).to({graphics:mask_4_graphics_14,x:30.7142,y:35.1085}).wait(1).to({graphics:mask_4_graphics_15,x:30.9497,y:35.0923}).wait(1).to({graphics:mask_4_graphics_16,x:31.2191,y:35.0739}).wait(1).to({graphics:mask_4_graphics_17,x:31.5237,y:35.0532}).wait(1).to({graphics:mask_4_graphics_18,x:31.8653,y:35.0302}).wait(1).to({graphics:mask_4_graphics_19,x:32.2455,y:35.0048}).wait(1).to({graphics:mask_4_graphics_20,x:32.6659,y:34.977}).wait(1).to({graphics:mask_4_graphics_21,x:33.1283,y:34.9468}).wait(1).to({graphics:mask_4_graphics_22,x:33.6345,y:34.9141}).wait(1).to({graphics:mask_4_graphics_23,x:34.1862,y:34.879}).wait(1).to({graphics:mask_4_graphics_24,x:34.785,y:34.8414}).wait(1).to({graphics:mask_4_graphics_25,x:35.4325,y:34.8013}).wait(1).to({graphics:mask_4_graphics_26,x:36.1301,y:34.7589}).wait(1).to({graphics:mask_4_graphics_27,x:36.8787,y:34.7142}).wait(1).to({graphics:mask_4_graphics_28,x:37.6791,y:34.6673}).wait(1).to({graphics:mask_4_graphics_29,x:38.5312,y:34.6184}).wait(1).to({graphics:mask_4_graphics_30,x:39.4345,y:34.5676}).wait(1).to({graphics:mask_4_graphics_31,x:40.3872,y:34.5153}).wait(1).to({graphics:mask_4_graphics_32,x:41.3866,y:34.4616}).wait(1).to({graphics:mask_4_graphics_33,x:42.4285,y:34.4071}).wait(1).to({graphics:mask_4_graphics_34,x:43.5069,y:34.352}).wait(1).to({graphics:mask_4_graphics_35,x:44.6144,y:34.2969}).wait(1).to({graphics:mask_4_graphics_36,x:45.7415,y:34.2424}).wait(1).to({graphics:mask_4_graphics_37,x:46.8768,y:34.1889}).wait(1).to({graphics:mask_4_graphics_38,x:48.0076,y:34.137}).wait(1).to({graphics:mask_4_graphics_39,x:49.1201,y:34.0873}).wait(1).to({graphics:mask_4_graphics_40,x:50.1999,y:34.0403}).wait(1).to({graphics:mask_4_graphics_41,x:51.2329,y:33.9965}).wait(1).to({graphics:mask_4_graphics_42,x:52.2059,y:33.9562}).wait(1).to({graphics:mask_4_graphics_43,x:53.1074,y:33.9197}).wait(1).to({graphics:mask_4_graphics_44,x:53.9278,y:33.8871}).wait(1).to({graphics:mask_4_graphics_45,x:54.6601,y:33.8586}).wait(1).to({graphics:mask_4_graphics_46,x:55.4186,y:33.7799}).wait(117));

	// Layer_10
	this.instance_4 = new lib.doodle_line1();
	this.instance_4.setTransform(82.5,40.5,1,1,0,0,0,25,17);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(6).to({_off:false},0).wait(157));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(56,7.9,221.3,62.1);


(lib.iconFolderSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.iconFolder();
	this.sub.name = "sub";
	this.sub.setTransform(76.45,50.35,1,1,0,0,0,76.4,46.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconFolderSub, new cjs.Rectangle(0,0,153.9,97), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(180.35,119.8,1,1,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(60.6,119.8,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(125.9,172.5,1,1,0,0,0,125.9,52.5);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(125.9,52.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-0.5,-6.6,243.5,243.5), null);


(lib.collabIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_35 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(35).call(this.frame_35).wait(1));

	// folderFront (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_1 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_2 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_3 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_4 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_5 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_6 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_7 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_8 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_9 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_10 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_13 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_14 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AoGGQQgVAAgGgQIAAAAIgBgQIgIq3QAAgcAWgWIAAAAQAVgWAbAAIAAAAIGyAAQAdAAAWAQIAAAAQAXAQAJAbIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAVIAAAAQAUAUAAAfIAAAAIAGHxIABA6QgEAHgFAFIAAAAQgEAFgFADIAAAAQgLAHgMAAIAAAAgAoLlOIAIK+IQLAAIAEAAIAAAAIgGofQAAgUgOgOIAAAAQgNgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgHgFgDgJIAAAAIgdhTQgGgUgRgMIAAAAQgQgLgWAAIAAAAImyAAQgMAAgKAKIAAAAQgKAKAAANIAAAAIAAAAgAoDFwIgIq+QAAgNAKgKIAAAAQAKgKAMAAIAAAAIGyAAQAWAAAQALIAAAAQARAMAGAUIAAAAIAdBTQADAJAHAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAANANIAAAAQAOAOAAAUIAAAAIAGIfIgEAAIAAAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AoBGPQgWAAgFgPIAAAAIgCgQIgQq3QgBgbAWgWIAAAAQAUgWAbAAIAAAAIGyAAQAeAAAXAPIAAAAQAWAQAJAcIAAAAIAeBTQABACAEAAIAAAAIGbAAQAfAAAUAVIAAAAQAUAUABAfIAAAAIALHwIACA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAHgMAAIAAAAgAoQlNIARK9IQMAAIAEgBIAAAAIgOodQAAgVgOgNIAAAAQgNgOgUAAIAAAAImbAAQgKAAgHgFIAAAAQgHgFgDgIIAAAAIgehTQgGgUgRgMIAAAAQgRgMgWAAIAAAAImyAAQgMAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAn/FwIgRq9QAAgNAKgKIAAAAQAKgLAMAAIAAAAIGyAAQAWAAARAMIAAAAQARAMAGAUIAAAAIAeBTQADAIAHAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAANAOIAAAAQAOANAAAVIAAAAIAOIdIgEABIAAAAg");
	var mask_graphics_17 = new cjs.Graphics().p("An6GOQgVAAgGgQIAAAAIgCgQIgeqzQgBgcAVgWIAAAAQAUgWAbAAIAAAAIGyAAQAeAAAXAQIAAAAQAWAQAKAbIAAAAIAgBTQABACADAAIAAAAIGcAAQAeAAAVAVIAAAAQAUAUACAfIAAAAIAVHuIADA6QgDAHgFAFIAAAAQgEAFgFADIAAAAQgLAHgMAAIAAAAgAoXlMIAfK6IQLAAIAEAAIAAAAIgXocQgBgUgOgOIAAAAQgOgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgHgFgDgJIAAAAIgfhSQgHgUgSgMIAAAAQgRgLgVAAIAAAAImyAAQgNAAgJAKIAAAAQgKAKAAAMIAAAAIAAABgAn4FuIgfq6IAAgBIAAAAQAAgMAKgKIAAAAQAJgKANAAIAAAAIGyAAQAVAAARALIAAAAQASAMAHAUIAAAAIAfBSQADAJAHAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAAOANIAAAAQAOAOABAUIAAAAIAXIcIgEAAIAAAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AnwGMQgVAAgGgQIAAAAIgCgPIgxqxQgCgbAUgWIAAAAQAUgWAbAAIAAAAIGyAAQAdAAAYAQIAAAAQAXAPALAcIAAAAIAhBSQABADAEAAIAAAAIGbAAQAfAAAVAUIAAAAQAVAUACAfIAAAAIAjHsIAEA5QgDAHgEAFIAAAAQgEAEgFAEIAAAAQgLAHgMAAIAAAAgAoglLIAyK4IQLAAIAEgBIAAAAIgnoZQgBgUgOgNIAAAAQgOgOgUAAIAAAAImcAAQgJAAgIgFIAAAAQgHgFgDgIIAAAAIghhTQgIgUgSgLIAAAAQgRgMgWAAIAAAAImyAAQgMAAgJALIAAAAQgJAJAAAMIAAAAIAAABgAnuFtIgyq4IAAgBIAAAAQAAgMAJgJIAAAAQAJgLAMAAIAAAAIGyAAQAWAAARAMIAAAAQASALAIAUIAAAAIAhBTQADAIAHAFIAAAAQAIAFAJAAIAAAAIGcAAQAUAAAOAOIAAAAQAOANABAUIAAAAIAnIZIgEABIAAAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AnjGJQgVAAgHgQIAAAAIgDgPIhIqrQgDgbAUgWIAAAAQATgWAbAAIAAAAIGyAAQAdAAAYAQIAAAAQAZAPALAbIAAAAIAkBSQABADAEAAIAAAAIGbAAQAfAAAVAUIAAAAQAWAUADAeIAAAAIA0HoIAGA5QgCAHgFAFIAAAAQgDAEgFAEIAAAAQgLAHgMAAIAAAAgAoslIIBJKyIQMAAIAEgBIAAAAIg5oVQgDgUgOgNIAAAAQgPgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgIgFgDgIIAAAAIgkhSQgJgUgSgLIAAAAQgRgMgWAAIAAAAImyAAQgNAAgIALIAAAAQgIAJAAAKIAAAAIAAADgAnjFqIhJqyIAAgDIAAAAQAAgKAIgJIAAAAQAIgLANAAIAAAAIGyAAQAWAAARAMIAAAAQASALAJAUIAAAAIAkBSQADAIAIAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAAPANIAAAAQAOANADAUIAAAAIA5IVIgEABIAAAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AnVGFQgVAAgHgQIAAAAIgEgPIhiqkQgEgbATgVIAAAAQASgWAbAAIAAAAIGyAAQAeAAAYAQIAAAAQAZAPANAbIAAAAIAnBRQABACAEAAIAAAAIGbAAQAfAAAWAUIAAAAQAWAUAFAeIAAAAIBGHjIAJA5QgDAGgEAFIAAAAQgEAFgEADIAAAAQgLAHgMAAIAAAAgAo5lFIBjKrIQLAAIAEgBIAAAAIhNoPQgDgUgOgNIAAAAQgPgNgUAAIAAAAImcAAQgJAAgIgFIAAAAQgIgFgDgIIAAAAIgohRQgJgTgTgMIAAAAQgSgLgVAAIAAAAImyAAQgNAAgIAKIAAAAQgIAJAAAKIAAAAIABADgAnWFmIhjqrIgBgDIAAAAQAAgKAIgJIAAAAQAIgKANAAIAAAAIGyAAQAVAAASALIAAAAQATAMAJATIAAAAIAoBRQADAIAIAFIAAAAQAIAFAJAAIAAAAIGcAAQAUAAAPANIAAAAQAOANADAUIAAAAIBNIPIgEABIAAAAg");
	var mask_graphics_21 = new cjs.Graphics().p("AnIGBQgVAAgIgQIAAAAIgEgPIh5qcQgFgbASgVIAAAAQARgWAbAAIAAAAIGyAAQAeAAAZAQIAAAAQAZAPAOAaIAAAAIApBQQACADADAAIAAAAIGcAAQAeAAAXAUIAAAAQAYATAFAeIAAAAIBXHeIAKA4QgCAGgEAFIAAAAQgDAEgFAEIAAAAQgKAHgMAAIAAAAgApFlBIB7KjIQLAAIAEAAIAAAAIhfoKQgEgUgPgMIAAAAQgQgOgUAAIAAAAImbAAQgKAAgHgEIAAAAQgIgFgEgJIAAAAIgqhPQgKgUgTgLIAAAAQgTgLgVAAIAAAAImyAAQgNAAgIAKIAAAAQgHAIAAAJIAAAAIABAFgAnKFiIh7qjIgBgFIAAAAQAAgJAHgIIAAAAQAIgKANAAIAAAAIGyAAQAVAAATALIAAAAQATALAKAUIAAAAIAqBPQAEAJAIAFIAAAAQAHAEAKAAIAAAAIGbAAQAUAAAQAOIAAAAQAPAMAEAUIAAAAIBfIKIgEAAIAAAAg");
	var mask_graphics_22 = new cjs.Graphics().p("Am9F9QgWAAgIgPIAAAAIgEgPIiNqWQgFgbARgVIAAAAQARgVAbAAIAAAAIGyAAQAdAAAaAPIAAAAQAaAPAOAbIAAAAIAsBPQABACAEAAIAAAAIGcAAQAeAAAYAUIAAAAQAXATAHAeIAAAAIBkHZIAMA3QgCAHgEAFIAAAAQgDAEgFADIAAAAQgKAHgMAAIAAAAgApPk+ICPKdIQLAAIAEgBIAAAAIhuoEQgEgUgQgMIAAAAQgQgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgFgFgIIAAAAIgshPQgLgTgTgMIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAIAAAJIAAAAIAAAFgAnAFfIiPqdIAAgFIAAAAQAAgJAGgIIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQATAMALATIAAAAIAsBPQAFAIAIAFIAAAAQAHAEAJAAIAAAAIGcAAQAUAAAQAOIAAAAQAQAMAEAUIAAAAIBuIEIgEABIAAAAg");
	var mask_graphics_23 = new cjs.Graphics().p("Am1F6QgWAAgIgPIAAAAIgFgPIibqRQgGgaARgVIAAAAQAQgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAaAPAPAaIAAAAIAtBPQACACADAAIAAAAIGcAAQAeAAAZAUIAAAAQAYATAHAdIAAAAIBuHVIAOA3QgCAHgEAFIAAAAQgDAEgFADIAAAAQgKAHgMAAIAAAAgApWk7ICdKXIQLAAIAEgBIAAAAIh5oAQgFgTgQgNIAAAAQgQgNgUAAIAAAAImbAAQgJAAgIgEIAAAAQgJgFgEgIIAAAAIguhPQgLgTgUgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAHAAAJIAAAAIABAGgAm5FcIidqXIgBgGIAAAAQAAgJAGgHIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAUALALATIAAAAIAuBPQAEAIAJAFIAAAAQAIAEAJAAIAAAAIGbAAQAUAAAQANIAAAAQAQANAFATIAAAAIB5IAIgEABIAAAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AmwF3QgVAAgJgPIAAAAIgFgPIilqMQgHgZARgVIAAAAQAQgVAbAAIAAAAIGyAAQAdAAAbAPIAAAAQAaAPAQAZIAAAAIAvBOQABADADAAIAAAAIGcAAQAeAAAZATIAAAAQAYATAIAdIAAAAIB2HSIAOA3QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApbk5ICnKSIQLAAIAEAAIAAAAIiBn9QgFgTgQgNIAAAAQgRgMgUAAIAAAAImbAAQgJAAgIgFIAAAAQgIgFgFgIIAAAAIgwhOQgLgTgUgKIAAAAQgTgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgGAGAAAJIAAAAIABAGgAm0FZIinqSIgBgGIAAAAQAAgJAGgGIAAAAQAHgKANAAIAAAAIGyAAQAVAAATALIAAAAQAUAKALATIAAAAIAwBOQAFAIAIAFIAAAAQAIAFAJAAIAAAAIGbAAQAUAAARAMIAAAAQAQANAFATIAAAAICBH9IgEAAIAAAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AmrF1QgWAAgJgOIAAAAIgFgPIitqJQgHgaARgVIAAAAQAPgUAbAAIAAAAIGyAAQAeAAAaAOIAAAAQAbAPAQAaIAAAAIAwBOQACACACAAIAAAAIGcAAQAeAAAZATIAAAAQAZATAIAdIAAAAIB7HQIAPA2QgCAHgEAEIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApfk4ICvKQIQLAAIAEgBIAAAAIiHn6QgFgTgRgNIAAAAQgQgMgUAAIAAAAImcAAQgIAAgIgFIAAAAQgJgFgFgIIAAAAIgwhNQgMgTgUgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgHAKIAAAAQgGAHAAAIIAAAAIABAGgAmwFYIivqQIgBgGIAAAAQAAgIAGgHIAAAAQAHgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAUALAMATIAAAAIAwBNQAFAIAJAFIAAAAQAIAFAIAAIAAAAIGcAAQAUAAAQAMIAAAAQARANAFATIAAAAICHH6IgEABIAAAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AmoF0QgWAAgJgPIAAAAIgFgPIiyqGQgHgaAQgUIAAAAQAPgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAbAPAQAZIAAAAIAxBNQACADADAAIAAAAIGbAAQAeAAAZATIAAAAQAZATAIAdIAAAAIB/HOIAQA2QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApik2IC1KMIQLAAIAEAAIAAAAIiMn4QgFgUgQgMIAAAAQgRgNgUAAIAAAAImbAAQgJAAgIgEIAAAAQgJgFgFgIIAAAAIgxhNQgMgTgTgLIAAAAQgUgKgVAAIAAAAImyAAQgNAAgHAJIAAAAQgGAHAAAIIAAAAIABAHgAmtFWIi1qMIgBgHIAAAAQAAgIAGgHIAAAAQAHgJANAAIAAAAIGyAAQAVAAAUAKIAAAAQATALAMATIAAAAIAxBNQAFAIAJAFIAAAAQAIAEAJAAIAAAAIGbAAQAUAAARANIAAAAQAQAMAFAUIAAAAICMH4IgEAAIAAAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AmnFzQgVAAgJgPIAAAAIgFgOIi2qFQgHgaAQgVIAAAAQAPgUAbAAIAAAAIGyAAQAeAAAbAPIAAAAQAaAOAQAaIAAAAIAyBNQACACADAAIAAAAIGbAAQAeAAAZAUIAAAAQAZASAIAdIAAAAICCHNIAPA2QgBAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApjk2IC4KMIQLAAIAEgBIAAAAIiPn3QgFgTgRgMIAAAAQgQgNgUAAIAAAAImbAAQgJAAgIgFIAAAAQgJgEgFgIIAAAAIgxhNQgMgTgUgLIAAAAQgUgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgFAHAAAIIAAAAIABAGgAmrFWIi4qMIgBgGIAAAAQAAgIAFgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAAUALIAAAAQAUALAMATIAAAAIAxBNQAFAIAJAEIAAAAQAIAFAJAAIAAAAIGbAAQAUAAAQANIAAAAQARAMAFATIAAAAICPH3IgEABIAAAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AmmFzQgVAAgJgPIAAAAIgGgPIi3qEQgHgZAQgVIAAAAQAPgVAbAAIAAAAIGyAAQAeAAAbAPIAAAAQAaAPAQAZIAAAAIAyBNQACADADAAIAAAAIGbAAQAeAAAZATIAAAAQAZASAJAdIAAAAICDHNIAPA2QgBAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApkk1IC5KKIQLAAIAEAAIAAAAIiPn3QgFgTgRgMIAAAAQgRgNgUAAIAAAAImaAAQgKAAgIgEIAAAAQgJgFgFgIIAAAAIgxhNQgMgTgUgKIAAAAQgUgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgFAGAAAIIAAAAIABAHgAmrFVIi5qKIgBgHIAAAAQAAgIAFgGIAAAAQAHgKANAAIAAAAIGyAAQAVAAAUALIAAAAQAUAKAMATIAAAAIAxBNQAFAIAJAFIAAAAQAIAEAKAAIAAAAIGaAAQAUAAARANIAAAAQARAMAFATIAAAAICPH3IgEAAIAAAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AmlFzQgWAAgJgPIAAAAIgFgPIi4qEQgIgZAQgVIAAAAQAQgVAbAAIAAAAIGyAAQAdAAAbAPIAAAAQAbAPAQAZIAAAAIAyBNQACADADAAIAAAAIGbAAQAeAAAZATIAAAAQAZATAIAcIAAAAICEHNIAQA2QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgAplk1IC7KKIQLAAIAEAAIAAAAIiQn3QgGgTgQgMIAAAAQgRgNgUAAIAAAAImaAAQgKAAgIgEIAAAAQgJgFgFgIIAAAAIgyhNQgLgTgVgKIAAAAQgTgLgWAAIAAAAImyAAQgMAAgHAKIAAAAQgFAGAAAIIAAAAIAAAHgAmqFVIi7qKIAAgHIAAAAQAAgIAFgGIAAAAQAHgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAVAKALATIAAAAIAyBNQAFAIAJAFIAAAAQAIAEAKAAIAAAAIGaAAQAUAAARANIAAAAQAQAMAGATIAAAAICQH3IgEAAIAAAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AmnFzQgWAAgJgOIAAAAIgFgPIi1qGQgHgZAQgVIAAAAQAQgUAbAAIAAAAIGyAAQAdAAAbAOIAAAAQAbAPAQAaIAAAAIAxBNQACACADAAIAAAAIGbAAQAeAAAZATIAAAAQAZATAIAdIAAAAICBHNIAQA2QgCAHgEAFIAAAAQgCADgFADIAAAAQgJAHgMAAIAAAAgApjk2IC3KMIQLAAIAEgBIAAAAIiNn3QgGgTgQgMIAAAAQgRgNgUAAIAAAAImbAAQgJAAgIgFIAAAAQgJgFgFgHIAAAAIgxhOQgMgSgUgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgHAKIAAAAQgGAHAAAIIAAAAIABAGgAmsFWIi3qMIgBgGIAAAAQAAgIAGgHIAAAAQAHgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAUALAMASIAAAAIAxBOQAFAHAJAFIAAAAQAIAFAJAAIAAAAIGbAAQAUAAARANIAAAAQAQAMAGATIAAAAICNH3IgEABIAAAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AmsF1QgVAAgJgOIAAAAIgFgPIitqJQgGgaAQgVIAAAAQAQgUAbAAIAAAAIGyAAQAdAAAbAOIAAAAQAaAPAQAaIAAAAIAxBNQABADADAAIAAAAIGbAAQAfAAAYATIAAAAQAZATAIAdIAAAAIB7HQIAPA2QgCAHgEAFIAAAAQgDADgEADIAAAAQgKAHgMAAIAAAAgApfk4ICvKQIQLAAIAEgBIAAAAIiHn6QgFgTgRgNIAAAAQgQgMgUAAIAAAAImbAAQgJAAgIgFIAAAAQgJgFgFgIIAAAAIgwhNQgMgTgTgLIAAAAQgUgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgGAHAAAIIAAAAIABAGgAmwFYIivqQIgBgGIAAAAQAAgIAGgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAAUALIAAAAQATALAMATIAAAAIAwBNQAFAIAJAFIAAAAQAIAFAJAAIAAAAIGbAAQAUAAAQAMIAAAAQARANAFATIAAAAICHH6IgEABIAAAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AmxF4QgWAAgJgPIAAAAIgEgPIiiqNQgHgaARgVIAAAAQAQgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAaAPAPAaIAAAAIAvBOQABACAEAAIAAAAIGbAAQAfAAAYAUIAAAAQAYATAIAdIAAAAIBzHTIAOA2QgCAHgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApak6IClKUIQLAAIAEgBIAAAAIh/n9QgFgTgQgNIAAAAQgQgNgUAAIAAAAImcAAQgIAAgIgEIAAAAQgJgFgFgIIAAAAIgvhOQgLgTgUgLIAAAAQgTgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgGAHAAAJIAAAAIAAAFgAm1FaIilqUIAAgFIAAAAQAAgJAGgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAATALIAAAAQAUALALATIAAAAIAvBOQAFAIAJAFIAAAAQAIAEAIAAIAAAAIGcAAQAUAAAQANIAAAAQAQANAFATIAAAAIB/H9IgEABIAAAAg");
	var mask_graphics_33 = new cjs.Graphics().p("Am1F5QgVAAgJgPIAAAAIgFgPIibqPQgGgaAQgVIAAAAQARgVAbAAIAAAAIGyAAQAdAAAaAPIAAAAQAbAPAPAaIAAAAIAtBOQACACADAAIAAAAIGcAAQAeAAAYAUIAAAAQAYATAIAdIAAAAIBvHVIANA3QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApWk7ICdKWIQLAAIAEAAIAAAAIh5oAQgFgTgQgNIAAAAQgQgNgUAAIAAAAImcAAQgIAAgIgEIAAAAQgJgFgEgIIAAAAIgvhOQgLgTgTgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAHAAAIIAAAAIABAGgAm5FbIidqWIgBgGIAAAAQAAgIAGgHIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQATALALATIAAAAIAvBOQAEAIAJAFIAAAAQAIAEAIAAIAAAAIGcAAQAUAAAQANIAAAAQAQANAFATIAAAAIB5IAIgEAAIAAAAg");
	var mask_graphics_34 = new cjs.Graphics().p("Am3F6QgVAAgJgPIAAAAIgEgPIiZqRQgGgaARgVIAAAAQARgVAbAAIAAAAIGyAAQAdAAAaAPIAAAAQAaAPAPAaIAAAAIAtBPQACACADAAIAAAAIGcAAQAeAAAYAUIAAAAQAYATAHAdIAAAAIBtHVIANA3QgCAHgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApVk7ICbKXIQLAAIAEgBIAAAAIh4oAQgEgTgQgNIAAAAQgQgNgUAAIAAAAImcAAQgJAAgHgEIAAAAQgJgFgEgIIAAAAIguhPQgLgTgUgLIAAAAQgTgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgHAHABAJIAAAAIAAAGgAm6FcIibqXIAAgGIAAAAQgBgJAHgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAATALIAAAAQAUALALATIAAAAIAuBPQAEAIAJAFIAAAAQAHAEAJAAIAAAAIGcAAQAUAAAQANIAAAAQAQANAEATIAAAAIB4IAIgEABIAAAAg");
	var mask_graphics_35 = new cjs.Graphics().p("Am3F6QgVAAgJgPIAAAAIgEgPIiYqRQgGgaARgVIAAAAQAQgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAaAPAPAaIAAAAIAtBOQABADAEAAIAAAAIGbAAQAfAAAYATIAAAAQAYATAHAeIAAAAIBsHWIANA3QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApUk8ICaKYIQLAAIAEAAIAAAAIh3oBQgFgUgQgMIAAAAQgQgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgIgFgFgIIAAAAIguhOQgLgTgTgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAHAAAJIAAAAIABAFgAm6FcIiaqYIgBgFIAAAAQAAgJAGgHIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQATALALATIAAAAIAuBOQAFAIAIAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAAQANIAAAAQAQAMAFAUIAAAAIB3IBIgEAAIAAAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:70.8957,y:65.9506}).wait(1).to({graphics:mask_graphics_1,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_2,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_3,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_4,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_5,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_6,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_7,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_8,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_9,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_10,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_11,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_12,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_13,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_14,x:70.8957,y:65.9506}).wait(1).to({graphics:mask_graphics_15,x:70.6399,y:65.9893}).wait(1).to({graphics:mask_graphics_16,x:70.1752,y:66.0658}).wait(1).to({graphics:mask_graphics_17,x:69.4485,y:66.1991}).wait(1).to({graphics:mask_graphics_18,x:68.4182,y:66.4151}).wait(1).to({graphics:mask_graphics_19,x:67.1149,y:66.7341}).wait(1).to({graphics:mask_graphics_20,x:65.7068,y:67.1391}).wait(1).to({graphics:mask_graphics_21,x:64.4191,y:67.5666}).wait(1).to({graphics:mask_graphics_22,x:63.3748,y:67.9541}).wait(1).to({graphics:mask_graphics_23,x:62.58,y:68.2753}).wait(1).to({graphics:mask_graphics_24,x:61.9941,y:68.5273}).wait(1).to({graphics:mask_graphics_25,x:61.5745,y:68.7154}).wait(1).to({graphics:mask_graphics_26,x:61.2852,y:68.8491}).wait(1).to({graphics:mask_graphics_27,x:61.1001,y:68.9364}).wait(1).to({graphics:mask_graphics_28,x:60.9992,y:68.9845}).wait(1).to({graphics:mask_graphics_29,x:61.0156,y:68.9503}).wait(1).to({graphics:mask_graphics_30,x:61.1752,y:68.8671}).wait(1).to({graphics:mask_graphics_31,x:61.6023,y:68.6489}).wait(1).to({graphics:mask_graphics_32,x:62.1378,y:68.3874}).wait(1).to({graphics:mask_graphics_33,x:62.4631,y:68.2349}).wait(1).to({graphics:mask_graphics_34,x:62.6088,y:68.1678}).wait(1).to({graphics:mask_graphics_35,x:62.7979,y:68.2006}).wait(1));

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("AjQEHIHAAAQA+AAAug2QAsg1AAhBIAAgBQAAgtgWgvQgXgzgjgTQgdgQghgCQgYhfhWguQhXgvhwAZQgqAJgmAaQglAagZAlQhLABg7BDQg4BCAABPQABBQA1A9QA2BABLAAg");
	this.shape.setTransform(17.7748,85.3162);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(36));

	// Layer_9 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AklJBQANgKALgNQAsg1AAhBIAAgBQAAgtgVgwQgYgzgjgTQgdgQgggCQgZhfhWguQhXgvhxAZQgpAJgnAbQglAagZAkQhGABg3A6IAAs4IdhAAIAASBg");
	mask_1.setTransform(79.55,50.8);

	// folder
	this.folder = new lib.iconFolderSub();
	this.folder.name = "folder";
	this.folder.setTransform(76.2,57.55,1,1,0,0,0,77,48.5);

	var maskedShapeInstanceList = [this.folder];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.folder).wait(36));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.4,-72,300,250);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(422.15,26.3,1.3703,1.3703,-102.8482,0,0,14.8,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(437.1,16.05,1.3703,1.3703,-133.8477,0,0,14.8,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(445.2,0.9,1.3704,1.3704,-173.8508,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(312,-90.1,1.4111,1.4111,86.0017,0,0,14.8,0);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(295.5,-83.75,1.4111,1.4111,55.0025,0,0,14.8,-0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(286.55,-70,1.4112,1.4112,15.0001,0,0,15,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// cloud
	this.cloud = new lib.iconCloud();
	this.cloud.name = "cloud";
	this.cloud.setTransform(315.8,2.8,1,1,0,0,0,34.8,34.8);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

	// ODIcon
	this.ODIcon = new lib.collabIcon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(315.8,2.8,1,1,0,0,0,17.8,98.3);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	// intro line
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(144.5,23.6,1,1,0,0,0,144.5,23.6);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(166.9,16.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(40.5,-113.2,431.6,314.1), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(149.3,226.7,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(150,226.85,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(149.15,127.3,1,1,0,0,0,206.7,147.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(245.1,81.9,1,1,0,0,0,3.5,39.7);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(227.5,191.8,1,1,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,155,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.instance = new lib.bg();
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-192.8,-40.1,759.2,409.20000000000005), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut});
				this.tl1.from(exportRoot.intro2,{duration:0.6, alpha: 0, ease:Power3.easeOut, onComplete:function(){mc.anim.line1.play();}}, ">-.4");
		
				this.tl1.to(mc.anim,{duration:1.5, x: "-=310", ease:Power3.easeInOut}, "+=3.3");
				this.tl1.to(mc.anim.grid,{duration:1.5, x: "+=100", ease:Power3.easeInOut}, "<");
		
				this.tl1.to([exportRoot.intro1, exportRoot.intro2],{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<");
		
				//icon
				this.tl1.from(mc.anim.cloud,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+1");
				this.tl1.from(mc.anim.ODIcon,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut, onStart:function(){mc.anim.ODIcon.play(),mc.anim.ODIcon.folder.sub.play();}}, "<+.2");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">-.1");
		
				//chart transition
				this.tl1.to([mc.ui, mc.anim],{duration:.6, y:"+=70", ease:Power2.easeInOut}, ">");
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=70", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
				
				this.tl1.from(mc.ui.ui.file1,{duration:.6, x:"-=20", y:"+=4", scaleX:.28, scaleY:.28, ease:Power4.easeInOut}, ">+.1");
				this.tl1.from(mc.ui.ui.file1.fileShadow,{duration:.6, x:"-=10", y:"-=10", alpha:0, ease:Power4.easeInOut}, "<");
				
				this.tl1.from(mc.ui.ui.file2,{duration:.6, y:"+=10", scaleX:.35, scaleY:.35, ease:Power4.easeInOut}, ">-.5");
				this.tl1.from(mc.ui.ui.file2.fileShadow,{duration:.6, x:"-=10", y:"-=10", alpha:0, ease:Power4.easeInOut}, "<");
				
				this.tl1.from(mc.ui.ui.file3,{duration:.6, x:"+=20", scaleX:.35, scaleY:.35, ease:Power4.easeInOut}, ">-.5");
				this.tl1.from(mc.ui.ui.file3.fileShadow,{duration:.6, x:"-=10", y:"-=10", alpha:0, ease:Power4.easeInOut}, "<");
				
				this.tl1.to([mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.1, alpha:0}, ">");
				this.tl1.to(mc.anim, {duration:.1, y:"-=70"}, "<");
		
				//mid transition		
				this.tl1.to(mc.ui.ui,{duration:2, x:"-=10", y:"+=17", scaleX: .565, scaleY: .565, ease:Power3.easeInOut}, ">+.4");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"+=14", y:"+=17", alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=100", y:"-=100", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.4");
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.to(mc.anim.cloud,{duration:0.1, alpha:0, ease:Power3.easeInOut}, "<");
						
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"-=20", y:"+=4", scaleX:.28, scaleY:.28, ease:Power3.easeInOut}, ">-.2");
				this.tl1.to(mc.ui.ui.file1.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");		
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");		
				this.tl1.to(mc.ui.ui.file2,{duration:.7, y:"+=10", scaleX:.28, scaleY:.28, ease:Power3.easeInOut}, ">-.6");
				this.tl1.to(mc.ui.ui.file2.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");			
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");		
				this.tl1.to(mc.ui.ui.file3,{duration:.7, x:"+=10", scaleX:.28, scaleY:.28, ease:Power3.easeInOut}, ">-.6");
				this.tl1.to(mc.ui.ui.file3.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");			
				this.tl1.to(mc.ui.ui.file3,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");			
				
				this.tl1.from(mc.ui.ui.file4,{duration:.6, x:"-=5", y:"-=5", scaleX:.4, scaleY:.4, ease:Power4.easeInOut}, ">+.2");
				this.tl1.from(mc.ui.ui.file4.fileShadow,{duration:.5, x:"-=10", y:"-=10", alpha:0, ease:Power4.easeInOut}, "<");		
				this.tl1.from(mc.ui.ui.file5,{duration:.6, x:"+=0", y:"-=35", scaleX:.22, scaleY:.22, ease:Power4.easeInOut}, ">-.6");
				this.tl1.from(mc.ui.ui.file5.fileShadow,{duration:.5, x:"-=10", y:"-=10", alpha:0, ease:Power4.easeInOut}, "<");
						
						
				this.tl1.to(mc.ui.ui.file4,{duration:.7, x:"-=5", y:"-=5", scaleX:.4, scaleY:.4, ease:Power3.easeInOut}, ">+.6");
				this.tl1.to(mc.ui.ui.file4.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");		
				this.tl1.to(mc.ui.ui.file4,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");		
				this.tl1.to(mc.ui.ui.file5,{duration:.7, x:"+=3", y:"-=35", scaleX:.22, scaleY:.22, ease:Power3.easeInOut}, ">-0.5");
				this.tl1.to(mc.ui.ui.file5.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");			
				this.tl1.to(mc.ui.ui.file5,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
				
		
				//final frame
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"+=23", y:"+=13", scaleX: .315, scaleY: .315, ease:Power3.easeInOut}, ">+0.1");
				this.tl1.to(mc.anim,{duration:1.2, x:"-=27", y:"+=8", scaleX: 1, scaleY: 1, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"-=30", y:"+=30", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				//this.tl1.to(mc.ui.ui.vaultTxt,{duration:1, scaleX:.3, scaleY:.3, alpha:0, ease:Power4.easeInOut}, "<");
				//this.tl1.to(mc.ui.ui.vault,{duration:1, scaleX:.3, scaleY:.3, y:"-=40", alpha:0, ease:Power4.easeInOut}, "<");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ui.ad1,{duration:2, x:"-=120", y:"+=20",  ease:Power3.easeInOut, onStart:function(){mc.ui.ui.ad1.visible=true;}});
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-42.8,84.9,609.1999999999999,284.20000000000005);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622711182939", id:"M365_FY22Q1BTS_USA_300x250_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;