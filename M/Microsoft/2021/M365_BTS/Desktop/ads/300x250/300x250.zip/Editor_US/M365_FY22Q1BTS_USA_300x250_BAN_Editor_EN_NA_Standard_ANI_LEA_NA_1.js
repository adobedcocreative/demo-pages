(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[632,908,137,21],[754,724,112,63],[632,724,120,124],[0,0,734,508],[0,510,630,420],[632,510,157,105],[0,932,628,419],[632,617,157,105],[632,850,155,56],[630,932,136,320]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.angledShadowSml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap58 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.cursor = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.laptop = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.LinkedIn_Screen = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.LinkedInEndFrameSml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Word_Editor_Simplified_Screen = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Word_Editor_Simplified_Screen_Sml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.wordDropdown = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.wordPanel = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wordPanel_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.wordPanel();
	this.instance.setTransform(0,0,0.432,0.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordPanel_1, new cjs.Rectangle(0,0,58.8,138.3), null);


(lib.wordDropdown_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.wordDropdown();
	this.instance.setTransform(0,0,0.432,0.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordDropdown_1, new cjs.Rectangle(0,0,67,24.2), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.socialScreenEnd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.LinkedInEndFrameSml();
	this.instance.setTransform(0,0,1.8029,1.8029);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.socialScreenEnd, new cjs.Rectangle(0,0,283.1,189.3), null);


(lib.sml = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word_Editor_Simplified_Screen_Sml();
	this.instance.setTransform(0,0,1.7243,1.7243);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sml, new cjs.Rectangle(0,0,270.7,181.1), null);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.222,21.222,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6132,21.222,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.222,6.6132,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6132,6.6132,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1754,14.0578,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9643,13.9128,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.5018,13.9128,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.laptopSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.laptop();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.laptopSub, new cjs.Rectangle(0,0,367,254), null);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL7A/XMAAAh+tMCX3AAAMAAAB+tg");
	this.shape.setTransform(486,405.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(0,0,972,811), null);


(lib.highlight_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AgNCGQlwggh6ATQg3AKgughQgtgggKg3QgJg2AgguQAhgtA3gKQCLgaGiAkQFxAgB/gTQA3gJAuAhQAtAgAJA3QAJA2ggAuQghAtg3AKQg8AKhrAAQiXAAj0gVg");
	this.shape.setTransform(66.1902,15.5585);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.highlight_sub, new cjs.Rectangle(0,0,132.4,31.1), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.editorCursor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cursor();
	this.instance.setTransform(0,0,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.editorCursor, new cjs.Rectangle(0,0,30,31), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.dropdown1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap58();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.dropdown1, new cjs.Rectangle(0,0,56,31.5), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AoHCNIAAkZIQPAAIAAEZg");
	this.shape.setTransform(51.35,13.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-0.6,-0.3,104,28.2), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.angledShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.angledShadowSml();
	this.instance.setTransform(11.6,0.15,1.3639,1.3639);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.angledShadow, new cjs.Rectangle(0,0,206.1,31.5), null);


(lib.wordScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlZCDIAAkFIKzAAIAAEFg");
	mask.setTransform(177.775,159.675);

	// Layer_4
	this.dropdown = new lib.wordDropdown_1();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(176.65,158.7,1,1,0,0,0,33.5,12.1);

	var maskedShapeInstanceList = [this.dropdown];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// Layer_3
	this.panel = new lib.wordPanel_1();
	this.panel.name = "panel";
	this.panel.setTransform(241.8,99.45,1,1,0,0,0,29.4,69.1);

	this.timeline.addTween(cjs.Tween.get(this.panel).wait(1));

	// Layer_2
	this.instance = new lib.Word_Editor_Simplified_Screen();
	this.instance.setTransform(0,0,0.4321,0.4321);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordScreen, new cjs.Rectangle(0,0,271.4,181.1), null);


(lib.socialScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ak9CtIAAlZIJ7AAIAAFZg");
	mask.setTransform(101.45,67.325);

	// Layer_3
	this.dropdown = new lib.dropdown1();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(73.75,50.7,0.8702,0.8702,0,0,0,0.1,0.1);

	var maskedShapeInstanceList = [this.dropdown];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// Layer_2
	this.instance = new lib.LinkedIn_Screen();
	this.instance.setTransform(0,0,0.4303,0.4303);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.socialScreen, new cjs.Rectangle(0,0,271.1,180.8), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.highlight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.highlight.cache(-140,-40,280,80,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.highlight = new lib.highlight_sub();
	this.highlight.name = "highlight";
	this.highlight.setTransform(52.7,2.1,1,1,0,0,0,66.2,15.6);

	this.timeline.addTween(cjs.Tween.get(this.highlight).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.highlight, new cjs.Rectangle(-13.5,-13.5,132.4,31.1), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,250,10,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8595,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(300.05,337.5,1,1,0,0,0,486,405.4);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(301.475,344.45);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(301.45,344.45);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,978.8,828.1);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("ApzNIQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwByhxAuMgi6AOGQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_54 = new cjs.Graphics().p("Ap3NKQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOFQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_55 = new cjs.Graphics().p("AqENPQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_56 = new cjs.Graphics().p("AqiNbQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_57 = new cjs.Graphics().p("ArVNwQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQByAwAuByQAvBygxBxQgwByhyAuMgi5AOFQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_58 = new cjs.Graphics().p("AsaOMQhxgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_59 = new cjs.Graphics().p("AtdOnQhxgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_60 = new cjs.Graphics().p("AuTO9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAvQBzAxAuByQAuBygxBxQgwBwhxAvMgi6AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_61 = new cjs.Graphics().p("Au8PNQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_62 = new cjs.Graphics().p("AvbPaQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQBzAwAuByQAuBygxBxQgwBxhyAuMgi5AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_63 = new cjs.Graphics().p("AvzPkQhxgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg6gZg");
	var mask_graphics_64 = new cjs.Graphics().p("AwHPsQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBxAvQByAxAuByQAuBygxBxQgvBwhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_65 = new cjs.Graphics().p("AwWPyQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBwAvQBzAxAuByQAuBygxBxQgvBwhyAuMgi6AOHQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_66 = new cjs.Graphics().p("AwiP3QhwgwguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAxAuByQAuBygxBwQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_67 = new cjs.Graphics().p("AwrP6QhwgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_68 = new cjs.Graphics().p("AwyP9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_69 = new cjs.Graphics().p("Aw3P/QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_70 = new cjs.Graphics().p("Aw6QAQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwBxhxAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_71 = new cjs.Graphics().p("Aw8QBQhwgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_72 = new cjs.Graphics().p("Aw8QBQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg6gZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:202.0962,y:86.5199}).wait(1).to({graphics:mask_graphics_54,x:201.7207,y:86.6713}).wait(1).to({graphics:mask_graphics_55,x:200.3452,y:87.2276}).wait(1).to({graphics:mask_graphics_56,x:197.4159,y:88.4121}).wait(1).to({graphics:mask_graphics_57,x:192.2778,y:90.4898}).wait(1).to({graphics:mask_graphics_58,x:185.33,y:93.2993}).wait(1).to({graphics:mask_graphics_59,x:178.6284,y:96.0092}).wait(1).to({graphics:mask_graphics_60,x:173.2948,y:98.166}).wait(1).to({graphics:mask_graphics_61,x:169.2189,y:99.8141}).wait(1).to({graphics:mask_graphics_62,x:166.0817,y:101.0827}).wait(1).to({graphics:mask_graphics_63,x:163.6368,y:102.0714}).wait(1).to({graphics:mask_graphics_64,x:161.716,y:102.8481}).wait(1).to({graphics:mask_graphics_65,x:160.2043,y:103.4594}).wait(1).to({graphics:mask_graphics_66,x:159.0208,y:103.938}).wait(1).to({graphics:mask_graphics_67,x:158.1068,y:104.3076}).wait(1).to({graphics:mask_graphics_68,x:157.4183,y:104.586}).wait(1).to({graphics:mask_graphics_69,x:156.9218,y:104.7867}).wait(1).to({graphics:mask_graphics_70,x:156.5909,y:104.9205}).wait(1).to({graphics:mask_graphics_71,x:156.4046,y:104.9959}).wait(1).to({graphics:mask_graphics_72,x:156.3462,y:105.0199}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(102.75,162.9,1,1,0,0,0,42,16.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AQ4K1MgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AQ4K6MgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AQ4LGMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AQ4LaMgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AQ4LyMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AQ4MNMgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AQ4MpMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AQ4NBMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AQ4NVMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB3QghB2hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AQ4NhMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AQ4NmMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-96.7896,y:70.4804}).wait(1).to({graphics:mask_1_graphics_45,x:-93.6755,y:70.912}).wait(1).to({graphics:mask_1_graphics_46,x:-84.6383,y:72.1637}).wait(1).to({graphics:mask_1_graphics_47,x:-70.5624,y:74.1133}).wait(1).to({graphics:mask_1_graphics_48,x:-52.8258,y:76.57}).wait(1).to({graphics:mask_1_graphics_49,x:-33.1646,y:79.2932}).wait(1).to({graphics:mask_1_graphics_50,x:-13.5033,y:82.0164}).wait(1).to({graphics:mask_1_graphics_51,x:4.2333,y:84.473}).wait(1).to({graphics:mask_1_graphics_52,x:18.3092,y:86.4226}).wait(1).to({graphics:mask_1_graphics_53,x:27.3464,y:87.6744}).wait(1).to({graphics:mask_1_graphics_54,x:30.4604,y:88.1054}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(87.45,129.7,1,1,0,0,0,57.2,16.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AqeI4Qhqg9gfh3Qggh2A8hrQA/hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_39 = new cjs.Graphics().p("Aq/I4Qhqg9gfh3Qggh2A9hrQA+hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AsbI4Qhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJuQB3ggBpA9QBsA+AgB3QAfB2g+BqQg9Brh2AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AugI7Qhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB3g+BqQg9Brh3AfMgkVAJvQgoAKgnAAQhLAAhHgpg");
	var mask_2_graphics_42 = new cjs.Graphics().p("Aw0JjQhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB2g+BqQg9Brh3AfMgkUAJvQgpALgnAAQhLAAhHgpg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Ay6KHQhqg9gfh3Qggh2A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBrA+AgB3QAgB2g/BqQg8Bqh3AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0WKgQhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJvQB3gfBqA9QBrA+AgB2QAfB3g+BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0fKpQhqg9ggh3Qgfh3A8hrQA/hqB2gfMAkVgJvQB3gfBqA9QBrA+AgB2QAgB3g/BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:210.152,y:47.6773}).wait(1).to({graphics:mask_2_graphics_39,x:206.8592,y:49.4475}).wait(1).to({graphics:mask_2_graphics_40,x:197.6331,y:54.4074}).wait(1).to({graphics:mask_2_graphics_41,x:184.3009,y:61.2431}).wait(1).to({graphics:mask_2_graphics_42,x:169.5032,y:65.2207}).wait(1).to({graphics:mask_2_graphics_43,x:156.171,y:68.8043}).wait(1).to({graphics:mask_2_graphics_44,x:146.9448,y:71.2843}).wait(1).to({graphics:mask_2_graphics_45,x:141.2573,y:72.1694}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(90.65,97,1,1,0,0,0,60.4,16.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARZIjMgkwgIBQh4gbhChnQhChnAah4QAah4BnhDQBohBB4AaMAkwAIBQB4AbBCBlQBDBpgbB4QgaB4hoBBQhKAxhTAAQggAAgigIg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-92.9368,y:26.509}).wait(1).to({graphics:mask_3_graphics_32,x:-89.047,y:27.3834}).wait(1).to({graphics:mask_3_graphics_33,x:-77.8467,y:29.9013}).wait(1).to({graphics:mask_3_graphics_34,x:-60.6868,y:33.759}).wait(1).to({graphics:mask_3_graphics_35,x:-39.6371,y:38.4911}).wait(1).to({graphics:mask_3_graphics_36,x:-17.2365,y:43.5269}).wait(1).to({graphics:mask_3_graphics_37,x:3.8132,y:48.259}).wait(1).to({graphics:mask_3_graphics_38,x:20.973,y:52.1166}).wait(1).to({graphics:mask_3_graphics_39,x:32.1733,y:54.6345}).wait(1).to({graphics:mask_3_graphics_40,x:36.0632,y:55.4651}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(91.3,67.5,1,1,0,0,0,59.7,13.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("ArPHpQhnhFgZh6QgYh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBoBGAZB6QAYB6hGBoQhEBnh7AZMglbAHdQggAHgeAAQhYAAhNg0g");
	var mask_4_graphics_20 = new cjs.Graphics().p("ArTHpQhnhFgYh6QgZh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBpBGAYB6QAYB6hGBoQhEBnh6AZMglcAHdQgfAHgfAAQhXAAhOg0g");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArfHpQhnhFgYh6QgYh6BEhpQBGhmB7gYMAlagHeQB7gYBnBEQBoBGAZB6QAYB7hGBnQhFBnh6AZMglbAHdQgfAGgfAAQhXAAhOgzg");
	var mask_4_graphics_22 = new cjs.Graphics().p("Ar1HoQhnhEgZh6QgYh7BFhoQBGhmB6gYMAlZgHeQB7gYBnBFQBoBFAYB7QAZB6hGBnQhFBnh6AZMglaAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_23 = new cjs.Graphics().p("AsbHoQhnhFgYh6QgYh6BEhoQBGhmB6gYMAlYgHdQB6gZBnBFQBoBGAZB6QAYB6hGBnQhEBnh6AYMglYAHdQggAHgeAAQhXAAhOg0g");
	var mask_4_graphics_24 = new cjs.Graphics().p("AtUHnQhnhEgYh6QgYh6BEhoQBGhmB6gYMAlVgHdQB5gYBnBFQBpBFAYB6QAYB6hGBnQhEBnh6AYMglVAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_25 = new cjs.Graphics().p("AulHnQhnhFgYh6QgZh5BFhoQBFhmB6gYMAlRgHcQB6gYBmBEQBoBGAZB6QAYB5hGBnQhEBnh6AYMglRAHcQgfAGgeAAQhXAAhNgzg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AwLHlQhnhEgYh5QgYh6BEhnQBGhmB5gYMAlLgHbQB6gYBmBFQBoBFAYB5QAZB6hGBmQhEBnh6AYMglLAHbQgfAGgfAAQhWAAhNg0g");
	var mask_4_graphics_27 = new cjs.Graphics().p("AxzHkQhnhEgYh5QgYh5BEhnQBGhmB5gYMAlGgHZQB5gZBmBFQBoBFAYB5QAYB5hFBmQhEBnh5AYMglHAHZQgfAHgeAAQhXAAhMg0g");
	var mask_4_graphics_28 = new cjs.Graphics().p("AzLHjQhmhEgYh4QgYh5BDhoQBGhlB5gYMAlBgHYQB5gZBmBFQBoBFAYB5QAYB4hFBnQhEBmh5AYMglCAHZQgfAGgeAAQhWAAhNg0g");
	var mask_4_graphics_29 = new cjs.Graphics().p("A0OHjQhmhEgYh5QgYh5BEhnQBFhlB5gYMAk+gHYQB5gYBmBEQBnBFAYB5QAYB5hFBmQhEBmh5AYMgk+AHYQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A0/HiQhlhEgYh4QgYh5BDhnQBFhlB5gYMAk8gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk8AHXQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A1CHiQhmhEgYh4QgYh5BEhnQBFhlB5gYMAk6gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk6AHXQggAGgeAAQhWAAhMgzg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A1BHiQhmhEgYh5QgYh4BEhnQBFhlB4gYMAk5gHWQB4gYBmBDQBnBFAYB5QAYB4hFBmQhEBmh4AYMgk5AHWQgfAHgeAAQhWAAhMgzg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:214.6102,y:3.3334}).wait(1).to({graphics:mask_4_graphics_20,x:214.2404,y:3.4806}).wait(1).to({graphics:mask_4_graphics_21,x:212.9875,y:3.9786}).wait(1).to({graphics:mask_4_graphics_22,x:210.5721,y:4.9385}).wait(1).to({graphics:mask_4_graphics_23,x:206.5928,y:6.5199}).wait(1).to({graphics:mask_4_graphics_24,x:200.5171,y:8.9344}).wait(1).to({graphics:mask_4_graphics_25,x:191.8775,y:12.3679}).wait(1).to({graphics:mask_4_graphics_26,x:181.0603,y:16.6668}).wait(1).to({graphics:mask_4_graphics_27,x:170.0151,y:21.0562}).wait(1).to({graphics:mask_4_graphics_28,x:160.7061,y:24.7557}).wait(1).to({graphics:mask_4_graphics_29,x:153.6244,y:27.57}).wait(1).to({graphics:mask_4_graphics_30,x:148.4436,y:29.629}).wait(1).to({graphics:mask_4_graphics_31,x:141.5638,y:31.1044}).wait(1).to({graphics:mask_4_graphics_32,x:136.4625,y:32.1336}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(94.8,41.2,1,1,0,0,0,63.2,13.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2,188.1,211.9);


(lib.wordScreenSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.sml = new lib.sml();
	this.sml.name = "sml";
	this.sml.setTransform(135.3,90.5,1,1,0,0,0,135.3,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sml).wait(1));

	// Layer_1
	this.sub = new lib.wordScreen();
	this.sub.name = "sub";
	this.sub.setTransform(135.7,90.5,1,1,0,0,0,135.7,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordScreenSub, new cjs.Rectangle(0,0,271.4,181.1), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-12.2,0.5,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Poplines
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.popRight},{t:this.popLeft}]}).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.9,143.7,28.200000000000003), null);


(lib.laptop_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}
	this.frame_90 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(31).call(this.frame_90).wait(1));

	// endCursor
	this.editorCursorEnd = new lib.editorCursor();
	this.editorCursorEnd.name = "editorCursorEnd";
	this.editorCursorEnd.setTransform(120.4,155,1,1,0,0,0,0,31);

	this.timeline.addTween(cjs.Tween.get(this.editorCursorEnd).wait(91));

	// editorCursor
	this.editorCursor = new lib.editorCursor();
	this.editorCursor.name = "editorCursor";
	this.editorCursor.setTransform(150,35.5,1,1,0,0,0,15,15.5);

	this.timeline.addTween(cjs.Tween.get(this.editorCursor).wait(91));

	// rightMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AEBOxIAA8tIU/AAIAActg");
	var mask_graphics_1 = new cjs.Graphics().p("AEJOxIAA8tIU3AAIAActg");
	var mask_graphics_2 = new cjs.Graphics().p("AEUOxIAA8tIUsAAIAActg");
	var mask_graphics_3 = new cjs.Graphics().p("AEjOxIAA8tIUdAAIAActg");
	var mask_graphics_4 = new cjs.Graphics().p("AE3OxIAA8tIUJAAIAActg");
	var mask_graphics_5 = new cjs.Graphics().p("AFQOxIAA8tITwAAIAActg");
	var mask_graphics_6 = new cjs.Graphics().p("AFuOxIAA8tITSAAIAActg");
	var mask_graphics_7 = new cjs.Graphics().p("AGTOxIAA8sIStAAIAAcsg");
	var mask_graphics_8 = new cjs.Graphics().p("AG+OxIAA8sISCAAIAAcsg");
	var mask_graphics_9 = new cjs.Graphics().p("AHuOxIAA8sIRSAAIAAcsg");
	var mask_graphics_10 = new cjs.Graphics().p("AIjOxIAA8sIQdAAIAAcsg");
	var mask_graphics_11 = new cjs.Graphics().p("AJZOxIAA8sIPnAAIAAcsg");
	var mask_graphics_12 = new cjs.Graphics().p("AKPOxIAA8sIOxAAIAAcsg");
	var mask_graphics_13 = new cjs.Graphics().p("ALBOxIAA8sIN/AAIAAcsg");
	var mask_graphics_14 = new cjs.Graphics().p("ALwOxIAA8sINQAAIAAcsg");
	var mask_graphics_15 = new cjs.Graphics().p("AMaOxIAA8sIMmAAIAAcsg");
	var mask_graphics_16 = new cjs.Graphics().p("AM/OxIAA8sIMBAAIAAcsg");
	var mask_graphics_17 = new cjs.Graphics().p("ANeOxIAA8sILiAAIAAcsg");
	var mask_graphics_18 = new cjs.Graphics().p("AN6OxIAA8sILGAAIAAcsg");
	var mask_graphics_19 = new cjs.Graphics().p("AOSOxIAA8sIKuAAIAAcsg");
	var mask_graphics_20 = new cjs.Graphics().p("AOmOxIAA8sIKaAAIAAcsg");
	var mask_graphics_21 = new cjs.Graphics().p("AO2OxIAA8sIKKAAIAAcsg");
	var mask_graphics_22 = new cjs.Graphics().p("APEOxIAA8sIJ8AAIAAcsg");
	var mask_graphics_23 = new cjs.Graphics().p("APQOxIAA8sIJwAAIAAcsg");
	var mask_graphics_24 = new cjs.Graphics().p("APZOxIAA8sIJnAAIAAcsg");
	var mask_graphics_25 = new cjs.Graphics().p("APgOxIAA8sIJgAAIAAcsg");
	var mask_graphics_26 = new cjs.Graphics().p("APlOxIAA8sIJbAAIAAcsg");
	var mask_graphics_27 = new cjs.Graphics().p("APpOxIAA8sIJXAAIAAcsg");
	var mask_graphics_28 = new cjs.Graphics().p("APrOxIAA8sIJVAAIAAcsg");
	var mask_graphics_29 = new cjs.Graphics().p("APsOxIAA8tIJUAAIAActg");
	var mask_graphics_30 = new cjs.Graphics().p("APcOxIAA8tIJkAAIAActg");
	var mask_graphics_31 = new cjs.Graphics().p("APEOxIAA8tIJ8AAIAActg");
	var mask_graphics_32 = new cjs.Graphics().p("AOlOxIAA8tIKbAAIAActg");
	var mask_graphics_33 = new cjs.Graphics().p("AN8OxIAA8tILEAAIAActg");
	var mask_graphics_34 = new cjs.Graphics().p("ANJOwIAA8sIL3AAIAAcsg");
	var mask_graphics_35 = new cjs.Graphics().p("AMKOwIAA8sIM2AAIAAcsg");
	var mask_graphics_36 = new cjs.Graphics().p("AK/OwIAA8sIOBAAIAAcsg");
	var mask_graphics_37 = new cjs.Graphics().p("AJnOwIAA8sIPZAAIAAcsg");
	var mask_graphics_38 = new cjs.Graphics().p("AIDOwIAA8sIQ9AAIAAcsg");
	var mask_graphics_39 = new cjs.Graphics().p("AGWOwIAA8sISqAAIAAcsg");
	var mask_graphics_40 = new cjs.Graphics().p("AEkOwIAA8sIUcAAIAAcsg");
	var mask_graphics_41 = new cjs.Graphics().p("ACwOwIAA8sIWQAAIAAcsg");
	var mask_graphics_42 = new cjs.Graphics().p("ABBOwIAA8sIX/AAIAAcsg");
	var mask_graphics_43 = new cjs.Graphics().p("AglOwIAA8sIZlAAIAAcsg");
	var mask_graphics_44 = new cjs.Graphics().p("AiDOwIAA8sIbDAAIAAcsg");
	var mask_graphics_45 = new cjs.Graphics().p("AjWOwIAA8sIcWAAIAAcsg");
	var mask_graphics_46 = new cjs.Graphics().p("AkgOwIAA8sIdgAAIAAcsg");
	var mask_graphics_47 = new cjs.Graphics().p("AlgOwIAA8sIegAAIAAcsg");
	var mask_graphics_48 = new cjs.Graphics().p("AmXOwIAA8sIfXAAIAAcsg");
	var mask_graphics_49 = new cjs.Graphics().p("AnGOwIAA8sMAgGAAAIAAcsg");
	var mask_graphics_50 = new cjs.Graphics().p("AnvOwIAA8sMAgvAAAIAAcsg");
	var mask_graphics_51 = new cjs.Graphics().p("AoROwIAA8sMAhRAAAIAAcsg");
	var mask_graphics_52 = new cjs.Graphics().p("AotOwIAA8sMAhtAAAIAAcsg");
	var mask_graphics_53 = new cjs.Graphics().p("ApEOwIAA8sMAiEAAAIAAcsg");
	var mask_graphics_54 = new cjs.Graphics().p("ApXOwIAA8sMAiXAAAIAAcsg");
	var mask_graphics_55 = new cjs.Graphics().p("AplOwIAA8sMAilAAAIAAcsg");
	var mask_graphics_56 = new cjs.Graphics().p("ApwOwIAA8sMAiwAAAIAAcsg");
	var mask_graphics_57 = new cjs.Graphics().p("Ap3OwIAA8sMAi3AAAIAAcsg");
	var mask_graphics_58 = new cjs.Graphics().p("Ap8OwIAA8sMAi8AAAIAAcsg");
	var mask_graphics_59 = new cjs.Graphics().p("Ap9OxIAA8tMAi9AAAIAActg");
	var mask_graphics_60 = new cjs.Graphics().p("AqCOxIAA8tMAjCAAAIAActg");
	var mask_graphics_61 = new cjs.Graphics().p("AqJOxIAA8tMAjJAAAIAActg");
	var mask_graphics_62 = new cjs.Graphics().p("AqSOxIAA8tMAjSAAAIAActg");
	var mask_graphics_63 = new cjs.Graphics().p("AqeOxIAA8tMAjeAAAIAActg");
	var mask_graphics_64 = new cjs.Graphics().p("AqtOxIAA8tMAjtAAAIAActg");
	var mask_graphics_65 = new cjs.Graphics().p("ArAOxIAA8tMAkAAAAIAActg");
	var mask_graphics_66 = new cjs.Graphics().p("ArWOxIAA8tMAkWAAAIAActg");
	var mask_graphics_67 = new cjs.Graphics().p("ArwOxIAA8tMAkwAAAIAActg");
	var mask_graphics_68 = new cjs.Graphics().p("AsOOxIAA8tMAlOAAAIAActg");
	var mask_graphics_69 = new cjs.Graphics().p("AsuOxIAA8tMAluAAAIAActg");
	var mask_graphics_70 = new cjs.Graphics().p("AtQOxIAA8tMAmQAAAIAActg");
	var mask_graphics_71 = new cjs.Graphics().p("AtzOxIAA8tMAmzAAAIAActg");
	var mask_graphics_72 = new cjs.Graphics().p("AuTOxIAA8tMAnTAAAIAActg");
	var mask_graphics_73 = new cjs.Graphics().p("AuyOxIAA8tMAnyAAAIAActg");
	var mask_graphics_74 = new cjs.Graphics().p("AvOOxIAA8tMAoOAAAIAActg");
	var mask_graphics_75 = new cjs.Graphics().p("AvnOxIAA8tMAonAAAIAActg");
	var mask_graphics_76 = new cjs.Graphics().p("Av9OxIAA8tMAo9AAAIAActg");
	var mask_graphics_77 = new cjs.Graphics().p("AwPOxIAA8tMApPAAAIAActg");
	var mask_graphics_78 = new cjs.Graphics().p("AwgOxIAA8tMApgAAAIAActg");
	var mask_graphics_79 = new cjs.Graphics().p("AwuOxIAA8tMApuAAAIAActg");
	var mask_graphics_80 = new cjs.Graphics().p("Aw6OxIAA8tMAp6AAAIAActg");
	var mask_graphics_81 = new cjs.Graphics().p("AxEOxIAA8tMAqEAAAIAActg");
	var mask_graphics_82 = new cjs.Graphics().p("AxMOxIAA8tMAqMAAAIAActg");
	var mask_graphics_83 = new cjs.Graphics().p("AxTOxIAA8tMAqTAAAIAActg");
	var mask_graphics_84 = new cjs.Graphics().p("AxZOxIAA8tMAqZAAAIAActg");
	var mask_graphics_85 = new cjs.Graphics().p("AxdOxIAA8tMAqdAAAIAActg");
	var mask_graphics_86 = new cjs.Graphics().p("AxgOxIAA8tMAqgAAAIAActg");
	var mask_graphics_87 = new cjs.Graphics().p("AxiOxIAA8tMAqiAAAIAActg");
	var mask_graphics_88 = new cjs.Graphics().p("AxkOxIAA8tMAqkAAAIAActg");
	var mask_graphics_89 = new cjs.Graphics().p("AxlOxIAA8tMAqkAAAIAActg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:159.978,y:94.4521}).wait(1).to({graphics:mask_graphics_1,x:159.9779,y:94.4524}).wait(1).to({graphics:mask_graphics_2,x:159.9778,y:94.4528}).wait(1).to({graphics:mask_graphics_3,x:159.9776,y:94.4533}).wait(1).to({graphics:mask_graphics_4,x:159.9774,y:94.4539}).wait(1).to({graphics:mask_graphics_5,x:159.9772,y:94.4548}).wait(1).to({graphics:mask_graphics_6,x:159.9769,y:94.4558}).wait(1).to({graphics:mask_graphics_7,x:159.9765,y:94.457}).wait(1).to({graphics:mask_graphics_8,x:159.9761,y:94.4585}).wait(1).to({graphics:mask_graphics_9,x:159.9757,y:94.4601}).wait(1).to({graphics:mask_graphics_10,x:159.9752,y:94.4618}).wait(1).to({graphics:mask_graphics_11,x:159.9746,y:94.4637}).wait(1).to({graphics:mask_graphics_12,x:159.9741,y:94.4655}).wait(1).to({graphics:mask_graphics_13,x:159.9736,y:94.4672}).wait(1).to({graphics:mask_graphics_14,x:159.9732,y:94.4687}).wait(1).to({graphics:mask_graphics_15,x:159.9728,y:94.4701}).wait(1).to({graphics:mask_graphics_16,x:159.9724,y:94.4713}).wait(1).to({graphics:mask_graphics_17,x:159.9721,y:94.4724}).wait(1).to({graphics:mask_graphics_18,x:159.9719,y:94.4733}).wait(1).to({graphics:mask_graphics_19,x:159.9716,y:94.4741}).wait(1).to({graphics:mask_graphics_20,x:159.9714,y:94.4748}).wait(1).to({graphics:mask_graphics_21,x:159.9713,y:94.4754}).wait(1).to({graphics:mask_graphics_22,x:159.9711,y:94.4758}).wait(1).to({graphics:mask_graphics_23,x:159.971,y:94.4762}).wait(1).to({graphics:mask_graphics_24,x:159.9709,y:94.4765}).wait(1).to({graphics:mask_graphics_25,x:159.9709,y:94.4768}).wait(1).to({graphics:mask_graphics_26,x:159.9708,y:94.4769}).wait(1).to({graphics:mask_graphics_27,x:159.9708,y:94.4771}).wait(1).to({graphics:mask_graphics_28,x:159.9708,y:94.4771}).wait(1).to({graphics:mask_graphics_29,x:159.9819,y:94.4521}).wait(1).to({graphics:mask_graphics_30,x:159.982,y:94.4519}).wait(1).to({graphics:mask_graphics_31,x:159.9823,y:94.4515}).wait(1).to({graphics:mask_graphics_32,x:159.9826,y:94.4511}).wait(1).to({graphics:mask_graphics_33,x:159.9831,y:94.4504}).wait(1).to({graphics:mask_graphics_34,x:159.9836,y:94.4497}).wait(1).to({graphics:mask_graphics_35,x:159.9843,y:94.4487}).wait(1).to({graphics:mask_graphics_36,x:159.9852,y:94.4476}).wait(1).to({graphics:mask_graphics_37,x:159.9861,y:94.4462}).wait(1).to({graphics:mask_graphics_38,x:159.9872,y:94.4447}).wait(1).to({graphics:mask_graphics_39,x:159.9884,y:94.443}).wait(1).to({graphics:mask_graphics_40,x:159.9897,y:94.4413}).wait(1).to({graphics:mask_graphics_41,x:159.9909,y:94.4395}).wait(1).to({graphics:mask_graphics_42,x:159.9922,y:94.4379}).wait(1).to({graphics:mask_graphics_43,x:159.9933,y:94.4363}).wait(1).to({graphics:mask_graphics_44,x:159.9943,y:94.4348}).wait(1).to({graphics:mask_graphics_45,x:159.9952,y:94.4336}).wait(1).to({graphics:mask_graphics_46,x:159.996,y:94.4325}).wait(1).to({graphics:mask_graphics_47,x:159.9967,y:94.4315}).wait(1).to({graphics:mask_graphics_48,x:159.9973,y:94.4306}).wait(1).to({graphics:mask_graphics_49,x:159.9979,y:94.4299}).wait(1).to({graphics:mask_graphics_50,x:159.9983,y:94.4293}).wait(1).to({graphics:mask_graphics_51,x:159.9987,y:94.4288}).wait(1).to({graphics:mask_graphics_52,x:159.999,y:94.4284}).wait(1).to({graphics:mask_graphics_53,x:159.9992,y:94.428}).wait(1).to({graphics:mask_graphics_54,x:159.9994,y:94.4277}).wait(1).to({graphics:mask_graphics_55,x:159.9996,y:94.4275}).wait(1).to({graphics:mask_graphics_56,x:159.9997,y:94.4273}).wait(1).to({graphics:mask_graphics_57,x:159.9998,y:94.4272}).wait(1).to({graphics:mask_graphics_58,x:159.9999,y:94.4272}).wait(1).to({graphics:mask_graphics_59,x:159.9999,y:94.4521}).wait(1).to({graphics:mask_graphics_60,x:160,y:94.4521}).wait(1).to({graphics:mask_graphics_61,x:160.0002,y:94.4521}).wait(1).to({graphics:mask_graphics_62,x:160.0004,y:94.4521}).wait(1).to({graphics:mask_graphics_63,x:160.0007,y:94.4521}).wait(1).to({graphics:mask_graphics_64,x:160.0011,y:94.4521}).wait(1).to({graphics:mask_graphics_65,x:160.0016,y:94.4521}).wait(1).to({graphics:mask_graphics_66,x:160.0021,y:94.4521}).wait(1).to({graphics:mask_graphics_67,x:160.0028,y:94.4521}).wait(1).to({graphics:mask_graphics_68,x:160.0035,y:94.4521}).wait(1).to({graphics:mask_graphics_69,x:160.0043,y:94.4521}).wait(1).to({graphics:mask_graphics_70,x:160.0052,y:94.4521}).wait(1).to({graphics:mask_graphics_71,x:160.006,y:94.4521}).wait(1).to({graphics:mask_graphics_72,x:160.0069,y:94.4521}).wait(1).to({graphics:mask_graphics_73,x:160.0076,y:94.4521}).wait(1).to({graphics:mask_graphics_74,x:160.0083,y:94.4521}).wait(1).to({graphics:mask_graphics_75,x:160.009,y:94.4521}).wait(1).to({graphics:mask_graphics_76,x:160.0095,y:94.4521}).wait(1).to({graphics:mask_graphics_77,x:160.01,y:94.4521}).wait(1).to({graphics:mask_graphics_78,x:160.0104,y:94.4521}).wait(1).to({graphics:mask_graphics_79,x:160.0108,y:94.4521}).wait(1).to({graphics:mask_graphics_80,x:160.0111,y:94.4521}).wait(1).to({graphics:mask_graphics_81,x:160.0113,y:94.4521}).wait(1).to({graphics:mask_graphics_82,x:160.0115,y:94.4521}).wait(1).to({graphics:mask_graphics_83,x:160.0117,y:94.4521}).wait(1).to({graphics:mask_graphics_84,x:160.0118,y:94.4521}).wait(1).to({graphics:mask_graphics_85,x:160.0119,y:94.4521}).wait(1).to({graphics:mask_graphics_86,x:160.012,y:94.4521}).wait(1).to({graphics:mask_graphics_87,x:160.0121,y:94.4521}).wait(1).to({graphics:mask_graphics_88,x:160.0121,y:94.4521}).wait(1).to({graphics:mask_graphics_89,x:159.9106,y:94.4521}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// wordScreen
	this.wordScreen = new lib.wordScreenSub();
	this.wordScreen.name = "wordScreen";
	this.wordScreen.setTransform(47.85,187.55,1,1,0,0,0,0,181.1);

	var maskedShapeInstanceList = [this.wordScreen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.wordScreen).wait(91));

	// leftMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Am5OxIAA8tIVSAAIAActg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Am9OxIAA8tIVZAAIAActg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AnCOxIAA8tIVkAAIAActg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AnKOxIAA8tIVzAAIAActg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AnUOxIAA8tIWHAAIAActg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AngOxIAA8tIWgAAIAActg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnvOxIAA8tIW+AAIAActg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AoBOxIAA8tIXiAAIAActg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AoXOxIAA8tIYNAAIAActg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AovOxIAA8tIY9AAIAActg");
	var mask_1_graphics_10 = new cjs.Graphics().p("ApJOxIAA8tIZxAAIAActg");
	var mask_1_graphics_11 = new cjs.Graphics().p("ApjOxIAA8tIamAAIAActg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ap+OxIAA8tIbcAAIAActg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AqXOxIAA8tIcOAAIAActg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AquOxIAA8tIc8AAIAActg");
	var mask_1_graphics_15 = new cjs.Graphics().p("ArDOxIAA8tIdmAAIAActg");
	var mask_1_graphics_16 = new cjs.Graphics().p("ArVOxIAA8tIeKAAIAActg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArlOxIAA8tIeqAAIAActg");
	var mask_1_graphics_18 = new cjs.Graphics().p("ArzOxIAA8tIfFAAIAActg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Ar+OxIAA8tIfcAAIAActg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AsIOxIAA8tIfwAAIAActg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AsROxIAA8tMAgBAAAIAActg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AsYOxIAA8tMAgPAAAIAActg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AsdOxIAA8tMAgaAAAIAActg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AsiOxIAA8tMAgkAAAIAActg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AslOxIAA8tMAgqAAAIAActg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AsoOxIAA8tMAgwAAAIAActg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AsqOxIAA8tMAgzAAAIAActg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AsrOxIAA8tMAg1AAAIAActg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AsrOxIAA8tMAg1AAAIAActg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AsjOxIAA8tMAglAAAIAActg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AsYOxIAA8tMAgPAAAIAActg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AsIOxIAA8tIfvAAIAActg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ar0OxIAA8tIfGAAIAActg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AraOxIAA8tIeTAAIAActg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Aq7OxIAA8tIdVAAIAActg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqVOxIAA8tIcJAAIAActg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AppOxIAA8tIaxAAIAActg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ao4OxIAA8tIZOAAIAActg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AoBOxIAA8tIXhAAIAActg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AnIOxIAA8tIVvAAIAActg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AmOOxIAA8tIT7AAIAActg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AlXOxIAA8tISNAAIAActg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkjOxIAA8tIQlAAIAActg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Aj0OxIAA8tIPHAAIAActg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AjLOxIAA8tIN0AAIAActg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AimOxIAA8tIMrAAIAActg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AiGOxIAA8tILrAAIAActg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AhrOxIAA8tIK0AAIAActg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AhTOxIAA8tIKFAAIAActg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Ag/OxIAA8tIJdAAIAActg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AguOxIAA8tII7AAIAActg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AggOxIAA8tIIeAAIAActg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AgUOxIAA8tIIHAAIAActg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AgLOxIAA8tIH0AAIAActg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AgDOxIAA8tIHlAAIAActg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AABOxIAA8tIHcAAIAActg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AAFOxIAA8tIHUAAIAActg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AAHOxIAA8tIHQAAIAActg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AAIOxIAA8tIHPAAIAActg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AAKOxIAA8tIHKAAIAActg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AAMOxIAA8tIHFAAIAActg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AAQOxIAA8tIG8AAIAActg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AAVOxIAA8tIGxAAIAActg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AAcOxIAA8tIGiAAIAActg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AAkOxIAA8tIGRAAIAActg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AAtOxIAA8tIF9AAIAActg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AA4OxIAA8tIFlAAIAActg");
	var mask_1_graphics_68 = new cjs.Graphics().p("ABEOxIAA8tIFKAAIAActg");
	var mask_1_graphics_69 = new cjs.Graphics().p("ABSOxIAA8tIEsAAIAActg");
	var mask_1_graphics_70 = new cjs.Graphics().p("ABgOxIAA8tIENAAIAActg");
	var mask_1_graphics_71 = new cjs.Graphics().p("ABvOxIAA8tIDtAAIAActg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AB8OxIAA8tIDPAAIAActg");
	var mask_1_graphics_73 = new cjs.Graphics().p("ACJOxIAA8tICzAAIAActg");
	var mask_1_graphics_74 = new cjs.Graphics().p("ACVOxIAA8tICZAAIAActg");
	var mask_1_graphics_75 = new cjs.Graphics().p("ACfOxIAA8tICDAAIAActg");
	var mask_1_graphics_76 = new cjs.Graphics().p("ACpOxIAA8sIBuAAIAAcsg");
	var mask_1_graphics_77 = new cjs.Graphics().p("ACxOxIAA8sIBcAAIAAcsg");
	var mask_1_graphics_78 = new cjs.Graphics().p("AC3OxIAA8sIBOAAIAAcsg");
	var mask_1_graphics_79 = new cjs.Graphics().p("AC9OxIAA8sIBBAAIAAcsg");
	var mask_1_graphics_80 = new cjs.Graphics().p("ADCOxIAA8sIA2AAIAAcsg");
	var mask_1_graphics_81 = new cjs.Graphics().p("ADHOxIAA8sIAsAAIAAcsg");
	var mask_1_graphics_82 = new cjs.Graphics().p("ADKOxIAA8sIAlAAIAAcsg");
	var mask_1_graphics_83 = new cjs.Graphics().p("ADNOxIAA8sIAeAAIAAcsg");
	var mask_1_graphics_84 = new cjs.Graphics().p("ADPOxIAA8sIAaAAIAAcsg");
	var mask_1_graphics_85 = new cjs.Graphics().p("ADROxIAA8sIAVAAIAAcsg");
	var mask_1_graphics_86 = new cjs.Graphics().p("ADTOxIAA8sIASAAIAAcsg");
	var mask_1_graphics_87 = new cjs.Graphics().p("ADTOxIAA8sIARAAIAAcsg");
	var mask_1_graphics_88 = new cjs.Graphics().p("ADUOxIAA8sIAPAAIAAcsg");
	var mask_1_graphics_89 = new cjs.Graphics().p("ADUOxIAA8sIAPAAIAAcsg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:92.0519,y:94.4521}).wait(1).to({graphics:mask_1_graphics_1,x:92.4343,y:94.4521}).wait(1).to({graphics:mask_1_graphics_2,x:92.9899,y:94.4521}).wait(1).to({graphics:mask_1_graphics_3,x:93.7431,y:94.4521}).wait(1).to({graphics:mask_1_graphics_4,x:94.7216,y:94.4521}).wait(1).to({graphics:mask_1_graphics_5,x:95.9548,y:94.4521}).wait(1).to({graphics:mask_1_graphics_6,x:97.4707,y:94.4521}).wait(1).to({graphics:mask_1_graphics_7,x:99.2896,y:94.4521}).wait(1).to({graphics:mask_1_graphics_8,x:101.4132,y:94.4521}).wait(1).to({graphics:mask_1_graphics_9,x:103.8115,y:94.4521}).wait(1).to({graphics:mask_1_graphics_10,x:106.4121,y:94.4521}).wait(1).to({graphics:mask_1_graphics_11,x:109.1049,y:94.4521}).wait(1).to({graphics:mask_1_graphics_12,x:111.7656,y:94.4521}).wait(1).to({graphics:mask_1_graphics_13,x:114.2873,y:94.4521}).wait(1).to({graphics:mask_1_graphics_14,x:116.5994,y:94.4521}).wait(1).to({graphics:mask_1_graphics_15,x:118.6687,y:94.4521}).wait(1).to({graphics:mask_1_graphics_16,x:120.4902,y:94.4521}).wait(1).to({graphics:mask_1_graphics_17,x:122.0747,y:94.4521}).wait(1).to({graphics:mask_1_graphics_18,x:123.4409,y:94.4521}).wait(1).to({graphics:mask_1_graphics_19,x:124.6097,y:94.4521}).wait(1).to({graphics:mask_1_graphics_20,x:125.6019,y:94.4521}).wait(1).to({graphics:mask_1_graphics_21,x:126.4363,y:94.4521}).wait(1).to({graphics:mask_1_graphics_22,x:127.13,y:94.4521}).wait(1).to({graphics:mask_1_graphics_23,x:127.6978,y:94.4521}).wait(1).to({graphics:mask_1_graphics_24,x:128.1527,y:94.4521}).wait(1).to({graphics:mask_1_graphics_25,x:128.506,y:94.4521}).wait(1).to({graphics:mask_1_graphics_26,x:128.7674,y:94.4521}).wait(1).to({graphics:mask_1_graphics_27,x:128.9455,y:94.4521}).wait(1).to({graphics:mask_1_graphics_28,x:129.0477,y:94.4521}).wait(1).to({graphics:mask_1_graphics_29,x:129.0418,y:94.4521}).wait(1).to({graphics:mask_1_graphics_30,x:128.2291,y:94.4521}).wait(1).to({graphics:mask_1_graphics_31,x:127.0596,y:94.4521}).wait(1).to({graphics:mask_1_graphics_32,x:125.4847,y:94.4521}).wait(1).to({graphics:mask_1_graphics_33,x:123.4495,y:94.4521}).wait(1).to({graphics:mask_1_graphics_34,x:120.8954,y:94.4521}).wait(1).to({graphics:mask_1_graphics_35,x:117.7653,y:94.4521}).wait(1).to({graphics:mask_1_graphics_36,x:114.0142,y:94.4521}).wait(1).to({graphics:mask_1_graphics_37,x:109.628,y:94.4521}).wait(1).to({graphics:mask_1_graphics_38,x:104.6483,y:94.4521}).wait(1).to({graphics:mask_1_graphics_39,x:99.1952,y:94.4521}).wait(1).to({graphics:mask_1_graphics_40,x:93.4687,y:94.4521}).wait(1).to({graphics:mask_1_graphics_41,x:87.7152,y:94.4521}).wait(1).to({graphics:mask_1_graphics_42,x:82.1688,y:94.4521}).wait(1).to({graphics:mask_1_graphics_43,x:77.0038,y:94.4521}).wait(1).to({graphics:mask_1_graphics_44,x:72.318,y:94.4521}).wait(1).to({graphics:mask_1_graphics_45,x:68.1457,y:94.4521}).wait(1).to({graphics:mask_1_graphics_46,x:64.479,y:94.4521}).wait(1).to({graphics:mask_1_graphics_47,x:61.287,y:94.4521}).wait(1).to({graphics:mask_1_graphics_48,x:58.5297,y:94.4521}).wait(1).to({graphics:mask_1_graphics_49,x:56.1648,y:94.4521}).wait(1).to({graphics:mask_1_graphics_50,x:54.152,y:94.4521}).wait(1).to({graphics:mask_1_graphics_51,x:52.4546,y:94.4521}).wait(1).to({graphics:mask_1_graphics_52,x:51.0398,y:94.4521}).wait(1).to({graphics:mask_1_graphics_53,x:49.8789,y:94.4521}).wait(1).to({graphics:mask_1_graphics_54,x:48.9467,y:94.4521}).wait(1).to({graphics:mask_1_graphics_55,x:48.2212,y:94.4521}).wait(1).to({graphics:mask_1_graphics_56,x:47.6833,y:94.4521}).wait(1).to({graphics:mask_1_graphics_57,x:47.3162,y:94.4521}).wait(1).to({graphics:mask_1_graphics_58,x:47.1053,y:94.4521}).wait(1).to({graphics:mask_1_graphics_59,x:47.0546,y:94.4521}).wait(1).to({graphics:mask_1_graphics_60,x:46.8131,y:94.4521}).wait(1).to({graphics:mask_1_graphics_61,x:46.4656,y:94.4521}).wait(1).to({graphics:mask_1_graphics_62,x:45.9975,y:94.4521}).wait(1).to({graphics:mask_1_graphics_63,x:45.3927,y:94.452}).wait(1).to({graphics:mask_1_graphics_64,x:44.6337,y:94.452}).wait(1).to({graphics:mask_1_graphics_65,x:43.7036,y:94.4519}).wait(1).to({graphics:mask_1_graphics_66,x:42.5888,y:94.4519}).wait(1).to({graphics:mask_1_graphics_67,x:41.2854,y:94.4518}).wait(1).to({graphics:mask_1_graphics_68,x:39.8056,y:94.4517}).wait(1).to({graphics:mask_1_graphics_69,x:38.185,y:94.4516}).wait(1).to({graphics:mask_1_graphics_70,x:36.4833,y:94.4515}).wait(1).to({graphics:mask_1_graphics_71,x:34.7735,y:94.4514}).wait(1).to({graphics:mask_1_graphics_72,x:33.1253,y:94.4513}).wait(1).to({graphics:mask_1_graphics_73,x:31.5904,y:94.4513}).wait(1).to({graphics:mask_1_graphics_74,x:30.1979,y:94.4512}).wait(1).to({graphics:mask_1_graphics_75,x:28.9581,y:94.4511}).wait(1).to({graphics:mask_1_graphics_76,x:27.8684,y:94.451}).wait(1).to({graphics:mask_1_graphics_77,x:26.9198,y:94.451}).wait(1).to({graphics:mask_1_graphics_78,x:26.1004,y:94.4509}).wait(1).to({graphics:mask_1_graphics_79,x:25.3977,y:94.4509}).wait(1).to({graphics:mask_1_graphics_80,x:24.7995,y:94.4509}).wait(1).to({graphics:mask_1_graphics_81,x:24.2951,y:94.4508}).wait(1).to({graphics:mask_1_graphics_82,x:23.8747,y:94.4508}).wait(1).to({graphics:mask_1_graphics_83,x:23.5297,y:94.4508}).wait(1).to({graphics:mask_1_graphics_84,x:23.2526,y:94.4508}).wait(1).to({graphics:mask_1_graphics_85,x:23.0371,y:94.4508}).wait(1).to({graphics:mask_1_graphics_86,x:22.8772,y:94.4508}).wait(1).to({graphics:mask_1_graphics_87,x:22.7681,y:94.4507}).wait(1).to({graphics:mask_1_graphics_88,x:22.7054,y:94.4507}).wait(1).to({graphics:mask_1_graphics_89,x:22.6926,y:94.4507}).wait(2));

	// socialScreen
	this.socialScreen = new lib.socialScreen();
	this.socialScreen.name = "socialScreen";
	this.socialScreen.setTransform(183.6,96.8,1,1,0,0,0,135.6,90.5);

	var maskedShapeInstanceList = [this.socialScreen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.socialScreen).wait(91));

	// LinkedInEndFrame
	this.socialScreenEnd = new lib.socialScreenEnd();
	this.socialScreenEnd.name = "socialScreenEnd";
	this.socialScreenEnd.setTransform(114.9,154.5,0.3296,0.3296,-20.7926,0,0,0.7,189.7);

	this.timeline.addTween(cjs.Tween.get(this.socialScreenEnd).wait(91));

	// angledShadows
	this.angledShadow2 = new lib.angledShadow();
	this.angledShadow2.name = "angledShadow2";
	this.angledShadow2.setTransform(198.45,153.85,0.6902,0.6902,0,0,0,18.4,21.9);

	this.angledShadow1 = new lib.angledShadow();
	this.angledShadow1.name = "angledShadow1";
	this.angledShadow1.setTransform(109.65,153.85,0.6902,0.6902,0,0,0,18.4,21.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.angledShadow1},{t:this.angledShadow2}]}).wait(91));

	// Layer_1
	this.laptop = new lib.laptopSub();
	this.laptop.name = "laptop";
	this.laptop.setTransform(183.5,127,1,1,0,0,0,183.5,127);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-58.4,367,312.4);


(lib.IntroTxtHighlights = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_61 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(61).call(this.frame_61).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_36 = new cjs.Graphics().p("ACtDAQgEAAgDg5QgDg3AAhQQAAhPADg4QADg4AEAAIBVAAQAEAAADA4QADA4AABPQAABQgDA3QgDA5gEAAg");
	var mask_graphics_37 = new cjs.Graphics().p("ACnDAQgFAAgEg5QgEg3AAhQQAAhPAEg4QADg4AGAAIBiAAQAFAAADA4QAEA4AABPQAABQgEA3QgDA5gFAAg");
	var mask_graphics_38 = new cjs.Graphics().p("ACcDAQgGAAgEg5QgFg3AAhQQAAhPAFg4QAEg4AGAAIB3AAQAGAAAFA4QAEA4AABPQAABQgEA3QgFA5gGAAg");
	var mask_graphics_39 = new cjs.Graphics().p("ACNDAQgHAAgGg5QgFg3AAhQQAAhPAFg4QAGg4AHAAICVAAQAHAAAGA4QAFA4AABPQAABQgFA3QgGA5gHAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AB6DAQgKAAgHg5QgHg3AAhQQAAhPAHg4QAHg4AKAAIC7AAQAKAAAGA4QAHA4AABPQAABQgHA3QgGA5gKAAg");
	var mask_graphics_41 = new cjs.Graphics().p("ABgDAQgMAAgIg5QgJg3AAhQQAAhPAJg4QAIg4AMAAIDuAAQAMAAAJA4QAIA4AABPQAABQgIA3QgJA5gMAAg");
	var mask_graphics_42 = new cjs.Graphics().p("ABBDAQgPAAgLg5QgLg3AAhQQAAhPALg4QALg4APAAIEsAAQAPAAALA4QALA4AABPQAABQgLA3QgLA5gPAAg");
	var mask_graphics_43 = new cjs.Graphics().p("AAbDAQgTAAgMg5QgOg3AAhQQAAhPAOg4QAMg4ATAAIF3AAQATAAANA4QAOA4AABPQAABQgOA3QgNA5gTAAg");
	var mask_graphics_44 = new cjs.Graphics().p("Ag3CHQgQg3AAhQQAAhPAQg4QARg4AXAAIHLAAQAXAAARA4QARA4AABPQAABQgRA3QgRA5gXAAInLAAQgXAAgRg5g");
	var mask_graphics_45 = new cjs.Graphics().p("AhtCHQgUg3AAhQQAAhPAUg4QAUg4AcAAIInAAQAcAAAUA4QAUA4AABPQAABQgUA3QgUA5gcAAIonAAQgcAAgUg5g");
	var mask_graphics_46 = new cjs.Graphics().p("AhsDAQghAAgYg5QgXg3AAhQQAAhPAXg4QAYg4AhAAIKEAAQAhAAAXA4QAYA4AABPQAABQgYA3QgXA5ghAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AjaCHQgag3AAhQQAAhPAag4QAbg4AlAAILfAAQAlAAAbA4QAbA4AABPQAABQgbA3QgbA5glAAIrfAAQglAAgbg5g");
	var mask_graphics_48 = new cjs.Graphics().p("AkKCHQgeg3AAhQQAAhPAeg4QAdg4AqAAIMxAAQApAAAeA4QAdA4AABPQAABQgdA3QgeA5gpAAIsxAAQgqAAgdg5g");
	var mask_graphics_49 = new cjs.Graphics().p("AjnDAQguAAggg5Qggg3AAhQQAAhPAgg4QAgg4AuAAIN4AAQAuAAAgA4QAgA4AABPQAABQggA3QggA5guAAg");
	var mask_graphics_50 = new cjs.Graphics().p("AlaCHQgig3AAhQQAAhPAig4QAjg4AwAAIO3AAQAxAAAiA4QAjA4AABPQAABQgjA3QgiA5gxAAIu3AAQgwAAgjg5g");
	var mask_graphics_51 = new cjs.Graphics().p("Al5CHQgkg3AAhQQAAhPAkg4QAlg4AzAAIPrAAQA0AAAkA4QAkA4AABPQAABQgkA3QgkA5g0AAIvrAAQgzAAglg5g");
	var mask_graphics_52 = new cjs.Graphics().p("AmTCHQgmg3AAhQQAAhPAmg4QAmg4A1AAIQYAAQA2AAAlA4QAnA4AABPQAABQgmA3QgmA5g2AAIwYAAQg1AAgmg5g");
	var mask_graphics_53 = new cjs.Graphics().p("AmpCHQgng3AAhQQAAhPAng4QAog4A3AAIQ9AAQA3AAAnA4QAnA4AABPQAABQgnA3QgnA5g3AAIw9AAQg3AAgog5g");
	var mask_graphics_54 = new cjs.Graphics().p("Am7CHQgog3AAhQQAAhPAog4QApg4A5AAIRbAAQA5AAAoA4QAoA4AABPQAABQgoA3QgoA5g5AAIxbAAQg5AAgpg5g");
	var mask_graphics_55 = new cjs.Graphics().p("AnJCHQgpg3AAhQQAAhPApg4QApg4A6AAIR0AAQA6AAApA4QApA4AABPQAABQgpA3QgpA5g6AAIx0AAQg6AAgpg5g");
	var mask_graphics_56 = new cjs.Graphics().p("AnVCHQgpg3AAhQQAAhPApg4QArg4A7AAISGAAQA7AAAqA4QAqA4AABPQAABQgqA3QgqA5g7AAIyGAAQg7AAgrg5g");
	var mask_graphics_57 = new cjs.Graphics().p("AndCHQgqg3AAhQQgBhPArg4QAqg4A8AAISWAAQA8AAAqA4QAqA4AABPQAABQgqA3QgqA5g8AAIyWAAQg8AAgqg5g");
	var mask_graphics_58 = new cjs.Graphics().p("AnkCHQgqg3AAhQQAAhPAqg4QArg4A9AAISgAAQA8AAArA4QArA4AABPQAABQgrA3QgqA5g9AAIygAAQg9AAgrg5g");
	var mask_graphics_59 = new cjs.Graphics().p("AnoCHQgrg3AAhQQAAhPArg4QArg4A9AAISoAAQA9AAAqA4QAsA4AABPQAABQgsA3QgqA5g9AAIyoAAQg9AAgrg5g");
	var mask_graphics_60 = new cjs.Graphics().p("AnrCHQgrg3AAhQQAAhPArg4QAsg4A9AAISsAAQA9AAArA4QArA4AABPQAABQgrA3QgrA5g9AAIysAAQg9AAgsg5g");
	var mask_graphics_61 = new cjs.Graphics().p("AnrCHQgrg3AAhQQAAhPArg4QAsg4A9AAIStAAQA9AAArA4QAsA4AABPQAABQgsA3QgrA5g9AAIytAAQg9AAgsg5g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(36).to({graphics:mask_graphics_36,x:26.8333,y:1.9004}).wait(1).to({graphics:mask_graphics_37,x:27.6885,y:1.8994}).wait(1).to({graphics:mask_graphics_38,x:28.9872,y:1.8977}).wait(1).to({graphics:mask_graphics_39,x:30.803,y:1.8955}).wait(1).to({graphics:mask_graphics_40,x:33.2188,y:1.8924}).wait(1).to({graphics:mask_graphics_41,x:36.3188,y:1.8885}).wait(1).to({graphics:mask_graphics_42,x:40.1696,y:1.8837}).wait(1).to({graphics:mask_graphics_43,x:44.7833,y:1.8779}).wait(1).to({graphics:mask_graphics_44,x:50.0664,y:1.8712}).wait(1).to({graphics:mask_graphics_45,x:55.7844,y:1.864}).wait(1).to({graphics:mask_graphics_46,x:61.5962,y:1.8566}).wait(1).to({graphics:mask_graphics_47,x:67.1597,y:1.8496}).wait(1).to({graphics:mask_graphics_48,x:72.2339,y:1.8431}).wait(1).to({graphics:mask_graphics_49,x:76.7056,y:1.8374}).wait(1).to({graphics:mask_graphics_50,x:80.5579,y:1.8325}).wait(1).to({graphics:mask_graphics_51,x:83.8268,y:1.8284}).wait(1).to({graphics:mask_graphics_52,x:86.5693,y:1.8249}).wait(1).to({graphics:mask_graphics_53,x:88.8464,y:1.822}).wait(1).to({graphics:mask_graphics_54,x:90.7152,y:1.8196}).wait(1).to({graphics:mask_graphics_55,x:92.2262,y:1.8177}).wait(1).to({graphics:mask_graphics_56,x:93.423,y:1.8161}).wait(1).to({graphics:mask_graphics_57,x:94.3426,y:1.8149}).wait(1).to({graphics:mask_graphics_58,x:95.0165,y:1.8141}).wait(1).to({graphics:mask_graphics_59,x:95.4716,y:1.8135}).wait(1).to({graphics:mask_graphics_60,x:95.7306,y:1.8132}).wait(1).to({graphics:mask_graphics_61,x:95.8801,y:1.9004}).wait(1));

	// Layer_3
	this.instance = new lib.highlight();
	this.instance.setTransform(121.65,2,1,1,0,0,0,52.7,2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).wait(26));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgHBFIgDgaIgBgZQAAgKABgBIAQgBQABAAABAKIADAaIABAZQAAALgBAAIgQABIAAAAQgBAAgBgKg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AgNBFIgDgaIgBgZQAAgKABgBIAbgCQABAAACAKIADAaIABAZQAAALgBAAIgbACIAAAAQgBAAgCgKg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AgZBFQgCgLgCgOQgBgPABgLQABgLACAAIAvgDQACgBADALQACAKACAPQABAPgBAKQgBALgCAAIgvAEIAAAAQgCAAgDgKg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AgsBFQgDgLgBgOQgCgPACgLQADgLAEAAIBOgGQAEAAAEAKQADAKABAPQACAPgDAKQgCALgEAAIhOAHIAAAAQgEAAgEgKg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AhGBFQgGgKgBgPQgBgPAEgLQADgLAHAAIB8gJQAGAAAFAJQAGAKABAPQABAOgEALQgDALgHABIh8AJIAAAAQgGAAgFgJg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AhoBFQgHgKgBgPQgBgPAFgLQAGgLAJAAIC1gOQAJAAAIAJQAHAKABAOQABAPgFALQgGALgJABIi1AOIgBAAQgJAAgHgJg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AiKBFQgKgKgBgPQgBgOAIgMQAIgLAMgBIDwgSQAMgBAJAKQAKAJABAPQABAPgIALQgIALgMABIjvATIgDAAQgLAAgIgJg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AipBFQgLgKgBgOQgBgPAJgLQAKgMAPgBIEjgWQAPgBALAKQAMAIABAPQABAPgKALQgJALgPACIkjAXIgDAAQgNAAgLgJg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AjABFQgNgJgBgPQgBgPALgLQALgMARgBIFLgZQARgCANAKQANAKABANQABAPgLALQgLAMgRABIlLAaIgEABQgPAAgLgJg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AjSBFQgOgJgBgPQgBgPAMgLQANgMASgBIFpgcQATgBAOAJQAOAKABANQABAPgMAMQgNALgSACIlpAcIgFAAQgQAAgMgIg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AjfBFQgOgJgBgPQgBgPANgLQANgMATgBIF/geQAUgBAOAJQAPAKABANQABAPgNAMQgNALgTACIl/AeIgFAAQgRAAgNgIg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AjnBFQgPgJgBgPQgCgPAOgLQAOgMAUgBIGNgfQAVgBAPAJQAPAJABAOQACAPgOALQgOAMgUACImNAfIgGAAQgRAAgNgIg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AjtBFQgPgJgBgPQgBgPANgLQAOgMAVgCIGXgfQAVgBAPAJQAQAJABAOQABAPgOAMQgNALgVACImXAgIgGAAQgRAAgOgIg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AjwBFQgPgJgBgPQgCgPAOgLQAPgMAVgCIGcgfQAVgCAPAKQAQAJABAOQACAPgPALQgOAMgVACImcAgIgGAAQgRAAgOgIg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AjxBFQgPgJgBgPQgCgOAOgMQAPgMAVgBIGeggQAVgCAPAKQAQAJABAOQACAPgPALQgOAMgVACImeAgIgGAAQgRAAgOgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-1.2002,y:7.897}).wait(1).to({graphics:mask_1_graphics_1,x:-0.5454,y:7.8921}).wait(1).to({graphics:mask_1_graphics_2,x:0.6822,y:7.883}).wait(1).to({graphics:mask_1_graphics_3,x:2.6469,y:7.8684}).wait(1).to({graphics:mask_1_graphics_4,x:5.4664,y:7.8478}).wait(1).to({graphics:mask_1_graphics_5,x:8.9901,y:7.8225}).wait(1).to({graphics:mask_1_graphics_6,x:12.6479,y:7.7967}).wait(1).to({graphics:mask_1_graphics_7,x:15.8388,y:7.7745}).wait(1).to({graphics:mask_1_graphics_8,x:18.3389,y:7.7574}).wait(1).to({graphics:mask_1_graphics_9,x:20.1949,y:7.7449}).wait(1).to({graphics:mask_1_graphics_10,x:21.5249,y:7.7359}).wait(1).to({graphics:mask_1_graphics_11,x:22.4383,y:7.7298}).wait(1).to({graphics:mask_1_graphics_12,x:23.0206,y:7.726}).wait(1).to({graphics:mask_1_graphics_13,x:23.3359,y:7.7239}).wait(1).to({graphics:mask_1_graphics_14,x:23.4118,y:7.7404}).wait(48));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjfALQCHgdE4AK");
	this.shape.setTransform(24.25,10.3155);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(62));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("AgeBhIgDgZIgBgaQAAgKACAAIAggDQABAAACAKIAEAaIAAAZQAAALgCAAIgfACIAAAAQgCAAgCgKg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AgeBhQgCgKgBgPQgBgPAAgLQABgKACAAIAqgEQADAAACAKQACALACAPQABAOgBALQgBALgCAAIgqADIAAAAQgCAAgDgKg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AgiBhQgDgKgBgPQgCgPACgLQABgKAEAAIA+gFQADgBADALQADAKABAPQACAPgCAKQgBALgEAAIg+AFIAAAAQgDAAgDgKg");
	var mask_2_graphics_15 = new cjs.Graphics().p("Ag1BhQgFgKgBgPQgBgPADgLQACgKAFgBIBfgHQAFgBAEALQAFAKABAPQABAOgDALQgCALgFAAIhfAIIgBAAQgEAAgEgKg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AhRBhQgGgKgBgPQgBgOAEgLQAEgLAIgBICOgLQAHgBAGAKQAGAKABAPQABAPgEALQgEALgIAAIiOAMIAAAAQgHAAgGgKg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AhyBhQgIgKgBgOQgBgPAGgLQAGgLALgBIDGgQQAKgBAIAKQAIAKABAPQABAPgGALQgGALgLABIjGAPIgBAAQgKAAgHgJg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AiSBhQgKgJgBgPQgBgPAIgLQAJgLANgBID8gUQANgBAKAJQAKAKABAPQABAPgIALQgJALgNABIj8AUIgCAAQgMAAgJgJg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AisBhQgLgJgBgPQgBgPAJgLQAKgMAQgBIEogXQAPgBALAJQAMAKABAPQABAPgKALQgJALgQABIkoAYIgDAAQgNAAgLgJg");
	var mask_2_graphics_20 = new cjs.Graphics().p("Ai/BhQgMgJgCgPQgBgPALgLQALgMARgBIFJgaQARgBANAJQAMAKACAPQABAPgLALQgLALgRACIlJAaIgEAAQgPAAgLgJg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AjMBhQgOgJgBgPQgBgPAMgLQAMgMASgBIFggcQASgBANAJQAOAKABAPQABAOgMAMQgMALgSACIlgAbIgEABQgPAAgMgJg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AjWBhQgOgJgBgPQgBgPAMgLQANgMATgBIFwgdQASgCAOAKQAPAJABAPQABAPgNALQgMAMgTABIlwAdIgFABQgPAAgNgJg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AjbBhQgPgJgBgPQgBgPANgLQANgMATgBIF5geQAUgBAOAJQAPAJABAPQABAPgNALQgNAMgTACIl5AdIgGABQgQAAgMgJg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AjfBhQgOgJgBgPQgBgPANgLQANgMATgBIF/geQAUgCAOAJQAPAKABAPQABAOgNAMQgNAMgTABIl/AeIgGABQgQAAgNgJg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AjfBiQgPgKgBgOQgBgPANgMQANgLATgCIGBgeQAUgCAOAKQAPAJABAPQABAPgNALQgNAMgTABImBAfIgFAAQgRAAgMgIg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:-3.5151,y:10.7277}).wait(1).to({graphics:mask_2_graphics_13,x:-3.5023,y:10.7222}).wait(1).to({graphics:mask_2_graphics_14,x:-2.9731,y:10.7118}).wait(1).to({graphics:mask_2_graphics_15,x:-0.9058,y:10.6948}).wait(1).to({graphics:mask_2_graphics_16,x:2.052,y:10.6708}).wait(1).to({graphics:mask_2_graphics_17,x:5.5982,y:10.6425}).wait(1).to({graphics:mask_2_graphics_18,x:9.0145,y:10.6156}).wait(1).to({graphics:mask_2_graphics_19,x:11.7877,y:10.5941}).wait(1).to({graphics:mask_2_graphics_20,x:13.8464,y:10.5783}).wait(1).to({graphics:mask_2_graphics_21,x:15.3052,y:10.5672}).wait(1).to({graphics:mask_2_graphics_22,x:16.2944,y:10.5597}).wait(1).to({graphics:mask_2_graphics_23,x:16.9179,y:10.555}).wait(1).to({graphics:mask_2_graphics_24,x:17.2523,y:10.5525}).wait(1).to({graphics:mask_2_graphics_25,x:17.011,y:10.5816}).wait(37));

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AjAAPQB9gkEEAI");
	this.shape_1.setTransform(19.25,15.8047);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(12).to({_off:false},0).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-13.5,188.9,31.9);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(180.35,119.8,1,1,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(60.6,119.8,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(125.9,172.5,1,1,0,0,0,125.9,52.5);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(125.9,52.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-0.5,-6.6,243.5,243.5), null);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(-40.55,15.05,1,1,0,0,0,125.9,52.6);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-166.9,-44.1,243.5,243.5), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(150.9,226.9,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(150,226.85,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// laptop
	this.laptop = new lib.laptop_1();
	this.laptop.name = "laptop";
	this.laptop.setTransform(153.25,162,0.625,0.625,0,0,0,183.7,127.2);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// highlights
	this.highlights = new lib.IntroTxtHighlights();
	this.highlights.name = "highlights";
	this.highlights.setTransform(190.15,58.05,1,1,0,0,0,93.4,2.4);

	this.timeline.addTween(cjs.Tween.get(this.highlights).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(227.5,191.8,1,1,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,155,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.instance = new lib.bg();
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-72.6,-0.5,374.70000000000005,368.1), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, ease:Power4.easeOut, onComplete:function(){mc.highlights.play();}});
				this.tl1.from(mc.laptop,{duration:.8, scaleX:.5, scaleY:.5, y:"+=150", ease:Power2.easeOut}, "<");
				
				this.tl1.to([exportRoot.intro1, mc.highlights],{duration:0.6, alpha: 0, ease:Power4.easeIn}, ">+2");
		
				//laptop
		
				//chart transition
				this.tl1.to(mc.laptop,{duration:.6, scaleX:.98, scaleY:.98, x:"-=3", y:"+=19", ease:Power2.easeInOut}, ">-.2");
				this.tl1.from(mc.laptop.editorCursor, {duration:.8, x:"+=300", ease:Sine.easeOut}, ">-.4");
				this.tl1.from(mc.laptop.editorCursor, {duration:.8, y:"+=150", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.6, x:"+=18", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.from(mc.laptop.socialScreen.dropdown, {duration:.3, y:"-=30", ease:Sine.easeInOut}, ">-.3");
				this.tl1.to(mc.laptop.editorCursor, {duration:.4, y:"+=18", x:"-=12", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.socialScreen.dropdown, {duration:.1, alpha:0, ease:Sine.easeInOut}, "<");
		
				//Editor Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">-2.2");
		
				//Word Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">+2.2");
		
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=80", y:"+=80", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.from(mc.laptop.wordScreen.sub.dropdown, {duration:.3, y:"-=30", ease:Sine.easeInOut}, ">-.3");
				this.tl1.to(mc.laptop.editorCursor, {duration:.4, y:"+=12", x:"-=4", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.wordScreen.sub.dropdown, {duration:.1, alpha:0, ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.wordScreen.sub.panel, {duration:.2, alpha:0, ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=70", y:"-=110", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=150", ease:Power1.easeIn}, ">+.2");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, y:"+=75", ease:Power1.easeInOut}, "<");
				
				//Word Full Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">-.5");
				//this.
				
				this.tl1.to(mc.laptop.laptop,{duration:1.2, y:"+=250", ease:Power3.easeIn}, ">+.7");
				this.tl1.to(mc.laptop.wordScreen,{duration:.5, y:"+=5", rotation:"+=10", ease:Power1.easeInOut}, "<+.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.7, y:"-=120", ease:Power1.easeInOut}, ">-.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.5, y:"+=84", ease:Power1.easeIn}, ">");
				this.tl1.from(mc.laptop.angledShadow2,{duration:.5, alpha:0, ease:Power1.easeIn}, "<");
				this.tl1.to(mc.laptop.wordScreen,{duration:1.2, scaleX:.345, scaleY:.345, x:"+=150", ease:Power1.easeInOut}, ">-1.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:1, rotation:"-=48", ease:Power1.easeIn}, "<+.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.4, rotation:"+=17", ease:Back.easeOut}, ">");
				
				this.tl1.from(mc.anim,{duration:.6, alpha:0, ease:Power3.easeInOut}, "<-.6");
				this.tl1.from(mc.laptop.wordScreen.sml,{duration:.6, alpha:0, ease:Power3.easeInOut}, "<-.6");
				
				this.tl2 = gsap.timeline();	
				
				this.tl2.from([mc.laptop.socialScreenEnd, mc.laptop.angledShadow1],{duration:.6, x:"+=80", alpha:0, ease:Power2.easeOut});
				this.tl2.from(mc.laptop.socialScreenEnd,{duration:.4, rotation:"+=10", ease:Back.easeOut}, ">-.2");
				this.tl2.from(mc.laptop.editorCursorEnd,{duration:.8, x:"+=90", alpha:0, ease:Power3.easeOut}, "<+.2");
				
				this.tl2.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.6");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl2.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl2.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:Linear.easeNone},">-.7");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(77.4,124.5,224.70000000000002,243.10000000000002);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622805846987", id:"M365_FY22Q1BTS_USA_300x250_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;