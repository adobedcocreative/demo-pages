(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1", frames: [[0,456,294,97],[0,0,343,239],[0,241,256,213],[682,469,166,166],[682,235,275,232],[345,0,335,233],[0,555,113,111],[850,469,103,181],[115,555,113,111],[296,470,103,181],[682,0,335,233],[611,637,113,111],[401,470,103,181],[345,235,335,233],[726,637,113,109],[506,470,103,181]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.angledShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.DesignerInWordPerennialsLargerRatio2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.EditorDesktopsmlx = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.EditorIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.EditorSocialsml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ExcelDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ExcelIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ExcelMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Group242x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.PPTDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.PPTIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.PPTMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdCXQMAAAkufMCY7AAAMAAAEufg");
	this.shape.setTransform(0.975,555.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.4,-412.3,978.8,1936);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707070").s().p("AgaAaQgKgMAAgOQAAgOAKgMQAMgKAOAAQAOAAAMAKQALAMgBAOQABAOgLAMQgMALgOgBQgOABgMgLg");
	this.shape.setTransform(0.05,0.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgZAZQgLgKAAgPQAAgOALgLQALgLAOAAQAPAAAKALQAMALAAAOQAAAPgMAKQgKAMgPAAQgOAAgLgMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.scribble5_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AK3NZQoEhlnPicIABABQvqlPgimUQhKjXBljMQBkjNDXhKQDXhKDNBkQDMBlBLDXQBGgnEQBbIABAAQGPCGG7BXQDfAtB/C8QB/C9gsDfQgsDfi9B/QiNBfifAAQg3AAg5gMg");
	this.shape.setTransform(135.147,86.872);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_2Sub, new cjs.Rectangle(0,0,270.3,173.8), null);


(lib.scribble5_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AtcOEQjigciNizQiNizAbjgQg+n4Q2mUQENhkEwhQIAAAAQEghMC7gYQDhgeC1CLQC2CKAeDhQAeDhiKC1QiLC1jhAfQiGASjQA3Qj5BBjaBRQj0BchBhUQgbDii0CNQiXB2i2AAQgjAAgkgEg");
	this.shape.setTransform(134.6501,90.4499);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_1Sub, new cjs.Rectangle(0,0,269.3,180.9), null);


(lib.scribble4_5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AnOIOQhtgYg9hdQg9hfAYhsQAYhtBdg9IMsoMQBeg9BtAYQBtAXA9BeQA9BegYBtQgYBthdA9IssIMQhEAshLAAQgeAAgegHg");
	this.shape.setTransform(67.688,53.3149);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_5Sub, new cjs.Rectangle(0,0,135.4,106.6), null);


(lib.scribble4_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AJAEUIyFgMQhwgChOhQQhOhQABhuQABhwBQhOQBQhOBwABISFAMQBwACBOBQQBOBQgBBuQgBBwhQBOQhPBNhuAAIgDAAg");
	this.shape.setTransform(84.8992,27.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_4Sub, new cjs.Rectangle(0,0,169.8,55.3), null);


(lib.scribble4_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ApLI0Qhsgdg4hhQg5hhAdhrQAdhsBgg4IQNpdQBhg4BsAdQBsAcA4BhQA4BhgcBsQgdBrhgA5IwNJcQhBAlhFAAQgjAAgkgJg");
	this.shape.setTransform(78.9638,57.3388);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_3Sub, new cjs.Rectangle(0,0,157.9,114.7), null);


(lib.scribble4_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AJuETIzggKQhvgBhPhPQhOhQABhuQAAhwBQhPQBQhOBwAAITgAKQBvABBOBQQBPBPgBBvQgBBvhPBPQhQBOhuAAIgCAAg");
	this.shape.setTransform(89.4245,27.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_2Sub, new cjs.Rectangle(0,0,178.9,55), null);


(lib.scribble4_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArDIHQhngpgthnQgthmAphoQAohoBmgtITCoWQBngtBoApQBnApAuBmQAsBngoBoQgpBnhmAuIzCIWQg2AXg2AAQgxAAgygTg");
	this.shape.setTransform(87.9875,53.8125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_1Sub, new cjs.Rectangle(0,0,176,107.7), null);


(lib.scribble3_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AbTSEQjBghhzigQgaglgigPQgogIg5gDIgDAAIjQgEQl4gKkShnIAAAAQmMiLl/l4IAAAAQmpmfmTg9Qh9gMiPAYQhsARinAjQjBAoikhtQilhsgojAQgojABtilQBsikDAgoQC+goB7gUQEYguD1AcQKxA4K8KuIAAAAQDcDXDeBXIABAAQCSAyDJAFIABAAIDSAEIAKABQCqAGB1AeQFwBRD0FZQBxChghDBQghDBihByQh8BZiRAAQgpAAgsgIg");
	this.shape.setTransform(230.211,116.3692);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3_1Sub, new cjs.Rectangle(0,0,460.5,232.8), null);


(lib.scribble2_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("A6ieNQkLhKiKjxQiJjyBJkKQA9jdA7iGIAAAAQB9kkDOjyIABgBQICp6Q/j3IAAABQDbgzCEhnQBHhKA6h6IABgBIABgCQA9iKAfhBIABgCQBXi1BShoIABgBQEhmRIegyQESgZDWCxQDWCxAaEUQAaETixDWQiXC1jdAvQgcA7g1B3QgEAFgCAIQi9GRkBDdIAAABQlZFGpfCKIgBAAQpHCEkkE3QhMBZgtBqIgBABQgcBFgfBxQhKEKjxCKQidBZioAAQhaAAhdgag");
	this.shape.setTransform(219.3304,195.8844);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2_1Sub, new cjs.Rectangle(0,0,438.7,391.8), null);


(lib.scribble1_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AFcF1QmngwmEhvQh3gjg9hsQg8hsAih3QAih3Btg9QBsg8B4AiQFVBiF1AqQB7APBOBhQBNBigOB6QgPB7hhBNQhTBBhkAAQgSAAgTgCg");
	this.shape.setTransform(68.2062,37.5211);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_2Sub, new cjs.Rectangle(0,0,136.4,75.1), null);


(lib.scribble1_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArRFgQhsg9gih3Qgjh3A9hsQA8hsB3gjQI9ikKKgbQB7gGBcBVQBcBUAFB8QAFB6hUBcQhVBch7AFQpAAYn7CRQgrANgpAAQhKAAhGgng");
	this.shape.setTransform(87.6876,39.0698);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_1Sub, new cjs.Rectangle(0,0,175.4,78.1), null);


(lib.option_hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AhPBRIAAihICfAAIAAAuIAAA6IAAA5g");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-8.1,16,16.2);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.222,21.222,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6132,21.222,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.222,6.6132,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6132,6.6132,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1754,14.0578,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9643,13.9128,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.5018,13.9128,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL7A/XMAAAh+tMCX3AAAMAAAB+tg");
	this.shape.setTransform(486,405.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(0,0,972,811), null);


(lib.img5Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.EditorSocialsml();
	this.instance.setTransform(-9,-159,0.69,0.69);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub3, new cjs.Rectangle(-12.4,-159.8,195.4,165.8), null);


(lib.img5Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorIcon2x();
	this.instance.setTransform(-3.3,-86.2,0.54,0.54);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub2, new cjs.Rectangle(-3.3,-86.2,89.7,142.2), null);


(lib.img5Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.EditorDesktopsmlx();
	this.instance.setTransform(-8,-153,0.6846,0.6846);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub1, new cjs.Rectangle(-10,-155.8,201.1,158.4), null);


(lib.img4Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveDesktop2x();
	this.instance.setTransform(-1.7,-1.15,0.53,0.53);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub3, new cjs.Rectangle(-1.7,-1.1,177.6,123.5), null);


(lib.img4Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveIcon2x();
	this.instance.setTransform(-2.8,-2.7,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub2, new cjs.Rectangle(-2.8,-2.7,62.199999999999996,61.1), null);


(lib.img4Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveMobile2x();
	this.instance.setTransform(-11.3,-19.9,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub1, new cjs.Rectangle(-11.3,-19.9,74.2,130.3), null);


(lib.img3Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelDesktop2x();
	this.instance.setTransform(-1.7,-1.15,0.53,0.53);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub3, new cjs.Rectangle(-1.7,-1.1,177.6,123.5), null);


(lib.img3Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelIcon2x();
	this.instance.setTransform(-2.8,-2.75,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub2, new cjs.Rectangle(-2.8,-2.7,62.199999999999996,61), null);


(lib.img3Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ExcelMobile2x();
	this.instance.setTransform(-11.35,-19.9,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub1, new cjs.Rectangle(-11.3,-19.9,74.1,130.3), null);


(lib.img2Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTDesktop2x();
	this.instance.setTransform(-1.7,-1.15,0.53,0.53);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub3, new cjs.Rectangle(-1.7,-1.1,177.6,123.5), null);


(lib.img2Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTIcon2x();
	this.instance.setTransform(-2.8,-2.7,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub2, new cjs.Rectangle(-2.8,-2.7,62.199999999999996,60), null);


(lib.img2Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTMobile2x();
	this.instance.setTransform(-11.35,-19.9,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub1, new cjs.Rectangle(-11.3,-19.9,74.1,130.3), null);


(lib.img1Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.DesignerInWordPerennialsLargerRatio2x();
	this.instance.setTransform(-0.05,-0.1,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub3, new cjs.Rectangle(0,-0.1,172,120.1), null);


(lib.img1Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group242x();
	this.instance.setTransform(-2.8,-2.75,0.55,0.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub2, new cjs.Rectangle(-2.8,-2.7,62.199999999999996,61), null);


(lib.img1Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group332x();
	this.instance.setTransform(-11.35,-19.9,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub1, new cjs.Rectangle(-11.3,-19.9,74.1,130.3), null);


(lib.gridSubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Az/AAMAn/AAA");
	this.shape.setTransform(128,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridSubSub, new cjs.Rectangle(-1,-1,258,2), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.doodle5_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AggBEQgEgCgCgEIgyhtQgDgGADgGQACgGAGgCQAFgDAGACQAGACADAGIAqBdIBVg7QAFgEAGACQAGABAEAFQADAFgBAGQgBAGgFAEIhkBFQgDACgFAAQgEAAgEgCg");
	this.shape.setTransform(9.0293,6.9932);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_3Sub, new cjs.Rectangle(0,0,18.1,14), null);


(lib.doodle5_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhJBLQgGgCgCgFQgDgGACgGQAdhLA9gjQAUgMAVgFIABAAQAKgEAIAAQAGgBAFAEQAEAEABAHQAAAGgEAFQgEAEgGABIgMADIgBAAQgRAEgRAKQg0AdgZBCQgCAFgFADIgGABIgGgBg");
	this.shape.setTransform(8.371,7.6347);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_2Sub, new cjs.Rectangle(0,0,16.8,15.3), null);


(lib.doodle5_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah6CMQgHgCgDgFQgEgFACgGQAdifByhDQA6giA1gBQAGAAAFAEQAEAEAAAGQAAAGgEAFQgEAFgGAAQguABgzAeQhmA9gbCRQgBAGgFADQgEADgEAAIgDAAg");
	this.shape.setTransform(13.5545,14.0111);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_1Sub, new cjs.Rectangle(0,0,27.1,28), null);


(lib.doodle4_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AktAKQgGAAgFgCQgEgEAAgEQAAgDAEgEQAFgDAGAAIJbAAQAGAAAFADQAEAEAAADQAAAEgEAEQgFACgGAAg");
	this.shape.setTransform(31.725,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_4Sub, new cjs.Rectangle(0,0.5,63.5,2.1), null);


(lib.doodle4_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjqAKQgGAAgEgCQgFgEAAgEQAAgDAFgEQAEgDAGAAIHVAAQAGAAAEADQAFAEAAADQAAAEgFAEQgEACgGAAg");
	this.shape.setTransform(24.975,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_3Sub, new cjs.Rectangle(0,0.5,50,2.1), null);


(lib.doodle4_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AisAKQgHAAgEgCQgEgEgBgEQABgDAEgEQAEgDAHAAIFZAAQAHAAAEADQAEAEABADQgBAEgEAEQgEACgHAAg");
	this.shape.setTransform(18.85,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_2Sub, new cjs.Rectangle(0,0.5,37.7,2.1), null);


(lib.doodle4_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhWALQgGAAgFgEQgEgDAAgEQAAgDAEgDQAFgDAGgBICtAAQAGABAFADQAEADAAADQAAAEgEADQgFAEgGAAg");
	this.shape.setTransform(10.225,1.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_1Sub, new cjs.Rectangle(0,0.4,20.5,2.1), null);


(lib.doodle3_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAsB5QgDgBgBgDQgBgDABgDQABgDADgBIAogSIgTgIIAAABIgcgKQgDgBgCgCQgBgDABgDQAAgDADgBQAkgYASgOIgaADIgnAFQgCAAgDgBQgCgCgBgCQgBgDABgDIAbg/Ig1AuIgFACQgDAAgCgCQgDgCAAgCIgBhNIgjBLQgBADgDABQgDABgDgBQgDgBgBgDIgYg+QgDAPgBAWIgCApQAAADgCACQgCACgDAAQgEAAgCgCQgCgDAAgDIACgoIAAgBQADguAHgRQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIADAEIAbBEIAphaQABAAAAgBQAAAAABgBQAAAAABgBQAAAAAAAAQADgCACABQADABACACQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIACBdIBCg6QACgCADAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIADAEQABACgBADIgjBRIAagDIAxgFQADAAADACQACABAAADQABADgCADQgIALg1AkIAOAEQAfAMAFADIADAEIgBAGIgEADIg2AaIgDAAIgDAAg");
	this.shape.setTransform(11.855,12.13);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_1Sub, new cjs.Rectangle(0,0,23.7,24.3), null);


(lib.doodle2_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgeCmQgDgBgBgDIgnhoQgBgDABgDQABgDADgBQADgBADABQADABABADIAnBpQABACgBADQgBADgDABIgDABIgDgBgAiPCWQgDAAgCgCQgCgDAAgDIAGhCQAAgDADgCQACgCADAAQADABACACQACACAAAEIgGBCQAAADgCACQgBAAAAAAQgBABAAAAQgBAAAAAAQgBAAgBAAIgBAAgAB5CDIiGhxQgDgCAAgDQgBgDADgCQABgDAEAAQADgBACADICHBxQACABAAAEQABADgCACQgCACgDABIgCAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBgBgACNgVIhwgeQgDgBgBgCQgCgDABgDQABgDADgCQACgBADABIBwAdQADABACADQABACAAADQgBADgDACIgEABIgCAAgAAWh2QgDgBgCgDQgBgDABgDQABgDADgBIBMghQADgBADABQADABABADQABADgBADQgBACgDACIhMAhIgDAAIgCAAg");
	this.shape.setTransform(15.0771,16.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle2_1Sub, new cjs.Rectangle(0,0,30.2,33.4), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.angledShadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.angledShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.angledShadow_1, new cjs.Rectangle(0,0,294,97), null);


(lib.scribble5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,271,174,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble5_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(135.2,86.9,1,1,0,0,0,135.2,86.9);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_2, new cjs.Rectangle(0,0,270.3,173.8), null);


(lib.scribble5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,270,181,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble5_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(134.7,90.5,1,1,0,0,0,134.7,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_1, new cjs.Rectangle(0,0,269.3,180.9), null);


(lib.scribble5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,out:30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_11 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_12 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_13 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_14 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_15 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_16 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_17 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_18 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_19 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_20 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_21 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_22 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_23 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_24 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_25 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_26 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_27 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_28 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_29 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_30 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_31 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_32 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_33 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_34 = new cjs.Graphics().p("AfkUaMhFHgVwQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB+QiLBViQAAQhOAAhQgag");
	var mask_graphics_35 = new cjs.Graphics().p("AfkUjMhFHgVxQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB/QiLBUiQAAQhOAAhQgZg");
	var mask_graphics_36 = new cjs.Graphics().p("AfkVGMhFHgVxQjihHhojnQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFHAVxQDiBHBnDjQBoDnhPD8QhQD8jZB/QiLBUiQAAQhOAAhQgZg");
	var mask_graphics_37 = new cjs.Graphics().p("AfxVpMhFIgVxQjhhHhojmQhnjkBPj8QBQj8DXiCQDZh/DhBIMBFIAVwQDhBHBnDjQBoDnhPD8QhPD8jZB/QiMBUiPAAQhPAAhPgZg");
	var mask_graphics_38 = new cjs.Graphics().p("EAhgAWMMhFHgVyQjhhGhpjmQhnjkBQj8QBPj8DXiCQDZh+DiBHMBFHAVwQDiBHBnDjQBoDnhPD8QhQD8jZB/QiLBUiQAAQhOAAhQgZg");
	var mask_graphics_39 = new cjs.Graphics().p("EAjQAWvMhFHgVxQjihGhojnQhnjkBPj8QBQj8DXiCQDZh+DiBHMBFHAVwQDhBHBnDkQBpDmhQD8QhPD9jZB+QiLBUiQAAQhOAAhQgZg");
	var mask_graphics_40 = new cjs.Graphics().p("EAlAAXSMhFIgVxQjhhHhpjmQhmjjBPj9QBPj8DYiCQDZh+DhBHMBFIAVwQDhBHBnDkQBoDmhPD8QhQD9jYB+QiMBUiPAAQhPAAhPgZg");
	var mask_graphics_41 = new cjs.Graphics().p("EAmvAX1MhFHgVxQjihHhojmQhnjjBQj8QBPj9DXiCQDZh+DiBHMBFHAVwQDiBHBmDkQBpDnhQD8QhPD8jZB+QiLBUiQAAQhOAAhQgZg");
	var mask_graphics_42 = new cjs.Graphics().p("EAnBAX7MhFJgVvQjhhHhpjmQhnjjBQj8QBPj8DXiCQDZh/DiBHMBFIAVuQDhBHBnDkQBpDmhPD8QhQD9jZB+QiLBUiQAAQhOABhPgag");
	var mask_graphics_43 = new cjs.Graphics().p("EAnkAYIMhFJgVrQjihGhpjmQhnjjBPj8QBPj8DXiDQDZh/DiBHMBFJAVqQDiBHBnDjQBpDmhPD9QhPD8jZB/QiLBUiQAAQhOAAhQgZg");
	var mask_graphics_44 = new cjs.Graphics().p("EAofAYdMhFMgVjQjihGhpjmQhojjBPj8QBPj9DXiCQDYiADiBHMBFMAViQDhBHBoDjQBpDmhPD8QhOD9jZB/QiLBViRAAQhNAAhPgZg");
	var mask_graphics_45 = new cjs.Graphics().p("EAp1AY8MhFPgVYQjihGhqjlQhojjBOj8QBOj9DWiDQDZiADiBGMBFPAVXQDiBGBoDjQBpDmhOD9QhOD8jYCAQiMBWiRAAQhNAAhOgZg");
	var mask_graphics_46 = new cjs.Graphics().p("EArrAZnMhFUgVKQjihFhrjlQhpjiBOj9QBNj9DWiEQDYiADiBFMBFUAVJQDiBFBpDiQBqDmhND9QhND8jYCBQiNBXiRAAQhNAAhNgYg");
	var mask_graphics_47 = new cjs.Graphics().p("EAuBAadMhFagU3QjihEhsjlQhqjhBMj9QBNj+DViFQDXiBDjBEMBFZAU2QDjBEBqDiQBrDlhMD9QhMD+jXCBQiOBYiTAAQhLAAhMgXg");
	var mask_graphics_48 = new cjs.Graphics().p("EAwtAbbMhFggUhQjjhDhsjlQhrjgBLj+QBKj9DViGQDXiDDjBDMBFgAUgQDjBDBqDiQBtDkhLD+QhLD9jWCDQiOBZiUAAQhKAAhMgWg");
	var mask_graphics_49 = new cjs.Graphics().p("EAzdAcaMhFmgUKQjjhChujlQhsjgBJj9QBKj+DUiHQDWiEDjBCMBFnAUKQDjBCBsDgQBuDlhKD+QhKD9jVCEQiPBbiWAAQhIAAhLgWg");
	var mask_graphics_50 = new cjs.Graphics().p("EA1+AdUMhFsgT2QjkhBhvjkQhtjgBJj9QBIj+DUiIQDViFDkBBMBFsAT1QDjBBBtDgQBvDkhID+QhJD+jVCFQiPBciXAAQhIAAhJgVg");
	var mask_graphics_51 = new cjs.Graphics().p("EA4GAeFMhFxgTlQjkhAhwjjQhujgBIj+QBHj+DTiJQDViFDkBAMBFxATkQDkA/BuDgQBvDkhHD+QhID/jUCFQiQBdiYAAQhHAAhIgUg");
	var mask_graphics_52 = new cjs.Graphics().p("EA5zAesMhF1gTXQjkg/hwjjQhvjgBHj9QBGj/DTiJQDUiGDkA/MBF1ATWQDkA/BvDgQBwDjhGD+QhHD/jUCGQiRBeiYAAQhGAAhIgUg");
	var mask_graphics_53 = new cjs.Graphics().p("EA7JAfLMhF4gTMQjkg/hxjjQhwjfBGj+QBGj/DTiKQDUiGDkA/MBF4ATLQDkA+BvDgQBxDihGD/QhGD/jUCHQiRBfiZAAQhFAAhHgUg");
	var mask_graphics_54 = new cjs.Graphics().p("EA8KAfjMhF6gTEQjlg/hxjiQhvjfBFj/QBGj+DSiLQDUiGDkA+MBF6ATDQDkA+BwDfQBxDihFD/QhGD/jUCHQiRBgiZAAQhFAAhHgTg");
	var mask_graphics_55 = new cjs.Graphics().p("EA86Af0MhF8gS+Qjkg+hyjiQhvjfBFj/QBFj+DSiLQDTiHDlA+MBF8AS9QDkA9BwDfQByDjhGD/QhFD/jTCHQiSBgiZAAQhFAAhHgTg");
	var mask_graphics_56 = new cjs.Graphics().p("EA9dAgAMhF9gS5Qjlg+hyjiQhwjfBFj/QBFj+DSiLQDTiHDlA9MBF9AS5QDkA9BwDfQByDihFEAQhFD/jTCHQiRBgibAAQhEAAhGgTg");
	var mask_graphics_57 = new cjs.Graphics().p("EA9zAgIMhF+gS2Qjkg+hyjiQhwjfBEj/QBFj+DSiLQDTiHDlA9MBF+AS2QDkA9BwDfQByDihED/QhFD/jUCIQiRBgiaAAQhFAAhGgTg");
	var mask_graphics_58 = new cjs.Graphics().p("EA+AAgNMhF/gS1Qjkg9hyjjQhwjeBEj/QBFj/DRiLQDUiHDkA9MBF/AS0QDkA9BwDfQBzDihFD/QhFEAjTCHQiSBhiaAAQhEAAhGgTg");
	var mask_graphics_59 = new cjs.Graphics().p("EA+FAgPMhF/gS1Qjkg9hyjiQhwjfBEj/QBFj+DRiMQDUiHDkA9MBF/AS0QDkA9BwDfQBzDihFD/QhFD/jTCIQiRBgibAAQhEAAhGgSg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_graphics_11,x:-171.3387,y:5.6188}).wait(1).to({graphics:mask_graphics_12,x:-168.1547,y:6.6293}).wait(1).to({graphics:mask_graphics_13,x:-161.5851,y:8.7142}).wait(1).to({graphics:mask_graphics_14,x:-150.8328,y:12.1265}).wait(1).to({graphics:mask_graphics_15,x:-134.9848,y:17.156}).wait(1).to({graphics:mask_graphics_16,x:-113.2561,y:24.0518}).wait(1).to({graphics:mask_graphics_17,x:-85.6439,y:32.8147}).wait(1).to({graphics:mask_graphics_18,x:-53.8758,y:42.8966}).wait(1).to({graphics:mask_graphics_19,x:-21.4422,y:53.1896}).wait(1).to({graphics:mask_graphics_20,x:8.1883,y:62.5931}).wait(1).to({graphics:mask_graphics_21,x:33.2087,y:70.5335}).wait(1).to({graphics:mask_graphics_22,x:53.3647,y:76.9302}).wait(1).to({graphics:mask_graphics_23,x:69.1344,y:81.9348}).wait(1).to({graphics:mask_graphics_24,x:81.1758,y:85.7562}).wait(1).to({graphics:mask_graphics_25,x:90.1049,y:88.59}).wait(1).to({graphics:mask_graphics_26,x:96.4372,y:90.5996}).wait(1).to({graphics:mask_graphics_27,x:100.5883,y:91.917}).wait(1).to({graphics:mask_graphics_28,x:102.8898,y:92.6473}).wait(1).to({graphics:mask_graphics_29,x:103.1113,y:92.7188}).wait(1).to({graphics:mask_graphics_30,x:125.4321,y:99.7355}).wait(1).to({graphics:mask_graphics_31,x:147.7529,y:106.7521}).wait(1).to({graphics:mask_graphics_32,x:170.0738,y:113.7688}).wait(1).to({graphics:mask_graphics_33,x:192.3946,y:120.7855}).wait(1).to({graphics:mask_graphics_34,x:214.7154,y:127.8021}).wait(1).to({graphics:mask_graphics_35,x:237.0363,y:133.9848}).wait(1).to({graphics:mask_graphics_36,x:259.3571,y:137.4932}).wait(1).to({graphics:mask_graphics_37,x:280.4349,y:141.0015}).wait(1).to({graphics:mask_graphics_38,x:291.5953,y:144.5099}).wait(1).to({graphics:mask_graphics_39,x:302.7557,y:148.0182}).wait(1).to({graphics:mask_graphics_40,x:313.9162,y:151.5265}).wait(1).to({graphics:mask_graphics_41,x:325.0764,y:155.0347}).wait(1).to({graphics:mask_graphics_42,x:326.7739,y:155.6499}).wait(1).to({graphics:mask_graphics_43,x:330.2759,y:156.9189}).wait(1).to({graphics:mask_graphics_44,x:336.0073,y:158.9958}).wait(1).to({graphics:mask_graphics_45,x:344.4544,y:162.0567}).wait(1).to({graphics:mask_graphics_46,x:356.0349,y:166.253}).wait(1).to({graphics:mask_graphics_47,x:370.7494,y:171.585}).wait(1).to({graphics:mask_graphics_48,x:387.676,y:177.7185}).wait(1).to({graphics:mask_graphics_49,x:404.9546,y:183.9796}).wait(1).to({graphics:mask_graphics_50,x:420.7375,y:189.6987}).wait(1).to({graphics:mask_graphics_51,x:434.063,y:194.5273}).wait(1).to({graphics:mask_graphics_52,x:444.7967,y:198.4168}).wait(1).to({graphics:mask_graphics_53,x:453.1938,y:201.4596}).wait(1).to({graphics:mask_graphics_54,x:459.6052,y:203.7829}).wait(1).to({graphics:mask_graphics_55,x:464.3592,y:205.5056}).wait(1).to({graphics:mask_graphics_56,x:467.7306,y:206.7273}).wait(1).to({graphics:mask_graphics_57,x:469.9406,y:207.5281}).wait(1).to({graphics:mask_graphics_58,x:471.1658,y:207.9721}).wait(1).to({graphics:mask_graphics_59,x:471.6716,y:208.1436}).wait(1));

	// Layer_5
	this.instance = new lib.scribble5_2();
	this.instance.setTransform(243.35,130.05,1,1,-4.3046,0,0,135.2,86.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).wait(49));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AonVqQjdhzhej3Qhdj4BYjrQBcjqDehTMBDxgZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AorVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_2 = new cjs.Graphics().p("Ao6VqQjdhzhej3Qhdj4BYjrQBcjqDehTMBDxgZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_3 = new cjs.Graphics().p("ApVVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDygZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiBAAiDhEg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AqAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDygZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiBAAiDhEg");
	var mask_1_graphics_5 = new cjs.Graphics().p("ArAVqQjdhzhej3Qhdj4BZjrQBcjqDdhTMBDxgZqQDdhTDeBzQDhB0BdD4QBeD3hdDpQhYDsjdBUMhDyAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AsZVqQjdhzhej3Qhdj4BYjrQBcjqDehTMBDxgZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhYDsjeBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AuRVqQjdhzhej3Qhdj3BYjsQBcjqDehTMBDxgZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AwnVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiBAAiDhEg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AzPVqQjdhzhej3Qhdj4BYjrQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBeD3hdDpQhYDsjdBUMhDyAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A1wVqQjdhzhej3Qhdj4BYjrQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBeD3hdDpQhYDsjdBUMhDyAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A35VqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiBAAiDhEg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A5oVqQjdhzhej3Qhdj4BZjrQBcjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBeD3hdDpQhYDsjdBUMhDyAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A6+VqQjdhzhej3Qhdj4BYjrQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBeD3hdDpQhYDsjdBUMhDyAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A8AVqQjdhzhej3Qhdj3BYjsQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBeD3hdDpQhYDsjeBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A8yVqQjdhzhej3Qhdj4BYjrQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBdD3hcDpQhYDsjeBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A9WVqQjdhzhej3Qhdj4BYjrQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBeD3hdDpQhYDsjeBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A+4VqQjehzhdj3Qhej3BZjsQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDyAZpQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EggbAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDygZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiBAAiDhEg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Egh+AVqQjdhzhej3Qhdj4BYjrQBdjqDdhTMBDxgZqQDdhTDeBzQDgB0BeD4QBdD3hcDpQhYDsjeBUMhDxAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EgjhAVqQjdhzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDdhTDeBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDyAZpQhcAjhdAAQiCAAiDhEg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EglDAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDygZqQDdhTDdBzQDhB0BeD4QBdD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiBAAiDhEg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej3BZjsQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDyAZpQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej3BZjsQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDyAZpQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EglTAVqQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBUMhDyAZpQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EglTAWVQjehzhdj3Qhej3BZjsQBcjpDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDrjdBUMhDyAZpQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EglTAXTQjehzhdj3Qhej3BZjsQBcjpDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDrjdBUMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EglTAYQQjehzhdj3Qhej4BZjrQBcjqDdhTMBDxgZqQDehTDdBzQDhB0BdD4QBeD3hcDpQhZDsjdBTMhDxAZqQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EglTAZFQjehzhdj3Qhej3BZjrQBcjqDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDsjdBTMhDxAZpQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EglTAZyQjehzhdj3Qhej3BZjsQBcjpDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDrjdBTMhDxAZqQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EglTAaWQjehzhdj3Qhej3BZjrQBcjqDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDrjdBTMhDxAZqQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EglTAazQjehzhdj3Qhej3BZjsQBcjpDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDqjdBUMhDyAZqQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EglTAbKQjehzhdj3Qhej3BZjsQBcjpDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDqjdBUMhDxAZqQhdAjhdAAQiCAAiChEg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EglTAbcQjehzhdj4Qhej3BZjrQBcjqDdhUMBDxgZpQDehTDdByQDhB1BdD3QBeD4hcDpQhZDrjdBTMhDyAZrQhcAjhdAAQiCAAiChEg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EglTAbpQjehzhdj3Qhej3BZjsQBcjpDdhUMBDxgZpQDehUDdBzQDhB1BdD3QBeD3hcDqQhZDqjdBUMhDxAZqQhdAjhdAAQiCAAiChEg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:458.7849,y:-85.6115}).wait(1).to({graphics:mask_1_graphics_1,x:458.3451,y:-85.2783}).wait(1).to({graphics:mask_1_graphics_2,x:456.8902,y:-84.1795}).wait(1).to({graphics:mask_1_graphics_3,x:454.1745,y:-82.1285}).wait(1).to({graphics:mask_1_graphics_4,x:449.8655,y:-78.8742}).wait(1).to({graphics:mask_1_graphics_5,x:443.5212,y:-74.0828}).wait(1).to({graphics:mask_1_graphics_6,x:434.5975,y:-67.3434}).wait(1).to({graphics:mask_1_graphics_7,x:422.5931,y:-58.2773}).wait(1).to({graphics:mask_1_graphics_8,x:407.5515,y:-46.9174}).wait(1).to({graphics:mask_1_graphics_9,x:390.8127,y:-34.2758}).wait(1).to({graphics:mask_1_graphics_10,x:374.7167,y:-22.1196}).wait(1).to({graphics:mask_1_graphics_11,x:360.9533,y:-11.725}).wait(1).to({graphics:mask_1_graphics_12,x:349.9175,y:-3.3904}).wait(1).to({graphics:mask_1_graphics_13,x:341.3167,y:3.1051}).wait(1).to({graphics:mask_1_graphics_14,x:334.7103,y:8.0945}).wait(1).to({graphics:mask_1_graphics_15,x:329.7048,y:11.8748}).wait(1).to({graphics:mask_1_graphics_16,x:326.1099,y:14.5885}).wait(1).to({graphics:mask_1_graphics_17,x:316.2421,y:22.027}).wait(1).to({graphics:mask_1_graphics_18,x:306.3728,y:29.4654}).wait(1).to({graphics:mask_1_graphics_19,x:296.5036,y:36.9039}).wait(1).to({graphics:mask_1_graphics_20,x:286.6344,y:44.3423}).wait(1).to({graphics:mask_1_graphics_21,x:276.7651,y:51.7808}).wait(1).to({graphics:mask_1_graphics_22,x:258.6494,y:59.2193}).wait(1).to({graphics:mask_1_graphics_23,x:238.9109,y:66.6577}).wait(1).to({graphics:mask_1_graphics_24,x:219.1724,y:74.0962}).wait(1).to({graphics:mask_1_graphics_25,x:199.434,y:81.5347}).wait(1).to({graphics:mask_1_graphics_26,x:179.6955,y:88.9731}).wait(1).to({graphics:mask_1_graphics_27,x:159.9571,y:96.4116}).wait(1).to({graphics:mask_1_graphics_28,x:140.2186,y:103.85}).wait(1).to({graphics:mask_1_graphics_29,x:120.4802,y:111.2885}).wait(1).to({graphics:mask_1_graphics_30,x:119.7228,y:111.577}).wait(1).to({graphics:mask_1_graphics_31,x:117.2535,y:112.5175}).wait(1).to({graphics:mask_1_graphics_32,x:112.712,y:114.2475}).wait(1).to({graphics:mask_1_graphics_33,x:105.6282,y:116.9458}).wait(1).to({graphics:mask_1_graphics_34,x:95.392,y:120.8449}).wait(1).to({graphics:mask_1_graphics_35,x:81.2351,y:126.2374}).wait(1).to({graphics:mask_1_graphics_36,x:62.2894,y:133.454}).wait(1).to({graphics:mask_1_graphics_37,x:37.8823,y:142.751}).wait(1).to({graphics:mask_1_graphics_38,x:8.3047,y:149.6988}).wait(1).to({graphics:mask_1_graphics_39,x:-24.2464,y:155.8984}).wait(1).to({graphics:mask_1_graphics_40,x:-56.1135,y:161.9676}).wait(1).to({graphics:mask_1_graphics_41,x:-84.3426,y:167.344}).wait(1).to({graphics:mask_1_graphics_42,x:-107.8555,y:171.8222}).wait(1).to({graphics:mask_1_graphics_43,x:-126.8517,y:175.4401}).wait(1).to({graphics:mask_1_graphics_44,x:-141.9729,y:178.3201}).wait(1).to({graphics:mask_1_graphics_45,x:-153.8884,y:180.5894}).wait(1).to({graphics:mask_1_graphics_46,x:-163.1687,y:182.3569}).wait(1).to({graphics:mask_1_graphics_47,x:-170.2698,y:183.7087}).wait(13));

	// Layer_2
	this.instance_1 = new lib.scribble5_1();
	this.instance_1.setTransform(247.45,70.05,1,1,2.4338,0,0,134.7,90.4);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-25.9,385.8,275.9);


(lib.scribble4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,136,107,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_5Sub();
	this.sub.name = "sub";
	this.sub.setTransform(67.7,53.3,1,1,0,0,0,67.7,53.3);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_5, new cjs.Rectangle(0,0,135.4,106.6), null);


(lib.scribble4_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,170,56,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(84.9,27.6,1,1,0,0,0,84.9,27.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_4, new cjs.Rectangle(0,0,169.8,55.3), null);


(lib.scribble4_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,158,115,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(79,57.3,1,1,0,0,0,79,57.3);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_3, new cjs.Rectangle(0,0,157.9,114.7), null);


(lib.scribble4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,180,55,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(89.4,27.4,1,1,0,0,0,89.4,27.4);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_2, new cjs.Rectangle(0,0,178.9,55), null);


(lib.scribble4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,178,108,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(88,53.8,1,1,0,0,0,88,53.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_1, new cjs.Rectangle(0,0,176,107.7), null);


(lib.scribble4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("AJ5NxQhqgdg/hhQg/hgARhsQAPhsBWg4IaMxBQBWg4BqAdQBoAdA/BhQA/BggPBsQgRBshWA4I6MRBQg5AlhAAAQgiAAgjgKg");
	var mask_graphics_22 = new cjs.Graphics().p("AJcOEQhqgeg/hgQg+hhAQhsQAQhsBVg3IaNxCQBVg3BqAdQBpAdA+BgQA/BhgPBsQgRBshVA3I6NRCQg4AkhBAAQghAAgkgJg");
	var mask_graphics_23 = new cjs.Graphics().p("AIKO5Qhqgdg/hhQg+hhAQhrQAQhsBVg4IaNxBQBVg4BqAdQBpAdA+BhQA/BggPBsQgRBshVA4I6NRBQg4AlhBAAQghAAgkgKg");
	var mask_graphics_24 = new cjs.Graphics().p("AF1QaQhqgdg/hhQg/hgARhsQAPhsBWg4IaMxBQBWg4BqAdQBoAdA/BhQA/BggQBtQgRBrhVA4I6NRBQg4AlhAAAQgiAAgjgKg");
	var mask_graphics_25 = new cjs.Graphics().p("ADNSHQhqgeg+hgQg+hhARhrQAOhtBVg3IaNxCQBWg3BpAdQBpAdA/BgQA+BhgPBsQgRBshVA2I6NRDQg4AlhBAAQghAAgkgKg");
	var mask_graphics_26 = new cjs.Graphics().p("ABYTTQhpgdg/hhQg/hgARhsQAPhsBWg4IaLxBQBWg4BqAeQBoAcA/BhQA/BhgQBsQgRBqhVA4I6NRCQg4AlhAAAQgiAAgjgKg");
	var mask_graphics_27 = new cjs.Graphics().p("AAUT/Qhpgdg/hhQg+hgAQhsQAQhsBVg4IaMxBQBVg4BqAdQBpAdA+BhQA/BggPBsQgRBrhVA4I6NRCQg4AlhBAAQghAAgkgKg");
	var mask_graphics_28 = new cjs.Graphics().p("AgMUUQhpgdg/hhQg/hgARhsQAPhsBVg4IaMxBQBWg4BqAeQBoAcA/BhQA/BhgQBrQgRBrhVA4I6NRDQg4AkhAAAQgiAAgjgKg");
	var mask_graphics_29 = new cjs.Graphics().p("AgVUaQhqgdg/hhQg+hgARhsQAPhsBVg4IaMxBQBVg4BqAeQBpAcA+BhQA/BhgPBrQgRBrhVA4I6NRCQg4AlhBAAQghAAgjgKg");
	var mask_graphics_30 = new cjs.Graphics().p("AgoUnQhqgdg/hhQg/hgARhsQAPhsBWg4IaMxBQBVg4BqAdQBoAdA/BhQA/BggPBrQgRBshWA4I6MRCQg5AlhAAAQggAAgkgKg");
	var mask_graphics_31 = new cjs.Graphics().p("Ag7U0Qhqgeg/hgQg/hhARhrQAPhsBWg4IaLxCQBWg3BqAdQBoAdA/BhQA/BggQBrQgQBshWA3I6NRDQg4AlhAAAQghAAgjgKg");
	var mask_graphics_32 = new cjs.Graphics().p("AhPVBQhqgeg+hgQg/hhARhsQAPhsBVg3IaMxCQBVg3BqAdQBpAdA/BgQA+BhgPBrQgRBshVA3I6NRDQg4AkhAAAQghAAgkgJg");
	var mask_graphics_33 = new cjs.Graphics().p("AhiVNQhqgdg/hhQg/hgARhsQAQhsBVg4IaMxBQBVg4BqAeQBoAcA/BhQA/BhgPBrQgRBrhWA4I6MRCQg4AlhAAAQghAAgkgKg");
	var mask_graphics_34 = new cjs.Graphics().p("Ah1VaQhqgdg/hhQg/hgARhsQAPhsBWg4IaLxBQBWg4BqAdQBoAdA/BhQA/BggQBrQgQBshWA4I6NRCQg4Alg/AAQgiAAgjgKg");
	var mask_graphics_35 = new cjs.Graphics().p("AiJVnQhqgeg+hgQg/hhARhrQAPhsBVg4IaMxCQBWg3BpAdQBpAdA/BhQA+BggPBrQgRBshVA3I6NRDQg3AlhBAAQghAAgkgKg");
	var mask_graphics_36 = new cjs.Graphics().p("AicVzQhqgdg/hgQg/hhARhsQAQhsBVg3IaMxCQBVg3BqAdQBoAdA/BgQA/BggPBsQgRBshVA3I6NRDQg3AkhBAAQghAAgkgKg");
	var mask_graphics_37 = new cjs.Graphics().p("AivWAQhqgdg/hhQg/hgARhsQAPhsBWg4IaLxBQBWg4BqAeQBoAcA/BhQA/BggPBsQgRBrhWA4I6MRCQg4AlhAAAQgiAAgjgKg");
	var mask_graphics_38 = new cjs.Graphics().p("AjDWNQhpgdg/hhQg/hgARhsQAPhsBVg4IaMxBQBWg4BqAdQBoAdA/BhQA+BfgPBsQgRBshVA4I6MRCQg4AlhBAAQghAAgkgKg");
	var mask_graphics_39 = new cjs.Graphics().p("AjWWaQhqgeg/hgQg+hhAQhrQAQhsBVg4IaMxCQBVg3BqAdQBpAdA+BhQA/BfgPBsQgRBshVA3I6MRDQg4AlhBAAQghAAgkgKg");
	var mask_graphics_40 = new cjs.Graphics().p("AjpWmQhqgdg/hgQg/hhARhsQAPhsBWg3IaMxCQBVg3BqAdQBoAdA/BgQA/BggPBsQgRBshWA3I6LRDQg5AkhAAAQgiAAgjgKg");
	var mask_graphics_41 = new cjs.Graphics().p("Aj8WzQhqgdg/hhQg/hgARhsQAPhsBWg4IaLxBQBWg4BqAeQBoAcA/BhQA/BggQBsQgRBrhVA4I6MRCQg4AlhAAAQgiAAgjgKg");
	var mask_graphics_42 = new cjs.Graphics().p("AkQXAQhqgdg/hhQg+hgAQhsQAQhsBVg4IaMxBQBVg4BqAdQBpAdA+BhQA/BfgPBsQgRBshVA4I6MRCQg4AlhBAAQghAAgkgKg");
	var mask_graphics_43 = new cjs.Graphics().p("AkjXNQhqgeg/hgQg/hhARhrQAPhsBWg4IaMxCQBVg3BqAdQBoAdA/BgQA/BggPBsQgRBshWA3I6LRDQg5AlhAAAQghAAgkgKg");
	var mask_graphics_44 = new cjs.Graphics().p("Ak2XaQhqgeg/hgQg/hhARhsQAPhsBWg3IaLxCQBWg3BqAdQBoAdA/BfQA/BhgQBsQgRBshVA3I6MRDQg4AkhAAAQgiAAgjgJg");
	var mask_graphics_45 = new cjs.Graphics().p("AlKXmQhqgdg+hhQg/hgARhsQAPhsBVg4IaMxBQBVg4BqAeQBpAcA+BgQA/BhgPBsQgRBrhVA4I6MRCQg4AlhBAAQghAAgkgKg");
	var mask_graphics_46 = new cjs.Graphics().p("AldXzQhqgdg/hhQg/hgARhsQAPhsBWg4IaMxBQBVg4BqAdQBoAdA/BgQA/BggPBsQgRBshWA4I6LRCQg5AlhAAAQghAAgkgKg");
	var mask_graphics_47 = new cjs.Graphics().p("AlwYAQhqgeg/hgQg/hhARhrQAPhsBWg4IaLxCQBWg3BqAdQBoAdA/BgQA/BggQBsQgQBshWA3I6MRDQg4AlhAAAQgiAAgjgKg");
	var mask_graphics_48 = new cjs.Graphics().p("AmEYMQhqgdg+hgQg/hhARhsQAPhsBVg3IaMxCQBVg3BqAdQBpAdA/BfQA+BhgPBsQgRBshVA3I6MRDQg4AkhBAAQghAAgkgKg");
	var mask_graphics_49 = new cjs.Graphics().p("AmXYZQhqgdg/hhQg/hgARhsQAQhsBVg4IaMxBQBVg4BqAeQBoAcA/BgQA/BhgPBsQgRBrhWA4I6LRCQg5AlhAAAQghAAgkgKg");
	var mask_graphics_50 = new cjs.Graphics().p("AmuYpQhqgeg/hgQg/hhARhsQAPhsBWg3IaLxCQBWg3BqAdQBoAdA/BfQA/BhgPBsQgRBshWA3I6LRDQg5AkhAAAQgiAAgjgJg");
	var mask_graphics_51 = new cjs.Graphics().p("AnuZSQhpgdg/hhQg/hgARhsQAPhsBVg4IaMxCQBWg3BqAcQBoAdA/BhQA/BggQBtQgRBrhVA4I6MRCQg4AlhAAAQgiAAgkgKg");
	var mask_graphics_52 = new cjs.Graphics().p("ApjafQhqgdg/hhQg/hgARhsQAQhsBVg4IaMxCQBVg4BqAeQBoAcA/BhQA/BhgPBsQgRBrhWA4I6LRDQg4AkhBAAQghAAgkgKg");
	var mask_graphics_53 = new cjs.Graphics().p("Ar8cEQhqgeg/hgQg+hhAQhrQAQhtBVg3IaMxDQBVg3BqAdQBpAdA+BgQA/BhgPBsQgRBshVA3I6MRDQg4AlhBAAQghAAgkgKg");
	var mask_graphics_54 = new cjs.Graphics().p("AtsdZQhqgdg/hhQg+hgARhsQAPhsBVg4IaMxCQBVg4BqAeQBpAcA+BhQA/BhgPBsQgRBrhVA4I6MRCQg4AlhBAAQghAAgkgKg");
	var mask_graphics_55 = new cjs.Graphics().p("AtseRQhqgdg+hhQg/hgARhsQAPhsBVg3IaMxDQBVg4BqAeQBpAdA+BgQA/BhgPBsQgRBrhVA4I6MRDQg4AkhBAAQghAAgkgKg");
	var mask_graphics_56 = new cjs.Graphics().p("AtseyQhqgdg/hhQg+hgARhsQAPhsBVg4IaMxCQBVg4BqAeQBpAcA+BhQA/BhgPBsQgRBrhVA4I6MRCQg4AlhBAAQghAAgkgKg");
	var mask_graphics_57 = new cjs.Graphics().p("AtsfDQhqgeg+hgQg/hhARhsQAPhsBVg3IaMxDQBVg3BqAdQBpAdA+BgQA/BhgPBsQgRBshVA3I6MRDQg4AkhBAAQghAAgkgJg");
	var mask_graphics_58 = new cjs.Graphics().p("AtsfHQhqgdg/hhQg+hgARhsQAPhsBVg4IaMxCQBVg4BqAeQBpAcA+BhQA/BhgPBsQgRBrhVA4I6MRCQg4AlhBAAQghAAgkgKg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:260.4531,y:89.0848}).wait(1).to({graphics:mask_graphics_22,x:257.5928,y:90.9429}).wait(1).to({graphics:mask_graphics_23,x:249.3948,y:96.2694}).wait(1).to({graphics:mask_graphics_24,x:234.4334,y:105.9903}).wait(1).to({graphics:mask_graphics_25,x:217.7171,y:116.8515}).wait(1).to({graphics:mask_graphics_26,x:205.9326,y:124.5083}).wait(1).to({graphics:mask_graphics_27,x:199.1955,y:128.8856}).wait(1).to({graphics:mask_graphics_28,x:195.9245,y:131.0109}).wait(1).to({graphics:mask_graphics_29,x:195.0031,y:131.6098}).wait(1).to({graphics:mask_graphics_30,x:193.0717,y:132.8846}).wait(1).to({graphics:mask_graphics_31,x:191.1404,y:134.1596}).wait(1).to({graphics:mask_graphics_32,x:189.2092,y:135.4346}).wait(1).to({graphics:mask_graphics_33,x:187.2779,y:136.7096}).wait(1).to({graphics:mask_graphics_34,x:185.3467,y:137.9846}).wait(1).to({graphics:mask_graphics_35,x:183.4154,y:139.2596}).wait(1).to({graphics:mask_graphics_36,x:181.4842,y:140.5346}).wait(1).to({graphics:mask_graphics_37,x:179.5529,y:141.8096}).wait(1).to({graphics:mask_graphics_38,x:177.6217,y:143.0846}).wait(1).to({graphics:mask_graphics_39,x:175.6904,y:144.3596}).wait(1).to({graphics:mask_graphics_40,x:173.7592,y:145.6346}).wait(1).to({graphics:mask_graphics_41,x:171.8279,y:146.9096}).wait(1).to({graphics:mask_graphics_42,x:169.8967,y:148.1846}).wait(1).to({graphics:mask_graphics_43,x:167.9654,y:149.4596}).wait(1).to({graphics:mask_graphics_44,x:166.0342,y:150.7346}).wait(1).to({graphics:mask_graphics_45,x:164.1029,y:152.0096}).wait(1).to({graphics:mask_graphics_46,x:162.1717,y:153.2846}).wait(1).to({graphics:mask_graphics_47,x:160.2404,y:154.5596}).wait(1).to({graphics:mask_graphics_48,x:158.3092,y:155.8346}).wait(1).to({graphics:mask_graphics_49,x:156.3781,y:157.1098}).wait(1).to({graphics:mask_graphics_50,x:154.0561,y:158.635}).wait(1).to({graphics:mask_graphics_51,x:147.724,y:162.7952}).wait(1).to({graphics:mask_graphics_52,x:135.9785,y:170.5118}).wait(1).to({graphics:mask_graphics_53,x:120.6955,y:180.5526}).wait(1).to({graphics:mask_graphics_54,x:105.8695,y:189.0997}).wait(1).to({graphics:mask_graphics_55,x:88.7655,y:194.7183}).wait(1).to({graphics:mask_graphics_56,x:78.7815,y:197.998}).wait(1).to({graphics:mask_graphics_57,x:73.7904,y:199.6375}).wait(1).to({graphics:mask_graphics_58,x:72.3533,y:200.1098}).wait(2));

	// Layer_10
	this.instance = new lib.scribble4_5();
	this.instance.setTransform(242.3,205.85,1,1,0,0,0,67.7,53.3);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({_off:false},0).wait(39));

	// Layer_4 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("APjP3I/PghQhmgChHhTQhGhSACh0QAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBHBUgCBzQgBBzhLBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("APjP4I/PghQhmgChHhTQhGhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBHBTgCB0QgBBzhLBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("APjP6I/PghQhmgChHhTQhGhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBHBUgCBzQgBBzhLBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("APjP9I/PghQhmgChHhTQhGhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBHBUgCBzQgCBzhKBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("APjQBI/PgiQhmgChHhTQhGhSAChzQACh0BJhRQBKhQBmACIfPAhQBmACBGBSQBHBUgCBzQgCBzhKBQQhHBQhkAAIgEAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AR8QEI/PgiQhmgChHhTQhHhSAChzQACh0BJhRQBKhQBmACIfPAhQBmACBHBSQBHBUgCBzQgCBzhKBQQhIBQhjAAIgEAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AT1QGI/PgiQhmgBhIhUQhGhSAChzQACh0BJhRQBKhQBmACIfPAiQBmABBGBSQBIBUgCBzQgCBzhKBQQhIBQhjAAIgEAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AUgQGI/PghQhmgChHhTQhHhSACh0QAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBIBUgCBzQgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AUxQHI/PgiQhmgBhHhUQhHhSAChzQAChzBJhSQBLhPBlABIfPAiQBmABBHBTQBHBTgCBzQgCB0hKBPQhHBQhkAAIgEAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AVCQHI/PghQhmgChHhTQhGhTAChzQABhzBKhRQBKhQBmACIfPAhQBlACBHBSQBHBUgCBzQgCBzhKBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AVTQII/OgiQhmgBhIhUQhGhSAChzQAChzBJhSQBKhPBmABIfPAiQBmABBGBTQBIBTgCBzQgCBzhLBQQhHBQhjAAIgFAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AVlQII/PghQhmgChIhTQhGhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBIBUgCBzQgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AV2QJI/PgiQhmgBhHhUQhHhSAChzQACh0BJhRQBKhPBmABIfPAiQBmABBGBSQBIBUgCBzQgCBzhKBQQhIBQhjAAIgEAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AWHQJI/PghQhmgChHhTQhHhTAChzQAChzBJhRQBLhQBlACIfPAhQBmACBHBSQBHBTgCB0QgCBzhKBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AWYQKI/PgiQhmgChHhTQhGhSAChzQABh0BKhRQBKhQBmACIfPAhQBmACBGBSQBHBUgCBzQgCBzhKBQQhHBQhkAAIgEAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AWpQKI/OghQhmgChIhUQhGhSAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBIBTgCB0QgCBzhKBQQhIBPhjAAIgFAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AW7QKI/PghQhmgChIhTQhGhSACh0QAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBIBUgCBzQgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AXMQLI/PghQhmgChHhUQhHhSAChzQAChzBJhRQBKhQBmABIfPAiQBmACBGBSQBIBTgCBzQgCB0hKBPQhIBQhjAAIgEAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AXdQLI/PghQhmgChHhTQhHhSACh0QAChzBJhRQBLhQBmACIfOAhQBmACBHBSQBHBUgCBzQgCBzhKBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AXuQMI/PgiQhmgBhHhUQhGhSAChzQAChzBJhSQBKhPBmABIfPAiQBmABBGBTQBHBTgCBzQgBB0hLBPQhHBQhkAAIgEAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AYAQMI/PghQhmgChIhTQhGhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBIBUgCBzQgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AYRQNI/PgiQhmgBhIhUQhGhSAChzQAChzBJhSQBKhPBmABIfPAiQBmABBGBTQBIBTgCBzQgCBzhKBQQhIBQhjAAIgEAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AYiQNI/PghQhmgChHhTQhHhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBHBSQBHBUgCBzQgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AYzQOI/PgiQhmgBhHhUQhHhSAChzQACh0BJhRQBLhPBmABIfOAiQBmABBHBSQBHBUgCBzQgCBzhKBQQhHBQhkAAIgEAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AZEQOI/PghQhlgChIhTQhGhTAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBHBTgCB0QgBBzhLBQQhHBPhjAAIgFAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AZWQPI/PgiQhmgChIhTQhGhSAChzQACh0BJhRQBKhQBmACIfPAhQBmACBGBSQBIBUgCBzQgCBzhKBQQhIBQhjAAIgEAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AZnQPI/PghQhmgChIhUQhGhSAChzQAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBIBTgCB0QgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AZ4QPI/PghQhmgChHhTQhHhSACh0QAChzBJhRQBKhQBmACIfPAhQBmACBHBSQBHBUgCBzQgCBzhKBQQhIBPhjAAIgEAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AaJQQI/PghQhmgChHhUQhGhSABhzQAChzBJhRQBLhQBmABIfOAiQBmACBHBSQBHBTgCBzQgCB0hKBPQhHBQhkAAIgEAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AaaQQI/PghQhlgChIhTQhGhSACh0QAChzBJhRQBKhQBmACIfPAhQBmACBGBSQBHBUgCBzQgBBzhLBQQhHBPhjAAIgFAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AbUQSI/OgiQhmgChIhTQhGhSAChzQACh0BJhRQBKhQBmACIfPAhQBmACBGBSQBIBUgCBzQgCBzhKBQQhIBQhjAAIgFAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AdzQVI/PgiQhmgBhHhUQhGhSAChzQABhzBKhSQBKhPBmABIfPAiQBmABBGBTQBHBTgCBzQgCB0hKBPQhHBQhkAAIgEAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAhMAQZI/QghQhmgChGhTQhGhTAChzQABhzBKhRQBJhQBmACIfQAhQBlACBHBSQBHBTgCB0QgCBzhKBQQhHBPhkAAIgEAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAklAQdI/QghQhmgChHhTQhGhSABh0QAChzBJhRQBLhQBmACIfPAhQBmACBHBSQBHBUgCBzQgCBzhKBQQhHBPhkABIgEgBg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAnEAQhI/QgiQhmgBhHhUQhHhSAChzQACh0BJhRQBKhPBmABIfQAiQBmABBHBTQBHBTgCBzQgCBzhKBQQhIBQhjAAIgEAAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAn+AQiI/QghQhmgChHhUQhHhSAChzQAChzBJhRQBLhQBmABIfPAiQBmABBHBTQBHBTgCBzQgCB0hKBPQhHBQhkAAIgEAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:13.9073,y:101.5378}).wait(1).to({graphics:mask_1_graphics_16,x:22.5255,y:101.612}).wait(1).to({graphics:mask_1_graphics_17,x:46.6731,y:101.8202}).wait(1).to({graphics:mask_1_graphics_18,x:81.5674,y:102.1209}).wait(1).to({graphics:mask_1_graphics_19,x:120.2972,y:102.4547}).wait(1).to({graphics:mask_1_graphics_20,x:139.9192,y:102.7554}).wait(1).to({graphics:mask_1_graphics_21,x:151.993,y:102.9635}).wait(1).to({graphics:mask_1_graphics_22,x:156.3022,y:103.0378}).wait(1).to({graphics:mask_1_graphics_23,x:158.0226,y:103.0832}).wait(1).to({graphics:mask_1_graphics_24,x:159.743,y:103.1287}).wait(1).to({graphics:mask_1_graphics_25,x:161.4635,y:103.1741}).wait(1).to({graphics:mask_1_graphics_26,x:163.1839,y:103.2196}).wait(1).to({graphics:mask_1_graphics_27,x:164.9044,y:103.265}).wait(1).to({graphics:mask_1_graphics_28,x:166.6248,y:103.3105}).wait(1).to({graphics:mask_1_graphics_29,x:168.3453,y:103.356}).wait(1).to({graphics:mask_1_graphics_30,x:170.0658,y:103.4014}).wait(1).to({graphics:mask_1_graphics_31,x:171.7862,y:103.4469}).wait(1).to({graphics:mask_1_graphics_32,x:173.5067,y:103.4923}).wait(1).to({graphics:mask_1_graphics_33,x:175.2271,y:103.5378}).wait(1).to({graphics:mask_1_graphics_34,x:176.9476,y:103.5832}).wait(1).to({graphics:mask_1_graphics_35,x:178.668,y:103.6287}).wait(1).to({graphics:mask_1_graphics_36,x:180.3885,y:103.6741}).wait(1).to({graphics:mask_1_graphics_37,x:182.1089,y:103.7196}).wait(1).to({graphics:mask_1_graphics_38,x:183.8294,y:103.765}).wait(1).to({graphics:mask_1_graphics_39,x:185.5498,y:103.8105}).wait(1).to({graphics:mask_1_graphics_40,x:187.2703,y:103.856}).wait(1).to({graphics:mask_1_graphics_41,x:188.9908,y:103.9014}).wait(1).to({graphics:mask_1_graphics_42,x:190.7112,y:103.9469}).wait(1).to({graphics:mask_1_graphics_43,x:192.4317,y:103.9923}).wait(1).to({graphics:mask_1_graphics_44,x:194.1522,y:104.0378}).wait(1).to({graphics:mask_1_graphics_45,x:199.9649,y:104.155}).wait(1).to({graphics:mask_1_graphics_46,x:215.8459,y:104.4753}).wait(1).to({graphics:mask_1_graphics_47,x:237.5396,y:104.9128}).wait(1).to({graphics:mask_1_graphics_48,x:259.2334,y:105.3503}).wait(1).to({graphics:mask_1_graphics_49,x:275.1143,y:105.6705}).wait(1).to({graphics:mask_1_graphics_50,x:280.9272,y:105.7878}).wait(10));

	// Layer_9
	this.instance_1 = new lib.scribble4_4();
	this.instance_1.setTransform(225,177.7,1,1,0,0,0,84.9,27.6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(45));

	// Layer_4 copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("AIpMBQhnghg7hjQg7hjAUhrQAVhrBYg0Ia3v9QBXg1BoAhQBoAiA7BjQA7BjgVBrQgUBrhXA0I64P+Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AG2MBQhnghg7hjQg7hjAThrQAWhrBXg0Ia3v9QBYg1BnAhQBpAiA7BjQA7BjgWBrQgTBrhYA0I63P+Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_14 = new cjs.Graphics().p("ACfMfQhnghg6hjQg7hjAUhrQAVhrBXg0Ia3v+QBYg0BnAhQBoAiA7BjQA7BjgVBrQgUBrhXA0I63P9Qg2Agg7AAQgnAAgpgNg");
	var mask_2_graphics_15 = new cjs.Graphics().p("Ah2PCQhnghg7hjQg7hjAUhsQAVhrBXg0Ia3v9QBXg0BnAhQBpAhA7BjQA7BkgVBqQgUBshYA0I63P9Qg1Agg7AAQgmAAgpgNg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AjpQFQhoghg6hjQg7hjAThrQAVhrBYg0Ia2v+QBYg0BnAhQBpAiA7BjQA6BjgVBrQgTBrhYA0I62P+Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_17 = new cjs.Graphics().p("Aj1QMQhnghg7hjQg7hjAUhsQAVhqBYg1Ia2v9QBXg0BnAhQBpAiA7BjQA7BjgVBrQgUBrhXA0I63P9Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AkBQTQhnghg6hjQg7hjAThsQAVhrBYg0Ia2v9QBYg0BnAhQBpAhA7BjQA6BkgVBqQgTBshYAzI62P+Qg2Agg7AAQgnAAgpgNg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AkMQaQhnghg7hjQg7hkAUhrQAVhrBYg0Ia2v9QBXg0BnAhQBpAhA7BjQA7BjgVBrQgUBshYAzI62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AkYQgQhnghg7hjQg6hjAThrQAVhrBYg0Ia2v9QBYg0BnAhQBpAhA6BjQA7BjgVBrQgTBrhYA0I62P+Qg2Afg7AAQgnAAgpgNg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AkjQnQhnghg7hjQg7hjAUhrQAVhrBXg0Ia3v+QBXg0BnAhQBpAiA7BjQA7BjgVBrQgUBrhYAzI62P/Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AkvQuQhnghg7hjQg7hjAUhsQAVhqBYg1Ia2v9QBYg0BnAhQBoAiA7BjQA7BjgVBrQgUBrhXAzI62P+Qg2Agg7AAQgnAAgpgNg");
	var mask_2_graphics_23 = new cjs.Graphics().p("Ak6Q1Qhnghg7hjQg7hjAUhsQAVhrBXg0Ia3v9QBXg0BnAhQBpAhA7BkQA7BjgVBqQgUBshYAzI62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AlGQ8Qhnghg7hjQg7hjAUhsQAVhrBYg0Ia2v9QBYg0BnAhQBoAhA7BjQA7BjgVBrQgUBshXAzI62P+Qg2Agg7AAQgnAAgpgNg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AlRRCQhnghg7hjQg7hjAThrQAWhrBXg0Ia2v9QBYg0BnAhQBpAhA7BjQA7BjgWBrQgTBrhYA0I62P+Qg1Agg8AAQgmAAgpgOg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AldRJQhnghg7hjQg7hjAUhrQAVhrBYg0Ia2v9QBYg1BnAhQBoAiA7BjQA7BjgVBrQgUBqhXA0I63P/Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AloRQQhnghg7hjQg7hjAThrQAWhrBXg0Ia2v+QBYg0BnAhQBpAiA7BjQA7BjgWBrQgTBqhYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_28 = new cjs.Graphics().p("Al0RXQhnghg7hjQg7hjAUhsQAVhrBYg0Ia2v9QBXg0BoAhQBoAiA7BjQA7BjgVBrQgUBqhXA0I63P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_29 = new cjs.Graphics().p("Al/ReQhoghg6hjQg7hjAThsQAVhrBYg0Ia2v9QBYg0BnAhQBpAhA7BjQA6BjgVBrQgTBrhYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AmLRkQhnghg7hjQg7hjAUhrQAVhrBYg0Ia2v9QBXg0BnAhQBpAhA7BjQA7BjgVBrQgUBrhXA0I63P+Qg1Agg8AAQgmAAgpgOg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AmXRrQhnghg6hjQg7hjAThrQAVhrBYg0Ia2v9QBYg1BnAhQBpAiA6BjQA7BjgVBrQgTBqhYA0I62P/Qg2Afg7AAQgnAAgpgNg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AmiRyQhnghg7hjQg7hjAUhrQAVhrBXg0Ia3v+QBXg0BnAhQBpAiA7BjQA7BjgVBrQgUBqhYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_33 = new cjs.Graphics().p("AmuR5Qhnghg7hjQg6hjAThsQAVhqBYg1Ia2v9QBYg0BnAhQBpAiA6BjQA7BjgVBrQgTBqhYA0I62P+Qg2Agg7AAQgnAAgpgNg");
	var mask_2_graphics_34 = new cjs.Graphics().p("Am5SAQhnghg7hjQg7hjAUhsQAVhrBXg0Ia3v9QBXg0BnAhQBpAhA7BjQA7BjgVBrQgUBrhYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AnFSHQhnghg7hkQg7hjAUhrQAVhrBYg0Ia2v9QBYg0BnAhQBoAhA7BjQA7BjgVBrQgUBrhXA0I62P+Qg2Agg7AAQgnAAgpgNg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AnQSNQhnghg7hjQg7hjAThrQAWhrBXg0Ia3v9QBXg1BnAhQBpAiA7BjQA7BjgWBrQgTBqhYA0I62P/Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AncSUQhnghg7hjQg7hjAUhrQAVhrBYg0Ia2v+QBYg0BnAhQBoAiA7BjQA7BjgVBrQgUBqhXA0I62P/Qg2Afg7AAQgnAAgpgNg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AnnSbQhnghg7hjQg7hjAThsQAWhqBXg1Ia2v9QBYg0BnAhQBpAiA7BjQA7BjgWBrQgTBqhYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AnzSiQhnghg7hjQg7hjAUhsQAVhrBYg0Ia2v9QBYg0BnAhQBoAhA7BjQA7BkgVBqQgUBrhXA0I63P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_40 = new cjs.Graphics().p("An+SpQhnghg7hjQg7hkAThrQAWhrBXg0Ia2v9QBYg0BnAhQBpAhA7BjQA7BjgWBrQgTBrhYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AoKSvQhnghg7hjQg7hjAUhrQAVhrBYg0Ia2v9QBXg0BoAhQBoAhA7BjQA7BjgVBrQgUBqhXA1I63P+Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_42 = new cjs.Graphics().p("Ap7TzQhnghg7hjQg7hjAThrQAVhrBYg0Ia2v+QBYg0BnAhQBpAiA7BjQA6BjgVBqQgTBrhYA0I62P/Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AuMWXQhnghg7hjQg7hjAUhsQAVhrBXg0Ia3v9QBXg0BnAhQBpAhA7BiQA7BjgVBrQgUBshYA0I62P+Qg1Agg8AAQgmAAgpgNg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AuMY6Qhnghg7hjQg7hjAUhrQAVhrBXg0Ia3v/QBXg0BnAhQBpAiA7BjQA7BjgVBrQgUBrhYA0I62P/Qg1Afg8AAQgmAAgpgNg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AuMZ+Qhnghg7hjQg7hjAUhsQAVhqBXg1Ia3v+QBXg0BnAhQBpAiA7BjQA7BjgVBrQgUBrhYA0I62P+Qg1Agg8AAQgmAAgpgNg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:257.7405,y:38.1616}).wait(1).to({graphics:mask_2_graphics_13,x:246.2072,y:51.6421}).wait(1).to({graphics:mask_2_graphics_14,x:218.3649,y:81.212}).wait(1).to({graphics:mask_2_graphics_15,x:190.5226,y:97.4842}).wait(1).to({graphics:mask_2_graphics_16,x:178.9905,y:104.2249}).wait(1).to({graphics:mask_2_graphics_17,x:177.8359,y:104.9055}).wait(1).to({graphics:mask_2_graphics_18,x:176.6819,y:105.5865}).wait(1).to({graphics:mask_2_graphics_19,x:175.5279,y:106.2675}).wait(1).to({graphics:mask_2_graphics_20,x:174.3739,y:106.9485}).wait(1).to({graphics:mask_2_graphics_21,x:173.2199,y:107.6295}).wait(1).to({graphics:mask_2_graphics_22,x:172.0659,y:108.3105}).wait(1).to({graphics:mask_2_graphics_23,x:170.9119,y:108.9915}).wait(1).to({graphics:mask_2_graphics_24,x:169.7579,y:109.6725}).wait(1).to({graphics:mask_2_graphics_25,x:168.6039,y:110.3535}).wait(1).to({graphics:mask_2_graphics_26,x:167.4499,y:111.0345}).wait(1).to({graphics:mask_2_graphics_27,x:166.2959,y:111.7155}).wait(1).to({graphics:mask_2_graphics_28,x:165.1419,y:112.3965}).wait(1).to({graphics:mask_2_graphics_29,x:163.9879,y:113.0775}).wait(1).to({graphics:mask_2_graphics_30,x:162.8339,y:113.7585}).wait(1).to({graphics:mask_2_graphics_31,x:161.6799,y:114.4395}).wait(1).to({graphics:mask_2_graphics_32,x:160.5259,y:115.1205}).wait(1).to({graphics:mask_2_graphics_33,x:159.3719,y:115.8015}).wait(1).to({graphics:mask_2_graphics_34,x:158.2179,y:116.4825}).wait(1).to({graphics:mask_2_graphics_35,x:157.0639,y:117.1635}).wait(1).to({graphics:mask_2_graphics_36,x:155.9099,y:117.8445}).wait(1).to({graphics:mask_2_graphics_37,x:154.7559,y:118.5255}).wait(1).to({graphics:mask_2_graphics_38,x:153.6019,y:119.2065}).wait(1).to({graphics:mask_2_graphics_39,x:152.4479,y:119.8875}).wait(1).to({graphics:mask_2_graphics_40,x:151.2939,y:120.5685}).wait(1).to({graphics:mask_2_graphics_41,x:150.1405,y:121.2499}).wait(1).to({graphics:mask_2_graphics_42,x:138.7903,y:128.0226}).wait(1).to({graphics:mask_2_graphics_43,x:111.2552,y:144.3745}).wait(1).to({graphics:mask_2_graphics_44,x:56.4544,y:160.7263}).wait(1).to({graphics:mask_2_graphics_45,x:33.7552,y:167.4999}).wait(15));

	// Layer_8
	this.instance_2 = new lib.scribble4_3();
	this.instance_2.setTransform(219,146.8,1,1,0,0,0,79,57.3);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).wait(48));

	// Layer_4 copy (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_7 = new cjs.Graphics().p("APnLNI/QgLQhlAAhJhTQhHhRAAhzQABh0BIhSQBJhQBmAAIfQAKQBlABBIBRQBIBTAABzQgBBzhJBRQhIBShlAAIgBAAg");
	var mask_3_graphics_8 = new cjs.Graphics().p("APnLNI/QgKQhlgBhJhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBlAABIBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_9 = new cjs.Graphics().p("APnLOI/QgKQhlAAhJhTQhHhRAAhzQABh0BIhSQBJhQBmAAIfQAKQBlABBIBRQBIBTAABzQgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_10 = new cjs.Graphics().p("APnLQI/QgKQhlAAhJhTQhHhRAAh0QABhzBIhSQBJhQBmAAIfQAKQBlABBIBRQBIBTAABzQgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_11 = new cjs.Graphics().p("AQDLSI/PgKQhmAAhJhTQhHhRABh0QAAhzBIhSQBKhRBmABIfPAKQBmABBHBRQBIBTAABzQgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_12 = new cjs.Graphics().p("ASuLUI/QgLQhmAAhIhTQhHhRAAhzQABh0BIhSQBJhQBmAAIfPAKQBmABBIBRQBIBTAABzQgBBzhJBRQhIBShlAAIgBAAg");
	var mask_3_graphics_13 = new cjs.Graphics().p("ATsLUI/PgKQhmgBhIhSQhIhSABhzQAAhzBJhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhmAAIgBAAg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AT6LUI/PgKQhmgBhIhSQhIhSABhzQABhzBIhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhlAAIgCAAg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AUJLUI/QgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSgBB0QAABzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_16 = new cjs.Graphics().p("AUXLUI/QgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBlAABIBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AUlLUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBJhRBmABIfQAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_18 = new cjs.Graphics().p("AUzLUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBmABIfPAKQBmAABHBSQBJBSgBB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_19 = new cjs.Graphics().p("AVBLUI/PgKQhmgBhIhSQhIhSABhzQAAhzBJhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhmAAIgBAAg");
	var mask_3_graphics_20 = new cjs.Graphics().p("AVPLUI/PgKQhmgBhIhSQhIhSABhzQABhzBIhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhlAAIgCAAg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AVeLUI/QgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSgBB0QAABzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_22 = new cjs.Graphics().p("AVsLUI/PgKQhmgBhJhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_23 = new cjs.Graphics().p("AV6LUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBlABIfQAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_24 = new cjs.Graphics().p("AWILUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBmABIfPAKQBmAABHBSQBJBSgBB0QgBBzhJBRQhHBRhmAAIgBAAg");
	var mask_3_graphics_25 = new cjs.Graphics().p("AWWLUI/PgKQhmgBhIhSQhIhSABhzQAAhzBJhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhlAAIgCAAg");
	var mask_3_graphics_26 = new cjs.Graphics().p("AWkLUI/PgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSgBB0QAABzhJBRQhIBRhlAAIgCAAg");
	var mask_3_graphics_27 = new cjs.Graphics().p("AWzLUI/QgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_28 = new cjs.Graphics().p("AXBLUI/PgKQhmgBhJhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_29 = new cjs.Graphics().p("AXPLUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBmABIfPAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_30 = new cjs.Graphics().p("AXdLUI/PgKQhmgBhIhSQhIhSABhzQAAhzBIhSQBKhRBmABIfPAKQBmAABHBSQBJBSgBB0QgBBzhJBRQhHBRhmAAIgBAAg");
	var mask_3_graphics_31 = new cjs.Graphics().p("AXrLUI/PgKQhmgBhIhSQhIhSABhzQABhzBIhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhlAAIgCAAg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AX5LUI/PgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSgBB0QAABzhJBRQhIBRhlAAIgCAAg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AYILUI/QgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AYWLUI/PgKQhmgBhJhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AYkLUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBmABIfPAKQBmAABHBSQBJBSgBB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AYyLUI/PgKQhmgBhIhSQhIhSABhzQAAhzBJhSQBJhRBmABIfPAKQBmAABHBSQBJBSgBB0QAABzhKBRQhHBRhmAAIgBAAg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AZvLUI/PgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfPAKQBmAABIBSQBIBSgBB0QAABzhJBRQhIBRhlAAIgCAAg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AcXLUI/PgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBmABIfPAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_39 = new cjs.Graphics().p("Af8LUI/QgKQhlgBhJhSQhHhSAAhzQABhzBIhSQBJhRBlABIfRAKQBmAABHBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EAjhALUI/RgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBmAABIBSQBIBSAAB0QgBBzhJBRQhIBRhlAAIgBAAg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EAmIALUI/QgKQhmgBhJhSQhHhSABhzQAAhzBIhSQBKhRBmABIfQAKQBmAABHBSQBJBSgBB0QgBBzhJBRQhHBRhmAAIgBAAg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EAnFALUI/QgKQhmgBhIhSQhHhSAAhzQABhzBIhSQBJhRBmABIfQAKQBmAABHBSQBJBSgBB0QAABzhJBRQhIBRhlAAIgCAAg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(7).to({graphics:mask_3_graphics_7,x:-9.6427,y:71.657}).wait(1).to({graphics:mask_3_graphics_8,x:2.8571,y:71.7074}).wait(1).to({graphics:mask_3_graphics_9,x:37.0073,y:71.8447}).wait(1).to({graphics:mask_3_graphics_10,x:83.6573,y:72.0322}).wait(1).to({graphics:mask_3_graphics_11,x:127.4858,y:72.2197}).wait(1).to({graphics:mask_3_graphics_12,x:144.5609,y:72.357}).wait(1).to({graphics:mask_3_graphics_13,x:150.8097,y:72.407}).wait(1).to({graphics:mask_3_graphics_14,x:152.2282,y:72.4072}).wait(1).to({graphics:mask_3_graphics_15,x:153.6456,y:72.4072}).wait(1).to({graphics:mask_3_graphics_16,x:155.063,y:72.4072}).wait(1).to({graphics:mask_3_graphics_17,x:156.4804,y:72.4072}).wait(1).to({graphics:mask_3_graphics_18,x:157.8978,y:72.4072}).wait(1).to({graphics:mask_3_graphics_19,x:159.3152,y:72.4072}).wait(1).to({graphics:mask_3_graphics_20,x:160.7325,y:72.4072}).wait(1).to({graphics:mask_3_graphics_21,x:162.1499,y:72.4072}).wait(1).to({graphics:mask_3_graphics_22,x:163.5673,y:72.4072}).wait(1).to({graphics:mask_3_graphics_23,x:164.9847,y:72.4072}).wait(1).to({graphics:mask_3_graphics_24,x:166.4021,y:72.4072}).wait(1).to({graphics:mask_3_graphics_25,x:167.8195,y:72.4072}).wait(1).to({graphics:mask_3_graphics_26,x:169.2369,y:72.4072}).wait(1).to({graphics:mask_3_graphics_27,x:170.6543,y:72.4072}).wait(1).to({graphics:mask_3_graphics_28,x:172.0717,y:72.4072}).wait(1).to({graphics:mask_3_graphics_29,x:173.4891,y:72.4072}).wait(1).to({graphics:mask_3_graphics_30,x:174.9065,y:72.4072}).wait(1).to({graphics:mask_3_graphics_31,x:176.3239,y:72.4072}).wait(1).to({graphics:mask_3_graphics_32,x:177.7412,y:72.4072}).wait(1).to({graphics:mask_3_graphics_33,x:179.1586,y:72.4072}).wait(1).to({graphics:mask_3_graphics_34,x:180.576,y:72.4072}).wait(1).to({graphics:mask_3_graphics_35,x:181.9934,y:72.4072}).wait(1).to({graphics:mask_3_graphics_36,x:183.4097,y:72.407}).wait(1).to({graphics:mask_3_graphics_37,x:189.5418,y:72.4072}).wait(1).to({graphics:mask_3_graphics_38,x:206.2921,y:72.4072}).wait(1).to({graphics:mask_3_graphics_39,x:229.1733,y:72.4072}).wait(1).to({graphics:mask_3_graphics_40,x:252.0546,y:72.4072}).wait(1).to({graphics:mask_3_graphics_41,x:268.8048,y:72.4072}).wait(1).to({graphics:mask_3_graphics_42,x:274.9347,y:72.407}).wait(18));

	// Layer_5
	this.instance_3 = new lib.scribble4_2();
	this.instance_3.setTransform(208.4,116,1,1,0,0,0,89.4,27.4);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(7).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("AHPKQQhigtgvhpQgvhqAhhoQAhhoBegpIcksqQBdgqBjAtQBjAuAvBqQAvBpgiBnQggBphdApI8lMqQgsAUguAAQgyAAg1gYg");
	var mask_4_graphics_1 = new cjs.Graphics().p("AHDKQQhjgtguhpQgvhqAghoQAihoBdgpIcksqQBegqBiAtQBkAuAvBqQAvBpgiBnQggBpheApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_2 = new cjs.Graphics().p("AGVKQQhjgtguhpQgvhqAghoQAihoBdgpIcksqQBegqBiAtQBkAuAvBqQAuBpghBnQggBpheApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_3 = new cjs.Graphics().p("AExKQQhjgtguhpQgvhqAghoQAihoBdgpIcksqQBegqBiAtQBkAuAvBqQAuBpghBnQggBpheApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_4 = new cjs.Graphics().p("ACAKQQhjgtguhpQguhqAghoQAhhoBdgpIcksqQBdgqBjAtQBkAuAuBqQAvBpgiBnQggBphdApI8kMqQgtAUgtAAQgzAAg0gYg");
	var mask_4_graphics_5 = new cjs.Graphics().p("AhXKQQhigtgvhpQgvhqAhhoQAhhoBegpIcjsqQBdgqBjAtQBkAuAuBqQAvBpgiBnQggBphdApI8kMqQgtAUguAAQgxAAg1gYg");
	var mask_4_graphics_6 = new cjs.Graphics().p("Aj5KQQhjgtguhpQgvhqAghoQAihoBdgpIcjsqQBegqBiAtQBkAuAvBqQAvBpgiBnQggBpheApI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_7 = new cjs.Graphics().p("AldKeQhigtgvhqQgvhpAghoQAihoBdgpIcksqQBdgqBiAtQBkAuAvBpQAvBqgiBnQggBphdApI8kMqQgsAUguAAQgyAAg1gYg");
	var mask_4_graphics_8 = new cjs.Graphics().p("AmWK3QhigtgvhpQgvhqAghoQAihoBdgpIcksqQBdgpBiAtQBkAtAvBqQAvBpgiBoQggBohdApI8kMqQgsAUguAAQgyAAg1gYg");
	var mask_4_graphics_9 = new cjs.Graphics().p("AmjK9QhigtgvhpQgvhqAghoQAihoBdgpIcksqQBdgqBiAtQBkAuAvBpQAvBqgiBnQggBphdApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_10 = new cjs.Graphics().p("AmwLDQhigtgvhqQgvhpAghoQAihoBdgpIcksqQBdgqBiAtQBkAuAvBpQAvBqgiBnQggBphdApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_11 = new cjs.Graphics().p("Am9LJQhigtgvhqQgvhpAghoQAihoBdgpIcksrQBdgpBiAtQBkAuAvBpQAvBpgiBoQggBohdAqI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_12 = new cjs.Graphics().p("AnKLOQhigtgvhpQgvhpAghpQAihnBdgqIcksqQBdgpBiAtQBkAuAvBpQAvBpgiBoQggBohdAqI8kMqQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AnXLUQhigtgvhpQgvhpAghpQAihnBdgqIcksqQBdgpBiAtQBkAtAvBqQAvBpgiBoQggBohdApI8kMrQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_14 = new cjs.Graphics().p("AnkLaQhigtgvhpQgvhqAghoQAihoBdgpIcksqQBdgpBiAtQBkAtAvBqQAvBpgiBoQggBohdApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_15 = new cjs.Graphics().p("AnxLgQhigtgvhpQgvhqAghoQAihoBdgpIcksqQBdgqBiAtQBkAuAvBpQAvBqgiBnQggBphdApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_16 = new cjs.Graphics().p("An+LmQhjgtguhqQgvhpAghoQAihoBdgpIcksqQBdgqBiAtQBkAuAvBpQAvBqgiBnQggBphdApI8kMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_17 = new cjs.Graphics().p("AoLLsQhjgtguhqQgvhpAghoQAihoBdgpIcksrQBdgpBiAtQBkAuAvBpQAvBpgiBoQggBoheAqI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_18 = new cjs.Graphics().p("AoYLxQhjgtguhpQgvhpAghpQAihnBdgqIcksqQBdgpBiAtQBkAuAvBpQAvBpgiBoQggBoheAqI8jMqQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_19 = new cjs.Graphics().p("AolL3QhjgtguhpQgvhpAghpQAihnBdgqIcksqQBdgpBiAtQBkAtAvBqQAvBpgiBoQggBoheApI8jMrQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AoyL9QhjgtguhpQgvhqAghoQAihoBdgpIcksqQBdgpBiAtQBkAtAvBqQAvBpgiBoQggBoheApI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_21 = new cjs.Graphics().p("Ao/MDQhjgtguhpQgvhqAghoQAihoBdgpIcjsqQBegqBiAtQBkAuAvBpQAvBqgiBnQggBpheApI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_22 = new cjs.Graphics().p("ApMMJQhjgtguhqQgvhpAghoQAihoBdgpIcjsqQBegqBiAtQBkAuAvBpQAvBqgiBnQggBpheApI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_23 = new cjs.Graphics().p("ApZMPQhjgtguhqQgvhpAghoQAihoBdgpIcjsrQBegpBiAtQBkAuAvBpQAvBpgiBoQggBoheAqI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_24 = new cjs.Graphics().p("ApmMUQhjgtguhpQgvhpAghpQAihnBdgqIcjsqQBegpBiAtQBkAuAvBpQAvBpgiBoQggBoheAqI8jMqQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_25 = new cjs.Graphics().p("ApzMaQhjgtguhpQgvhpAghpQAihnBdgqIcjsqQBegpBiAtQBkAtAvBqQAvBpgiBoQggBoheApI8jMrQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AqAMgQhjgtguhpQgvhqAghoQAihoBdgpIcjsqQBegpBiAtQBkAtAvBqQAuBpghBoQggBoheApI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_27 = new cjs.Graphics().p("AqNMmQhjgtguhpQgvhqAghoQAihoBdgpIcjsqQBegqBiAtQBkAuAvBpQAuBqghBnQggBpheApI8jMqQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AqaMsQhjgtguhqQgvhpAghoQAihoBdgpIcjsqQBegqBiAtQBkAuAvBpQAuBqghBnQggBpheAoI8jMrQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AqnMyQhjgtguhqQgvhpAghoQAihoBdgpIcjsrQBegpBiAtQBkAuAvBpQAuBpghBoQggBoheApI8jMrQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_30 = new cjs.Graphics().p("Aq0M3QhigtgvhpQgvhqAhhoQAhhnBegqIcjsqQBdgpBjAtQBkAtAuBqQAvBpgiBoQggBohdAoI8jMrQgtAUguAAQgyAAg1gYg");
	var mask_4_graphics_31 = new cjs.Graphics().p("AriNMQhigtgvhqQguhpAghoQAhhoBegpIcjsrQBdgpBjAtQBkAuAuBpQAvBqgiBnQggBohdApI8jMrQgtAUgtAAQgzAAg1gYg");
	var mask_4_graphics_32 = new cjs.Graphics().p("AtFN4QhjgtguhpQgvhpAghpQAihnBdgqIcjsqQBegpBiAtQBkAtAvBqQAuBpghBoQghBnhdApI8jMsQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_33 = new cjs.Graphics().p("AvhPHQhjgtguhpQgvhpAghpQAihnBdgqIcjsqQBegpBiAtQBkAtAvBqQAvBpgiBnQggBoheApI8jMsQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AvhQnQhjgtguhpQgvhqAghoQAihoBdgpIcjsqQBegpBiAtQBkAtAvBqQAvBogiBoQggBoheApI8jMrQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_35 = new cjs.Graphics().p("AvhRvQhjgtguhpQgvhpAghpQAihnBdgpIcjsrQBegpBiAtQBkAuAvBpQAvBogiBoQggBoheAqI8jMrQgsATguAAQgzAAg0gYg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AvhScQhjgtguhpQgvhqAghoQAihoBdgpIcjsqQBegqBiAtQBkAuAvBoQAvBqgiBnQggBpheApI8jMrQgsAUguAAQgzAAg0gYg");
	var mask_4_graphics_37 = new cjs.Graphics().p("AvhS1QhjgtguhpQgvhpAghpQAihnBdgqIcjsqQBegpBiAtQBkAuAvBoQAvBpgiBoQggBoheAqI8jMrQgsATguAAQgzAAg0gYg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:262.4357,y:-1.2307}).wait(1).to({graphics:mask_4_graphics_1,x:261.194,y:-0.1305}).wait(1).to({graphics:mask_4_graphics_2,x:256.5905,y:3.9453}).wait(1).to({graphics:mask_4_graphics_3,x:246.585,y:12.8039}).wait(1).to({graphics:mask_4_graphics_4,x:228.8611,y:28.4963}).wait(1).to({graphics:mask_4_graphics_5,x:207.3436,y:47.5474}).wait(1).to({graphics:mask_4_graphics_6,x:191.092,y:61.9362}).wait(1).to({graphics:mask_4_graphics_7,x:181.1264,y:69.3781}).wait(1).to({graphics:mask_4_graphics_8,x:175.4107,y:71.9075}).wait(1).to({graphics:mask_4_graphics_9,x:174.1104,y:72.4913}).wait(1).to({graphics:mask_4_graphics_10,x:172.8092,y:73.0747}).wait(1).to({graphics:mask_4_graphics_11,x:171.508,y:73.658}).wait(1).to({graphics:mask_4_graphics_12,x:170.2068,y:74.2413}).wait(1).to({graphics:mask_4_graphics_13,x:168.9056,y:74.8247}).wait(1).to({graphics:mask_4_graphics_14,x:167.6044,y:75.408}).wait(1).to({graphics:mask_4_graphics_15,x:166.3033,y:75.9913}).wait(1).to({graphics:mask_4_graphics_16,x:165.0021,y:76.5747}).wait(1).to({graphics:mask_4_graphics_17,x:163.7009,y:77.158}).wait(1).to({graphics:mask_4_graphics_18,x:162.3997,y:77.7413}).wait(1).to({graphics:mask_4_graphics_19,x:161.0985,y:78.3247}).wait(1).to({graphics:mask_4_graphics_20,x:159.7973,y:78.908}).wait(1).to({graphics:mask_4_graphics_21,x:158.4961,y:79.4913}).wait(1).to({graphics:mask_4_graphics_22,x:157.1949,y:80.0747}).wait(1).to({graphics:mask_4_graphics_23,x:155.8937,y:80.658}).wait(1).to({graphics:mask_4_graphics_24,x:154.5925,y:81.2413}).wait(1).to({graphics:mask_4_graphics_25,x:153.2913,y:81.8247}).wait(1).to({graphics:mask_4_graphics_26,x:151.9902,y:82.408}).wait(1).to({graphics:mask_4_graphics_27,x:150.689,y:82.9913}).wait(1).to({graphics:mask_4_graphics_28,x:149.3878,y:83.5747}).wait(1).to({graphics:mask_4_graphics_29,x:148.0857,y:84.1575}).wait(1).to({graphics:mask_4_graphics_30,x:146.8476,y:84.7116}).wait(1).to({graphics:mask_4_graphics_31,x:142.2573,y:86.7628}).wait(1).to({graphics:mask_4_graphics_32,x:132.2806,y:91.2208}).wait(1).to({graphics:mask_4_graphics_33,x:112.5181,y:99.1179}).wait(1).to({graphics:mask_4_graphics_34,x:69.6067,y:108.7053}).wait(1).to({graphics:mask_4_graphics_35,x:37.197,y:115.9464}).wait(1).to({graphics:mask_4_graphics_36,x:17.3229,y:120.3867}).wait(1).to({graphics:mask_4_graphics_37,x:5.9262,y:122.9325}).wait(23));

	// Layer_2
	this.instance_4 = new lib.scribble4_1();
	this.instance_4.setTransform(206.45,87.8,1,1,0,0,0,88,53.8);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(60));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,310,259.2);


(lib.scribble3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,460,230,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble3_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(230.2,116.4,1,1,0,0,0,230.2,116.4);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3_1, new cjs.Rectangle(0,0,460.5,232.8), null);


(lib.scribble3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("Ae+Y2MhGxgb8QjnhbhTkLQhTkPBxkgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEOQBSELhxEgQhyEgj0CNQiTBTiOAAQheAAhdglg");
	var mask_graphics_2 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_3 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_4 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_5 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_6 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_7 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_8 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_9 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_10 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_11 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_12 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_13 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_14 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_15 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_16 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_17 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_18 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_19 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_20 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_21 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_22 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_23 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_24 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_25 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_26 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_27 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_28 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_29 = new cjs.Graphics().p("AfGY2MhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_30 = new cjs.Graphics().p("AfGZTMhGxgb9QjnhbhTkLQhUkOBykgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcgkg");
	var mask_graphics_31 = new cjs.Graphics().p("AfGZTMhGxgb8QjnhbhTkLQhUkPBykfQBykgD1iJQDziODnBbMBGyAb9QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_32 = new cjs.Graphics().p("AfGZWMhGxgb9QjnhbhTkLQhUkOBykgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSELhyEfQhxEgj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_33 = new cjs.Graphics().p("AfGZaMhGxgb9QjnhbhTkKQhUkPBykgQBykgD1iJQDziNDnBbMBGyAb8QDnBbBUEPQBSELhyEgQhxEfj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_34 = new cjs.Graphics().p("AfGZgMhGxgb8QjnhchTkKQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb8QDnBcBUEOQBSELhyEgQhxEgj0CNQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_35 = new cjs.Graphics().p("AfGZpMhGxgb9QjnhbhTkLQhUkOBykgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSEKhyEgQhxEgj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_36 = new cjs.Graphics().p("AfGZ0MhGxgb9QjnhbhTkKQhUkPBykgQBykgD1iJQDziNDnBbMBGyAb8QDnBbBUEPQBSELhyEfQhxEgj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_37 = new cjs.Graphics().p("AfGaCMhGxgb8QjnhchTkKQhUkPBykgQBykgD1iJQDziNDnBbMBGyAb8QDnBcBUEOQBSELhyEgQhxEfj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_38 = new cjs.Graphics().p("AfGaTMhGxgb8QjnhbhTkLQhUkOBykgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSEKhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_39 = new cjs.Graphics().p("AfGapMhGxgb8QjnhchTkKQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb8QDnBcBUEOQBSELhyEgQhxEgj0CNQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_40 = new cjs.Graphics().p("AfGbDMhGxgb8QjnhchTkKQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb8QDnBcBUEOQBSELhyEgQhxEgj0CNQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_41 = new cjs.Graphics().p("AfGbiMhGxgb8QjnhbhTkLQhUkPBykgQBykfD1iKQDziNDnBbMBGyAb9QDnBbBUEOQBSELhyEgQhxEgj0CNQiTBTiOAAQhfAAhcglg");
	var mask_graphics_42 = new cjs.Graphics().p("Af0cHMhGygb+QjnhahSkKQhUkPBykgQBxkgD1iJQD0iNDnBbMBGyAb8QDmBbBUEPQBTELhyEfQhyEgjzCOQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_43 = new cjs.Graphics().p("EAheAcxMhGxgb9QjnhbhTkKQhTkPBxkgQBykgD1iJQD0iNDnBbMBGxAb8QDnBcBUEOQBSELhxEgQhyEfj0COQiTBSiOAAQheAAhdgkg");
	var mask_graphics_44 = new cjs.Graphics().p("EAjWAdgMhGxgb9QjnhbhTkKQhTkOBxkgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSEKhxEgQhyEgj0CNQiTBTiOAAQheAAhdglg");
	var mask_graphics_45 = new cjs.Graphics().p("EAlYAeUMhGxgb9QjnhchTkJQhTkPBxkgQBykfD1iKQD0iNDmBbMBGyAb8QDnBcBUEOQBSELhxEgQhyEgj0CNQiTBSiOAAQheAAhdgkg");
	var mask_graphics_46 = new cjs.Graphics().p("EAngAfKMhGygb+QjnhbhSkKQhUkOBxkgQBykgD1iJQD0iODnBcMBGxAb8QDnBbBUEPQBSELhxEfQhyEgj0COQiTBSiOAAQheAAhcgkg");
	var mask_graphics_47 = new cjs.Graphics().p("EApmAf/MhGygb+QjnhbhTkJQhTkPBxkgQBykgD1iJQD0iNDnBbMBGxAb8QDnBbBUEPQBSELhxEfQhyEgj0COQiTBSiOAAQheAAhcgkg");
	var mask_graphics_48 = new cjs.Graphics().p("EArlAgxMhGygb9QjnhbhSkKQhUkPBykgQBxkfD1iKQD0iNDnBbMBGxAb8QDnBcBUEOQBTELhyEgQhyEgjzCNQiUBTiOAAQheAAhcglg");
	var mask_graphics_49 = new cjs.Graphics().p("EAtaAhfMhGygb9QjnhbhTkKQhTkOBxkgQBykgD1iJQD0iODnBbMBGxAb9QDnBbBUEPQBSEKhxEgQhyEgj0CNQiTBTiOAAQheAAhcglg");
	var mask_graphics_50 = new cjs.Graphics().p("EAvCAiJMhGxgb9QjnhchTkKQhUkOBykgQBykgD1iJQDziNDnBbMBGyAb8QDnBcBUEOQBSELhyEgQhxEfj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_51 = new cjs.Graphics().p("EAwfAiuMhGygb+QjnhbhSkLQhUkNBykgQBxkgD1iJQD0iODnBcMBGxAb8QDnBbBUEPQBTELhyEfQhyEgjzCOQiTBSiPAAQheAAhcgkg");
	var mask_graphics_52 = new cjs.Graphics().p("EAxwAjOMhGygb+QjnhbhSkKQhUkOBykgQBxkgD1iJQD0iNDnBbMBGxAb8QDnBbBUEPQBTELhyEfQhyEgjzCOQiTBSiPAAQheAAhcgkg");
	var mask_graphics_53 = new cjs.Graphics().p("EAy2AjqMhGxgb+QjnhbhTkLQhUkNBykgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSELhyEfQhxEgj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_54 = new cjs.Graphics().p("EAzzAkCMhGxgb+QjnhbhTkKQhUkOBykgQBykgD1iJQDziNDnBbMBGyAb8QDnBbBUEPQBSELhyEgQhxEfj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_55 = new cjs.Graphics().p("EA0oAkXMhGygb+QjnhbhSkKQhUkOBykgQBxkgD1iJQD0iNDnBbMBGyAb8QDnBbBTEPQBTELhyEfQhyEgjzCOQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_56 = new cjs.Graphics().p("EA1VAkpMhGxgb+QjnhbhTkLQhUkNBykgQBykgD1iJQDziODnBcMBGyAb8QDnBbBUEPQBSELhyEfQhxEgj0COQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_57 = new cjs.Graphics().p("EA18Ak4MhGygb9QjnhchSkKQhUkOBykgQBxkgD1iJQD0iNDnBbMBGyAb8QDnBcBTEOQBTELhyEgQhyEgjzCNQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_58 = new cjs.Graphics().p("EA2dAlFMhGygb9QjnhchSkKQhUkOBykgQBxkfD1iKQD0iNDnBbMBGxAb8QDnBcBUEOQBTELhyEgQhyEgjzCNQiTBSiOAAQhfAAhcgkg");
	var mask_graphics_59 = new cjs.Graphics().p("EA25AlQMhGygb9QjnhchSkKQhUkOBxkgQBykfD1iKQD0iNDnBbMBGxAb8QDnBcBUEOQBSELhxEgQhyEgj0CNQiTBSiOAAQheAAhcgkg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-289.7187,y:-27.8203}).wait(1).to({graphics:mask_graphics_2,x:-288.2458,y:-26.9191}).wait(1).to({graphics:mask_graphics_3,x:-284.207,y:-25.3101}).wait(1).to({graphics:mask_graphics_4,x:-278.1217,y:-22.8857}).wait(1).to({graphics:mask_graphics_5,x:-269.6793,y:-19.5223}).wait(1).to({graphics:mask_graphics_6,x:-258.5358,y:-15.0828}).wait(1).to({graphics:mask_graphics_7,x:-244.3424,y:-9.4282}).wait(1).to({graphics:mask_graphics_8,x:-226.8109,y:-2.4437}).wait(1).to({graphics:mask_graphics_9,x:-205.8384,y:5.9116}).wait(1).to({graphics:mask_graphics_10,x:-181.6849,y:15.5343}).wait(1).to({graphics:mask_graphics_11,x:-155.1319,y:26.1129}).wait(1).to({graphics:mask_graphics_12,x:-127.461,y:37.1369}).wait(1).to({graphics:mask_graphics_13,x:-100.156,y:48.0151}).wait(1).to({graphics:mask_graphics_14,x:-74.4839,y:58.2428}).wait(1).to({graphics:mask_graphics_15,x:-51.2408,y:67.5027}).wait(1).to({graphics:mask_graphics_16,x:-30.7556,y:75.664}).wait(1).to({graphics:mask_graphics_17,x:-13.0336,y:82.7243}).wait(1).to({graphics:mask_graphics_18,x:2.0938,y:88.751}).wait(1).to({graphics:mask_graphics_19,x:14.866,y:93.8394}).wait(1).to({graphics:mask_graphics_20,x:25.5355,y:98.0901}).wait(1).to({graphics:mask_graphics_21,x:34.3409,y:101.5982}).wait(1).to({graphics:mask_graphics_22,x:41.4962,y:104.4488}).wait(1).to({graphics:mask_graphics_23,x:47.1885,y:106.7166}).wait(1).to({graphics:mask_graphics_24,x:51.5797,y:108.466}).wait(1).to({graphics:mask_graphics_25,x:54.8089,y:109.7526}).wait(1).to({graphics:mask_graphics_26,x:56.996,y:110.6239}).wait(1).to({graphics:mask_graphics_27,x:58.2441,y:111.1211}).wait(1).to({graphics:mask_graphics_28,x:58.6423,y:111.2797}).wait(1).to({graphics:mask_graphics_29,x:132.8923,y:139.8047}).wait(1).to({graphics:mask_graphics_30,x:207.1423,y:165.4925}).wait(1).to({graphics:mask_graphics_31,x:207.5212,y:165.5685}).wait(1).to({graphics:mask_graphics_32,x:208.7159,y:165.8053}).wait(1).to({graphics:mask_graphics_33,x:210.8247,y:166.2232}).wait(1).to({graphics:mask_graphics_34,x:213.963,y:166.8452}).wait(1).to({graphics:mask_graphics_35,x:218.2667,y:167.6981}).wait(1).to({graphics:mask_graphics_36,x:223.8964,y:168.8139}).wait(1).to({graphics:mask_graphics_37,x:231.0412,y:170.2299}).wait(1).to({graphics:mask_graphics_38,x:239.9217,y:171.9899}).wait(1).to({graphics:mask_graphics_39,x:250.7906,y:174.144}).wait(1).to({graphics:mask_graphics_40,x:263.9254,y:176.7471}).wait(1).to({graphics:mask_graphics_41,x:279.6055,y:179.8548}).wait(1).to({graphics:mask_graphics_42,x:293.4971,y:183.5124}).wait(1).to({graphics:mask_graphics_43,x:304.155,y:187.737}).wait(1).to({graphics:mask_graphics_44,x:316.1429,y:192.4886}).wait(1).to({graphics:mask_graphics_45,x:329.1522,y:197.6452}).wait(1).to({graphics:mask_graphics_46,x:342.6642,y:203.001}).wait(1).to({graphics:mask_graphics_47,x:356.0572,y:208.3097}).wait(1).to({graphics:mask_graphics_48,x:368.7774,y:213.3517}).wait(1).to({graphics:mask_graphics_49,x:380.4581,y:217.9816}).wait(1).to({graphics:mask_graphics_50,x:390.9341,y:222.134}).wait(1).to({graphics:mask_graphics_51,x:400.1881,y:225.8021}).wait(1).to({graphics:mask_graphics_52,x:408.2863,y:229.012}).wait(1).to({graphics:mask_graphics_53,x:415.3311,y:231.8044}).wait(1).to({graphics:mask_graphics_54,x:421.4338,y:234.2234}).wait(1).to({graphics:mask_graphics_55,x:426.7008,y:236.3111}).wait(1).to({graphics:mask_graphics_56,x:431.2283,y:238.1057}).wait(1).to({graphics:mask_graphics_57,x:435.1007,y:239.6406}).wait(1).to({graphics:mask_graphics_58,x:438.3912,y:240.9449}).wait(1).to({graphics:mask_graphics_59,x:441.161,y:242.0425}).wait(1));

	// Layer_2
	this.instance = new lib.scribble3_1();
	this.instance.setTransform(153.25,162.55,1,1,0,0,0,230.2,116.4);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-76.9,0,460.4,278.9);


(lib.scribble2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,438,350,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble2_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(219.3,195.9,1,1,0,0,0,219.3,195.9);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2_1, new cjs.Rectangle(0,0,438.7,391.8), null);


(lib.scribble2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("EgI/AlNQk+hwjrk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFCByDsE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_2 = new cjs.Graphics().p("EgJMAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_3 = new cjs.Graphics().p("EgJjAlNQk+hwjrk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFCByDsE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQhzAAiGgvg");
	var mask_graphics_4 = new cjs.Graphics().p("EgKGAlNQk+hwjrk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFCByDsE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_5 = new cjs.Graphics().p("EgK3AlNQk9hwjrk+Qjrk/gQlUQgMlSDYifMBCMgw4QDYigE+BwQFCByDrE+QDsE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQh0AAiGgvg");
	var mask_graphics_6 = new cjs.Graphics().p("EgL2AlNQk+hwjrk+Qjrk/gQlUQgMlSDYifMBCNgw4QDYigE9BwQFCByDrE+QDsE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQhzAAiGgvg");
	var mask_graphics_7 = new cjs.Graphics().p("EgNIAlNQk9hwjrk+Qjsk/gQlUQgLlSDYifMBCMgw4QDYigE+BwQFCByDrE+QDrE/ALFSQARFTjYCgMhCNAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_8 = new cjs.Graphics().p("EgOsAlNQk+hwjrk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFCByDsE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQhzAAiGgvg");
	var mask_graphics_9 = new cjs.Graphics().p("EgQlAlNQk9hwjrk+Qjrk/gRlUQgLlSDYifMBCMgw4QDYigE+BwQFCByDrE+QDsE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQh0AAiGgvg");
	var mask_graphics_10 = new cjs.Graphics().p("EgSvAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_11 = new cjs.Graphics().p("EgVHAlNQk+hwjrk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFCByDsE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQhzAAiGgvg");
	var mask_graphics_12 = new cjs.Graphics().p("EgXmAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_13 = new cjs.Graphics().p("EgaCAlNQk+hwjrk+Qjrk/gQlUQgMlSDYifMBCNgw4QDYigE9BwQFCByDrE+QDsE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQhzAAiGgvg");
	var mask_graphics_14 = new cjs.Graphics().p("EgcWAlNQk9hwjrk+Qjrk/gRlUQgLlSDYifMBCMgw4QDYigE+BwQFCByDrE+QDrE/AMFSQAQFTjYCgMhCMAw4Qh/BdiiAAQh0AAiGgvg");
	var mask_graphics_15 = new cjs.Graphics().p("EgebAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_16 = new cjs.Graphics().p("EggQAlNQk+hwjrk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFCByDsE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdijAAQhzAAiGgvg");
	var mask_graphics_17 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_18 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_19 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_20 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_21 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_22 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_23 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_24 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_25 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_26 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_27 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_28 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_29 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_30 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_31 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_32 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_33 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_34 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_35 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_36 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_37 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_38 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_39 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_40 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_41 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_42 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_43 = new cjs.Graphics().p("EgglAlNQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_44 = new cjs.Graphics().p("EgglAmpQk9hwjsk+Qjrk/gQlTQgLlSDYigMBCMgw4QDYifE9BvQFDByDrE+QDrE/ALFSQAQFUjYCfMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_45 = new cjs.Graphics().p("EgglAoVQk9hwjsk+Qjrk/gQlTQgLlSDYigMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_46 = new cjs.Graphics().p("EgglAqFQk9hwjsk+Qjrk/gQlUQgLlRDYigMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_47 = new cjs.Graphics().p("EgglAr0Qk9hwjsk+Qjrk/gQlTQgLlSDYigMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_48 = new cjs.Graphics().p("EgglAteQk9hwjsk/Qjrk+gQlUQgLlSDYigMBCMgw4QDYifE9BwQFDBxDrE/QDrE+ALFSQAQFUjYCfMhCMAw5Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_49 = new cjs.Graphics().p("EgglAu+Qk9hvjsk/Qjrk/gQlTQgLlSDYigMBCMgw4QDYifE9BvQFDByDrE/QDrE+ALFSQAQFUjYCfMhCMAw4Qh+BeiiAAQh0AAiGgwg");
	var mask_graphics_50 = new cjs.Graphics().p("EgglAwVQk9hwjsk+Qjrk/gQlTQgLlSDYigMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFUjYCfMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_51 = new cjs.Graphics().p("EgglAxiQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCgMhCMAw4Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_52 = new cjs.Graphics().p("EgglAylQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCfMhCMAw5Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_53 = new cjs.Graphics().p("EgglAzfQk9hvjsk/Qjrk+gQlUQgLlSDYigMBCMgw4QDYifE9BvQFDByDrE/QDrE+ALFSQAQFUjYCeMhCMAw5Qh+BeiiAAQh0AAiGgwg");
	var mask_graphics_54 = new cjs.Graphics().p("EgglA0SQk9hwjsk+Qjrk/gQlUQgLlSDYifMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFSjYCgMhCMAw5Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_55 = new cjs.Graphics().p("EgglA0+Qk9hwjsk/Qjrk+gQlUQgLlSDYifMBCMgw5QDYifE9BwQFDBxDrE/QDrE+ALFSQAQFTjYCgMhCMAw5Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_56 = new cjs.Graphics().p("EgglA1jQk9hwjsk+Qjrk/gQlTQgLlSDYigMBCMgw4QDYigE9BwQFDByDrE+QDrE/ALFSQAQFTjYCfMhCMAw5Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_57 = new cjs.Graphics().p("EgglA2DQk9hwjsk+Qjrk/gQlTQgLlSDYigMBCMgw4QDYifE9BvQFDByDrE+QDrE/ALFSQAQFTjYCfMhCMAw5Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_58 = new cjs.Graphics().p("EgglA2fQk9hwjsk/Qjrk+gQlUQgLlSDYigMBCMgw4QDYifE9BwQFDBxDrE/QDrE+ALFSQAQFTjYCfMhCMAw6Qh+BdiiAAQh0AAiGgvg");
	var mask_graphics_59 = new cjs.Graphics().p("EgglA21Qk9hvjsk/Qjrk+gQlUQgLlSDYigMBCMgw4QDYifE9BwQFDBxDrE/QDrE+ALFSQAQFTjYCfMhCMAw6Qh+BdiiAAQh0AAiGgwg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:440.023,y:-149.7679}).wait(1).to({graphics:mask_graphics_2,x:438.7266,y:-147.8364}).wait(1).to({graphics:mask_graphics_3,x:436.411,y:-144.3875}).wait(1).to({graphics:mask_graphics_4,x:432.9222,y:-139.1911}).wait(1).to({graphics:mask_graphics_5,x:428.082,y:-131.9819}).wait(1).to({graphics:mask_graphics_6,x:421.6932,y:-122.4661}).wait(1).to({graphics:mask_graphics_7,x:413.5558,y:-110.3459}).wait(1).to({graphics:mask_graphics_8,x:403.5047,y:-95.3753}).wait(1).to({graphics:mask_graphics_9,x:391.4807,y:-77.4662}).wait(1).to({graphics:mask_graphics_10,x:377.633,y:-56.8408}).wait(1).to({graphics:mask_graphics_11,x:362.4096,y:-34.1663}).wait(1).to({graphics:mask_graphics_12,x:346.5453,y:-10.5372}).wait(1).to({graphics:mask_graphics_13,x:330.8907,y:12.7793}).wait(1).to({graphics:mask_graphics_14,x:316.1724,y:34.7015}).wait(1).to({graphics:mask_graphics_15,x:302.8466,y:54.5495}).wait(1).to({graphics:mask_graphics_16,x:291.1021,y:72.0425}).wait(1).to({graphics:mask_graphics_17,x:272.84,y:87.1758}).wait(1).to({graphics:mask_graphics_18,x:255.4942,y:100.0936}).wait(1).to({graphics:mask_graphics_19,x:240.8491,y:111.0002}).wait(1).to({graphics:mask_graphics_20,x:228.615,y:120.1112}).wait(1).to({graphics:mask_graphics_21,x:218.5183,y:127.6304}).wait(1).to({graphics:mask_graphics_22,x:210.3138,y:133.7405}).wait(1).to({graphics:mask_graphics_23,x:203.7867,y:138.6014}).wait(1).to({graphics:mask_graphics_24,x:198.7516,y:142.3511}).wait(1).to({graphics:mask_graphics_25,x:195.0488,y:145.1087}).wait(1).to({graphics:mask_graphics_26,x:192.541,y:146.9763}).wait(1).to({graphics:mask_graphics_27,x:191.11,y:148.042}).wait(1).to({graphics:mask_graphics_28,x:190.6534,y:148.3821}).wait(1).to({graphics:mask_graphics_29,x:190.6534,y:148.3821}).wait(1).to({graphics:mask_graphics_30,x:190.6534,y:148.3821}).wait(1).to({graphics:mask_graphics_31,x:190.2272,y:148.6961}).wait(1).to({graphics:mask_graphics_32,x:188.8834,y:149.6864}).wait(1).to({graphics:mask_graphics_33,x:186.5114,y:151.4343}).wait(1).to({graphics:mask_graphics_34,x:182.9815,y:154.0355}).wait(1).to({graphics:mask_graphics_35,x:178.1407,y:157.6027}).wait(1).to({graphics:mask_graphics_36,x:171.8085,y:162.2691}).wait(1).to({graphics:mask_graphics_37,x:163.7721,y:168.1911}).wait(1).to({graphics:mask_graphics_38,x:153.7834,y:175.5519}).wait(1).to({graphics:mask_graphics_39,x:141.5581,y:184.5608}).wait(1).to({graphics:mask_graphics_40,x:126.7843,y:195.4477}).wait(1).to({graphics:mask_graphics_41,x:109.1475,y:208.4445}).wait(1).to({graphics:mask_graphics_42,x:88.3888,y:223.7418}).wait(1).to({graphics:mask_graphics_43,x:64.4129,y:241.4098}).wait(1).to({graphics:mask_graphics_44,x:37.4453,y:252.0464}).wait(1).to({graphics:mask_graphics_45,x:8.1798,y:262.8294}).wait(1).to({graphics:mask_graphics_46,x:-22.2164,y:274.029}).wait(1).to({graphics:mask_graphics_47,x:-52.3451,y:285.1301}).wait(1).to({graphics:mask_graphics_48,x:-80.9602,y:295.6734}).wait(1).to({graphics:mask_graphics_49,x:-107.2368,y:305.3551}).wait(1).to({graphics:mask_graphics_50,x:-130.8034,y:314.0384}).wait(1).to({graphics:mask_graphics_51,x:-151.6211,y:321.7087}).wait(1).to({graphics:mask_graphics_52,x:-169.8387,y:328.4211}).wait(1).to({graphics:mask_graphics_53,x:-185.6866,y:334.2603}).wait(1).to({graphics:mask_graphics_54,x:-199.415,y:339.3186}).wait(1).to({graphics:mask_graphics_55,x:-211.2635,y:343.6843}).wait(1).to({graphics:mask_graphics_56,x:-221.4485,y:347.4369}).wait(1).to({graphics:mask_graphics_57,x:-230.1598,y:350.6467}).wait(1).to({graphics:mask_graphics_58,x:-237.562,y:353.374}).wait(1).to({graphics:mask_graphics_59,x:-243.7966,y:355.6709}).wait(1));

	// Layer_2
	this.instance = new lib.scribble2_1();
	this.instance.setTransform(187.25,152.9,1,1,0,0,0,219.3,195.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-32,-43,438.6,391.8);


(lib.scribble1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,136,75,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble1_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(68.2,37.5,1,1,0,0,0,68.2,37.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_2, new cjs.Rectangle(0,0,136.4,75.1), null);


(lib.scribble1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,175,78,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble1_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(87.7,39.1,1,1,0,0,0,87.7,39.1);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_1, new cjs.Rectangle(0,0,175.4,78.1), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_13 = new cjs.Graphics().p("AL4KnI6cmtQhWgWgkhyQgkhzAkiNQAjiMBXhTQBWhVBXAWIacGsQBWAWAkB0QAkBygkCNQgjCMhXBVQhEBChFAAQgSAAgSgFg");
	var mask_graphics_14 = new cjs.Graphics().p("ALOLRI5HmYQhSgVghhyQghhzAkiLQAjiNBUhTQBThWBSAVIZHGXQBSAVAhBzQAhBxgkCNQgjCMhUBWQhDBDhCAAQgQAAgQgEg");
	var mask_graphics_15 = new cjs.Graphics().p("AKqL0I3/mGQhPgUgehxQgehyAkiMQAjiMBRhUQBRhXBOAUIX/GFQBPAUAeByQAeBxgkCNQgjCMhRBWQhBBFhAAAQgPAAgPgEg");
	var mask_graphics_16 = new cjs.Graphics().p("ALLMRI3Dl2QhLgUgchwQgdhyAkiMQAkiMBPhVQBOhXBLAUIXDF1QBMATAcByQAcBxgkCMQgjCMhPBXQhABGg+AAQgOAAgOgEg");
	var mask_graphics_17 = new cjs.Graphics().p("AMsMpI2SlqQhJgSgahwQgahyAkiMQAjiMBNhVQBNhXBJASIWSFpQBIATAbBxQAaBwgkCMQgjCNhNBXQg/BHg9AAQgNAAgNgEg");
	var mask_graphics_18 = new cjs.Graphics().p("AN6M8I1rlgQhGgSgZhvQgZhxAjiNQAkiLBMhWQBLhYBHASIVqFfQBHASAZByQAZBvgkCMQgjCNhMBYQg+BHg7AAQgNAAgMgEg");
	var mask_graphics_19 = new cjs.Graphics().p("AO2NLI1MlYQhFgSgXhvQgYhxAjiMQAkiLBLhXQBKhYBFASIVMFXQBFASAYBxQAYBvgkCMQgkCNhKBYQg+BHg6AAQgMAAgMgDg");
	var mask_graphics_20 = new cjs.Graphics().p("APkNXI01lTQhEgRgXhvQgXhxAkiMQAjiMBKhWQBJhYBEARIU1FSQBEARAYBxQAWBugjCNQgkCMhJBZQg+BIg5AAQgMAAgLgDg");
	var mask_graphics_21 = new cjs.Graphics().p("AQFNfI0llPQhDgRgWhvQgXhwAkiNQAkiMBJhWQBIhYBEARIUkFOQBDARAXBwQAWBvgkCMQgkCNhIBYQg9BJg5AAQgLAAgLgDg");
	var mask_graphics_22 = new cjs.Graphics().p("AQaNkI0ZlMQhDgQgVhvQgWhxAjiMQAkiMBJhWQBIhYBCAQIUaFLQBCARAXBwQAVBvgjCNQgkCMhIBYQg9BJg5AAQgLAAgLgDg");
	var mask_graphics_23 = new cjs.Graphics().p("AQoNnI0TlKQhCgQgWhvQgWhwAkiNQAkiMBIhWQBIhYBCAQIUTFJQBCARAWBxQAWBugkCNQgkCMhIBYQg8BJg5AAQgLAAgKgDg");
	var mask_graphics_24 = new cjs.Graphics().p("AQuNpI0PlJQhCgRgVhuQgWhxAkiMQAjiNBJhVQBIhZBCARIUPFIQBCARAWBwQAVBvgkCMQgjCNhIBYQg9BJg4AAQgLAAgLgDg");
	var mask_graphics_25 = new cjs.Graphics().p("AQxNqI0OlJQhCgRgVhuQgWhxAkiMQAjiNBJhVQBHhZBCARIUOFIQBCAQAWBxQAVBugjCNQgkCMhIBZQg8BIg4AAQgLAAgLgCg");
	var mask_graphics_26 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_27 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_28 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_29 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_30 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_31 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_32 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_33 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_34 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_35 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_36 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_37 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_38 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_39 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_40 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_41 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_42 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_43 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_44 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_45 = new cjs.Graphics().p("AQ+NuI0OlJQhCgRgVhuQgWhxAkiMQAjiMBJhWQBIhZBCARIUNFIQBCARAWBwQAVBugjCNQgkCMhIBZQg8BIg5AAQgKAAgLgCg");
	var mask_graphics_46 = new cjs.Graphics().p("AT/OhI2altQhJgSgahwQgbhyAkiMQAjiNBOhUQBNhXBIASIWaFsQBJASAbByQAaBvgjCNQgkCMhNBYQg/BGg9AAQgNAAgNgDg");
	var mask_graphics_47 = new cjs.Graphics().p("AWvPPI4ZmNQhQgUgfhxQgfhzAkiMQAjiNBShTQBShWBOAUIYaGMQBQAUAfBzQAfBxgjCMQgkCNhSBWQhCBEhAAAQgQAAgPgEg");
	var mask_graphics_48 = new cjs.Graphics().p("AZOP5I6MmqQhWgWgjhyQgjh0AjiMQAkiNBWhSQBVhVBVAWIaNGpQBWAVAkB0QAjBygkCNQgkCMhVBVQhFBChEAAQgRAAgSgEg");
	var mask_graphics_49 = new cjs.Graphics().p("AbcQeI7znEQhbgXgnhzQgnh1AkiMQAjiNBahRQBZhUBaAXIb1HDQBbAXAnB1QAnBzgkCMQgkCNhZBUQhGBAhHAAQgUAAgUgFg");
	var mask_graphics_50 = new cjs.Graphics().p("AdaQ/I9QnbQhegYgqh0Qgrh2AkiMQAkiNBdhQQBbhTBgAYIdPHaQBgAYArB2QAqB0gkCMQgkCNhcBTQhIA/hJAAQgWAAgWgGg");
	var mask_graphics_51 = new cjs.Graphics().p("AfHRcI+fnvQhigagth0Qguh3AkiMQAkiMBfhQQBfhTBkAaIeeHuQBkAZAtB2QAtB1gjCMQgkCNhgBSQhJA+hLAAQgXAAgYgGg");
	var mask_graphics_52 = new cjs.Graphics().p("EAgjAR0I/hoAQhmgagvh1Qgwh3AjiNQAkiMBhhQQBihRBnAaIfhH/QBnAaAwB3QAvB1gjCNQgkCMhiBSQhKA8hNAAQgZAAgZgGg");
	var mask_graphics_53 = new cjs.Graphics().p("EAhuASIMggYgIOQhogbgyh2Qgyh3AkiNQAkiMBjhQQBkhQBqAbMAgYAINQBpAbAyB3QAyB2gkCMQgkCNhkBRQhLA7hOAAQgaAAgbgGg");
	var mask_graphics_54 = new cjs.Graphics().p("EAipASXMghDgIZQhqgbgzh2Qg0h4AkiMQAkiNBlhPQBlhQBsAbMAhCAIYQBsAcA0B3QAyB2gjCNQgkCMhlBRQhMA7hPAAQgbAAgcgHg");
	var mask_graphics_55 = new cjs.Graphics().p("EAjTASiMghhgIgQhugcgyh2Qg1h5AkiMQAjiMBnhPQBmhQBtAcMAhhAIfQBuAcA0B4QA0B2gkCNQgjCMhnBRQhMA6hQAAQgcAAgcgHg");
	var mask_graphics_56 = new cjs.Graphics().p("EAjsASpMghzgIlQhvgcgzh3Qg1h4AjiNQAkiMBnhPQBnhPBuAcMAhzAIkQBvAcA1B4QA0B2gjCNQgkCMhnBRQhNA6hQAAQgcAAgdgHg");
	var mask_graphics_57 = new cjs.Graphics().p("EAj0ASqMgh5gInQhugcg0h2Qg2h4AkiNQAkiMBnhPQBnhQBvAcMAh5AImQBuAcA2B5QA1B2gkCNQgkCMhnBRQhNA6hQAAQgdAAgdgIg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(13).to({graphics:mask_graphics_13,x:12.4086,y:68.3905}).wait(1).to({graphics:mask_graphics_14,x:49.3312,y:72.5003}).wait(1).to({graphics:mask_graphics_15,x:80.5856,y:75.9797}).wait(1).to({graphics:mask_graphics_16,x:100.3205,y:78.8812}).wait(1).to({graphics:mask_graphics_17,x:109.4846,y:81.2571}).wait(1).to({graphics:mask_graphics_18,x:116.8239,y:83.1598}).wait(1).to({graphics:mask_graphics_19,x:122.5406,y:84.6418}).wait(1).to({graphics:mask_graphics_20,x:126.837,y:85.7555}).wait(1).to({graphics:mask_graphics_21,x:129.9158,y:86.5536}).wait(1).to({graphics:mask_graphics_22,x:131.9798,y:87.0886}).wait(1).to({graphics:mask_graphics_23,x:133.2317,y:87.4131}).wait(1).to({graphics:mask_graphics_24,x:133.8746,y:87.5797}).wait(1).to({graphics:mask_graphics_25,x:134.1115,y:87.6411}).wait(1).to({graphics:mask_graphics_26,x:135.3949,y:88.0492}).wait(1).to({graphics:mask_graphics_27,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_28,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_29,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_30,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_31,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_32,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_33,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_34,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_35,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_36,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_37,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_38,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_39,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_40,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_41,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_42,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_43,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_44,x:135.3951,y:88.0494}).wait(1).to({graphics:mask_graphics_45,x:135.3949,y:88.0492}).wait(1).to({graphics:mask_graphics_46,x:156.2313,y:93.1822}).wait(1).to({graphics:mask_graphics_47,x:175.2674,y:97.8712}).wait(1).to({graphics:mask_graphics_48,x:192.4985,y:102.1156}).wait(1).to({graphics:mask_graphics_49,x:207.921,y:105.9147}).wait(1).to({graphics:mask_graphics_50,x:221.5326,y:109.2682}).wait(1).to({graphics:mask_graphics_51,x:233.3318,y:112.1754}).wait(1).to({graphics:mask_graphics_52,x:243.3172,y:114.636}).wait(1).to({graphics:mask_graphics_53,x:251.488,y:116.6497}).wait(1).to({graphics:mask_graphics_54,x:257.8437,y:118.2161}).wait(1).to({graphics:mask_graphics_55,x:262.3837,y:119.3352}).wait(1).to({graphics:mask_graphics_56,x:265.1078,y:120.0067}).wait(1).to({graphics:mask_graphics_57,x:266.0346,y:120.153}).wait(3));

	// Layer_3
	this.instance = new lib.scribble1_2();
	this.instance.setTransform(191.15,126.45,1,1,0,0,0,68.2,37.5);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).wait(47));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("ACgISQhnhUgbiOQgbiPBBh1QBDh0B5gXMAk3gG+QB4gXBoBUQBpBWAbCOQAbCOhDB0QhBB1h5AXMgk3AG/QgZAFgZAAQhdAAhThEg");
	var mask_1_graphics_2 = new cjs.Graphics().p("ACeITQhnhUgbiOQgbiPBBh1QBDh0B4gXMAkygG9QB4gXBoBUQBpBWAbCOQAbCOhDB0QhBB1h4AXMgkzAG+QgZAFgZAAQhcAAhThEg");
	var mask_1_graphics_3 = new cjs.Graphics().p("ACXIWQhnhUgbiPQgaiOA/h1QBDh0B3gWMAkkgG7QB3gXBnBUQBpBWAbCOQAaCPhCBzQhAB2h4AWMgkkAG7QgZAFgYAAQhcAAhShEg");
	var mask_1_graphics_4 = new cjs.Graphics().p("ACKIbQhmhUgbiPQgaiOA/h2QBChzB2gWMAkLgG2QB2gXBmBVQBoBWAbCOQAbCOhCBzQhAB2h2AWMgkLAG2QgZAFgXAAQhcAAhShEg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AB5IiQhlhVgaiOQgbiOA+h2QBAhzB0gWMAjqgGvQB0gWBlBUQBmBWAbCPQAbCOhABzQg/B1h0AWMgjpAGwQgYAEgXAAQhbAAhRhEg");
	var mask_1_graphics_6 = new cjs.Graphics().p("ABjIrQhjhVgaiPQgbiOA8h1QA+hyBygWMAi+gGnQBygWBjBVQBlBWAbCPQAbCOg/ByQg9B1hyAWMgi9AGnQgXAFgXAAQhZAAhQhFg");
	var mask_1_graphics_7 = new cjs.Graphics().p("ABII2QhhhWgbiOQgbiOA8h1QA7hyBvgVMAiIgGeQBwgVBhBWQBjBWAbCPQAbCOg9ByQg7B1hvAVMgiIAGdQgWAEgVAAQhYAAhPhFg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AAoJCQhehVgbiPQgbiOA4h0QA6hyBsgUMAhIgGSQBsgUBfBWQBhBXAbCOQAbCOg6ByQg5B0hsAVMghJAGRQgUAEgVAAQhVAAhOhHg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AADJRQhchWgbiOQgbiPA2hzQA4hyBngTMAgAgGEQBogUBdBXQBdBXAbCOQAbCOg3ByQg2B0hpATI//GEQgTAEgTAAQhUAAhMhIg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AgmJiQhahXgbiOQgbiPAzhzQA1hxBjgSIetl0QBkgTBZBXQBbBYAbCOQAbCOg1BxQgzBzhkATI+tF0QgRADgSAAQhRAAhJhIg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AhVJ1QhWhYgbiOQgbiPAwhyQAxhxBfgSIdPlhQBggSBWBXQBXBZAbCOQAbCNgxBxQgwBzhgASI9QFiQgQADgQAAQhNAAhIhJg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AiJKJQhThYgbiOQgbiPAthxQAthxBagRIbplOQBagRBSBYQBUBaAbCNQAbCPgtBwQgtByhaARI7pFPQgPACgOAAQhKAAhGhLg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AjCKgQhOhZgbiOQgbiPAohxQAphvBVgQIZ4k5QBVgQBOBZQBQBaAaCNQAbCPgpBvQgoBxhVAQI54E6QgNACgMAAQhHAAhEhMg");
	var mask_1_graphics_14 = new cjs.Graphics().p("Aj6K5QhLhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhAhOg");
	var mask_1_graphics_15 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_17 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_18 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_21 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_22 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_23 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_24 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_25 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_26 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_27 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_28 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_30 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_31 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_32 = new cjs.Graphics().p("Aj7K5QhKhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Aj6K5QhLhagaiOQgbiPAjhwQAlhuBPgPIX+kiQBOgPBKBaQBMBbAbCOQAaCOgkBvQgkBwhPAPI3+EiQgLACgLAAQhDAAhAhOg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AkCK6QhKhZgbiPQgbiOAkhwQAlhvBOgPIYAkiQBOgPBKBaQBMBbAbCNQAaCPglBvQgjBwhPAPI4AEiQgLADgLAAQhDAAhAhPg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AkaK+QhKhagbiOQgbiOAkhwQAlhvBPgPIYEkjQBPgPBKBaQBMBbAaCNQAbCPglBvQgkBwhOAPI4FEjQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AlBLFQhLhagbiOQgbiPAkhwQAmhvBPgPIYMkkQBPgPBLBaQBLBbAbCNQAbCPglBuQgkBxhPAPI4NElQgLACgLAAQhDAAhBhOg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Al5LOQhLhagaiOQgbiOAkhxQAmhuBQgPIYXknQBPgPBLBaQBMBbAbCNQAbCOgmBvQgkBxhQAPI4XEnQgLACgMAAQhDAAhChOg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AnALaQhLhagbiOQgbiOAlhxQAnhvBQgPIYlkpQBQgPBMBaQBMBaAbCOQAbCOgmBvQglBwhRAQI4lEpQgLADgMAAQhEAAhChOg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AoWLoQhMhZgbiOQgbiPAmhwQAnhvBRgQIY2ksQBRgPBMBZQBNBbAbCNQAbCPgnBvQgmBwhRAQI42EtQgMACgLAAQhFAAhChOg");
	var mask_1_graphics_40 = new cjs.Graphics().p("Ap9L5QhMhZgbiOQgbiPAmhwQAohvBSgQIZKkvQBSgQBNBZQBOBaAbCOQAbCOgoBwQgmBwhSAQI5LEwQgMADgMAAQhFAAhDhOg");
	var mask_1_graphics_41 = new cjs.Graphics().p("ArzMNQhOhZgaiOQgbiPAnhwQAphwBTgQIZhkzQBUgQBNBZQBPBZAbCPQAbCOgpBvQgnBxhTAQI5iE1QgMACgMAAQhHAAhDhNg");
	var mask_1_graphics_42 = new cjs.Graphics().p("At5MjQhOhYgbiPQgbiOAohxQAphwBVgQIZ8k4QBVgQBOBZQBQBZAbCOQAbCPgqBvQgoBxhVAQI58E6QgMACgNAAQhHAAhEhNg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AuyM8QhPhYgbiPQgbiOAphxQArhwBWgQIaZk+QBWgQBQBYQBRBZAaCPQAbCOgqBwQgqBxhWAQI6ZE/QgNADgNAAQhIAAhFhNg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AvFNYQhRhYgbiPQgaiOAqhxQAshwBYgRIa5lEQBYgRBRBZQBSBZAbCOQAbCPgsBvQgrByhXAQI66FFQgOADgNAAQhKAAhFhMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AvaN2QhShYgbiOQgbiPAshxQAthwBagRIbdlLQBagRBSBYQBTBZAbCPQAbCOgtBwQgsByhaARI7dFLQgOADgOAAQhLAAhGhMg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AvwOMQhUhYgbiOQgbiPAthyQAvhwBcgRIcDlSQBcgRBTBXQBVBZAbCPQAbCOgvBwQgtByhbARI8EFTQgPADgPAAQhLAAhHhLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:297.871,y:59.7553}).wait(1).to({graphics:mask_1_graphics_2,x:297.0362,y:59.8601}).wait(1).to({graphics:mask_1_graphics_3,x:294.53,y:60.174}).wait(1).to({graphics:mask_1_graphics_4,x:290.353,y:60.6973}).wait(1).to({graphics:mask_1_graphics_5,x:284.5053,y:61.43}).wait(1).to({graphics:mask_1_graphics_6,x:276.9871,y:62.3721}).wait(1).to({graphics:mask_1_graphics_7,x:267.7985,y:63.5238}).wait(1).to({graphics:mask_1_graphics_8,x:256.9399,y:64.8852}).wait(1).to({graphics:mask_1_graphics_9,x:244.4114,y:66.4563}).wait(1).to({graphics:mask_1_graphics_10,x:230.2136,y:68.2375}).wait(1).to({graphics:mask_1_graphics_11,x:214.347,y:70.2288}).wait(1).to({graphics:mask_1_graphics_12,x:196.8125,y:72.4305}).wait(1).to({graphics:mask_1_graphics_13,x:177.6111,y:74.8428}).wait(1).to({graphics:mask_1_graphics_14,x:157.29,y:77.5247}).wait(1).to({graphics:mask_1_graphics_15,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_16,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_17,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_18,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_19,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_20,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_21,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_22,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_23,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_24,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_25,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_26,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_27,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_28,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_29,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_30,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_31,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_32,x:157.2901,y:77.5248}).wait(1).to({graphics:mask_1_graphics_33,x:157.29,y:77.5247}).wait(1).to({graphics:mask_1_graphics_34,x:156.6881,y:77.6543}).wait(1).to({graphics:mask_1_graphics_35,x:154.8822,y:78.0429}).wait(1).to({graphics:mask_1_graphics_36,x:151.8723,y:78.6907}).wait(1).to({graphics:mask_1_graphics_37,x:147.6585,y:79.5974}).wait(1).to({graphics:mask_1_graphics_38,x:142.2408,y:80.7633}).wait(1).to({graphics:mask_1_graphics_39,x:135.6193,y:82.1882}).wait(1).to({graphics:mask_1_graphics_40,x:127.794,y:83.8722}).wait(1).to({graphics:mask_1_graphics_41,x:118.7651,y:85.8152}).wait(1).to({graphics:mask_1_graphics_42,x:108.5325,y:88.0172}).wait(1).to({graphics:mask_1_graphics_43,x:87.8019,y:90.4782}).wait(1).to({graphics:mask_1_graphics_44,x:60.5162,y:93.1982}).wait(1).to({graphics:mask_1_graphics_45,x:30.6318,y:96.1771}).wait(1).to({graphics:mask_1_graphics_46,x:9.2927,y:98.2839}).wait(14));

	// Layer_2
	this.instance_1 = new lib.scribble1_1();
	this.instance_1.setTransform(210.65,109.6,1,1,0,0,0,87.7,39.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.Page_indicator_dot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {selected:1,deselected:17};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(19));

	// Layer_2
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(0,0,0.75,0.75);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.25,alpha:1},16,cjs.Ease.cubicInOut).to({scaleX:0.75,scaleY:0.75,alpha:0},18,cjs.Ease.cubicInOut).wait(1));

	// Layer_1
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(0,0,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.25,scaleY:1.25,alpha:0},16,cjs.Ease.cubicInOut).to({scaleX:0.75,scaleY:0.75,alpha:1},18,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.5,-4.5,9.2,9.2);


(lib.Page_indicator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AAUA7Ig1g2QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBQAAgCACgCIA1g2QABgCAEAAQAAAAABAAQABAAAAABQABAAAAAAQABABAAAAIAEAEQAEAFgEAEIguAtIAvAuQAEAEgEAFIgFAEQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQgEAAgBgCg");
	this.shape.setTransform(-3.7375,4.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D4").s().p("AAUA7Ig1g2QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBQAAgCACgCIA1g2QABgCAEAAQAAAAABAAQABAAAAABQABAAAAAAQABABAAAAIAEAEQAEAFgEAEIguAtIAvAuQAEAEgEAFIgFAEQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQgEAAgBgCg");
	this.shape_1.setTransform(88.6375,4.825,1,1,0,0,180);

	this.dot_5 = new lib.Page_indicator_dot();
	this.dot_5.name = "dot_5";
	this.dot_5.setTransform(73.2,4.8);

	this.dot_4 = new lib.Page_indicator_dot();
	this.dot_4.name = "dot_4";
	this.dot_4.setTransform(57.9,4.8);

	this.dot_3 = new lib.Page_indicator_dot();
	this.dot_3.name = "dot_3";
	this.dot_3.setTransform(42.6,4.8);

	this.dot_2 = new lib.Page_indicator_dot();
	this.dot_2.name = "dot_2";
	this.dot_2.setTransform(27.3,4.8);

	this.dot_1 = new lib.Page_indicator_dot();
	this.dot_1.name = "dot_1";
	this.dot_1.setTransform(12,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.dot_1},{t:this.dot_2},{t:this.dot_3},{t:this.dot_4},{t:this.dot_5},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_indicator, new cjs.Rectangle(-7.3,-1.2,99.6,12.1), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.img5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub1 = new lib.img5Sub2();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-85,370.45,1,1,0,0,0,22.5,-22.1);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	// shadow
	this.sub2Shadow = new lib.angledShadow_1();
	this.sub2Shadow.name = "sub2Shadow";
	this.sub2Shadow.setTransform(-85,370.5,0.54,0.54,0,0,0,21.7,89.1);

	this.timeline.addTween(cjs.Tween.get(this.sub2Shadow).wait(1));

	// sub1
	this.sub2 = new lib.img5Sub1();
	this.sub2.name = "sub2";
	this.sub2.setTransform(-88.25,371.1,1,1,0,0,0,29.4,-6);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub2
	this.sub3 = new lib.img5Sub3();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-63.7,276.9,1,1,0,0,0,43.2,-15.6);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5, new cjs.Rectangle(-125.6,133.5,199.5,262.5), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img4Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-87.5,153,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img4Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(-20,203,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img4Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-36,328.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4, new cjs.Rectangle(-118.8,122.3,188.7,271.09999999999997), null);


(lib.img3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img3Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-87.5,153,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img3Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(-20,203,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img3Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-36,328.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3, new cjs.Rectangle(-118.8,122.3,188.7,271.09999999999997), null);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img2Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-87.5,153,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img2Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(-20,203,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img2Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-36,328.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2, new cjs.Rectangle(-118.8,122.3,188.7,271.09999999999997), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img1Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(-87.5,153,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img1Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(-20,203,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img1Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(-36,328.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(-118.8,122.3,184.3,271.09999999999997), null);


(lib.gridSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,-1,250,2,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.gridSubSub();
	this.sub.name = "sub";
	this.sub.setTransform(128,0,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridSub, new cjs.Rectangle(-0.5,-0.5,257,1), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridSub();
	this.instance.setTransform(128,120,1,1,0,0,0,128,0);

	this.instance_1 = new lib.gridSub();
	this.instance_1.setTransform(128,105,1,1,0,0,0,128,0);

	this.instance_2 = new lib.gridSub();
	this.instance_2.setTransform(128,90,1,1,0,0,0,128,0);

	this.instance_3 = new lib.gridSub();
	this.instance_3.setTransform(128,75,1,1,0,0,0,128,0);

	this.instance_4 = new lib.gridSub();
	this.instance_4.setTransform(128,60,1,1,0,0,0,128,0);

	this.instance_5 = new lib.gridSub();
	this.instance_5.setTransform(128,45,1,1,0,0,0,128,0);

	this.instance_6 = new lib.gridSub();
	this.instance_6.setTransform(128,30,1,1,0,0,0,128,0);

	this.instance_7 = new lib.gridSub();
	this.instance_7.setTransform(128,15,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_8 = new lib.gridSub();
	this.instance_8.setTransform(128,0,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,257,121), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(69.6,128.95,1.1117,1.1117,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(-6.1,207.55,1.1117,1.1117,0,0,0,125.9,52.6);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(-6.1,57.35,1.1117,1.1117,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-146.6,-11.5,285.7,294.5), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		exportRoot.mainMC.logo.visible=false;
	}
	this.frame_65 = function() {
		exportRoot.animStart();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgFJBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_15 = new cjs.Graphics().p("EgFUBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_16 = new cjs.Graphics().p("EgF3BJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_17 = new cjs.Graphics().p("EgGxBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_18 = new cjs.Graphics().p("EgICBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_19 = new cjs.Graphics().p("EgJqBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_20 = new cjs.Graphics().p("EgLqBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_21 = new cjs.Graphics().p("EgNpBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_22 = new cjs.Graphics().p("EgPSBJ2IAAqHMA3xAAAIAAKHg");
	var mask_graphics_23 = new cjs.Graphics().p("EgQjBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_24 = new cjs.Graphics().p("EgRdBJ2IAAqHMA3xAAAIAAKHg");
	var mask_graphics_25 = new cjs.Graphics().p("EgR/BJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_26 = new cjs.Graphics().p("EgSLBJ2IAAqHMA3wAAAIAAKHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:323.9456,y:472.6093}).wait(1).to({graphics:mask_graphics_15,x:322.7869,y:472.6093}).wait(1).to({graphics:mask_graphics_16,x:319.3108,y:472.6093}).wait(1).to({graphics:mask_graphics_17,x:313.5174,y:472.6093}).wait(1).to({graphics:mask_graphics_18,x:305.4067,y:472.6093}).wait(1).to({graphics:mask_graphics_19,x:294.9786,y:472.6093}).wait(1).to({graphics:mask_graphics_20,x:282.2331,y:472.6093}).wait(1).to({graphics:mask_graphics_21,x:269.4876,y:472.6093}).wait(1).to({graphics:mask_graphics_22,x:259.0595,y:472.6093}).wait(1).to({graphics:mask_graphics_23,x:250.9487,y:472.6093}).wait(1).to({graphics:mask_graphics_24,x:245.1553,y:472.6093}).wait(1).to({graphics:mask_graphics_25,x:241.6793,y:472.6093}).wait(1).to({graphics:mask_graphics_26,x:240.5206,y:472.6093}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-3.25,909.35,2.9988,2.9988,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({regX:0.2,x:212.45},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:173.3,y:75.1},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(259.65,912.6,0.608,0.608,0,0,0,485.9,405.6);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(258.7,913.05,0.1812,0.1812,0,0,0,-39.5,1.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:2.9988,scaleY:2.9988,x:258.6,y:912.95},13,cjs.Ease.quadOut).to({x:91.9},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgoTChGMAAAlCLMBQnAAAMAAAFCLg");
	this.shape.setTransform(258,1031);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(250.1,326.05,0.608,1.0591,0,0,0,0.1,0.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({regX:0,regY:0.9,scaleX:1,scaleY:1.1007,x:301.45,y:386.55,alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187,-110.7,978.8,2174.2);


(lib.doodle5_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,18,14,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(9,7,1,1,0,0,0,9,7);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_3, new cjs.Rectangle(0,0,18.1,14), null);


(lib.doodle5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,17,16,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(8.3,7.6,1,1,0,0,0,8.3,7.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_2, new cjs.Rectangle(0,0,16.8,15.3), null);


(lib.doodle5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,28,28,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(13.6,14,1,1,0,0,0,13.6,14);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_1, new cjs.Rectangle(0,0,27.1,28), null);


(lib.doodle5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("EAKpApSQgIgLgDgQQgEgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADAQQADARgEANQgEAMgIACIirAhIgCAAQgIAAgHgIg");
	var mask_graphics_21 = new cjs.Graphics().p("EAKiApTQgIgLgDgQQgEgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEAMgIACIirAhIgCABQgIAAgHgJg");
	var mask_graphics_22 = new cjs.Graphics().p("EAKQApWQgJgLgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADARQAEAQgEANQgEAMgJACIiqAhIgDABQgHAAgHgJg");
	var mask_graphics_23 = new cjs.Graphics().p("EAJ2ApaQgIgLgEgQQgDgQAEgNQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgIABIirAhIgCABQgIAAgHgJg");
	var mask_graphics_24 = new cjs.Graphics().p("EAJdApeQgJgLgDgQQgDgQAEgNQAEgNAIgCICrghQAIgBAJAKQAIAKADARQAEAQgEANQgEANgJABIiqAiIgDAAQgHAAgHgJg");
	var mask_graphics_25 = new cjs.Graphics().p("EAJKAphQgJgLgDgQQgDgQAEgNQAEgNAJgCICqghQAJgBAIAKQAIAKAEARQADAQgEANQgEANgJABIiqAiIgCAAQgIAAgHgJg");
	var mask_graphics_26 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_27 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_28 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_29 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_30 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_31 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_32 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_33 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_34 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_35 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_36 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_37 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_38 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_39 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_40 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_41 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_42 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_43 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_44 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_45 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_46 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_47 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_48 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_49 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_50 = new cjs.Graphics().p("EAJCApiQgJgKgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADAQQAEARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_graphics_51 = new cjs.Graphics().p("EAI+ApjQgJgKgDgRQgDgQAEgNQAEgNAIgBICrghQAIgCAJAKQAIALADAQQAEAQgEANQgEANgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_graphics_52 = new cjs.Graphics().p("EAI1AplQgIgLgDgQQgDgRADgMQAEgNAJgCICqghQAJgCAIALQAJAKADAQQADARgEANQgEAMgIACIirAhIgCAAQgHAAgIgIg");
	var mask_graphics_53 = new cjs.Graphics().p("EAImApnQgIgLgDgQQgDgQADgNQAEgNAJgCICqghQAJgBAJAKQAIAKADARQADAQgEANQgEANgIABIirAiIgCAAQgHAAgIgJg");
	var mask_graphics_54 = new cjs.Graphics().p("EAIRApqQgJgKgDgQQgDgRAEgMQAEgNAJgCICqghQAJgCAIALQAIAKAEAQQADARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_graphics_55 = new cjs.Graphics().p("EAH8ApuQgIgLgEgQQgDgQAEgNQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgJABIiqAhIgCABQgIAAgHgJg");
	var mask_graphics_56 = new cjs.Graphics().p("EAHtApwQgIgKgDgRQgDgQAEgNQADgNAJgBICqghQAJgCAJAKQAIALADAQQADAQgEANQgEANgIACIirAhIgCAAQgHAAgIgJg");
	var mask_graphics_57 = new cjs.Graphics().p("EAHkApyQgIgLgEgQQgDgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgJABIiqAhIgCABQgIAAgHgJg");
	var mask_graphics_58 = new cjs.Graphics().p("EAHfApzQgJgLgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADAQQAEARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgIg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:88.328,y:265.0434}).wait(1).to({graphics:mask_graphics_21,x:87.6448,y:265.1535}).wait(1).to({graphics:mask_graphics_22,x:85.7777,y:265.4541}).wait(1).to({graphics:mask_graphics_23,x:83.2273,y:265.8647}).wait(1).to({graphics:mask_graphics_24,x:80.6769,y:266.2753}).wait(1).to({graphics:mask_graphics_25,x:78.8099,y:266.5759}).wait(1).to({graphics:mask_graphics_26,x:78.103,y:266.7184}).wait(1).to({graphics:mask_graphics_27,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_28,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_29,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_30,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_31,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_32,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_33,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_34,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_35,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_36,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_37,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_38,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_39,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_40,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_41,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_42,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_43,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_44,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_45,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_46,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_47,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_48,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_49,x:78.103,y:266.7184}).wait(1).to({graphics:mask_graphics_50,x:77.9916,y:266.7366}).wait(1).to({graphics:mask_graphics_51,x:77.5898,y:266.8017}).wait(1).to({graphics:mask_graphics_52,x:76.7468,y:266.9384}).wait(1).to({graphics:mask_graphics_53,x:75.2484,y:267.1814}).wait(1).to({graphics:mask_graphics_54,x:73.1011,y:267.5297}).wait(1).to({graphics:mask_graphics_55,x:71.0241,y:267.8665}).wait(1).to({graphics:mask_graphics_56,x:69.5549,y:268.1048}).wait(1).to({graphics:mask_graphics_57,x:68.6205,y:268.2563}).wait(1).to({graphics:mask_graphics_58,x:68.078,y:268.3434}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance = new lib.doodle5_2();
	this.instance.setTransform(146.05,529.25,0.8671,0.8671,35.9343,0,0,8.6,7.7);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("EAJzAqoQgHgFgBgIQgBgHAEgHQAFgGAIgBQAHgCAHAFQAGAFACAHQABAIgFAHQgEAGgIABIgDABQgGAAgFgEg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAJsAqqQgIgGgCgLQgBgKAGgIQAGgIAKgCQAKgCAIAGQAJAGABALQACAKgGAIQgGAIgKACIgFAAQgHAAgHgEg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAJZAqvQgOgLgDgRQgDgRAKgOQALgPARgCQARgDAOAKQAPALADARQACARgKAOQgKAPgSACIgHABQgNAAgLgIg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAI4Aq3QgYgRgFgeQgFgdASgYQARgYAegFQAdgFAZASQAYARAFAeQAEAdgRAZQgSAYgdAEIgMABQgXAAgTgOg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAIbAq/QghgYgHgoQgGgoAYghQAYghAogHQAogGAhAYQAiAYAGAoQAHAogYAiQgYAhgoAGIgRABQgfAAgagTg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAIKArEQgmgcgIgvQgHguAcgmQAbgmAvgIQAugHAmAcQAnAbAHAvQAIAvgcAmQgbAmgvAHQgKACgJAAQgkAAgegWg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAICArGQgogegIgxQgIgxAdgpQAegoAxgJQAxgHApAdQApAeAIAxQAIAygeAoQgdApgxAHQgLACgKAAQgmAAgggXg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAICArHQgpgegIgyQgIgxAegpQAegpAxgIQAygIApAeQAqAdAIAyQAIAygeApQgeApgxAIQgLACgKAAQgmAAghgYg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAIFArGQgogdgIgxQgIgwAdgoQAdgoAxgJQAxgHAoAdQAoAdAIAxQAIAxgdAoQgdAogxAIQgKABgKAAQglAAgggXg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAILArFQgngcgHgvQgHguAbgnQAcgmAvgIQAugHAnAcQAmAcAIAuQAHAvgbAnQgcAmgvAHQgKACgJAAQgkAAgegWg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAIUArCQgjgagHgrQgHgrAagjQAagjArgHQArgHAjAaQAkAZAHArQAHAsgaAjQgaAjgrAHIgSABQghAAgcgUg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAIkAq+QgfgWgGgmQgGglAWgfQAWgfAmgGQAlgGAfAXQAfAWAGAlQAGAmgWAfQgXAeglAGIgQABQgcAAgYgRg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAI3Aq4QgYgRgFgfQgFgdASgZQASgZAegEQAegFAYASQAZASAFAeQAFAegSAYQgSAZgeAEIgMABQgXAAgUgOg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAJLAqzQgSgOgEgWQgDgWANgTQAOgSAWgEQAWgEATAOQASANAEAXQAEAWgOATQgNASgWAEIgKAAQgRAAgPgKg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAJbAquQgNgJgDgRQgDgRAKgNQAKgOARgDQAQgCAOAKQANAKADAQQADARgKAOQgKANgQADIgHAAQgNAAgLgIg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAJmAqrQgKgHgCgMQgCgNAHgKQAIgKAMgCQANgCAKAHQAKAIACAMQACANgHAKQgIAKgMACIgFAAQgKAAgIgGg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAJuAqpQgIgFgCgKQgBgKAGgIQAFgHAKgCQAJgCAIAGQAIAGACAKQABAJgFAIQgGAIgKACIgEAAQgHAAgGgFg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAJzAqoQgHgFgBgIQgBgHAEgHQAFgGAIgBQAHgCAHAFQAGAFACAHQABAIgFAHQgEAGgIABIgDABQgGAAgFgEg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:65.679,y:273.1519}).wait(1).to({graphics:mask_1_graphics_23,x:65.9616,y:273.4331}).wait(1).to({graphics:mask_1_graphics_24,x:66.8163,y:274.2836}).wait(1).to({graphics:mask_1_graphics_25,x:68.2748,y:275.7349}).wait(1).to({graphics:mask_1_graphics_26,x:69.5655,y:277.0192}).wait(1).to({graphics:mask_1_graphics_27,x:70.3068,y:277.757}).wait(1).to({graphics:mask_1_graphics_28,x:70.6535,y:278.1019}).wait(1).to({graphics:mask_1_graphics_29,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_30,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_31,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_32,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_33,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_34,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_35,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_36,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_37,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_38,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_39,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_40,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_41,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_42,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_43,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_44,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_45,x:70.845,y:278.2564}).wait(1).to({graphics:mask_1_graphics_46,x:70.7146,y:278.1275}).wait(1).to({graphics:mask_1_graphics_47,x:70.4547,y:277.8703}).wait(1).to({graphics:mask_1_graphics_48,x:70.0104,y:277.4309}).wait(1).to({graphics:mask_1_graphics_49,x:69.3206,y:276.7486}).wait(1).to({graphics:mask_1_graphics_50,x:68.4094,y:275.8472}).wait(1).to({graphics:mask_1_graphics_51,x:67.4961,y:274.9437}).wait(1).to({graphics:mask_1_graphics_52,x:66.7784,y:274.2339}).wait(1).to({graphics:mask_1_graphics_53,x:66.2716,y:273.7325}).wait(1).to({graphics:mask_1_graphics_54,x:65.9267,y:273.3914}).wait(1).to({graphics:mask_1_graphics_55,x:65.679,y:273.1519}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_1 = new lib.doodle5_3();
	this.instance_1.setTransform(133.5,542.5,0.8671,0.8671,35.9343,0,0,9.2,7);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_16 = new cjs.Graphics().p("EAKIAqMQgNgRgFgaQgFgaAGgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAVQgGAUgOACIkQA1IgDABQgMAAgMgOg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EAKFAqMQgNgRgFgaQgGgaAHgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAbQAFAagGAUQgGAUgOADIkQA1IgEAAQgLAAgMgOg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EAJ5AqOQgNgQgFgaQgGgaAHgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAUQgGAVgOACIkQA1IgEABQgLAAgMgPg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EAJeAqUQgOgRgFgaQgFgaAHgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAVQgGAUgOADIkQA0IgEABQgMAAgLgOg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EAIxAqcQgNgRgFgaQgFgaAGgUQAGgVAOgCIEQg1QAOgDANARQANAQAFAaQAGAbgHAUQgGAUgOADIkPA1IgEAAQgMAAgMgOg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EAIJAqkQgNgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QANgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkPA1IgEAAQgMAAgMgOg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EAHxAqoQgNgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QANgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkPA1IgEAAQgMAAgMgOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAHjAqrQgOgRgFgaQgFgaAHgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAaQAFAbgGAUQgGAUgOADIkQA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAHeAqsQgOgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QAOgDANARQAOARAFAaQAFAagGAUQgHAVgOACIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAHTAqvQgOgRgFgaQgFgaAHgUQAGgVAOgDIEPg0QAOgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkQA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAHAAqzQgNgRgFgaQgFgaAGgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAaQAFAbgGAUQgGAUgOADIkQA1IgEAAQgLAAgMgOg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAGjAq6QgNgRgFgaQgFgaAGgVQAGgUAOgDIEQg1QAOgCANAQQANARAFAaQAFAagGAVQgGAUgOADIkPA0IgEABQgMAAgMgOg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAGCArBQgOgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QAOgDANARQAOARAFAaQAFAagGAUQgHAVgOACIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAFlArIQgNgRgFgaQgFgaAGgUQAGgVAOgDIEPg0QAOgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkQA1IgDAAQgMAAgMgOg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAFRArMQgNgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QANgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkPA1IgEABQgMAAgMgPg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAFEArPQgNgQgFgaQgFgbAGgUQAGgUAOgDIEPg1QAOgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkQA1IgDABQgMAAgMgPg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAE7ArRQgNgRgFgaQgFgaAGgUQAGgVAOgCIEQg1QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgMgOg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_2_graphics_16,x:97.0494,y:271.3687}).wait(1).to({graphics:mask_2_graphics_17,x:96.7375,y:271.4284}).wait(1).to({graphics:mask_2_graphics_18,x:95.5374,y:271.6574}).wait(1).to({graphics:mask_2_graphics_19,x:92.8225,y:272.1755}).wait(1).to({graphics:mask_2_graphics_20,x:88.3728,y:273.0247}).wait(1).to({graphics:mask_2_graphics_21,x:84.3627,y:273.79}).wait(1).to({graphics:mask_2_graphics_22,x:81.9606,y:274.2484}).wait(1).to({graphics:mask_2_graphics_23,x:80.6744,y:274.4937}).wait(1).to({graphics:mask_2_graphics_24,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_25,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_26,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_27,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_28,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_29,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_30,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_31,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_32,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_33,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_34,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_35,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_36,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_37,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_38,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_39,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_40,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_41,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_42,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_43,x:80.6744,y:274.4937}).wait(1).to({graphics:mask_2_graphics_44,x:80.525,y:274.528}).wait(1).to({graphics:mask_2_graphics_45,x:79.9976,y:274.6483}).wait(1).to({graphics:mask_2_graphics_46,x:78.9219,y:274.8938}).wait(1).to({graphics:mask_2_graphics_47,x:77.0439,y:275.3223}).wait(1).to({graphics:mask_2_graphics_48,x:74.1712,y:275.9778}).wait(1).to({graphics:mask_2_graphics_49,x:70.7931,y:276.7486}).wait(1).to({graphics:mask_2_graphics_50,x:67.9489,y:277.3976}).wait(1).to({graphics:mask_2_graphics_51,x:65.96,y:277.8514}).wait(1).to({graphics:mask_2_graphics_52,x:64.6491,y:278.1505}).wait(1).to({graphics:mask_2_graphics_53,x:63.7744,y:278.3187}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_2 = new lib.doodle5_1();
	this.instance_2.setTransform(144,542.15,0.8671,0.8671,35.9343,0,0,13.7,14.1);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160.6,600);


(lib.doodle4_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,64,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(31.7,1.5,1,1,0,0,0,31.7,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_4, new cjs.Rectangle(0,0.5,63.5,2.1), null);


(lib.doodle4_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,50,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(24.9,1.5,1,1,0,0,0,24.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_3, new cjs.Rectangle(0,0.5,50,2.1), null);


(lib.doodle4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,38,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(18.9,1.5,1,1,0,0,0,18.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_2, new cjs.Rectangle(0,0.5,37.7,2.1), null);


(lib.doodle4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(-3,0,25,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(10.2,1.5,1,1,0,0,0,10.2,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_1, new cjs.Rectangle(0,0.4,20.5,2.1), null);


(lib.doodle4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_51 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(22).call(this.frame_51).wait(1));

	// Layer_24 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_10 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_13 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_14 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_17 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_21 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_22 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AlydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AlkdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AlRdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_28 = new cjs.Graphics().p("Ak+dFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AkrdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AkYdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AkFdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AjydFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_33 = new cjs.Graphics().p("AjfdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_34 = new cjs.Graphics().p("AjMdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_35 = new cjs.Graphics().p("Ai5dFQglAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAlAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_36 = new cjs.Graphics().p("AizdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_37 = new cjs.Graphics().p("AijdFQgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_38 = new cjs.Graphics().p("AiGdFQgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_39 = new cjs.Graphics().p("AhgdFQgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAlAAAbARQAbASAAAZQAAAYgbARQgbASglAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AhAdFQgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AgrdFQgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AgfdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_43 = new cjs.Graphics().p("AgZdFQglAAgcgSQgagRAAgYQAAgZAagSQAcgRAlAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AgXdFQgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_graphics_10,x:-10.3787,y:186.0969}).wait(1).to({graphics:mask_graphics_11,x:-10.0143,y:186.0969}).wait(1).to({graphics:mask_graphics_12,x:-8.7011,y:186.0969}).wait(1).to({graphics:mask_graphics_13,x:-5.9458,y:186.0969}).wait(1).to({graphics:mask_graphics_14,x:-1.0489,y:186.0969}).wait(1).to({graphics:mask_graphics_15,x:5.9688,y:186.0969}).wait(1).to({graphics:mask_graphics_16,x:12.7569,y:186.0969}).wait(1).to({graphics:mask_graphics_17,x:17.5586,y:186.0969}).wait(1).to({graphics:mask_graphics_18,x:20.6125,y:186.0969}).wait(1).to({graphics:mask_graphics_19,x:22.4213,y:186.0969}).wait(1).to({graphics:mask_graphics_20,x:26.2275,y:186.0969}).wait(1).to({graphics:mask_graphics_21,x:30.0338,y:186.0969}).wait(1).to({graphics:mask_graphics_22,x:33.84,y:186.0969}).wait(1).to({graphics:mask_graphics_23,x:37.6463,y:186.0969}).wait(1).to({graphics:mask_graphics_24,x:41.4525,y:186.0969}).wait(1).to({graphics:mask_graphics_25,x:45.2588,y:186.0969}).wait(1).to({graphics:mask_graphics_26,x:47.6559,y:186.0969}).wait(1).to({graphics:mask_graphics_27,x:49.559,y:186.0969}).wait(1).to({graphics:mask_graphics_28,x:51.4622,y:186.0969}).wait(1).to({graphics:mask_graphics_29,x:53.3653,y:186.0969}).wait(1).to({graphics:mask_graphics_30,x:55.2684,y:186.0969}).wait(1).to({graphics:mask_graphics_31,x:57.1715,y:186.0969}).wait(1).to({graphics:mask_graphics_32,x:59.0747,y:186.0969}).wait(1).to({graphics:mask_graphics_33,x:60.9778,y:186.0969}).wait(1).to({graphics:mask_graphics_34,x:62.8809,y:186.0969}).wait(1).to({graphics:mask_graphics_35,x:64.784,y:186.0969}).wait(1).to({graphics:mask_graphics_36,x:65.3578,y:186.0969}).wait(1).to({graphics:mask_graphics_37,x:66.9227,y:186.0969}).wait(1).to({graphics:mask_graphics_38,x:69.8254,y:186.0969}).wait(1).to({graphics:mask_graphics_39,x:73.6024,y:186.0969}).wait(1).to({graphics:mask_graphics_40,x:76.8175,y:186.0969}).wait(1).to({graphics:mask_graphics_41,x:78.931,y:186.0969}).wait(1).to({graphics:mask_graphics_42,x:80.1647,y:186.0969}).wait(1).to({graphics:mask_graphics_43,x:80.7814,y:186.0969}).wait(1).to({graphics:mask_graphics_44,x:80.959,y:186.0969}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// Layer_20
	this.instance = new lib.doodle4_1();
	this.instance.setTransform(39,363,1.4122,1.4122);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({_off:true},35).wait(7));

	// Layer_23 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_11 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AlyerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AlterQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AlherQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAbASQAbARAAAZQAAAYgbASQgbARgmAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AlUerQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAlAAAbASQAbARAAAZQAAAYgbASQgbARglAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AlIerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAaASQAcARAAAZQAAAYgcASQgaARgmAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Ak8erQglAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAlAAILlAAQAmAAAbASQAbARAAAZQAAAYgbASQgbARgmAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AkverQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAlAAAbASQAbARAAAZQAAAYgbASQgbARglAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AknerQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AkRerQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AjperQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AiwerQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("Ah3erQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAlAAAbASQAbARAAAZQAAAYgbASQgbARglAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AhNerQgmAAgbgRQgagSAAgYQAAgZAagRQAbgSAmAAILlAAQAmAAAbASQAbARAAAZQAAAYgbASQgbARgmAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AgxerQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AgherQglAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAlAAILlAAQAmAAAbASQAbARAAAZQAAAYgbASQgbARgmAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AgYerQgmAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAmAAILlAAQAmAAAaASQAbARAAAZQAAAYgbASQgaARgmAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AgWerQglAAgbgRQgbgSAAgYQAAgZAbgRQAbgSAlAAILlAAQAmAAAbASQAbARAAAZQAAAYgbASQgbARgmAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_1_graphics_11,x:-34.5287,y:196.3219}).wait(1).to({graphics:mask_1_graphics_12,x:-34.023,y:196.3219}).wait(1).to({graphics:mask_1_graphics_13,x:-32.2397,y:196.3219}).wait(1).to({graphics:mask_1_graphics_14,x:-28.6027,y:196.3219}).wait(1).to({graphics:mask_1_graphics_15,x:-22.2535,y:196.3219}).wait(1).to({graphics:mask_1_graphics_16,x:-12.5406,y:196.3219}).wait(1).to({graphics:mask_1_graphics_17,x:-1.1191,y:196.3219}).wait(1).to({graphics:mask_1_graphics_18,x:8.4968,y:196.3219}).wait(1).to({graphics:mask_1_graphics_19,x:15.2213,y:196.3219}).wait(1).to({graphics:mask_1_graphics_20,x:19.6538,y:196.3219}).wait(1).to({graphics:mask_1_graphics_21,x:22.4213,y:196.3219}).wait(1).to({graphics:mask_1_graphics_22,x:24.9007,y:196.3219}).wait(1).to({graphics:mask_1_graphics_23,x:27.3801,y:196.3219}).wait(1).to({graphics:mask_1_graphics_24,x:29.8596,y:196.3219}).wait(1).to({graphics:mask_1_graphics_25,x:32.339,y:196.3219}).wait(1).to({graphics:mask_1_graphics_26,x:34.8185,y:196.3219}).wait(1).to({graphics:mask_1_graphics_27,x:37.2979,y:196.3219}).wait(1).to({graphics:mask_1_graphics_28,x:39.7773,y:196.3219}).wait(1).to({graphics:mask_1_graphics_29,x:42.2568,y:196.3219}).wait(1).to({graphics:mask_1_graphics_30,x:44.7362,y:196.3219}).wait(1).to({graphics:mask_1_graphics_31,x:46.7312,y:196.3219}).wait(1).to({graphics:mask_1_graphics_32,x:47.9709,y:196.3219}).wait(1).to({graphics:mask_1_graphics_33,x:49.2107,y:196.3219}).wait(1).to({graphics:mask_1_graphics_34,x:50.4504,y:196.3219}).wait(1).to({graphics:mask_1_graphics_35,x:51.6901,y:196.3219}).wait(1).to({graphics:mask_1_graphics_36,x:52.909,y:196.3219}).wait(1).to({graphics:mask_1_graphics_37,x:53.7424,y:196.3219}).wait(1).to({graphics:mask_1_graphics_38,x:55.9161,y:196.3219}).wait(1).to({graphics:mask_1_graphics_39,x:59.9255,y:196.3219}).wait(1).to({graphics:mask_1_graphics_40,x:65.6182,y:196.3219}).wait(1).to({graphics:mask_1_graphics_41,x:71.306,y:196.3219}).wait(1).to({graphics:mask_1_graphics_42,x:75.5604,y:196.3219}).wait(1).to({graphics:mask_1_graphics_43,x:78.3334,y:196.3219}).wait(1).to({graphics:mask_1_graphics_44,x:79.9893,y:196.3219}).wait(1).to({graphics:mask_1_graphics_45,x:80.8361,y:196.3219}).wait(1).to({graphics:mask_1_graphics_46,x:81.084,y:196.3219}).wait(1).to({graphics:null,x:0,y:0}).wait(5));

	// Layer_21
	this.instance_1 = new lib.doodle4_2();
	this.instance_1.setTransform(40.7,386.25,1.4122,1.4122,0,0,0,18.9,1.6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({_off:true},36).wait(5));

	// Layer_22 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("EgGMAgTQgmAAgbgRQgbgRAAgZQAAgZAbgRQAbgRAmAAILlAAQAlAAAbARQAbARAAAZQAAAZgbARQgbARglAAg");
	var mask_2_graphics_13 = new cjs.Graphics().p("EgGKAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_14 = new cjs.Graphics().p("EgGAAgTQgmAAgbgRQgbgRAAgZQAAgZAbgRQAbgRAmAAILlAAQAlAAAbARQAbARAAAZQAAAZgbARQgbARglAAg");
	var mask_2_graphics_15 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_16 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EgFyAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EgFoAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgE+AgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgEAAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgC6AgTQglAAgbgRQgbgRAAgZQAAgZAbgRQAbgRAlAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgB+AgTQgmAAgbgRQgbgRAAgZQAAgZAbgRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgBUAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgA4AgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgAnAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAbARQAbARAAAZQAAAZgbARQgbARgmAAg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgAeAgTQgmAAgbgRQgagRAAgZQAAgZAagRQAbgRAmAAILlAAQAmAAAaARQAcARAAAZQAAAZgcARQgaARgmAAg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EgAbAgTQgmAAgbgRQgbgRAAgZQAAgZAbgRQAbgRAmAAILlAAQAmAAAaARQAbARAAAZQAAAZgbARQgaARgmAAg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:-48.8878,y:206.7469}).wait(1).to({graphics:mask_2_graphics_13,x:-48.6193,y:206.7469}).wait(1).to({graphics:mask_2_graphics_14,x:-47.6885,y:206.7469}).wait(1).to({graphics:mask_2_graphics_15,x:-45.419,y:206.7469}).wait(1).to({graphics:mask_2_graphics_16,x:-39.0764,y:206.7469}).wait(1).to({graphics:mask_2_graphics_17,x:-29.2292,y:206.7469}).wait(1).to({graphics:mask_2_graphics_18,x:-16.2196,y:206.7469}).wait(1).to({graphics:mask_2_graphics_19,x:-3.181,y:206.7469}).wait(1).to({graphics:mask_2_graphics_20,x:7.0642,y:206.7469}).wait(1).to({graphics:mask_2_graphics_21,x:14.2999,y:206.7469}).wait(1).to({graphics:mask_2_graphics_22,x:19.2237,y:206.7469}).wait(1).to({graphics:mask_2_graphics_23,x:22.4213,y:206.7469}).wait(1).to({graphics:mask_2_graphics_24,x:23.8135,y:206.7469}).wait(1).to({graphics:mask_2_graphics_25,x:25.2058,y:206.7469}).wait(1).to({graphics:mask_2_graphics_26,x:26.598,y:206.7469}).wait(1).to({graphics:mask_2_graphics_27,x:27.9903,y:206.7469}).wait(1).to({graphics:mask_2_graphics_28,x:29.3825,y:206.7469}).wait(1).to({graphics:mask_2_graphics_29,x:30.7748,y:206.7469}).wait(1).to({graphics:mask_2_graphics_30,x:32.1671,y:206.7469}).wait(1).to({graphics:mask_2_graphics_31,x:33.5593,y:206.7469}).wait(1).to({graphics:mask_2_graphics_32,x:34.9516,y:206.7469}).wait(1).to({graphics:mask_2_graphics_33,x:36.3438,y:206.7469}).wait(1).to({graphics:mask_2_graphics_34,x:37.7361,y:206.7469}).wait(1).to({graphics:mask_2_graphics_35,x:39.1283,y:206.7469}).wait(1).to({graphics:mask_2_graphics_36,x:40.5206,y:206.7469}).wait(1).to({graphics:mask_2_graphics_37,x:41.8713,y:206.7469}).wait(1).to({graphics:mask_2_graphics_38,x:43.7079,y:206.7469}).wait(1).to({graphics:mask_2_graphics_39,x:47.2788,y:206.7469}).wait(1).to({graphics:mask_2_graphics_40,x:51.4646,y:206.7469}).wait(1).to({graphics:mask_2_graphics_41,x:57.6762,y:206.7469}).wait(1).to({graphics:mask_2_graphics_42,x:64.6858,y:206.7469}).wait(1).to({graphics:mask_2_graphics_43,x:70.6251,y:206.7469}).wait(1).to({graphics:mask_2_graphics_44,x:74.8691,y:206.7469}).wait(1).to({graphics:mask_2_graphics_45,x:77.6627,y:206.7469}).wait(1).to({graphics:mask_2_graphics_46,x:79.3644,y:206.7469}).wait(1).to({graphics:mask_2_graphics_47,x:80.2503,y:206.7469}).wait(1).to({graphics:mask_2_graphics_48,x:80.534,y:206.7469}).wait(1).to({graphics:null,x:0,y:0}).wait(3));

	// Layer_18
	this.instance_2 = new lib.doodle4_3();
	this.instance_2.setTransform(32.15,407.1,1.4122,1.4122,0,0,0,24.9,1.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).to({_off:true},37).wait(3));

	// Layer_16 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_13 = new cjs.Graphics().p("EgHsAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_3_graphics_14 = new cjs.Graphics().p("EgHpAh6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_15 = new cjs.Graphics().p("EgHfAh6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAlAAAbARQAbASAAAZQAAAYgbARQgbASglAAg");
	var mask_3_graphics_16 = new cjs.Graphics().p("EgHNAh6QglAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAlAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_3_graphics_17 = new cjs.Graphics().p("EgGtAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_18 = new cjs.Graphics().p("EgF8Ah6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_19 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_20 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_21 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_22 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_23 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_24 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_25 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_26 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_27 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_28 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_29 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_30 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_31 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_32 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_33 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_34 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_35 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_36 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_37 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_38 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_39 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EgFyAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EgFYAh6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAlAAAbARQAbASAAAZQAAAYgbARQgbASglAAg");
	var mask_3_graphics_43 = new cjs.Graphics().p("EgEHAh6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_44 = new cjs.Graphics().p("EgC6Ah6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_45 = new cjs.Graphics().p("EgB+Ah6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_3_graphics_46 = new cjs.Graphics().p("EgBTAh6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_47 = new cjs.Graphics().p("EgA3Ah6QglAAgcgSQgagRAAgYQAAgZAagSQAcgRAlAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_3_graphics_48 = new cjs.Graphics().p("EgAlAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");
	var mask_3_graphics_49 = new cjs.Graphics().p("EgAcAh6QgmAAgbgSQgagRAAgYQAAgZAagSQAbgRAmAAILlAAQAmAAAbARQAbASAAAZQAAAYgbARQgbASgmAAg");
	var mask_3_graphics_50 = new cjs.Graphics().p("EgAZAh6QgmAAgbgSQgbgRAAgYQAAgZAbgSQAbgRAmAAILlAAQAmAAAaARQAbASAAAZQAAAYgbARQgaASgmAAg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(13).to({graphics:mask_3_graphics_13,x:-58.4378,y:216.9969}).wait(1).to({graphics:mask_3_graphics_14,x:-58.156,y:216.9969}).wait(1).to({graphics:mask_3_graphics_15,x:-57.1925,y:216.9969}).wait(1).to({graphics:mask_3_graphics_16,x:-55.3068,y:216.9969}).wait(1).to({graphics:mask_3_graphics_17,x:-52.1467,y:216.9969}).wait(1).to({graphics:mask_3_graphics_18,x:-47.2655,y:216.9969}).wait(1).to({graphics:mask_3_graphics_19,x:-34.6646,y:216.9969}).wait(1).to({graphics:mask_3_graphics_20,x:-19.0201,y:216.9969}).wait(1).to({graphics:mask_3_graphics_21,x:-4.9613,y:216.9969}).wait(1).to({graphics:mask_3_graphics_22,x:5.7915,y:216.9969}).wait(1).to({graphics:mask_3_graphics_23,x:13.5154,y:216.9969}).wait(1).to({graphics:mask_3_graphics_24,x:18.9189,y:216.9969}).wait(1).to({graphics:mask_3_graphics_25,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_26,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_27,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_28,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_29,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_30,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_31,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_32,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_33,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_34,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_35,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_36,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_37,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_38,x:22.4213,y:216.9969}).wait(1).to({graphics:mask_3_graphics_39,x:24.4472,y:216.9969}).wait(1).to({graphics:mask_3_graphics_40,x:29.3456,y:216.9969}).wait(1).to({graphics:mask_3_graphics_41,x:38.1073,y:216.9969}).wait(1).to({graphics:mask_3_graphics_42,x:48.8024,y:216.9969}).wait(1).to({graphics:mask_3_graphics_43,x:56.9313,y:216.9969}).wait(1).to({graphics:mask_3_graphics_44,x:64.6447,y:216.9969}).wait(1).to({graphics:mask_3_graphics_45,x:70.6696,y:216.9969}).wait(1).to({graphics:mask_3_graphics_46,x:74.9346,y:216.9969}).wait(1).to({graphics:mask_3_graphics_47,x:77.7812,y:216.9969}).wait(1).to({graphics:mask_3_graphics_48,x:79.5443,y:216.9969}).wait(1).to({graphics:mask_3_graphics_49,x:80.4755,y:216.9969}).wait(1).to({graphics:mask_3_graphics_50,x:80.734,y:216.9969}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_19
	this.instance_3 = new lib.doodle4_4();
	this.instance_3.setTransform(22.75,430.1,1.4122,1.4122,0,0,0,31.7,1.5);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(13).to({_off:false},0).to({_off:true},38).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22,0,182,600);


(lib.doodle3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,24,24,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(11.8,12.1,1,1,0,0,0,11.8,12.1);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_1, new cjs.Rectangle(0,0,23.7,24.3), null);


(lib.doodle3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("AgKRsQhRgtgahZQgZhVAohOIAEgIIGJDZIgFAJQgtBKhVAZQggAJggAAQg3AAgzgdg");
	var mask_graphics_10 = new cjs.Graphics().p("AgeRYQhJg6gLhcQgKhYA0hGIAFgIIFgEXIgGAIQg5BChYAKQgOACgOAAQhLAAg9gxg");
	var mask_graphics_11 = new cjs.Graphics().p("ABvSIQhdgEg+hFQg/hFAFhdQAEhZA+g8IAHgHIEtFNIgHAGQg9A0hRAAIgMAAg");
	var mask_graphics_12 = new cjs.Graphics().p("ABZSDQhagUgyhOQgzhOAUhbQAShWBHgyIAHgFID0F5IgIAFQg0Agg7AAQgYAAgagGg");
	var mask_graphics_13 = new cjs.Graphics().p("ABGR4QhVgiglhVQglhWAihWQAghTBOglIAJgEICyGcIgIAEQgoAQgpAAQgpAAgqgRg");
	var mask_graphics_14 = new cjs.Graphics().p("AA3RoQhPgwgWhaQgXhaAwhQQAshMBUgYIAJgDIBtG0IgJADQgYAFgXAAQg7AAg3ghg");
	var mask_graphics_15 = new cjs.Graphics().p("AAsRTQhGg8gIhdQgHhdA7hHQA5hDBXgKIAJgBIAlHAIgKAAIgLABQhQAAg/g2g");
	var mask_graphics_16 = new cjs.Graphics().p("AChSHQhWgKg5hDQg7hHAIhdQAHhdBGg8QBEg5BXAEIAJAAIglHAIgKgBg");
	var mask_graphics_17 = new cjs.Graphics().p("ABsSDQhUgYgshMQgwhQAXhaQAWhbBPgvQBMguBVATIAKACIhuGzIgJgCg");
	var mask_graphics_18 = new cjs.Graphics().p("AA4R8QhNgmghhSQgihXAlhVQAmhVBVgiQBTghBQAgIAJAEIizGcIgJgEg");
	var mask_graphics_19 = new cjs.Graphics().p("AAIRyQhGgygShWQgUhbAzhOQAyhPBagTQBXgTBLAtIAIAFIj1F5IgIgFg");
	var mask_graphics_20 = new cjs.Graphics().p("AghRmQg+g9gEhYQgFhdA/hFQA+hFBdgEQBYgEBCA4IAHAGIktFMIgHgGg");
	var mask_graphics_21 = new cjs.Graphics().p("AhGRYQgzhGAKhYQALhdBJg5QBJg6BcALQBYAKA4BDIAGAHIlgEWIgGgHg");
	var mask_graphics_22 = new cjs.Graphics().p("AhjRIQgnhOAZhVQAZhZBSgtQBRgtBZAaQBVAYAtBLIAEAIImIDZIgFgIg");
	var mask_graphics_23 = new cjs.Graphics().p("Ah4Q3QgahTAmhQQAohUBXgfQBYgfBUAoQBQAmAgBRIADAJImnCWIgDgJg");
	var mask_graphics_24 = new cjs.Graphics().p("AiFQlQgMhWAzhJQA1hMBbgQQBcgQBMA1QBIAyATBVIACAKIm6BPIgCgKg");
	var mask_graphics_25 = new cjs.Graphics().p("AiIQTQAChXA+g/QBBhDBcgBQBdgBBCBBQBAA+AEBXIAAAJInAAGIAAgKg");
	var mask_graphics_26 = new cjs.Graphics().p("AiGPoIACgJQAQhVBHg1QBKg3BcAOQBcAOA3BLQA1BIgKBWIgCAJg");
	var mask_graphics_27 = new cjs.Graphics().p("Ah+OzIADgJQAehSBPgoQBSgqBZAdQBYAdAqBTQAoBPgYBUIgDAJg");
	var mask_graphics_28 = new cjs.Graphics().p("AhyN/IAFgIQArhMBTgaQBZgcBTArQBSArAcBYQAbBVgmBOIgEAJg");
	var mask_graphics_29 = new cjs.Graphics().p("AhyN/IAFgIQArhMBTgaQBZgcBTArQBSArAcBYQAbBVgmBOIgEAJg");
	var mask_graphics_30 = new cjs.Graphics().p("AhyN/IAFgIQArhMBTgaQBZgcBTArQBSArAcBYQAbBVgmBOIgEAJg");
	var mask_graphics_31 = new cjs.Graphics().p("AhyN/IAFgIQArhMBTgaQBZgcBTArQBSArAcBYQAbBVgmBOIgEAJg");
	var mask_graphics_32 = new cjs.Graphics().p("AhyOBIAEgIQAqhMBUgbQBYgdBTAqQBTArAdBYQAbBVglBOIgEAJg");
	var mask_graphics_33 = new cjs.Graphics().p("Ah1OIIAEgIQAphNBTgdQBXgfBUApQBUAoAfBYQAdBTgjBQIgEAJg");
	var mask_graphics_34 = new cjs.Graphics().p("Ah5OWIAEgJQAlhPBSggQBWgjBWAlQBVAlAjBWQAgBSgfBRIgEAJg");
	var mask_graphics_35 = new cjs.Graphics().p("Ah+OrIADgJQAghRBQgmQBTgoBYAeQBXAfApBUQAmBQgaBTIgDAJg");
	var mask_graphics_36 = new cjs.Graphics().p("AiEPKIACgKQAYhTBMguQBPgwBaAXQBbAWAwBQQAtBMgSBVIgCAJg");
	var mask_graphics_37 = new cjs.Graphics().p("AiJP1IABgJQANhWBFg3QBIg6BcAKQBdAKA6BJQA3BFgHBXIAAAJg");
	var mask_graphics_38 = new cjs.Graphics().p("AiKQYQgDhWA7hDQA+hGBcgFQBdgGBFA9QBDA7AIBWIABAKInAAcIAAgKg");
	var mask_graphics_39 = new cjs.Graphics().p("Ah/QyQgWhVArhNQAshSBYgaQBagbBRAsQBOArAcBSIADAJImuCAIgDgJg");
	var mask_graphics_40 = new cjs.Graphics().p("AhbRPQgrhLAThWQAUhbBPgyQBNgyBbAUQBWATAyBIIAFAIIl7DxIgFgIg");
	var mask_graphics_41 = new cjs.Graphics().p("AgVRsQhCg6gJhYQgJhcA7hIQA6hJBdgJQBYgJBFA1IAHAGIkbFcIgHgGg");
	var mask_graphics_42 = new cjs.Graphics().p("ABJSBQhQghglhRQgnhUAhhXQAghYBTgnQBQglBTAbIAJADIibGmIgJgDg");
	var mask_graphics_43 = new cjs.Graphics().p("ACvSKQhXgHg8hBQg+hEAEhdQAEhdBDg/QBCg8BWAAIAKABIgTHBIgJgBg");
	var mask_graphics_44 = new cjs.Graphics().p("AA2RoQhOgxgVhaQgVhbAxhPQAuhLBTgXIAKgCIBmG1IgJADQgXAEgVAAQg9AAg4gjg");
	var mask_graphics_45 = new cjs.Graphics().p("ABMR+QhXgegphUQgphUAehYQAdhTBMgpIAIgFIDGGUIgJAEQgsAUgtAAQgkAAgmgNg");
	var mask_graphics_46 = new cjs.Graphics().p("ABiSIQhcgOg2hLQg4hLAOhcQANhXBEg2IAIgGIEKFpIgIAGQg4AmhDAAQgRAAgTgCg");
	var mask_graphics_47 = new cjs.Graphics().p("AB3SKQheAAhAhCQhChCAAhdQAAhYA8hAIAGgHIE9E+IgHAHQhAA7hYAAIAAAAg");
	var mask_graphics_48 = new cjs.Graphics().p("AgcRZQhKg5gKhdQgLhYA0hGIAGgHIFfEXIgGAHQg4BChYAKQgPACgOAAQhLAAg8gxg");
	var mask_graphics_49 = new cjs.Graphics().p("AgSRlQhOgzgThbQgShWAthLIAFgIIF3D2IgFAIQgyBHhXASQgZAFgYAAQg/AAg4glg");
	var mask_graphics_50 = new cjs.Graphics().p("AgKRsQhRgtgahZQgZhVAohOIAEgIIGJDZIgFAJQgtBKhVAZQggAJggAAQg3AAgzgdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:29.4557,y:116.093}).wait(1).to({graphics:mask_graphics_10,x:28.4687,y:116.0571}).wait(1).to({graphics:mask_graphics_11,x:27.2476,y:116.0394}).wait(1).to({graphics:mask_graphics_12,x:25.8253,y:116.0555}).wait(1).to({graphics:mask_graphics_13,x:24.2402,y:116.0706}).wait(1).to({graphics:mask_graphics_14,x:22.5348,y:116.0698}).wait(1).to({graphics:mask_graphics_15,x:20.755,y:116.062}).wait(1).to({graphics:mask_graphics_16,x:20.8059,y:116.0273}).wait(1).to({graphics:mask_graphics_17,x:22.6528,y:115.7473}).wait(1).to({graphics:mask_graphics_18,x:24.4225,y:115.1793}).wait(1).to({graphics:mask_graphics_19,x:26.0673,y:114.3385}).wait(1).to({graphics:mask_graphics_20,x:27.5434,y:113.2475}).wait(1).to({graphics:mask_graphics_21,x:28.8112,y:111.9357}).wait(1).to({graphics:mask_graphics_22,x:29.8368,y:110.4382}).wait(1).to({graphics:mask_graphics_23,x:30.5927,y:108.7953}).wait(1).to({graphics:mask_graphics_24,x:31.0587,y:107.0511}).wait(1).to({graphics:mask_graphics_25,x:31.2224,y:105.2525}).wait(1).to({graphics:mask_graphics_26,x:31.2209,y:106.846}).wait(1).to({graphics:mask_graphics_27,x:31.223,y:108.6646}).wait(1).to({graphics:mask_graphics_28,x:31.0205,y:110.2616}).wait(1).to({graphics:mask_graphics_29,x:31.0206,y:110.2616}).wait(1).to({graphics:mask_graphics_30,x:31.0206,y:110.2616}).wait(1).to({graphics:mask_graphics_31,x:31.0205,y:110.2616}).wait(1).to({graphics:mask_graphics_32,x:31.0213,y:110.1894}).wait(1).to({graphics:mask_graphics_33,x:31.0233,y:109.9534}).wait(1).to({graphics:mask_graphics_34,x:31.0257,y:109.5148}).wait(1).to({graphics:mask_graphics_35,x:31.0263,y:108.8194}).wait(1).to({graphics:mask_graphics_36,x:31.0207,y:107.7936}).wait(1).to({graphics:mask_graphics_37,x:31.0065,y:106.3467}).wait(1).to({graphics:mask_graphics_38,x:30.9869,y:105.7935}).wait(1).to({graphics:mask_graphics_39,x:30.5579,y:108.2842}).wait(1).to({graphics:mask_graphics_40,x:29.2816,y:111.1178}).wait(1).to({graphics:mask_graphics_41,x:26.9229,y:113.7815}).wait(1).to({graphics:mask_graphics_42,x:23.7082,y:115.6062}).wait(1).to({graphics:mask_graphics_43,x:20.295,y:116.2668}).wait(1).to({graphics:mask_graphics_44,x:22.3889,y:116.2861}).wait(1).to({graphics:mask_graphics_45,x:24.7609,y:116.2744}).wait(1).to({graphics:mask_graphics_46,x:26.5091,y:116.2379}).wait(1).to({graphics:mask_graphics_47,x:27.7536,y:116.2124}).wait(1).to({graphics:mask_graphics_48,x:28.6227,y:116.2128}).wait(1).to({graphics:mask_graphics_49,x:29.2225,y:116.2185}).wait(1).to({graphics:mask_graphics_50,x:29.4557,y:116.093}).wait(1).to({graphics:null,x:0,y:0}).wait(9));

	// Layer_1
	this.instance = new lib.doodle3_1();
	this.instance.setTransform(42.8,202.05,1,1,-2.741,0,0,11.8,12.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({_off:true},42).wait(9));

	// Layer_14 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_20 = new cjs.Graphics().p("EAKpApSQgIgLgDgQQgEgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADAQQADARgEANQgEAMgIACIirAhIgCAAQgIAAgHgIg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EAKiApTQgIgLgDgQQgEgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEAMgIACIirAhIgCABQgIAAgHgJg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EAKQApWQgJgLgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADARQAEAQgEANQgEAMgJACIiqAhIgDABQgHAAgHgJg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAJ2ApaQgIgLgEgQQgDgQAEgNQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgIABIirAhIgCABQgIAAgHgJg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAJdApeQgJgLgDgQQgDgQAEgNQAEgNAIgCICrghQAIgBAJAKQAIAKADARQAEAQgEANQgEANgJABIiqAiIgDAAQgHAAgHgJg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAJKAphQgJgLgDgQQgDgQAEgNQAEgNAJgCICqghQAJgBAIAKQAIAKAEARQADAQgEANQgEANgJABIiqAiIgCAAQgIAAgHgJg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAJCApiQgJgKgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADAQQAEARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAI+ApjQgJgKgDgRQgDgQAEgNQAEgNAIgBICrghQAIgCAJAKQAIALADAQQAEAQgEANQgEANgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAI1AplQgIgLgDgQQgDgRADgMQAEgNAJgCICqghQAJgCAIALQAJAKADAQQADARgEANQgEAMgIACIirAhIgCAAQgHAAgIgIg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAImApnQgIgLgDgQQgDgQADgNQAEgNAJgCICqghQAJgBAJAKQAIAKADARQADAQgEANQgEANgIABIirAiIgCAAQgHAAgIgJg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAIRApqQgJgKgDgQQgDgRAEgMQAEgNAJgCICqghQAJgCAIALQAIAKAEAQQADARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAH8ApuQgIgLgEgQQgDgQAEgNQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgJABIiqAhIgCABQgIAAgHgJg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EAHtApwQgIgKgDgRQgDgQAEgNQADgNAJgBICqghQAJgCAJAKQAIALADAQQADAQgEANQgEANgIACIirAhIgCAAQgHAAgIgJg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EAHkApyQgIgLgEgQQgDgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgJABIiqAhIgCABQgIAAgHgJg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EAHfApzQgJgLgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADAQQAEARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_1_graphics_20,x:88.328,y:265.0434}).wait(1).to({graphics:mask_1_graphics_21,x:87.6448,y:265.1535}).wait(1).to({graphics:mask_1_graphics_22,x:85.7777,y:265.4541}).wait(1).to({graphics:mask_1_graphics_23,x:83.2273,y:265.8647}).wait(1).to({graphics:mask_1_graphics_24,x:80.6769,y:266.2753}).wait(1).to({graphics:mask_1_graphics_25,x:78.8099,y:266.5759}).wait(1).to({graphics:mask_1_graphics_26,x:78.103,y:266.7184}).wait(1).to({graphics:mask_1_graphics_27,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_28,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_29,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_30,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_31,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_32,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_33,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_34,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_35,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_36,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_37,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_38,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_39,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_40,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_41,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_42,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_43,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_44,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_45,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_46,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_47,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_48,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_1_graphics_49,x:78.103,y:266.7184}).wait(1).to({graphics:mask_1_graphics_50,x:77.9916,y:266.7366}).wait(1).to({graphics:mask_1_graphics_51,x:77.5898,y:266.8017}).wait(1).to({graphics:mask_1_graphics_52,x:76.7468,y:266.9384}).wait(1).to({graphics:mask_1_graphics_53,x:75.2484,y:267.1814}).wait(1).to({graphics:mask_1_graphics_54,x:73.1011,y:267.5297}).wait(1).to({graphics:mask_1_graphics_55,x:71.0241,y:267.8665}).wait(1).to({graphics:mask_1_graphics_56,x:69.5549,y:268.1048}).wait(1).to({graphics:mask_1_graphics_57,x:68.6205,y:268.2563}).wait(1).to({graphics:mask_1_graphics_58,x:68.078,y:268.3434}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance_1 = new lib.doodle5_2();
	this.instance_1.setTransform(146.05,529.25,0.8671,0.8671,35.9343,0,0,8.6,7.7);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_22 = new cjs.Graphics().p("EAJzAqoQgHgFgBgIQgBgHAEgHQAFgGAIgBQAHgCAHAFQAGAFACAHQABAIgFAHQgEAGgIABIgDABQgGAAgFgEg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAJsAqqQgIgGgCgLQgBgKAGgIQAGgIAKgCQAKgCAIAGQAJAGABALQACAKgGAIQgGAIgKACIgFAAQgHAAgHgEg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAJZAqvQgOgLgDgRQgDgRAKgOQALgPARgCQARgDAOAKQAPALADARQACARgKAOQgKAPgSACIgHABQgNAAgLgIg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAI4Aq3QgYgRgFgeQgFgdASgYQARgYAegFQAdgFAZASQAYARAFAeQAEAdgRAZQgSAYgdAEIgMABQgXAAgTgOg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAIbAq/QghgYgHgoQgGgoAYghQAYghAogHQAogGAhAYQAiAYAGAoQAHAogYAiQgYAhgoAGIgRABQgfAAgagTg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAIKArEQgmgcgIgvQgHguAcgmQAbgmAvgIQAugHAmAcQAnAbAHAvQAIAvgcAmQgbAmgvAHQgKACgJAAQgkAAgegWg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAICArGQgogegIgxQgIgxAdgpQAegoAxgJQAxgHApAdQApAeAIAxQAIAygeAoQgdApgxAHQgLACgKAAQgmAAgggXg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAICArHQgpgegIgyQgIgxAegpQAegpAxgIQAygIApAeQAqAdAIAyQAIAygeApQgeApgxAIQgLACgKAAQgmAAghgYg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAIFArGQgogdgIgxQgIgwAdgoQAdgoAxgJQAxgHAoAdQAoAdAIAxQAIAxgdAoQgdAogxAIQgKABgKAAQglAAgggXg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAILArFQgngcgHgvQgHguAbgnQAcgmAvgIQAugHAnAcQAmAcAIAuQAHAvgbAnQgcAmgvAHQgKACgJAAQgkAAgegWg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAIUArCQgjgagHgrQgHgrAagjQAagjArgHQArgHAjAaQAkAZAHArQAHAsgaAjQgaAjgrAHIgSABQghAAgcgUg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAIkAq+QgfgWgGgmQgGglAWgfQAWgfAmgGQAlgGAfAXQAfAWAGAlQAGAmgWAfQgXAeglAGIgQABQgcAAgYgRg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAI3Aq4QgYgRgFgfQgFgdASgZQASgZAegEQAegFAYASQAZASAFAeQAFAegSAYQgSAZgeAEIgMABQgXAAgUgOg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAJLAqzQgSgOgEgWQgDgWANgTQAOgSAWgEQAWgEATAOQASANAEAXQAEAWgOATQgNASgWAEIgKAAQgRAAgPgKg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAJbAquQgNgJgDgRQgDgRAKgNQAKgOARgDQAQgCAOAKQANAKADAQQADARgKAOQgKANgQADIgHAAQgNAAgLgIg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAJmAqrQgKgHgCgMQgCgNAHgKQAIgKAMgCQANgCAKAHQAKAIACAMQACANgHAKQgIAKgMACIgFAAQgKAAgIgGg");
	var mask_2_graphics_54 = new cjs.Graphics().p("EAJuAqpQgIgFgCgKQgBgKAGgIQAFgHAKgCQAJgCAIAGQAIAGACAKQABAJgFAIQgGAIgKACIgEAAQgHAAgGgFg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EAJzAqoQgHgFgBgIQgBgHAEgHQAFgGAIgBQAHgCAHAFQAGAFACAHQABAIgFAHQgEAGgIABIgDABQgGAAgFgEg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_2_graphics_22,x:65.679,y:273.1519}).wait(1).to({graphics:mask_2_graphics_23,x:65.9616,y:273.4331}).wait(1).to({graphics:mask_2_graphics_24,x:66.8163,y:274.2836}).wait(1).to({graphics:mask_2_graphics_25,x:68.2748,y:275.7349}).wait(1).to({graphics:mask_2_graphics_26,x:69.5655,y:277.0192}).wait(1).to({graphics:mask_2_graphics_27,x:70.3068,y:277.757}).wait(1).to({graphics:mask_2_graphics_28,x:70.6535,y:278.1019}).wait(1).to({graphics:mask_2_graphics_29,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_30,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_31,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_32,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_33,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_34,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_35,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_36,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_37,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_38,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_39,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_40,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_41,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_42,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_43,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_44,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_2_graphics_45,x:70.845,y:278.2564}).wait(1).to({graphics:mask_2_graphics_46,x:70.7146,y:278.1275}).wait(1).to({graphics:mask_2_graphics_47,x:70.4547,y:277.8703}).wait(1).to({graphics:mask_2_graphics_48,x:70.0104,y:277.4309}).wait(1).to({graphics:mask_2_graphics_49,x:69.3206,y:276.7486}).wait(1).to({graphics:mask_2_graphics_50,x:68.4094,y:275.8472}).wait(1).to({graphics:mask_2_graphics_51,x:67.4961,y:274.9437}).wait(1).to({graphics:mask_2_graphics_52,x:66.7784,y:274.2339}).wait(1).to({graphics:mask_2_graphics_53,x:66.2716,y:273.7325}).wait(1).to({graphics:mask_2_graphics_54,x:65.9267,y:273.3914}).wait(1).to({graphics:mask_2_graphics_55,x:65.679,y:273.1519}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_2 = new lib.doodle5_3();
	this.instance_2.setTransform(133.5,542.5,0.8671,0.8671,35.9343,0,0,9.2,7);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_16 = new cjs.Graphics().p("EAKIAqMQgNgRgFgaQgFgaAGgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAVQgGAUgOACIkQA1IgDABQgMAAgMgOg");
	var mask_3_graphics_17 = new cjs.Graphics().p("EAKFAqMQgNgRgFgaQgGgaAHgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAbQAFAagGAUQgGAUgOADIkQA1IgEAAQgLAAgMgOg");
	var mask_3_graphics_18 = new cjs.Graphics().p("EAJ5AqOQgNgQgFgaQgGgaAHgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAUQgGAVgOACIkQA1IgEABQgLAAgMgPg");
	var mask_3_graphics_19 = new cjs.Graphics().p("EAJeAqUQgOgRgFgaQgFgaAHgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAVQgGAUgOADIkQA0IgEABQgMAAgLgOg");
	var mask_3_graphics_20 = new cjs.Graphics().p("EAIxAqcQgNgRgFgaQgFgaAGgUQAGgVAOgCIEQg1QAOgDANARQANAQAFAaQAGAbgHAUQgGAUgOADIkPA1IgEAAQgMAAgMgOg");
	var mask_3_graphics_21 = new cjs.Graphics().p("EAIJAqkQgNgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QANgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkPA1IgEAAQgMAAgMgOg");
	var mask_3_graphics_22 = new cjs.Graphics().p("EAHxAqoQgNgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QANgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkPA1IgEAAQgMAAgMgOg");
	var mask_3_graphics_23 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_24 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_25 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_26 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_27 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_28 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_29 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_30 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_31 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_32 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_33 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_34 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_35 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_36 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_37 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_38 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_39 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_43 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_44 = new cjs.Graphics().p("EAHjAqrQgOgRgFgaQgFgaAHgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAaQAFAbgGAUQgGAUgOADIkQA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_45 = new cjs.Graphics().p("EAHeAqsQgOgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QAOgDANARQAOARAFAaQAFAagGAUQgHAVgOACIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_46 = new cjs.Graphics().p("EAHTAqvQgOgRgFgaQgFgaAHgUQAGgVAOgDIEPg0QAOgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkQA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_47 = new cjs.Graphics().p("EAHAAqzQgNgRgFgaQgFgaAGgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAaQAFAbgGAUQgGAUgOADIkQA1IgEAAQgLAAgMgOg");
	var mask_3_graphics_48 = new cjs.Graphics().p("EAGjAq6QgNgRgFgaQgFgaAGgVQAGgUAOgDIEQg1QAOgCANAQQANARAFAaQAFAagGAVQgGAUgOADIkPA0IgEABQgMAAgMgOg");
	var mask_3_graphics_49 = new cjs.Graphics().p("EAGCArBQgOgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QAOgDANARQAOARAFAaQAFAagGAUQgHAVgOACIkPA1IgEAAQgMAAgLgOg");
	var mask_3_graphics_50 = new cjs.Graphics().p("EAFlArIQgNgRgFgaQgFgaAGgUQAGgVAOgDIEPg0QAOgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkQA1IgDAAQgMAAgMgOg");
	var mask_3_graphics_51 = new cjs.Graphics().p("EAFRArMQgNgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QANgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkPA1IgEABQgMAAgMgPg");
	var mask_3_graphics_52 = new cjs.Graphics().p("EAFEArPQgNgQgFgaQgFgbAGgUQAGgUAOgDIEPg1QAOgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkQA1IgDABQgMAAgMgPg");
	var mask_3_graphics_53 = new cjs.Graphics().p("EAE7ArRQgNgRgFgaQgFgaAGgUQAGgVAOgCIEQg1QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgMgOg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_3_graphics_16,x:97.0494,y:271.3687}).wait(1).to({graphics:mask_3_graphics_17,x:96.7375,y:271.4284}).wait(1).to({graphics:mask_3_graphics_18,x:95.5374,y:271.6574}).wait(1).to({graphics:mask_3_graphics_19,x:92.8225,y:272.1755}).wait(1).to({graphics:mask_3_graphics_20,x:88.3728,y:273.0247}).wait(1).to({graphics:mask_3_graphics_21,x:84.3627,y:273.79}).wait(1).to({graphics:mask_3_graphics_22,x:81.9606,y:274.2484}).wait(1).to({graphics:mask_3_graphics_23,x:80.6744,y:274.4937}).wait(1).to({graphics:mask_3_graphics_24,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_25,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_26,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_27,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_28,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_29,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_30,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_31,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_32,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_33,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_34,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_35,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_36,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_37,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_38,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_39,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_40,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_41,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_42,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_3_graphics_43,x:80.6744,y:274.4937}).wait(1).to({graphics:mask_3_graphics_44,x:80.525,y:274.528}).wait(1).to({graphics:mask_3_graphics_45,x:79.9976,y:274.6483}).wait(1).to({graphics:mask_3_graphics_46,x:78.9219,y:274.8938}).wait(1).to({graphics:mask_3_graphics_47,x:77.0439,y:275.3223}).wait(1).to({graphics:mask_3_graphics_48,x:74.1712,y:275.9778}).wait(1).to({graphics:mask_3_graphics_49,x:70.7931,y:276.7486}).wait(1).to({graphics:mask_3_graphics_50,x:67.9489,y:277.3976}).wait(1).to({graphics:mask_3_graphics_51,x:65.96,y:277.8514}).wait(1).to({graphics:mask_3_graphics_52,x:64.6491,y:278.1505}).wait(1).to({graphics:mask_3_graphics_53,x:63.7744,y:278.3187}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_3 = new lib.doodle5_1();
	this.instance_3.setTransform(144,542.15,0.8671,0.8671,35.9343,0,0,13.7,14.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160.6,600);


(lib.doodle2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,31,34,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle2_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(15.1,16.6,1,1,0,0,0,15.1,16.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle2_1, new cjs.Rectangle(0,0,30.2,33.4), null);


(lib.doodle2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_10 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_6 = new cjs.Graphics().p("ACZRRIAAAAQgRgRAAgYQAAgYARgRIABAAQARgRAXAAQAYAAARARIAAAAQARARAAAYQAAAYgRARIAAAAQgRARgYAAIAAAAQgYAAgRgRgADCQ5QAHgBAFgEIAAAAQAFgFAAgHQAAgHgFgEIAAgBQgFgEgHAAQgGAAgFAEIgBABQgEAEAAAHQAAAHAFAFIAAAAQAEAEAHABg");
	var mask_graphics_7 = new cjs.Graphics().p("ACZRRIAAAAQgRgRAAgYQAAgYARgSIAAAAQARgRAYAAQAYAAARARIABAAQARASAAAYQAAAYgSARIAAAAQgRARgYAAIAAAAQgYAAgRgRgADCQ4QAHAAAFgFIAAABQAFgFAAgHQAAgHgFgFIAAAAQgFgFgHAAQgHAAgFAFIAAAAQgFAFAAAHQAAAHAFAFIAAgBQAFAFAHAAg");
	var mask_graphics_8 = new cjs.Graphics().p("ACWRSIAAgBQgRgRAAgZQAAgZARgSIABAAQARgRAZAAQAZAAASARIAAAAQARASAAAZQAAAZgRARIAAABQgSARgZAAIAAAAQgZAAgSgRgADBQ4QAHAAAFgFIAAAAQAFgFAAgHQAAgHgFgFIAAgBQgFgEgHAAQgHAAgFAEIAAABQgFAFAAAHQAAAHAFAFIAAAAQAFAFAHAAg");
	var mask_graphics_9 = new cjs.Graphics().p("ACSRSIAAAAQgSgTgBgaQAAgaATgTIAAAAQATgTAaAAQAbAAASATIABAAQASATAAAaQAAAagSATIgBAAQgSATgbAAIAAAAQgaAAgTgTgAC/Q3QAIAAAFgFIAAAAQAGgFAAgIQAAgHgGgGIAAAAQgFgFgIAAQgHAAgFAFIgBAAQgFAGAAAHQAAAIAFAFIAAAAQAGAFAHAAg");
	var mask_graphics_10 = new cjs.Graphics().p("ACMRTIAAAAQgVgUAAgdQAAgcAUgVIABAAQAUgUAdAAQAcAAAUAUIABAAQAUAVAAAcQAAAdgUAUIAAAAQgVAVgcAAIgBAAQgcAAgUgVgAC9Q2QAIAAAGgGIAAAAQAFgGAAgIQAAgIgFgGIAAAAQgGgFgIAAQgIAAgGAFIgBAAQgFAGAAAIQAAAIAGAGIAAAAQAFAGAJAAg");
	var mask_graphics_11 = new cjs.Graphics().p("ACCRVIAAAAQgWgXAAggQAAggAWgWIAAgBQAXgWAgAAQAfAAAXAWIAAABQAXAWAAAgQAAAggXAXIAAAAQgXAWgfAAIgBAAQgfAAgXgWgAC5Q0QAJAAAGgGIAAAAQAHgHAAgJQAAgJgHgGIAAAAQgGgHgJAAQgJAAgHAHIAAAAQgGAGAAAJQAAAJAGAHIAAAAQAHAGAJAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AB1RXIAAAAQgagaAAgkQAAglAagZIAAgBQAagZAkAAQAkAAAaAZIABABQAZAZAAAlQAAAkgZAaIgBAAQgZAaglAAIAAAAQgkAAgagagACzQyQALAAAHgIIAAABQAHgIAAgKQAAgKgHgIIAAAAQgIgHgKAAQgKAAgHAHIgBAAQgHAIAAAKQAAAKAHAIIAAgBQAIAIAKAAg");
	var mask_graphics_13 = new cjs.Graphics().p("ABkRaIgBAAQgegeAAgrQAAgqAegeIABgBQAegdAqAAQAqAAAeAdIABABQAeAeAAAqQAAArgeAeIgBAAQgeAegqAAIAAAAQgqAAgegegACsQvQAMgBAJgIIAAAAQAIgIAAgNQAAgLgIgJIAAgBQgJgIgMAAQgMAAgJAIIAAABQgIAJAAALQAAANAIAIIAAAAQAJAIAMABg");
	var mask_graphics_14 = new cjs.Graphics().p("ABNReIAAAAQgkgkAAgyQAAgyAkgkIAAAAQAkgjAyAAQAyAAAjAjIABAAQAjAkAAAyQAAAygkAkIAAAAQgjAjgyAAIgBAAQgxAAgkgjgACjQqQAOAAAKgKIAAAAQAKgKAAgOQAAgOgKgKIAAgBQgKgKgOAAQgOABgLAJIAAABQgKAKAAAOQAAAOAKAKIAAAAQAKAKAPAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AAyRiIgBAAQgqgqAAg8QAAg7AqgrIABAAQAqgqA7AAQA7AAArAqIABAAQApArAAA7QAAA8gqAqIAAAAQgqAqg8AAIAAAAQg7AAgqgqgACXQlQARAAANgMIgBAAQAMgMAAgRQAAgQgLgMIgBgBQgMgMgRAAQgQABgNALIAAABQgMAMAAAQQAAARAMAMIAAAAQAMAMARAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AATRnIAAAAQgwgxAAhGQAAhGAwgyIABgBQAxgwBGAAQBFAAAyAwIABABQAxAyAABGQAABGgyAxIAAAAQgyAyhFAAIgBAAQhFAAgygygACLQgQAUAAAOgPIAAABQAOgOAAgUQAAgUgOgOIAAgBQgPgNgTAAQgUAAgOANIgBABQgNAOAAAUQAAAUAOAOIgBgBQAPAPAUAAg");
	var mask_graphics_17 = new cjs.Graphics().p("AgJRsIAAAAQg5g5AAhQQAAhQA4g5IABgBQA4g3BPAAQBQAAA5A3IABABQA4A5AABQQAABQg4A5IgBAAQg5A5hQAAIAAAAQhPAAg4g5gAB+QaQAXAAARgQIAAAAQAQgQAAgXQAAgWgQgQIgBgBQgQgQgXAAQgWAAgQAQIgBABQgPAQgBAWQAAAXAQAQIAAAAQARAQAWAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AgjRxIAAgBQg/g/gBhZQAAhZA/g/IABgBQA+g+BZAAQBYAABAA+IABABQA+A/AABZQAABZg/A/IAAABQhAA+hYAAIgBAAQhYAAg+g+gAB0QVQAZAAATgSIgBABQASgSAAgaQAAgZgRgSIgBgBQgSgRgZAAQgZAAgSARIgBABQgRASgBAZQAAAaASASIAAgBQASASAaAAg");
	var mask_graphics_19 = new cjs.Graphics().p("Ag5R0IAAAAQhFhEAAhhQAAhgBEhFIABgBQBEhDBfAAQBhAABEBDIABABQBEBFAABgQAABhhEBEIAAAAQhFBEhhAAIAAAAQhfAAhEhEgABqQRQAcAAAUgTIAAAAQATgTAAgcQAAgbgTgUIgBgBQgTgSgcAAQgaAAgUASIgBABQgTAUAAAbQAAAcAUATIgBAAQAUATAbAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AhLR3IAAAAQhIhJAAhmQgBhnBJhJIABgBQBJhHBkAAQBmAABJBHIABABQBJBJgBBnQAABmhIBJIAAAAQhKBJhmgBIAAAAQhlAAhJhIgABjQOQAeAAAVgVIAAABQAUgVAAgdQAAgdgUgVIgBgBQgVgUgdAAQgcAAgVAUIgBABQgUAVAAAdQAAAdAUAVIAAgBQAVAVAdAAg");
	var mask_graphics_21 = new cjs.Graphics().p("AhZR6IAAgBQhMhMAAhrQAAhrBMhNIABgBQBMhLBpABQBrAABNBKIABABQBLBNAABrQAABrhMBMIAAABQhNBLhrAAIAAAAQhpAAhNhLgABdQLQAfAAAWgWIAAABQAWgWAAgeQAAgegVgWIgBgBQgWgVgfAAQgdAAgWAVIgBABQgVAWAAAeQAAAeAVAWIAAgBQAWAWAeAAg");
	var mask_graphics_22 = new cjs.Graphics().p("AhkR8IAAgBQhPhPAAhvQAAhvBOhPIACgBQBPhNBtAAQBuAABQBNIABABQBOBPAABvQAABvhPBPIAAABQhPBOhvAAIgBAAQhtAAhPhOgABZQJQAgAAAXgWIgBAAQAXgWAAggQAAgfgWgXIgBgBQgXgVgfAAQgfAAgXAVIgBABQgVAXAAAfQgBAgAXAWIgBAAQAXAWAgAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AhsR9IgBgBQhQhQAAhyQAAhyBQhSIABgBQBRhPBwAAQByAABRBPIABABQBRBSgBByQAAByhQBQIgBABQhRBQhyAAIAAAAQhwAAhRhQgABVQIQAhAAAYgYIgBABQAXgXAAggQAAgggWgYIgBgBQgYgWggAAQggAAgXAWIgBABQgWAYAAAgQAAAgAXAXIgBgBQAYAYAgAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_25 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_26 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_27 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_28 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_29 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_30 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_31 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_32 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_33 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_34 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_35 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_36 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_37 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_38 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_39 = new cjs.Graphics().p("AhzR/IAAgBQhThSAAh0QAAh0BShTIABgBQBThRByAAQB0AABTBRIABABQBSBTAAB0QAAB0hTBSIAAABQhTBSh0AAIAAAAQhyAAhThSgABSQIQAigBAYgXIgBAAQAYgXAAghQAAghgXgYIgBgBQgYgWghAAQggAAgYAWIgBABQgXAYAAAhQAAAhAYAXIgBAAQAYAXAhABg");
	var mask_graphics_40 = new cjs.Graphics().p("Ah4SAIAAgBQhUhTAAh2QAAh2BThUIABgBQBUhSB0AAQB2AABUBSIABABQBTBUAAB2QAAB2hUBTIAAABQhUBTh2AAIgBAAQhzAAhUhTgABQQHQAiAAAZgZIgBABQAYgYAAghQAAghgXgYIgBgCQgYgWgiAAQghAAgYAWIgBACQgWAYAAAhQAAAhAXAYIgBgBQAZAYAhABg");
	var mask_graphics_41 = new cjs.Graphics().p("AiISDIgBgBQhXhXAAh8QAAh7BXhYIABgCQBYhWB5AAQB8AABXBWIACACQBXBYAAB7QAAB8hYBXIAAABQhYBXh8AAIAAAAQh5gBhYhWgABJQEQAkAAAagaIgBABQAZgZAAgjQAAgjgYgZIgBgBQgagYgjAAQgiAAgZAYIgBABQgXAZAAAjQAAAjAXAZIAAgBQAZAaAjAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AioSIIAAgBQhfhfAAiGQAAiGBehgIACgBQBfheCEAAQCGAABgBeIABABQBfBgAACGQAACGhfBfIgBABQhgBfiGAAIAAAAQiEAAhghfgAA8P+QAnAAAcgbIgBAAQAbgbAAgmQAAgmgagbIgBgCQgcgZgmAAQglAAgaAZIgCACQgaAbAAAmQAAAmAbAbIAAAAQAaAbAmAAg");
	var mask_graphics_43 = new cjs.Graphics().p("AjcSRIAAgBQhshrAAiZQAAiXBrhtIACgBQBshqCWAAQCXAABtBqIABABQBrBtAACXQAACZhrBrIgBABQhsBriYAAIgBAAQiVAAhthrgAAnP1QAsAAAfgfIAAAAQAegeAAgsQAAgqgdgfIgCgCQgfgdgrAAQgpAAgfAdIgCACQgdAfgBAqQAAAsAfAeIgBAAQAgAfAqAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AkrSfIAAgBQh/h/AAizQAAizB+iAIACgCQCAh9CwAAQCzAAB/B9IACACQB+CAAACzQAACzh/B/IAAABQiAB+izAAIgBAAQiwAAiAh+gAAGPnQA0gBAlgkIgBABQAkgkAAgzQAAgzgjgkIgCgCQgkgigzAAQgxAAgkAiIgCACQgjAkAAAzQAAAzAkAkIgBgBQAlAkAyABg");
	var mask_graphics_45 = new cjs.Graphics().p("AlzSyIgBgBQiaiaAAjaQAAjaCZibIACgCQCciYDXABQDYAACcCXIACACQCZCbAADaQAADaiaCaIgBABQibCajZgBIgBAAQjXAAibiZgAAAPSQA+AAAtgsIAAABQArgsAAg+QAAg9gqgsIgDgDQgsgqg9AAQg8ABgsApIgDADQgqAsAAA9QAAA+ArAsIAAgBQAtAsA9AAg");
	var mask_graphics_46 = new cjs.Graphics().p("AnGTLIAAgCQi9i8AAkLQAAkJC7i+IADgDQC+i5EHAAQEIAAC+C5IADADQC7C+AAEJQAAELi9C8IAAACQi+C7kJAAIgBAAQkHAAi+i7gAAAO5QBMAAA3g2IgBABQA2g2gBhMQAAhKgzg2IgDgDQg3gzhKAAQhKAAg2AzIgDADQgzA2AABKQgBBMA2A2IgBgBQA3A2BLAAg");
	var mask_graphics_47 = new cjs.Graphics().p("AoaTjIgBgBQjfjfAAk8QgBk7DejhIAEgDQDhjbE4AAQE6AADgDbIAEADQDeDhgBE7QAAE8jfDfIgBABQjhDfk6gBIgCAAQk3AAjhjegAAAOfQBaAABBhAIgBABQBAg/gBhaQAAhZg9hAIgDgDQhBg9hYAAQhYAAhAA9IgDADQg9BAAABZQgBBaBAA/IgBgBQBBBABZAAg");
	var mask_graphics_48 = new cjs.Graphics().p("AphT4IgBgBQj9j9AAllQAAllD7j+IAEgEQD/j4FhABQFjAAD+D3IAEAEQD7D+AAFlQAAFlj9D9IgBABQj/D8ljgBIgCAAQlhAAj+j7gAAAOKQBmgBBKhJIgBACQBHhIAAhlQAAhlhFhIIgEgEQhJhFhkAAQhjABhJBEIgEAEQhFBIAABlQAABlBHBIIgBgCQBKBJBlABg");
	var mask_graphics_49 = new cjs.Graphics().p("AqXUIIgBgCQkTkSAAmGQgBmEESkUIAEgEQEVkOGBAAQGCAAEVEOIAEAEQESEUgBGEQAAGGkTESIgBACQkVESmDAAIgCAAQmAAAkVkSgAAAN5QBvAABQhQIgBACQBOhOAAhvQAAhthMhPIgEgEQhPhLhtAAQhsABhPBKIgEAEQhMBPAABtQAABvBOBOIgBgCQBPBPBvABg");
	var mask_graphics_50 = new cjs.Graphics().p("Aq/UUIgBgCQkjkjAAmdQgBmbEikkIAFgFQElkeGYAAQGZAAElEeIAFAFQEiEkgBGbQAAGdkjEjIgBACQkmEimaAAIgDAAQmWAAkmkigAAANtQB2AABVhVIgCADQBThTAAh2QgBhzhPhUIgFgEQhUhQhzABQhzAAhTBPIgFAEQhPBUgBBzQAAB2BTBTIgCgDQBVBUB1ABg");
	var mask_graphics_51 = new cjs.Graphics().p("ArbUcIgBgCQkvkvAAmtQgBmrEukxIAEgEQEykqGoAAQGqAAExEqIAEAEQEuExgBGrQAAGtkvEvIgBACQkyEumqAAIgDAAQmnAAkxkugAAANkQB6AABZhYIgBADQBWhXgBh6QAAh4hThXIgFgFQhXhSh4AAQh3AAhXBSIgFAFQhTBXAAB4QgBB6BWBXIgBgDQBYBXB6ABg");
	var mask_graphics_52 = new cjs.Graphics().p("ArvUgIgBgCQk3k4AAm4QgBm3E2k5IAFgFQE5kyG0ABQG1AAE5ExIAFAFQE2E5gBG3QAAG4k3E4IgBACQk6E2m2gBIgDAAQmyAAk6k1gAAANcQB+gBBahZIgBACQBZhZgBh9QAAh8hVhZIgFgFQhahUh7AAQh7AAhZBUIgFAFQhVBZAAB8QgBB9BZBZIgBgCQBaBZB9ABg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(6).to({graphics:mask_graphics_6,x:25.2228,y:112.1913}).wait(1).to({graphics:mask_graphics_7,x:25.2519,y:112.2199}).wait(1).to({graphics:mask_graphics_8,x:25.3469,y:112.3133}).wait(1).to({graphics:mask_graphics_9,x:25.5217,y:112.4849}).wait(1).to({graphics:mask_graphics_10,x:25.7944,y:112.7527}).wait(1).to({graphics:mask_graphics_11,x:26.1883,y:113.1395}).wait(1).to({graphics:mask_graphics_12,x:26.7332,y:113.6746}).wait(1).to({graphics:mask_graphics_13,x:27.4623,y:114.3907}).wait(1).to({graphics:mask_graphics_14,x:28.4017,y:115.3132}).wait(1).to({graphics:mask_graphics_15,x:29.54,y:116.4312}).wait(1).to({graphics:mask_graphics_16,x:30.7928,y:117.6615}).wait(1).to({graphics:mask_graphics_17,x:32.0193,y:118.8659}).wait(1).to({graphics:mask_graphics_18,x:33.1057,y:119.9329}).wait(1).to({graphics:mask_graphics_19,x:34.0107,y:120.8216}).wait(1).to({graphics:mask_graphics_20,x:34.7418,y:121.5396}).wait(1).to({graphics:mask_graphics_21,x:35.3237,y:122.1111}).wait(1).to({graphics:mask_graphics_22,x:35.7823,y:122.5615}).wait(1).to({graphics:mask_graphics_23,x:36.1395,y:122.9123}).wait(1).to({graphics:mask_graphics_24,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_25,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_26,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_27,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_28,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_29,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_30,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_31,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_32,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_33,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_34,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_35,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_36,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_37,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_38,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_39,x:36.3814,y:123.275}).wait(1).to({graphics:mask_graphics_40,x:36.5821,y:123.4748}).wait(1).to({graphics:mask_graphics_41,x:37.2606,y:124.1504}).wait(1).to({graphics:mask_graphics_42,x:38.5686,y:125.4528}).wait(1).to({graphics:mask_graphics_43,x:40.7236,y:127.5986}).wait(1).to({graphics:mask_graphics_44,x:44.0138,y:130.8747}).wait(1).to({graphics:mask_graphics_45,x:44.6864,y:135.5333}).wait(1).to({graphics:mask_graphics_46,x:44.7126,y:141.3663}).wait(1).to({graphics:mask_graphics_47,x:44.7394,y:147.3221}).wait(1).to({graphics:mask_graphics_48,x:44.7619,y:152.3416}).wait(1).to({graphics:mask_graphics_49,x:44.779,y:156.1603}).wait(1).to({graphics:mask_graphics_50,x:44.7916,y:158.9539}).wait(1).to({graphics:mask_graphics_51,x:44.8005,y:160.9559}).wait(1).to({graphics:mask_graphics_52,x:44.5689,y:162.1144}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// Layer_9
	this.instance = new lib.doodle2_1();
	this.instance.setTransform(49.4,204.5,0.6775,0.6775,0,161.6671,-18.3329,14.8,16.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(6).to({_off:false},0).to({_off:true},47).wait(7));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.doodle1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("EAKpApSQgIgLgDgQQgEgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADAQQADARgEANQgEAMgIACIirAhIgCAAQgIAAgHgIg");
	var mask_graphics_21 = new cjs.Graphics().p("EAKiApTQgIgLgDgQQgEgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEAMgIACIirAhIgCABQgIAAgHgJg");
	var mask_graphics_22 = new cjs.Graphics().p("EAKQApWQgJgLgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADARQAEAQgEANQgEAMgJACIiqAhIgDABQgHAAgHgJg");
	var mask_graphics_23 = new cjs.Graphics().p("EAJ2ApaQgIgLgEgQQgDgQAEgNQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgIABIirAhIgCABQgIAAgHgJg");
	var mask_graphics_24 = new cjs.Graphics().p("EAJdApeQgJgLgDgQQgDgQAEgNQAEgNAIgCICrghQAIgBAJAKQAIAKADARQAEAQgEANQgEANgJABIiqAiIgDAAQgHAAgHgJg");
	var mask_graphics_25 = new cjs.Graphics().p("EAJKAphQgJgLgDgQQgDgQAEgNQAEgNAJgCICqghQAJgBAIAKQAIAKAEARQADAQgEANQgEANgJABIiqAiIgCAAQgIAAgHgJg");
	var mask_graphics_26 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_27 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_28 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_29 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_30 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_31 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_32 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_33 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_34 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_35 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_36 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_37 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_38 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_39 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_40 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_41 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_42 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_43 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_44 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_45 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_46 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_47 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_48 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_49 = new cjs.Graphics().p("EAJDApiQgJgKgDgRQgDgQAEgNQAEgMAJgCICqghQAJgCAIAKQAIALAEAQQADARgEAMQgEANgJACIiqAhIgCAAQgIAAgHgJg");
	var mask_graphics_50 = new cjs.Graphics().p("EAJCApiQgJgKgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADAQQAEARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_graphics_51 = new cjs.Graphics().p("EAI+ApjQgJgKgDgRQgDgQAEgNQAEgNAIgBICrghQAIgCAJAKQAIALADAQQAEAQgEANQgEANgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_graphics_52 = new cjs.Graphics().p("EAI1AplQgIgLgDgQQgDgRADgMQAEgNAJgCICqghQAJgCAIALQAJAKADAQQADARgEANQgEAMgIACIirAhIgCAAQgHAAgIgIg");
	var mask_graphics_53 = new cjs.Graphics().p("EAImApnQgIgLgDgQQgDgQADgNQAEgNAJgCICqghQAJgBAJAKQAIAKADARQADAQgEANQgEANgIABIirAiIgCAAQgHAAgIgJg");
	var mask_graphics_54 = new cjs.Graphics().p("EAIRApqQgJgKgDgQQgDgRAEgMQAEgNAJgCICqghQAJgCAIALQAIAKAEAQQADARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgJg");
	var mask_graphics_55 = new cjs.Graphics().p("EAH8ApuQgIgLgEgQQgDgQAEgNQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgJABIiqAhIgCABQgIAAgHgJg");
	var mask_graphics_56 = new cjs.Graphics().p("EAHtApwQgIgKgDgRQgDgQAEgNQADgNAJgBICqghQAJgCAJAKQAIALADAQQADAQgEANQgEANgIACIirAhIgCAAQgHAAgIgJg");
	var mask_graphics_57 = new cjs.Graphics().p("EAHkApyQgIgLgEgQQgDgRAEgMQAEgNAJgCICqghQAJgCAIALQAJAKADARQADAQgEANQgEANgJABIiqAhIgCABQgIAAgHgJg");
	var mask_graphics_58 = new cjs.Graphics().p("EAHfApzQgJgLgDgQQgDgRAEgMQAEgNAIgCICrghQAIgCAJALQAIAKADAQQAEARgEANQgEAMgJACIiqAhIgDAAQgHAAgHgIg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:88.328,y:265.0434}).wait(1).to({graphics:mask_graphics_21,x:87.6448,y:265.1535}).wait(1).to({graphics:mask_graphics_22,x:85.7777,y:265.4541}).wait(1).to({graphics:mask_graphics_23,x:83.2273,y:265.8647}).wait(1).to({graphics:mask_graphics_24,x:80.6769,y:266.2753}).wait(1).to({graphics:mask_graphics_25,x:78.8099,y:266.5759}).wait(1).to({graphics:mask_graphics_26,x:78.103,y:266.7184}).wait(1).to({graphics:mask_graphics_27,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_28,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_29,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_30,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_31,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_32,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_33,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_34,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_35,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_36,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_37,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_38,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_39,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_40,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_41,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_42,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_43,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_44,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_45,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_46,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_47,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_48,x:78.1032,y:266.7185}).wait(1).to({graphics:mask_graphics_49,x:78.103,y:266.7184}).wait(1).to({graphics:mask_graphics_50,x:77.9916,y:266.7366}).wait(1).to({graphics:mask_graphics_51,x:77.5898,y:266.8017}).wait(1).to({graphics:mask_graphics_52,x:76.7468,y:266.9384}).wait(1).to({graphics:mask_graphics_53,x:75.2484,y:267.1814}).wait(1).to({graphics:mask_graphics_54,x:73.1011,y:267.5297}).wait(1).to({graphics:mask_graphics_55,x:71.0241,y:267.8665}).wait(1).to({graphics:mask_graphics_56,x:69.5549,y:268.1048}).wait(1).to({graphics:mask_graphics_57,x:68.6205,y:268.2563}).wait(1).to({graphics:mask_graphics_58,x:68.078,y:268.3434}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_3
	this.instance = new lib.doodle5_2();
	this.instance.setTransform(146.05,529.25,0.8671,0.8671,35.9343,0,0,8.6,7.7);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("EAJzAqoQgHgFgBgIQgBgHAEgHQAFgGAIgBQAHgCAHAFQAGAFACAHQABAIgFAHQgEAGgIABIgDABQgGAAgFgEg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAJsAqqQgIgGgCgLQgBgKAGgIQAGgIAKgCQAKgCAIAGQAJAGABALQACAKgGAIQgGAIgKACIgFAAQgHAAgHgEg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAJZAqvQgOgLgDgRQgDgRAKgOQALgPARgCQARgDAOAKQAPALADARQACARgKAOQgKAPgSACIgHABQgNAAgLgIg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAI4Aq3QgYgRgFgeQgFgdASgYQARgYAegFQAdgFAZASQAYARAFAeQAEAdgRAZQgSAYgdAEIgMABQgXAAgTgOg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAIbAq/QghgYgHgoQgGgoAYghQAYghAogHQAogGAhAYQAiAYAGAoQAHAogYAiQgYAhgoAGIgRABQgfAAgagTg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAIKArEQgmgcgIgvQgHguAcgmQAbgmAvgIQAugHAmAcQAnAbAHAvQAIAvgcAmQgbAmgvAHQgKACgJAAQgkAAgegWg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAICArGQgogegIgxQgIgxAdgpQAegoAxgJQAxgHApAdQApAeAIAxQAIAygeAoQgdApgxAHQgLACgKAAQgmAAgggXg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAIBArHQgpgegIgyQgIgyAegpQAegpAygJQAygHApAeQAqAeAIAyQAIAygeApQgeApgyAIQgKACgLAAQgmAAghgYg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAICArHQgpgegIgyQgIgxAegpQAegpAxgIQAygIApAeQAqAdAIAyQAIAygeApQgeApgxAIQgLACgKAAQgmAAghgYg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAIFArGQgogdgIgxQgIgwAdgoQAdgoAxgJQAxgHAoAdQAoAdAIAxQAIAxgdAoQgdAogxAIQgKABgKAAQglAAgggXg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAILArFQgngcgHgvQgHguAbgnQAcgmAvgIQAugHAnAcQAmAcAIAuQAHAvgbAnQgcAmgvAHQgKACgJAAQgkAAgegWg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAIUArCQgjgagHgrQgHgrAagjQAagjArgHQArgHAjAaQAkAZAHArQAHAsgaAjQgaAjgrAHIgSABQghAAgcgUg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAIkAq+QgfgWgGgmQgGglAWgfQAWgfAmgGQAlgGAfAXQAfAWAGAlQAGAmgWAfQgXAeglAGIgQABQgcAAgYgRg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAI3Aq4QgYgRgFgfQgFgdASgZQASgZAegEQAegFAYASQAZASAFAeQAFAegSAYQgSAZgeAEIgMABQgXAAgUgOg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAJLAqzQgSgOgEgWQgDgWANgTQAOgSAWgEQAWgEATAOQASANAEAXQAEAWgOATQgNASgWAEIgKAAQgRAAgPgKg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAJbAquQgNgJgDgRQgDgRAKgNQAKgOARgDQAQgCAOAKQANAKADAQQADARgKAOQgKANgQADIgHAAQgNAAgLgIg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAJmAqrQgKgHgCgMQgCgNAHgKQAIgKAMgCQANgCAKAHQAKAIACAMQACANgHAKQgIAKgMACIgFAAQgKAAgIgGg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAJuAqpQgIgFgCgKQgBgKAGgIQAFgHAKgCQAJgCAIAGQAIAGACAKQABAJgFAIQgGAIgKACIgEAAQgHAAgGgFg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAJzAqoQgHgFgBgIQgBgHAEgHQAFgGAIgBQAHgCAHAFQAGAFACAHQABAIgFAHQgEAGgIABIgDABQgGAAgFgEg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:65.679,y:273.1519}).wait(1).to({graphics:mask_1_graphics_23,x:65.9616,y:273.4331}).wait(1).to({graphics:mask_1_graphics_24,x:66.8163,y:274.2836}).wait(1).to({graphics:mask_1_graphics_25,x:68.2748,y:275.7349}).wait(1).to({graphics:mask_1_graphics_26,x:69.5655,y:277.0192}).wait(1).to({graphics:mask_1_graphics_27,x:70.3068,y:277.757}).wait(1).to({graphics:mask_1_graphics_28,x:70.6535,y:278.1019}).wait(1).to({graphics:mask_1_graphics_29,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_30,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_31,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_32,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_33,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_34,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_35,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_36,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_37,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_38,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_39,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_40,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_41,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_42,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_43,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_44,x:70.8826,y:278.2936}).wait(1).to({graphics:mask_1_graphics_45,x:70.845,y:278.2564}).wait(1).to({graphics:mask_1_graphics_46,x:70.7146,y:278.1275}).wait(1).to({graphics:mask_1_graphics_47,x:70.4547,y:277.8703}).wait(1).to({graphics:mask_1_graphics_48,x:70.0104,y:277.4309}).wait(1).to({graphics:mask_1_graphics_49,x:69.3206,y:276.7486}).wait(1).to({graphics:mask_1_graphics_50,x:68.4094,y:275.8472}).wait(1).to({graphics:mask_1_graphics_51,x:67.4961,y:274.9437}).wait(1).to({graphics:mask_1_graphics_52,x:66.7784,y:274.2339}).wait(1).to({graphics:mask_1_graphics_53,x:66.2716,y:273.7325}).wait(1).to({graphics:mask_1_graphics_54,x:65.9267,y:273.3914}).wait(1).to({graphics:mask_1_graphics_55,x:65.679,y:273.1519}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_5
	this.instance_1 = new lib.doodle5_3();
	this.instance_1.setTransform(133.5,542.5,0.8671,0.8671,35.9343,0,0,9.2,7);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_8 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_16 = new cjs.Graphics().p("EAKIAqMQgNgRgFgaQgFgaAGgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAVQgGAUgOACIkQA1IgDABQgMAAgMgOg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EAKFAqMQgNgRgFgaQgGgaAHgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAbQAFAagGAUQgGAUgOADIkQA1IgEAAQgLAAgMgOg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EAJ5AqOQgNgQgFgaQgGgaAHgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAUQgGAVgOACIkQA1IgEABQgLAAgMgPg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EAJeAqUQgOgRgFgaQgFgaAHgVQAGgUAOgDIEPg1QAOgCAOAQQANARAFAaQAFAagGAVQgGAUgOADIkQA0IgEABQgMAAgLgOg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EAIxAqcQgNgRgFgaQgFgaAGgUQAGgVAOgCIEQg1QAOgDANARQANAQAFAaQAGAbgHAUQgGAUgOADIkPA1IgEAAQgMAAgMgOg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EAIJAqkQgNgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QANgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkPA1IgEAAQgMAAgMgOg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EAHxAqoQgNgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QANgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkPA1IgEAAQgMAAgMgOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAHlAqrQgOgRgFgaQgFgaAGgUQAGgVAOgDIEQg0QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAHjAqrQgOgRgFgaQgFgaAHgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAaQAFAbgGAUQgGAUgOADIkQA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAHeAqsQgOgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QAOgDANARQAOARAFAaQAFAagGAUQgHAVgOACIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAHTAqvQgOgRgFgaQgFgaAHgUQAGgVAOgDIEPg0QAOgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkQA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAHAAqzQgNgRgFgaQgFgaAGgUQAGgVAOgCIEPg1QAOgDAOARQANAQAFAaQAFAbgGAUQgGAUgOADIkQA1IgEAAQgLAAgMgOg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAGjAq6QgNgRgFgaQgFgaAGgVQAGgUAOgDIEQg1QAOgCANAQQANARAFAaQAFAagGAVQgGAUgOADIkPA0IgEABQgMAAgMgOg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAGCArBQgOgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QAOgDANARQAOARAFAaQAFAagGAUQgHAVgOACIkPA1IgEAAQgMAAgLgOg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAFlArIQgNgRgFgaQgFgaAGgUQAGgVAOgDIEPg0QAOgDAOARQANAQAFAaQAFAagGAVQgGAUgOADIkQA1IgDAAQgMAAgMgOg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAFRArMQgNgQgFgaQgFgbAGgUQAGgUAOgDIEQg1QANgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkPA1IgEABQgMAAgMgPg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAFEArPQgNgQgFgaQgFgbAGgUQAGgUAOgDIEPg1QAOgDAOARQANARAFAaQAFAagGAUQgGAVgOACIkQA1IgDABQgMAAgMgPg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAE7ArRQgNgRgFgaQgFgaAGgUQAGgVAOgCIEQg1QAOgDANARQANAQAFAaQAGAagHAVQgGAUgOADIkPA1IgEAAQgMAAgMgOg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_2_graphics_16,x:97.0494,y:271.3687}).wait(1).to({graphics:mask_2_graphics_17,x:96.7375,y:271.4284}).wait(1).to({graphics:mask_2_graphics_18,x:95.5374,y:271.6574}).wait(1).to({graphics:mask_2_graphics_19,x:92.8225,y:272.1755}).wait(1).to({graphics:mask_2_graphics_20,x:88.3728,y:273.0247}).wait(1).to({graphics:mask_2_graphics_21,x:84.3627,y:273.79}).wait(1).to({graphics:mask_2_graphics_22,x:81.9606,y:274.2484}).wait(1).to({graphics:mask_2_graphics_23,x:80.6744,y:274.4937}).wait(1).to({graphics:mask_2_graphics_24,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_25,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_26,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_27,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_28,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_29,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_30,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_31,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_32,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_33,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_34,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_35,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_36,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_37,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_38,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_39,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_40,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_41,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_42,x:80.6746,y:274.4938}).wait(1).to({graphics:mask_2_graphics_43,x:80.6744,y:274.4937}).wait(1).to({graphics:mask_2_graphics_44,x:80.525,y:274.528}).wait(1).to({graphics:mask_2_graphics_45,x:79.9976,y:274.6483}).wait(1).to({graphics:mask_2_graphics_46,x:78.9219,y:274.8938}).wait(1).to({graphics:mask_2_graphics_47,x:77.0439,y:275.3223}).wait(1).to({graphics:mask_2_graphics_48,x:74.1712,y:275.9778}).wait(1).to({graphics:mask_2_graphics_49,x:70.7931,y:276.7486}).wait(1).to({graphics:mask_2_graphics_50,x:67.9489,y:277.3976}).wait(1).to({graphics:mask_2_graphics_51,x:65.96,y:277.8514}).wait(1).to({graphics:mask_2_graphics_52,x:64.6491,y:278.1505}).wait(1).to({graphics:mask_2_graphics_53,x:63.7744,y:278.3187}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_9
	this.instance_2 = new lib.doodle5_1();
	this.instance_2.setTransform(144,542.15,0.8671,0.8671,35.9343,0,0,13.7,14.1);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160.6,600);


(lib.bgScreens = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img5
	this.img5 = new lib.img5();
	this.img5.name = "img5";
	this.img5.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img5).wait(1));

	// img4
	this.img4 = new lib.img4();
	this.img4.name = "img4";
	this.img4.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img3
	this.img3 = new lib.img3();
	this.img3.name = "img3";
	this.img3.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img2
	this.img2 = new lib.img2();
	this.img2.name = "img2";
	this.img2.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgScreens, new cjs.Rectangle(-12.6,199.3,199.5,273.7), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.scribbleClip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// scribble5
	this.scribble5 = new lib.scribble5();
	this.scribble5.name = "scribble5";
	this.scribble5.setTransform(-13.95,339.9,1.1,1.1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble5).wait(1));

	// scribble4
	this.scribble4 = new lib.scribble4();
	this.scribble4.name = "scribble4";
	this.scribble4.setTransform(18.7,304.65,1.395,1.395,0,0,0,149.9,125.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble4).wait(1));

	// scribble3
	this.scribble3 = new lib.scribble3();
	this.scribble3.name = "scribble3";
	this.scribble3.setTransform(184.05,293.95,1.8,1.8,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble3).wait(1));

	// scribble2
	this.scribble2 = new lib.scribble2();
	this.scribble2.name = "scribble2";
	this.scribble2.setTransform(58.1,248,1.3,1.3,0,0,0,150,125.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble2).wait(1));

	// scribble1
	this.scribble1 = new lib.scribble1();
	this.scribble1.name = "scribble1";
	this.scribble1.setTransform(-133,332,2.5499,2.5499,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribbleClip, new cjs.Rectangle(-515.5,-70.1,1365.6,720.8000000000001), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// CTA_arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(85.65,14.95,0.7084,0.65,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AoKCOIAAkbIQUAAIAAEbg");
	this.shape.setTransform(52.25,14.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,0.5,104.5,28.5), null);


(lib.doodleClip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// doodle5
	this.doodle5 = new lib.doodle5();
	this.doodle5.name = "doodle5";
	this.doodle5.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle5).wait(1));

	// doodle4
	this.doodle4 = new lib.doodle4();
	this.doodle4.name = "doodle4";
	this.doodle4.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle4).wait(1));

	// doodle3
	this.doodle3 = new lib.doodle3();
	this.doodle3.name = "doodle3";
	this.doodle3.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle3).wait(1));

	// doodle2
	this.doodle2 = new lib.doodle2();
	this.doodle2.name = "doodle2";
	this.doodle2.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle2).wait(1));

	// doodle1
	this.doodle1 = new lib.doodle1();
	this.doodle1.name = "doodle1";
	this.doodle1.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodleClip, new cjs.Rectangle(0,0,160,600), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// navHits
	this.hit5 = new lib.option_hit();
	this.hit5.name = "hit5";
	this.hit5.setTransform(112.9,510.7,0.9992,2.8433,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit5, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit4 = new lib.option_hit();
	this.hit4.name = "hit4";
	this.hit4.setTransform(96.95,510.7,0.9992,2.8433,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit4, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(80.75,510.7,0.9992,2.8433,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(64.75,510.7,0.9992,2.8433,0,0,0,0,0.2);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(48.6,510.7,0.9992,2.8433,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hitNext = new lib.option_hit();
	this.hitNext.name = "hitNext";
	this.hitNext.setTransform(136.05,510.25,1.8835,2.9581,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.hitNext, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hitPrev = new lib.option_hit();
	this.hitPrev.name = "hitPrev";
	this.hitPrev.setTransform(24.65,510.55,1.9725,2.958,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hitPrev, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hitPrev},{t:this.hitNext},{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit4},{t:this.hit5}]}).wait(1));

	// hit
	this.hit = new lib.option_hit();
	this.hit.name = "hit";
	this.hit.setTransform(0,0.25,10,37.0375,0,0,0,-8,-8.1);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// introLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(0.05,0,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// nav
	this.nav = new lib.Page_indicator();
	this.nav.name = "nav";
	this.nav.setTransform(96.85,512.3,1.0461,1.0461,0,0,0,59.1,6);

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// CTA_txt
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(28.2,569.6,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(28.2,555.3,1,1,0,0,0,0.2,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// bgScreens
	this.screens = new lib.bgScreens();
	this.screens.name = "screens";
	this.screens.setTransform(124,94.5,1,1,0,0,0,124,94.5);

	this.timeline.addTween(cjs.Tween.get(this.screens).wait(1));

	// doodle
	this.doodle = new lib.doodleClip();
	this.doodle.name = "doodle";
	this.doodle.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(73.05,394.05,1,1,0,0,0,125.9,52.6);
	this.grid.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.scribbleClip();
	this.scribble.name = "scribble";
	this.scribble.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-515.5,-70.1,1365.6,720.8000000000001), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
				
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "subh") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillSubHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillSubHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillSmallPrint = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var img1 = mc.screens.img1
		
		exportRoot.init_img1_x = mc.screens.img1.x;
		exportRoot.init_img2_x = mc.screens.img2.x;
		exportRoot.init_img3_x = mc.screens.img3.x;
		exportRoot.init_img4_x = mc.screens.img4.x;
		exportRoot.init_img5_x = mc.screens.img5.x;
		
		var init_headline_x 
		
		this.runBanner = function() {
			
				var maxNav = 5	
				mc.cta.alpha=1
			
				var nxt = mc.hitNext
				var prv = mc.hitPrev
				var hit1 = mc.hit1
				var hit2 = mc.hit2
				var hit3 = mc.hit3
				var hit4 = mc.hit4
				var hit5 = mc.hit5
				var hit6 = mc.hit6
			
				var initXpos = 0
				var initOffset = 325
					
				var subHeadPos = exportRoot.headline1.x
			
				var prevSelection = 0
				exportRoot.currentSelection = 1
			
				var nav = mc.nav
			
				hit1.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 1;
						amoAd.onInteraction('Dot1 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit2.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 2;
						amoAd.onInteraction('Dot2 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit3.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 3;
						amoAd.onInteraction('Dot3 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit4.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 4;
						amoAd.onInteraction('Dot4 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit5.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 5;
						amoAd.onInteraction('Dot5 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				nxt.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						exportRoot.animInProgress=true
						exportRoot.getSelectionId("next")
						amoAd.onInteraction('Next Click', exportRoot.currentSelection-1);
						exportRoot.gotoNextNav()
						exportRoot.scribbleAnim()
						exportRoot.nextScene();
					}
				});

				prv.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						exportRoot.animInProgress=true
						exportRoot.getSelectionId("prev")
						amoAd.onInteraction('Prev Click', exportRoot.currentSelection-1);
						exportRoot.gotoNextNav();
						exportRoot.scribbleAnim()
						exportRoot.prevScene();
					}
				});
				
				exportRoot.gotoNextNav = function() {
					for (var i=1;i<=maxNav;i++) {
						if (nav["dot_"+i].currentFrame > 15) nav["dot_"+i].gotoAndPlay("deselected")
					}
					nav["dot_"+exportRoot.currentSelection].gotoAndPlay("selected");			
				}
				
				exportRoot.getSelectionId = function(direction) {
					prevSelection = exportRoot.currentSelection
					if (direction == "next") {
						if (exportRoot.currentSelection == maxNav) {
							exportRoot.currentSelection = 1
						} else {
							exportRoot.currentSelection++
						}
					} else if (direction == "prev") {
						if (exportRoot.currentSelection == 1) {
							exportRoot.currentSelection = maxNav
						} else {
							exportRoot.currentSelection--
						}
					}
				}
				
				exportRoot.subHeadMoveCheck = function() {
				}
				
				exportRoot.scribbleAnim = function() {
						if (prevSelection > 0) {
							mc.scribble["scribble"+prevSelection].gotoAndPlay("out");
							mc.doodle["doodle"+prevSelection].gotoAndPlay("out");
		
						}
						gsap.delayedCall(0.5,function(){
							mc.scribble["scribble"+exportRoot.currentSelection].gotoAndPlay("in");
							mc.doodle["doodle"+exportRoot.currentSelection].gotoAndPlay("in");
						})
				}
				
				
						
			exportRoot.tl0 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl0.add("left");
			exportRoot.tl0.add("mid");
			exportRoot.tl0.add("right");
			exportRoot.tl0.pause();
			
			exportRoot.tl1 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl1.add("right");
			exportRoot.tl1.from(mc.screens.img1.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl1.from(mc.screens.img1.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl1.from(mc.screens.img1.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl1.add("mid");
			exportRoot.tl1.to(mc.screens.img1.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl1.to(mc.screens.img1.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl1.to(mc.screens.img1.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl1.add("left");	
			exportRoot.tl1.pause();
			
			exportRoot.tl2 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl2.add("right");
			exportRoot.tl2.from(mc.screens.img2.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl2.from(mc.screens.img2.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl2.from(mc.screens.img2.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl2.add("mid");
			exportRoot.tl2.to(mc.screens.img2.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl2.to(mc.screens.img2.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl2.to(mc.screens.img2.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl2.add("left");
			exportRoot.tl2.pause();
			
			exportRoot.tl3 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl3.add("right");
			exportRoot.tl3.from(mc.screens.img3.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl3.from(mc.screens.img3.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl3.from(mc.screens.img3.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl3.add("mid");
			exportRoot.tl3.to(mc.screens.img3.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl3.to(mc.screens.img3.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl3.to(mc.screens.img3.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl3.add("left");
			exportRoot.tl3.pause();
			
			exportRoot.tl4 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl4.add("right");
			exportRoot.tl4.from(mc.screens.img4.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl4.from(mc.screens.img4.sub2, 1, { x: "+=140", alpha: 0},"<");
			exportRoot.tl4.from(mc.screens.img4.sub3, 1, { x: "+=200", alpha: 0},"<");
			exportRoot.tl4.add("mid");
			exportRoot.tl4.to(mc.screens.img4.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl4.to(mc.screens.img4.sub2, 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl4.to(mc.screens.img4.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl4.add("left");
			exportRoot.tl4.pause();
			
			exportRoot.tl5 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl5.add("right");
			exportRoot.tl5.from(mc.screens.img5.sub1, 1, { x: "+=80", alpha: 0});
			exportRoot.tl5.from([mc.screens.img5.sub2, mc.screens.img5.sub2Shadow], 1, { x: "+=150", alpha: 0},"<");
			exportRoot.tl5.from(mc.screens.img5.sub3, 1, { x: "+=300", alpha: 0},"<");
			exportRoot.tl5.from(mc.screens.img5.sub2, .4, { rotation:"+=10"}, ">-.2");
			exportRoot.tl5.from(mc.screens.img5.sub3, .4, { rotation:"+=10"}, ">-.2");
			exportRoot.tl5.add("mid");
			exportRoot.tl5.to(mc.screens.img5.sub3, 1, { x:  "-=80", alpha: 0});
			exportRoot.tl5.to([mc.screens.img5.sub2, mc.screens.img5.sub2Shadow], 1, { x:  "-=140", alpha: 0},"<");
			exportRoot.tl5.to(mc.screens.img5.sub1, 1, { x:  "-=200", alpha: 0},"<");
			exportRoot.tl5.to(mc.screens.img5.sub2, .4, { rotation:"+=10"}, "<");
			exportRoot.tl5.to(mc.screens.img5.sub3, .4, { rotation:"+=10"}, "<+.2");
			exportRoot.tl5.add("left");
			exportRoot.tl5.pause();
			
				exportRoot.tlSubHeadMove = gsap.timeline();
		
				exportRoot.tlSubHeadMove.add("out");
				exportRoot.tlSubHeadMove.to(exportRoot.subheadline1, .5, { y: "-=20", ease:Power2.easeInOut});	
				exportRoot.tlSubHeadMove.add("in");
				
				exportRoot.tlSubHeadMove.pause();		
				
				init_headline_x = exportRoot.headline1[0].x
				
				exportRoot.nextScene = function() {
					exportRoot.subHeadMoveCheck(exportRoot.currentSelection);
								
					exportRoot.tlNext = gsap.timeline();
					exportRoot.tlNext.to(mc.screens["img"+exportRoot.currentSelection], 0, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]+initOffset/6, alpha: 0});		
					exportRoot.tlNext.to(exportRoot["headline"+exportRoot.currentSelection], 0, { x:init_headline_x+initOffset/3, alpha: 0});		
					
					if(prevSelection==0) {prevSelection=5;}
					exportRoot.tlNext.to(exportRoot["headline"+prevSelection], 0.6, { x:init_headline_x-initOffset/3, alpha: 0, ease:Power2.easeIn, stagger:0.03});
					exportRoot.tlNext.to(mc.screens["img"+prevSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]-initOffset/6, alpha: 0, ease:Power2.easeIn, onStart:function(){exportRoot["tl"+prevSelection].tweenFromTo("mid","left", {duration:0.6, ease:Power2.easeIn});}},"<+0.1");			
						
					exportRoot.tlNext.to(exportRoot["headline"+exportRoot.currentSelection], 0.6, { x:init_headline_x, alpha: 1, ease:Power2.easeOut, stagger:0.03},"<+0.3");
					exportRoot.tlNext.to(mc.screens["img"+exportRoot.currentSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"], alpha: 1, ease:Power2.easeOut, onStart:function(){exportRoot["tl"+exportRoot.currentSelection].tweenFromTo("right","mid", {duration:0.6, ease:Power2.easeOut});}, onComplete:function(){exportRoot.animInProgress=false;}},"<+0.2");
				}
				
				exportRoot.prevScene = function() {
					exportRoot.subHeadMoveCheck(exportRoot.currentSelection);
					
					exportRoot.tlBack = gsap.timeline();
					exportRoot.tlBack.to(mc.screens["img"+exportRoot.currentSelection], 0, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]-initOffset/6, alpha: 0});		
					exportRoot.tlBack.to(exportRoot["headline"+exportRoot.currentSelection], 0, { x:init_headline_x-initOffset/3, alpha: 0});		
					
					exportRoot.tlBack.to(mc.screens["img"+prevSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]+initOffset/6, alpha: 0, ease:Power2.easeIn, onStart:function(){exportRoot["tl"+prevSelection].tweenFromTo("mid","right", {duration:0.6, ease:Power2.easeIn});}});			
					exportRoot.tlBack.to(exportRoot["headline"+prevSelection], 0.6, { x:init_headline_x+initOffset/3, alpha: 0, ease:Power2.easeIn, stagger:0.03},"<+0.1");
						
					exportRoot.tlBack.to(mc.screens["img"+exportRoot.currentSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"], alpha: 1, ease:Power2.easeOut, onStart:function(){exportRoot["tl"+exportRoot.currentSelection].tweenFromTo("left","mid", {duration:0.6, ease:Power2.easeOut});}, onComplete:function(){exportRoot.animInProgress=false}},"<+0.3");
					exportRoot.tlBack.to(exportRoot["headline"+exportRoot.currentSelection], 0.6, { x:init_headline_x, alpha: 1, ease:Power2.easeOut, stagger:0.03},"<+0.2");
		
				}
				
				exportRoot.animStart = function() {
					exportRoot.tlText = gsap.timeline();			
					exportRoot.tlText.to([exportRoot.headline1,exportRoot.headline2,exportRoot.headline3,exportRoot.headline4,exportRoot.headline5,mc.screens.img1,mc.screens.img2,mc.screens.img3,mc.screens.img4,mc.screens.img5], 0, { alpha: 0, onStart:function(){exportRoot.nextScene(), exportRoot.gotoNextNav();}});
					exportRoot.tlText.to(exportRoot.subheadline1, 0, {x:"+=150", alpha: 0});
					exportRoot.tlText.to(exportRoot.subheadline1, .8, { x: "-=150", alpha: 1, ease:Power4.easeOut, stagger:0.05},">+.45");
					exportRoot.tlText.from(exportRoot.mainMC.nav, .8, { alpha:0, ease:Power4.easeOut},"<+.1");
					exportRoot.tlText.from([mc.cta,mc.txtCta], { duration: 0.8, x: "-=200", ease:Power4.easeOut, onStart:function(){mc.scribble.scribble1.play(),mc.doodle.doodle1.play();}}, ">-0.6");
					//exportRoot.tlText.pause();
				}
					
				mc.logo_intro.gotoAndPlay(1);
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9968,0.9997,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-433.8,229.9,1281.2,420.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#DBDBDD",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1.png?1622648610252", id:"M365_FY22Q1BTS_USA_160x600_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_2_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;