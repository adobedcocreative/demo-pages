(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[754,889,137,21],[754,824,112,63],[632,766,120,124],[0,0,734,508],[0,510,630,420],[632,510,189,126],[0,932,628,419],[632,638,189,126],[754,766,155,56],[630,932,136,320]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.angledShadowSml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap58 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.cursor = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.laptop = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.LinkedIn_Screen = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.LinkedInEndFrame300x600 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Word_Editor_Simplified_Screen = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Word_Editor_Simplified_Screen_M = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.wordDropdown = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.wordPanel = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wordPanel_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.wordPanel();
	this.instance.setTransform(0,0,0.432,0.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordPanel_1, new cjs.Rectangle(0,0,58.8,138.3), null);


(lib.wordDropdown_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.wordDropdown();
	this.instance.setTransform(0,0,0.432,0.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordDropdown_1, new cjs.Rectangle(0,0,67,24.2), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdCXQMAAAkufMCY7AAAMAAAEufg");
	this.shape.setTransform(0.975,555.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-488.4,-412.3,978.8,1936);


(lib.socialScreenEnd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.LinkedInEndFrame300x600();
	this.instance.setTransform(-0.4,83.4,0.85,0.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.socialScreenEnd, new cjs.Rectangle(-0.4,82.3,160.70000000000002,108.2), null);


(lib.sml = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Word_Editor_Simplified_Screen_M();
	this.instance.setTransform(0,0.35,1.435,1.435);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sml, new cjs.Rectangle(0,0,271.2,181.2), null);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pointerc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhKBlQgkgXgRihQgBgJAFgGQAGgGAIgBQAIgBAGAFQAHAFABAIQAFA3ALAtQAKAuAJAJQAMADAtgSQAtgSAxgaQAHgEAIADQAIACAEAHQAEAHgCAIQgDAJgHADQh2BAgzAAQgOAAgJgGg");
	this.shape.setTransform(12.8311,10.6417);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointerc, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.117,21.817,0.3866,0.3866);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.5116,21.817,0.3866,0.3866);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.117,7.2116,0.3866,0.3866);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.5116,7.2116,0.3866,0.3866);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.306,14.0513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.0359,14.6545,0.3866,0.3866);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.8276,14.5095,0.3866,0.3866);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.3681,14.5095,0.3866,0.3866);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(-0.1,0.6,228.2,55.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.laptopSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.laptop();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.laptopSub, new cjs.Rectangle(0,0,367,254), null);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL7A/XMAAAh+tMCX3AAAMAAAB+tg");
	this.shape.setTransform(486,405.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(0,0,972,811), null);


(lib.highlight_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AgNCGQlwggh6ATQg3AKgughQgtgggKg3QgJg2AgguQAhgtA3gKQCLgaGiAkQFxAgB/gTQA3gJAuAhQAtAgAJA3QAJA2ggAuQghAtg3AKQg8AKhrAAQiXAAj0gVg");
	this.shape.setTransform(66.1902,15.5585);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.highlight_sub, new cjs.Rectangle(0,0,132.4,31.1), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.editorCursor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cursor();
	this.instance.setTransform(0,-32.2,0.5101,0.5101);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.editorCursor, new cjs.Rectangle(0,-32.2,61.2,63.300000000000004), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.dropdown1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap58();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.dropdown1, new cjs.Rectangle(0,0,56,31.5), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AoECJIAAkRIQJAAIAAERg");
	this.shape.setTransform(50.1,14.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-1.6,0.4,103.39999999999999,27.400000000000002), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.arc_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkCCeQgIgEgDgHQgDgIADgIQBrj0DbgmQBugTBcAeQAHADAEAHQADAIgCAIQgDAIgHADQgIAEgIgDQhXgdhjASQjCAlhhDfQgFAMgNAAIgIgBg");
	this.shape.setTransform(27.1896,15.9604);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc_c, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.angledShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.angledShadowSml();
	this.instance.setTransform(11.6,0.15,1.3639,1.3639);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.angledShadow, new cjs.Rectangle(0,0,206.1,31.5), null);


(lib.wordScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlZCDIAAkFIKzAAIAAEFg");
	mask.setTransform(177.775,159.675);

	// Layer_4
	this.dropdown = new lib.wordDropdown_1();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(176.65,158.7,1,1,0,0,0,33.5,12.1);

	var maskedShapeInstanceList = [this.dropdown];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// Layer_3
	this.panel = new lib.wordPanel_1();
	this.panel.name = "panel";
	this.panel.setTransform(241.8,99.45,1,1,0,0,0,29.4,69.1);

	this.timeline.addTween(cjs.Tween.get(this.panel).wait(1));

	// Layer_2
	this.instance = new lib.Word_Editor_Simplified_Screen();
	this.instance.setTransform(0,0,0.4321,0.4321);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordScreen, new cjs.Rectangle(0,0,271.4,181.1), null);


(lib.socialScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ak9CtIAAlZIJ7AAIAAFZg");
	mask.setTransform(101.45,67.325);

	// Layer_3
	this.dropdown = new lib.dropdown1();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(73.75,50.7,0.8702,0.8702,0,0,0,0.1,0.1);

	var maskedShapeInstanceList = [this.dropdown];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// Layer_2
	this.instance = new lib.LinkedIn_Screen();
	this.instance.setTransform(0,0,0.4303,0.4303);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.socialScreen, new cjs.Rectangle(0,0,271.1,180.8), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.pointer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointer.cache(0,0,30,25,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointer = new lib.pointerc();
	this.pointer.name = "pointer";
	this.pointer.setTransform(12.8,10.7,1,1,0,0,0,12.8,10.7);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.highlight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.highlight.cache(-140,-40,280,80,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.highlight = new lib.highlight_sub();
	this.highlight.name = "highlight";
	this.highlight.setTransform(52.7,2.1,1,1,0,0,0,66.2,15.6);

	this.timeline.addTween(cjs.Tween.get(this.highlight).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.highlight, new cjs.Rectangle(-13.5,-13.5,132.4,31.1), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,250,10,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgFJBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_15 = new cjs.Graphics().p("EgFUBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_16 = new cjs.Graphics().p("EgF3BJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_17 = new cjs.Graphics().p("EgGxBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_18 = new cjs.Graphics().p("EgICBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_19 = new cjs.Graphics().p("EgJqBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_20 = new cjs.Graphics().p("EgLqBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_21 = new cjs.Graphics().p("EgNpBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_22 = new cjs.Graphics().p("EgPSBJ2IAAqHMA3xAAAIAAKHg");
	var mask_graphics_23 = new cjs.Graphics().p("EgQjBJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_24 = new cjs.Graphics().p("EgRdBJ2IAAqHMA3xAAAIAAKHg");
	var mask_graphics_25 = new cjs.Graphics().p("EgR/BJ2IAAqHMA3wAAAIAAKHg");
	var mask_graphics_26 = new cjs.Graphics().p("EgSLBJ2IAAqHMA3wAAAIAAKHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:323.9456,y:472.6093}).wait(1).to({graphics:mask_graphics_15,x:322.7869,y:472.6093}).wait(1).to({graphics:mask_graphics_16,x:319.3108,y:472.6093}).wait(1).to({graphics:mask_graphics_17,x:313.5174,y:472.6093}).wait(1).to({graphics:mask_graphics_18,x:305.4067,y:472.6093}).wait(1).to({graphics:mask_graphics_19,x:294.9786,y:472.6093}).wait(1).to({graphics:mask_graphics_20,x:282.2331,y:472.6093}).wait(1).to({graphics:mask_graphics_21,x:269.4876,y:472.6093}).wait(1).to({graphics:mask_graphics_22,x:259.0595,y:472.6093}).wait(1).to({graphics:mask_graphics_23,x:250.9487,y:472.6093}).wait(1).to({graphics:mask_graphics_24,x:245.1553,y:472.6093}).wait(1).to({graphics:mask_graphics_25,x:241.6793,y:472.6093}).wait(1).to({graphics:mask_graphics_26,x:240.5206,y:472.6093}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-3.25,909.35,2.9988,2.9988,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({regX:0.2,x:212.45},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:173.3,y:75.1},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(259.65,912.6,0.608,0.608,0,0,0,485.9,405.6);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(258.7,913.05,0.1812,0.1812,0,0,0,-39.5,1.9);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:2.9988,scaleY:2.9988,x:258.6,y:912.95},13,cjs.Ease.quadOut).to({x:91.9},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgoTChGMAAAlCLMBQnAAAMAAAFCLg");
	this.shape.setTransform(258,1031);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(250.1,326.05,0.608,1.0591,0,0,0,0.1,0.1);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({regX:0,regY:0.9,scaleX:1,scaleY:1.1007,x:301.45,y:386.55,alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187,-110.7,978.8,2174.2);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.arc.cache(0,0,55,35,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.arc = new lib.arc_c();
	this.arc.name = "arc";
	this.arc.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.arc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("ApzNIQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwByhxAuMgi6AOGQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_54 = new cjs.Graphics().p("Ap3NKQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOFQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_55 = new cjs.Graphics().p("AqENPQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_56 = new cjs.Graphics().p("AqiNbQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAuMgi5AOGQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_57 = new cjs.Graphics().p("ArVNwQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQByAwAuByQAvBygxBxQgwByhyAuMgi5AOFQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_58 = new cjs.Graphics().p("AsaOMQhxgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_59 = new cjs.Graphics().p("AtdOnQhxgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvByhyAtMgi5AOHQg4AWg3AAQg7AAg6gZg");
	var mask_graphics_60 = new cjs.Graphics().p("AuTO9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAvQBzAxAuByQAuBygxBxQgwBwhxAvMgi6AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_61 = new cjs.Graphics().p("Au8PNQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gZg");
	var mask_graphics_62 = new cjs.Graphics().p("AvbPaQhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBwAwQBzAwAuByQAuBygxBxQgwBxhyAuMgi5AOGQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_63 = new cjs.Graphics().p("AvzPkQhxgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg6gZg");
	var mask_graphics_64 = new cjs.Graphics().p("AwHPsQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBxAvQByAxAuByQAuBygxBxQgvBwhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_65 = new cjs.Graphics().p("AwWPyQhwgwguhyQguhyAvhyQAxhxByguMAi5gOFQByguBwAvQBzAxAuByQAuBygxBxQgvBwhyAuMgi6AOHQg3AXg4AAQg6AAg7gZg");
	var mask_graphics_66 = new cjs.Graphics().p("AwiP3QhwgwguhyQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAxAuByQAuBygxBwQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg7gYg");
	var mask_graphics_67 = new cjs.Graphics().p("AwrP6QhwgwguhxQguhyAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_68 = new cjs.Graphics().p("AwyP9QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_69 = new cjs.Graphics().p("Aw3P/QhwgwguhyQguhyAvhxQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi5AOGQg4AXg3AAQg7AAg7gZg");
	var mask_graphics_70 = new cjs.Graphics().p("Aw6QAQhwgvguhyQguhyAvhyQAxhxByguMAi5gOGQByguBwAwQBzAxAuBxQAuBygxBxQgwBxhxAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_71 = new cjs.Graphics().p("Aw8QBQhwgwguhyQguhxAvhyQAxhxByguMAi5gOGQByguBxAwQByAwAuByQAuBygxBxQgvBxhyAuMgi6AOHQg3AWg4AAQg6AAg7gZg");
	var mask_graphics_72 = new cjs.Graphics().p("Aw8QBQhxgvguhyQguhyAvhyQAxhxByguMAi6gOGQBxguBxAwQByAxAuBxQAuBygxBxQgvBxhyAuMgi5AOHQg4AWg3AAQg7AAg6gZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:202.0962,y:86.5199}).wait(1).to({graphics:mask_graphics_54,x:201.7207,y:86.6713}).wait(1).to({graphics:mask_graphics_55,x:200.3452,y:87.2276}).wait(1).to({graphics:mask_graphics_56,x:197.4159,y:88.4121}).wait(1).to({graphics:mask_graphics_57,x:192.2778,y:90.4898}).wait(1).to({graphics:mask_graphics_58,x:185.33,y:93.2993}).wait(1).to({graphics:mask_graphics_59,x:178.6284,y:96.0092}).wait(1).to({graphics:mask_graphics_60,x:173.2948,y:98.166}).wait(1).to({graphics:mask_graphics_61,x:169.2189,y:99.8141}).wait(1).to({graphics:mask_graphics_62,x:166.0817,y:101.0827}).wait(1).to({graphics:mask_graphics_63,x:163.6368,y:102.0714}).wait(1).to({graphics:mask_graphics_64,x:161.716,y:102.8481}).wait(1).to({graphics:mask_graphics_65,x:160.2043,y:103.4594}).wait(1).to({graphics:mask_graphics_66,x:159.0208,y:103.938}).wait(1).to({graphics:mask_graphics_67,x:158.1068,y:104.3076}).wait(1).to({graphics:mask_graphics_68,x:157.4183,y:104.586}).wait(1).to({graphics:mask_graphics_69,x:156.9218,y:104.7867}).wait(1).to({graphics:mask_graphics_70,x:156.5909,y:104.9205}).wait(1).to({graphics:mask_graphics_71,x:156.4046,y:104.9959}).wait(1).to({graphics:mask_graphics_72,x:156.3462,y:105.0199}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(102.75,162.9,1,1,0,0,0,42,16.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AQ4K1MgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AQ4K6MgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AQ4LGMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AQ4LaMgkNgKFQh3ghg8hrQg8hqAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AQ4LyMgkNgKEQh3ghg8hrQg8hqAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AQ4MNMgkNgKEQh3ghg8hrQg8hqAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AQ4MpMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AQ4NBMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg8B3AhMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AQ4NVMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg9QBrg8B3AhMAkMAKDQB3AhA8BqQA9BsghB3QghB2hsA7QhFAohKAAQgoAAgpgLg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AQ4NhMgkNgKEQh3ghg8hsQg8hpAgh2QAhh3Brg9QBrg7B3AgMAkMAKEQB3AhA8BqQA9BsghB2QghB2hsA8QhFAohKAAQgoAAgpgMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AQ4NmMgkNgKFQh3ghg8hsQg8hpAgh2QAhh2Brg+QBrg7B3AhMAkMAKDQB3AhA8BqQA9BsghB2QghB3hsA7QhFAohKAAQgoAAgpgLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-96.7896,y:70.4804}).wait(1).to({graphics:mask_1_graphics_45,x:-93.6755,y:70.912}).wait(1).to({graphics:mask_1_graphics_46,x:-84.6383,y:72.1637}).wait(1).to({graphics:mask_1_graphics_47,x:-70.5624,y:74.1133}).wait(1).to({graphics:mask_1_graphics_48,x:-52.8258,y:76.57}).wait(1).to({graphics:mask_1_graphics_49,x:-33.1646,y:79.2932}).wait(1).to({graphics:mask_1_graphics_50,x:-13.5033,y:82.0164}).wait(1).to({graphics:mask_1_graphics_51,x:4.2333,y:84.473}).wait(1).to({graphics:mask_1_graphics_52,x:18.3092,y:86.4226}).wait(1).to({graphics:mask_1_graphics_53,x:27.3464,y:87.6744}).wait(1).to({graphics:mask_1_graphics_54,x:30.4604,y:88.1054}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(87.45,129.7,1,1,0,0,0,57.2,16.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AqeI4Qhqg9gfh3Qggh2A8hrQA/hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_39 = new cjs.Graphics().p("Aq/I4Qhqg9gfh3Qggh2A9hrQA+hqB2ggMAkVgJuQB3ggBqA9QBrA+AgB3QAgB2g/BqQg8Brh3AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AsbI4Qhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJuQB3ggBpA9QBsA+AgB3QAfB2g+BqQg9Brh2AgMgkVAJuQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AugI7Qhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB3g+BqQg9Brh3AfMgkVAJvQgoAKgnAAQhLAAhHgpg");
	var mask_2_graphics_42 = new cjs.Graphics().p("Aw0JjQhqg9ggh2Qggh3A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBsA+AfB3QAgB2g+BqQg9Brh3AfMgkUAJvQgpALgnAAQhLAAhHgpg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Ay6KHQhqg9gfh3Qggh2A9hrQA+hqB3ggMAkVgJuQB2ggBqA9QBrA+AgB3QAgB2g/BqQg8Bqh3AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0WKgQhqg9ggh3Qgfh2A8hrQA/hqB2ggMAkVgJvQB3gfBqA9QBrA+AgB2QAfB3g+BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0fKpQhqg9ggh3Qgfh3A8hrQA/hqB2gfMAkVgJvQB3gfBqA9QBrA+AgB2QAgB3g/BqQg9Bqh2AgMgkVAJvQgoALgnAAQhMAAhHgpg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:210.152,y:47.6773}).wait(1).to({graphics:mask_2_graphics_39,x:206.8592,y:49.4475}).wait(1).to({graphics:mask_2_graphics_40,x:197.6331,y:54.4074}).wait(1).to({graphics:mask_2_graphics_41,x:184.3009,y:61.2431}).wait(1).to({graphics:mask_2_graphics_42,x:169.5032,y:65.2207}).wait(1).to({graphics:mask_2_graphics_43,x:156.171,y:68.8043}).wait(1).to({graphics:mask_2_graphics_44,x:146.9448,y:71.2843}).wait(1).to({graphics:mask_2_graphics_45,x:141.2573,y:72.1694}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(90.65,97,1,1,0,0,0,60.4,16.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBCBogaB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARZIjMgkwgICQh4gahChnQhChnAah4QAah4BnhDQBohCB4AaMAkwAICQB4AaBCBmQBDBogbB4QgaB4hoBCQhKAwhTAAQggAAgigHg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARZIjMgkwgIBQh4gbhChnQhChnAah4QAah4BnhDQBohBB4AaMAkwAIBQB4AbBCBlQBDBpgbB4QgaB4hoBBQhKAxhTAAQggAAgigIg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-92.9368,y:26.509}).wait(1).to({graphics:mask_3_graphics_32,x:-89.047,y:27.3834}).wait(1).to({graphics:mask_3_graphics_33,x:-77.8467,y:29.9013}).wait(1).to({graphics:mask_3_graphics_34,x:-60.6868,y:33.759}).wait(1).to({graphics:mask_3_graphics_35,x:-39.6371,y:38.4911}).wait(1).to({graphics:mask_3_graphics_36,x:-17.2365,y:43.5269}).wait(1).to({graphics:mask_3_graphics_37,x:3.8132,y:48.259}).wait(1).to({graphics:mask_3_graphics_38,x:20.973,y:52.1166}).wait(1).to({graphics:mask_3_graphics_39,x:32.1733,y:54.6345}).wait(1).to({graphics:mask_3_graphics_40,x:36.0632,y:55.4651}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(91.3,67.5,1,1,0,0,0,59.7,13.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("ArPHpQhnhFgZh6QgYh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBoBGAZB6QAYB6hGBoQhEBnh7AZMglbAHdQggAHgeAAQhYAAhNg0g");
	var mask_4_graphics_20 = new cjs.Graphics().p("ArTHpQhnhFgYh6QgZh6BFhpQBGhmB6gYMAlcgHeQB6gZBnBFQBpBGAYB6QAYB6hGBoQhEBnh6AZMglcAHdQgfAHgfAAQhXAAhOg0g");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArfHpQhnhFgYh6QgYh6BEhpQBGhmB7gYMAlagHeQB7gYBnBEQBoBGAZB6QAYB7hGBnQhFBnh6AZMglbAHdQgfAGgfAAQhXAAhOgzg");
	var mask_4_graphics_22 = new cjs.Graphics().p("Ar1HoQhnhEgZh6QgYh7BFhoQBGhmB6gYMAlZgHeQB7gYBnBFQBoBFAYB7QAZB6hGBnQhFBnh6AZMglaAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_23 = new cjs.Graphics().p("AsbHoQhnhFgYh6QgYh6BEhoQBGhmB6gYMAlYgHdQB6gZBnBFQBoBGAZB6QAYB6hGBnQhEBnh6AYMglYAHdQggAHgeAAQhXAAhOg0g");
	var mask_4_graphics_24 = new cjs.Graphics().p("AtUHnQhnhEgYh6QgYh6BEhoQBGhmB6gYMAlVgHdQB5gYBnBFQBpBFAYB6QAYB6hGBnQhEBnh6AYMglVAHdQgfAGgfAAQhXAAhNg0g");
	var mask_4_graphics_25 = new cjs.Graphics().p("AulHnQhnhFgYh6QgZh5BFhoQBFhmB6gYMAlRgHcQB6gYBmBEQBoBGAZB6QAYB5hGBnQhEBnh6AYMglRAHcQgfAGgeAAQhXAAhNgzg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AwLHlQhnhEgYh5QgYh6BEhnQBGhmB5gYMAlLgHbQB6gYBmBFQBoBFAYB5QAZB6hGBmQhEBnh6AYMglLAHbQgfAGgfAAQhWAAhNg0g");
	var mask_4_graphics_27 = new cjs.Graphics().p("AxzHkQhnhEgYh5QgYh5BEhnQBGhmB5gYMAlGgHZQB5gZBmBFQBoBFAYB5QAYB5hFBmQhEBnh5AYMglHAHZQgfAHgeAAQhXAAhMg0g");
	var mask_4_graphics_28 = new cjs.Graphics().p("AzLHjQhmhEgYh4QgYh5BDhoQBGhlB5gYMAlBgHYQB5gZBmBFQBoBFAYB5QAYB4hFBnQhEBmh5AYMglCAHZQgfAGgeAAQhWAAhNg0g");
	var mask_4_graphics_29 = new cjs.Graphics().p("A0OHjQhmhEgYh5QgYh5BEhnQBFhlB5gYMAk+gHYQB5gYBmBEQBnBFAYB5QAYB5hFBmQhEBmh5AYMgk+AHYQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A0/HiQhlhEgYh4QgYh5BDhnQBFhlB5gYMAk8gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk8AHXQgfAGgeAAQhWAAhNgzg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A1CHiQhmhEgYh4QgYh5BEhnQBFhlB5gYMAk6gHXQB4gYBmBEQBnBFAYB4QAYB5hFBmQhEBmh4AYMgk6AHXQggAGgeAAQhWAAhMgzg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A1BHiQhmhEgYh5QgYh4BEhnQBFhlB4gYMAk5gHWQB4gYBmBDQBnBFAYB5QAYB4hFBmQhEBmh4AYMgk5AHWQgfAHgeAAQhWAAhMgzg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:214.6102,y:3.3334}).wait(1).to({graphics:mask_4_graphics_20,x:214.2404,y:3.4806}).wait(1).to({graphics:mask_4_graphics_21,x:212.9875,y:3.9786}).wait(1).to({graphics:mask_4_graphics_22,x:210.5721,y:4.9385}).wait(1).to({graphics:mask_4_graphics_23,x:206.5928,y:6.5199}).wait(1).to({graphics:mask_4_graphics_24,x:200.5171,y:8.9344}).wait(1).to({graphics:mask_4_graphics_25,x:191.8775,y:12.3679}).wait(1).to({graphics:mask_4_graphics_26,x:181.0603,y:16.6668}).wait(1).to({graphics:mask_4_graphics_27,x:170.0151,y:21.0562}).wait(1).to({graphics:mask_4_graphics_28,x:160.7061,y:24.7557}).wait(1).to({graphics:mask_4_graphics_29,x:153.6244,y:27.57}).wait(1).to({graphics:mask_4_graphics_30,x:148.4436,y:29.629}).wait(1).to({graphics:mask_4_graphics_31,x:141.5638,y:31.1044}).wait(1).to({graphics:mask_4_graphics_32,x:136.4625,y:32.1336}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(94.8,41.2,1,1,0,0,0,63.2,13.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2,188.1,211.9);


(lib.wordScreenSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.sml = new lib.sml();
	this.sml.name = "sml";
	this.sml.setTransform(135.3,90.5,1,1,0,0,0,135.3,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sml).wait(1));

	// Layer_1
	this.sub = new lib.wordScreen();
	this.sub.name = "sub";
	this.sub.setTransform(135.7,90.5,1,1,0,0,0,135.7,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordScreenSub, new cjs.Rectangle(0,0,271.4,181.2), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-18,0.85,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.2,143.7,27.4), null);


(lib.laptop_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}
	this.frame_90 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(31).call(this.frame_90).wait(1));

	// endCursor
	this.editorCursorEnd = new lib.editorCursor();
	this.editorCursorEnd.name = "editorCursorEnd";
	this.editorCursorEnd.setTransform(102.3,401.5,1,1,0,0,0,0,31);

	this.timeline.addTween(cjs.Tween.get(this.editorCursorEnd).wait(91));

	// editorCursor
	this.editorCursor = new lib.editorCursor();
	this.editorCursor.name = "editorCursor";
	this.editorCursor.setTransform(150,35.5,1,1,0,0,0,15,15.5);

	this.timeline.addTween(cjs.Tween.get(this.editorCursor).wait(91));

	// LinkedInEndFrame
	this.socialScreenEnd = new lib.socialScreenEnd();
	this.socialScreenEnd.name = "socialScreenEnd";
	this.socialScreenEnd.setTransform(106.05,393.8,1.3385,1.3385,-20.7835,0,0,0.8,190.1);

	this.timeline.addTween(cjs.Tween.get(this.socialScreenEnd).wait(91));

	// rightMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AEBOxIAA8tIU/AAIAActg");
	var mask_graphics_1 = new cjs.Graphics().p("AEJOxIAA8tIU3AAIAActg");
	var mask_graphics_2 = new cjs.Graphics().p("AEUOxIAA8tIUsAAIAActg");
	var mask_graphics_3 = new cjs.Graphics().p("AEjOxIAA8tIUdAAIAActg");
	var mask_graphics_4 = new cjs.Graphics().p("AE3OxIAA8tIUJAAIAActg");
	var mask_graphics_5 = new cjs.Graphics().p("AFQOxIAA8tITwAAIAActg");
	var mask_graphics_6 = new cjs.Graphics().p("AFuOxIAA8tITSAAIAActg");
	var mask_graphics_7 = new cjs.Graphics().p("AGTOxIAA8sIStAAIAAcsg");
	var mask_graphics_8 = new cjs.Graphics().p("AG+OxIAA8sISCAAIAAcsg");
	var mask_graphics_9 = new cjs.Graphics().p("AHuOxIAA8sIRSAAIAAcsg");
	var mask_graphics_10 = new cjs.Graphics().p("AIjOxIAA8sIQdAAIAAcsg");
	var mask_graphics_11 = new cjs.Graphics().p("AJZOxIAA8sIPnAAIAAcsg");
	var mask_graphics_12 = new cjs.Graphics().p("AKPOxIAA8sIOxAAIAAcsg");
	var mask_graphics_13 = new cjs.Graphics().p("ALBOxIAA8sIN/AAIAAcsg");
	var mask_graphics_14 = new cjs.Graphics().p("ALwOxIAA8sINQAAIAAcsg");
	var mask_graphics_15 = new cjs.Graphics().p("AMaOxIAA8sIMmAAIAAcsg");
	var mask_graphics_16 = new cjs.Graphics().p("AM/OxIAA8sIMBAAIAAcsg");
	var mask_graphics_17 = new cjs.Graphics().p("ANeOxIAA8sILiAAIAAcsg");
	var mask_graphics_18 = new cjs.Graphics().p("AN6OxIAA8sILGAAIAAcsg");
	var mask_graphics_19 = new cjs.Graphics().p("AOSOxIAA8sIKuAAIAAcsg");
	var mask_graphics_20 = new cjs.Graphics().p("AOmOxIAA8sIKaAAIAAcsg");
	var mask_graphics_21 = new cjs.Graphics().p("AO2OxIAA8sIKKAAIAAcsg");
	var mask_graphics_22 = new cjs.Graphics().p("APEOxIAA8sIJ8AAIAAcsg");
	var mask_graphics_23 = new cjs.Graphics().p("APQOxIAA8sIJwAAIAAcsg");
	var mask_graphics_24 = new cjs.Graphics().p("APZOxIAA8sIJnAAIAAcsg");
	var mask_graphics_25 = new cjs.Graphics().p("APgOxIAA8sIJgAAIAAcsg");
	var mask_graphics_26 = new cjs.Graphics().p("APlOxIAA8sIJbAAIAAcsg");
	var mask_graphics_27 = new cjs.Graphics().p("APpOxIAA8sIJXAAIAAcsg");
	var mask_graphics_28 = new cjs.Graphics().p("APrOxIAA8sIJVAAIAAcsg");
	var mask_graphics_29 = new cjs.Graphics().p("APsOxIAA8tIJUAAIAActg");
	var mask_graphics_30 = new cjs.Graphics().p("APcOxIAA8tIJkAAIAActg");
	var mask_graphics_31 = new cjs.Graphics().p("APEOxIAA8tIJ8AAIAActg");
	var mask_graphics_32 = new cjs.Graphics().p("AOlOxIAA8tIKbAAIAActg");
	var mask_graphics_33 = new cjs.Graphics().p("AN8OxIAA8tILEAAIAActg");
	var mask_graphics_34 = new cjs.Graphics().p("ANJOwIAA8sIL3AAIAAcsg");
	var mask_graphics_35 = new cjs.Graphics().p("AMKOwIAA8sIM2AAIAAcsg");
	var mask_graphics_36 = new cjs.Graphics().p("AK/OwIAA8sIOBAAIAAcsg");
	var mask_graphics_37 = new cjs.Graphics().p("AJnOwIAA8sIPZAAIAAcsg");
	var mask_graphics_38 = new cjs.Graphics().p("AIDOwIAA8sIQ9AAIAAcsg");
	var mask_graphics_39 = new cjs.Graphics().p("AGWOwIAA8sISqAAIAAcsg");
	var mask_graphics_40 = new cjs.Graphics().p("AEkOwIAA8sIUcAAIAAcsg");
	var mask_graphics_41 = new cjs.Graphics().p("ACwOwIAA8sIWQAAIAAcsg");
	var mask_graphics_42 = new cjs.Graphics().p("ABBOwIAA8sIX/AAIAAcsg");
	var mask_graphics_43 = new cjs.Graphics().p("AglOwIAA8sIZlAAIAAcsg");
	var mask_graphics_44 = new cjs.Graphics().p("AiDOwIAA8sIbDAAIAAcsg");
	var mask_graphics_45 = new cjs.Graphics().p("AjWOwIAA8sIcWAAIAAcsg");
	var mask_graphics_46 = new cjs.Graphics().p("AkgOwIAA8sIdgAAIAAcsg");
	var mask_graphics_47 = new cjs.Graphics().p("AlgOwIAA8sIegAAIAAcsg");
	var mask_graphics_48 = new cjs.Graphics().p("AmXOwIAA8sIfXAAIAAcsg");
	var mask_graphics_49 = new cjs.Graphics().p("AnGOwIAA8sMAgGAAAIAAcsg");
	var mask_graphics_50 = new cjs.Graphics().p("AnvOwIAA8sMAgvAAAIAAcsg");
	var mask_graphics_51 = new cjs.Graphics().p("AoROwIAA8sMAhRAAAIAAcsg");
	var mask_graphics_52 = new cjs.Graphics().p("AotOwIAA8sMAhtAAAIAAcsg");
	var mask_graphics_53 = new cjs.Graphics().p("ApEOwIAA8sMAiEAAAIAAcsg");
	var mask_graphics_54 = new cjs.Graphics().p("ApXOwIAA8sMAiXAAAIAAcsg");
	var mask_graphics_55 = new cjs.Graphics().p("AplOwIAA8sMAilAAAIAAcsg");
	var mask_graphics_56 = new cjs.Graphics().p("ApwOwIAA8sMAiwAAAIAAcsg");
	var mask_graphics_57 = new cjs.Graphics().p("Ap3OwIAA8sMAi3AAAIAAcsg");
	var mask_graphics_58 = new cjs.Graphics().p("Ap8OwIAA8sMAi8AAAIAAcsg");
	var mask_graphics_59 = new cjs.Graphics().p("Ap9OxIAA8tMAi9AAAIAActg");
	var mask_graphics_60 = new cjs.Graphics().p("AqCOxIAA8tMAjCAAAIAActg");
	var mask_graphics_61 = new cjs.Graphics().p("AqJOxIAA8tMAjJAAAIAActg");
	var mask_graphics_62 = new cjs.Graphics().p("AqSOxIAA8tMAjSAAAIAActg");
	var mask_graphics_63 = new cjs.Graphics().p("AqeOxIAA8tMAjeAAAIAActg");
	var mask_graphics_64 = new cjs.Graphics().p("AqtOxIAA8tMAjtAAAIAActg");
	var mask_graphics_65 = new cjs.Graphics().p("ArAOxIAA8tMAkAAAAIAActg");
	var mask_graphics_66 = new cjs.Graphics().p("ArWOxIAA8tMAkWAAAIAActg");
	var mask_graphics_67 = new cjs.Graphics().p("ArwOxIAA8tMAkwAAAIAActg");
	var mask_graphics_68 = new cjs.Graphics().p("AsOOxIAA8tMAlOAAAIAActg");
	var mask_graphics_69 = new cjs.Graphics().p("AsuOxIAA8tMAluAAAIAActg");
	var mask_graphics_70 = new cjs.Graphics().p("AtQOxIAA8tMAmQAAAIAActg");
	var mask_graphics_71 = new cjs.Graphics().p("AtzOxIAA8tMAmzAAAIAActg");
	var mask_graphics_72 = new cjs.Graphics().p("AuTOxIAA8tMAnTAAAIAActg");
	var mask_graphics_73 = new cjs.Graphics().p("AuyOxIAA8tMAnyAAAIAActg");
	var mask_graphics_74 = new cjs.Graphics().p("AvOOxIAA8tMAoOAAAIAActg");
	var mask_graphics_75 = new cjs.Graphics().p("AvnOxIAA8tMAonAAAIAActg");
	var mask_graphics_76 = new cjs.Graphics().p("Av9OxIAA8tMAo9AAAIAActg");
	var mask_graphics_77 = new cjs.Graphics().p("AwPOxIAA8tMApPAAAIAActg");
	var mask_graphics_78 = new cjs.Graphics().p("AwgOxIAA8tMApgAAAIAActg");
	var mask_graphics_79 = new cjs.Graphics().p("AwuOxIAA8tMApuAAAIAActg");
	var mask_graphics_80 = new cjs.Graphics().p("Aw6OxIAA8tMAp6AAAIAActg");
	var mask_graphics_81 = new cjs.Graphics().p("AxEOxIAA8tMAqEAAAIAActg");
	var mask_graphics_82 = new cjs.Graphics().p("AxMOxIAA8tMAqMAAAIAActg");
	var mask_graphics_83 = new cjs.Graphics().p("AxTOxIAA8tMAqTAAAIAActg");
	var mask_graphics_84 = new cjs.Graphics().p("AxZOxIAA8tMAqZAAAIAActg");
	var mask_graphics_85 = new cjs.Graphics().p("AxdOxIAA8tMAqdAAAIAActg");
	var mask_graphics_86 = new cjs.Graphics().p("AxgOxIAA8tMAqgAAAIAActg");
	var mask_graphics_87 = new cjs.Graphics().p("AxiOxIAA8tMAqiAAAIAActg");
	var mask_graphics_88 = new cjs.Graphics().p("AxkOxIAA8tMAqkAAAIAActg");
	var mask_graphics_89 = new cjs.Graphics().p("AxlOxIAA8tMAqkAAAIAActg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:159.978,y:94.4521}).wait(1).to({graphics:mask_graphics_1,x:159.9779,y:94.4524}).wait(1).to({graphics:mask_graphics_2,x:159.9778,y:94.4528}).wait(1).to({graphics:mask_graphics_3,x:159.9776,y:94.4533}).wait(1).to({graphics:mask_graphics_4,x:159.9774,y:94.4539}).wait(1).to({graphics:mask_graphics_5,x:159.9772,y:94.4548}).wait(1).to({graphics:mask_graphics_6,x:159.9769,y:94.4558}).wait(1).to({graphics:mask_graphics_7,x:159.9765,y:94.457}).wait(1).to({graphics:mask_graphics_8,x:159.9761,y:94.4585}).wait(1).to({graphics:mask_graphics_9,x:159.9757,y:94.4601}).wait(1).to({graphics:mask_graphics_10,x:159.9752,y:94.4618}).wait(1).to({graphics:mask_graphics_11,x:159.9746,y:94.4637}).wait(1).to({graphics:mask_graphics_12,x:159.9741,y:94.4655}).wait(1).to({graphics:mask_graphics_13,x:159.9736,y:94.4672}).wait(1).to({graphics:mask_graphics_14,x:159.9732,y:94.4687}).wait(1).to({graphics:mask_graphics_15,x:159.9728,y:94.4701}).wait(1).to({graphics:mask_graphics_16,x:159.9724,y:94.4713}).wait(1).to({graphics:mask_graphics_17,x:159.9721,y:94.4724}).wait(1).to({graphics:mask_graphics_18,x:159.9719,y:94.4733}).wait(1).to({graphics:mask_graphics_19,x:159.9716,y:94.4741}).wait(1).to({graphics:mask_graphics_20,x:159.9714,y:94.4748}).wait(1).to({graphics:mask_graphics_21,x:159.9713,y:94.4754}).wait(1).to({graphics:mask_graphics_22,x:159.9711,y:94.4758}).wait(1).to({graphics:mask_graphics_23,x:159.971,y:94.4762}).wait(1).to({graphics:mask_graphics_24,x:159.9709,y:94.4765}).wait(1).to({graphics:mask_graphics_25,x:159.9709,y:94.4768}).wait(1).to({graphics:mask_graphics_26,x:159.9708,y:94.4769}).wait(1).to({graphics:mask_graphics_27,x:159.9708,y:94.4771}).wait(1).to({graphics:mask_graphics_28,x:159.9708,y:94.4771}).wait(1).to({graphics:mask_graphics_29,x:159.9819,y:94.4521}).wait(1).to({graphics:mask_graphics_30,x:159.982,y:94.4519}).wait(1).to({graphics:mask_graphics_31,x:159.9823,y:94.4515}).wait(1).to({graphics:mask_graphics_32,x:159.9826,y:94.4511}).wait(1).to({graphics:mask_graphics_33,x:159.9831,y:94.4504}).wait(1).to({graphics:mask_graphics_34,x:159.9836,y:94.4497}).wait(1).to({graphics:mask_graphics_35,x:159.9843,y:94.4487}).wait(1).to({graphics:mask_graphics_36,x:159.9852,y:94.4476}).wait(1).to({graphics:mask_graphics_37,x:159.9861,y:94.4462}).wait(1).to({graphics:mask_graphics_38,x:159.9872,y:94.4447}).wait(1).to({graphics:mask_graphics_39,x:159.9884,y:94.443}).wait(1).to({graphics:mask_graphics_40,x:159.9897,y:94.4413}).wait(1).to({graphics:mask_graphics_41,x:159.9909,y:94.4395}).wait(1).to({graphics:mask_graphics_42,x:159.9922,y:94.4379}).wait(1).to({graphics:mask_graphics_43,x:159.9933,y:94.4363}).wait(1).to({graphics:mask_graphics_44,x:159.9943,y:94.4348}).wait(1).to({graphics:mask_graphics_45,x:159.9952,y:94.4336}).wait(1).to({graphics:mask_graphics_46,x:159.996,y:94.4325}).wait(1).to({graphics:mask_graphics_47,x:159.9967,y:94.4315}).wait(1).to({graphics:mask_graphics_48,x:159.9973,y:94.4306}).wait(1).to({graphics:mask_graphics_49,x:159.9979,y:94.4299}).wait(1).to({graphics:mask_graphics_50,x:159.9983,y:94.4293}).wait(1).to({graphics:mask_graphics_51,x:159.9987,y:94.4288}).wait(1).to({graphics:mask_graphics_52,x:159.999,y:94.4284}).wait(1).to({graphics:mask_graphics_53,x:159.9992,y:94.428}).wait(1).to({graphics:mask_graphics_54,x:159.9994,y:94.4277}).wait(1).to({graphics:mask_graphics_55,x:159.9996,y:94.4275}).wait(1).to({graphics:mask_graphics_56,x:159.9997,y:94.4273}).wait(1).to({graphics:mask_graphics_57,x:159.9998,y:94.4272}).wait(1).to({graphics:mask_graphics_58,x:159.9999,y:94.4272}).wait(1).to({graphics:mask_graphics_59,x:159.9999,y:94.4521}).wait(1).to({graphics:mask_graphics_60,x:160,y:94.4521}).wait(1).to({graphics:mask_graphics_61,x:160.0002,y:94.4521}).wait(1).to({graphics:mask_graphics_62,x:160.0004,y:94.4521}).wait(1).to({graphics:mask_graphics_63,x:160.0007,y:94.4521}).wait(1).to({graphics:mask_graphics_64,x:160.0011,y:94.4521}).wait(1).to({graphics:mask_graphics_65,x:160.0016,y:94.4521}).wait(1).to({graphics:mask_graphics_66,x:160.0021,y:94.4521}).wait(1).to({graphics:mask_graphics_67,x:160.0028,y:94.4521}).wait(1).to({graphics:mask_graphics_68,x:160.0035,y:94.4521}).wait(1).to({graphics:mask_graphics_69,x:160.0043,y:94.4521}).wait(1).to({graphics:mask_graphics_70,x:160.0052,y:94.4521}).wait(1).to({graphics:mask_graphics_71,x:160.006,y:94.4521}).wait(1).to({graphics:mask_graphics_72,x:160.0069,y:94.4521}).wait(1).to({graphics:mask_graphics_73,x:160.0076,y:94.4521}).wait(1).to({graphics:mask_graphics_74,x:160.0083,y:94.4521}).wait(1).to({graphics:mask_graphics_75,x:160.009,y:94.4521}).wait(1).to({graphics:mask_graphics_76,x:160.0095,y:94.4521}).wait(1).to({graphics:mask_graphics_77,x:160.01,y:94.4521}).wait(1).to({graphics:mask_graphics_78,x:160.0104,y:94.4521}).wait(1).to({graphics:mask_graphics_79,x:160.0108,y:94.4521}).wait(1).to({graphics:mask_graphics_80,x:160.0111,y:94.4521}).wait(1).to({graphics:mask_graphics_81,x:160.0113,y:94.4521}).wait(1).to({graphics:mask_graphics_82,x:160.0115,y:94.4521}).wait(1).to({graphics:mask_graphics_83,x:160.0117,y:94.4521}).wait(1).to({graphics:mask_graphics_84,x:160.0118,y:94.4521}).wait(1).to({graphics:mask_graphics_85,x:160.0119,y:94.4521}).wait(1).to({graphics:mask_graphics_86,x:160.012,y:94.4521}).wait(1).to({graphics:mask_graphics_87,x:160.0121,y:94.4521}).wait(1).to({graphics:mask_graphics_88,x:160.0121,y:94.4521}).wait(1).to({graphics:mask_graphics_89,x:159.9106,y:94.4521}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// wordScreen
	this.wordScreen = new lib.wordScreenSub();
	this.wordScreen.name = "wordScreen";
	this.wordScreen.setTransform(47.85,187.55,1,1,0,0,0,0,181.1);

	var maskedShapeInstanceList = [this.wordScreen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.wordScreen).wait(91));

	// leftMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Am5OxIAA8tIVSAAIAActg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Am9OxIAA8tIVZAAIAActg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AnCOxIAA8tIVkAAIAActg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AnKOxIAA8tIVzAAIAActg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AnUOxIAA8tIWHAAIAActg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AngOxIAA8tIWgAAIAActg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnvOxIAA8tIW+AAIAActg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AoBOxIAA8tIXiAAIAActg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AoXOxIAA8tIYNAAIAActg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AovOxIAA8tIY9AAIAActg");
	var mask_1_graphics_10 = new cjs.Graphics().p("ApJOxIAA8tIZxAAIAActg");
	var mask_1_graphics_11 = new cjs.Graphics().p("ApjOxIAA8tIamAAIAActg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ap+OxIAA8tIbcAAIAActg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AqXOxIAA8tIcOAAIAActg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AquOxIAA8tIc8AAIAActg");
	var mask_1_graphics_15 = new cjs.Graphics().p("ArDOxIAA8tIdmAAIAActg");
	var mask_1_graphics_16 = new cjs.Graphics().p("ArVOxIAA8tIeKAAIAActg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArlOxIAA8tIeqAAIAActg");
	var mask_1_graphics_18 = new cjs.Graphics().p("ArzOxIAA8tIfFAAIAActg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Ar+OxIAA8tIfcAAIAActg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AsIOxIAA8tIfwAAIAActg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AsROxIAA8tMAgBAAAIAActg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AsYOxIAA8tMAgPAAAIAActg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AsdOxIAA8tMAgaAAAIAActg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AsiOxIAA8tMAgkAAAIAActg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AslOxIAA8tMAgqAAAIAActg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AsoOxIAA8tMAgwAAAIAActg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AsqOxIAA8tMAgzAAAIAActg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AsrOxIAA8tMAg1AAAIAActg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AsrOxIAA8tMAg1AAAIAActg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AsjOxIAA8tMAglAAAIAActg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AsYOxIAA8tMAgPAAAIAActg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AsIOxIAA8tIfvAAIAActg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ar0OxIAA8tIfGAAIAActg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AraOxIAA8tIeTAAIAActg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Aq7OxIAA8tIdVAAIAActg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqVOxIAA8tIcJAAIAActg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AppOxIAA8tIaxAAIAActg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ao4OxIAA8tIZOAAIAActg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AoBOxIAA8tIXhAAIAActg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AnIOxIAA8tIVvAAIAActg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AmOOxIAA8tIT7AAIAActg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AlXOxIAA8tISNAAIAActg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkjOxIAA8tIQlAAIAActg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Aj0OxIAA8tIPHAAIAActg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AjLOxIAA8tIN0AAIAActg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AimOxIAA8tIMrAAIAActg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AiGOxIAA8tILrAAIAActg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AhrOxIAA8tIK0AAIAActg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AhTOxIAA8tIKFAAIAActg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Ag/OxIAA8tIJdAAIAActg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AguOxIAA8tII7AAIAActg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AggOxIAA8tIIeAAIAActg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AgUOxIAA8tIIHAAIAActg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AgLOxIAA8tIH0AAIAActg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AgDOxIAA8tIHlAAIAActg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AABOxIAA8tIHcAAIAActg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AAFOxIAA8tIHUAAIAActg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AAHOxIAA8tIHQAAIAActg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AAIOxIAA8tIHPAAIAActg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AAKOxIAA8tIHKAAIAActg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AAMOxIAA8tIHFAAIAActg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AAQOxIAA8tIG8AAIAActg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AAVOxIAA8tIGxAAIAActg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AAcOxIAA8tIGiAAIAActg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AAkOxIAA8tIGRAAIAActg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AAtOxIAA8tIF9AAIAActg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AA4OxIAA8tIFlAAIAActg");
	var mask_1_graphics_68 = new cjs.Graphics().p("ABEOxIAA8tIFKAAIAActg");
	var mask_1_graphics_69 = new cjs.Graphics().p("ABSOxIAA8tIEsAAIAActg");
	var mask_1_graphics_70 = new cjs.Graphics().p("ABgOxIAA8tIENAAIAActg");
	var mask_1_graphics_71 = new cjs.Graphics().p("ABvOxIAA8tIDtAAIAActg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AB8OxIAA8tIDPAAIAActg");
	var mask_1_graphics_73 = new cjs.Graphics().p("ACJOxIAA8tICzAAIAActg");
	var mask_1_graphics_74 = new cjs.Graphics().p("ACVOxIAA8tICZAAIAActg");
	var mask_1_graphics_75 = new cjs.Graphics().p("ACfOxIAA8tICDAAIAActg");
	var mask_1_graphics_76 = new cjs.Graphics().p("ACpOxIAA8sIBuAAIAAcsg");
	var mask_1_graphics_77 = new cjs.Graphics().p("ACxOxIAA8sIBcAAIAAcsg");
	var mask_1_graphics_78 = new cjs.Graphics().p("AC3OxIAA8sIBOAAIAAcsg");
	var mask_1_graphics_79 = new cjs.Graphics().p("AC9OxIAA8sIBBAAIAAcsg");
	var mask_1_graphics_80 = new cjs.Graphics().p("ADCOxIAA8sIA2AAIAAcsg");
	var mask_1_graphics_81 = new cjs.Graphics().p("ADHOxIAA8sIAsAAIAAcsg");
	var mask_1_graphics_82 = new cjs.Graphics().p("ADKOxIAA8sIAlAAIAAcsg");
	var mask_1_graphics_83 = new cjs.Graphics().p("ADNOxIAA8sIAeAAIAAcsg");
	var mask_1_graphics_84 = new cjs.Graphics().p("ADPOxIAA8sIAaAAIAAcsg");
	var mask_1_graphics_85 = new cjs.Graphics().p("ADROxIAA8sIAVAAIAAcsg");
	var mask_1_graphics_86 = new cjs.Graphics().p("ADTOxIAA8sIASAAIAAcsg");
	var mask_1_graphics_87 = new cjs.Graphics().p("ADTOxIAA8sIARAAIAAcsg");
	var mask_1_graphics_88 = new cjs.Graphics().p("ADUOxIAA8sIAPAAIAAcsg");
	var mask_1_graphics_89 = new cjs.Graphics().p("ADUOxIAA8sIAPAAIAAcsg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:92.0519,y:94.4521}).wait(1).to({graphics:mask_1_graphics_1,x:92.4343,y:94.4521}).wait(1).to({graphics:mask_1_graphics_2,x:92.9899,y:94.4521}).wait(1).to({graphics:mask_1_graphics_3,x:93.7431,y:94.4521}).wait(1).to({graphics:mask_1_graphics_4,x:94.7216,y:94.4521}).wait(1).to({graphics:mask_1_graphics_5,x:95.9548,y:94.4521}).wait(1).to({graphics:mask_1_graphics_6,x:97.4707,y:94.4521}).wait(1).to({graphics:mask_1_graphics_7,x:99.2896,y:94.4521}).wait(1).to({graphics:mask_1_graphics_8,x:101.4132,y:94.4521}).wait(1).to({graphics:mask_1_graphics_9,x:103.8115,y:94.4521}).wait(1).to({graphics:mask_1_graphics_10,x:106.4121,y:94.4521}).wait(1).to({graphics:mask_1_graphics_11,x:109.1049,y:94.4521}).wait(1).to({graphics:mask_1_graphics_12,x:111.7656,y:94.4521}).wait(1).to({graphics:mask_1_graphics_13,x:114.2873,y:94.4521}).wait(1).to({graphics:mask_1_graphics_14,x:116.5994,y:94.4521}).wait(1).to({graphics:mask_1_graphics_15,x:118.6687,y:94.4521}).wait(1).to({graphics:mask_1_graphics_16,x:120.4902,y:94.4521}).wait(1).to({graphics:mask_1_graphics_17,x:122.0747,y:94.4521}).wait(1).to({graphics:mask_1_graphics_18,x:123.4409,y:94.4521}).wait(1).to({graphics:mask_1_graphics_19,x:124.6097,y:94.4521}).wait(1).to({graphics:mask_1_graphics_20,x:125.6019,y:94.4521}).wait(1).to({graphics:mask_1_graphics_21,x:126.4363,y:94.4521}).wait(1).to({graphics:mask_1_graphics_22,x:127.13,y:94.4521}).wait(1).to({graphics:mask_1_graphics_23,x:127.6978,y:94.4521}).wait(1).to({graphics:mask_1_graphics_24,x:128.1527,y:94.4521}).wait(1).to({graphics:mask_1_graphics_25,x:128.506,y:94.4521}).wait(1).to({graphics:mask_1_graphics_26,x:128.7674,y:94.4521}).wait(1).to({graphics:mask_1_graphics_27,x:128.9455,y:94.4521}).wait(1).to({graphics:mask_1_graphics_28,x:129.0477,y:94.4521}).wait(1).to({graphics:mask_1_graphics_29,x:129.0418,y:94.4521}).wait(1).to({graphics:mask_1_graphics_30,x:128.2291,y:94.4521}).wait(1).to({graphics:mask_1_graphics_31,x:127.0596,y:94.4521}).wait(1).to({graphics:mask_1_graphics_32,x:125.4847,y:94.4521}).wait(1).to({graphics:mask_1_graphics_33,x:123.4495,y:94.4521}).wait(1).to({graphics:mask_1_graphics_34,x:120.8954,y:94.4521}).wait(1).to({graphics:mask_1_graphics_35,x:117.7653,y:94.4521}).wait(1).to({graphics:mask_1_graphics_36,x:114.0142,y:94.4521}).wait(1).to({graphics:mask_1_graphics_37,x:109.628,y:94.4521}).wait(1).to({graphics:mask_1_graphics_38,x:104.6483,y:94.4521}).wait(1).to({graphics:mask_1_graphics_39,x:99.1952,y:94.4521}).wait(1).to({graphics:mask_1_graphics_40,x:93.4687,y:94.4521}).wait(1).to({graphics:mask_1_graphics_41,x:87.7152,y:94.4521}).wait(1).to({graphics:mask_1_graphics_42,x:82.1688,y:94.4521}).wait(1).to({graphics:mask_1_graphics_43,x:77.0038,y:94.4521}).wait(1).to({graphics:mask_1_graphics_44,x:72.318,y:94.4521}).wait(1).to({graphics:mask_1_graphics_45,x:68.1457,y:94.4521}).wait(1).to({graphics:mask_1_graphics_46,x:64.479,y:94.4521}).wait(1).to({graphics:mask_1_graphics_47,x:61.287,y:94.4521}).wait(1).to({graphics:mask_1_graphics_48,x:58.5297,y:94.4521}).wait(1).to({graphics:mask_1_graphics_49,x:56.1648,y:94.4521}).wait(1).to({graphics:mask_1_graphics_50,x:54.152,y:94.4521}).wait(1).to({graphics:mask_1_graphics_51,x:52.4546,y:94.4521}).wait(1).to({graphics:mask_1_graphics_52,x:51.0398,y:94.4521}).wait(1).to({graphics:mask_1_graphics_53,x:49.8789,y:94.4521}).wait(1).to({graphics:mask_1_graphics_54,x:48.9467,y:94.4521}).wait(1).to({graphics:mask_1_graphics_55,x:48.2212,y:94.4521}).wait(1).to({graphics:mask_1_graphics_56,x:47.6833,y:94.4521}).wait(1).to({graphics:mask_1_graphics_57,x:47.3162,y:94.4521}).wait(1).to({graphics:mask_1_graphics_58,x:47.1053,y:94.4521}).wait(1).to({graphics:mask_1_graphics_59,x:47.0546,y:94.4521}).wait(1).to({graphics:mask_1_graphics_60,x:46.8131,y:94.4521}).wait(1).to({graphics:mask_1_graphics_61,x:46.4656,y:94.4521}).wait(1).to({graphics:mask_1_graphics_62,x:45.9975,y:94.4521}).wait(1).to({graphics:mask_1_graphics_63,x:45.3927,y:94.452}).wait(1).to({graphics:mask_1_graphics_64,x:44.6337,y:94.452}).wait(1).to({graphics:mask_1_graphics_65,x:43.7036,y:94.4519}).wait(1).to({graphics:mask_1_graphics_66,x:42.5888,y:94.4519}).wait(1).to({graphics:mask_1_graphics_67,x:41.2854,y:94.4518}).wait(1).to({graphics:mask_1_graphics_68,x:39.8056,y:94.4517}).wait(1).to({graphics:mask_1_graphics_69,x:38.185,y:94.4516}).wait(1).to({graphics:mask_1_graphics_70,x:36.4833,y:94.4515}).wait(1).to({graphics:mask_1_graphics_71,x:34.7735,y:94.4514}).wait(1).to({graphics:mask_1_graphics_72,x:33.1253,y:94.4513}).wait(1).to({graphics:mask_1_graphics_73,x:31.5904,y:94.4513}).wait(1).to({graphics:mask_1_graphics_74,x:30.1979,y:94.4512}).wait(1).to({graphics:mask_1_graphics_75,x:28.9581,y:94.4511}).wait(1).to({graphics:mask_1_graphics_76,x:27.8684,y:94.451}).wait(1).to({graphics:mask_1_graphics_77,x:26.9198,y:94.451}).wait(1).to({graphics:mask_1_graphics_78,x:26.1004,y:94.4509}).wait(1).to({graphics:mask_1_graphics_79,x:25.3977,y:94.4509}).wait(1).to({graphics:mask_1_graphics_80,x:24.7995,y:94.4509}).wait(1).to({graphics:mask_1_graphics_81,x:24.2951,y:94.4508}).wait(1).to({graphics:mask_1_graphics_82,x:23.8747,y:94.4508}).wait(1).to({graphics:mask_1_graphics_83,x:23.5297,y:94.4508}).wait(1).to({graphics:mask_1_graphics_84,x:23.2526,y:94.4508}).wait(1).to({graphics:mask_1_graphics_85,x:23.0371,y:94.4508}).wait(1).to({graphics:mask_1_graphics_86,x:22.8772,y:94.4508}).wait(1).to({graphics:mask_1_graphics_87,x:22.7681,y:94.4507}).wait(1).to({graphics:mask_1_graphics_88,x:22.7054,y:94.4507}).wait(1).to({graphics:mask_1_graphics_89,x:22.6926,y:94.4507}).wait(2));

	// socialScreen
	this.socialScreen = new lib.socialScreen();
	this.socialScreen.name = "socialScreen";
	this.socialScreen.setTransform(183.6,96.8,1,1,0,0,0,135.6,90.5);

	var maskedShapeInstanceList = [this.socialScreen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.socialScreen).wait(91));

	// angledShadows
	this.angledShadow2 = new lib.angledShadow();
	this.angledShadow2.name = "angledShadow2";
	this.angledShadow2.setTransform(109.6,230.2,1.2131,1.2131,0,0,0,18.5,22.2);

	this.angledShadow1 = new lib.angledShadow();
	this.angledShadow1.name = "angledShadow1";
	this.angledShadow1.setTransform(93.9,392.3,1.5861,1.5861,0,0,0,18.6,22.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.angledShadow1},{t:this.angledShadow2}]}).wait(91));

	// Layer_1
	this.laptop = new lib.laptopSub();
	this.laptop.name = "laptop";
	this.laptop.setTransform(183.5,127,1,1,0,0,0,183.5,127);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-130.5,379.2,533.5);


(lib.IntroTxtHighlights = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_61 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(61).call(this.frame_61).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ai3HXQgBAAgBgKIAAgZIABgZQAAgKABAAIARAAQABAAAAALIABAYIgBAZQgBAKgBAAg");
	var mask_graphics_1 = new cjs.Graphics().p("Ai2HXQgCAAAAgKIgBgZIABgZQABgKABAAIAbABQACAAABAKIABAYIgCAZQgBAKgBAAg");
	var mask_graphics_2 = new cjs.Graphics().p("AiFHXIgvAAQgCAAgCgKQgBgLAAgOQAAgOACgLQABgKADAAIAuABQADAAABAKQACAKAAAPQgBAOgBAKQgCAKgCAAIAAAAg");
	var mask_graphics_3 = new cjs.Graphics().p("AhjHXIhNAAQgEAAgDgKQgCgLAAgOQAAgPADgKQADgKAEAAIBNABQAEAAADAKQACAKAAAPQAAAOgDAKQgDAKgEAAIAAAAg");
	var mask_graphics_4 = new cjs.Graphics().p("AgxHYIh5gBQgHAAgEgLQgEgKAAgOQAAgPAFgKQAEgKAGAAIB6ABQAGAAAEAKQAFALAAAOQgBAOgEAKQgFALgGAAIAAAAg");
	var mask_graphics_5 = new cjs.Graphics().p("AANHYIiwgBQgJgBgHgKQgGgKAAgPQAAgOAHgKQAGgKAJAAICwABQAJAAAGALQAHAKAAAOQAAAPgHAKQgGAKgJAAIAAAAg");
	var mask_graphics_6 = new cjs.Graphics().p("ABNHYIjpgCQgMAAgJgKQgIgKAAgPQAAgOAJgKQAIgLAMABIDqACQAMAAAIAKQAJAKAAAPQgBAOgIAKQgJAKgLAAIgBAAg");
	var mask_graphics_7 = new cjs.Graphics().p("ACGHYIkcgCQgOAAgLgKQgKgLAAgOQAAgOALgLQAKgKAPAAIEbADQAPAAAKAKQAKAKAAAPQAAAOgKAKQgLAKgOAAIAAAAg");
	var mask_graphics_8 = new cjs.Graphics().p("ACiHZIlDgDQgRAAgMgLQgLgKAAgOQAAgPAMgKQAMgKAQAAIFDADQARAAALAKQAMALAAAOQAAAPgMAKQgMAKgQAAIAAAAg");
	var mask_graphics_9 = new cjs.Graphics().p("ACwHZIlggDQgSAAgNgLQgMgKAAgOQAAgPANgKQANgKASAAIFgADQASAAANAKQAMALAAAOQAAAPgNAKQgMAKgSAAIgBAAg");
	var mask_graphics_10 = new cjs.Graphics().p("AC7HZIl1gDQgTAAgOgLQgNgKAAgOQAAgPANgKQAOgKATAAIF1ADQATAAAOALQANAKAAAOQAAAPgOAKQgNAKgTAAIAAAAg");
	var mask_graphics_11 = new cjs.Graphics().p("ADCHZImEgDQgTAAgOgLQgOgKAAgPQAAgOAOgKQAOgKAUAAIGEADQATAAAOALQAOAKAAAPQAAAOgOAKQgOAKgTAAIgBAAg");
	var mask_graphics_12 = new cjs.Graphics().p("ADHHZImNgDQgUAAgPgLQgOgKAAgPQAAgOAPgKQAOgKAUAAIGNADQAUAAAPALQAOAKAAAPQAAAOgPAKQgOAKgUAAIAAAAg");
	var mask_graphics_13 = new cjs.Graphics().p("ADJHZImSgDQgUgBgPgKQgOgKAAgPQAAgOAPgKQAOgKAVAAIGSADQAUABAPAKQAOAKAAAPQAAAOgPAKQgOAKgUAAIgBAAg");
	var mask_graphics_14 = new cjs.Graphics().p("ADKHaImTgEQgVAAgPgKQgOgLAAgOQAAgPAPgKQAPgKAUAAIGTAEQAVAAAOAKQAPALAAAOQAAAPgPAKQgOAKgUAAIgBAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-18.6221,y:47.1217}).wait(1).to({graphics:mask_graphics_1,x:-18.6199,y:47.1265}).wait(1).to({graphics:mask_graphics_2,x:-18.6163,y:47.1355}).wait(1).to({graphics:mask_graphics_3,x:-18.6108,y:47.1498}).wait(1).to({graphics:mask_graphics_4,x:-18.6031,y:47.1706}).wait(1).to({graphics:mask_graphics_5,x:-18.5935,y:47.1969}).wait(1).to({graphics:mask_graphics_6,x:-18.5836,y:47.2246}).wait(1).to({graphics:mask_graphics_7,x:-18.5749,y:47.2489}).wait(1).to({graphics:mask_graphics_8,x:-16.9368,y:47.2682}).wait(1).to({graphics:mask_graphics_9,x:-15.107,y:47.2826}).wait(1).to({graphics:mask_graphics_10,x:-13.7958,y:47.293}).wait(1).to({graphics:mask_graphics_11,x:-12.8953,y:47.3002}).wait(1).to({graphics:mask_graphics_12,x:-12.3212,y:47.3047}).wait(1).to({graphics:mask_graphics_13,x:-12.0103,y:47.3072}).wait(1).to({graphics:mask_graphics_14,x:-12.1884,y:47.3543}).wait(48));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjZAGQCFgXEuAX");
	this.shape.setTransform(-11.4,91.2625);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(62));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_12 = new cjs.Graphics().p("AivHxIggAAQgBAAgBgLIgBgYIABgZQABgKACAAIAgAAQACAAABAKIABAZIgCAZQgBAKgCAAIAAAAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AijHxIgqAAQgDAAgBgLQgBgKAAgOQAAgPABgKQACgKACAAIAqAAQACAAACAKQABALAAAOQAAAPgCAKQgBAKgCAAIAAAAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AiNHxIg+AAQgDAAgCgLQgDgKABgOQAAgPACgKQACgKAEAAIA9AAQADAAACALQADAKAAAOQgBAPgCAKQgCAKgDAAIAAAAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AhqHxIhdAAQgFgBgDgKQgEgKAAgOQABgPADgKQADgKAFAAIBeABQAFAAADAKQADAKAAAOQAAAPgDAKQgEAKgFAAIAAAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("Ag3HxIiLgBQgHAAgFgKQgFgKAAgPQAAgOAFgKQAFgKAIAAICLABQAHAAAFAKQAFAKAAAPQAAAOgFAKQgGAKgHAAIAAAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AAGHyIjCgCQgKAAgHgKQgGgLAAgOQAAgOAHgLQAHgKAKAAIDBACQAKAAAHAKQAHALAAAOQAAAOgIALQgHAKgJAAIAAAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("ABAHyIj1gCQgNAAgJgLQgJgKAAgOQABgPAIgKQAKgKAMAAID2ACQANAAAIALQAJAKAAAOQAAAPgJAKQgJAKgMAAIgBAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("ABwHyIkggCQgPAAgLgLQgKgKAAgOQAAgPALgKQAKgKAPAAIEhACQAPABAKAKQAKAKAAAPQAAAOgKAKQgLAKgOAAIgBAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("ACUHyIlBgCQgQgBgMgKQgLgKAAgPQAAgOAMgKQALgKARAAIFAADQARAAALAKQAMAKAAAPQAAAOgMAKQgMAKgQAAIAAAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("ACsHyIlXgCQgSgBgMgKQgNgKAAgPQABgOAMgKQANgKARAAIFXADQASAAAMAKQANAKAAAPQgBAOgMAKQgMAKgSAAIAAAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("ACzHyIlmgDQgSAAgNgKQgNgKAAgPQAAgOANgKQANgKATAAIFmADQASAAANAKQANALAAAOQAAAOgNAKQgNAKgSAAIgBAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AC4HzIlwgEQgTAAgNgKQgNgKAAgPQAAgOANgKQAOgKATAAIFwADQATAAANAKQANALAAAOQAAAOgOAKQgNALgSAAIgBAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AC7HzIl1gEQgUAAgNgKQgNgKAAgPQAAgOANgKQAOgLATABIF1ADQAUAAANAKQANALAAAOQAAAOgOALQgNAKgTAAIAAAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AC8HzIl3gDQgTgBgOgKQgNgKAAgPQAAgOANgKQAOgKATAAIF3ADQATAAAOAKQANALAAAOQAAAPgOAKQgNAKgTAAIAAAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_1_graphics_12,x:-21.1199,y:49.6995}).wait(1).to({graphics:mask_1_graphics_13,x:-21.1265,y:49.7037}).wait(1).to({graphics:mask_1_graphics_14,x:-21.1393,y:49.7118}).wait(1).to({graphics:mask_1_graphics_15,x:-21.1602,y:49.7253}).wait(1).to({graphics:mask_1_graphics_16,x:-21.1902,y:49.745}).wait(1).to({graphics:mask_1_graphics_17,x:-21.2263,y:49.7694}).wait(1).to({graphics:mask_1_graphics_18,x:-21.2611,y:49.7936}).wait(1).to({graphics:mask_1_graphics_19,x:-21.2893,y:49.8138}).wait(1).to({graphics:mask_1_graphics_20,x:-21.3103,y:49.8291}).wait(1).to({graphics:mask_1_graphics_21,x:-21.199,y:49.8401}).wait(1).to({graphics:mask_1_graphics_22,x:-20.2663,y:49.8476}).wait(1).to({graphics:mask_1_graphics_23,x:-19.6785,y:49.8524}).wait(1).to({graphics:mask_1_graphics_24,x:-19.3631,y:49.855}).wait(1).to({graphics:mask_1_graphics_25,x:-18.8892,y:49.8732}).wait(37));

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("Ai7ALQB7gfD8AQ");
	this.shape_1.setTransform(-16.675,96.4333);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(12).to({_off:false},0).wait(50));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_36 = new cjs.Graphics().p("An+LNQgIg+gGhYQgGhZgBg/QgBg+AFgBIBegGQAFAAAHA9QAIA/AGBZQAGBYABA/QABA/gFAAIhdAHIAAAAQgFAAgIg/g");
	var mask_2_graphics_37 = new cjs.Graphics().p("An9LNQgJg+gGhYQgGhZAAg/QgBg+AGgBIBtgHQAGgBAIA+QAIA/AGBZQAGBYABA+QAABAgFAAIhuAIIAAAAQgFAAgIg/g");
	var mask_2_graphics_38 = new cjs.Graphics().p("An9LNQgJg+gGhYQgGhZAAg/QABg+AHgBICEgJQAHAAAJA9QAJA/AGBZQAGBYAAA+QgBBAgGAAIiFAKIAAAAQgHAAgJg/g");
	var mask_2_graphics_39 = new cjs.Graphics().p("An8LNQgKg+gGhYQgGhYAChAQABg/AJAAIClgLQAIgBAKA+QALA/AGBYQAGBYgCA/QgBA/gJABIilALIAAAAQgIAAgLg+g");
	var mask_2_graphics_40 = new cjs.Graphics().p("An6LNQgMg9gGhZQgGhYADhAQAEg/AKAAIDRgPQAKAAAMA9QAMA/AGBYQAGBZgDA+QgDBAgLABIjQAOIgBAAQgKAAgMg+g");
	var mask_2_graphics_41 = new cjs.Graphics().p("An4LNQgNg9gGhZQgGhYAFhAQAFg/ANgBIEJgSQANgBAOA+QAOA+AGBZQAGBYgFA/QgGBAgNABIkIASIAAAAQgOAAgOg+g");
	var mask_2_graphics_42 = new cjs.Graphics().p("An0LNQgRg9gGhYQgGhZAIhAQAIg/ARgBIFNgXQARgBAQA9QARA/AGBYQAGBYgIA/QgIBAgRACIlNAWIgBAAQgQAAgQg9g");
	var mask_2_graphics_43 = new cjs.Graphics().p("AnxLNQgTg9gGhYQgGhZALhAQAKg/AWgBIGggdQAVgBATA9QAUA+AGBYQAFBZgKA/QgLBAgVABImgAdIgBAAQgVAAgTg9g");
	var mask_2_graphics_44 = new cjs.Graphics().p("AnsLNQgXg9gGhYQgGhYAOhBQAOg/AagCIH+gjQAagCAXA9QAXA+AGBYQAGBZgOA/QgOBBgaABIn+AjIgCABQgZAAgWg9g");
	var mask_2_graphics_45 = new cjs.Graphics().p("AnnLNQgbg8gGhZQgGhYAShBQASg/AfgDIJlgqQAfgCAaA9QAbA9AGBZQAGBYgSBAQgSBBgfACIpkAqIgCAAQgfAAgZg8g");
	var mask_2_graphics_46 = new cjs.Graphics().p("AniLOQgeg9gGhYQgHhZAWhBQAWhAAkgCILNgxQAlgDAeA9QAeA9AGBYQAGBZgVBAQgWBBgkACIrNAxIgDAAQgjAAgdg6g");
	var mask_2_graphics_47 = new cjs.Graphics().p("AneLOQghg9gGhYQgGhYAZhCQAZhAAqgDIMxg4QApgDAiA9QAiA9AGBYQAGBYgZBBQgZBBgqADIsxA4IgDAAQgoAAghg6g");
	var mask_2_graphics_48 = new cjs.Graphics().p("AoKLOQglg8gGhZQgHhYAdhCQAdhAAugDIOMg/QAugDAlA8QAlA9AGBYQAHBZgdBAQgdBCguADIuMA+IgEAAQgsAAgjg5g");
	var mask_2_graphics_49 = new cjs.Graphics().p("Ao6LOQgng8gGhYQgHhZAghBQAfhBAzgEIPchEQAygDAoA8QAoA8AGBZQAHBYggBBQgfBBgzAEIvcBEIgFAAQgvAAgng5g");
	var mask_2_graphics_50 = new cjs.Graphics().p("ApiLOQgqg8gHhYQgGhZAihBQAihBA2gEIQhhJQA2gDArA7QAqA9AHBYQAGBYgjBBQghBCg2AEIwhBIIgHABQgyAAgog5g");
	var mask_2_graphics_51 = new cjs.Graphics().p("AqFLOQgsg8gGhYQgGhYAjhCQAlhBA5gEIRchNQA5gEAsA7QAtA9AGBYQAGBZgkBBQgkBBg5AEIxcBNIgHAAQg0AAgrg4g");
	var mask_2_graphics_52 = new cjs.Graphics().p("AqiLOQgug8gGhYQgGhYAmhCQAmhBA7gFISNhQQA8gEAuA7QAvA9AGBYQAGBYgmBCQgmBCg7AEIyNBQIgIAAQg3AAgsg4g");
	var mask_2_graphics_53 = new cjs.Graphics().p("Aq6LOQgvg7gGhZQgGhYAnhCQAnhCA+gEIS2hTQA9gEAwA7QAwA8AGBZQAGBYgnBBQgnBCg+AFIy2BTIgIAAQg5AAgtg4g");
	var mask_2_graphics_54 = new cjs.Graphics().p("ArNLOQgxg7gGhZQgGhYAohCQAphCA/gEITYhVQA/gFAxA7QAxA8AGBZQAGBYgpBCQgoBCg/AEIzYBVIgIABQg6AAgug4g");
	var mask_2_graphics_55 = new cjs.Graphics().p("ArdLOQgyg7gGhZQgGhYAphCQAqhCBAgEITzhXQBBgFAyA7QAyA8AGBZQAGBYgqBBQgpBDhAAEIzzBXIgJABQg7AAgvg4g");
	var mask_2_graphics_56 = new cjs.Graphics().p("ArqLOQgyg7gGhZQgHhYAqhCQArhCBCgEIUIhZQBCgEAyA7QAzA7AGBZQAHBYgrBCQgqBChCAFI0IBYIgJABQg8AAgwg4g");
	var mask_2_graphics_57 = new cjs.Graphics().p("Ar0LOQgzg7gGhZQgGhYArhCQArhCBCgEIUZhaQBDgFAzA7QA0A8AGBYQAGBZgrBBQgrBDhCAEI0ZBaIgKAAQg8AAgxg3g");
	var mask_2_graphics_58 = new cjs.Graphics().p("Ar7LOQgzg7gGhZQgGhYArhCQArhCBDgEIUlhbQBDgFA0A7QA0A8AGBYQAGBZgrBBQgrBDhDAEI0lBbIgKAAQg9AAgxg3g");
	var mask_2_graphics_59 = new cjs.Graphics().p("Ar/LOQg0g7gGhYQgGhZArhCQAshCBDgEIUthcQBEgEA0A7QA0A7AGBZQAHBYgtBCQgrBChDAFI0tBbIgKAAQg+AAgwg3g");
	var mask_2_graphics_60 = new cjs.Graphics().p("AsCLOQg0g7gGhYQgGhZArhCQAshCBEgEIUyhcQBDgFA0A7QA1A8AGBYQAGBZgsBBQgrBDhEAEI0yBcIgJAAQg+AAgxg3g");
	var mask_2_graphics_61 = new cjs.Graphics().p("AsDLPQg0g7gGhYQgGhYArhDQAshBBEgFIUzhcQBEgEA0A6QA1A8AGBZQAGBYgsBCQgrBChEAFI0zBbIgKABQg+AAgxg4g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(36).to({graphics:mask_2_graphics_36,x:-53.1831,y:77.972}).wait(1).to({graphics:mask_2_graphics_37,x:-53.1299,y:77.964}).wait(1).to({graphics:mask_2_graphics_38,x:-53.0582,y:77.9517}).wait(1).to({graphics:mask_2_graphics_39,x:-52.9723,y:77.9345}).wait(1).to({graphics:mask_2_graphics_40,x:-52.8752,y:77.9117}).wait(1).to({graphics:mask_2_graphics_41,x:-52.7671,y:77.8824}).wait(1).to({graphics:mask_2_graphics_42,x:-52.6473,y:77.8462}).wait(1).to({graphics:mask_2_graphics_43,x:-52.5155,y:77.8028}).wait(1).to({graphics:mask_2_graphics_44,x:-52.3734,y:77.7533}).wait(1).to({graphics:mask_2_graphics_45,x:-52.2257,y:77.6998}).wait(1).to({graphics:mask_2_graphics_46,x:-52.0795,y:77.6457}).wait(1).to({graphics:mask_2_graphics_47,x:-51.942,y:77.594}).wait(1).to({graphics:mask_2_graphics_48,x:-46.8859,y:77.547}).wait(1).to({graphics:mask_2_graphics_49,x:-41.6744,y:77.5057}).wait(1).to({graphics:mask_2_graphics_50,x:-37.1847,y:77.4702}).wait(1).to({graphics:mask_2_graphics_51,x:-33.375,y:77.4401}).wait(1).to({graphics:mask_2_graphics_52,x:-30.1788,y:77.4149}).wait(1).to({graphics:mask_2_graphics_53,x:-27.5249,y:77.394}).wait(1).to({graphics:mask_2_graphics_54,x:-25.347,y:77.3769}).wait(1).to({graphics:mask_2_graphics_55,x:-23.586,y:77.3631}).wait(1).to({graphics:mask_2_graphics_56,x:-22.1913,y:77.3521}).wait(1).to({graphics:mask_2_graphics_57,x:-21.1196,y:77.3437}).wait(1).to({graphics:mask_2_graphics_58,x:-20.3342,y:77.3375}).wait(1).to({graphics:mask_2_graphics_59,x:-19.8038,y:77.3334}).wait(1).to({graphics:mask_2_graphics_60,x:-19.502,y:77.331}).wait(1).to({graphics:mask_2_graphics_61,x:-22.0124,y:77.4686}).wait(1));

	// yellow
	this.instance = new lib.highlight();
	this.instance.setTransform(-17.8,128.8,1.1287,1.1144,-3.9351,0,0,52.4,2.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).wait(26));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-93.1,0,151.5,151);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(180.35,119.8,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(124.3,172.5,1,1,0,0,0,125.9,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(124.3,52.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-2.1,-6.6,243.5,243.5), null);


(lib.cta_arrow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// Layer_5 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgaDEQgJgJgHgQQgGgOgCgMQgCgNAFgCIA+gfQAEgCAIAJQAJAJAGAPQAHAPACAMQACANgEACIg/AeIgBABQgFAAgGgHg");
	var mask_graphics_24 = new cjs.Graphics().p("AgaDEQgJgJgHgQQgGgOgCgMQgCgNAFgCIA+gfQAEgCAIAJQAJAJAGAPQAHAPACAMQACANgEACIg/AeIgBABQgFAAgGgHg");
	var mask_graphics_25 = new cjs.Graphics().p("AglDEQgJgJgHgPQgHgPgBgMQgBgNAGgDIBPgnQAGgCAJAIQAJAJAHAPQAHAPABAMQABANgGADIhPAmIgDABQgFAAgHgGg");
	var mask_graphics_26 = new cjs.Graphics().p("AgvDEQgKgIgHgQQgHgOAAgNQAAgOAHgDIBfguQAHgDAKAIQAKAIAHAPQAHAPAAANQAAANgHADIhfAuIgFABQgFAAgHgFg");
	var mask_graphics_27 = new cjs.Graphics().p("Ag5DEQgKgIgIgPQgGgPAAgNQABgOAIgEIBvg1QAIgEALAIQAKAIAHAPQAHAPAAANQgBAOgIADIhvA2IgFABQgGAAgIgFg");
	var mask_graphics_28 = new cjs.Graphics().p("AhBDEQgMgIgHgPQgHgPACgNQABgOAJgFIB9g7QAJgEALAHQAMAHAHAPQAHAPgCAOQgBAOgJAEIh9A8QgDABgEAAQgGAAgHgEg");
	var mask_graphics_29 = new cjs.Graphics().p("AhJDEQgMgHgIgQQgGgOACgPQABgOALgEICJhCQAKgFAMAHQANAHAGAPQAHAPgCAOQgBAPgLAEIiJBCQgEACgEAAQgHAAgHgEg");
	var mask_graphics_30 = new cjs.Graphics().p("AhRDDQgMgGgIgQQgGgOACgPQADgOALgFICVhHQALgFANAGQAMAHAHAPQAHAPgCAPQgDAOgLAFIiVBHQgFACgFAAQgGAAgIgEg");
	var mask_graphics_31 = new cjs.Graphics().p("AhXDDQgOgGgHgPQgHgPAEgPQADgOAMgGICghMQALgFANAGQAOAHAHAPQAHAPgEAOQgDAPgLAFIigBMQgGADgFAAQgHAAgHgEg");
	var mask_graphics_32 = new cjs.Graphics().p("AhdDDQgOgGgHgPQgHgPAEgPQADgPANgGICphQQAMgGAOAHQAOAGAHAPQAHAPgEAPQgDAPgMAFIiqBRQgGADgGAAQgHAAgHgEg");
	var mask_graphics_33 = new cjs.Graphics().p("AhiDDQgPgGgHgPQgHgPAEgPQAEgPAOgGICyhUQAMgGAOAGQAPAGAHAPQAHAPgEAPQgEAPgNAGIiyBUQgHADgGAAQgHAAgHgDg");
	var mask_graphics_34 = new cjs.Graphics().p("AhnDDQgPgGgHgPQgHgPAFgPQAEgPAOgHIC5hXQANgGAPAFQAPAGAHAPQAHAPgFAPQgEAQgOAGIi5BYQgHADgHAAQgHAAgHgDg");
	var mask_graphics_35 = new cjs.Graphics().p("AhrDDQgPgGgHgPQgHgOAFgQQAFgPAOgHIC/hbQAOgGAPAGQAPAGAHAOQAHAPgFAQQgFAPgOAHIi/BaQgHAEgIAAQgHAAgHgDg");
	var mask_graphics_36 = new cjs.Graphics().p("AhuDDQgPgFgHgQQgHgOAFgQQAFgPAOgHIDFhdQAOgHAPAGQAPAFAHAPQAHAPgFAQQgFAPgOAHIjEBdQgIAEgIAAQgHAAgHgDg");
	var mask_graphics_37 = new cjs.Graphics().p("AhwDDQgQgFgHgQQgHgOAFgQQAFgQAQgHIDIheQAOgHAPAGQAQAFAHAPQAHAPgFAQQgFAPgPAHIjIBfQgIAEgJAAQgGAAgHgDg");
	var mask_graphics_38 = new cjs.Graphics().p("AhyDDQgQgFgHgQQgHgOAGgQQAFgQAPgHIDLhgQAOgHAQAGQAQAFAHAPQAHAPgGAQQgFAQgPAGIjLBhQgIADgIAAQgHAAgHgCg");
	var mask_graphics_39 = new cjs.Graphics().p("AhzDDQgQgFgHgQQgHgOAGgQQAFgQAPgHIDNhhQAOgGAQAFQAQAFAHAPQAHAPgGAQQgFAQgPAHIjMBgQgJAEgJAAQgGAAgHgCg");
	var mask_graphics_40 = new cjs.Graphics().p("AhzDEQgQgGgHgPQgHgPAFgPQAGgQAPgHIDNhiQAPgGAPAFQAQAFAHAPQAHAPgFAQQgGAQgPAHIjNBhQgIAEgJAAQgHAAgGgCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-4.8696,y:20.2831}).wait(24).to({graphics:mask_graphics_24,x:-4.8696,y:20.2831}).wait(1).to({graphics:mask_graphics_25,x:-3.4611,y:20.2081}).wait(1).to({graphics:mask_graphics_26,x:-2.1432,y:20.1404}).wait(1).to({graphics:mask_graphics_27,x:-0.9162,y:20.0794}).wait(1).to({graphics:mask_graphics_28,x:0.2198,y:20.0246}).wait(1).to({graphics:mask_graphics_29,x:1.2648,y:19.9756}).wait(1).to({graphics:mask_graphics_30,x:2.2189,y:19.9319}).wait(1).to({graphics:mask_graphics_31,x:3.0822,y:19.8932}).wait(1).to({graphics:mask_graphics_32,x:3.8546,y:19.8594}).wait(1).to({graphics:mask_graphics_33,x:4.5361,y:19.83}).wait(1).to({graphics:mask_graphics_34,x:5.1267,y:19.805}).wait(1).to({graphics:mask_graphics_35,x:5.6265,y:19.7841}).wait(1).to({graphics:mask_graphics_36,x:6.0354,y:19.7672}).wait(1).to({graphics:mask_graphics_37,x:6.3535,y:19.7542}).wait(1).to({graphics:mask_graphics_38,x:6.5807,y:19.7449}).wait(1).to({graphics:mask_graphics_39,x:6.717,y:19.7394}).wait(1).to({graphics:mask_graphics_40,x:6.6475,y:19.7919}).wait(5));

	// Layer_2 copy
	this.instance = new lib.pointer();
	this.instance.setTransform(7.2,22.85,1,1,0,0,0,12.8,10.7);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45));

	// Layer_5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgUA7QgNgBgBgFIgNhEQgBgFAKgFQALgGARgDQAOgDANABQAMACABAFIAOBDQABAFgLAGQgKAGgRADQgKACgJAAIgIgBg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AgUA7QgNgBgBgFIgNhEQgBgFAKgFQALgGARgDQAOgDANABQAMACABAFIAOBDQABAFgLAGQgKAGgRADQgKACgJAAIgIgBg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AgPBOQgMgDgCgHIgThhQgBgHAKgHQAKgIARgDQAPgDANADQAMADACAHIATBhQABAHgKAIQgLAHgQADIgPABIgNgBg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AgMBfQgNgEgBgJIgYh8QgCgJAKgJQAKgJARgDQAPgDANAFQANAEABAJIAYB8QACAJgKAIQgKAJgQADIgNABQgIAAgIgCg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AgJBuQgNgFgCgLIgdiUQgCgLAKgKQAKgKARgDQAQgDAMAGQANAFACALIAdCUQACAKgKAKQgKAKgQADIgMABQgIAAgJgDg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AgGB7QgOgGgCgMIghipQgCgNAKgLQAKgLAQgDQAQgDAMAHQAOAGACANIAhCpQACAMgKALQgKALgQADIgKABQgKAAgIgFg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AgECHQgOgIgCgNIgki7QgDgOAKgMQAJgMARgDQAQgDAMAHQAOAHACAPIAkC7QADANgKAMQgJAMgRADIgJABQgLAAgIgFg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AgCCQQgOgIgDgOIgnjLQgCgPAJgNQAJgNARgDQAQgDAMAJQAOAIADAPIAnDLQACAOgJANQgJANgRADIgIAAQgLAAgJgGg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AgBCYQgOgIgDgQIgpjXQgDgQAKgOQAJgNAQgDQAQgDANAJQAOAIADARIApDXQADAPgKAOQgJANgQADIgIABQgMAAgJgHg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AAACfQgOgKgDgQIgrjhQgDgRAJgOQAJgOARgDQAQgDANAJQAOAKADARIArDhQADAQgJAOQgKAOgQADIgIABQgLAAgKgHg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AAACjQgNgKgDgRIgsjoQgDgRAJgOQAJgOAQgEQAQgCANAJQAOAKADARIAsDoQADARgJAOQgJAPgQADIgHAAQgMAAgLgHg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AAACmQgNgKgDgRIgtjtQgDgRAJgPQAJgOARgDQAQgDANAJQAOAKADASIAtDsQADARgJAPQgJAOgQADIgIABQgMAAgLgHg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AABCmQgNgKgEgRIgtjuQgDgRAJgPQAJgOARgEQAPgDAOAKQANAKAEASIAtDuQADARgJAOQgJAPgQADIgIABQgMAAgKgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-4.8405,y:5.9812}).wait(16).to({graphics:mask_1_graphics_16,x:-4.8405,y:5.9812}).wait(1).to({graphics:mask_1_graphics_17,x:-4.685,y:7.9487}).wait(1).to({graphics:mask_1_graphics_18,x:-4.3495,y:9.7385}).wait(1).to({graphics:mask_1_graphics_19,x:-4.0494,y:11.344}).wait(1).to({graphics:mask_1_graphics_20,x:-3.7846,y:12.7625}).wait(1).to({graphics:mask_1_graphics_21,x:-3.5552,y:13.993}).wait(1).to({graphics:mask_1_graphics_22,x:-3.361,y:15.0346}).wait(1).to({graphics:mask_1_graphics_23,x:-3.2022,y:15.8872}).wait(1).to({graphics:mask_1_graphics_24,x:-3.0787,y:16.5505}).wait(1).to({graphics:mask_1_graphics_25,x:-2.9904,y:17.0243}).wait(1).to({graphics:mask_1_graphics_26,x:-2.9375,y:17.3087}).wait(1).to({graphics:mask_1_graphics_27,x:-2.9787,y:17.3818}).wait(18));

	// Layer_2
	this.instance_1 = new lib.pointer();
	this.instance_1.setTransform(7.2,22.85,1,1,0,0,0,12.8,10.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(45));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhyGQIAAsfIAOAAQFFAADmDmQDmDlAAFHIAAANg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AhyGQIAAsfIAOAAQFFAADmDmQDmDlAAFHIAAANg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AhymPIAOAAQFFAADmDmQDmDlAAFGIAAANIsfABg");
	var mask_2_graphics_3 = new cjs.Graphics().p("Ah0mOIAOgBQFFAADnDlQDmDlABFGIAAANIsfACg");
	var mask_2_graphics_4 = new cjs.Graphics().p("Ah4mOIANgBQFFgCDpDkQDnDjADFGIAAANIsfAHg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AiBmOIAOAAQFFgHDrDiQDpDhAGFGIABANIsfAPg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AiOmOIANAAQFFgMDvDdQDtDdAMFGIAAANIsdAdg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AijmMIAOgBQFEgVD0DXQD0DXAUFFIABANIsdAyg");
	var mask_2_graphics_8 = new cjs.Graphics().p("Ai/mKIANgBQFEggD8DNQD7DPAgFDIACANIsbBPg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AjkmEIAOgCQFBgxEGDBQEFDCAwFCIACANIsVB2g");
	var mask_2_graphics_10 = new cjs.Graphics().p("AkQl7IANgCQE+hFERCwQERCxBEE+IADANIsNCog");
	var mask_2_graphics_11 = new cjs.Graphics().p("AlFlqIANgEQE4hdEdCaQEeCbBdE3IAEANIr9Dkg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AmBlQIANgFQEuh7EqB+QEsB/B7EtIAEAMIrjEtg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AnAkpIAMgGQEeidE3BbQE4BcCdEdIAGALIq8GAg");
	var mask_2_graphics_14 = new cjs.Graphics().p("An+juIALgIQEGjCFAAvQFCAxDCEGIAIALIqCHag");
	var mask_2_graphics_15 = new cjs.Graphics().p("AoyifIAJgJQDmjoFEgCQFFgBDoDmIAJAJIozI3g");
	var mask_2_graphics_16 = new cjs.Graphics().p("AovhMIAJgLQDEkFFCguQFBgtEEDEIALAIInhJ+g");
	var mask_2_graphics_17 = new cjs.Graphics().p("AoiAAIAHgLQClkaE6hSQE6hSEaClIALAHImUKwg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AoSBDIAGgMQCJknExhwQExhwEoCJIAMAGIlRLUg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AoBB9IAFgNQBykwEniJQEniHExByIANAEIkXLtg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AnxCsIAEgNQBek3EeibQEeiZE4BeIANAEIjnL9g");
	var mask_2_graphics_21 = new cjs.Graphics().p("AnjDRIADgNQBPk7EWioQEWioE9BPIAMADIjBMHg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AnYDuIADgOQBDk+EQiyQEPixE/BDIANACIikMOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AnQECIADgNQA6lAELi5QELi5FBA7IANACIiQMRg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AnKEQIACgNQA1lBEIi+QEHi+FCA1IANACIiCMUg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AnGEYIACgNQAxlBEGjBQEFjAFDAxIAMACIh5MVg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AnFEdIACgOQAwlBEFjDQEEjBFDAvIANACIh1MWg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AnEEeIACgNQAvlCEEjDQEEjCFDAvIANACIhzMWg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AnEEeIACgNQAvlCEEjDQEEjCFDAvIANACIhzMWg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:68.4756,y:4.1506}).wait(1).to({graphics:mask_2_graphics_1,x:68.4756,y:4.1506}).wait(1).to({graphics:mask_2_graphics_2,x:68.4756,y:4.1505}).wait(1).to({graphics:mask_2_graphics_3,x:68.4755,y:4.1498}).wait(1).to({graphics:mask_2_graphics_4,x:68.4744,y:4.1478}).wait(1).to({graphics:mask_2_graphics_5,x:68.4687,y:4.1434}).wait(1).to({graphics:mask_2_graphics_6,x:68.4494,y:4.1348}).wait(1).to({graphics:mask_2_graphics_7,x:68.3974,y:4.1196}).wait(1).to({graphics:mask_2_graphics_8,x:68.2787,y:4.0949}).wait(1).to({graphics:mask_2_graphics_9,x:68.0375,y:4.0591}).wait(1).to({graphics:mask_2_graphics_10,x:67.5894,y:4.0139}).wait(1).to({graphics:mask_2_graphics_11,x:66.8139,y:3.9679}).wait(1).to({graphics:mask_2_graphics_12,x:65.548,y:3.9379}).wait(1).to({graphics:mask_2_graphics_13,x:63.5836,y:3.9464}).wait(1).to({graphics:mask_2_graphics_14,x:60.6703,y:4.0056}).wait(1).to({graphics:mask_2_graphics_15,x:56.6974,y:4.0699}).wait(1).to({graphics:mask_2_graphics_16,x:49.2578,y:4.0817}).wait(1).to({graphics:mask_2_graphics_17,x:42.9182,y:4.0852}).wait(1).to({graphics:mask_2_graphics_18,x:37.7756,y:4.1121}).wait(1).to({graphics:mask_2_graphics_19,x:33.6975,y:4.1575}).wait(1).to({graphics:mask_2_graphics_20,x:30.5363,y:4.2091}).wait(1).to({graphics:mask_2_graphics_21,x:28.1473,y:4.2573}).wait(1).to({graphics:mask_2_graphics_22,x:26.398,y:4.2971}).wait(1).to({graphics:mask_2_graphics_23,x:25.1703,y:4.3268}).wait(1).to({graphics:mask_2_graphics_24,x:24.3598,y:4.3471}).wait(1).to({graphics:mask_2_graphics_25,x:23.8733,y:4.3594}).wait(1).to({graphics:mask_2_graphics_26,x:23.6249,y:4.3658}).wait(1).to({graphics:mask_2_graphics_27,x:23.5336,y:4.3681}).wait(1).to({graphics:mask_2_graphics_28,x:23.5283,y:4.3196}).wait(17));

	// Layer_1
	this.instance_2 = new lib.arc();
	this.instance_2.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.6,0,60,33.5);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(-52.05,26.3,1.08,1.08,0,0,0,125.5,52.2);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-189.8,-37.1,263,263), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(0.05,0,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(145.65,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(77.2,570.6,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(81.6,569.95,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// CTA_Arrow
	this.CTA_Arrow = new lib.cta_arrow_1();
	this.CTA_Arrow.name = "CTA_Arrow";
	this.CTA_Arrow.setTransform(134.75,528.6,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.CTA_Arrow).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// laptop
	this.laptop = new lib.laptop_1();
	this.laptop.name = "laptop";
	this.laptop.setTransform(80.35,376.25,0.496,0.496,0,0,0,183.8,127.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// highlights
	this.highlights = new lib.IntroTxtHighlights();
	this.highlights.name = "highlights";
	this.highlights.setTransform(190.15,105.55,1,1,0,0,0,93.4,2.4);

	this.timeline.addTween(cjs.Tween.get(this.highlights).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// anim - grid
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(183,462.55,1,1,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(80.05,182.6,0.859,0.859,0,0,0,93.2,104.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.instance = new lib.bg();
	this.instance.setTransform(81,300,0.54,2.4,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-140,0,384.5,664.8), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							/*popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15*/
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onComplete:function(){mc.highlights.play();}});
				this.tl1.from(mc.laptop,{duration:.8, scaleX:.6, scaleY:.6, y:"+=370", ease:Power2.easeOut}, "<");
				
				this.tl1.to([exportRoot.intro1, mc.highlights],{duration:0.6, alpha: 0, ease:Power4.easeIn}, ">+2");
		
				//laptop
		
				//chart transition
				this.tl1.to(mc.laptop,{duration:.6, scaleX:.68, scaleY:.68, x:"-=0", y:"-=73", ease:Power2.easeInOut}, ">-.2");
				this.tl1.from(mc.laptop.editorCursor, {duration:.8, x:"+=300", ease:Sine.easeOut}, ">-.4");
				this.tl1.from(mc.laptop.editorCursor, {duration:.8, y:"+=150", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.6, x:"+=18", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.from(mc.laptop.socialScreen.dropdown, {duration:.3, y:"-=30", ease:Sine.easeInOut}, ">-.3");
				this.tl1.to(mc.laptop.editorCursor, {duration:.4, y:"+=18", x:"-=12", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.socialScreen.dropdown, {duration:.1, alpha:0, ease:Sine.easeInOut}, "<");
		
				//Editor Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">-2.2");
		
				//Word Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">+2.2");
		
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=80", y:"+=80", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.from(mc.laptop.wordScreen.sub.dropdown, {duration:.3, y:"-=30", ease:Sine.easeInOut}, ">-.3");
				this.tl1.to(mc.laptop.editorCursor, {duration:.4, y:"+=12", x:"-=4", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.wordScreen.sub.dropdown, {duration:.1, alpha:0, ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.wordScreen.sub.panel, {duration:.2, alpha:0, ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=70", y:"-=110", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=150", ease:Power1.easeIn}, ">+.2");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, y:"+=75", ease:Power1.easeInOut}, "<");
				
				//this.tl1.to(mc.laptop.editorCursor, {duration:.8, y:"+=80", ease:Sine.easeOut}, "<");
						
				//Word Full Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">-.5");
				
				this.tl1.to(mc.laptop.laptop,{duration:1.2, y:"+=560", ease:Power3.easeIn}, ">+.7");
				this.tl1.to(mc.laptop.wordScreen,{duration:.5, y:"+=5", rotation:"+=10", ease:Power1.easeInOut}, "<+.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.7, y:"-=120", ease:Power1.easeInOut}, ">-.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.5, y:"+=84", ease:Power1.easeIn}, ">");
				this.tl1.from(mc.laptop.angledShadow2,{duration:.5, alpha:0, ease:Power1.easeIn}, "<");
				this.tl1.to(mc.laptop.wordScreen,{duration:1.2, scaleX:.8, scaleY:.8, x:"+=71", y:"-=75", ease:Power1.easeInOut}, ">-1.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:1, rotation:"-=48", ease:Power1.easeIn}, "<+.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.4, rotation:"+=17", ease:Back.easeOut}, ">");
				
				this.tl1.from(mc.anim,{duration:.6, alpha:0, ease:Power3.easeInOut}, "<-.6");
				this.tl1.from(mc.laptop.wordScreen.sml,{duration:.6, alpha:0, ease:Power3.easeInOut}, "<-.2");
				
				this.tl2 = gsap.timeline();	
				
				this.tl2.from([mc.laptop.socialScreenEnd, mc.laptop.angledShadow1],{duration:.6, x:"+=80", alpha:0, ease:Power2.easeOut});
				this.tl2.from(mc.laptop.socialScreenEnd,{duration:.4, rotation:"+=10", ease:Back.easeOut}, ">-.2");
				this.tl2.from(mc.laptop.editorCursorEnd,{duration:.8, x:"+=90", alpha:0, ease:Power3.easeOut}, "<+.2");
				
				this.tl2.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.6");
				this.tl1.from(mc.cta, 0.8, { scaleX:0, scaleY:0, ease:Power4.easeOut, onStart:function(){mc.CTA_Arrow.play();}}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl2.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
		
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:Linear.easeNone},">-.7");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-60.1,300,304.6,364.79999999999995);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622807541624", id:"M365_FY22Q1BTS_USA_160x600_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;