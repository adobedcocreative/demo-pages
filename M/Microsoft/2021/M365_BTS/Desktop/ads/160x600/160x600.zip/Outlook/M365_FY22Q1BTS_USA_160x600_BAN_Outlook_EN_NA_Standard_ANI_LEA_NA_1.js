(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[593,502,130,199],[725,701,143,145],[0,0,750,500],[752,378,272,182],[395,707,218,73],[0,772,218,73],[752,0,211,376],[395,502,196,203],[0,502,393,268],[725,562,182,137]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BudgetMeeting_lg = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ExcelLogo = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_CU = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_FinalFrame = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.NewMeeting_lg_sh = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.NewSkypeMeeting_lg_sh = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.OutlookBTSCalendarMobilepngcopy = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.tileShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.VirtualMeeting_lg = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pointerc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhKBlQgkgXgRihQgBgJAFgGQAGgGAIgBQAIgBAGAFQAHAFABAIQAFA3ALAtQAKAuAJAJQAMADAtgSQAtgSAxgaQAHgEAIADQAIACAEAHQAEAHgCAIQgDAJgHADQh2BAgzAAQgOAAgJgGg");
	this.shape.setTransform(12.8311,10.6417);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointerc, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.OutlookLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelLogo();
	this.instance.setTransform(-16,-24.05,0.8727,0.8727);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OutlookLogo, new cjs.Rectangle(-16,-24,124.8,126.5), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mail_lines_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A6CB1QgrAAgegfQgfgeAAgtQAAgpAfgfQAegeArAAIADAAQFBACJugEIR9gNIAJAAQPbgLDxAAQArAAAfAeQAfAfAAAsQAAAqgfAfQgfAfgrgBQkUAAuvAMIgoABQ0eAPnlgBIkWgBg");
	this.shape.setTransform(34.4412,47.6946,0.1945,0.1945);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("A0LBnQgrAAgeggQgfgeAAgrQACgsAegdQAfgeAqgBQJTAGVsgDIJWgBQArAAAgAfQAeAfAAAqQAAArgeAgQggAegrAAI3GACQrFAAmLgEg");
	this.shape_1.setTransform(41.7339,31.7381,0.1945,0.1945);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AN3B0IACgEQmJgRlVgBQmTAArOATQgrABgggdQgggdgBgrIAAgDQgBgqAdggQAegfAsgBQLxgUGjACQFRABG2AUQArACAeAgQAdAggCAqQgCArgeAdQgeAdgrAAg");
	this.shape_2.setTransform(47.9726,17.0536,0.1945,0.1945);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("An1BgIgDAAQgqgHgagjQgZgjAGgqQAHgrAkgaQAjgZArAHQBUAND6AAQCXAAFJgHICOgDQAsAAAfAeQAfAeABAsQABAqgeAfQgfAggrAAIiOADQlgAHiKAAIg8ABQiXAAiUgRg");
	this.shape_3.setTransform(57.3474,2.2121,0.1945,0.1945);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mail_lines_sub, new cjs.Rectangle(0,0,68.9,50), null);


(lib.line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AH2FDQhmgViBhpQgdgXjEi1QiLiChmg9QiKhTiGgEIAAAAQjegGkcB8QhcAohgA1IAAAAQgxAbgwAcQgJAGgKgDQgKgDgGgJQgFgIADgKQACgKAJgGQAxgcAygcIAAAAQBig2BegpQEoiBDnAHIAAAAQCTADCWBbQBpA/CQCHQDCCyAdAXQB1BgBdAUQDkAwEXiYQCNhNBehYQAIgGAKABQALAAAHAHQAHAIgBAKQAAAKgIAHQhiBbiTBRQjgB6jCAAQhAAAg8gNg");
	this.shape.setTransform(127.2216,31.1607);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_sub, new cjs.Rectangle(-2.5,-2.5,259.5,67.3), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.letter_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmxFoQgRAAgPgGQgPgHgMgMQgKgLgGgOQgGgPAAgPIAAovQAAgPAGgOQAFgOALgLQALgNAPgGQAQgHARAAINjAAQAPAAAPAFQAOAGALAKQAMAMAHAPQAGAPAAARIAAIvQABAPgGAPQgGAOgLALQgLAMgQAHQgPAGgQAAgAm8E/QAFABAGAAINjAAQAFAAAFgBIlvkBIhAA3QgGAFgHAAQgGAAgGgFIhAg4gAFbiuIjwDQIFuEAIACgKIAAovQgBgGgCgGgAnakXIAAIvQAAAFACAFIFtj/IjvjOIh/h1IgBAJgAm+k9IB/B0IE/EVIFJkgIByhqIgJgBItjAAQgGAAgHACg");
	this.shape.setTransform(51.4519,36.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letter_sub, new cjs.Rectangle(0,0,102.9,72.1), null);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg5XDVeMAAAmq7MByvAAAMAAAGq7g");
	this.shape.setTransform(481.45,404.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(114.3,-961.5,734.3000000000001,2732.4), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8hKMAl5AAAAy8jgMAl5AAAAy8l2MAl5AAAAy8oMMAl5AAAAy8F3MAl5AAAAy8DhMAl5AAAAy8BLMAl5AAAAy8INMAl5AAA");
	this.shape.setTransform(121.25,52.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-1,-1,244.5,107), null);


(lib.fileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tileShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fileShadow, new cjs.Rectangle(0,0,196,203), null);


(lib.file4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.NewSkypeMeeting_lg_sh();
	this.instance.setTransform(35.25,60.1,0.6691,0.6691);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file4, new cjs.Rectangle(35.3,60,148.10000000000002,52), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.VirtualMeeting_lg();
	this.instance.setTransform(-0.1,-0.05,0.809,0.809);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(-2.4,-2.4,170,133.4), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.NewMeeting_lg_sh();
	this.instance.setTransform(21.35,62.2,0.68,0.68);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file1, new cjs.Rectangle(0,61.2,196,74.3), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ExcelUI_FinalFrame();
	this.instance.setTransform(-0.05,0,1.3786,1.3785);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(0,0,375,250.9), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.calendar_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A5ndQQijAAhyhkQh0hmAAiOMAAAgwBQABiHBshfQBuhgCagBMAz3AAAQCaABBuBgQBtBfAACHMAAAAwBQAACOhzBmQhzBkiiAAgANqadIL+AAQBPABA3gxQA2gwABhFIAAqiIu7AAgAncadIR6AAIAAtHIx6AAgA8jX4QAABFA3AwQA3AxBOgBIO/AAIAAtHIx7AAgANqKiIO7AAIAAtGIu7AAgAncKiIR6AAIAAtGIx6AAgA8jKiIR7AAIAAtGIx7AAgANqlXIO7AAIAAtIIu7AAgAnclXIR6AAIAAtIIx6AAgA8jlXIR7AAIAAtIIx7AAgA7u51QgxArgEBBIAAC3MA5IAAAIAAi3QgFhBgxgrQgygrhBAEMgz3AAAIgKgBQg7AAguAog");
	this.shape.setTransform(53.7185,49.4897,0.2643,0.2643);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.calendar_sub, new cjs.Rectangle(0,0,107.5,99), null);


(lib.bang_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABTDbQgDgBgCgEQgCgEABgEQACgDAEgCIBRgmIgrgQIABAAIg1gTQgEgBgCgDQgCgEABgEQABgDADgDQBPgzAggaIg9AHIhHAJQgDAAgEgCQgDgCgBgDQgBgDACgEIA4iHIhxBjQgDACgEAAQgDAAgDgCQgDgDAAgEIgDieIhICbQgCAEgEABQgDACgEgCQgEgBgBgEIgzh/QgFAfgEAzQgDApAAAiQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEQAAgjADgpQAGhVANghQABgCACgCQADgCADAAQADAAADACQACACABACQANAkAoBjIBQitQABgDADgCQAEgCADABQADABADADQACACAAAEIADCzICBhxQADgCADAAQAEAAADACQADACABADQABAEgCADIhCCeIA2gHQBLgJAQAAQAEAAACACQADADABAEQAAAEgCADQgPAVhnBEIAhAMIAAAAQA5AVAIAFQAEADAAADQACAEgCADQgBADgEACIhlAvIgEABIgEgBg");
	this.shape.setTransform(20.5024,21.0027);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_sub, new cjs.Rectangle(-1,-1,43,44), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AoHCLIAAkVIQPAAIAAEVg");
	this.shape.setTransform(50,13.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-1.9,-0.3,103.9,27.8), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.arc_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkCCeQgIgEgDgHQgDgIADgIQBrj0DbgmQBugTBcAeQAHADAEAHQADAIgCAIQgDAIgHADQgIAEgIgDQhXgdhjASQjCAlhhDfQgFAMgNAAIgIgBg");
	this.shape.setTransform(27.1896,15.9604);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc_c, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OutlookBTSCalendarMobilepngcopy();
	this.instance.setTransform(-41.9,-19.85,0.7725,0.7725);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(-42.9,-27.1,168.1,297.70000000000005), null);


(lib.squiggle_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-270,-70,540,140,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.line_sub();
	this.line.name = "line";
	this.line.setTransform(127.2,31.2,1,1,0,0,0,127.2,31.2);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squiggle_line, new cjs.Rectangle(-2.5,-2.5,259.5,67.3), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.pointer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointer.cache(0,0,30,25,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointer = new lib.pointerc();
	this.pointer.name = "pointer";
	this.pointer.setTransform(12.8,10.7,1,1,0,0,0,12.8,10.7);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mail_lines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.lines.cache(0,0,70,70,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lines = new lib.mail_lines_sub();
	this.lines.name = "lines";
	this.lines.setTransform(34.5,24.95,1,1,0,0,0,34.5,25);

	this.timeline.addTween(cjs.Tween.get(this.lines).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mail_lines, new cjs.Rectangle(0,0,68.9,50), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_118 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(118).call(this.frame_118).wait(2));

	// Layer_3 copy 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_85 = new cjs.Graphics().p("AJOA4QgCgrAAg7QgBg9ACgrQABgrACAAIAnAAQACAAACArQABArAAA9QABA7gCArQgBArgCAAIgnAAQgCAAgBgrg");
	var mask_graphics_86 = new cjs.Graphics().p("AJHA5QgDgrAAg7QgBg9ABgrQACgrACAAIAzAAQADAAACAqQADAsAAA8QABA8gBAqQgCArgCAAIg0ABQgCAAgCgrg");
	var mask_graphics_87 = new cjs.Graphics().p("AI+A6QgDgrgBg7QgBg8ABgsQACgqADAAIBCgCQADAAADArQADArACA8QABA8gCArQgBArgEAAIhBABIAAAAQgDAAgEgrg");
	var mask_graphics_88 = new cjs.Graphics().p("AI1A8QgEgrgCg7QgCg9ACgrQABgrAFAAIBSgCQAEAAAEAqQAEArACA9QACA7gCArQgCArgEAAIhSADIAAAAQgEAAgEgrg");
	var mask_graphics_89 = new cjs.Graphics().p("AIqA+QgFgrgDg7QgCg9ACgrQABgrAGAAIBkgEQAFAAAGAqQAFArADA9QACA7gCArQgCArgFAAIhlAEIAAAAQgFAAgFgqg");
	var mask_graphics_90 = new cjs.Graphics().p("AIeBAQgHgqgDg7QgDg9ACgrQACgrAGAAIB6gHQAGAAAHAqQAGArAEA9QADA7gCArQgCArgHAAIh5AHIAAAAQgHAAgGgrg");
	var mask_graphics_91 = new cjs.Graphics().p("AIQBDQgIgqgEg7QgEg8ACgsQADgrAHAAICRgKQAIAAAIAqQAIArAEA8QAEA7gDArQgCAsgHAAIiRAKIAAAAQgIAAgIgrg");
	var mask_graphics_92 = new cjs.Graphics().p("AICBHQgKgqgFg7QgFg8ADgsQACgrAJAAICqgOQAJgBAKAqQAJArAFA8QAFA7gCArQgDAsgJAAIiqAOIAAAAQgJAAgJgqg");
	var mask_graphics_93 = new cjs.Graphics().p("AHyBMQgMgqgFg7QgGg8ACgsQADgrAKgBIDGgTQAKgBALAqQAMAqAGA8QAGA7gDArQgDAsgKABIjGATIAAAAQgKAAgLgpg");
	var mask_graphics_94 = new cjs.Graphics().p("AHhBRQgNgpgHg7QgHg8ADgsQADgrAMgBIDjgbQALgBANApQANAqAHA8QAHA7gDAsQgDArgMACIjiAaIgBAAQgLAAgNgpg");
	var mask_graphics_95 = new cjs.Graphics().p("AHPBYQgPgpgIg7QgIg8ADgsQAEgrANgCIECgjQANgCAPApQAPAqAIA8QAIA7gEArQgDAsgNACIkCAjIgBAAQgMAAgPgog");
	var mask_graphics_96 = new cjs.Graphics().p("AG9BfQgRgogKg7QgJg7AEgtQAEgrAOgDIEigtQAPgCARApQARApAJA7QAKA8gEArQgEAsgPACIkiAtIgBAAQgOAAgQgng");
	var mask_graphics_97 = new cjs.Graphics().p("AGpBoQgSgogLg7QgLg7AEgtQAFgrAQgDIFDg5QAQgDATAoQATAoALA8QAKA7gEArQgEAtgQADIlDA5IgCAAQgQAAgSgmg");
	var mask_graphics_98 = new cjs.Graphics().p("AGWByQgVgogMg7QgLg6AEgtQAFgsASgEIFkhGQASgEAVAnQAVAoAMA7QAMA8gFArQgEAtgTADIljBHIgDAAQgRAAgUgkg");
	var mask_graphics_99 = new cjs.Graphics().p("AGDB8QgXgngNg7QgNg6AFgtQAFgtATgEIGFhVQAUgFAXAnQAYAnANA7QANA7gFAsQgFAtgUAEImFBWIgEAAQgSAAgVgjg");
	var mask_graphics_100 = new cjs.Graphics().p("AFwCHQgZglgOg7QgPg6AFguQAGgtAVgFIGmhmQAVgFAaAlQAZAnAOA6QAPA7gGAsQgEAugWAFImmBmIgFABQgTAAgXgig");
	var mask_graphics_101 = new cjs.Graphics().p("AFeCTQgbglgQg6QgPg6AFguQAFgtAYgGIHFh4QAXgGAbAkQAcAmAQA6QAPA7gGAsQgFAugXAGInFB4IgHABQgUAAgYggg");
	var mask_graphics_102 = new cjs.Graphics().p("AFMCfQgdgkgQg6QgRg6AFgtQAGguAZgHIHkiLQAZgHAdAkQAdAkARA6QARA6gGAuQgGAugYAHInkCLIgJABQgVAAgZgfg");
	var mask_graphics_103 = new cjs.Graphics().p("AE8CsQgfgjgSg6QgSg6AGguQAGguAagIIIBieQAagIAfAjQAgAjARA6QASA6gGAuQgGAugaAIIoBCeQgEACgFAAQgXAAgZgdg");
	var mask_graphics_104 = new cjs.Graphics().p("AEsC5QgggjgTg5QgTg5AGgvQAGgvAcgJIIbixQAcgJAhAiQAhAiATA6QATA5gHAvQgGAugbAJIocCyQgGACgGAAQgWAAgbgbg");
	var mask_graphics_105 = new cjs.Graphics().p("AEeDFQgighgUg5QgUg5AGgwQAHgvAcgKII1jFQAdgKAiAiQAjAhAUA5QAUA5gHAwQgGAugcALIo1DFQgHACgHAAQgXAAgbgag");
	var mask_graphics_106 = new cjs.Graphics().p("AERDRQgkgggVg5QgUg5AGgwQAGgvAegLIJMjYQAegLAkAhQAkAgAVA5QAVA5gHAvQgGAwgeALIpMDYQgHACgIAAQgYAAgbgYg");
	var mask_graphics_107 = new cjs.Graphics().p("AEFDdQglgggVg4QgWg5AGgwQAHgvAfgMIJgjrQAfgLAlAfQAmAgAWA4QAVA4gGAxQgHAwgfALIpgDqQgIAEgJAAQgYAAgcgXg");
	var mask_graphics_108 = new cjs.Graphics().p("AD7DoQgmgfgXg4QgWg4AGgxQAHgwAggNIJzj7QAfgNAnAfQAnAfAWA4QAXA4gHAwQgHAxggANIpyD7QgKADgKAAQgYAAgbgVg");
	var mask_graphics_109 = new cjs.Graphics().p("ADyDyQgogegXg4QgXg4AGgxQAHgxAhgNIKDkLQAhgOAnAeQAoAeAYA4QAXA4gHAxQgHAxghAOIqDEKQgKAEgLAAQgYAAgbgUg");
	var mask_graphics_110 = new cjs.Graphics().p("ADqD7QgpgdgYg4QgYg3AHgyQAHgxAigOIKRkaQAigOAoAdQApAdAYA4QAYA3gIAyQgGAxgiAPIqREZQgLAFgMAAQgYAAgbgUg");
	var mask_graphics_111 = new cjs.Graphics().p("ADiEDQgpgcgYg3QgZg4AHgyQAHgxAigPIKeknQAigPAqAcQApAdAZA3QAYA4gHAxQgHAzgiAPIqeEmQgLAFgNAAQgYAAgcgTg");
	var mask_graphics_112 = new cjs.Graphics().p("ADcELQgpgcgZg3QgZg3AGgzQAIgyAigPIKpkyQAjgQAqAcQAqAcAZA3QAZA3gHAyQgHAygjAQIqoEyQgNAGgNAAQgYAAgcgSg");
	var mask_graphics_113 = new cjs.Graphics().p("ADXERQgqgbgZg3Qgag3AHgzQAHgyAjgQIKyk8QAjgRArAcQArAbAZA3QAZA3gHAyQgHAzgjAQIqxE9QgNAGgOAAQgYAAgcgSg");
	var mask_graphics_114 = new cjs.Graphics().p("ADTEXQgrgbgZg3Qgag3AHgzQAHgyAjgRIK5lFQAkgQArAaQAsAcAZA2QAaA3gHAzQgHAygkARIq5FFQgNAHgPAAQgYAAgbgRg");
	var mask_graphics_115 = new cjs.Graphics().p("ADQEbQgsgagag3QgZg3AGgzQAIgyAjgRILAlMQAjgRAsAaQAsAbAaA3QAaA2gIAzQgGAzgkARIq/FMQgOAHgPAAQgYAAgbgRg");
	var mask_graphics_116 = new cjs.Graphics().p("ADNEfQgsgbgag2Qgag3AHgzQAHgyAkgSILElSQAkgRAsAaQAsAbAaA2QAbA3gIAzQgHAzgkARIrDFSQgOAHgQAAQgYAAgbgQg");
	var mask_graphics_117 = new cjs.Graphics().p("ADLEhQgsgagag2Qgag3AGgzQAIgzAkgRILHlWQAkgSAsAaQAtAbAaA2QAbA3gIAyQgGA0glARIrHFWQgOAHgQAAQgYAAgbgQg");
	var mask_graphics_118 = new cjs.Graphics().p("ADwERQgsgagag3Qgbg2AHgzQAHgzAlgSILJlZQAkgRAsAaQAtAaAbA2QAaA3gHAzQgHAzglARIrJFZQgOAHgQAAQgYAAgbgPg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(85).to({graphics:mask_graphics_85,x:63.6441,y:-19.3621}).wait(1).to({graphics:mask_graphics_86,x:64.3629,y:-19.3075}).wait(1).to({graphics:mask_graphics_87,x:65.2113,y:-19.2541}).wait(1).to({graphics:mask_graphics_88,x:66.1918,y:-19.2069}).wait(1).to({graphics:mask_graphics_89,x:67.3064,y:-19.1721}).wait(1).to({graphics:mask_graphics_90,x:68.5554,y:-19.1569}).wait(1).to({graphics:mask_graphics_91,x:69.9373,y:-19.1696}).wait(1).to({graphics:mask_graphics_92,x:71.448,y:-19.219}).wait(1).to({graphics:mask_graphics_93,x:73.0799,y:-19.3145}).wait(1).to({graphics:mask_graphics_94,x:74.822,y:-19.4656}).wait(1).to({graphics:mask_graphics_95,x:76.659,y:-19.6807}).wait(1).to({graphics:mask_graphics_96,x:78.5717,y:-19.967}).wait(1).to({graphics:mask_graphics_97,x:80.5372,y:-20.3294}).wait(1).to({graphics:mask_graphics_98,x:82.5297,y:-20.7698}).wait(1).to({graphics:mask_graphics_99,x:84.522,y:-21.2866}).wait(1).to({graphics:mask_graphics_100,x:86.4864,y:-21.8745}).wait(1).to({graphics:mask_graphics_101,x:88.397,y:-22.5247}).wait(1).to({graphics:mask_graphics_102,x:90.2305,y:-23.2255}).wait(1).to({graphics:mask_graphics_103,x:91.9676,y:-23.963}).wait(1).to({graphics:mask_graphics_104,x:93.5935,y:-24.7224}).wait(1).to({graphics:mask_graphics_105,x:95.0979,y:-25.4883}).wait(1).to({graphics:mask_graphics_106,x:96.475,y:-26.2463}).wait(1).to({graphics:mask_graphics_107,x:97.7228,y:-26.9831}).wait(1).to({graphics:mask_graphics_108,x:98.8422,y:-27.6872}).wait(1).to({graphics:mask_graphics_109,x:99.8365,y:-28.3489}).wait(1).to({graphics:mask_graphics_110,x:100.7106,y:-28.9604}).wait(1).to({graphics:mask_graphics_111,x:101.4703,y:-29.5158}).wait(1).to({graphics:mask_graphics_112,x:102.1222,y:-30.0109}).wait(1).to({graphics:mask_graphics_113,x:102.6728,y:-30.4431}).wait(1).to({graphics:mask_graphics_114,x:103.1286,y:-30.8109}).wait(1).to({graphics:mask_graphics_115,x:103.4956,y:-31.1139}).wait(1).to({graphics:mask_graphics_116,x:103.7797,y:-31.3527}).wait(1).to({graphics:mask_graphics_117,x:103.986,y:-31.5286}).wait(1).to({graphics:mask_graphics_118,x:107.9152,y:-33.4835}).wait(2));

	// Layer_12
	this.instance = new lib.squiggle_line();
	this.instance.setTransform(83.6,-47.75,0.8531,0.8531,-0.0072,0,0,127.2,31);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(85).to({_off:false},0).wait(35));

	// Layer_3 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_58 = new cjs.Graphics().p("ADIiuIhDgGQgDAAABgmQABglAEg0QAFg1AGglQAGglADAAIBDAGQADAAAAAmQgBAlgFA1QgFA1gFAkQgGAlgDAAIgBAAg");
	var mask_1_graphics_59 = new cjs.Graphics().p("ADOitIhPgHQgEAAABgmQABglAFg1QAFg0AGgmQAHgkAEAAIBPAIQAEAAgBAlQgBAmgFA0QgFA1gHAlQgGAlgEAAIAAgBg");
	var mask_1_graphics_60 = new cjs.Graphics().p("ADVirIhdgKQgFAAABgmQAAglAGg1QAFg0AIglQAHglAFABIBcAKQAFAAAAAlQgBAmgGA1QgFA0gHAlQgIAkgEAAIAAAAg");
	var mask_1_graphics_61 = new cjs.Graphics().p("ADcipIhtgMQgFgBAAgmQABglAGg0QAGg1AIglQAIgkAGABIBtAMQAFABAAAlQAAAmgHA0QgGA1gIAkQgIAkgGAAIAAAAg");
	var mask_1_graphics_62 = new cjs.Graphics().p("ADlimIiAgQQgGgBAAgmQAAglAHg0QAHg1AJgkQAKgkAGAAICAARQAGABAAAlQAAAmgHA0QgHA0gJAlQgKAjgGAAIAAAAg");
	var mask_1_graphics_63 = new cjs.Graphics().p("ADuiiIiUgVQgHgBAAgmQAAglAHg0QAIg1AKgkQALgkAIABICUAVQAHACAAAlQAAAmgHA0QgIA0gKAkQgLAjgHAAIgBAAg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AD5idIirgbQgJgBAAgmQAAgmAIg0QAIg0ANgkQAMgjAIABICrAbQAJACAAAlQABAmgJA0QgIA0gMAkQgMAigIAAIgBAAg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AEFiWIjEgjQgKgCgBgmQAAgmAJgzQAJg0AOgkQANgjAKACIDFAjQAKACAAAlQABAmgKA0QgJA0gNAjQgNAigKAAIgBAAg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AESiOIjggsQgLgCgBgnQgBgmAKgzQALg0APgjQAPgiAMACIDfAsQALACABAmQABAmgKA0QgKAzgQAjQgOAhgLAAIgBAAg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AEfiEIj8g4QgNgCgBgnQgBgmALgzQALgzARgjQARgiANADID8A3QANADABAmQACAmgMA0QgLAzgRAiQgQAggMAAIgCAAg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AEth5IkahEQgPgDgBgnQgCgmANgzQAMgzATgiQATgiAOAEIEbBEQAOAEACAmQABAngMAzQgMAzgTAhQgRAfgOAAIgDgBg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AE8hrIk6hTQgPgFgCgnQgCgmAOgzQAMgyAVgiQAVggAQAEIE6BUQAQAEACAnQACAngOAyQgNAzgVAgQgSAegPAAIgEgBg");
	var mask_1_graphics_70 = new cjs.Graphics().p("AFLhbIlZhlQgSgFgCgoQgCgnAOgyQAPgyAWggQAXggASAGIFaBlQASAFACAnQACAngPAyQgOAzgXAfQgUAcgQAAIgFgBg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AFahJIl6h5QgTgGgCgoQgDgnAQgyQAQgxAYgfQAZgfATAGIF7B5QAUAGACAnQACAogPAyQgQAygZAeQgVAagRAAIgHgBg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AFqg1ImbiOQgVgHgCgpQgDgnARgyQARgxAbgeQAagdAVAHIGbCOQAVAHADAoQADApgRAxQgSAxgbAdQgVAZgSAAIgIgCg");
	var mask_1_graphics_73 = new cjs.Graphics().p("AF4gfIm5imQgXgIgDgpQgDgoASgxQATgxAdgdQAcgcAWAJIG7CmQAWAIADAoQADApgSAxQgSAwgdAdQgXAWgSAAQgGAAgFgCg");
	var mask_1_graphics_74 = new cjs.Graphics().p("AGHgIInYi+QgYgKgEgpQgDgpAUgwQATgxAfgbQAfgbAXAKIHZC+QAYAKADApQADApgTAwQgUAxgeAbQgXAUgTAAQgHAAgGgDg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AGUAQIn0jYQgagLgDgqQgEgpAVgwQAUgvAhgbQAhgZAYALIH2DYQAZALAEAqQADAqgUAvQgVAwghAZQgXASgTAAQgIAAgIgDg");
	var mask_1_graphics_76 = new cjs.Graphics().p("AGhApIoPjyQgbgNgEgqQgEgqAWgvQAWgvAigZQAjgYAaAMIIQDzQAaAMAEAqQAEArgWAvQgVAugjAYQgXARgUAAQgJAAgJgEg");
	var mask_1_graphics_77 = new cjs.Graphics().p("AGsBCIonkMQgcgOgEgrQgEgrAWguQAXgvAkgXQAkgXAdAOIInENQAcAOAEAqQAEArgXAvQgWAtgkAXQgXAPgUAAQgLAAgLgFg");
	var mask_1_graphics_78 = new cjs.Graphics().p("AG3BbIo+knQgdgPgEgrQgEgrAXguQAYguAlgXQAmgVAdAPII+EnQAeAQAEArQAEArgYAtQgYAuglAWQgXANgTAAQgNAAgMgGg");
	var mask_1_graphics_79 = new cjs.Graphics().p("AHBBzIpTlAQgegQgEgsQgEgsAYgtQAZguAngVQAngUAeAQIJSFBQAeARAFArQAEAsgZAtQgYAtgnAVQgWALgTAAQgPAAgNgHg");
	var mask_1_graphics_80 = new cjs.Graphics().p("AHJCLIpklZQgfgRgEgtQgFgsAagtQAZgtAogUQAogTAgASIJkFZQAfASAEAsQAEArgZAtQgaAtgoATQgVALgTAAQgQAAgPgIg");
	var mask_1_graphics_81 = new cjs.Graphics().p("AHRChIp0lvQgggTgEgtQgFgtAagsQAagtAqgSQApgSAgASIJ0FwQAgATAEAsQAEAtgaAsQgaAtgpASQgVAJgSAAQgSAAgQgJg");
	var mask_1_graphics_82 = new cjs.Graphics().p("AHXC1IqBmEQghgUgEguQgFgtAbgsQAbgsAqgRQAqgRAhAUIKBGFQAhAUAEAsQAFAtgbAsQgbAsgqARQgUAIgSAAQgUAAgRgKg");
	var mask_1_graphics_83 = new cjs.Graphics().p("AHdDIIqNmYQgigVgEguQgEgtAbgsQAbgrArgRQArgQAiAVIKNGYQAhAUAEAuQAFAugcArQgbAsgrAQQgTAHgRAAQgWAAgSgLg");
	var mask_1_graphics_84 = new cjs.Graphics().p("AHiDZIqYmpQghgWgFguQgEguAcgrQAbgsAsgPQAsgPAiAVIKXGpQAiAWAEAtQAEAvgbArQgcAsgsAPQgSAGgRAAQgXAAgTgMg");
	var mask_1_graphics_85 = new cjs.Graphics().p("AHmDnIqgm4QgigWgFgvQgEguAcgrQAcgrAtgPQAsgOAiAWIKgG4QAiAXAFAuQAEAvgcArQgcArgtAOQgRAGgQAAQgZAAgUgOg");
	var mask_1_graphics_86 = new cjs.Graphics().p("AHpD0IqnnFQgigXgFgvQgEgvAdgqQAcgrAtgOQAtgOAiAXIKnHGQAjAXAEAuQAFAvgdArQgdArgsANQgSAGgPAAQgZAAgWgPg");
	var mask_1_graphics_87 = new cjs.Graphics().p("AHsD/IqtnQQgjgYgEgvQgEgvAdgqQAdgrAtgOQAtgNAjAYIKtHRQAiAYAFAuQAEAvgdArQgdArgtAMQgQAFgQAAQgaAAgWgPg");
	var mask_1_graphics_88 = new cjs.Graphics().p("AHuEIIqxnZQgjgZgFgvQgEgvAdgqQAdgrAugNQAugMAjAYIKxHaQAjAYAEAvQAFAvgdArQgeAqgtAMQgQAFgPAAQgbAAgXgQg");
	var mask_1_graphics_89 = new cjs.Graphics().p("AHwEPIq1nhQgjgYgFgwQgEgvAegqQAdgqAugNQAugMAjAYIK1HhQAjAZAEAvQAFAwgeAqQgdAqguAMQgQAFgOAAQgcAAgXgRg");
	var mask_1_graphics_90 = new cjs.Graphics().p("AHxEVIq3nnQgkgZgEgvQgEgvAdgrQAegqAugMQAugMAjAZIK3HmQAkAZAEAvQAFAwgeAqQgdAqguAMQgQAEgOAAQgcAAgYgQg");
	var mask_1_graphics_91 = new cjs.Graphics().p("AH5EeIq5nqQgkgZgEgwQgEgvAdgqQAegqAugNQAugLAkAZIK5HpQAjAZAEAwQAFAvgeAqQgdAqgvAMQgPAEgOAAQgcAAgYgQg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_1_graphics_58,x:22.5761,y:-43.4766}).wait(1).to({graphics:mask_1_graphics_59,x:23.3941,y:-43.4951}).wait(1).to({graphics:mask_1_graphics_60,x:24.3657,y:-43.5154}).wait(1).to({graphics:mask_1_graphics_61,x:25.4953,y:-43.5369}).wait(1).to({graphics:mask_1_graphics_62,x:26.7855,y:-43.5589}).wait(1).to({graphics:mask_1_graphics_63,x:28.237,y:-43.5803}).wait(1).to({graphics:mask_1_graphics_64,x:29.8476,y:-43.5999}).wait(1).to({graphics:mask_1_graphics_65,x:31.6115,y:-43.6165}).wait(1).to({graphics:mask_1_graphics_66,x:33.519,y:-43.6288}).wait(1).to({graphics:mask_1_graphics_67,x:35.5555,y:-43.6357}).wait(1).to({graphics:mask_1_graphics_68,x:37.7013,y:-43.6361}).wait(1).to({graphics:mask_1_graphics_69,x:39.932,y:-43.6291}).wait(1).to({graphics:mask_1_graphics_70,x:42.2182,y:-43.6145}).wait(1).to({graphics:mask_1_graphics_71,x:44.5276,y:-43.5924}).wait(1).to({graphics:mask_1_graphics_72,x:46.8257,y:-43.5635}).wait(1).to({graphics:mask_1_graphics_73,x:49.0787,y:-43.5288}).wait(1).to({graphics:mask_1_graphics_74,x:51.2547,y:-43.4898}).wait(1).to({graphics:mask_1_graphics_75,x:53.3261,y:-43.4481}).wait(1).to({graphics:mask_1_graphics_76,x:55.2709,y:-43.4054}).wait(1).to({graphics:mask_1_graphics_77,x:57.0731,y:-43.3633}).wait(1).to({graphics:mask_1_graphics_78,x:58.7229,y:-43.3231}).wait(1).to({graphics:mask_1_graphics_79,x:60.2162,y:-43.2857}).wait(1).to({graphics:mask_1_graphics_80,x:61.5537,y:-43.2518}).wait(1).to({graphics:mask_1_graphics_81,x:62.7395,y:-43.2218}).wait(1).to({graphics:mask_1_graphics_82,x:63.7807,y:-43.1957}).wait(1).to({graphics:mask_1_graphics_83,x:64.6858,y:-43.1735}).wait(1).to({graphics:mask_1_graphics_84,x:65.464,y:-43.1549}).wait(1).to({graphics:mask_1_graphics_85,x:66.1251,y:-43.1395}).wait(1).to({graphics:mask_1_graphics_86,x:66.6782,y:-43.1271}).wait(1).to({graphics:mask_1_graphics_87,x:67.1322,y:-43.1173}).wait(1).to({graphics:mask_1_graphics_88,x:67.4951,y:-43.1097}).wait(1).to({graphics:mask_1_graphics_89,x:67.7741,y:-43.104}).wait(1).to({graphics:mask_1_graphics_90,x:67.9755,y:-43.1}).wait(1).to({graphics:mask_1_graphics_91,x:68.7957,y:-42.5427}).wait(29));

	// Layer_11
	this.instance_1 = new lib.squiggle_line();
	this.instance_1.setTransform(83.6,-47.75,0.8531,0.8531,-0.0072,0,0,127.2,31);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(58).to({_off:false},0).wait(62));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_19 = new cjs.Graphics().p("AhZiJIgog2Igng3QgPgXABgBIAXgQQABgBARAWIAoA2IAnA3QAPAXgBABIgXARIAAAAQgCAAgQgWg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AhZiJIgog2Igng3QgPgXABgBIAXgRQABAAARAVIApA3IAmA3QAQAXgCABIgXARIAAAAQgCAAgQgWg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AhZiIIgog2Igng4QgPgXABgBIAYgRQABgBARAWIApA2IAmA3QAPAYgBABIgYARIAAAAQgCAAgQgVg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AhZiIIgog2Igng3QgPgXABgBIAZgSQACgBARAWIAoA2IAmA3QAQAXgCABIgZASIAAAAQgCAAgQgVg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AhZiHIgog2Igng4QgPgXABgBIAbgTQACgBARAWIAoA2IAmA3QAPAYgBABIgbATIAAAAQgCAAgQgVg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AhZiGQgSgWgXggIgmg4QgPgXACgBIAdgVQABgBARAWQASAWAXAgQAXAgAPAXQAPAYgCABIgdAVIAAAAQgCAAgQgVg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AhaiFQgRgWgXggQgWgggQgYQgPgXACgBIAggXQABgBASAWQARAWAXAgQAXAgAPAXQAPAYgCABIgfAXIgBAAQgCAAgRgVg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AhaiEQgRgWgXggQgXgggPgYQgOgXABgBIAkgZQABgBASAVQARAWAXAgQAXAgAPAYQAPAYgCABIgjAZIgBAAQgCAAgRgVg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AhaiCQgRgWgXggQgXgggPgYQgOgYACgBIAngcQACgBARAVQASAWAXAhQAXAgAOAXQAPAYgCACIgnAbIAAAAQgDAAgRgUg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AhaiAQgRgWgXggQgXgggOgYQgPgYACgCIAsgeQACgCASAWQASAVAWAhQAXAgAOAXQAPAZgCABIgsAfIAAAAQgDAAgRgUg");
	var mask_2_graphics_29 = new cjs.Graphics().p("Ahah+QgSgWgWggQgXgggOgZQgOgXACgCIAxgiQACgCASAVQASAWAXAgQAWAgAOAYQAPAZgDABIgxAjIAAAAQgDAAgRgUg");
	var mask_2_graphics_30 = new cjs.Graphics().p("Ahah8QgSgVgXghQgWgggOgYQgOgYADgCIA2gnQADgCASAWQASAVAXAhQAWAgAOAYQAOAZgDABIg2AnIgBAAQgEAAgQgUg");
	var mask_2_graphics_31 = new cjs.Graphics().p("Ahah6QgSgVgXggQgWgggOgZQgOgYAEgCIA9grQADgCASAVQASAWAXAgQAWAgAOAZQANAYgDACIg9ArIgBAAQgEAAgQgUg");
	var mask_2_graphics_32 = new cjs.Graphics().p("Ahah3QgTgVgWggQgWghgOgYQgNgZADgCIBFgwQAEgCASAVQASAVAXAhQAWAgANAZQANAZgDACIhFAvIAAABQgFAAgQgUg");
	var mask_2_graphics_33 = new cjs.Graphics().p("Ahbh0QgSgVgWggQgXghgNgZQgMgYADgDIBNg1QAEgCATAVQASAVAWAhQAXAgANAZQAMAZgEADIhMA0IgBAAQgFAAgRgTg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AhbhwQgSgVgXghQgWgggMgaQgNgZAFgDIBVg6QAFgDASAVQATAVAWAhQAWAgAMAZQANAagFADIhVA6IgBAAQgFAAgRgSg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AhbhtQgTgUgWghQgWghgMgZQgMgaAFgDIBfhAQAFgDATAUQATAVAWAhQAVAhAMAZQAMAagEADIhfBAIgCABQgFAAgRgTg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AhbhpQgTgUgWghQgWghgMgaQgLgZAFgEIBqhHQAGgDATAUQATAVAWAhQAVAhAMAZQALAagFAEIhpBGIgCABQgHAAgQgSg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AhbhlQgUgUgWghQgVghgLgaQgLgaAGgEIB2hNQAGgEATAUQAUAVAVAgQAVAhALAaQALAagGAEIh1BOIgCABQgHAAgQgSg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AhchgQgTgUgWghQgVghgLgbQgKgaAGgEICDhWQAHgEATAUQAUAVAVAhQAWAhAKAaQALAbgHAEIiCBVIgDABQgHAAgRgRg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AhchbQgUgUgVghQgWgigKgbQgJgaAHgFICQhdQAIgFATAUQAVAVAVAhQAVAhAKAbQAKAagHAFIiQBdIgDABQgIAAgRgQg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AhchWQgUgUgWghQgVgigJgbQgJgbAIgFICfhlQAHgFAVATQAVAUAVAiQAVAhAJAbQAJAbgIAFIieBlIgEABQgIAAgRgPg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AhchRQgVgUgVghQgVgigIgbQgJgcAJgFICuhuQAJgGAVAUQAWAUAUAhQAVAiAJAbQAIAcgJAFIiuBuIgEABQgJAAgRgPg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AhchMQgWgTgUgiQgVghgIgcQgHgcAKgGIC/h3QAKgGAVAUQAWATAVAiQAUAhAIAcQAIAcgKAGIjAB3QgCABgDAAQgJAAgRgPg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AhchGQgWgTgUgiQgVgigHgcQgHgdALgGIDSiAQAKgGAWATQAXATAUAiQAUAiAHAcQAHAcgLAHIjRCAQgDABgDAAQgKAAgRgOg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AhkhAQgWgTgUgiQgVgigGgdQgFgdALgHIDliJQAMgHAXATQAWATAVAiQAUAiAFAdQAHAdgMAHIjlCJQgDACgEAAQgLAAgRgOg");
	var mask_2_graphics_45 = new cjs.Graphics().p("Ahwg6QgXgTgUgiQgUgigFgeQgFgdANgHID5iTQANgHAXASQAYATATAiQAUAiAFAdQAFAegMAHIj6CTQgEACgEAAQgMAAgQgNg");
	var mask_2_graphics_46 = new cjs.Graphics().p("Ah+g0QgXgTgUgiQgUgigEgeQgEgeAOgIIEQicQAOgIAYASQAYATATAiQAUAiAEAeQAEAegOAIIkQCcQgEADgFAAQgMAAgRgNg");
	var mask_2_graphics_47 = new cjs.Graphics().p("AiMguQgYgSgTgjQgUgigDgeQgDgfAPgIIEoimQAPgJAYASQAYATAUAiQATAiADAeQADAfgPAIIknCnQgFACgGAAQgMAAgRgMg");
	var mask_2_graphics_48 = new cjs.Graphics().p("AibgoQgZgSgTgiQgTgjgCgfQgBgfAQgJIFAiwQAQgJAZASQAZASATAjQATAiACAfQACAfgRAJIk/CwQgGADgGAAQgNAAgRgMg");
	var mask_2_graphics_49 = new cjs.Graphics().p("AiqgiQgagSgSgiQgTgjgBgfQAAgfARgKIFZi6QASgJAZARQAaASATAjQASAjABAfQABAfgSAKIlZC6QgGADgHAAQgNAAgRgMg");
	var mask_2_graphics_50 = new cjs.Graphics().p("Ai6gcQgbgRgSgjQgSgjAAggQABggATgJIFzjEQATgKAaASQAbASASAiQATAjgBAgQAAAggTAKIl0DDQgHAEgHAAQgOAAgRgMg");
	var mask_2_graphics_51 = new cjs.Graphics().p("AjLgWQgbgRgSgjQgSgjACghQACggAUgKIGPjNQAUgKAbARQAbASASAjQASAjgCAgQgBAggVALImODMQgIAEgIAAQgPAAgRgLg");
	var mask_2_graphics_52 = new cjs.Graphics().p("AjcgQQgcgRgRgkQgSgjADghQADggAWgLIGqjVQAWgLAcARQAcASARAjQASAjgDAhQgDAggWALImqDVQgIAFgKAAQgPAAgRgLg");
	var mask_2_graphics_53 = new cjs.Graphics().p("AjtgLQgcgRgSgjQgRgjAEgiQAFghAXgLIHGjdQAXgMAdARQAdASARAjQARAjgEAhQgEAigYALInGDdQgJAFgKAAQgQAAgRgLg");
	var mask_2_graphics_54 = new cjs.Graphics().p("Aj+gGQgdgQgRgkQgRgkAFghQAGgiAZgLIHijlQAZgMAdARQAeARAQAkQARAjgGAhQgFAigYAMInjDlQgKAEgLAAQgPAAgSgKg");
	var mask_2_graphics_55 = new cjs.Graphics().p("AkPgBQgegRgQgjQgRgkAHgiQAHgiAagMIH+jsQAagMAeARQAeARARAkQAQAjgHAiQgGAigaAMIn/DrQgKAFgMAAQgQAAgSgJg");
	var mask_2_graphics_56 = new cjs.Graphics().p("AkgACQgegPgQgkQgQgkAHgiQAJgiAbgNIIZjyQAcgMAeAQQAfARARAkQAQAkgJAiQgHAigcANIoZDxQgMAFgMAAQgRAAgSgKg");
	var mask_2_graphics_57 = new cjs.Graphics().p("AkvAGQgggPgQgkQgPgkAJgjQAJgiAdgNIIzj3QAdgNAfAQQAgARAQAkQAQAkgKAjQgJAigdANIozD2QgMAGgNAAQgRAAgSgKg");
	var mask_2_graphics_58 = new cjs.Graphics().p("Ak+AKQgggQgQgkQgPgkAKgjQAKgjAegMIJMj9QAegNAgARQAhAQAPAlQAQAkgLAiQgKAjgeANIpMD8QgNAFgOAAQgRAAgSgJg");
	var mask_2_graphics_59 = new cjs.Graphics().p("AlMANQghgQgPgkQgPgkALgjQALgjAfgNIJjkBQAfgNAhARQAhAQAPAkQAQAlgMAjQgLAjgfANIpjD/QgOAGgOAAQgSAAgSgJg");
	var mask_2_graphics_60 = new cjs.Graphics().p("AlZAWQghgQgPgjQgPglAMgjQAMgjAhgNIJ3kEQAhgNAhAQQAiARAOAkQAPAkgMAjQgMAkggANIp4EDQgPAGgOAAQgSAAgTgKg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_2_graphics_19,x:-18.3064,y:-28.7529}).wait(1).to({graphics:mask_2_graphics_20,x:-18.3039,y:-28.762}).wait(1).to({graphics:mask_2_graphics_21,x:-18.2964,y:-28.7896}).wait(1).to({graphics:mask_2_graphics_22,x:-18.2836,y:-28.8363}).wait(1).to({graphics:mask_2_graphics_23,x:-18.2653,y:-28.9029}).wait(1).to({graphics:mask_2_graphics_24,x:-18.2415,y:-28.9898}).wait(1).to({graphics:mask_2_graphics_25,x:-18.2119,y:-29.0978}).wait(1).to({graphics:mask_2_graphics_26,x:-18.1764,y:-29.2274}).wait(1).to({graphics:mask_2_graphics_27,x:-18.1347,y:-29.3791}).wait(1).to({graphics:mask_2_graphics_28,x:-18.0868,y:-29.5536}).wait(1).to({graphics:mask_2_graphics_29,x:-18.0324,y:-29.7514}).wait(1).to({graphics:mask_2_graphics_30,x:-17.9714,y:-29.9728}).wait(1).to({graphics:mask_2_graphics_31,x:-17.9037,y:-30.2184}).wait(1).to({graphics:mask_2_graphics_32,x:-17.8291,y:-30.4885}).wait(1).to({graphics:mask_2_graphics_33,x:-17.7475,y:-30.7832}).wait(1).to({graphics:mask_2_graphics_34,x:-17.6589,y:-31.1029}).wait(1).to({graphics:mask_2_graphics_35,x:-17.5631,y:-31.4475}).wait(1).to({graphics:mask_2_graphics_36,x:-17.4603,y:-31.8169}).wait(1).to({graphics:mask_2_graphics_37,x:-17.3503,y:-32.2108}).wait(1).to({graphics:mask_2_graphics_38,x:-17.2333,y:-32.6286}).wait(1).to({graphics:mask_2_graphics_39,x:-17.1094,y:-33.0696}).wait(1).to({graphics:mask_2_graphics_40,x:-16.9789,y:-33.5327}).wait(1).to({graphics:mask_2_graphics_41,x:-16.842,y:-34.0165}).wait(1).to({graphics:mask_2_graphics_42,x:-16.6991,y:-34.5192}).wait(1).to({graphics:mask_2_graphics_43,x:-16.5508,y:-35.0386}).wait(1).to({graphics:mask_2_graphics_44,x:-15.6367,y:-35.5718}).wait(1).to({graphics:mask_2_graphics_45,x:-14.2098,y:-36.1156}).wait(1).to({graphics:mask_2_graphics_46,x:-12.6989,y:-36.6661}).wait(1).to({graphics:mask_2_graphics_47,x:-11.1057,y:-37.219}).wait(1).to({graphics:mask_2_graphics_48,x:-9.434,y:-37.7693}).wait(1).to({graphics:mask_2_graphics_49,x:-7.6894,y:-38.3115}).wait(1).to({graphics:mask_2_graphics_50,x:-5.8782,y:-38.8398}).wait(1).to({graphics:mask_2_graphics_51,x:-4.0105,y:-39.3483}).wait(1).to({graphics:mask_2_graphics_52,x:-2.1039,y:-39.831}).wait(1).to({graphics:mask_2_graphics_53,x:-0.1759,y:-40.2825}).wait(1).to({graphics:mask_2_graphics_54,x:1.753,y:-40.6978}).wait(1).to({graphics:mask_2_graphics_55,x:3.6597,y:-41.0732}).wait(1).to({graphics:mask_2_graphics_56,x:5.5197,y:-41.4063}).wait(1).to({graphics:mask_2_graphics_57,x:7.3081,y:-41.6961}).wait(1).to({graphics:mask_2_graphics_58,x:9.0004,y:-41.9431}).wait(1).to({graphics:mask_2_graphics_59,x:10.5743,y:-42.1495}).wait(1).to({graphics:mask_2_graphics_60,x:8.7104,y:-41.5944}).wait(60));

	// Layer_5
	this.instance_2 = new lib.squiggle_line();
	this.instance_2.setTransform(83.6,-47.75,0.8531,0.8531,-0.0072,0,0,127.2,31);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(19).to({_off:false},0).wait(101));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27,-76.4,221.3,76.4);


(lib.letter = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.letter.cache(0,0,110,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.letter = new lib.letter_sub();
	this.letter.name = "letter";
	this.letter.setTransform(51.5,36,1,1,0,0,0,51.5,36);

	this.timeline.addTween(cjs.Tween.get(this.letter).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letter, new cjs.Rectangle(0,0,102.9,72.1), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.gridpiece();
	this.instance.setTransform(223.25,324.65,0.8462,0.8462,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(121.9,324.65,0.8462,0.8462,90,0,0,125.9,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(177.2,369.25,0.8462,0.8462,0,0,0,125.9,52.6);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(177.2,267.75,0.8462,0.8462,0,0,0,125.9,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(70.2,217.7,206.10000000000002,206.10000000000002), null);


(lib.file3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.BudgetMeeting_lg();
	this.instance.setTransform(6.65,8.8,0.7004,0.7004);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(62.1,89.75,0.4698,0.7124,0,0,0,98,101.6);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file3, new cjs.Rectangle(4,4.8,113,160), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_98 = function() {
		this.stop()
		//exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(33).call(this.frame_98).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgYCBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_15 = new cjs.Graphics().p("EgYQBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_16 = new cjs.Graphics().p("EgY5BJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_17 = new cjs.Graphics().p("EgZ9BJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_18 = new cjs.Graphics().p("EgbcBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_19 = new cjs.Graphics().p("EgdXBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_20 = new cjs.Graphics().p("EgfsBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_21 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_22 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_23 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_24 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_25 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_26 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:265.5896,y:471.3031}).wait(1).to({graphics:mask_graphics_15,x:264.2278,y:471.3031}).wait(1).to({graphics:mask_graphics_16,x:260.1424,y:471.3031}).wait(1).to({graphics:mask_graphics_17,x:253.3334,y:471.3031}).wait(1).to({graphics:mask_graphics_18,x:243.8008,y:471.3031}).wait(1).to({graphics:mask_graphics_19,x:231.5445,y:471.3031}).wait(1).to({graphics:mask_graphics_20,x:216.5646,y:471.3031}).wait(1).to({graphics:mask_graphics_21,x:193.4146,y:471.3031}).wait(1).to({graphics:mask_graphics_22,x:168.9021,y:471.3031}).wait(1).to({graphics:mask_graphics_23,x:149.8369,y:471.3031}).wait(1).to({graphics:mask_graphics_24,x:136.2188,y:471.3031}).wait(1).to({graphics:mask_graphics_25,x:128.048,y:471.3031}).wait(1).to({graphics:mask_graphics_26,x:125.3244,y:471.3031}).wait(1).to({graphics:null,x:0,y:0}).wait(72));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-233.95,900.4,3.5247,3.5247,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:19.1},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(74.9,904.15,0.7146,0.7146,0,0,0,485.9,405.6);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(73.85,904.75,0.213,0.213,0,0,0,-39.2,2.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).wait(72));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.5247,scaleY:3.5247,x:73.65,y:904.65},13,cjs.Ease.quadOut).to({x:-122.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(72));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgpBCYZMAAAkwxMBSDAAAMAAAEwxg");
	this.shape.setTransform(74.65,905.65);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(74.65,905.65,0.5365,2.3555,0,0,0,0.1,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-190.6,-72.7,527.8,1953.7);


(lib.calendar_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.calendar.cache(0,0,110,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.calendar = new lib.calendar_sub();
	this.calendar.name = "calendar";
	this.calendar.setTransform(53.7,49.5,1,1,0,0,0,53.7,49.5);

	this.timeline.addTween(cjs.Tween.get(this.calendar).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.calendar_icon, new cjs.Rectangle(0,0,107.5,99), null);


(lib.bang_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bang.cache(-60,-60,120,120,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bang = new lib.bang_sub();
	this.bang.name = "bang";
	this.bang.setTransform(20.5,21,1,1,0,0,0,20.5,21);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_icon, new cjs.Rectangle(-1,-1,43,44), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhnE7QhSgzgWhdQgVhZAshOIAFgIIGKDzIgFAJQgyBKhZAVQgcAHgcAAQg9AAg5gjg");
	var mask_graphics_1 = new cjs.Graphics().p("Ah7EkQhJg/gGhgQgGhbA4hFIAHgHIFdEwIgHAHQg9BChcAGIgRABQhUAAhCg6g");
	var mask_graphics_2 = new cjs.Graphics().p("AAUFcQhfgJg9hKQg9hKAJhgQAJhbBDg6IAIgHIEmFlIgIAHQg9AvhMAAIgZgCg");
	var mask_graphics_3 = new cjs.Graphics().p("AgBFVQhcgYgxhUQgwhTAZhdQAXhXBMgwIAJgFIDoGRIgJAFQgzAbg2AAQgfAAgfgJg");
	var mask_graphics_4 = new cjs.Graphics().p("AgTFJQhYgogihaQgihaAohYQAlhSBTgjIAJgDICkGxIgKAEQgkAMglAAQgwAAgugVg");
	var mask_graphics_5 = new cjs.Graphics().p("AgiE2QhQg1gTheQgThfA1hPQAzhMBWgUIAKgDIBbHHIgKACQgTADgTAAQhDAAg6gog");
	var mask_graphics_6 = new cjs.Graphics().p("AgtEfQhHhCgDhgQgDhgBChFQA9hDBagGIAJgBIAQHQIgKAAQhaAAhBg/g");
	var mask_graphics_7 = new cjs.Graphics().p("AA9FcQhXgPg4hJQg7hMANhgQAMheBNg7QBHg3BaAIIAJABIg8HMIgKgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AAGFWQhUgdgrhRQgthUAchcQAbhcBVgtQBQgrBXAXIAJADIiHG7IgJgDg");
	var mask_graphics_9 = new cjs.Graphics().p("AguFOQhPgrgdhWQgfhbArhXQAqhVBcgfQBVgdBSAlIAJAEIjNGfIgJgEg");
	var mask_graphics_10 = new cjs.Graphics().p("AheFDQhHg3gPhaQgPhfA4hOQA4hNBegQQBagPBLAyIAIAGIkOF4IgIgGg");
	var mask_graphics_11 = new cjs.Graphics().p("AiIE2Qg9hCAAhbQAAhgBEhDQBEhEBfAAQBcAABBA9IAHAHIlHFHIgHgHg");
	var mask_graphics_12 = new cjs.Graphics().p("AisEnQgxhLAPhaQAQhfBOg3QBOg4BeAQQBaAPA3BGIAGAIIl5EOIgGgIg");
	var mask_graphics_13 = new cjs.Graphics().p("AjIEWQgkhSAdhWQAghbBWgqQBWgqBaAfQBXAdAqBPIAFAIImgDNIgFgJg");
	var mask_graphics_14 = new cjs.Graphics().p("AjbEEQgXhXAshQQAthVBcgbQBcgbBUAtQBRAqAdBWIADAJIm8CGIgDgKg");
	var mask_graphics_15 = new cjs.Graphics().p("AjlDyQgJhaA4hIQA7hMBfgMQBfgMBMA6QBIA4APBYIABAKInLA7IgBgJg");
	var mask_graphics_16 = new cjs.Graphics().p("AjnDhIAAgKQAHhaBDg+QBGhBBfADQBgADBCBHQA+BCAABaIAAAKg");
	var mask_graphics_17 = new cjs.Graphics().p("AjlCoIACgJQAVhYBMgyQBQg0BeATQBeASA1BQQAzBMgPBZIgCAJg");
	var mask_graphics_18 = new cjs.Graphics().p("AjgByIADgJQAkhTBTglQBYgnBZAiQBaAiAnBXQAlBUgdBVIgDAJg");
	var mask_graphics_19 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_20 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_21 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_22 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_23 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_24 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_25 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_26 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_27 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_28 = new cjs.Graphics().p("AjYA9IAFgIQAwhLBZgYQBcgYBTAwQBTAwAYBdQAYBYgrBPIgEAJg");
	var mask_graphics_29 = new cjs.Graphics().p("AjYA/IAFgIQAvhLBYgYQBcgaBUAwQBTAvAZBdQAYBYgqBQIgEAIg");
	var mask_graphics_30 = new cjs.Graphics().p("AjaBGIAFgIQAuhMBYgaQBbgcBUAuQBVAtAbBcQAaBYgoBQIgEAJg");
	var mask_graphics_31 = new cjs.Graphics().p("AjcBUIAEgJQArhOBWgeQBagfBXAqQBWApAfBbQAeBWgkBSIgEAJg");
	var mask_graphics_32 = new cjs.Graphics().p("AjfBpIAEgJQAlhSBUgiQBZgmBYAlQBZAjAlBZQAkBUgfBUIgEAJg");
	var mask_graphics_33 = new cjs.Graphics().p("AjjCJIADgKQAdhVBRgqQBUguBbAcQBdAaAtBVQAsBRgXBWIgDAKg");
	var mask_graphics_34 = new cjs.Graphics().p("AjmC1IACgKQARhYBKg1QBOg3BeAPQBfAOA5BOQA1BKgLBZIgBAKg");
	var mask_graphics_35 = new cjs.Graphics().p("AjnDlQAChaA/hCQBDhFBhgBQBfgCBFBDQBBBAAFBaIAAAKInPAGIAAgJg");
	var mask_graphics_36 = new cjs.Graphics().p("AjfD/QgShYAvhOQAyhTBdgWQBdgWBSAwQBOAwAZBWIACAKInCBuIgCgJg");
	var mask_graphics_37 = new cjs.Graphics().p("Ai+EeQgqhQAZhYQAZhdBUgvQBTgvBcAZQBYAYAvBMIAFAIImSDmIgFgIg");
	var mask_graphics_38 = new cjs.Graphics().p("Ah7E8QhBg+gEhcQgGhgBBhGQBAhIBfgFQBcgFBEA6IAIAGIk2FZIgHgHg");
	var mask_graphics_39 = new cjs.Graphics().p("AgbFTQhSgmgihVQgkhZAlhYQAmhYBZgkQBUgiBUAgIAJADIi0GrIgJgEg");
	var mask_graphics_40 = new cjs.Graphics().p("ABLFfQhYgMg6hGQg+hJAJhgQAIhgBKg9QBFg6BaAEIAJABIgpHOIgKgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AgkE3QhPg3gRhfQgRheA2hOQA0hMBXgTIAJgCIBUHIIgJACQgSACgRAAQhFAAg8gpg");
	var mask_graphics_42 = new cjs.Graphics().p("AgOFPQhagkgmhYQgmhZAkhZQAihUBRgmIAJgEIC2GpIgJAEQgpAQgpAAQgrAAgqgRg");
	var mask_graphics_43 = new cjs.Graphics().p("AAHFbQhegTg1hQQg2hQATheQAShZBJg0IAIgGIEBGBIgIAGQg4Aig+AAQgYAAgYgFg");
	var mask_graphics_44 = new cjs.Graphics().p("AAbFfQhfgFhBhHQhBhHAFhgQAFhcBAg9IAHgHIE3FXIgHAHQhAA1hTABIgNgBg");
	var mask_graphics_45 = new cjs.Graphics().p("Ah7EmQhJg/gGhgQgGhbA4hFIAHgIIFdExIgHAHQg9BChcAGIgRAAQhUAAhCg5g");
	var mask_graphics_46 = new cjs.Graphics().p("AhxEzQhOg4gPhfQgPhaAyhKIAGgIIF3EPIgFAIQg4BHhaAOQgUADgUAAQhGAAg+gsg");
	var mask_graphics_47 = new cjs.Graphics().p("AhnE7QhSgzgWhdQgVhZAshOIAFgIIGKDzIgFAJQgyBKhZAVQgcAHgcAAQg9AAg5gjg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:12.8886,y:35.0135}).wait(1).to({graphics:mask_graphics_1,x:11.85,y:34.9757}).wait(1).to({graphics:mask_graphics_2,x:10.5571,y:34.9681}).wait(1).to({graphics:mask_graphics_3,x:9.0507,y:34.9862}).wait(1).to({graphics:mask_graphics_4,x:7.404,y:34.9965}).wait(1).to({graphics:mask_graphics_5,x:5.6685,y:34.9908}).wait(1).to({graphics:mask_graphics_6,x:3.8735,y:34.9859}).wait(1).to({graphics:mask_graphics_7,x:5.057,y:34.8962}).wait(1).to({graphics:mask_graphics_8,x:6.9575,y:34.5193}).wait(1).to({graphics:mask_graphics_9,x:8.7775,y:33.8489}).wait(1).to({graphics:mask_graphics_10,x:10.4708,y:32.903}).wait(1).to({graphics:mask_graphics_11,x:11.9694,y:31.7071}).wait(1).to({graphics:mask_graphics_12,x:13.203,y:30.2933}).wait(1).to({graphics:mask_graphics_13,x:14.168,y:28.6995}).wait(1).to({graphics:mask_graphics_14,x:14.8615,y:26.9686}).wait(1).to({graphics:mask_graphics_15,x:15.2626,y:25.147}).wait(1).to({graphics:mask_graphics_16,x:15.3562,y:24.1113}).wait(1).to({graphics:mask_graphics_17,x:15.5637,y:26.0338}).wait(1).to({graphics:mask_graphics_18,x:16.0615,y:27.8909}).wait(1).to({graphics:mask_graphics_19,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_20,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_21,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_22,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_23,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_24,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_25,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_26,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_27,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_28,x:16.4594,y:29.4958}).wait(1).to({graphics:mask_graphics_29,x:16.4187,y:29.423}).wait(1).to({graphics:mask_graphics_30,x:16.29,y:29.185}).wait(1).to({graphics:mask_graphics_31,x:16.0684,y:28.7418}).wait(1).to({graphics:mask_graphics_32,x:15.7605,y:28.0369}).wait(1).to({graphics:mask_graphics_33,x:15.3961,y:26.9925}).wait(1).to({graphics:mask_graphics_34,x:15.0522,y:25.5106}).wait(1).to({graphics:mask_graphics_35,x:14.9045,y:23.8319}).wait(1).to({graphics:mask_graphics_36,x:14.5743,y:26.4221}).wait(1).to({graphics:mask_graphics_37,x:13.4175,y:29.408}).wait(1).to({graphics:mask_graphics_38,x:11.1638,y:32.2724}).wait(1).to({graphics:mask_graphics_39,x:7.9194,y:34.3138}).wait(1).to({graphics:mask_graphics_40,x:4.4698,y:35.1643}).wait(1).to({graphics:mask_graphics_41,x:5.5239,y:35.215}).wait(1).to({graphics:mask_graphics_42,x:7.9933,y:35.212}).wait(1).to({graphics:mask_graphics_43,x:9.8611,y:35.1805}).wait(1).to({graphics:mask_graphics_44,x:11.2124,y:35.1503}).wait(1).to({graphics:mask_graphics_45,x:12.1516,y:35.1439}).wait(1).to({graphics:mask_graphics_46,x:12.7963,y:35.1498}).wait(1).to({graphics:mask_graphics_47,x:12.8886,y:35.0135}).wait(1));

	// Layer_1
	this.instance = new lib.bang_icon();
	this.instance.setTransform(19.2,39.25,0.5596,0.5596,0,0,0,20.6,21.2);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(7.1,26.9,24.1,24.6);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.arc.cache(0,0,55,35,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.arc = new lib.arc_c();
	this.arc.name = "arc";
	this.arc.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.arc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AuZcOQiWglhQiGQhQiFAliYQAniXCGhQMAo5gYdQCFhQCWAmQCYAmBQCFQBQCGgnCXQglCWiFBQMgo5AYfQhaA2hjAAQgwAAgxgNg");
	var mask_graphics_54 = new cjs.Graphics().p("AudcRQiWgmhQiFQhQiGAliXQAniXCFhQMAo5gYeQCGhQCWAmQCYAmBQCGQBQCFgnCXQglCXiGBQMgo4AYeQhbA2hjAAQgvAAgxgMg");
	var mask_graphics_55 = new cjs.Graphics().p("AutcbQiWgmhQiFQhQiGAliXQAniXCFhQMAo5gYeQCGhQCWAmQCYAmBQCGQBQCFgnCXQglCWiGBQMgo5AYfQhaA2hjAAQgvAAgxgMg");
	var mask_graphics_56 = new cjs.Graphics().p("AvQcvQiWglhQiGQhPiFAkiYQAniXCGhQMAo5gYdQCFhQCWAlQCZAnBQCFQBPCGgnCWQglCXiFBQMgo5AYfQhaA2hjAAQgvAAgygNg");
	var mask_graphics_57 = new cjs.Graphics().p("AwMdTQiWglhQiGQhQiFAliYQAniXCGhQMAo5gYdQCFhQCWAmQCZAmBPCFQBQCGgnCWQglCXiFBQMgo5AYfQhaA2hjAAQgwAAgxgNg");
	var mask_graphics_58 = new cjs.Graphics().p("AxdeEQiWglhQiGQhQiFAliYQAniXCFhQMAo5gYdQCGhQCWAlQCYAnBQCFQBQCGgnCVQglCYiGBQMgo4AYfQhbA2hjAAQgvAAgxgNg");
	var mask_graphics_59 = new cjs.Graphics().p("AysezQiWglhQiGQhQiFAliYQAniXCGhQMAo5gYdQCFhQCWAlQCZAnBQCFQBPCGgnCWQglCXiFBQMgo5AYfQhaA2hjAAQgvAAgygNg");
	var mask_graphics_60 = new cjs.Graphics().p("AzqfZQiWgmhQiFQhQiGAliXQAniXCFhQMAo5gYeQCGhQCWAmQCYAmBQCGQBQCEgnCXQglCYiFBPMgo5AYfQhbA2hiAAQgwAAgxgMg");
	var mask_graphics_61 = new cjs.Graphics().p("A0af1QiWglhQiGQhQiFAliYQAniXCGhPMAo5gYeQCFhQCWAmQCYAmBQCFQBQCFgnCXQglCXiFBQMgo5AYfQhaA2hjAAQgwAAgxgNg");
	var mask_graphics_62 = new cjs.Graphics().p("EgU/AgLQiWglhQiGQhPiFAkiYQAniXCGhPMAo5gYeQCFhQCWAmQCZAmBQCFQBPCFgnCXQglCXiFBQMgo5AYfQhaA2hjAAQgvAAgygNg");
	var mask_graphics_63 = new cjs.Graphics().p("EgVbAgdQiWgmhQiGQhQiFAliXQAniXCFhQMAo5gYeQCGhQCWAmQCYAmBQCGQBQCEgnCXQglCXiGBQMgo4AYfQhbA2hjAAQgvAAgxgMg");
	var mask_graphics_64 = new cjs.Graphics().p("EgVyAgqQiWgmhQiFQhQiFAliYQAniXCGhQMAo5gYeQCFhPCWAlQCZAnBPCFQBQCEgnCXQglCYiFBQMgo5AYfQhaA2hjAAQgvAAgygNg");
	var mask_graphics_65 = new cjs.Graphics().p("EgV4Ag1QiWgmhQiFQhQiGAliXQAniXCFhQMAo5gYeQCGhQCWAmQCYAmBQCGQBQCEgnCXQglCYiFBPMgo5AYfQhbA2hiAAQgwAAgxgMg");
	var mask_graphics_66 = new cjs.Graphics().p("EgV4Ag9QiWgmhQiFQhQiGAliXQAniXCFhQMAo5gYeQCGhPCWAlQCYAmBQCGQBQCEgnCXQglCYiFBQMgo5AYeQhbA2hiAAQgwAAgxgMg");
	var mask_graphics_67 = new cjs.Graphics().p("EgV4AhEQiWgmhQiGQhQiFAliYQAniXCFhPMAo5gYeQCGhQCWAmQCYAmBQCFQBQCFgnCXQglCXiFBQMgo5AYfQhbA2hiAAQgwAAgxgMg");
	var mask_graphics_68 = new cjs.Graphics().p("EgV4AhIQiWglhQiGQhQiFAliYQAniXCFhQMAo5gYdQCGhQCWAlQCYAnBQCFQBQCFgnCXQglCXiFBQMgo5AYfQhbA2hiAAQgwAAgxgNg");
	var mask_graphics_69 = new cjs.Graphics().p("EgV4AhMQiWgmhQiFQhQiGAliXQAniXCFhQMAo5gYeQCGhQCWAmQCYAmBQCFQBQCFgnCXQglCYiFBPMgo5AYfQhbA2hiAAQgwAAgxgMg");
	var mask_graphics_70 = new cjs.Graphics().p("EgV4AhOQiWgmhQiFQhQiFAliYQAniXCFhQMAo5gYeQCGhPCWAlQCYAnBQCEQBQCFgnCXQglCYiFBQMgo5AYfQhbA2hiAAQgwAAgxgNg");
	var mask_graphics_71 = new cjs.Graphics().p("EgV4AhPQiWglhQiGQhQiFAliYQAniXCFhPMAo5gYeQCGhQCWAmQCYAmBQCEQBQCGgnCXQglCXiFBQMgo5AYfQhbA2hiAAQgwAAgxgNg");
	var mask_graphics_72 = new cjs.Graphics().p("EgV4AhPQiWgmhQiFQhQiFAliYQAniXCGhQMAo4gYeQCGhPCWAlQCYAnBQCEQBQCFgnCXQglCYiFBQMgo5AYfQhbA2hiAAQgwAAgxgNg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:216.4968,y:181.8793}).wait(1).to({graphics:mask_graphics_54,x:216.0581,y:182.1432}).wait(1).to({graphics:mask_graphics_55,x:214.4471,y:183.1098}).wait(1).to({graphics:mask_graphics_56,x:211.0165,y:185.1682}).wait(1).to({graphics:mask_graphics_57,x:204.9989,y:188.7787}).wait(1).to({graphics:mask_graphics_58,x:196.8618,y:193.6609}).wait(1).to({graphics:mask_graphics_59,x:189.013,y:198.3701}).wait(1).to({graphics:mask_graphics_60,x:182.7665,y:202.118}).wait(1).to({graphics:mask_graphics_61,x:177.9929,y:204.9821}).wait(1).to({graphics:mask_graphics_62,x:174.3187,y:207.1866}).wait(1).to({graphics:mask_graphics_63,x:171.4553,y:208.9046}).wait(1).to({graphics:mask_graphics_64,x:169.2057,y:210.2544}).wait(1).to({graphics:mask_graphics_65,x:166.2975,y:211.3166}).wait(1).to({graphics:mask_graphics_66,x:163.5254,y:212.1483}).wait(1).to({graphics:mask_graphics_67,x:161.3844,y:212.7906}).wait(1).to({graphics:mask_graphics_68,x:159.7718,y:213.2743}).wait(1).to({graphics:mask_graphics_69,x:158.6088,y:213.6232}).wait(1).to({graphics:mask_graphics_70,x:157.8337,y:213.8558}).wait(1).to({graphics:mask_graphics_71,x:157.3972,y:213.9867}).wait(1).to({graphics:mask_graphics_72,x:157.1716,y:213.9544}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(77.35,360.25,1.266,1.266,-8.8955,0,0,42.2,17.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AW9bQMgvQgFgQiagShih7Qhgh5ASiaQASiaB6hiQB6hgCbASMAvQAFhQCaASBgB5QBiB7gSCaQgSCah7BgQhmBSh+AAQgYAAgYgDg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AW9bTMgvQgFgQibgShhh7Qhgh5ASibQASiaB5hiQB7hfCbASMAvQAFgQCbASBfB5QBiB7gSCaQgSCah7BgQhmBTh+AAQgYAAgYgDg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AW9bZMgvQgFgQibgShhh7Qhgh5ASiaQASiaB5hiQB7hfCbASMAvQAFgQCbASBfB5QBiB7gSCaQgSCah7BgQhmBSh+AAQgYAAgYgDg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AW9bkMgvQgFgQibgShhh7Qhgh5ASiaQASibB5hhQB7hgCbASMAvQAFgQCbASBfB5QBiB7gSCbQgSCah7BfQhmBTh+AAQgYAAgYgDg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AW9bxMgvQgFgQibgShhh7Qhgh5ASiaQASiaB5hiQB7hgCbASMAvQAFgQCbASBfB6QBiB7gSCaQgSCah7BgQhmBSh+AAQgYAAgYgDg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AW9cAMgvQgFgQibgShhh7Qhgh5ASiaQASibB5hhQB7hgCbASMAvQAFgQCbASBfB5QBiB7gSCaQgSCbh7BfQhmBTh+AAQgYAAgYgDg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AW9cPMgvQgFgQibgShhh7Qhgh6ASiaQASiaB5hiQB7hfCbASMAvQAFgQCbASBfB5QBiB7gSCaQgSCah7BgQhmBSh+AAQgYAAgYgCg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AW9ccMgvQgFgQibgShhh7Qhgh5ASibQASiaB5hhQB7hgCbASMAvQAFgQCbASBfB5QBiB7gSCaQgSCbh7BfQhmBTh+AAQgYAAgYgDg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AW9cmMgvQgFgQibgShhh7Qhgh5ASiaQASiaB5hiQB7hfCbARMAvQAFhQCbASBfB5QBiB7gSCaQgSCah7BgQhmBSh+AAQgYAAgYgDg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AW9ctMgvQgFgQibgShhh7Qhgh5ASiaQASiaB5hiQB7hgCbASMAvQAFgQCbASBfB5QBiB7gSCbQgSCah7BgQhmBSh+AAQgYAAgYgDg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AW9cwMgvQgFgQiagShih7Qhgh6ASiaQASiaB6hiQB6hfCbASMAvQAFgQCbASBfB5QBiB7gSCaQgSCah7BgQhmBSh+AAQgYAAgYgCg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-188.2652,y:174.719}).wait(1).to({graphics:mask_1_graphics_45,x:-184.2046,y:174.9525}).wait(1).to({graphics:mask_1_graphics_46,x:-172.4203,y:175.6283}).wait(1).to({graphics:mask_1_graphics_47,x:-154.0657,y:176.6808}).wait(1).to({graphics:mask_1_graphics_48,x:-130.9376,y:178.0071}).wait(1).to({graphics:mask_1_graphics_49,x:-105.3,y:179.4772}).wait(1).to({graphics:mask_1_graphics_50,x:-79.6623,y:180.9474}).wait(1).to({graphics:mask_1_graphics_51,x:-56.5342,y:182.2737}).wait(1).to({graphics:mask_1_graphics_52,x:-38.1797,y:183.3262}).wait(1).to({graphics:mask_1_graphics_53,x:-26.3953,y:184.0019}).wait(1).to({graphics:mask_1_graphics_54,x:-22.1652,y:184.244}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(51.95,321.75,1.266,1.266,-8.8955,0,0,57,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AwtVmQiQg4g/iOQg/iOA3iSQA5iRCOg/MArjgTSQCOg/CQA4QCTA4A/COQA+CPg5CQQg3CRiOA/MgriATTQhLAhhMAAQhEAAhGgag");
	var mask_2_graphics_39 = new cjs.Graphics().p("AxUV3QiQg3g/iOQg/iPA3iRQA5iRCOg/MArigTSQCOg/CRA3QCSA5A/COQA/COg5CRQg3CRiOA/MgrjATTQhLAhhMAAQhEAAhFgbg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AzDWoQiQg3g/iOQg/iOA3iSQA5iRCOg/MArjgTSQCOg/CQA3QCSA5A/COQA/COg5CRQg3CRiOA/MgriATTQhLAhhMAAQhFAAhFgbg");
	var mask_2_graphics_41 = new cjs.Graphics().p("A1jXvQiQg3g/iOQg/iOA3iSQA5iRCOg/MArjgTSQCOg/CQA4QCTA4A/COQA/COg6CQQg3CSiOA/MgriATTQhLAhhMAAQhEAAhGgbg");
	var mask_2_graphics_42 = new cjs.Graphics().p("A35Y+QiQg3g/iOQg/iPA3iRQA5iRCOg/MArjgTSQCOg/CQA3QCTA5A/COQA/CNg6CRQg3CSiOA/MgriATTQhLAhhMAAQhEAAhGgbg");
	var mask_2_graphics_43 = new cjs.Graphics().p("A35aFQiQg3g/iOQg/iOA3iSQA5iRCOg/MArjgTSQCOg/CQA3QCTA5A/COQA/CNg6CRQg3CSiOA/MgriATTQhLAhhMAAQhEAAhGgbg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A35a3QiQg4g/iOQg/iOA3iSQA5iRCOg/MArjgTSQCOg/CQA4QCTA4A/COQA/CNg6CRQg3CSiOA/MgriATTQhLAhhMAAQhEAAhGgag");
	var mask_2_graphics_45 = new cjs.Graphics().p("A35bIQiQg4g/iOQg/iOA3iSQA5iRCOg/MArjgTSQCOg/CQA4QCTA4A/COQA/COg6CQQg3CSiOA/MgriATTQhLAhhMAAQhEAAhGgag");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:223.051,y:140.8461}).wait(1).to({graphics:mask_2_graphics_39,x:219.1039,y:142.601}).wait(1).to({graphics:mask_2_graphics_40,x:208.0424,y:147.5171}).wait(1).to({graphics:mask_2_graphics_41,x:192.0582,y:154.6212}).wait(1).to({graphics:mask_2_graphics_42,x:171.5795,y:162.5062}).wait(1).to({graphics:mask_2_graphics_43,x:139.611,y:169.6103}).wait(1).to({graphics:mask_2_graphics_44,x:117.4881,y:174.5264}).wait(1).to({graphics:mask_2_graphics_45,x:109.7487,y:176.2461}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(49.4,280.25,1.266,1.266,-8.8955,0,0,60.1,16.6);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AXIVbMgvigC2QibgJhph1Qhmh0AJibQAJibB0hpQB1hmCcAJMAviAC2QCbAJBnB0QBoB1gJCbQgJCch2BmQhqBgiMAAIgZgBg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AXbVdMgvigC2QibgJhoh2QhnhzAJibQAJicB0hoQB2hmCbAJMAviAC2QCbAJBnBzQBoB2gJCbQgJCbh2BnQhqBgiMAAIgZgBg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AXbViMgvigC2QibgJhoh2QhnhzAJicQAJibB0hoQB2hmCbAJMAviAC1QCbAKBnBzQBoB2gJCbQgJCbh2BnQhqBfiMAAIgZAAg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AXbVpMgvigC2QibgJhoh1Qhnh0AJibQAJibB0hpQB2hmCbAJMAviAC2QCbAJBnB0QBoB1gJCbQgJCch2BmQhqBgiMAAIgZgBg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AXbVyMgvigC1QibgKhoh1Qhnh0AJibQAJibB0hoQB2hnCbAJMAviAC2QCbAJBnB0QBoB1gJCcQgJCbh2BmQhqBgiMAAIgZgBg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AXbV8MgvigC2QibgJhoh1Qhnh0AJibQAJibB0hpQB2hmCbAJMAviAC2QCbAJBnB0QBoB1gJCbQgJCbh2BnQhqBgiMAAIgZgBg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AXbWFMgvigC2QibgJhoh1Qhnh0AJibQAJibB0hpQB2hmCbAJMAviAC2QCbAJBnB0QBoB1gJCbQgJCbh2BnQhqBgiMAAIgZgBg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AXbWMMgvigC1QibgJhoh2Qhnh0AJibQAJibB0hoQB2hnCbAKMAviAC1QCbAKBnBzQBoB2gJCbQgJCbh2BmQhqBgiMAAIgZgBg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AXbWRMgvigC1QibgKhoh1Qhnh0AJibQAJibB0hoQB2hnCbAJMAviAC2QCbAJBnB0QBoB1gJCcQgJCbh2BmQhqBgiMAAIgZgBg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AXbWSMgvigC2QibgJhoh1Qhnh0AJibQAJibB0hpQB2hmCbAJMAviAC2QCbAJBnB0QBoB1gJCbQgJCch2BmQhqBgiMAAIgZgBg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-191.6611,y:137.1878}).wait(1).to({graphics:mask_3_graphics_32,x:-188.5244,y:137.3565}).wait(1).to({graphics:mask_3_graphics_33,x:-174.0152,y:137.8418}).wait(1).to({graphics:mask_3_graphics_34,x:-151.7858,y:138.5855}).wait(1).to({graphics:mask_3_graphics_35,x:-124.5174,y:139.4977}).wait(1).to({graphics:mask_3_graphics_36,x:-95.499,y:140.4684}).wait(1).to({graphics:mask_3_graphics_37,x:-68.2306,y:141.3806}).wait(1).to({graphics:mask_3_graphics_38,x:-46.0012,y:142.1243}).wait(1).to({graphics:mask_3_graphics_39,x:-31.492,y:142.6097}).wait(1).to({graphics:mask_3_graphics_40,x:-26.6134,y:142.6878}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(44.3,243.25,1.266,1.266,-8.8955,0,0,59.3,13.3);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("AysQbQiPhCg2iUQg3iUBCiQQBDiPCUg3MAtYgQqQCUg2COBCQCRBDA2CUQA2CUhDCPQhBCQiUA2MgtYAQqQhCAZhCAAQhRAAhPglg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AyxQcQiOhCg2iUQg3iUBBiQQBEiPCUg2MAtXgQqQCUg2CPBBQCQBDA3CUQA2CUhDCPQhCCQiUA3MgtXAQqQhCAYhCAAQhRAAhQglg");
	var mask_4_graphics_21 = new cjs.Graphics().p("Ay/QiQiOhCg3iUQg2iUBBiQQBEiPCUg3MAtWgQpQCUg3COBCQCRBDA2CUQA3CUhECPQhBCQiUA2MgtWAQqQhDAZhBAAQhRAAhQglg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AzbQsQiOhCg2iUQg3iUBCiQQBDiOCUg3MAtVgQpQCUg2COBCQCRBCA2CUQA2CUhDCPQhBCQiUA2MgtVAQqQhDAYhBAAQhRAAhQglg");
	var mask_4_graphics_23 = new cjs.Graphics().p("A0IQ9QiOhBg3iUQg2iUBBiQQBEiPCUg2MAtSgQoQCUg3COBCQCRBDA2CUQA2CUhDCOQhBCQiUA2MgtTAQpQhCAYhCAAQhQAAhQglg");
	var mask_4_graphics_24 = new cjs.Graphics().p("A1ORYQiOhCg2iUQg2iTBBiQQBDiPCUg2MAtPgQnQCUg2COBCQCQBCA2CUQA2CUhDCOQhBCPiUA2MgtPAQoQhCAYhBAAQhRAAhQgkg");
	var mask_4_graphics_25 = new cjs.Graphics().p("A2wR9QiOhCg2iTQg2iTBBiQQBDiOCTg2MAtKgQlQCUg2CNBBQCQBDA2CTQA3CUhECOQhBCOiTA2MgtKAQmQhCAZhCAAQhQAAhPglg");
	var mask_4_graphics_26 = new cjs.Graphics().p("A4sSsQiOhCg2iTQg2iTBBiPQBDiOCTg2MAtEgQjQCTg2COBCQCPBCA2CTQA2CThDCOQhBCOiTA3MgtDAQjQhCAYhCAAQhQAAhPgkg");
	var mask_4_graphics_27 = new cjs.Graphics().p("A4+TcQiNhCg2iSQg2iTBBiPQBDiOCTg1MAs9gQhQCTg2CNBCQCPBCA2CTQA2CShDCNQhBCPiSA2Mgs+AQhQhBAYhCAAQhQAAhPgkg");
	var mask_4_graphics_28 = new cjs.Graphics().p("A47UEQiMhBg2iTQg2iSBAiPQBDiNCTg2MAs4gQeQCSg2CNBBQCPBCA2CTQA2CShDCNQhBCOiSA2Mgs4AQfQhCAYhBAAQhQAAhPgkg");
	var mask_4_graphics_29 = new cjs.Graphics().p("A44UjQiNhCg2iSQg1iSBAiOQBDiNCSg2MAs0gQdQCSg2CNBBQCOBCA2CTQA2CShDCMQhACOiTA2MgszAQeQhCAYhBAAQhQAAhOgkg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A43U5QiMhBg2iSQg1iSBAiOQBDiNCSg2MAswgQcQCSg1CNBBQCPBCA1CSQA2CShDCMQhACOiSA2MgsxAQcQhBAYhBAAQhQAAhPgkg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A41VJQiNhBg1iSQg2iSBAiOQBDiNCSg1MAsugQbQCSg2CNBBQCOBCA2CSQA2CShDCMQhACOiSA1MgsvAQcQhBAYhBAAQhQAAhOgkg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A41VUQiMhBg2iSQg1iSBAiOQBDiNCSg1MAstgQbQCSg1CMBBQCOBCA2CSQA2CShDCLQhACOiSA2MgstAQbQhCAYhAAAQhQAAhPgkg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:225.0374,y:108.7516}).wait(1).to({graphics:mask_4_graphics_20,x:224.5886,y:108.9121}).wait(1).to({graphics:mask_4_graphics_21,x:223.0686,y:109.4535}).wait(1).to({graphics:mask_4_graphics_22,x:220.1383,y:110.497}).wait(1).to({graphics:mask_4_graphics_23,x:215.3107,y:112.2163}).wait(1).to({graphics:mask_4_graphics_24,x:207.9399,y:114.8413}).wait(1).to({graphics:mask_4_graphics_25,x:197.4585,y:118.5741}).wait(1).to({graphics:mask_4_graphics_26,x:184.3352,y:123.2478}).wait(1).to({graphics:mask_4_graphics_27,x:160.0524,y:128.0199}).wait(1).to({graphics:mask_4_graphics_28,x:137.8094,y:132.0419}).wait(1).to({graphics:mask_4_graphics_29,x:120.8881,y:135.1016}).wait(1).to({graphics:mask_4_graphics_30,x:108.5089,y:137.34}).wait(1).to({graphics:mask_4_graphics_31,x:99.6378,y:138.944}).wait(1).to({graphics:mask_4_graphics_32,x:93.6101,y:140.0329}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(43.8,209.55,1.266,1.266,-8.8955,0,0,63,13.3);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.3,137,266.7,322.5);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.pptLogo = new lib.OutlookLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(56.9,30.45,1,1,0,0,0,53,32.5);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(221.35,379.85,1,1,0,0,0,84.2,49.1);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	//  files 1 - 2
	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(183.75,189.25,1,1,0,0,0,73.5,54.2);

	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(172.95,105.8,1,1,0,0,0,80.5,77);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file1},{t:this.file2}]}).wait(1));

	// file 3
	this.file3 = new lib.file3();
	this.file3.name = "file3";
	this.file3.setTransform(229.4,235.2,1.7,1.7,0,0,0,50.1,70.2);

	this.timeline.addTween(cjs.Tween.get(this.file3).wait(1));

	// file 4
	this.file4 = new lib.file4();
	this.file4.name = "file4";
	this.file4.setTransform(234.7,93.2,1.7,1.7,0,0,0,100.5,74.8);

	this.timeline.addTween(cjs.Tween.get(this.file4).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(225.85,146,1,1,0,0,0,187.5,125.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.ExcelUI_CU();
	this.instance.setTransform(38.35,20.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-12.1,-26.1,425.5,627.5), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhfJGQgHAAgHgGIgGgHIg9hZQgKgRgOgJQgPgKgXgCIo3AAIAAv/IZLAAIAASLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:210.875,y:79.025}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(167.5,172.9,1,1,0,0,0,167.5,172.9);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.1,-26,425.5,627.3);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-18,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.9,143.7,27.8), null);


(lib.Icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_64 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(64).call(this.frame_64).wait(1));

	// calendar
	this.calendar = new lib.calendar_icon();
	this.calendar.name = "calendar";
	this.calendar.setTransform(66.6,51.15,0.023,0.9156,0,0,0,54.4,49.6);
	this.calendar._off = true;

	this.timeline.addTween(cjs.Tween.get(this.calendar).wait(49).to({_off:false},0).to({regX:53.8,scaleX:0.9156,x:66.55},7,cjs.Ease.quadOut).wait(9));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("ApxG8IImpdIEYAAIAAJdg");
	var mask_graphics_2 = new cjs.Graphics().p("ApvG8IImpdIEXAAIAAJdg");
	var mask_graphics_3 = new cjs.Graphics().p("ApsG8IImpdIEYAAIAAJdg");
	var mask_graphics_4 = new cjs.Graphics().p("AplG8IImpdIEXAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("ApcG8IImpdIEYAAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("ApQG8IImpdIEXAAIAAJdg");
	var mask_graphics_7 = new cjs.Graphics().p("ApCG8IImpdIEXAAIAAJdg");
	var mask_graphics_8 = new cjs.Graphics().p("AoxG8IImpdIEXAAIAAJdg");
	var mask_graphics_9 = new cjs.Graphics().p("AoeG8IIlpdIEZAAIAAJdg");
	var mask_graphics_10 = new cjs.Graphics().p("AoIG7IIlpcIEZAAIAAJcg");
	var mask_graphics_11 = new cjs.Graphics().p("AnvG7IIlpcIEYAAIAAJcg");
	var mask_graphics_12 = new cjs.Graphics().p("AnUG7IIlpcIEZAAIAAJcg");
	var mask_graphics_13 = new cjs.Graphics().p("Am2G7IIlpcIEYAAIAAJcg");
	var mask_graphics_14 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_15 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_16 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_17 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_18 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_19 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_20 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_21 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_22 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_23 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_24 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_25 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_26 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_27 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_28 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_29 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_30 = new cjs.Graphics().p("AmeG7IIlpdIEYAAIAAJdg");
	var mask_graphics_31 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_32 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_33 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_34 = new cjs.Graphics().p("AlsG7IIlpcIEZAAIAAJcg");
	var mask_graphics_35 = new cjs.Graphics().p("Ak+G8IIlpdIEZAAIAAJdg");
	var mask_graphics_36 = new cjs.Graphics().p("AkaG8IIlpdIEYAAIAAJdg");
	var mask_graphics_37 = new cjs.Graphics().p("AkBG8IIlpdIEZAAIAAJdg");
	var mask_graphics_38 = new cjs.Graphics().p("AjxG8IIlpdIEYAAIAAJdg");
	var mask_graphics_39 = new cjs.Graphics().p("AjsG8IIlpdIEYAAIAAJdg");
	var mask_graphics_42 = new cjs.Graphics().p("AjsG8IIlpdIEYAAIAAJdg");
	var mask_graphics_49 = new cjs.Graphics().p("AjsG8IIlpdIEYAAIAAJdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-62.575,y:44.3755}).wait(1).to({graphics:mask_graphics_2,x:-62.4454,y:44.3751}).wait(1).to({graphics:mask_graphics_3,x:-62.0566,y:44.3741}).wait(1).to({graphics:mask_graphics_4,x:-61.4086,y:44.3723}).wait(1).to({graphics:mask_graphics_5,x:-60.5014,y:44.3699}).wait(1).to({graphics:mask_graphics_6,x:-59.335,y:44.3668}).wait(1).to({graphics:mask_graphics_7,x:-57.9094,y:44.363}).wait(1).to({graphics:mask_graphics_8,x:-56.2246,y:44.3584}).wait(1).to({graphics:mask_graphics_9,x:-54.2806,y:44.3532}).wait(1).to({graphics:mask_graphics_10,x:-52.0773,y:44.3473}).wait(1).to({graphics:mask_graphics_11,x:-49.6149,y:44.3407}).wait(1).to({graphics:mask_graphics_12,x:-46.8933,y:44.3334}).wait(1).to({graphics:mask_graphics_13,x:-43.9125,y:44.3255}).wait(1).to({graphics:mask_graphics_14,x:-40.3377,y:44.3175}).wait(1).to({graphics:mask_graphics_15,x:-34.8945,y:44.3102}).wait(1).to({graphics:mask_graphics_16,x:-29.9697,y:44.3036}).wait(1).to({graphics:mask_graphics_17,x:-25.5633,y:44.2977}).wait(1).to({graphics:mask_graphics_18,x:-21.6752,y:44.2925}).wait(1).to({graphics:mask_graphics_19,x:-18.3056,y:44.288}).wait(1).to({graphics:mask_graphics_20,x:-15.4544,y:44.2841}).wait(1).to({graphics:mask_graphics_21,x:-13.1216,y:44.281}).wait(1).to({graphics:mask_graphics_22,x:-11.3072,y:44.2786}).wait(1).to({graphics:mask_graphics_23,x:-10.0112,y:44.2769}).wait(1).to({graphics:mask_graphics_24,x:-9.2336,y:44.2758}).wait(1).to({graphics:mask_graphics_25,x:-8.9744,y:44.2755}).wait(1).to({graphics:mask_graphics_26,x:-8.9744,y:44.2755}).wait(1).to({graphics:mask_graphics_27,x:-7.9554,y:44.2766}).wait(1).to({graphics:mask_graphics_28,x:-4.8986,y:44.2802}).wait(1).to({graphics:mask_graphics_29,x:0.196,y:44.2861}).wait(1).to({graphics:mask_graphics_30,x:7.3286,y:44.2944}).wait(1).to({graphics:mask_graphics_31,x:16.499,y:44.305}).wait(1).to({graphics:mask_graphics_32,x:27.7073,y:44.3181}).wait(1).to({graphics:mask_graphics_33,x:40.444,y:44.3329}).wait(1).to({graphics:mask_graphics_34,x:46.5889,y:44.3459}).wait(1).to({graphics:mask_graphics_35,x:51.1742,y:44.3565}).wait(1).to({graphics:mask_graphics_36,x:54.7404,y:44.3648}).wait(1).to({graphics:mask_graphics_37,x:57.2878,y:44.3707}).wait(1).to({graphics:mask_graphics_38,x:58.8162,y:44.3743}).wait(1).to({graphics:mask_graphics_39,x:59.3256,y:44.3755}).wait(3).to({graphics:mask_graphics_42,x:59.3256,y:44.3755}).wait(7).to({graphics:mask_graphics_49,x:59.3256,y:44.3755}).wait(16));

	// lines
	this.instance = new lib.mail_lines();
	this.instance.setTransform(-4.6,60.75,1,1,0,0,0,34.5,25);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(25).to({alpha:0},13).wait(26));

	// letter
	this.letter = new lib.letter();
	this.letter.name = "letter";
	this.letter.setTransform(12.4,52.7,1,1,0,0,0,51.5,36);

	this.timeline.addTween(cjs.Tween.get(this.letter).to({x:87.1},24,cjs.Ease.quadInOut).wait(9).to({scaleX:1.0387,scaleY:1.361,x:70.65,y:59.7},9,cjs.Ease.quadIn).to({regX:51.1,scaleX:0.0313,x:70.6},7,cjs.Ease.quadIn).to({_off:true},1).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45,-394.4,224.7,842.7);


(lib.cta_arrow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// Layer_5 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgaDEQgJgJgHgQQgGgOgCgMQgCgNAFgCIA+gfQAEgCAIAJQAJAJAGAPQAHAPACAMQACANgEACIg/AeIgBABQgFAAgGgHg");
	var mask_graphics_24 = new cjs.Graphics().p("AgaDEQgJgJgHgQQgGgOgCgMQgCgNAFgCIA+gfQAEgCAIAJQAJAJAGAPQAHAPACAMQACANgEACIg/AeIgBABQgFAAgGgHg");
	var mask_graphics_25 = new cjs.Graphics().p("AglDEQgJgJgHgPQgHgPgBgMQgBgNAGgDIBPgnQAGgCAJAIQAJAJAHAPQAHAPABAMQABANgGADIhPAmIgDABQgFAAgHgGg");
	var mask_graphics_26 = new cjs.Graphics().p("AgvDEQgKgIgHgQQgHgOAAgNQAAgOAHgDIBfguQAHgDAKAIQAKAIAHAPQAHAPAAANQAAANgHADIhfAuIgFABQgFAAgHgFg");
	var mask_graphics_27 = new cjs.Graphics().p("Ag5DEQgKgIgIgPQgGgPAAgNQABgOAIgEIBvg1QAIgEALAIQAKAIAHAPQAHAPAAANQgBAOgIADIhvA2IgFABQgGAAgIgFg");
	var mask_graphics_28 = new cjs.Graphics().p("AhBDEQgMgIgHgPQgHgPACgNQABgOAJgFIB9g7QAJgEALAHQAMAHAHAPQAHAPgCAOQgBAOgJAEIh9A8QgDABgEAAQgGAAgHgEg");
	var mask_graphics_29 = new cjs.Graphics().p("AhJDEQgMgHgIgQQgGgOACgPQABgOALgEICJhCQAKgFAMAHQANAHAGAPQAHAPgCAOQgBAPgLAEIiJBCQgEACgEAAQgHAAgHgEg");
	var mask_graphics_30 = new cjs.Graphics().p("AhRDDQgMgGgIgQQgGgOACgPQADgOALgFICVhHQALgFANAGQAMAHAHAPQAHAPgCAPQgDAOgLAFIiVBHQgFACgFAAQgGAAgIgEg");
	var mask_graphics_31 = new cjs.Graphics().p("AhXDDQgOgGgHgPQgHgPAEgPQADgOAMgGICghMQALgFANAGQAOAHAHAPQAHAPgEAOQgDAPgLAFIigBMQgGADgFAAQgHAAgHgEg");
	var mask_graphics_32 = new cjs.Graphics().p("AhdDDQgOgGgHgPQgHgPAEgPQADgPANgGICphQQAMgGAOAHQAOAGAHAPQAHAPgEAPQgDAPgMAFIiqBRQgGADgGAAQgHAAgHgEg");
	var mask_graphics_33 = new cjs.Graphics().p("AhiDDQgPgGgHgPQgHgPAEgPQAEgPAOgGICyhUQAMgGAOAGQAPAGAHAPQAHAPgEAPQgEAPgNAGIiyBUQgHADgGAAQgHAAgHgDg");
	var mask_graphics_34 = new cjs.Graphics().p("AhnDDQgPgGgHgPQgHgPAFgPQAEgPAOgHIC5hXQANgGAPAFQAPAGAHAPQAHAPgFAPQgEAQgOAGIi5BYQgHADgHAAQgHAAgHgDg");
	var mask_graphics_35 = new cjs.Graphics().p("AhrDDQgPgGgHgPQgHgOAFgQQAFgPAOgHIC/hbQAOgGAPAGQAPAGAHAOQAHAPgFAQQgFAPgOAHIi/BaQgHAEgIAAQgHAAgHgDg");
	var mask_graphics_36 = new cjs.Graphics().p("AhuDDQgPgFgHgQQgHgOAFgQQAFgPAOgHIDFhdQAOgHAPAGQAPAFAHAPQAHAPgFAQQgFAPgOAHIjEBdQgIAEgIAAQgHAAgHgDg");
	var mask_graphics_37 = new cjs.Graphics().p("AhwDDQgQgFgHgQQgHgOAFgQQAFgQAQgHIDIheQAOgHAPAGQAQAFAHAPQAHAPgFAQQgFAPgPAHIjIBfQgIAEgJAAQgGAAgHgDg");
	var mask_graphics_38 = new cjs.Graphics().p("AhyDDQgQgFgHgQQgHgOAGgQQAFgQAPgHIDLhgQAOgHAQAGQAQAFAHAPQAHAPgGAQQgFAQgPAGIjLBhQgIADgIAAQgHAAgHgCg");
	var mask_graphics_39 = new cjs.Graphics().p("AhzDDQgQgFgHgQQgHgOAGgQQAFgQAPgHIDNhhQAOgGAQAFQAQAFAHAPQAHAPgGAQQgFAQgPAHIjMBgQgJAEgJAAQgGAAgHgCg");
	var mask_graphics_40 = new cjs.Graphics().p("AhzDEQgQgGgHgPQgHgPAFgPQAGgQAPgHIDNhiQAPgGAPAFQAQAFAHAPQAHAPgFAQQgGAQgPAHIjNBhQgIAEgJAAQgHAAgGgCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-4.8696,y:20.2831}).wait(24).to({graphics:mask_graphics_24,x:-4.8696,y:20.2831}).wait(1).to({graphics:mask_graphics_25,x:-3.4611,y:20.2081}).wait(1).to({graphics:mask_graphics_26,x:-2.1432,y:20.1404}).wait(1).to({graphics:mask_graphics_27,x:-0.9162,y:20.0794}).wait(1).to({graphics:mask_graphics_28,x:0.2198,y:20.0246}).wait(1).to({graphics:mask_graphics_29,x:1.2648,y:19.9756}).wait(1).to({graphics:mask_graphics_30,x:2.2189,y:19.9319}).wait(1).to({graphics:mask_graphics_31,x:3.0822,y:19.8932}).wait(1).to({graphics:mask_graphics_32,x:3.8546,y:19.8594}).wait(1).to({graphics:mask_graphics_33,x:4.5361,y:19.83}).wait(1).to({graphics:mask_graphics_34,x:5.1267,y:19.805}).wait(1).to({graphics:mask_graphics_35,x:5.6265,y:19.7841}).wait(1).to({graphics:mask_graphics_36,x:6.0354,y:19.7672}).wait(1).to({graphics:mask_graphics_37,x:6.3535,y:19.7542}).wait(1).to({graphics:mask_graphics_38,x:6.5807,y:19.7449}).wait(1).to({graphics:mask_graphics_39,x:6.717,y:19.7394}).wait(1).to({graphics:mask_graphics_40,x:6.6475,y:19.7919}).wait(5));

	// Layer_2 copy
	this.instance = new lib.pointer();
	this.instance.setTransform(7.2,22.85,1,1,0,0,0,12.8,10.7);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45));

	// Layer_5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgUA7QgNgBgBgFIgNhEQgBgFAKgFQALgGARgDQAOgDANABQAMACABAFIAOBDQABAFgLAGQgKAGgRADQgKACgJAAIgIgBg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AgUA7QgNgBgBgFIgNhEQgBgFAKgFQALgGARgDQAOgDANABQAMACABAFIAOBDQABAFgLAGQgKAGgRADQgKACgJAAIgIgBg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AgPBOQgMgDgCgHIgThhQgBgHAKgHQAKgIARgDQAPgDANADQAMADACAHIATBhQABAHgKAIQgLAHgQADIgPABIgNgBg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AgMBfQgNgEgBgJIgYh8QgCgJAKgJQAKgJARgDQAPgDANAFQANAEABAJIAYB8QACAJgKAIQgKAJgQADIgNABQgIAAgIgCg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AgJBuQgNgFgCgLIgdiUQgCgLAKgKQAKgKARgDQAQgDAMAGQANAFACALIAdCUQACAKgKAKQgKAKgQADIgMABQgIAAgJgDg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AgGB7QgOgGgCgMIghipQgCgNAKgLQAKgLAQgDQAQgDAMAHQAOAGACANIAhCpQACAMgKALQgKALgQADIgKABQgKAAgIgFg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AgECHQgOgIgCgNIgki7QgDgOAKgMQAJgMARgDQAQgDAMAHQAOAHACAPIAkC7QADANgKAMQgJAMgRADIgJABQgLAAgIgFg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AgCCQQgOgIgDgOIgnjLQgCgPAJgNQAJgNARgDQAQgDAMAJQAOAIADAPIAnDLQACAOgJANQgJANgRADIgIAAQgLAAgJgGg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AgBCYQgOgIgDgQIgpjXQgDgQAKgOQAJgNAQgDQAQgDANAJQAOAIADARIApDXQADAPgKAOQgJANgQADIgIABQgMAAgJgHg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AAACfQgOgKgDgQIgrjhQgDgRAJgOQAJgOARgDQAQgDANAJQAOAKADARIArDhQADAQgJAOQgKAOgQADIgIABQgLAAgKgHg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AAACjQgNgKgDgRIgsjoQgDgRAJgOQAJgOAQgEQAQgCANAJQAOAKADARIAsDoQADARgJAOQgJAPgQADIgHAAQgMAAgLgHg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AAACmQgNgKgDgRIgtjtQgDgRAJgPQAJgOARgDQAQgDANAJQAOAKADASIAtDsQADARgJAPQgJAOgQADIgIABQgMAAgLgHg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AABCmQgNgKgEgRIgtjuQgDgRAJgPQAJgOARgEQAPgDAOAKQANAKAEASIAtDuQADARgJAOQgJAPgQADIgIABQgMAAgKgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-4.8405,y:5.9812}).wait(16).to({graphics:mask_1_graphics_16,x:-4.8405,y:5.9812}).wait(1).to({graphics:mask_1_graphics_17,x:-4.685,y:7.9487}).wait(1).to({graphics:mask_1_graphics_18,x:-4.3495,y:9.7385}).wait(1).to({graphics:mask_1_graphics_19,x:-4.0494,y:11.344}).wait(1).to({graphics:mask_1_graphics_20,x:-3.7846,y:12.7625}).wait(1).to({graphics:mask_1_graphics_21,x:-3.5552,y:13.993}).wait(1).to({graphics:mask_1_graphics_22,x:-3.361,y:15.0346}).wait(1).to({graphics:mask_1_graphics_23,x:-3.2022,y:15.8872}).wait(1).to({graphics:mask_1_graphics_24,x:-3.0787,y:16.5505}).wait(1).to({graphics:mask_1_graphics_25,x:-2.9904,y:17.0243}).wait(1).to({graphics:mask_1_graphics_26,x:-2.9375,y:17.3087}).wait(1).to({graphics:mask_1_graphics_27,x:-2.9787,y:17.3818}).wait(18));

	// Layer_2
	this.instance_1 = new lib.pointer();
	this.instance_1.setTransform(7.2,22.85,1,1,0,0,0,12.8,10.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(45));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhyGQIAAsfIAOAAQFFAADmDmQDmDlAAFHIAAANg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AhyGQIAAsfIAOAAQFFAADmDmQDmDlAAFHIAAANg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AhymPIAOAAQFFAADmDmQDmDlAAFGIAAANIsfABg");
	var mask_2_graphics_3 = new cjs.Graphics().p("Ah0mOIAOgBQFFAADnDlQDmDlABFGIAAANIsfACg");
	var mask_2_graphics_4 = new cjs.Graphics().p("Ah4mOIANgBQFFgCDpDkQDnDjADFGIAAANIsfAHg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AiBmOIAOAAQFFgHDrDiQDpDhAGFGIABANIsfAPg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AiOmOIANAAQFFgMDvDdQDtDdAMFGIAAANIsdAdg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AijmMIAOgBQFEgVD0DXQD0DXAUFFIABANIsdAyg");
	var mask_2_graphics_8 = new cjs.Graphics().p("Ai/mKIANgBQFEggD8DNQD7DPAgFDIACANIsbBPg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AjkmEIAOgCQFBgxEGDBQEFDCAwFCIACANIsVB2g");
	var mask_2_graphics_10 = new cjs.Graphics().p("AkQl7IANgCQE+hFERCwQERCxBEE+IADANIsNCog");
	var mask_2_graphics_11 = new cjs.Graphics().p("AlFlqIANgEQE4hdEdCaQEeCbBdE3IAEANIr9Dkg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AmBlQIANgFQEuh7EqB+QEsB/B7EtIAEAMIrjEtg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AnAkpIAMgGQEeidE3BbQE4BcCdEdIAGALIq8GAg");
	var mask_2_graphics_14 = new cjs.Graphics().p("An+juIALgIQEGjCFAAvQFCAxDCEGIAIALIqCHag");
	var mask_2_graphics_15 = new cjs.Graphics().p("AoyifIAJgJQDmjoFEgCQFFgBDoDmIAJAJIozI3g");
	var mask_2_graphics_16 = new cjs.Graphics().p("AovhMIAJgLQDEkFFCguQFBgtEEDEIALAIInhJ+g");
	var mask_2_graphics_17 = new cjs.Graphics().p("AoiAAIAHgLQClkaE6hSQE6hSEaClIALAHImUKwg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AoSBDIAGgMQCJknExhwQExhwEoCJIAMAGIlRLUg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AoBB9IAFgNQBykwEniJQEniHExByIANAEIkXLtg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AnxCsIAEgNQBek3EeibQEeiZE4BeIANAEIjnL9g");
	var mask_2_graphics_21 = new cjs.Graphics().p("AnjDRIADgNQBPk7EWioQEWioE9BPIAMADIjBMHg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AnYDuIADgOQBDk+EQiyQEPixE/BDIANACIikMOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AnQECIADgNQA6lAELi5QELi5FBA7IANACIiQMRg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AnKEQIACgNQA1lBEIi+QEHi+FCA1IANACIiCMUg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AnGEYIACgNQAxlBEGjBQEFjAFDAxIAMACIh5MVg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AnFEdIACgOQAwlBEFjDQEEjBFDAvIANACIh1MWg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AnEEeIACgNQAvlCEEjDQEEjCFDAvIANACIhzMWg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AnEEeIACgNQAvlCEEjDQEEjCFDAvIANACIhzMWg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:68.4756,y:4.1506}).wait(1).to({graphics:mask_2_graphics_1,x:68.4756,y:4.1506}).wait(1).to({graphics:mask_2_graphics_2,x:68.4756,y:4.1505}).wait(1).to({graphics:mask_2_graphics_3,x:68.4755,y:4.1498}).wait(1).to({graphics:mask_2_graphics_4,x:68.4744,y:4.1478}).wait(1).to({graphics:mask_2_graphics_5,x:68.4687,y:4.1434}).wait(1).to({graphics:mask_2_graphics_6,x:68.4494,y:4.1348}).wait(1).to({graphics:mask_2_graphics_7,x:68.3974,y:4.1196}).wait(1).to({graphics:mask_2_graphics_8,x:68.2787,y:4.0949}).wait(1).to({graphics:mask_2_graphics_9,x:68.0375,y:4.0591}).wait(1).to({graphics:mask_2_graphics_10,x:67.5894,y:4.0139}).wait(1).to({graphics:mask_2_graphics_11,x:66.8139,y:3.9679}).wait(1).to({graphics:mask_2_graphics_12,x:65.548,y:3.9379}).wait(1).to({graphics:mask_2_graphics_13,x:63.5836,y:3.9464}).wait(1).to({graphics:mask_2_graphics_14,x:60.6703,y:4.0056}).wait(1).to({graphics:mask_2_graphics_15,x:56.6974,y:4.0699}).wait(1).to({graphics:mask_2_graphics_16,x:49.2578,y:4.0817}).wait(1).to({graphics:mask_2_graphics_17,x:42.9182,y:4.0852}).wait(1).to({graphics:mask_2_graphics_18,x:37.7756,y:4.1121}).wait(1).to({graphics:mask_2_graphics_19,x:33.6975,y:4.1575}).wait(1).to({graphics:mask_2_graphics_20,x:30.5363,y:4.2091}).wait(1).to({graphics:mask_2_graphics_21,x:28.1473,y:4.2573}).wait(1).to({graphics:mask_2_graphics_22,x:26.398,y:4.2971}).wait(1).to({graphics:mask_2_graphics_23,x:25.1703,y:4.3268}).wait(1).to({graphics:mask_2_graphics_24,x:24.3598,y:4.3471}).wait(1).to({graphics:mask_2_graphics_25,x:23.8733,y:4.3594}).wait(1).to({graphics:mask_2_graphics_26,x:23.6249,y:4.3658}).wait(1).to({graphics:mask_2_graphics_27,x:23.5336,y:4.3681}).wait(1).to({graphics:mask_2_graphics_28,x:23.5283,y:4.3196}).wait(17));

	// Layer_1
	this.instance_2 = new lib.arc();
	this.instance_2.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.6,0,60,33.5);


(lib.Anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(201.85,133.45,0.8792,0.8792,-102.8469,0,0,14.6,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(211.45,126.75,0.8792,0.8792,-133.8467,0,0,14.7,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(216.6,116.95,0.8792,0.8792,-173.8511,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(141.85,49.95,0.9054,0.9054,86.0029,0,0,15,0);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(131.3,54.1,0.9054,0.9054,55.0039,0,0,15,-0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(125.55,62.95,0.9054,0.9054,14.9995,0,0,15.1,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(-61,176.95);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	// ODIcon
	this.ODIcon = new lib.Icon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(135.3,123.45,0.7188,0.7188,0,0,0,17.9,98.5);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Anim, new cjs.Rectangle(94.3,35,136.7,112.6), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(143.2,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(76.35,570.15,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(81.6,569.95,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// CTA_Arrow
	this.CTA_Arrow = new lib.cta_arrow_1();
	this.CTA_Arrow.name = "CTA_Arrow";
	this.CTA_Arrow.setTransform(134.75,528.6,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.CTA_Arrow).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(82.55,330.2,1,1,0,0,0,168.3,176.5);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(130.5,239.8,1,1,0,0,0,3.5,39.7);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.Anim();
	this.anim.name = "anim";
	this.anim.setTransform(299.5,372.7,1,1,0,0,0,205.2,143.5);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(185.75,77.45,1.4753,1.4753,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,155,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-97.8,-1.4,505.40000000000003,756.4), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							/*popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15*/
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		//mc.logo.visible = false;
		mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut});
				this.tl1.from(exportRoot,{duration:0.1, onStart:function(){ mc.anim.line1.play();}}, "<.3");			
		
				this.tl1.to(mc.anim,{duration:1.5, x: "-=175", ease:Power3.easeInOut}, "+=1");
				this.tl1.to(mc.grid,{duration:1.5, x: "-=285", ease:Power3.easeInOut}, "<");
		
				this.tl1.to([exportRoot.intro1, exportRoot.intro2],{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<");
		
				//icon
				this.tl1.from(mc.anim.ODIcon,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut, onStart:function(){mc.anim.ODIcon.play(),mc.anim.ODIcon.play();}}, "<+1");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">+.7");
		
				//chart transition
				//this.tl1.to([mc.ui, mc.anim],{duration:.6, y:"+=70", ease:Power2.easeInOut}, ">");
				this.tl1.to(mc.anim,{duration:1.2, scaleX: 2, scaleY: 2, alpha: 0, ease:Power4.easeInOut}, ">");		
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, alpha: 0, ease:Power4.easeInOut}, "<.1");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=0", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
				
				this.tl1.from(mc.ui.ui.file1,{duration:.6, x:"-=60", y:"-=50", scaleX:.4, scaleY:.4, ease:Power4.easeInOut}, ">+.1");
				//this.tl1.from(mc.ui.ui.file1.fileShadow,{duration:.6, x:"-=10", y:"-=10", alpha:0, ease:Power4.easeInOut}, "<");
				
				this.tl1.from(mc.ui.ui.file2,{duration:.6, x:"+=12", y:"-=35", scaleX:.4, scaleY:.4, ease:Power4.easeInOut}, ">-.4");
				//this.tl1.from(mc.ui.ui.file2.fileShadow,{duration:.6, x:"+=12", y:"-=17", alpha:0, ease:Power4.easeInOut}, "<");
				
			
				this.tl1.to([mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.1, alpha:0}, ">");
				this.tl1.to(mc.anim, {duration:.1, y:"-=70"}, "<");
		
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=23", y:"-=28", scaleX: .355, scaleY: .355, ease:Power3.easeInOut}, ">+.6");
		
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=100", y:"-=100", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.4");
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
				
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"+=0", y:"+=0", scaleX:.28, scaleY:.28, ease:Power3.easeIn}, ">-1");
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
				this.tl1.to(mc.ui.ui.file2,{duration:.7, x:"-=0", y:"-=0", scaleX:.28, scaleY:.28, ease:Power3.easeIn}, "<-.5");
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");				
				
				this.tl1.from(mc.ui.ui.file3,{duration:.6, x:"+=85", y:"-=27", scaleX:.33, scaleY:.33, ease:Power3.easeInOut}, "<-.2");
				this.tl1.from(mc.ui.ui.file3.fileShadow,{duration:.6, x:"+=85", y:"-=27", alpha:0, scaleX:.33, scaleY:.33, ease:Power3.easeInOut}, "<-.2");
				
				this.tl1.from(mc.ui.ui.file4,{duration:.6, x:"-=70", y:"-=90", scaleX:.37, scaleY:.37, alpha:0, ease:Power3.easeInOut}, ">-.4");
		
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"+=15", y:"+=35", scaleX: .41, scaleY: .41, ease:Power3.easeInOut}, ">+1.3");
				//this.tl1.to(mc.grid ,{duration:1.2, x:"+=3", y:"-=2", scaleX: 1, scaleY: 1, ease:Power3.easeInOut}, ">-1.2");
				this.tl1.to(mc.anim,{duration:1.2,  scaleX: 0.2, scaleY: 0.2, alpha:1, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"+=14", y:"+=35", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.to(mc.ui.ui.file4,{duration:1, scaleX:.3, scaleY:.3, y:"-=80", alpha:0, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file3,{duration:1, scaleX:.3, scaleY:.3, y:"-=80", alpha:0, ease:Power4.easeInOut}, "<");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta, 0.8, { scaleX:0, scaleY:0, ease:Power4.easeOut, onStart:function(){mc.CTA_Arrow.play();}}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
			//	this.tl1.from([mc.lineR1,mc.lineR2,mc.lineR3,mc.lineL1,mc.lineL2,mc.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ui.ad1,{duration:2.5, x:"-=270", y:"+=60",  ease:Power3.easeInOut, onStart:function(){mc.ui.ui.ad1.visible=true;}});
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
		
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-17.8,298.6,425.40000000000003,456.4);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622832885811", id:"M365_FY22Q1BTS_USA_160x600_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;