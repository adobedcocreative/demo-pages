(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[585,793,102,105],[395,1128,316,228],[0,502,583,356],[585,502,158,289],[0,1128,393,268],[0,0,750,500],[0,860,400,266]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Group242x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Group60 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.popup1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.PresenterCoach_AndroidMobile_LightUIINSKIN = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pptLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group242x();
	this.instance.setTransform(-12.25,-9.8,1.0793,1.0793);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptLogo, new cjs.Rectangle(-12.2,-9.8,110.10000000000001,113.39999999999999), null);


(lib.pointerc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhKBlQgkgXgRihQgBgJAFgGQAGgGAIgBQAIgBAGAFQAHAFABAIQAFA3ALAtQAKAuAJAJQAMADAtgSQAtgSAxgaQAHgEAIADQAIACAEAHQAEAHgCAIQgDAJgHADQh2BAgzAAQgOAAgJgGg");
	this.shape.setTransform(12.8311,10.6417);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointerc, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.outlines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AsRJJQgYAAgQgRQgHgHgEgIQgGgLAAgOIAAwfQAAgXARgRQAQgRAYAAIYjAAQAYAAAQARQARARAAAXIAACYQAAAXgQARQgRARgYAAQgXAAgRgRQgRgQAAgYIAAhfI2xAAIAAOtIKEAAQAYAAARARQAQAQAAAYQAAAOgGALQgEAIgGAHQgRARgYAAg");
	this.shape.setTransform(113.4263,86.1261);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AxCNPQgYAAgRgRQgQgRAAgXIAA4rQAAgXAQgRQARgRAYAAMAiGAAAQAXAAARARQAQARAAAXIAAOPQABAXgRARQgRARgXAAQgYAAgRgRQgQgRAAgXIAAtWMggUAAAIAAW5IQDAAQAXAAARAQQAQARAAAYQAAAXgQARQgRARgXAAg");
	this.shape_1.setTransform(114.8257,84.675);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlines, new cjs.Rectangle(0,0,229.7,169.4), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Microphone = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiaA5QgXAAgRgQQgRgSAAgXQAAgWARgRQARgRAXAAIE1AAQAXAAARARQARARAAAWQAAAXgRASQgRAQgXAAg");
	this.shape.setTransform(50.4777,126.5529);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgoCCQgQgRAAgYIAAixQAAgYAQgQQASgRAWAAQAYAAAQARQARAQAAAYIAACxQAAAXgRASQgQAQgYAAQgWAAgSgQg");
	this.shape_1.setTransform(50.5027,113.1527);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ai8ERQiDAAhdhcQhchdAAiBIAAiuQAAgYARgRQARgQAXAAQAXAAASAQQAQARAAAYIAACuQAABSA7A7QA7A7BUAAIF5AAQBUAAA7g7QA7g7AAhSIAAiuQAAgYAQgRQARgQAYAAQAYAAAQAQQARARAAAYIAACuQgBCBhbBdQhdBciDAAg");
	this.shape_2.setTransform(50.5027,79.9272);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiFGlQg1AAgmgmQgmglAAg1IAApJQAAg1AmglQAmgmA1AAIELAAQA2AAAlAmQAmAlAAA1IAAJJQAAA1gmAlQgmAmg1AAg");
	this.shape_3.setTransform(50.4777,42.1016);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Microphone, new cjs.Rectangle(0,0,101,132.3), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_110 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(110).call(this.frame_110).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_58 = new cjs.Graphics().p("AE3DcIlegFQgSAAgMgeQgMgdAAgpQABgqANgdQANgdASAAIFeAFQASAAAMAdQAMAeAAApQgBAqgNAcQgNAegSAAIAAAAg");
	var mask_graphics_59 = new cjs.Graphics().p("AE/DcIlqgEQgTgBgMgeQgNgdAAgqQABgpANgeQAOgdASAAIFrAFQASAAANAdQANAegBAqQAAApgOAdQgNAegTAAIAAAAg");
	var mask_graphics_60 = new cjs.Graphics().p("AFIDcIl4gEQgTAAgOgeQgNgeABgqQAAgqAOgdQAOgeATABIF5AEQATAAANAdQANAeAAAqQAAAqgOAdQgOAegTAAIgBAAg");
	var mask_graphics_61 = new cjs.Graphics().p("AFTDcImIgDQgUgBgPgeQgNgeAAgqQAAgqAPgeQAOgeAUABIGJADQAUAAAOAeQAOAfgBAqQAAAqgPAdQgOAegUAAIAAAAg");
	var mask_graphics_62 = new cjs.Graphics().p("AFeDdImagEQgVAAgOgeQgPgfABgqQAAgrAPgeQAPgeAVABIGaADQAVAAAPAeQAOAfAAAqQAAArgQAdQgPAfgUAAIgBAAg");
	var mask_graphics_63 = new cjs.Graphics().p("AFrDdImugDQgVAAgQgfQgPgeAAgrQAAgrAQgfQAQgeAWAAIGuADQAWAAAPAfQAPAeAAArQAAArgQAeQgQAfgVAAIgBAAg");
	var mask_graphics_64 = new cjs.Graphics().p("AF6DdInEgCQgXAAgRgfQgQgfABgrQAAgsAQgeQARgfAXAAIHEADQAXAAAQAeQAQAfAAArQAAAsgRAeQgQAfgXAAIAAAAg");
	var mask_graphics_65 = new cjs.Graphics().p("AGJDdIncgBQgYAAgRggQgRgfAAgrQAAgsARgfQASgfAYAAIHcABQAYABARAeQASAgAAArQgBAsgRAfQgRAfgYAAIgBAAg");
	var mask_graphics_66 = new cjs.Graphics().p("AGbDdIn3AAQgaAAgSggQgSgfAAgsQAAgtASgfQATgfAZAAIH3AAQAaAAASAfQASAgAAAsQAAAtgSAfQgSAfgaAAIAAAAg");
	var mask_graphics_67 = new cjs.Graphics().p("AiVC+QgTggAAgtQAAgsATghQAUgfAbAAIIUgBQAbAAATAgQATAgAAAtQAAAsgTAgQgTAggbAAIoUABQgbAAgUggg");
	var mask_graphics_68 = new cjs.Graphics().p("AiiC+QgVggAAgtQAAguAUggQAUggAdAAII0gCQAdAAAUAgQAVAgAAAtQAAAugVAgQgUAggcAAIo0ACIAAAAQgdAAgUggg");
	var mask_graphics_69 = new cjs.Graphics().p("AixC+QgWggAAguQgBguAWghQAVggAfgBIJWgCQAeAAAWAfQAWAhAAAuQAAAugVAgQgVAhgfAAIpWAEIAAAAQgfAAgVghg");
	var mask_graphics_70 = new cjs.Graphics().p("AjCC/QgXghAAguQAAgvAWgiQAXggAgAAIJ7gGQAhAAAXAgQAXAhABAuQAAAvgXAhQgWAighAAIp7AGIAAAAQggAAgYghg");
	var mask_graphics_71 = new cjs.Graphics().p("AjTC/QgYghgBgvQgBgwAYgiQAYghAjAAIKigIQAjAAAYAgQAZAhABAwQAAAvgYAiQgYAigiABIqiAIIgBAAQgiAAgZgig");
	var mask_graphics_72 = new cjs.Graphics().p("AjlDAQgagigBgwQgBgwAagjQAZghAlgBILMgLQAkAAAbAgQAaAiABAxQABAwgaAiQgZAjglABIrMALIgBAAQgkAAgagig");
	var mask_graphics_73 = new cjs.Graphics().p("Aj4DBQgcgigBgyQgBgxAbgjQAbgiAngBIL4gOQAmgBAcAhQAdAjAAAxQABAxgbAjQgaAkgnAAIr4AOIgBAAQgmAAgcghg");
	var mask_graphics_74 = new cjs.Graphics().p("AkMDBQgdgigBgyQgCgyAdglQAcgiApgBIMlgSQApgBAeAiQAeAjABAyQABAygcAkQgcAkgpABIsmARIgCAAQgnAAgegig");
	var mask_graphics_75 = new cjs.Graphics().p("AkgDCQgfgjgCgzQgBgzAeglQAegjArgBINUgWQArgBAgAjQAgAiABAzQABAzgeAlQgeAlgrABItTAVIgDAAQgqAAgfgig");
	var mask_graphics_76 = new cjs.Graphics().p("Ak0DCQgigjgBg0QgCgzAggmQAfgkAugCIOCgaQAugBAhAjQAiAjACA0QABA0gfAlQggAmgtABIuDAaIgDAAQgsAAgggjg");
	var mask_graphics_77 = new cjs.Graphics().p("AlJDDQgjgkgBg0QgCg1AhgnQAhglAwgBIOxgfQAwgBAjAkQAkAjACA1QABA0ghAmQghAngwABIuxAfIgEAAQgtAAgjgjg");
	var mask_graphics_78 = new cjs.Graphics().p("AlcDEQglglgCg1QgCg1AigoQAjgmAygCIPfgjQAzgCAkAkQAmAkACA2QACA1gjAnQgiAngzACIveAkIgFAAQgwAAgjgjg");
	var mask_graphics_79 = new cjs.Graphics().p("AlwDEQgngkgCg3QgCg2AkgoQAkgnA1gCIQLgoQA1gDAnAlQAnAkACA3QACA2gkAoQgkAog0ACIwMApIgFAAQgyAAglgkg");
	var mask_graphics_80 = new cjs.Graphics().p("AmDDFQgoglgCg3QgDg3AlgpQAmgoA3gCIQ2guQA4gCAoAlQApAmACA2QADA3gmAoQglApg3ACIw3AuIgGAAQgzAAgngjg");
	var mask_graphics_81 = new cjs.Graphics().p("AmUDGQgqgmgDg4QgCg3AmgqQAngoA5gDIRfgzQA6gDAqAmQAqAmADA3QACA3gnAqQgmApg5ADIxgAzIgHAAQg0AAgogjg");
	var mask_graphics_82 = new cjs.Graphics().p("AmlDGQgsgmgCg4QgDg5AngqQApgpA7gDISGg4QA7gDAsAmQAsAmADA4QACA4goAqQgoAqg7ADIyGA5IgIAAQg2AAgpgkg");
	var mask_graphics_83 = new cjs.Graphics().p("Am1DHQgtgmgDg6QgDg5ApgrQApgpA9gEISrg9QA9gDAtAmQAuAnADA4QADA5gqArQgpArg9ADIyqA9IgKAAQg3AAgqgjg");
	var mask_graphics_84 = new cjs.Graphics().p("AnEDHQgugmgDg6QgDg6ApgsQArgqA/gDITNhCQA/gEAuAmQAvAnADA5QADA6grArQgpAsg/ADIzNBDIgKAAQg5AAgrgkg");
	var mask_graphics_85 = new cjs.Graphics().p("AnSDIQgvgngDg6QgEg7ArgsQAsgrBAgDITthIQBAgDAwAmQAwAnADA6QAEA6gsAsQgrAshAAEIztBHIgLABQg5AAgtgkg");
	var mask_graphics_86 = new cjs.Graphics().p("AneDIQgxgngEg7QgDg7AsgsQAsgsBCgEIULhMQBBgDAxAmQAyAoADA6QAEA7gtAsQgsAthCAEI0KBMIgMAAQg6AAgtgkg");
	var mask_graphics_87 = new cjs.Graphics().p("AnqDJQgygngEg8QgDg8AsgsQAugtBDgEIUmhQQBDgEAyAnQAzAoADA6QAEA8guAsQgsAuhEAEI0lBQIgNAAQg7AAgugjg");
	var mask_graphics_88 = new cjs.Graphics().p("An1DJQgzgngEg8QgEg8AugtQAugtBFgFIU/hUQBEgEAzAnQA0AoAEA8QADA7guAtQgtAuhFAEI0/BUIgNABQg9AAgugkg");
	var mask_graphics_89 = new cjs.Graphics().p("An/DJQg0gngEg8QgEg9AugtQAvguBGgEIVXhZQBFgEA0AnQA1AoAEA9QAEA7gwAuQguAuhFAFI1XBYIgOAAQg9AAgvgkg");
	var mask_graphics_90 = new cjs.Graphics().p("AoJDKQg0gogEg9QgEg9AvgtQAvguBHgFIVshcQBHgFA1AoQA1AoAEA9QAEA8gwAuQgvAvhGAEI1sBcIgPABQg+AAgwgkg");
	var mask_graphics_91 = new cjs.Graphics().p("AoRDKQg1gogFg9QgEg9AwguQAwgvBIgFIWAhfQBHgFA2AoQA2AoAEA9QAEA9gwAuQgwAvhHAFI2ABfIgPABQg/AAgwgkg");
	var mask_graphics_92 = new cjs.Graphics().p("AoZDKQg2gogEg9QgEg+AwguQAxgvBIgFIWShiQBJgFA2AnQA3ApAEA9QAEA9gxAvQgwAvhIAFI2SBjIgQAAQg/AAgxgkg");
	var mask_graphics_93 = new cjs.Graphics().p("AogDKQg3gngEg+QgEg+AwgvQAygvBJgFIWihmQBKgFA3AoQA3AoAFA+QAEA9gxAvQgxAwhKAFI2iBmIgQAAQhAAAgxgkg");
	var mask_graphics_94 = new cjs.Graphics().p("AomDLQg4gogEg+QgFg/AygvQAxgvBLgFIWxhpQBKgFA4AoQA4ApAEA+QAFA9gyAvQgxAxhLAFI2xBoIgRABQhAAAgxgkg");
	var mask_graphics_95 = new cjs.Graphics().p("AosDLQg4gogFg/QgEg+AxgvQAzgwBLgFIW+hrQBLgGA4AoQA5ApAFA/QAEA9gyAwQgyAwhLAFI2+BrIgSABQhAAAgygkg");
	var mask_graphics_96 = new cjs.Graphics().p("AoxDLQg5gogFg/QgEg+AygwQAzgwBLgFIXLhtQBMgGA4AoQA6ApAEA/QAFA9gzAwQgyAxhMAFI3LBtIgRABQhBAAgygkg");
	var mask_graphics_97 = new cjs.Graphics().p("Ao2DLQg5gogFg/QgEg/AygvQAzgxBMgFIXWhvQBMgGA5AoQA6ApAFA/QAEA+gzAwQgyAxhMAFI3WBvIgTABQhBAAgygkg");
	var mask_graphics_98 = new cjs.Graphics().p("Ao7DLQg5gogFg/QgEg/AygwQA0gwBNgGIXfhxQBNgGA5ApQA7AoAEA/QAFA+gzAxQgzAxhNAGI3gBxIgSAAQhCAAgzgkg");
	var mask_graphics_99 = new cjs.Graphics().p("Ao+DMQg6gpgFg/QgFg/AzgwQA0gxBNgGIXphyQBNgGA6AoQA6ApAFA/QAFA+g0AxQgzAxhNAGI3pBzIgTAAQhBAAgzgjg");
	var mask_graphics_100 = new cjs.Graphics().p("ApCDMQg6gpgFg/QgEg/AzgxQA0gwBNgGIXxh0QBNgGA6AoQA7ApAFA/QAFA/g0AwQgzAyhOAGI3wB0IgUABQhBAAg0gkg");
	var mask_graphics_101 = new cjs.Graphics().p("ApFDMQg6gpgFg/QgFg/A0gxQA0gxBOgGIX3h1QBOgGA6AoQA8ApAEBAQAFA+g0AxQgzAxhOAGI34B2IgTABQhCAAg0gkg");
	var mask_graphics_102 = new cjs.Graphics().p("ApHDMQg7gpgFg/QgFhAA0gwQA0gxBPgGIX9h3QBOgGA7AoQA7ApAFBAQAFA/g0AxQg0AxhOAGI3+B3IgTABQhDAAgzgkg");
	var mask_graphics_103 = new cjs.Graphics().p("ApKDMQg6gogFhAQgFhAA0gxQA0gxBPgGIYCh3QBPgHA6ApQA8ApAFBAQAFA+g1AxQgzAyhPAGI4CB4IgUABQhDAAg0gkg");
	var mask_graphics_104 = new cjs.Graphics().p("ApLDMQg7gogFhAQgFhAA0gxQA0gxBPgGIYHh5QBPgGA7ApQA7ApAFBAQAFA+g0AyQg0AxhPAHI4HB4IgUABQhCAAg0gkg");
	var mask_graphics_105 = new cjs.Graphics().p("ApNDMQg7gogFhAQgFhAA0gxQA1gxBPgGIYKh6QBPgGA7ApQA8ApAFBAQAFA+g1AyQg0AyhPAGI4KB5IgUABQhDAAg0gkg");
	var mask_graphics_106 = new cjs.Graphics().p("ApODMQg7gogFhAQgFhAA0gxQA1gxBPgHIYNh5QBPgHA7ApQA8ApAFBAQAFA/g1AxQg0AyhPAGI4NB6IgUABQhDAAg0gkg");
	var mask_graphics_107 = new cjs.Graphics().p("ApPDMQg7gogFhAQgFhAA0gxQA1gyBPgGIYPh6QBQgGA7AoQA8AqAFA/QAFA/g1AyQg0AyhPAGI4QB6IgUABQhDAAg0gkg");
	var mask_graphics_108 = new cjs.Graphics().p("ApQDMQg7gogFhAQgFhAA0gxQA1gyBPgGIYRh6QBQgHA7ApQA8ApAFBAQAFA/g1AxQg0AyhPAHI4RB6IgVABQhCAAg1gkg");
	var mask_graphics_109 = new cjs.Graphics().p("ApQDMQg7gogFhAQgGhAA1gxQA1gyBPgGIYSh7QBPgGA8ApQA8ApAFBAQAFA/g1AxQg0AyhQAGI4SB7IgUABQhDAAg0gkg");
	var mask_graphics_110 = new cjs.Graphics().p("ApODOQg8gpgFhAQgFhAA0gxQA1gxBQgGIYSh7QBPgGA8AoQA8ApAFBAQAFA/g1AyQg0AyhQAGI4SB7IgUABQhDAAg0gkg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_graphics_58,x:35.5617,y:21.964}).wait(1).to({graphics:mask_graphics_59,x:36.5191,y:21.9844}).wait(1).to({graphics:mask_graphics_60,x:37.6033,y:22.0059}).wait(1).to({graphics:mask_graphics_61,x:38.8234,y:22.0281}).wait(1).to({graphics:mask_graphics_62,x:40.1888,y:22.0504}).wait(1).to({graphics:mask_graphics_63,x:41.7094,y:22.072}).wait(1).to({graphics:mask_graphics_64,x:43.3954,y:22.0922}).wait(1).to({graphics:mask_graphics_65,x:45.2565,y:22.1097}).wait(1).to({graphics:mask_graphics_66,x:47.3022,y:22.1232}).wait(1).to({graphics:mask_graphics_67,x:49.5406,y:22.1606}).wait(1).to({graphics:mask_graphics_68,x:51.9777,y:22.2305}).wait(1).to({graphics:mask_graphics_69,x:54.6163,y:22.3053}).wait(1).to({graphics:mask_graphics_70,x:57.4544,y:22.3845}).wait(1).to({graphics:mask_graphics_71,x:60.4842,y:22.4678}).wait(1).to({graphics:mask_graphics_72,x:63.6901,y:22.5545}).wait(1).to({graphics:mask_graphics_73,x:67.0484,y:22.6437}).wait(1).to({graphics:mask_graphics_74,x:70.5266,y:22.7344}).wait(1).to({graphics:mask_graphics_75,x:74.0853,y:22.8254}).wait(1).to({graphics:mask_graphics_76,x:77.6796,y:22.9155}).wait(1).to({graphics:mask_graphics_77,x:81.2632,y:23.0036}).wait(1).to({graphics:mask_graphics_78,x:84.7915,y:23.0885}).wait(1).to({graphics:mask_graphics_79,x:88.2251,y:23.1696}).wait(1).to({graphics:mask_graphics_80,x:91.5317,y:23.2461}).wait(1).to({graphics:mask_graphics_81,x:94.687,y:23.3178}).wait(1).to({graphics:mask_graphics_82,x:97.6749,y:23.3845}).wait(1).to({graphics:mask_graphics_83,x:100.486,y:23.4462}).wait(1).to({graphics:mask_graphics_84,x:103.1171,y:23.5029}).wait(1).to({graphics:mask_graphics_85,x:105.5691,y:23.5551}).wait(1).to({graphics:mask_graphics_86,x:107.846,y:23.6028}).wait(1).to({graphics:mask_graphics_87,x:109.954,y:23.6464}).wait(1).to({graphics:mask_graphics_88,x:111.9008,y:23.6862}).wait(1).to({graphics:mask_graphics_89,x:113.6945,y:23.7224}).wait(1).to({graphics:mask_graphics_90,x:115.3435,y:23.7553}).wait(1).to({graphics:mask_graphics_91,x:116.8563,y:23.7853}).wait(1).to({graphics:mask_graphics_92,x:118.2411,y:23.8124}).wait(1).to({graphics:mask_graphics_93,x:119.5057,y:23.837}).wait(1).to({graphics:mask_graphics_94,x:120.6574,y:23.8592}).wait(1).to({graphics:mask_graphics_95,x:121.7033,y:23.8793}).wait(1).to({graphics:mask_graphics_96,x:122.6497,y:23.8973}).wait(1).to({graphics:mask_graphics_97,x:123.5028,y:23.9135}).wait(1).to({graphics:mask_graphics_98,x:124.268,y:23.9279}).wait(1).to({graphics:mask_graphics_99,x:124.9506,y:23.9407}).wait(1).to({graphics:mask_graphics_100,x:125.5553,y:23.952}).wait(1).to({graphics:mask_graphics_101,x:126.0866,y:23.9619}).wait(1).to({graphics:mask_graphics_102,x:126.5486,y:23.9705}).wait(1).to({graphics:mask_graphics_103,x:126.9449,y:23.9778}).wait(1).to({graphics:mask_graphics_104,x:127.2792,y:23.984}).wait(1).to({graphics:mask_graphics_105,x:127.5546,y:23.9891}).wait(1).to({graphics:mask_graphics_106,x:127.7741,y:23.9931}).wait(1).to({graphics:mask_graphics_107,x:127.9407,y:23.9962}).wait(1).to({graphics:mask_graphics_108,x:128.0567,y:23.9983}).wait(1).to({graphics:mask_graphics_109,x:128.1247,y:23.9995}).wait(1).to({graphics:mask_graphics_110,x:128.3347,y:24.1619}).wait(1));

	// Layer_2 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape.setTransform(131.9805,19.1959,0.8095,0.8095,1.1837);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(58).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_40 = new cjs.Graphics().p("AGZBbQgOgFgMgNQgNgNgFgNQgFgNAGgGIB1h1QAGgGAOAFQANAFANANQAMANAFANQAFANgGAGIh1B1QgDADgGAAQgEAAgGgCg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AGQBfQgOgEgNgNQgNgNgEgNQgFgOAGgGIB9h8QAHgHANAFQAOAEANANQANANAEANQAFAOgHAGIh9B8QgDAEgHAAQgEAAgFgCg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AGFBlQgOgFgNgMQgNgNgEgOQgFgOAHgHICGiFQAHgHAOAEQAOAFANAMQANANAEAOQAEAOgHAHIiGCFQgEAEgHAAIgJgBg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AF4BrQgOgEgNgNQgNgNgEgOQgEgOAIgIICQiPQAIgIAOAEQAOAEANANQANANAEAOQAEAOgIAIIiQCPQgFAFgIAAIgJgBg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AFqByQgPgEgMgNQgNgMgDgPQgEgPAIgIICcibQAIgIAPADQAOAEANANQANAMAEAPQADAPgIAIIicCbQgGAGgJAAIgIgBg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AFbB5QgPgDgNgNQgMgNgDgPQgDgPAIgJICpinQAIgJAQADQAPADAMANQANANADAPQADAPgIAJIipCnQgGAHgKAAIgIgBg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AFMCBQgQgDgNgNQgNgNgCgPQgDgQAKgJIC1i1QAJgJAQACQAQADAMANQANAMADAQQACAQgJAJIi2C1QgHAHgLAAIgGAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AE7CJQgQgCgNgNQgNgNgBgQQgDgQAKgKIDEjDQAKgKAQACQAQACANANQAMANADAQQABAQgKAKIjDDDQgIAIgNAAIgFAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AEqCRQgQgCgNgMQgNgNgBgRQgCgRALgKIDRjRQALgKAQABQARACANAMQAMANACARQACARgLAKIjRDRQgKAJgOAAIgEAAg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AEZCZQgRgBgNgNQgMgMgBgSQgBgRALgLIDfjfQAMgLARABQARABANANQANAMABASQABARgMALIjfDfQgLAKgPAAIgDAAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AEJChQgSAAgNgNQgNgNAAgRQgBgSAMgMIDujtQAMgMASABQARAAANANQANANAAARQABASgNAMIjtDtQgMALgQAAIgBAAg");
	var mask_1_graphics_51 = new cjs.Graphics().p("ADZCdQgNgNAAgSQAAgSANgNID7j7QANgMASAAQASAAANAMQANANAAASQAAASgNANIj7D7QgNAMgSAAIAAAAQgSAAgNgMg");
	var mask_1_graphics_52 = new cjs.Graphics().p("ADIClQgNgNABgSQAAgTAOgNIEIkIQAOgOATAAQASgBANANQANANgBASQAAATgOAOIkIEHQgOAOgSAAIgCAAQgSAAgMgMg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AC4CtQgNgNABgTQABgTAOgOIEWkVQAOgOATgBQATgBANANQANANgBATQgBATgOAOIkWEVQgOAOgTABIgDAAQgRAAgMgMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("ACpC1QgNgNACgUQABgTAPgPIEhkhQAPgPAUgBQATgBANAMQANANgCAUQgBATgPAPIkhEhQgPAPgUABIgDAAQgSAAgLgLg");
	var mask_1_graphics_55 = new cjs.Graphics().p("ACbC8QgNgNACgUQACgUAPgPIEtksQAPgQAUgCQAUgBANAMQANANgCAUQgCAUgPAPIktEsQgPAQgUACIgFAAQgRAAgLgLg");
	var mask_1_graphics_56 = new cjs.Graphics().p("ACODCQgNgNADgUQACgUAPgQIE4k3QAPgPAVgDQAUgCANANQANANgCAUQgDAUgQAQIk3E3QgQAPgUADIgGAAQgQAAgLgLg");
	var mask_1_graphics_57 = new cjs.Graphics().p("ACCDIQgMgNACgVQADgUAQgRIFAk/QARgRAUgCQAVgDANANQANANgDAVQgCAUgRARIlAE/QgQARgVACIgHABQgQAAgLgLg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AB4DNQgMgNACgVQADgVARgRIFIlHQARgRAVgDQAVgDANANQANANgDAVQgDAVgRARIlIFHQgRARgVADIgHAAQgQAAgLgKg");
	var mask_1_graphics_59 = new cjs.Graphics().p("ABzDRQgMgNADgVQADgVARgRIFPlPQARgRAWgDQAVgDAMANQANANgDAVQgDAVgRARIlPFPQgRARgVADIgIABQgQAAgLgLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(40).to({graphics:mask_1_graphics_40,x:54.8396,y:-6.7456}).wait(1).to({graphics:mask_1_graphics_41,x:54.8,y:-6.2406}).wait(1).to({graphics:mask_1_graphics_42,x:54.7544,y:-5.6439}).wait(1).to({graphics:mask_1_graphics_43,x:54.7042,y:-4.9659}).wait(1).to({graphics:mask_1_graphics_44,x:54.6508,y:-4.2177}).wait(1).to({graphics:mask_1_graphics_45,x:54.5954,y:-3.4111}).wait(1).to({graphics:mask_1_graphics_46,x:54.5392,y:-2.5585}).wait(1).to({graphics:mask_1_graphics_47,x:54.4833,y:-1.6723}).wait(1).to({graphics:mask_1_graphics_48,x:54.4284,y:-0.7652}).wait(1).to({graphics:mask_1_graphics_49,x:54.3754,y:0.1503}).wait(1).to({graphics:mask_1_graphics_50,x:54.3249,y:1.0621}).wait(1).to({graphics:mask_1_graphics_51,x:54.2772,y:1.9583}).wait(1).to({graphics:mask_1_graphics_52,x:54.2319,y:2.8281}).wait(1).to({graphics:mask_1_graphics_53,x:54.19,y:3.6612}).wait(1).to({graphics:mask_1_graphics_54,x:54.1518,y:4.4481}).wait(1).to({graphics:mask_1_graphics_55,x:54.1171,y:5.1802}).wait(1).to({graphics:mask_1_graphics_56,x:54.0863,y:5.85}).wait(1).to({graphics:mask_1_graphics_57,x:54.0591,y:6.4507}).wait(1).to({graphics:mask_1_graphics_58,x:54.0358,y:6.9765}).wait(1).to({graphics:mask_1_graphics_59,x:54.3921,y:6.558}).wait(52));

	// Layer_2 copy
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape_1.setTransform(131.9805,19.1959,0.8095,0.8095,1.1837);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(40).to({_off:false},0).wait(71));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhBBjQgHgOgEgVQgFgWACgQQABgQAHgBIB7gYQAGgBAIAOQAHANAFAWQAEAVgCAQQgBAQgGACIh8AYIgBAAQgGAAgHgNg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AhBBjQgIgOgEgVQgEgWABgQQACgQAGgBIB8gYQAHgCAHAPQAIANAEAWQAEAVgBAQQgCAQgGABIh8AZIgBAAQgGAAgHgNg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AhDBjQgIgOgEgVQgEgWABgQQACgQAHgBIB/gZQAGgBAIAOQAIANAEAWQAEAVgBAQQgCAQgGACIiAAZIgBAAQgGAAgHgNg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AhGBjQgIgOgEgVQgFgWACgQQACgQAHgCICFgZQAGgCAIAPQAIANAEAVQAFAWgCAQQgCAQgHABIiFAbIgBAAQgGAAgHgNg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AhLBjQgIgOgFgWQgEgVACgQQACgQAIgCICNgbQAHgCAIAOQAIAOAFAVQAEAWgCAQQgCAQgIACIiNAcIgBAAQgHAAgHgNg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AhSBjQgIgOgFgWQgEgVADgQQACgRAIgBICYgeQAIgBAJAOQAIANAFAVQAEAWgDAQQgCAQgIACIiYAeIgCABQgHAAgIgNg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AhbBjQgJgOgEgWQgEgVADgRQADgQAIgCICoggQAJgCAJAOQAJANAEAVQAEAWgDAQQgDARgIABIioAiIgCAAQgHAAgJgMg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AhmBiQgKgNgEgWQgEgVADgRQAEgQAKgCIC7glQAJgCAKAOQAKAOAEAVQAEAVgDAQQgEARgKACIi7AlIgCABQgIAAgJgNg");
	var mask_2_graphics_28 = new cjs.Graphics().p("Ah0BiQgLgOgEgVQgEgWAEgQQAFgRALgCIDTgpQALgCAKANQALAOAEAUQAEAWgEAQQgFARgLACIjTArIgDAAQgJAAgJgMg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AiGBhQgLgNgFgVQgEgWAGgRQAFgRANgCIDxgvQAMgDAMAOQALANAFAVQAEAVgGARQgFARgNACIjxAxIgDAAQgLAAgKgMg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AibBhQgNgNgEgWQgEgVAHgRQAHgRAOgDIEUg3QAPgCANANQANANAEAWQAEAUgHARQgHARgOADIkUA3IgFABQgMAAgLgLg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AixBgQgPgNgEgVQgEgVAIgSQAJgRAQgEIE+g+QARgDAOAMQAPANAEAWQAEAUgIASQgJARgQADIk+BAIgHABQgMAAgMgLg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AjJBgQgQgNgEgVQgFgWAKgSQALgRASgEIFuhIQASgEAQANQARAMAEAWQAEAVgKARQgKASgTAEIltBIIgIABQgOAAgNgJg");
	var mask_2_graphics_33 = new cjs.Graphics().p("AjiBfQgSgMgEgWQgFgVAMgTQAMgSAVgDIGghTQAVgEASAMQASAMAEAWQAFAVgNASQgLASgWAEImfBTIgLABQgPAAgNgJg");
	var mask_2_graphics_34 = new cjs.Graphics().p("Aj8BeQgUgMgEgVQgEgWANgSQAOgTAYgEIHShcQAYgFATAMQAVALAEAWQAEAVgOATQgOARgXAFInSBdIgNABQgRAAgOgIg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AkUBhQgWgMgEgVQgEgWAPgTQAQgSAagFIIChmQAagFAWALQAVAMAFAVQAEAWgQASQgPATgaAFIoCBmQgJACgHAAQgRAAgPgIg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AkrBmQgXgLgEgWQgFgVARgTQASgTAcgGIIvhvQAcgFAXALQAYALAEAWQAEAVgRATQgRATgdAGIouBvQgKABgJAAQgRAAgQgHg");
	var mask_2_graphics_37 = new cjs.Graphics().p("Ak/BrQgYgLgFgWQgEgVATgUQASgTAfgGIJVh2QAfgHAYALQAZALAFAWQAEAVgTAUQgSATgfAGIpWB2QgKADgLAAQgSAAgQgHg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AlQBvQgagLgEgVQgFgWAUgUQAUgTAggHIJ4h9QAhgGAZAKQAaALAFAVQAEAWgUAUQgUATggAHIp4B9QgMACgLAAQgTAAgQgGg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AlfByQgbgKgEgWQgFgVAVgUQAVgUAigHIKViDQAigHAbALQAbAKAEAWQAFAVgWAUQgUAUgiAHIqVCDQgNACgNAAQgTAAgQgGg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AlsB1QgcgKgEgWQgEgVAVgUQAWgUAkgHIKuiIQAjgHAcAKQAcAKAEAWQAEAVgWAUQgVAUgjAHIqvCIQgOADgNAAQgTAAgRgGg");
	var mask_2_graphics_41 = new cjs.Graphics().p("Al3B3QgcgKgEgVQgEgVAWgVQAXgUAkgHILDiMQAlgIAcAKQAdALAEAVQAEAWgWAUQgXAUgkAHIrECMQgOADgOAAQgUAAgRgGg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:5.3004,y:11.2408}).wait(21).to({graphics:mask_2_graphics_21,x:5.3004,y:11.2451}).wait(1).to({graphics:mask_2_graphics_22,x:5.5397,y:11.2359}).wait(1).to({graphics:mask_2_graphics_23,x:5.9661,y:11.2193}).wait(1).to({graphics:mask_2_graphics_24,x:6.6076,y:11.1945}).wait(1).to({graphics:mask_2_graphics_25,x:7.4976,y:11.1602}).wait(1).to({graphics:mask_2_graphics_26,x:8.6752,y:11.1148}).wait(1).to({graphics:mask_2_graphics_27,x:10.186,y:11.0568}).wait(1).to({graphics:mask_2_graphics_28,x:12.0799,y:10.9844}).wait(1).to({graphics:mask_2_graphics_29,x:14.4057,y:10.896}).wait(1).to({graphics:mask_2_graphics_30,x:17.1987,y:10.7905}).wait(1).to({graphics:mask_2_graphics_31,x:20.251,y:10.6684}).wait(1).to({graphics:mask_2_graphics_32,x:23.5312,y:10.5324}).wait(1).to({graphics:mask_2_graphics_33,x:27.0365,y:10.3885}).wait(1).to({graphics:mask_2_graphics_34,x:30.5775,y:10.2445}).wait(1).to({graphics:mask_2_graphics_35,x:33.9672,y:9.7417}).wait(1).to({graphics:mask_2_graphics_36,x:37.0733,y:9.0245}).wait(1).to({graphics:mask_2_graphics_37,x:39.8328,y:8.3874}).wait(1).to({graphics:mask_2_graphics_38,x:42.2355,y:7.8327}).wait(1).to({graphics:mask_2_graphics_39,x:44.3011,y:7.3558}).wait(1).to({graphics:mask_2_graphics_40,x:46.0616,y:6.9494}).wait(1).to({graphics:mask_2_graphics_41,x:47.5754,y:6.6447}).wait(70));

	// Layer_2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape_2.setTransform(131.9805,19.1959,0.8095,0.8095,1.1837);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(111));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-1.3,288.9,48.5);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.introBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg5XDVeMAAAmq7MByvAAAMAAAGq7g");
	this.shape.setTransform(481.45,404.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg, new cjs.Rectangle(114.3,-961.5,734.3000000000001,2732.4), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8INMAl5AAAAy8BLMAl5AAAAy8DhMAl5AAAAy8F3MAl5AAAAy8oMMAl5AAAAy8l2MAl5AAAAy8jgMAl5AAAAy8hKMAl5AAA");
	this.shape.setTransform(121.25,52.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-1,-1,244.5,107), null);


(lib.greenLineC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7A9E3E").s().p("AtpM9QAAlRCDk0QB+koDljlQDmjmEoh+QE0iDFRAAQApAAAxADIAAF8Qg0gDgmAAQkDAAjuBlQjlBhiwCxQixCwhhDlQhlDuAAEDg");
	this.shape.setTransform(34.5388,32.7699,0.3953,0.3953);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.greenLineC, new cjs.Rectangle(0,0,69.1,65.6), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group60();
	this.instance.setTransform(105.8,59.05,0.9188,0.9188);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(105.8,59.1,290.4,209.50000000000003), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS();
	this.instance.setTransform(38.35,20.45,0.94,0.94);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(38.4,20.5,376,250), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.blankchart_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F0EFEF").s().p("AT+M9QAAkDhljuQhhjlixiwQixixjlhhQjthlkEAAQkCAAjuBlQjlBhixCxQixCwhhDlQhlDuAAEDIl8AAQAAlRCDk0QB+koDljlQDmjmEph+QE0iDFQAAQFRAAE0CDQEpB+DmDmQDlDlB+EoQCDE0AAFRg");
	this.shape.setTransform(65.5198,32.7648,0.3952,0.3952);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blankchart_c, new cjs.Rectangle(0,0,131.1,65.6), null);


(lib.bangc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAxCIQgEgBgBgEQgCgEABgDQACgEADgCIApgTIgRgGIAAAAIgggLQgDgCgCgDQgCgEABgDQABgEADgCQAkgYATgOIgWADIgrAFQgEAAgDgCQgDgCgBgDQgBgEABgDIAchCIg3AwQgDADgEAAQgEgBgDgCQgCgCAAgEIgChPIgkBOQgCAEgEABQgEABgDgBQgEgBgCgEIgZg+IgDAiIgCAtQAAAEgDADQgDADgEAAQgEgBgDgCQgDgEAAgEIACgtIAAgBQAEg0AHgTQABgDADgCQADgCADAAQADAAACACQADACABADIAcBIIAthgQACgDADgCQADgBADAAQAEABACADQACACAAAEIACBkIBHg/QADgCADAAQAEgBACADQADACABADQABADgBADIgmBaIAagDIA3gGQAEgBADADQADACABAEQAAAEgCADQgIANg6AmIANAFIAAAAQAjAMAFAEQADACABAEQABAEgBADQgCADgDACIg9AcIgEABIgEgBg");
	this.shape.setTransform(12.3796,12.6957);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bangc, new cjs.Rectangle(-1,-1,26.8,27.4), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzCKIAAkTIPnAAIAAETg");
	this.shape.setTransform(50,13.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,-0.2,100,27.599999999999998), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.arc_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkCCeQgIgEgDgHQgDgIADgIQBrj0DbgmQBugTBcAeQAHADAEAHQADAIgCAIQgDAIgHADQgIAEgIgDQhXgdhjASQjCAlhhDfQgFAMgNAAIgIgBg");
	this.shape.setTransform(27.1896,15.9604);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc_c, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.PresenterCoach_AndroidMobile_LightUIINSKIN();
	this.instance.setTransform(48.95,22.7,0.9098,0.9098);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(-4.7,6.1,197.39999999999998,331.79999999999995), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.pointer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointer.cache(0,0,30,25,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointer = new lib.pointerc();
	this.pointer.name = "pointer";
	this.pointer.setTransform(12.8,10.7,1,1,0,0,0,12.8,10.7);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.gridpiece();
	this.instance.setTransform(223.25,324.65,0.8462,0.8462,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(121.9,324.65,0.8462,0.8462,90,0,0,125.9,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(177.2,369.25,0.8462,0.8462,0,0,0,125.9,52.6);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(177.2,267.75,0.8462,0.8462,0,0,0,125.9,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(70.2,217.7,206.10000000000002,206.10000000000002), null);


(lib.green_bar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.glc.cache(0,0,75,70,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.glc = new lib.greenLineC();
	this.glc.name = "glc";
	this.glc.setTransform(34.6,32.8,1,1,0,0,0,34.6,32.8);

	this.timeline.addTween(cjs.Tween.get(this.glc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.green_bar, new cjs.Rectangle(0,0,69.1,65.6), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_98 = function() {
		this.stop()
		//exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(33).call(this.frame_98).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgYCBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_15 = new cjs.Graphics().p("EgYQBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_16 = new cjs.Graphics().p("EgY5BJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_17 = new cjs.Graphics().p("EgZ9BJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_18 = new cjs.Graphics().p("EgbcBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_19 = new cjs.Graphics().p("EgdXBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_20 = new cjs.Graphics().p("EgfsBJpIAAr4MBBiAAAIAAL4g");
	var mask_graphics_21 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_22 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_23 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_24 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_25 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");
	var mask_graphics_26 = new cjs.Graphics().p("EggxBJpIAAr4MBBjAAAIAAL4g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:265.5928,y:471.3035}).wait(1).to({graphics:mask_graphics_15,x:264.231,y:471.3035}).wait(1).to({graphics:mask_graphics_16,x:260.1456,y:471.3035}).wait(1).to({graphics:mask_graphics_17,x:253.3366,y:471.3035}).wait(1).to({graphics:mask_graphics_18,x:243.8039,y:471.3035}).wait(1).to({graphics:mask_graphics_19,x:231.5477,y:471.3035}).wait(1).to({graphics:mask_graphics_20,x:216.5678,y:471.3035}).wait(1).to({graphics:mask_graphics_21,x:193.4169,y:471.3035}).wait(1).to({graphics:mask_graphics_22,x:168.9044,y:471.3035}).wait(1).to({graphics:mask_graphics_23,x:149.8391,y:471.3035}).wait(1).to({graphics:mask_graphics_24,x:136.2211,y:471.3035}).wait(1).to({graphics:mask_graphics_25,x:128.0503,y:471.3035}).wait(1).to({graphics:mask_graphics_26,x:125.3266,y:471.3035}).wait(1).to({graphics:null,x:0,y:0}).wait(72));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-233.95,900.4,3.5247,3.5247,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:19.1},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).wait(1));

	// Layer_2
	this.introBg = new lib.introBg();
	this.introBg.name = "introBg";
	this.introBg.setTransform(74.9,904.15,0.7146,0.7146,0,0,0,485.9,405.6);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(73.85,904.75,0.213,0.213,0,0,0,-39.2,2.1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.introBg}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).wait(72));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.5247,scaleY:3.5247,x:73.65,y:904.65},13,cjs.Ease.quadOut).to({x:-122.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(72));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgpBCYZMAAAkwxMBSDAAAMAAAEwxg");
	this.shape.setTransform(74.65,905.65);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(74.65,905.65,0.5365,2.3555,0,0,0,0.1,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-190.6,-72.7,527.8,1953.7);


(lib.collabIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_13
	this.outlines = new lib.outlines();
	this.outlines.name = "outlines";
	this.outlines.setTransform(-77.1,154.6,1,1,0,0,0,-0.4,168.9);

	this.timeline.addTween(cjs.Tween.get(this.outlines).wait(1));

	// mic
	this.mic = new lib.Microphone();
	this.mic.name = "mic";
	this.mic.setTransform(102.65,117.8,1,1,0,0,0,50.5,66.1);

	this.timeline.addTween(cjs.Tween.get(this.mic).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabIcon, new cjs.Rectangle(-76.7,-14.3,229.89999999999998,198.3), null);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(202.2,37.1,0.9673,0.9673,-102.8471,0,0,14.7,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(213.25,29.65,0.9673,0.9673,-133.847,0,0,14.7,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(218.05,18.1,0.9674,0.9674,-173.8516,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(131.4,-54.7,0.9961,0.9961,86.0024,0,0,14.8,0);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(119.3,-49.8,0.9961,0.9961,55.0029,0,0,14.8,-0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(111.9,-40.35,0.9961,0.9961,14.9997,0,0,15,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// PPT_Icon
	this.ODIcon = new lib.collabIcon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(120.15,18,0.3921,0.3921,0,0,0,-75.4,149.3);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(39.5,49.6,1,1,0,0,0,144.5,23.6);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-108.5,-71,469.4,717), null);


(lib.blank_chart = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.blankchart.cache(0,0,135,70)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.blankchart = new lib.blankchart_c();
	this.blankchart.name = "blankchart";
	this.blankchart.setTransform(65.5,32.8,1,1,0,0,0,65.5,32.8);

	this.timeline.addTween(cjs.Tween.get(this.blankchart).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blank_chart, new cjs.Rectangle(0,0,131.1,65.6), null);


(lib.bang_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bang.cache(-27,-27,54,54,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bang = new lib.bangc();
	this.bang.name = "bang";
	this.bang.setTransform(12.3,12.7,1,1,0,0,0,12.3,12.7);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_c, new cjs.Rectangle(-1,-1,26.8,27.4), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhePhQhYg3gYhlQgXhgAwhUIAGgJIGpEHIgFAJQg2BRhhAWQgeAIgeAAQhCAAg+gmg");
	var mask_graphics_1 = new cjs.Graphics().p("AhyPIQhPhEgHhnQgHhjA+hLIAGgIIF5FJIgHAIQhCBHhjAHIgTAAQhaAAhHg+g");
	var mask_graphics_2 = new cjs.Graphics().p("AAoQFQhmgKhChQQhChQAKhoQAJhiBJhAIAIgHIE+GDIgIAHQhDAyhSAAIgbgBg");
	var mask_graphics_3 = new cjs.Graphics().p("AARP+Qhjgbg0haQg0haAahkQAahgBSgzIAJgGID6GyIgJAFQg3Aeg7AAQghAAgigJg");
	var mask_graphics_4 = new cjs.Graphics().p("AgCPwQhegrglhhQglhhArhfQAphaBYglIAKgEICxHVIgKAEQgnANgoAAQg0AAgygXg");
	var mask_graphics_5 = new cjs.Graphics().p("AgRPcQhXg5gUhmQgVhmA6hXQA3hSBdgWIALgCIBiHrIgLACQgVAEgUAAQhIAAg/grg");
	var mask_graphics_6 = new cjs.Graphics().p("AgdPDQhMhHgDhoQgEhoBHhLQBDhIBggHIALgBIARH2IgLAAQhhgBhHhDg");
	var mask_graphics_7 = new cjs.Graphics().p("ABWQFQhegRg8hOQhAhSAOhnQANhnBThAQBNg8BhAKIAKABIhBHxIgLgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AAbP/QhbgggvhXQgwhbAehkQAehjBbgxQBXgvBdAZIAKADIiRHgIgKgDg");
	var mask_graphics_9 = new cjs.Graphics().p("AgdP2QhVguggheQghhiAuhdQAuhdBhgiQBegfBYAoIAKAEIjdHCIgKgFg");
	var mask_graphics_10 = new cjs.Graphics().p("AhRPqQhMg7gQhiQgRhmA9hUQA8hVBmgRQBhgQBRA2IAJAGIkkGXIgJgGg");
	var mask_graphics_11 = new cjs.Graphics().p("Ah+PcQhChHAAhjQAAhoBKhJQBJhKBnABQBjAABHBCIAHAHIliFjIgHgIg");
	var mask_graphics_12 = new cjs.Graphics().p("AilPMQg1hRAQhiQARhmBVg9QBUg8BmARQBhAQA7BNIAHAJImYEjIgGgIg");
	var mask_graphics_13 = new cjs.Graphics().p("AjDO5QgnhYAgheQAhhiBdguQBdgtBiAhQBdAgAuBWIAFAJInBDdIgFgKg");
	var mask_graphics_14 = new cjs.Graphics().p("AjYOmQgYheAuhXQAyhbBjgeQBjgeBbAxQBXAvAfBcIADAKInfCQIgDgKg");
	var mask_graphics_15 = new cjs.Graphics().p("AjjOSQgJhhA8hOQBAhSBngNQBmgOBSBAQBOA8AQBgIACAKInxBAIgBgKg");
	var mask_graphics_16 = new cjs.Graphics().p("AjlN/IAAgKQAIhhBIhDQBMhHBnAEQBnADBHBMQBDBJAABhIAAAKg");
	var mask_graphics_17 = new cjs.Graphics().p("AjhNCIACgKQAXheBTg3QBWg5BlAUQBmAVA5BWQA3BTgQBfIgCALg");
	var mask_graphics_18 = new cjs.Graphics().p("AjWMHIAEgKQAmhZBagoQBegrBhAlQBhAlArBfQAoBagfBcIgEAKg");
	var mask_graphics_19 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBkgbBZA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_20 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_21 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_22 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_23 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_24 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_25 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_26 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_27 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBjgbBaA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_28 = new cjs.Graphics().p("AjFLPIAGgJQA0hSBfgZQBkgbBZA1QBaA0AbBkQAZBgguBVIgFAKg");
	var mask_graphics_29 = new cjs.Graphics().p("AjGLRIAGgJQAzhSBfgaQBkgbBaA0QBaAzAbBkQAaBggtBWIgFAJg");
	var mask_graphics_30 = new cjs.Graphics().p("AjILZIAFgJQAxhUBfgcQBigdBcAxQBbAyAdBjQAdBfgsBXIgFAJg");
	var mask_graphics_31 = new cjs.Graphics().p("AjNLoIAEgKQAuhVBdghQBighBdAtQBdAuAiBiQAgBdgnBZIgFAJg");
	var mask_graphics_32 = new cjs.Graphics().p("AjUL+IAEgJQAohZBbgmQBfgoBgAnQBgAnAoBgQAnBbgiBbIgEAKg");
	var mask_graphics_33 = new cjs.Graphics().p("AjcMgIADgKQAfhcBXguQBcgyBiAeQBkAeAxBbQAvBXgZBeIgDAKg");
	var mask_graphics_34 = new cjs.Graphics().p("AjjNQIACgKQAThfBQg6QBUg9BmARQBmAQA9BUQA6BRgMBgIgCAKg");
	var mask_graphics_35 = new cjs.Graphics().p("AjmODQAChhBFhGQBIhLBngBQBogCBLBIQBGBFAFBhIABALIn1AHIAAgLg");
	var mask_graphics_36 = new cjs.Graphics().p("AjdOfQgUhfAzhUQA2hZBlgZQBkgYBZA2QBUAzAaBdIADAKInmB4IgCgLg");
	var mask_graphics_37 = new cjs.Graphics().p("Ai5PAQgthWAahfQAbhkBagzQBag0BkAbQBfAbAzBSIAFAJImyD5IgFgKg");
	var mask_graphics_38 = new cjs.Graphics().p("AhxPhQhGhDgFhjQgFhoBFhNQBGhNBngGQBigFBKA/IAIAHIlOF0IgIgHg");
	var mask_graphics_39 = new cjs.Graphics().p("AgKP6QhYgpglhcQgnhgAphgQAohfBfgnQBcglBbAiIAJAEIjCHOIgKgEg");
	var mask_graphics_40 = new cjs.Graphics().p("ABlQGQhggMg+hMQhDhPAJhoQAKhnBPhDQBLg/BhAFIAKABIgsHzIgLgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AgTPbQhWg7gShmQgThnA7hVQA4hRBegVIAKgCIBbHtIgLACQgTADgSAAQhLAAhAgtg");
	var mask_graphics_42 = new cjs.Graphics().p("AACP1QhfgmgphgQgphfAmhhQAlhbBXgqIAKgEIDFHMIgJAFQgtARgsAAQgvAAgvgTg");
	var mask_graphics_43 = new cjs.Graphics().p("AAaQCQhlgUg6hWQg5hXAUhmQAThgBPg5IAIgGIEWGhIgJAGQg8AkhDAAQgaAAgagFg");
	var mask_graphics_44 = new cjs.Graphics().p("AAwQHQhngFhGhNQhGhNAGhoQAEhjBGhDIAIgHIFPFzIgHAHQhFA6haAAIgOAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AhyPJQhPhEgHhoQgGhiA9hLIAHgJIF5FKIgHAIQhDBHhiAHIgTAAQhbAAhHg+g");
	var mask_graphics_46 = new cjs.Graphics().p("AhnPYQhVg9gQhnQgQhhA2hRIAGgJIGWEmIgHAJQg7BMhiAQQgWADgVAAQhMAAhCgvg");
	var mask_graphics_47 = new cjs.Graphics().p("AhePhQhYg3gYhlQgXhgAwhUIAGgJIGpEHIgFAJQg2BRhhAWQgeAIgeAAQhCAAg+gmg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:25.0153,y:103.0666}).wait(1).to({graphics:mask_graphics_1,x:23.8316,y:103.0362}).wait(1).to({graphics:mask_graphics_2,x:22.3954,y:103.0382}).wait(1).to({graphics:mask_graphics_3,x:20.7452,y:103.0671}).wait(1).to({graphics:mask_graphics_4,x:18.9254,y:103.0866}).wait(1).to({graphics:mask_graphics_5,x:16.9848,y:103.0875}).wait(1).to({graphics:mask_graphics_6,x:14.9756,y:103.0879}).wait(1).to({graphics:mask_graphics_7,x:16.2175,y:102.9952}).wait(1).to({graphics:mask_graphics_8,x:18.248,y:102.5906}).wait(1).to({graphics:mask_graphics_9,x:20.1761,y:101.8673}).wait(1).to({graphics:mask_graphics_10,x:21.95,y:100.8448}).wait(1).to({graphics:mask_graphics_11,x:23.5221,y:99.5504}).wait(1).to({graphics:mask_graphics_12,x:24.8505,y:98.0191}).wait(1).to({graphics:mask_graphics_13,x:25.8993,y:96.2918}).wait(1).to({graphics:mask_graphics_14,x:26.6405,y:94.415}).wait(1).to({graphics:mask_graphics_15,x:27.0544,y:92.4391}).wait(1).to({graphics:mask_graphics_16,x:27.1357,y:91.3114}).wait(1).to({graphics:mask_graphics_17,x:27.1354,y:93.3765}).wait(1).to({graphics:mask_graphics_18,x:27.1259,y:95.3704}).wait(1).to({graphics:mask_graphics_19,x:27.0455,y:97.1625}).wait(1).to({graphics:mask_graphics_20,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_21,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_22,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_23,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_24,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_25,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_26,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_27,x:27.0456,y:97.1625}).wait(1).to({graphics:mask_graphics_28,x:27.0455,y:97.1625}).wait(1).to({graphics:mask_graphics_29,x:27.0473,y:97.0834}).wait(1).to({graphics:mask_graphics_30,x:27.0524,y:96.8244}).wait(1).to({graphics:mask_graphics_31,x:27.0606,y:96.3422}).wait(1).to({graphics:mask_graphics_32,x:27.0695,y:95.5752}).wait(1).to({graphics:mask_graphics_33,x:27.0739,y:94.4386}).wait(1).to({graphics:mask_graphics_34,x:27.0674,y:92.8257}).wait(1).to({graphics:mask_graphics_35,x:27.0667,y:90.9946}).wait(1).to({graphics:mask_graphics_36,x:26.7244,y:93.7679}).wait(1).to({graphics:mask_graphics_37,x:25.449,y:96.964}).wait(1).to({graphics:mask_graphics_38,x:22.9477,y:100.0283}).wait(1).to({graphics:mask_graphics_39,x:19.438,y:102.2104}).wait(1).to({graphics:mask_graphics_40,x:15.6407,y:103.1169}).wait(1).to({graphics:mask_graphics_41,x:16.7627,y:103.1695}).wait(1).to({graphics:mask_graphics_42,x:19.4285,y:103.1704}).wait(1).to({graphics:mask_graphics_43,x:21.4162,y:103.1435}).wait(1).to({graphics:mask_graphics_44,x:22.8479,y:103.1191}).wait(1).to({graphics:mask_graphics_45,x:23.8599,y:103.12}).wait(1).to({graphics:mask_graphics_46,x:24.5669,y:103.1333}).wait(1).to({graphics:mask_graphics_47,x:25.0153,y:103.0666}).wait(1));

	// Layer_1
	this.instance = new lib.bang_c();
	this.instance.setTransform(33.35,172.8,1,1,0,0,0,12.3,12.7);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(20.1,159.1,26.699999999999996,27.400000000000006);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.arc.cache(0,0,55,35,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.arc = new lib.arc_c();
	this.arc.name = "arc";
	this.arc.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.arc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AvGckQiWgthLiKQhLiKAriXQAuiXCLhLMAqVgW/QCLhLCWAtQCYAtBLCKQBLCKguCWQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_54 = new cjs.Graphics().p("AvLcmQiWgshLiKQhLiKAsiYQAuiXCKhLMAqWgW+QCKhLCWAsQCYAuBLCKQBLCKguCWQgrCXiKBLMgqWAW/QhXAvhbAAQg4AAg5gRg");
	var mask_graphics_55 = new cjs.Graphics().p("AvbcvQiWgshLiKQhLiKAriYQAuiXCKhLMAqWgW+QCKhLCWAsQCZAuBLCKQBLCKguCWQgsCXiKBLMgqWAXAQhWAuhcAAQg3AAg5gRg");
	var mask_graphics_56 = new cjs.Graphics().p("Av/dDQiWgthLiKQhLiKAsiYQAuiWCKhLMAqWgW/QCKhLCWAtQCYAtBLCKQBLCKguCWQgrCYiLBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_57 = new cjs.Graphics().p("Aw9dlQiWgthLiKQhLiKAriYQAuiXCKhLMAqWgW+QCLhLCWAtQCYAtBLCKQBLCJguCXQgsCXiKBLMgqWAXAQhWAuhcAAQg3AAg5gQg");
	var mask_graphics_58 = new cjs.Graphics().p("AySeSQiWgshLiKQhLiLAsiXQAuiXCKhLMAqWgW+QCKhLCWAsQCZAtBLCLQBLCJguCXQgsCXiKBLMgqWAW/QhWAvhcAAQg3AAg6gRg");
	var mask_graphics_59 = new cjs.Graphics().p("Azje+QiWgshLiKQhLiKAsiYQAuiXCKhLMAqWgW+QCKhLCWAsQCYAuBLCKQBLCJguCXQgrCXiLBLMgqVAXAQhXAuhbAAQg4AAg5gRg");
	var mask_graphics_60 = new cjs.Graphics().p("A0kfiQiWgthLiKQhLiKAsiYQAuiXCKhLMAqWgW+QCKhLCWAtQCZAtBLCJQBLCKguCXQgsCXiKBLMgqWAXAQhWAuhcAAQg3AAg6gQg");
	var mask_graphics_61 = new cjs.Graphics().p("A1Vf8QiWgshLiKQhLiKAsiYQAuiXCKhLMAqWgW+QCKhLCWAsQCYAuBLCJQBLCKguCXQgrCXiLBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_62 = new cjs.Graphics().p("EgV7AgRQiWgshLiLQhLiKAsiXQAtiXCLhLMAqWgW+QCKhLCWAsQCYAtBLCJQBLCLguCWQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_63 = new cjs.Graphics().p("EgWZAghQiWgshLiLQhLiKAsiXQAuiXCKhLMAqWgW+QCKhLCWAsQCYAtBLCJQBLCLguCWQgrCYiKBLMgqWAW/QhXAvhbAAQg4AAg5gRg");
	var mask_graphics_64 = new cjs.Graphics().p("EgWwAguQiWgthLiKQhLiKAsiYQAuiWCKhLMAqWgW/QCKhLCWAtQCYAtBLCJQBLCKguCXQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_65 = new cjs.Graphics().p("EgW3Ag4QiWgthLiKQhLiKAsiYQAtiWCLhLMAqWgW/QCKhLCWAtQCYAtBLCJQBLCKguCXQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_66 = new cjs.Graphics().p("EgW3AhAQiWgthLiKQhLiKAsiYQAtiXCLhLMAqWgW+QCKhLCWAtQCYAtBLCJQBLCKguCXQgsCXiKBLMgqWAXAQhWAuhcAAQg3AAg5gQg");
	var mask_graphics_67 = new cjs.Graphics().p("EgW3AhGQiWgthLiKQhLiKAsiYQAtiXCLhLMAqWgW+QCKhLCWAtQCYAtBLCJQBLCKguCXQgsCXiKBLMgqWAXAQhWAuhcAAQg3AAg5gQg");
	var mask_graphics_68 = new cjs.Graphics().p("EgW3AhKQiWgshLiLQhLiKAsiXQAtiXCLhLMAqWgW+QCKhLCWAsQCYAtBLCJQBLCLguCWQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_69 = new cjs.Graphics().p("EgW3AhNQiWgshLiKQhLiLAsiXQAtiXCLhLMAqWgW+QCKhLCWAsQCYAuBLCJQBLCKguCXQgsCXiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_70 = new cjs.Graphics().p("EgW3AhQQiWgthLiKQhLiKAsiYQAtiXCLhLMAqWgW+QCKhLCWAtQCYAtBLCJQBLCKguCXQgsCXiKBLMgqWAXAQhWAuhcAAQg3AAg5gQg");
	var mask_graphics_71 = new cjs.Graphics().p("EgW3AhRQiWgthLiKQhLiKAsiYQAtiWCLhLMAqWgW/QCKhLCWAtQCYAtBLCJQBLCKguCXQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");
	var mask_graphics_72 = new cjs.Graphics().p("EgW3AhRQiWgshLiLQhLiKAriXQAuiXCLhLMAqWgW+QCKhLCWAsQCYAtBLCKQBLCKguCWQgsCYiKBLMgqWAW/QhWAvhcAAQg3AAg5gRg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:223.343,y:184.4842}).wait(1).to({graphics:mask_graphics_54,x:222.8879,y:184.7311}).wait(1).to({graphics:mask_graphics_55,x:221.2192,y:185.6369}).wait(1).to({graphics:mask_graphics_56,x:217.6657,y:187.5657}).wait(1).to({graphics:mask_graphics_57,x:211.4326,y:190.949}).wait(1).to({graphics:mask_graphics_58,x:203.0042,y:195.5239}).wait(1).to({graphics:mask_graphics_59,x:194.8743,y:199.9367}).wait(1).to({graphics:mask_graphics_60,x:188.4041,y:203.4487}).wait(1).to({graphics:mask_graphics_61,x:183.4595,y:206.1326}).wait(1).to({graphics:mask_graphics_62,x:179.6537,y:208.1983}).wait(1).to({graphics:mask_graphics_63,x:176.6878,y:209.8082}).wait(1).to({graphics:mask_graphics_64,x:174.3576,y:211.073}).wait(1).to({graphics:mask_graphics_65,x:171.394,y:212.0684}).wait(1).to({graphics:mask_graphics_66,x:168.5226,y:212.8477}).wait(1).to({graphics:mask_graphics_67,x:166.3049,y:213.4495}).wait(1).to({graphics:mask_graphics_68,x:164.6345,y:213.9029}).wait(1).to({graphics:mask_graphics_69,x:163.4299,y:214.2298}).wait(1).to({graphics:mask_graphics_70,x:162.6271,y:214.4477}).wait(1).to({graphics:mask_graphics_71,x:162.175,y:214.5704}).wait(1).to({graphics:mask_graphics_72,x:162.0322,y:214.6092}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(79.15,362.75,1.28,1.28,-6.4876,0,0,42.1,17);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AW1bDMgvggHkQibgZhdiAQhch/AZibQAYibB/hdQCAhcCbAZMAvgAHkQCbAZBcB+QBdCBgZCbQgYCbiABbQhlBKh1AAQggAAgggFg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AW1bGMgvggHkQibgZhdiAQhch/AZibQAYibB/hdQCAhcCbAZMAvgAHlQCbAYBcB/QBdCAgYCbQgZCbiABcQhkBJh2AAQggAAgggFg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AW1bQMgvggHlQibgYhdiBQhch+AZibQAYibB/heQCAhbCbAZMAvgAHkQCbAZBcB+QBdCAgYCbQgZCbiABcQhkBKh2AAQggAAgggFg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AW1beMgvggHkQibgZhdiAQhch/AZibQAYibB/hdQCAhcCbAZMAvgAHkQCbAZBcB/QBdCAgYCbQgZCbiABbQhkBKh2AAQggAAgggFg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AW1bwMgvggHkQibgZhdiAQhch+AZibQAYibB/heQCAhbCbAYMAvgAHlQCbAYBcB/QBdCAgYCbQgZCbiABcQhkBKh2AAQggAAgggGg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AW1cFMgvggHlQibgYhdiBQhch+AZibQAYibB/heQCAhbCbAZMAvgAHkQCbAZBcB+QBdCBgYCbQgZCbiABbQhkBKh2AAQggAAgggFg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AW1cZMgvggHkQibgZhdiAQhch/AZibQAYibB/hdQCAhcCbAZMAvgAHkQCbAZBcB/QBdCAgYCbQgZCbiABbQhkBKh2AAQggAAgggFg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AW1crMgvggHkQibgZhdiAQhch+AZibQAYicB/hdQCAhbCbAYMAvgAHlQCbAYBcB/QBdCAgYCbQgZCbiABcQhkBKh2AAQggAAgggGg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AW1c6MgvggHkQibgZhdiAQhch/AZibQAYibB/hdQCAhcCbAZMAvgAHkQCbAZBcB+QBdCBgYCbQgZCbiABbQhkBKh2AAQggAAgggFg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AW1dDMgvggHkQibgZhdiAQhch/AZibQAYibB/hdQCAhbCbAYMAvgAHlQCbAYBcB/QBdCAgYCbQgZCbiABcQhkBJh2AAQggAAgggFg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AW1dGMgvggHkQibgZhdiAQhch+AZibQAYibB/heQCAhbCbAYMAvgAHlQCbAZBcB+QBdCAgZCbQgYCbiABcQhlBKh1AAQggAAgggGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-186.5162,y:173.6157}).wait(1).to({graphics:mask_1_graphics_45,x:-182.4318,y:173.938}).wait(1).to({graphics:mask_1_graphics_46,x:-170.5786,y:174.872}).wait(1).to({graphics:mask_1_graphics_47,x:-152.1168,y:176.3265}).wait(1).to({graphics:mask_1_graphics_48,x:-128.8536,y:178.1595}).wait(1).to({graphics:mask_1_graphics_49,x:-103.0662,y:180.1912}).wait(1).to({graphics:mask_1_graphics_50,x:-77.2787,y:182.223}).wait(1).to({graphics:mask_1_graphics_51,x:-54.0155,y:184.0559}).wait(1).to({graphics:mask_1_graphics_52,x:-35.5537,y:185.5105}).wait(1).to({graphics:mask_1_graphics_53,x:-23.7005,y:186.4444}).wait(1).to({graphics:mask_1_graphics_54,x:-19.6162,y:186.7657}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(55,322.95,1.28,1.28,-6.4876,0,0,57.1,16.3);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AxCV0QiQg+g5iSQg6iSA+iRQBAiQCSg6MAszgRoQCSg5CQA+QCRA/A6CSQA5CThACPQg9CQiTA6MgszARpQhFAchGAAQhMAAhMgig");
	var mask_2_graphics_39 = new cjs.Graphics().p("AxrWEQiPg+g6iSQg5iSA9iRQBAiQCTg6MAszgRoQCSg5CPA+QCSA/A5CSQA6CThACPQg+CQiSA6MgszARpQhGAchFAAQhNAAhMgig");
	var mask_2_graphics_40 = new cjs.Graphics().p("AzdWxQiPg+g6iSQg5iSA+iRQBAiQCSg6MAszgRoQCSg6CPA/QCSA/A5CSQA6CThACOQg+CRiSA6MgszARpQhFAbhGAAQhMAAhNghg");
	var mask_2_graphics_41 = new cjs.Graphics().p("A2BXyQiPg+g6iSQg5iTA9iRQBAiPCSg6MAszgRoQCTg6CPA/QCSA/A5CSQA6CRhACQQg+CRiSA6MgszARpQhGAbhFAAQhNAAhMghg");
	var mask_2_graphics_42 = new cjs.Graphics().p("A4xY6QiQg+g5iSQg6iTA+iRQBAiPCSg6MAszgRoQCSg6CQA/QCRA/A6CSQA5CRhACQQg9CRiTA6MgszARpQhFAbhGAAQhMAAhMghg");
	var mask_2_graphics_43 = new cjs.Graphics().p("A4xZ7QiQg+g5iTQg6iSA+iRQBAiQCSg5MAszgRoQCSg6CQA+QCRBAA6CRQA5CShACQQg9CRiTA6MgszARpQhFAbhGAAQhMAAhMghg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A4xaoQiQg+g5iTQg6iSA+iRQBAiQCSg5MAszgRoQCSg6CQA+QCRBAA6CRQA5CShACQQg9CRiTA6MgszARpQhFAbhGAAQhMAAhMghg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A4xa4QiQg+g5iTQg6iSA+iRQBAiQCSg5MAszgRoQCSg6CQA+QCRBAA6CRQA5CShACQQg9CRiTA6MgszARpQhFAbhGAAQhMAAhMghg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:231.0035,y:142.9565}).wait(1).to({graphics:mask_2_graphics_39,x:226.9445,y:144.5583}).wait(1).to({graphics:mask_2_graphics_40,x:215.5714,y:149.0465}).wait(1).to({graphics:mask_2_graphics_41,x:199.1366,y:155.5322}).wait(1).to({graphics:mask_2_graphics_42,x:180.2908,y:162.7307}).wait(1).to({graphics:mask_2_graphics_43,x:147.4214,y:169.2164}).wait(1).to({graphics:mask_2_graphics_44,x:124.675,y:173.7046}).wait(1).to({graphics:mask_2_graphics_45,x:116.5569,y:175.3065}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(54.2,280.8,1.28,1.28,-6.4876,0,0,60.2,16.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AXXVKMgv6gE5QicgQhkh7Qhjh5AQidQAQicB5hkQB7hjCcAQMAv6AE5QCcAQBjB5QBkB7gQCdQgQCch7BiQhoBXiDAAQgVAAgVgCg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AXXVNMgv6gE5QicgQhkh7Qhjh5AQidQAQicB5hlQB7hiCcAQMAv6AE5QCcAQBjB5QBkB7gQCcQgQCdh7BiQhoBXiDAAQgVAAgVgCg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AXXVVMgv6gE5QicgQhkh7Qhjh6AQicQAQicB5hlQB7hiCcAQMAv6AE5QCcAQBjB5QBkB7gQCcQgQCdh7BiQhoBXiDAAQgVAAgVgCg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AXXVhMgv6gE5QicgQhkh7Qhjh5AQidQAQicB5hlQB7hiCcAQMAv6AE5QCcAQBjB5QBkB7gQCcQgQCdh7BiQhoBXiDAAQgVAAgVgCg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AXXVwMgv6gE5QicgQhkh7Qhjh6AQicQAQicB5hlQB7hiCcAQMAv6AE5QCcAQBjB5QBkB7gQCcQgQCdh7BiQhoBXiDAAQgVAAgVgCg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AXXV/Mgv6gE4QicgQhkh7Qhjh6AQicQAQicB5hlQB7hiCcAQMAv6AE5QCcAQBjB5QBkB7gQCcQgQCch7BjQhoBXiDAAQgVAAgVgDg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AXXWOMgv6gE5QicgQhkh7Qhjh5AQicQAQicB5hlQB7hiCcAQMAv6AE4QCcAQBjB6QBkB7gQCcQgQCch7BjQhoBXiDAAQgVAAgVgDg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AXXWaMgv6gE4QicgQhkh7Qhjh6AQicQAQicB5hlQB7hiCcAQMAv6AE5QCcAQBjB5QBkB7gQCcQgQCch7BjQhoBXiDAAQgVAAgVgDg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AXXWiMgv6gE5QicgPhkh8Qhjh5AQicQAQicB5hlQB7hiCcAQMAv6AE5QCcAPBjB6QBkB7gQCcQgQCch7BjQhoBXiDAAQgVAAgVgDg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AXXWlMgv6gE5QicgQhkh7Qhjh5AQicQAQidB5hkQB7hjCcAQMAv6AE5QCcAQBjB5QBkB7gQCdQgQCch7BjQhoBWiDAAQgVAAgVgCg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-189.1637,y:135.6092}).wait(1).to({graphics:mask_3_graphics_32,x:-184.0903,y:135.885}).wait(1).to({graphics:mask_3_graphics_33,x:-169.4822,y:136.6773}).wait(1).to({graphics:mask_3_graphics_34,x:-147.1012,y:137.8911}).wait(1).to({graphics:mask_3_graphics_35,x:-119.6468,y:139.3801}).wait(1).to({graphics:mask_3_graphics_36,x:-90.4305,y:140.9646}).wait(1).to({graphics:mask_3_graphics_37,x:-62.9762,y:142.4536}).wait(1).to({graphics:mask_3_graphics_38,x:-40.5952,y:143.6675}).wait(1).to({graphics:mask_3_graphics_39,x:-25.987,y:144.4597}).wait(1).to({graphics:mask_3_graphics_40,x:-20.9137,y:144.7342}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(50.8,243.25,1.28,1.28,-6.4876,0,0,59.5,13.3);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("AyyQjQiNhIgxiYQgwiYBIiPQBKiNCYgxMAuigO5QCYgxCNBJQCPBJAxCYQAwCYhKCOQhICNiYAxMguiAO6Qg8AUg7AAQhaAAhWgtg");
	var mask_4_graphics_20 = new cjs.Graphics().p("Ay2QlQiNhJgxiYQgxiYBIiOQBLiOCXgwMAuigO6QCYgwCNBIQCPBKAxCYQAxCYhLCNQhICOiXAxMguiAO6Qg9ATg7AAQhZAAhWgsg");
	var mask_4_graphics_21 = new cjs.Graphics().p("AzFQqQiNhJgxiYQgwiYBIiOQBKiOCYgwMAuhgO5QCYgxCNBIQCPBKAwCYQAxCYhKCNQhICOiYAxMguhAO6Qg8ATg7AAQhaAAhWgsg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AzhQzQiNhJgxiXQgxiYBIiPQBLiNCXgxMAuggO4QCYgxCNBJQCPBJAwCYQAxCYhKCNQhICOiYAwMgugAO6Qg8ATg7AAQhZAAhWgsg");
	var mask_4_graphics_23 = new cjs.Graphics().p("A0QRCQiNhIgwiYQgxiXBIiPQBKiNCYgxMAudgO4QCYgwCMBIQCPBKAxCYQAxCXhLCOQhICNiXAxMgudAO4Qg9AUg7AAQhZAAhWgtg");
	var mask_4_graphics_24 = new cjs.Graphics().p("A1XRaQiNhJgwiXQgxiXBIiPQBKiNCXgwMAuagO3QCXgxCNBJQCPBJAwCYQAxCXhKCNQhICOiXAwMguaAO4Qg8ATg7AAQhZAAhWgsg");
	var mask_4_graphics_25 = new cjs.Graphics().p("A29R7QiMhIgwiXQgxiXBIiOQBKiNCXgxMAuUgO1QCYgwCMBIQCPBKAwCXQAwCXhKCMQhHCOiXAwMguVAO2Qg8ATg7AAQhZAAhWgsg");
	var mask_4_graphics_26 = new cjs.Graphics().p("A47SlQiNhIgwiXQgwiXBHiNQBKiNCXgwMAuOgOzQCXgxCMBJQCOBJAwCXQAxCWhKCMQhICOiWAwMguOAO0Qg8ATg7AAQhZAAhVgsg");
	var mask_4_graphics_27 = new cjs.Graphics().p("A5zTQQiMhIgwiXQgwiWBHiOQBKiMCWgwMAuIgOxQCWgwCMBIQCOBJAwCXQAwCWhJCLQhICOiWAwMguHAOyQg8ATg7AAQhYAAhWgsg");
	var mask_4_graphics_28 = new cjs.Graphics().p("A5wT0QiLhIgwiWQgwiWBHiOQBJiMCWgwMAuCgOvQCWgwCMBIQCOBJAwCWQAwCVhKCMQhHCOiWAwMguCAOwQg8ATg6AAQhYAAhWgsg");
	var mask_4_graphics_29 = new cjs.Graphics().p("A5tUPQiMhHgwiXQgwiWBHiMQBKiMCWgwMAt9gOuQCWgwCMBIQCNBJAwCWQAwCVhJCLQhHCNiWAwMgt+AOvQg8ATg6AAQhYAAhVgsg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A5sUjQiLhHgwiWQgwiWBHiNQBKiMCVgwMAt7gOsQCWgwCLBHQCNBJAwCWQAwCVhJCMQhHCMiWAwMgt6AOuQg8ATg6AAQhYAAhWgsg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A5qUyQiLhIgwiWQgwiVBHiNQBJiMCWgwMAt4gOsQCWgvCLBHQCNBJAwCWQAwCUhKCMQhHCNiVAvMgt4AOtQg8ATg6AAQhYAAhVgrg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A5qU7QiKhHgwiWQgwiVBHiNQBJiMCVgwMAt3gOrQCWgwCLBIQCNBIAwCWQAwCVhJCLQhHCNiWAwMgt3AOsQg7ATg6AAQhYAAhWgsg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:233.9896,y:110.3695}).wait(1).to({graphics:mask_4_graphics_20,x:233.5293,y:110.5129}).wait(1).to({graphics:mask_4_graphics_21,x:231.9707,y:110.9964}).wait(1).to({graphics:mask_4_graphics_22,x:228.966,y:111.9287}).wait(1).to({graphics:mask_4_graphics_23,x:224.0158,y:113.4646}).wait(1).to({graphics:mask_4_graphics_24,x:216.4578,y:115.8096}).wait(1).to({graphics:mask_4_graphics_25,x:205.7102,y:119.1442}).wait(1).to({graphics:mask_4_graphics_26,x:192.2537,y:123.3193}).wait(1).to({graphics:mask_4_graphics_27,x:171.0993,y:127.5824}).wait(1).to({graphics:mask_4_graphics_28,x:148.2905,y:131.1753}).wait(1).to({graphics:mask_4_graphics_29,x:130.9388,y:133.9086}).wait(1).to({graphics:mask_4_graphics_30,x:118.2448,y:135.9082}).wait(1).to({graphics:mask_4_graphics_31,x:109.148,y:137.3412}).wait(1).to({graphics:mask_4_graphics_32,x:102.9671,y:138.314}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(51.6,209.25,1.28,1.28,-6.4876,0,0,63.1,13.3);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83.3,140.6,266.7,318.9);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-18,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.8,143.7,27.6), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_42 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(42).call(this.frame_42).wait(1));

	// Layer_6
	this.text = new cjs.Text("0", "22px 'Segoe Pro Semibold'", "#505050");
	this.text.textAlign = "center";
	this.text.lineHeight = 32;
	this.text.lineWidth = 36;
	this.text.parent = this;
	this.text.setTransform(206.6509,145.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(10).to({text:"2"},0).wait(1).to({text:"5"},0).wait(1).to({text:"8"},0).wait(1).to({text:"13"},0).wait(1).to({text:"19"},0).wait(1).to({text:"26"},0).wait(1).to({text:"34"},0).wait(1).to({text:"43"},0).wait(1).to({text:"52"},0).wait(1).to({text:"61"},0).wait(1).to({text:"78"},0).wait(1).to({text:"93"},0).wait(1).to({text:"100"},0).wait(1).to({text:"106"},0).wait(1).to({text:"112"},0).wait(1).to({text:"117"},0).wait(1).to({text:"121"},0).wait(1).to({text:"125"},0).wait(1).to({text:"128"},0).wait(1).to({text:"131"},0).wait(2).to({text:"133"},0).wait(2).to({text:"135"},0).wait(2).to({text:"138"},0).wait(2).to({text:"139"},0).wait(6));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_2 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_3 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_4 = new cjs.Graphics().p("ACeQwQjgjWgIk2IAAgFIXYglIAAAFQAIE2jVDhQjWDgk3AIIgVAAQkoAAjZjOg");
	var mask_graphics_5 = new cjs.Graphics().p("ACcQvQjfjWgHk2IAAgFIXYgjIAAAFQAIE2jWDhQjXDgk2AHIgUAAQkpAAjajPg");
	var mask_graphics_6 = new cjs.Graphics().p("ACaQtQjejXgGk2IAAgFIXYgdIABAFQAFE2jWDgQjYDfk2AGIgRAAQkrAAjajRg");
	var mask_graphics_7 = new cjs.Graphics().p("ACXQqQjdjZgEk2IAAgFIXZgTIAAAFQAEE2jZDfQjYDdk3AEIgLAAQkvAAjajUg");
	var mask_graphics_8 = new cjs.Graphics().p("ACSQlQjbjbgBk2IAAgFIXZgFIAAAFQABE2jbDdQjbDbk2ABIgDAAQk0AAjbjZg");
	var mask_graphics_9 = new cjs.Graphics().p("AKaT+Qk2gDjZjdQjZjeAEk2IAAgFIXZAPIAAAFQgEE2jdDaQjaDVkxAAIgJAAg");
	var mask_graphics_10 = new cjs.Graphics().p("AKNT+Qk2gJjWjhQjUjhAJk3IAAgFIXYAqIAAAFQgIE3jhDVQjZDMknAAIgYAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AJ8T9Qk2gPjQjmQjPjnAQk2IAAgFIXXBMIAAAFQgQE2jmDQQjWDBkbAAIgrgBg");
	var mask_graphics_12 = new cjs.Graphics().p("AJnT8Qk1gZjJjsQjJjsAZk1IAAgFIXUB3IAAAFQgZE1jrDKQjTCykMAAQghAAgigCg");
	var mask_graphics_13 = new cjs.Graphics().p("AJOT5Qk0gjjBjzQjAjzAjk0IABgFIXPCqIAAAFQgkE1jyDBQjOCjj8AAQguAAgwgGg");
	var mask_graphics_14 = new cjs.Graphics().p("AIxT1Qkygwi3j7Qi2j7AxkzIAAgFIXHDpIgBAFQgwEzj6C3QjHCQjpAAQg+AAhAgKg");
	var mask_graphics_15 = new cjs.Graphics().p("AIQTuQkwg/iqkEQipkDA/kwIABgFIW6ExIgBAFQhAEwkDCqQi9B8jUAAQhQAAhSgRg");
	var mask_graphics_16 = new cjs.Graphics().p("AHrTjQkshQibkNQiakNBRksIABgEIWmGFIgBAFQhREskNCbQiwBli+AAQhjAAhngcg");
	var mask_graphics_17 = new cjs.Graphics().p("AHCTVQklhliJkWQiIkXBlklIABgFIWJHlIgCAEQhkEmkXCJQigBOilAAQh6AAh9gqg");
	var mask_graphics_18 = new cjs.Graphics().p("AGXTAQkdh6hzkgQhzkgB6keIACgEIVgJPIgBAEQh7EekgBzQiLA3iLAAQiUAAiTg/g");
	var mask_graphics_19 = new cjs.Graphics().p("AFqSkQkRiShZkpQhakpCRkSIADgEIUpLDIgDAEQiSESkpBaQhxAihtAAQizAAiqhbg");
	var mask_graphics_20 = new cjs.Graphics().p("AE/R/QkCisg9kwQg8kwCrkDIADgEITeM/IgDAFQisECkwA9QhPAQhMAAQjYAAi/iAg");
	var mask_graphics_21 = new cjs.Graphics().p("AEWRPQjujHgck1Qgbk1DGjuIADgEIR+PBIgDAEQjIDuk0AcQglADglAAQkIAAjRivg");
	var mask_graphics_22 = new cjs.Graphics().p("AL9T9Qk2gKjUjiQjVjiAKk2QAJk2DijUIAEgDIQCRDIgEADQjYDMkmAAIgagBg");
	var mask_graphics_23 = new cjs.Graphics().p("ALGT1Qkzgvi4j7Qi3j5AukzQAvkzD6i3IAEgDIN4S2IgEADQjICTjsAAQg7AAg+gJg");
	var mask_graphics_24 = new cjs.Graphics().p("AKYTjQkrhPickNQickMBPksQBQksEMibIAEgCILxUOIgFADQiyBnjAAAQhhAAhlgbg");
	var mask_graphics_25 = new cjs.Graphics().p("AJzTNQkihsiCkbQiBkZBskjQBskiEaiBIAFgDIJwVRIgFADQiaBGicAAQiDAAiEgxg");
	var mask_graphics_26 = new cjs.Graphics().p("AJVS0QkYiFhokkQhpkkCFkZQCEkXElhpIAFgCIH4WCIgFACQiBAuh/AAQigAAidhKg");
	var mask_graphics_27 = new cjs.Graphics().p("AI+SaQkNiahSksQhSkrCZkNQCakNErhSIAFgBIGMWjIgFACQhoAchlAAQi8AAiwhjg");
	var mask_graphics_28 = new cjs.Graphics().p("AIsSAQkDisg+kwQg+kwCrkCQCrkCExg+IAFgBIErW6IgFABQhRARhOAAQjWAAi+h9g");
	var mask_graphics_29 = new cjs.Graphics().p("AIeRnQj4i6gtkzQgskzC5j5QC6j3EzgtIAFAAIDXXJIgFABQg8AJg5AAQjvAAjIiWg");
	var mask_graphics_30 = new cjs.Graphics().p("AITRQQjvjGgdk1Qgdk0DFjwQDGjuE1gdIAFAAICNXSIgFAAQgoAEgmAAQkGAAjQisg");
	var mask_graphics_31 = new cjs.Graphics().p("AILQ8QjmjQgRk2QgQk2DQjmQDPjmE2gQIAFAAIBPXXIgFAAIgtABQkaAAjWjAg");
	var mask_graphics_32 = new cjs.Graphics().p("AIFQqQjfjYgFk2QgGk2DXjfQDYjfE2gFIAFAAIAbXZIgFAAIgQAAQksAAjajSg");
	var mask_graphics_33 = new cjs.Graphics().p("AQIT8Qk3gEjZjdQjYjeADk3QADk2DejYQDejZE2AEIAFAAIgQXZIgFAAg");
	var mask_graphics_34 = new cjs.Graphics().p("APuT7Qk2gKjUjiQjUjjALk3QAKk1DjjTQDijUE3AKIAFAAIgzXZIgFgBg");
	var mask_graphics_35 = new cjs.Graphics().p("APaT7Qk2gQjQjmQjPjnAQk2QAQk1DmjPQDmjQE2AQIAFAAIhNXXIgFAAg");
	var mask_graphics_36 = new cjs.Graphics().p("APLT7Qk2gVjNjoQjMjqAUk1QAVk2DojMQDqjME1AUIAFAAIhhXWIgFAAg");
	var mask_graphics_37 = new cjs.Graphics().p("APAT6Qk1gXjLjrQjKjrAXk1QAXk2DrjJQDrjLE2AYIAFAAIhwXVIgFgBg");
	var mask_graphics_38 = new cjs.Graphics().p("AO5T6Qk1gZjJjsQjJjtAZk1QAZk1DsjIQDtjJE1AZIAFAAIh5XVIgFgBg");
	var mask_graphics_39 = new cjs.Graphics().p("AO1T6Qk2gajIjtQjHjtAak2QAak1DtjHQDujIE1AaIAFABIh/XTIgFAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AOzT6Qk2gbjHjtQjIjuAbk1QAbk1DujHQDtjHE2AbIAFAAIiCXTIgFAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AOyT6Qk2gbjHjuQjHjuAbk1QAbk1DujGQDujIE1AcIAFAAIiDXTIgFAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AOxT6Qk1gbjHjuQjHjuAbk1QAbk1DujGQDtjIE2AcIAFAAIiEXTIgFAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:142.2699,y:127.8343}).wait(2).to({graphics:mask_graphics_2,x:142.2699,y:127.8343}).wait(1).to({graphics:mask_graphics_3,x:142.2704,y:127.8349}).wait(1).to({graphics:mask_graphics_4,x:142.2702,y:127.8348}).wait(1).to({graphics:mask_graphics_5,x:142.2695,y:127.8345}).wait(1).to({graphics:mask_graphics_6,x:142.2682,y:127.834}).wait(1).to({graphics:mask_graphics_7,x:142.2662,y:127.8333}).wait(1).to({graphics:mask_graphics_8,x:142.2637,y:127.8327}).wait(1).to({graphics:mask_graphics_9,x:142.2616,y:127.8328}).wait(1).to({graphics:mask_graphics_10,x:142.2496,y:127.8346}).wait(1).to({graphics:mask_graphics_11,x:142.2169,y:127.8391}).wait(1).to({graphics:mask_graphics_12,x:142.1487,y:127.8474}).wait(1).to({graphics:mask_graphics_13,x:142.0242,y:127.8603}).wait(1).to({graphics:mask_graphics_14,x:141.8153,y:127.8778}).wait(1).to({graphics:mask_graphics_15,x:141.4854,y:127.8985}).wait(1).to({graphics:mask_graphics_16,x:140.9878,y:127.9189}).wait(1).to({graphics:mask_graphics_17,x:140.2651,y:127.9332}).wait(1).to({graphics:mask_graphics_18,x:139.2483,y:127.934}).wait(1).to({graphics:mask_graphics_19,x:137.8571,y:127.9136}).wait(1).to({graphics:mask_graphics_20,x:136.0012,y:127.8686}).wait(1).to({graphics:mask_graphics_21,x:133.5835,y:127.8092}).wait(1).to({graphics:mask_graphics_22,x:130.5055,y:127.774}).wait(1).to({graphics:mask_graphics_23,x:127.0581,y:127.7881}).wait(1).to({graphics:mask_graphics_24,x:123.6803,y:127.8065}).wait(1).to({graphics:mask_graphics_25,x:120.4703,y:127.8041}).wait(1).to({graphics:mask_graphics_26,x:117.4932,y:127.7796}).wait(1).to({graphics:mask_graphics_27,x:114.7879,y:127.7409}).wait(1).to({graphics:mask_graphics_28,x:112.3729,y:127.6971}).wait(1).to({graphics:mask_graphics_29,x:110.2524,y:127.656}).wait(1).to({graphics:mask_graphics_30,x:108.4199,y:127.6222}).wait(1).to({graphics:mask_graphics_31,x:106.8618,y:127.5979}).wait(1).to({graphics:mask_graphics_32,x:105.56,y:127.5828}).wait(1).to({graphics:mask_graphics_33,x:105.3227,y:127.5755}).wait(1).to({graphics:mask_graphics_34,x:106.1797,y:127.5566}).wait(1).to({graphics:mask_graphics_35,x:106.8466,y:127.5283}).wait(1).to({graphics:mask_graphics_36,x:107.3474,y:127.4993}).wait(1).to({graphics:mask_graphics_37,x:107.706,y:127.4744}).wait(1).to({graphics:mask_graphics_38,x:107.9462,y:127.4558}).wait(1).to({graphics:mask_graphics_39,x:108.0919,y:127.4437}).wait(1).to({graphics:mask_graphics_40,x:108.1667,y:127.4373}).wait(1).to({graphics:mask_graphics_41,x:108.1942,y:127.4349}).wait(1).to({graphics:mask_graphics_42,x:108.1732,y:127.4316}).wait(1));

	// green_chart
	this.instance = new lib.green_bar();
	this.instance.setTransform(209.7,179.85,1,1,0,0,0,65.5,65.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(43));

	// blank_chart
	this.instance_1 = new lib.blank_chart();
	this.instance_1.setTransform(209.7,146.85,1,1,0,0,0,65.5,32.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(43));

	// Layer_1
	this.instance_2 = new lib.popup1();
	this.instance_2.setTransform(97.6,87.65,0.3957,0.3957);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(43));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(97.6,87.7,230.70000000000002,140.8);


(lib.cta_arrow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// Layer_5 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgaDEQgJgJgHgQQgGgOgCgMQgCgNAFgCIA+gfQAEgCAIAJQAJAJAGAPQAHAPACAMQACANgEACIg/AeIgBABQgFAAgGgHg");
	var mask_graphics_24 = new cjs.Graphics().p("AgaDEQgJgJgHgQQgGgOgCgMQgCgNAFgCIA+gfQAEgCAIAJQAJAJAGAPQAHAPACAMQACANgEACIg/AeIgBABQgFAAgGgHg");
	var mask_graphics_25 = new cjs.Graphics().p("AglDEQgJgJgHgPQgHgPgBgMQgBgNAGgDIBPgnQAGgCAJAIQAJAJAHAPQAHAPABAMQABANgGADIhPAmIgDABQgFAAgHgGg");
	var mask_graphics_26 = new cjs.Graphics().p("AgvDEQgKgIgHgQQgHgOAAgNQAAgOAHgDIBfguQAHgDAKAIQAKAIAHAPQAHAPAAANQAAANgHADIhfAuIgFABQgFAAgHgFg");
	var mask_graphics_27 = new cjs.Graphics().p("Ag5DEQgKgIgIgPQgGgPAAgNQABgOAIgEIBvg1QAIgEALAIQAKAIAHAPQAHAPAAANQgBAOgIADIhvA2IgFABQgGAAgIgFg");
	var mask_graphics_28 = new cjs.Graphics().p("AhBDEQgMgIgHgPQgHgPACgNQABgOAJgFIB9g7QAJgEALAHQAMAHAHAPQAHAPgCAOQgBAOgJAEIh9A8QgDABgEAAQgGAAgHgEg");
	var mask_graphics_29 = new cjs.Graphics().p("AhJDEQgMgHgIgQQgGgOACgPQABgOALgEICJhCQAKgFAMAHQANAHAGAPQAHAPgCAOQgBAPgLAEIiJBCQgEACgEAAQgHAAgHgEg");
	var mask_graphics_30 = new cjs.Graphics().p("AhRDDQgMgGgIgQQgGgOACgPQADgOALgFICVhHQALgFANAGQAMAHAHAPQAHAPgCAPQgDAOgLAFIiVBHQgFACgFAAQgGAAgIgEg");
	var mask_graphics_31 = new cjs.Graphics().p("AhXDDQgOgGgHgPQgHgPAEgPQADgOAMgGICghMQALgFANAGQAOAHAHAPQAHAPgEAOQgDAPgLAFIigBMQgGADgFAAQgHAAgHgEg");
	var mask_graphics_32 = new cjs.Graphics().p("AhdDDQgOgGgHgPQgHgPAEgPQADgPANgGICphQQAMgGAOAHQAOAGAHAPQAHAPgEAPQgDAPgMAFIiqBRQgGADgGAAQgHAAgHgEg");
	var mask_graphics_33 = new cjs.Graphics().p("AhiDDQgPgGgHgPQgHgPAEgPQAEgPAOgGICyhUQAMgGAOAGQAPAGAHAPQAHAPgEAPQgEAPgNAGIiyBUQgHADgGAAQgHAAgHgDg");
	var mask_graphics_34 = new cjs.Graphics().p("AhnDDQgPgGgHgPQgHgPAFgPQAEgPAOgHIC5hXQANgGAPAFQAPAGAHAPQAHAPgFAPQgEAQgOAGIi5BYQgHADgHAAQgHAAgHgDg");
	var mask_graphics_35 = new cjs.Graphics().p("AhrDDQgPgGgHgPQgHgOAFgQQAFgPAOgHIC/hbQAOgGAPAGQAPAGAHAOQAHAPgFAQQgFAPgOAHIi/BaQgHAEgIAAQgHAAgHgDg");
	var mask_graphics_36 = new cjs.Graphics().p("AhuDDQgPgFgHgQQgHgOAFgQQAFgPAOgHIDFhdQAOgHAPAGQAPAFAHAPQAHAPgFAQQgFAPgOAHIjEBdQgIAEgIAAQgHAAgHgDg");
	var mask_graphics_37 = new cjs.Graphics().p("AhwDDQgQgFgHgQQgHgOAFgQQAFgQAQgHIDIheQAOgHAPAGQAQAFAHAPQAHAPgFAQQgFAPgPAHIjIBfQgIAEgJAAQgGAAgHgDg");
	var mask_graphics_38 = new cjs.Graphics().p("AhyDDQgQgFgHgQQgHgOAGgQQAFgQAPgHIDLhgQAOgHAQAGQAQAFAHAPQAHAPgGAQQgFAQgPAGIjLBhQgIADgIAAQgHAAgHgCg");
	var mask_graphics_39 = new cjs.Graphics().p("AhzDDQgQgFgHgQQgHgOAGgQQAFgQAPgHIDNhhQAOgGAQAFQAQAFAHAPQAHAPgGAQQgFAQgPAHIjMBgQgJAEgJAAQgGAAgHgCg");
	var mask_graphics_40 = new cjs.Graphics().p("AhzDEQgQgGgHgPQgHgPAFgPQAGgQAPgHIDNhiQAPgGAPAFQAQAFAHAPQAHAPgFAQQgGAQgPAHIjNBhQgIAEgJAAQgHAAgGgCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-4.8696,y:20.2831}).wait(24).to({graphics:mask_graphics_24,x:-4.8696,y:20.2831}).wait(1).to({graphics:mask_graphics_25,x:-3.4611,y:20.2081}).wait(1).to({graphics:mask_graphics_26,x:-2.1432,y:20.1404}).wait(1).to({graphics:mask_graphics_27,x:-0.9162,y:20.0794}).wait(1).to({graphics:mask_graphics_28,x:0.2198,y:20.0246}).wait(1).to({graphics:mask_graphics_29,x:1.2648,y:19.9756}).wait(1).to({graphics:mask_graphics_30,x:2.2189,y:19.9319}).wait(1).to({graphics:mask_graphics_31,x:3.0822,y:19.8932}).wait(1).to({graphics:mask_graphics_32,x:3.8546,y:19.8594}).wait(1).to({graphics:mask_graphics_33,x:4.5361,y:19.83}).wait(1).to({graphics:mask_graphics_34,x:5.1267,y:19.805}).wait(1).to({graphics:mask_graphics_35,x:5.6265,y:19.7841}).wait(1).to({graphics:mask_graphics_36,x:6.0354,y:19.7672}).wait(1).to({graphics:mask_graphics_37,x:6.3535,y:19.7542}).wait(1).to({graphics:mask_graphics_38,x:6.5807,y:19.7449}).wait(1).to({graphics:mask_graphics_39,x:6.717,y:19.7394}).wait(1).to({graphics:mask_graphics_40,x:6.6475,y:19.7919}).wait(5));

	// Layer_2 copy
	this.instance = new lib.pointer();
	this.instance.setTransform(7.2,22.85,1,1,0,0,0,12.8,10.7);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45));

	// Layer_5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgUA7QgNgBgBgFIgNhEQgBgFAKgFQALgGARgDQAOgDANABQAMACABAFIAOBDQABAFgLAGQgKAGgRADQgKACgJAAIgIgBg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AgUA7QgNgBgBgFIgNhEQgBgFAKgFQALgGARgDQAOgDANABQAMACABAFIAOBDQABAFgLAGQgKAGgRADQgKACgJAAIgIgBg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AgPBOQgMgDgCgHIgThhQgBgHAKgHQAKgIARgDQAPgDANADQAMADACAHIATBhQABAHgKAIQgLAHgQADIgPABIgNgBg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AgMBfQgNgEgBgJIgYh8QgCgJAKgJQAKgJARgDQAPgDANAFQANAEABAJIAYB8QACAJgKAIQgKAJgQADIgNABQgIAAgIgCg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AgJBuQgNgFgCgLIgdiUQgCgLAKgKQAKgKARgDQAQgDAMAGQANAFACALIAdCUQACAKgKAKQgKAKgQADIgMABQgIAAgJgDg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AgGB7QgOgGgCgMIghipQgCgNAKgLQAKgLAQgDQAQgDAMAHQAOAGACANIAhCpQACAMgKALQgKALgQADIgKABQgKAAgIgFg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AgECHQgOgIgCgNIgki7QgDgOAKgMQAJgMARgDQAQgDAMAHQAOAHACAPIAkC7QADANgKAMQgJAMgRADIgJABQgLAAgIgFg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AgCCQQgOgIgDgOIgnjLQgCgPAJgNQAJgNARgDQAQgDAMAJQAOAIADAPIAnDLQACAOgJANQgJANgRADIgIAAQgLAAgJgGg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AgBCYQgOgIgDgQIgpjXQgDgQAKgOQAJgNAQgDQAQgDANAJQAOAIADARIApDXQADAPgKAOQgJANgQADIgIABQgMAAgJgHg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AAACfQgOgKgDgQIgrjhQgDgRAJgOQAJgOARgDQAQgDANAJQAOAKADARIArDhQADAQgJAOQgKAOgQADIgIABQgLAAgKgHg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AAACjQgNgKgDgRIgsjoQgDgRAJgOQAJgOAQgEQAQgCANAJQAOAKADARIAsDoQADARgJAOQgJAPgQADIgHAAQgMAAgLgHg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AAACmQgNgKgDgRIgtjtQgDgRAJgPQAJgOARgDQAQgDANAJQAOAKADASIAtDsQADARgJAPQgJAOgQADIgIABQgMAAgLgHg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AABCmQgNgKgEgRIgtjuQgDgRAJgPQAJgOARgEQAPgDAOAKQANAKAEASIAtDuQADARgJAOQgJAPgQADIgIABQgMAAgKgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-4.8405,y:5.9812}).wait(16).to({graphics:mask_1_graphics_16,x:-4.8405,y:5.9812}).wait(1).to({graphics:mask_1_graphics_17,x:-4.685,y:7.9487}).wait(1).to({graphics:mask_1_graphics_18,x:-4.3495,y:9.7385}).wait(1).to({graphics:mask_1_graphics_19,x:-4.0494,y:11.344}).wait(1).to({graphics:mask_1_graphics_20,x:-3.7846,y:12.7625}).wait(1).to({graphics:mask_1_graphics_21,x:-3.5552,y:13.9929}).wait(1).to({graphics:mask_1_graphics_22,x:-3.361,y:15.0346}).wait(1).to({graphics:mask_1_graphics_23,x:-3.2022,y:15.8872}).wait(1).to({graphics:mask_1_graphics_24,x:-3.0787,y:16.5505}).wait(1).to({graphics:mask_1_graphics_25,x:-2.9904,y:17.0243}).wait(1).to({graphics:mask_1_graphics_26,x:-2.9375,y:17.3087}).wait(1).to({graphics:mask_1_graphics_27,x:-2.9787,y:17.3818}).wait(18));

	// Layer_2
	this.instance_1 = new lib.pointer();
	this.instance_1.setTransform(7.2,22.85,1,1,0,0,0,12.8,10.7);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(45));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhyGQIAAsfIAOAAQFFAADmDmQDmDlAAFHIAAANg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AhyGQIAAsfIAOAAQFFAADmDmQDmDlAAFHIAAANg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AhymPIAOAAQFFAADmDmQDmDlAAFGIAAANIsfABg");
	var mask_2_graphics_3 = new cjs.Graphics().p("Ah0mOIAOgBQFFAADnDlQDmDlABFGIAAANIsfACg");
	var mask_2_graphics_4 = new cjs.Graphics().p("Ah4mOIANgBQFFgCDpDkQDnDjADFGIAAANIsfAHg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AiBmOIAOAAQFFgHDrDiQDpDhAGFGIABANIsfAPg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AiOmOIANAAQFFgMDvDdQDtDdAMFGIAAANIsdAdg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AijmMIAOgBQFEgVD0DXQD0DXAUFFIABANIsdAyg");
	var mask_2_graphics_8 = new cjs.Graphics().p("Ai/mKIANgBQFEggD8DNQD7DPAgFDIACANIsbBPg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AjkmEIAOgCQFBgxEGDBQEFDCAwFCIACANIsVB2g");
	var mask_2_graphics_10 = new cjs.Graphics().p("AkQl7IANgCQE+hFERCwQERCxBEE+IADANIsNCog");
	var mask_2_graphics_11 = new cjs.Graphics().p("AlFlqIANgEQE4hdEdCaQEeCbBdE3IAEANIr9Dkg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AmBlQIANgFQEuh7EqB+QEsB/B7EtIAEAMIrjEtg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AnAkpIAMgGQEeidE3BbQE4BcCdEdIAGALIq8GAg");
	var mask_2_graphics_14 = new cjs.Graphics().p("An+juIALgIQEGjCFAAvQFCAxDCEGIAIALIqCHag");
	var mask_2_graphics_15 = new cjs.Graphics().p("AoyifIAJgJQDmjoFEgCQFFgBDoDmIAJAJIozI3g");
	var mask_2_graphics_16 = new cjs.Graphics().p("AovhMIAJgLQDEkFFCguQFBgtEEDEIALAIInhJ+g");
	var mask_2_graphics_17 = new cjs.Graphics().p("AoiAAIAHgLQClkaE6hSQE6hSEaClIALAHImUKwg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AoSBDIAGgMQCJknExhwQExhwEoCJIAMAGIlRLUg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AoBB9IAFgNQBykwEniJQEniHExByIANAEIkXLtg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AnxCsIAEgNQBek3EeibQEeiZE4BeIANAEIjnL9g");
	var mask_2_graphics_21 = new cjs.Graphics().p("AnjDRIADgNQBPk7EWioQEWioE9BPIAMADIjBMHg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AnYDuIADgOQBDk+EQiyQEPixE/BDIANACIikMOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AnQECIADgNQA6lAELi5QELi5FBA7IANACIiQMRg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AnKEQIACgNQA1lBEIi+QEHi+FCA1IANACIiCMUg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AnGEYIACgNQAxlBEGjBQEFjAFDAxIAMACIh5MVg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AnFEdIACgOQAwlBEFjDQEEjBFDAvIANACIh1MWg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AnEEeIACgNQAvlCEEjDQEEjCFDAvIANACIhzMWg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AnEEeIACgNQAvlCEEjDQEEjCFDAvIANACIhzMWg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:68.4756,y:4.1506}).wait(1).to({graphics:mask_2_graphics_1,x:68.4756,y:4.1506}).wait(1).to({graphics:mask_2_graphics_2,x:68.4756,y:4.1505}).wait(1).to({graphics:mask_2_graphics_3,x:68.4755,y:4.1498}).wait(1).to({graphics:mask_2_graphics_4,x:68.4744,y:4.1478}).wait(1).to({graphics:mask_2_graphics_5,x:68.4687,y:4.1434}).wait(1).to({graphics:mask_2_graphics_6,x:68.4494,y:4.1348}).wait(1).to({graphics:mask_2_graphics_7,x:68.3974,y:4.1196}).wait(1).to({graphics:mask_2_graphics_8,x:68.2787,y:4.0949}).wait(1).to({graphics:mask_2_graphics_9,x:68.0375,y:4.0591}).wait(1).to({graphics:mask_2_graphics_10,x:67.5894,y:4.0139}).wait(1).to({graphics:mask_2_graphics_11,x:66.8139,y:3.9679}).wait(1).to({graphics:mask_2_graphics_12,x:65.548,y:3.9379}).wait(1).to({graphics:mask_2_graphics_13,x:63.5836,y:3.9464}).wait(1).to({graphics:mask_2_graphics_14,x:60.6703,y:4.0056}).wait(1).to({graphics:mask_2_graphics_15,x:56.6974,y:4.0699}).wait(1).to({graphics:mask_2_graphics_16,x:49.2578,y:4.0817}).wait(1).to({graphics:mask_2_graphics_17,x:42.9182,y:4.0852}).wait(1).to({graphics:mask_2_graphics_18,x:37.7756,y:4.1121}).wait(1).to({graphics:mask_2_graphics_19,x:33.6975,y:4.1575}).wait(1).to({graphics:mask_2_graphics_20,x:30.5363,y:4.2091}).wait(1).to({graphics:mask_2_graphics_21,x:28.1473,y:4.2573}).wait(1).to({graphics:mask_2_graphics_22,x:26.398,y:4.2971}).wait(1).to({graphics:mask_2_graphics_23,x:25.1703,y:4.3268}).wait(1).to({graphics:mask_2_graphics_24,x:24.3598,y:4.3471}).wait(1).to({graphics:mask_2_graphics_25,x:23.8733,y:4.3594}).wait(1).to({graphics:mask_2_graphics_26,x:23.6249,y:4.3658}).wait(1).to({graphics:mask_2_graphics_27,x:23.5336,y:4.3681}).wait(1).to({graphics:mask_2_graphics_28,x:23.5283,y:4.3196}).wait(17));

	// Layer_1
	this.instance_2 = new lib.arc();
	this.instance_2.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.6,0,60,33.5);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pptLogo
	this.pptLogo = new lib.pptLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(58.6,33,1,1,0,0,0,58.6,33);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(190.1,435.25,1,1,0,0,0,120.2,154.4);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	// files
	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(233.2,155.5,1,1,0,0,0,213.8,157.9);

	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(204.35,167,1,1,0,0,0,217.5,176.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file2},{t:this.file1}]}).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(226.8,153.5,1,1,0,0,0,226.8,153.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x();
	this.instance.setTransform(38.35,20.5,0.4987,0.4987);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-12.2,-608,426.59999999999997,1399.9), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ag/GGQgFAAgFgEIgEgEIgpg8QgGgLgKgHQgJgGgQgBIl8AAIAAquIQ4AAIAAMLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:184.7,y:-15.025}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(183.45,40.75,0.5301,0.5301,0,0,0,205.6,150.2);

	var maskedShapeInstanceList = [this.ui];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(68,-44,226.10000000000002,305.4);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(143.2,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(76.35,569.55,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(81.6,569.95,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// CTA_Arrow
	this.CTA_Arrow = new lib.cta_arrow_1();
	this.CTA_Arrow.name = "CTA_Arrow";
	this.CTA_Arrow.setTransform(134.75,528.6,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.CTA_Arrow).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(83.65,251.15,1,1,0,0,0,180.4,22.3);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(144.25,236.35,1,1,0,0,0,33.5,177.5);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(254.8,296.9,1,1,0,0,0,159.5,-12.3);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(185.75,77.45,1.4753,1.4753,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,155,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(80.0011,300.0046,0.5333,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-28.8,-1.4,436.40000000000003,626.5), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							/*popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15*/
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		//mc.logo.visible = false;
		mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.anim.line1.play();}});
				
				this.tl1.to(mc.anim,{duration:1.5, x: "-=180", ease:Power3.easeInOut}, "+=.4");
				this.tl1.to(mc.grid,{duration:1.5, x: "-=285", ease:Power3.easeInOut}, "<");
		
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<");
		
				//icon
				this.tl1.from(mc.anim.ODIcon.outlines,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut}, ">+.1");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">-.1");
		
				//chart transition
						this.tl1.to(mc.anim, {duration:.6, y:"+=0", ease:Power2.easeInOut}, ">");
						this.tl1.to(mc.ui, {duration:.6, y:"+=75", ease:Power2.easeInOut}, ">");
		
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=75", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
				this.tl1.to(mc.anim,{duration:.4, y:"-=40", scale: .9, alpha:0, ease:Power4.easeIn}, "<");
				
				this.tl1.from(mc.ui.ui.file1,{duration:.6, x:"+=12", y:"-=47", scaleX:.35, scaleY:.35, ease:Power4.easeInOut, onComplete:function(){mc.ui.ui.file1.play(10);}}, ">+0.1");
		
		
				this.tl1.to([mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.1, alpha:0}, ">+.1");
				this.tl1.to(mc.anim, {duration:.1, y:"-=70"}, ">+.3");
		
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=10", y:"+=10", scaleX: .34, scaleY: .34, ease:Power3.easeInOut}, ">+.4");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"+=6", y:"+=10", alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"+=12", y:"-=47", scaleX:.37, scaleY:.37, ease:Power3.easeIn}, ">-1");
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
		
		
				this.tl1.from(mc.ui.ui.file2,{duration:.6, y:"+=7",x:"-=70", scaleX:.28, scaleY:.34, ease:Power4.easeInOut}, "<-.3");
				
				
				this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<-.5");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<-0");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=150", y:"-=150", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.1");
		
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
		
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"+=15", y:"+=43",scaleX: .4, scaleY: .4, ease:Power3.easeInOut}, ">+0.6");
				this.tl1.to(mc.ui.ui.pptLogo,{duration:1.2, scaleX: 1.1, scaleY: 1.1, ease:Power3.easeInOut}, ">-1.2");
				this.tl1.to(mc.anim,{duration:1.2, x:"+=40", y:"-=0", scaleX: .8, scaleY: .8, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"+=15", y:"+=43",scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				
				this.tl1.to(mc.ui.ui.file2,{duration:.7,  y:"+=5",x:"-=70", scaleX:.29, scaleY:.35, ease:Power3.easeInOut}, ">-1");
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.3");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
		
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta, 0.8, { scaleX:0, scaleY:0, ease:Power4.easeOut, onStart:function(){mc.CTA_Arrow.play();}}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ui.ad1,{duration:2.5, x:"-=270", y:"+=60",  ease:Power3.easeInOut, onStart:function(){mc.ui.ui.ad1.visible=true;}});
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
		
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(51.2,298.6,356.40000000000003,326.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622721971644", id:"M365_FY22Q1BTS_USA_160x600_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;