(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[632,908,137,21],[754,724,112,63],[632,724,120,124],[0,0,734,508],[0,510,630,420],[632,510,157,105],[0,932,628,419],[632,617,157,105],[632,850,155,56],[630,932,136,320]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.angledShadowSml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap58 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.cursor = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.laptop = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.LinkedIn_Screen = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.LinkedInEndFrameSml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Word_Editor_Simplified_Screen = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Word_Editor_Simplified_Screen_Sml = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.wordDropdown = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.wordPanel = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wordPanel_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.wordPanel();
	this.instance.setTransform(0,0,0.432,0.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordPanel_1, new cjs.Rectangle(0,0,58.8,138.3), null);


(lib.wordDropdown_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.wordDropdown();
	this.instance.setTransform(0,0,0.432,0.432);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordDropdown_1, new cjs.Rectangle(0,0,67,24.2), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.socialScreenEnd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.LinkedInEndFrameSml();
	this.instance.setTransform(0,0,1.8029,1.8029);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.socialScreenEnd, new cjs.Rectangle(0,0,283.1,189.3), null);


(lib.sml = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word_Editor_Simplified_Screen_Sml();
	this.instance.setTransform(0,0,1.7243,1.7243);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.sml, new cjs.Rectangle(0,0,270.7,181.1), null);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2195,21.2195,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6124,21.2195,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2195,6.6124,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6124,6.6124,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1557,14.0561,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.946,13.9111,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.485,13.9111,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.laptopSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.laptop();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.laptopSub, new cjs.Rectangle(0,0,367,254), null);


(lib.highlight_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AgNCGQlwggh6ATQg3AKgughQgtgggKg3QgJg2AgguQAhgtA3gKQCLgaGiAkQFxAgB/gTQA3gJAuAhQAtAgAJA3QAJA2ggAuQghAtg3AKQg8AKhrAAQiXAAj0gVg");
	this.shape.setTransform(66.1902,15.5585);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.highlight_sub, new cjs.Rectangle(0,0,132.4,31.1), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("AvCAAIeFAA");
	this.shape.setTransform(96.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,194.5,2), null);


(lib.editorCursor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.cursor();
	this.instance.setTransform(0,-10.45,0.3343,0.3343);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.editorCursor, new cjs.Rectangle(0,-10.4,40.1,41.4), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.dropdown1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Bitmap58();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.dropdown1, new cjs.Rectangle(0,0,56,31.5), null);


(lib.bg_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AotCHIAAkNIRbAAIAAENg");
	this.shape.setTransform(50.05,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-5.7,0,111.60000000000001,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.angledShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.angledShadowSml();
	this.instance.setTransform(11.6,0.15,1.3639,1.3639);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.angledShadow, new cjs.Rectangle(0,0,206.1,31.5), null);


(lib.wordScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlZCDIAAkFIKzAAIAAEFg");
	mask.setTransform(177.775,159.675);

	// Layer_4
	this.dropdown = new lib.wordDropdown_1();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(176.65,158.7,1,1,0,0,0,33.5,12.1);

	var maskedShapeInstanceList = [this.dropdown];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// Layer_3
	this.panel = new lib.wordPanel_1();
	this.panel.name = "panel";
	this.panel.setTransform(241.8,99.45,1,1,0,0,0,29.4,69.1);

	this.timeline.addTween(cjs.Tween.get(this.panel).wait(1));

	// Layer_2
	this.instance = new lib.Word_Editor_Simplified_Screen();
	this.instance.setTransform(0,0,0.4321,0.4321);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordScreen, new cjs.Rectangle(0,0,271.4,181.1), null);


(lib.socialScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ak9CtIAAlZIJ7AAIAAFZg");
	mask.setTransform(101.45,67.325);

	// Layer_3
	this.dropdown = new lib.dropdown1();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(73.75,50.7,0.8702,0.8702,0,0,0,0.1,0.1);

	var maskedShapeInstanceList = [this.dropdown];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// Layer_2
	this.instance = new lib.LinkedIn_Screen();
	this.instance.setTransform(0,0,0.4303,0.4303);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.socialScreen, new cjs.Rectangle(0,0,271.1,180.8), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.highlight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.highlight.cache(-140,-40,280,80,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.highlight = new lib.highlight_sub();
	this.highlight.name = "highlight";
	this.highlight.setTransform(52.7,2.1,1,1,0,0,0,66.2,15.6);

	this.timeline.addTween(cjs.Tween.get(this.highlight).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.highlight, new cjs.Rectangle(-13.5,-13.5,132.4,31.1), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-200,-10,400,20,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,193.5,1), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AlsHuQhhg9gahxQgbhxA9hjQA+hiBxgZMAijgIBQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BjhxAZMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_54 = new cjs.Graphics().p("AlvHuQhig9gahxQgahxA8hjQA+hiBxgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_55 = new cjs.Graphics().p("Al9HuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AaBxQAbBxg/BiQg8BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_56 = new cjs.Graphics().p("AmaHuQhig9gahxQgahxA9hjQA+hiBwgZMAijgIBQBxgaBiA8QBjA+AaBxQAbBxg/BiQg8BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_57 = new cjs.Graphics().p("AnNHuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AaBxQAbBxg+BiQg9BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_58 = new cjs.Graphics().p("AoSH8Qhhg9gbhxQgahwA9hjQA+hiBxgZMAijgICQBxgaBhA9QBjA+AbBxQAaBwg+BiQg9BihxAaMgijAICQghAIghAAQhMAAhGgsg");
	var mask_graphics_59 = new cjs.Graphics().p("ApUIMQhig9gahxQgahxA8hjQA/hiBwgaMAijgIAQBxgbBiA9QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhMAAhGgrg");
	var mask_graphics_60 = new cjs.Graphics().p("AqJIYQhig9gahxQgahxA9hjQA+hiBxgaMAijgIAQBwgaBiA9QBjA9AaBxQAbBxg/BiQg8BihxAaMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_61 = new cjs.Graphics().p("AqxIhQhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg9BihwAaMgijAICQgiAIggAAQhNAAhFgsg");
	var mask_graphics_62 = new cjs.Graphics().p("ArQIoQhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBwg+BiQg9BihwAbMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_63 = new cjs.Graphics().p("ArpIuQhhg9gbhxQgahxA9hjQA+hiBxgaMAijgIAQBxgaBhA9QBkA9AaBxQAaBxg+BiQg9BihxAaMgijAICQghAHggAAQhNAAhGgrg");
	var mask_graphics_64 = new cjs.Graphics().p("Ar8IyQhhg9gbhwQgahxA9hjQA+hiBxgaMAijgIBQBxgaBhA9QBkA+AaBxQAaBwg+BiQg9BihxAbMgijAIBQghAIggAAQhNAAhGgsg");
	var mask_graphics_65 = new cjs.Graphics().p("AsLI2Qhhg9gbhxQgahxA9hjQA+hiBxgaMAijgIAQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BihxAaMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_66 = new cjs.Graphics().p("AsWI4Qhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_67 = new cjs.Graphics().p("AsfI6Qhig8gahxQgahxA8hjQA+hiBxgaMAijgIAQBxgbBiA9QBjA+AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_68 = new cjs.Graphics().p("AsmI8Qhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg8BihxAaMgijAICQgiAIggAAQhMAAhGgsg");
	var mask_graphics_69 = new cjs.Graphics().p("AsrI9Qhig9gahwQgahxA8hjQA/hiBwgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBwg+BiQg8BihxAbMgijAIBQgiAIggAAQhMAAhGgsg");
	var mask_graphics_70 = new cjs.Graphics().p("AsuI+Qhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg9BihwAaMgijAICQgiAHggAAQhNAAhFgrg");
	var mask_graphics_71 = new cjs.Graphics().p("AswI+Qhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_72 = new cjs.Graphics().p("AswI+Qhig9gahxQgahxA8hjQA+hiBxgaMAijgIAQBxgaBiA9QBjA9AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:227.651,y:48.9317}).wait(1).to({graphics:mask_graphics_54,x:227.2796,y:49.1034}).wait(1).to({graphics:mask_graphics_55,x:225.9169,y:49.7334}).wait(1).to({graphics:mask_graphics_56,x:223.015,y:51.0749}).wait(1).to({graphics:mask_graphics_57,x:217.9249,y:53.4281}).wait(1).to({graphics:mask_graphics_58,x:211.0421,y:55.1619}).wait(1).to({graphics:mask_graphics_59,x:204.403,y:56.6965}).wait(1).to({graphics:mask_graphics_60,x:199.1193,y:57.9179}).wait(1).to({graphics:mask_graphics_61,x:195.0814,y:58.8512}).wait(1).to({graphics:mask_graphics_62,x:191.9736,y:59.5696}).wait(1).to({graphics:mask_graphics_63,x:189.5515,y:60.1295}).wait(1).to({graphics:mask_graphics_64,x:187.6486,y:60.5693}).wait(1).to({graphics:mask_graphics_65,x:186.1511,y:60.9155}).wait(1).to({graphics:mask_graphics_66,x:184.9786,y:61.1865}).wait(1).to({graphics:mask_graphics_67,x:184.0731,y:61.3958}).wait(1).to({graphics:mask_graphics_68,x:183.3911,y:61.5534}).wait(1).to({graphics:mask_graphics_69,x:182.8992,y:61.6671}).wait(1).to({graphics:mask_graphics_70,x:182.5714,y:61.7429}).wait(1).to({graphics:mask_graphics_71,x:182.3868,y:61.7856}).wait(1).to({graphics:mask_graphics_72,x:182.376,y:61.7226}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(158.5,85.75,0.9423,0.9423,8.9317,0,0,42.2,17.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_45 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_46 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_47 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_48 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_49 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_50 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_51 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_52 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_53 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_54 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-14.8503,y:-21.3471}).wait(1).to({graphics:mask_1_graphics_45,x:-12.0762,y:-20.0886}).wait(1).to({graphics:mask_1_graphics_46,x:-4.0254,y:-16.4364}).wait(1).to({graphics:mask_1_graphics_47,x:8.5139,y:-10.7478}).wait(1).to({graphics:mask_1_graphics_48,x:24.3145,y:-3.5798}).wait(1).to({graphics:mask_1_graphics_49,x:41.8296,y:4.3659}).wait(1).to({graphics:mask_1_graphics_50,x:59.3446,y:12.3117}).wait(1).to({graphics:mask_1_graphics_51,x:75.1452,y:19.4797}).wait(1).to({graphics:mask_1_graphics_52,x:87.6846,y:25.1682}).wait(1).to({graphics:mask_1_graphics_53,x:95.7353,y:28.8205}).wait(1).to({graphics:mask_1_graphics_54,x:98.0997,y:29.7529}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(149.25,52.65,0.9423,0.9423,8.9317,0,0,57.6,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AlOFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_39 = new cjs.Graphics().p("AluFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_40 = new cjs.Graphics().p("AnHFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_41 = new cjs.Graphics().p("ApJFRQhZhJgMhzQgMhzBIhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_42 = new cjs.Graphics().p("ArYFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhKBYQhIBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_43 = new cjs.Graphics().p("AtaFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_44 = new cjs.Graphics().p("AuzFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhKBYQhIBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_45 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_46 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_47 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_48 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_49 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_50 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_51 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_52 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_53 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_54 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_55 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_56 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_57 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_58 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_59 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_60 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_61 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_62 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_63 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_64 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_65 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_66 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_67 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_68 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_69 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_70 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_71 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_72 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:237.811,y:3.6926}).wait(1).to({graphics:mask_2_graphics_39,x:234.616,y:4.3817}).wait(1).to({graphics:mask_2_graphics_40,x:225.6604,y:6.3124}).wait(1).to({graphics:mask_2_graphics_41,x:212.7192,y:9.1024}).wait(1).to({graphics:mask_2_graphics_42,x:198.3555,y:12.1991}).wait(1).to({graphics:mask_2_graphics_43,x:185.4143,y:14.9891}).wait(1).to({graphics:mask_2_graphics_44,x:176.4587,y:16.9198}).wait(1).to({graphics:mask_2_graphics_45,x:173.311,y:17.3426}).wait(1).to({graphics:mask_2_graphics_46,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_47,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_48,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_49,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_50,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_51,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_52,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_53,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_54,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_55,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_56,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_57,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_58,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_59,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_60,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_61,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_62,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_63,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_64,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_65,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_66,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_67,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_68,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_69,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_70,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_71,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_72,x:173.311,y:17.3426}).wait(1));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(156.85,22.8,0.9423,0.9423,8.9317,0,0,60.6,16.6);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AO8KeMghCgM1QhsgqgvhrQguhqAqhsQAqhrBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBrhqAuQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-3.6977,y:-69.3836}).wait(1).to({graphics:mask_3_graphics_32,x:-0.2049,y:-68.2125}).wait(1).to({graphics:mask_3_graphics_33,x:9.8522,y:-64.2339}).wait(1).to({graphics:mask_3_graphics_34,x:25.2605,y:-58.1383}).wait(1).to({graphics:mask_3_graphics_35,x:44.1617,y:-50.661}).wait(1).to({graphics:mask_3_graphics_36,x:64.2759,y:-42.7038}).wait(1).to({graphics:mask_3_graphics_37,x:83.1771,y:-35.2265}).wait(1).to({graphics:mask_3_graphics_38,x:98.5854,y:-29.1309}).wait(1).to({graphics:mask_3_graphics_39,x:108.6425,y:-25.1523}).wait(1).to({graphics:mask_3_graphics_40,x:111.8523,y:-23.7442}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(161.75,-4.7,0.9423,0.9423,8.9317,0,0,59.9,12.9);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("Ak3EPQhahKgMh1QgLh0BKhbQBLhaB1gMMAjzgDgQB1gLBaBKQBcBLALB1QAMB1hMBZQhKBch1ALMgjzADgIgeACQhiAAhQhCg");
	var mask_4_graphics_20 = new cjs.Graphics().p("Ak6EQQhbhKgLh1QgLh0BKhcQBLhaB1gLMAjzgDgQB1gMBaBKQBbBMAMB0QALB1hLBaQhKBbh1AMMgjzADgIgeABQhjAAhPhBg");
	var mask_4_graphics_21 = new cjs.Graphics().p("AlGERQhahKgLh1QgMh0BKhbQBMhaB0gMMAjzgDgQB0gMBbBKQBbBMAMB0QALB1hLBaQhKBbh1ALMgjyADhIgfABQhiAAhQhBg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AlbEUQhbhKgLh1QgMh0BKhbQBMhaB0gMMAjxgDhQB1gMBaBKQBcBMALB0QAMB1hLBZQhKBch1ALMgjxADiIgfABQhiAAhPhBg");
	var mask_4_graphics_23 = new cjs.Graphics().p("Al/EZQhahKgMh1QgLh0BJhbQBMhaB0gMMAjvgDjQB1gLBaBKQBcBLALB0QAMB1hLBZQhKBch1ALMgjvADjQgPACgQAAQhiAAhPhBg");
	var mask_4_graphics_24 = new cjs.Graphics().p("Am2EgQhahKgLh1QgMhzBJhcQBLhaB1gLMAjsgDlQB0gMBbBKQBbBLAMB0QALB1hLBZQhJBbh1AMMgjsADlQgPABgQAAQhhAAhQhAg");
	var mask_4_graphics_25 = new cjs.Graphics().p("AoDEqQhahKgMh0QgMhzBJhcQBLhaB0gMMAjogDoQB0gLBaBJQBcBLAMB0QALB0hKBZQhKBch0AMMgjoADnQgPACgQAAQhhAAhPhAg");
	var mask_4_graphics_26 = new cjs.Graphics().p("ApkE2QhahJgNh0QgMh0BJhaQBLhaB0gMMAjigDsQB0gMBaBJQBcBKAMB0QAMB0hLBaQhJBbh0AMMgjiADrQgQACgQAAQhhAAhOhAg");
	var mask_4_graphics_27 = new cjs.Graphics().p("ArIFDQhahJgMh0QgMhzBJhbQBKhaBzgMMAjdgDvQB0gMBaBIQBbBKAMB0QANB0hLBZQhIBbh0AMMgjdADwQgQABgQAAQhgAAhPg/g");
	var mask_4_graphics_28 = new cjs.Graphics().p("AsbFOQhahJgNhzQgMh0BIhaQBKhaB0gMMAjYgDzQBzgMBaBIQBbBKANBzQAMB0hKBZQhIBbh0AMMgjYADzQgQACgQAAQhgAAhOg/g");
	var mask_4_graphics_29 = new cjs.Graphics().p("AtbFUQhahIgMhzQgNh0BIhaQBKhaBzgMMAjVgD1QBzgNBaBJQBbBJANBzQAMB0hJBZQhJBbhzAMMgjUAD1QgRACgQAAQhgAAhOg/g");
	var mask_4_graphics_30 = new cjs.Graphics().p("AuJFVQhahIgNhzQgMhzBIhbQBJhaBzgMMAjSgD3QBzgMBaBIQBbBJANBzQAMB0hJBYQhIBchzAMMgjSAD3QgRACgQAAQhgAAhNg/g");
	var mask_4_graphics_31 = new cjs.Graphics().p("AurFWQhahIgMh0QgNhzBIhaQBJhaBzgMMAjQgD4QBzgNBaBIQBbBKANBzQANBzhKBZQhIBbhzAMMgjQAD4QgQACgRAAQhfAAhOg+g");
	var mask_4_graphics_32 = new cjs.Graphics().p("AvCFWQhahIgNhzQgMhzBIhaQBJhaBzgNMAjOgD4QBzgNBaBIQBbBJANBzQANBzhJBZQhIBbhzANMgjPAD4QgRACgQAAQhfAAhOg+g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:244.4826,y:-45.5271}).wait(1).to({graphics:mask_4_graphics_20,x:244.1273,y:-45.4947}).wait(1).to({graphics:mask_4_graphics_21,x:242.9225,y:-45.3842}).wait(1).to({graphics:mask_4_graphics_22,x:240.6001,y:-45.1713}).wait(1).to({graphics:mask_4_graphics_23,x:236.774,y:-44.8203}).wait(1).to({graphics:mask_4_graphics_24,x:230.9321,y:-44.2844}).wait(1).to({graphics:mask_4_graphics_25,x:222.6248,y:-43.522}).wait(1).to({graphics:mask_4_graphics_26,x:212.2235,y:-42.5671}).wait(1).to({graphics:mask_4_graphics_27,x:201.6029,y:-41.5915}).wait(1).to({graphics:mask_4_graphics_28,x:192.6517,y:-40.7689}).wait(1).to({graphics:mask_4_graphics_29,x:185.842,y:-39.9904}).wait(1).to({graphics:mask_4_graphics_30,x:180.8602,y:-39.0163}).wait(1).to({graphics:mask_4_graphics_31,x:177.2901,y:-38.3183}).wait(1).to({graphics:mask_4_graphics_32,x:174.7929,y:-37.9577}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(101.6,-22.35,0.9423,0.9423,4.9774,0,0,-6,30.6);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-81.2,259.1,289.2);


(lib.wordScreenSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.sml = new lib.sml();
	this.sml.name = "sml";
	this.sml.setTransform(135.3,90.5,1,1,0,0,0,135.3,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sml).wait(1));

	// Layer_1
	this.sub = new lib.wordScreen();
	this.sub.name = "sub";
	this.sub.setTransform(135.7,90.5,1,1,0,0,0,135.7,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordScreenSub, new cjs.Rectangle(0,0,271.4,181.1), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-21.7,0.7,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.CTAbg},{t:this.popRight},{t:this.popLeft}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.6,143.7,27), null);


(lib.laptop_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}
	this.frame_90 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(31).call(this.frame_90).wait(1));

	// endCursor
	this.editorCursorEnd = new lib.editorCursor();
	this.editorCursorEnd.name = "editorCursorEnd";
	this.editorCursorEnd.setTransform(-215.7,155.8,1,1,0,0,0,0,31);

	this.timeline.addTween(cjs.Tween.get(this.editorCursorEnd).wait(91));

	// editorCursor
	this.editorCursor = new lib.editorCursor();
	this.editorCursor.name = "editorCursor";
	this.editorCursor.setTransform(150,35.5,1,1,0,0,0,15,15.5);

	this.timeline.addTween(cjs.Tween.get(this.editorCursor).wait(91));

	// LinkedInEndFrame
	this.socialScreenEnd = new lib.socialScreenEnd();
	this.socialScreenEnd.name = "socialScreenEnd";
	this.socialScreenEnd.setTransform(-225.7,154.05,0.5094,0.5094,-20.7828,0,0,0.4,190.1);

	this.timeline.addTween(cjs.Tween.get(this.socialScreenEnd).wait(91));

	// rightMask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AEBOxIAA8tIU/AAIAActg");
	var mask_graphics_1 = new cjs.Graphics().p("AEJOxIAA8tIU3AAIAActg");
	var mask_graphics_2 = new cjs.Graphics().p("AEUOxIAA8tIUsAAIAActg");
	var mask_graphics_3 = new cjs.Graphics().p("AEjOxIAA8tIUdAAIAActg");
	var mask_graphics_4 = new cjs.Graphics().p("AE3OxIAA8tIUJAAIAActg");
	var mask_graphics_5 = new cjs.Graphics().p("AFQOxIAA8tITwAAIAActg");
	var mask_graphics_6 = new cjs.Graphics().p("AFuOxIAA8tITSAAIAActg");
	var mask_graphics_7 = new cjs.Graphics().p("AGTOxIAA8sIStAAIAAcsg");
	var mask_graphics_8 = new cjs.Graphics().p("AG+OxIAA8sISCAAIAAcsg");
	var mask_graphics_9 = new cjs.Graphics().p("AHuOxIAA8sIRSAAIAAcsg");
	var mask_graphics_10 = new cjs.Graphics().p("AIjOxIAA8sIQdAAIAAcsg");
	var mask_graphics_11 = new cjs.Graphics().p("AJZOxIAA8sIPnAAIAAcsg");
	var mask_graphics_12 = new cjs.Graphics().p("AKPOxIAA8sIOxAAIAAcsg");
	var mask_graphics_13 = new cjs.Graphics().p("ALBOxIAA8sIN/AAIAAcsg");
	var mask_graphics_14 = new cjs.Graphics().p("ALwOxIAA8sINQAAIAAcsg");
	var mask_graphics_15 = new cjs.Graphics().p("AMaOxIAA8sIMmAAIAAcsg");
	var mask_graphics_16 = new cjs.Graphics().p("AM/OxIAA8sIMBAAIAAcsg");
	var mask_graphics_17 = new cjs.Graphics().p("ANeOxIAA8sILiAAIAAcsg");
	var mask_graphics_18 = new cjs.Graphics().p("AN6OxIAA8sILGAAIAAcsg");
	var mask_graphics_19 = new cjs.Graphics().p("AOSOxIAA8sIKuAAIAAcsg");
	var mask_graphics_20 = new cjs.Graphics().p("AOmOxIAA8sIKaAAIAAcsg");
	var mask_graphics_21 = new cjs.Graphics().p("AO2OxIAA8sIKKAAIAAcsg");
	var mask_graphics_22 = new cjs.Graphics().p("APEOxIAA8sIJ8AAIAAcsg");
	var mask_graphics_23 = new cjs.Graphics().p("APQOxIAA8sIJwAAIAAcsg");
	var mask_graphics_24 = new cjs.Graphics().p("APZOxIAA8sIJnAAIAAcsg");
	var mask_graphics_25 = new cjs.Graphics().p("APgOxIAA8sIJgAAIAAcsg");
	var mask_graphics_26 = new cjs.Graphics().p("APlOxIAA8sIJbAAIAAcsg");
	var mask_graphics_27 = new cjs.Graphics().p("APpOxIAA8sIJXAAIAAcsg");
	var mask_graphics_28 = new cjs.Graphics().p("APrOxIAA8sIJVAAIAAcsg");
	var mask_graphics_29 = new cjs.Graphics().p("APsOxIAA8tIJUAAIAActg");
	var mask_graphics_30 = new cjs.Graphics().p("APcOxIAA8tIJkAAIAActg");
	var mask_graphics_31 = new cjs.Graphics().p("APEOxIAA8tIJ8AAIAActg");
	var mask_graphics_32 = new cjs.Graphics().p("AOlOxIAA8tIKbAAIAActg");
	var mask_graphics_33 = new cjs.Graphics().p("AN8OxIAA8tILEAAIAActg");
	var mask_graphics_34 = new cjs.Graphics().p("ANJOwIAA8sIL3AAIAAcsg");
	var mask_graphics_35 = new cjs.Graphics().p("AMKOwIAA8sIM2AAIAAcsg");
	var mask_graphics_36 = new cjs.Graphics().p("AK/OwIAA8sIOBAAIAAcsg");
	var mask_graphics_37 = new cjs.Graphics().p("AJnOwIAA8sIPZAAIAAcsg");
	var mask_graphics_38 = new cjs.Graphics().p("AIDOwIAA8sIQ9AAIAAcsg");
	var mask_graphics_39 = new cjs.Graphics().p("AGWOwIAA8sISqAAIAAcsg");
	var mask_graphics_40 = new cjs.Graphics().p("AEkOwIAA8sIUcAAIAAcsg");
	var mask_graphics_41 = new cjs.Graphics().p("ACwOwIAA8sIWQAAIAAcsg");
	var mask_graphics_42 = new cjs.Graphics().p("ABBOwIAA8sIX/AAIAAcsg");
	var mask_graphics_43 = new cjs.Graphics().p("AglOwIAA8sIZlAAIAAcsg");
	var mask_graphics_44 = new cjs.Graphics().p("AiDOwIAA8sIbDAAIAAcsg");
	var mask_graphics_45 = new cjs.Graphics().p("AjWOwIAA8sIcWAAIAAcsg");
	var mask_graphics_46 = new cjs.Graphics().p("AkgOwIAA8sIdgAAIAAcsg");
	var mask_graphics_47 = new cjs.Graphics().p("AlgOwIAA8sIegAAIAAcsg");
	var mask_graphics_48 = new cjs.Graphics().p("AmXOwIAA8sIfXAAIAAcsg");
	var mask_graphics_49 = new cjs.Graphics().p("AnGOwIAA8sMAgGAAAIAAcsg");
	var mask_graphics_50 = new cjs.Graphics().p("AnvOwIAA8sMAgvAAAIAAcsg");
	var mask_graphics_51 = new cjs.Graphics().p("AoROwIAA8sMAhRAAAIAAcsg");
	var mask_graphics_52 = new cjs.Graphics().p("AotOwIAA8sMAhtAAAIAAcsg");
	var mask_graphics_53 = new cjs.Graphics().p("ApEOwIAA8sMAiEAAAIAAcsg");
	var mask_graphics_54 = new cjs.Graphics().p("ApXOwIAA8sMAiXAAAIAAcsg");
	var mask_graphics_55 = new cjs.Graphics().p("AplOwIAA8sMAilAAAIAAcsg");
	var mask_graphics_56 = new cjs.Graphics().p("ApwOwIAA8sMAiwAAAIAAcsg");
	var mask_graphics_57 = new cjs.Graphics().p("Ap3OwIAA8sMAi3AAAIAAcsg");
	var mask_graphics_58 = new cjs.Graphics().p("Ap8OwIAA8sMAi8AAAIAAcsg");
	var mask_graphics_59 = new cjs.Graphics().p("Ap9OxIAA8tMAi9AAAIAActg");
	var mask_graphics_60 = new cjs.Graphics().p("AqCOxIAA8tMAjCAAAIAActg");
	var mask_graphics_61 = new cjs.Graphics().p("AqJOxIAA8tMAjJAAAIAActg");
	var mask_graphics_62 = new cjs.Graphics().p("AqSOxIAA8tMAjSAAAIAActg");
	var mask_graphics_63 = new cjs.Graphics().p("AqeOxIAA8tMAjeAAAIAActg");
	var mask_graphics_64 = new cjs.Graphics().p("AqtOxIAA8tMAjtAAAIAActg");
	var mask_graphics_65 = new cjs.Graphics().p("ArAOxIAA8tMAkAAAAIAActg");
	var mask_graphics_66 = new cjs.Graphics().p("ArWOxIAA8tMAkWAAAIAActg");
	var mask_graphics_67 = new cjs.Graphics().p("ArwOxIAA8tMAkwAAAIAActg");
	var mask_graphics_68 = new cjs.Graphics().p("AsOOxIAA8tMAlOAAAIAActg");
	var mask_graphics_69 = new cjs.Graphics().p("AsuOxIAA8tMAluAAAIAActg");
	var mask_graphics_70 = new cjs.Graphics().p("AtQOxIAA8tMAmQAAAIAActg");
	var mask_graphics_71 = new cjs.Graphics().p("AtzOxIAA8tMAmzAAAIAActg");
	var mask_graphics_72 = new cjs.Graphics().p("AuTOxIAA8tMAnTAAAIAActg");
	var mask_graphics_73 = new cjs.Graphics().p("AuyOxIAA8tMAnyAAAIAActg");
	var mask_graphics_74 = new cjs.Graphics().p("AvOOxIAA8tMAoOAAAIAActg");
	var mask_graphics_75 = new cjs.Graphics().p("AvnOxIAA8tMAonAAAIAActg");
	var mask_graphics_76 = new cjs.Graphics().p("Av9OxIAA8tMAo9AAAIAActg");
	var mask_graphics_77 = new cjs.Graphics().p("AwPOxIAA8tMApPAAAIAActg");
	var mask_graphics_78 = new cjs.Graphics().p("AwgOxIAA8tMApgAAAIAActg");
	var mask_graphics_79 = new cjs.Graphics().p("AwuOxIAA8tMApuAAAIAActg");
	var mask_graphics_80 = new cjs.Graphics().p("Aw6OxIAA8tMAp6AAAIAActg");
	var mask_graphics_81 = new cjs.Graphics().p("AxEOxIAA8tMAqEAAAIAActg");
	var mask_graphics_82 = new cjs.Graphics().p("AxMOxIAA8tMAqMAAAIAActg");
	var mask_graphics_83 = new cjs.Graphics().p("AxTOxIAA8tMAqTAAAIAActg");
	var mask_graphics_84 = new cjs.Graphics().p("AxZOxIAA8tMAqZAAAIAActg");
	var mask_graphics_85 = new cjs.Graphics().p("AxdOxIAA8tMAqdAAAIAActg");
	var mask_graphics_86 = new cjs.Graphics().p("AxgOxIAA8tMAqgAAAIAActg");
	var mask_graphics_87 = new cjs.Graphics().p("AxiOxIAA8tMAqiAAAIAActg");
	var mask_graphics_88 = new cjs.Graphics().p("AxkOxIAA8tMAqkAAAIAActg");
	var mask_graphics_89 = new cjs.Graphics().p("AxlOxIAA8tMAqkAAAIAActg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:159.978,y:94.4521}).wait(1).to({graphics:mask_graphics_1,x:159.9779,y:94.4524}).wait(1).to({graphics:mask_graphics_2,x:159.9778,y:94.4528}).wait(1).to({graphics:mask_graphics_3,x:159.9776,y:94.4533}).wait(1).to({graphics:mask_graphics_4,x:159.9774,y:94.4539}).wait(1).to({graphics:mask_graphics_5,x:159.9772,y:94.4548}).wait(1).to({graphics:mask_graphics_6,x:159.9769,y:94.4558}).wait(1).to({graphics:mask_graphics_7,x:159.9765,y:94.457}).wait(1).to({graphics:mask_graphics_8,x:159.9761,y:94.4585}).wait(1).to({graphics:mask_graphics_9,x:159.9757,y:94.4601}).wait(1).to({graphics:mask_graphics_10,x:159.9752,y:94.4618}).wait(1).to({graphics:mask_graphics_11,x:159.9746,y:94.4637}).wait(1).to({graphics:mask_graphics_12,x:159.9741,y:94.4655}).wait(1).to({graphics:mask_graphics_13,x:159.9736,y:94.4672}).wait(1).to({graphics:mask_graphics_14,x:159.9732,y:94.4687}).wait(1).to({graphics:mask_graphics_15,x:159.9728,y:94.4701}).wait(1).to({graphics:mask_graphics_16,x:159.9724,y:94.4713}).wait(1).to({graphics:mask_graphics_17,x:159.9721,y:94.4724}).wait(1).to({graphics:mask_graphics_18,x:159.9719,y:94.4733}).wait(1).to({graphics:mask_graphics_19,x:159.9716,y:94.4741}).wait(1).to({graphics:mask_graphics_20,x:159.9714,y:94.4748}).wait(1).to({graphics:mask_graphics_21,x:159.9713,y:94.4754}).wait(1).to({graphics:mask_graphics_22,x:159.9711,y:94.4758}).wait(1).to({graphics:mask_graphics_23,x:159.971,y:94.4762}).wait(1).to({graphics:mask_graphics_24,x:159.9709,y:94.4765}).wait(1).to({graphics:mask_graphics_25,x:159.9709,y:94.4768}).wait(1).to({graphics:mask_graphics_26,x:159.9708,y:94.4769}).wait(1).to({graphics:mask_graphics_27,x:159.9708,y:94.4771}).wait(1).to({graphics:mask_graphics_28,x:159.9708,y:94.4771}).wait(1).to({graphics:mask_graphics_29,x:159.9819,y:94.4521}).wait(1).to({graphics:mask_graphics_30,x:159.982,y:94.4519}).wait(1).to({graphics:mask_graphics_31,x:159.9823,y:94.4515}).wait(1).to({graphics:mask_graphics_32,x:159.9826,y:94.4511}).wait(1).to({graphics:mask_graphics_33,x:159.9831,y:94.4504}).wait(1).to({graphics:mask_graphics_34,x:159.9836,y:94.4497}).wait(1).to({graphics:mask_graphics_35,x:159.9843,y:94.4487}).wait(1).to({graphics:mask_graphics_36,x:159.9852,y:94.4476}).wait(1).to({graphics:mask_graphics_37,x:159.9861,y:94.4462}).wait(1).to({graphics:mask_graphics_38,x:159.9872,y:94.4447}).wait(1).to({graphics:mask_graphics_39,x:159.9884,y:94.443}).wait(1).to({graphics:mask_graphics_40,x:159.9897,y:94.4413}).wait(1).to({graphics:mask_graphics_41,x:159.9909,y:94.4395}).wait(1).to({graphics:mask_graphics_42,x:159.9922,y:94.4379}).wait(1).to({graphics:mask_graphics_43,x:159.9933,y:94.4363}).wait(1).to({graphics:mask_graphics_44,x:159.9943,y:94.4348}).wait(1).to({graphics:mask_graphics_45,x:159.9952,y:94.4336}).wait(1).to({graphics:mask_graphics_46,x:159.996,y:94.4325}).wait(1).to({graphics:mask_graphics_47,x:159.9967,y:94.4315}).wait(1).to({graphics:mask_graphics_48,x:159.9973,y:94.4306}).wait(1).to({graphics:mask_graphics_49,x:159.9979,y:94.4299}).wait(1).to({graphics:mask_graphics_50,x:159.9983,y:94.4293}).wait(1).to({graphics:mask_graphics_51,x:159.9987,y:94.4288}).wait(1).to({graphics:mask_graphics_52,x:159.999,y:94.4284}).wait(1).to({graphics:mask_graphics_53,x:159.9992,y:94.428}).wait(1).to({graphics:mask_graphics_54,x:159.9994,y:94.4277}).wait(1).to({graphics:mask_graphics_55,x:159.9996,y:94.4275}).wait(1).to({graphics:mask_graphics_56,x:159.9997,y:94.4273}).wait(1).to({graphics:mask_graphics_57,x:159.9998,y:94.4272}).wait(1).to({graphics:mask_graphics_58,x:159.9999,y:94.4272}).wait(1).to({graphics:mask_graphics_59,x:159.9999,y:94.4521}).wait(1).to({graphics:mask_graphics_60,x:160,y:94.4521}).wait(1).to({graphics:mask_graphics_61,x:160.0002,y:94.4521}).wait(1).to({graphics:mask_graphics_62,x:160.0004,y:94.4521}).wait(1).to({graphics:mask_graphics_63,x:160.0007,y:94.4521}).wait(1).to({graphics:mask_graphics_64,x:160.0011,y:94.4521}).wait(1).to({graphics:mask_graphics_65,x:160.0016,y:94.4521}).wait(1).to({graphics:mask_graphics_66,x:160.0021,y:94.4521}).wait(1).to({graphics:mask_graphics_67,x:160.0028,y:94.4521}).wait(1).to({graphics:mask_graphics_68,x:160.0035,y:94.4521}).wait(1).to({graphics:mask_graphics_69,x:160.0043,y:94.4521}).wait(1).to({graphics:mask_graphics_70,x:160.0052,y:94.4521}).wait(1).to({graphics:mask_graphics_71,x:160.006,y:94.4521}).wait(1).to({graphics:mask_graphics_72,x:160.0069,y:94.4521}).wait(1).to({graphics:mask_graphics_73,x:160.0076,y:94.4521}).wait(1).to({graphics:mask_graphics_74,x:160.0083,y:94.4521}).wait(1).to({graphics:mask_graphics_75,x:160.009,y:94.4521}).wait(1).to({graphics:mask_graphics_76,x:160.0095,y:94.4521}).wait(1).to({graphics:mask_graphics_77,x:160.01,y:94.4521}).wait(1).to({graphics:mask_graphics_78,x:160.0104,y:94.4521}).wait(1).to({graphics:mask_graphics_79,x:160.0108,y:94.4521}).wait(1).to({graphics:mask_graphics_80,x:160.0111,y:94.4521}).wait(1).to({graphics:mask_graphics_81,x:160.0113,y:94.4521}).wait(1).to({graphics:mask_graphics_82,x:160.0115,y:94.4521}).wait(1).to({graphics:mask_graphics_83,x:160.0117,y:94.4521}).wait(1).to({graphics:mask_graphics_84,x:160.0118,y:94.4521}).wait(1).to({graphics:mask_graphics_85,x:160.0119,y:94.4521}).wait(1).to({graphics:mask_graphics_86,x:160.012,y:94.4521}).wait(1).to({graphics:mask_graphics_87,x:160.0121,y:94.4521}).wait(1).to({graphics:mask_graphics_88,x:160.0121,y:94.4521}).wait(1).to({graphics:mask_graphics_89,x:159.9106,y:94.4521}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// wordScreen
	this.wordScreen = new lib.wordScreenSub();
	this.wordScreen.name = "wordScreen";
	this.wordScreen.setTransform(47.85,187.55,1,1,0,0,0,0,181.1);

	var maskedShapeInstanceList = [this.wordScreen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.wordScreen).wait(91));

	// leftMask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Am5OxIAA8tIVSAAIAActg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Am9OxIAA8tIVZAAIAActg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AnCOxIAA8tIVkAAIAActg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AnKOxIAA8tIVzAAIAActg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AnUOxIAA8tIWHAAIAActg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AngOxIAA8tIWgAAIAActg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AnvOxIAA8tIW+AAIAActg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AoBOxIAA8tIXiAAIAActg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AoXOxIAA8tIYNAAIAActg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AovOxIAA8tIY9AAIAActg");
	var mask_1_graphics_10 = new cjs.Graphics().p("ApJOxIAA8tIZxAAIAActg");
	var mask_1_graphics_11 = new cjs.Graphics().p("ApjOxIAA8tIamAAIAActg");
	var mask_1_graphics_12 = new cjs.Graphics().p("Ap+OxIAA8tIbcAAIAActg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AqXOxIAA8tIcOAAIAActg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AquOxIAA8tIc8AAIAActg");
	var mask_1_graphics_15 = new cjs.Graphics().p("ArDOxIAA8tIdmAAIAActg");
	var mask_1_graphics_16 = new cjs.Graphics().p("ArVOxIAA8tIeKAAIAActg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArlOxIAA8tIeqAAIAActg");
	var mask_1_graphics_18 = new cjs.Graphics().p("ArzOxIAA8tIfFAAIAActg");
	var mask_1_graphics_19 = new cjs.Graphics().p("Ar+OxIAA8tIfcAAIAActg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AsIOxIAA8tIfwAAIAActg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AsROxIAA8tMAgBAAAIAActg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AsYOxIAA8tMAgPAAAIAActg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AsdOxIAA8tMAgaAAAIAActg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AsiOxIAA8tMAgkAAAIAActg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AslOxIAA8tMAgqAAAIAActg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AsoOxIAA8tMAgwAAAIAActg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AsqOxIAA8tMAgzAAAIAActg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AsrOxIAA8tMAg1AAAIAActg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AsrOxIAA8tMAg1AAAIAActg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AsjOxIAA8tMAglAAAIAActg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AsYOxIAA8tMAgPAAAIAActg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AsIOxIAA8tIfvAAIAActg");
	var mask_1_graphics_33 = new cjs.Graphics().p("Ar0OxIAA8tIfGAAIAActg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AraOxIAA8tIeTAAIAActg");
	var mask_1_graphics_35 = new cjs.Graphics().p("Aq7OxIAA8tIdVAAIAActg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AqVOxIAA8tIcJAAIAActg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AppOxIAA8tIaxAAIAActg");
	var mask_1_graphics_38 = new cjs.Graphics().p("Ao4OxIAA8tIZOAAIAActg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AoBOxIAA8tIXhAAIAActg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AnIOxIAA8tIVvAAIAActg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AmOOxIAA8tIT7AAIAActg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AlXOxIAA8tISNAAIAActg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AkjOxIAA8tIQlAAIAActg");
	var mask_1_graphics_44 = new cjs.Graphics().p("Aj0OxIAA8tIPHAAIAActg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AjLOxIAA8tIN0AAIAActg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AimOxIAA8tIMrAAIAActg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AiGOxIAA8tILrAAIAActg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AhrOxIAA8tIK0AAIAActg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AhTOxIAA8tIKFAAIAActg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Ag/OxIAA8tIJdAAIAActg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AguOxIAA8tII7AAIAActg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AggOxIAA8tIIeAAIAActg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AgUOxIAA8tIIHAAIAActg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AgLOxIAA8tIH0AAIAActg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AgDOxIAA8tIHlAAIAActg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AABOxIAA8tIHcAAIAActg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AAFOxIAA8tIHUAAIAActg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AAHOxIAA8tIHQAAIAActg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AAIOxIAA8tIHPAAIAActg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AAKOxIAA8tIHKAAIAActg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AAMOxIAA8tIHFAAIAActg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AAQOxIAA8tIG8AAIAActg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AAVOxIAA8tIGxAAIAActg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AAcOxIAA8tIGiAAIAActg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AAkOxIAA8tIGRAAIAActg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AAtOxIAA8tIF9AAIAActg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AA4OxIAA8tIFlAAIAActg");
	var mask_1_graphics_68 = new cjs.Graphics().p("ABEOxIAA8tIFKAAIAActg");
	var mask_1_graphics_69 = new cjs.Graphics().p("ABSOxIAA8tIEsAAIAActg");
	var mask_1_graphics_70 = new cjs.Graphics().p("ABgOxIAA8tIENAAIAActg");
	var mask_1_graphics_71 = new cjs.Graphics().p("ABvOxIAA8tIDtAAIAActg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AB8OxIAA8tIDPAAIAActg");
	var mask_1_graphics_73 = new cjs.Graphics().p("ACJOxIAA8tICzAAIAActg");
	var mask_1_graphics_74 = new cjs.Graphics().p("ACVOxIAA8tICZAAIAActg");
	var mask_1_graphics_75 = new cjs.Graphics().p("ACfOxIAA8tICDAAIAActg");
	var mask_1_graphics_76 = new cjs.Graphics().p("ACpOxIAA8sIBuAAIAAcsg");
	var mask_1_graphics_77 = new cjs.Graphics().p("ACxOxIAA8sIBcAAIAAcsg");
	var mask_1_graphics_78 = new cjs.Graphics().p("AC3OxIAA8sIBOAAIAAcsg");
	var mask_1_graphics_79 = new cjs.Graphics().p("AC9OxIAA8sIBBAAIAAcsg");
	var mask_1_graphics_80 = new cjs.Graphics().p("ADCOxIAA8sIA2AAIAAcsg");
	var mask_1_graphics_81 = new cjs.Graphics().p("ADHOxIAA8sIAsAAIAAcsg");
	var mask_1_graphics_82 = new cjs.Graphics().p("ADKOxIAA8sIAlAAIAAcsg");
	var mask_1_graphics_83 = new cjs.Graphics().p("ADNOxIAA8sIAeAAIAAcsg");
	var mask_1_graphics_84 = new cjs.Graphics().p("ADPOxIAA8sIAaAAIAAcsg");
	var mask_1_graphics_85 = new cjs.Graphics().p("ADROxIAA8sIAVAAIAAcsg");
	var mask_1_graphics_86 = new cjs.Graphics().p("ADTOxIAA8sIASAAIAAcsg");
	var mask_1_graphics_87 = new cjs.Graphics().p("ADTOxIAA8sIARAAIAAcsg");
	var mask_1_graphics_88 = new cjs.Graphics().p("ADUOxIAA8sIAPAAIAAcsg");
	var mask_1_graphics_89 = new cjs.Graphics().p("ADUOxIAA8sIAPAAIAAcsg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:92.0519,y:94.4521}).wait(1).to({graphics:mask_1_graphics_1,x:92.4343,y:94.4521}).wait(1).to({graphics:mask_1_graphics_2,x:92.9899,y:94.4521}).wait(1).to({graphics:mask_1_graphics_3,x:93.7431,y:94.4521}).wait(1).to({graphics:mask_1_graphics_4,x:94.7216,y:94.4521}).wait(1).to({graphics:mask_1_graphics_5,x:95.9548,y:94.4521}).wait(1).to({graphics:mask_1_graphics_6,x:97.4707,y:94.4521}).wait(1).to({graphics:mask_1_graphics_7,x:99.2896,y:94.4521}).wait(1).to({graphics:mask_1_graphics_8,x:101.4132,y:94.4521}).wait(1).to({graphics:mask_1_graphics_9,x:103.8115,y:94.4521}).wait(1).to({graphics:mask_1_graphics_10,x:106.4121,y:94.4521}).wait(1).to({graphics:mask_1_graphics_11,x:109.1049,y:94.4521}).wait(1).to({graphics:mask_1_graphics_12,x:111.7656,y:94.4521}).wait(1).to({graphics:mask_1_graphics_13,x:114.2873,y:94.4521}).wait(1).to({graphics:mask_1_graphics_14,x:116.5994,y:94.4521}).wait(1).to({graphics:mask_1_graphics_15,x:118.6687,y:94.4521}).wait(1).to({graphics:mask_1_graphics_16,x:120.4902,y:94.4521}).wait(1).to({graphics:mask_1_graphics_17,x:122.0747,y:94.4521}).wait(1).to({graphics:mask_1_graphics_18,x:123.4409,y:94.4521}).wait(1).to({graphics:mask_1_graphics_19,x:124.6097,y:94.4521}).wait(1).to({graphics:mask_1_graphics_20,x:125.6019,y:94.4521}).wait(1).to({graphics:mask_1_graphics_21,x:126.4363,y:94.4521}).wait(1).to({graphics:mask_1_graphics_22,x:127.13,y:94.4521}).wait(1).to({graphics:mask_1_graphics_23,x:127.6978,y:94.4521}).wait(1).to({graphics:mask_1_graphics_24,x:128.1527,y:94.4521}).wait(1).to({graphics:mask_1_graphics_25,x:128.506,y:94.4521}).wait(1).to({graphics:mask_1_graphics_26,x:128.7674,y:94.4521}).wait(1).to({graphics:mask_1_graphics_27,x:128.9455,y:94.4521}).wait(1).to({graphics:mask_1_graphics_28,x:129.0477,y:94.4521}).wait(1).to({graphics:mask_1_graphics_29,x:129.0418,y:94.4521}).wait(1).to({graphics:mask_1_graphics_30,x:128.2291,y:94.4521}).wait(1).to({graphics:mask_1_graphics_31,x:127.0596,y:94.4521}).wait(1).to({graphics:mask_1_graphics_32,x:125.4847,y:94.4521}).wait(1).to({graphics:mask_1_graphics_33,x:123.4495,y:94.4521}).wait(1).to({graphics:mask_1_graphics_34,x:120.8954,y:94.4521}).wait(1).to({graphics:mask_1_graphics_35,x:117.7653,y:94.4521}).wait(1).to({graphics:mask_1_graphics_36,x:114.0142,y:94.4521}).wait(1).to({graphics:mask_1_graphics_37,x:109.628,y:94.4521}).wait(1).to({graphics:mask_1_graphics_38,x:104.6483,y:94.4521}).wait(1).to({graphics:mask_1_graphics_39,x:99.1952,y:94.4521}).wait(1).to({graphics:mask_1_graphics_40,x:93.4687,y:94.4521}).wait(1).to({graphics:mask_1_graphics_41,x:87.7152,y:94.4521}).wait(1).to({graphics:mask_1_graphics_42,x:82.1688,y:94.4521}).wait(1).to({graphics:mask_1_graphics_43,x:77.0038,y:94.4521}).wait(1).to({graphics:mask_1_graphics_44,x:72.318,y:94.4521}).wait(1).to({graphics:mask_1_graphics_45,x:68.1457,y:94.4521}).wait(1).to({graphics:mask_1_graphics_46,x:64.479,y:94.4521}).wait(1).to({graphics:mask_1_graphics_47,x:61.287,y:94.4521}).wait(1).to({graphics:mask_1_graphics_48,x:58.5297,y:94.4521}).wait(1).to({graphics:mask_1_graphics_49,x:56.1648,y:94.4521}).wait(1).to({graphics:mask_1_graphics_50,x:54.152,y:94.4521}).wait(1).to({graphics:mask_1_graphics_51,x:52.4546,y:94.4521}).wait(1).to({graphics:mask_1_graphics_52,x:51.0398,y:94.4521}).wait(1).to({graphics:mask_1_graphics_53,x:49.8789,y:94.4521}).wait(1).to({graphics:mask_1_graphics_54,x:48.9467,y:94.4521}).wait(1).to({graphics:mask_1_graphics_55,x:48.2212,y:94.4521}).wait(1).to({graphics:mask_1_graphics_56,x:47.6833,y:94.4521}).wait(1).to({graphics:mask_1_graphics_57,x:47.3162,y:94.4521}).wait(1).to({graphics:mask_1_graphics_58,x:47.1053,y:94.4521}).wait(1).to({graphics:mask_1_graphics_59,x:47.0546,y:94.4521}).wait(1).to({graphics:mask_1_graphics_60,x:46.8131,y:94.4521}).wait(1).to({graphics:mask_1_graphics_61,x:46.4656,y:94.4521}).wait(1).to({graphics:mask_1_graphics_62,x:45.9975,y:94.4521}).wait(1).to({graphics:mask_1_graphics_63,x:45.3927,y:94.452}).wait(1).to({graphics:mask_1_graphics_64,x:44.6337,y:94.452}).wait(1).to({graphics:mask_1_graphics_65,x:43.7036,y:94.4519}).wait(1).to({graphics:mask_1_graphics_66,x:42.5888,y:94.4519}).wait(1).to({graphics:mask_1_graphics_67,x:41.2854,y:94.4518}).wait(1).to({graphics:mask_1_graphics_68,x:39.8056,y:94.4517}).wait(1).to({graphics:mask_1_graphics_69,x:38.185,y:94.4516}).wait(1).to({graphics:mask_1_graphics_70,x:36.4833,y:94.4515}).wait(1).to({graphics:mask_1_graphics_71,x:34.7735,y:94.4514}).wait(1).to({graphics:mask_1_graphics_72,x:33.1253,y:94.4513}).wait(1).to({graphics:mask_1_graphics_73,x:31.5904,y:94.4513}).wait(1).to({graphics:mask_1_graphics_74,x:30.1979,y:94.4512}).wait(1).to({graphics:mask_1_graphics_75,x:28.9581,y:94.4511}).wait(1).to({graphics:mask_1_graphics_76,x:27.8684,y:94.451}).wait(1).to({graphics:mask_1_graphics_77,x:26.9198,y:94.451}).wait(1).to({graphics:mask_1_graphics_78,x:26.1004,y:94.4509}).wait(1).to({graphics:mask_1_graphics_79,x:25.3977,y:94.4509}).wait(1).to({graphics:mask_1_graphics_80,x:24.7995,y:94.4509}).wait(1).to({graphics:mask_1_graphics_81,x:24.2951,y:94.4508}).wait(1).to({graphics:mask_1_graphics_82,x:23.8747,y:94.4508}).wait(1).to({graphics:mask_1_graphics_83,x:23.5297,y:94.4508}).wait(1).to({graphics:mask_1_graphics_84,x:23.2526,y:94.4508}).wait(1).to({graphics:mask_1_graphics_85,x:23.0371,y:94.4508}).wait(1).to({graphics:mask_1_graphics_86,x:22.8772,y:94.4508}).wait(1).to({graphics:mask_1_graphics_87,x:22.7681,y:94.4507}).wait(1).to({graphics:mask_1_graphics_88,x:22.7054,y:94.4507}).wait(1).to({graphics:mask_1_graphics_89,x:22.6926,y:94.4507}).wait(2));

	// socialScreen
	this.socialScreen = new lib.socialScreen();
	this.socialScreen.name = "socialScreen";
	this.socialScreen.setTransform(183.6,96.8,1,1,0,0,0,135.6,90.5);

	var maskedShapeInstanceList = [this.socialScreen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.socialScreen).wait(91));

	// angledShadows
	this.angledShadow2 = new lib.angledShadow();
	this.angledShadow2.name = "angledShadow2";
	this.angledShadow2.setTransform(-98.3,150.65,1.0583,1.0583,0,0,0,18.4,22);

	this.angledShadow1 = new lib.angledShadow();
	this.angledShadow1.name = "angledShadow1";
	this.angledShadow1.setTransform(-232.9,152.25,1.0583,1.0583,0,0,0,18.4,22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.angledShadow1},{t:this.angledShadow2}]}).wait(91));

	// Layer_1
	this.laptop = new lib.laptopSub();
	this.laptop.name = "laptop";
	this.laptop.setTransform(183.5,127,1,1,0,0,0,183.5,127);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-260.2,-58.4,627.2,312.4);


(lib.IntroTxtHighlights = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_61 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(61).call(this.frame_61).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_36 = new cjs.Graphics().p("ADSDNQgKhTgGh2QgHh1AAhUQAAhTAGgBIB9gHQAHAAAJBTQAJBUAHB2QAHB1AABTQAABUgGABIh+AHIAAAAQgGAAgJhUg");
	var mask_graphics_37 = new cjs.Graphics().p("ADGDOQgKhTgHh2QgGh1AAhUQABhUAHAAICSgIQAHgBAKBTQAKBUAHB2QAHB1gBBTQgBBVgHAAIiSAIIAAAAQgHAAgKhTg");
	var mask_graphics_38 = new cjs.Graphics().p("AC0DPQgLhTgHh2QgHh1AChUQAChUAJAAICxgKQAJgBALBTQALBUAGB2QAHB1gCBTQgBBVgJAAIixAKIAAAAQgJAAgLhTg");
	var mask_graphics_39 = new cjs.Graphics().p("ACaDQQgMhSgHh2QgHh1AEhVQADhTALgBIDcgMQAMgBAMBTQANBTAHB2QAGB1gDBUQgDBUgLABIjdAMIAAAAQgLAAgNhTg");
	var mask_graphics_40 = new cjs.Graphics().p("AB4DSQgOhSgHh2QgHh1AGhVQAFhUAOAAIEWgQQAPgBAOBTQAPBTAHB2QAGB1gFBUQgFBVgPAAIkWAQIAAAAQgOAAgPhTg");
	var mask_graphics_41 = new cjs.Graphics().p("ABMDVQgRhTgHh2QgGh1AIhVQAIhTASgBIFggUQASgBASBSQARBUAHB2QAGB1gIBTQgIBVgSABIlgAUIgBAAQgRAAgShSg");
	var mask_graphics_42 = new cjs.Graphics().p("AAWDYQgVhTgFh1QgHh1ALhWQALhTAWgCIG9gZQAXgBAUBSQAVBUAHB1QAGB1gLBUQgLBVgXACIm9AZIAAAAQgXAAgUhSg");
	var mask_graphics_43 = new cjs.Graphics().p("AgrDbQgYhSgHh2QgGh1APhVQAPhUAdgCIIqgfQAcgBAZBSQAYBTAHB2QAHB1gQBUQgPBVgcACIorAfIgBAAQgbAAgZhSg");
	var mask_graphics_44 = new cjs.Graphics().p("Ah2DfQgdhRgGh2QgHh1AUhWQAUhUAjgCIKogmQAjgCAdBRQAeBTAGB2QAHB1gUBUQgUBWgjACIqoAmIgCAAQgiAAgdhRg");
	var mask_graphics_45 = new cjs.Graphics().p("AjHDkQgihRgHh2QgGh1AYhWQAZhVAqgCIMyguQAqgCAiBRQAiBSAHB2QAGB1gZBVQgYBWgqACIsyAuIgCAAQgoAAgihQg");
	var mask_graphics_46 = new cjs.Graphics().p("AkaDoQgnhRgGh2QgHh0AehXQAehVAxgCIO8g2QAxgDAnBRQAoBTAGB2QAHB0geBVQgeBXgxACIu8A2IgDAAQgvAAgnhQg");
	var mask_graphics_47 = new cjs.Graphics().p("AlpDtQgshRgGh2QgHh1AihWQAkhVA3gEIRCg9QA4gDAsBRQAsBSAHB2QAGB1gjBVQgiBWg4AEIxCA9IgEAAQg1AAgrhPg");
	var mask_graphics_48 = new cjs.Graphics().p("AmxDxQgwhRgHh2QgGh1AmhWQAohWA+gDIS7hEQA+gEAwBRQAxBSAHB2QAGB1gnBVQgnBXg+ADIy7BEIgFAAQg7AAgvhOg");
	var mask_graphics_49 = new cjs.Graphics().p("AnxD0Qg0hQgGh2QgHh1ArhXQArhVBDgEIUnhKQBDgEA0BQQA1BSAHB2QAGB1grBVQgrBXhDAEI0nBKIgGAAQg/AAgzhOg");
	var mask_graphics_50 = new cjs.Graphics().p("AooD3Qg3hQgGh2QgHh1AuhXQAvhVBIgFIWChPQBIgEA4BQQA4BSAGB2QAHB1gvBVQguBXhIAFI2CBPIgHAAQhEAAg2hOg");
	var mask_graphics_51 = new cjs.Graphics().p("ApWD6Qg6hQgHh2QgGh1AwhXQAyhWBMgEIXRhUQBMgEA6BQQA7BRAHB2QAGB1gxBWQgxBXhMAEI3RBUIgIAAQhHAAg4hNg");
	var mask_graphics_52 = new cjs.Graphics().p("Ap9D8Qg9hQgGh2QgHh1AzhXQA0hWBQgEIYShYQBQgEA8BQQA9BRAHB2QAHB1g0BWQgzBXhQAEI4SBYIgJAAQhKAAg6hNg");
	var mask_graphics_53 = new cjs.Graphics().p("AqeD+Qg+hQgHh2QgGh1A1hXQA2hWBSgFIZJhaQBSgFA/BQQA/BRAHB2QAGB1g2BWQg1BXhSAFI5JBaIgJABQhNAAg8hNg");
	var mask_graphics_54 = new cjs.Graphics().p("Aq4D/QhAhPgHh2QgGh1A2hYQA4hWBUgFIZ2hdQBVgEBABPQBBBRAGB2QAHB1g4BWQg2BYhVAFI52BdIgJAAQhPAAg9hNg");
	var mask_graphics_55 = new cjs.Graphics().p("ArOEBQhBhQgHh2QgGh1A4hXQA5hXBWgFIaahfQBWgEBCBPQBCBRAHB2QAGB1g5BWQg4BYhWAFI6aBfIgKAAQhQAAg/hMg");
	var mask_graphics_56 = new cjs.Graphics().p("ArfECQhChQgHh2QgGh1A5hXQA6hXBXgFIa3hgQBYgFBCBPQBEBRAGB2QAHB1g6BWQg5BYhYAFI63BgIgKABQhRAAhAhMg");
	var mask_graphics_57 = new cjs.Graphics().p("ArsECQhDhPgHh2QgGh1A6hYQA6hWBZgFIbNhiQBZgFBDBPQBEBRAHB2QAGB1g6BXQg6BXhZAFI7NBiIgKAAQhTAAhAhMg");
	var mask_graphics_58 = new cjs.Graphics().p("Ar1EDQhEhQgHh1QgGh1A6hYQA7hXBagFIbdhiQBagGBDBQQBFBRAHB2QAGB0g7BXQg6BYhaAFI7dBiIgKABQhUAAhAhMg");
	var mask_graphics_59 = new cjs.Graphics().p("Ar8EDQhEhPgHh2QgGh1A6hYQA8hWBagFIbohkQBbgFBEBQQBFBQAGB2QAHB1g8BXQg6BXhbAFI7oBkIgKAAQhUAAhBhMg");
	var mask_graphics_60 = new cjs.Graphics().p("AsAEDQhEhPgHh2QgGh1A7hYQA8hWBagFIbuhkQBbgFBEBPQBGBRAGB2QAHB1g8BWQg7BYhaAFI7vBkIgKAAQhUAAhChMg");
	var mask_graphics_61 = new cjs.Graphics().p("Ar6EDQhFhPgGh2QgHh1A7hYQA8hWBbgFIbwhkQBbgFBEBPQBFBRAHB2QAHB1g8BWQg7BYhbAFI7wBkIgLAAQhUAAhBhMg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(36).to({graphics:mask_graphics_36,x:35.6662,y:-8.3995}).wait(1).to({graphics:mask_graphics_37,x:36.893,y:-8.4716}).wait(1).to({graphics:mask_graphics_38,x:38.7681,y:-8.581}).wait(1).to({graphics:mask_graphics_39,x:41.4053,y:-8.7339}).wait(1).to({graphics:mask_graphics_40,x:44.9307,y:-8.9373}).wait(1).to({graphics:mask_graphics_41,x:49.4704,y:-9.1983}).wait(1).to({graphics:mask_graphics_42,x:55.1233,y:-9.5225}).wait(1).to({graphics:mask_graphics_43,x:61.9072,y:-9.9111}).wait(1).to({graphics:mask_graphics_44,x:69.6833,y:-10.356}).wait(1).to({graphics:mask_graphics_45,x:78.1053,y:-10.8376}).wait(1).to({graphics:mask_graphics_46,x:86.6687,y:-11.3271}).wait(1).to({graphics:mask_graphics_47,x:94.8687,y:-11.7957}).wait(1).to({graphics:mask_graphics_48,x:102.3487,y:-12.2231}).wait(1).to({graphics:mask_graphics_49,x:108.9412,y:-12.5998}).wait(1).to({graphics:mask_graphics_50,x:114.621,y:-12.9243}).wait(1).to({graphics:mask_graphics_51,x:119.4409,y:-13.1997}).wait(1).to({graphics:mask_graphics_52,x:123.4849,y:-13.4308}).wait(1).to({graphics:mask_graphics_53,x:126.8427,y:-13.6226}).wait(1).to({graphics:mask_graphics_54,x:129.5984,y:-13.7801}).wait(1).to({graphics:mask_graphics_55,x:131.8266,y:-13.9074}).wait(1).to({graphics:mask_graphics_56,x:133.5913,y:-14.0082}).wait(1).to({graphics:mask_graphics_57,x:134.9474,y:-14.0857}).wait(1).to({graphics:mask_graphics_58,x:135.9413,y:-14.1425}).wait(1).to({graphics:mask_graphics_59,x:136.6123,y:-14.1808}).wait(1).to({graphics:mask_graphics_60,x:136.9942,y:-14.2027}).wait(1).to({graphics:mask_graphics_61,x:137.7635,y:-14.1524}).wait(1));

	// Layer_3
	this.instance = new lib.highlight();
	this.instance.setTransform(171.6,-14.4,1.4856,1.4856,-3.2114,0,0,52.8,2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(36).to({_off:false},0).wait(26));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgXArIgEglIgCglQAAgPABAAIAZgCQACAAABAPIAEAkIACAmQAAAPgBAAIgZACIAAAAQgBAAgCgPg");
	var mask_1_graphics_1 = new cjs.Graphics().p("AgXArQgCgPgCgWQgCgVAAgQQABgPACAAIAogDQACgBACAQQADAPACAVQACAWgBAPQAAAQgCAAIgoADIAAAAQgCAAgDgPg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AglArQgEgPgCgWQgBgVABgQQABgPAEAAIBFgGQAEAAADAPQAEAPACAWQABAVgBAQQgBAPgEABIhFAFIAAAAQgEAAgDgPg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AhBArQgFgPgCgWQgCgVADgPQADgQAGgBIB0gJQAGAAAGAPQAFAPACAWQACAVgDAPQgDAQgGABIh0AJIgBAAQgFAAgGgPg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AhoAuQgIgPgCgWQgBgVAFgQQAFgQAKgBIC3gOQAJgBAIAPQAIAPACAWQABAVgFAQQgFAQgKABIi3AOIgBAAQgJAAgHgOg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AiaAxQgKgOgCgWQgCgVAJgQQAIgQAOgBIELgVQAOgBAKAOQALAPACAWQACAVgJAQQgIAQgOABIkLAVIgCAAQgMAAgLgOg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AjNA2QgOgPgBgWQgCgVALgQQAMgQASgCIFigcQATgBANAOQAPAPABAWQACAUgMARQgLAQgSACIliAcIgEAAQgQAAgNgNg");
	var mask_1_graphics_7 = new cjs.Graphics().p("Aj5A5QgRgOgCgWQgBgVAOgRQAOgQAWgCIGugiQAWgBARAOQARAOACAWQABAVgOAQQgOARgWACImuAiIgFAAQgTAAgPgNg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AkcA8QgTgOgCgWQgCgWARgQQARgRAZgCIHpgmQAZgCATAOQATAOACAWQACAWgRAQQgRARgZACInpAmIgGAAQgWAAgQgMg");
	var mask_1_graphics_9 = new cjs.Graphics().p("Ak2A+QgVgOgBgWQgCgWASgQQASgRAbgCIIWgqQAcgCAUAOQAVAOABAWQACAWgSAQQgSARgbACIoWAqIgHAAQgXAAgSgMg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AlJA/QgVgNgCgWQgCgWATgQQAUgRAdgDII1gsQAdgCAWANQAVAOACAWQACAWgUAQQgTARgdADIo1AsIgIAAQgYAAgTgMg");
	var mask_1_graphics_11 = new cjs.Graphics().p("AlWBAQgWgNgCgWQgBgWAUgQQAUgRAegDIJLguQAegCAWANQAXAOACAWQABAWgUAQQgUARgeADIpLAuIgIAAQgZAAgUgMg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AleBBQgXgOgBgVQgCgWAUgRQAVgRAfgCIJZgvQAfgDAWAOQAYAOABAWQACAVgVAQQgUASgfACIpZAvIgJABQgZAAgUgMg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AliBBQgXgNgCgWQgCgWAVgQQAVgRAfgDIJhgwQAfgCAXANQAXAOACAWQACAWgVAQQgVARgfADIphAwIgJAAQgZAAgUgMg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AlkBBQgXgNgBgWQgCgWAVgQQAVgRAfgDIJjgwQAfgCAXANQAYAOABAWQACAWgVAQQgVARgfADIpjAwIgJAAQgaAAgUgMg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:-2.9941,y:5.8386}).wait(1).to({graphics:mask_1_graphics_1,x:-2.9663,y:5.831}).wait(1).to({graphics:mask_1_graphics_2,x:-1.4134,y:5.8167}).wait(1).to({graphics:mask_1_graphics_3,x:1.4953,y:5.7941}).wait(1).to({graphics:mask_1_graphics_4,x:5.6696,y:5.5235}).wait(1).to({graphics:mask_1_graphics_5,x:10.8864,y:5.1114}).wait(1).to({graphics:mask_1_graphics_6,x:16.3018,y:4.6823}).wait(1).to({graphics:mask_1_graphics_7,x:21.0257,y:4.3071}).wait(1).to({graphics:mask_1_graphics_8,x:24.7269,y:4.0124}).wait(1).to({graphics:mask_1_graphics_9,x:27.4746,y:3.7933}).wait(1).to({graphics:mask_1_graphics_10,x:29.4435,y:3.6361}).wait(1).to({graphics:mask_1_graphics_11,x:30.7957,y:3.5281}).wait(1).to({graphics:mask_1_graphics_12,x:31.6577,y:3.4591}).wait(1).to({graphics:mask_1_graphics_13,x:32.1245,y:3.4218}).wait(1).to({graphics:mask_1_graphics_14,x:32.0674,y:3.4985}).wait(48));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AlKARQDIgsHNAP");
	this.shape.setTransform(33.35,3.6764);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(62));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("Ag5BVQgDgPgCgWQgBgWAAgQQABgOACAAIAwgEQADAAADAOQADAPACAWQABAWAAAQQgBAPgCABIgxADIAAAAQgCAAgDgPg");
	var mask_2_graphics_13 = new cjs.Graphics().p("Ag4BVQgEgPgCgWQgBgWABgQQABgOADAAIA/gFQADgBAEAPQADAPACAWQACAWgCAPQgBAQgDAAIg/AFIAAAAQgDAAgDgPg");
	var mask_2_graphics_14 = new cjs.Graphics().p("Ag3BVQgFgPgBgWQgCgWACgQQACgOAFAAIBcgIQAFAAAFAOQAEAPACAWQACAWgCAQQgDAPgEABIhdAHIAAAAQgFAAgEgPg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AhPBVQgHgPgBgWQgCgVAEgQQAEgPAHgBICNgLQAHAAAGAOQAHAPABAWQACAVgEAQQgEAQgHABIiNALIAAAAQgHAAgGgPg");
	var mask_2_graphics_16 = new cjs.Graphics().p("Ah4BVQgJgPgBgVQgCgWAGgQQAHgPAKgBIDSgRQALgBAJAPQAJAOABAWQACAWgGAQQgHAQgKABIjSAQIgBAAQgLAAgIgOg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AipBVQgLgOgCgWQgCgWAJgQQAKgQAPgBIElgXQAPgBAMAPQALAOACAVQACAWgKAQQgJARgPABIklAXIgCAAQgOAAgLgOg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AjYBVQgOgOgCgWQgCgWAMgQQANgQATgBIF1geQATgBAOAOQAPAPACAVQACAVgNARQgMARgTABIl1AdIgDAAQgRAAgOgNg");
	var mask_2_graphics_19 = new cjs.Graphics().p("Aj+BVQgRgOgBgWQgCgVAOgRQAPgQAWgCIG2giQAXgCARAOQARAPABAUQACAWgPARQgOARgWABIm2AjIgFAAQgTAAgQgNg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AkaBVQgTgOgBgVQgCgWAQgRQARgQAYgCIHmgmQAZgCATAOQATAOABAVQACAWgQAQQgRARgYACInmAnIgGAAQgVAAgRgNg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AkuBVQgUgNgCgWQgBgWARgRQASgQAagCIIIgpQAbgCAUAOQAUAOACAWQABAUgRARQgSARgaACIoIApIgHABQgXAAgRgNg");
	var mask_2_graphics_22 = new cjs.Graphics().p("Ak8BVQgUgNgCgWQgCgWASgRQATgQAcgCIIfgrQAcgCAUAOQAVAOACAVQACAVgTARQgSARgcADIofAqIgHABQgYAAgSgNg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AlEBVQgWgNgBgWQgCgWATgRQATgQAcgCIIugsQAdgDAVAOQAWAOABAWQACAVgTARQgTARgcACIouAsIgIAAQgYAAgSgMg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AlJBVQgVgNgCgWQgCgWATgRQAUgQAdgCII1gtQAdgCAWAOQAVANACAWQACAVgUARQgTARgdADIo1AsIgIAAQgYAAgTgMg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AlKBWQgWgOgCgVQgBgWATgRQATgQAdgDII4gsQAdgDAWAOQAWAOACAWQABAVgTARQgTARgdACIo4AtIgIAAQgYAAgTgMg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:-6.3963,y:10.034}).wait(1).to({graphics:mask_2_graphics_13,x:-6.3652,y:10.025}).wait(1).to({graphics:mask_2_graphics_14,x:-6.3159,y:10.0078}).wait(1).to({graphics:mask_2_graphics_15,x:-3.6078,y:9.98}).wait(1).to({graphics:mask_2_graphics_16,x:0.8668,y:9.9406}).wait(1).to({graphics:mask_2_graphics_17,x:6.2314,y:9.8939}).wait(1).to({graphics:mask_2_graphics_18,x:11.3994,y:9.8495}).wait(1).to({graphics:mask_2_graphics_19,x:15.5946,y:9.8139}).wait(1).to({graphics:mask_2_graphics_20,x:18.7089,y:9.7877}).wait(1).to({graphics:mask_2_graphics_21,x:20.9156,y:9.7693}).wait(1).to({graphics:mask_2_graphics_22,x:22.4121,y:9.7568}).wait(1).to({graphics:mask_2_graphics_23,x:23.3553,y:9.749}).wait(1).to({graphics:mask_2_graphics_24,x:23.8612,y:9.7448}).wait(1).to({graphics:mask_2_graphics_25,x:22.6162,y:9.8227}).wait(37));

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AkbAXQC4g3F/AM");
	this.shape_1.setTransform(25.95,11.7683);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(12).to({_off:false},0).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.4,-42.8,274.4,57.9);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,76.25,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,65.1,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,54.25,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,43.4,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,32.55,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,21.7,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,10.85,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,193.5,77.3), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(93.35,120.55,1,1,90,0,0,125.9,52.5);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(180.35,120.55,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(170.65,52.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(44.3,-5.8,193.5,193.5), null);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(-40.55,14.8,1,1,0,0,0,125.9,52.6);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-122.2,-43.6,193.5,193.5), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(709.6,6.4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(672.3,45.2,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(681.65,45,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// laptop
	this.laptop = new lib.laptop_1();
	this.laptop.name = "laptop";
	this.laptop.setTransform(235.65,50.8,0.34,0.34,0,0,0,184,127.7);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// highlights
	this.highlights = new lib.IntroTxtHighlights();
	this.highlights.name = "highlights";
	this.highlights.setTransform(537.1,58.65,1,1,0,0,0,93.4,2.4);

	this.timeline.addTween(cjs.Tween.get(this.highlights).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(227.4,105.5,1,1,0,0,0,133.3,23.7);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(314.6,46.45,0.8021,0.8021);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.instance = new lib.bg();
	this.instance.setTransform(364.95,46,2.4332,0.3682,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-28,-0.5,780.3,232.2), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, ease:Power4.easeOut, onComplete:function(){mc.highlights.play();}});
				this.tl1.from(mc.laptop,{duration:.8, scaleX:.5, scaleY:.5, y:"+=150", ease:Power2.easeOut}, "<");
				
				this.tl1.to([exportRoot.intro1, mc.highlights],{duration:0.6, alpha: 0, ease:Power4.easeIn}, ">+2");
		
				//laptop
		
				//chart transition
				this.tl1.to(mc.laptop,{duration:.6, scaleX:.55, scaleY:.55, x:"+=170", y:"+=16", ease:Power2.easeInOut}, ">-.2");
				this.tl1.from(mc.laptop.editorCursor, {duration:.8, x:"+=1100", ease:Sine.easeOut}, ">-.4");
				this.tl1.from(mc.laptop.editorCursor, {duration:.3, alpha:0 , ease:Sine.easeInOut}, "<");
				this.tl1.from(mc.laptop.editorCursor, {duration:.8, y:"+=250", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.6, x:"+=18", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.from(mc.laptop.socialScreen.dropdown, {duration:.3, y:"-=30", ease:Sine.easeInOut}, ">-.3");
				this.tl1.to(mc.laptop.editorCursor, {duration:.4, y:"+=18", x:"-=12", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.socialScreen.dropdown, {duration:.1, alpha:0, ease:Sine.easeInOut}, "<");
		
				//Editor Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">-2.2");
		
				//Word Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">+2.2");
		
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=80", y:"+=80", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.from(mc.laptop.wordScreen.sub.dropdown, {duration:.3, y:"-=30", ease:Sine.easeInOut}, ">-.3");
				this.tl1.to(mc.laptop.editorCursor, {duration:.4, y:"+=12", x:"-=4", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.1, y:"+=3", x:"-=3", ease:Sine.easeInOut}, ">+.1");
				this.tl1.to(mc.laptop.editorCursor, {duration:.2, y:"-=3", x:"+=3", ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.wordScreen.sub.dropdown, {duration:.1, alpha:0, ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.wordScreen.sub.panel, {duration:.2, alpha:0, ease:Sine.easeInOut}, ">");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=70", y:"-=110", ease:Sine.easeInOut}, "<");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, x:"+=150", ease:Power1.easeIn}, ">+.2");
				this.tl1.to(mc.laptop.editorCursor, {duration:.8, y:"+=165", ease:Power1.easeInOut}, "<");
				
				//Word Full Screen
				this.tl1.to(mc.laptop,{duration:.1, onComplete:function(){mc.laptop.play();}}, ">-.5");
				//this.
				
				this.tl1.to(mc.laptop.laptop,{duration:1.2, y:"+=250", ease:Power3.easeIn}, ">+.7");
				this.tl1.to(mc.laptop.wordScreen,{duration:.5, y:"+=5", rotation:"+=10", ease:Power1.easeInOut}, "<+.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.7, y:"-=120", ease:Power1.easeInOut}, ">-.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.5, y:"+=77", ease:Power1.easeIn}, ">");
				this.tl1.from(mc.laptop.angledShadow2,{duration:.5, alpha:0, ease:Power1.easeIn}, "<");
				this.tl1.to(mc.laptop.wordScreen,{duration:1.2, scaleX:.54, scaleY:.54, x:"-=145", ease:Power1.easeInOut}, ">-1.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:1, rotation:"-=48", ease:Power1.easeIn}, "<+.2");
				this.tl1.to(mc.laptop.wordScreen,{duration:.4, rotation:"+=17", ease:Back.easeOut}, ">");
				
				this.tl1.from(mc.anim,{duration:.6, alpha:0, ease:Power3.easeInOut}, "<-.6");
				this.tl1.from(mc.laptop.wordScreen.sml,{duration:.6, alpha:0, ease:Power3.easeInOut}, "<-.2");
				
				this.tl2 = gsap.timeline();	
					
				this.tl2.from([mc.laptop.socialScreenEnd, mc.laptop.angledShadow1],{duration:.6, x:"+=80", alpha:0, ease:Power2.easeOut});
				this.tl2.from(mc.laptop.socialScreenEnd,{duration:.4, rotation:"+=10", ease:Back.easeOut}, ">-.2");
				this.tl2.from(mc.laptop.editorCursorEnd,{duration:.8, x:"+=90", alpha:0, ease:Power3.easeOut}, "<+.2");
				
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.3");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");			
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");		
		
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:Linear.easeNone},">-2.8");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(336,44.5,416.29999999999995,187.2);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622808180322", id:"M365_FY22Q1BTS_USA_728x90_BAN_Editor_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;