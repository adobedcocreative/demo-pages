(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[752,205,130,199],[823,545,143,145],[0,0,750,500],[950,0,56,98],[428,772,218,73],[648,772,218,73],[752,0,196,203],[0,502,426,284],[428,502,393,268],[823,406,182,137]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BudgetMeeting_lg = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ExcelLogo = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_CU = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Group33 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.NewMeeting_lg_sh = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.NewSkypeMeeting_lg_sh = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.tileShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.UI = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.VirtualMeeting_lg = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.OutlookLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelLogo();
	this.instance.setTransform(-14,-22.5,0.87,0.87);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OutlookLogo, new cjs.Rectangle(-14,-22.5,124.4,126.2), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2204,21.2204,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6126,21.2204,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2204,6.6126,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6126,6.6126,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1623,14.0567,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9521,13.9117,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.4906,13.9117,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mail_lines_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A6CB1QgrAAgegfQgfgeAAgtQAAgpAfgfQAegeArAAIADAAQFBACJugEIR9gNIAJAAQPbgLDxAAQArAAAfAeQAfAfAAAsQAAAqgfAfQgfAfgrgBQkUAAuvAMIgoABQ0eAPnlgBIkWgBg");
	this.shape.setTransform(34.4412,47.6946,0.1945,0.1945);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("A0LBnQgrAAgeggQgfgeAAgrQACgsAegdQAfgeAqgBQJTAGVsgDIJWgBQArAAAgAfQAeAfAAAqQAAArgeAgQggAegrAAI3GACQrFAAmLgEg");
	this.shape_1.setTransform(41.7339,31.7381,0.1945,0.1945);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AN3B0IACgEQmJgRlVgBQmTAArOATQgrABgggdQgggdgBgrIAAgDQgBgqAdggQAegfAsgBQLxgUGjACQFRABG2AUQArACAeAgQAdAggCAqQgCArgeAdQgeAdgrAAg");
	this.shape_2.setTransform(47.9726,17.0536,0.1945,0.1945);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("An1BgIgDAAQgqgHgagjQgZgjAGgqQAHgrAkgaQAjgZArAHQBUAND6AAQCXAAFJgHICOgDQAsAAAfAeQAfAeABAsQABAqgeAfQgfAggrAAIiOADQlgAHiKAAIg8ABQiXAAiUgRg");
	this.shape_3.setTransform(57.3474,2.2121,0.1945,0.1945);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mail_lines_sub, new cjs.Rectangle(0,0,68.9,50), null);


(lib.line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AH2FDQhmgViBhpQgdgXjEi1QiLiChmg9QiKhTiGgEIAAAAQjegGkcB8QhcAohgA1IAAAAQgxAbgwAcQgJAGgKgDQgKgDgGgJQgFgIADgKQACgKAJgGQAxgcAygcIAAAAQBig2BegpQEoiBDnAHIAAAAQCTADCWBbQBpA/CQCHQDCCyAdAXQB1BgBdAUQDkAwEXiYQCNhNBehYQAIgGAKABQALAAAHAHQAHAIgBAKQAAAKgIAHQhiBbiTBRQjgB6jCAAQhAAAg8gNg");
	this.shape.setTransform(127.2216,31.1607);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_sub, new cjs.Rectangle(-2.5,-2.5,259.5,67.3), null);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.letter_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AmxFoQgRAAgPgGQgPgHgMgMQgKgLgGgOQgGgPAAgPIAAovQAAgPAGgOQAFgOALgLQALgNAPgGQAQgHARAAINjAAQAPAAAPAFQAOAGALAKQAMAMAHAPQAGAPAAARIAAIvQABAPgGAPQgGAOgLALQgLAMgQAHQgPAGgQAAgAm8E/QAFABAGAAINjAAQAFAAAFgBIlvkBIhAA3QgGAFgHAAQgGAAgGgFIhAg4gAFbiuIjwDQIFuEAIACgKIAAovQgBgGgCgGgAnakXIAAIvQAAAFACAFIFtj/IjvjOIh/h1IgBAJgAm+k9IB/B0IE/EVIFJkgIByhqIgJgBItjAAQgGAAgHACg");
	this.shape.setTransform(51.4519,36.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letter_sub, new cjs.Rectangle(0,0,102.9,72.1), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.fileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tileShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fileShadow, new cjs.Rectangle(0,0,196,203), null);


(lib.file4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.NewSkypeMeeting_lg_sh();
	this.instance.setTransform(35,60,0.66,0.66);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file4, new cjs.Rectangle(35,60,148.4,52), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.NewMeeting_lg_sh();
	this.instance.setTransform(21,62,0.685,0.6848);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file1, new cjs.Rectangle(0,61.2,196,74.3), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.UI();
	this.instance.setTransform(-1,0,0.8826,0.8803);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(-1,0,376,250), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.calendar_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("A5ndQQijAAhyhkQh0hmAAiOMAAAgwBQABiHBshfQBuhgCagBMAz3AAAQCaABBuBgQBtBfAACHMAAAAwBQAACOhzBmQhzBkiiAAgANqadIL+AAQBPABA3gxQA2gwABhFIAAqiIu7AAgAncadIR6AAIAAtHIx6AAgA8jX4QAABFA3AwQA3AxBOgBIO/AAIAAtHIx7AAgANqKiIO7AAIAAtGIu7AAgAncKiIR6AAIAAtGIx6AAgA8jKiIR7AAIAAtGIx7AAgANqlXIO7AAIAAtIIu7AAgAnclXIR6AAIAAtIIx6AAgA8jlXIR7AAIAAtIIx7AAgA7u51QgxArgEBBIAAC3MA5IAAAIAAi3QgFhBgxgrQgygrhBAEMgz3AAAIgKgBQg7AAguAog");
	this.shape.setTransform(53.7185,49.4897,0.2643,0.2643);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.calendar_sub, new cjs.Rectangle(0,0,107.5,99), null);


(lib.bang_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABTDbQgDgBgCgEQgCgEABgEQACgDAEgCIBRgmIgrgQIABAAIg1gTQgEgBgCgDQgCgEABgEQABgDADgDQBPgzAggaIg9AHIhHAJQgDAAgEgCQgDgCgBgDQgBgDACgEIA4iHIhxBjQgDACgEAAQgDAAgDgCQgDgDAAgEIgDieIhICbQgCAEgEABQgDACgEgCQgEgBgBgEIgzh/QgFAfgEAzQgDApAAAiQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEQAAgjADgpQAGhVANghQABgCACgCQADgCADAAQADAAADACQACACABACQANAkAoBjIBQitQABgDADgCQAEgCADABQADABADADQACACAAAEIADCzICBhxQADgCADAAQAEAAADACQADACABADQABAEgCADIhCCeIA2gHQBLgJAQAAQAEAAACACQADADABAEQAAAEgCADQgPAVhnBEIAhAMIAAAAQA5AVAIAFQAEADAAADQACAEgCADQgBADgEACIhlAvIgEABIgEgBg");
	this.shape.setTransform(20.5024,21.0027);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_sub, new cjs.Rectangle(-1,-1,43,44), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AotCHIAAkNIRbAAIAAENg");
	this.shape.setTransform(50.05,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-5.7,0,111.60000000000001,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Group33();
	this.instance.setTransform(44.7,58.3,0.5,0.5102);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(41,44.9,38.099999999999994,72.1), null);


(lib.squiggle_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-270,-70,540,140,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.line_sub();
	this.line.name = "line";
	this.line.setTransform(127.2,31.2,1,1,0,0,0,127.2,31.2);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squiggle_line, new cjs.Rectangle(-2.5,-2.5,259.5,67.3), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mail_lines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.lines.cache(0,0,70,70,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.lines = new lib.mail_lines_sub();
	this.lines.name = "lines";
	this.lines.setTransform(34.5,24.95,1,1,0,0,0,34.5,25);

	this.timeline.addTween(cjs.Tween.get(this.lines).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mail_lines, new cjs.Rectangle(0,0,68.9,50), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_90 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(90).call(this.frame_90).wait(2));

	// Layer_3 copy 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_61 = new cjs.Graphics().p("AIwCDIgChRIABhQQABghACAAIAeAAQACAAABAhIACBQIgBBRQgBAhgCAAIgeAAQgCAAgBghg");
	var mask_graphics_62 = new cjs.Graphics().p("AIpCDQgCghAAgvQgBgvABghQABghADAAIAqgBQACAAACAhQACAhAAAvQABAwgBAhQgBAigDAAIgqAAQgCAAgCgig");
	var mask_graphics_63 = new cjs.Graphics().p("AIhCEQgDghgBgvQgBgvACghQABghADAAIA4gCQADAAACAhQADAhABAvQABAwgBAhQgBAigDAAIg4ABIAAAAQgDAAgDgig");
	var mask_graphics_64 = new cjs.Graphics().p("AIYCFQgEghgBgvQgCgvABghQACghAEAAIBIgDQADAAAEAhQAEAhACAvQABAvgBAhQgCAigEAAIhIADIAAAAQgDAAgEgig");
	var mask_graphics_65 = new cjs.Graphics().p("AINCGQgFghgCgvQgCgvABghQACghAFAAIBbgEQAEgBAFAhQAFAhACAvQACAvgBAiQgCAhgFABIhaAEIAAAAQgFAAgFgig");
	var mask_graphics_66 = new cjs.Graphics().p("AIBCIQgGghgDgvQgDgvACghQACgiAGAAIBvgHQAGAAAGAhQAGAgADAvQADAvgCAiQgCAigFAAIhwAHIAAAAQgGAAgGghg");
	var mask_graphics_67 = new cjs.Graphics().p("AHzCJQgHgggEgvQgEgvADghQACgiAHAAICHgLQAHgBAHAhQAIAhAEAvQADAvgCAhQgCAigHABIiHAKIAAAAQgHAAgIghg");
	var mask_graphics_68 = new cjs.Graphics().p("AHlCLQgJgggFgvQgFgvADghQACgiAJgBICggPQAJgBAJAgQAJAhAEAuQAFAvgDAiQgCAigIABIihAQIAAAAQgIAAgJghg");
	var mask_graphics_69 = new cjs.Graphics().p("AHVCNQgLgggGgvQgFgvADghQADgiAJgBIC8gWQAKgBALAgQALAhAFAuQAGAvgDAhQgDAjgKABIi8AWIgBAAQgJAAgKggg");
	var mask_graphics_70 = new cjs.Graphics().p("AHECQQgNgggGgvQgHgvADghQAEgiALgCIDZgeQALgBANAfQAMAhAHAtQAGAvgDAiQgDAjgLABIjaAfIgBAAQgKAAgMgfg");
	var mask_graphics_71 = new cjs.Graphics().p("AGyCSQgOgfgIgvQgHguADgiQAEgiAMgCID4gpQANgCAOAgQAPAgAHAtQAIAvgEAiQgDAjgNACIj4AoIgBAAQgMAAgOgeg");
	var mask_graphics_72 = new cjs.Graphics().p("AGgCVQgQgfgJguQgIgvADgiQAEgiAPgDIEXg0QAOgDAQAfQAQAfAJAuQAJAugEAjQgEAjgOACIkXA1IgCAAQgOAAgPgdg");
	var mask_graphics_73 = new cjs.Graphics().p("AGOCYQgSgegKguQgKgvAFgiQAEgjAQgDIE2hCQAQgDASAeQASAeAKAvQAKAtgEAjQgEAjgQADIk3BCIgDABQgOAAgRgcg");
	var mask_graphics_74 = new cjs.Graphics().p("AF8CbQgUgdgLguQgKguAEgjQAFgjARgEIFVhRQASgFAUAeQAUAeALAuQALAtgFAjQgEAjgSAFIlVBRIgEAAQgQAAgSgag");
	var mask_graphics_75 = new cjs.Graphics().p("AFrCeQgWgdgMgtQgMguAFgkQAFgjATgFIFzhhQATgFAWAcQAWAdAMAuQAMAtgFAjQgFAkgSAFIl0BiIgFABQgRAAgTgZg");
	var mask_graphics_76 = new cjs.Graphics().p("AFbChQgYgcgNgtQgNgtAFglQAFgjAVgGIGQhzQAUgGAYAcQAYAcANAtQANAugGAjQgFAkgUAGImQBzIgHABQgSAAgTgXg");
	var mask_graphics_77 = new cjs.Graphics().p("AFLCkQgZgbgOgtQgOgtAFglQAGgkAVgGIGriGQAWgHAZAbQAaAcAOAtQAOAtgFAjQgGAlgVAHImrCGIgJABQgSAAgVgWg");
	var mask_graphics_78 = new cjs.Graphics().p("AE9CnQgbgagPgtQgPgtAGglQAFgkAXgIIHEiXQAXgIAbAaQAbAaAPAtQAPAtgFAlQgGAkgXAIInECYQgFABgFAAQgTAAgVgUg");
	var mask_graphics_79 = new cjs.Graphics().p("AEwCvQgcgZgQgsQgQgtAGglQAGglAYgJIHaipQAZgJAcAZQAdAaAPAsQAQAtgGAlQgFAlgZAJInaCpQgGADgHAAQgTAAgVgUg");
	var mask_graphics_80 = new cjs.Graphics().p("AElC5QgegYgRgsQgQgsAFgnQAHglAZgJIHvi7QAZgKAdAYQAeAZARAsQARAtgGAlQgGAmgZAJInvC7QgHADgIAAQgTAAgVgSg");
	var mask_graphics_81 = new cjs.Graphics().p("AEaDCQgegXgSgsQgRgsAGgnQAGgmAagJIIBjMQAagKAfAXQAfAYARAsQASAsgHAmQgFAngbAJIoADMQgIADgJAAQgTAAgWgRg");
	var mask_graphics_82 = new cjs.Graphics().p("AERDLQgfgXgSgsQgSgrAGgnQAGgnAbgLIIRjaQAbgLAfAXQAgAXASAsQATArgHAnQgGAngbALIoRDaQgIAEgKAAQgTAAgWgQg");
	var mask_graphics_83 = new cjs.Graphics().p("AEKDTQghgWgSgsQgTgrAGgoQAHgnAbgLIIejoQAcgMAhAWQAhAXASArQATArgHAnQgGAogbAMIofDnQgJAEgKAAQgUAAgVgOg");
	var mask_graphics_84 = new cjs.Graphics().p("AEDDaQghgWgTgrQgTgrAGgoQAHgnAcgNIIpj0QAdgMAhAVQAiAWATArQATArgHAoQgGAngcANIoqD0QgKAFgLAAQgTAAgWgOg");
	var mask_graphics_85 = new cjs.Graphics().p("AD+DgQgigWgUgqQgTgrAGgoQAHgoAcgNII0j/QAdgNAiAVQAiAWAUArQATArgHAnQgGAogdANIozD/QgLAFgMAAQgTAAgVgNg");
	var mask_graphics_86 = new cjs.Graphics().p("AD5DlQgigVgUgrQgUgrAGgoQAHgoAdgNII8kIQAdgOAiAVQAjAVAUArQAUArgHAoQgGAogdANIo8EIQgLAFgMAAQgTAAgWgMg");
	var mask_graphics_87 = new cjs.Graphics().p("AD2DpQgjgVgUgqQgUgrAGgoQAHgoAdgOIJCkPQAdgOAjAUQAkAVAUAqQAUArgHAoQgGAogeAOIpBEPQgMAGgNAAQgTAAgVgMg");
	var mask_graphics_88 = new cjs.Graphics().p("ADzDsQgjgUgUgrQgVgqAHgpQAGgoAegOIJGkVQAegOAjAUQAkAUAUArQAVAqgHAoQgGApgeAOIpHEVQgMAGgNAAQgTAAgVgMg");
	var mask_graphics_89 = new cjs.Graphics().p("ADxDuQgjgTgVgrQgUgrAGgoQAHgoAegPIJKkZQAegOAjATQAkAVAUAqQAVArgHAoQgGAogeAPIpKEZQgMAGgOAAQgTAAgVgMg");
	var mask_graphics_90 = new cjs.Graphics().p("AEODwQgkgUgVgqQgUgrAGgoQAHgpAegOIJMkcQAegPAkAUQAkAUAUAqQAVArgHAoQgGApgeAOIpMEcQgNAGgOAAQgSAAgVgLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(61).to({graphics:mask_graphics_61,x:59.6528,y:16.4347}).wait(1).to({graphics:mask_graphics_62,x:60.3401,y:16.501}).wait(1).to({graphics:mask_graphics_63,x:61.1667,y:16.5798}).wait(1).to({graphics:mask_graphics_64,x:62.1356,y:16.6711}).wait(1).to({graphics:mask_graphics_65,x:63.2487,y:16.7751}).wait(1).to({graphics:mask_graphics_66,x:64.5054,y:16.8912}).wait(1).to({graphics:mask_graphics_67,x:65.902,y:17.0189}).wait(1).to({graphics:mask_graphics_68,x:67.4303,y:17.1572}).wait(1).to({graphics:mask_graphics_69,x:69.0771,y:17.305}).wait(1).to({graphics:mask_graphics_70,x:70.8238,y:17.4605}).wait(1).to({graphics:mask_graphics_71,x:72.6461,y:17.6219}).wait(1).to({graphics:mask_graphics_72,x:74.5147,y:17.7871}).wait(1).to({graphics:mask_graphics_73,x:76.3972,y:17.9539}).wait(1).to({graphics:mask_graphics_74,x:78.2599,y:18.1201}).wait(1).to({graphics:mask_graphics_75,x:80.0703,y:18.2836}).wait(1).to({graphics:mask_graphics_76,x:81.7996,y:18.4425}).wait(1).to({graphics:mask_graphics_77,x:83.4241,y:18.5951}).wait(1).to({graphics:mask_graphics_78,x:84.9265,y:18.74}).wait(1).to({graphics:mask_graphics_79,x:86.296,y:18.295}).wait(1).to({graphics:mask_graphics_80,x:87.5273,y:17.7001}).wait(1).to({graphics:mask_graphics_81,x:88.6201,y:17.1263}).wait(1).to({graphics:mask_graphics_82,x:89.5776,y:16.5859}).wait(1).to({graphics:mask_graphics_83,x:90.4055,y:16.0884}).wait(1).to({graphics:mask_graphics_84,x:91.1109,y:15.6413}).wait(1).to({graphics:mask_graphics_85,x:91.7018,y:15.2493}).wait(1).to({graphics:mask_graphics_86,x:92.1862,y:14.9157}).wait(1).to({graphics:mask_graphics_87,x:92.5718,y:14.6418}).wait(1).to({graphics:mask_graphics_88,x:92.8659,y:14.4279}).wait(1).to({graphics:mask_graphics_89,x:93.0752,y:14.2729}).wait(1).to({graphics:mask_graphics_90,x:96.1754,y:11.2393}).wait(2));

	// Layer_12
	this.instance = new lib.squiggle_line();
	this.instance.setTransform(85.2,2.9,0.6662,0.6662,0,0,0,127.2,31.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61).to({_off:false},0).wait(31));

	// Layer_3 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_37 = new cjs.Graphics().p("AEABAIg0gFQgDAAABgdQABgdADgoQAEgpAEgeQAFgcADAAIA0AFQADAAgBAdQgBAdgDApQgEAogFAdQgEAdgDAAIAAAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AEFBBIg/gGQgDAAABgeQAAgdAEgoQAEgpAFgdQAGgcADAAIA/AGQADAAgBAdQAAAegEApQgEAogFAcQgFAdgEAAIAAAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AELBDIhLgIQgEgBAAgdQABgdAEgoQAFgpAFgdQAGgdAEABIBMAIQAEAAgBAdQAAAegFApQgEAogGAcQgGAdgEAAIAAAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AESBFIhagLQgFgBAAgdQAAgcAFgpQAFgpAHgdQAHgcAFAAIBbAMQAEAAAAAdQAAAegFApQgFAngHAdQgHAcgEAAIgBAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AEaBIIhsgPQgFgBAAgdQAAgcAGgpQAFgpAIgcQAIgcAGAAIBsAPQAFABAAAdQAAAegGAoQgFAogIAcQgIAcgFAAIgBAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AEkBMIiAgUQgHgBAAgdQAAgdAGgoQAHgpAJgcQAJgcAGABICAAUQAHABAAAdQAAAegGApQgHAngJAcQgIAbgHAAIAAAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AEuBSIiWgbQgHgBgBgeQAAgcAHgoQAHgpAKgcQALgbAIABICVAaQAIACAAAdQABAegHAoQgIAogKAbQgKAbgHAAIgBAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AE5BZIitgjQgJgBgBgeQgBgdAIgoQAIgoAMgcQAMgbAJACICuAiQAIACABAeQABAdgIApQgIAngMAbQgLAagJAAIgBAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AFFBhIjHgsQgKgCgBgeQgBgdAJgoQAJgoANgbQAOgaAKACIDHAsQAKACABAeQABAegJAnQgJAogNAbQgNAZgJAAIgCgBg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AFSBsIjjg4QgLgDgBgeQgCgdAKgoQAKgnAPgbQAPgaAMADIDjA4QALADABAeQACAfgKAmQgKAogPAaQgOAYgLAAIgCgBg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AFfB5Ij/hGQgNgEgBgfQgCgdALgnQALgnARgaQARgZANADID/BHQANADABAfQACAegLAnQgLAngRAZQgPAXgLAAIgEgBg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AFtCIIkchXQgOgEgCgfQgCgeAMgnQAMgnATgYQASgZAPAFIEcBXQAOAEACAfQACAegMAnQgMAngTAYQgQAVgNAAIgEgBg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AF6CSIk4hpQgQgGgCgfQgCgeANgnQANgmAUgYQAVgXAQAFIE4BpQAQAGACAfQACAegNAnQgNAmgUAYQgRATgOAAIgGgBg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AGICbIlVh+QgRgGgDgfQgCgfAOgmQAOgmAXgXQAWgWARAGIFVB+QARAGACAeQADAggOAmQgOAngXAWQgRARgOAAIgIgBg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AGUClIlviUQgTgHgCggQgDgfAPgmQAPgmAYgVQAYgVATAHIFwCUQASAHADAfQACAggPAmQgPAmgYAVQgSAQgPAAQgFAAgFgCg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AGgCvImJiqQgUgIgCghQgCggAPglQAQglAagVQAagUAUAJIGJCqQAUAIACAgQADAhgQAlQgQAmgaATQgSAPgPAAQgHAAgGgDg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AGsC6ImhjBQgUgKgDgiQgDggAQglQARglAbgTQAcgTAVAKIGgDBQAVAKADAhQADAhgRAlQgRAlgbASQgSANgPAAQgIAAgHgDg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AG2DEIm2jYQgVgLgDgiQgDghASglQARgkAcgSQAdgRAWALIG2DYQAWALADAiQADAhgSAlQgSAkgcARQgSAMgPAAQgKAAgIgFg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AG/DPInIjwQgXgMgDgiQgEgiATgkQATgkAdgQQAegRAXAMIHJDwQAXAMADAiQADAigSAkQgTAkgeAQQgRAKgQAAQgKAAgKgFg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AHHDZInZkGQgYgNgDgjQgDgiATgkQAUgjAegQQAfgPAYAOIHZEFQAYANAEAjQADAigUAkQgTAjgfAPQgRAJgPAAQgMAAgLgGg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AHODiInnkaQgZgPgDgjQgEgjAUgiQAVgjAfgPQAggOAZAOIHnEaQAZAPAEAjQADAjgUAjQgUAiggAPQgRAHgOAAQgOAAgMgHg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AHUDqIn0ktQgZgPgEgkQgDgjAVgiQAVgjAfgOQAhgNAaAQIH0EtQAaAPADAjQADAkgUAiQgVAjghANQgPAHgOAAQgQAAgNgJg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AHZDyIn+k+QgagRgEgkQgDgjAVgiQAWgiAggNQAigMAaAQIH/E+QAaARADAjQAEAkgWAiQgVAigiANQgOAFgOAAQgRAAgOgJg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AHdD5IoHlOQgagRgEgkQgDgkAWgiQAVghAigMQAigMAaARIIIFOQAbARADAkQADAkgVAiQgWAigiALQgPAFgMAAQgTAAgPgKg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AHhD/IoPlbQgagSgEgkQgDgkAWgiQAWghAjgMQAigLAaASIIQFbQAaASAEAkQADAkgWAiQgWAhgjALQgOAFgMAAQgTAAgQgLg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AHjEEIoUlmQgbgSgDglQgDgkAWgiQAWghAkgLQAigKAbASIIVFmQAbASADAlQAEAlgXAhQgWAhgjALQgNAEgMAAQgVAAgRgMg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AHmEIIoZlvQgbgTgEglQgDgkAXghQAWghAkgLQAigKAcATIIZFvQAcATADAkQADAlgWAiQgXAhgkAKQgMADgMAAQgVAAgRgMg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AHnELIocl2QgbgTgEglQgDglAXghQAXghAjgKQAjgJAcATIIdF2QAbATAEAlQADAlgXAhQgXAhgjAJQgNAEgLAAQgWAAgSgNg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AHoEOIoel7QgcgUgDglQgDglAXghQAXghAkgKQAjgJAbAUIIgF7QAbATAEAlQADAlgXAhQgXAhgkAJQgMADgLAAQgWAAgTgMg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AHuEPIofl+QgcgUgEglQgDglAXghQAXghAkgJQAjgJAcATIIhF+QAcAUADAlQADAlgXAhQgXAhgkAJQgMADgLAAQgWAAgTgNg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(37).to({graphics:mask_1_graphics_37,x:27.6067,y:-13.9025}).wait(1).to({graphics:mask_1_graphics_38,x:28.3441,y:-13.9182}).wait(1).to({graphics:mask_1_graphics_39,x:29.2378,y:-13.9354}).wait(1).to({graphics:mask_1_graphics_40,x:30.2925,y:-13.9534}).wait(1).to({graphics:mask_1_graphics_41,x:31.5103,y:-13.9712}).wait(1).to({graphics:mask_1_graphics_42,x:32.8906,y:-13.9874}).wait(1).to({graphics:mask_1_graphics_43,x:34.4282,y:-14.0007}).wait(1).to({graphics:mask_1_graphics_44,x:36.1132,y:-14.0096}).wait(1).to({graphics:mask_1_graphics_45,x:37.9293,y:-14.0127}).wait(1).to({graphics:mask_1_graphics_46,x:39.8537,y:-14.0087}).wait(1).to({graphics:mask_1_graphics_47,x:41.8572,y:-13.9969}).wait(1).to({graphics:mask_1_graphics_48,x:43.9047,y:-13.9771}).wait(1).to({graphics:mask_1_graphics_49,x:45.9577,y:-13.2067}).wait(1).to({graphics:mask_1_graphics_50,x:47.9767,y:-12.1832}).wait(1).to({graphics:mask_1_graphics_51,x:49.9243,y:-11.0697}).wait(1).to({graphics:mask_1_graphics_52,x:51.7679,y:-9.8906}).wait(1).to({graphics:mask_1_graphics_53,x:53.4821,y:-8.6739}).wait(1).to({graphics:mask_1_graphics_54,x:55.0495,y:-7.4487}).wait(1).to({graphics:mask_1_graphics_55,x:56.4607,y:-6.2431}).wait(1).to({graphics:mask_1_graphics_56,x:57.7133,y:-5.0822}).wait(1).to({graphics:mask_1_graphics_57,x:58.8105,y:-3.9871}).wait(1).to({graphics:mask_1_graphics_58,x:59.7593,y:-2.9747}).wait(1).to({graphics:mask_1_graphics_59,x:60.5692,y:-2.0572}).wait(1).to({graphics:mask_1_graphics_60,x:61.2511,y:-1.2431}).wait(1).to({graphics:mask_1_graphics_61,x:61.8159,y:-0.5373}).wait(1).to({graphics:mask_1_graphics_62,x:62.2741,y:0.058}).wait(1).to({graphics:mask_1_graphics_63,x:62.6357,y:0.5429}).wait(1).to({graphics:mask_1_graphics_64,x:62.9093,y:0.9194}).wait(1).to({graphics:mask_1_graphics_65,x:63.1026,y:1.1904}).wait(1).to({graphics:mask_1_graphics_66,x:63.7439,y:2.1481}).wait(26));

	// Layer_11
	this.instance_1 = new lib.squiggle_line();
	this.instance_1.setTransform(85.2,2.9,0.6662,0.6662,0,0,0,127.2,31.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(37).to({_off:false},0).wait(55));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_3 = new cjs.Graphics().p("AAUAyIgegqIgegqQgMgSABgBIASgNQABAAANARIAeAqIAeAqQAMASgBABIgSANIAAAAQgBAAgNgRg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AAUAyIgegqIgegqQgMgSABgBIASgNQABgBANASIAeAqIAeAqQAMASgBABIgSANIAAAAQgBAAgNgRg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AATAzIgegrIgegqQgMgSABgBIATgNQABgBANARIAfArIAeAqQAMASgBABIgTANIAAAAQgCAAgNgQg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AATAzIgfgqIgegqQgLgSABgBIAUgPQABAAANARIAfAqIAdAqQAMASgBABIgUAPIAAAAQgBAAgNgRg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AASA0IgfgqIgdgrQgMgSABgBIAWgPQABgBANARIAfAqIAdAqQAMATgBABIgWAPIAAAAQgBAAgNgQg");
	var mask_2_graphics_8 = new cjs.Graphics().p("AAQA1IgegqIgegrQgLgSABgBIAYgRQABgBAOARIAeAqIAeArQALASgBABIgYARIAAAAQgCAAgNgQg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AAOA2IgegqIgdgrQgMgSABgBIAbgTQACgBANARIAfAqIAdAqQAMATgBABIgbATIgBAAQgCAAgNgQg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AAMA3QgMgQgSgaQgSgYgLgSQgMgTACgBIAegVQACgBANAQQANASASAZQASAYALASQAMATgCABIgeAVIAAAAQgDAAgNgQg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AAKA5QgNgRgRgZQgSgYgMgTQgLgSACgCIAigYQACgBAOARQANARASAZQARAYALATQAMASgCACIgiAYIgBAAQgCAAgNgQg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AAHA7QgNgRgRgZQgSgYgLgTQgLgTACgBIAngcQACgBAOARQANARARAZQASAYALATQALATgCABIgnAcIAAAAQgDAAgNgQg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AAEA9QgNgQgSgaQgRgYgLgTQgLgTACgBIAtggQACgBAOARQANAQASAaQARAYALATQALATgCABIgtAgIAAAAQgDAAgNgQg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AAABAQgNgRgSgZQgRgYgLgUQgKgTACgCIAzgjQADgBANAQQAOARASAZQARAYALATQAKAUgCACIgzAjIgBAAQgDAAgNgPg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AgDBCQgPgQgRgZQgRgZgLgTQgKgTADgCIA6goQADgCANAQQAPARARAZQARAZALATQAKATgDACIg6AoIgBAAQgDAAgMgPg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AgIBFQgPgQgRgZQgRgagKgSQgKgUADgCIBCgtQADgCAOAQQAPARARAZQARAaAKASQAKAUgDACIhCAtIgBAAQgEAAgMgPg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AgNBJQgPgQgRgaQgRgZgKgTQgJgUADgDIBLgyQADgCAOAQQAPAQARAaQARAZAKATQAJAUgDADIhLAyIgBAAQgDAAgNgOg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AgTBMQgPgQgRgZQgRgagJgTQgJgUAEgDIBTg4QAEgDAPAQQAPARARAZQARAaAJATQAJAUgEADIhTA4IgBAAQgFAAgNgOg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AgaBQQgPgQgRgZQgRgagIgUQgJgUAFgDIBdg+QAFgDAPAQQAQAQARAZQARAaAIATQAJAVgFADIhdA+IgCABQgGAAgNgOg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AghBUQgPgPgRgaQgRgagIgUQgIgUAGgEIBohFQAGgDAPAQQAQAPARAaQARAaAIAUQAIAUgGAEIhoBFIgDAAQgGAAgNgNg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AgoBZQgQgQgRgaQgQgagIgVQgHgUAGgEIB1hLQAGgEAQAPQAQAQARAaQAQAaAIAUQAHAVgGAEIh1BLIgDABQgGAAgNgMg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AgxBdQgQgPgQgaQgRgagHgWQgGgUAGgEICEhTQAGgFARAQQAQAPAQAaQARAaAGAVQAHAVgGAEIiDBTIgEABQgHAAgNgMg");
	var mask_2_graphics_23 = new cjs.Graphics().p("Ag6BiQgQgPgRgaQgQgagGgWQgGgVAHgFICShbQAIgEARAPQARAPAQAaQAQAaAGAWQAGAVgHAFIiSBbIgEABQgIAAgNgMg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AhEBnQgRgPgQgaQgQgagFgXQgFgVAIgFICihjQAIgFARAPQASAPAQAaQAQAaAFAXQAGAVgJAFIiiBjIgFABQgIAAgNgLg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AhOBsQgSgPgPgaQgQgagFgXQgEgWAJgFICzhsQAKgFARAPQASAPAQAaQAPAaAFAXQAFAWgKAFIizBsQgDABgDAAQgIAAgNgLg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AhaBxQgSgOgPgbQgQgagDgXQgEgXAKgFIDGh0QAKgGASAOQATAPAPAbQAQAaADAXQAEAWgKAGIjGB0QgDACgEAAQgIAAgOgLg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AhmB3QgSgOgPgbQgQgbgDgXQgCgYALgFIDah9QALgGATAOQASAPAQAaQAPAbADAXQADAYgMAFIjaB9QgDACgEAAQgKAAgNgKg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AhyB8QgUgOgPgbQgOgbgDgYQgBgXAMgHIDviFQAMgHATAPQAUAOAPAbQAPAbABAXQADAYgNAHIjvCFQgEACgEAAQgKAAgNgKg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AiACCQgUgOgOgbQgPgbgBgZQgBgYAOgHIEFiNQANgIAUAOQAUAOAPAbQAOAbABAZQABAYgNAHIkGCNQgEADgFAAQgLAAgNgJg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AiOCHQgUgOgPgbQgOgbAAgZQAAgZAPgHIEciWQAPgIAUAOQAVAOAOAbQAOAbAAAZQAAAZgOAHIkdCWQgFADgGAAQgLAAgNgJg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AidCMQgVgOgOgbQgOgbABgaQACgZAPgIIE1ieQAQgIAVAOQAVAOAOAbQAOAbgBAZQgBAagQAIIk1CeQgGADgGAAQgLAAgOgJg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AisCRQgVgOgOgbQgOgcACgZQADgaARgIIFNimQARgIAWANQAWAOANAbQAOAcgCAZQgDAagRAIIlNCmQgGADgIAAQgLAAgOgIg");
	var mask_2_graphics_33 = new cjs.Graphics().p("Ai7CVQgWgNgOgcQgNgbADgaQAEgaASgJIFmitQATgJAWAOQAXANANAcQANAbgDAaQgEAagSAJIlmCtQgHADgIAAQgMAAgOgIg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AjKCZQgXgNgNgbQgNgcAEgbQAFgaATgJIGAizQATgKAXANQAXAOANAbQAOAcgFAaQgFAbgTAJIl/C0QgIADgJAAQgMAAgOgIg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AjZCdQgYgNgNgcQgMgcAFgaQAGgbAVgJIGYi6QAUgJAYANQAYANANAcQANAcgGAaQgGAbgVAJImXC6QgJAEgJAAQgNAAgOgIg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AjoCgQgYgMgMgdQgNgcAHgbQAHgaAWgKIGvi/QAWgJAYAMQAZANAMAdQANAcgHAaQgHAbgWAKImvC/QgJAEgKAAQgOAAgOgIg");
	var mask_2_graphics_37 = new cjs.Graphics().p("Aj1CjQgZgNgMgcQgMgcAHgbQAIgbAXgKIHGjDQAXgKAZANQAZANAMAcQANAcgIAbQgIAbgXAKInGDDQgKAFgKAAQgOAAgOgIg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AkCCmQgZgNgMgcQgMgdAIgbQAJgbAZgLIHajGQAYgLAaANQAZANAMAdQAMAcgJAbQgIAbgYALInbDGQgLAFgLAAQgNAAgPgHg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AkNCoQgagNgMgdQgMgcAKgcQAKgbAZgKIHtjKQAZgKAaAMQAaANAMAdQAMAcgKAbQgJAcgaAKIntDKQgLAFgLAAQgPAAgOgHg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(3).to({graphics:mask_2_graphics_3,x:-3.5994,y:1.8998}).wait(1).to({graphics:mask_2_graphics_4,x:-3.5837,y:1.8904}).wait(1).to({graphics:mask_2_graphics_5,x:-3.5355,y:1.8618}).wait(1).to({graphics:mask_2_graphics_6,x:-3.4535,y:1.8132}).wait(1).to({graphics:mask_2_graphics_7,x:-3.3362,y:1.744}).wait(1).to({graphics:mask_2_graphics_8,x:-3.1819,y:1.6534}).wait(1).to({graphics:mask_2_graphics_9,x:-2.9888,y:1.5407}).wait(1).to({graphics:mask_2_graphics_10,x:-2.7551,y:1.4055}).wait(1).to({graphics:mask_2_graphics_11,x:-2.4786,y:1.247}).wait(1).to({graphics:mask_2_graphics_12,x:-2.1571,y:1.0648}).wait(1).to({graphics:mask_2_graphics_13,x:-1.7882,y:0.8585}).wait(1).to({graphics:mask_2_graphics_14,x:-1.3693,y:0.6276}).wait(1).to({graphics:mask_2_graphics_15,x:-0.8977,y:0.3721}).wait(1).to({graphics:mask_2_graphics_16,x:-0.3703,y:0.0917}).wait(1).to({graphics:mask_2_graphics_17,x:0.2159,y:-0.2133}).wait(1).to({graphics:mask_2_graphics_18,x:0.8642,y:-0.5427}).wait(1).to({graphics:mask_2_graphics_19,x:1.5779,y:-0.8958}).wait(1).to({graphics:mask_2_graphics_20,x:2.3605,y:-1.2718}).wait(1).to({graphics:mask_2_graphics_21,x:3.2154,y:-1.6694}).wait(1).to({graphics:mask_2_graphics_22,x:4.146,y:-2.0869}).wait(1).to({graphics:mask_2_graphics_23,x:5.1553,y:-2.5221}).wait(1).to({graphics:mask_2_graphics_24,x:6.2459,y:-2.9723}).wait(1).to({graphics:mask_2_graphics_25,x:7.4197,y:-3.434}).wait(1).to({graphics:mask_2_graphics_26,x:8.6776,y:-3.9031}).wait(1).to({graphics:mask_2_graphics_27,x:10.0188,y:-4.3749}).wait(1).to({graphics:mask_2_graphics_28,x:11.441,y:-4.8438}).wait(1).to({graphics:mask_2_graphics_29,x:12.939,y:-5.3038}).wait(1).to({graphics:mask_2_graphics_30,x:14.5054,y:-5.7483}).wait(1).to({graphics:mask_2_graphics_31,x:16.1319,y:-6.1704}).wait(1).to({graphics:mask_2_graphics_32,x:17.7988,y:-6.5637}).wait(1).to({graphics:mask_2_graphics_33,x:19.4864,y:-6.9222}).wait(1).to({graphics:mask_2_graphics_34,x:21.1711,y:-7.241}).wait(1).to({graphics:mask_2_graphics_35,x:22.8263,y:-7.517}).wait(1).to({graphics:mask_2_graphics_36,x:24.4239,y:-7.749}).wait(1).to({graphics:mask_2_graphics_37,x:25.9357,y:-7.938}).wait(1).to({graphics:mask_2_graphics_38,x:27.3356,y:-8.0868}).wait(1).to({graphics:mask_2_graphics_39,x:26.7581,y:-7.4076}).wait(53));

	// Layer_5
	this.instance_2 = new lib.squiggle_line();
	this.instance_2.setTransform(85.2,2.9,0.6662,0.6662,0,0,0,127.2,31.1);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({_off:false},0).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.2,-19.4,172.79999999999998,44.8);


(lib.letter = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.letter.cache(0,0,110,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.letter = new lib.letter_sub();
	this.letter.name = "letter";
	this.letter.setTransform(51.5,36,1,1,0,0,0,51.5,36);

	this.timeline.addTween(cjs.Tween.get(this.letter).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.letter, new cjs.Rectangle(0,0,102.9,72.1), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-250,-10,500,20,1.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.file3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.BudgetMeeting_lg();
	this.instance.setTransform(-8,-13,0.9,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(63.55,91.1,0.6,0.9099,0,0,0,98.2,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file3, new cjs.Rectangle(-8,-13,130.3,196.5), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.VirtualMeeting_lg();
	this.instance.setTransform(0,0,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(83,65.5,0.8468,0.6453,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(-2.4,-2.4,170,133.4), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.calendar_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.calendar.cache(0,0,110,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.calendar = new lib.calendar_sub();
	this.calendar.name = "calendar";
	this.calendar.setTransform(53.7,49.5,1,1,0,0,0,53.7,49.5);

	this.timeline.addTween(cjs.Tween.get(this.calendar).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.calendar_icon, new cjs.Rectangle(0,0,107.5,99), null);


(lib.bang_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bang.cache(-60,-60,120,120,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bang = new lib.bang_sub();
	this.bang.name = "bang";
	this.bang.setTransform(20.5,21,1,1,0,0,0,20.5,21);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_icon, new cjs.Rectangle(-1,-1,43,44), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ah5EYQhfg7gahtQgZhoA0haIAGgKIHMEcIgGAKQg6BXhoAYQghAIggAAQhIAAhDgpg");
	var mask_graphics_1 = new cjs.Graphics().p("AiQD+QhUhKgIhwQgHhpBChRIAHgJIGYFjIgIAJQhIBMhqAHIgVABQhiAAhNhDg");
	var mask_graphics_2 = new cjs.Graphics().p("AAXFAQhugLhIhXQhHhXALhvQAKhpBPhGIAIgHIFYGhIgJAHQhIA3hZAAIgdgBg");
	var mask_graphics_3 = new cjs.Graphics().p("AgBE3Qhsgcg5hiQg4hhAdhrQAbhnBZg4IAKgGIEPHUIgKAGQg8Afg/AAQgkAAgkgKg");
	var mask_graphics_4 = new cjs.Graphics().p("AgWEoQhngugnhpQgohpAuhlQAshhBhgpIAKgEIC/H6IgLAEQgrAOgqAAQg4AAg2gZg");
	var mask_graphics_5 = new cjs.Graphics().p("AgoETQhdg+gXhuQgWhtA/heQA7hYBlgYIALgDIBqISIgLADQgXADgWAAQhOAAhEgug");
	var mask_graphics_6 = new cjs.Graphics().p("Ag1D4QhShNgEhwQgEhvBNhSQBIhOBogHIAMgBIASIdIgLAAQhpAAhNhJg");
	var mask_graphics_7 = new cjs.Graphics().p("ABHE/QhmgShBhUQhEhZAOhwQAPhuBZhEQBUhBBoAKIALABIhGIYIgMgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AAHE4QhigigyheQg1hjAghqQAhhsBjg0QBdgzBlAbIALADIidIGIgLgEg");
	var mask_graphics_9 = new cjs.Graphics().p("Ag1EvQhcgygjhlQgkhqAyhkQAyhlBqgkQBkgiBfArIALAFIjvHlIgKgFg");
	var mask_graphics_10 = new cjs.Graphics().p("AhuEiQhShAgShpQgShvBChaQBBhbBugTQBpgRBXA6IAKAHIk7G3IgKgHg");
	var mask_graphics_11 = new cjs.Graphics().p("AifETQhHhNAAhrQAAhvBPhPQBQhQBvAAQBrABBMBHIAIAIIl+F+IgIgIg");
	var mask_graphics_12 = new cjs.Graphics().p("AjJEBQg5hYARhpQAThtBbhCQBbhBBuASQBpASBABTIAHAJIm4E6IgHgJg");
	var mask_graphics_13 = new cjs.Graphics().p("AjpDtQgrhgAjhlQAkhpBlgxQBlgyBpAlQBlAiAxBdIAGAJInmDuIgFgKg");
	var mask_graphics_14 = new cjs.Graphics().p("AkADYQgahlAzheQA1hiBrggQBrghBiA1QBeAzAiBiIAEALIoGCcIgEgLg");
	var mask_graphics_15 = new cjs.Graphics().p("AkMDCQgJhoBBhUQBEhYBwgPQBugOBZBFQBUBAARBnIACALIoYBGIgCgMg");
	var mask_graphics_16 = new cjs.Graphics().p("AkOCuIABgLQAHhpBOhHQBShNBwAEQBwAEBMBSQBJBNAABpIAAAMg");
	var mask_graphics_17 = new cjs.Graphics().p("AkLBsIACgLQAYhlBZg7QBeg+BtAXQBuAWA+BcQA7BZgRBoIgCALg");
	var mask_graphics_18 = new cjs.Graphics().p("AkFAtIAEgLQAphgBhgrQBmguBoAoQBpAoAuBlQAsBhgiBkIgEAKg");
	var mask_graphics_19 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_20 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_21 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_22 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_23 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_24 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_25 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_26 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_27 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_28 = new cjs.Graphics().p("Aj8gPIAGgKQA4hYBngbQBsgdBhA4QBhA5AcBrQAbBogxBcIgGAKg");
	var mask_graphics_29 = new cjs.Graphics().p("Aj8gMIAFgKQA4hZBngcQBrgdBhA3QBiA4AdBrQAcBngxBdIgFAKg");
	var mask_graphics_30 = new cjs.Graphics().p("Aj+gEIAGgKQA1haBmgfQBrgfBiA1QBjA2AgBqQAeBmguBeIgGAKg");
	var mask_graphics_31 = new cjs.Graphics().p("AkBALIAFgLQAyhbBlgjQBpgkBlAxQBlAxAkBpQAjBlgrBgIgFAKg");
	var mask_graphics_32 = new cjs.Graphics().p("AkEAjIAEgKQArhfBigpQBogsBnArQBoAqArBmQAqBjglBiIgEALg");
	var mask_graphics_33 = new cjs.Graphics().p("AkJBIIAEgLQAihiBdgzQBjg1BrAgQBrAhA1BhQAzBegbBmIgDALg");
	var mask_graphics_34 = new cjs.Graphics().p("AkMB8IABgLQAVhnBXg+QBahBBuASQBvARBCBaQA+BXgNBoIgBALg");
	var mask_graphics_35 = new cjs.Graphics().p("AkOCzQAChpBLhLQBOhRBwgBQBvgCBRBOQBMBJAFBpIABALIodAIIAAgLg");
	var mask_graphics_36 = new cjs.Graphics().p("AkFDRQgVhmA4hcQA6heBtgbQBsgbBgA6QBbA4AcBkIADALIoNCAIgDgLg");
	var mask_graphics_37 = new cjs.Graphics().p("AjeD1QgwhdAchnQAdhrBig4QBhg3BsAdQBnAdA3BZIAFAKInVELIgGgKg");
	var mask_graphics_38 = new cjs.Graphics().p("AiQEZQhLhJgGhrQgGhvBMhTQBLhUBvgGQBqgFBQBDIAJAHIlpGSIgJgHg");
	var mask_graphics_39 = new cjs.Graphics().p("AggEzQhfgsgohjQgqhoAshmQArhoBogqQBigoBiAmIALAEIjTHyIgKgFg");
	var mask_graphics_40 = new cjs.Graphics().p("ABYFBQhngOhEhRQhIhXAKhvQAKhvBWhIQBQhFBpAGIAMABIgxIbIgLgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AgqESQhchAgUhuQgVhuBAhcQA9hYBlgWIALgDIBiIUIgLACQgVADgUAAQhQAAhGgwg");
	var mask_graphics_42 = new cjs.Graphics().p("AgREuQhogpgshoQgthnAqhnQAnhjBfgtIAKgFIDVHxIgKAFQgwASgwAAQgyAAgygUg");
	var mask_graphics_43 = new cjs.Graphics().p("AAIE8QhtgWg/hdQg+hdAWhtQAUhpBWg9IAJgHIEsHCIgKAGQhAAohJAAQgcAAgcgGg");
	var mask_graphics_44 = new cjs.Graphics().p("AAfFBQhvgFhLhTQhMhUAGhwQAFhpBLhJIAJgIIFqGQIgIAIQhKA/hiAAIgPgBg");
	var mask_graphics_45 = new cjs.Graphics().p("AiQD/QhUhKgIhwQgHhpBChSIAHgJIGYFkIgIAIQhIBNhqAHIgVABQhiAAhNhDg");
	var mask_graphics_46 = new cjs.Graphics().p("AiEEOQhbhCgShuQgRhpA7hXIAGgJIG2E8IgGAJQhBBThpARQgYAEgWAAQhTAAhIg0g");
	var mask_graphics_47 = new cjs.Graphics().p("Ah5EYQhfg7gahtQgZhoA0haIAGgKIHMEcIgGAKQg6BXhoAYQghAIggAAQhIAAhDgpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:13.5454,y:32.1265}).wait(1).to({graphics:mask_graphics_1,x:12.3181,y:32.0922}).wait(1).to({graphics:mask_graphics_2,x:10.7908,y:32.0919}).wait(1).to({graphics:mask_graphics_3,x:9.0118,y:32.1198}).wait(1).to({graphics:mask_graphics_4,x:7.0669,y:32.1367}).wait(1).to({graphics:mask_graphics_5,x:5.0168,y:32.1329}).wait(1).to({graphics:mask_graphics_6,x:2.8965,y:32.1278}).wait(1).to({graphics:mask_graphics_7,x:4.2506,y:32.0217}).wait(1).to({graphics:mask_graphics_8,x:6.4417,y:31.5784}).wait(1).to({graphics:mask_graphics_9,x:8.54,y:30.7905}).wait(1).to({graphics:mask_graphics_10,x:10.4924,y:29.6794}).wait(1).to({graphics:mask_graphics_11,x:12.2204,y:28.2748}).wait(1).to({graphics:mask_graphics_12,x:13.6423,y:26.6144}).wait(1).to({graphics:mask_graphics_13,x:14.7545,y:24.7429}).wait(1).to({graphics:mask_graphics_14,x:15.5538,y:22.7104}).wait(1).to({graphics:mask_graphics_15,x:16.0162,y:20.5715}).wait(1).to({graphics:mask_graphics_16,x:16.1242,y:19.3498}).wait(1).to({graphics:mask_graphics_17,x:16.3697,y:21.5784}).wait(1).to({graphics:mask_graphics_18,x:16.9579,y:23.731}).wait(1).to({graphics:mask_graphics_19,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_20,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_21,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_22,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_23,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_24,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_25,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_26,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_27,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_28,x:17.7276,y:25.6947}).wait(1).to({graphics:mask_graphics_29,x:17.681,y:25.6094}).wait(1).to({graphics:mask_graphics_30,x:17.5338,y:25.33}).wait(1).to({graphics:mask_graphics_31,x:17.2803,y:24.8098}).wait(1).to({graphics:mask_graphics_32,x:16.9284,y:23.9823}).wait(1).to({graphics:mask_graphics_33,x:16.5124,y:22.7561}).wait(1).to({graphics:mask_graphics_34,x:16.121,y:21.0161}).wait(1).to({graphics:mask_graphics_35,x:15.9566,y:19.0411}).wait(1).to({graphics:mask_graphics_36,x:15.573,y:22.0415}).wait(1).to({graphics:mask_graphics_37,x:14.2116,y:25.4994}).wait(1).to({graphics:mask_graphics_38,x:11.5515,y:28.8149}).wait(1).to({graphics:mask_graphics_39,x:7.7176,y:31.1762}).wait(1).to({graphics:mask_graphics_40,x:3.6368,y:32.1576}).wait(1).to({graphics:mask_graphics_41,x:4.8128,y:32.2151}).wait(1).to({graphics:mask_graphics_42,x:7.6491,y:32.2156}).wait(1).to({graphics:mask_graphics_43,x:9.7936,y:32.1856}).wait(1).to({graphics:mask_graphics_44,x:11.3441,y:32.1581}).wait(1).to({graphics:mask_graphics_45,x:12.4209,y:32.1581}).wait(1).to({graphics:mask_graphics_46,x:13.1592,y:32.1716}).wait(1).to({graphics:mask_graphics_47,x:13.5454,y:32.1265}).wait(1));

	// Layer_1
	this.instance = new lib.bang_icon();
	this.instance.setTransform(20.8,28.25,0.6528,0.6528,0,0,0,20.6,21.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.7,13.9,28.099999999999998,28.700000000000003);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AlQHuQhig9gahxQgahxA8hjQA/hiBwgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg8BjhxAZMgijAIBQgiAIggAAQhMAAhGgrg");
	var mask_graphics_54 = new cjs.Graphics().p("AlUHuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AbBxQAaBxg+BiQg9BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_55 = new cjs.Graphics().p("AlhHuQhig9gahxQgbhxA9hjQA+hiBxgZMAijgIBQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_56 = new cjs.Graphics().p("Al+HuQhig9gahxQgbhxA9hjQA+hiBxgZMAijgIBQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_57 = new cjs.Graphics().p("AmxHuQhig9gahxQgahxA8hjQA+hiBxgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_58 = new cjs.Graphics().p("An2HuQhig9gahxQgahxA8hjQA+hiBxgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg8BjhxAZMgijAIBQgiAIggAAQhMAAhGgrg");
	var mask_graphics_59 = new cjs.Graphics().p("Ao5HuQhhg9gahxQgbhxA9hjQA+hiBxgZMAijgIBQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BjhxAZMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_60 = new cjs.Graphics().p("AptHuQhig9gahxQgahxA8hjQA+hiBxgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_61 = new cjs.Graphics().p("AqWHuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AbBxQAaBxg+BiQg9BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_62 = new cjs.Graphics().p("Aq1HxQhig9gahwQgahxA9hjQA+hiBxgZMAijgICQBwgaBiA9QBjA+AaBxQAbBwg+BiQg9BjhxAaMgijAIBQghAIghAAQhMAAhGgsg");
	var mask_graphics_63 = new cjs.Graphics().p("ArNH3Qhig9gahxQgahxA8hjQA/hiBwgZMAijgIBQBxgaBiA9QBjA9AaBxQAaBxg+BiQg8BjhxAZMgijAICQgiAHggAAQhMAAhGgrg");
	var mask_graphics_64 = new cjs.Graphics().p("ArgH7Qhig9gahwQgahxA8hjQA/hiBwgZMAijgICQBxgaBiA9QBjA+AaBxQAaBwg+BiQg8BihxAbMgijAIBQgiAIggAAQhMAAhGgsg");
	var mask_graphics_65 = new cjs.Graphics().p("ArvH/Qhig9gahxQgahxA8hjQA/hiBwgaMAijgIAQBxgaBiA8QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhMAAhGgrg");
	var mask_graphics_66 = new cjs.Graphics().p("Ar7IBQhig8gahxQgahxA9hjQA+hiBxgaMAijgIBQBwgaBiA9QBjA+AbBxQAaBxg+BiQg9BihxAaMgijAIBQghAIghAAQhMAAhGgsg");
	var mask_graphics_67 = new cjs.Graphics().p("AsEIDQhig8gahxQgahxA9hjQA+hiBxgaMAijgIAQBwgbBiA9QBjA+AaBxQAbBxg+BiQg9BihxAaMgijAIBQghAIghAAQhMAAhGgsg");
	var mask_graphics_68 = new cjs.Graphics().p("AsLIFQhhg9gbhxQgahwA9hjQA+hiBxgaMAijgIBQBxgaBhA9QBjA+AbBwQAaBxg+BiQg9BihxAaMgijAICQghAIghAAQhMAAhGgsg");
	var mask_graphics_69 = new cjs.Graphics().p("AsQIGQhhg9gbhwQgahxA9hjQA+hiBxgaMAijgIBQBxgaBhA9QBkA+AaBxQAaBwg+BiQg9BihxAbMgijAIBQghAIggAAQhNAAhGgsg");
	var mask_graphics_70 = new cjs.Graphics().p("AsTIHQhig9gahxQgahwA9hjQA+hiBxgbMAijgIAQBwgaBiA9QBjA+AaBwQAbBxg/BiQg8BihxAaMgijAICQghAHghAAQhMAAhGgrg");
	var mask_graphics_71 = new cjs.Graphics().p("AsVIHQhhg9gbhwQgahxA9hjQA+hiBxgaMAijgIBQBwgaBiA9QBjA+AbBxQAaBxg+BiQg9BihxAaMgijAIBQghAIghAAQhMAAhGgsg");
	var mask_graphics_72 = new cjs.Graphics().p("AsVIHQhig9gahxQgahxA9hjQA+hiBxgaMAijgIAQBwgaBiA9QBjA9AbBxQAaBxg+BiQg9BihxAaMgijAIBQghAIghAAQhMAAhGgrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:230.401,y:37.9317}).wait(1).to({graphics:mask_graphics_54,x:230.0296,y:38.1034}).wait(1).to({graphics:mask_graphics_55,x:228.6669,y:38.7334}).wait(1).to({graphics:mask_graphics_56,x:225.765,y:40.0749}).wait(1).to({graphics:mask_graphics_57,x:220.6749,y:42.4281}).wait(1).to({graphics:mask_graphics_58,x:213.7921,y:45.6101}).wait(1).to({graphics:mask_graphics_59,x:207.153,y:48.6793}).wait(1).to({graphics:mask_graphics_60,x:201.8693,y:51.122}).wait(1).to({graphics:mask_graphics_61,x:197.8314,y:52.9887}).wait(1).to({graphics:mask_graphics_62,x:194.7236,y:54.0696}).wait(1).to({graphics:mask_graphics_63,x:192.3015,y:54.6295}).wait(1).to({graphics:mask_graphics_64,x:190.3986,y:55.0693}).wait(1).to({graphics:mask_graphics_65,x:188.9011,y:55.4155}).wait(1).to({graphics:mask_graphics_66,x:187.7286,y:55.6865}).wait(1).to({graphics:mask_graphics_67,x:186.8231,y:55.8958}).wait(1).to({graphics:mask_graphics_68,x:186.1411,y:56.0534}).wait(1).to({graphics:mask_graphics_69,x:185.6492,y:56.1671}).wait(1).to({graphics:mask_graphics_70,x:185.3214,y:56.2429}).wait(1).to({graphics:mask_graphics_71,x:185.1368,y:56.2856}).wait(1).to({graphics:mask_graphics_72,x:185.126,y:56.2226}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(164,74.75,0.9423,0.9423,8.9317,0,0,42.2,17.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_45 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_46 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_47 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_48 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_49 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_50 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_51 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_52 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_53 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_54 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-9.3503,y:-32.3471}).wait(1).to({graphics:mask_1_graphics_45,x:-6.5762,y:-31.0886}).wait(1).to({graphics:mask_1_graphics_46,x:1.4746,y:-27.4364}).wait(1).to({graphics:mask_1_graphics_47,x:14.0139,y:-21.7478}).wait(1).to({graphics:mask_1_graphics_48,x:29.8145,y:-14.5798}).wait(1).to({graphics:mask_1_graphics_49,x:47.3296,y:-6.6341}).wait(1).to({graphics:mask_1_graphics_50,x:64.8446,y:1.3117}).wait(1).to({graphics:mask_1_graphics_51,x:80.6452,y:8.4797}).wait(1).to({graphics:mask_1_graphics_52,x:93.1846,y:14.1682}).wait(1).to({graphics:mask_1_graphics_53,x:101.2353,y:17.8205}).wait(1).to({graphics:mask_1_graphics_54,x:103.5997,y:18.7529}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(154.75,41.65,0.9423,0.9423,8.9317,0,0,57.6,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AkyFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_39 = new cjs.Graphics().p("AlSFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_40 = new cjs.Graphics().p("AmsFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_41 = new cjs.Graphics().p("AotFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_42 = new cjs.Graphics().p("Aq9FRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_43 = new cjs.Graphics().p("As+FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_44 = new cjs.Graphics().p("AuYFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_45 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_46 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_47 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_48 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_49 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_50 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_51 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_52 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_53 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_54 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_55 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_56 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_57 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_58 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_59 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_60 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_61 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_62 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_63 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_64 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_65 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_66 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_67 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_68 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_69 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_70 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_71 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");
	var mask_2_graphics_72 = new cjs.Graphics().p("Au3FRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgPAAQhgAAhOg/g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:240.561,y:-7.3074}).wait(1).to({graphics:mask_2_graphics_39,x:237.366,y:-6.6183}).wait(1).to({graphics:mask_2_graphics_40,x:228.4104,y:-4.6876}).wait(1).to({graphics:mask_2_graphics_41,x:215.4692,y:-1.8976}).wait(1).to({graphics:mask_2_graphics_42,x:201.1055,y:1.1991}).wait(1).to({graphics:mask_2_graphics_43,x:188.1643,y:3.9891}).wait(1).to({graphics:mask_2_graphics_44,x:179.2087,y:5.9198}).wait(1).to({graphics:mask_2_graphics_45,x:176.061,y:6.3426}).wait(1).to({graphics:mask_2_graphics_46,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_47,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_48,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_49,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_50,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_51,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_52,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_53,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_54,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_55,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_56,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_57,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_58,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_59,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_60,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_61,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_62,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_63,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_64,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_65,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_66,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_67,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_68,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_69,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_70,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_71,x:176.0622,y:6.3426}).wait(1).to({graphics:mask_2_graphics_72,x:176.061,y:6.3426}).wait(1));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(162.35,11.8,0.9423,0.9423,8.9317,0,0,60.6,16.6);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AO8JnMghCgM1QhsgqgvhrQguhqAqhsQAqhrBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBrhqAuQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AO8JuMghCgM2QhsgqgvhqQguhqAqhsQAqhrBqgwQBqguBsAqMAhCAM2QBsApAuBqQAvBrgqBsQgqBrhqAuQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AO8KCMghCgM2QhsgqgvhrQguhpAqhsQAqhsBqgvQBqguBsAqMAhCAM1QBsAqAuBqQAvBrgqBrQgqBshqAuQg4AZg5AAQgyAAgzgTg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:1.8023,y:-74.8836}).wait(1).to({graphics:mask_3_graphics_32,x:5.2951,y:-74.1927}).wait(1).to({graphics:mask_3_graphics_33,x:15.3522,y:-72.2034}).wait(1).to({graphics:mask_3_graphics_34,x:30.7605,y:-69.1383}).wait(1).to({graphics:mask_3_graphics_35,x:49.6617,y:-61.661}).wait(1).to({graphics:mask_3_graphics_36,x:69.7759,y:-53.7038}).wait(1).to({graphics:mask_3_graphics_37,x:88.6771,y:-46.2265}).wait(1).to({graphics:mask_3_graphics_38,x:104.0854,y:-40.1309}).wait(1).to({graphics:mask_3_graphics_39,x:114.1425,y:-36.1523}).wait(1).to({graphics:mask_3_graphics_40,x:117.3523,y:-34.7442}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(167.25,-15.7,0.9423,0.9423,8.9317,0,0,59.9,12.9);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("AkuC1QhWhPgFh0QgFh1BPhYQBRhVB1gFMAj8gBeQB1gFBWBPQBXBRAFB1QAFB1hQBVQhPBXh2AFMgj8ABeIgNAAQhtAAhShMg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AkyC2QhWhQgEh0QgFh1BPhXQBQhWB2gFMAj8gBeQB1gFBWBPQBXBRAFB1QAEB1hQBVQhPBXh1AFMgj8ABeIgNAAQhtAAhThLg");
	var mask_4_graphics_21 = new cjs.Graphics().p("Ak9C2QhWhPgFh0QgEh2BPhXQBQhWB1gFMAj8gBdQB1gFBWBPQBXBQAFB2QAEB1hQBVQhPBXh1AFMgj8ABdIgNABQhtAAhShMg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AlTC3QhWhPgEh1QgFh1BPhXQBQhWB1gEMAj7gBeQB1gFBWBPQBXBQAEB1QAFB2hQBVQhPBXh1AEMgj7ABeIgNABQhtAAhShMg");
	var mask_4_graphics_23 = new cjs.Graphics().p("Al3C4QhWhPgEh0QgFh1BPhXQBQhWB1gFMAj5gBeQB1gEBVBPQBXBQAFB1QAFB1hQBVQhPBXh1AFMgj5ABeIgNAAQhtAAhShMg");
	var mask_4_graphics_24 = new cjs.Graphics().p("AmuC6QhVhPgFh0QgFh1BPhXQBQhVB1gFMAj2gBeQB0gFBWBPQBXBQAFB1QAFB1hRBVQhOBXh1AFMgj2ABdIgNABQhtAAhShMg");
	var mask_4_graphics_25 = new cjs.Graphics().p("An8C9QhWhPgEh0QgFh0BPhXQBQhWB1gEMAjxgBeQB1gFBVBPQBXBQAFB1QAFB1hQBUQhPBXh1AFMgjxABdIgNAAQhtAAhShLg");
	var mask_4_graphics_26 = new cjs.Graphics().p("ApeDBQhVhPgFh0QgFh0BPhXQBQhVB0gFMAjtgBdQB0gFBWBPQBWBQAFB0QAFB1hQBUQhPBXh0AEMgjtABeIgNAAQhsAAhShLg");
	var mask_4_graphics_27 = new cjs.Graphics().p("ArCDEQhVhOgFh0QgEh0BOhWQBQhVB0gFMAjngBdQB1gFBVBPQBWBPAFB1QAFBzhQBVQhOBWh1AFMgjnABdIgNAAQhsAAhShLg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AsWDHQhVhOgFh0QgEhzBOhWQBPhVB0gFMAjjgBdQB0gFBVBPQBXBPAEB0QAFBzhPBVQhPBWh0AFMgjjABdIgNAAQhsAAhRhLg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AtWDKQhVhOgFh0QgEhzBOhWQBPhVB0gFMAjggBdQB0gEBUBOQBXBPAEB0QAFBzhPBVQhOBWh0AFMgjgABcIgNABQhsAAhRhLg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AuFDLQhVhOgEhzQgFhzBOhWQBPhVB0gFMAjdgBcQB0gFBVBOQBWBPAFB0QAEBzhPBVQhOBWh0AEMgjdABdIgNAAQhsAAhRhLg");
	var mask_4_graphics_31 = new cjs.Graphics().p("AunDNQhUhOgFh0QgFhzBOhWQBQhUBzgFMAjcgBdQB0gEBUBOQBWBPAFB0QAFByhQBVQhOBWhzAFMgjcABcIgNAAQhrAAhShKg");
	var mask_4_graphics_32 = new cjs.Graphics().p("Au+DNQhVhNgEh0QgFhzBOhWQBPhUB0gFMAjagBcQB0gFBUBOQBWBPAFB0QAFByhPBVQhOBWh0AEMgjaABdIgNAAQhsAAhRhLg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:247.4516,y:-40.4424}).wait(1).to({graphics:mask_4_graphics_20,x:247.0972,y:-40.4261}).wait(1).to({graphics:mask_4_graphics_21,x:245.8935,y:-40.3696}).wait(1).to({graphics:mask_4_graphics_22,x:243.573,y:-40.2608}).wait(1).to({graphics:mask_4_graphics_23,x:239.7501,y:-40.0814}).wait(1).to({graphics:mask_4_graphics_24,x:233.9132,y:-39.8076}).wait(1).to({graphics:mask_4_graphics_25,x:225.6132,y:-39.4182}).wait(1).to({graphics:mask_4_graphics_26,x:215.221,y:-38.9307}).wait(1).to({graphics:mask_4_graphics_27,x:204.6099,y:-38.4329}).wait(1).to({graphics:mask_4_graphics_28,x:195.6668,y:-38.0134}).wait(1).to({graphics:mask_4_graphics_29,x:188.8633,y:-37.6942}).wait(1).to({graphics:mask_4_graphics_30,x:183.8861,y:-37.4607}).wait(1).to({graphics:mask_4_graphics_31,x:180.3194,y:-37.2934}).wait(1).to({graphics:mask_4_graphics_32,x:177.8298,y:-37.1763}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(174.5,-39.55,0.9423,0.9423,8.9317,0,0,63.6,13);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-82,267.3,290);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.pptLogo = new lib.OutlookLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(55.3,31.5,1,1,0,0,0,53,32.6);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	//  files 1 - 2
	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(187,183.8,1,1,0,0,0,70,58.8);

	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(203.9,117.4,1,1,0,0,0,95.9,87.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file1},{t:this.file2}]}).wait(1));

	// file 3
	this.file3 = new lib.file3();
	this.file3.name = "file3";
	this.file3.setTransform(243.9,249.15,1.3199,1.3199,0,0,0,56,84.2);

	this.timeline.addTween(cjs.Tween.get(this.file3).wait(1));

	// file 4
	this.file4 = new lib.file4();
	this.file4.name = "file4";
	this.file4.setTransform(275.4,104,1.7,1.7,0,0,0,106.7,85.3);

	this.timeline.addTween(cjs.Tween.get(this.file4).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(225.85,146,1,1,0,0,0,187.5,125.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.ExcelUI_CU();
	this.instance.setTransform(38.35,20.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-549,-40.1,2451,420.3), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhJHGQgGAAgGgFIgEgFIgwhGQgIgNgLgHQgLgIgSgBIm6AAIAAseIToAAIAAOLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:210.9,y:65.825}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(205.5,150.3,1,1,0,0,0,205.5,150.3);

	var maskedShapeInstanceList = [this.ui];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11.7,-23.5,425.09999999999997,403.6);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-21.7,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.CTAbg},{t:this.popRight},{t:this.popLeft}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.6,143.7,27), null);


(lib.Icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_64 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(64).call(this.frame_64).wait(2));

	// calendar
	this.calendar = new lib.calendar_icon();
	this.calendar.name = "calendar";
	this.calendar.setTransform(9.7,53.25,0.0214,0.8525,0,0,0,56.1,49.6);
	this.calendar._off = true;

	this.timeline.addTween(cjs.Tween.get(this.calendar).wait(49).to({_off:false},0).to({regX:53.7,scaleX:0.8525},7,cjs.Ease.quadOut).to({_off:true},9).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AtmG8IImpdIEZAAIAAJdg");
	var mask_graphics_2 = new cjs.Graphics().p("AtkG8IImpdIEYAAIAAJdg");
	var mask_graphics_3 = new cjs.Graphics().p("AthG8IImpdIEZAAIAAJdg");
	var mask_graphics_4 = new cjs.Graphics().p("AtaG8IImpdIEYAAIAAJdg");
	var mask_graphics_5 = new cjs.Graphics().p("AtRG8IImpdIEYAAIAAJdg");
	var mask_graphics_6 = new cjs.Graphics().p("AtFG8IImpdIEYAAIAAJdg");
	var mask_graphics_7 = new cjs.Graphics().p("As3G8IImpdIEXAAIAAJdg");
	var mask_graphics_8 = new cjs.Graphics().p("AsmG8IImpdIEXAAIAAJdg");
	var mask_graphics_9 = new cjs.Graphics().p("AsTG8IImpdIEYAAIAAJdg");
	var mask_graphics_10 = new cjs.Graphics().p("Ar9G7IImpcIEYAAIAAJcg");
	var mask_graphics_11 = new cjs.Graphics().p("ArkG7IImpcIEXAAIAAJcg");
	var mask_graphics_12 = new cjs.Graphics().p("ArJG7IImpcIEYAAIAAJcg");
	var mask_graphics_13 = new cjs.Graphics().p("AqrG7IImpcIEXAAIAAJcg");
	var mask_graphics_14 = new cjs.Graphics().p("AqNG7IImpcIEXAAIAAJcg");
	var mask_graphics_15 = new cjs.Graphics().p("ApyG7IImpcIEXAAIAAJcg");
	var mask_graphics_16 = new cjs.Graphics().p("ApZG7IImpcIEXAAIAAJcg");
	var mask_graphics_17 = new cjs.Graphics().p("ApDG7IImpdIEXAAIAAJdg");
	var mask_graphics_18 = new cjs.Graphics().p("AowG7IImpdIEYAAIAAJdg");
	var mask_graphics_19 = new cjs.Graphics().p("AofG7IIlpdIEYAAIAAJdg");
	var mask_graphics_20 = new cjs.Graphics().p("AoRG7IIlpdIEZAAIAAJdg");
	var mask_graphics_21 = new cjs.Graphics().p("AoFG7IIlpdIEYAAIAAJdg");
	var mask_graphics_22 = new cjs.Graphics().p("An8G7IIlpdIEYAAIAAJdg");
	var mask_graphics_23 = new cjs.Graphics().p("An2G7IIlpdIEZAAIAAJdg");
	var mask_graphics_24 = new cjs.Graphics().p("AnyG7IIlpdIEZAAIAAJdg");
	var mask_graphics_25 = new cjs.Graphics().p("AnxG7IImpdIEYAAIAAJdg");
	var mask_graphics_26 = new cjs.Graphics().p("AnxG7IImpdIEYAAIAAJdg");
	var mask_graphics_27 = new cjs.Graphics().p("AnrG7IIlpdIEYAAIAAJdg");
	var mask_graphics_28 = new cjs.Graphics().p("AncG7IIlpdIEYAAIAAJdg");
	var mask_graphics_29 = new cjs.Graphics().p("AnDG7IIlpdIEZAAIAAJdg");
	var mask_graphics_30 = new cjs.Graphics().p("AmfG7IIlpdIEZAAIAAJdg");
	var mask_graphics_31 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_32 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_33 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_34 = new cjs.Graphics().p("AmeG7IIlpcIEYAAIAAJcg");
	var mask_graphics_35 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");
	var mask_graphics_36 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");
	var mask_graphics_37 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");
	var mask_graphics_38 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");
	var mask_graphics_39 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");
	var mask_graphics_42 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");
	var mask_graphics_49 = new cjs.Graphics().p("AmeG8IIlpdIEYAAIAAJdg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-87.075,y:44.3755}).wait(1).to({graphics:mask_graphics_2,x:-86.9454,y:44.3751}).wait(1).to({graphics:mask_graphics_3,x:-86.5566,y:44.3741}).wait(1).to({graphics:mask_graphics_4,x:-85.9086,y:44.3723}).wait(1).to({graphics:mask_graphics_5,x:-85.0014,y:44.3699}).wait(1).to({graphics:mask_graphics_6,x:-83.835,y:44.3668}).wait(1).to({graphics:mask_graphics_7,x:-82.4094,y:44.363}).wait(1).to({graphics:mask_graphics_8,x:-80.7246,y:44.3584}).wait(1).to({graphics:mask_graphics_9,x:-78.7806,y:44.3532}).wait(1).to({graphics:mask_graphics_10,x:-76.5773,y:44.3473}).wait(1).to({graphics:mask_graphics_11,x:-74.1149,y:44.3407}).wait(1).to({graphics:mask_graphics_12,x:-71.3933,y:44.3334}).wait(1).to({graphics:mask_graphics_13,x:-68.4125,y:44.3255}).wait(1).to({graphics:mask_graphics_14,x:-65.4317,y:44.3175}).wait(1).to({graphics:mask_graphics_15,x:-62.7101,y:44.3102}).wait(1).to({graphics:mask_graphics_16,x:-60.2477,y:44.3036}).wait(1).to({graphics:mask_graphics_17,x:-58.0444,y:44.2977}).wait(1).to({graphics:mask_graphics_18,x:-56.1004,y:44.2925}).wait(1).to({graphics:mask_graphics_19,x:-54.4156,y:44.288}).wait(1).to({graphics:mask_graphics_20,x:-52.99,y:44.2841}).wait(1).to({graphics:mask_graphics_21,x:-51.8236,y:44.281}).wait(1).to({graphics:mask_graphics_22,x:-50.9164,y:44.2786}).wait(1).to({graphics:mask_graphics_23,x:-50.2684,y:44.2769}).wait(1).to({graphics:mask_graphics_24,x:-49.8796,y:44.2758}).wait(1).to({graphics:mask_graphics_25,x:-49.75,y:44.2755}).wait(1).to({graphics:mask_graphics_26,x:-49.75,y:44.2755}).wait(1).to({graphics:mask_graphics_27,x:-49.2405,y:44.2766}).wait(1).to({graphics:mask_graphics_28,x:-47.7121,y:44.2802}).wait(1).to({graphics:mask_graphics_29,x:-45.1648,y:44.2861}).wait(1).to({graphics:mask_graphics_30,x:-41.5985,y:44.2944}).wait(1).to({graphics:mask_graphics_31,x:-32.501,y:44.305}).wait(1).to({graphics:mask_graphics_32,x:-21.2927,y:44.3181}).wait(1).to({graphics:mask_graphics_33,x:-8.556,y:44.3329}).wait(1).to({graphics:mask_graphics_34,x:2.6523,y:44.3459}).wait(1).to({graphics:mask_graphics_35,x:11.8227,y:44.3565}).wait(1).to({graphics:mask_graphics_36,x:18.9552,y:44.3648}).wait(1).to({graphics:mask_graphics_37,x:24.0499,y:44.3707}).wait(1).to({graphics:mask_graphics_38,x:27.1067,y:44.3743}).wait(1).to({graphics:mask_graphics_39,x:28.1256,y:44.3755}).wait(3).to({graphics:mask_graphics_42,x:28.1256,y:44.3755}).wait(7).to({graphics:mask_graphics_49,x:28.1256,y:44.3755}).wait(17));

	// lines
	this.instance = new lib.mail_lines();
	this.instance.setTransform(-53.6,60.75,1,1,0,0,0,34.5,25);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(25).to({alpha:0},13).to({_off:true},26).wait(1));

	// letter
	this.letter = new lib.letter();
	this.letter.name = "letter";
	this.letter.setTransform(-36.6,52.7,1,1,0,0,0,51.5,36);

	this.timeline.addTween(cjs.Tween.get(this.letter).wait(1).to({x:-36.35},0).wait(1).to({x:-35.55},0).wait(1).to({x:-34.35},0).wait(1).to({x:-32.7},0).wait(1).to({x:-30.5},0).wait(1).to({x:-27.8},0).wait(1).to({x:-24.55},0).wait(1).to({x:-20.7},0).wait(1).to({x:-16.35},0).wait(1).to({x:-11.5},0).wait(1).to({x:-6.3},0).wait(1).to({x:-0.9},0).wait(1).to({x:4.5},0).wait(1).to({x:9.75},0).wait(1).to({x:14.7},0).wait(1).to({x:19.2},0).wait(1).to({x:23.25},0).wait(1).to({x:26.75},0).wait(1).to({x:29.7},0).wait(1).to({x:32.2},0).wait(1).to({x:34.2},0).wait(1).to({x:35.75},0).wait(1).to({x:36.9},0).wait(1).to({x:37.7},0).wait(1).to({x:38.1},0).wait(9).to({regY:36.1,scaleX:0.9144,scaleY:1.1095,x:9.8,y:52.8},9,cjs.Ease.quadIn).to({regX:51.6,regY:36,scaleX:0.1562,x:9.7,y:52.7},7,cjs.Ease.quadIn).to({_off:true},1).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.1,0,177.6,95.4);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.grid_line();
	this.instance.setTransform(369.55,33.95,0.4977,1,90,0,0,121.2,-0.1);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(303.35,36.05,0.499,1,90,0,0,125.8,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(183.6,36.05,0.499,1,90,0,0,125.8,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(252.95,31.9,1.0322,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(122.5,-26.9,251.3,121.5), null);


(lib.Anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(331.5,-10.45,0.6543,0.6543,-102.8464,0,0,14.7,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(338.75,-15.4,0.6542,0.6542,-133.8481,0,0,14.8,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(342.5,-22.6,0.6543,0.6543,-173.8512,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(287.15,-71.2,0.6738,0.6738,86.0027,0,0,14.8,0);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(279.3,-68.2,0.6737,0.6737,55.0034,0,0,14.7,-0.2);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(275.1,-61.6,0.6738,0.6738,14.9993,0,0,15.1,-0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// ODIcon
	this.ODIcon = new lib.Icon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(282.1,-39.95,0.5687,0.5687,0,0,0,-37.4,56.8);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(52.5,-35.5);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Anim, new cjs.Rectangle(253.2,-82.2,100.10000000000002,82.3), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.2,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(672.95,44.85,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(681.65,45,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(155.75,67,1,1,0,0,0,61.1,80.5);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(399.65,46,0.6039,0.6039,0,0,0,206.8,147.7);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(416.1,31.9,1,1,0,0,0,3.5,39.7);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.Anim();
	this.anim.name = "anim";
	this.anim.setTransform(518.95,44.2,1,1,0,0,0,200.7,-43);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(247.4,32.55,1,1,0,0,0,249.6,33.1);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,155,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-57.4,752.3,243.8), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		mc.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut});
				this.tl1.from(exportRoot,{duration:0.1, onStart:function(){ mc.anim.line1.play();}}, "<.3");			
		
				//icon
				this.tl1.from(mc.anim.ODIcon,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut, onStart:function(){mc.anim.ODIcon.play();}}, "<+2.1");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<+1.2");
		
				//chart transition
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, ease:Power4.easeInOut}, ">");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=20", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<-.6");
				this.tl1.to([mc.anim, mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.6, alpha:0, ease:Back.easeOut}, ">");
		
				this.tl3 = gsap.timeline();		
				this.tl3.from(mc.ui.ui.file1,{duration:1.5, x:"-=500", y:"-=60", scaleX:.2, scaleY:.2}, ">-.6");
				this.tl3.from(mc.ui.ui.file1,{duration:0.1, alpha:0},  "<");		
				//this.tl3.from(mc.ui.ui.file1.fileShadow,{duration:2, x:"-=20", y:"-=60", alpha:0}, "<");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:"-=15"}, "<-0.2");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:"+=20"}, ">+.5");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:"-=15"}, ">+.5");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:0}, ">+.5");		
				
				this.tl3.from(mc.ui.ui.file2,{duration:2, x:"+=600", y:"+=60", scaleX:.2, scaleY:.2}, "<-.8");
				this.tl3.from(mc.ui.ui.file2,{duration:0.1, alpha:0}, "<-.8");			
				this.tl3.from(mc.ui.ui.file2.fileShadow,{duration:2, x:"-=20", y:"+=60", alpha:0}, "<-.8");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:"-=10"}, "<-0.6");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:0}, ">+.5");
						
				
				this.tl3.to(mc.ui.ui.file1,{duration:.7, x:"-=103",y:"-=73", scaleX:.28, scaleY:.28, ease:Power3.easeIn}, ">+1.6");
				this.tl3.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
				
				this.tl3.to(mc.ui.ui.file2,{duration:.7, x:"+=7", y:"-=24", scaleX:.4, scaleY:.4, ease:Power3.easeIn}, "<-0.6");
				this.tl3.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");		
								
				
				//mid transition		
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=73", y:"+=64", scaleX: .615, scaleY: .615, ease:Power3.easeInOut}, ">+4.7");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"+=14", y:"+=17", alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, ">");
				
				this.tl1.from(mc.ui.ui.pptLogo,{duration:0.9, x: "-=100", y: "-=100", alpha: 0, ease:Power3.easeInOut}, "<+.4");			
			
		/*		this.tl5 = gsap.timeline();	
				this.tl5.from(mc.ui.ui.pptLogo,{duration:2, x:"-=300",y:"+=50", scaleX: 0, scaleY: 0, ease:Power3.easeOut}, "<+.4");
				this.tl5.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<");	
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:"-=10"}, "<-.2");
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:0}, ">+.5");*/
		
				
				this.tl4 = gsap.timeline();	
				this.tl4.from(mc.ui.ui.file3,{duration:2, x:"+=500", y:"-=0", scaleX:1, scaleY:1}, "<");
				this.tl4.from(mc.ui.ui.file3,{duration:0.1, alpha:0}, "<");			
				this.tl4.from(mc.ui.ui.file3.fileShadow,{duration:2, x:"-=10", y:"-=10", alpha:0}, "<");		
				this.tl4.to(mc.ui.ui.file3, {duration:0, rotation:"-=10"}, "<");
				this.tl4.to(mc.ui.ui.file3,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl4.to(mc.ui.ui.file3,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl4.to(mc.ui.ui.file3,{duration:0, rotation:0}, ">+.5");		
						
				
				this.tl4.from(mc.ui.ui.file4,{duration:2, x:"+=200", y:"-=100", scaleX: .2, scaleY: .2}, ">-1");
				this.tl4.from(mc.ui.ui.file4,{duration:0.1, alpha:0}, "<-1");			
				this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:"-=10"}, "<-.2");
				this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:"+=15"}, ">+.5");
				//this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:0}, ">+.5");
				
		
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"-=216", y:"-=30", scaleX: .491, scaleY: .491, ease:Power3.easeInOut}, ">+1.6");
		
				this.tl1.to(mc.grid ,{duration:1.2, x:"+=3", y:"-=2", scaleX: 1, scaleY: 1, ease:Power3.easeInOut}, ">-1.2");
				this.tl1.to(mc.anim,{duration:1.2, x:"-=30", y:"+=80", scaleX: 1, scaleY: 1, alpha:1, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2,  x:"-=135", y:"-=20", scaleX: .491, scaleY: .491, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.to(mc.ui.ui.file3,{duration:1, scaleX:.3, scaleY:.3, x:"+=60", y:"-=80", alpha:0, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file4,{duration:1, scaleX:.1, scaleY:.1, alpha:0, x:"-=30", y:"-=80", ease:Power4.easeInOut}, "<");		
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from([mc.txtCta,mc.cta] , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.5, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ad1,{duration:2, x:"-=200", y:"+=40",  ease:Power3.easeInOut, onStart:function(){mc.ad1.visible=true;}});
				this.tl2.to(mc.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				exportRoot.tl3.pause();
				exportRoot.tl4.pause();
		/*		exportRoot.tl5.pause();*/
				
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
					this.tlMaster.to(exportRoot.tl3, {time:exportRoot.tl3.duration(), duration:exportRoot.tl3.duration(), 
					ease:SteppedEase.config(exportRoot.tl3.duration()*8)},"<-8.3");
					this.tlMaster.to(exportRoot.tl4, {time:exportRoot.tl4.duration(), duration:exportRoot.tl4.duration(), 
					ease:SteppedEase.config(exportRoot.tl4.duration()*8)},"<+5");
		/*			this.tlMaster.to(exportRoot.tl5, {time:exportRoot.tl4.duration(), duration:exportRoot.tl4.duration(), 
					ease:SteppedEase.config(exportRoot.tl4.duration()*8)},"<+0.5");*/
				}		
		
				
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,-12.5,388.29999999999995,198.9);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622832083653", id:"M365_FY22Q1BTS_USA_728x90_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;