(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[697,0,294,97],[343,272,343,239],[343,0,352,270],[697,99,166,166],[0,0,341,284],[0,286,335,233],[0,521,113,111],[865,99,103,181],[115,521,113,111],[697,267,103,181],[337,513,335,233],[0,634,113,111],[802,282,103,181],[674,513,335,233],[115,634,113,109],[907,282,103,181]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.angledShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.DesignerInWordPerennialsLargerRatio2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.EditorDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.EditorIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.EditorSocial2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.ExcelDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ExcelIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ExcelMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Group242x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.PPTDesktop2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.PPTIcon2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.PPTMobile2x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707070").s().p("AgaAaQgKgMAAgOQAAgOAKgMQAMgKAOAAQAOAAAMAKQALAMgBAOQABAOgLAMQgMALgOgBQgOABgMgLg");
	this.shape.setTransform(0.05,0.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgZAZQgLgKAAgPQAAgOALgLQALgLAOAAQAPAAAKALQAMALAAAOQAAAPgMAKQgKAMgPAAQgOAAgLgMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.scribble5_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AK3NZQoEhlnPicIABABQvqlPgimUQhKjXBljMQBkjNDXhKQDXhKDNBkQDMBlBLDXQBGgnEQBbIABAAQGPCGG7BXQDfAtB/C8QB/C9gsDfQgsDfi9B/QiNBfifAAQg3AAg5gMg");
	this.shape.setTransform(135.147,86.872);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_2Sub, new cjs.Rectangle(0,0,270.3,173.8), null);


(lib.scribble5_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AuUOEQjhgciNizQiNizAbjgQg+n4Q2mUQEMhkExhQIAAAAQEghMC7gYQDhgeC1CLQBRA+A0BkQAgA+AvCLQA6CuAVBMQAoCUgEBSQgDBejsAYQhCAHiAAEQh2ADgkAGQiGASjQA3Qj5BBjaBRQj0BchBhUQgcDiizCNQiXB2i3AAQgjAAgkgEg");
	this.shape.setTransform(140.1721,90.4499);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_1Sub, new cjs.Rectangle(0,0,280.4,180.9), null);


(lib.scribble4_5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AnOIOQhtgYg9hdQg9hfAYhsQAYhtBdg9IMsoMQBeg9BtAYQBtAXA9BeQA9BegYBtQgYBthdA9IssIMQhEAshLAAQgeAAgegHg");
	this.shape.setTransform(67.688,53.3149);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_5Sub, new cjs.Rectangle(0,0,135.4,106.6), null);


(lib.scribble4_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AJAEUIyFgMQhwgChOhQQhOhQABhuQABhwBQhOQBQhOBwABISFAMQBwACBOBQQBOBQgBBuQgBBwhQBOQhPBNhuAAIgDAAg");
	this.shape.setTransform(84.8992,27.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_4Sub, new cjs.Rectangle(0,0,169.8,55.3), null);


(lib.scribble4_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ApLI0Qhsgdg4hhQg5hhAdhrQAdhsBgg4IQNpdQBhg4BsAdQBsAcA4BhQA4BhgcBsQgdBrhgA5IwNJcQhBAlhFAAQgjAAgkgJg");
	this.shape.setTransform(78.9638,57.3388);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_3Sub, new cjs.Rectangle(0,0,157.9,114.7), null);


(lib.scribble4_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AJuETIzggKQhvgBhPhPQhOhQABhuQAAhwBQhPQBQhOBwAAITgAKQBvABBOBQQBPBPgBBvQgBBvhPBPQhQBOhuAAIgCAAg");
	this.shape.setTransform(89.4245,27.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_2Sub, new cjs.Rectangle(0,0,178.9,55), null);


(lib.scribble4_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArDIHQhngpgthnQgthmAphoQAohoBmgtITCoWQBngtBoApQBnApAuBmQAsBngoBoQgpBnhmAuIzCIWQg2AXg2AAQgxAAgygTg");
	this.shape.setTransform(87.9875,53.8125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_1Sub, new cjs.Rectangle(0,0,176,107.7), null);


(lib.scribble3_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AbTSEQjBghhzigQgaglgigPQgogIg5gDIgDAAIjQgEQl4gKkShnIAAAAQmMiLl/l4IAAAAQmpmfmTg9Qh9gMiPAYQhsARinAjQjBAoikhtQilhsgojAQgojABtilQBsikDAgoQC+goB7gUQEYguD1AcQKxA4K8KuIAAAAQDcDXDeBXIABAAQCSAyDJAFIABAAIDSAEIAKABQCqAGB1AeQFwBRD0FZQBxChghDBQghDBihByQh8BZiRAAQgpAAgsgIg");
	this.shape.setTransform(230.211,116.3692);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3_1Sub, new cjs.Rectangle(0,0,460.5,232.8), null);


(lib.scribble2_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("A19Y4QkLhKiKjxQiJjyBJkLQA9jdA7iFIAAgBQB9kjDOjxIABgBQDzksGRjiQFkjIGxh2ICYgsQChg2A1gwQAzgvAUinIALh3QAFg5AGgNIWKhoIAGBIQAHBbgBBiQgCE5hJEEQggBzh1DAQiCDVh3BnIAAAAQlZFGpfCKIgBAAQpHCEkkE3QhMBYgtBrIgBAAQgcBFgfBxQhKELjxCJQidBaioAAQhaAAhdgag");
	this.shape.setTransform(190.0216,230.0196);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2_1Sub, new cjs.Rectangle(0,68.3,380.1,323.5), null);


(lib.scribble1_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AFcF1QmngwmEhvQh3gjg9hsQg8hsAih3QAih3Btg9QBsg8B4AiQFVBiF1AqQB7APBOBhQBNBigOB6QgPB7hhBNQhTBBhkAAQgSAAgTgCg");
	this.shape.setTransform(68.2062,37.5211);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_2Sub, new cjs.Rectangle(0,0,136.4,75.1), null);


(lib.scribble1_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArRFgQhsg9gih3Qgjh3A9hsQA8hsB3gjQI9ikKKgbQB7gGBcBVQBcBUAFB8QAFB6hUBcQhVBch7AFQpAAYn7CRQgrANgpAAQhKAAhGgng");
	this.shape.setTransform(87.6876,39.0698);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_1Sub, new cjs.Rectangle(0,0,175.4,78.1), null);


(lib.option_hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AhPBRIAAihICfAAIAAAuIAAA6IAAA5g");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-8.1,16,16.2);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.222,21.222,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6132,21.222,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.222,6.6132,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6132,6.6132,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1754,14.0578,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9643,13.9128,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.5018,13.9128,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.img5Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorSocial2x();
	this.instance.setTransform(0,-142,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub3, new cjs.Rectangle(0,-142,170.5,142), null);


(lib.img5Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorIcon2x();
	this.instance.setTransform(0,-83,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub2, new cjs.Rectangle(0,-83,83,139), null);


(lib.img5Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.EditorDesktop2x();
	this.instance.setTransform(0,-135,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5Sub1, new cjs.Rectangle(0,-135,176,135), null);


(lib.img4Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveDesktop2x();
	this.instance.setTransform(22.55,15.6,0.385,0.385);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub3, new cjs.Rectangle(22.6,15.6,128.9,89.7), null);


(lib.img4Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveIcon2x();
	this.instance.setTransform(5.65,5.55,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub2, new cjs.Rectangle(5.7,5.6,45.199999999999996,44.4), null);


(lib.img4Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDriveMobile2x();
	this.instance.setTransform(12.35,21.7,0.26,0.26);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4Sub1, new cjs.Rectangle(12.4,21.7,26.800000000000004,47.099999999999994), null);


(lib.img3Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelDesktop2x();
	this.instance.setTransform(23.45,16.3,0.38,0.38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub3, new cjs.Rectangle(23.5,16.3,127.30000000000001,88.60000000000001), null);


(lib.img3Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelIcon2x();
	this.instance.setTransform(5.65,5.55,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub2, new cjs.Rectangle(5.7,5.6,45.199999999999996,44.4), null);


(lib.img3Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ExcelMobile2x();
	this.instance.setTransform(11.85,20.8,0.27,0.27);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3Sub1, new cjs.Rectangle(11.9,20.8,27.800000000000004,48.900000000000006), null);


(lib.img2Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTDesktop2x();
	this.instance.setTransform(23.45,16.3,0.38,0.38);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub3, new cjs.Rectangle(23.5,16.3,127.30000000000001,88.60000000000001), null);


(lib.img2Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTIcon2x();
	this.instance.setTransform(5.65,5.45,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub2, new cjs.Rectangle(5.7,5.5,45.199999999999996,43.6), null);


(lib.img2Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PPTMobile2x();
	this.instance.setTransform(11.85,20.8,0.27,0.27);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2Sub1, new cjs.Rectangle(11.9,20.8,27.800000000000004,48.900000000000006), null);


(lib.img1Sub3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.DesignerInWordPerennialsLargerRatio2x();
	this.instance.setTransform(21.35,14.9,0.375,0.375);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub3, new cjs.Rectangle(21.4,14.9,128.6,89.6), null);


(lib.img1Sub2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group242x();
	this.instance.setTransform(5.65,5.55,0.4,0.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub2, new cjs.Rectangle(5.7,5.6,45.199999999999996,44.4), null);


(lib.img1Sub1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group332x();
	this.instance.setTransform(12.7,22.4,0.25,0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1Sub1, new cjs.Rectangle(12.7,22.4,25.8,45.300000000000004), null);


(lib.gridSubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("AwkAAMAhJAAA");
	this.shape.setTransform(106.125,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridSubSub, new cjs.Rectangle(-1,-1,214.3,2), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.doodle5_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AggBEQgEgCgCgEIgyhtQgDgGADgGQACgGAGgCQAFgDAGACQAGACADAGIAqBdIBVg7QAFgEAGACQAGABAEAFQADAFgBAGQgBAGgFAEIhkBFQgDACgFAAQgEAAgEgCg");
	this.shape.setTransform(9.0293,6.9932);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_3Sub, new cjs.Rectangle(0,0,18.1,14), null);


(lib.doodle5_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhJBLQgGgCgCgFQgDgGACgGQAdhLA9gjQAUgMAVgFIABAAQAKgEAIAAQAGgBAFAEQAEAEABAHQAAAGgEAFQgEAEgGABIgMADIgBAAQgRAEgRAKQg0AdgZBCQgCAFgFADIgGABIgGgBg");
	this.shape.setTransform(8.371,7.6347);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_2Sub, new cjs.Rectangle(0,0,16.8,15.3), null);


(lib.doodle5_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ah6CMQgHgCgDgFQgEgFACgGQAdifByhDQA6giA1gBQAGAAAFAEQAEAEAAAGQAAAGgEAFQgEAFgGAAQguABgzAeQhmA9gbCRQgBAGgFADQgEADgEAAIgDAAg");
	this.shape.setTransform(13.5545,14.0111);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_1Sub, new cjs.Rectangle(0,0,27.1,28), null);


(lib.doodle4_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AktAPQgGAAgFgFQgEgEAAgGQAAgFAEgFQAFgEAGAAIJbAAQAGAAAFAEQAEAFAAAFQAAAGgEAEQgFAFgGAAg");
	this.shape.setTransform(31.725,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_4Sub, new cjs.Rectangle(0,0,63.5,3), null);


(lib.doodle4_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjqAPQgGAAgEgFQgFgEAAgGQAAgFAFgFQAEgEAGAAIHVAAQAGAAAEAEQAFAFAAAFQAAAGgFAEQgEAFgGAAg");
	this.shape.setTransform(24.975,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_3Sub, new cjs.Rectangle(0,0,50,3), null);


(lib.doodle4_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AisAPQgHAAgEgFQgEgEgBgGQABgFAEgFQAEgEAHAAIFZAAQAHAAAEAEQAEAFABAFQgBAGgEAEQgEAFgHAAg");
	this.shape.setTransform(18.85,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_2Sub, new cjs.Rectangle(0,0,37.7,3), null);


(lib.doodle4_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhWAPQgGAAgFgFQgEgEAAgGQAAgFAEgFQAFgEAGAAICtAAQAGAAAFAEQAEAFAAAFQAAAGgEAEQgFAFgGAAg");
	this.shape.setTransform(10.225,1.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_1Sub, new cjs.Rectangle(0,0,20.5,3), null);


(lib.doodle3_4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgaA2QgEgDgCgEIglhQQgDgGADgGQACgGAGgCQAFgDAGACQAGACADAGIAdBAIA7goQAFgEAHABQAGABADAFQAEAFgBAHQgCAGgFACIhKA0QgDADgFAAQgEAAgEgCg");
	this.shape.setTransform(7.1043,5.5682);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_4Sub, new cjs.Rectangle(0,0,14.2,11.2), null);


(lib.doodle3_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3A7QgGgCgCgFQgDgGACgGQAWg4AvgbIAAAAQAOgJAQgEQAJgDAGgBQAGAAAFAEQAEADABAHQABAGgEAFQgEAEgGABIgIADIgBAAQgMADgMAHIAAAAQgmAVgSAvQgCAFgFADIgGACIgGgCg");
	this.shape.setTransform(6.5963,6.0597);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_3Sub, new cjs.Rectangle(0,0,13.2,12.1), null);


(lib.doodle3_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhbBsQgHgCgDgFQgEgFACgGQAWh4BWgzQAsgZAogBQAGAAAFAEQAEAEAAAGQAAAGgEAFQgEAFgGAAQghABglAVQhKAtgUBqQgBAGgFADQgEADgEAAIgDAAg");
	this.shape.setTransform(10.4545,10.8111);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_2Sub, new cjs.Rectangle(0,0,20.9,21.6), null);


(lib.doodle3_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAsB5QgDgBgBgDQgBgDABgDQABgDADgBIAogSIgTgIIAAABIgcgKQgDgBgCgCQgBgDABgDQAAgDADgBQAkgYASgOIgaADIgnAFQgCAAgDgBQgCgCgBgCQgBgDABgDIAbg/Ig1AuIgFACQgDAAgCgCQgDgCAAgCIgBhNIgjBLQgBADgDABQgDABgDgBQgDgBgBgDIgYg+QgDAPgBAWIgCApQAAADgCACQgCACgDAAQgEAAgCgCQgCgDAAgDIACgoIAAgBQADguAHgRQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIADAEIAbBEIAphaQABAAAAgBQAAAAABgBQAAAAABgBQAAAAAAAAQADgCACABQADABACACQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIACBdIBCg6QACgCADAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABIADAEQABACgBADIgjBRIAagDIAxgFQADAAADACQACABAAADQABADgCADQgIALg1AkIAOAEQAfAMAFADIADAEIgBAGIgEADIg2AaIgDAAIgDAAg");
	this.shape.setTransform(11.855,12.13);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_1Sub, new cjs.Rectangle(0,0,23.7,24.3), null);


(lib.doodle2_2Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiAB0QgDgCAAgDQAAgEACgCQACgCAEAAIA/gDQADAAACACQACACAAAEQAAADgCACQgCACgDAAIg/ADQgDAAgCgCgAg7A5IhEgtQgDgCAAgDQgBgDACgDQABgBADgBQADgBADACIBEAsQACACABADQABADgCACQgCADgDABIgBAAIgEgBgAgJAKQgDAAgCgDIhLhqQgCgDAAgDQABgDADgCQACgCADABQADAAACADIBMBsQABABAAADQgBADgCACIgEABIgCAAgAAwgKQgDgCgBgDIgPhcQgBgDACgDQACgDADAAQADgBADACQACACABADIAPBdQABACgCADQgCADgDAAIgBAAIgEgBgABugLQgDgBgBgDQgCgCABgDIAMg1QAAgDADgBQACgCAEABQACAAACADQACACgBAEIgMA0IgDAFIgEABIgCAAg");
	this.shape.setTransform(13.1563,11.745);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle2_2Sub, new cjs.Rectangle(0,0,26.3,23.5), null);


(lib.doodle1_3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgXBCQgEgDgCgDIg8hoQgDgGACgGQACgGAFgDQAFgDAGACQAGACADAFIAzBYIBPhCQAFgEAGABQAGAAAEAFQAEAFAAAGQgBAGgEAEIhdBOQgEADgEAAIgCABQgEAAgDgCg");
	this.shape.setTransform(9.1778,6.755);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_3Sub, new cjs.Rectangle(0,0,18.4,13.5), null);


(lib.doodle1_1Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkwDaQgHgBgEgEQgEgFABgGQAak9ENhPQBagbBuAEQBLADA4AOQAGACADAFQADAGgBAGQgCAGgFADQgGADgFgCQg2gNhHgDQhpgEhVAaQj6BKgYEnQgBAGgEAEQgFAEgFAAIgBAAg");
	this.shape.setTransform(31.9222,21.8015);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_1Sub, new cjs.Rectangle(0,0,63.9,43.6), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AnzCMIAAkXIPnAAIAAEXg");
	this.shape.setTransform(50,14);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(0,0,100,28), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.angledShadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.angledShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.angledShadow_1, new cjs.Rectangle(0,0,294,97), null);


(lib.scribble5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,271,174,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble5_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(135.2,86.9,1,1,0,0,0,135.2,86.9);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_2, new cjs.Rectangle(0,0,270.3,173.8), null);


(lib.scribble5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,270,181,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble5_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(134.7,90.5,1,1,0,0,0,134.7,90.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5_1, new cjs.Rectangle(0,0,280.4,180.9), null);


(lib.scribble5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,out:30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_11 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_12 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_13 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_14 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_15 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_16 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_17 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_18 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_19 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_20 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_21 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_22 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_23 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_24 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_25 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_26 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_27 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_28 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_29 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_30 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_31 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_32 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_33 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_34 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_35 = new cjs.Graphics().p("AaaXuMg9OgejQjIhkg/jmQg+jjBwjgQBvjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_36 = new cjs.Graphics().p("AaaX7Mg9OgejQjIhkg/jnQg+jjBwjfQBvjgDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDfjdBWQhoAqhjAAQhvAAhqg0g");
	var mask_graphics_37 = new cjs.Graphics().p("AaaYsMg9OgejQjIhkg/jnQg+jjBwjfQBvjfDchaQDdhVDIBjMA9OAejQDIBkA+DjQA/DnhvDfQhwDgjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_38 = new cjs.Graphics().p("Aa1ZdMg9OgejQjIhkg/jmQg+jkBvjfQBvjfDdhZQDdhWDHBkMA9PAejQDHBjA+DkQBADmhwDgQhvDfjdBWQhpAqhjAAQhvAAhpg1g");
	var mask_graphics_39 = new cjs.Graphics().p("AcXaPMg9OgekQjHhjg/jnQg/jjBwjgQBvjfDchZQDehWDHBkMA9OAejQDIBkA+DjQA/DnhvDfQhvDfjeBWQhoAqhjAAQhvAAhqg0g");
	var mask_graphics_40 = new cjs.Graphics().p("Ad6bAMg9OgejQjHhkhAjnQg+jjBwjfQBvjgDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDgjdBVQhoArhjAAQhvAAhqg1g");
	var mask_graphics_41 = new cjs.Graphics().p("AfdbxMg9OgejQjIhkg/jnQg+jjBwjfQBvjfDchaQDdhVDIBjMA9OAekQDIBjA+DjQA/DnhvDfQhwDgjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_42 = new cjs.Graphics().p("Afsb4Mg9OgejQjIhkg/jmQg+jkBvjfQBwjfDchaQDdhVDIBjMA9OAekQDIBjA+DkQA/DmhwDgQhvDfjdBWQhoAqhkAAQhvAAhpg1g");
	var mask_graphics_43 = new cjs.Graphics().p("EAgKAcHMg9OgejQjIhkg/jnQg+jjBvjfQBwjgDchZQDdhWDIBkMA9OAejQDHBkA/DjQA/DnhwDfQhvDfjdBWQhoAqhkAAQhvAAhpg0g");
	var mask_graphics_44 = new cjs.Graphics().p("EAg7AcfMg9OgejQjIhkg/jnQg+jjBvjfQBwjgDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhwDfQhvDfjdBWQhoAqhkAAQhvAAhpg0g");
	var mask_graphics_45 = new cjs.Graphics().p("EAiDAdCMg9OgejQjIhkg/jnQg+jjBvjfQBwjfDchaQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDgjdBVQhoArhjAAQhwAAhpg1g");
	var mask_graphics_46 = new cjs.Graphics().p("EAjmAdyMg9OgejQjIhkg/jmQg+jkBwjfQBvjfDchaQDdhVDIBjMA9OAekQDIBjA+DkQA/DmhvDgQhwDfjdBWQhoAqhjAAQhvAAhqg1g");
	var mask_graphics_47 = new cjs.Graphics().p("EAlkAewMg9OgelQjIhig/jnQg+jjBvjgQBwjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDfjdBWQhoAqhjAAQhwAAhpg0g");
	var mask_graphics_48 = new cjs.Graphics().p("EAn1Af2Mg9OgekQjIhjg/jmQg+jkBvjfQBwjfDchaQDdhVDIBjMA9OAekQDIBjA+DkQA/DmhwDgQhvDfjdBWQhoAqhkAAQhvAAhpg1g");
	var mask_graphics_49 = new cjs.Graphics().p("EAqJAg+Mg9OgekQjIhkg/jlQg+jkBvjfQBwjfDchaQDdhVDIBjMA9OAekQDIBjA+DkQA/DmhwDgQhvDfjdBWQhoAqhkAAQhvAAhpg1g");
	var mask_graphics_50 = new cjs.Graphics().p("EAsQAiAMg9OgekQjIhkg/jmQg+jjBvjfQBwjfDchaQDdhVDIBjMA9OAekQDIBjA+DjQA/DnhvDfQhwDgjdBWQhoAqhkAAQhvAAhpg1g");
	var mask_graphics_51 = new cjs.Graphics().p("EAuCAi4Mg9OgekQjIhkg/jmQg+jjBwjfQBvjgDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDfjdBWQhoAqhjAAQhvAAhqg0g");
	var mask_graphics_52 = new cjs.Graphics().p("EAveAjlMg9OgelQjIhjg/jmQg+jjBvjgQBwjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDfjdBWQhoAqhjAAQhvAAhqg0g");
	var mask_graphics_53 = new cjs.Graphics().p("EAwmAkIMg9OgelQjIhjg/jnQg+jiBvjgQBwjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhvDfQhwDfjdBWQhoAqhkAAQhvAAhpg0g");
	var mask_graphics_54 = new cjs.Graphics().p("EAxdAkiMg9OgekQjIhkg/jmQg+jjBvjfQBwjfDchZQDdhWDIBjMA9OAekQDIBjA+DkQA/DmhwDgQhvDfjdBWQhoAqhkAAQhvAAhpg1g");
	var mask_graphics_55 = new cjs.Graphics().p("EAyGAk2Mg9OgekQjIhkg/jnQg+jiBvjfQBwjfDchaQDdhVDIBjMA9OAekQDHBjA/DjQA/DnhwDfQhvDgjdBWQhoAqhkAAQhvAAhpg1g");
	var mask_graphics_56 = new cjs.Graphics().p("EAyjAlEMg9OgekQjIhkg/jmQg/jjBwjfQBvjfDdhaQDdhVDHBjMA9OAekQDIBjA+DkQBADmhwDgQhvDfjeBWQhoAqhjAAQhvAAhpg1g");
	var mask_graphics_57 = new cjs.Graphics().p("EAy2AlOMg9PgelQjHhjg/jnQg/jiBwjgQBvjfDchZQDehWDHBkMA9OAejQDIBkA+DjQA/DmhvDgQhvDfjeBWQhoAqhjAAQhvAAhpg0g");
	var mask_graphics_58 = new cjs.Graphics().p("EAzAAlTMg9OgelQjIhjg/jnQg+jiBvjgQBwjfDchZQDdhWDIBkMA9OAejQDIBkA+DjQA/DnhwDfQhvDfjdBWQhoAqhkAAQhvAAhpg0g");
	var mask_graphics_59 = new cjs.Graphics().p("EAzDAlUMg9OgekQjIhkg/jnQg+jiBwjfQBvjfDchaQDdhVDIBjMA9OAekQDIBjA+DjQA/DnhvDfQhwDgjdBWQhoAqhjAAQhvAAhqg1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_graphics_11,x:-164.4582,y:-31.293}).wait(1).to({graphics:mask_graphics_12,x:-161.643,y:-29.8813}).wait(1).to({graphics:mask_graphics_13,x:-155.8343,y:-26.9686}).wait(1).to({graphics:mask_graphics_14,x:-146.3273,y:-22.2014}).wait(1).to({graphics:mask_graphics_15,x:-132.315,y:-15.1751}).wait(1).to({graphics:mask_graphics_16,x:-113.103,y:-5.5415}).wait(1).to({graphics:mask_graphics_17,x:-88.689,y:6.7007}).wait(1).to({graphics:mask_graphics_18,x:-60.6005,y:20.7854}).wait(1).to({graphics:mask_graphics_19,x:-31.9235,y:35.1652}).wait(1).to({graphics:mask_graphics_20,x:-5.725,y:48.3022}).wait(1).to({graphics:mask_graphics_21,x:16.3974,y:59.3952}).wait(1).to({graphics:mask_graphics_22,x:34.2188,y:68.3316}).wait(1).to({graphics:mask_graphics_23,x:48.162,y:75.3232}).wait(1).to({graphics:mask_graphics_24,x:58.8087,y:80.6619}).wait(1).to({graphics:mask_graphics_25,x:66.7036,y:84.6207}).wait(1).to({graphics:mask_graphics_26,x:72.3025,y:87.4283}).wait(1).to({graphics:mask_graphics_27,x:75.9728,y:89.2687}).wait(1).to({graphics:mask_graphics_28,x:78.0077,y:90.2891}).wait(1).to({graphics:mask_graphics_29,x:78.6418,y:90.607}).wait(1).to({graphics:mask_graphics_30,x:98.421,y:100.4612}).wait(1).to({graphics:mask_graphics_31,x:118.2001,y:110.3154}).wait(1).to({graphics:mask_graphics_32,x:137.9793,y:120.1695}).wait(1).to({graphics:mask_graphics_33,x:157.7585,y:130.0237}).wait(1).to({graphics:mask_graphics_34,x:177.5376,y:139.8779}).wait(1).to({graphics:mask_graphics_35,x:197.3168,y:149.732}).wait(1).to({graphics:mask_graphics_36,x:217.096,y:158.3457}).wait(1).to({graphics:mask_graphics_37,x:236.8751,y:163.2728}).wait(1).to({graphics:mask_graphics_38,x:254.023,y:168.1999}).wait(1).to({graphics:mask_graphics_39,x:263.9126,y:173.1269}).wait(1).to({graphics:mask_graphics_40,x:273.8022,y:178.054}).wait(1).to({graphics:mask_graphics_41,x:283.6918,y:182.9814}).wait(1).to({graphics:mask_graphics_42,x:285.144,y:183.6887}).wait(1).to({graphics:mask_graphics_43,x:288.1403,y:185.1486}).wait(1).to({graphics:mask_graphics_44,x:293.0443,y:187.5381}).wait(1).to({graphics:mask_graphics_45,x:300.2724,y:191.0599}).wait(1).to({graphics:mask_graphics_46,x:310.1827,y:195.8886}).wait(1).to({graphics:mask_graphics_47,x:322.7763,y:202.0247}).wait(1).to({graphics:mask_graphics_48,x:337.2654,y:209.0844}).wait(1).to({graphics:mask_graphics_49,x:352.0581,y:216.292}).wait(1).to({graphics:mask_graphics_50,x:365.5723,y:222.8766}).wait(1).to({graphics:mask_graphics_51,x:376.9838,y:228.4368}).wait(1).to({graphics:mask_graphics_52,x:386.1768,y:232.916}).wait(1).to({graphics:mask_graphics_53,x:393.3692,y:236.4204}).wait(1).to({graphics:mask_graphics_54,x:398.8611,y:239.0963}).wait(1).to({graphics:mask_graphics_55,x:402.9336,y:241.0806}).wait(1).to({graphics:mask_graphics_56,x:405.8217,y:242.4878}).wait(1).to({graphics:mask_graphics_57,x:407.715,y:243.4103}).wait(1).to({graphics:mask_graphics_58,x:408.7647,y:243.9217}).wait(1).to({graphics:mask_graphics_59,x:409.0918,y:244.0814}).wait(1));

	// Layer_5
	this.instance = new lib.scribble5_2();
	this.instance.setTransform(203.9,146.35,0.9443,0.9443,4.7374,0,0,135.2,87);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(11).to({_off:false},0).wait(49));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Ap7TBQjNh1hOjtQhPjtBcjaQBgjZDUhHMBA7gVoQDThGDNB1QDQB2BPDtQBODthfDZQhdDbjUBGMhA6AVoQhPAahPAAQiEAAiChKg");
	var mask_1_graphics_1 = new cjs.Graphics().p("Ap/TBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AqOTBQjMh1hPjtQhPjtBdjaQBfjZDUhHMBA7gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhdDbjUBGMhA6AVoQhPAahPAAQiEAAiChKg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AqpTBQjMh1hPjtQhPjtBdjaQBgjZDThHMBA7gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhdDbjTBGMhA7AVoQhPAahPAAQiDAAiDhKg");
	var mask_1_graphics_4 = new cjs.Graphics().p("ArTTBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AsSTBQjMh1hPjtQhPjtBcjaQBgjZDUhHMBA7gVoQDUhGDMB1QDQB2BPDtQBODthfDZQhdDbjUBGMhA6AVoQhPAahPAAQiEAAiChKg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AtqTBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AvhTBQjMh1hPjtQhPjtBcjaQBgjZDUhHMBA7gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhdDbjUBGMhA6AVoQhPAahPAAQiEAAiChKg");
	var mask_1_graphics_8 = new cjs.Graphics().p("Ax2TBQjMh1hPjtQhPjtBdjaQBgjZDThHMBA7gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhdDbjTBGMhA7AVoQhPAahPAAQiDAAiDhKg");
	var mask_1_graphics_9 = new cjs.Graphics().p("A0bTBQjNh1hPjtQhOjtBcjaQBgjZDUhHMBA7gVoQDThGDNB1QDQB2BODtQBPDthfDZQhdDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_10 = new cjs.Graphics().p("A26TBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_11 = new cjs.Graphics().p("A5CTBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_12 = new cjs.Graphics().p("A6vTBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_13 = new cjs.Graphics().p("A8FTBQjMh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiDhKg");
	var mask_1_graphics_14 = new cjs.Graphics().p("A9GTBQjMh1hPjtQhPjtBdjaQBfjZDUhHMBA7gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhdDbjUBGMhA6AVoQhPAahPAAQiEAAiChKg");
	var mask_1_graphics_15 = new cjs.Graphics().p("A93TBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_16 = new cjs.Graphics().p("A+cTBQjNh1hOjtQhPjtBcjaQBgjZDUhHMBA7gVoQDThGDNB1QDQB2BPDtQBODthfDZQhdDbjUBGMhA6AVoQhPAahPAAQiEAAiChKg");
	var mask_1_graphics_17 = new cjs.Graphics().p("A/wTBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_18 = new cjs.Graphics().p("EghFATBQjMh1hPjtQhPjtBdjaQBfjZDUhHMBA7gVoQDUhGDMB1QDQB2BPDtQBPDthgDZQhdDbjUBGMhA6AVoQhPAahPAAQiDAAiDhKg");
	var mask_1_graphics_19 = new cjs.Graphics().p("EgiZATBQjNh1hOjtQhPjtBcjaQBgjZDUhHMBA7gVoQDThGDNB1QDQB2BPDtQBODthfDZQhdDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_20 = new cjs.Graphics().p("EgjtATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgkBATBQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDbjUBGMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EgkBATXQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB0QDPB3BPDtQBPDthgDZQhcDajUBHMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EgkBAUDQjNh1hPjtQhPjtBdjbQBgjYDUhHMBA6gVoQDUhHDNB1QDPB3BPDtQBPDthgDZQhcDajUBHMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgkBAU4QjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDajUBHMhA7AVoQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EgkBAVyQjNh1hPjsQhPjtBdjbQBgjZDUhGMBA6gVoQDUhHDNB1QDPB3BPDsQBPDthgDZQhcDbjUBGMhA7AVoQhPAbhOAAQiEAAiChLg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgkBAWsQjNh1hPjtQhPjtBdjbQBgjZDUhGMBA6gVoQDUhHDNB1QDPB3BPDtQBPDthgDYQhcDajUBHMhA7AVpQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgkBAXeQjNh1hPjsQhPjtBdjbQBgjZDUhGMBA6gVoQDUhHDNB1QDPB3BPDsQBPDthgDZQhcDajUBHMhA7AVoQhPAbhOAAQiEAAiChLg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgkBAYJQjNh1hPjtQhPjtBdjbQBgjZDUhGMBA6gVoQDUhHDNB1QDPB3BPDtQBPDshgDZQhcDajUBHMhA7AVpQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgkBAYrQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB0QDPB3BPDtQBPDthgDZQhcDZjUBHMhA7AVpQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EgkBAZGQjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDZQhcDajUBGMhA7AVpQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EgkBAZbQjNh1hPjsQhPjtBdjbQBgjZDUhGMBA6gVoQDUhHDNB1QDPB3BPDsQBPDthgDYQhcDbjUBHMhA7AVoQhPAbhOAAQiEAAiChLg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EgkBAZsQjNh1hPjtQhPjsBdjbQBgjZDUhHMBA6gVoQDUhGDNB1QDPB2BPDtQBPDthgDYQhcDbjUBGMhA7AVpQhPAahOAAQiEAAiChKg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EgkBAZ5QjNh1hPjtQhPjtBdjaQBgjZDUhHMBA6gVoQDUhGDNB0QDPB3BPDtQBPDthgDYQhcDajUBHMhA7AVpQhPAahOAAQiEAAiChKg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:429.6142,y:-45.4012}).wait(1).to({graphics:mask_1_graphics_1,x:429.1796,y:-45.1107}).wait(1).to({graphics:mask_1_graphics_2,x:427.741,y:-44.1526}).wait(1).to({graphics:mask_1_graphics_3,x:425.056,y:-42.3642}).wait(1).to({graphics:mask_1_graphics_4,x:420.7955,y:-39.5266}).wait(1).to({graphics:mask_1_graphics_5,x:414.5227,y:-35.3487}).wait(1).to({graphics:mask_1_graphics_6,x:405.6996,y:-29.4722}).wait(1).to({graphics:mask_1_graphics_7,x:393.8305,y:-21.567}).wait(1).to({graphics:mask_1_graphics_8,x:378.9584,y:-11.6618}).wait(1).to({graphics:mask_1_graphics_9,x:362.4082,y:-0.6388}).wait(1).to({graphics:mask_1_graphics_10,x:346.4936,y:9.9608}).wait(1).to({graphics:mask_1_graphics_11,x:332.8853,y:19.0244}).wait(1).to({graphics:mask_1_graphics_12,x:321.9738,y:26.2918}).wait(1).to({graphics:mask_1_graphics_13,x:313.47,y:31.9556}).wait(1).to({graphics:mask_1_graphics_14,x:306.938,y:36.3061}).wait(1).to({graphics:mask_1_graphics_15,x:301.9889,y:39.6024}).wait(1).to({graphics:mask_1_graphics_16,x:298.3142,y:42.0488}).wait(1).to({graphics:mask_1_graphics_17,x:289.8831,y:47.4757}).wait(1).to({graphics:mask_1_graphics_18,x:281.4504,y:52.9026}).wait(1).to({graphics:mask_1_graphics_19,x:273.0177,y:58.3296}).wait(1).to({graphics:mask_1_graphics_20,x:264.585,y:63.7565}).wait(1).to({graphics:mask_1_graphics_21,x:249.7094,y:69.1834}).wait(1).to({graphics:mask_1_graphics_22,x:232.844,y:74.6103}).wait(1).to({graphics:mask_1_graphics_23,x:215.9787,y:80.0373}).wait(1).to({graphics:mask_1_graphics_24,x:199.1133,y:85.4642}).wait(1).to({graphics:mask_1_graphics_25,x:182.2479,y:90.8911}).wait(1).to({graphics:mask_1_graphics_26,x:165.3825,y:96.318}).wait(1).to({graphics:mask_1_graphics_27,x:148.5171,y:101.7449}).wait(1).to({graphics:mask_1_graphics_28,x:131.6517,y:107.1719}).wait(1).to({graphics:mask_1_graphics_29,x:114.7864,y:112.5988}).wait(1).to({graphics:mask_1_graphics_30,x:113.9916,y:112.871}).wait(1).to({graphics:mask_1_graphics_31,x:111.4005,y:113.7585}).wait(1).to({graphics:mask_1_graphics_32,x:106.6348,y:115.3908}).wait(1).to({graphics:mask_1_graphics_33,x:99.2014,y:117.9368}).wait(1).to({graphics:mask_1_graphics_34,x:88.46,y:121.6159}).wait(1).to({graphics:mask_1_graphics_35,x:73.6044,y:126.7041}).wait(1).to({graphics:mask_1_graphics_36,x:53.7236,y:131.321}).wait(1).to({graphics:mask_1_graphics_37,x:28.1119,y:135.7071}).wait(1).to({graphics:mask_1_graphics_38,x:-2.9256,y:141.0224}).wait(1).to({graphics:mask_1_graphics_39,x:-37.0832,y:146.8721}).wait(1).to({graphics:mask_1_graphics_40,x:-70.5231,y:152.5989}).wait(1).to({graphics:mask_1_graphics_41,x:-100.1454,y:157.6719}).wait(1).to({graphics:mask_1_graphics_42,x:-124.8188,y:161.8973}).wait(1).to({graphics:mask_1_graphics_43,x:-144.7526,y:165.3111}).wait(1).to({graphics:mask_1_graphics_44,x:-160.6201,y:168.0285}).wait(1).to({graphics:mask_1_graphics_45,x:-173.1237,y:170.1698}).wait(1).to({graphics:mask_1_graphics_46,x:-182.862,y:171.8375}).wait(1).to({graphics:mask_1_graphics_47,x:-190.3136,y:173.1129}).wait(1).to({graphics:null,x:0,y:0}).wait(12));

	// Layer_2
	this.instance_1 = new lib.scribble5_1();
	this.instance_1.setTransform(209.65,89.4,0.9443,0.9443,4.7374,0,0,134.8,90.4);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},48).wait(12));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-6.1,353.7,256.1);


(lib.scribble4_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,136,107,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_5Sub();
	this.sub.name = "sub";
	this.sub.setTransform(67.7,53.3,1,1,0,0,0,67.7,53.3);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_5, new cjs.Rectangle(0,0,135.4,106.6), null);


(lib.scribble4_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,170,56,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(84.9,27.6,1,1,0,0,0,84.9,27.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_4, new cjs.Rectangle(0,0,169.8,55.3), null);


(lib.scribble4_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,158,115,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(79,57.3,1,1,0,0,0,79,57.3);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_3, new cjs.Rectangle(0,0,157.9,114.7), null);


(lib.scribble4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,180,55,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(89.4,27.4,1,1,0,0,0,89.4,27.4);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_2, new cjs.Rectangle(0,0,178.9,55), null);


(lib.scribble4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,178,108,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble4_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(88,53.8,1,1,0,0,0,88,53.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4_1, new cjs.Rectangle(0,0,176,107.7), null);


(lib.scribble4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_21 = new cjs.Graphics().p("AISKPQhngtgxhpQgxhoAihoQAhhnBggqIdWspQBfgpBoAtQBlAsAxBpQAxBoggBoQgiBnhgApI9WMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_22 = new cjs.Graphics().p("AHyKPQhngtgxhpQgxhoAihoQAhhnBggqIdWspQBfgpBoAtQBlAsAxBpQAxBoggBoQgiBnhgApI9WMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_23 = new cjs.Graphics().p("AGXKPQhogtgxhpQgwhoAihoQAghnBggqIdWspQBggpBnAtQBmAsAwBpQAxBoggBoQgiBnhgApI9WMqQguAUgwAAQgzAAg0gXg");
	var mask_graphics_24 = new cjs.Graphics().p("ADvKPQhngtgxhpQgxhoAihoQAhhnBfgqIdWspQBggpBnAtQBmAsAxBpQAxBoghBoQgiBnhfApI9WMqQgvAUgvAAQgzAAg1gXg");
	var mask_graphics_25 = new cjs.Graphics().p("AA0KPQhmgtgxhpQgxhoAihoQAghnBfgqIdWspQBggpBnAtQBmAsAxBpQAxBoghBoQgiBnhfApI9XMqQguAUgvAAQgzAAg1gXg");
	var mask_graphics_26 = new cjs.Graphics().p("AhPKPQhngtgxhpQgxhoAihoQAhhnBfgqIdVspQBggpBnAtQBmAsAxBpQAxBoghBoQgiBnhfApI9WMqQgvAUgvAAQgyAAg1gXg");
	var mask_graphics_27 = new cjs.Graphics().p("AiaKlQhogtgxhpQgwhoAihnQAghoBggpIdVsqQBggpBnAtQBmAsAwBpQAxBoggBoQgiBnhgAqI9WMpQgtAUgwAAQgzAAg0gXg");
	var mask_graphics_28 = new cjs.Graphics().p("Ai/K1QhngtgxhpQgxhpAihnQAghnBggqIdVspQBggpBnAtQBmAsAxBpQAxBoghBoQgiBnhfApI9XMqQgtAUgvAAQgzAAg1gXg");
	var mask_graphics_29 = new cjs.Graphics().p("AjJK4QhogtgwhpQgxhoAihoQAghnBggqIdVspQBggpBnAtQBmAsAxBpQAwBoggBoQgiBnhgApI9VMqQguAUgvAAQg0AAg0gXg");
	var mask_graphics_30 = new cjs.Graphics().p("AjfLBQhngtgxhoQgxhpAihnQAghoBggpIdVsqQBggpBnAtQBmAtAxBoQAxBpghBoQgiBnhfApI9WMpQguAUgvAAQgzAAg1gXg");
	var mask_graphics_31 = new cjs.Graphics().p("Aj1LLQhngtgxhpQgxhpAihnQAhhnBggqIdVspQBfgpBoAtQBlAsAxBpQAxBoggBoQgiBnhgApI9VMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_32 = new cjs.Graphics().p("AkKLUQhogtgwhpQgxhoAihnQAghoBggpIdVsqQBggpBnAtQBmAtAxBoQAwBpggBoQgiBnhgApI9VMpQguAUgvAAQg0AAg0gXg");
	var mask_graphics_33 = new cjs.Graphics().p("AkgLeQhngtgxhpQgxhpAihnQAghnBggqIdVspQBggpBnAtQBmAsAxBpQAxBoghBoQgiBnhfApI9VMqQgvAUgvAAQgzAAg1gXg");
	var mask_graphics_34 = new cjs.Graphics().p("Ak2LnQhngtgxhpQgxhoAihnQAhhoBggpIdVsqQBfgpBoAtQBlAtAxBoQAxBpggBnQgiBohgApI9VMpQguAUgwAAQgzAAg1gXg");
	var mask_graphics_35 = new cjs.Graphics().p("AlLLxQhogugwhoQgxhpAihnQAghnBggqIdVspQBggpBnAtQBmAsAxBpQAwBoggBoQgiBnhgApI9VMqQguAUgvAAQg0AAg0gXg");
	var mask_graphics_36 = new cjs.Graphics().p("AlhL6QhngtgxhpQgxhoAihnQAghoBggpIdVsqQBggpBnAtQBmAtAxBoQAxBpghBnQgiBnhfAqI9VMpQgvAUgvAAQgzAAg1gXg");
	var mask_graphics_37 = new cjs.Graphics().p("Al3MEQhngugxhoQgxhpAihnQAhhnBggqIdVspQBfgqBoAuQBlAsAxBpQAxBoggBoQgiBnhgApI9VMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_38 = new cjs.Graphics().p("AmMMNQhogtgwhpQgxhoAihnQAghoBggpIdVsqQBggpBnAtQBmAtAxBoQAwBpggBnQgiBnhgAqI9VMpQguAUgvAAQg0AAg0gXg");
	var mask_graphics_39 = new cjs.Graphics().p("AmiMXQhngugxhoQgxhpAihnQAghnBggqIdVspQBggqBnAuQBmAsAxBpQAxBoghBoQgiBnhfApI9VMqQgvAUgvAAQgzAAg1gXg");
	var mask_graphics_40 = new cjs.Graphics().p("Am4MgQhngtgxhpQgxhoAihnQAhhoBggpIdVsqQBfgpBoAtQBlAtAxBoQAxBpggBnQgiBnhgAqI9VMpQguAUgwAAQgzAAg1gXg");
	var mask_graphics_41 = new cjs.Graphics().p("AnNMqQhogugwhoQgxhpAihnQAghnBggqIdVspQBggqBnAuQBmAsAxBpQAwBoggBoQgiBnhgAoI9VMrQguAUgvAAQg0AAg0gXg");
	var mask_graphics_42 = new cjs.Graphics().p("AnjMzQhngtgxhpQgxhoAihnQAhhoBfgpIdVsqQBggpBnAtQBmAtAxBoQAxBpghBnQgiBnhfApI9VMqQgvAUgvAAQgzAAg1gXg");
	var mask_graphics_43 = new cjs.Graphics().p("An5M8QhngtgxhoQgxhpAihnQAhhoBggpIdVspQBfgqBoAuQBlAsAxBpQAxBoggBoQgiBnhgAoI9VMrQguAUgwAAQgzAAg1gYg");
	var mask_graphics_44 = new cjs.Graphics().p("AoONGQhogtgwhpQgxhoAihnQAghoBggpIdVsqQBggpBnAtQBmAsAxBpQAwBpggBnQgiBnhgApI9VMqQguAUgvAAQg0AAg0gXg");
	var mask_graphics_45 = new cjs.Graphics().p("AokNPQhngtgxhoQgxhpAihnQAhhoBfgpIdVspQBggqBnAtQBmAtAxBoQAxBpghBoQgiBnhfAoI9VMrQgvATgvAAQgzAAg1gXg");
	var mask_graphics_46 = new cjs.Graphics().p("Ao6NZQhngtgxhpQgxhoAihnQAhhoBggpIdVsqQBfgpBoAtQBlAsAxBpQAxBpggBnQgiBmhgAqI9VMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_47 = new cjs.Graphics().p("ApPNiQhogtgwhoQgxhpAihnQAghoBggpIdVspQBggqBnAtQBmAtAxBoQAwBpggBoQgiBmhgApI9VMrQguATgvAAQg0AAg0gXg");
	var mask_graphics_48 = new cjs.Graphics().p("AplNsQhngtgxhpQgxhoAihnQAhhoBfgpIdVsqQBggpBnAtQBmAsAxBpQAxBoghBoQgiBmhfAqI9VMqQgvAUgvAAQgzAAg1gXg");
	var mask_graphics_49 = new cjs.Graphics().p("Ap6N2QhngtgxhoQgxhpAihnQAghoBggpIdVspQBggqBnAuQBmAsAxBpQAxBoghBoQgiBmhgApI9VMrQguAUgvAAQgzAAg1gYg");
	var mask_graphics_50 = new cjs.Graphics().p("AqUOCQhngtgxhpQgxhoAihnQAghoBggpIdVsqQBggpBnAtQBmAsAxBpQAxBoghBoQgiBmhgAqI9VMqQguAUgvAAQgzAAg1gXg");
	var mask_graphics_51 = new cjs.Graphics().p("ArbOhQhngtgxhpQgxhoAihnQAghoBggpIdVsqQBggpBnAtQBmAsAxBpQAxBoghBoQgiBmhgAqI9VMqQguAUgvAAQgzAAg1gXg");
	var mask_graphics_52 = new cjs.Graphics().p("AtfPaQhngtgxhoQgxhpAihnQAhhoBfgpIdVspQBggqBoAtQBlAtAxBoQAxBpggBnQgiBnhgApI9VMrQguATgwAAQgzAAg1gXg");
	var mask_graphics_53 = new cjs.Graphics().p("Av6QlQhngtgxhoQgxhpAihnQAhhoBggpIdVsqQBfgpBoAtQBlAtAxBoQAxBoggBoQgiBnhgApI9VMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_54 = new cjs.Graphics().p("Av6RlQhngtgxhpQgxhoAihnQAhhoBggpIdVsqQBfgpBoAtQBlAsAxBpQAxBoggBnQgiBnhgAqI9VMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_55 = new cjs.Graphics().p("Av6SPQhngtgxhpQgxhoAihnQAhhoBggpIdVsqQBfgpBoAtQBlAsAxBoQAxBoggBoQgiBnhgApI9VMrQguAUgwAAQgzAAg1gXg");
	var mask_graphics_56 = new cjs.Graphics().p("Av6SnQhngtgxhoQgxhpAihnQAhhoBggpIdVsqQBfgpBoAtQBlAtAxBnQAxBpggBoQgiBnhgApI9VMqQguAUgwAAQgzAAg1gXg");
	var mask_graphics_57 = new cjs.Graphics().p("Av6SzQhngtgxhoQgxhpAihnQAhhoBggpIdVspQBfgqBoAuQBlAsAxBoQAxBoggBoQgiBnhgApI9VMrQguAUgwAAQgzAAg1gYg");
	var mask_graphics_58 = new cjs.Graphics().p("Av6S3QhngtgxhpQgxhoAihnQAhhoBggpIdVsqQBfgpBoAtQBlAtAxBnQAxBpggBnQgiBnhgAqI9VMqQguAUgwAAQgzAAg1gXg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(21).to({graphics:mask_graphics_21,x:274.8655,y:13.0306}).wait(1).to({graphics:mask_graphics_22,x:271.6642,y:15.7936}).wait(1).to({graphics:mask_graphics_23,x:262.4862,y:23.7128}).wait(1).to({graphics:mask_graphics_24,x:245.7363,y:38.1656}).wait(1).to({graphics:mask_graphics_25,x:227.0217,y:54.3138}).wait(1).to({graphics:mask_graphics_26,x:213.8285,y:65.6977}).wait(1).to({graphics:mask_graphics_27,x:206.2861,y:69.9921}).wait(1).to({graphics:mask_graphics_28,x:202.624,y:71.572}).wait(1).to({graphics:mask_graphics_29,x:201.5905,y:71.8794}).wait(1).to({graphics:mask_graphics_30,x:199.4248,y:72.8276}).wait(1).to({graphics:mask_graphics_31,x:197.2584,y:73.7756}).wait(1).to({graphics:mask_graphics_32,x:195.0919,y:74.7236}).wait(1).to({graphics:mask_graphics_33,x:192.9255,y:75.6716}).wait(1).to({graphics:mask_graphics_34,x:190.7591,y:76.6196}).wait(1).to({graphics:mask_graphics_35,x:188.5926,y:77.5676}).wait(1).to({graphics:mask_graphics_36,x:186.4262,y:78.5156}).wait(1).to({graphics:mask_graphics_37,x:184.2598,y:79.4636}).wait(1).to({graphics:mask_graphics_38,x:182.0933,y:80.4116}).wait(1).to({graphics:mask_graphics_39,x:179.9269,y:81.3596}).wait(1).to({graphics:mask_graphics_40,x:177.7604,y:82.3076}).wait(1).to({graphics:mask_graphics_41,x:175.594,y:83.2556}).wait(1).to({graphics:mask_graphics_42,x:173.4276,y:84.2037}).wait(1).to({graphics:mask_graphics_43,x:171.2611,y:85.1517}).wait(1).to({graphics:mask_graphics_44,x:169.0947,y:86.0997}).wait(1).to({graphics:mask_graphics_45,x:166.9283,y:87.0477}).wait(1).to({graphics:mask_graphics_46,x:164.7618,y:87.9957}).wait(1).to({graphics:mask_graphics_47,x:162.5954,y:88.9437}).wait(1).to({graphics:mask_graphics_48,x:160.429,y:89.8917}).wait(1).to({graphics:mask_graphics_49,x:158.3155,y:90.9544}).wait(1).to({graphics:mask_graphics_50,x:155.7133,y:92.0915}).wait(1).to({graphics:mask_graphics_51,x:148.6144,y:95.1923}).wait(1).to({graphics:mask_graphics_52,x:135.4468,y:100.9439}).wait(1).to({graphics:mask_graphics_53,x:116.668,y:108.4278}).wait(1).to({graphics:mask_graphics_54,x:87.4986,y:114.7984}).wait(1).to({graphics:mask_graphics_55,x:68.3235,y:118.9862}).wait(1).to({graphics:mask_graphics_56,x:57.1307,y:121.4307}).wait(1).to({graphics:mask_graphics_57,x:51.5352,y:122.6527}).wait(1).to({graphics:mask_graphics_58,x:49.9241,y:123.0044}).wait(2));

	// Layer_10
	this.instance = new lib.scribble4_5();
	this.instance.setTransform(240.9,94.35,1.03,0.9938,0,9.0529,8.6456,68.2,53.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(21).to({_off:false},0).wait(39));

	// Layer_4 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_15 = new cjs.Graphics().p("APHG8I/ulXQhogRg7hcQg7hcAUhwQAUhxBXhFQBYhCBoARIfuFXQBoARA6BbQA8BdgUBxQgUBwhYBDQhFA3hQAAQgUAAgWgEg");
	var mask_1_graphics_16 = new cjs.Graphics().p("APHG8I/ulXQhogRg7hcQg7hcAUhwQAUhxBXhFQBYhCBoARIfuFXQBoARA6BbQA8BdgUBxQgUBwhYBDQhFA3hQAAQgUAAgWgEg");
	var mask_1_graphics_17 = new cjs.Graphics().p("APHG8I/ulXQhogRg7hcQg7hcAUhwQAUhxBXhFQBYhCBoARIfuFXQBoARA6BbQA8BdgUBxQgUBwhYBDQhFA3hQAAQgUAAgWgEg");
	var mask_1_graphics_18 = new cjs.Graphics().p("APHG8I/ulXQhogRg7hcQg7hcAUhwQAUhxBXhFQBYhCBoARIfuFXQBoARA6BbQA8BdgUBxQgUBwhYBDQhFA3hQAAQgUAAgWgEg");
	var mask_1_graphics_19 = new cjs.Graphics().p("APHG8I/ulWQhogRg7hdQg7hbAUhxQAUhxBXhEQBYhDBoASIfuFWQBoASA6BaQA8BdgUBxQgUBxhYBDQhFA2hQAAQgUAAgWgEg");
	var mask_1_graphics_20 = new cjs.Graphics().p("ARaHaI/ulWQhogSg7hdQg7haAUhxQAUhxBXhEQBYhDBoASIfuFWQBoASA6BaQA8BdgUBxQgUBxhYBDQhFA2hQAAQgVAAgVgEg");
	var mask_1_graphics_21 = new cjs.Graphics().p("ATVHvI/ulWQhogSg8hdQg7haAUhxQAUhxBYhEQBYhDBnARIfvFXQBnARA7BbQA8BdgUBxQgUBwhYBDQhGA3hQAAQgUAAgVgEg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AUBH3I/ulWQhogSg7hdQg7haAUhxQAUhxBXhEQBYhDBnARIfvFXQBnARA7BbQA8BdgUBxQgUBxhYBCQhGA3hPAAQgVAAgVgEg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AUTH6I/vlWQhngSg8hdQg7haAUhxQAUhxBXhEQBYhDBoARIfuFXQBoARA7BbQA7BdgUBxQgUBxhYBDQhFA2hQAAQgUAAgVgEg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AUkH9I/ulWQhogSg8hdQg6haAUhxQAUhxBXhEQBYhDBnASIfvFWQBnASA7BaQA8BdgUBxQgUBxhYBDQhGA2hPAAQgVAAgVgEg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AU1IBI/ulXQhngRg8hdQg7hbAUhxQAUhxBXhEQBYhDBoASIfuFWQBoASA6BaQA8BdgUBxQgUBxhYBDQhFA2hQAAQgUAAgWgDg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AVHIEI/ulXQhogRg8hdQg7hbAUhxQAUhxBYhEQBYhDBnASIfuFWQBoASA7BaQA8BdgUBxQgUBxhYBDQhGA2hQAAQgUAAgVgDg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AVYIHI/ulXQhogRg7hdQg7hbAUhxQAUhwBXhFQBYhDBoASIfuFWQBnASA7BbQA8BdgUBwQgUBxhYBDQhFA2hQAAQgVAAgVgDg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AVqIKI/vlXQhngRg8hdQg7hbAUhxQAUhwBXhFQBYhCBoARIfuFXQBoARA7BbQA7BdgUBwQgUBxhYBDQhFA2hQAAQgUAAgVgDg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AV7INI/ulXQhogRg7hdQg7hbAUhwQAUhxBXhEQBYhDBnARIfvFXQBnARA7BbQA8BdgUBxQgUBwhYBDQhFA3hQAAQgVAAgVgEg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AWNIQI/vlWQhngSg8hdQg7hbAUhwQAUhxBXhEQBYhDBoARIfuFXQBoAQA7BcQA7BdgUBxQgUBwhYBDQhFA3hQAAQgUAAgVgEg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AWeITI/ulWQhogSg8hdQg6haAUhxQAUhxBXhEQBYhDBnARIfvFXQBnAQA7BcQA8BdgUBxQgUBxhYBCQhGA3hPAAQgVAAgVgEg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AWwIWI/vlWQhngSg8hdQg7haAUhxQAUhxBXhEQBYhDBoARIfuFXQBoAQA6BcQA8BdgUBxQgUBxhYBDQhFA2hQAAQgUAAgVgEg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AXBIZI/ulWQhogSg8hdQg6haAThxQAUhxBYhEQBYhDBnASIfvFWQBnARA7BbQA8BdgUBxQgUBxhYBDQhGA2hQAAQgUAAgVgEg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AXSIdI/ulXQhogRg7hdQg7hbAUhxQAUhxBXhEQBYhDBoASIfuFWQBoARA6BbQA8BdgUBxQgUBxhYBDQhFA2hQAAQgVAAgVgDg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AXkIgI/vlXQhngRg8hdQg7hbAUhxQAUhxBXhEQBYhDBoASIfuFWQBoARA7BbQA7BdgTBxQgUBxhYBDQhGA2hQAAQgUAAgVgDg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AX1IjI/ulXQhogRg7hdQg7hcAUhwQAUhwBXhFQBYhDBnASIfvFVQBnASA7BbQA8BegUBwQgUBxhYBDQhFA2hQAAQgVAAgVgDg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AYHImI/vlXQhngRg8hdQg7hcAUhwQAUhwBXhFQBYhCBoARIfuFWQBoARA7BcQA7BdgUBwQgUBxhYBDQhFA2hQAAQgUAAgVgDg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AYYIpI/ulXQhogRg8hdQg6hcAUhvQAUhxBXhFQBYhCBnARIfvFWQBnARA7BcQA8BdgUBxQgUBwhYBDQhGA3hPAAQgVAAgVgEg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AYqIsI/vlWQhngSg8hdQg7hcAUhvQAUhxBXhEQBYhDBoARIfuFWQBoARA7BcQA7BdgUBxQgUBwhYBDQhFA3hQAAQgUAAgVgEg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AY7IvI/ulWQhogSg8hdQg6hbAUhwQAUhxBXhEQBYhDBnARIfvFWQBnARA7BcQA8BdgUBxQgUBxhYBCQhGA3hPAAQgVAAgVgEg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AZMIyI/ulWQhogSg7hdQg7hbAUhwQAUhxBXhEQBYhDBoARIfuFWQBoARA6BcQA8BdgUBxQgUBxhYBCQhFA3hQAAQgUAAgWgEg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AZeI1I/vlWQhngSg8hdQg7hbAUhwQAUhxBXhEQBZhDBnASIfuFVQBoASA7BbQA8BdgUBxQgUBxhYBDQhGA2hQAAQgUAAgVgEg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AZvI5I/ulXQhogRg7heQg7hbAUhwQAUhxBXhEQBYhDBoASIfuFVQBnASA7BbQA8BdgUBxQgUBxhYBDQhFA2hQAAQgVAAgVgDg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AaBI8I/vlWQhngSg8hdQg7hbAUhwQAUhxBXhEQBYhDBoARIfuFWQBoARA7BcQA7BdgUBxQgUBxhYBCQhFA3hQAAQgUAAgVgEg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Aa8JGI/vlWQhngSg8hdQg7hbAUhwQAUhxBXhEQBYhDBoASIfuFVQBoASA7BbQA7BdgUBxQgUBxhYBDQhFA2hQAAQgUAAgVgEg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AddJiI/vlWQhngSg8hdQg7hbAUhwQAUhxBXhEQBYhDBoARIfuFWQBoARA7BcQA8BdgUBxQgUBxhYBCQhGA3hQAAQgUAAgVgEg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAg5AKII/vlWQhngSg8hdQg6hcAUhvQAUhxBXhEQBXhDBnARIfwFWQBnARA7BcQA8BdgUBxQgUBwhYBDQhGA3hPAAQgVAAgVgEg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAkVAKuI/vlWQhogSg7hdQg7hcAUhwQAUhwBXhEQBYhDBnARIfwFWQBnARA7BcQA8BdgUBxQgUBwhYBDQhFA3hQAAQgVAAgVgEg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAm2ALKI/vlXQhngRg8hdQg7hcAUhxQAUhvBXhFQBYhCBoARIfvFWQBoARA6BcQA8BdgUBwQgUBxhYBDQhFA2hQAAQgUAAgWgDg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAnyALTI/vlWQhogSg7hdQg7hbAUhxQAUhwBXhEQBYhDBnASIfwFVQBnASA7BbQA8BdgUBxQgUBxhYBDQhGA2hPAAQgVAAgVgEg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(15).to({graphics:mask_1_graphics_15,x:13.0552,y:26.6074}).wait(1).to({graphics:mask_1_graphics_16,x:21.805,y:28.0858}).wait(1).to({graphics:mask_1_graphics_17,x:46.3214,y:32.2281}).wait(1).to({graphics:mask_1_graphics_18,x:81.7486,y:38.2139}).wait(1).to({graphics:mask_1_graphics_19,x:121.0699,y:44.8048}).wait(1).to({graphics:mask_1_graphics_20,x:141.8039,y:47.7978}).wait(1).to({graphics:mask_1_graphics_21,x:154.0621,y:49.8689}).wait(1).to({graphics:mask_1_graphics_22,x:158.4821,y:50.6793}).wait(1).to({graphics:mask_1_graphics_23,x:160.2266,y:50.9905}).wait(1).to({graphics:mask_1_graphics_24,x:161.9703,y:51.3013}).wait(1).to({graphics:mask_1_graphics_25,x:163.714,y:51.6121}).wait(1).to({graphics:mask_1_graphics_26,x:165.4576,y:51.923}).wait(1).to({graphics:mask_1_graphics_27,x:167.2013,y:52.2338}).wait(1).to({graphics:mask_1_graphics_28,x:168.945,y:52.5446}).wait(1).to({graphics:mask_1_graphics_29,x:170.6887,y:52.8554}).wait(1).to({graphics:mask_1_graphics_30,x:172.4324,y:53.1662}).wait(1).to({graphics:mask_1_graphics_31,x:174.176,y:53.4771}).wait(1).to({graphics:mask_1_graphics_32,x:175.9197,y:53.7879}).wait(1).to({graphics:mask_1_graphics_33,x:177.6634,y:54.0987}).wait(1).to({graphics:mask_1_graphics_34,x:179.4071,y:54.4095}).wait(1).to({graphics:mask_1_graphics_35,x:181.1508,y:54.7203}).wait(1).to({graphics:mask_1_graphics_36,x:182.8945,y:55.0312}).wait(1).to({graphics:mask_1_graphics_37,x:184.6381,y:55.342}).wait(1).to({graphics:mask_1_graphics_38,x:186.3818,y:55.6528}).wait(1).to({graphics:mask_1_graphics_39,x:188.1255,y:55.9636}).wait(1).to({graphics:mask_1_graphics_40,x:189.8692,y:56.2744}).wait(1).to({graphics:mask_1_graphics_41,x:191.6129,y:56.5853}).wait(1).to({graphics:mask_1_graphics_42,x:193.3565,y:56.8961}).wait(1).to({graphics:mask_1_graphics_43,x:195.1002,y:57.2069}).wait(1).to({graphics:mask_1_graphics_44,x:196.8321,y:57.5793}).wait(1).to({graphics:mask_1_graphics_45,x:202.7333,y:58.5964}).wait(1).to({graphics:mask_1_graphics_46,x:218.8535,y:61.374}).wait(1).to({graphics:mask_1_graphics_47,x:240.874,y:65.1684}).wait(1).to({graphics:mask_1_graphics_48,x:262.8945,y:68.9627}).wait(1).to({graphics:mask_1_graphics_49,x:279.0147,y:71.7404}).wait(1).to({graphics:mask_1_graphics_50,x:284.9821,y:72.7043}).wait(10));

	// Layer_9
	this.instance_1 = new lib.scribble4_4();
	this.instance_1.setTransform(227.65,63.85,1.03,0.9938,0,9.0529,8.6456,85.2,27.9);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({_off:false},0).wait(45));

	// Layer_4 copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("AH3JmQhjgwgthrQgshqAkhmQAnhmBhgmId3rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI93LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AF3JmQhjgwgthrQgshqAkhmQAnhmBhgmId3rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI93LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_14 = new cjs.Graphics().p("ABDJmQhjgwgthrQgshqAlhmQAmhmBggmId3rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI93LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AjxJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBhgmBkAwQBmAxAsBrQAtBqgnBmQglBmhhAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AlxJmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBjAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI91LgQgrAQgrAAQg4AAg5gcg");
	var mask_2_graphics_17 = new cjs.Graphics().p("Al+JmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAsBrQAtBqgmBmQglBmhiAmI91LgQgqAQgrAAQg5AAg5gcg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AmLJmQhkgwgshrQgthqAlhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AmYJmQhjgwgthrQgshqAkhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AmkJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBhgmBkAwQBmAxAsBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AmxJmQhkgwgshrQgthqAlhmQAmhmBhgmId2rfQBigmBjAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI91LgQgrAQgrAAQg4AAg5gcg");
	var mask_2_graphics_22 = new cjs.Graphics().p("Am+JmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAsBrQAtBqgmBmQglBmhiAmI91LgQgqAQgrAAQg5AAg5gcg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AnLJmQhkgwgshrQgthqAlhmQAmhmBigmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AnYJmQhjgwgthrQgshqAkhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AnkJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AnxJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBigmBjAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_27 = new cjs.Graphics().p("An+JmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAsBrQAtBqgmBmQglBmhiAmI91LgQgrAQgqAAQg5AAg5gcg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AoLJmQhkgwgshrQgthqAlhmQAmhmBigmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AoYJmQhjgwgthrQgshqAkhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AokJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AoxJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBigmBjAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_32 = new cjs.Graphics().p("Ao+JmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBjAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI91LgQgrAQgrAAQg4AAg5gcg");
	var mask_2_graphics_33 = new cjs.Graphics().p("ApLJmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_34 = new cjs.Graphics().p("ApYJmQhkgwgshrQgshqAkhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AplJmQhjgwgthrQgshqAkhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_36 = new cjs.Graphics().p("ApxJmQhkgwgthrQgshqAlhmQAmhmBhgmId2rfQBhgmBkAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_37 = new cjs.Graphics().p("Ap+JmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBjAwQBmAxAsBrQAtBqgnBmQgkBmhiAmI91LgQgrAQgrAAQg4AAg5gcg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AqLJmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAsBrQAtBqgmBmQglBmhiAmI91LgQgqAQgrAAQg5AAg5gcg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AqYJmQhkgwgshrQgthqAlhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AqlJmQhjgwgthrQgshqAkhmQAnhmBhgmId2rfQBhgmBkAwQBlAxAtBrQAsBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AqyJmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAsBrQAtBqgmBmQglBmhhAmI92LgQgqAQgrAAQg4AAg6gcg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AswJmQhkgwgshrQgthqAlhmQAmhmBigmId1rfQBigmBkAwQBlAxAsBrQAtBqgmBmQglBmhiAmI91LgQgrAQgqAAQg5AAg5gcg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AwVKrQhkgwgthqQgshrAlhmQAmhmBhglId2rgQBhgmBkAxQBmAxAsBqQAtBrgnBlQgkBnhiAlI92LgQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AwVMhQhkgwgthqQgshrAlhmQAmhmBhglId2rgQBhgmBkAxQBmAxAsBqQAtBqgnBmQgkBlhiAmI92LhQgqAQgrAAQg4AAg5gcg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AwVNSQhkgwgthrQgshqAlhmQAmhmBhglId2rgQBhgmBkAxQBmAxAsBqQAtBqgnBmQglBlhhAmI92LhQgqAQgrAAQg4AAg5gcg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:276.4633,y:-44.8777}).wait(1).to({graphics:mask_2_graphics_13,x:263.6703,y:-35.2232}).wait(1).to({graphics:mask_2_graphics_14,x:232.7825,y:-11.9152}).wait(1).to({graphics:mask_2_graphics_15,x:201.8946,y:11.3928}).wait(1).to({graphics:mask_2_graphics_16,x:189.1133,y:20.2223}).wait(1).to({graphics:mask_2_graphics_17,x:187.8336,y:21.2007}).wait(1).to({graphics:mask_2_graphics_18,x:186.5527,y:22.179}).wait(1).to({graphics:mask_2_graphics_19,x:185.2718,y:23.1574}).wait(1).to({graphics:mask_2_graphics_20,x:183.991,y:24.1357}).wait(1).to({graphics:mask_2_graphics_21,x:182.7101,y:25.1141}).wait(1).to({graphics:mask_2_graphics_22,x:181.4293,y:26.0924}).wait(1).to({graphics:mask_2_graphics_23,x:180.1484,y:27.0708}).wait(1).to({graphics:mask_2_graphics_24,x:178.8676,y:28.0491}).wait(1).to({graphics:mask_2_graphics_25,x:177.5867,y:29.0275}).wait(1).to({graphics:mask_2_graphics_26,x:176.3058,y:30.0058}).wait(1).to({graphics:mask_2_graphics_27,x:175.025,y:30.9842}).wait(1).to({graphics:mask_2_graphics_28,x:173.7441,y:31.9625}).wait(1).to({graphics:mask_2_graphics_29,x:172.4633,y:32.9409}).wait(1).to({graphics:mask_2_graphics_30,x:171.1824,y:33.9192}).wait(1).to({graphics:mask_2_graphics_31,x:169.9015,y:34.8975}).wait(1).to({graphics:mask_2_graphics_32,x:168.6207,y:35.8759}).wait(1).to({graphics:mask_2_graphics_33,x:167.3398,y:36.8542}).wait(1).to({graphics:mask_2_graphics_34,x:166.059,y:37.8326}).wait(1).to({graphics:mask_2_graphics_35,x:164.7781,y:38.8109}).wait(1).to({graphics:mask_2_graphics_36,x:163.4972,y:39.7893}).wait(1).to({graphics:mask_2_graphics_37,x:162.2164,y:40.7676}).wait(1).to({graphics:mask_2_graphics_38,x:160.9355,y:41.746}).wait(1).to({graphics:mask_2_graphics_39,x:159.6547,y:42.7243}).wait(1).to({graphics:mask_2_graphics_40,x:158.3738,y:43.7027}).wait(1).to({graphics:mask_2_graphics_41,x:157.0383,y:44.7223}).wait(1).to({graphics:mask_2_graphics_42,x:144.4231,y:54.4903}).wait(1).to({graphics:mask_2_graphics_43,x:106.432,y:71.1292}).wait(1).to({graphics:mask_2_graphics_44,x:45.5148,y:82.9202}).wait(1).to({graphics:mask_2_graphics_45,x:20.2821,y:87.8038}).wait(15));

	// Layer_8
	this.instance_2 = new lib.scribble4_3();
	this.instance_2.setTransform(226.25,32.6,1.03,0.9938,0,9.0529,8.6456,79.2,56.8);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).wait(48));

	// Layer_4 copy (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_7 = new cjs.Graphics().p("APNGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_8 = new cjs.Graphics().p("APNGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_9 = new cjs.Graphics().p("APNGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_10 = new cjs.Graphics().p("APNGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_11 = new cjs.Graphics().p("AQQGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_12 = new cjs.Graphics().p("AS+GxI/zlAQhngQg9hcQg8haAShxQAThxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_13 = new cjs.Graphics().p("AT9GxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AULGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AUZGxI/ylAQhogQg9hcQg7haAShxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgSBxhYBEQhFA4hSAAQgTAAgUgDg");
	var mask_3_graphics_16 = new cjs.Graphics().p("AUoGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AU2GxI/ylAQhogQg9hcQg8haAThxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_18 = new cjs.Graphics().p("AVFGxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_19 = new cjs.Graphics().p("AVTGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_20 = new cjs.Graphics().p("AVhGxI/ylAQhogQg9hcQg7haAShxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgSBxhYBEQhFA4hSAAQgTAAgUgDg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AVwGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgUAAgTgDg");
	var mask_3_graphics_22 = new cjs.Graphics().p("AV+GxI/ylAQhogQg9hcQg8haAThxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_23 = new cjs.Graphics().p("AWNGxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_24 = new cjs.Graphics().p("AWbGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_25 = new cjs.Graphics().p("AWpGxI/ylAQhogQg9hcQg7haAShxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgSBxhYBEQhFA4hSAAQgTAAgUgDg");
	var mask_3_graphics_26 = new cjs.Graphics().p("AW4GxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBnAQA8BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_27 = new cjs.Graphics().p("AXGGxI/ylAQhogQg9hcQg8haAThxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_28 = new cjs.Graphics().p("AXVGxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_29 = new cjs.Graphics().p("AXjGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_30 = new cjs.Graphics().p("AXxGxI/ylAQhogQg9hcQg7haAShxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgSBxhYBEQhFA4hSAAQgTAAgUgDg");
	var mask_3_graphics_31 = new cjs.Graphics().p("AYAGxI/zlAQhngQg9hcQg8haAThxQAShxBWhGQBYhDBnAQIfzFAQBoAQA7BbQA9BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AYOGxI/ylAQhogQg9hcQg8haAThxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AYdGxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AYrGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AY5GxI/ylAQhogQg9hcQg7haAShxQAThxBWhGQBXhDBoAQIfyFAQBoAQA8BbQA9BbgTBxQgSBxhYBEQhFA4hSAAQgTAAgUgDg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AZJGxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AaHGxI/ylAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfyFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AcyGxI/zlAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIfzFAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_39 = new cjs.Graphics().p("EAgbAGxI/0lAQhngQg8hcQg8haAShxQAThxBWhGQBWhDBoAQIf0FAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EAkEAGxI/0lAQhogQg8hcQg8haAShxQAThxBWhGQBXhDBoAQIf0FAQBnAQA8BbQA9BbgTBxQgSBxhXBEQhGA4hSAAQgTAAgTgDg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EAmuAGxI/zlAQhogQg9hcQg8haAThxQAThxBWhGQBXhDBoAQIfzFAQBoAQA8BbQA9BbgTBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EAnsAGxI/zlAQhogQg9hcQg8haAThxQAShxBXhGQBXhDBoAQIfzFAQBoAQA8BbQA8BbgSBxQgTBxhXBEQhGA4hRAAQgTAAgUgDg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(7).to({graphics:mask_3_graphics_7,x:-1.6444,y:-33.7428}).wait(1).to({graphics:mask_3_graphics_8,x:11.0729,y:-31.7076}).wait(1).to({graphics:mask_3_graphics_9,x:45.8172,y:-26.1472}).wait(1).to({graphics:mask_3_graphics_10,x:93.2788,y:-18.5516}).wait(1).to({graphics:mask_3_graphics_11,x:134.0158,y:-10.9559}).wait(1).to({graphics:mask_3_graphics_12,x:151.388,y:-5.3955}).wait(1).to({graphics:mask_3_graphics_13,x:157.6734,y:-3.8928}).wait(1).to({graphics:mask_3_graphics_14,x:159.1136,y:-3.4524}).wait(1).to({graphics:mask_3_graphics_15,x:160.5537,y:-3.0119}).wait(1).to({graphics:mask_3_graphics_16,x:161.9938,y:-2.5715}).wait(1).to({graphics:mask_3_graphics_17,x:163.4339,y:-2.131}).wait(1).to({graphics:mask_3_graphics_18,x:164.874,y:-1.6906}).wait(1).to({graphics:mask_3_graphics_19,x:166.3141,y:-1.2501}).wait(1).to({graphics:mask_3_graphics_20,x:167.7543,y:-0.8097}).wait(1).to({graphics:mask_3_graphics_21,x:169.1944,y:-0.3692}).wait(1).to({graphics:mask_3_graphics_22,x:170.6345,y:0.0712}).wait(1).to({graphics:mask_3_graphics_23,x:172.0746,y:0.5117}).wait(1).to({graphics:mask_3_graphics_24,x:173.5147,y:0.9522}).wait(1).to({graphics:mask_3_graphics_25,x:174.9548,y:1.3926}).wait(1).to({graphics:mask_3_graphics_26,x:176.3949,y:1.8331}).wait(1).to({graphics:mask_3_graphics_27,x:177.835,y:2.2735}).wait(1).to({graphics:mask_3_graphics_28,x:179.2751,y:2.714}).wait(1).to({graphics:mask_3_graphics_29,x:180.7152,y:3.1544}).wait(1).to({graphics:mask_3_graphics_30,x:182.1554,y:3.5949}).wait(1).to({graphics:mask_3_graphics_31,x:183.5955,y:4.0353}).wait(1).to({graphics:mask_3_graphics_32,x:185.0356,y:4.4758}).wait(1).to({graphics:mask_3_graphics_33,x:186.4757,y:4.9162}).wait(1).to({graphics:mask_3_graphics_34,x:187.9158,y:5.3567}).wait(1).to({graphics:mask_3_graphics_35,x:189.3559,y:5.7971}).wait(1).to({graphics:mask_3_graphics_36,x:190.8734,y:6.0072}).wait(1).to({graphics:mask_3_graphics_37,x:197.1172,y:7.9041}).wait(1).to({graphics:mask_3_graphics_38,x:214.1752,y:13.0866}).wait(1).to({graphics:mask_3_graphics_39,x:237.477,y:20.1661}).wait(1).to({graphics:mask_3_graphics_40,x:260.7787,y:27.2456}).wait(1).to({graphics:mask_3_graphics_41,x:277.8368,y:32.4281}).wait(1).to({graphics:mask_3_graphics_42,x:284.0234,y:34.3072}).wait(18));

	// Layer_5
	this.instance_3 = new lib.scribble4_2();
	this.instance_3.setTransform(220.55,0.9,1.03,0.9938,0,9.0529,8.6456,89.8,27.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(7).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("AHVFWQheg8gfhuQgfhvAxhgQAzhhBlgaIfFoBQBlgaBeA8QBeA8AfBvQAfBugyBhQgxBhhmAaI/EIAQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_1 = new cjs.Graphics().p("AHHFZQhdg7gfhvQgfhvAxhgQAyhgBmgbIfFoAQBlgaBdA7QBfA8AfBvQAfBvgzBgQgxBhhlAbI/FH/QgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_2 = new cjs.Graphics().p("AGVFmQhdg8gfhuQgfhvAxhgQAyhhBmgaIfEoAQBmgbBdA8QBfA8AfBvQAfBugzBhQgxBhhlAaI/FIAQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_3 = new cjs.Graphics().p("AEoGCQhdg8gfhuQgfhvAxhhQAyhgBmgaIfEoBQBmgaBdA8QBfA8AfBvQAfBugzBhQgxBhhlAaI/FIAQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_4 = new cjs.Graphics().p("ABnGzQhdg7gehvQgfhvAxhhQAxhgBmgaIfFoAQBlgbBdA8QBfA8AfBvQAfBugzBhQgxBhhlAaI/FIAQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_5 = new cjs.Graphics().p("AiCHqQhdg8gghuQgfhvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBeA8AgBuQAfBvgzBhQgxBhhlAZI/FIBQgfAIgeAAQhEAAhCgqg");
	var mask_4_graphics_6 = new cjs.Graphics().p("AkzHqQhdg8gfhuQgghvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_7 = new cjs.Graphics().p("AmgHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_8 = new cjs.Graphics().p("AndHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_9 = new cjs.Graphics().p("AnrHqQheg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBeA8AfBuQAgBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_10 = new cjs.Graphics().p("An6HqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBeA8QBeA8AfBuQAfBvgyBhQgxBhhmAZI/DIBQgfAIgeAAQhFAAhDgqg");
	var mask_4_graphics_11 = new cjs.Graphics().p("AoIHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_12 = new cjs.Graphics().p("AoWHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgyBhhlAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AokHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_14 = new cjs.Graphics().p("AoyHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_15 = new cjs.Graphics().p("ApAHqQhdg8gghuQgfhvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBeA8AgBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_16 = new cjs.Graphics().p("ApOHqQheg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBeA8QBeA8AfBuQAfBvgyBhQgxBhhmAZI/DIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_17 = new cjs.Graphics().p("ApdHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_18 = new cjs.Graphics().p("AprHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_19 = new cjs.Graphics().p("Ap5HqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AqHHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfDoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_21 = new cjs.Graphics().p("AqVHqQhdg8gghuQgfhvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBeA8AgBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AqjHqQheg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBeA8QBeA8AfBuQAgBvgzBhQgxBhhmAZI/DIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_23 = new cjs.Graphics().p("AqyHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBeA8QBeA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_24 = new cjs.Graphics().p("ArAHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_25 = new cjs.Graphics().p("ArOHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgyBhhlAZI/EIBQgeAIgfAAQhFAAhCgqg");
	var mask_4_graphics_26 = new cjs.Graphics().p("ArcHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfDoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_27 = new cjs.Graphics().p("ArqHqQhdg8gfhuQgghvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_28 = new cjs.Graphics().p("Ar4HqQheg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBmgaBdA8QBeA8AfBuQAgBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AsHHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AsUHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_31 = new cjs.Graphics().p("AtGHqQhdg8gfhuQgfhvAxhhQAyhhBmgZIfDoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_32 = new cjs.Graphics().p("AuzHqQhdg8gfhuQgfhvAxhhQAzhhBlgZIfEoBQBlgaBdA8QBfA8AfBuQAfBvgyBhQgxBhhmAZI/EIBQgeAIgeAAQhGAAhCgqg");
	var mask_4_graphics_33 = new cjs.Graphics().p("AxaHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AxaHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_35 = new cjs.Graphics().p("AxaHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AxaHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");
	var mask_4_graphics_37 = new cjs.Graphics().p("AxaHqQhdg8gfhuQgghvAyhhQAyhhBlgZIfEoBQBmgaBdA8QBfA8AfBuQAfBvgzBhQgxBhhlAZI/EIBQgfAIgeAAQhFAAhCgqg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:283.523,y:-67.9713}).wait(1).to({graphics:mask_4_graphics_1,x:282.1713,y:-67.6263}).wait(1).to({graphics:mask_4_graphics_2,x:277.1593,y:-66.3472}).wait(1).to({graphics:mask_4_graphics_3,x:266.2658,y:-63.5674}).wait(1).to({graphics:mask_4_graphics_4,x:246.9691,y:-58.643}).wait(1).to({graphics:mask_4_graphics_5,x:223.542,y:-52.1548}).wait(1).to({graphics:mask_4_graphics_6,x:205.8483,y:-43.1243}).wait(1).to({graphics:mask_4_graphics_7,x:194.9982,y:-37.5867}).wait(1).to({graphics:mask_4_graphics_8,x:188.848,y:-34.3184}).wait(1).to({graphics:mask_4_graphics_9,x:187.4333,y:-33.5697}).wait(1).to({graphics:mask_4_graphics_10,x:186.0174,y:-32.8211}).wait(1).to({graphics:mask_4_graphics_11,x:184.6016,y:-32.0724}).wait(1).to({graphics:mask_4_graphics_12,x:183.1857,y:-31.3238}).wait(1).to({graphics:mask_4_graphics_13,x:181.7698,y:-30.5751}).wait(1).to({graphics:mask_4_graphics_14,x:180.354,y:-29.8265}).wait(1).to({graphics:mask_4_graphics_15,x:178.9381,y:-29.0778}).wait(1).to({graphics:mask_4_graphics_16,x:177.5223,y:-28.3292}).wait(1).to({graphics:mask_4_graphics_17,x:176.1064,y:-27.5805}).wait(1).to({graphics:mask_4_graphics_18,x:174.6906,y:-26.8319}).wait(1).to({graphics:mask_4_graphics_19,x:173.2747,y:-26.0832}).wait(1).to({graphics:mask_4_graphics_20,x:171.8589,y:-25.3346}).wait(1).to({graphics:mask_4_graphics_21,x:170.443,y:-24.586}).wait(1).to({graphics:mask_4_graphics_22,x:169.0272,y:-23.8373}).wait(1).to({graphics:mask_4_graphics_23,x:167.6113,y:-23.0887}).wait(1).to({graphics:mask_4_graphics_24,x:166.1955,y:-22.34}).wait(1).to({graphics:mask_4_graphics_25,x:164.7796,y:-21.5914}).wait(1).to({graphics:mask_4_graphics_26,x:163.3638,y:-20.8427}).wait(1).to({graphics:mask_4_graphics_27,x:161.9479,y:-20.0941}).wait(1).to({graphics:mask_4_graphics_28,x:160.5321,y:-19.3454}).wait(1).to({graphics:mask_4_graphics_29,x:159.098,y:-18.7184}).wait(1).to({graphics:mask_4_graphics_30,x:157.7512,y:-18.0163}).wait(1).to({graphics:mask_4_graphics_31,x:152.7576,y:-15.4156}).wait(1).to({graphics:mask_4_graphics_32,x:141.904,y:-9.7629}).wait(1).to({graphics:mask_4_graphics_33,x:120.2039,y:0.2503}).wait(1).to({graphics:mask_4_graphics_34,x:73.5214,y:12.4067}).wait(1).to({graphics:mask_4_graphics_35,x:38.2634,y:21.5882}).wait(1).to({graphics:mask_4_graphics_36,x:16.6428,y:27.2183}).wait(1).to({graphics:mask_4_graphics_37,x:4.2964,y:29.7816}).wait(23));

	// Layer_2
	this.instance_4 = new lib.scribble4_1();
	this.instance_4.setTransform(222.95,-27.15,1.03,0.9938,0,9.0529,8.6456,88.4,53.4);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(60));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(382.05,39);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18.1,-93.2,728,249.8);


(lib.scribble3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,460,230,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble3_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(230.2,116.4,1,1,0,0,0,230.2,116.4);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3_1, new cjs.Rectangle(0,0,460.5,232.8), null);


(lib.scribble3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AXgaFMg7WgloQjCh7gVkFQgVkJCjj4QCkj3D9hXQD9haDCB6MA7WAlpQDBB7AWEIQAVEFijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_2 = new cjs.Graphics().p("AXgaLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB6MA7WAlpQDBB7AWEIQAVEFijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_3 = new cjs.Graphics().p("AXgaWMg7WglpQjCh6gVkFQgVkJCjj4QCkj3D9hXQD9hbDCB7MA7WAlpQDBB6AWEJQAVEFijD4QikD3j9BbQhpAkheAAQiGAAhyhIg");
	var mask_graphics_4 = new cjs.Graphics().p("AXgamMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB6MA7WAlpQDBB7AWEIQAVEFijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_5 = new cjs.Graphics().p("AXga9Mg7WglpQjCh7gVkEQgVkJCjj4QCkj4D9hWQD9hbDCB7MA7WAloQDBB7AWEJQAVEFijD3QikD4j9BbQhpAkheAAQiGAAhyhIg");
	var mask_graphics_6 = new cjs.Graphics().p("AXgbaMg7WgloQjCh7gVkFQgVkICjj4QCkj4D9hWQD9hbDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BbQhpAjheAAQiGAAhyhIg");
	var mask_graphics_7 = new cjs.Graphics().p("AXgcAMg7WgloQjCh7gVkFQgVkICjj4QCkj4D9hWQD9hbDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BbQhpAjheAAQiGAAhyhIg");
	var mask_graphics_8 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_9 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_10 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_11 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_12 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_13 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_14 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_15 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_16 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_17 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_18 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_19 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_20 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_21 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_22 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_23 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_24 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_25 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_26 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_27 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_28 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_29 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_30 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_31 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_32 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_33 = new cjs.Graphics().p("AXgcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_34 = new cjs.Graphics().p("AXrcLMg7WgloQjBh7gWkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDCB7AVEJQAVEEijD4QikD4j9BaQhoAkhfAAQiGAAhyhIg");
	var mask_graphics_35 = new cjs.Graphics().p("AX/cLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_36 = new cjs.Graphics().p("AYZcLMg7WgloQjCh7gVkFQgWkJCkj3QCjj4D+hXQD9haDBB7MA7WAloQDCB7AWEJQAVEEikD4QijD4j9BaQhpAkheAAQiHAAhxhIg");
	var mask_graphics_37 = new cjs.Graphics().p("AY5cLMg7WgloQjBh7gVkFQgWkJCkj3QCjj4D9hXQD+haDBB7MA7WAloQDCB7AVEJQAWEEikD4QikD4j9BaQhoAkhfAAQiGAAhyhIg");
	var mask_graphics_38 = new cjs.Graphics().p("AZicLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_39 = new cjs.Graphics().p("AaUcLMg7WgloQjCh7gVkFQgWkJCkj3QCjj4D+hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEikD4QijD4j9BaQhpAkheAAQiHAAhxhIg");
	var mask_graphics_40 = new cjs.Graphics().p("AbQcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEikD4QijD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_41 = new cjs.Graphics().p("AcYcLMg7WgloQjCh7gVkFQgWkJCkj3QCjj4D+hXQD9haDBB7MA7WAloQDCB7AWEJQAVEEikD4QijD4j9BaQhpAkhfAAQiGAAhxhIg");
	var mask_graphics_42 = new cjs.Graphics().p("AdscLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_43 = new cjs.Graphics().p("AfOcLMg7WgloQjCh7gVkFQgWkJCkj3QCjj4D+hXQD9haDBB7MA7WAloQDCB7AWEJQAVEEikD4QijD4j9BaQhpAkhfAAQiGAAhxhIg");
	var mask_graphics_44 = new cjs.Graphics().p("EAg7AcLMg7WgloQjBh7gWkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDCB7AVEJQAVEEijD4QikD4j9BaQhoAkhfAAQiGAAhyhIg");
	var mask_graphics_45 = new cjs.Graphics().p("EAiyAcLMg7WgloQjBh7gVkFQgWkJCkj3QCjj4D9hXQD9haDCB7MA7WAloQDCB7AVEJQAVEEijD4QikD4j9BaQhoAkhfAAQiGAAhyhIg");
	var mask_graphics_46 = new cjs.Graphics().p("EAkuAcLMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDCB7MA7WAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_47 = new cjs.Graphics().p("EAmpAcLMg7WgloQjCh7gVkFQgWkJCkj3QCjj4D+hXQD9haDBB7MA7WAloQDCB7AVEJQAWEEikD4QijD4j9BaQhpAkhfAAQiGAAhxhIg");
	var mask_graphics_48 = new cjs.Graphics().p("EAodAcXMg7WglpQjCh7gVkEQgVkJCjj4QCkj4D9hWQD9hbDCB7MA7WAlpQDBB6AWEJQAVEFijD4QikD3j9BbQhpAkheAAQiGAAhyhIg");
	var mask_graphics_49 = new cjs.Graphics().p("EAqIAdbMg7WglpQjCh7gVkEQgWkJCkj4QCkj4D9hWQD9hbDCB7MA7WAloQDBB7AWEJQAVEFikD3QijD4j9BbQhpAkheAAQiHAAhxhIg");
	var mask_graphics_50 = new cjs.Graphics().p("EAroAeXMg7WgloQjCh7gVkEQgWkJCkj4QCjj4D+hWQD9hbDBB7MA7WAloQDCB7AWEJQAVEFikD3QijD4j9BbQhpAkheAAQiHAAhxhJg");
	var mask_graphics_51 = new cjs.Graphics().p("EAs8AfNMg7WgloQjBh7gVkFQgWkICkj4QCjj4D9hXQD9haDCB7MA7WAloQDCB7AVEJQAWEEikD4QikD4j9BbQhoAjhfAAQiGAAhyhIg");
	var mask_graphics_52 = new cjs.Graphics().p("EAuHAf8Mg7WgloQjCh7gVkFQgWkICkj4QCjj4D+hXQD9haDBB7MA7WAloQDCB7AVEJQAWEEikD4QijD4j9BbQhpAjhfAAQiGAAhxhIg");
	var mask_graphics_53 = new cjs.Graphics().p("EAvHAglMg7WgloQjCh7gVkFQgVkICjj4QCkj4D9hXQD9haDBB7MA7XAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_54 = new cjs.Graphics().p("EAv/AhJMg7WglpQjCh7gVkEQgWkJCkj4QCkj4D9hWQD9hbDBB7MA7XAloQDBB7AWEJQAVEFikD4QijD3j9BbQhpAkheAAQiHAAhxhIg");
	var mask_graphics_55 = new cjs.Graphics().p("EAwvAhnMg7WgloQjCh7gVkFQgVkICjj4QCkj4D9hXQD9haDBB7MA7XAloQDBB7AWEJQAVEEijD4QikD4j9BbQhpAjheAAQiGAAhyhIg");
	var mask_graphics_56 = new cjs.Graphics().p("EAxYAiCMg7WglpQjBh7gVkEQgWkJCkj4QCjj4D9hWQD9hbDBB7MA7XAloQDCB7AVEJQAWEFikD3QikD4j9BbQhoAkhfAAQiGAAhyhIg");
	var mask_graphics_57 = new cjs.Graphics().p("EAx8AiYMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD9haDBB6MA7XAlpQDBB7AWEIQAVEFikD4QijD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_58 = new cjs.Graphics().p("EAyaAirMg7WgloQjCh7gVkFQgVkJCjj3QCkj4D9hXQD8haDCB7MA7XAloQDBB7AWEJQAVEEijD4QikD4j9BaQhpAkheAAQiGAAhyhIg");
	var mask_graphics_59 = new cjs.Graphics().p("EAyzAi7Mg7WgloQjBh7gVkFQgWkICkj4QCjj4D9hXQD8haDCB7MA7XAloQDCB7AVEJQAVEEijD4QikD4j9BbQhoAjhfAAQiGAAhyhIg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:-169.495,y:-200.9339}).wait(1).to({graphics:mask_graphics_2,x:-167.5997,y:-200.3299}).wait(1).to({graphics:mask_graphics_3,x:-164.2156,y:-199.2504}).wait(1).to({graphics:mask_graphics_4,x:-159.1167,y:-197.6238}).wait(1).to({graphics:mask_graphics_5,x:-152.0428,y:-195.3673}).wait(1).to({graphics:mask_graphics_6,x:-142.7055,y:-192.3888}).wait(1).to({graphics:mask_graphics_7,x:-130.8127,y:-188.595}).wait(1).to({graphics:mask_graphics_8,x:-116.123,y:-180.3008}).wait(1).to({graphics:mask_graphics_9,x:-98.55,y:-169.0894}).wait(1).to({graphics:mask_graphics_10,x:-78.3116,y:-156.1775}).wait(1).to({graphics:mask_graphics_11,x:-56.0626,y:-141.9828}).wait(1).to({graphics:mask_graphics_12,x:-32.8769,y:-127.1906}).wait(1).to({graphics:mask_graphics_13,x:-9.9979,y:-112.594}).wait(1).to({graphics:mask_graphics_14,x:11.5129,y:-98.8703}).wait(1).to({graphics:mask_graphics_15,x:30.9885,y:-86.445}).wait(1).to({graphics:mask_graphics_16,x:48.1532,y:-75.4941}).wait(1).to({graphics:mask_graphics_17,x:63.0026,y:-66.0203}).wait(1).to({graphics:mask_graphics_18,x:75.6779,y:-57.9336}).wait(1).to({graphics:mask_graphics_19,x:86.3798,y:-51.1058}).wait(1).to({graphics:mask_graphics_20,x:95.3199,y:-45.4022}).wait(1).to({graphics:mask_graphics_21,x:102.698,y:-40.695}).wait(1).to({graphics:mask_graphics_22,x:108.6935,y:-36.8699}).wait(1).to({graphics:mask_graphics_23,x:113.4631,y:-33.827}).wait(1).to({graphics:mask_graphics_24,x:117.1425,y:-31.4795}).wait(1).to({graphics:mask_graphics_25,x:119.8484,y:-29.7532}).wait(1).to({graphics:mask_graphics_26,x:121.6809,y:-28.5841}).wait(1).to({graphics:mask_graphics_27,x:122.7267,y:-27.9169}).wait(1).to({graphics:mask_graphics_28,x:122.455,y:-27.7017}).wait(1).to({graphics:mask_graphics_29,x:184.7651,y:11.0595}).wait(1).to({graphics:mask_graphics_30,x:247.255,y:49.5483}).wait(1).to({graphics:mask_graphics_31,x:247.6017,y:49.7684}).wait(1).to({graphics:mask_graphics_32,x:248.695,y:50.4625}).wait(1).to({graphics:mask_graphics_33,x:250.6247,y:51.6877}).wait(1).to({graphics:mask_graphics_34,x:252.3657,y:53.5109}).wait(1).to({graphics:mask_graphics_35,x:254.3348,y:56.0113}).wait(1).to({graphics:mask_graphics_36,x:256.9107,y:59.282}).wait(1).to({graphics:mask_graphics_37,x:260.1797,y:63.4329}).wait(1).to({graphics:mask_graphics_38,x:264.2429,y:68.5922}).wait(1).to({graphics:mask_graphics_39,x:269.2159,y:74.9067}).wait(1).to({graphics:mask_graphics_40,x:275.2255,y:82.5376}).wait(1).to({graphics:mask_graphics_41,x:282.3998,y:91.6474}).wait(1).to({graphics:mask_graphics_42,x:290.844,y:102.3695}).wait(1).to({graphics:mask_graphics_43,x:300.5969,y:114.7534}).wait(1).to({graphics:mask_graphics_44,x:311.5667,y:128.6826}).wait(1).to({graphics:mask_graphics_45,x:323.4713,y:143.7987}).wait(1).to({graphics:mask_graphics_46,x:335.8359,y:159.4988}).wait(1).to({graphics:mask_graphics_47,x:348.0916,y:175.0607}).wait(1).to({graphics:mask_graphics_48,x:359.7316,y:188.6791}).wait(1).to({graphics:mask_graphics_49,x:370.4203,y:195.4652}).wait(1).to({graphics:mask_graphics_50,x:380.0068,y:201.5515}).wait(1).to({graphics:mask_graphics_51,x:388.4749,y:206.9278}).wait(1).to({graphics:mask_graphics_52,x:395.8855,y:211.6326}).wait(1).to({graphics:mask_graphics_53,x:402.332,y:215.7254}).wait(1).to({graphics:mask_graphics_54,x:407.9165,y:219.2709}).wait(1).to({graphics:mask_graphics_55,x:412.7362,y:222.3309}).wait(1).to({graphics:mask_graphics_56,x:416.8792,y:224.9612}).wait(1).to({graphics:mask_graphics_57,x:420.4228,y:227.211}).wait(1).to({graphics:mask_graphics_58,x:423.4339,y:229.1227}).wait(1).to({graphics:mask_graphics_59,x:425.9692,y:230.7322}).wait(1));

	// Layer_2
	this.instance = new lib.scribble3_1();
	this.instance.setTransform(199.15,35.4,0.9343,0.9489,0,12.4738,10.2229,230.4,116.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(363.9999,45.0001,2.4267,0.36);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.6,-110.4,764.6,292);


(lib.scribble2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,438,292,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble2_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(219.3,195.9,1,1,0,0,0,219.3,195.9);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2_1, new cjs.Rectangle(0,68.3,380.1,323.5), null);


(lib.scribble2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AkifpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+mAoNQhqBFh+AAQh3AAiIg7g");
	var mask_graphics_2 = new cjs.Graphics().p("AkufpQkYh3jCktQjBktAFk0QAKkxDMiDMA+lgoOQDMiDEXB3QEdB6DBEtQDCEtgKExQgFE0jNCDMg+lAoNQhqBFh/AAQh2AAiIg7g");
	var mask_graphics_3 = new cjs.Graphics().p("AlEfpQkYh3jBktQjCktAFk0QAKkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jNCDMg+lAoNQhqBFh/AAQh2AAiIg7g");
	var mask_graphics_4 = new cjs.Graphics().p("AllfpQkYh3jBktQjCktAFk0QAKkxDMiDMA+lgoOQDMiDEXB3QEdB6DBEtQDCEtgKExQgFE0jNCDMg+lAoNQhqBFh/AAQh2AAiIg7g");
	var mask_graphics_5 = new cjs.Graphics().p("AmTfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+mAoNQhpBFh/AAQh3AAiIg7g");
	var mask_graphics_6 = new cjs.Graphics().p("AnPfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+lAoNQhpBFiAAAQh2AAiIg7g");
	var mask_graphics_7 = new cjs.Graphics().p("AocfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_8 = new cjs.Graphics().p("Ap8fpQkXh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDMiDEYB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiJg7g");
	var mask_graphics_9 = new cjs.Graphics().p("ArtfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEcB6DCEtQDCEtgKExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_10 = new cjs.Graphics().p("AtwfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEcB6DCEtQDCEtgKExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_11 = new cjs.Graphics().p("AwAfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_12 = new cjs.Graphics().p("AyXfpQkXh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDMiDEYB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiJg7g");
	var mask_graphics_13 = new cjs.Graphics().p("A0rfpQkXh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDMiDEYB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiJg7g");
	var mask_graphics_14 = new cjs.Graphics().p("A22fpQkYh3jBktQjCktAGk0QAJkxDNiDMA+kgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFh/AAQh2AAiJg7g");
	var mask_graphics_15 = new cjs.Graphics().p("A40fpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_16 = new cjs.Graphics().p("A6jfpQkYh3jBktQjCktAFk0QAKkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jNCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_17 = new cjs.Graphics().p("A8DfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEdB6DBEtQDCEtgKExQgFE0jNCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_18 = new cjs.Graphics().p("A9VfpQkYh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDNiDEXB3QEcB6DCEtQDCEtgKExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_19 = new cjs.Graphics().p("A+bfpQkXh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDMiDEYB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiJg7g");
	var mask_graphics_20 = new cjs.Graphics().p("A/VfpQkXh3jCktQjBktAFk0QAKkxDMiDMA+kgoOQDMiDEYB3QEcB6DCEtQDBEtgJExQgGE0jMCDMg+kAoNQhqBFiAAAQh2AAiJg7g");
	var mask_graphics_21 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_22 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_23 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_24 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_25 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_26 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_27 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_28 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_29 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_30 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_31 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_32 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_33 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_34 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_35 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_36 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_37 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_38 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_39 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_40 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_41 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_42 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_43 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_44 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_45 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_46 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_47 = new cjs.Graphics().p("A/kfpQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_48 = new cjs.Graphics().p("A/kf2QkYh4jBktQjCktAGkzQAJkyDMiDMA+lgoOQDMiDEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_49 = new cjs.Graphics().p("EgfkAhGQkYh4jBktQjCktAGkzQAJkyDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_50 = new cjs.Graphics().p("EgfkAiNQkYh3jBkuQjCktAGkzQAJkyDMiDMA+lgoNQDMiEEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_51 = new cjs.Graphics().p("EgfkAjMQkYh3jBktQjCkuAGkzQAJkxDMiEMA+lgoNQDMiEEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCEMg+lAoNQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_52 = new cjs.Graphics().p("EgfkAkDQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB5DBEuQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_53 = new cjs.Graphics().p("EgfkAkzQkYh3jBktQjCktAGk0QAJkxDMiDMA+lgoOQDMiDEYB3QEcB5DBEuQDCEtgKExQgFE0jMCDMg+lAoNQhqBFiAAAQh2AAiIg7g");
	var mask_graphics_54 = new cjs.Graphics().p("EgfkAldQkYh3jBkuQjCktAGkzQAJkyDMiDMA+lgoNQDMiEEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_55 = new cjs.Graphics().p("EgfkAmBQkYh4jBktQjCktAGkzQAJkyDMiDMA+lgoNQDMiEEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_56 = new cjs.Graphics().p("EgfkAmgQkYh4jBktQjCktAGkzQAJkyDMiDMA+lgoOQDMiDEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_57 = new cjs.Graphics().p("EgfkAm6QkYh3jBktQjCktAGk0QAJkxDMiEMA+lgoNQDMiDEYB3QEcB5DBEtQDCEtgKEyQgFEzjMCEMg+lAoNQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_58 = new cjs.Graphics().p("EgfkAnRQkYh4jBktQjCktAGkzQAJkyDMiDMA+lgoOQDMiDEYB3QEcB6DBEtQDCEtgKExQgFE0jMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");
	var mask_graphics_59 = new cjs.Graphics().p("EgfkAnjQkYh4jBktQjCktAGkzQAJkyDMiDMA+lgoOQDMiDEYB4QEcB5DBEtQDCEtgKEyQgFEzjMCDMg+lAoOQhqBEiAAAQh2AAiIg6g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:441.2621,y:-199.0475}).wait(1).to({graphics:mask_graphics_2,x:440.0351,y:-197.4581}).wait(1).to({graphics:mask_graphics_3,x:437.844,y:-194.62}).wait(1).to({graphics:mask_graphics_4,x:434.5428,y:-190.344}).wait(1).to({graphics:mask_graphics_5,x:429.9628,y:-184.4116}).wait(1).to({graphics:mask_graphics_6,x:423.9176,y:-176.5812}).wait(1).to({graphics:mask_graphics_7,x:416.2177,y:-166.6075}).wait(1).to({graphics:mask_graphics_8,x:406.707,y:-154.2884}).wait(1).to({graphics:mask_graphics_9,x:395.3295,y:-139.5512}).wait(1).to({graphics:mask_graphics_10,x:382.2263,y:-122.5788}).wait(1).to({graphics:mask_graphics_11,x:367.8214,y:-103.9202}).wait(1).to({graphics:mask_graphics_12,x:352.8101,y:-84.4762}).wait(1).to({graphics:mask_graphics_13,x:337.9973,y:-65.2892}).wait(1).to({graphics:mask_graphics_14,x:324.0703,y:-47.2497}).wait(1).to({graphics:mask_graphics_15,x:311.461,y:-30.917}).wait(1).to({graphics:mask_graphics_16,x:300.3479,y:-16.5223}).wait(1).to({graphics:mask_graphics_17,x:290.7338,y:-4.0692}).wait(1).to({graphics:mask_graphics_18,x:282.5272,y:6.5607}).wait(1).to({graphics:mask_graphics_19,x:275.5984,y:15.5356}).wait(1).to({graphics:mask_graphics_20,x:269.8102,y:23.0329}).wait(1).to({graphics:mask_graphics_21,x:261.8058,y:29.2204}).wait(1).to({graphics:mask_graphics_22,x:254.0424,y:34.2484}).wait(1).to({graphics:mask_graphics_23,x:247.8663,y:38.2483}).wait(1).to({graphics:mask_graphics_24,x:243.1019,y:41.3339}).wait(1).to({graphics:mask_graphics_25,x:239.5982,y:43.6031}).wait(1).to({graphics:mask_graphics_26,x:237.2252,y:45.1399}).wait(1).to({graphics:mask_graphics_27,x:235.8711,y:46.0169}).wait(1).to({graphics:mask_graphics_28,x:235.6634,y:46.1525}).wait(1).to({graphics:mask_graphics_29,x:235.6634,y:46.1525}).wait(1).to({graphics:mask_graphics_30,x:235.6634,y:46.1525}).wait(1).to({graphics:mask_graphics_31,x:235.2607,y:46.4109}).wait(1).to({graphics:mask_graphics_32,x:233.9907,y:47.2258}).wait(1).to({graphics:mask_graphics_33,x:231.7491,y:48.6641}).wait(1).to({graphics:mask_graphics_34,x:228.4132,y:50.8046}).wait(1).to({graphics:mask_graphics_35,x:223.8385,y:53.74}).wait(1).to({graphics:mask_graphics_36,x:217.8542,y:57.5798}).wait(1).to({graphics:mask_graphics_37,x:210.2595,y:62.4529}).wait(1).to({graphics:mask_graphics_38,x:200.8197,y:68.5099}).wait(1).to({graphics:mask_graphics_39,x:189.2663,y:75.9231}).wait(1).to({graphics:mask_graphics_40,x:175.3044,y:84.8818}).wait(1).to({graphics:mask_graphics_41,x:158.6368,y:95.5765}).wait(1).to({graphics:mask_graphics_42,x:139.0189,y:108.1643}).wait(1).to({graphics:mask_graphics_43,x:116.3607,y:122.7029}).wait(1).to({graphics:mask_graphics_44,x:90.8751,y:139.0557}).wait(1).to({graphics:mask_graphics_45,x:63.2179,y:156.8018}).wait(1).to({graphics:mask_graphics_46,x:34.4921,y:175.2337}).wait(1).to({graphics:mask_graphics_47,x:6.0191,y:193.5033}).wait(1).to({graphics:mask_graphics_48,x:-21.0233,y:209.6126}).wait(1).to({graphics:mask_graphics_49,x:-45.8559,y:217.5795}).wait(1).to({graphics:mask_graphics_50,x:-68.1274,y:224.7247}).wait(1).to({graphics:mask_graphics_51,x:-87.801,y:231.0365}).wait(1).to({graphics:mask_graphics_52,x:-105.0174,y:236.5599}).wait(1).to({graphics:mask_graphics_53,x:-119.9944,y:241.3649}).wait(1).to({graphics:mask_graphics_54,x:-132.9684,y:245.5273}).wait(1).to({graphics:mask_graphics_55,x:-144.1657,y:249.1197}).wait(1).to({graphics:mask_graphics_56,x:-153.791,y:252.2077}).wait(1).to({graphics:mask_graphics_57,x:-162.0236,y:254.8489}).wait(1).to({graphics:mask_graphics_58,x:-169.0189,y:257.0932}).wait(1).to({graphics:mask_graphics_59,x:-174.6866,y:258.9114}).wait(1));

	// Layer_2
	this.instance = new lib.scribble2_1();
	this.instance.setTransform(173.55,92.7,0.9039,0.9039,3.7108,0,0,219.3,195.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).wait(59));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-35.7,-35.2,361.7,314.09999999999997);


(lib.scribble1_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,136,75,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble1_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(68.2,37.5,1,1,0,0,0,68.2,37.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_2, new cjs.Rectangle(0,0,136.4,75.1), null);


(lib.scribble1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,175,78,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.scribble1_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(87.7,39.1,1,1,0,0,0,87.7,39.1);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_1, new cjs.Rectangle(0,0,175.4,78.1), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_58 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(29).call(this.frame_58).wait(1));

	// Layer_4 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_13 = new cjs.Graphics().p("AQGLvMgj0gJGQh1gegwiaQgxidAwi+QAwi+B2hwQB0hzB1AdMAj0AJGQB1AeAxCcQAwCagwC/QgwC+h1BzQhdBZhdAAQgYAAgYgGg");
	var mask_graphics_14 = new cjs.Graphics().p("APMLgMgiBgIpQhvgcgsiZQgtibAxi/QAwi+BxhxQBxh0BvAcMAiBAIpQBvAcAsCbQAsCZgwC+QgwC/hxB0QhaBbhaAAQgWAAgWgGg");
	var mask_graphics_15 = new cjs.Graphics().p("AObLUMggfgIQQhqgbgpiZQgpiaAwi+QAxi+BthzQBuh1BqAbMAgfAIQQBqAbApCbQApCYgxC+QgwC+htB1QhZBdhWAAQgVAAgUgFg");
	var mask_graphics_16 = new cjs.Graphics().p("ANzLJI/On7QhmgagmiYQgmiZAwi+QAwi+Brh0QBqh1BmAaIfOH7QBmAaAmCaQAmCXgwC+QgxC+hqB2QhXBehUAAQgTAAgSgFg");
	var mask_graphics_17 = new cjs.Graphics().p("ANRLBI+LnrQhigZgkiXQgkiZAxi+QAwi+Boh0QBoh2BjAZIeLHrQBiAZAkCZQAkCXgxC+QgwC+hoB2QhWBfhSAAQgRAAgSgEg");
	var mask_graphics_18 = new cjs.Graphics().p("ANCK6I9WndQhfgYgiiXQgiiYAxi+QAwi+Bmh1QBmh3BgAZIdWHdQBgAYAiCZQAhCWgwC+QgxC+hlB3QhVBghQAAQgRAAgRgEg");
	var mask_graphics_19 = new cjs.Graphics().p("AOUK7I8snTQhegYggiWQggiYAwi+QAwi+Blh1QBlh3BdAYIctHSQBeAYAgCZQAgCVgwC+QgxC+hkB4QhUBhhPAAQgQAAgQgEg");
	var mask_graphics_20 = new cjs.Graphics().p("APSLKI8NnLQhcgXgfiWQgfiYAwi+QAwi+Bkh1QBjh4BcAYIcNHKQBdAYAfCYQAfCVgxC/QgwC+hjB3QhTBihOAAQgQAAgPgEg");
	var mask_graphics_21 = new cjs.Graphics().p("AP+LVI73nFQhbgXgeiWQgeiYAwi+QAwi+Bjh1QBjh4BbAXIb3HFQBbAXAeCZQAeCVgwC+QgxC+hiB3QhTBihNAAQgPAAgPgDg");
	var mask_graphics_22 = new cjs.Graphics().p("AQcLcI7onBQhagXgeiWQgeiXAwi+QAxi+Bih2QBih4BaAXIboHBQBaAXAeCZQAeCUgxC/QgwC+hiB3QhSBjhNAAQgPAAgOgEg");
	var mask_graphics_23 = new cjs.Graphics().p("AQuLgI7fm+QhagXgdiWQgeiXAxi+QAwi+Bih2QBih4BZAXIbfG/QBaAXAdCYQAeCVgxC+QgwC+hiB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_24 = new cjs.Graphics().p("AQ3LjI7am+QhagXgdiVQgdiYAwi+QAwi+Bih1QBih4BZAXIbaG9QBaAXAdCYQAdCVgwC+QgwC+hiB4QhSBihMAAQgPAAgOgDg");
	var mask_graphics_25 = new cjs.Graphics().p("AQ6LjI7Ym9QhagWgdiWQgdiXAwi+QAxi+Bhh2QBih4BZAXIbZG9QBZAXAdCYQAdCUgwC/QgwC+hiB4QhSBihMAAQgOAAgPgEg");
	var mask_graphics_26 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_27 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_28 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_29 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_30 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_31 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_32 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_33 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_34 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_35 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_36 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_37 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_38 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_39 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_40 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_41 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_42 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_43 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_44 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_45 = new cjs.Graphics().p("ARKLoI7Zm9QhZgWgdiWQgdiXAwi+QAwi+Bih2QBih4BZAXIbYG9QBaAXAdCXQAdCVgxC/QgwC+hhB4QhSBihMAAQgPAAgOgEg");
	var mask_graphics_46 = new cjs.Graphics().p("AVPMtI+WntQhjgZgjiYQgkiYAwi+QAwi/BphzQBoh3BjAaIeVHtQBjAZAlCZQAjCXgwC+QgwC+hoB3QhWBfhTAAQgRAAgSgFg");
	var mask_graphics_47 = new cjs.Graphics().p("AY9NsMghCgIZQhsgbgqiZQgqicAwi9QAwi+BvhyQBvh1BsAbMAhCAIZQBrAcArCaQAqCZgwC+QgxC/huB0QhaBchXAAQgVAAgVgFg");
	var mask_graphics_48 = new cjs.Graphics().p("AcVOlMgjfgJBQhzgdgwibQgwidAwi9QAwi+B1hxQB0hzB0AeMAjeAI/QB0AeAwCcQAwCbgxC+QgwC+h0BzQhcBahcAAQgYAAgYgGg");
	var mask_graphics_49 = new cjs.Graphics().p("AfVPXMglqgJkQh7gfg0icQg1ieAwi9QAwi+B6hwQB5hxB7AfMAlqAJjQB7AfA1CeQA1CcgxC+QgwC+h5ByQhfBXhgAAQgbAAgbgHg");
	var mask_graphics_50 = new cjs.Graphics().p("EAh/AQEMgnlgKDQiBghg5idQg6ifAwi9QAxi/B+huQB9hxCCAhMAnlAKDQCBAgA6CgQA5CcgwC/QgxC+h9BxQhhBVhkAAQgdAAgegIg");
	var mask_graphics_51 = new cjs.Graphics().p("EAkTAQrMgpRgKfQiGgig9ieQg+igAxi9QAwi+CChuQCBhvCHAiMApQAKdQCHAiA+ChQA8CegwC+QgwC+iBBwQhkBThlAAQggAAgggIg");
	var mask_graphics_52 = new cjs.Graphics().p("EAmPARMMgqqgK2QiMgjhAifQhBihAxi9QAwi+CFhtQCFhvCLAkMAqrAK0QCLAjBBCiQBACegwC+QgwC+iFBvQhlBShoAAQghAAgjgIg");
	var mask_graphics_53 = new cjs.Graphics().p("EAn1ARmMgr0gLIQiPgkhDifQhEiiAxi9QAwi/CIhrQCHhvCPAlMAr1ALHQCPAkBECiQBCCfgwC+QgwC/iIBuQhlBQhqAAQgkAAgkgJg");
	var mask_graphics_54 = new cjs.Graphics().p("EApFAR7MgsvgLXQiSglhEigQhGiiAwi9QAwi+CLhrQCJhuCSAlMAsuALWQCSAlBGCiQBFCggxC+QgwC+iJBuQhnBQhrAAQglAAglgKg");
	var mask_graphics_55 = new cjs.Graphics().p("EAp9ASKMgtXgLhQiUgmhGigQhIijAxi9QAwi+CMhrQCKhtCTAlMAtZALhQCUAlBHCjQBGCggwC+QgwC+iLBuQhnBPhsAAQgmAAgngKg");
	var mask_graphics_56 = new cjs.Graphics().p("EAqfASTMgtwgLoQiVglhHihQhIijAwi9QAwi+CNhrQCLhtCVAmMAtxALnQCVAlBICjQBHChgwC+QgwC+iMBtQhoBPhsAAQgnAAgngKg");
	var mask_graphics_57 = new cjs.Graphics().p("EAqsASVMgt5gLpQiVgmhIihQhIijAwi9QAwi+CNhrQCMhtCVAmMAt5ALpQCWAmBICjQBICggxC+QgwC+iMBuQhoBOhsAAQgnAAgngKg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(13).to({graphics:mask_graphics_13,x:-57.2561,y:20.8374}).wait(1).to({graphics:mask_graphics_14,x:-7.2771,y:33.4792}).wait(1).to({graphics:mask_graphics_15,x:35.0293,y:44.1802}).wait(1).to({graphics:mask_graphics_16,x:70.3023,y:53.1022}).wait(1).to({graphics:mask_graphics_17,x:99.1814,y:60.407}).wait(1).to({graphics:mask_graphics_18,x:121.13,y:66.2562}).wait(1).to({graphics:mask_graphics_19,x:128.8677,y:70.2541}).wait(1).to({graphics:mask_graphics_20,x:134.683,y:71.7615}).wait(1).to({graphics:mask_graphics_21,x:138.8503,y:72.8417}).wait(1).to({graphics:mask_graphics_22,x:141.6439,y:73.5657}).wait(1).to({graphics:mask_graphics_23,x:143.3384,y:74.005}).wait(1).to({graphics:mask_graphics_24,x:144.2086,y:74.2305}).wait(1).to({graphics:mask_graphics_25,x:144.5292,y:74.3136}).wait(1).to({graphics:mask_graphics_26,x:146.0704,y:74.8161}).wait(1).to({graphics:mask_graphics_27,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_28,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_29,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_30,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_31,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_32,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_33,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_34,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_35,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_36,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_37,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_38,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_39,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_40,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_41,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_42,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_43,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_44,x:146.0709,y:74.8165}).wait(1).to({graphics:mask_graphics_45,x:146.0704,y:74.8161}).wait(1).to({graphics:mask_graphics_46,x:174.2752,y:81.7679}).wait(1).to({graphics:mask_graphics_47,x:200.0429,y:88.1182}).wait(1).to({graphics:mask_graphics_48,x:223.3672,y:93.8663}).wait(1).to({graphics:mask_graphics_49,x:244.2435,y:99.0115}).wait(1).to({graphics:mask_graphics_50,x:262.6685,y:103.553}).wait(1).to({graphics:mask_graphics_51,x:278.64,y:107.4902}).wait(1).to({graphics:mask_graphics_52,x:292.1565,y:110.8226}).wait(1).to({graphics:mask_graphics_53,x:303.2167,y:113.5497}).wait(1).to({graphics:mask_graphics_54,x:311.8199,y:115.6712}).wait(1).to({graphics:mask_graphics_55,x:317.9654,y:117.1867}).wait(1).to({graphics:mask_graphics_56,x:321.6528,y:118.0961}).wait(1).to({graphics:mask_graphics_57,x:322.9903,y:118.3152}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_3
	this.instance = new lib.scribble1_2();
	this.instance.setTransform(184.55,82.65,1.3541,1.3541,0,0,0,68.4,37.6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({_off:true},45).wait(1));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_1 = new cjs.Graphics().p("AiLKsQiMhygljBQgkjBBYifQBbidCjgfMAx6gJcQCigfCNByQCOBzAlDBQAkDBhbCeQhYCeijAfMgx7AJcQgiAHgiAAQh8AAhwhbg");
	var mask_1_graphics_2 = new cjs.Graphics().p("AiPKrQiMhygkjBQgljBBZifQBaidCjgeMAxzgJcQCjgeCMBxQCOB0AkDBQAlDBhbCdQhYCfijAeMgx0AJcQgiAGghAAQh8AAhxhbg");
	var mask_1_graphics_3 = new cjs.Graphics().p("AiZKpQiLhygljBQgkjBBXifQBaidCigeMAxfgJYQCigeCLByQCNB0AlDAQAkDBhZCeQhYCeihAeMgxhAJYQgiAGggAAQh8AAhwhbg");
	var mask_1_graphics_4 = new cjs.Graphics().p("AiqKlQiKhygljBQgkjBBWifQBZicCggeMAw+gJSQCggeCKByQCMB0AlDBQAkDBhYCdQhXCeifAeMgxAAJSQghAGggAAQh7AAhvhcg");
	var mask_1_graphics_5 = new cjs.Graphics().p("AjCKgQiIhzgljBQgkjABUifQBXicCegeMAwQgJIQCdgeCJByQCKB1AlDBQAkDAhWCdQhVCeieAeMgwRAJIQggAGgfAAQh6AAhuhcg");
	var mask_1_graphics_6 = new cjs.Graphics().p("AjhKZQiGhzgljBQgkjABSifQBVibCbgdMAvUgI+QCbgdCGBzQCJB1AkDBQAlDAhVCdQhTCdiaAdMgvWAI+QgfAGgeAAQh4AAhtheg");
	var mask_1_graphics_7 = new cjs.Graphics().p("AkHKRQiDhzgljBQgkjBBQidQBSicCXgcMAuMgIwQCXgcCDBzQCGB1AkDBQAlDBhSCbQhQCeiXAcMguNAIwQgdAFgcAAQh3AAhsheg");
	var mask_1_graphics_8 = new cjs.Graphics().p("AkzKIQiBh1gkjAQgljBBNicQBPicCSgbMAs3gIgQCSgbCBB0QCDB2AkDAQAlDBhPCaQhNCeiTAbMgs2AIgQgcAFgbAAQh0AAhqhfg");
	var mask_1_graphics_9 = new cjs.Graphics().p("AlnJ9Qh9h1gkjBQgljBBKibQBLibCNgbMArUgIMQCNgbB9B1QB/B2AlDBQAkDBhLCZQhJCdiOAbMgrTAIMQgaAFgaAAQhxAAhohgg");
	var mask_1_graphics_10 = new cjs.Graphics().p("AmhJwQh5h1gkjBQgljBBFibQBIiaCHgZMApjgH4QCIgZB5B1QB7B3AlDBQAkDBhHCZQhGCciHAZMgpjAH4QgYAEgYAAQhuAAhlhig");
	var mask_1_graphics_11 = new cjs.Graphics().p("AniJiQh1h2gkjBQgljBBBiaQBDiZCBgYMAnmgHgQCBgYB1B2QB2B4AkDBQAlDBhDCYQhACbiCAYMgnlAHgQgWAEgWAAQhqAAhihkg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AoqJTQhwh4gkjAQgljBA8iZQA+iYB6gXMAlbgHGQB6gXBwB3QBxB6AlDAQAkDBg+CXQg7Cah7AXMglbAHGQgTAEgUAAQhlAAhfhmg");
	var mask_1_graphics_13 = new cjs.Graphics().p("Ap5JCQhqh4gljBQgkjBA2iYQA4iXBzgWMAjDgGoQBygWBqB4QBsB7AlDAQAkDBg4CWQg2CZhzAWMgjDAGoQgRAEgRAAQhhAAhbhog");
	var mask_1_graphics_14 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_15 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_16 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_17 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_18 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_19 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_20 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_21 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_22 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_23 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_24 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_25 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_26 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_27 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_28 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_29 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_30 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_31 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_32 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_33 = new cjs.Graphics().p("ArIIwQhkh6gljBQgkjAAwiXQAyiWBqgUMAgegGKQBqgUBlB6QBlB7AlDBQAkDBgyCUQgwCYhqAUMggeAGKQgPADgPAAQhbAAhXhqg");
	var mask_1_graphics_34 = new cjs.Graphics().p("ArTIwQhkh6gljAQgkjBAwiXQAyiWBrgUMAgggGKQBqgUBkB5QBmB8AlDBQAkDAgyCVQgxCYhqAUMgggAGKQgPADgPAAQhaAAhYhqg");
	var mask_1_graphics_35 = new cjs.Graphics().p("ArzIwQhkh5gljBQgkjBAwiWQAziWBqgUMAgngGMQBqgUBlB6QBmB7AkDBQAlDBgzCVQgwCXhrAVMggmAGLQgPACgPAAQhbAAhYhqg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AsoIyQhlh6gljBQgkjAAxiXQAziWBrgVMAgxgGNQBrgUBlB6QBmB7AlDBQAkDAgzCVQgxCYhrAVMggxAGNQgPACgPAAQhbAAhYhpg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AtzIzQhmh5gkjBQgljBAyiXQAziWBsgUMAhAgGQQBsgUBlB5QBnB7AlDBQAkDBgzCVQgyCYhsAUMgg/AGQQgQADgPAAQhcAAhYhqg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AvTI1Qhmh5gljBQgkjAAyiYQA0iWBtgUMAhSgGUQBtgUBmB5QBoB7AkDBQAlDBg0CVQgzCYhsAUMghTAGUQgPADgQAAQhcAAhZhqg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AxJI4Qhnh5gkjBQgljBA0iXQA0iXBugUMAhqgGYQBugUBnB4QBoB7AlDBQAkDBg1CVQgzCZhuAUMghpAGYQgQADgQAAQhdAAhahpg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AzCJLQhoh5gljBQgkjBA0iXQA2iXBvgVMAiFgGcQBvgVBoB4QBpB7AlDBQAkDBg1CVQg1CZhvAVMgiFAGcQgQADgQAAQheAAhahog");
	var mask_1_graphics_41 = new cjs.Graphics().p("AzVJlQhph4gkjBQgljBA2iYQA2iWBxgWMAilgGiQBwgVBpB4QBrB7AlDBQAkDAg3CWQg1CZhxAVMgikAGiQgRAEgRAAQhfAAhbhpg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AzqKDQhqh4gkjBQgljAA3iYQA4iXBygWMAjIgGpQBzgVBqB4QBsB6AlDBQAkDBg4CWQg3CZhyAVMgjIAGpQgRADgRAAQhhAAhchog");
	var mask_1_graphics_43 = new cjs.Graphics().p("A0BKlQhsh4gkjBQgljAA4iaQA6iWB1gWMAjvgGwQB1gWBsB4QBtB6AlDBQAkDAg6CXQg4CZh0AWMgjwAGwQgSAEgRAAQhiAAhdhog");
	var mask_1_graphics_44 = new cjs.Graphics().p("A0bLLQhth4gljBQgkjBA5iZQA8iXB3gWMAkbgG4QB3gXBtB4QBvB6AlDAQAkDAg7CYQg5CZh3AXMgkcAG4QgSADgTAAQhjAAhehmg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A03LzQhvh3gljBQgkjBA7iZQA9iXB6gXMAlLgHBQB6gXBvB3QBwB6AlDBQAkC/g9CYQg7Cah5AXMglMAHBQgTADgTAAQhlAAhfhmg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A1WMRQhxh3gkjBQgljBA9iaQA/iXB8gXMAmAgHLQB9gXBwB3QBzB5AlDBQAkC/g/CZQg9Cah8AXMgmAAHLQgUADgUAAQhnAAhghlg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_1_graphics_1,x:367.6075,y:-5.5202}).wait(1).to({graphics:mask_1_graphics_2,x:366.4674,y:-5.162}).wait(1).to({graphics:mask_1_graphics_3,x:363.0476,y:-4.0875}).wait(1).to({graphics:mask_1_graphics_4,x:357.3481,y:-2.2965}).wait(1).to({graphics:mask_1_graphics_5,x:349.369,y:0.2109}).wait(1).to({graphics:mask_1_graphics_6,x:339.1105,y:3.4346}).wait(1).to({graphics:mask_1_graphics_7,x:326.5727,y:7.3747}).wait(1).to({graphics:mask_1_graphics_8,x:311.7561,y:12.0313}).wait(1).to({graphics:mask_1_graphics_9,x:294.6611,y:17.4042}).wait(1).to({graphics:mask_1_graphics_10,x:275.2882,y:23.4934}).wait(1).to({graphics:mask_1_graphics_11,x:253.6383,y:30.2991}).wait(1).to({graphics:mask_1_graphics_12,x:229.7124,y:37.8211}).wait(1).to({graphics:mask_1_graphics_13,x:203.5121,y:46.0595}).wait(1).to({graphics:mask_1_graphics_14,x:175.7177,y:54.5379}).wait(1).to({graphics:mask_1_graphics_15,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_16,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_17,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_18,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_19,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_20,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_21,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_22,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_23,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_24,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_25,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_26,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_27,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_28,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_29,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_30,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_31,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_32,x:175.7182,y:54.5379}).wait(1).to({graphics:mask_1_graphics_33,x:175.7177,y:54.5379}).wait(1).to({graphics:mask_1_graphics_34,x:174.9025,y:54.8681}).wait(1).to({graphics:mask_1_graphics_35,x:172.4556,y:55.8587}).wait(1).to({graphics:mask_1_graphics_36,x:168.3773,y:57.5096}).wait(1).to({graphics:mask_1_graphics_37,x:162.6679,y:59.8209}).wait(1).to({graphics:mask_1_graphics_38,x:155.3272,y:62.7925}).wait(1).to({graphics:mask_1_graphics_39,x:146.3555,y:66.4246}).wait(1).to({graphics:mask_1_graphics_40,x:134.0345,y:69.1262}).wait(1).to({graphics:mask_1_graphics_41,x:107.628,y:71.7511}).wait(1).to({graphics:mask_1_graphics_42,x:77.7006,y:74.7259}).wait(1).to({graphics:mask_1_graphics_43,x:44.2524,y:78.0506}).wait(1).to({graphics:mask_1_graphics_44,x:7.2833,y:81.7252}).wait(1).to({graphics:mask_1_graphics_45,x:-33.2067,y:85.7495}).wait(1).to({graphics:mask_1_graphics_46,x:-61.5421,y:88.6468}).wait(1).to({graphics:null,x:0,y:0}).wait(12));

	// Layer_2
	this.instance_1 = new lib.scribble1_1();
	this.instance_1.setTransform(210.95,59.8,1.3541,1.3541,0,0,0,87.9,39.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({_off:true},46).wait(12));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(58));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,133.4);


(lib.Page_indicator_dot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {selected:1,deselected:17};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(19));

	// Layer_2
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(0,0,0.75,0.75);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.25,scaleY:1.25,alpha:1},16,cjs.Ease.cubicInOut).to({scaleX:0.75,scaleY:0.75,alpha:0},18,cjs.Ease.cubicInOut).wait(1));

	// Layer_1
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(0,0,0.75,0.75);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1.25,scaleY:1.25,alpha:0},16,cjs.Ease.cubicInOut).to({scaleX:0.75,scaleY:0.75,alpha:1},18,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-4.5,-4.5,9.2,9.2);


(lib.Page_indicator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AAUA7Ig1g2QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBQAAgCACgCIA1g2QABgCAEAAQAAAAABAAQABAAAAABQABAAAAAAQABABAAAAIAEAEQAEAFgEAEIguAtIAvAuQAEAEgEAFIgFAEQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQgEAAgBgCg");
	this.shape.setTransform(-3.7375,4.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D4").s().p("AAUA7Ig1g2QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBQAAgCACgCIA1g2QABgCAEAAQAAAAABAAQABAAAAABQABAAAAAAQABABAAAAIAEAEQAEAFgEAEIguAtIAvAuQAEAEgEAFIgFAEQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQgEAAgBgCg");
	this.shape_1.setTransform(88.6375,4.825,1,1,0,0,180);

	this.dot_5 = new lib.Page_indicator_dot();
	this.dot_5.name = "dot_5";
	this.dot_5.setTransform(73.2,4.8);

	this.dot_4 = new lib.Page_indicator_dot();
	this.dot_4.name = "dot_4";
	this.dot_4.setTransform(57.9,4.8);

	this.dot_3 = new lib.Page_indicator_dot();
	this.dot_3.name = "dot_3";
	this.dot_3.setTransform(42.6,4.8);

	this.dot_2 = new lib.Page_indicator_dot();
	this.dot_2.name = "dot_2";
	this.dot_2.setTransform(27.3,4.8);

	this.dot_1 = new lib.Page_indicator_dot();
	this.dot_1.name = "dot_1";
	this.dot_1.setTransform(12,4.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.dot_1},{t:this.dot_2},{t:this.dot_3},{t:this.dot_4},{t:this.dot_5},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_indicator, new cjs.Rectangle(-7.3,-1.2,99.6,12.1), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.img5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub1 = new lib.img5Sub2();
	this.sub1.name = "sub1";
	this.sub1.setTransform(9.75,115.7,0.5741,0.5741,0,0,0,22.3,-21.9);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	// Layer_2
	this.sub2Shadow = new lib.angledShadow_1();
	this.sub2Shadow.name = "sub2Shadow";
	this.sub2Shadow.setTransform(51.6,101.75,0.2815,0.2815,0,0,0,147.1,48.9);

	this.timeline.addTween(cjs.Tween.get(this.sub2Shadow).wait(1));

	// sub1
	this.sub2 = new lib.img5Sub1();
	this.sub2.name = "sub2";
	this.sub2.setTransform(14.3,113.55,0.5673,0.5673,0,0,0,29.2,-5.8);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub2
	this.sub3 = new lib.img5Sub3();
	this.sub3.name = "sub3";
	this.sub3.setTransform(78.35,111.95,0.563,0.563,0,0,0,43.4,-15.2);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img5, new cjs.Rectangle(-3,40.3,152.9,88.00000000000001), null);


(lib.img4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img4Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(72.75,-41.25,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img4Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(123,-3.5,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img4Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(51.5,2.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img4, new cjs.Rectangle(37.9,-63.7,150.6,105.5), null);


(lib.img3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img3Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(72.5,-41,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img3Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(122,-4,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img3Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(52,2.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img3, new cjs.Rectangle(37.9,-63.4,148.9,104.3), null);


(lib.img2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img2Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(72.5,-41,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img2Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(122.5,-4,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img2Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(52,2.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img2, new cjs.Rectangle(37.9,-63.5,149.4,104.4), null);


(lib.img1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// sub3
	this.sub3 = new lib.img1Sub2();
	this.sub3.name = "sub3";
	this.sub3.setTransform(72.5,-41,1,1,0,0,0,28.5,28);

	this.timeline.addTween(cjs.Tween.get(this.sub3).wait(1));

	// sub2
	this.sub2 = new lib.img1Sub3();
	this.sub2.name = "sub2";
	this.sub2.setTransform(124,-3,1,1,0,0,0,86,60);

	this.timeline.addTween(cjs.Tween.get(this.sub2).wait(1));

	// sub1
	this.sub1 = new lib.img1Sub1();
	this.sub1.name = "sub1";
	this.sub1.setTransform(52,2.5,1,1,0,0,0,26,45.5);

	this.timeline.addTween(cjs.Tween.get(this.sub1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.img1, new cjs.Rectangle(38.7,-63.4,149.3,104.9), null);


(lib.gridSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,-1,250,2,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.gridSubSub();
	this.sub.name = "sub";
	this.sub.setTransform(128,0,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridSub, new cjs.Rectangle(-0.5,-0.5,213.3,1), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridSub();
	this.instance.setTransform(128,120,1,1,0,0,0,128,0);

	this.instance_1 = new lib.gridSub();
	this.instance_1.setTransform(128,105,1,1,0,0,0,128,0);

	this.instance_2 = new lib.gridSub();
	this.instance_2.setTransform(128,90,1,1,0,0,0,128,0);

	this.instance_3 = new lib.gridSub();
	this.instance_3.setTransform(128,75,1,1,0,0,0,128,0);

	this.instance_4 = new lib.gridSub();
	this.instance_4.setTransform(128,60,1,1,0,0,0,128,0);

	this.instance_5 = new lib.gridSub();
	this.instance_5.setTransform(128,45,1,1,0,0,0,128,0);

	this.instance_6 = new lib.gridSub();
	this.instance_6.setTransform(128,30,1,1,0,0,0,128,0);

	this.instance_7 = new lib.gridSub();
	this.instance_7.setTransform(128,15,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_8 = new lib.gridSub();
	this.instance_8.setTransform(128,-75,1,1,0,0,0,128,0);

	this.instance_9 = new lib.gridSub();
	this.instance_9.setTransform(128,-60,1,1,0,0,0,128,0);

	this.instance_10 = new lib.gridSub();
	this.instance_10.setTransform(128,-45,1,1,0,0,0,128,0);

	this.instance_11 = new lib.gridSub();
	this.instance_11.setTransform(128,-30,1,1,0,0,0,128,0);

	this.instance_12 = new lib.gridSub();
	this.instance_12.setTransform(128,-15,1,1,0,0,0,128,0);

	this.instance_13 = new lib.gridSub();
	this.instance_13.setTransform(128,0,1,1,0,0,0,128,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-75.5,213.3,196), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.gridpiece();
	this.instance.setTransform(76.5,118.9,1,1,90,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(125.9,125.5,1,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-0.5,-7.5,213.3,213.3), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		exportRoot.mainMC.logo.visible=false;
	}
	this.frame_65 = function() {
		exportRoot.animStart();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3978,scaleY:2.3978,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.doodle5_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,18,14,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(9,7,1,1,0,0,0,9,7);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_3, new cjs.Rectangle(0,0,18.1,14), null);


(lib.doodle5_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,17,16,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(8.3,7.6,1,1,0,0,0,8.3,7.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_2, new cjs.Rectangle(0,0,16.8,15.3), null);


(lib.doodle5_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,28,28,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle5_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(13.6,14,1,1,0,0,0,13.6,14);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle5_1, new cjs.Rectangle(0,0,27.1,28), null);


(lib.doodle5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("EAvHAA6IiegrQgIgCgDgMQgDgMAEgPQAEgPAJgJQAJgJAIACICeArQAIACACAMQADAMgEAPQgEAPgJAJQgHAIgGAAIgDgBg");
	var mask_graphics_21 = new cjs.Graphics().p("EAvNAA6IiegrQgIgCgDgMQgDgMAEgPQAFgPAIgJQAJgJAIACICeArQAIACADAMQADAMgFAPQgEAPgIAJQgHAIgHAAIgDgBg");
	var mask_graphics_22 = new cjs.Graphics().p("EAveAA6IiegrQgIgCgDgMQgCgMAEgPQAEgPAJgJQAIgJAIACICeArQAIACADAMQADAMgEAPQgEAPgJAJQgHAIgHAAIgDgBg");
	var mask_graphics_23 = new cjs.Graphics().p("EAv2AA6IiegrQgIgCgDgMQgDgMAFgPQAEgPAIgJQAJgJAIACICeArQAIACADAMQADAMgEAPQgFAPgIAJQgHAIgHAAIgDgBg");
	var mask_graphics_24 = new cjs.Graphics().p("EAwOAA6IiegrQgIgCgDgMQgDgMAEgPQAFgPAIgJQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAJQgGAIgHAAIgDgBg");
	var mask_graphics_25 = new cjs.Graphics().p("EAwfAA+IiegrQgIgDgDgMQgCgLAEgPQAEgQAIgJQAJgJAIACICeArQAIACADAMQADAMgEAPQgEAPgJAKQgHAHgHAAIgDAAg");
	var mask_graphics_26 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_27 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_28 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_29 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_30 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_31 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_32 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_33 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_34 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_35 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_36 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_37 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_38 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_39 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_40 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_41 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_42 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_43 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_44 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_45 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_46 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_47 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_48 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_49 = new cjs.Graphics().p("EAwmAA/IiegrQgIgDgDgMQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIACADAMQACAMgEAPQgEAPgJAKQgGAHgHAAIgDAAg");
	var mask_graphics_50 = new cjs.Graphics().p("EAwnAA/IiegrQgIgCgDgNQgDgLAEgPQAFgPAIgJQAJgKAIADICeAqQAIADADALQACAMgEAPQgEAQgJAJQgGAHgHAAIgDAAg");
	var mask_graphics_51 = new cjs.Graphics().p("EAwrABAIiegrQgIgCgDgNQgDgLAEgPQAEgPAJgKQAJgJAIACICeArQAIADACALQADAMgEAPQgEAQgJAJQgHAHgGAAIgDAAg");
	var mask_graphics_52 = new cjs.Graphics().p("EAwyABCIiegrQgIgDgCgMQgDgLAEgPQAEgQAJgJQAIgJAIACICeArQAIACADAMQADAMgEAPQgEAPgJAKQgHAHgGAAIgEAAg");
	var mask_graphics_53 = new cjs.Graphics().p("EAxAABFIiegrQgIgCgDgNQgCgLAEgPQAEgPAJgJQAIgKAIACICeArQAIADADALQADAMgEAPQgEAQgJAJQgHAHgHAAIgDAAg");
	var mask_graphics_54 = new cjs.Graphics().p("EAxUABJIiegqQgIgDgDgMQgCgMAEgOQAEgQAIgJQAJgJAIACICeAqQAIACADANQADAMgEAPQgEAPgJAKQgHAHgHAAIgDgBg");
	var mask_graphics_55 = new cjs.Graphics().p("EAxoABOIiegrQgJgCgCgMQgDgNAEgOQAEgPAJgJQAIgKAIADICeAqQAJACACAMQADAMgEAQQgEAPgJAJQgHAHgGAAIgDAAg");
	var mask_graphics_56 = new cjs.Graphics().p("EAx1ABRIiegrQgIgCgDgMQgCgNAEgOQAEgPAIgJQAJgJAIACICeAqQAIACADAMQADANgEAPQgFAPgIAJQgHAIgHAAIgDgBg");
	var mask_graphics_57 = new cjs.Graphics().p("EAx+ABTIiegrQgIgCgDgMQgDgNAEgOQAEgPAJgJQAJgJAIACICeAqQAIACADAMQACANgEAPQgEAPgJAJQgGAIgHAAIgDgBg");
	var mask_graphics_58 = new cjs.Graphics().p("EAyDABVIiegrQgIgCgDgNQgDgMAEgPQAEgOAJgJQAJgKAIADICeApQAIADADAMQACAMgEAPQgEAQgJAJQgGAHgHAAIgDAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:304.6474,y:2.2014}).wait(1).to({graphics:mask_graphics_21,x:305.2841,y:2.5126}).wait(1).to({graphics:mask_graphics_22,x:307.0231,y:3.3627}).wait(1).to({graphics:mask_graphics_23,x:309.3988,y:4.524}).wait(1).to({graphics:mask_graphics_24,x:311.7744,y:5.6854}).wait(1).to({graphics:mask_graphics_25,x:313.5135,y:6.1974}).wait(1).to({graphics:mask_graphics_26,x:314.1724,y:6.3053}).wait(1).to({graphics:mask_graphics_27,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_28,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_29,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_30,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_31,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_32,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_33,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_34,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_35,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_36,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_37,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_38,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_39,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_40,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_41,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_42,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_43,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_44,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_45,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_46,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_47,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_48,x:314.1725,y:6.3053}).wait(1).to({graphics:mask_graphics_49,x:314.1724,y:6.3053}).wait(1).to({graphics:mask_graphics_50,x:314.276,y:6.3295}).wait(1).to({graphics:mask_graphics_51,x:314.6487,y:6.4165}).wait(1).to({graphics:mask_graphics_52,x:315.4308,y:6.5992}).wait(1).to({graphics:mask_graphics_53,x:316.8209,y:6.9239}).wait(1).to({graphics:mask_graphics_54,x:318.8129,y:7.3891}).wait(1).to({graphics:mask_graphics_55,x:320.7398,y:7.8392}).wait(1).to({graphics:mask_graphics_56,x:322.1028,y:8.1575}).wait(1).to({graphics:mask_graphics_57,x:322.9697,y:8.36}).wait(1).to({graphics:mask_graphics_58,x:323.4724,y:8.5303}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance = new lib.doodle5_2();
	this.instance.setTransform(617.75,8,0.8181,0.8181,0,-31.7218,148.2782,8.2,7.7);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("EAxLAB+QgHgCgEgGQgEgGACgIQACgHAGgEQAGgEAIACQAHACAEAGQAEAGgCAIQgCAHgGAEQgEACgFAAIgFAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAxHACBQgJgDgFgIQgFgIACgKQACgJAIgFQAJgFAJACQAJACAGAIQAFAJgDAJQgCAKgIAFQgGADgGAAIgGAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAw7ACIQgRgDgIgOQgJgPAEgQQAEgQAOgIQAOgJAQAEQAQADAJAOQAJAPgEAQQgEAQgOAIQgKAGgLAAIgJgBg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAwlACWQgbgHgPgYQgPgYAHgbQAGgcAYgPQAYgOAcAGQAbAHAPAYQAPAYgHAbQgGAbgYAPQgRALgSAAQgJAAgIgCg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAwSAChQglgIgVghQgUghAJglQAJgmAhgTQAhgVAlAJQAmAJAUAgQAUAhgJAlQgIAmghAUQgXAOgZAAQgLAAgMgDg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAwHACoQgrgKgXgmQgYglAKgsQALgqAmgYQAmgXArAKQArAKAYAlQAXAmgKArQgKArgmAYQgbAQgdAAQgNAAgNgDg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAwCACrQgugKgZgoQgZgpALguQALgtApgZQAogZAuALQAuALAZAnQAZAogLAuQgLAugoAZQgcASgfAAQgOAAgOgEg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAwDACsQgugLgZgpQgagpALgvQAMgtApgaQApgZAuALQAvALAZApQAZAogLAuQgLAvgpAZQgcASggAAQgNAAgPgDg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAwEACrQgugKgZgpQgagpALguQAMgtAogaQApgZAuALQAvALAZApQAZAngLAuQgLAvgpAZQgcASgfAAQgOAAgOgEg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAwGACqQgugKgYgoQgZgoALgtQALgtAogYQAogZAtALQAtALAZAmQAZAogLAtQgLAugoAYQgbARgfAAQgNAAgOgDg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAwJACoQgrgKgXgmQgYgmAKgsQALgqAmgYQAmgXArAKQAsAKAXAlQAYAmgKArQgLAsgmAYQgaAQgeAAQgMAAgOgDg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAwQACkQgogJgWgjQgWgjAKgpQAJgnAkgVQAjgWAoAJQAoAKAVAiQAWAjgJAoQgKAogjAWQgYAPgbAAQgMAAgMgDg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAwZACeQgjgIgSgfQgTgeAIgjQAIgjAfgTQAfgRAiAIQAjAIATAdQATAfgIAiQgJAjgeATQgVANgYAAQgKAAgLgCg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAwmACWQgcgHgPgYQgPgYAHgcQAGgcAZgPQAYgPAcAGQAcAHAPAYQAPAZgHAbQgGAcgZAPQgRALgSAAQgJAAgIgCg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAwzACOQgVgFgMgSQgLgTAFgVQAFgUATgMQASgLAVAFQAVAFALASQALASgFAVQgFAVgSALQgNAIgOAAIgMgBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAw9ACHQgQgDgIgOQgIgNADgQQAEgPAOgIQANgJAQAEQAPADAIAOQAJANgEAQQgEAPgNAJQgKAGgKAAIgJgCg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAxEACDQgMgDgGgKQgGgKACgMQADgLAKgGQALgHALADQAMADAGAKQAGAKgDALQgCAMgKAGQgHAFgIAAIgHgBg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAxJACAQgJgCgFgIQgFgIACgJQACgJAIgFQAIgEAJACQAJACAFAIQAFAHgDAJQgCAJgIAFQgFAEgGAAIgFgBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAxLAB+QgHgCgEgGQgEgGACgIQACgHAGgEQAGgEAIACQAHACAEAGQAEAGgCAIQgCAHgGAEQgEACgFAAIgFAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:316.9514,y:12.6487}).wait(1).to({graphics:mask_1_graphics_23,x:317.2101,y:12.9219}).wait(1).to({graphics:mask_1_graphics_24,x:317.9924,y:13.7482}).wait(1).to({graphics:mask_1_graphics_25,x:319.3274,y:15.1581}).wait(1).to({graphics:mask_1_graphics_26,x:320.5087,y:16.4057}).wait(1).to({graphics:mask_1_graphics_27,x:321.1873,y:17.1224}).wait(1).to({graphics:mask_1_graphics_28,x:321.5047,y:17.4576}).wait(1).to({graphics:mask_1_graphics_29,x:321.8681,y:17.5008}).wait(1).to({graphics:mask_1_graphics_30,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_31,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_32,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_33,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_34,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_35,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_36,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_37,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_38,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_39,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_40,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_41,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_42,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_43,x:321.8681,y:17.5009}).wait(1).to({graphics:mask_1_graphics_44,x:321.8681,y:17.5008}).wait(1).to({graphics:mask_1_graphics_45,x:321.8327,y:17.4656}).wait(1).to({graphics:mask_1_graphics_46,x:321.7101,y:17.3433}).wait(1).to({graphics:mask_1_graphics_47,x:321.4657,y:17.0996}).wait(1).to({graphics:mask_1_graphics_48,x:321.0479,y:16.683}).wait(1).to({graphics:mask_1_graphics_49,x:320.3992,y:16.0363}).wait(1).to({graphics:mask_1_graphics_50,x:319.5423,y:15.1818}).wait(1).to({graphics:mask_1_graphics_51,x:318.6834,y:14.3255}).wait(1).to({graphics:mask_1_graphics_52,x:318.0086,y:13.6526}).wait(1).to({graphics:mask_1_graphics_53,x:317.5319,y:13.1773}).wait(1).to({graphics:mask_1_graphics_54,x:317.2076,y:12.854}).wait(1).to({graphics:mask_1_graphics_55,x:316.9514,y:12.6487}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_1 = new lib.doodle5_3();
	this.instance_1.setTransform(628.5,21.4,0.8181,0.8181,0,-31.7218,148.2782,9.1,7.1);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_16 = new cjs.Graphics().p("EAuaABhIj8hFQgNgDgEgUQgEgSAGgZQAHgYANgOQAOgPANADID8BFQANADAEATQAFAUgHAYQgHAYgNAPQgLALgLAAIgFAAg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EAudABiIj8hFQgNgDgEgUQgFgTAHgYQAHgYANgPQAOgOANADID8BFQANADAEATQAFATgHAZQgHAYgNAPQgMALgKAAIgFAAg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EAuoABlIj8hFQgNgDgEgUQgEgTAGgYQAHgYANgPQAOgOANADID8BFQANADAEATQAFATgHAZQgGAYgOAOQgLAMgLAAIgFAAg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EAvBABrIj8hEQgMgEgFgTQgEgTAGgYQAHgYAOgPQANgPANAEID8BEQANAEAEATQAFATgHAYQgGAYgOAPQgLAMgLAAIgFgBg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EAvrAB2Ij8hEQgNgEgFgTQgEgUAHgXQAGgYAOgPQAOgPANAEID7BDQANAEAFAUQAEATgGAYQgHAZgOAOQgLAMgKAAIgFgBg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EAwQACAIj8hEQgNgEgEgTQgFgUAHgXQAGgYAOgPQAOgPANAEID8BDQANAEAEAUQAEATgGAYQgHAZgOAOQgLAMgKAAIgFgBg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EAwmACGIj8hEQgNgEgEgTQgEgUAGgXQAHgYANgPQAOgPANAEID8BDQANAEAEAUQAFATgHAYQgGAZgOAOQgLAMgLAAIgFgBg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAwyACKIj8hFQgMgDgFgUQgEgTAGgZQAHgXAOgOQANgPANADID8BEQANADAEAUQAFAUgHAYQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAw0ACKIj8hEQgNgEgFgTQgEgUAHgYQAGgXAOgPQAOgPANAEID8BDQAMAEAFATQAEAUgGAYQgHAYgOAPQgLAMgKAAIgFgBg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAw5ACMIj8hFQgNgDgFgUQgEgUAHgYQAGgXAOgPQAOgOANADID7BEQANADAFAUQAEATgGAZQgHAYgOAPQgLALgKAAIgFAAg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAxDACPIj8hFQgNgDgFgUQgEgUAHgYQAGgXAOgOQAOgPANADID7BEQANADAFAUQAEATgGAZQgHAYgOAPQgLALgKAAIgFAAg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAxUACUIj8hEQgNgEgEgTQgFgUAHgYQAHgYANgOQAOgPANAEID8BDQANAEAEATQAFAUgHAYQgHAYgNAPQgMAMgKAAIgFgBg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAxvACcIj8hEQgNgEgFgTQgEgUAHgYQAGgYAOgOQAOgPANAEID7BDQANAEAFATQAEAUgGAYQgHAYgOAPQgLAMgKAAIgFgBg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAyOACmIj8hFQgNgDgEgUQgFgUAHgYQAHgYANgOQAOgOANADID8BEQANADAEAUQAEATgGAZQgHAYgOAPQgLALgKAAIgFAAg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAyoACuIj8hFQgMgDgFgUQgEgUAGgYQAHgYAOgOQANgOANADID8BEQANADAEAUQAFATgHAZQgGAYgOAPQgLALgLAAIgFAAg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAy7ACzIj8hEQgNgEgFgTQgEgUAHgYQAGgYAOgPQAOgOANAEID8BDQAMAEAFAUQAEATgGAYQgHAYgOAPQgLAMgKAAIgFgBg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAzHAC3Ij8hFQgNgDgEgUQgFgTAHgYQAGgZAOgOQAOgOANADID8BEQANADAEAUQAEAUgGAYQgHAYgOAPQgLAMgKAAIgFgBg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAzOAC6Ij8hFQgMgDgFgUQgEgUAGgYQAHgYAOgPQANgNANACID8BFQANADAEAUQAFATgHAYQgGAZgOAOQgLAMgLAAIgFAAg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_2_graphics_16,x:302.0975,y:9.7473}).wait(1).to({graphics:mask_2_graphics_17,x:302.3874,y:9.8252}).wait(1).to({graphics:mask_2_graphics_18,x:303.5015,y:10.1241}).wait(1).to({graphics:mask_2_graphics_19,x:306.0216,y:10.8004}).wait(1).to({graphics:mask_2_graphics_20,x:310.1521,y:11.9088}).wait(1).to({graphics:mask_2_graphics_21,x:313.8746,y:12.9078}).wait(1).to({graphics:mask_2_graphics_22,x:316.1044,y:13.5061}).wait(1).to({graphics:mask_2_graphics_23,x:317.3225,y:13.8473}).wait(1).to({graphics:mask_2_graphics_24,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_25,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_26,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_27,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_28,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_29,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_30,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_31,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_32,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_33,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_34,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_35,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_36,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_37,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_38,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_39,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_40,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_41,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_42,x:317.3227,y:13.8474}).wait(1).to({graphics:mask_2_graphics_43,x:317.3225,y:13.8473}).wait(1).to({graphics:mask_2_graphics_44,x:317.4613,y:13.8896}).wait(1).to({graphics:mask_2_graphics_45,x:317.9501,y:14.0383}).wait(1).to({graphics:mask_2_graphics_46,x:318.947,y:14.3416}).wait(1).to({graphics:mask_2_graphics_47,x:320.6873,y:14.871}).wait(1).to({graphics:mask_2_graphics_48,x:323.3496,y:15.6809}).wait(1).to({graphics:mask_2_graphics_49,x:326.4802,y:16.6333}).wait(1).to({graphics:mask_2_graphics_50,x:329.116,y:17.4351}).wait(1).to({graphics:mask_2_graphics_51,x:330.9591,y:17.9958}).wait(1).to({graphics:mask_2_graphics_52,x:332.1741,y:18.3654}).wait(1).to({graphics:mask_2_graphics_53,x:332.9225,y:18.6223}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_2 = new lib.doodle5_1();
	this.instance_2.setTransform(618.65,20.3,0.8181,0.8181,0,-31.7218,148.2782,13.6,14.1);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.9,637.8,250.9);


(lib.doodle4_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,64,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(31.7,1.5,1,1,0,0,0,31.7,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_4, new cjs.Rectangle(0,0,63.5,3), null);


(lib.doodle4_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,50,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(24.9,1.5,1,1,0,0,0,24.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_3, new cjs.Rectangle(0,0,50,3), null);


(lib.doodle4_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,38,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(18.9,1.5,1,1,0,0,0,18.9,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_2, new cjs.Rectangle(0,0,37.7,3), null);


(lib.doodle4_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,21,3,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle4_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(10.2,1.5,1,1,0,0,0,10.2,1.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle4_1, new cjs.Rectangle(0,0,20.5,3), null);


(lib.doodle4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_53 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(24).call(this.frame_53).wait(1));

	// Layer_24 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_10 = new cjs.Graphics().p("AFbEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AFcEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQAQAAAMAIQAMAHAAALQAAALgMAHQgMAIgQAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AFfEJQgQAAgMgIQgMgHAAgLQAAgLAMgHQAMgIAQAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_13 = new cjs.Graphics().p("AFlEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_14 = new cjs.Graphics().p("AFvEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AF+EJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFBAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AGNEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQAQAAAMAIQAMAHAAALQAAALgMAHQgMAIgQAAg");
	var mask_graphics_17 = new cjs.Graphics().p("AGXEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFBAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AGeEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQAQAAAMAIQAMAHAAALQAAALgMAHQgMAIgQAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AGiEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AGqEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFBAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_21 = new cjs.Graphics().p("AGzEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_22 = new cjs.Graphics().p("AG7EJQgQAAgMgIQgMgHAAgLQAAgLAMgHQAMgIAQAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AHDEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AHLEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AHUEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AHcEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AHkEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQAQAAAMAIQAMAHAAALQAAALgMAHQgMAIgQAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AHsEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AH0EJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFBAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AH9EJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AIFEJQgQAAgMgIQgMgHAAgLQAAgLAMgHQAMgIAQAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AINEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_33 = new cjs.Graphics().p("AIVEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_34 = new cjs.Graphics().p("AIeEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_35 = new cjs.Graphics().p("AImEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_36 = new cjs.Graphics().p("AIoEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQARAAALAIQAMAHAAALQAAALgMAHQgLAIgRAAg");
	var mask_graphics_37 = new cjs.Graphics().p("AIvEJQgQAAgMgIQgMgHAAgLQAAgLAMgHQAMgIAQAAIFAAAQAQAAAMAIQAMAHAAALQAAALgMAHQgMAIgQAAg");
	var mask_graphics_38 = new cjs.Graphics().p("AI7EJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFBAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");
	var mask_graphics_39 = new cjs.Graphics().p("AJMEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AJaEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AJjEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AJoEJQgQAAgMgIQgLgHAAgLQAAgLALgHQAMgIAQAAIFAAAQAQAAAMAIQAMAHAAALQAAALgMAHQgMAIgQAAg");
	var mask_graphics_43 = new cjs.Graphics().p("AJrEJQgRAAgLgIQgMgHAAgLQAAgLAMgHQALgIARAAIFAAAQAQAAAMAIQALAHAAALQAAALgLAHQgMAIgQAAg");
	var mask_graphics_44 = new cjs.Graphics().p("AJrEJQgQAAgLgIQgMgHAAgLQAAgLAMgHQALgIAQAAIFBAAQAQAAALAIQAMAHAAALQAAALgMAHQgLAIgQAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_graphics_10,x:70.6803,y:26.4571}).wait(1).to({graphics:mask_graphics_11,x:70.7588,y:26.4571}).wait(1).to({graphics:mask_graphics_12,x:71.0416,y:26.4571}).wait(1).to({graphics:mask_graphics_13,x:71.6351,y:26.4571}).wait(1).to({graphics:mask_graphics_14,x:72.6897,y:26.4571}).wait(1).to({graphics:mask_graphics_15,x:74.2011,y:26.4571}).wait(1).to({graphics:mask_graphics_16,x:75.6631,y:26.4571}).wait(1).to({graphics:mask_graphics_17,x:76.6972,y:26.4571}).wait(1).to({graphics:mask_graphics_18,x:77.3549,y:26.4571}).wait(1).to({graphics:mask_graphics_19,x:77.7803,y:26.4571}).wait(1).to({graphics:mask_graphics_20,x:78.6022,y:26.4571}).wait(1).to({graphics:mask_graphics_21,x:79.4241,y:26.4571}).wait(1).to({graphics:mask_graphics_22,x:80.246,y:26.4571}).wait(1).to({graphics:mask_graphics_23,x:81.0678,y:26.4571}).wait(1).to({graphics:mask_graphics_24,x:81.8897,y:26.4571}).wait(1).to({graphics:mask_graphics_25,x:82.7116,y:26.4571}).wait(1).to({graphics:mask_graphics_26,x:83.5335,y:26.4571}).wait(1).to({graphics:mask_graphics_27,x:84.3553,y:26.4571}).wait(1).to({graphics:mask_graphics_28,x:85.1772,y:26.4571}).wait(1).to({graphics:mask_graphics_29,x:85.9991,y:26.4571}).wait(1).to({graphics:mask_graphics_30,x:86.821,y:26.4571}).wait(1).to({graphics:mask_graphics_31,x:87.6428,y:26.4571}).wait(1).to({graphics:mask_graphics_32,x:88.4647,y:26.4571}).wait(1).to({graphics:mask_graphics_33,x:89.2866,y:26.4571}).wait(1).to({graphics:mask_graphics_34,x:90.1085,y:26.4571}).wait(1).to({graphics:mask_graphics_35,x:90.9303,y:26.4571}).wait(1).to({graphics:mask_graphics_36,x:91.1778,y:26.4571}).wait(1).to({graphics:mask_graphics_37,x:91.8526,y:26.4571}).wait(1).to({graphics:mask_graphics_38,x:93.1043,y:26.4571}).wait(1).to({graphics:mask_graphics_39,x:94.733,y:26.4571}).wait(1).to({graphics:mask_graphics_40,x:96.1194,y:26.4571}).wait(1).to({graphics:mask_graphics_41,x:97.0308,y:26.4571}).wait(1).to({graphics:mask_graphics_42,x:97.5628,y:26.4571}).wait(1).to({graphics:mask_graphics_43,x:97.8288,y:26.4571}).wait(1).to({graphics:mask_graphics_44,x:97.9053,y:26.4571}).wait(1).to({graphics:null,x:0,y:0}).wait(9));

	// Layer_20
	this.instance = new lib.doodle4_1();
	this.instance.setTransform(148.7,50.15,0.6093,0.6093,0,0,0,10.2,1.6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).to({_off:true},35).wait(9));

	// Layer_23 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_11 = new cjs.Graphics().p("AEnE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_12 = new cjs.Graphics().p("AEoE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_13 = new cjs.Graphics().p("AEsE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_14 = new cjs.Graphics().p("AE0E1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_1_graphics_15 = new cjs.Graphics().p("AFCE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AFXE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AFvE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AGEE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AGTE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_20 = new cjs.Graphics().p("AGcE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AGiE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AGoE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AGtE1QgQAAgMgIQgMgHAAgLQAAgKAMgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AGyE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AG4E1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AG9E1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AHCE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AHIE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AHNE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AHSE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AHYE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AHdE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AHiE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AHoE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AHtE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AHyE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AH2E1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("AH/E1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AIRE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AIpE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AJCE1QgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AJUE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AJgE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AJnE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AJrE1QgQAAgMgIQgMgHAAgLQAAgKAMgIQAMgHAQAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AJsE1QgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(11).to({graphics:mask_1_graphics_11,x:65.4803,y:30.8821}).wait(1).to({graphics:mask_1_graphics_12,x:65.5895,y:30.8821}).wait(1).to({graphics:mask_1_graphics_13,x:65.9744,y:30.8821}).wait(1).to({graphics:mask_1_graphics_14,x:66.7593,y:30.8821}).wait(1).to({graphics:mask_1_graphics_15,x:68.1296,y:30.8821}).wait(1).to({graphics:mask_1_graphics_16,x:70.2258,y:30.8821}).wait(1).to({graphics:mask_1_graphics_17,x:72.6908,y:30.8821}).wait(1).to({graphics:mask_1_graphics_18,x:74.7662,y:30.8821}).wait(1).to({graphics:mask_1_graphics_19,x:76.2175,y:30.8821}).wait(1).to({graphics:mask_1_graphics_20,x:77.1741,y:30.8821}).wait(1).to({graphics:mask_1_graphics_21,x:77.7803,y:30.8821}).wait(1).to({graphics:mask_1_graphics_22,x:78.3153,y:30.8821}).wait(1).to({graphics:mask_1_graphics_23,x:78.8503,y:30.8821}).wait(1).to({graphics:mask_1_graphics_24,x:79.3853,y:30.8821}).wait(1).to({graphics:mask_1_graphics_25,x:79.9203,y:30.8821}).wait(1).to({graphics:mask_1_graphics_26,x:80.4553,y:30.8821}).wait(1).to({graphics:mask_1_graphics_27,x:80.9903,y:30.8821}).wait(1).to({graphics:mask_1_graphics_28,x:81.5253,y:30.8821}).wait(1).to({graphics:mask_1_graphics_29,x:82.0603,y:30.8821}).wait(1).to({graphics:mask_1_graphics_30,x:82.5953,y:30.8821}).wait(1).to({graphics:mask_1_graphics_31,x:83.1303,y:30.8821}).wait(1).to({graphics:mask_1_graphics_32,x:83.6653,y:30.8821}).wait(1).to({graphics:mask_1_graphics_33,x:84.2003,y:30.8821}).wait(1).to({graphics:mask_1_graphics_34,x:84.7353,y:30.8821}).wait(1).to({graphics:mask_1_graphics_35,x:85.2703,y:30.8821}).wait(1).to({graphics:mask_1_graphics_36,x:85.8053,y:30.8821}).wait(1).to({graphics:mask_1_graphics_37,x:86.1647,y:30.8821}).wait(1).to({graphics:mask_1_graphics_38,x:87.1021,y:30.8821}).wait(1).to({graphics:mask_1_graphics_39,x:88.8311,y:30.8821}).wait(1).to({graphics:mask_1_graphics_40,x:91.286,y:30.8821}).wait(1).to({graphics:mask_1_graphics_41,x:93.7387,y:30.8821}).wait(1).to({graphics:mask_1_graphics_42,x:95.5734,y:30.8821}).wait(1).to({graphics:mask_1_graphics_43,x:96.7692,y:30.8821}).wait(1).to({graphics:mask_1_graphics_44,x:97.4833,y:30.8821}).wait(1).to({graphics:mask_1_graphics_45,x:97.8484,y:30.8821}).wait(1).to({graphics:mask_1_graphics_46,x:97.9553,y:30.8821}).wait(1).to({graphics:null,x:0,y:0}).wait(7));

	// Layer_21
	this.instance_1 = new lib.doodle4_2();
	this.instance_1.setTransform(143.5,59.3,0.6093,0.6093,0,0,0,18.9,1.6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(11).to({_off:false},0).to({_off:true},36).wait(7));

	// Layer_22 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("AECFiQgQAAgLgIQgMgHAAgLQAAgKAMgIQALgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AEEFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AEIFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AEQFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AEdFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AEzFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AFPFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AFrFiQgQAAgMgIQgMgHAAgLQAAgKAMgIQAMgHAQAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AGBFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AGRFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AGbFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AGiFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AGlFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AGoFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AGrFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AGuFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AGxFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AG0FiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AG3FiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AG6FiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AG9FiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_33 = new cjs.Graphics().p("AHAFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AHDFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AHGFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AHJFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AHMFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AHQFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_39 = new cjs.Graphics().p("AHaFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AHsFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AIHFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AIlFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AI/FiQgQAAgMgIQgMgHAAgLQAAgKAMgIQAMgHAQAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AJRFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_45 = new cjs.Graphics().p("AJdFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_46 = new cjs.Graphics().p("AJlFiQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_2_graphics_47 = new cjs.Graphics().p("AJoFiQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_2_graphics_48 = new cjs.Graphics().p("AJpFiQgQAAgLgIQgMgHAAgLQAAgKAMgIQALgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:61.8053,y:35.3821}).wait(1).to({graphics:mask_2_graphics_13,x:61.9213,y:35.3821}).wait(1).to({graphics:mask_2_graphics_14,x:62.3232,y:35.3821}).wait(1).to({graphics:mask_2_graphics_15,x:63.1244,y:35.3821}).wait(1).to({graphics:mask_2_graphics_16,x:64.4938,y:35.3821}).wait(1).to({graphics:mask_2_graphics_17,x:66.6199,y:35.3821}).wait(1).to({graphics:mask_2_graphics_18,x:69.4287,y:35.3821}).wait(1).to({graphics:mask_2_graphics_19,x:72.2438,y:35.3821}).wait(1).to({graphics:mask_2_graphics_20,x:74.4557,y:35.3821}).wait(1).to({graphics:mask_2_graphics_21,x:76.0179,y:35.3821}).wait(1).to({graphics:mask_2_graphics_22,x:77.081,y:35.3821}).wait(1).to({graphics:mask_2_graphics_23,x:77.7803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_24,x:78.0803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_25,x:78.3803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_26,x:78.6803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_27,x:78.9803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_28,x:79.2803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_29,x:79.5803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_30,x:79.8803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_31,x:80.1803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_32,x:80.4803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_33,x:80.7803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_34,x:81.0803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_35,x:81.3803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_36,x:81.6803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_37,x:81.9803,y:35.3821}).wait(1).to({graphics:mask_2_graphics_38,x:82.3765,y:35.3821}).wait(1).to({graphics:mask_2_graphics_39,x:83.3692,y:35.3821}).wait(1).to({graphics:mask_2_graphics_40,x:85.1748,y:35.3821}).wait(1).to({graphics:mask_2_graphics_41,x:87.8543,y:35.3821}).wait(1).to({graphics:mask_2_graphics_42,x:90.8779,y:35.3821}).wait(1).to({graphics:mask_2_graphics_43,x:93.4399,y:35.3821}).wait(1).to({graphics:mask_2_graphics_44,x:95.2706,y:35.3821}).wait(1).to({graphics:mask_2_graphics_45,x:96.4757,y:35.3821}).wait(1).to({graphics:mask_2_graphics_46,x:97.2098,y:35.3821}).wait(1).to({graphics:mask_2_graphics_47,x:97.5919,y:35.3821}).wait(1).to({graphics:mask_2_graphics_48,x:97.7053,y:35.3821}).wait(1).to({graphics:null,x:0,y:0}).wait(5));

	// Layer_18
	this.instance_2 = new lib.doodle4_3();
	this.instance_2.setTransform(139.7,67.95,0.6093,0.6093,0,0,0,24.9,1.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(12).to({_off:false},0).to({_off:true},37).wait(5));

	// Layer_16 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_13 = new cjs.Graphics().p("ADZGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_14 = new cjs.Graphics().p("ADaGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_3_graphics_15 = new cjs.Graphics().p("ADfGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_16 = new cjs.Graphics().p("ADnGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AD0GOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_18 = new cjs.Graphics().p("AEJGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_3_graphics_19 = new cjs.Graphics().p("AEnGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_20 = new cjs.Graphics().p("AFJGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AFnGOQgQAAgMgIQgMgHAAgLQAAgKAMgIQAMgHAQAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_22 = new cjs.Graphics().p("AF+GOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_3_graphics_23 = new cjs.Graphics().p("AGPGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_24 = new cjs.Graphics().p("AGaGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_25 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_26 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_27 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_28 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_29 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_30 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_31 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AGiGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AGnGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AGxGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_41 = new cjs.Graphics().p("AHEGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_42 = new cjs.Graphics().p("AHhGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_43 = new cjs.Graphics().p("AIEGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_44 = new cjs.Graphics().p("AIlGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_3_graphics_45 = new cjs.Graphics().p("AI/GOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQAQAAAMAHQAMAIAAAKQAAALgMAHQgMAIgQAAg");
	var mask_3_graphics_46 = new cjs.Graphics().p("AJRGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_47 = new cjs.Graphics().p("AJeGOQgRAAgLgIQgMgHAAgLQAAgKAMgIQALgHARAAIFAAAQAQAAAMAHQALAIAAAKQAAALgLAHQgMAIgQAAg");
	var mask_3_graphics_48 = new cjs.Graphics().p("AJlGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_49 = new cjs.Graphics().p("AJpGOQgQAAgMgIQgLgHAAgLQAAgKALgIQAMgHAQAAIFAAAQARAAALAHQAMAIAAAKQAAALgMAHQgLAIgRAAg");
	var mask_3_graphics_50 = new cjs.Graphics().p("AJqGOQgQAAgLgIQgMgHAAgLQAAgKAMgIQALgHAQAAIFBAAQAQAAALAHQAMAIAAAKQAAALgMAHQgLAIgQAAg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(13).to({graphics:mask_3_graphics_13,x:57.6803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_14,x:57.8018,y:39.7821}).wait(1).to({graphics:mask_3_graphics_15,x:58.2174,y:39.7821}).wait(1).to({graphics:mask_3_graphics_16,x:59.0306,y:39.7821}).wait(1).to({graphics:mask_3_graphics_17,x:60.3934,y:39.7821}).wait(1).to({graphics:mask_3_graphics_18,x:62.4984,y:39.7821}).wait(1).to({graphics:mask_3_graphics_19,x:65.4352,y:39.7821}).wait(1).to({graphics:mask_3_graphics_20,x:68.8086,y:39.7821}).wait(1).to({graphics:mask_3_graphics_21,x:71.84,y:39.7821}).wait(1).to({graphics:mask_3_graphics_22,x:74.1587,y:39.7821}).wait(1).to({graphics:mask_3_graphics_23,x:75.8241,y:39.7821}).wait(1).to({graphics:mask_3_graphics_24,x:76.9893,y:39.7821}).wait(1).to({graphics:mask_3_graphics_25,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_26,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_27,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_28,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_29,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_30,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_31,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_32,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_33,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_34,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_35,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_36,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_37,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_38,x:77.7803,y:39.7821}).wait(1).to({graphics:mask_3_graphics_39,x:78.2173,y:39.7821}).wait(1).to({graphics:mask_3_graphics_40,x:79.2738,y:39.7821}).wait(1).to({graphics:mask_3_graphics_41,x:81.1637,y:39.7821}).wait(1).to({graphics:mask_3_graphics_42,x:84.0217,y:39.7821}).wait(1).to({graphics:mask_3_graphics_43,x:87.5283,y:39.7821}).wait(1).to({graphics:mask_3_graphics_44,x:90.8557,y:39.7821}).wait(1).to({graphics:mask_3_graphics_45,x:93.4548,y:39.7821}).wait(1).to({graphics:mask_3_graphics_46,x:95.2946,y:39.7821}).wait(1).to({graphics:mask_3_graphics_47,x:96.5226,y:39.7821}).wait(1).to({graphics:mask_3_graphics_48,x:97.2831,y:39.7821}).wait(1).to({graphics:mask_3_graphics_49,x:97.6848,y:39.7821}).wait(1).to({graphics:mask_3_graphics_50,x:97.8053,y:39.7821}).wait(1).to({graphics:null,x:0,y:0}).wait(3));

	// Layer_19
	this.instance_3 = new lib.doodle4_4();
	this.instance_3.setTransform(135.65,77.25,0.6093,0.6093,0,0,0,31.8,1.6);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(13).to({_off:false},0).to({_off:true},38).wait(3));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(53));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.doodle3_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,14,12,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_4Sub();
	this.sub.name = "sub";
	this.sub.setTransform(7.1,5.5,1,1,0,0,0,7.1,5.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_4, new cjs.Rectangle(0,0,14.2,11.2), null);


(lib.doodle3_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,14,12,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(6.6,6,1,1,0,0,0,6.6,6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_3, new cjs.Rectangle(0,0,13.2,12.1), null);


(lib.doodle3_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,21,22,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(10.5,10.8,1,1,0,0,0,10.5,10.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_2, new cjs.Rectangle(0,0,20.9,21.6), null);


(lib.doodle3_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,24,24,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle3_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(11.8,12.1,1,1,0,0,0,11.8,12.1);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle3_1, new cjs.Rectangle(0,0,23.7,24.3), null);


(lib.doodle3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("AMMC4QhKgugVhVQgThQAphGIAEgIIFnDdIgEAHQguBEhRATQgaAGgYAAQg5AAg0ggg");
	var mask_graphics_10 = new cjs.Graphics().p("AL7CkQhCg6gGhXQgGhSA0g/IAFgHIE+EVIgGAGQg3A8hTAFIgQABQhOAAg7g0g");
	var mask_graphics_11 = new cjs.Graphics().p("AN+DXQhXgJg4hDQg3hEAIhVQAIhTA9g2IAHgGIEMFFIgHAFQg4ArhFAAIgWgBg");
	var mask_graphics_12 = new cjs.Graphics().p("ANqDQQhUgWgshMQgshLAXhUQAVhQBFgrIAIgFIDTFsIgHAEQgvAZgxAAQgcAAgdgIg");
	var mask_graphics_13 = new cjs.Graphics().p("ANaDFQhQgkgfhSQgfhRAkhPQAihMBMgfIAIgEICVGKIgIADQgiALghAAQgrAAgrgTg");
	var mask_graphics_14 = new cjs.Graphics().p("ANNC0QhJgwgRhWQgRhVAwhIQAuhFBQgTIAIgCIBTGdIgJABQgSADgRAAQg9AAg1gkg");
	var mask_graphics_15 = new cjs.Graphics().p("ANDCfQhAg8gDhXQgDhWA8hAQA5g9BRgFIAJgBIAOGlIgJAAQhRAAg9g5g");
	var mask_graphics_16 = new cjs.Graphics().p("AOlDWQhRgNgyhCQg1hGALhVQALhXBGg1QBCgzBRAIIAJABIg3GhIgJgBg");
	var mask_graphics_17 = new cjs.Graphics().p("ANzDRQhNgagohJQgphOAahSQAZhUBNgpQBJgnBPAVIAJACIh7GTIgIgDg");
	var mask_graphics_18 = new cjs.Graphics().p("ANDDKQhHgngbhPQgchSAnhOQAmhOBTgcQBPgbBKAiIAIAEIi7F5IgIgEg");
	var mask_graphics_19 = new cjs.Graphics().p("AMYDAQhBgygNhSQgOhVAzhHQAzhHBWgOQBSgOBEAuIAHAFIj2FVIgHgFg");
	var mask_graphics_20 = new cjs.Graphics().p("ALxC0Qg3g8AAhTQAAhWA+g+QA+g+BXAAQBTABA8A3IAGAGIkqEpIgHgGg");
	var mask_graphics_21 = new cjs.Graphics().p("ALRCmQgthEAOhSQAOhVBHgzQBIgzBWAPQBSANAxBBIAGAHIlYD1IgFgIg");
	var mask_graphics_22 = new cjs.Graphics().p("AK4CXQghhKAbhOQAchTBOgmQBPgnBSAcQBPAbAmBIIAFAIIl7C5IgEgIg");
	var mask_graphics_23 = new cjs.Graphics().p("AKmCHQgUhPAnhIQAphNBUgZQBUgaBNAqQBJAnAaBMIADAJImUB5IgDgIg");
	var mask_graphics_24 = new cjs.Graphics().p("AKdB2QgIhRAzhBQA1hFBXgLQBXgMBFA2QBCAyANBQIABAJImiA2IgBgJg");
	var mask_graphics_25 = new cjs.Graphics().p("AKbBmIABgJQAGhRA8g4QBAg7BYADQBXADA8BAQA4A8AABRIAAAJg");
	var mask_graphics_26 = new cjs.Graphics().p("AKfAzIACgJQAThOBFguQBJgwBWARQBVASAxBIQAtBEgNBRIgBAJg");
	var mask_graphics_27 = new cjs.Graphics().p("AKoACIADgIQAghLBMgiQBQgkBRAfQBSAgAkBPQAiBLgaBNIgDAJg");
	var mask_graphics_28 = new cjs.Graphics().p("AK1gtIAFgIQArhFBRgVQBUgWBMAsQBLAsAWBTQAWBQgnBIIgEAIg");
	var mask_graphics_29 = new cjs.Graphics().p("AK1gtIAFgIQArhFBRgVQBUgWBMAsQBLAsAXBTQAVBQgnBIIgEAIg");
	var mask_graphics_30 = new cjs.Graphics().p("AK1gtIAFgIQArhFBRgVQBUgWBMAsQBLAsAXBTQAVBQgnBIIgEAIg");
	var mask_graphics_31 = new cjs.Graphics().p("AK1gtIAFgIQArhFBRgVQBUgWBMAsQBLAsAWBTQAWBQgnBIIgEAIg");
	var mask_graphics_32 = new cjs.Graphics().p("AK0grIAFgIQArhFBQgWQBVgXBLAsQBMArAXBTQAWBQgmBJIgEAHg");
	var mask_graphics_33 = new cjs.Graphics().p("AKyglIAEgIQAqhGBPgXQBUgZBNApQBNAqAZBTQAXBPgkBJIgEAIg");
	var mask_graphics_34 = new cjs.Graphics().p("AKugZIAEgIQAmhIBPgbQBSgcBPAmQBPAnAcBSQAbBOghBKIgEAIg");
	var mask_graphics_35 = new cjs.Graphics().p("AKogFIAEgJQAhhKBNggQBQgiBRAhQBRAhAiBQQAgBMgcBNIgDAIg");
	var mask_graphics_36 = new cjs.Graphics().p("AKiAWIACgIQAahNBKgnQBMgpBUAZQBUAZApBNQAoBIgVBPIgCAIg");
	var mask_graphics_37 = new cjs.Graphics().p("AKcA/IABgJQAQhPBDgxQBHgzBWAOQBXAOAzBHQAwBCgKBRIgBAJg");
	var mask_graphics_38 = new cjs.Graphics().p("AKZBqQAChSA6g6QA9g/BXgBQBXgBA/A8QA8A5AEBSIAAAJImmAGIAAgJg");
	var mask_graphics_39 = new cjs.Graphics().p("AKgCCQgQhQArhGQAthLBVgVQBVgUBLAtQBHArAWBNIACAJImaBkIgCgIg");
	var mask_graphics_40 = new cjs.Graphics().p("AK/CeQgmhJAWhQQAXhTBMgrQBMgrBUAXQBQAVArBGIAEAIIluDQIgEgIg");
	var mask_graphics_41 = new cjs.Graphics().p("AL8C6Qg7g5gEhTQgFhWA7hBQA6hBBXgFQBTgEA/A0IAHAGIkbE5IgGgGg");
	var mask_graphics_42 = new cjs.Graphics().p("ANTDPQhKgjgfhNQghhRAihPQAihRBRghQBNgfBMAdIAIAEIikGDIgIgDg");
	var mask_graphics_43 = new cjs.Graphics().p("AOxDZQhRgKg1hAQg4hDAIhWQAIhXBDg4QA/g1BSAEIAJABIgmGjIgJgBg");
	var mask_graphics_44 = new cjs.Graphics().p("ANMC1QhIgygQhWQgQhVAyhIQAvhEBQgSIAIgCIBMGeIgIACQgQACgQAAQg/AAg2glg");
	var mask_graphics_45 = new cjs.Graphics().p("ANfDLQhRghgjhQQgjhQAhhQQAehOBKgiIAIgEICnGCIgIAEQglAOgmAAQgnAAgngPg");
	var mask_graphics_46 = new cjs.Graphics().p("ANzDVQhWgRgxhIQgwhJARhVQAQhRBCgwIAIgFIDqFeIgHAFQgzAfg5AAQgVAAgWgFg");
	var mask_graphics_47 = new cjs.Graphics().p("AOFDZQhXgEg7hBQg6hBAEhWQAEhTA6g5IAHgGIEbE4IgGAGQg6AxhMAAIgMgBg");
	var mask_graphics_48 = new cjs.Graphics().p("AL8ClQhCg5gGhXQgFhSAzg/IAGgHIE+EUIgGAHQg4A7hTAGIgQABQhNAAg8g1g");
	var mask_graphics_49 = new cjs.Graphics().p("AMFCxQhHgzgOhWQgNhRAuhEIAFgHIFWD2IgFAHQgzBAhSAOQgSADgSAAQhBAAg4gpg");
	var mask_graphics_50 = new cjs.Graphics().p("AMMC4QhKgugVhVQgThQAphGIAEgIIFnDdIgEAHQguBEhRATQgaAGgYAAQg5AAg0ggg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:107.0221,y:21.6211}).wait(1).to({graphics:mask_graphics_10,x:106.0299,y:21.5894}).wait(1).to({graphics:mask_graphics_11,x:104.8264,y:21.5854}).wait(1).to({graphics:mask_graphics_12,x:103.4438,y:21.6047}).wait(1).to({graphics:mask_graphics_13,x:101.9193,y:21.6167}).wait(1).to({graphics:mask_graphics_14,x:100.2939,y:21.614}).wait(1).to({graphics:mask_graphics_15,x:98.6112,y:21.6117}).wait(1).to({graphics:mask_graphics_16,x:99.6628,y:21.5322}).wait(1).to({graphics:mask_graphics_17,x:101.379,y:21.1914}).wait(1).to({graphics:mask_graphics_18,x:103.0091,y:20.5836}).wait(1).to({graphics:mask_graphics_19,x:104.5093,y:19.7251}).wait(1).to({graphics:mask_graphics_20,x:105.8395,y:18.639}).wait(1).to({graphics:mask_graphics_21,x:106.9641,y:17.3545}).wait(1).to({graphics:mask_graphics_22,x:107.853,y:15.9061}).wait(1).to({graphics:mask_graphics_23,x:108.4823,y:14.3326}).wait(1).to({graphics:mask_graphics_24,x:108.8354,y:12.6763}).wait(1).to({graphics:mask_graphics_25,x:108.9077,y:11.7334}).wait(1).to({graphics:mask_graphics_26,x:108.9104,y:13.4772}).wait(1).to({graphics:mask_graphics_27,x:108.9043,y:15.1613}).wait(1).to({graphics:mask_graphics_28,x:108.6991,y:16.6097}).wait(1).to({graphics:mask_graphics_29,x:108.6992,y:16.6098}).wait(1).to({graphics:mask_graphics_30,x:108.6992,y:16.6098}).wait(1).to({graphics:mask_graphics_31,x:108.6991,y:16.6097}).wait(1).to({graphics:mask_graphics_32,x:108.7002,y:16.5439}).wait(1).to({graphics:mask_graphics_33,x:108.703,y:16.3284}).wait(1).to({graphics:mask_graphics_34,x:108.7072,y:15.9271}).wait(1).to({graphics:mask_graphics_35,x:108.7109,y:15.2888}).wait(1).to({graphics:mask_graphics_36,x:108.7101,y:14.3428}).wait(1).to({graphics:mask_graphics_37,x:108.7,y:13.0005}).wait(1).to({graphics:mask_graphics_38,x:108.6963,y:11.4805}).wait(1).to({graphics:mask_graphics_39,x:108.4095,y:13.8387}).wait(1).to({graphics:mask_graphics_40,x:107.3456,y:16.5563}).wait(1).to({graphics:mask_graphics_41,x:105.2613,y:19.1619}).wait(1).to({graphics:mask_graphics_42,x:102.3376,y:21.0172}).wait(1).to({graphics:mask_graphics_43,x:99.1747,y:21.7879}).wait(1).to({graphics:mask_graphics_44,x:100.1477,y:21.8304}).wait(1).to({graphics:mask_graphics_45,x:102.4126,y:21.8234}).wait(1).to({graphics:mask_graphics_46,x:104.1013,y:21.7906}).wait(1).to({graphics:mask_graphics_47,x:105.3175,y:21.7595}).wait(1).to({graphics:mask_graphics_48,x:106.177,y:21.7506}).wait(1).to({graphics:mask_graphics_49,x:106.7773,y:21.7534}).wait(1).to({graphics:mask_graphics_50,x:107.0221,y:21.6211}).wait(1).to({graphics:null,x:0,y:0}).wait(9));

	// Layer_1
	this.instance = new lib.doodle3_1();
	this.instance.setTransform(199.75,14.65,0.9386,0.9386,0,0,0,11.9,12.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({_off:false},0).to({_off:true},42).wait(9));

	// Layer_14 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_20 = new cjs.Graphics().p("EAvNAA2IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_21 = new cjs.Graphics().p("EAvTAA2IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgJAJQgGAGgGAAIgDAAg");
	var mask_1_graphics_22 = new cjs.Graphics().p("EAvjAA2IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAIACICSAoQAHACADALQACALgDAOQgEAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAv5AA2IiSgoQgHgCgDgLQgDgLAEgOQAEgOAIgIQAIgJAIACICSAoQAHACADALQACALgDAOQgEAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAwPAA5IiSgoQgHgCgDgLQgDgLAEgOQAEgOAIgIQAIgJAIACICSAoQAHACADALQACALgDAOQgEAOgIAJQgHAHgGAAIgDgBg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAwfAA9IiSgoQgHgCgDgLQgCgLADgOQAEgOAIgIQAIgJAIACICSAoQAIACACALQADALgEAOQgEAOgIAJQgHAHgGAAIgDgBg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAwmAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgJAJQgGAHgGAAIgDgBg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAwqABAIiTgoQgHgCgDgLQgCgLAEgOQADgOAIgIQAIgJAIACICSAoQAIACACALQADALgEAOQgEAOgIAJQgGAGgHAAIgCAAg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAwxABCIiTgoQgHgCgDgMQgCgLAEgNQAEgOAIgJQAIgIAHACICSAoQAIABACALQADAMgEAOQgEAOgIAIQgGAHgGAAIgDAAg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAw+ABFIiTgoQgHgCgDgMQgCgLAEgNQADgOAIgJQAIgIAIACICSAnQAIACACALQADAMgEAOQgEAOgIAIQgGAHgGAAIgDAAg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAxQABJIiSgoQgIgCgCgLQgDgMAEgNQAEgOAIgIQAIgJAHACICTAnQAHACADAMQACALgEAOQgDAOgJAJQgGAGgGAAIgDAAg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAxiABNIiSgoQgIgCgCgLQgDgMAEgNQAEgOAIgIQAIgJAHACICTAnQAHACACAMQADALgEAOQgEAOgIAJQgGAHgGAAIgDgBg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EAxvABQIiTgoQgHgCgDgLQgCgMADgOQAEgNAIgIQAIgJAIACICSAnQAIACACAMQADALgEAOQgEAOgIAJQgGAGgHAAIgCAAg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EAx3ABSIiTgoQgHgCgDgLQgCgMAEgOQADgNAIgIQAIgJAIACICSAnQAIACACALQADAMgEAOQgEAOgIAJQgGAGgHAAIgCAAg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EAx8ABUIiSgoQgIgCgCgMQgDgLAEgOQAEgNAIgJQAIgIAHACICSAnQAIACACALQADALgEAOQgEAPgIAIQgGAHgGAAIgDAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_1_graphics_20,x:305.0749,y:2.9013}).wait(1).to({graphics:mask_1_graphics_21,x:305.666,y:3.1858}).wait(1).to({graphics:mask_1_graphics_22,x:307.2807,y:3.9629}).wait(1).to({graphics:mask_1_graphics_23,x:309.4865,y:5.0245}).wait(1).to({graphics:mask_1_graphics_24,x:311.6922,y:5.7623}).wait(1).to({graphics:mask_1_graphics_25,x:313.3069,y:6.1509}).wait(1).to({graphics:mask_1_graphics_26,x:313.8749,y:6.3449}).wait(1).to({graphics:mask_1_graphics_27,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_28,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_29,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_30,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_31,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_32,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_33,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_34,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_35,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_36,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_37,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_38,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_39,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_40,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_41,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_42,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_43,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_44,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_45,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_46,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_47,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_48,x:313.875,y:6.3449}).wait(1).to({graphics:mask_1_graphics_49,x:313.8749,y:6.3449}).wait(1).to({graphics:mask_1_graphics_50,x:313.9707,y:6.3672}).wait(1).to({graphics:mask_1_graphics_51,x:314.3156,y:6.4473}).wait(1).to({graphics:mask_1_graphics_52,x:315.0393,y:6.6153}).wait(1).to({graphics:mask_1_graphics_53,x:316.3255,y:6.9141}).wait(1).to({graphics:mask_1_graphics_54,x:318.1688,y:7.3422}).wait(1).to({graphics:mask_1_graphics_55,x:319.9517,y:7.7563}).wait(1).to({graphics:mask_1_graphics_56,x:321.2129,y:8.0492}).wait(1).to({graphics:mask_1_graphics_57,x:322.015,y:8.2355}).wait(1).to({graphics:mask_1_graphics_58,x:322.5499,y:8.3949}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance_1 = new lib.doodle3_3();
	this.instance_1.setTransform(618.05,8.35,1.0206,1.0206,0,-31.6363,148.3637,6.4,6);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_22 = new cjs.Graphics().p("EAxIAB5QgHgBgDgGQgEgGACgHQABgGAGgEQAGgEAHACQAGACAEAFQAEAGgCAHQgBAHgGADQgEADgFAAIgEgBg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAxEAB7QgJgCgFgHQgEgIACgJQACgJAIgEQAHgFAJACQAJACAEAIQAFAHgCAJQgCAJgIAFQgFADgGAAIgFgBg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAw3ACBQgPgDgIgNQgIgNAEgPQADgPAOgIQANgIAOADQAPAEAIANQAIANgDAPQgEAPgNAIQgJAFgKAAIgJgBg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAwiACLQgagGgNgWQgOgWAGgaQAGgZAWgOQAXgOAZAGQAZAGAOAXQAOAWgGAZQgGAagWANQgQAKgRAAQgIAAgHgCg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAwPACUQgjgIgTgfQgTgeAJgjQAIgjAfgRQAegTAjAIQAiAIATAeQATAegIAjQgJAjgeASQgVANgYAAQgKAAgKgCg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAwEACZQgogJgWgjQgWgkAKgoQAKgnAjgWQAjgVAoAJQAoAKAWAiQAVAjgJAoQgKAogjAWQgYAPgbAAQgMAAgMgDg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAv/ACbQgrgKgXglQgXglAKgrQAKgpAmgXQAlgXArAJQAqALAXAlQAXAkgKArQgKAqglAXQgaAQgdAAQgMAAgNgDg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAwGACkQgrgKgXgmQgXglAKgsQAKgpAmgYQAmgXArAKQArAKAXAlQAXAmgKAqQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAwIACjQgqgKgXglQgXglAKgqQALgpAlgXQAkgWArAJQAqALAWAjQAXAlgKAqQgKAqglAXQgaAQgcAAQgMAAgNgDg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAwLAChQgogKgWgjQgVgjAJgoQAKgpAjgUQAkgWAoAJQAoAKAWAiQAVAjgJAoQgKApgjAVQgZAQgbAAQgLAAgNgDg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAwRACdQglgIgUghQgUggAJgmQAJglAggTQAhgUAlAJQAlAJAUAfQAUAhgJAlQgJAlggAUQgXAOgZAAQgLAAgLgDg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAwaACYQgggIgSgcQgRgcAIghQAHggAdgRQAcgRAgAIQAhAHARAcQARAcgHAgQgIAggcASQgUAMgWAAQgJAAgKgCg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAwmACQQgagGgOgWQgOgXAGgaQAHgaAWgOQAXgNAaAGQAaAGANAWQAOAXgGAaQgGAagWANQgQAKgSAAQgHAAgIgCg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAwyACJQgUgFgKgQQgKgRAEgUQAFgTARgLQARgKATAEQAUAFAKARQALARgFATQgFAUgRAKQgLAHgOAAIgLgBg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAw7ACDQgOgDgIgNQgHgMADgOQADgPANgIQANgHAOADQAOAEAIAMQAIANgEAOQgDAOgNAIQgJAFgJAAIgJgBg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAxCAB/QgLgCgGgKQgFgJACgLQADgLAJgFQAKgGAKACQALADAGAJQAGAKgDAKQgDALgJAGQgGAEgIAAIgGgBg");
	var mask_2_graphics_54 = new cjs.Graphics().p("EAxGAB8QgIgCgEgHQgFgHACgIQACgJAHgEQAIgFAIACQAIACAFAIQAEAHgCAIQgCAIgHAFQgFADgGAAIgFgBg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EAxIAB5QgHgBgDgGQgEgGACgHQABgGAGgEQAGgEAHACQAGACAEAFQAEAGgCAHQgBAHgGADQgEADgFAAIgEgBg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_2_graphics_22,x:316.4597,y:12.1822}).wait(1).to({graphics:mask_2_graphics_23,x:316.6679,y:12.3897}).wait(1).to({graphics:mask_2_graphics_24,x:317.2976,y:13.0172}).wait(1).to({graphics:mask_2_graphics_25,x:318.3722,y:14.0878}).wait(1).to({graphics:mask_2_graphics_26,x:319.3231,y:15.0353}).wait(1).to({graphics:mask_2_graphics_27,x:319.8693,y:15.5796}).wait(1).to({graphics:mask_2_graphics_28,x:320.1247,y:15.8341}).wait(1).to({graphics:mask_2_graphics_29,x:321.0412,y:16.7253}).wait(1).to({graphics:mask_2_graphics_30,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_31,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_32,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_33,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_34,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_35,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_36,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_37,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_38,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_39,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_40,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_41,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_42,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_43,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_2_graphics_44,x:321.0412,y:16.7253}).wait(1).to({graphics:mask_2_graphics_45,x:321.009,y:16.6932}).wait(1).to({graphics:mask_2_graphics_46,x:320.897,y:16.5821}).wait(1).to({graphics:mask_2_graphics_47,x:320.6738,y:16.3607}).wait(1).to({graphics:mask_2_graphics_48,x:320.2923,y:15.9821}).wait(1).to({graphics:mask_2_graphics_49,x:319.7,y:15.3944}).wait(1).to({graphics:mask_2_graphics_50,x:318.9175,y:14.618}).wait(1).to({graphics:mask_2_graphics_51,x:318.1332,y:13.8399}).wait(1).to({graphics:mask_2_graphics_52,x:317.517,y:13.2285}).wait(1).to({graphics:mask_2_graphics_53,x:317.0818,y:12.7966}).wait(1).to({graphics:mask_2_graphics_54,x:316.7856,y:12.5028}).wait(1).to({graphics:mask_2_graphics_55,x:316.4597,y:12.1822}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_2 = new lib.doodle3_4();
	this.instance_2.setTransform(628,20.85,1.0206,1.0206,0,-31.6363,148.3637,7.1,5.7);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_16 = new cjs.Graphics().p("EAukABeIjphAQgMgDgEgSQgEgRAGgXQAGgWANgOQANgNALADIDqBAQAMADAEARQAEATgGAWQgGAWgNAOQgLALgJAAIgFgBg");
	var mask_3_graphics_17 = new cjs.Graphics().p("EAunABfIjqhAQgLgDgFgSQgEgRAHgXQAGgWAMgOQANgNAMADIDpBAQAMADAEARQAEASgGAXQgGAWgNAOQgKALgKAAIgEgBg");
	var mask_3_graphics_18 = new cjs.Graphics().p("EAuxABiIjphAQgMgDgEgSQgEgSAGgWQAGgWANgOQANgOALAEIDqA/QAMAEAEARQAEASgGAWQgGAXgNAOQgLAKgJAAIgFAAg");
	var mask_3_graphics_19 = new cjs.Graphics().p("EAvIABoIjphAQgMgDgEgSQgEgSAGgWQAGgWANgOQANgNAMADIDpBAQAMADAEARQAEASgGAXQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_20 = new cjs.Graphics().p("EAvvABzIjqhAQgLgEgFgSQgEgSAGgVQAHgXAMgNQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAXgNANQgKALgKAAIgEAAg");
	var mask_3_graphics_21 = new cjs.Graphics().p("EAwRAB8IjphAQgMgDgEgSQgEgTAGgVQAGgWANgOQANgOAMAEIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgLALgJAAIgFgBg");
	var mask_3_graphics_22 = new cjs.Graphics().p("EAwmACBIjpg/QgMgEgFgSQgEgSAHgWQAGgWAMgNQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAXgNANQgKALgKAAIgEgBg");
	var mask_3_graphics_23 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_24 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_25 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_26 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_27 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_28 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_29 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_30 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_31 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_32 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_33 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_34 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_35 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_36 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_37 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_38 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_39 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_40 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_41 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_42 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_43 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_44 = new cjs.Graphics().p("EAwzACFIjqhAQgMgDgEgTQgEgSAGgWQAHgWAMgNQANgOAMADIDpA/QAMAEAEASQAEASgGAWQgGAXgNANQgKALgKAAIgEAAg");
	var mask_3_graphics_45 = new cjs.Graphics().p("EAw3ACGIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgLALgJAAIgFgBg");
	var mask_3_graphics_46 = new cjs.Graphics().p("EAxAACJIjphAQgMgDgEgSQgEgTAGgWQAGgVANgOQANgOAMAEIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_47 = new cjs.Graphics().p("EAxQACOIjphAQgMgDgEgSQgEgTAGgWQAGgVANgOQANgOAMAEIDpA+QAMAEAEASQAEASgGAXQgGAWgNAOQgKAKgKAAIgFAAg");
	var mask_3_graphics_48 = new cjs.Graphics().p("EAxpACVIjpg/QgMgEgEgSQgEgSAGgWQAGgXANgMQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAXgNANQgKALgKAAIgFgBg");
	var mask_3_graphics_49 = new cjs.Graphics().p("EAyGACeIjpg/QgMgEgEgSQgEgSAGgWQAGgXANgMQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_3_graphics_50 = new cjs.Graphics().p("EAyfACmIjqhAQgMgDgEgSQgEgTAGgWQAHgWAMgOQANgNAMAEIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgKALgKAAIgEgBg");
	var mask_3_graphics_51 = new cjs.Graphics().p("EAywACrIjqhAQgLgDgFgSQgEgSAHgXQAGgWAMgOQANgMAMADIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgKALgKAAIgEgBg");
	var mask_3_graphics_52 = new cjs.Graphics().p("EAy7ACvIjphAQgMgDgEgTQgEgSAGgWQAGgXANgNQAMgNAMACIDqBAQALAEAEASQAFASgGAWQgHAXgMANQgLALgJAAIgFAAg");
	var mask_3_graphics_53 = new cjs.Graphics().p("EAzCACwIjpg/QgMgEgFgSQgDgSAGgWQAGgXAMgNQANgOAMADIDpBAQAMADAEATQAFASgHAWQgGAXgNANQgKALgKAAIgEgBg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_3_graphics_16,x:302.7297,y:9.4868}).wait(1).to({graphics:mask_3_graphics_17,x:302.998,y:9.5598}).wait(1).to({graphics:mask_3_graphics_18,x:304.0296,y:9.8402}).wait(1).to({graphics:mask_3_graphics_19,x:306.3633,y:10.4746}).wait(1).to({graphics:mask_3_graphics_20,x:310.1882,y:11.5143}).wait(1).to({graphics:mask_3_graphics_21,x:313.6352,y:12.4513}).wait(1).to({graphics:mask_3_graphics_22,x:315.7,y:13.0126}).wait(1).to({graphics:mask_3_graphics_23,x:316.8547,y:13.2868}).wait(1).to({graphics:mask_3_graphics_24,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_25,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_26,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_27,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_28,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_29,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_30,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_31,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_32,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_33,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_34,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_35,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_36,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_37,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_38,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_39,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_40,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_41,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_42,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_3_graphics_43,x:316.8547,y:13.2868}).wait(1).to({graphics:mask_3_graphics_44,x:316.9832,y:13.3264}).wait(1).to({graphics:mask_3_graphics_45,x:317.4361,y:13.4659}).wait(1).to({graphics:mask_3_graphics_46,x:318.36,y:13.7505}).wait(1).to({graphics:mask_3_graphics_47,x:319.9727,y:14.2472}).wait(1).to({graphics:mask_3_graphics_48,x:322.4397,y:15.007}).wait(1).to({graphics:mask_3_graphics_49,x:325.3408,y:15.9006}).wait(1).to({graphics:mask_3_graphics_50,x:327.7833,y:16.6528}).wait(1).to({graphics:mask_3_graphics_51,x:329.4913,y:17.1789}).wait(1).to({graphics:mask_3_graphics_52,x:330.6172,y:17.5257}).wait(1).to({graphics:mask_3_graphics_53,x:331.3047,y:17.7118}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_3 = new lib.doodle3_2();
	this.instance_3.setTransform(619.05,19.75,1.0206,1.0206,0,-31.6363,148.3637,10.3,11);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.3,637.1,250.3);


(lib.doodle2_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,27,24,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle2_2Sub();
	this.sub.name = "sub";
	this.sub.setTransform(13.2,11.8,1,1,0,0,0,13.2,11.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle2_2, new cjs.Rectangle(0,0,26.3,23.5), null);


(lib.doodle2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_17 = new cjs.Graphics().p("AMfCNIAAAAQgWgWAAgfQAAgfAWgWIAAAAQAWgWAfAAQAfAAAWAWIAAAAQAWAWAAAfQAAAfgWAWIAAAAQgWAWgfAAIAAAAQgfAAgWgWgANUBtQAJAAAGgGIAAAAQAGgGAAgJQAAgJgGgGIAAAAQgGgGgJAAQgJAAgGAGIAAAAQgGAGAAAJQAAAJAGAGIAAAAQAGAGAJAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AMbCOIAAAAQgXgXAAggQAAghAXgXIAAAAQAXgXAgAAQAhABAXAWIAAAAQAXAXAAAhQAAAggXAXIAAAAQgXAXghAAIAAAAQgggBgXgWgANSBtQAKAAAGgHIAAAAQAHgGAAgJQAAgKgHgGIAAAAQgGgHgKAAQgJAAgGAHIAAAAQgHAGAAAKQAAAJAHAGIAAAAQAGAHAJAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AMSCPIAAAAQgZgZAAgjQAAgkAZgZIAAgBQAZgXAjAAQAkAAAZAXIABABQAZAZAAAkQgBAjgZAZIAAAAQgZAZgkAAIAAAAQgjAAgZgZgANOBrQALAAAHgHIAAAAQAHgHAAgKQAAgKgHgIIAAAAQgHgHgLAAQgJAAgIAHIAAAAQgHAIAAAKQAAAKAHAHIAAAAQAHAHAKAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AMBCSIAAAAQgdgdAAgpQAAgqAdgdIAAgBQAegbAoAAQAqAAAdAbIABABQAdAdAAAqQAAApgeAdIAAAAQgdAdgqAAIAAAAQgpAAgdgdgANHBoQAMAAAJgJIAAABQAIgJAAgLQAAgMgIgIIAAgBQgJgIgMAAQgLAAgIAIIgBABQgIAIAAAMQAAALAIAJIAAgBQAJAJALAAg");
	var mask_graphics_21 = new cjs.Graphics().p("ALnCXIAAAAQgjgkAAgyQAAgyAjgjIAAAAQAkgjAyAAQAyAAAjAjIABAAQAjAjAAAyQAAAygjAkIAAAAQgkAjgyAAIAAAAQgyAAgkgjgAM9BjQAOAAALgKIgBAAQALgKgBgOQAAgOgJgKIgBgBQgKgJgOAAQgOAAgKAJIgBABQgKAKAAAOQAAAOAKAKIAAAAQALAKAOAAg");
	var mask_graphics_22 = new cjs.Graphics().p("ALICcIAAAAQgrgrAAg9QAAg8AqgrIABgBQArgqA9AAQA8AAAsAqIAAABQArArAAA8QAAA9grArIAAAAQgrArg9AAIgBAAQg8AAgrgrgAMwBeQARAAANgNIAAABQAMgNAAgRQAAgRgMgNIgBAAQgMgMgRAAQgRAAgNAMIAAAAQgMANAAARQAAARAMANIAAgBQAMANASAAg");
	var mask_graphics_23 = new cjs.Graphics().p("AKqChIAAAAQgygygBhHQAAhGAygzIABgBQAzgxBGAAQBHAAAzAxIABABQAyAzAABGQAABHgzAyIAAAAQgzAzhHgBIAAAAQhGAAgzgygAMjBYQAVAAAPgOIgBAAQAPgOAAgUQAAgUgOgPIgBgBQgPgMgUAAQgTAAgPAMIgBABQgNAPAAAUQgBAUAPAOIAAAAQAOAOAUAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AKTClIAAAAQg4g4AAhPQgBhOA4g4IABgBQA4g3BPAAQBPAAA4A3IABABQA3A4AABOQAABPg4A4IAAAAQg4A4hPAAIgBAAQhOAAg4g4gAMaBUQAXAAAQgQIAAAAQAPgQAAgWQAAgWgPgPIgBgBQgQgPgWAAQgWAAgQAPIgBABQgQAPAAAWQAAAWAQAQIAAAAQAQAQAXAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AKCCoIAAAAQg8g8AAhVQAAhUA8g8IAAgBQA9g7BUAAQBUAAA9A7IABABQA7A8AABUQAABVg8A8IAAAAQg9A8hUAAIgBAAQhTAAg9g8gAMTBRQAYAAASgRIAAAAQARgRAAgYQgBgXgQgRIgBgBQgRgQgYAAQgYAAgRAQIgBABQgQARAAAXQAAAYARARIgBAAQASARAYAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AJ3CqIAAAAQg/g/AAhYQAAhYA/g/IAAgBQBAg+BXABQBYAABAA9IAAABQA/A/AABYQAABYg/A/IAAAAQg/A/hZgBIAAAAQhYAAg/g+gAMOBPQAaAAASgSIAAABQASgSAAgZQgBgYgRgSIgBgBQgSgRgZAAQgYAAgSARIgBABQgRASgBAYQAAAZASASIAAgBQASASAZAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AJwCrIAAAAQhAhAAAhbQAAhaBAhBIABgBQBAg/BaAAQBbAABBA/IABABQBABBAABaQAABbhBBAIAAAAQhBBAhbAAIAAAAQhaAAhBhAgAMLBOQAbAAASgTIAAABQASgSAAgaQAAgZgRgSIgBgBQgTgSgaAAQgZAAgSASIgBABQgSASAAAZQAAAaASASIAAgBQATATAZAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AJtCsIAAAAQhChCAAhcQAAhbBBhBIABgBQBChABbAAQBcAABBBAIABABQBBBBAABbQAABchBBCIAAAAQhCBBhcAAIgBAAQhbAAhBhBgAMKBNQAbAAATgSIgBAAQATgTAAgaQAAgZgSgSIgBgBQgTgSgaAAQgaAAgSASIgBABQgSASAAAZQAAAaASATIAAAAQATASAaAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AJsCsIgBAAQhBhCAAhcQAAhcBBhCIABgBQBChABcAAQBcAABBBAIACABQBBBCAABcQgBBchBBCIAAAAQhCBBhcAAIgBAAQhbAAhChBgAMKBNQAaAAATgTIAAABQATgTAAgaQgBgZgRgTIgBgBQgTgSgaAAQgaAAgTASIgBABQgSATAAAZQAAAaATATIgBgBQATATAbAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AJsCsIgBAAQhBhCAAhcQAAhcBBhCIABgBQBChABcAAQBcAABBBAIACABQBBBCAABcQgBBchBBCIAAAAQhCBBhcAAIgBAAQhbAAhChBgAMKBNQAaAAATgTIAAABQATgTAAgaQgBgZgRgTIgBgBQgTgSgaAAQgaAAgTASIgBABQgSATAAAZQAAAaATATIgBgBQATATAbAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AJnCtIgBAAQhChDAAheQgBheBDhDIABgBQBDhBBdAAQBeAABDBBIABABQBDBDAABeQAABehDBDIAAAAQhEBDhegBIAAAAQhdAAhDhCgAMHBMQAcAAATgTIAAAAQATgTAAgaQgBgagSgTIgBgBQgTgSgbAAQgaAAgTASIgBABQgSATAAAaQAAAaASATIAAAAQAUATAaAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AJUCwIAAAAQhHhHAAhlQAAhjBHhIIABgBQBHhGBkAAQBkAABHBGIACABQBGBIAABjQAABlhHBHIAAAAQhIBHhkAAIgBAAQhjAAhIhHgAMABJQAdAAAVgVIgBABQAUgUAAgdQAAgbgTgVIgBgBQgVgTgcAAQgcAAgVATIgBABQgTAVAAAbQAAAdAUAUIAAgBQAUAVAdAAg");
	var mask_graphics_33 = new cjs.Graphics().p("AIwDBIAAAAQhQhQAAhxQAAhwBPhQIACgBQBQhPBwAAQBwAABRBPIABABQBPBQAABwQAABxhQBQIAAAAQhRBQhwAAIgBAAQhvAAhRhQgALxBNQAgAAAYgXIgBABQAXgXAAggQAAgfgWgXIgBgBQgXgVggAAQggAAgWAVIgCABQgWAXAAAfQAAAgAXAXIAAgBQAXAXAgAAg");
	var mask_graphics_34 = new cjs.Graphics().p("AHzDmIgBgBQhehfAAiGQgBiFBfhfIABgCQBghdCEAAQCGAABfBdIACACQBeBfAACFQAACGhfBfIgBABQhfBeiGAAIgBAAQiEAAhfhegALXBcQAnAAAcgcIgBABQAbgbAAgmQAAglgagbIgCgBQgbgagmAAQglAAgbAaIgCABQgaAbAAAlQAAAmAbAbIAAgBQAbAcAmAAg");
	var mask_graphics_35 = new cjs.Graphics().p("AGTEeIAAgBQh2h2AAinQgBilB2h3IACgCQB2h0CmAAQCmAAB2B0IACACQB2B3gBClQAACnh2B2IAAABQh3B1imAAIgBAAQilAAh3h1gAKwBzQAwgBAigiIAAABQAhghAAgwQAAgughgiIgBgCQgigggvAAQgvABgiAfIgCACQggAiAAAuQAAAwAhAhIAAgBQAiAiAwABg");
	var mask_graphics_36 = new cjs.Graphics().p("AEVFoIgBgBQiViVAAjSQAAjRCUiWIACgCQCWiSDQAAQDRAACWCSIACACQCUCWAADRQAADSiVCVIAAABQiWCUjSAAIgBAAQjQAAiViUgAJ7CQQA9AAArgrIgBABQArgqgBg8QAAg6gogrIgDgCQgrgog7AAQg6AAgrAoIgCACQgpArAAA6QAAA8AqAqIgBgBQArArA8AAg");
	var mask_graphics_37 = new cjs.Graphics().p("ACWGzIgBgCQiyizAAj+QgBj8Cyi1IADgDQC0iwD7AAQD9AAC1CwIACADQCzC1AAD8QgBD+izCzIgBACQi0Cyj+AAIgBAAQj7AAi0iygAJGCuQBKAAA0g0IgBABQAzgzAAhIQAAhGgxg0IgDgCQg0gxhIAAQhGAAg0AxIgCACQgxA0gBBGQAABIAzAzIgBgBQA0A0BIAAg");
	var mask_graphics_38 = new cjs.Graphics().p("AAyHtIAAgCQjLjLAAkgQAAkeDJjNIADgDQDNjIEdAAQEfAADNDIIADADQDKDNAAEeQAAEgjMDLIgBACQjNDLkfgBIgCAAQkcAAjNjKgAIdDGQBTgBA7g7IAAACQA5g6AAhSQAAhQg4g6IgDgDQg7g4hRAAQhQABg6A3IgDADQg4A6AABQQgBBSA6A6IgBgCQA7A7BSABg");
	var mask_graphics_39 = new cjs.Graphics().p("AgTIWIgBgBQjcjdgBk4QAAk2DcjeIADgEQDdjZE1ABQE3AADeDYIADAEQDbDeAAE2QAAE4jdDdIgBABQjeDck3gBIgCAAQk0AAjdjbgAIADWQBaAABAhAIgBACQA/g/AAhZQgBhXg8g/IgDgDQhAg8hYAAQhXAAg/A8IgDADQg9A/AABXQAABZA+A/IgBgCQBAA/BZABg");
	var mask_graphics_40 = new cjs.Graphics().p("AhDIyIgBgBQjojoAAlJQAAlHDnjqIADgDQDpjkFFAAQFHAADqDkIADADQDnDqAAFHQAAFJjoDoIgBABQjqDnlIAAIgCAAQlEAAjpjngAHsDhQBfAABDhDIAAACQBBhCAAheQAAhbhAhDIgDgDQhDg/hdAAQhbAAhDA/IgDADQhABDAABbQAABeBBBCIgBgCQBEBDBdAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AhiJFIgBgCQjwjwAAlTQgBlRDvjyIAEgEQDwjrFQAAQFSAADxDrIAEAEQDuDyAAFRQAAFTjwDwIgBACQjyDvlSgBIgCAAQlPAAjwjugAHfDpQBigBBGhFIgBACQBEhEAAhhQgBhehBhFIgEgEQhFhBhgAAQheABhFBAIgEAEQhBBFgBBeQAABhBEBEIgBgCQBGBFBgABg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_graphics_17,x:92.6961,y:16.2877}).wait(1).to({graphics:mask_graphics_18,x:92.8588,y:16.45}).wait(1).to({graphics:mask_graphics_19,x:93.252,y:16.8424}).wait(1).to({graphics:mask_graphics_20,x:93.9555,y:17.5443}).wait(1).to({graphics:mask_graphics_21,x:95.0194,y:18.6058}).wait(1).to({graphics:mask_graphics_22,x:96.3247,y:19.9082}).wait(1).to({graphics:mask_graphics_23,x:97.5633,y:21.1441}).wait(1).to({graphics:mask_graphics_24,x:98.5307,y:22.1094}).wait(1).to({graphics:mask_graphics_25,x:99.2156,y:22.7927}).wait(1).to({graphics:mask_graphics_26,x:99.6727,y:23.2488}).wait(1).to({graphics:mask_graphics_27,x:99.9558,y:23.5313}).wait(1).to({graphics:mask_graphics_28,x:100.1053,y:23.6804}).wait(1).to({graphics:mask_graphics_29,x:100.1502,y:23.7252}).wait(1).to({graphics:mask_graphics_30,x:100.1502,y:23.7252}).wait(1).to({graphics:mask_graphics_31,x:100.3668,y:23.9413}).wait(1).to({graphics:mask_graphics_32,x:101.1178,y:24.6907}).wait(1).to({graphics:mask_graphics_33,x:102.615,y:25.1}).wait(1).to({graphics:mask_graphics_34,x:105.1738,y:25.1}).wait(1).to({graphics:mask_graphics_35,x:109.1464,y:25.1}).wait(1).to({graphics:mask_graphics_36,x:114.3948,y:25.1001}).wait(1).to({graphics:mask_graphics_37,x:119.6549,y:25.1001}).wait(1).to({graphics:mask_graphics_38,x:123.7881,y:25.1001}).wait(1).to({graphics:mask_graphics_39,x:126.7072,y:25.1001}).wait(1).to({graphics:mask_graphics_40,x:128.6936,y:25.1001}).wait(1).to({graphics:mask_graphics_41,x:130.0003,y:25.1001}).wait(1).to({graphics:null,x:0,y:0}).wait(18));

	// Layer_8
	this.instance = new lib.doodle2_2();
	this.instance.setTransform(173.95,17.8,1,1,0,0,0,13.2,11.8);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(17).to({_off:false},0).to({_off:true},25).wait(18));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.doodle1_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,19,14,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle1_3Sub();
	this.sub.name = "sub";
	this.sub.setTransform(9.2,6.8,1,1,0,0,0,9.2,6.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_3, new cjs.Rectangle(0,0,18.4,13.5), null);


(lib.doodle1_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,64,44,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.doodle1_1Sub();
	this.sub.name = "sub";
	this.sub.setTransform(31.9,21.8,1,1,0,0,0,31.9,21.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodle1_1, new cjs.Rectangle(0,0,63.9,43.6), null);


(lib.doodle1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"in":1,"out":30};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(30).call(this.frame_59).wait(1));

	// Layer_14 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_20 = new cjs.Graphics().p("EAvNAA2IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_21 = new cjs.Graphics().p("EAvTAA2IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgJAJQgGAGgGAAIgDAAg");
	var mask_graphics_22 = new cjs.Graphics().p("EAvjAA2IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAIACICSAoQAHACADALQACALgDAOQgEAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_23 = new cjs.Graphics().p("EAv5AA2IiSgoQgHgCgDgLQgDgLAEgOQAEgOAIgIQAIgJAIACICSAoQAHACADALQACALgDAOQgEAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_24 = new cjs.Graphics().p("EAwPAA5IiSgoQgHgCgDgLQgDgLAEgOQAEgOAIgIQAIgJAIACICSAoQAHACADALQACALgDAOQgEAOgIAJQgHAHgGAAIgDgBg");
	var mask_graphics_25 = new cjs.Graphics().p("EAwfAA9IiSgoQgHgCgDgLQgCgLADgOQAEgOAIgIQAIgJAIACICSAoQAIACACALQADALgEAOQgEAOgIAJQgHAHgGAAIgDgBg");
	var mask_graphics_26 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_27 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_28 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_29 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_30 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_31 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_32 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_33 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_34 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_35 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_36 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_37 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_38 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_39 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_40 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_41 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_42 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_43 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_44 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_45 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_46 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_47 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_48 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_49 = new cjs.Graphics().p("EAwlAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgIAJQgHAGgGAAIgDAAg");
	var mask_graphics_50 = new cjs.Graphics().p("EAwmAA/IiSgoQgIgCgCgLQgDgLAEgOQAEgOAIgIQAIgJAHACICTAoQAHACADALQACALgEAOQgDAOgJAJQgGAHgGAAIgDgBg");
	var mask_graphics_51 = new cjs.Graphics().p("EAwqABAIiTgoQgHgCgDgLQgCgLAEgOQADgOAIgIQAIgJAIACICSAoQAIACACALQADALgEAOQgEAOgIAJQgGAGgHAAIgCAAg");
	var mask_graphics_52 = new cjs.Graphics().p("EAwxABCIiTgoQgHgCgDgMQgCgLAEgNQAEgOAIgJQAIgIAHACICSAoQAIABACALQADAMgEAOQgEAOgIAIQgGAHgGAAIgDAAg");
	var mask_graphics_53 = new cjs.Graphics().p("EAw+ABFIiTgoQgHgCgDgMQgCgLAEgNQADgOAIgJQAIgIAIACICSAnQAIACACALQADAMgEAOQgEAOgIAIQgGAHgGAAIgDAAg");
	var mask_graphics_54 = new cjs.Graphics().p("EAxQABJIiSgoQgIgCgCgLQgDgMAEgNQAEgOAIgIQAIgJAHACICTAnQAHACADAMQACALgEAOQgDAOgJAJQgGAGgGAAIgDAAg");
	var mask_graphics_55 = new cjs.Graphics().p("EAxiABNIiSgoQgIgCgCgLQgDgMAEgNQAEgOAIgIQAIgJAHACICTAnQAHACACAMQADALgEAOQgEAOgIAJQgGAHgGAAIgDgBg");
	var mask_graphics_56 = new cjs.Graphics().p("EAxvABQIiTgoQgHgCgDgLQgCgMADgOQAEgNAIgIQAIgJAIACICSAnQAIACACAMQADALgEAOQgEAOgIAJQgGAGgHAAIgCAAg");
	var mask_graphics_57 = new cjs.Graphics().p("EAx3ABSIiTgoQgHgCgDgLQgCgMAEgOQADgNAIgIQAIgJAIACICSAnQAIACACALQADAMgEAOQgEAOgIAJQgGAGgHAAIgCAAg");
	var mask_graphics_58 = new cjs.Graphics().p("EAx8ABUIiSgoQgIgCgCgMQgDgLAEgOQAEgNAIgJQAIgIAHACICSAnQAIACACALQADALgEAOQgEAPgIAIQgGAHgGAAIgDAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(20).to({graphics:mask_graphics_20,x:305.0749,y:2.9013}).wait(1).to({graphics:mask_graphics_21,x:305.666,y:3.1858}).wait(1).to({graphics:mask_graphics_22,x:307.2807,y:3.9629}).wait(1).to({graphics:mask_graphics_23,x:309.4865,y:5.0245}).wait(1).to({graphics:mask_graphics_24,x:311.6922,y:5.7623}).wait(1).to({graphics:mask_graphics_25,x:313.3069,y:6.1509}).wait(1).to({graphics:mask_graphics_26,x:313.8749,y:6.3449}).wait(1).to({graphics:mask_graphics_27,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_28,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_29,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_30,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_31,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_32,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_33,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_34,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_35,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_36,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_37,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_38,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_39,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_40,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_41,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_42,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_43,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_44,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_45,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_46,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_47,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_48,x:313.875,y:6.3449}).wait(1).to({graphics:mask_graphics_49,x:313.8749,y:6.3449}).wait(1).to({graphics:mask_graphics_50,x:313.9707,y:6.3672}).wait(1).to({graphics:mask_graphics_51,x:314.3156,y:6.4473}).wait(1).to({graphics:mask_graphics_52,x:315.0393,y:6.6153}).wait(1).to({graphics:mask_graphics_53,x:316.3255,y:6.9141}).wait(1).to({graphics:mask_graphics_54,x:318.1688,y:7.3422}).wait(1).to({graphics:mask_graphics_55,x:319.9517,y:7.7563}).wait(1).to({graphics:mask_graphics_56,x:321.2129,y:8.0492}).wait(1).to({graphics:mask_graphics_57,x:322.015,y:8.2355}).wait(1).to({graphics:mask_graphics_58,x:322.5499,y:8.3949}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_12
	this.instance = new lib.doodle3_3();
	this.instance.setTransform(618.05,8.35,1.0206,1.0206,0,-31.6363,148.3637,6.4,6);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).to({_off:true},39).wait(1));

	// Layer_15 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_22 = new cjs.Graphics().p("EAxIAB5QgHgBgDgGQgEgGACgHQABgGAGgEQAGgEAHACQAGACAEAFQAEAGgCAHQgBAHgGADQgEADgFAAIgEgBg");
	var mask_1_graphics_23 = new cjs.Graphics().p("EAxEAB7QgJgCgFgHQgEgIACgJQACgJAIgEQAHgFAJACQAJACAEAIQAFAHgCAJQgCAJgIAFQgFADgGAAIgFgBg");
	var mask_1_graphics_24 = new cjs.Graphics().p("EAw3ACBQgPgDgIgNQgIgNAEgPQADgPAOgIQANgIAOADQAPAEAIANQAIANgDAPQgEAPgNAIQgJAFgKAAIgJgBg");
	var mask_1_graphics_25 = new cjs.Graphics().p("EAwiACLQgagGgNgWQgOgWAGgaQAGgZAWgOQAXgOAZAGQAZAGAOAXQAOAWgGAZQgGAagWANQgQAKgRAAQgIAAgHgCg");
	var mask_1_graphics_26 = new cjs.Graphics().p("EAwPACUQgjgIgTgfQgTgeAJgjQAIgjAfgRQAegTAjAIQAiAIATAeQATAegIAjQgJAjgeASQgVANgYAAQgKAAgKgCg");
	var mask_1_graphics_27 = new cjs.Graphics().p("EAwEACZQgogJgWgjQgWgkAKgoQAKgnAjgWQAjgVAoAJQAoAKAWAiQAVAjgJAoQgKAogjAWQgYAPgbAAQgMAAgMgDg");
	var mask_1_graphics_28 = new cjs.Graphics().p("EAv/ACbQgrgKgXglQgXglAKgrQAKgpAmgXQAlgXArAJQAqALAXAlQAXAkgKArQgKAqglAXQgaAQgdAAQgMAAgNgDg");
	var mask_1_graphics_29 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_30 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_31 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_32 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_33 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_36 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_37 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_39 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_44 = new cjs.Graphics().p("EAwGACkQgsgKgXgmQgXgmAKgrQAKgqAngYQAlgXAsAKQArAKAXAlQAYAmgLArQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_45 = new cjs.Graphics().p("EAwGACkQgrgKgXgmQgXglAKgsQAKgpAmgYQAmgXArAKQArAKAXAlQAXAmgKAqQgKAsgmAXQgaAQgdAAQgNAAgNgDg");
	var mask_1_graphics_46 = new cjs.Graphics().p("EAwIACjQgqgKgXglQgXglAKgqQALgpAlgXQAkgWArAJQAqALAWAjQAXAlgKAqQgKAqglAXQgaAQgcAAQgMAAgNgDg");
	var mask_1_graphics_47 = new cjs.Graphics().p("EAwLAChQgogKgWgjQgVgjAJgoQAKgpAjgUQAkgWAoAJQAoAKAWAiQAVAjgJAoQgKApgjAVQgZAQgbAAQgLAAgNgDg");
	var mask_1_graphics_48 = new cjs.Graphics().p("EAwRACdQglgIgUghQgUggAJgmQAJglAggTQAhgUAlAJQAlAJAUAfQAUAhgJAlQgJAlggAUQgXAOgZAAQgLAAgLgDg");
	var mask_1_graphics_49 = new cjs.Graphics().p("EAwaACYQgggIgSgcQgRgcAIghQAHggAdgRQAcgRAgAIQAhAHARAcQARAcgHAgQgIAggcASQgUAMgWAAQgJAAgKgCg");
	var mask_1_graphics_50 = new cjs.Graphics().p("EAwmACQQgagGgOgWQgOgXAGgaQAHgaAWgOQAXgNAaAGQAaAGANAWQAOAXgGAaQgGAagWANQgQAKgSAAQgHAAgIgCg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EAwyACJQgUgFgKgQQgKgRAEgUQAFgTARgLQARgKATAEQAUAFAKARQALARgFATQgFAUgRAKQgLAHgOAAIgLgBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EAw7ACDQgOgDgIgNQgHgMADgOQADgPANgIQANgHAOADQAOAEAIAMQAIANgEAOQgDAOgNAIQgJAFgJAAIgJgBg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EAxCAB/QgLgCgGgKQgFgJACgLQADgLAJgFQAKgGAKACQALADAGAJQAGAKgDAKQgDALgJAGQgGAEgIAAIgGgBg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EAxGAB8QgIgCgEgHQgFgHACgIQACgJAHgEQAIgFAIACQAIACAFAIQAEAHgCAIQgCAIgHAFQgFADgGAAIgFgBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EAxIAB5QgHgBgDgGQgEgGACgHQABgGAGgEQAGgEAHACQAGACAEAFQAEAGgCAHQgBAHgGADQgEADgFAAIgEgBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_1_graphics_22,x:316.4597,y:12.1822}).wait(1).to({graphics:mask_1_graphics_23,x:316.6679,y:12.3897}).wait(1).to({graphics:mask_1_graphics_24,x:317.2976,y:13.0172}).wait(1).to({graphics:mask_1_graphics_25,x:318.3722,y:14.0878}).wait(1).to({graphics:mask_1_graphics_26,x:319.3231,y:15.0353}).wait(1).to({graphics:mask_1_graphics_27,x:319.8693,y:15.5796}).wait(1).to({graphics:mask_1_graphics_28,x:320.1247,y:15.8341}).wait(1).to({graphics:mask_1_graphics_29,x:321.0412,y:16.7253}).wait(1).to({graphics:mask_1_graphics_30,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_31,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_32,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_33,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_34,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_35,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_36,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_37,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_38,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_39,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_40,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_41,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_42,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_43,x:321.0413,y:16.7253}).wait(1).to({graphics:mask_1_graphics_44,x:321.0412,y:16.7253}).wait(1).to({graphics:mask_1_graphics_45,x:321.009,y:16.6932}).wait(1).to({graphics:mask_1_graphics_46,x:320.897,y:16.5821}).wait(1).to({graphics:mask_1_graphics_47,x:320.6738,y:16.3607}).wait(1).to({graphics:mask_1_graphics_48,x:320.2923,y:15.9821}).wait(1).to({graphics:mask_1_graphics_49,x:319.7,y:15.3944}).wait(1).to({graphics:mask_1_graphics_50,x:318.9175,y:14.618}).wait(1).to({graphics:mask_1_graphics_51,x:318.1332,y:13.8399}).wait(1).to({graphics:mask_1_graphics_52,x:317.517,y:13.2285}).wait(1).to({graphics:mask_1_graphics_53,x:317.0818,y:12.7966}).wait(1).to({graphics:mask_1_graphics_54,x:316.7856,y:12.5028}).wait(1).to({graphics:mask_1_graphics_55,x:316.4597,y:12.1822}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_1 = new lib.doodle3_4();
	this.instance_1.setTransform(628,20.85,1.0206,1.0206,0,-31.6363,148.3637,7.1,5.7);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_16 = new cjs.Graphics().p("EAukABeIjphAQgMgDgEgSQgEgRAGgXQAGgWANgOQANgNALADIDqBAQAMADAEARQAEATgGAWQgGAWgNAOQgLALgJAAIgFgBg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EAunABfIjqhAQgLgDgFgSQgEgRAHgXQAGgWAMgOQANgNAMADIDpBAQAMADAEARQAEASgGAXQgGAWgNAOQgKALgKAAIgEgBg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EAuxABiIjphAQgMgDgEgSQgEgSAGgWQAGgWANgOQANgOALAEIDqA/QAMAEAEARQAEASgGAWQgGAXgNAOQgLAKgJAAIgFAAg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EAvIABoIjphAQgMgDgEgSQgEgSAGgWQAGgWANgOQANgNAMADIDpBAQAMADAEARQAEASgGAXQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EAvvABzIjqhAQgLgEgFgSQgEgSAGgVQAHgXAMgNQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAXgNANQgKALgKAAIgEAAg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EAwRAB8IjphAQgMgDgEgSQgEgTAGgVQAGgWANgOQANgOAMAEIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgLALgJAAIgFgBg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EAwmACBIjpg/QgMgEgFgSQgEgSAHgWQAGgWAMgNQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAXgNANQgKALgKAAIgEgBg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_35 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_36 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_37 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_38 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_40 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EAwxACEIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEATgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EAwzACFIjqhAQgMgDgEgTQgEgSAGgWQAHgWAMgNQANgOAMADIDpA/QAMAEAEASQAEASgGAWQgGAXgNANQgKALgKAAIgEAAg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EAw3ACGIjphAQgMgDgEgSQgEgSAGgXQAGgVANgOQANgNAMADIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgLALgJAAIgFgBg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EAxAACJIjphAQgMgDgEgSQgEgTAGgWQAGgVANgOQANgOAMAEIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EAxQACOIjphAQgMgDgEgSQgEgTAGgWQAGgVANgOQANgOAMAEIDpA+QAMAEAEASQAEASgGAXQgGAWgNAOQgKAKgKAAIgFAAg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EAxpACVIjpg/QgMgEgEgSQgEgSAGgWQAGgXANgMQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAXgNANQgKALgKAAIgFgBg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EAyGACeIjpg/QgMgEgEgSQgEgSAGgWQAGgXANgMQANgOAMADIDpA/QAMADAEATQAEASgGAWQgGAWgNAOQgKALgKAAIgFgBg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EAyfACmIjqhAQgMgDgEgSQgEgTAGgWQAHgWAMgOQANgNAMAEIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgKALgKAAIgEgBg");
	var mask_2_graphics_51 = new cjs.Graphics().p("EAywACrIjqhAQgLgDgFgSQgEgSAHgXQAGgWAMgOQANgMAMADIDpA/QAMADAEASQAEASgGAXQgGAWgNAOQgKALgKAAIgEgBg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EAy7ACvIjphAQgMgDgEgTQgEgSAGgWQAGgXANgNQAMgNAMACIDqBAQALAEAEASQAFASgGAWQgHAXgMANQgLALgJAAIgFAAg");
	var mask_2_graphics_53 = new cjs.Graphics().p("EAzCACwIjpg/QgMgEgFgSQgDgSAGgWQAGgXAMgNQANgOAMADIDpBAQAMADAEATQAFASgHAWQgGAXgNANQgKALgKAAIgEgBg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_2_graphics_16,x:302.7297,y:9.4868}).wait(1).to({graphics:mask_2_graphics_17,x:302.998,y:9.5598}).wait(1).to({graphics:mask_2_graphics_18,x:304.0296,y:9.8402}).wait(1).to({graphics:mask_2_graphics_19,x:306.3633,y:10.4746}).wait(1).to({graphics:mask_2_graphics_20,x:310.1882,y:11.5143}).wait(1).to({graphics:mask_2_graphics_21,x:313.6352,y:12.4513}).wait(1).to({graphics:mask_2_graphics_22,x:315.7,y:13.0126}).wait(1).to({graphics:mask_2_graphics_23,x:316.8547,y:13.2868}).wait(1).to({graphics:mask_2_graphics_24,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_25,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_26,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_27,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_28,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_29,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_30,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_31,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_32,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_33,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_34,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_35,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_36,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_37,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_38,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_39,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_40,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_41,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_42,x:316.8547,y:13.2869}).wait(1).to({graphics:mask_2_graphics_43,x:316.8547,y:13.2868}).wait(1).to({graphics:mask_2_graphics_44,x:316.9832,y:13.3264}).wait(1).to({graphics:mask_2_graphics_45,x:317.4361,y:13.4659}).wait(1).to({graphics:mask_2_graphics_46,x:318.36,y:13.7505}).wait(1).to({graphics:mask_2_graphics_47,x:319.9727,y:14.2472}).wait(1).to({graphics:mask_2_graphics_48,x:322.4397,y:15.007}).wait(1).to({graphics:mask_2_graphics_49,x:325.3408,y:15.9006}).wait(1).to({graphics:mask_2_graphics_50,x:327.7833,y:16.6528}).wait(1).to({graphics:mask_2_graphics_51,x:329.4913,y:17.1789}).wait(1).to({graphics:mask_2_graphics_52,x:330.6172,y:17.5257}).wait(1).to({graphics:mask_2_graphics_53,x:331.3047,y:17.7118}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_2 = new lib.doodle3_2();
	this.instance_2.setTransform(619.05,19.75,1.0206,1.0206,0,-31.6363,148.3637,10.3,11);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(16).to({_off:false},0).to({_off:true},38).wait(6));

	// Layer_15 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_22 = new cjs.Graphics().p("ASgB9QgDgDgBgEQAAgEADgDQACgDAEgBQAEAAAEADQADACAAAEQABAEgDAEQgDADgEAAIgBAAQgDAAgDgCg");
	var mask_3_graphics_23 = new cjs.Graphics().p("AScB9QgEgDAAgFQgBgGAEgEQADgEAFAAQAGgBAEAEQAEADAAAFQABAGgEAEQgDAEgFAAIgCAAQgEAAgEgDg");
	var mask_3_graphics_24 = new cjs.Graphics().p("ASRB/QgHgGgBgJQgBgJAGgHQAGgHAJgBQAJAAAHAFQAHAGABAJQABAJgGAHQgGAHgJABIgCAAQgIAAgGgFg");
	var mask_3_graphics_25 = new cjs.Graphics().p("AR+CCQgMgKgBgPQgCgQAKgMQAKgMAQgBQAPgBAMAJQAMAKACAQQABAPgKAMQgKAMgPACIgEAAQgNAAgLgJg");
	var mask_3_graphics_26 = new cjs.Graphics().p("ARtCFQgQgOgCgVQgCgVAOgQQANgRAVgCQAWgCAQAOQARAOACAVQACAVgOAQQgOARgVACIgFAAQgSAAgPgMg");
	var mask_3_graphics_27 = new cjs.Graphics().p("ARkCGQgTgPgCgZQgDgYAQgTQAQgTAYgCQAZgCATAPQATAQACAYQACAZgQATQgPATgZACIgGAAQgVAAgQgOg");
	var mask_3_graphics_28 = new cjs.Graphics().p("ARfCHQgUgQgCgaQgDgaARgUQARgUAagDQAagCAUAQQAUARACAaQADAagRAUQgRAUgaACIgGABQgWAAgSgPg");
	var mask_3_graphics_29 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_30 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_31 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_41 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_42 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_43 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_44 = new cjs.Graphics().p("ARiCLQgUgRgDgaQgCgaARgVQARgUAagDQAbgCAUARQAVARACAaQACAagRAVQgQAUgbADIgHAAQgWAAgSgPg");
	var mask_3_graphics_45 = new cjs.Graphics().p("ARjCLQgVgRgCgaQgCgaAQgUQARgUAagDQAbgCAUAQQAUARADAaQACAbgRAUQgQAUgbACIgGABQgXAAgRgPg");
	var mask_3_graphics_46 = new cjs.Graphics().p("ARkCLQgUgRgCgZQgCgaAQgUQARgTAZgDQAagCAUAQQAUARACAZQADAagRATQgQAUgaADIgHAAQgVAAgSgOg");
	var mask_3_graphics_47 = new cjs.Graphics().p("ARnCKQgTgQgCgYQgCgZAPgTQAQgSAZgDQAYgCAUAQQATAPACAZQACAYgQATQgPATgZADIgGAAQgVAAgRgOg");
	var mask_3_graphics_48 = new cjs.Graphics().p("ARtCJQgSgPgCgWQgCgXAOgRQAPgSAXgCQAWgCASAOQARAPADAXQACAWgPASQgOARgXACIgGABQgTAAgPgNg");
	var mask_3_graphics_49 = new cjs.Graphics().p("AR1CHQgPgMgCgUQgCgUANgPQAMgPAUgCQAUgCAPANQAPAMACAUQACAUgNAPQgMAPgUACIgFAAQgRAAgNgLg");
	var mask_3_graphics_50 = new cjs.Graphics().p("ASACFQgMgKgCgQQgBgQAKgMQAKgMAQgCQAQgBAMAKQAMAKABAQQACAQgKAMQgKAMgQABIgEAAQgNAAgLgIg");
	var mask_3_graphics_51 = new cjs.Graphics().p("ASLCCQgJgHgBgMQgBgMAHgJQAIgJAMgBQALgBAKAHQAJAIABAMQABALgIAJQgHAKgMABIgDAAQgKAAgIgHg");
	var mask_3_graphics_52 = new cjs.Graphics().p("ASUCAQgHgFgBgJQgBgJAGgGQAFgHAJgBQAJgBAHAGQAGAFABAJQABAJgGAHQgFAGgJABIgCAAQgIAAgFgFg");
	var mask_3_graphics_53 = new cjs.Graphics().p("ASaB/QgFgEgBgHQgBgGAFgFQAEgFAGgBQAHgBAFAFQAFAEABAGQAAAHgEAFQgEAFgHABIgBAAQgGAAgEgEg");
	var mask_3_graphics_54 = new cjs.Graphics().p("ASeB+QgEgDgBgFQAAgFADgEQADgEAGgBQAFAAAEADQADADABAGQAAAFgDADQgDAEgFABIgBAAQgFAAgDgDg");
	var mask_3_graphics_55 = new cjs.Graphics().p("ASgB9QgDgDgBgEQAAgEADgDQACgDAEgBQAEAAAEADQADACAAAEQABAEgDAEQgDADgEAAIgBAAQgDAAgDgCg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_3_graphics_22,x:120.0212,y:12.7199}).wait(1).to({graphics:mask_3_graphics_23,x:120.1492,y:12.8476}).wait(1).to({graphics:mask_3_graphics_24,x:120.5365,y:13.2338}).wait(1).to({graphics:mask_3_graphics_25,x:121.1974,y:13.893}).wait(1).to({graphics:mask_3_graphics_26,x:121.7822,y:14.4763}).wait(1).to({graphics:mask_3_graphics_27,x:122.1181,y:14.8114}).wait(1).to({graphics:mask_3_graphics_28,x:122.2751,y:14.9681}).wait(1).to({graphics:mask_3_graphics_29,x:122.7297,y:15.3963}).wait(1).to({graphics:mask_3_graphics_30,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_31,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_32,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_33,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_34,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_35,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_36,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_37,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_38,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_39,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_40,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_41,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_42,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_43,x:122.7297,y:15.3962}).wait(1).to({graphics:mask_3_graphics_44,x:122.7297,y:15.3963}).wait(1).to({graphics:mask_3_graphics_45,x:122.7105,y:15.3773}).wait(1).to({graphics:mask_3_graphics_46,x:122.644,y:15.3114}).wait(1).to({graphics:mask_3_graphics_47,x:122.5113,y:15.1802}).wait(1).to({graphics:mask_3_graphics_48,x:122.2846,y:14.9559}).wait(1).to({graphics:mask_3_graphics_49,x:121.9326,y:14.6076}).wait(1).to({graphics:mask_3_graphics_50,x:121.4676,y:14.1475}).wait(1).to({graphics:mask_3_graphics_51,x:121.0015,y:13.6864}).wait(1).to({graphics:mask_3_graphics_52,x:120.6353,y:13.3241}).wait(1).to({graphics:mask_3_graphics_53,x:120.3766,y:13.0682}).wait(1).to({graphics:mask_3_graphics_54,x:120.2006,y:12.8941}).wait(1).to({graphics:mask_3_graphics_55,x:120.0212,y:12.7199}).wait(1).to({graphics:null,x:0,y:0}).wait(4));

	// Layer_10
	this.instance_3 = new lib.doodle1_3();
	this.instance_3.setTransform(239.95,22.7,0.4513,0.4513,-0.3487,0,0,9.5,7.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(22).to({_off:false},0).to({_off:true},34).wait(4));

	// Layer_13 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_9 = new cjs.Graphics().p("AVDCtIiRkTQgIgOAPgUQAOgVAcgOQAbgPAZAAQAZgBAHAOICSEUQAHAOgOAVQgOAUgcAOQgbAPgZAAIgBAAQgYAAgIgOg");
	var mask_4_graphics_10 = new cjs.Graphics().p("AVECtIiUkSQgHgOAOgVQAOgUAcgPQAbgPAZAAQAZgBAHAOICUETQAHAOgOAVQgOAUgbAPQgcAOgZABIgBAAQgYAAgHgOg");
	var mask_4_graphics_11 = new cjs.Graphics().p("AVFCtIiakPQgIgOAOgUQAOgVAbgQQAbgPAZgBQAZgBAIAOICaEPQAHANgNAVQgOAVgbAPQgbAQgZABIgDAAQgXAAgHgNg");
	var mask_4_graphics_12 = new cjs.Graphics().p("AVICsIimkHQgJgOANgVQANgWAagQQAagRAZgCQAZgCAIANICmEIQAJAOgNAVQgNAVgaARQgaAQgZADIgGAAQgUAAgHgMg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AVLCrIi4j7QgKgNALgWQALgXAagSQAZgTAYgDQAZgFAJANIC5D7QAKANgMAWQgLAWgZATQgZASgZAFIgKAAQgQAAgIgJg");
	var mask_4_graphics_14 = new cjs.Graphics().p("AVRCmIjUjlQgKgMAIgXQAJgXAXgWQAXgVAYgGQAYgHAKAMIDUDlQALAMgJAXQgJAXgXAVQgXAWgYAGQgIADgHAAQgMAAgHgIg");
	var mask_4_graphics_15 = new cjs.Graphics().p("AVXCcIj1jBQgMgKAFgYQAFgZATgYQAUgZAWgKQAXgKAMAKID1DBQANAKgFAZQgFAYgUAYQgTAZgXAKQgLAFgJAAQgJAAgGgFg");
	var mask_4_graphics_16 = new cjs.Graphics().p("AVdCKIkXiMQgOgHAAgZQgBgZAOgcQAPgbAUgPQAUgPAOAHIEXCMQAOAHAAAZQAAAZgOAcQgOAbgUAPQgNAKgLAAQgFAAgFgCg");
	var mask_4_graphics_17 = new cjs.Graphics().p("AVfBuIkwhJQgPgEgGgYQgGgXAIgeQAHgfAQgSQAQgTAQADIEwBJQAPAEAGAYQAGAXgIAeQgHAfgQATQgNAPgNAAIgGAAg");
	var mask_4_graphics_18 = new cjs.Graphics().p("AVcBTIk4gFQgQgBgLgWQgLgWABggQAAgeAMgVQAMgXAQABIE4AFQAQABALAWQALAWgBAfQAAAfgMAWQgLAVgQAAIgBAAg");
	var mask_4_graphics_19 = new cjs.Graphics().p("AQDBSQgPgUgFgfQgFgfAIgXQAIgXAPgDIE1gxQAQgDAPAVQAOATAFAfQAFAegIAYQgHAXgQADIk1AxIgDAAQgOAAgNgRg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AQDBoQgRgSgJgeQgJgeAEgYQAFgXAPgFIErhaQAPgFASASQARASAJAeQAJAegFAYQgEAXgPAFIkrBaIgHABQgMAAgOgOg");
	var mask_4_graphics_21 = new cjs.Graphics().p("AQGB4QgTgQgMgdQgMgdACgZQACgYAPgGIEgh4QAPgGATAQQATAQAMAdQAMAdgCAZQgCAYgPAGIkgB4QgEABgFAAQgLAAgOgLg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AQKCCQgUgOgOgcQgOgcAAgZQAAgZAOgHIEXiMQAOgHAUAPQAUAOAOAcQAPAcAAAZQgBAZgOAHIkXCMQgFACgFAAQgLAAgNgKg");
	var mask_4_graphics_23 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_24 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_25 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_27 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_31 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_32 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_33 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_35 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_37 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_38 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_39 = new cjs.Graphics().p("AQOCKQgVgOgQgbQgPgbgBgZQgBgZANgIIEQiaQANgIAVAOQAVANAPAbQAQAbABAZQABAZgNAIIkQCaQgFADgGAAQgKAAgNgIg");
	var mask_4_graphics_40 = new cjs.Graphics().p("AQOCLQgVgOgPgbQgQgbgBgZQgCgZAOgIIEOicQAOgIAVAOQAVANAPAbQAQAbACAZQABAZgOAIIkOCcQgFADgGAAQgLAAgNgIg");
	var mask_4_graphics_41 = new cjs.Graphics().p("AQQCOQgVgOgQgaQgRgbgCgYQgCgZAOgJIEKiiQAOgIAVANQAVANARAaQAQAbACAZQACAYgOAJIkKCiQgFADgHAAQgKAAgNgHg");
	var mask_4_graphics_42 = new cjs.Graphics().p("AQUCTQgWgMgRgaQgSgagDgYQgDgZANgJIEDiuQANgJAWAMQAWAMARAaQASAaADAZQADAYgNAJIkDCuQgGAEgHAAQgKAAgMgHg");
	var mask_4_graphics_43 = new cjs.Graphics().p("AQbCbQgXgKgTgZQgTgYgFgZQgFgYANgKID2jAQAMgKAXALQAWAKAUAZQATAYAFAZQAEAYgMAKIj2DAQgGAFgJAAQgIAAgMgGg");
	var mask_4_graphics_44 = new cjs.Graphics().p("AQoCmQgYgIgVgWQgWgWgHgYQgIgYAMgLIDfjZQAMgLAYAIQAXAIAWAWQAWAWAHAYQAHAYgLALIjgDZQgHAHgKAAQgIAAgKgEg");
	var mask_4_graphics_45 = new cjs.Graphics().p("ARAC3QgZgEgZgTQgZgTgLgWQgLgWAKgNIC8j5QAKgMAYAEQAZAEAYATQAZATALAWQALAXgJAMIi8D5QgIAJgPAAIgLgBg");
	var mask_4_graphics_46 = new cjs.Graphics().p("AQxDDQgcgNgPgUQgPgUAHgOICGkZQAHgOAZgBQAZgBAcAOQAcANAPAUQAPAUgHAOIiGEZQgHAPgZAAIgCAAQgYAAgbgNg");
	var mask_4_graphics_47 = new cjs.Graphics().p("ARkDnQgegHgTgQQgUgQAEgPIBEkwQADgQAZgGQAXgGAfAGQAeAHAUAQQATAQgEAPIhEEwQgDAQgYAGQgMADgNAAQgOAAgQgDg");
	var mask_4_graphics_48 = new cjs.Graphics().p("ASdEBQggAAgVgMQgXgLAAgQIADk3QAAgQAWgMQAXgLAfABQAfAAAWALQAWAMAAAQIgDE3QAAAQgWALQgWALgeAAIgBAAg");
	var mask_4_graphics_49 = new cjs.Graphics().p("AR/EOQgXgHgDgQIgzkzQgDgQAUgPQAUgOAfgFQAfgFAYAHQAXAIADAPIAzE0QADAPgUAPQgUAPgfAFQgNACgLAAQgQAAgPgFg");
	var mask_4_graphics_50 = new cjs.Graphics().p("ASUEeQgYgEgFgQIhbkpQgFgQASgRQASgRAegJQAdgKAZAFQAYAEAFAPIBbEqQAFAQgSARQgSARgeAJQgUAGgRAAQgJAAgIgBg");
	var mask_4_graphics_51 = new cjs.Graphics().p("ASlEnQgZgCgGgOIh4kgQgGgOAQgUQAQgSAdgMQAdgMAZABQAYACAGAPIB5EgQAGAOgQATQgRATgcAMQgZAKgWAAIgHAAg");
	var mask_4_graphics_52 = new cjs.Graphics().p("ASyEtQgZAAgHgOIiMkXQgHgOAOgUQAPgUAcgOQAcgOAZAAQAYAAAIAPICMEWQAHAOgOAUQgPAUgcAOQgbAOgZAAIgBAAg");
	var mask_4_graphics_53 = new cjs.Graphics().p("AScEiIibkQQgIgOAOgUQAOgUAbgQQAbgPAZgBQAYgBAIANICbEPQAIAOgOAUQgNAVgbAQQgcAPgYABIgFAAQgVAAgHgMg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_4_graphics_9,x:148.3535,y:17.657}).wait(1).to({graphics:mask_4_graphics_10,x:148.3507,y:17.5358}).wait(1).to({graphics:mask_4_graphics_11,x:148.3355,y:17.1347}).wait(1).to({graphics:mask_4_graphics_12,x:148.2843,y:16.391}).wait(1).to({graphics:mask_4_graphics_13,x:148.14,y:15.2418}).wait(1).to({graphics:mask_4_graphics_14,x:147.782,y:13.6579}).wait(1).to({graphics:mask_4_graphics_15,x:146.9953,y:11.7411}).wait(1).to({graphics:mask_4_graphics_16,x:145.5325,y:9.9033}).wait(1).to({graphics:mask_4_graphics_17,x:143.4456,y:8.8325}).wait(1).to({graphics:mask_4_graphics_18,x:141.2388,y:8.3373}).wait(1).to({graphics:mask_4_graphics_19,x:139.3969,y:9.5756}).wait(1).to({graphics:mask_4_graphics_20,x:137.9823,y:10.5624}).wait(1).to({graphics:mask_4_graphics_21,x:136.9274,y:11.5255}).wait(1).to({graphics:mask_4_graphics_22,x:136.1578,y:12.3477}).wait(1).to({graphics:mask_4_graphics_23,x:135.6445,y:12.5557}).wait(1).to({graphics:mask_4_graphics_24,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_25,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_26,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_27,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_28,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_29,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_30,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_31,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_32,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_33,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_34,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_35,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_36,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_37,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_38,x:135.6446,y:12.5558}).wait(1).to({graphics:mask_4_graphics_39,x:135.6445,y:12.5557}).wait(1).to({graphics:mask_4_graphics_40,x:135.5713,y:12.6429}).wait(1).to({graphics:mask_4_graphics_41,x:135.3261,y:12.9406}).wait(1).to({graphics:mask_4_graphics_42,x:134.8603,y:13.5317}).wait(1).to({graphics:mask_4_graphics_43,x:134.1073,y:14.5572}).wait(1).to({graphics:mask_4_graphics_44,x:132.9825,y:16.2462}).wait(1).to({graphics:mask_4_graphics_45,x:131.4137,y:18.4447}).wait(1).to({graphics:mask_4_graphics_46,x:129.459,y:20.821}).wait(1).to({graphics:mask_4_graphics_47,x:127.4684,y:23.4189}).wait(1).to({graphics:mask_4_graphics_48,x:125.8933,y:25.7253}).wait(1).to({graphics:mask_4_graphics_49,x:127.4276,y:27.4988}).wait(1).to({graphics:mask_4_graphics_50,x:128.8242,y:28.7305}).wait(1).to({graphics:mask_4_graphics_51,x:129.9212,y:29.5501}).wait(1).to({graphics:mask_4_graphics_52,x:130.7483,y:30.0885}).wait(1).to({graphics:mask_4_graphics_53,x:131.3945,y:30.2435}).wait(1).to({graphics:null,x:0,y:0}).wait(6));

	// Layer_11
	this.instance_4 = new lib.doodle1_1();
	this.instance_4.setTransform(253.35,15.25,0.4513,0.4513,-0.3487,0,0,32.1,22.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(9).to({_off:false},0).to({_off:true},45).wait(6));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,0,0,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(59));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-0.3,728,90.3);


(lib.bgScreens = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img5
	this.img5 = new lib.img5();
	this.img5.name = "img5";
	this.img5.setTransform(252.1,36.45,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img5).wait(1));

	// img4
	this.img4 = new lib.img4();
	this.img4.name = "img4";
	this.img4.setTransform(220.5,135,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img3
	this.img3 = new lib.img3();
	this.img3.name = "img3";
	this.img3.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img2
	this.img2 = new lib.img2();
	this.img2.name = "img2";
	this.img2.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img1
	this.img1 = new lib.img1();
	this.img1.name = "img1";
	this.img1.setTransform(220.5,146,1,1,0,0,0,107.5,69);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgScreens, new cjs.Rectangle(141.6,2.3,159.9,116.2), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.scribbleClip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// scribble5
	this.scribble5 = new lib.scribble5();
	this.scribble5.name = "scribble5";
	this.scribble5.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble5).wait(1));

	// scribble4
	this.scribble4 = new lib.scribble4();
	this.scribble4.name = "scribble4";
	this.scribble4.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble4).wait(1));

	// scribble3
	this.scribble3 = new lib.scribble3();
	this.scribble3.name = "scribble3";
	this.scribble3.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble3).wait(1));

	// scribble2
	this.scribble2 = new lib.scribble2();
	this.scribble2.name = "scribble2";
	this.scribble2.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble2).wait(1));

	// scribble1
	this.scribble1 = new lib.scribble1();
	this.scribble1.name = "scribble1";
	this.scribble1.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribbleClip, new cjs.Rectangle(0,-188.9,874.7,438.9), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-14.75,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-96.5,-13.8,1,1,0,0,0,1.5,0.2);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-14,142.79999999999998,28), null);


(lib.doodleClip = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// doodle5
	this.doodle5 = new lib.doodle5();
	this.doodle5.name = "doodle5";
	this.doodle5.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle5).wait(1));

	// doodle4
	this.doodle4 = new lib.doodle4();
	this.doodle4.name = "doodle4";
	this.doodle4.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle4).wait(1));

	// doodle3
	this.doodle3 = new lib.doodle3();
	this.doodle3.name = "doodle3";
	this.doodle3.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle3).wait(1));

	// doodle2
	this.doodle2 = new lib.doodle2();
	this.doodle2.name = "doodle2";
	this.doodle2.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle2).wait(1));

	// doodle1
	this.doodle1 = new lib.doodle1();
	this.doodle1.name = "doodle1";
	this.doodle1.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.doodleClip, new cjs.Rectangle(0,0,728,250), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// navHits
	this.hit5 = new lib.option_hit();
	this.hit5.name = "hit5";
	this.hit5.setTransform(97.1,68.15,0.9783,2.7839,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit5, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit4 = new lib.option_hit();
	this.hit4.name = "hit4";
	this.hit4.setTransform(81.5,68.15,0.9783,2.7839,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit4, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(65.65,68.15,0.9783,2.7839,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(50.05,68.15,0.9783,2.7839,0,0,0,0.1,0.2);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(34.25,68.15,0.9783,2.7839,0,0,0,0,0.2);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hitNext = new lib.option_hit();
	this.hitNext.name = "hitNext";
	this.hitNext.setTransform(119.8,67,1.8442,2.8963,0,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.hitNext, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hitPrev = new lib.option_hit();
	this.hitPrev.name = "hitPrev";
	this.hitPrev.setTransform(10.7,67.3,1.9313,2.8962,0,0,0,-0.1,0.2);
	new cjs.ButtonHelper(this.hitPrev, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hitPrev},{t:this.hitNext},{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit4},{t:this.hit5}]}).wait(1));

	// hit
	this.hit = new lib.option_hit();
	this.hit.name = "hit";
	this.hit.setTransform(364.3,45,45.4993,5.5556);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// introLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// nav
	this.nav = new lib.Page_indicator();
	this.nav.name = "nav";
	this.nav.setTransform(82.05,68.65,1.0243,1.0243,0,0,0,59.1,6);

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// CTA_txt
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(624.2,45.6,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(725.2,45.3,1,1,0,0,0,0.2,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// bgScreens
	this.screens = new lib.bgScreens();
	this.screens.name = "screens";
	this.screens.setTransform(124,94.5,1,1,0,0,0,124,94.5);

	this.timeline.addTween(cjs.Tween.get(this.screens).wait(1));

	// doodle
	this.doodle = new lib.doodleClip();
	this.doodle.name = "doodle";
	this.doodle.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.doodle).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(248.9,46.6,1,1,0,0,0,125.9,52.6);
	this.grid.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.scribbleClip();
	this.scribble.name = "scribble";
	this.scribble.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-4.5,-188.9,879.2,438.9), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		
		this.initBanner = function (data) {
				
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "subh") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillSubHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							//popL = mc.cta.popLeft
							//popR1 = mc.cta.pop1
							//popR2 = mc.cta.pop2
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							//popL.x = mc.cta.CTAbg.x
							//popL.x -= 15
							//popR1.x = mc.cta.CTAbg.x+newWidth
							//popR2.x = mc.cta.CTAbg.x+newWidth
							//popR1.x += 8
							//popR2.x += 8
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillSubHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillSmallPrint = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var img1 = mc.screens.img1
		
		exportRoot.init_img1_x = mc.screens.img1.x;
		exportRoot.init_img2_x = mc.screens.img2.x;
		exportRoot.init_img3_x = mc.screens.img3.x;
		exportRoot.init_img4_x = mc.screens.img4.x;
		exportRoot.init_img5_x = mc.screens.img5.x;
		
		var init_headline_x 
		
		this.runBanner = function() {
			
				var maxNav = 5	
				mc.cta.alpha=1
			
				var nxt = mc.hitNext
				var prv = mc.hitPrev
				var hit1 = mc.hit1
				var hit2 = mc.hit2
				var hit3 = mc.hit3
				var hit4 = mc.hit4
				var hit5 = mc.hit5
				var hit6 = mc.hit6
			
				var initXpos = 0
				var initOffset = 325
					
				var subHeadPos = exportRoot.headline1.x
			
				var prevSelection = 0
				exportRoot.currentSelection = 1
			
				var nav = mc.nav
			
				hit1.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 1;
						amoAd.onInteraction('Dot1 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit2.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 2;
						amoAd.onInteraction('Dot2 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit3.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 3;
						amoAd.onInteraction('Dot3 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit4.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 4;
						amoAd.onInteraction('Dot4 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				hit5.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						prevSelection = exportRoot.currentSelection;
						exportRoot.currentSelection = 5;
						amoAd.onInteraction('Dot5 Click', exportRoot.currentSelection-1);
						if (exportRoot.currentSelection != prevSelection){
							exportRoot.animInProgress=true
							if(exportRoot.currentSelection > prevSelection) {
								exportRoot.nextScene();
							} else {
								exportRoot.prevScene();
							}
							exportRoot.gotoNextNav()
							exportRoot.scribbleAnim()
						}
					}
				});

				nxt.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						exportRoot.animInProgress=true
						exportRoot.getSelectionId("next")
						amoAd.onInteraction('Next Click', exportRoot.currentSelection-1);
						exportRoot.gotoNextNav()
						exportRoot.scribbleAnim()
						exportRoot.nextScene();
					}
				});

				prv.on("click", function(evt) {
					if (!exportRoot.animInProgress) {
						exportRoot.animInProgress=true
						exportRoot.getSelectionId("prev")
						amoAd.onInteraction('Prev Click', exportRoot.currentSelection-1);
						exportRoot.gotoNextNav();
						exportRoot.scribbleAnim()
						exportRoot.prevScene();
					}
				});
				
				exportRoot.gotoNextNav = function() {
					for (var i=1;i<=maxNav;i++) {
						if (nav["dot_"+i].currentFrame > 15) nav["dot_"+i].gotoAndPlay("deselected")
					}
					nav["dot_"+exportRoot.currentSelection].gotoAndPlay("selected");			
				}
				
				exportRoot.getSelectionId = function(direction) {
					prevSelection = exportRoot.currentSelection
					if (direction == "next") {
						if (exportRoot.currentSelection == maxNav) {
							exportRoot.currentSelection = 1
						} else {
							exportRoot.currentSelection++
						}
					} else if (direction == "prev") {
						if (exportRoot.currentSelection == 1) {
							exportRoot.currentSelection = maxNav
						} else {
							exportRoot.currentSelection--
						}
					}
				}
				
				exportRoot.subHeadMoveCheck = function() {
				}
				
				exportRoot.scribbleAnim = function() {
						if (prevSelection > 0) {
							mc.scribble["scribble"+prevSelection].gotoAndPlay("out");
							mc.doodle["doodle"+prevSelection].gotoAndPlay("out");
		
						}
						gsap.delayedCall(0.5,function(){
							mc.scribble["scribble"+exportRoot.currentSelection].gotoAndPlay("in");
							mc.doodle["doodle"+exportRoot.currentSelection].gotoAndPlay("in");
						})
				}
				
				
						
			exportRoot.tl0 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl0.add("left");
			exportRoot.tl0.add("mid");
			exportRoot.tl0.add("right");
			exportRoot.tl0.pause();
			
			exportRoot.tl1 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl1.add("right");
			exportRoot.tl1.from(mc.screens.img1.sub1, 1, { x: "+=40", alpha: 0});
			exportRoot.tl1.from(mc.screens.img1.sub2, 1, { x: "+=70", alpha: 0},"<");
			exportRoot.tl1.from(mc.screens.img1.sub3, 1, { x: "+=100", alpha: 0},"<");
			exportRoot.tl1.add("mid");
			exportRoot.tl1.to(mc.screens.img1.sub3, 1, { x:  "-=40", alpha: 0});
			exportRoot.tl1.to(mc.screens.img1.sub2, 1, { x:  "-=70", alpha: 0},"<");
			exportRoot.tl1.to(mc.screens.img1.sub1, 1, { x:  "-=100", alpha: 0},"<");
			exportRoot.tl1.add("left");	
			exportRoot.tl1.pause();
			
			exportRoot.tl2 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl2.add("right");
			exportRoot.tl2.from(mc.screens.img2.sub1, 1, { x: "+=40", alpha: 0});
			exportRoot.tl2.from(mc.screens.img2.sub2, 1, { x: "+=70", alpha: 0},"<");
			exportRoot.tl2.from(mc.screens.img2.sub3, 1, { x: "+=100", alpha: 0},"<");
			exportRoot.tl2.add("mid");
			exportRoot.tl2.to(mc.screens.img2.sub3, 1, { x:  "-=40", alpha: 0});
			exportRoot.tl2.to(mc.screens.img2.sub2, 1, { x:  "-=70", alpha: 0},"<");
			exportRoot.tl2.to(mc.screens.img2.sub1, 1, { x:  "-=100", alpha: 0},"<");
			exportRoot.tl2.add("left");
			exportRoot.tl2.pause();
			
			exportRoot.tl3 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl3.add("right");
			exportRoot.tl3.from(mc.screens.img3.sub1, 1, { x: "+=40", alpha: 0});
			exportRoot.tl3.from(mc.screens.img3.sub2, 1, { x: "+=70", alpha: 0},"<");
			exportRoot.tl3.from(mc.screens.img3.sub3, 1, { x: "+=100", alpha: 0},"<");
			exportRoot.tl3.add("mid");
			exportRoot.tl3.to(mc.screens.img3.sub3, 1, { x:  "-=40", alpha: 0});
			exportRoot.tl3.to(mc.screens.img3.sub2, 1, { x:  "-=70", alpha: 0},"<");
			exportRoot.tl3.to(mc.screens.img3.sub1, 1, { x:  "-=100", alpha: 0},"<");
			exportRoot.tl3.add("left");
			exportRoot.tl3.pause();
			
			exportRoot.tl4 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl4.add("right");
			exportRoot.tl4.from(mc.screens.img4.sub1, 1, { x: "+=40", alpha: 0});
			exportRoot.tl4.from(mc.screens.img4.sub2, 1, { x: "+=70", alpha: 0},"<");
			exportRoot.tl4.from(mc.screens.img4.sub3, 1, { x: "+=100", alpha: 0},"<");
			exportRoot.tl4.add("mid");
			exportRoot.tl4.to(mc.screens.img4.sub3, 1, { x:  "-=40", alpha: 0});
			exportRoot.tl4.to(mc.screens.img4.sub2, 1, { x:  "-=70", alpha: 0},"<");
			exportRoot.tl4.to(mc.screens.img4.sub1, 1, { x:  "-=100", alpha: 0},"<");
			exportRoot.tl4.add("left");
			exportRoot.tl4.pause();
			
			exportRoot.tl5 = gsap.timeline({defaults:{ease:Power0.easeNone}});
			exportRoot.tl5.add("right");
			exportRoot.tl5.from(mc.screens.img5.sub1, 1, { x: "+=40", alpha: 0});
			exportRoot.tl5.from([mc.screens.img5.sub2, mc.screens.img5.sub2Shadow], 1, { x: "+=75", alpha: 0},"<");
			exportRoot.tl5.from(mc.screens.img5.sub3, 1, { x: "+=150", alpha: 0},"<");
			exportRoot.tl5.from(mc.screens.img5.sub2, .4, { rotation:"+=10"}, ">-.2");
			exportRoot.tl5.from(mc.screens.img5.sub3, .4, { rotation:"+=10"}, ">-.2");
			exportRoot.tl5.add("mid");
			exportRoot.tl5.to(mc.screens.img5.sub3, 1, { x:  "-=40", alpha: 0});
			exportRoot.tl5.to([mc.screens.img5.sub2, mc.screens.img5.sub2Shadow], 1, { x:  "-=70", alpha: 0},"<");
			exportRoot.tl5.to(mc.screens.img5.sub1, 1, { x:  "-=100", alpha: 0},"<");
			exportRoot.tl5.to(mc.screens.img5.sub2, .4, { rotation:"+=10"}, "<");
			exportRoot.tl5.to(mc.screens.img5.sub3, .4, { rotation:"+=10"}, "<+.2");
			exportRoot.tl5.add("left");
			exportRoot.tl5.pause();
			
				exportRoot.tlSubHeadMove = gsap.timeline();
		
				exportRoot.tlSubHeadMove.add("out");
				exportRoot.tlSubHeadMove.to(exportRoot.subheadline1, .5, { y: "-=20", ease:Power2.easeInOut});	
				exportRoot.tlSubHeadMove.add("in");
				
				exportRoot.tlSubHeadMove.pause();		
				
				init_headline_x = exportRoot.headline1[0].x
				
				exportRoot.nextScene = function() {
					exportRoot.subHeadMoveCheck(exportRoot.currentSelection);
								
					exportRoot.tlNext = gsap.timeline();
					exportRoot.tlNext.to(mc.screens["img"+exportRoot.currentSelection], 0, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]+initOffset/6, alpha: 0});		
					exportRoot.tlNext.to(exportRoot["headline"+exportRoot.currentSelection], 0, { x:init_headline_x+initOffset/3, alpha: 0});		
					
					if(prevSelection==0) {prevSelection=5;}
					exportRoot.tlNext.to(exportRoot["headline"+prevSelection], 0.6, { x:init_headline_x-initOffset/3, alpha: 0, ease:Power2.easeIn, stagger:0.03});
					exportRoot.tlNext.to(mc.screens["img"+prevSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]-initOffset/6, alpha: 0, ease:Power2.easeIn, onStart:function(){exportRoot["tl"+prevSelection].tweenFromTo("mid","left", {duration:0.6, ease:Power2.easeIn});}},"<+0.1");			
						
					exportRoot.tlNext.to(exportRoot["headline"+exportRoot.currentSelection], 0.6, { x:init_headline_x, alpha: 1, ease:Power2.easeOut, stagger:0.03},"<+0.3");
					exportRoot.tlNext.to(mc.screens["img"+exportRoot.currentSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"], alpha: 1, ease:Power2.easeOut, onStart:function(){exportRoot["tl"+exportRoot.currentSelection].tweenFromTo("right","mid", {duration:0.6, ease:Power2.easeOut});}, onComplete:function(){exportRoot.animInProgress=false;}},"<+0.2");
				}
				
				exportRoot.prevScene = function() {
					exportRoot.subHeadMoveCheck(exportRoot.currentSelection);
					
					exportRoot.tlBack = gsap.timeline();
					exportRoot.tlBack.to(mc.screens["img"+exportRoot.currentSelection], 0, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]-initOffset/6, alpha: 0});		
					exportRoot.tlBack.to(exportRoot["headline"+exportRoot.currentSelection], 0, { x:init_headline_x-initOffset/3, alpha: 0});		
					
					exportRoot.tlBack.to(mc.screens["img"+prevSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"]+initOffset/6, alpha: 0, ease:Power2.easeIn, onStart:function(){exportRoot["tl"+prevSelection].tweenFromTo("mid","right", {duration:0.6, ease:Power2.easeIn});}});			
					exportRoot.tlBack.to(exportRoot["headline"+prevSelection], 0.6, { x:init_headline_x+initOffset/3, alpha: 0, ease:Power2.easeIn, stagger:0.03},"<+0.1");
						
					exportRoot.tlBack.to(mc.screens["img"+exportRoot.currentSelection], 0.6, { x:exportRoot["init_img"+exportRoot.currentSelection+"_x"], alpha: 1, ease:Power2.easeOut, onStart:function(){exportRoot["tl"+exportRoot.currentSelection].tweenFromTo("left","mid", {duration:0.6, ease:Power2.easeOut});}, onComplete:function(){exportRoot.animInProgress=false}},"<+0.3");
					exportRoot.tlBack.to(exportRoot["headline"+exportRoot.currentSelection], 0.6, { x:init_headline_x, alpha: 1, ease:Power2.easeOut, stagger:0.03},"<+0.2");
		
				}
				
				exportRoot.animStart = function() {
					exportRoot.tlText = gsap.timeline();			
					exportRoot.tlText.to([exportRoot.headline1,exportRoot.headline2,exportRoot.headline3,exportRoot.headline4,exportRoot.headline5,mc.screens.img1,mc.screens.img2,mc.screens.img3,mc.screens.img4,mc.screens.img5], 0, { alpha: 0, onStart:function(){exportRoot.nextScene(), exportRoot.gotoNextNav();}});
					exportRoot.tlText.to(exportRoot.subheadline1, 0, {x:"+=150", alpha: 0});
					exportRoot.tlText.to(exportRoot.subheadline1, .8, { x: "-=150", alpha: 1, ease:Power4.easeOut, stagger:0.05},">+.45");
					exportRoot.tlText.from(exportRoot.mainMC.nav, .8, { alpha:0, ease:Power4.easeOut},"<+.1");
					exportRoot.tlText.from([mc.cta,mc.txtCta], { duration: 0.8, x: "+=120", ease:Power4.easeOut, onStart:function(){mc.scribble.scribble1.play(),mc.doodle.doodle1.play();}}, ">-0.6");
					//exportRoot.tlText.pause();
				}
					
				mc.logo_intro.gotoAndPlay(1);
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9968,0.9997,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,-143.8,508,393.70000000000005);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#DBDBDD",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622719431664", id:"M365_FY22Q1BTS_USA_728x90_BAN_INTCarousel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;