(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[395,907,102,105],[395,734,237,171],[532,358,98,159],[0,0,583,356],[0,734,393,268],[0,358,530,374]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Group242x1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Group60 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.popup1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pptLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group242x1();
	this.instance.setTransform(12.95,-9.2,0.3438,0.3438);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptLogo, new cjs.Rectangle(1.4,-9.6,94.39999999999999,95.69999999999999), null);


(lib.outter_outline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AxCNPQgYAAgRgRQgQgRAAgXIAA4rQAAgXAQgRQARgRAYAAMAiGAAAQAXAAARARQAQARAAAXIAAOPQABAXgRARQgRARgXAAQgYAAgRgRQgQgRAAgXIAAtWMggUAAAIAAW5IQDAAQAXAAARAQQAQARAAAYQAAAXgQARQgRARgXAAg");
	this.shape.setTransform(114.8257,84.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outter_outline, new cjs.Rectangle(0,0,229.7,169.4), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.222,21.222,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6132,21.222,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.222,6.6132,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6132,6.6132,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1754,14.0578,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9643,13.9128,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.5018,13.9128,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mic_inner = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AiaA5QgXAAgRgQQgRgSAAgXQAAgWARgRQARgRAXAAIE1AAQAXAAARARQARARAAAWQAAAXgRASQgRAQgXAAg");
	this.shape.setTransform(50.4777,126.5529);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgoCCQgQgRAAgYIAAixQAAgYAQgQQASgRAWAAQAYAAAQARQARAQAAAYIAACxQAAAXgRASQgQAQgYAAQgWAAgSgQg");
	this.shape_1.setTransform(50.5027,113.1527);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ai8ERQiDAAhdhcQhchdAAiBIAAiuQAAgYARgRQARgQAXAAQAXAAASAQQAQARAAAYIAACuQAABSA7A7QA7A7BUAAIF5AAQBUAAA7g7QA7g7AAhSIAAiuQAAgYAQgRQARgQAYAAQAYAAAQAQQARARAAAYIAACuQgBCBhbBdQhdBciDAAg");
	this.shape_2.setTransform(50.5027,79.9272);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AiFGlQg1AAgmgmQgmglAAg1IAApJQAAg1AmglQAmgmA1AAIELAAQA2AAAlAmQAmAlAAA1IAAJJQAAA1gmAlQgmAmg1AAg");
	this.shape_3.setTransform(50.4777,42.1016);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mic_inner, new cjs.Rectangle(0,0,101,132.3), null);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_47 = new cjs.Graphics().p("AJbDZQgKgYgBggQAAghAKgYQAKgXAOAAIEXgCQAOgBAKAXQALAYAAAhQAAAhgKAXQgKAXgOABIkXACIAAAAQgOAAgKgXg");
	var mask_graphics_48 = new cjs.Graphics().p("AJWDZQgKgYAAghQgBghAKgXQALgYAOAAIEhgDQAPAAALAYQAKAXABAhQAAAhgKAYQgLAXgOAAIkhADIAAAAQgPAAgLgXg");
	var mask_graphics_49 = new cjs.Graphics().p("AJSDZQgLgYgBghQAAghAKgYQALgYAPAAIEsgDQAQAAALAXQALAYAAAhQAAAigKAXQgLAYgPAAIksADIAAAAQgPAAgLgXg");
	var mask_graphics_50 = new cjs.Graphics().p("AJMDZQgLgYgBghQAAgiALgYQALgXAQgBIE4gDQAQAAAMAXQALAYABAhQAAAigLAYQgLAYgQAAIk4ADIgBAAQgPAAgMgXg");
	var mask_graphics_51 = new cjs.Graphics().p("AJGDZQgMgYgBghQAAgiALgZQAMgXARgBIFGgEQARAAAMAYQAMAYABAhQAAAigLAYQgMAYgRABIlGAEIgBAAQgQAAgMgYg");
	var mask_graphics_52 = new cjs.Graphics().p("AI/DZQgNgYAAgiQgBgiAMgYQAMgZASAAIFWgFQASAAAMAYQANAYABAiQAAAigMAYQgMAZgRAAIlXAFIAAAAQgRAAgNgYg");
	var mask_graphics_53 = new cjs.Graphics().p("AI3DZQgNgYAAgiQgBgjANgYQAMgZATAAIFngGQATAAANAYQAOAYAAAjQABAigNAZQgNAYgSABIloAFIAAAAQgSAAgOgYg");
	var mask_graphics_54 = new cjs.Graphics().p("AIvDaQgOgZgBgjQAAgiANgZQANgZAUAAIF7gHQATAAAOAYQAOAYABAjQABAjgOAZQgNAZgTAAIl7AHIgBAAQgTAAgOgYg");
	var mask_graphics_55 = new cjs.Graphics().p("AImDaQgPgZgBgjQgBgjAOgaQAOgZAVAAIGQgIQAVAAAOAYQAPAZABAjQABAjgOAaQgOAZgVAAImQAIIAAAAQgUAAgPgYg");
	var mask_graphics_56 = new cjs.Graphics().p("AIcDaQgQgZgBgjQgBgkAPgaQAPgZAVgBIGogJQAVAAAQAYQAQAaABAjQABAkgPAZQgPAagVAAImoAKIgBAAQgVAAgPgZg");
	var mask_graphics_57 = new cjs.Graphics().p("AIRDaQgRgZgBgkQgBgkAQgaQAPgaAXAAIHBgLQAXgBAQAZQARAaABAkQABAkgQAZQgPAbgXAAInBALIgBAAQgWAAgQgZg");
	var mask_graphics_58 = new cjs.Graphics().p("AIFDaQgSgZgBgkQgBglAQgbQARgaAYAAIHcgNQAYgBASAZQASAaABAlQABAkgQAbQgRAagYABIncANIgBAAQgYAAgRgag");
	var mask_graphics_59 = new cjs.Graphics().p("AH4DbQgTgagBglQgBglARgbQASgbAagBIH5gPQAaAAASAZQAUAaABAlQABAmgSAaQgRAbgaABIn5APIgCAAQgYAAgTgZg");
	var mask_graphics_60 = new cjs.Graphics().p("AHqDbQgUgagBgmQgBglASgcQATgbAbgBIIZgRQAbgBAUAaQAVAaABAmQABAlgTAcQgSAbgbABIoZASIgCAAQgaAAgUgag");
	var mask_graphics_61 = new cjs.Graphics().p("AHcDcQgWgbgBgmQgBgmATgdQAUgbAdgBII6gVQAdgBAVAbQAWAaABAnQACAmgUAcQgUAcgdABIo5AUIgDAAQgbAAgVgZg");
	var mask_graphics_62 = new cjs.Graphics().p("AHNDcQgXgbgCgnQgBgnAVgcQAUgdAfgBIJdgYQAegBAXAbQAXAbACAnQABAngVAcQgUAdgfABIpcAYIgDAAQgdAAgWgag");
	var mask_graphics_63 = new cjs.Graphics().p("AG9DcQgYgbgCgnQgBgoAVgdQAWgdAhgCIKAgbQAhgBAYAbQAZAbABAoQACAngWAdQgWAeggABIqBAbIgDAAQgfAAgXgag");
	var mask_graphics_64 = new cjs.Graphics().p("AGtDdQgZgcgCgoQgCgoAXgeQAXgeAjgBIKlgfQAigCAaAbQAaAcACAoQACApgYAdQgXAegiACIqlAfIgEAAQggAAgZgag");
	var mask_graphics_65 = new cjs.Graphics().p("AGdDdQgbgbgCgqQgCgpAYgeQAZgeAkgCILKgkQAlgBAbAbQAbAcACApQACApgYAfQgZAegkACIrKAjIgEAAQgiAAgagag");
	var mask_graphics_66 = new cjs.Graphics().p("AGNDeQgdgcgCgqQgCgqAZgfQAagfAmgCILwgoQAmgCAcAcQAdAcADAqQACAqgaAfQgZAfgnACIrvAoIgFAAQgjAAgbgag");
	var mask_graphics_67 = new cjs.Graphics().p("AF9DeQgegcgCgrQgDgqAbggQAbgfAogDIMUgrQAogDAeAcQAeAcADArQACAqgbAgQgbAggoACIsTAsIgGABQglAAgcgbg");
	var mask_graphics_68 = new cjs.Graphics().p("AFuDeQgggcgCgrQgDgrAcghQAcggAqgCIM3gxQAqgCAfAbQAgAdADArQACArgcAgQgbAhgqADIs3AxIgHAAQgmAAgdgbg");
	var mask_graphics_69 = new cjs.Graphics().p("AFfDfQghgdgCgsQgDgrAdgiQAdggAsgDINZg1QArgDAhAcQAhAdADAsQADArgeAhQgcAhgsADItZA2IgIABQgnAAgegbg");
	var mask_graphics_70 = new cjs.Graphics().p("AFRDfQgigdgDgsQgDgsAegiQAegiAugDIN5g6QAugDAhAcQAjAeADAsQADAtgeAhQgeAiguADIt5A7IgJAAQgoAAgfgbg");
	var mask_graphics_71 = new cjs.Graphics().p("AFEDgQgkgegDgtQgDgsAfgjQAfgiAvgDIOZg/QAvgDAjAdQAjAdAEAtQADAtggAiQgeAigvADIuZBAIgJAAQgpAAgggag");
	var mask_graphics_72 = new cjs.Graphics().p("AE3DgQgkgegEgtQgDgtAggjQAggjAxgDIO1hEQAwgDAlAdQAlAdADAuQADAtggAjQggAigwAEIu2BEIgKABQgqAAghgbg");
	var mask_graphics_73 = new cjs.Graphics().p("AErDgQglgdgEguQgDguAhgkQAhgjAygDIPQhIQAygEAlAeQAmAdAEAuQADAughAjQghAjgxAEIvRBJIgLAAQgrAAgigbg");
	var mask_graphics_74 = new cjs.Graphics().p("AEgDhQgmgegEgvQgDguAhgkQAigjAzgEIPqhNQAzgEAmAeQAoAeADAuQAEAugiAkQgiAkgzAEIvpBNIgMAAQgsAAgjgag");
	var mask_graphics_75 = new cjs.Graphics().p("AEWDhQgngegEgvQgEgvAjgkQAigkA1gEIQBhRQA0gEAnAeQAoAeAEAvQAEAugjAkQgiAlg0AEIwBBRIgNABQgsAAgkgbg");
	var mask_graphics_76 = new cjs.Graphics().p("AENDhQgogegEgvQgEgvAjglQAjglA2gEIQWhUQA2gFAoAeQApAfAEAuQAEAwgkAkQgjAlg1AEIwXBWIgNAAQgtAAgkgbg");
	var mask_graphics_77 = new cjs.Graphics().p("AEEDhQgpgegEgvQgEgwAkglQAkglA2gFIQrhYQA3gEApAeQApAfAEAuQAEAwgkAlQgjAlg3AFIwrBZIgNAAQguAAglgbg");
	var mask_graphics_78 = new cjs.Graphics().p("AD8DiQgpgfgFgwQgEgwAkglQAlglA3gFIQ+hcQA3gEAqAeQAqAfAEAvQAFAwglAlQgkAmg3AEIw+BdIgOABQgvAAglgbg");
	var mask_graphics_79 = new cjs.Graphics().p("AD1DiQgqgfgFgwQgEgwAlgmQAlgmA4gEIROhfQA5gFAqAeQArAfAEAwQAFAwgmAlQgkAmg4AFIxPBgIgPABQgvAAglgbg");
	var mask_graphics_80 = new cjs.Graphics().p("ADuDiQgrgegEgxQgEgxAlgmQAlgmA5gFIRehiQA5gFArAfQAsAfAEAwQAFAwgmAmQglAmg5AFIxeBjIgQABQgvAAgmgbg");
	var mask_graphics_81 = new cjs.Graphics().p("ADoDiQgrgegFgxQgEgxAlgnQAmgmA6gFIRshlQA6gFAsAfQAsAfAEAwQAFAxgmAmQgmAmg6AGIxsBlIgQABQgwAAgmgbg");
	var mask_graphics_82 = new cjs.Graphics().p("ADjDiQgtgegEgxQgFgxAmgnQAngnA6gFIR5hnQA7gGAsAfQAtAgAEAwQAFAxgnAmQgmAng6AFIx5BoIgRABQgwAAgmgbg");
	var mask_graphics_83 = new cjs.Graphics().p("ADeDjQgtgfgFgxQgEgyAmgnQAngmA7gGISFhqQA7gFAtAfQAtAfAFAwQAEAygnAmQgmAng7AGIyFBrIgRAAQgxAAgmgag");
	var mask_graphics_84 = new cjs.Graphics().p("ADZDjQgtgfgFgyQgEgxAmgnQAngnA8gGISQhsQA7gFAtAfQAuAfAFAxQAEAxgnAnQgmAng8AGIyQBtIgRAAQgxAAgngag");
	var mask_graphics_85 = new cjs.Graphics().p("ADVDjQgugfgFgyQgEgxAngoQAngnA8gGISahtQA8gGAtAfQAvAfAEAxQAFAygoAnQgmAng9AGIyZBvIgSABQgxAAgngbg");
	var mask_graphics_86 = new cjs.Graphics().p("ADRDjQgugfgFgyQgEgyAngnQAognA8gGISihwQA9gGAuAfQAuAgAFAxQAFAxgoAoQgnAng9AGIyiBxIgSABQgyAAgngbg");
	var mask_graphics_87 = new cjs.Graphics().p("ADODjQgvgfgEgyQgFgyAngoQAognA9gGISqhxQA9gGAuAfQAvAfAFAxQAFAygoAoQgoAog8AFIyrBzIgSABQgyAAgngbg");
	var mask_graphics_88 = new cjs.Graphics().p("ADLDjQgvgfgFgyQgFgyAogoQAogoA+gFISxhzQA9gGAuAfQAwAfAFAxQAEAzgoAnQgoAog9AGIyxB0IgTABQgyAAgngbg");
	var mask_graphics_89 = new cjs.Graphics().p("ADIDjQgvgfgFgyQgFgyAogoQApgoA9gGIS4h0QA9gGAvAfQAvAfAFAyQAFAygoAoQgoAog+AGIy3B1IgTABQgyAAgogbg");
	var mask_graphics_90 = new cjs.Graphics().p("ADFDjQgugfgFgyQgFgyAogpQAognA+gGIS9h2QA+gGAvAfQAwAgAEAyQAFAygoAnQgoAog+AHIy9B2IgTABQgyAAgpgbg");
	var mask_graphics_91 = new cjs.Graphics().p("ADDDjQgvgfgFgyQgFgzApgoQAogoA+gGITCh2QA+gGAvAfQAwAfAFAzQAFAxgpAoQgoAog+AHIzCB3IgTABQgyAAgpgbg");
	var mask_graphics_92 = new cjs.Graphics().p("ADCDkQgwgggFgyQgFgzApgoQApgoA+gGITGh4QA+gGAvAgQAwAfAFAzQAFAxgpAoQgoApg+AGIzGB4IgUABQgyAAgogag");
	var mask_graphics_93 = new cjs.Graphics().p("ADADkQgvgggFgyQgFgzAogoQApgoA/gGITJh5QA+gGAwAfQAwAgAFAzQAFAxgpAoQgpApg+AGIzJB5IgUABQgyAAgpgag");
	var mask_graphics_94 = new cjs.Graphics().p("AC/DkQgwgggFgyQgFgzApgoQApgoA/gHITMh4QA+gHAwAgQAwAfAFAzQAFAygpAoQgpAog+AGIzMB6IgUABQgzAAgogag");
	var mask_graphics_95 = new cjs.Graphics().p("AC+DkQgwgggFgyQgFgzApgpQApgoA/gGITOh5QA/gGAvAfQAxAgAFAyQAFAygpAoQgpApg/AGIzOB6IgUABQgyAAgpgag");
	var mask_graphics_96 = new cjs.Graphics().p("AC9DkQgvgggFgyQgGgzApgpQApgoA/gGITQh6QA/gGAwAfQAwAgAFAzQAFAygpAoQgpAog+AHIzQB6IgVABQgyAAgpgag");
	var mask_graphics_97 = new cjs.Graphics().p("AC9DkQgwgggFgyQgFgzApgpQApgoA/gGITRh6QA/gGAwAfQAwAgAFAyQAFAygpAoQgpApg/AGIzRB7IgUABQgzAAgogag");
	var mask_graphics_98 = new cjs.Graphics().p("AC8DkQgvgggFgyQgFgzAogpQAqgoA+gGITSh6QA/gGAwAfQAxAgAFAyQAFAygqAoQgoApg/AGIzSB7IgUABQgzAAgpgag");
	var mask_graphics_99 = new cjs.Graphics().p("AC/DlQgwgggFgyQgFgzAogpQAqgoA/gGITSh6QA/gHAvAgQAxAfAFAzQAFAygpAoQgpApg/AGIzSB7IgUABQgzAAgogag");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(47).to({graphics:mask_graphics_47,x:93.9942,y:23.9829}).wait(1).to({graphics:mask_graphics_48,x:94.7552,y:24.0027}).wait(1).to({graphics:mask_graphics_49,x:95.6165,y:24.0248}).wait(1).to({graphics:mask_graphics_50,x:96.5857,y:24.0495}).wait(1).to({graphics:mask_graphics_51,x:97.6704,y:24.077}).wait(1).to({graphics:mask_graphics_52,x:98.8783,y:24.1073}).wait(1).to({graphics:mask_graphics_53,x:100.2174,y:24.1406}).wait(1).to({graphics:mask_graphics_54,x:101.6955,y:24.177}).wait(1).to({graphics:mask_graphics_55,x:103.3202,y:24.2165}).wait(1).to({graphics:mask_graphics_56,x:105.0977,y:24.2592}).wait(1).to({graphics:mask_graphics_57,x:107.0328,y:24.305}).wait(1).to({graphics:mask_graphics_58,x:109.1277,y:24.3538}).wait(1).to({graphics:mask_graphics_59,x:111.3809,y:24.4055}).wait(1).to({graphics:mask_graphics_60,x:113.7859,y:24.4596}).wait(1).to({graphics:mask_graphics_61,x:116.3305,y:24.5158}).wait(1).to({graphics:mask_graphics_62,x:118.9958,y:24.5734}).wait(1).to({graphics:mask_graphics_63,x:121.7559,y:24.6318}).wait(1).to({graphics:mask_graphics_64,x:124.5795,y:24.6902}).wait(1).to({graphics:mask_graphics_65,x:127.4311,y:24.7478}).wait(1).to({graphics:mask_graphics_66,x:130.2738,y:24.8038}).wait(1).to({graphics:mask_graphics_67,x:133.0724,y:24.8577}).wait(1).to({graphics:mask_graphics_68,x:135.7955,y:24.9089}).wait(1).to({graphics:mask_graphics_69,x:138.4176,y:24.957}).wait(1).to({graphics:mask_graphics_70,x:140.9194,y:25.0019}).wait(1).to({graphics:mask_graphics_71,x:143.2883,y:25.0435}).wait(1).to({graphics:mask_graphics_72,x:145.5169,y:25.0819}).wait(1).to({graphics:mask_graphics_73,x:147.6025,y:25.1171}).wait(1).to({graphics:mask_graphics_74,x:149.5459,y:25.1493}).wait(1).to({graphics:mask_graphics_75,x:151.3505,y:25.1787}).wait(1).to({graphics:mask_graphics_76,x:153.0211,y:25.2054}).wait(1).to({graphics:mask_graphics_77,x:154.5639,y:25.2298}).wait(1).to({graphics:mask_graphics_78,x:155.9852,y:25.2519}).wait(1).to({graphics:mask_graphics_79,x:157.2918,y:25.2719}).wait(1).to({graphics:mask_graphics_80,x:158.4904,y:25.2901}).wait(1).to({graphics:mask_graphics_81,x:159.5875,y:25.3066}).wait(1).to({graphics:mask_graphics_82,x:160.5893,y:25.3215}).wait(1).to({graphics:mask_graphics_83,x:161.5017,y:25.3349}).wait(1).to({graphics:mask_graphics_84,x:162.3303,y:25.347}).wait(1).to({graphics:mask_graphics_85,x:163.08,y:25.3578}).wait(1).to({graphics:mask_graphics_86,x:163.7557,y:25.3675}).wait(1).to({graphics:mask_graphics_87,x:164.3619,y:25.3762}).wait(1).to({graphics:mask_graphics_88,x:164.9026,y:25.3839}).wait(1).to({graphics:mask_graphics_89,x:165.3816,y:25.3906}).wait(1).to({graphics:mask_graphics_90,x:165.8024,y:25.3966}).wait(1).to({graphics:mask_graphics_91,x:166.1682,y:25.4017}).wait(1).to({graphics:mask_graphics_92,x:166.4822,y:25.4061}).wait(1).to({graphics:mask_graphics_93,x:166.7469,y:25.4097}).wait(1).to({graphics:mask_graphics_94,x:166.965,y:25.4128}).wait(1).to({graphics:mask_graphics_95,x:167.1389,y:25.4152}).wait(1).to({graphics:mask_graphics_96,x:167.2708,y:25.417}).wait(1).to({graphics:mask_graphics_97,x:167.3627,y:25.4183}).wait(1).to({graphics:mask_graphics_98,x:167.4166,y:25.419}).wait(1).to({graphics:mask_graphics_99,x:167.6507,y:25.51}).wait(1));

	// Layer_2 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape.setTransform(236.1662,26.9665,0.6435,0.6435);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(47).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_29 = new cjs.Graphics().p("APVBJQgLgEgKgKQgLgKgEgKQgEgLAFgFIBbheQAFgEAKADQALAEAKAKQALAKAEAKQAEALgFAFIhbBeQgDACgEAAIgIgBg");
	var mask_1_graphics_30 = new cjs.Graphics().p("APNBNQgKgEgLgKQgKgKgEgKQgEgLAFgFIBhhlQAFgFALADQALAEAKAKQALAKAEAKQADALgFAFIhhBlQgDADgFAAIgIgBg");
	var mask_1_graphics_31 = new cjs.Graphics().p("APFBRQgLgDgLgKQgKgKgDgLQgEgLAFgGIBphrQAFgGALADQALADALAKQAKAKAEALQADALgFAGIhpBrQgDAEgGAAIgHgBg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AO7BWQgLgDgLgKQgKgKgDgLQgEgLAGgGIBxh1QAFgGAMADQALADALAKQAKAKADALQAEALgGAGIhxB1QgEAEgGAAIgHgBg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AOxBbQgMgCgLgKQgKgKgDgMQgDgLAGgHIB6h9QAGgHAMADQALACALAKQAKAKADAMQADALgGAHIh5B9QgFAFgHAAIgGgBg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AOlBhQgMgCgKgKQgLgKgCgMQgDgMAHgHICDiHQAGgHANACQAMACAKAKQAKAKADAMQADAMgHAHIiDCHQgFAGgJAAIgFgBg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AOZBoQgNgCgKgKQgKgKgDgMQgCgNAHgHICOiTQAHgHAMABQANACAKAKQALAKACAMQACANgHAHIiOCTQgFAGgKAAIgEAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AOMBuQgNgBgKgKQgLgKgBgNQgCgNAIgIICXidQAIgIANABQANABAKAKQALAKACANQABANgHAIIiYCdQgHAHgKAAIgEAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AN/B1QgNgBgLgKQgKgKgBgNQgCgNAIgJICjipQAJgJANABQANABAKAKQALAKABANQACANgJAJIiiCpQgIAIgLAAIgDAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("ANyB7QgOAAgKgKQgKgKgBgOQgCgNAJgJICui1QAJgJAOABQANAAALAKQAKAKABAOQABANgJAJIiuC1QgIAIgNAAIgBAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("ANlCCQgOAAgLgKQgKgKgBgOQAAgOAJgKIC5i/QAJgKAOAAQAOAAALAKQAKAKABAOQAAAOgJAKIi5C/QgJAKgOAAIAAAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AM/B/QgKgJgBgPQAAgOAKgLIDEjLQAKgKAOAAQAOgBALAKQAKAKABAPQAAAOgKAKIjEDLQgKALgOAAIgBAAQgOAAgKgKg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AMyCHQgKgKAAgPQAAgPAKgLIDOjWQALgLAPAAQAOgBALAKQAKAKAAAPQAAAOgKALIjODWQgLALgPABIgCAAQgNAAgKgJg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AMmCNQgLgKABgPQAAgPALgMIDYjgQALgLAPgBQAPgBALAKQAKAJAAAQQgBAPgLALIjYDhQgLALgPABIgDAAQgNAAgJgJg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AMaCUQgKgKABgQQAAgPAMgMIDhjqQAMgMAPgCQAQgBAKAKQAKAKAAAPQgBAQgMAMIjhDqQgMAMgPABIgEAAQgNAAgJgIg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AMPCaQgKgKABgQQABgQAMgNIDqjzQAMgMAQgCQAQgCAKAKQAKAKgBAQQgBAQgMAMIjqD0QgMAMgQACIgEAAQgNAAgJgIg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AMFCfQgKgKABgQQABgQANgNIDyj8QAMgNARgCQAQgCAKAKQAKAKgBAQQgBAQgNANIjyD8QgMANgQACIgGAAQgMAAgJgIg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AL8CkQgKgKACgRQABgQANgNID5kDQANgOAQgCQARgCAKAKQAKAKgBAQQgCAQgNAOIj5EDQgNANgQACIgGABQgMAAgJgIg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AL0CoQgKgKACgRQACgQANgOID/kKQANgNARgDQARgCAKAKQAKAKgBAQQgCARgNAOIkAEJQgNAOgRACIgGABQgMAAgJgIg");
	var mask_1_graphics_48 = new cjs.Graphics().p("ALwCqQgKgKACgRQACgRANgOIEFkPQANgOARgDQARgDAKAKQALAKgCARQgCARgOAOIkFEPQgNAOgRADIgHABQgMAAgIgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_1_graphics_29,x:108.9581,y:6.7536}).wait(1).to({graphics:mask_1_graphics_30,x:108.9291,y:7.1592}).wait(1).to({graphics:mask_1_graphics_31,x:108.8959,y:7.6384}).wait(1).to({graphics:mask_1_graphics_32,x:108.8595,y:8.1829}).wait(1).to({graphics:mask_1_graphics_33,x:108.8207,y:8.7838}).wait(1).to({graphics:mask_1_graphics_34,x:108.7806,y:9.4316}).wait(1).to({graphics:mask_1_graphics_35,x:108.74,y:10.1164}).wait(1).to({graphics:mask_1_graphics_36,x:108.6997,y:10.8281}).wait(1).to({graphics:mask_1_graphics_37,x:108.6603,y:11.5566}).wait(1).to({graphics:mask_1_graphics_38,x:108.6224,y:12.2919}).wait(1).to({graphics:mask_1_graphics_39,x:108.5863,y:13.0199}).wait(1).to({graphics:mask_1_graphics_40,x:108.5525,y:13.7093}).wait(1).to({graphics:mask_1_graphics_41,x:108.521,y:14.3799}).wait(1).to({graphics:mask_1_graphics_42,x:108.4914,y:15.0234}).wait(1).to({graphics:mask_1_graphics_43,x:108.4646,y:15.6321}).wait(1).to({graphics:mask_1_graphics_44,x:108.4404,y:16.1992}).wait(1).to({graphics:mask_1_graphics_45,x:108.4189,y:16.7186}).wait(1).to({graphics:mask_1_graphics_46,x:108.4001,y:17.1849}).wait(1).to({graphics:mask_1_graphics_47,x:108.384,y:17.5934}).wait(1).to({graphics:mask_1_graphics_48,x:108.6169,y:17.7518}).wait(52));

	// Layer_2 copy
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape_1.setTransform(236.1662,26.9665,0.6435,0.6435);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(29).to({_off:false},0).wait(71));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AJRCVQgGgLgEgRQgEgRABgNQABgNAFgBIBjgWQAFgBAGALQAGALAEARQAEARgBANQgBANgFABIhjAWIAAAAQgFAAgGgKg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AJRCVQgGgLgEgRQgEgRABgNQABgNAFgBIBjgWQAFgBAGALQAHALADARQAEARgBANQgBANgFABIhjAWIgBAAQgFAAgFgKg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AJQCVQgHgLgDgRQgEgRABgNQABgNAFgBIBmgXQAFgBAGALQAGAMAEARQAEARgBAMQgBANgFABIhmAXIgBAAQgFAAgFgKg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AJNCVQgGgLgEgRQgEgRACgNQABgNAFgBIBqgYQAGgBAGALQAHALADARQAEARgBANQgBANgGABIhqAYIgBAAQgFAAgGgKg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AJKCVQgHgMgDgRQgEgQABgNQACgNAGgCIBwgYQAGgCAGALQAHAMAEARQAEARgCAMQgBANgGACIhwAYIgBABQgGAAgGgKg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AJGCUQgHgLgEgRQgEgRACgNQACgNAGgBIB5gbQAGgBAHALQAIALADARQAEARgCANQgBANgHABIh5AbIgBAAQgGAAgGgKg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AJACUQgIgLgDgRQgEgRACgNQACgNAHgBICFgeQAHgBAIALQAHALAEARQAEARgDANQgCANgHABIiFAeIgCAAQgGAAgGgKg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AI4CUQgIgLgEgRQgDgRACgNQADgNAIgCICUghQAIgBAIAKQAIALAEARQADARgCANQgDAOgIABIiUAhIgCAAQgHAAgHgJg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AIuCUQgIgLgEgRQgEgRAEgNQADgOAJgCICoglQAIgCAJALQAJALADARQAEARgDANQgEAOgIABIioAlIgDABQgHAAgIgJg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AIjCTQgKgKgEgRQgDgRAEgOQAEgNAKgCIC/grQAKgCAKALQAJAKAEARQAEARgFAOQgEANgKACIi/ArIgDAAQgIAAgIgJg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AIUCTQgKgLgEgQQgEgRAGgOQAFgOALgCIDcgxQALgCALAKQAKAKAEARQAEARgGAOQgFAOgLACIjcAxIgEAAQgJAAgJgIg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AIECSQgMgKgEgRQgDgRAGgOQAHgOAMgDID9g3QANgDAMAKQAMAKADARQAEARgGAOQgHAOgNADIj8A3IgGABQgKAAgJgIg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AHxCRQgNgJgEgRQgDgRAHgPQAIgOAPgDIEihAQAPgDANAJQANAKAEARQADARgIAOQgHAPgPADIkiBAIgHABQgLAAgKgIg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AHdCRQgOgKgEgRQgEgRAJgOQAKgPAQgEIFKhHQARgEAOAIQAPAKAEARQADARgJAOQgJAPgRAEIlJBIIgKACQgLAAgLgHg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AHJCQQgQgJgEgRQgDgRAKgPQALgPATgEIFxhRQATgEAQAJQAQAJAEAQQADARgKAPQgLAPgTAEIlxBSIgMABQgMAAgLgGg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AG2CPQgSgIgDgRQgEgRAMgQQAMgPAVgFIGXhZQAVgEARAJQASAIAEAQQADARgMAQQgMAPgUAFImYBaQgHABgHAAQgNAAgLgGg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AGkCPQgTgJgDgRQgEgRANgPQAOgQAWgFIG7hhQAWgFATAJQATAIADARQAEAQgNAQQgOAPgWAFIm7BiQgIACgIAAQgNAAgMgFg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AGUCOQgTgIgEgRQgEgRAOgQQAPgQAYgFIHahoQAYgFAUAIQAUAJADAQQAEAQgOAQQgPAQgYAFInaBpQgJACgJAAQgOAAgMgFg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AGGCNQgUgIgEgQQgEgRAQgRQAPgQAagFIH1huQAZgFAVAIQAVAIADARQAEARgPAPQgQAQgZAFIn1BvQgLACgJAAQgOAAgNgFg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AF7CNQgWgIgDgRQgEgRAQgQQAQgQAbgGIIMhzQAbgGAVAIQAWAIAEARQAEARgRAPQgQAQgbAGIoMB0QgLADgLAAQgOAAgMgFg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AFxCNQgWgIgEgRQgEgRARgQQARgRAcgGIIgh3QAcgGAWAIQAWAHAEARQAEARgSAQQgQAQgcAGIogB4QgMADgMAAQgOAAgMgEg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AFnCNQgWgIgEgRQgEgRASgQQARgRAdgGIIxh7QAcgGAXAHQAXAIAEARQAEARgSAQQgRAQgdAGIoxB8QgNADgMAAQgOAAgNgEg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:70.8937,y:15.8993}).wait(10).to({graphics:mask_2_graphics_10,x:70.9412,y:15.9033}).wait(1).to({graphics:mask_2_graphics_11,x:71.1091,y:15.8952}).wait(1).to({graphics:mask_2_graphics_12,x:71.4086,y:15.8807}).wait(1).to({graphics:mask_2_graphics_13,x:71.8599,y:15.8589}).wait(1).to({graphics:mask_2_graphics_14,x:72.4867,y:15.8287}).wait(1).to({graphics:mask_2_graphics_15,x:73.3176,y:15.7889}).wait(1).to({graphics:mask_2_graphics_16,x:74.3855,y:15.7381}).wait(1).to({graphics:mask_2_graphics_17,x:75.7263,y:15.6747}).wait(1).to({graphics:mask_2_graphics_18,x:77.3754,y:15.5972}).wait(1).to({graphics:mask_2_graphics_19,x:79.3584,y:15.5049}).wait(1).to({graphics:mask_2_graphics_20,x:81.6749,y:15.398}).wait(1).to({graphics:mask_2_graphics_21,x:84.2774,y:15.2791}).wait(1).to({graphics:mask_2_graphics_22,x:87.0589,y:15.1534}).wait(1).to({graphics:mask_2_graphics_23,x:89.8689,y:15.0278}).wait(1).to({graphics:mask_2_graphics_24,x:92.559,y:14.9088}).wait(1).to({graphics:mask_2_graphics_25,x:95.0241,y:14.8007}).wait(1).to({graphics:mask_2_graphics_26,x:97.2142,y:14.7054}).wait(1).to({graphics:mask_2_graphics_27,x:99.1212,y:14.6231}).wait(1).to({graphics:mask_2_graphics_28,x:100.7607,y:14.5527}).wait(1).to({graphics:mask_2_graphics_29,x:102.1579,y:14.4931}).wait(1).to({graphics:mask_2_graphics_30,x:103.2679,y:14.4881}).wait(70));

	// Layer_2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape_2.setTransform(236.1662,26.9665,0.6435,0.6435);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,329.9,47.2);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.inner_outlinec = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AsRJJQgYAAgQgRQgHgHgEgIQgGgLAAgOIAAwfQAAgXARgRQAQgRAYAAIYjAAQAYAAAQARQARARAAAXIAACYQAAAXgQARQgRARgYAAQgXAAgRgRQgRgQAAgYIAAhfI2xAAIAAOtIKEAAQAYAAARARQAQAQAAAYQAAAOgGALQgEAIgGAHQgRARgYAAg");
	this.shape.setTransform(84.2763,58.4761);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.inner_outlinec, new cjs.Rectangle(0,0,168.6,117), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.greenLineC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7A9E3E").s().p("AtpM9QAAlRCDk0QB+koDljlQDmjmEoh+QE0iDFRAAQApAAAxADIAAF8Qg0gDgmAAQkDAAjuBlQjlBhiwCxQixCwhhDlQhlDuAAEDg");
	this.shape.setTransform(34.5388,32.7699,0.3953,0.3953);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.greenLineC, new cjs.Rectangle(0,0,69.1,65.6), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group60();
	this.instance.setTransform(0,0,0.4899,0.4899);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(0,0,116.1,83.8), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS();
	this.instance.setTransform(-10.7,20.35,0.7981,0.7981);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(-10.7,20.4,425.09999999999997,298.5), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.blankchart_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F0EFEF").s().p("AT+M9QAAkDhljuQhhjlixiwQixixjlhhQjthlkEAAQkCAAjuBlQjlBhixCxQixCwhhDlQhlDuAAEDIl8AAQAAlRCDk0QB+koDljlQDmjmEph+QE0iDFQAAQFRAAE0CDQEpB+DmDmQDlDlB+EoQCDE0AAFRg");
	this.shape.setTransform(65.5198,32.7648,0.3952,0.3952);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blankchart_c, new cjs.Rectangle(0,0,131.1,65.6), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiQEyQhxhHgfiBQgdh7A+hsIAGgMIIjFSIgHALQhFBoh8AdQgnAJgmAAQhWAAhPgwg");
	var mask_graphics_1 = new cjs.Graphics().p("AirESQhlhXgJiFQgIh+BPhgIAIgLIHkGnIgJAKQhVBbh+AIIgZABQh1AAhbhQg");
	var mask_graphics_2 = new cjs.Graphics().p("AAcFgQiEgMhVhnQhVhnANiFQAMh9BehTIAKgJIGZHwIgLAJQhVBBhqAAQgRAAgRgCg");
	var mask_graphics_3 = new cjs.Graphics().p("AgBFXQiBgjhDhzQhDhzAiiAQAhh7BqhCIALgHIFCIsIgMAHQhGAlhMAAQgqAAgrgLg");
	var mask_graphics_4 = new cjs.Graphics().p("AgbFFQh5g3gwh9Qgvh8A3h5QA0h0BzgwIANgFIDiJaIgMAFQgzARgzAAQhCAAhBgeg");
	var mask_graphics_5 = new cjs.Graphics().p("AgwEsQhvhKgaiDQgaiCBKhvQBGhpB4gdIAOgDIB+J3IgNACQgcAFgaAAQhdAAhRg3g");
	var mask_graphics_6 = new cjs.Graphics().p("Ag/EMQhihbgEiGQgFiEBbhiQBWhcB8gJIAOAAIAVKCIgNABQh9gBhbhWg");
	var mask_graphics_7 = new cjs.Graphics().p("ABVFgQh6gVhNhlQhRhpARiEQARiEBqhRQBkhNB8AMIANABIhUJ9IgNgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AAIFYQh1gog7hwQg/h2Anh+QAmiAB2g/QBvg8B4AgIANAEIi7JnIgNgEg");
	var mask_graphics_9 = new cjs.Graphics().p("AhAFNQhtg7gph4Qgrh/A7h2QA8h4B+grQB3gpBxA0IANAFIkcJBIgNgGg");
	var mask_graphics_10 = new cjs.Graphics().p("AiCE+QhjhNgUh9QgWiCBOhtQBOhsCCgWQB9gUBoBFIALAHIl2ILIgLgIg");
	var mask_graphics_11 = new cjs.Graphics().p("Ai+ErQhUhbAAh/QAAiEBfheQBehfCEAAQB/ABBbBVIAKAJInHHGIgKgKg");
	var mask_graphics_12 = new cjs.Graphics().p("AjvEWQhEhoAVh9QAViCBthOQBthOCCAWQB9AVBMBjIAIALIoLF1IgIgLg");
	var mask_graphics_13 = new cjs.Graphics().p("AkVD/QgzhyAph4QArh9B4g7QB4g7B9ArQB4ApA7BuIAGAMIpBEbIgGgMg");
	var mask_graphics_14 = new cjs.Graphics().p("AkwDmQgfh5A8huQA/h2CAgmQB+gnB2A/QBvA8AoB1IAFANIpoC6IgEgNg");
	var mask_graphics_15 = new cjs.Graphics().p("Ak/DMQgLh8BOhkQBRhpCEgRQCEgRBpBRQBlBOAUB6IACANIp+BSIgCgNg");
	var mask_graphics_16 = new cjs.Graphics().p("AlBC0IABgOQAJh8BchVQBihbCEAFQCGAEBbBiQBWBcAAB8IAAAOg");
	var mask_graphics_17 = new cjs.Graphics().p("Ak+BmIADgOQAdh4BphGQBwhKCBAbQCDAaBKBvQBGBpgVB7IgCANg");
	var mask_graphics_18 = new cjs.Graphics().p("Ak3AaIAFgNQAwhyB0g0QB6g2B7AvQB9AwA3B4QA0B0gpB2IgEANg");
	var mask_graphics_19 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_20 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_21 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_22 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_23 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_24 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_25 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_26 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_27 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_28 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQCAgiBzBDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_29 = new cjs.Graphics().p("AksgqIAHgMQBChpB6giQCAgjBzBDQB0BCAjCAQAhB6g6BuIgGAMg");
	var mask_graphics_30 = new cjs.Graphics().p("AkuggIAGgMQBAhrB5gkQB/gmB2A/QB1BAAmB/QAkB5g4BwIgGAMg");
	var mask_graphics_31 = new cjs.Graphics().p("AkxgOIAGgMQA6huB4gpQB9grB4A6QB4A7AsB9QApB4gzBxIgFANg");
	var mask_graphics_32 = new cjs.Graphics().p("Ak2APIAFgNQA0hwB1gyQB7gzB6AyQB8AzAzB5QAyB1grB1IgFANg");
	var mask_graphics_33 = new cjs.Graphics().p("Ak7A6IAEgNQAoh1Bwg8QB1g/B/AmQCAAnA/B1QA8BvgfB4IgEANg");
	var mask_graphics_34 = new cjs.Graphics().p("Ak/B4IACgOQAYh5BnhKQBshOCDAVQCEAWBOBsQBKBlgQB8IgBAOg");
	var mask_graphics_35 = new cjs.Graphics().p("AlBC5QADh8BYhaQBdhgCFgCQCFgCBfBdQBbBYAHB8IAAAOIqDAJIAAgOg");
	var mask_graphics_36 = new cjs.Graphics().p("Ak2DdQgZh6BChrQBFhyCCggQCAggByBGQBtBBAhB3IAEANIpxCaIgDgOg");
	var mask_graphics_37 = new cjs.Graphics().p("AkIEIQg6hvAih6QAjiAB0hCQB0hCCAAjQB6AiBBBqIAHALIouE/IgHgMg");
	var mask_graphics_38 = new cjs.Graphics().p("AirEyQhahXgGh/QgHiEBZhjQBZhjCEgHQB/gHBfBQIALAJImuHeIgKgJg");
	var mask_graphics_39 = new cjs.Graphics().p("AgmFSQhxg1gwh2Qgyh7A0h6QA0h7B8gyQB0gwB1AtIAMAFIj6JQIgMgFg");
	var mask_graphics_40 = new cjs.Graphics().p("ABpFhQh7gPhRhiQhWhmAMiFQAMiEBmhVQBghSB9AHIANABIg5KAIgNgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AgyEqQhthMgZiDQgYiDBMhtQBIhpB5gbIANgCIB0J4IgNADQgZADgXAAQhgAAhTg5g");
	var mask_graphics_42 = new cjs.Graphics().p("AgUFLQh8gxg1h7Qg1h6Ayh7QAvh2Bwg1IANgGID9JPIgMAFQg5AWg5AAQg8AAg7gYg");
	var mask_graphics_43 = new cjs.Graphics().p("AAJFcQiCgahKhvQhKhvAaiCQAZh8BlhJIALgIIFlIXIgLAHQhNAwhXAAQghAAgigHg");
	var mask_graphics_44 = new cjs.Graphics().p("AAlFiQiEgGhahjQhZhjAGiFQAGh+BahXIAKgJIGvHcIgKAJQhYBLh0AAIgSgBg");
	var mask_graphics_45 = new cjs.Graphics().p("AirETQhlhYgJiFQgIh9BOhhIAJgKIHkGmIgIAKQhWBbh+AJIgZABQh1AAhbhQg");
	var mask_graphics_46 = new cjs.Graphics().p("AidElQhshOgViDQgVh8BGhoIAIgLIIJF4IgIALQhNBih9AUQgcAFgbAAQhjAAhVg+g");
	var mask_graphics_47 = new cjs.Graphics().p("AiQEyQhxhHgfiBQgdh7A+hsIAGgMIIjFSIgHALQhFBoh8AdQgnAJgmAAQhWAAhPgwg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:8.6074,y:35.4393}).wait(1).to({graphics:mask_graphics_1,x:7.1492,y:35.4036}).wait(1).to({graphics:mask_graphics_2,x:5.3329,y:35.4084}).wait(1).to({graphics:mask_graphics_3,x:3.2159,y:35.4466}).wait(1).to({graphics:mask_graphics_4,x:0.9002,y:35.4716}).wait(1).to({graphics:mask_graphics_5,x:-1.5418,y:35.4717}).wait(1).to({graphics:mask_graphics_6,x:-4.0685,y:35.4698}).wait(1).to({graphics:mask_graphics_7,x:-2.4654,y:35.3474}).wait(1).to({graphics:mask_graphics_8,x:0.1311,y:34.8234}).wait(1).to({graphics:mask_graphics_9,x:2.6167,y:33.8893}).wait(1).to({graphics:mask_graphics_10,x:4.9284,y:32.5701}).wait(1).to({graphics:mask_graphics_11,x:6.9729,y:30.9014}).wait(1).to({graphics:mask_graphics_12,x:8.6536,y:28.9279}).wait(1).to({graphics:mask_graphics_13,x:9.9664,y:26.7026}).wait(1).to({graphics:mask_graphics_14,x:10.9078,y:24.2853}).wait(1).to({graphics:mask_graphics_15,x:11.4493,y:21.7409}).wait(1).to({graphics:mask_graphics_16,x:11.5705,y:20.2869}).wait(1).to({graphics:mask_graphics_17,x:11.8562,y:22.9332}).wait(1).to({graphics:mask_graphics_18,x:12.5506,y:25.4888}).wait(1).to({graphics:mask_graphics_19,x:13.5821,y:27.8321}).wait(1).to({graphics:mask_graphics_20,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_21,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_22,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_23,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_24,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_25,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_26,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_27,x:13.5822,y:27.8321}).wait(1).to({graphics:mask_graphics_28,x:13.5821,y:27.8321}).wait(1).to({graphics:mask_graphics_29,x:13.5271,y:27.7304}).wait(1).to({graphics:mask_graphics_30,x:13.353,y:27.3974}).wait(1).to({graphics:mask_graphics_31,x:13.0534,y:26.7774}).wait(1).to({graphics:mask_graphics_32,x:12.6374,y:25.7911}).wait(1).to({graphics:mask_graphics_33,x:12.1456,y:24.3296}).wait(1).to({graphics:mask_graphics_34,x:11.6831,y:22.2556}).wait(1).to({graphics:mask_graphics_35,x:11.4891,y:19.8999}).wait(1).to({graphics:mask_graphics_36,x:11.0318,y:23.4571}).wait(1).to({graphics:mask_graphics_37,x:9.4065,y:27.5565}).wait(1).to({graphics:mask_graphics_38,x:6.2299,y:31.487}).wait(1).to({graphics:mask_graphics_39,x:1.6519,y:34.2858}).wait(1).to({graphics:mask_graphics_40,x:-3.2214,y:35.4484}).wait(1).to({graphics:mask_graphics_41,x:-1.844,y:35.5161}).wait(1).to({graphics:mask_graphics_42,x:1.5118,y:35.5183}).wait(1).to({graphics:mask_graphics_43,x:4.0492,y:35.4853}).wait(1).to({graphics:mask_graphics_44,x:5.884,y:35.4556}).wait(1).to({graphics:mask_graphics_45,x:7.1581,y:35.4584}).wait(1).to({graphics:mask_graphics_46,x:8.0317,y:35.4768}).wait(1).to({graphics:mask_graphics_47,x:8.6074,y:35.4393}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AieAOQABgaABgfQAFhBAKgZQAKAfAlBaIBGiWIADCcIBwhjIg5CHIA4gHQA5gHAMAAQgMARhbA7IApAPQArAPAGAFIhOAk");
	this.shape.setTransform(17.15,28.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.3,10.8,33.800000000000004,34.599999999999994);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AotCHIAAkNIRbAAIAAENg");
	this.shape.setTransform(50.05,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-5.7,0,111.60000000000001,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Group332x();
	this.instance.setTransform(104.3,6,0.3085,0.3085);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(47.7,6,86.89999999999999,177), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.Microphone = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.mic.cache(0,0,105,135,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mic = new lib.mic_inner();
	this.mic.name = "mic";
	this.mic.setTransform(50.5,66.1,1,1,0,0,0,50.5,66.1);

	this.timeline.addTween(cjs.Tween.get(this.mic).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Microphone, new cjs.Rectangle(0,0,101,132.3), null);


(lib.inner_outline = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.outer.cache(0,0,235,175,2)
		this.inner.cache(0,0,175,125,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.outer = new lib.outter_outline();
	this.outer.name = "outer";
	this.outer.setTransform(85.75,57,1,1,0,0,0,114.8,84.7);

	this.timeline.addTween(cjs.Tween.get(this.outer).wait(1));

	// Layer_1
	this.inner = new lib.inner_outlinec();
	this.inner.name = "inner";
	this.inner.setTransform(84.2,58.5,1,1,0,0,0,84.2,58.5);

	this.timeline.addTween(cjs.Tween.get(this.inner).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.inner_outline, new cjs.Rectangle(-29,-27.7,229.6,169.39999999999998), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,250,10,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.green_bar = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.glc.cache(0,0,75,70,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.glc = new lib.greenLineC();
	this.glc.name = "glc";
	this.glc.setTransform(34.6,32.8,1,1,0,0,0,34.6,32.8);

	this.timeline.addTween(cjs.Tween.get(this.glc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.green_bar, new cjs.Rectangle(0,0,69.1,65.6), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.blank_chart = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.blankchart.cache(0,0,135,70)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.blankchart = new lib.blankchart_c();
	this.blankchart.name = "blankchart";
	this.blankchart.setTransform(65.5,32.8,1,1,0,0,0,65.5,32.8);

	this.timeline.addTween(cjs.Tween.get(this.blankchart).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blank_chart, new cjs.Rectangle(0,0,131.1,65.6), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AlsHuQhhg9gahxQgbhxA9hjQA+hiBxgZMAijgIBQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BjhxAZMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_54 = new cjs.Graphics().p("AlvHuQhig9gahxQgahxA8hjQA+hiBxgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_55 = new cjs.Graphics().p("Al9HuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AaBxQAbBxg/BiQg8BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_56 = new cjs.Graphics().p("AmaHuQhig9gahxQgahxA9hjQA+hiBwgZMAijgIBQBxgaBiA8QBjA+AaBxQAbBxg/BiQg8BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_57 = new cjs.Graphics().p("AnNHuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AaBxQAbBxg+BiQg9BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_58 = new cjs.Graphics().p("AoSH8Qhhg9gbhxQgahwA9hjQA+hiBxgZMAijgICQBxgaBhA9QBjA+AbBxQAaBwg+BiQg9BihxAaMgijAICQghAIghAAQhMAAhGgsg");
	var mask_graphics_59 = new cjs.Graphics().p("ApUIMQhig9gahxQgahxA8hjQA/hiBwgaMAijgIAQBxgbBiA9QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhMAAhGgrg");
	var mask_graphics_60 = new cjs.Graphics().p("AqJIYQhig9gahxQgahxA9hjQA+hiBxgaMAijgIAQBwgaBiA8QBjA+AaBxQAbBxg/BiQg8BihxAaMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_61 = new cjs.Graphics().p("AqxIhQhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg9BihwAaMgijAICQgiAIggAAQhNAAhFgsg");
	var mask_graphics_62 = new cjs.Graphics().p("ArQIoQhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBwg+BiQg9BihwAbMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_63 = new cjs.Graphics().p("ArpIuQhhg9gahxQgbhxA9hjQA+hiBxgaMAijgIAQBxgaBhA9QBkA9AaBxQAaBxg+BiQg9BihxAaMgijAICQghAHggAAQhNAAhGgrg");
	var mask_graphics_64 = new cjs.Graphics().p("Ar8IyQhhg9gbhwQgahxA9hjQA+hiBxgaMAijgIBQBxgaBhA9QBkA+AaBxQAaBwg+BiQg9BihxAbMgijAIBQghAIggAAQhNAAhGgsg");
	var mask_graphics_65 = new cjs.Graphics().p("AsLI2Qhhg9gbhxQgahxA9hjQA+hiBxgaMAijgIAQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BihxAaMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_66 = new cjs.Graphics().p("AsWI4Qhig8gahxQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_67 = new cjs.Graphics().p("AsfI6Qhig8gahxQgahxA8hjQA+hiBxgaMAijgIAQBxgbBiA9QBjA+AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_68 = new cjs.Graphics().p("AsmI8Qhig9gahxQgahwA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBwQAaBxg+BiQg8BihxAaMgijAICQgiAIggAAQhMAAhGgsg");
	var mask_graphics_69 = new cjs.Graphics().p("AsrI9Qhig9gahwQgahxA8hjQA/hiBwgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBwg+BiQg8BihxAbMgijAIBQgiAIggAAQhMAAhGgsg");
	var mask_graphics_70 = new cjs.Graphics().p("AsuI+Qhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg9BihwAaMgijAICQgiAHggAAQhNAAhFgrg");
	var mask_graphics_71 = new cjs.Graphics().p("AswI+Qhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_72 = new cjs.Graphics().p("AswI+Qhig9gahxQgahxA8hjQA+hiBxgaMAijgIAQBxgaBiA9QBjA9AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:227.651,y:48.9317}).wait(1).to({graphics:mask_graphics_54,x:227.2795,y:49.1034}).wait(1).to({graphics:mask_graphics_55,x:225.9168,y:49.7334}).wait(1).to({graphics:mask_graphics_56,x:223.0149,y:51.0749}).wait(1).to({graphics:mask_graphics_57,x:217.9248,y:53.4281}).wait(1).to({graphics:mask_graphics_58,x:211.042,y:55.1622}).wait(1).to({graphics:mask_graphics_59,x:204.4029,y:56.6968}).wait(1).to({graphics:mask_graphics_60,x:199.1192,y:57.9182}).wait(1).to({graphics:mask_graphics_61,x:195.0814,y:58.8515}).wait(1).to({graphics:mask_graphics_62,x:191.9735,y:59.5699}).wait(1).to({graphics:mask_graphics_63,x:189.5514,y:60.1298}).wait(1).to({graphics:mask_graphics_64,x:187.6486,y:60.5696}).wait(1).to({graphics:mask_graphics_65,x:186.151,y:60.9158}).wait(1).to({graphics:mask_graphics_66,x:184.9786,y:61.1868}).wait(1).to({graphics:mask_graphics_67,x:184.0731,y:61.3961}).wait(1).to({graphics:mask_graphics_68,x:183.391,y:61.5538}).wait(1).to({graphics:mask_graphics_69,x:182.8992,y:61.6675}).wait(1).to({graphics:mask_graphics_70,x:182.5714,y:61.7432}).wait(1).to({graphics:mask_graphics_71,x:182.3868,y:61.7859}).wait(1).to({graphics:mask_graphics_72,x:182.376,y:61.723}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(158.5,85.75,0.9423,0.9423,8.9326,0,0,42.2,17.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_45 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_46 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_47 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_48 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_49 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_50 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_51 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_52 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_53 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_54 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-14.8503,y:-21.3471}).wait(1).to({graphics:mask_1_graphics_45,x:-12.0762,y:-20.0886}).wait(1).to({graphics:mask_1_graphics_46,x:-4.0254,y:-16.4364}).wait(1).to({graphics:mask_1_graphics_47,x:8.5139,y:-10.7478}).wait(1).to({graphics:mask_1_graphics_48,x:24.3145,y:-3.5798}).wait(1).to({graphics:mask_1_graphics_49,x:41.8296,y:4.3659}).wait(1).to({graphics:mask_1_graphics_50,x:59.3446,y:12.3117}).wait(1).to({graphics:mask_1_graphics_51,x:75.1452,y:19.4797}).wait(1).to({graphics:mask_1_graphics_52,x:87.6846,y:25.1682}).wait(1).to({graphics:mask_1_graphics_53,x:95.7353,y:28.8205}).wait(1).to({graphics:mask_1_graphics_54,x:98.0997,y:29.7529}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(149.25,52.65,0.9423,0.9423,8.9326,0,0,57.6,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AlOFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_39 = new cjs.Graphics().p("AluFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_40 = new cjs.Graphics().p("AnHFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_41 = new cjs.Graphics().p("ApJFRQhZhJgMhzQgMhzBIhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_42 = new cjs.Graphics().p("ArYFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhKBYQhIBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_43 = new cjs.Graphics().p("AtaFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_44 = new cjs.Graphics().p("AuzFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhKBYQhIBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_45 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_46 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_47 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_48 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_49 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_50 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_51 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_52 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_53 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_54 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_55 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_56 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_57 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_58 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_59 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_60 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_61 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_62 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_63 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_64 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_65 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_66 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_67 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_68 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_69 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_70 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_71 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_72 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:237.8114,y:3.6926}).wait(1).to({graphics:mask_2_graphics_39,x:234.6164,y:4.3817}).wait(1).to({graphics:mask_2_graphics_40,x:225.6608,y:6.3124}).wait(1).to({graphics:mask_2_graphics_41,x:212.7196,y:9.1024}).wait(1).to({graphics:mask_2_graphics_42,x:198.3559,y:12.1991}).wait(1).to({graphics:mask_2_graphics_43,x:185.4147,y:14.9891}).wait(1).to({graphics:mask_2_graphics_44,x:176.4591,y:16.9198}).wait(1).to({graphics:mask_2_graphics_45,x:173.3114,y:17.3426}).wait(1).to({graphics:mask_2_graphics_46,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_47,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_48,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_49,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_50,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_51,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_52,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_53,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_54,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_55,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_56,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_57,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_58,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_59,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_60,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_61,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_62,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_63,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_64,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_65,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_66,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_67,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_68,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_69,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_70,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_71,x:173.3127,y:17.3426}).wait(1).to({graphics:mask_2_graphics_72,x:173.3114,y:17.3426}).wait(1));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(156.85,22.8,0.9423,0.9423,8.9326,0,0,60.6,16.6);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AO8KeMghCgM1QhsgqgvhrQguhqAqhsQAqhrBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBrhqAuQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-3.6977,y:-69.3836}).wait(1).to({graphics:mask_3_graphics_32,x:-0.2049,y:-68.2125}).wait(1).to({graphics:mask_3_graphics_33,x:9.8522,y:-64.2339}).wait(1).to({graphics:mask_3_graphics_34,x:25.2605,y:-58.1383}).wait(1).to({graphics:mask_3_graphics_35,x:44.1617,y:-50.661}).wait(1).to({graphics:mask_3_graphics_36,x:64.2759,y:-42.7038}).wait(1).to({graphics:mask_3_graphics_37,x:83.1771,y:-35.2265}).wait(1).to({graphics:mask_3_graphics_38,x:98.5854,y:-29.1309}).wait(1).to({graphics:mask_3_graphics_39,x:108.6425,y:-25.1523}).wait(1).to({graphics:mask_3_graphics_40,x:111.8523,y:-23.7442}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(161.75,-4.7,0.9423,0.9423,8.9326,0,0,59.9,12.9);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("AlKDsQhWhPgEh1QgFh0BPhYQBQhVB2gFMAj8gBeQB1gFBWBPQBXBRAFB1QAFB0hRBWQhPBXh1AFMgj8ABeIgNAAQhuAAhShMg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AlNDtQhWhQgFh1QgFh0BPhXQBRhWB1gFMAj8gBeQB1gFBWBPQBXBRAFB1QAFB0hQBWQhQBXh1AFMgj8ABeIgNAAQhtAAhShLg");
	var mask_4_graphics_21 = new cjs.Graphics().p("AlZDtQhVhPgFh1QgFh1BPhXQBQhWB2gFMAj7gBdQB1gFBWBPQBXBQAFB2QAFB0hQBWQhQBXh1AFMgj7ABeIgNAAQhtAAhThMg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AluDuQhWhPgFh2QgFh0BPhXQBRhWB1gEMAj6gBeQB1gFBWBPQBXBQAFB1QAFB1hRBWQhPBXh1AEMgj6ABeIgNABQhtAAhShMg");
	var mask_4_graphics_23 = new cjs.Graphics().p("AmSDvQhWhPgFh1QgFh0BPhXQBRhWB1gFMAj4gBeQB1gEBWBPQBXBQAFB1QAFB0hRBWQhPBXh1AFMgj4ABeIgNAAQhtAAhShMg");
	var mask_4_graphics_24 = new cjs.Graphics().p("AnJDxQhWhPgFh1QgFh0BPhXQBRhVB0gFMAj2gBeQB1gFBWBPQBXBQAEB1QAFB0hQBWQhPBXh1AFMgj1ABdIgOABQhsAAhShMg");
	var mask_4_graphics_25 = new cjs.Graphics().p("AoYD0QhVhPgFh1QgFhzBPhXQBQhWB1gEMAjygBeQB0gFBWBPQBXBQAEB1QAFB0hQBVQhPBXh0AFMgjyABdIgNAAQhtAAhShLg");
	var mask_4_graphics_26 = new cjs.Graphics().p("Ap5D4QhWhPgEh1QgFhzBOhXQBQhVB1gFMAjsgBdQB1gFBVBPQBXBQAEB0QAFB0hQBVQhOBXh1AEMgjsABeIgNAAQhtAAhRhLg");
	var mask_4_graphics_27 = new cjs.Graphics().p("ArdD7QhVhOgFh0QgFh0BOhWQBQhVB0gFMAjogBdQB0gFBVBPQBXBPAEB1QAFBzhQBVQhOBWh0AFMgjoABdIgNAAQhsAAhRhLg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AsyD8QhVhOgEh0QgFhzBOhWQBQhVB0gFMAjjgBdQB0gFBVBPQBWBPAFB0QAFBzhQBVQhOBWh0AFMgjjABdIgNAAQhsAAhShLg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AtyD8QhUhOgFh0QgFhzBOhWQBQhVB0gFMAjfgBdQB0gEBVBOQBWBPAFB0QAFBzhQBVQhOBWh0AFMgjgABdIgNAAQhrAAhShLg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AuhD8QhUhOgFh0QgFhzBOhWQBQhVBzgEMAjegBdQB0gFBUBOQBWBPAFB0QAFBzhQBVQhOBWhzAEMgjeABdIgNAAQhrAAhShKg");
	var mask_4_graphics_31 = new cjs.Graphics().p("AvCD7QhVhOgEhzQgFhzBOhWQBPhVB0gEMAjbgBdQB0gFBVBOQBWBQAEBzQAFBzhPBVQhOBWh0AEMgjbABdIgNAAQhsAAhRhLg");
	var mask_4_graphics_32 = new cjs.Graphics().p("AvZD7QhVhOgFhzQgFhzBOhWQBQhUBzgFMAjbgBdQBzgEBVBOQBWBPAFBzQAEBzhPBVQhOBVh0AFMgjaABdIgNAAQhrAAhRhLg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:244.7021,y:-34.9429}).wait(1).to({graphics:mask_4_graphics_20,x:244.3476,y:-34.9265}).wait(1).to({graphics:mask_4_graphics_21,x:243.1439,y:-34.87}).wait(1).to({graphics:mask_4_graphics_22,x:240.8234,y:-34.7612}).wait(1).to({graphics:mask_4_graphics_23,x:237.0005,y:-34.5818}).wait(1).to({graphics:mask_4_graphics_24,x:231.1636,y:-34.3079}).wait(1).to({graphics:mask_4_graphics_25,x:222.8634,y:-33.9185}).wait(1).to({graphics:mask_4_graphics_26,x:212.4712,y:-33.4309}).wait(1).to({graphics:mask_4_graphics_27,x:201.86,y:-32.9331}).wait(1).to({graphics:mask_4_graphics_28,x:192.9169,y:-32.3021}).wait(1).to({graphics:mask_4_graphics_29,x:186.1134,y:-31.7109}).wait(1).to({graphics:mask_4_graphics_30,x:181.1361,y:-31.2783}).wait(1).to({graphics:mask_4_graphics_31,x:177.5694,y:-30.9684}).wait(1).to({graphics:mask_4_graphics_32,x:175.0798,y:-30.7522}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(169,-28.55,0.9423,0.9423,8.9326,0,0,63.6,13);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-71,261.8,279);


(lib.outlines = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.outlines = new lib.inner_outline();
	this.outlines.name = "outlines";
	this.outlines.setTransform(113.35,86.15,1,1,0,0,0,84.2,58.5);

	this.timeline.addTween(cjs.Tween.get(this.outlines).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlines, new cjs.Rectangle(0,0,229.8,169.4), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-21.7,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.CTAbg},{t:this.popRight},{t:this.popLeft}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.6,143.7,27), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.grid_line();
	this.instance.setTransform(369.55,33.95,0.4977,1,90,0,0,121.2,-0.1);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(303.35,36.05,0.499,1,90,0,0,125.8,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(183.6,36.05,0.499,1,90,0,0,125.8,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(252.95,31.9,1.0322,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(122.5,-26.9,251.3,121.5), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_42 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(42).call(this.frame_42).wait(1));

	// Layer_6
	this.text = new cjs.Text("0", "22px 'Segoe Pro Semibold'", "#505050");
	this.text.textAlign = "center";
	this.text.lineHeight = 32;
	this.text.lineWidth = 36;
	this.text.parent = this;
	this.text.setTransform(206.6509,145.3);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(10).to({text:"2"},0).wait(1).to({text:"5"},0).wait(1).to({text:"8"},0).wait(1).to({text:"13"},0).wait(1).to({text:"19"},0).wait(1).to({text:"26"},0).wait(1).to({text:"34"},0).wait(1).to({text:"43"},0).wait(1).to({text:"52"},0).wait(1).to({text:"61"},0).wait(1).to({text:"78"},0).wait(1).to({text:"93"},0).wait(1).to({text:"100"},0).wait(1).to({text:"106"},0).wait(1).to({text:"112"},0).wait(1).to({text:"117"},0).wait(1).to({text:"121"},0).wait(1).to({text:"125"},0).wait(1).to({text:"128"},0).wait(1).to({text:"131"},0).wait(2).to({text:"133"},0).wait(2).to({text:"135"},0).wait(2).to({text:"138"},0).wait(2).to({text:"139"},0).wait(6));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_2 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_3 = new cjs.Graphics().p("ACeQxQjgjWgIk2IAAgFIXYgnIAAAFQAIE2jVDhQjWDhk2AIIgWAAQkoAAjZjNg");
	var mask_graphics_4 = new cjs.Graphics().p("ACeQwQjgjWgIk2IAAgFIXYglIAAAFQAIE2jVDhQjWDgk3AIIgVAAQkoAAjZjOg");
	var mask_graphics_5 = new cjs.Graphics().p("ACcQvQjfjWgHk2IAAgFIXYgjIAAAFQAIE2jWDhQjXDgk2AHIgUAAQkpAAjajPg");
	var mask_graphics_6 = new cjs.Graphics().p("ACaQtQjejXgGk2IAAgFIXYgdIABAFQAFE2jWDgQjYDfk2AGIgRAAQkrAAjajRg");
	var mask_graphics_7 = new cjs.Graphics().p("ACXQqQjdjZgEk2IAAgFIXZgTIAAAFQAEE2jZDfQjYDdk3AEIgLAAQkvAAjajUg");
	var mask_graphics_8 = new cjs.Graphics().p("ACSQlQjbjbgBk2IAAgFIXZgFIAAAFQABE2jbDdQjbDbk2ABIgDAAQk0AAjbjZg");
	var mask_graphics_9 = new cjs.Graphics().p("AKaT+Qk2gDjZjdQjZjeAEk2IAAgFIXZAPIAAAFQgEE2jdDaQjaDVkxAAIgJAAg");
	var mask_graphics_10 = new cjs.Graphics().p("AKNT+Qk2gJjWjhQjUjhAJk3IAAgFIXYAqIAAAFQgIE3jhDVQjZDMknAAIgYAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AJ8T9Qk2gPjQjmQjPjnAQk2IAAgFIXXBMIAAAFQgQE2jmDQQjWDBkbAAIgrgBg");
	var mask_graphics_12 = new cjs.Graphics().p("AJnT8Qk1gZjJjsQjJjsAZk1IAAgFIXUB3IAAAFQgZE1jrDKQjTCykMAAQghAAgigCg");
	var mask_graphics_13 = new cjs.Graphics().p("AJOT5Qk0gjjBjzQjAjzAjk0IABgFIXPCqIAAAFQgkE1jyDBQjOCjj8AAQguAAgwgGg");
	var mask_graphics_14 = new cjs.Graphics().p("AIxT1Qkygwi3j7Qi2j7AxkzIAAgFIXHDpIgBAFQgwEzj6C3QjHCQjpAAQg+AAhAgKg");
	var mask_graphics_15 = new cjs.Graphics().p("AIQTuQkwg/iqkEQipkDA/kwIABgFIW6ExIgBAFQhAEwkDCqQi9B8jUAAQhQAAhSgRg");
	var mask_graphics_16 = new cjs.Graphics().p("AHrTjQkshQibkNQiakNBRksIABgEIWmGFIgBAFQhREskNCbQiwBli+AAQhjAAhngcg");
	var mask_graphics_17 = new cjs.Graphics().p("AHCTVQklhliJkWQiIkXBlklIABgFIWJHlIgCAEQhkEmkXCJQigBOilAAQh6AAh9gqg");
	var mask_graphics_18 = new cjs.Graphics().p("AGXTAQkdh6hzkgQhzkgB6keIACgEIVgJPIgBAEQh7EekgBzQiLA3iLAAQiUAAiTg/g");
	var mask_graphics_19 = new cjs.Graphics().p("AFqSkQkRiShZkpQhakpCRkSIADgEIUpLDIgDAEQiSESkpBaQhxAihtAAQizAAiqhbg");
	var mask_graphics_20 = new cjs.Graphics().p("AE/R/QkCisg9kwQg8kwCrkDIADgEITeM/IgDAFQisECkwA9QhPAQhMAAQjYAAi/iAg");
	var mask_graphics_21 = new cjs.Graphics().p("AEWRPQjujHgck1Qgbk1DGjuIADgEIR+PBIgDAEQjIDuk0AcQglADglAAQkIAAjRivg");
	var mask_graphics_22 = new cjs.Graphics().p("AL9T9Qk2gKjUjiQjVjiAKk2QAJk2DijUIAEgDIQCRDIgEADQjYDMkmAAIgagBg");
	var mask_graphics_23 = new cjs.Graphics().p("ALGT1Qkzgvi4j7Qi3j5AukzQAvkzD6i3IAEgDIN4S2IgEADQjICTjsAAQg7AAg+gJg");
	var mask_graphics_24 = new cjs.Graphics().p("AKYTjQkrhPickNQickMBPksQBQksEMibIAEgCILxUOIgFADQiyBnjAAAQhhAAhlgbg");
	var mask_graphics_25 = new cjs.Graphics().p("AJzTNQkihsiCkbQiBkZBskjQBskiEaiBIAFgDIJwVRIgFADQiaBGicAAQiDAAiEgxg");
	var mask_graphics_26 = new cjs.Graphics().p("AJVS0QkYiFhokkQhpkkCFkZQCEkXElhpIAFgCIH4WCIgFACQiBAuh/AAQigAAidhKg");
	var mask_graphics_27 = new cjs.Graphics().p("AI+SaQkNiahSksQhSkrCZkNQCakNErhSIAFgBIGMWjIgFACQhoAchlAAQi8AAiwhjg");
	var mask_graphics_28 = new cjs.Graphics().p("AIsSAQkDisg+kwQg+kwCrkCQCrkCExg+IAFgBIErW6IgFABQhRARhOAAQjWAAi+h9g");
	var mask_graphics_29 = new cjs.Graphics().p("AIeRnQj4i6gtkzQgskzC5j5QC6j3EzgtIAFAAIDXXJIgFABQg8AJg5AAQjvAAjIiWg");
	var mask_graphics_30 = new cjs.Graphics().p("AITRQQjvjGgdk1Qgdk0DFjwQDGjuE1gdIAFAAICNXSIgFAAQgoAEgmAAQkGAAjQisg");
	var mask_graphics_31 = new cjs.Graphics().p("AILQ8QjmjQgRk2QgQk2DQjmQDPjmE2gQIAFAAIBPXXIgFAAIgtABQkaAAjWjAg");
	var mask_graphics_32 = new cjs.Graphics().p("AIFQqQjfjYgFk2QgGk2DXjfQDYjfE2gFIAFAAIAbXZIgFAAIgQAAQksAAjajSg");
	var mask_graphics_33 = new cjs.Graphics().p("AQIT8Qk3gEjZjdQjYjeADk3QADk2DejYQDejZE2AEIAFAAIgQXZIgFAAg");
	var mask_graphics_34 = new cjs.Graphics().p("APuT7Qk2gKjUjiQjUjjALk3QAKk1DjjTQDijUE3AKIAFAAIgzXZIgFgBg");
	var mask_graphics_35 = new cjs.Graphics().p("APaT7Qk2gQjQjmQjPjnAQk2QAQk1DmjPQDmjQE2AQIAFAAIhNXXIgFAAg");
	var mask_graphics_36 = new cjs.Graphics().p("APLT7Qk2gVjNjoQjMjqAUk1QAVk2DojMQDqjME1AUIAFAAIhhXWIgFAAg");
	var mask_graphics_37 = new cjs.Graphics().p("APAT6Qk1gXjLjrQjKjrAXk1QAXk2DrjJQDrjLE2AYIAFAAIhwXVIgFgBg");
	var mask_graphics_38 = new cjs.Graphics().p("AO5T6Qk1gZjJjsQjJjtAZk1QAZk1DsjIQDtjJE1AZIAFAAIh5XVIgFgBg");
	var mask_graphics_39 = new cjs.Graphics().p("AO1T6Qk2gajIjtQjHjtAak2QAak1DtjHQDujIE1AaIAFABIh/XTIgFAAg");
	var mask_graphics_40 = new cjs.Graphics().p("AOzT6Qk2gbjHjtQjIjuAbk1QAbk1DujHQDtjHE2AbIAFAAIiCXTIgFAAg");
	var mask_graphics_41 = new cjs.Graphics().p("AOyT6Qk2gbjHjuQjHjuAbk1QAbk1DujGQDujIE1AcIAFAAIiDXTIgFAAg");
	var mask_graphics_42 = new cjs.Graphics().p("AOxT6Qk1gbjHjuQjHjuAbk1QAbk1DujGQDtjIE2AcIAFAAIiEXTIgFAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:142.2699,y:127.8343}).wait(2).to({graphics:mask_graphics_2,x:142.2699,y:127.8343}).wait(1).to({graphics:mask_graphics_3,x:142.2704,y:127.8349}).wait(1).to({graphics:mask_graphics_4,x:142.2702,y:127.8348}).wait(1).to({graphics:mask_graphics_5,x:142.2695,y:127.8345}).wait(1).to({graphics:mask_graphics_6,x:142.2682,y:127.834}).wait(1).to({graphics:mask_graphics_7,x:142.2662,y:127.8333}).wait(1).to({graphics:mask_graphics_8,x:142.2637,y:127.8327}).wait(1).to({graphics:mask_graphics_9,x:142.2616,y:127.8328}).wait(1).to({graphics:mask_graphics_10,x:142.2496,y:127.8346}).wait(1).to({graphics:mask_graphics_11,x:142.2169,y:127.8391}).wait(1).to({graphics:mask_graphics_12,x:142.1487,y:127.8474}).wait(1).to({graphics:mask_graphics_13,x:142.0242,y:127.8603}).wait(1).to({graphics:mask_graphics_14,x:141.8153,y:127.8778}).wait(1).to({graphics:mask_graphics_15,x:141.4854,y:127.8985}).wait(1).to({graphics:mask_graphics_16,x:140.9878,y:127.9189}).wait(1).to({graphics:mask_graphics_17,x:140.2651,y:127.9332}).wait(1).to({graphics:mask_graphics_18,x:139.2483,y:127.934}).wait(1).to({graphics:mask_graphics_19,x:137.8571,y:127.9136}).wait(1).to({graphics:mask_graphics_20,x:136.0012,y:127.8686}).wait(1).to({graphics:mask_graphics_21,x:133.5835,y:127.8092}).wait(1).to({graphics:mask_graphics_22,x:130.5055,y:127.774}).wait(1).to({graphics:mask_graphics_23,x:127.0581,y:127.7881}).wait(1).to({graphics:mask_graphics_24,x:123.6803,y:127.8065}).wait(1).to({graphics:mask_graphics_25,x:120.4703,y:127.8041}).wait(1).to({graphics:mask_graphics_26,x:117.4932,y:127.7796}).wait(1).to({graphics:mask_graphics_27,x:114.7879,y:127.7409}).wait(1).to({graphics:mask_graphics_28,x:112.3729,y:127.6971}).wait(1).to({graphics:mask_graphics_29,x:110.2524,y:127.656}).wait(1).to({graphics:mask_graphics_30,x:108.4199,y:127.6222}).wait(1).to({graphics:mask_graphics_31,x:106.8618,y:127.5979}).wait(1).to({graphics:mask_graphics_32,x:105.56,y:127.5828}).wait(1).to({graphics:mask_graphics_33,x:105.3227,y:127.5755}).wait(1).to({graphics:mask_graphics_34,x:106.1797,y:127.5566}).wait(1).to({graphics:mask_graphics_35,x:106.8466,y:127.5283}).wait(1).to({graphics:mask_graphics_36,x:107.3474,y:127.4993}).wait(1).to({graphics:mask_graphics_37,x:107.706,y:127.4744}).wait(1).to({graphics:mask_graphics_38,x:107.9462,y:127.4558}).wait(1).to({graphics:mask_graphics_39,x:108.0919,y:127.4437}).wait(1).to({graphics:mask_graphics_40,x:108.1667,y:127.4373}).wait(1).to({graphics:mask_graphics_41,x:108.1942,y:127.4349}).wait(1).to({graphics:mask_graphics_42,x:108.1732,y:127.4316}).wait(1));

	// green_chart
	this.instance = new lib.green_bar();
	this.instance.setTransform(209.7,179.85,1,1,0,0,0,65.5,65.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(43));

	// blank_chart
	this.instance_1 = new lib.blank_chart();
	this.instance_1.setTransform(209.7,146.85,1,1,0,0,0,65.5,32.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(43));

	// Layer_1
	this.instance_2 = new lib.popup1();
	this.instance_2.setTransform(97.6,87.65,0.3957,0.3957);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(43));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(97.6,87.7,230.70000000000002,140.8);


(lib.collabIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_13
	this.outlines = new lib.outlines();
	this.outlines.name = "outlines";
	this.outlines.setTransform(34.5,72.4,1,1,0,0,0,111.2,86.7);

	this.timeline.addTween(cjs.Tween.get(this.outlines).wait(1));

	// mic
	this.mic = new lib.Microphone();
	this.mic.name = "mic";
	this.mic.setTransform(102.65,117.8,1,1,0,0,0,50.5,66.1);

	this.timeline.addTween(cjs.Tween.get(this.mic).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabIcon, new cjs.Rectangle(-76.6,-14.3,229.79999999999998,198.3), null);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(509.3,-91,0.6304,0.6304,-102.8447,0,0,15,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(516.6,-95.9,0.6304,0.6304,-133.8476,0,0,14.8,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(519.65,-103.4,0.6304,0.6304,-173.8531,0,0,14.8,0.2);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(463.25,-150.75,0.6492,0.6492,86.0036,0,0,14.8,-0.2);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(455.35,-147.65,0.6492,0.6492,55.0029,0,0,14.8,-0.2);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(450.6,-141.5,0.6492,0.6492,14.9982,0,0,15.2,-0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// PPT_Icon
	this.ODIcon = new lib.collabIcon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(483.15,-120.75,0.2555,0.2555,0,0,0,31.3,81.4);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(259,-111.95,1,1,0,0,0,144.5,23.6);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-94,-215.7,624,298.2), null);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pptLogo
	this.pptLogo = new lib.pptLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(132.4,148.9,1,1,0,0,0,29.8,9.5);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// files
	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(212.2,194.65,0.3877,0.3877,0,0,0,214,158.1);

	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(207.8,193.25,1,1,0,0,0,51.5,41.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file2},{t:this.file1}]}).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(209.65,194.7,0.4072,0.4072,0,0,0,226.8,153.8);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// Layer_3
	this.instance = new lib.W10_20H2_Surface_PPT_PresenterCoach_Summery_3x2_enUS();
	this.instance.setTransform(112.65,140.45,0.3253,0.3253);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(205.1,196.35,0.3878,0.3878,0,0,0,196.6,134.1);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-160,113.6,728,148.50000000000003), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AgYCVIgDgCIgCgBIgPgXQgDgFgEgCQgDgCgGgBIiRAAIAAkFIGbAAIAAEpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:211.275,y:181.35}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(205.5,150.3,1,1,0,0,0,205.5,150.3);

	var maskedShapeInstanceList = [this.ui];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(112.7,130.2,172.40000000000003,131.90000000000003);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.2,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(671.95,44.35,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(681.65,45,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(150.65,69.55,1,1,0,0,0,119,30.7);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(370.6,18.25,1,1,0,0,0,206.8,147.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(434.3,31.1,1,1,0,0,0,3.5,39.7);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(228.5,191.8,1,1,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(249.6,33.1,1,1,0,0,0,249.6,33.1);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,155,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-26.9,752.3,225.9), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		mc.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.anim.line1.play();}});
				
				//this.tl1.to(mc.anim,{duration:1.5, ease:Power3.easeInOut}, "+=.4");
		
				//icon
				this.tl1.from([mc.anim.ODIcon.outlines,mc.anim.ODIcon.mic],{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut}, ">+1.1");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">-.1");
		
				//chart transition
				this.tl1.to(mc.ui,{duration:.6, y:"+=20", ease:Power2.easeInOut}, ">+0.6");
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .1, scaleY: .1, ease:Power4.easeInOut}, "<");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=20", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<");
			//	this.tl1.from(mc.grid,{duration:1,x: "+=240", ease:Power3.easeInOut}, ">");					
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<-.6");
				this.tl1.to([mc.anim.ODIcon, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3, mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.line1],{duration:.6, alpha:0}, ">-.6");
		
				this.tl1.from(mc.ui.ui.file1,{duration:.6, x:"+=0", y:"-=20", scaleX:.1, scaleY:.1, ease:Power4.easeInOut, onComplete:function(){mc.ui.ui.file1.play(0);}}, ">+0.1");
						//this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, ease:Power4.easeOut, onComplete:function(){mc.highlights.play();}});
		
		
				//this.tl1.to(mc.anim, {duration:.1, y:"-=70"}, ">+.3");
		
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=3", y:"+=16", ease:Power3.easeInOut}, ">+1.4");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"+=14", y:"+=17", alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"+=0", y:"-=20", scaleX:.1, scaleY:.1,  ease:Power3.easeIn}, ">-1");
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
		
		
				this.tl1.from(mc.ui.ui.file2,{duration:.6, y:"+=7",x:"-=32", scaleX:.33, scaleY:.33, ease:Power4.easeInOut}, "<-.3");
				
				
				//this.tl1.to(mc.anim,{duration:1, x:"+=30", y:"-=8", scaleX: .9, scaleY: .9, ease:Power3.easeInOut}, "<-.5");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<-.5");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=150", y:"-=150", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, ">+.1");
		
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
		
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"-=139", y:"-=11",scaleX: 0.76, scaleY: 0.76, ease:Power3.easeInOut}, ">+0.6");
				this.tl1.to(mc.ui.ui.pptLogo,{duration:1.2, scaleX: 1.1, scaleY: 1.1, ease:Power3.easeInOut}, ">-1.2");
				//this.tl1.to(mc.anim,{duration:1.2, x:"+=40", y:"-=0", scaleX: .8, scaleY: .8, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"-=139", y:"-=11", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				
				this.tl1.to(mc.ui.ui.file2,{duration:.7, y:"+=7",x:"-=32", scaleX:.33, scaleY:.33, ease:Power3.easeInOut}, ">-1");
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
		
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.3");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
					//		this.tl1.from(mc.finalFrameMC,{duration:.4, alpha:0, ease:Power3.easeOut}, "+=0");						
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ad1,{duration:2, x:"-=100", y:"+=50",  ease:Power3.easeInOut, onStart:function(){mc.ad1.visible=true;}});
				this.tl2.to(mc.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,18.1,388.29999999999995,114.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622718409812", id:"M365_FY22Q1BTS_USA_728x90_BAN_PPT_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;