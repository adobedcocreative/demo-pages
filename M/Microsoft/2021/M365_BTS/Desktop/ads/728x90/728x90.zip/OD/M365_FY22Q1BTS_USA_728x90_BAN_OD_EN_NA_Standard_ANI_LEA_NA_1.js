(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[395,502,164,220],[886,644,80,132],[561,685,143,145],[727,644,157,166],[561,502,164,181],[752,439,196,203],[752,255,272,182],[0,502,393,268],[752,0,220,253],[0,0,750,500]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.BookReport = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Group332x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Group592x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Layer12x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Layer22x = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.tileShadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.UIFinalFrame1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.university = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pptLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Group592x();
	this.instance.setTransform(26.85,7.2,0.5341,0.5341);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptLogo, new cjs.Rectangle(26.9,7.2,76.30000000000001,77.5), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2195,21.2195,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6124,21.2195,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2195,6.6124,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6124,6.6124,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1557,14.0561,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.946,13.9111,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.485,13.9111,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.line1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_99 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_47 = new cjs.Graphics().p("AJbDZQgKgYgBggQAAghAKgYQAKgXAOAAIEXgCQAOgBAKAXQALAYAAAhQAAAhgKAXQgKAXgOABIkXACIAAAAQgOAAgKgXg");
	var mask_graphics_48 = new cjs.Graphics().p("AJWDZQgKgYAAghQgBghAKgXQALgYAOAAIEhgDQAPAAALAYQAKAXABAhQAAAhgKAYQgLAXgOAAIkhADIAAAAQgPAAgLgXg");
	var mask_graphics_49 = new cjs.Graphics().p("AJSDZQgLgYgBghQAAghAKgYQALgYAPAAIEsgDQAQAAALAXQALAYAAAhQAAAigKAXQgLAYgPAAIksADIAAAAQgPAAgLgXg");
	var mask_graphics_50 = new cjs.Graphics().p("AJMDZQgLgYgBghQAAgiALgYQALgXAQgBIE4gDQAQAAAMAXQALAYABAhQAAAigLAYQgLAYgQAAIk4ADIgBAAQgPAAgMgXg");
	var mask_graphics_51 = new cjs.Graphics().p("AJGDZQgMgYgBghQAAgiALgZQAMgXARgBIFGgEQARAAAMAYQAMAYABAhQAAAigLAYQgMAYgRABIlGAEIgBAAQgQAAgMgYg");
	var mask_graphics_52 = new cjs.Graphics().p("AI/DZQgNgYAAgiQgBgiAMgYQAMgZASAAIFWgFQASAAAMAYQANAYABAiQAAAigMAYQgMAZgRAAIlXAFIAAAAQgRAAgNgYg");
	var mask_graphics_53 = new cjs.Graphics().p("AI3DZQgNgYAAgiQgBgjANgYQAMgZATAAIFngGQATAAANAYQAOAYAAAjQABAigNAZQgNAYgSABIloAFIAAAAQgSAAgOgYg");
	var mask_graphics_54 = new cjs.Graphics().p("AIvDaQgOgZgBgjQAAgiANgZQANgZAUAAIF7gHQATAAAOAYQAOAYABAjQABAjgOAZQgNAZgTAAIl7AHIgBAAQgTAAgOgYg");
	var mask_graphics_55 = new cjs.Graphics().p("AImDaQgPgZgBgjQgBgjAOgaQAOgZAVAAIGQgIQAVAAAOAYQAPAZABAjQABAjgOAaQgOAZgVAAImQAIIAAAAQgUAAgPgYg");
	var mask_graphics_56 = new cjs.Graphics().p("AIcDaQgQgZgBgjQgBgkAPgaQAPgZAVgBIGogJQAVAAAQAYQAQAaABAjQABAkgPAZQgPAagVAAImoAKIgBAAQgVAAgPgZg");
	var mask_graphics_57 = new cjs.Graphics().p("AIRDaQgRgZgBgkQgBgkAQgaQAPgaAXAAIHBgLQAXgBAQAZQARAaABAkQABAkgQAZQgPAbgXAAInBALIgBAAQgWAAgQgZg");
	var mask_graphics_58 = new cjs.Graphics().p("AIFDaQgSgZgBgkQgBglAQgbQARgaAYAAIHcgNQAYgBASAZQASAaABAlQABAkgQAbQgRAagYABIncANIgBAAQgYAAgRgag");
	var mask_graphics_59 = new cjs.Graphics().p("AH4DbQgTgagBglQgBglARgbQASgbAagBIH5gPQAaAAASAZQAUAaABAlQABAmgSAaQgRAbgaABIn5APIgCAAQgYAAgTgZg");
	var mask_graphics_60 = new cjs.Graphics().p("AHqDbQgUgagBgmQgBglASgcQATgbAbgBIIZgRQAbgBAUAaQAVAaABAmQABAlgTAcQgSAbgbABIoZASIgCAAQgaAAgUgag");
	var mask_graphics_61 = new cjs.Graphics().p("AHcDcQgWgbgBgmQgBgmATgdQAUgbAdgBII6gVQAdgBAVAbQAWAaABAnQACAmgUAcQgUAcgdABIo5AUIgDAAQgbAAgVgZg");
	var mask_graphics_62 = new cjs.Graphics().p("AHNDcQgXgbgCgnQgBgnAVgcQAUgdAfgBIJdgYQAegBAXAbQAXAbACAnQABAngVAcQgUAdgfABIpcAYIgDAAQgdAAgWgag");
	var mask_graphics_63 = new cjs.Graphics().p("AG9DcQgYgbgCgnQgBgoAVgdQAWgdAhgCIKAgbQAhgBAYAbQAZAbABAoQACAngWAdQgWAeggABIqBAbIgDAAQgfAAgXgag");
	var mask_graphics_64 = new cjs.Graphics().p("AGtDdQgZgcgCgoQgCgoAXgeQAXgeAjgBIKlgfQAigCAaAbQAaAcACAoQACApgYAdQgXAegiACIqlAfIgEAAQggAAgZgag");
	var mask_graphics_65 = new cjs.Graphics().p("AGdDdQgbgbgCgqQgCgpAYgeQAZgeAkgCILKgkQAlgBAbAbQAbAcACApQACApgYAfQgZAegkACIrKAjIgEAAQgiAAgagag");
	var mask_graphics_66 = new cjs.Graphics().p("AGNDeQgdgcgCgqQgCgqAZgfQAagfAmgCILwgoQAmgCAcAcQAdAcADAqQACAqgaAfQgZAfgnACIrvAoIgFAAQgjAAgbgag");
	var mask_graphics_67 = new cjs.Graphics().p("AF9DeQgegcgCgrQgDgqAbggQAbgfAogDIMUgrQAogDAeAcQAeAcADArQACAqgbAgQgbAggoACIsTAsIgGABQglAAgcgbg");
	var mask_graphics_68 = new cjs.Graphics().p("AFuDeQgggcgCgrQgDgrAcghQAcggAqgCIM3gxQAqgCAfAbQAgAdADArQACArgcAgQgbAhgqADIs3AxIgHAAQgmAAgdgbg");
	var mask_graphics_69 = new cjs.Graphics().p("AFfDfQghgdgCgsQgDgrAdgiQAdggAsgDINZg1QArgDAhAcQAhAdADAsQADArgeAhQgcAhgsADItZA2IgIABQgnAAgegbg");
	var mask_graphics_70 = new cjs.Graphics().p("AFRDfQgigdgDgsQgDgsAegiQAegiAugDIN5g6QAugDAhAcQAjAeADAsQADAtgeAhQgeAiguADIt5A7IgJAAQgoAAgfgbg");
	var mask_graphics_71 = new cjs.Graphics().p("AFEDgQgkgegDgtQgDgsAfgjQAfgiAvgDIOZg/QAvgDAjAdQAjAdAEAtQADAtggAiQgeAigvADIuZBAIgJAAQgpAAgggag");
	var mask_graphics_72 = new cjs.Graphics().p("AE3DgQgkgegEgtQgDgtAggjQAggjAxgDIO1hEQAwgDAlAdQAlAdADAuQADAtggAjQggAigwAEIu2BEIgKABQgqAAghgbg");
	var mask_graphics_73 = new cjs.Graphics().p("AErDgQglgdgDguQgEguAhgkQAhgjAygDIPQhIQAygEAlAeQAmAdAEAuQADAughAjQghAjgxAEIvRBJIgLAAQgrAAgigbg");
	var mask_graphics_74 = new cjs.Graphics().p("AEgDhQgmgegEgvQgDguAhgkQAigjAzgEIPqhNQAzgEAmAeQAoAeADAuQAEAugiAkQgiAkgzAEIvpBNIgMAAQgsAAgjgag");
	var mask_graphics_75 = new cjs.Graphics().p("AEWDhQgngegEgvQgDgvAigkQAigkA1gEIQBhRQA0gEAnAeQAoAeAEAvQAEAugjAkQgiAlg0AEIwBBRIgNABQgsAAgkgbg");
	var mask_graphics_76 = new cjs.Graphics().p("AENDhQgogegEgvQgEgvAjglQAjglA2gEIQWhUQA2gFAoAeQApAfAEAuQAEAwgkAkQgjAlg1AEIwXBWIgNAAQgtAAgkgbg");
	var mask_graphics_77 = new cjs.Graphics().p("AEEDhQgpgegEgvQgEgwAkglQAkglA2gFIQrhYQA3gEApAeQApAfAEAuQAEAwgkAlQgjAlg3AFIwrBZIgNAAQguAAglgbg");
	var mask_graphics_78 = new cjs.Graphics().p("AD8DiQgpgfgFgwQgEgwAkglQAlglA3gFIQ+hcQA3gEAqAeQAqAfAEAvQAFAwglAlQgkAmg3AEIw+BdIgOABQgvAAglgbg");
	var mask_graphics_79 = new cjs.Graphics().p("AD1DiQgqgfgFgwQgEgwAlgmQAlgmA4gEIROhfQA5gFAqAeQArAfAEAwQAFAwgmAlQgkAmg4AFIxPBgIgPABQgvAAglgbg");
	var mask_graphics_80 = new cjs.Graphics().p("ADuDiQgrgegEgxQgEgxAlgmQAlgmA5gFIRehiQA5gFArAfQAsAfAEAwQAFAwgmAmQglAmg5AFIxeBjIgQABQgvAAgmgbg");
	var mask_graphics_81 = new cjs.Graphics().p("ADoDiQgrgegFgxQgEgxAlgnQAmgmA6gFIRshlQA6gFAsAfQAsAfAEAwQAFAxgmAmQgmAmg6AGIxsBlIgQABQgwAAgmgbg");
	var mask_graphics_82 = new cjs.Graphics().p("ADjDiQgtgegEgxQgFgxAmgnQAngnA6gFIR5hnQA7gGAsAfQAtAgAEAwQAFAxgnAmQgmAng6AFIx5BoIgRABQgwAAgmgbg");
	var mask_graphics_83 = new cjs.Graphics().p("ADeDjQgtgfgFgxQgEgyAmgnQAngmA7gGISFhqQA7gFAtAfQAtAfAFAwQAEAygnAmQgmAng7AGIyFBrIgRAAQgxAAgmgag");
	var mask_graphics_84 = new cjs.Graphics().p("ADZDjQgtgfgFgyQgEgxAmgnQAngnA8gGISQhsQA7gFAtAfQAuAfAFAxQAEAxgnAnQgmAng8AGIyQBtIgRAAQgxAAgngag");
	var mask_graphics_85 = new cjs.Graphics().p("ADVDjQgugfgEgyQgFgxAngoQAngnA8gGISahtQA8gGAtAfQAvAfAEAxQAFAygoAnQgmAng9AGIyZBvIgSABQgxAAgngbg");
	var mask_graphics_86 = new cjs.Graphics().p("ADRDjQgugfgFgyQgEgyAngnQAognA8gGISihwQA9gGAuAfQAuAgAFAxQAFAxgoAoQgnAng9AGIyiBxIgSABQgyAAgngbg");
	var mask_graphics_87 = new cjs.Graphics().p("ADODjQgvgfgEgyQgFgyAngoQAognA9gGISqhxQA9gGAuAfQAvAfAFAxQAFAygoAoQgoAog8AFIyrBzIgSABQgyAAgngbg");
	var mask_graphics_88 = new cjs.Graphics().p("ADLDjQgvgfgFgyQgFgyAogoQAogoA+gFISxhzQA9gGAuAfQAwAfAFAxQAEAzgoAnQgoAog9AGIyxB0IgTABQgyAAgngbg");
	var mask_graphics_89 = new cjs.Graphics().p("ADIDjQgvgfgFgyQgFgyAogoQApgoA9gGIS4h0QA9gGAvAfQAvAfAFAyQAFAygoAoQgoAog+AGIy3B1IgTABQgyAAgogbg");
	var mask_graphics_90 = new cjs.Graphics().p("ADGDjQgvgfgFgyQgFgyAogpQAognA+gGIS9h2QA+gGAvAfQAwAgAEAyQAFAygoAnQgoAog+AHIy9B2IgTABQgyAAgogbg");
	var mask_graphics_91 = new cjs.Graphics().p("ADDDjQgvgfgFgyQgFgzApgoQAogoA+gGITCh2QA+gGAvAfQAwAfAFAzQAFAxgpAoQgoAog+AHIzCB3IgTABQgyAAgpgbg");
	var mask_graphics_92 = new cjs.Graphics().p("ADCDkQgwgggFgyQgFgzApgoQApgoA+gGITGh4QA+gGAvAgQAwAfAFAzQAFAxgpAoQgoApg+AGIzGB4IgUABQgyAAgogag");
	var mask_graphics_93 = new cjs.Graphics().p("ADADkQgvgggFgyQgFgzAogoQApgoA/gGITJh5QA+gGAwAfQAwAgAFAzQAFAxgpAoQgpApg+AGIzJB5IgUABQgyAAgpgag");
	var mask_graphics_94 = new cjs.Graphics().p("AC/DkQgwgggFgyQgFgzApgoQApgoA/gHITMh4QA+gHAwAgQAwAfAFAzQAFAygpAoQgpAog+AGIzMB6IgUABQgzAAgogag");
	var mask_graphics_95 = new cjs.Graphics().p("AC+DkQgwgggFgyQgFgzApgpQApgoA/gGITOh5QA/gGAvAfQAxAgAFAyQAFAygpAoQgpApg/AGIzOB6IgUABQgyAAgpgag");
	var mask_graphics_96 = new cjs.Graphics().p("AC9DkQgvgggFgyQgFgzAogpQApgoA/gGITQh6QA/gGAwAfQAwAgAFAzQAFAygpAoQgpAog+AHIzQB6IgVABQgyAAgpgag");
	var mask_graphics_97 = new cjs.Graphics().p("AC9DkQgwgggFgyQgFgzApgpQApgoA/gGITRh6QA/gGAwAfQAwAgAFAyQAFAygpAoQgpApg/AGIzRB7IgUABQgzAAgogag");
	var mask_graphics_98 = new cjs.Graphics().p("AC9DkQgwgggFgyQgFgzAogpQAqgoA+gGITSh6QA/gGAwAfQAxAgAFAyQAFAygqAoQgoApg/AGIzSB7IgUABQgzAAgogag");
	var mask_graphics_99 = new cjs.Graphics().p("AC/DlQgwgggFgyQgFgzAogpQAqgoA/gGITSh6QA/gHAvAgQAxAfAFAzQAFAygpAoQgpApg/AGIzSB7IgUABQgzAAgogag");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(47).to({graphics:mask_graphics_47,x:93.9942,y:23.9829}).wait(1).to({graphics:mask_graphics_48,x:94.7552,y:24.0027}).wait(1).to({graphics:mask_graphics_49,x:95.6165,y:24.0248}).wait(1).to({graphics:mask_graphics_50,x:96.5857,y:24.0495}).wait(1).to({graphics:mask_graphics_51,x:97.6704,y:24.077}).wait(1).to({graphics:mask_graphics_52,x:98.8782,y:24.1073}).wait(1).to({graphics:mask_graphics_53,x:100.2173,y:24.1406}).wait(1).to({graphics:mask_graphics_54,x:101.6955,y:24.177}).wait(1).to({graphics:mask_graphics_55,x:103.3201,y:24.2165}).wait(1).to({graphics:mask_graphics_56,x:105.0976,y:24.2592}).wait(1).to({graphics:mask_graphics_57,x:107.0327,y:24.305}).wait(1).to({graphics:mask_graphics_58,x:109.1276,y:24.3538}).wait(1).to({graphics:mask_graphics_59,x:111.3808,y:24.4055}).wait(1).to({graphics:mask_graphics_60,x:113.7858,y:24.4596}).wait(1).to({graphics:mask_graphics_61,x:116.3304,y:24.5158}).wait(1).to({graphics:mask_graphics_62,x:118.9956,y:24.5734}).wait(1).to({graphics:mask_graphics_63,x:121.7558,y:24.6318}).wait(1).to({graphics:mask_graphics_64,x:124.5793,y:24.6902}).wait(1).to({graphics:mask_graphics_65,x:127.4309,y:24.7478}).wait(1).to({graphics:mask_graphics_66,x:130.2736,y:24.8038}).wait(1).to({graphics:mask_graphics_67,x:133.0722,y:24.8577}).wait(1).to({graphics:mask_graphics_68,x:135.7953,y:24.9089}).wait(1).to({graphics:mask_graphics_69,x:138.4173,y:24.957}).wait(1).to({graphics:mask_graphics_70,x:140.9192,y:25.0019}).wait(1).to({graphics:mask_graphics_71,x:143.288,y:25.0435}).wait(1).to({graphics:mask_graphics_72,x:145.5166,y:25.0819}).wait(1).to({graphics:mask_graphics_73,x:147.6022,y:25.1171}).wait(1).to({graphics:mask_graphics_74,x:149.5456,y:25.1493}).wait(1).to({graphics:mask_graphics_75,x:151.3502,y:25.1787}).wait(1).to({graphics:mask_graphics_76,x:153.0208,y:25.2054}).wait(1).to({graphics:mask_graphics_77,x:154.5635,y:25.2298}).wait(1).to({graphics:mask_graphics_78,x:155.9848,y:25.2519}).wait(1).to({graphics:mask_graphics_79,x:157.2914,y:25.2719}).wait(1).to({graphics:mask_graphics_80,x:158.49,y:25.2901}).wait(1).to({graphics:mask_graphics_81,x:159.5871,y:25.3066}).wait(1).to({graphics:mask_graphics_82,x:160.589,y:25.3215}).wait(1).to({graphics:mask_graphics_83,x:161.5014,y:25.3349}).wait(1).to({graphics:mask_graphics_84,x:162.3299,y:25.347}).wait(1).to({graphics:mask_graphics_85,x:163.0796,y:25.3578}).wait(1).to({graphics:mask_graphics_86,x:163.7553,y:25.3675}).wait(1).to({graphics:mask_graphics_87,x:164.3615,y:25.3762}).wait(1).to({graphics:mask_graphics_88,x:164.9021,y:25.3839}).wait(1).to({graphics:mask_graphics_89,x:165.3811,y:25.3906}).wait(1).to({graphics:mask_graphics_90,x:165.8019,y:25.3966}).wait(1).to({graphics:mask_graphics_91,x:166.1678,y:25.4017}).wait(1).to({graphics:mask_graphics_92,x:166.4817,y:25.4061}).wait(1).to({graphics:mask_graphics_93,x:166.7465,y:25.4097}).wait(1).to({graphics:mask_graphics_94,x:166.9646,y:25.4128}).wait(1).to({graphics:mask_graphics_95,x:167.1385,y:25.4152}).wait(1).to({graphics:mask_graphics_96,x:167.2704,y:25.417}).wait(1).to({graphics:mask_graphics_97,x:167.3623,y:25.4183}).wait(1).to({graphics:mask_graphics_98,x:167.4161,y:25.419}).wait(1).to({graphics:mask_graphics_99,x:167.6502,y:25.51}).wait(1));

	// Layer_2 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape.setTransform(236.1662,26.9665,0.6435,0.6435);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(47).to({_off:false},0).wait(53));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_29 = new cjs.Graphics().p("APVBJQgLgEgKgKQgLgKgEgKQgEgLAFgFIBbheQAFgEAKADQALAEAKAKQALAKAEAKQAEALgFAFIhbBeQgDACgEAAIgIgBg");
	var mask_1_graphics_30 = new cjs.Graphics().p("APNBNQgKgEgLgKQgKgKgEgKQgEgLAFgFIBhhlQAFgFALADQALAEAKAKQALAKAEAKQADALgFAFIhhBlQgDADgFAAIgIgBg");
	var mask_1_graphics_31 = new cjs.Graphics().p("APFBRQgLgDgLgKQgKgKgDgLQgEgLAFgGIBphrQAFgGALADQALADALAKQAKAKAEALQADALgFAGIhpBrQgDAEgGAAIgHgBg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AO7BWQgLgDgLgKQgKgKgDgLQgEgLAGgGIBxh1QAFgGAMADQALADALAKQAKAKADALQAEALgGAGIhxB1QgEAEgGAAIgHgBg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AOxBbQgMgCgLgKQgKgKgDgMQgDgLAGgHIB6h9QAGgHAMADQALACALAKQAKAKADAMQADALgGAHIh5B9QgFAFgHAAIgGgBg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AOlBhQgMgCgKgKQgLgKgCgMQgDgMAHgHICDiHQAGgHANACQAMACAKAKQAKAKADAMQADAMgHAHIiDCHQgFAGgJAAIgFgBg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AOZBoQgNgCgKgKQgKgKgDgMQgCgNAHgHICOiTQAHgHAMABQANACAKAKQALAKACAMQACANgHAHIiOCTQgFAGgKAAIgEAAg");
	var mask_1_graphics_36 = new cjs.Graphics().p("AOMBuQgNgBgKgKQgKgKgCgNQgCgNAIgIICXidQAIgIANABQANABAKAKQALAKACANQABANgHAIIiYCdQgHAHgKAAIgEAAg");
	var mask_1_graphics_37 = new cjs.Graphics().p("AN/B1QgNgBgLgKQgKgKgBgNQgCgNAIgJICjipQAJgJANABQANABAKAKQALAKABANQACANgJAJIiiCpQgIAIgLAAIgDAAg");
	var mask_1_graphics_38 = new cjs.Graphics().p("ANyB7QgOAAgKgKQgKgKgBgOQgCgNAJgJICui1QAJgJAOABQANAAALAKQAKAKABAOQABANgJAJIiuC1QgIAIgNAAIgBAAg");
	var mask_1_graphics_39 = new cjs.Graphics().p("ANlCCQgOAAgLgKQgKgKgBgOQAAgOAJgKIC5i/QAJgKAOAAQAOAAALAKQAKAKABAOQAAAOgJAKIi5C/QgJAKgOAAIAAAAg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AM/B/QgKgJgBgPQAAgOAKgLIDEjLQAKgKAOAAQAOgBALAKQAKAKABAPQAAAOgKAKIjEDLQgKALgOAAIgBAAQgOAAgKgKg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AMyCHQgKgKAAgPQAAgPAKgLIDOjWQALgLAPAAQAOgBALAKQAKAKAAAPQAAAOgKALIjODWQgLALgPABIgCAAQgNAAgKgJg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AMmCNQgLgKABgPQAAgPALgMIDYjgQALgLAPgBQAPgBALAKQAKAJAAAQQgBAPgLALIjYDhQgLALgPABIgDAAQgNAAgJgJg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AMaCUQgKgKABgQQAAgPAMgMIDhjqQALgMAQgCQAQgBAKAKQAKAKAAAPQgBAQgMAMIjhDqQgMAMgPABIgEAAQgNAAgJgIg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AMPCaQgKgKABgQQABgQAMgNIDqjzQAMgMAQgCQAQgCAKAKQAKAKgBAQQgBAQgMAMIjqD0QgMAMgQACIgEAAQgNAAgJgIg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AMFCfQgKgKABgQQACgQAMgNIDyj8QAMgNARgCQAQgCAKAKQAKAKgBAQQgBAQgNANIjyD8QgMANgQACIgGAAQgMAAgJgIg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AL8CkQgKgKACgRQABgQANgNID5kDQANgOAQgCQARgCAKAKQAKAKgBAQQgCAQgNAOIj5EDQgNANgQACIgGABQgMAAgJgIg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AL0CoQgKgKACgRQACgQANgOID/kKQANgNARgDQARgCAKAKQAKAKgBAQQgCARgNAOIkAEJQgNAOgRACIgGABQgMAAgJgIg");
	var mask_1_graphics_48 = new cjs.Graphics().p("ALwCqQgKgKACgRQACgRANgOIEFkPQANgOARgDQARgDAKAKQALAKgCARQgCARgOAOIkFEPQgNAOgRADIgHABQgMAAgIgIg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_1_graphics_29,x:108.9581,y:6.7536}).wait(1).to({graphics:mask_1_graphics_30,x:108.9291,y:7.1592}).wait(1).to({graphics:mask_1_graphics_31,x:108.8959,y:7.6384}).wait(1).to({graphics:mask_1_graphics_32,x:108.8594,y:8.1829}).wait(1).to({graphics:mask_1_graphics_33,x:108.8207,y:8.7838}).wait(1).to({graphics:mask_1_graphics_34,x:108.7805,y:9.4316}).wait(1).to({graphics:mask_1_graphics_35,x:108.7399,y:10.1164}).wait(1).to({graphics:mask_1_graphics_36,x:108.6996,y:10.8281}).wait(1).to({graphics:mask_1_graphics_37,x:108.6601,y:11.5566}).wait(1).to({graphics:mask_1_graphics_38,x:108.6222,y:12.2919}).wait(1).to({graphics:mask_1_graphics_39,x:108.5861,y:13.0197}).wait(1).to({graphics:mask_1_graphics_40,x:108.5523,y:13.7091}).wait(1).to({graphics:mask_1_graphics_41,x:108.5207,y:14.3797}).wait(1).to({graphics:mask_1_graphics_42,x:108.4912,y:15.0231}).wait(1).to({graphics:mask_1_graphics_43,x:108.4643,y:15.6318}).wait(1).to({graphics:mask_1_graphics_44,x:108.4401,y:16.1989}).wait(1).to({graphics:mask_1_graphics_45,x:108.4186,y:16.7183}).wait(1).to({graphics:mask_1_graphics_46,x:108.3998,y:17.1845}).wait(1).to({graphics:mask_1_graphics_47,x:108.3836,y:17.593}).wait(1).to({graphics:mask_1_graphics_48,x:108.6165,y:17.7514}).wait(52));

	// Layer_2 copy
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape_1.setTransform(236.1662,26.9665,0.6435,0.6435);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(29).to({_off:false},0).wait(71));

	// Layer_3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AJRCVQgGgLgEgRQgDgRAAgNQABgNAFgBIBjgWQAFgBAGALQAGALAEARQAEARgBANQgBANgFABIhjAWIAAAAQgFAAgGgKg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AJRCVQgGgLgEgRQgEgRABgNQABgNAFgBIBjgWQAFgBAGALQAHALADARQAEARgBANQgBANgFABIhjAWIgBAAQgFAAgFgKg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AJQCVQgHgLgDgRQgEgRABgNQABgNAFgBIBmgXQAFgBAGALQAGAMAEARQAEARgBAMQgBANgFABIhmAXIgBAAQgFAAgFgKg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AJNCVQgGgLgEgRQgEgRACgNQABgNAFgBIBqgYQAGgBAGALQAHALADARQAEARgBANQgBANgGABIhqAYIgBAAQgFAAgGgKg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AJKCVQgHgMgDgRQgEgQABgNQACgNAGgCIBwgYQAGgCAGALQAHAMAEARQAEARgCAMQgBANgGACIhwAYIgBABQgGAAgGgKg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AJGCUQgHgLgEgRQgEgRACgNQACgNAGgBIB5gbQAGgBAHALQAIALADARQAEARgCANQgBANgHABIh5AbIgBAAQgGAAgGgKg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AJACUQgIgLgDgRQgEgRACgNQACgNAHgBICFgeQAHgBAIALQAHALAEARQAEARgDANQgCANgHABIiFAeIgCAAQgGAAgGgKg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AI4CUQgIgLgEgRQgDgRACgNQADgNAIgCICUghQAIgBAIAKQAIALAEARQADARgCANQgDAOgIABIiUAhIgCAAQgHAAgHgJg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AIuCUQgIgLgEgRQgEgRAEgNQADgOAJgCICoglQAIgCAJALQAJALADARQAEARgDANQgEAOgIABIioAlIgDABQgHAAgIgJg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AIjCTQgKgKgEgRQgDgRAEgOQAEgNAKgCIC/grQAKgCAKALQAJAKAEARQAEARgFAOQgEANgKACIi/ArIgDAAQgIAAgIgJg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AIUCTQgKgLgEgQQgEgRAGgOQAFgOALgCIDcgxQALgCALAKQAKAKAEARQAEARgGAOQgFAOgLACIjcAxIgEAAQgJAAgJgIg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AIECSQgMgKgEgRQgDgRAGgOQAHgOAMgDID9g3QANgDAMAKQAMAKADARQAEARgGAOQgHAOgNADIj8A3IgGABQgKAAgJgIg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AHxCRQgNgJgEgRQgDgRAHgPQAIgOAPgDIEihAQAPgDANAJQANAKAEARQADARgIAOQgHAPgPADIkiBAIgHABQgLAAgKgIg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AHdCRQgOgKgEgRQgEgRAJgOQAKgPAQgEIFKhHQARgEAOAIQAPAKAEARQADARgJAOQgJAPgRAEIlJBIIgKACQgLAAgLgHg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AHJCQQgQgJgEgRQgDgRAKgPQALgPATgEIFxhRQATgEAQAJQAQAJAEAQQADARgKAPQgLAPgTAEIlxBSIgMABQgMAAgLgGg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AG2CPQgSgIgDgRQgEgRAMgQQAMgPAVgFIGXhZQAVgEARAJQASAIAEAQQADARgMAQQgMAPgUAFImYBaQgHABgHAAQgNAAgLgGg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AGkCPQgTgJgDgRQgEgRANgPQAOgQAWgFIG7hhQAWgFATAJQATAIADARQAEAQgNAQQgOAPgWAFIm7BiQgIACgIAAQgNAAgMgFg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AGUCOQgTgIgEgRQgEgRAOgQQAPgQAYgFIHahoQAYgFAUAIQAUAJADAQQAEAQgOAQQgPAQgYAFInaBpQgJACgJAAQgOAAgMgFg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AGGCNQgUgIgEgQQgEgRAQgRQAPgQAagFIH1huQAZgFAVAIQAVAIADARQAEARgPAPQgQAQgZAFIn1BvQgLACgJAAQgOAAgNgFg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AF7CNQgWgIgDgRQgEgRAQgQQAQgQAbgGIIMhzQAbgGAVAIQAWAIAEARQAEARgRAPQgQAQgbAGIoMB0QgLADgLAAQgOAAgMgFg");
	var mask_2_graphics_29 = new cjs.Graphics().p("AFxCNQgWgIgEgRQgEgRARgQQARgRAcgGIIgh3QAcgGAWAIQAWAHAEARQAEARgSAQQgQAQgcAGIogB4QgMADgMAAQgOAAgMgEg");
	var mask_2_graphics_30 = new cjs.Graphics().p("AFnCNQgWgIgEgRQgEgRASgQQARgRAdgGIIxh7QAcgGAXAHQAXAIAEARQAEARgSAQQgRAQgdAGIoxB8QgNADgMAAQgOAAgNgEg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:70.8933,y:15.8993}).wait(10).to({graphics:mask_2_graphics_10,x:70.9412,y:15.9033}).wait(1).to({graphics:mask_2_graphics_11,x:71.1091,y:15.8952}).wait(1).to({graphics:mask_2_graphics_12,x:71.4086,y:15.8807}).wait(1).to({graphics:mask_2_graphics_13,x:71.8599,y:15.8589}).wait(1).to({graphics:mask_2_graphics_14,x:72.4867,y:15.8287}).wait(1).to({graphics:mask_2_graphics_15,x:73.3176,y:15.7889}).wait(1).to({graphics:mask_2_graphics_16,x:74.3855,y:15.7381}).wait(1).to({graphics:mask_2_graphics_17,x:75.7263,y:15.6747}).wait(1).to({graphics:mask_2_graphics_18,x:77.3754,y:15.5972}).wait(1).to({graphics:mask_2_graphics_19,x:79.3584,y:15.5049}).wait(1).to({graphics:mask_2_graphics_20,x:81.6749,y:15.398}).wait(1).to({graphics:mask_2_graphics_21,x:84.2774,y:15.2791}).wait(1).to({graphics:mask_2_graphics_22,x:87.0589,y:15.1534}).wait(1).to({graphics:mask_2_graphics_23,x:89.8689,y:15.0278}).wait(1).to({graphics:mask_2_graphics_24,x:92.559,y:14.9088}).wait(1).to({graphics:mask_2_graphics_25,x:95.0241,y:14.8007}).wait(1).to({graphics:mask_2_graphics_26,x:97.2142,y:14.7054}).wait(1).to({graphics:mask_2_graphics_27,x:99.1212,y:14.6231}).wait(1).to({graphics:mask_2_graphics_28,x:100.7607,y:14.5527}).wait(1).to({graphics:mask_2_graphics_29,x:102.1579,y:14.4931}).wait(1).to({graphics:mask_2_graphics_30,x:103.2679,y:14.4881}).wait(70));

	// Layer_2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#231F20").ss(4,1,1).p("A2QgqQAWAGAhADQBCAGA4gNQA5gMBYgdQA1gSB4gpQCzg7BWgMQBugPAbAxQANAWgfAmQgSAWg4A0Qg5AygVAaQgiAqAHAdQAMA4BqAZQBdAVDgAIQDZAIE8giQE0ghDug1QCegkD+hUQB/grBggk");
	this.shape_2.setTransform(236.1662,26.9665,0.6435,0.6435);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(100));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,329.9,47.2);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.folder_front = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Am3F6QgVAAgJgPIgEgPIiYqRQgGgaARgVQAQgVAbAAIGyAAQAeAAAaAPQAaAPAPAaIAtBOQABADAEAAIGbAAQAfAAAYAUQAYASAHAeIBsHWIANA3QgCAGgEAFQgDAEgEADQgKAHgMAAgApPlRQgIAJADAMICaKYIQLAAIAEgBIh3oAQgFgUgQgMQgQgNgUAAImbAAQgKAAgHgEQgIgFgFgJIguhOQgLgTgTgLQgTgLgWAAImyAAQgMAAgIAKg");
	this.shape.setTransform(62.7967,37.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("Am6FcIiaqYQgCgMAIgJQAHgKANAAIGyAAQAVAAATALQAUALALATIAuBOQAEAJAJAFQAHAEAJAAIGcAAQAUAAAQANQAQAMAEAUIB3IAIgEABg");
	this.shape_1.setTransform(62.7202,37.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.folder_front, new cjs.Rectangle(0,0,125.6,75.6), null);


(lib.folder_bck = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AETHSIAAgeIAOAAIADAAQAFAAACgFIELsPIAAAAQAFgPgDgOQgCgPgJgMQgJgNgNgHQgOgHgPAAIt4AAQgdAAgXARQgYAQgJAcIheEQIgFAOIggAAIAFgOIBikaQAMgkAfgXQAfgWAnAAIN4AAQAXAAAUALQATAJAOATQANASADAWQADAXgHAVIkLMOQgDAMgKAHQgKAHgMAAgAEhGWIgBgCIABgIIAGheIDkqcQADgJgGgHQgFgHgJAAIt4AAQgPAAgLAIQgLAIgFANIg2CdIgfAAIA5inQAIgWATgOQATgNAYAAIN4AAQALgBALAGQAKAFAGAJQAHAJACAMQACALgEALIAAABIkFL/g");
	this.shape.setTransform(59.92,46.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AEdG0IAAgeIABAFIEGr/IAAgBQADgLgCgLQgBgMgHgJQgHgJgKgFQgKgGgMABIt4AAQgYAAgTANQgTAOgHAWIg6CnIgBAAIgiBlIgQAAIBekQQAJgcAXgQQAXgRAdAAIN4AAQAQAAANAHQAOAHAJANQAJAMACAPQACAOgFAPIAAAAIkLMPQgBAFgGAAg");
	this.shape_1.setTransform(60.2917,46.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.folder_bck, new cjs.Rectangle(0,0,119.9,93.2), null);


(lib.fileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tileShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fileShadow, new cjs.Rectangle(0,0,196,203), null);


(lib.endUI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIFinalFrame1();
	this.instance.setTransform(86.85,14.1,0.6355,0.6354);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endUI, new cjs.Rectangle(86.9,14.1,172.79999999999998,115.70000000000002), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.cloud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ap1FwQhthrgBiZQgCiYBrhtQBrhuCagCQAvhIBHgyQBGgyBTgVQC5gwClBiQClBhAwC6QBBAEA5AfQBIAnArBGQAqBHABBSIAAACQAAB9hYBYQhYBYh9AAIsoAAIgCAAQiXAAhshrg");
	this.shape.setTransform(34.8084,22.2904,0.47,0.47);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cloud, new cjs.Rectangle(0,0,69.6,44.6), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AiQEyQhxhHgfiBQgdh7A+hsIAGgMIIjFSIgHALQhFBoh8AdQgnAJgmAAQhWAAhPgwg");
	var mask_graphics_1 = new cjs.Graphics().p("AirESQhlhXgJiFQgIh+BPhgIAIgLIHkGnIgJAKQhVBbh+AIIgZABQh1AAhbhQg");
	var mask_graphics_2 = new cjs.Graphics().p("AAcFgQiEgMhVhnQhVhnANiFQAMh9BehTIAKgJIGZHwIgLAJQhVBBhqAAQgRAAgRgCg");
	var mask_graphics_3 = new cjs.Graphics().p("AgBFXQiBgihDh0QhDhzAiiAQAhh7BqhCIALgHIFCIsIgMAHQhGAlhMAAQgqAAgrgLg");
	var mask_graphics_4 = new cjs.Graphics().p("AgbFFQh5g3gwh9Qgvh8A3h5QA0h0BzgwIANgFIDiJaIgMAFQgzARgzAAQhCAAhBgeg");
	var mask_graphics_5 = new cjs.Graphics().p("AgwEsQhvhKgaiDQgaiCBKhvQBGhpB4gdIAOgDIB+J3IgNACQgcAFgaAAQhdAAhRg3g");
	var mask_graphics_6 = new cjs.Graphics().p("Ag/EMQhihbgEiGQgFiEBbhiQBWhcB8gJIAOAAIAVKCIgNABQh9gBhbhWg");
	var mask_graphics_7 = new cjs.Graphics().p("ABVFgQh6gVhNhlQhRhpARiEQARiEBqhRQBkhNB8AMIANABIhUJ9IgNgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AAIFYQh1gog7hwQg/h2Anh+QAmiAB2g/QBvg8B4AgIANAEIi7JnIgNgEg");
	var mask_graphics_9 = new cjs.Graphics().p("AhAFNQhtg7gph4Qgrh/A7h2QA8h4B+grQB3gpBxA0IANAFIkcJBIgNgGg");
	var mask_graphics_10 = new cjs.Graphics().p("AiCE+QhjhNgUh9QgWiCBOhtQBOhsCCgWQB9gUBoBFIALAHIl2ILIgLgIg");
	var mask_graphics_11 = new cjs.Graphics().p("Ai+ErQhUhbAAh/QAAiEBfheQBehfCEAAQB/ABBbBVIAKAJInHHGIgKgKg");
	var mask_graphics_12 = new cjs.Graphics().p("AjvEWQhEhoAVh9QAViCBthOQBthOCCAWQB9AVBMBjIAIALIoLF1IgIgLg");
	var mask_graphics_13 = new cjs.Graphics().p("AkVD/QgzhyAph4QArh9B4g7QB4g7B9ArQB4ApA7BuIAGAMIpBEbIgGgMg");
	var mask_graphics_14 = new cjs.Graphics().p("AkwDmQgfh5A8huQA/h2CAgmQB+gnB2A/QBvA8AoB1IAFANIpoC6IgEgNg");
	var mask_graphics_15 = new cjs.Graphics().p("Ak/DMQgLh8BOhkQBRhpCEgRQCEgRBpBRQBlBOAUB6IACANIp+BSIgCgNg");
	var mask_graphics_16 = new cjs.Graphics().p("AlBC0IABgOQAJh8BchVQBihbCEAFQCGAEBbBiQBWBcAAB8IAAAOg");
	var mask_graphics_17 = new cjs.Graphics().p("Ak+BmIADgOQAdh4BphGQBwhKCBAbQCDAaBKBvQBGBpgVB7IgCANg");
	var mask_graphics_18 = new cjs.Graphics().p("Ak3AaIAFgNQAwhyB0g0QB6g2B7AvQB9AwA3B4QA0B0gpB2IgEANg");
	var mask_graphics_19 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_20 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_21 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_22 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_23 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_24 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_25 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_26 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_27 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_28 = new cjs.Graphics().p("AksgtIAHgMQBDhpB7ggQB/giB0BDQBzBDAiCAQAgB7g7BtIgGAMg");
	var mask_graphics_29 = new cjs.Graphics().p("AksgqIAHgMQBChpB6giQCAgjBzBDQB0BCAjCAQAhB6g6BuIgGAMg");
	var mask_graphics_30 = new cjs.Graphics().p("AkuggIAGgMQBAhrB5gkQB/gmB2A/QB1BAAmB/QAkB5g4BwIgGAMg");
	var mask_graphics_31 = new cjs.Graphics().p("AkxgOIAGgMQA6huB4gpQB9grB4A6QB4A7AsB9QApB4gzBxIgFANg");
	var mask_graphics_32 = new cjs.Graphics().p("Ak2APIAFgNQA0hwB1gyQB7gzB6AyQB8AzAzB5QAyB1grB1IgFANg");
	var mask_graphics_33 = new cjs.Graphics().p("Ak7A6IAEgNQAoh1Bwg8QB1g/B/AmQCAAnA/B1QA8BvgfB4IgEANg");
	var mask_graphics_34 = new cjs.Graphics().p("Ak/B4IACgOQAYh5BnhKQBshOCDAVQCEAWBOBsQBKBlgQB8IgBAOg");
	var mask_graphics_35 = new cjs.Graphics().p("AlBC5QADh8BYhaQBdhgCFgCQCFgCBfBdQBbBYAHB8IAAAOIqDAJIAAgOg");
	var mask_graphics_36 = new cjs.Graphics().p("Ak2DdQgZh6BChrQBFhyCCggQCAggByBGQBtBBAhB3IAEANIpxCaIgDgOg");
	var mask_graphics_37 = new cjs.Graphics().p("AkIEIQg6hvAih6QAjiAB0hCQB0hCCAAjQB6AiBBBqIAHALIouE/IgHgMg");
	var mask_graphics_38 = new cjs.Graphics().p("AirEyQhahXgGh/QgHiEBZhjQBZhjCEgHQB/gHBfBQIALAJImuHeIgKgJg");
	var mask_graphics_39 = new cjs.Graphics().p("AgmFSQhxg1gwh2Qgyh7A0h6QA0h7B8gyQB0gwB1AtIAMAFIj6JQIgMgFg");
	var mask_graphics_40 = new cjs.Graphics().p("ABpFhQh7gPhRhiQhWhmAMiFQAMiEBmhVQBghSB9AHIANABIg5KAIgNgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AgyEqQhthMgZiDQgYiDBMhtQBIhpB5gbIANgCIB0J4IgNADQgZADgXAAQhgAAhTg5g");
	var mask_graphics_42 = new cjs.Graphics().p("AgUFLQh8gxg1h7Qg1h6Ayh7QAvh2Bwg1IANgGID9JPIgMAFQg5AWg5AAQg8AAg7gYg");
	var mask_graphics_43 = new cjs.Graphics().p("AAJFcQiCgahKhvQhKhvAaiCQAZh8BlhJIALgIIFlIXIgLAHQhNAwhXAAQghAAgigHg");
	var mask_graphics_44 = new cjs.Graphics().p("AAlFiQiEgGhahjQhZhjAGiFQAGh+BahXIAKgJIGvHcIgKAJQhYBLh0AAIgSgBg");
	var mask_graphics_45 = new cjs.Graphics().p("AirETQhlhYgJiFQgIh9BOhhIAJgKIHkGmIgJAKQhVBbh+AJIgZABQh1AAhbhQg");
	var mask_graphics_46 = new cjs.Graphics().p("AidElQhshOgViDQgUh8BFhoIAIgLIIJF4IgIALQhNBih9AUQgcAFgbAAQhjAAhVg+g");
	var mask_graphics_47 = new cjs.Graphics().p("AiQEyQhxhHgfiBQgdh7A+hsIAGgMIIjFSIgHALQhFBoh8AdQgnAJgmAAQhWAAhPgwg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:8.6073,y:35.439}).wait(1).to({graphics:mask_graphics_1,x:7.1492,y:35.4034}).wait(1).to({graphics:mask_graphics_2,x:5.3328,y:35.4082}).wait(1).to({graphics:mask_graphics_3,x:3.2159,y:35.4465}).wait(1).to({graphics:mask_graphics_4,x:0.9002,y:35.4714}).wait(1).to({graphics:mask_graphics_5,x:-1.5417,y:35.4715}).wait(1).to({graphics:mask_graphics_6,x:-4.0684,y:35.4696}).wait(1).to({graphics:mask_graphics_7,x:-2.4653,y:35.3472}).wait(1).to({graphics:mask_graphics_8,x:0.1312,y:34.8232}).wait(1).to({graphics:mask_graphics_9,x:2.6168,y:33.8891}).wait(1).to({graphics:mask_graphics_10,x:4.9284,y:32.57}).wait(1).to({graphics:mask_graphics_11,x:6.9729,y:30.9013}).wait(1).to({graphics:mask_graphics_12,x:8.6536,y:28.9279}).wait(1).to({graphics:mask_graphics_13,x:9.9664,y:26.7026}).wait(1).to({graphics:mask_graphics_14,x:10.9077,y:24.2854}).wait(1).to({graphics:mask_graphics_15,x:11.4493,y:21.7411}).wait(1).to({graphics:mask_graphics_16,x:11.5705,y:20.2866}).wait(1).to({graphics:mask_graphics_17,x:11.8561,y:22.9329}).wait(1).to({graphics:mask_graphics_18,x:12.5505,y:25.4885}).wait(1).to({graphics:mask_graphics_19,x:13.582,y:27.8317}).wait(1).to({graphics:mask_graphics_20,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_21,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_22,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_23,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_24,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_25,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_26,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_27,x:13.582,y:27.8318}).wait(1).to({graphics:mask_graphics_28,x:13.582,y:27.8317}).wait(1).to({graphics:mask_graphics_29,x:13.5269,y:27.7301}).wait(1).to({graphics:mask_graphics_30,x:13.3528,y:27.397}).wait(1).to({graphics:mask_graphics_31,x:13.0532,y:26.7771}).wait(1).to({graphics:mask_graphics_32,x:12.6373,y:25.7908}).wait(1).to({graphics:mask_graphics_33,x:12.1455,y:24.3293}).wait(1).to({graphics:mask_graphics_34,x:11.683,y:22.2554}).wait(1).to({graphics:mask_graphics_35,x:11.4891,y:19.9001}).wait(1).to({graphics:mask_graphics_36,x:11.0318,y:23.4572}).wait(1).to({graphics:mask_graphics_37,x:9.4064,y:27.5565}).wait(1).to({graphics:mask_graphics_38,x:6.2299,y:31.4869}).wait(1).to({graphics:mask_graphics_39,x:1.652,y:34.2856}).wait(1).to({graphics:mask_graphics_40,x:-3.2212,y:35.4482}).wait(1).to({graphics:mask_graphics_41,x:-1.8439,y:35.5159}).wait(1).to({graphics:mask_graphics_42,x:1.5118,y:35.5182}).wait(1).to({graphics:mask_graphics_43,x:4.0492,y:35.4851}).wait(1).to({graphics:mask_graphics_44,x:5.884,y:35.4554}).wait(1).to({graphics:mask_graphics_45,x:7.158,y:35.4582}).wait(1).to({graphics:mask_graphics_46,x:8.0316,y:35.4766}).wait(1).to({graphics:mask_graphics_47,x:8.6073,y:35.439}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AieAOQABgaABgfQAFhBAKgZQAKAfAlBaIBGiWIADCcIBwhjIg5CHIA4gHQA5gHAMAAQgMARhbA7IApAPQArAPAGAFIhOAk");
	this.shape.setTransform(17.15,28.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.3,10.8,33.800000000000004,34.599999999999994);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AotCHIAAkNIRbAAIAAENg");
	this.shape.setTransform(50.05,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-5.7,0,111.60000000000001,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.add1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Group332x();
	this.instance.setTransform(-34,-29.6,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.add1, new cjs.Rectangle(-34,-29.6,160,264), null);


(lib.Tween4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.folder.cache(0,0,130,80,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.folder = new lib.folder_front();
	this.folder.name = "folder";
	this.folder.setTransform(0,0,1,1,0,0,0,62.8,37.8);

	this.timeline.addTween(cjs.Tween.get(this.folder).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.8,-37.8,125.6,75.6);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.iconFolderBack = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.folder.cache(0,0,130,100,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.folder = new lib.folder_bck();
	this.folder.name = "folder";
	this.folder.setTransform(59.9,46.6,1,1,0,0,0,59.9,46.6);

	this.timeline.addTween(cjs.Tween.get(this.folder).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconFolderBack, new cjs.Rectangle(0,0,119.9,93.2), null);


(lib.iconFolder = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_35 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(35).call(this.frame_35).wait(1));

	// folderFront
	this.instance = new lib.Tween4("synched",0);
	this.instance.setTransform(62.95,93.2,1,1.0834,0,12.0418,0,0.2,37.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:71.3002,y:53.1491},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({startPosition:0},0).wait(1).to({regX:0.2,regY:37.8,x:62.95,y:93.2},0).wait(1).to({regX:0,regY:0,scaleY:1.0809,skewX:11.6821,x:71.0293,y:53.1887},0).wait(1).to({scaleY:1.0764,skewX:11.0269,x:70.5381,y:53.2655},0).wait(1).to({scaleY:1.0694,skewX:9.9954,x:69.7703,y:53.3985},0).wait(1).to({scaleY:1.0592,skewX:8.5188,x:68.6838,y:53.6143},0).wait(1).to({scaleY:1.0463,skewX:6.6255,x:67.3137,y:53.9335},0).wait(1).to({scaleY:1.032,skewX:4.5423,x:65.8376,y:54.3386},0).wait(1).to({scaleY:1.0187,skewX:2.5985,x:64.4918,y:54.7658},0).wait(1).to({scaleY:1.0076,skewX:0.991,x:63.4031,y:55.1537},0).wait(1).to({scaleY:0.9991,skewX:-0.2536,x:62.5758,y:55.475},0).wait(1).to({scaleY:0.9927,skewX:-1.1831,x:61.9671,y:55.7266},0).wait(1).to({scaleY:0.9881,skewX:-1.8564,x:61.5312,y:55.9149},0).wait(1).to({scaleY:0.9849,skewX:-2.3238,x:61.2311,y:56.0485},0).wait(1).to({scaleY:0.9828,skewX:-2.6247,x:61.039,y:56.1358},0).wait(1).to({scaleY:0.9817,skewX:-2.7889,x:60.9345,y:56.1839},0).wait(1).to({regX:0.1,regY:37.9,scaleY:0.9814,skewX:-2.8394,x:62.9,y:93.3},0).wait(1).to({regX:0,regY:0,scaleY:0.9832,skewX:-2.5574,x:61.1156,y:56.0663},0).wait(1).to({scaleY:0.9882,skewX:-1.806,x:61.5604,y:55.8482},0).wait(1).to({scaleY:0.9943,skewX:-0.8754,x:62.1182,y:55.5869},0).wait(1).to({scaleY:0.998,skewX:-0.316,x:62.4572,y:55.4345},0).wait(1).to({scaleY:0.9996,skewX:-0.0661,x:62.6096,y:55.3676},0).wait(1).to({regY:37.8,scaleY:1,skewX:0,x:62.8,y:93.2},0).wait(1));

	// folderBack
	this.instance_1 = new lib.iconFolderBack();
	this.instance_1.setTransform(94,93.2,1,1.093,0,-17.8671,0,60,93.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:59.9,regY:46.6,x:78.25,y:44.75},0).wait(13).to({regX:60,regY:93.2,x:94,y:93.2},0).wait(1).to({regX:59.9,regY:46.6,scaleY:1.0901,skewX:-17.3684,x:78.65,y:44.75},0).wait(1).to({scaleY:1.0849,skewX:-16.4601,x:79.45},0).wait(1).to({scaleY:1.0767,skewX:-15.0301,x:80.7},0).wait(1).to({scaleY:1.0649,skewX:-12.9828,x:82.45,y:44.9},0).wait(1).to({scaleY:1.0498,skewX:-10.3581,x:84.7,y:45.1},0).wait(1).to({scaleY:1.0332,skewX:-7.4699,x:87.05,y:45.55},0).wait(1).to({scaleY:1.0177,skewX:-4.7751,x:89.25,y:46},0).wait(1).to({scaleY:1.0049,skewX:-2.5466,x:91,y:46.5},0).wait(1).to({scaleY:0.9949,skewX:-0.821,x:92.3,y:46.85},0).wait(1).to({scaleY:0.9875,skewX:0.4677,x:93.25,y:47.2},0).wait(1).to({scaleY:0.9822,skewX:1.4011,x:94,y:47.45},0).wait(1).to({scaleY:0.9784,skewX:2.0491,x:94.45,y:47.65},0).wait(1).to({scaleY:0.976,skewX:2.4661,x:94.8,y:47.8},0).wait(1).to({scaleY:0.9747,skewX:2.6938,x:94.9,y:47.85},0).wait(1).to({regX:60,regY:93.2,scaleY:0.9743,skewX:2.7639,x:92.9,y:93.25},0).wait(1).to({regX:59.9,regY:46.6,scaleY:0.9769,skewX:2.4893,x:94.75,y:47.75},0).wait(1).to({scaleY:0.9837,skewX:1.7579,x:94.2,y:47.35},0).wait(1).to({scaleY:0.9921,skewX:0.8521,x:93.45,y:47},0).wait(1).to({scaleY:0.9972,skewX:0.3076,x:93.05,y:46.7},0).wait(1).to({scaleY:0.9994,skewX:0.0643,x:92.85,y:46.6},0).wait(1).to({regY:93.2,scaleY:1,skewX:0,y:93.2},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.4,-3.7,160.6,97);


(lib.iconCloud = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.cloud.cache(0,0,75,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cloud = new lib.cloud();
	this.cloud.name = "cloud";
	this.cloud.setTransform(34.8,22.3,1,1,0,0,0,34.8,22.3);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconCloud, new cjs.Rectangle(0,0,69.6,44.6), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(-250,-10,500,20,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.file5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.BookReport();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(88.5,123.5,0.903,1.2168,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file5, new cjs.Rectangle(0,0,177,247), null);


(lib.file4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.university();
	this.instance.setTransform(0,0,0.377,0.377);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(52.15,61.2,0.5321,0.5321,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file4, new cjs.Rectangle(0,0,104.3,115.2), null);


(lib.file3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer22x();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(98,101.5,1,1,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file3, new cjs.Rectangle(0,0,196,203), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Layer12x();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(98,101.5,1,1,0,0,0,98,101.5);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file1, new cjs.Rectangle(0,0,196,203), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AlsHuQhhg9gahxQgbhxA9hjQA+hiBxgZMAijgIBQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BjhxAZMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_54 = new cjs.Graphics().p("AlvHuQhig9gahxQgahxA8hjQA+hiBxgZMAijgIBQBxgaBiA8QBjA+AaBxQAaBxg+BiQg9BjhwAZMgijAIBQgiAIggAAQhNAAhFgrg");
	var mask_graphics_55 = new cjs.Graphics().p("Al9HuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AaBxQAbBxg/BiQg8BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_56 = new cjs.Graphics().p("AmaHuQhig9gahxQgahxA9hjQA+hiBwgZMAijgIBQBxgaBiA8QBjA+AaBxQAbBxg/BiQg8BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_57 = new cjs.Graphics().p("AnNHuQhig9gahxQgahxA9hjQA+hiBxgZMAijgIBQBwgaBiA8QBjA+AaBxQAbBxg+BiQg9BjhxAZMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_58 = new cjs.Graphics().p("AoSH8Qhhg9gbhxQgahwA9hjQA+hiBxgZMAijgICQBxgaBhA9QBjA+AbBxQAaBwg+BiQg9BihxAaMgijAICQghAIghAAQhMAAhGgsg");
	var mask_graphics_59 = new cjs.Graphics().p("ApUIMQhig9gahxQgahxA8hjQA/hiBwgaMAijgIAQBxgbBiA9QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhMAAhGgrg");
	var mask_graphics_60 = new cjs.Graphics().p("AqJIYQhig9gahxQgahxA9hjQA+hiBxgaMAijgIAQBwgaBiA9QBjA9AaBxQAbBxg/BiQg8BihxAaMgijAIBQghAIghAAQhMAAhGgrg");
	var mask_graphics_61 = new cjs.Graphics().p("AqxIhQhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg9BihwAaMgijAICQgiAIggAAQhNAAhFgsg");
	var mask_graphics_62 = new cjs.Graphics().p("ArQIoQhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBwg+BiQg9BihwAbMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_63 = new cjs.Graphics().p("ArpIuQhhg9gbhxQgahxA9hjQA+hiBxgaMAijgIAQBxgaBhA9QBkA9AaBxQAaBxg+BiQg9BihxAaMgijAICQghAHggAAQhNAAhGgrg");
	var mask_graphics_64 = new cjs.Graphics().p("Ar8IyQhhg9gbhwQgahxA9hjQA+hiBxgaMAijgIBQBxgaBhA9QBkA+AaBxQAaBwg+BiQg9BihxAbMgijAIBQghAIggAAQhNAAhGgsg");
	var mask_graphics_65 = new cjs.Graphics().p("AsLI2Qhhg9gbhxQgahxA9hjQA+hiBxgaMAijgIAQBxgaBhA8QBkA+AaBxQAaBxg+BiQg9BihxAaMgijAIBQghAIggAAQhNAAhGgrg");
	var mask_graphics_66 = new cjs.Graphics().p("AsWI4Qhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_67 = new cjs.Graphics().p("AsfI6Qhig8gahxQgahxA8hjQA+hiBxgaMAijgIAQBxgbBiA9QBjA+AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_68 = new cjs.Graphics().p("AsmI8Qhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg8BihxAaMgijAICQgiAIggAAQhMAAhGgsg");
	var mask_graphics_69 = new cjs.Graphics().p("AsrI9Qhig9gahwQgahxA8hjQA/hiBwgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBwg+BiQg8BihxAbMgijAIBQgiAIggAAQhMAAhGgsg");
	var mask_graphics_70 = new cjs.Graphics().p("AsuI+Qhig9gahxQgahwA8hjQA+hiBxgbMAijgIAQBxgaBiA9QBjA+AaBwQAaBxg+BiQg9BihwAaMgijAICQgiAHggAAQhNAAhFgrg");
	var mask_graphics_71 = new cjs.Graphics().p("AswI+Qhig9gahwQgahxA8hjQA+hiBxgaMAijgIBQBxgaBiA9QBjA+AaBxQAaBxg+BiQg8BihxAaMgijAIBQgiAIggAAQhNAAhFgsg");
	var mask_graphics_72 = new cjs.Graphics().p("AswI+Qhig9gahxQgahxA8hjQA+hiBxgaMAijgIAQBxgaBiA9QBjA9AaBxQAaBxg+BiQg9BihwAaMgijAIBQgiAIggAAQhNAAhFgrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:227.651,y:48.9317}).wait(1).to({graphics:mask_graphics_54,x:227.2796,y:49.1034}).wait(1).to({graphics:mask_graphics_55,x:225.9169,y:49.7334}).wait(1).to({graphics:mask_graphics_56,x:223.015,y:51.0749}).wait(1).to({graphics:mask_graphics_57,x:217.9249,y:53.4281}).wait(1).to({graphics:mask_graphics_58,x:211.0421,y:55.1619}).wait(1).to({graphics:mask_graphics_59,x:204.403,y:56.6965}).wait(1).to({graphics:mask_graphics_60,x:199.1193,y:57.9179}).wait(1).to({graphics:mask_graphics_61,x:195.0814,y:58.8512}).wait(1).to({graphics:mask_graphics_62,x:191.9736,y:59.5696}).wait(1).to({graphics:mask_graphics_63,x:189.5515,y:60.1295}).wait(1).to({graphics:mask_graphics_64,x:187.6486,y:60.5693}).wait(1).to({graphics:mask_graphics_65,x:186.1511,y:60.9155}).wait(1).to({graphics:mask_graphics_66,x:184.9786,y:61.1865}).wait(1).to({graphics:mask_graphics_67,x:184.0731,y:61.3958}).wait(1).to({graphics:mask_graphics_68,x:183.3911,y:61.5534}).wait(1).to({graphics:mask_graphics_69,x:182.8992,y:61.6671}).wait(1).to({graphics:mask_graphics_70,x:182.5714,y:61.7429}).wait(1).to({graphics:mask_graphics_71,x:182.3868,y:61.7856}).wait(1).to({graphics:mask_graphics_72,x:182.376,y:61.7226}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(158.5,85.75,0.9423,0.9423,8.9317,0,0,42.2,17.1);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_45 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_46 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_47 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_48 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_49 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_50 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_51 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOrQBpAvAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_52 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_53 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");
	var mask_1_graphics_54 = new cjs.Graphics().p("AOULUMggOgOqQhqgwgphtQgohsAwhpQAwhpBsgqQBtgoBpAwMAgPAOqQBpAwAoBsQApBtgwBqQgwBphtAoQgyATgxAAQg6AAg4gag");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-14.8503,y:-21.3471}).wait(1).to({graphics:mask_1_graphics_45,x:-12.0762,y:-20.0886}).wait(1).to({graphics:mask_1_graphics_46,x:-4.0254,y:-16.4364}).wait(1).to({graphics:mask_1_graphics_47,x:8.5139,y:-10.7478}).wait(1).to({graphics:mask_1_graphics_48,x:24.3145,y:-3.5798}).wait(1).to({graphics:mask_1_graphics_49,x:41.8296,y:4.3659}).wait(1).to({graphics:mask_1_graphics_50,x:59.3446,y:12.3117}).wait(1).to({graphics:mask_1_graphics_51,x:75.1452,y:19.4797}).wait(1).to({graphics:mask_1_graphics_52,x:87.6846,y:25.1682}).wait(1).to({graphics:mask_1_graphics_53,x:95.7353,y:28.8205}).wait(1).to({graphics:mask_1_graphics_54,x:98.0997,y:29.7529}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(149.25,52.65,0.9423,0.9423,8.9317,0,0,57.6,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AlOFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_39 = new cjs.Graphics().p("AluFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_40 = new cjs.Graphics().p("AnHFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhJBYQhJBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_41 = new cjs.Graphics().p("ApJFRQhZhJgMhzQgMhzBIhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_42 = new cjs.Graphics().p("ArYFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhKBYQhIBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_43 = new cjs.Graphics().p("AtaFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_44 = new cjs.Graphics().p("AuzFRQhahJgMhzQgMhzBIhZQBKhaBzgMMAjPgDwQBzgMBaBIQBbBKAMBzQAMBzhKBYQhIBbhzAMMgjPADwQgRACgQAAQhfAAhOg/g");
	var mask_2_graphics_45 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_46 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_47 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_48 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_49 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_50 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_51 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_52 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_53 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_54 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_55 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_56 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_57 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_58 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_59 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_60 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_61 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_62 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_63 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_64 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_65 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_66 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_67 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_68 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_69 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_70 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_71 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");
	var mask_2_graphics_72 = new cjs.Graphics().p("AvTFRQhZhJgMhzQgNhzBJhZQBJhaBzgMMAjQgDwQBzgMBZBIQBbBKAMBzQANBzhKBYQhIBbhzAMMgjQADwQgQACgQAAQhgAAhOg/g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:237.811,y:3.6926}).wait(1).to({graphics:mask_2_graphics_39,x:234.616,y:4.3817}).wait(1).to({graphics:mask_2_graphics_40,x:225.6604,y:6.3124}).wait(1).to({graphics:mask_2_graphics_41,x:212.7192,y:9.1024}).wait(1).to({graphics:mask_2_graphics_42,x:198.3555,y:12.1991}).wait(1).to({graphics:mask_2_graphics_43,x:185.4143,y:14.9891}).wait(1).to({graphics:mask_2_graphics_44,x:176.4587,y:16.9198}).wait(1).to({graphics:mask_2_graphics_45,x:173.311,y:17.3426}).wait(1).to({graphics:mask_2_graphics_46,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_47,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_48,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_49,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_50,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_51,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_52,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_53,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_54,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_55,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_56,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_57,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_58,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_59,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_60,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_61,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_62,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_63,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_64,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_65,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_66,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_67,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_68,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_69,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_70,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_71,x:173.3122,y:17.3426}).wait(1).to({graphics:mask_2_graphics_72,x:173.311,y:17.3426}).wait(1));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(156.85,22.8,0.9423,0.9423,8.9317,0,0,60.6,16.6);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AO8KeMghCgM1QhsgqgvhrQguhqAqhsQAqhrBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBrhqAuQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AO8KgMghCgM1QhsgqgvhrQguhqAqhrQAqhsBqgwQBqguBsAqMAhCAM2QBsAqAuBpQAvBrgqBsQgqBshqAtQg4Aag5AAQgyAAgzgUg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-3.6977,y:-69.3836}).wait(1).to({graphics:mask_3_graphics_32,x:-0.2049,y:-68.2125}).wait(1).to({graphics:mask_3_graphics_33,x:9.8522,y:-64.2339}).wait(1).to({graphics:mask_3_graphics_34,x:25.2605,y:-58.1383}).wait(1).to({graphics:mask_3_graphics_35,x:44.1617,y:-50.661}).wait(1).to({graphics:mask_3_graphics_36,x:64.2759,y:-42.7038}).wait(1).to({graphics:mask_3_graphics_37,x:83.1771,y:-35.2265}).wait(1).to({graphics:mask_3_graphics_38,x:98.5854,y:-29.1309}).wait(1).to({graphics:mask_3_graphics_39,x:108.6425,y:-25.1523}).wait(1).to({graphics:mask_3_graphics_40,x:111.8523,y:-23.7442}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(161.75,-4.7,0.9423,0.9423,8.9317,0,0,59.9,12.9);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("AlKDsQhWhPgEh1QgFh0BPhYQBQhVB2gFMAj8gBeQB1gFBWBPQBXBRAFB1QAFB0hRBWQhPBXh1AFMgj8ABeIgNAAQhuAAhShMg");
	var mask_4_graphics_20 = new cjs.Graphics().p("AlNDtQhWhQgFh1QgFh0BPhXQBRhWB1gFMAj8gBeQB1gFBWBPQBXBRAFB1QAFB0hQBWQhQBXh1AFMgj8ABeIgNAAQhtAAhShLg");
	var mask_4_graphics_21 = new cjs.Graphics().p("AlZDtQhVhPgFh1QgFh1BPhXQBQhWB2gFMAj7gBdQB1gFBWBPQBXBQAFB2QAFB0hQBWQhQBXh1AFMgj7ABdIgNABQhtAAhThMg");
	var mask_4_graphics_22 = new cjs.Graphics().p("AluDuQhWhPgFh2QgFh0BPhXQBRhWB1gEMAj6gBeQB1gFBWBPQBXBQAFB1QAFB1hRBWQhPBXh1AEMgj6ABeIgNABQhtAAhShMg");
	var mask_4_graphics_23 = new cjs.Graphics().p("AmSDvQhWhPgFh1QgFh0BPhXQBRhWB1gFMAj4gBeQB1gEBWBPQBXBQAFB1QAFB0hRBWQhPBXh1AFMgj4ABeIgNAAQhtAAhShMg");
	var mask_4_graphics_24 = new cjs.Graphics().p("AnJDxQhWhPgFh1QgFh0BPhXQBRhVB0gFMAj2gBeQB1gFBWBPQBXBQAEB1QAFB0hQBWQhPBXh1AFMgj1ABdIgNABQhtAAhShMg");
	var mask_4_graphics_25 = new cjs.Graphics().p("AoYD0QhVhPgFh1QgFhzBPhXQBQhWB1gEMAjygBeQB0gFBWBPQBXBQAEB1QAFB0hQBVQhPBXh0AFMgjyABdIgNAAQhtAAhShLg");
	var mask_4_graphics_26 = new cjs.Graphics().p("Ap5D4QhWhPgEh1QgFhzBOhXQBQhVB1gFMAjsgBdQB1gFBVBPQBXBQAEB0QAFB0hQBVQhOBXh1AEMgjsABeIgNAAQhtAAhRhLg");
	var mask_4_graphics_27 = new cjs.Graphics().p("ArdD7QhVhOgFh0QgFh0BOhWQBQhVB0gFMAjogBdQB0gFBVBPQBXBPAEB1QAFBzhQBVQhOBWh0AFMgjoABdIgNAAQhsAAhRhLg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AsyD8QhVhOgEh0QgFhzBOhWQBQhVB0gFMAjjgBdQB0gFBVBPQBWBPAFB0QAFBzhQBVQhOBWh0AFMgjjABdIgNAAQhsAAhShLg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AtyD8QhUhOgFh0QgFhzBOhWQBQhVB0gFMAjfgBdQB0gEBVBOQBWBPAFB0QAFBzhQBVQhOBWh0AFMgjgABdIgNAAQhrAAhShLg");
	var mask_4_graphics_30 = new cjs.Graphics().p("AuhD8QhUhOgFh0QgFhzBOhWQBQhVBzgEMAjegBdQB0gFBUBOQBWBPAFB0QAFBzhQBVQhOBWhzAEMgjeABdIgNAAQhrAAhShKg");
	var mask_4_graphics_31 = new cjs.Graphics().p("AvCD7QhVhOgEhzQgFhzBOhWQBPhVB0gEMAjbgBdQB0gFBVBOQBWBQAEBzQAFBzhPBVQhOBWh0AEMgjbABdIgNAAQhsAAhRhLg");
	var mask_4_graphics_32 = new cjs.Graphics().p("AvZD7QhVhOgFhzQgFhzBOhWQBQhUBzgFMAjbgBdQBzgEBVBOQBWBPAFBzQAEBzhPBVQhOBVh0AFMgjaABdIgNAAQhrAAhRhLg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:244.7016,y:-34.9424}).wait(1).to({graphics:mask_4_graphics_20,x:244.3472,y:-34.9261}).wait(1).to({graphics:mask_4_graphics_21,x:243.1435,y:-34.8696}).wait(1).to({graphics:mask_4_graphics_22,x:240.823,y:-34.7608}).wait(1).to({graphics:mask_4_graphics_23,x:237.0001,y:-34.5814}).wait(1).to({graphics:mask_4_graphics_24,x:231.1632,y:-34.3076}).wait(1).to({graphics:mask_4_graphics_25,x:222.8632,y:-33.9182}).wait(1).to({graphics:mask_4_graphics_26,x:212.471,y:-33.4307}).wait(1).to({graphics:mask_4_graphics_27,x:201.8599,y:-32.9329}).wait(1).to({graphics:mask_4_graphics_28,x:192.9168,y:-32.3021}).wait(1).to({graphics:mask_4_graphics_29,x:186.1133,y:-31.7109}).wait(1).to({graphics:mask_4_graphics_30,x:181.1361,y:-31.2783}).wait(1).to({graphics:mask_4_graphics_31,x:177.5694,y:-30.9684}).wait(1).to({graphics:mask_4_graphics_32,x:175.0798,y:-30.7522}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(169,-28.55,0.9423,0.9423,8.9317,0,0,63.6,13);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-71,261.8,279);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pptLogo copy
	this.pptLogo = new lib.pptLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(128.4,42,0.71,0.71,0,0,0,67.6,44.1);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	// mobile
	this.ad1 = new lib.add1();
	this.ad1.name = "ad1";
	this.ad1.setTransform(95.85,103.45,0.4526,0.4526,0,0,0,76.7,70);

	this.timeline.addTween(cjs.Tween.get(this.ad1).wait(1));

	// files 3 - 4
	this.file3 = new lib.file5();
	this.file3.name = "file3";
	this.file3.setTransform(390.65,53.65,0.3599,0.3599,0,0,0,83,91.4);

	this.file4 = new lib.file4();
	this.file4.name = "file4";
	this.file4.setTransform(194.95,83.95,0.5914,0.5914,0,0,0,46.6,61.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file4},{t:this.file3}]}).wait(1));

	// files 1 - 2
	this.file2 = new lib.file3();
	this.file2.name = "file2";
	this.file2.setTransform(371.7,78.95,0.2297,0.2297,0,0,0,83.4,91.5);

	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(64.5,76,0.23,0.23,0,0,0,78.7,83.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file1},{t:this.file2}]}).wait(1));

	// endUI
	this.endUI = new lib.endUI();
	this.endUI.name = "endUI";
	this.endUI.setTransform(225.85,146,1,1,0,0,0,187.5,125.5);

	this.timeline.addTween(cjs.Tween.get(this.endUI).wait(1));

	// ODUI
	this.instance = new lib.W10_20H1_Surface_OneDrive_Vault_3x2_enUSBTSEdits2x1();
	this.instance.setTransform(125.4,34.9,0.23,0.23);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(202.8,104.3,0.4421,0.4421,0,0,0,196.8,134.3);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-44.4,-115.8,527.2,439.3), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ABzEZQgDgBgDgDIgDgDIgcgrQgDgIgHgFQgGgEgLgCIoxAAIAAnrIP8AAIAAIwg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:433.55,y:40.7}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(205.5,150.3,1,1,0,0,0,205.5,150.3);

	var maskedShapeInstanceList = [this.ui];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.2,15.8,464.7,162);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-21.7,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.CTAbg},{t:this.popRight},{t:this.popLeft}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.6,143.7,27), null);


(lib.iconFolderSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.iconFolder();
	this.sub.name = "sub";
	this.sub.setTransform(76.45,50.35,1,1,0,0,0,76.4,46.6);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconFolderSub, new cjs.Rectangle(0,0,153.9,97), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.grid_line();
	this.instance.setTransform(369.55,33.95,0.4977,1,90,0,0,121.2,-0.1);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(303.35,36.05,0.499,1,90,0,0,125.8,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(183.6,36.05,0.499,1,90,0,0,125.8,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(252.95,31.9,1.0322,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(122.5,-26.9,251.3,121.5), null);


(lib.collabIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_35 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(35).call(this.frame_35).wait(1));

	// folderFront (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_1 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_2 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_3 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_4 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_5 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_6 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_7 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_8 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_9 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_10 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_11 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_12 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_13 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_14 = new cjs.Graphics().p("AoIGRQgWAAgFgQIAAAAIgBgQIgDq4QgBgcAWgWIAAAAQAVgXAbAAIAAAAIGyAAQAeAAAWAQIAAAAQAWAQAJAcIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAUIAAAAQATAUABAgIAAAAIACHxIAAA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAIgMAAIAAAAgAoJlOIAEK/IQLAAIAEgBIAAAAIgDofQAAgVgNgNIAAAAQgNgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgGgCgIIAAAAIgdhTQgGgUgQgMIAAAAQgRgMgVAAIAAAAImyAAQgNAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAoFFxIgEq/QAAgNAKgKIAAAAQAKgLANAAIAAAAIGyAAQAVAAARAMIAAAAQAQAMAGAUIAAAAIAdBTQACAIAIAGIAAAAQAHAEAJAAIAAAAIGcAAQAUAAANAOIAAAAQANANAAAVIAAAAIADIfIgEABIAAAAg");
	var mask_graphics_15 = new cjs.Graphics().p("AoGGQQgVAAgGgQIAAAAIgBgQIgIq3QAAgcAWgWIAAAAQAVgWAbAAIAAAAIGyAAQAdAAAWAQIAAAAQAXAQAJAbIAAAAIAdBTQABADADAAIAAAAIGcAAQAeAAAUAVIAAAAQAUAUAAAfIAAAAIAGHxIABA6QgEAHgFAFIAAAAQgEAFgFADIAAAAQgLAHgMAAIAAAAgAoLlOIAIK+IQLAAIAEAAIAAAAIgGofQAAgUgOgOIAAAAQgNgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgHgFgDgJIAAAAIgdhTQgGgUgRgMIAAAAQgQgLgWAAIAAAAImyAAQgMAAgKAKIAAAAQgKAKAAANIAAAAIAAAAgAoDFwIgIq+QAAgNAKgKIAAAAQAKgKAMAAIAAAAIGyAAQAWAAAQALIAAAAQARAMAGAUIAAAAIAdBTQADAJAHAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAANANIAAAAQAOAOAAAUIAAAAIAGIfIgEAAIAAAAg");
	var mask_graphics_16 = new cjs.Graphics().p("AoBGPQgWAAgFgPIAAAAIgCgQIgQq3QgBgbAWgWIAAAAQAUgWAbAAIAAAAIGyAAQAeAAAXAPIAAAAQAWAQAJAcIAAAAIAeBTQABACAEAAIAAAAIGbAAQAfAAAUAVIAAAAQAUAUABAfIAAAAIALHwIACA6QgDAHgFAGIAAAAQgEAEgFADIAAAAQgMAHgMAAIAAAAgAoQlNIARK9IQMAAIAEgBIAAAAIgOodQAAgVgOgNIAAAAQgNgOgUAAIAAAAImbAAQgKAAgHgFIAAAAQgHgFgDgIIAAAAIgehTQgGgUgRgMIAAAAQgRgMgWAAIAAAAImyAAQgMAAgKALIAAAAQgKAKAAANIAAAAIAAAAgAn/FwIgRq9QAAgNAKgKIAAAAQAKgLAMAAIAAAAIGyAAQAWAAARAMIAAAAQARAMAGAUIAAAAIAeBTQADAIAHAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAANAOIAAAAQAOANAAAVIAAAAIAOIdIgEABIAAAAg");
	var mask_graphics_17 = new cjs.Graphics().p("An6GOQgVAAgGgQIAAAAIgCgQIgeqzQgBgcAVgWIAAAAQAUgWAbAAIAAAAIGyAAQAeAAAXAQIAAAAQAWAQAKAbIAAAAIAgBTQABACADAAIAAAAIGcAAQAeAAAVAVIAAAAQAUAUACAfIAAAAIAVHuIADA6QgDAHgFAFIAAAAQgEAFgFADIAAAAQgLAHgMAAIAAAAgAoXlMIAfK6IQLAAIAEAAIAAAAIgXocQgBgUgOgOIAAAAQgOgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgHgFgDgJIAAAAIgfhSQgHgUgSgMIAAAAQgRgLgVAAIAAAAImyAAQgNAAgJAKIAAAAQgKAKAAAMIAAAAIAAABgAn4FuIgfq6IAAgBIAAAAQAAgMAKgKIAAAAQAJgKANAAIAAAAIGyAAQAVAAARALIAAAAQASAMAHAUIAAAAIAfBSQADAJAHAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAAOANIAAAAQAOAOABAUIAAAAIAXIcIgEAAIAAAAg");
	var mask_graphics_18 = new cjs.Graphics().p("AnwGMQgVAAgGgQIAAAAIgCgPIgxqxQgCgbAUgWIAAAAQAUgWAbAAIAAAAIGyAAQAdAAAYAQIAAAAQAXAPALAcIAAAAIAhBSQABADAEAAIAAAAIGbAAQAfAAAVAUIAAAAQAVAUACAfIAAAAIAjHsIAEA5QgDAHgEAFIAAAAQgEAEgFAEIAAAAQgLAHgMAAIAAAAgAoglLIAyK4IQLAAIAEgBIAAAAIgnoZQgBgUgOgNIAAAAQgOgOgUAAIAAAAImcAAQgJAAgIgFIAAAAQgHgFgDgIIAAAAIghhTQgIgUgSgLIAAAAQgRgMgWAAIAAAAImyAAQgMAAgJALIAAAAQgJAJAAAMIAAAAIAAABgAnuFtIgyq4IAAgBIAAAAQAAgMAJgJIAAAAQAJgLAMAAIAAAAIGyAAQAWAAARAMIAAAAQASALAIAUIAAAAIAhBTQADAIAHAFIAAAAQAIAFAJAAIAAAAIGcAAQAUAAAOAOIAAAAQAOANABAUIAAAAIAnIZIgEABIAAAAg");
	var mask_graphics_19 = new cjs.Graphics().p("AnjGJQgVAAgHgQIAAAAIgDgPIhIqrQgDgbAUgWIAAAAQATgWAbAAIAAAAIGyAAQAdAAAYAQIAAAAQAZAPALAbIAAAAIAkBSQABADAEAAIAAAAIGbAAQAfAAAVAUIAAAAQAWAUADAeIAAAAIA0HoIAGA5QgCAHgFAFIAAAAQgDAEgFAEIAAAAQgLAHgMAAIAAAAgAoslIIBJKyIQMAAIAEgBIAAAAIg5oVQgDgUgOgNIAAAAQgPgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgIgFgDgIIAAAAIgkhSQgJgUgSgLIAAAAQgRgMgWAAIAAAAImyAAQgNAAgIALIAAAAQgIAJAAAKIAAAAIAAADgAnjFqIhJqyIAAgDIAAAAQAAgKAIgJIAAAAQAIgLANAAIAAAAIGyAAQAWAAARAMIAAAAQASALAJAUIAAAAIAkBSQADAIAIAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAAPANIAAAAQAOANADAUIAAAAIA5IVIgEABIAAAAg");
	var mask_graphics_20 = new cjs.Graphics().p("AnVGFQgVAAgHgQIAAAAIgEgPIhiqkQgEgbATgVIAAAAQASgWAbAAIAAAAIGyAAQAeAAAYAQIAAAAQAZAPANAbIAAAAIAnBRQABACAEAAIAAAAIGbAAQAfAAAWAUIAAAAQAWAUAFAeIAAAAIBGHjIAJA5QgDAGgEAFIAAAAQgEAFgEADIAAAAQgLAHgMAAIAAAAgAo5lFIBjKrIQLAAIAEgBIAAAAIhNoPQgDgUgOgNIAAAAQgPgNgUAAIAAAAImcAAQgJAAgIgFIAAAAQgIgFgDgIIAAAAIgohRQgJgTgTgMIAAAAQgSgLgVAAIAAAAImyAAQgNAAgIAKIAAAAQgIAJAAAKIAAAAIABADgAnWFmIhjqrIgBgDIAAAAQAAgKAIgJIAAAAQAIgKANAAIAAAAIGyAAQAVAAASALIAAAAQATAMAJATIAAAAIAoBRQADAIAIAFIAAAAQAIAFAJAAIAAAAIGcAAQAUAAAPANIAAAAQAOANADAUIAAAAIBNIPIgEABIAAAAg");
	var mask_graphics_21 = new cjs.Graphics().p("AnIGBQgVAAgIgQIAAAAIgEgPIh5qcQgFgbASgVIAAAAQARgWAbAAIAAAAIGyAAQAeAAAZAQIAAAAQAZAPAOAaIAAAAIApBQQACADADAAIAAAAIGcAAQAeAAAXAUIAAAAQAYATAFAeIAAAAIBXHeIAKA4QgCAGgEAFIAAAAQgDAEgFAEIAAAAQgKAHgMAAIAAAAgApFlBIB7KjIQLAAIAEAAIAAAAIhfoKQgEgUgPgMIAAAAQgQgOgUAAIAAAAImbAAQgKAAgHgEIAAAAQgIgFgEgJIAAAAIgqhPQgKgUgTgLIAAAAQgTgLgVAAIAAAAImyAAQgNAAgIAKIAAAAQgHAIAAAJIAAAAIABAFgAnKFiIh7qjIgBgFIAAAAQAAgJAHgIIAAAAQAIgKANAAIAAAAIGyAAQAVAAATALIAAAAQATALAKAUIAAAAIAqBPQAEAJAIAFIAAAAQAHAEAKAAIAAAAIGbAAQAUAAAQAOIAAAAQAPAMAEAUIAAAAIBfIKIgEAAIAAAAg");
	var mask_graphics_22 = new cjs.Graphics().p("Am9F9QgWAAgIgPIAAAAIgEgPIiNqWQgFgbARgVIAAAAQARgVAbAAIAAAAIGyAAQAdAAAaAPIAAAAQAaAPAOAbIAAAAIAsBPQABACAEAAIAAAAIGcAAQAeAAAYAUIAAAAQAXATAHAeIAAAAIBkHZIAMA3QgCAHgEAFIAAAAQgDAEgFADIAAAAQgKAHgMAAIAAAAgApPk+ICPKdIQLAAIAEgBIAAAAIhuoEQgEgUgQgMIAAAAQgQgOgUAAIAAAAImcAAQgJAAgHgEIAAAAQgIgFgFgIIAAAAIgshPQgLgTgTgMIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAIAAAJIAAAAIAAAFgAnAFfIiPqdIAAgFIAAAAQAAgJAGgIIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQATAMALATIAAAAIAsBPQAFAIAIAFIAAAAQAHAEAJAAIAAAAIGcAAQAUAAAQAOIAAAAQAQAMAEAUIAAAAIBuIEIgEABIAAAAg");
	var mask_graphics_23 = new cjs.Graphics().p("Am1F6QgWAAgIgPIAAAAIgFgPIibqRQgGgaARgVIAAAAQAQgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAaAPAPAaIAAAAIAtBPQACACADAAIAAAAIGcAAQAeAAAZAUIAAAAQAYATAHAdIAAAAIBuHVIAOA3QgCAHgEAFIAAAAQgDAEgFADIAAAAQgKAHgMAAIAAAAgApWk7ICdKXIQLAAIAEgBIAAAAIh5oAQgFgTgQgNIAAAAQgQgNgUAAIAAAAImbAAQgJAAgIgEIAAAAQgJgFgEgIIAAAAIguhPQgLgTgUgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAHAAAJIAAAAIABAGgAm5FcIidqXIgBgGIAAAAQAAgJAGgHIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAUALALATIAAAAIAuBPQAEAIAJAFIAAAAQAIAEAJAAIAAAAIGbAAQAUAAAQANIAAAAQAQANAFATIAAAAIB5IAIgEABIAAAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AmwF3QgVAAgJgPIAAAAIgFgPIilqMQgHgZARgVIAAAAQAQgVAbAAIAAAAIGyAAQAdAAAbAPIAAAAQAaAPAQAZIAAAAIAvBOQABADADAAIAAAAIGcAAQAeAAAZATIAAAAQAYATAIAdIAAAAIB2HSIAOA3QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApbk5ICnKSIQLAAIAEAAIAAAAIiBn9QgFgTgQgNIAAAAQgRgMgUAAIAAAAImbAAQgJAAgIgFIAAAAQgIgFgFgIIAAAAIgwhOQgLgTgUgKIAAAAQgTgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgGAGAAAJIAAAAIABAGgAm0FZIinqSIgBgGIAAAAQAAgJAGgGIAAAAQAHgKANAAIAAAAIGyAAQAVAAATALIAAAAQAUAKALATIAAAAIAwBOQAFAIAIAFIAAAAQAIAFAJAAIAAAAIGbAAQAUAAARAMIAAAAQAQANAFATIAAAAICBH9IgEAAIAAAAg");
	var mask_graphics_25 = new cjs.Graphics().p("AmrF1QgWAAgJgOIAAAAIgFgPIitqJQgHgaARgVIAAAAQAPgUAbAAIAAAAIGyAAQAeAAAaAOIAAAAQAbAPAQAaIAAAAIAwBOQACACACAAIAAAAIGcAAQAeAAAZATIAAAAQAZATAIAdIAAAAIB7HQIAPA2QgCAHgEAEIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApfk4ICvKQIQLAAIAEgBIAAAAIiHn6QgFgTgRgNIAAAAQgQgMgUAAIAAAAImcAAQgIAAgIgFIAAAAQgJgFgFgIIAAAAIgwhNQgMgTgUgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgHAKIAAAAQgGAHAAAIIAAAAIABAGgAmwFYIivqQIgBgGIAAAAQAAgIAGgHIAAAAQAHgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAUALAMATIAAAAIAwBNQAFAIAJAFIAAAAQAIAFAIAAIAAAAIGcAAQAUAAAQAMIAAAAQARANAFATIAAAAICHH6IgEABIAAAAg");
	var mask_graphics_26 = new cjs.Graphics().p("AmoF0QgWAAgJgPIAAAAIgFgPIiyqGQgHgaAQgUIAAAAQAPgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAbAPAQAZIAAAAIAxBNQACADADAAIAAAAIGbAAQAeAAAZATIAAAAQAZATAIAdIAAAAIB/HOIAQA2QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApik2IC1KMIQLAAIAEAAIAAAAIiMn4QgFgUgQgMIAAAAQgRgNgUAAIAAAAImbAAQgJAAgIgEIAAAAQgJgFgFgIIAAAAIgxhNQgMgTgTgLIAAAAQgUgKgVAAIAAAAImyAAQgNAAgHAJIAAAAQgGAHAAAIIAAAAIABAHgAmtFWIi1qMIgBgHIAAAAQAAgIAGgHIAAAAQAHgJANAAIAAAAIGyAAQAVAAAUAKIAAAAQATALAMATIAAAAIAxBNQAFAIAJAFIAAAAQAIAEAJAAIAAAAIGbAAQAUAAARANIAAAAQAQAMAFAUIAAAAICMH4IgEAAIAAAAg");
	var mask_graphics_27 = new cjs.Graphics().p("AmnFzQgVAAgJgPIAAAAIgFgOIi2qFQgHgaAQgVIAAAAQAPgUAbAAIAAAAIGyAAQAeAAAbAPIAAAAQAaAOAQAaIAAAAIAyBNQACACADAAIAAAAIGbAAQAeAAAZAUIAAAAQAZASAIAdIAAAAICCHNIAPA2QgBAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApjk2IC4KMIQLAAIAEgBIAAAAIiPn3QgFgTgRgMIAAAAQgQgNgUAAIAAAAImbAAQgJAAgIgFIAAAAQgJgEgFgIIAAAAIgxhNQgMgTgUgLIAAAAQgUgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgFAHAAAIIAAAAIABAGgAmrFWIi4qMIgBgGIAAAAQAAgIAFgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAAUALIAAAAQAUALAMATIAAAAIAxBNQAFAIAJAEIAAAAQAIAFAJAAIAAAAIGbAAQAUAAAQANIAAAAQARAMAFATIAAAAICPH3IgEABIAAAAg");
	var mask_graphics_28 = new cjs.Graphics().p("AmmFzQgVAAgJgPIAAAAIgGgPIi3qEQgHgZAQgVIAAAAQAPgVAbAAIAAAAIGyAAQAeAAAbAPIAAAAQAaAPAQAZIAAAAIAyBNQACADADAAIAAAAIGbAAQAeAAAZATIAAAAQAZASAJAdIAAAAICDHNIAPA2QgBAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApkk1IC5KKIQLAAIAEAAIAAAAIiPn3QgFgTgRgMIAAAAQgRgNgUAAIAAAAImaAAQgKAAgIgEIAAAAQgJgFgFgIIAAAAIgxhNQgMgTgUgKIAAAAQgUgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgFAGAAAIIAAAAIABAHgAmrFVIi5qKIgBgHIAAAAQAAgIAFgGIAAAAQAHgKANAAIAAAAIGyAAQAVAAAUALIAAAAQAUAKAMATIAAAAIAxBNQAFAIAJAFIAAAAQAIAEAKAAIAAAAIGaAAQAUAAARANIAAAAQARAMAFATIAAAAICPH3IgEAAIAAAAg");
	var mask_graphics_29 = new cjs.Graphics().p("AmlFzQgWAAgJgPIAAAAIgFgPIi4qEQgIgZAQgVIAAAAQAQgVAbAAIAAAAIGyAAQAdAAAbAPIAAAAQAbAPAQAZIAAAAIAyBNQACADADAAIAAAAIGbAAQAeAAAZATIAAAAQAZATAIAcIAAAAICEHNIAQA2QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgAplk1IC7KKIQLAAIAEAAIAAAAIiQn3QgGgTgQgMIAAAAQgRgNgUAAIAAAAImaAAQgKAAgIgEIAAAAQgJgFgFgIIAAAAIgyhNQgLgTgVgKIAAAAQgTgLgWAAIAAAAImyAAQgMAAgHAKIAAAAQgFAGAAAIIAAAAIAAAHgAmqFVIi7qKIAAgHIAAAAQAAgIAFgGIAAAAQAHgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAVAKALATIAAAAIAyBNQAFAIAJAFIAAAAQAIAEAKAAIAAAAIGaAAQAUAAARANIAAAAQAQAMAGATIAAAAICQH3IgEAAIAAAAg");
	var mask_graphics_30 = new cjs.Graphics().p("AmnFzQgWAAgJgOIAAAAIgFgPIi1qGQgHgZAQgVIAAAAQAQgUAbAAIAAAAIGyAAQAdAAAbAOIAAAAQAbAPAQAaIAAAAIAxBNQACACADAAIAAAAIGbAAQAeAAAZATIAAAAQAZATAIAdIAAAAICBHNIAQA2QgCAHgEAFIAAAAQgCADgFADIAAAAQgJAHgMAAIAAAAgApjk2IC3KMIQLAAIAEgBIAAAAIiNn3QgGgTgQgMIAAAAQgRgNgUAAIAAAAImbAAQgJAAgIgFIAAAAQgJgFgFgHIAAAAIgxhOQgMgSgUgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgHAKIAAAAQgGAHAAAIIAAAAIABAGgAmsFWIi3qMIgBgGIAAAAQAAgIAGgHIAAAAQAHgKAMAAIAAAAIGyAAQAWAAATALIAAAAQAUALAMASIAAAAIAxBOQAFAHAJAFIAAAAQAIAFAJAAIAAAAIGbAAQAUAAARANIAAAAQAQAMAGATIAAAAICNH3IgEABIAAAAg");
	var mask_graphics_31 = new cjs.Graphics().p("AmsF1QgVAAgJgOIAAAAIgFgPIitqJQgGgaAQgVIAAAAQAQgUAbAAIAAAAIGyAAQAdAAAbAOIAAAAQAaAPAQAaIAAAAIAxBNQABADADAAIAAAAIGbAAQAfAAAYATIAAAAQAZATAIAdIAAAAIB7HQIAPA2QgCAHgEAFIAAAAQgDADgEADIAAAAQgKAHgMAAIAAAAgApfk4ICvKQIQLAAIAEgBIAAAAIiHn6QgFgTgRgNIAAAAQgQgMgUAAIAAAAImbAAQgJAAgIgFIAAAAQgJgFgFgIIAAAAIgwhNQgMgTgTgLIAAAAQgUgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgGAHAAAIIAAAAIABAGgAmwFYIivqQIgBgGIAAAAQAAgIAGgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAAUALIAAAAQATALAMATIAAAAIAwBNQAFAIAJAFIAAAAQAIAFAJAAIAAAAIGbAAQAUAAAQAMIAAAAQARANAFATIAAAAICHH6IgEABIAAAAg");
	var mask_graphics_32 = new cjs.Graphics().p("AmxF4QgWAAgJgPIAAAAIgEgPIiiqNQgHgaARgVIAAAAQAQgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAaAPAPAaIAAAAIAvBOQABACAEAAIAAAAIGbAAQAfAAAYAUIAAAAQAYATAIAdIAAAAIBzHTIAOA2QgCAHgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApak6IClKUIQLAAIAEgBIAAAAIh/n9QgFgTgQgNIAAAAQgQgNgUAAIAAAAImcAAQgIAAgIgEIAAAAQgJgFgFgIIAAAAIgvhOQgLgTgUgLIAAAAQgTgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgGAHAAAJIAAAAIAAAFgAm1FaIilqUIAAgFIAAAAQAAgJAGgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAATALIAAAAQAUALALATIAAAAIAvBOQAFAIAJAFIAAAAQAIAEAIAAIAAAAIGcAAQAUAAAQANIAAAAQAQANAFATIAAAAIB/H9IgEABIAAAAg");
	var mask_graphics_33 = new cjs.Graphics().p("Am1F5QgVAAgJgPIAAAAIgFgPIibqPQgGgaAQgVIAAAAQARgVAbAAIAAAAIGyAAQAdAAAaAPIAAAAQAbAPAPAaIAAAAIAtBOQACACADAAIAAAAIGcAAQAeAAAYAUIAAAAQAYATAIAdIAAAAIBvHVIANA3QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApWk7ICdKWIQLAAIAEAAIAAAAIh5oAQgFgTgQgNIAAAAQgQgNgUAAIAAAAImcAAQgIAAgIgEIAAAAQgJgFgEgIIAAAAIgvhOQgLgTgTgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAHAAAIIAAAAIABAGgAm5FbIidqWIgBgGIAAAAQAAgIAGgHIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQATALALATIAAAAIAvBOQAEAIAJAFIAAAAQAIAEAIAAIAAAAIGcAAQAUAAAQANIAAAAQAQANAFATIAAAAIB5IAIgEAAIAAAAg");
	var mask_graphics_34 = new cjs.Graphics().p("Am3F6QgVAAgJgPIAAAAIgEgPIiZqRQgGgaARgVIAAAAQARgVAbAAIAAAAIGyAAQAdAAAaAPIAAAAQAaAPAPAaIAAAAIAtBPQACACADAAIAAAAIGcAAQAeAAAYAUIAAAAQAYATAHAdIAAAAIBtHVIANA3QgCAHgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApVk7ICbKXIQLAAIAEgBIAAAAIh4oAQgEgTgQgNIAAAAQgQgNgUAAIAAAAImcAAQgJAAgHgEIAAAAQgJgFgEgIIAAAAIguhPQgLgTgUgLIAAAAQgTgLgVAAIAAAAImyAAQgNAAgHAKIAAAAQgHAHABAJIAAAAIAAAGgAm6FcIibqXIAAgGIAAAAQgBgJAHgHIAAAAQAHgKANAAIAAAAIGyAAQAVAAATALIAAAAQAUALALATIAAAAIAuBPQAEAIAJAFIAAAAQAHAEAJAAIAAAAIGcAAQAUAAAQANIAAAAQAQANAEATIAAAAIB4IAIgEABIAAAAg");
	var mask_graphics_35 = new cjs.Graphics().p("Am3F6QgVAAgJgPIAAAAIgEgPIiYqRQgGgaARgVIAAAAQAQgVAbAAIAAAAIGyAAQAeAAAaAPIAAAAQAaAPAPAaIAAAAIAtBOQABADAEAAIAAAAIGbAAQAfAAAYATIAAAAQAYATAHAeIAAAAIBsHWIANA3QgCAGgEAFIAAAAQgDAEgEADIAAAAQgKAHgMAAIAAAAgApUk8ICaKYIQLAAIAEAAIAAAAIh3oBQgFgUgQgMIAAAAQgQgNgUAAIAAAAImbAAQgKAAgHgFIAAAAQgIgFgFgIIAAAAIguhOQgLgTgTgLIAAAAQgTgLgWAAIAAAAImyAAQgMAAgIAKIAAAAQgGAHAAAJIAAAAIABAFgAm6FcIiaqYIgBgFIAAAAQAAgJAGgHIAAAAQAIgKAMAAIAAAAIGyAAQAWAAATALIAAAAQATALALATIAAAAIAuBOQAFAIAIAFIAAAAQAHAFAKAAIAAAAIGbAAQAUAAAQANIAAAAQAQAMAFAUIAAAAIB3IBIgEAAIAAAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:70.8957,y:65.9506}).wait(1).to({graphics:mask_graphics_1,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_2,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_3,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_4,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_5,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_6,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_7,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_8,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_9,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_10,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_11,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_12,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_13,x:70.8957,y:65.9497}).wait(1).to({graphics:mask_graphics_14,x:70.8957,y:65.9506}).wait(1).to({graphics:mask_graphics_15,x:70.6399,y:65.9893}).wait(1).to({graphics:mask_graphics_16,x:70.1752,y:66.0658}).wait(1).to({graphics:mask_graphics_17,x:69.4485,y:66.1991}).wait(1).to({graphics:mask_graphics_18,x:68.4182,y:66.4151}).wait(1).to({graphics:mask_graphics_19,x:67.1149,y:66.7341}).wait(1).to({graphics:mask_graphics_20,x:65.7068,y:67.1391}).wait(1).to({graphics:mask_graphics_21,x:64.4191,y:67.5666}).wait(1).to({graphics:mask_graphics_22,x:63.3748,y:67.9541}).wait(1).to({graphics:mask_graphics_23,x:62.58,y:68.2753}).wait(1).to({graphics:mask_graphics_24,x:61.9941,y:68.5273}).wait(1).to({graphics:mask_graphics_25,x:61.5745,y:68.7154}).wait(1).to({graphics:mask_graphics_26,x:61.2852,y:68.8491}).wait(1).to({graphics:mask_graphics_27,x:61.1001,y:68.9364}).wait(1).to({graphics:mask_graphics_28,x:60.9992,y:68.9845}).wait(1).to({graphics:mask_graphics_29,x:61.0156,y:68.9503}).wait(1).to({graphics:mask_graphics_30,x:61.1752,y:68.8671}).wait(1).to({graphics:mask_graphics_31,x:61.6023,y:68.6489}).wait(1).to({graphics:mask_graphics_32,x:62.1378,y:68.3874}).wait(1).to({graphics:mask_graphics_33,x:62.4631,y:68.2349}).wait(1).to({graphics:mask_graphics_34,x:62.6088,y:68.1678}).wait(1).to({graphics:mask_graphics_35,x:62.7979,y:68.2006}).wait(1));

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("AjQEHIHAAAQA+AAAug2QAsg1AAhBIAAgBQAAgtgWgvQgXgzgjgTQgdgQghgCQgYhfhWguQhXgvhwAZQgqAJgmAaQglAagZAlQhLABg7BDQg4BCAABPQABBQA1A9QA2BABLAAg");
	this.shape.setTransform(17.7748,85.3162);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(36));

	// Layer_9 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AklJBQANgKALgNQAsg1AAhBIAAgBQAAgtgVgwQgYgzgjgTQgdgQgggCQgZhfhWguQhXgvhxAZQgpAJgnAbQglAagZAkQhGABg3A6IAAs4IdhAAIAASBg");
	mask_1.setTransform(79.55,50.8);

	// folder
	this.folder = new lib.iconFolderSub();
	this.folder.name = "folder";
	this.folder.setTransform(76.2,57.55,1,1,0,0,0,77,48.5);

	var maskedShapeInstanceList = [this.folder];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.folder).wait(36));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.4,-72,300,250);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// popLines
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(435.15,15.5,1.22,1.22,-102.8472,0,0,14.7,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(448.6,6.4,1.22,1.22,-133.8471,0,0,14.7,-0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(454.85,-7.2,1.2201,1.2201,-173.851,0,0,14.8,0);

	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(303.75,-88.15,1.2564,1.2564,86.0018,0,0,14.8,0);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(289,-82.45,1.2564,1.2564,55.0028,0,0,14.8,-0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(281.2,-70.2,1.2564,1.2564,14.9998,0,0,15.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// cloud
	this.cloud = new lib.iconCloud();
	this.cloud.name = "cloud";
	this.cloud.setTransform(315.8,2.8,1,1,0,0,0,34.8,34.8);

	this.timeline.addTween(cjs.Tween.get(this.cloud).wait(1));

	// ODIcon
	this.ODIcon = new lib.collabIcon();
	this.ODIcon.name = "ODIcon";
	this.ODIcon.setTransform(315.8,2.8,1,1,0,0,0,17.8,98.3);

	this.timeline.addTween(cjs.Tween.get(this.ODIcon).wait(1));

	// lines
	this.line1 = new lib.line1();
	this.line1.name = "line1";
	this.line1.setTransform(-52.1,-16.2,1.5456,1.5456,0,0,0,144.4,23.6);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(-275.3,-108.7,750.1,167.3), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(711.2,4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(671.95,44.35,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(681.65,45,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(369.6,116.9,1,1,0,0,0,206.7,147.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(435,26.75,0.88,0.88,0,0,0,3.6,39.6);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(485.45,78.75,0.5374,0.5374,0,0,0,133.3,23.8);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(249.1,45.1,1,1,0,0,0,249.6,33.1);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(150.6,154,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-18.2,752.3,165.1), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut});
				this.tl1.from(exportRoot.intro2,{duration:0.6, alpha: 0, ease:Power3.easeOut, onComplete:function(){mc.anim.line1.play();}}, ">-.4");
		
		
				//icon
				this.tl1.from(mc.anim.cloud,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, ">+2.1");
				this.tl1.from(mc.anim.ODIcon,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Power3.easeOut, onStart:function(){mc.anim.ODIcon.play(),mc.anim.ODIcon.folder.sub.play();}}, "<+.2");
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, ">-.1");
		
				//UI transition
				this.tl1.from(mc.ui.ui,{duration:1.2, scaleX: .3, scaleY: .3, x: "+=236", y:"-=40", ease:Power4.easeInOut}, ">");
				this.tl1.to(mc.ui.ui,{duration:.4, y:"-=40", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, "<.2");
				this.tl1.to(mc.ui.ui,{duration:.6, y:"+=80", ease:Sine.easeOut}, ">");		
		
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<-.6");	
				this.tl1.to(exportRoot.intro2,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "<+.2");	
				this.tl1.to(mc.anim,{duration:.6, alpha:0, ease:Back.easeOut}, ">");		
				
				this.tl3 = gsap.timeline();	
				this.tl3.from(mc.ui.ui.file1,{duration:1.5, x:"-=20", y:"-=60", scaleX:.2, scaleY:.2});
				this.tl3.from(mc.ui.ui.file1,{duration:0.1, alpha:0}, "<");		
				this.tl3.from(mc.ui.ui.file1.fileShadow,{duration:2, x:"-=20", y:"-=60", alpha:0}, "<");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:"-=15"}, "<-0.7");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:"+=20"}, ">+.5");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:"-=15"}, ">+.5");
				this.tl3.to(mc.ui.ui.file1,{duration:0, rotation:0}, ">+.5");
		
				
				this.tl3.from(mc.ui.ui.file2,{duration:2, x:"-=20", y:"+=100", scaleX:.2, scaleY:.2}, "<-.6");
				this.tl3.from(mc.ui.ui.file2,{duration:0.1, alpha:0}, "<");			
				this.tl3.from(mc.ui.ui.file2.fileShadow,{duration:2, x:"-=20", y:"+=60", alpha:0}, "<");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:"-=10"}, "<-0.7");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl3.to(mc.ui.ui.file2,{duration:0, rotation:0}, ">+.5");
		
				
				this.tl3.to(mc.ui.ui.file1,{duration:.7, x:"+=126", y:"+=2", scaleX:.12, scaleY:.12, ease:Power3.easeInOut}, "<+.5");
				this.tl3.to(mc.ui.ui.file1.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");		
				this.tl3.to(mc.ui.ui.file1.fileShadow,{duration:.1, alpha:0}, ">-.1");		
				this.tl3.to(mc.ui.ui.file2,{duration:.7, x:"-=116", y:"-=2", scaleX:.1, scaleY:.1, ease:Power3.easeInOut}, ">-.6");
				//this.tl3.to(mc.ui.ui.file2.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");			
				this.tl3.to(mc.ui.ui.file2.fileShadow,{duration:.2, alpha:0}, ">-.1");		
			
				//mid transition		
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=2", y:"-=2", scaleX: .85, scaleY: .85, ease:Power3.easeInOut}, ">+2.3");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"-=2", y:"-=2", alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<.2");
				
				this.tl4 = gsap.timeline();	
				this.tl4.from(mc.ui.ui.file3,{duration:2, x:"+=40", y:"-=100", scaleX:.3, scaleY:.3}, ">");
				this.tl4.from(mc.ui.ui.file3,{duration:0.1, alpha:0}, "<");			
				this.tl4.from(mc.ui.ui.file3.fileShadow,{duration:2, x:"-=10", y:"-=10", alpha:0}, "<");		
				this.tl4.to(mc.ui.ui.file3, {duration:0, rotation:"-=10"}, "<-");
				this.tl4.to(mc.ui.ui.file3,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl4.to(mc.ui.ui.file3,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl4.to(mc.ui.ui.file3,{duration:0, rotation:0}, ">+.5");
			
				this.tl4.from(mc.ui.ui.file4,{duration:2, x:"-=70", y:"+=100", scaleX:.5, scaleY:.5}, "<-1.8");
				this.tl4.from(mc.ui.ui.file4,{duration:0.1, alpha:0}, ">-2");			
				this.tl4.from(mc.ui.ui.file4.fileShadow,{duration:2, x:"-=4", y:"+=17", alpha:0}, "<-2");
				this.tl4.to(mc.ui.ui.file4, {duration:0, rotation:"-=10"}, "<-1");
				this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl4.to(mc.ui.ui.file4,{duration:0, rotation:0}, ">+.5");
				
				this.tl4.to(mc.ui.ui.file3,{duration:.7, x:"-=135", y:"+=67", scaleX:.1, scaleY:.1, ease:Power3.easeInOut}, ">+0.2");
				this.tl4.to(mc.ui.ui.file3.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");		
				this.tl4.to(mc.ui.ui.file3.fileShadow,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");		
				this.tl4.to(mc.ui.ui.file4,{duration:.7, x:"-=4", y:"+=17", scaleX:.22, scaleY:.22, ease:Power3.easeInOut}, ">-0.6");
				this.tl4.to(mc.ui.ui.file4.fileShadow,{duration:.5, alpha:0, ease:Power3.easeInOut}, "<");			
				this.tl4.to(mc.ui.ui.file4.fileShadow,{duration:.1, alpha:0, ease:Power3.easeInOut},">-.1");		
			
				this.tl5 = gsap.timeline();	
				this.tl5.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<");
				this.tl5.from(mc.ui.ui.pptLogo,{duration:2, x:"-=150", y:"+=40", scaleX: 0, scaleY: 0}, ">");				
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:"-=10"}, "<-0.2");
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl5.to(mc.ui.ui.pptLogo,{duration:0, rotation:0}, ">+.5");
		
		
				//final frame
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"-=126", y:"-=16", scaleX: .73, scaleY: .73, ease:Power3.easeInOut}, ">+1.7");
				this.tl1.to(mc.anim,{duration:1.2, x:"-=27", y:"+=8", scaleX: 1, scaleY: 1, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1.2, x:"-=126", y:"-=16", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
		
				this.tl1.from(mc.ui.ui.endUI,{duration:.4, alpha:0, ease:Power3.easeOut}, ">-.4");
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
				
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.ui.ui.ad1,{duration:2, x:"-=120", y:"+=70",  ease:Power3.easeInOut, onStart:function(){mc.ui.ui.ad1.visible=true;}});
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.ui.ui.ad1,{duration:0, rotation:0}, ">+.5");
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				exportRoot.tl3.pause();
				exportRoot.tl4.pause();
				exportRoot.tl5.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
					this.tlMaster.to(exportRoot.tl3, {time:exportRoot.tl3.duration(), duration:exportRoot.tl3.duration(), 
					ease:SteppedEase.config(exportRoot.tl3.duration()*8)},"<-5.6");
					this.tlMaster.to(exportRoot.tl4, {time:exportRoot.tl4.duration(), duration:exportRoot.tl4.duration(), 
					ease:SteppedEase.config(exportRoot.tl4.duration()*8)},"<+3");
					this.tlMaster.to(exportRoot.tl5, {time:exportRoot.tl4.duration(), duration:exportRoot.tl4.duration(), 
					ease:SteppedEase.config(exportRoot.tl4.duration()*8)},"<+0.5");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,26.8,388.29999999999995,120.10000000000001);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622737344631", id:"M365_FY22Q1BTS_USA_728x90_BAN_OD_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;