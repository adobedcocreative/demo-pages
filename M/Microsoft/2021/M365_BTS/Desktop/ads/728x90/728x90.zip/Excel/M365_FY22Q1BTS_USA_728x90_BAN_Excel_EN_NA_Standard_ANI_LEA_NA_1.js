(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[402,152,30,62],[0,269,250,167],[252,269,190,127],[0,0,400,267],[434,152,43,40],[402,0,150,150]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.ExcelMobileUniversityBudgetAndroid111 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Excelscreen1 = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Excelscreen_END = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUniversityBudgeting = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Excel_icon = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.shadow_sq = function() {
	this.initialize(ss["M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("An+IDIAAwFIP9AAIAAQFg");
	this.shape.setTransform(51.125,51.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white_sq, new cjs.Rectangle(0,0,102.3,103), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.square3_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhbECQgEAAAAgEIAAn7QAAgEAEAAIC3AAQAEAAAAAEIAAH7QAAAEgEAAg");
	this.shape.setTransform(9.6266,25.8265);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square3_c, new cjs.Rectangle(0,0,19.3,51.7), null);


(lib.square_2_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjmBgQgEAAAAgEIAAi3QAAgEAEAAIHNAAQAEAAAAAEIAAC3QAAAEgEAAg");
	this.shape.setTransform(23.4772,9.6008);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square_2_cache, new cjs.Rectangle(0,0,47,19.2), null);


(lib.square_1_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhbBgQgEAAAAgEIAAi3QAAgEAEAAIC3AAQAEAAAAAEIAAC3QAAAEgEAAg");
	this.shape.setTransform(9.6266,9.6008);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square_1_cache, new cjs.Rectangle(0,0,19.3,19.2), null);


(lib.sq_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_89 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(89).call(this.frame_89).wait(1));

	// Layer_5 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_48 = new cjs.Graphics().p("AG1BrIkBhzQgNgGgDgTQgDgSAJgUQAJgVAQgKQAQgKANAGIEBBzQANAGADASQADATgJAUQgJAVgQAKQgKAGgJAAQgFAAgFgCg");
	var mask_graphics_49 = new cjs.Graphics().p("AG9BuIkNh5QgOgGgDgTQgDgTAJgUQAJgVAQgKQARgKANAHIEOB5QAOAGADATQADATgJAUQgKAVgQAKQgKAGgJAAQgGAAgFgDg");
	var mask_graphics_50 = new cjs.Graphics().p("AHHBzIkciBQgPgGgDgUQgEgTAJgVQAKgUARgKQARgKAOAGIEcCBQAPAHAEATQADATgJAVQgKAUgRAKQgKAGgJAAQgGAAgGgCg");
	var mask_graphics_51 = new cjs.Graphics().p("AHTB4IkuiKQgPgHgFgUQgEgTAKgVQAKgVARgKQASgKAPAHIEuCKQAPAHAEATQAEAUgJAVQgKAVgRAKQgLAGgJAAQgHAAgGgDg");
	var mask_graphics_52 = new cjs.Graphics().p("AHgB+IlCiUQgQgIgFgUQgFgUAKgWQAKgVASgKQATgJAQAHIFCCUQARAIAEAUQAFAVgKAVQgJAVgTAJQgKAGgKAAQgIAAgHgDg");
	var mask_graphics_53 = new cjs.Graphics().p("AHwCFIlaigQgRgIgGgWQgFgVAKgVQAKgWAUgJQATgKASAJIFZCfQASAJAFAUQAFAWgKAVQgKAWgTAJQgLAFgKAAQgIAAgIgDg");
	var mask_graphics_54 = new cjs.Graphics().p("AIBCNIl0iuQgTgJgGgWQgGgWAKgWQALgWAUgJQAVgJATAJIF0CtQATAJAGAWQAGAWgKAWQgKAWgVAJQgLAFgKAAQgJAAgKgEg");
	var mask_graphics_55 = new cjs.Graphics().p("AIVCWImSi+QgUgKgHgXQgHgXAKgWQALgWAWgKQAWgIAVAJIGSC+QAUAKAHAXQAHAXgKAWQgLAXgWAIQgLAFgKAAQgLAAgLgFg");
	var mask_graphics_56 = new cjs.Graphics().p("AIsCgIm0jQQgWgLgIgYQgIgYALgXQALgWAXgJQAYgJAWALIG0DRQAWAKAIAYQAIAYgLAXQgLAXgXAIQgLAEgKAAQgNAAgMgGg");
	var mask_graphics_57 = new cjs.Graphics().p("AJECsInZjlQgYgMgJgZQgJgZAMgYQALgXAZgIQAagJAYAMIHZDmQAYALAJAZQAJAZgMAYQgLAXgZAIQgLAEgKAAQgPAAgOgHg");
	var mask_graphics_58 = new cjs.Graphics().p("AJfC5IoBj8QgagNgKgbQgKgaAMgYQALgYAbgIQAbgIAaANIIBD9QAbANAKAaQAKAagMAYQgMAYgbAIQgKADgLAAQgQAAgQgIg");
	var mask_graphics_59 = new cjs.Graphics().p("AJ7DHIorkVQgcgPgMgbQgLgcANgYQAMgZAdgHQAcgIAdAOIIrEWQAcAOALAbQAMAcgNAYQgMAZgdAHQgKADgKAAQgTAAgSgJg");
	var mask_graphics_60 = new cjs.Graphics().p("AKYDVIpWkvQgfgPgMgdQgNgdANgZQANgaAfgHQAegHAfAQIJWEvQAeAQANAcQAMAdgNAaQgNAZgeAHQgKACgKAAQgVAAgUgLg");
	var mask_graphics_61 = new cjs.Graphics().p("AK0DkIqBlKQgggQgOgfQgNgeANgaQANgaAhgHQAggGAhARIKBFKQAgARAOAeQAOAegOAaQgNAaghAGQgJACgJAAQgXAAgYgMg");
	var mask_graphics_62 = new cjs.Graphics().p("ALQDzIqqlkQgjgTgOgfQgPggAOgaQANgbAigGQAjgGAjASIKqFlQAjASAOAfQAPAggOAbQgNAagjAGQgJABgIAAQgaAAgagNg");
	var mask_graphics_63 = new cjs.Graphics().p("ALqEBIrRl+QgkgTgQgiQgQggAOgbQAPgcAjgFQAkgFAlATILSF+QAkAUAQAgQAQAigOAbQgPAbgkAFIgQABQgcAAgdgPg");
	var mask_graphics_64 = new cjs.Graphics().p("AMCEPIr2mXQglgUgRgjQgRgiAPgcQAPgbAlgFQAmgFAmAVIL2GWQAnAVAQAiQARAigOAcQgPAcgmAEIgPABQgfAAgfgQg");
	var mask_graphics_65 = new cjs.Graphics().p("AMbEbIsXmtQgogWgSgjQgRgkAPgcQAPgcAogFQAmgEAoAWIMYGtQAoAWASAjQARAkgPAcQgPAcgoAEIgOABQggAAghgSg");
	var mask_graphics_66 = new cjs.Graphics().p("AM6ExIuEmpQgugWgUgrQgTgqASglQASgmAtgMQAtgLAtAWIOFGpQAuAVATAqQAUArgSAmQgRAmguALQgQAEgQAAQgdAAgegOg");
	var mask_graphics_67 = new cjs.Graphics().p("ANaFAIvpmcQg0gVgWgwQgXgwAUgvQATgvAygTQAygSAzAVIPqGcQAzAVAXAwQAWAwgTAvQgUAwgyASQgXAIgYAAQgbAAgbgLg");
	var mask_graphics_68 = new cjs.Graphics().p("AN6FLIxHmIQg4gUgag2QgZg1AUg4QAUg3A1gaQA2gZA4AUIRIGIQA4AUAZA1QAaA2gUA4QgUA3g2AZQgeAPgfAAQgYAAgZgJg");
	var mask_graphics_69 = new cjs.Graphics().p("AOZFSIyclvQg9gSgdg7Qgcg6AUhAQATg/A5ghQA5gfA8ATISdFuQA8ATAdA5QAdA7gUBAQgUBAg5AfQgkAUglAAQgVAAgXgGg");
	var mask_graphics_70 = new cjs.Graphics().p("AO3FVIzqlTQhAgQggg/Qggg+AThHQAThHA7gmQA7gmBAARITqFTQBAAQAgA+QAgA/gTBHQgTBHg7AmQgpAagrAAQgTAAgUgFg");
	var mask_graphics_71 = new cjs.Graphics().p("APSFWI0uk1QhEgPgkhCQgjhCAShNQAShOA9gsQA9grBEAQIUuE0QBEAQAjBAQAkBDgSBNQgSBOg9ArQgtAhgxAAQgRAAgSgEg");
	var mask_graphics_72 = new cjs.Graphics().p("APsFUI1skVQhHgOgnhFQgmhEARhUQAQhTA+gyQA+gwBHAOIVsEVQBHAOAmBEQAnBFgRBUQgQBTg/AxQgwAmg1AAQgQAAgPgDg");
	var mask_graphics_73 = new cjs.Graphics().p("AQDFSI2jj3QhJgMgqhJQgphGAPhZQAPhYA/g3QA/g1BKAMIWiD3QBKAMApBIQAqBHgPBZQgQBYg/A2QgzAsg6AAQgNAAgOgCg");
	var mask_graphics_74 = new cjs.Graphics().p("AQYFOI3TjYQhMgLgshLQgshIANheQAOhdA/g7QBAg6BMALIXTDYQBMALAsBKQAsBKgNBdQgOBdhAA6Qg1Ayg+AAQgMAAgMgCg");
	var mask_graphics_75 = new cjs.Graphics().p("AQrFKI39i8QhOgKgvhMQgvhLAMhhQAMhiA/g/QBBg9BOAJIX9C8QBOAKAuBLQAwBMgMBhQgMBihAA9Qg4A3hCAAIgUgBg");
	var mask_graphics_76 = new cjs.Graphics().p("AQ8FFI4iihQhQgIgyhOQgxhNALhlQAKhlBAhCQBAhBBQAIIYiChQBQAIAxBNQAyBOgLBlQgKBlhBBBQg4A7hGAAIgRgBg");
	var mask_graphics_77 = new cjs.Graphics().p("ARKFBI5BiJQhSgHg0hQQgzhOAJhnQAJhpBAhFQBAhFBSAHIZCCJQBRAHAzBOQA0BQgIBnQgJBphBBEQg6A/hJAAIgPAAg");
	var mask_graphics_78 = new cjs.Graphics().p("ARXE8I5dhyQhTgGg2hRQg1hPAIhqQAHhsBAhIQBBhHBTAGIZdByQBTAGA1BQQA2BQgIBqQgHBshBBHQg7BDhLAAIgNgBg");
	var mask_graphics_79 = new cjs.Graphics().p("ARjE4I51hfQhUgFg4hRQg3hRAGhsQAHhuA/hKQBBhKBUAFIZ1BfQBUAFA3BQQA4BSgGBsQgHBuhABJQg8BGhOAAIgKAAg");
	var mask_graphics_80 = new cjs.Graphics().p("ARsE0I6IhNQhWgEg5hTQg4hRAFhuQAFhwBAhNQBAhLBWAEIaIBNQBVAEA5BRQA5BTgFBuQgFBwhBBLQg9BJhQAAIgIAAg");
	var mask_graphics_81 = new cjs.Graphics().p("AR0ExI6Zg/QhWgDg6hTQg6hSAEhwQAEhxBAhPQBAhNBXADIaYA/QBWADA6BSQA7BTgFBwQgEBxhABNQg9BMhSAAIgHAAg");
	var mask_graphics_82 = new cjs.Graphics().p("AR6EuI6mgyQhWgDg8hUQg7hSAEhxQADhzBAhQQBAhPBXADIamAyQBXADA6BSQA8BUgDBxQgEBzhABPQg+BNhTAAIgGAAg");
	var mask_graphics_83 = new cjs.Graphics().p("ASAEsI6xgpQhXgCg9hUQg7hTAChyQADh0BAhRQBAhQBXACIaxApQBXACA8BTQA8BUgDByQgCB0hBBQQg9BPhVAAIgEAAg");
	var mask_graphics_84 = new cjs.Graphics().p("ASDEqI64ghQhYgCg9hUQg8hTAChzQACh1BAhSQBAhQBYABIa4AhQBYACA8BTQA9BUgCBzQgCB1hABQQg/BRhVAAIgEAAg");
	var mask_graphics_85 = new cjs.Graphics().p("ASGEoI6+gbQhYgCg9hUQg9hTACh0QACh1A/hTQBAhRBYACIa+AbQBYACA9BTQA9BUgBB0QgCB1hBBRQg+BRhWAAIgDAAg");
	var mask_graphics_86 = new cjs.Graphics().p("ASIEoI7BgZQhYgBg+hVQg9hTACh0QABh2A/hSQBBhSBYABIbBAZQBYABA9BTQA+BVgCB0QgCB2hABRQg+BShXAAIgCAAg");
	var mask_graphics_87 = new cjs.Graphics().p("ASJEnI7CgXQhZgBg9hVQg9hTABh1QACh1A/hTQBAhSBYACIbCAXQBZABA9BUQA+BUgCB1QgCB1hABSQg+BRhXAAIgCAAg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(48).to({graphics:mask_graphics_48,x:49.7622,y:-4.7485}).wait(1).to({graphics:mask_graphics_49,x:50.7599,y:-4.2148}).wait(1).to({graphics:mask_graphics_50,x:51.9517,y:-3.5735}).wait(1).to({graphics:mask_graphics_51,x:53.3573,y:-2.8118}).wait(1).to({graphics:mask_graphics_52,x:54.9973,y:-1.9157}).wait(1).to({graphics:mask_graphics_53,x:56.8922,y:-0.8701}).wait(1).to({graphics:mask_graphics_54,x:59.0604,y:0.3396}).wait(1).to({graphics:mask_graphics_55,x:61.5147,y:1.7267}).wait(1).to({graphics:mask_graphics_56,x:64.2576,y:3.2993}).wait(1).to({graphics:mask_graphics_57,x:67.2752,y:5.0574}).wait(1).to({graphics:mask_graphics_58,x:70.5308,y:6.9874}).wait(1).to({graphics:mask_graphics_59,x:73.9621,y:9.0596}).wait(1).to({graphics:mask_graphics_60,x:77.4837,y:11.2277}).wait(1).to({graphics:mask_graphics_61,x:80.9981,y:13.4338}).wait(1).to({graphics:mask_graphics_62,x:84.4114,y:15.6178}).wait(1).to({graphics:mask_graphics_63,x:87.6472,y:17.7263}).wait(1).to({graphics:mask_graphics_64,x:90.6538,y:19.7195}).wait(1).to({graphics:mask_graphics_65,x:93.6172,y:21.8434}).wait(1).to({graphics:mask_graphics_66,x:98.8899,y:24.6737}).wait(1).to({graphics:mask_graphics_67,x:103.7795,y:26.6693}).wait(1).to({graphics:mask_graphics_68,x:108.2502,y:27.9821}).wait(1).to({graphics:mask_graphics_69,x:112.2944,y:28.751}).wait(1).to({graphics:mask_graphics_70,x:115.923,y:29.0973}).wait(1).to({graphics:mask_graphics_71,x:119.1576,y:29.1242}).wait(1).to({graphics:mask_graphics_72,x:122.0256,y:28.9173}).wait(1).to({graphics:mask_graphics_73,x:124.5566,y:28.5465}).wait(1).to({graphics:mask_graphics_74,x:126.7803,y:28.0682}).wait(1).to({graphics:mask_graphics_75,x:128.7253,y:27.5271}).wait(1).to({graphics:mask_graphics_76,x:130.4181,y:26.9585}).wait(1).to({graphics:mask_graphics_77,x:131.8831,y:26.3895}).wait(1).to({graphics:mask_graphics_78,x:133.142,y:25.8412}).wait(1).to({graphics:mask_graphics_79,x:134.2142,y:25.3291}).wait(1).to({graphics:mask_graphics_80,x:135.117,y:24.8646}).wait(1).to({graphics:mask_graphics_81,x:135.8655,y:24.4557}).wait(1).to({graphics:mask_graphics_82,x:136.4728,y:24.1075}).wait(1).to({graphics:mask_graphics_83,x:136.9504,y:23.8232}).wait(1).to({graphics:mask_graphics_84,x:137.3084,y:23.604}).wait(1).to({graphics:mask_graphics_85,x:137.5554,y:23.4496}).wait(1).to({graphics:mask_graphics_86,x:137.699,y:23.3586}).wait(1).to({graphics:mask_graphics_87,x:137.7949,y:23.2013}).wait(3));

	// line1 copy 4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(4,1,1).p("A0PA2QA3AnBCAfQCEA+A3gmQATgOABgcQABgQgIgoQgPhNAjgVQAhgUBdAoQA5AaCBBKQCFBMA0AYQBaApAegUQAhgWgIg4QgEgigdhOQgehOgEgiQgIg4AigWQAmgZBrA+QBAAnCnByQCkBtB1AxQCkBECAgVQDhgkEEjDQCChiBVhb");
	this.shape.setTransform(129.602,21.3138);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48).to({_off:false},0).wait(42));

	// mask4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_38 = new cjs.Graphics().p("AG3ELQgQgDgBgHIgMiEQgBgHAQgGQAPgGAWgCQAXgCAQADQAQADABAHIAMCEQAAAHgPAGQgPAGgXACIgQABQgMAAgKgCg");
	var mask_1_graphics_39 = new cjs.Graphics().p("AG2EFQgQgEgBgIIgQiaQAAgIAPgHQAPgIAWgCQAWgCARAEQAQAEABAIIAQCaQAAAIgPAHQgPAHgWADIgQABQgMAAgLgDg");
	var mask_1_graphics_40 = new cjs.Graphics().p("AG1D/QgQgFgBgJIgUi0QgCgJAPgIQAPgIAXgDQAWgCAQAEQARAFABAJIAUCzQABAJgPAJQgPAIgWADIgPAAQgNAAgLgCg");
	var mask_1_graphics_41 = new cjs.Graphics().p("AG1D4QgRgGgBgKIgajNQgCgLAPgJQAPgJAWgDQAWgCARAFQARAEABALIAaDNQABAKgOAKQgPAJgWADIgPABQgNAAgLgDg");
	var mask_1_graphics_42 = new cjs.Graphics().p("AG0DxQgRgHgBgLIghjnQgCgMAPgKQAOgLAWgDQAXgDAQAGQARAGACAMIAhDnQABALgOALQgPAKgWAEIgOABQgOAAgLgEg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AGzDqQgRgHgCgNIgnkAQgCgNAOgMQAOgMAWgDQAWgEARAHQASAHACANIAnEAQACANgOAMQgOAMgWADIgPABQgNAAgMgEg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AGzDjQgRgHgDgPIgvkYQgCgOAOgNQAOgNAWgEQAWgDARAHQARAIADAOIAvEYQACAPgOANQgOAMgWAEIgOABQgOAAgLgFg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AGyDdQgRgIgDgQIg2kuQgDgQAOgNQANgOAWgEQAWgEASAIQARAIADAQIA2EuQADAQgOAOQgNANgWAEIgOACQgOAAgMgGg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AGyDYQgSgJgDgQIg9lDQgDgQANgPQANgOAWgEQAWgFASAJQASAJADAQIA9FCQADARgNAPQgNAOgWAEIgOACQgOAAgMgGg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AGxDTQgSgJgDgRIhDlTQgEgRANgPQAOgQAWgEQAVgFASAKQASAJAEARIBDFTQADARgNAQQgNAPgWAEIgNACQgOAAgNgHg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AGyDXQgSgKgDgSIhIlgQgEgSANgPQANgQAWgFQAVgEASAJQATAKADASIBJFgQADARgNARQgNAPgVAFIgOABQgOAAgNgGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_1_graphics_38,x:52.9659,y:26.9007}).wait(1).to({graphics:mask_1_graphics_39,x:52.8626,y:26.3517}).wait(1).to({graphics:mask_1_graphics_40,x:52.7449,y:25.7477}).wait(1).to({graphics:mask_1_graphics_41,x:52.6164,y:25.111}).wait(1).to({graphics:mask_1_graphics_42,x:52.4813,y:24.4638}).wait(1).to({graphics:mask_1_graphics_43,x:52.3443,y:23.8274}).wait(1).to({graphics:mask_1_graphics_44,x:52.2102,y:23.2218}).wait(1).to({graphics:mask_1_graphics_45,x:52.0838,y:22.6644}).wait(1).to({graphics:mask_1_graphics_46,x:51.9696,y:22.1706}).wait(1).to({graphics:mask_1_graphics_47,x:51.8714,y:21.7529}).wait(1).to({graphics:mask_1_graphics_48,x:51.9413,y:21.1911}).wait(42));

	// line1 copy 3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(4,1,1).p("A0PA2QA3AnBCAfQCEA+A3gmQATgOABgcQABgQgIgoQgPhNAjgVQAhgUBdAoQA5AaCBBKQCFBMA0AYQBaApAegUQAhgWgIg4QgEgigdhOQgehOgEgiQgIg4AigWQAmgZBrA+QBAAnCnByQCkBtB1AxQCkBECAgVQDhgkEEjDQCChiBVhb");
	this.shape_1.setTransform(129.602,21.3138);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(38).to({_off:false},0).wait(52));

	// mask3 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_24 = new cjs.Graphics().p("ACJBgIjGhfQgLgDAAgSQAAgSAJgUQAKgUAOgLQAOgLAKAFIDGBfQALADAAASQAAASgJAUQgKAUgOALQgJAIgIAAQgEAAgDgCg");
	var mask_2_graphics_25 = new cjs.Graphics().p("ACRBjIjRhjQgLgFgBgSQgBgSAKgUQAJgUAPgLQAOgKALAFIDRBiQAKAFABASQABASgJAUQgKAUgOALQgKAHgIAAQgEAAgDgBg");
	var mask_2_graphics_26 = new cjs.Graphics().p("ACbBoIjghpQgLgFgBgTQgCgSAKgUQAJgUAPgLQAPgKALAFIDgBpQALAGABASQACASgKAUQgJAUgPALQgKAHgIAAQgFAAgDgCg");
	var mask_2_graphics_27 = new cjs.Graphics().p("ACoBuIjyhxQgNgGgCgSQgCgTAKgUQAJgUAQgKQAPgLANAGIDyByQAMAFACATQACASgJAVQgKAUgPAKQgKAGgJAAQgFAAgEgCg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AC5B3IkKh8QgOgHgDgTQgDgSAKgVQAJgUAQgKQARgKANAHIEKB8QAOAGADATQADATgKAUQgJAUgQAKQgKAGgJAAQgGAAgFgCg");
	var mask_2_graphics_29 = new cjs.Graphics().p("ADNCBIkniJQgPgHgEgUQgEgTAJgUQAJgUASgKQARgJAPAHIEoCJQAPAHAEATQAEAUgJAUQgKAUgRAJQgKAGgJAAQgHAAgHgDg");
	var mask_2_graphics_30 = new cjs.Graphics().p("ADmCNIlLiZQgRgHgFgUQgGgUAKgUQAJgVATgJQATgIAQAHIFLCZQARAHAGAUQAFAUgJAUQgKAVgTAIQgKAFgJAAQgIAAgIgDg");
	var mask_2_graphics_31 = new cjs.Graphics().p("AEBCaIlyipQgTgJgHgVQgGgUAJgUQAJgVAUgIQAUgIATAJIFyCpQATAIAHAVQAHAUgJAVQgKAUgUAIQgKAEgJAAQgKAAgKgEg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AEdCnImai6QgVgJgJgWQgIgVAJgUQAKgUAVgIQAWgIAVAKIGaC6QAVAJAIAVQAJAWgJAUQgKAUgVAIQgKADgJAAQgMAAgMgFg");
	var mask_2_graphics_33 = new cjs.Graphics().p("AE4C0InBjKQgXgLgKgWQgKgVAJgVQAKgUAWgHQAXgHAXAKIHCDKQAXAKAKAWQAJAWgJAUQgJAVgXAHQgJADgKAAQgNAAgOgGg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AFRC/InljYQgZgLgLgXQgLgWAJgUQAJgVAYgHQAYgGAZALIHlDYQAZALALAWQALAXgJAUQgKAVgYAGQgJADgJAAQgPAAgPgHg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AFmDIIoDjkQgbgMgMgXQgMgWAJgUQAJgVAZgGQAZgGAbALIIDDlQAaALAMAXQAMAXgJAUQgJAVgZAGQgJACgJAAQgQAAgRgIg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AF3DQIocjuQgcgMgNgYQgNgWAJgVQAJgUAagGQAagGAbAMIIdDuQAcANANAXQANAXgJAUQgJAVgaAFQgJACgJAAQgRAAgTgIg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AGGDXIoyj3QgdgMgOgYQgOgXAJgVQAKgUAagGQAbgFAdAMIIyD3QAcANAOAXQAOAXgJAVQgJAUgbAGQgIABgJAAQgSAAgUgIg");
	var mask_2_graphics_38 = new cjs.Graphics().p("AGPDbIpDj+QgegNgPgYQgOgXAJgVQAJgUAbgFQAcgGAdANIJED+QAdANAPAXQAPAYgKAUQgJAVgbAFQgIACgIAAQgUAAgVgJg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(24).to({graphics:mask_2_graphics_24,x:19.4047,y:9.5515}).wait(1).to({graphics:mask_2_graphics_25,x:20.2346,y:10.0401}).wait(1).to({graphics:mask_2_graphics_26,x:21.3665,y:10.5606}).wait(1).to({graphics:mask_2_graphics_27,x:22.8579,y:11.2424}).wait(1).to({graphics:mask_2_graphics_28,x:24.7676,y:12.1089}).wait(1).to({graphics:mask_2_graphics_29,x:27.1361,y:13.1741}).wait(1).to({graphics:mask_2_graphics_30,x:29.9487,y:14.4261}).wait(1).to({graphics:mask_2_graphics_31,x:33.0904,y:15.8086}).wait(1).to({graphics:mask_2_graphics_32,x:36.3425,y:17.2227}).wait(1).to({graphics:mask_2_graphics_33,x:39.4607,y:18.5624}).wait(1).to({graphics:mask_2_graphics_34,x:42.2718,y:19.757}).wait(1).to({graphics:mask_2_graphics_35,x:44.7039,y:20.7805}).wait(1).to({graphics:mask_2_graphics_36,x:46.7569,y:21.6372}).wait(1).to({graphics:mask_2_graphics_37,x:48.4644,y:22.3448}).wait(1).to({graphics:mask_2_graphics_38,x:49.5919,y:22.7617}).wait(52));

	// line1 copy 2
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(4,1,1).p("A0PA2QA3AnBCAfQCEA+A3gmQATgOABgcQABgQgIgoQgPhNAjgVQAhgUBdAoQA5AaCBBKQCFBMA0AYQBaApAegUQAhgWgIg4QgEgigdhOQgehOgEgiQgIg4AigWQAmgZBrA+QBAAnCnByQCkBtB1AxQCkBECAgVQDhgkEEjDQCChiBVhb");
	this.shape_2.setTransform(129.602,21.3138);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(24).to({_off:false},0).wait(66));

	// mask2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_16 = new cjs.Graphics().p("AA9EzQgVgGgOgMQgNgLADgLIA3jOQADgLARgDQASgEAVAGQAWAGANAMQAOALgDALIg4DOQgDALgRADIgNABQgMAAgOgDg");
	var mask_3_graphics_17 = new cjs.Graphics().p("ABEEqQgWgGgOgLQgNgLACgLIA0jYQACgLARgEQASgEAVAFQAWAFAOALQANAMgCALIgzDXQgDALgRAFQgIABgJAAQgKAAgMgCg");
	var mask_3_graphics_18 = new cjs.Graphics().p("ABLEfQgWgEgOgLQgNgMACgLIAujiQACgLARgFQARgFAWAEQAWAEAOAMQAOALgDAMIgtDhQgDAMgRAFQgJACgKAAQgJAAgLgCg");
	var mask_3_graphics_19 = new cjs.Graphics().p("ABTEVQgWgEgOgLQgOgLACgMIAnjsQACgLARgGQARgGAXADQAWAEAOALQAOAKgCAMIgnDsQgCAMgSAGQgKAEgMAAIgRgBg");
	var mask_3_graphics_20 = new cjs.Graphics().p("ABcEKQgWgDgPgLQgOgLABgNIAhj0QACgNAQgHQARgHAWADQAXADAOALQAPALgCANIghD1QgBAMgRAHQgMAFgOAAIgNgBg");
	var mask_3_graphics_21 = new cjs.Graphics().p("ABkEAQgWgDgPgKQgPgLACgNIAZj+QABgNARgIQARgIAWADQAWACAPALQAPALgBANIgaD+QgBANgRAHQgNAGgQAAIgKAAg");
	var mask_3_graphics_22 = new cjs.Graphics().p("ABsD3QgWgCgQgLQgOgKAAgOIATkGQABgNAQgJQARgIAWACQAXABAPALQAPAKgBAOIgTEGQgBANgQAJQgOAHgSAAIgHAAg");
	var mask_3_graphics_23 = new cjs.Graphics().p("ABzDvQgXgBgPgLQgPgKAAgOIANkMQABgOAQgJQAQgJAXABQAWABAPAKQAQALgBAOIgNEMQAAAOgRAJQgOAIgUAAIgEAAg");
	var mask_3_graphics_24 = new cjs.Graphics().p("AB5DrQgXAAgPgKQgQgLABgOIAHkRQABgOAQgKQAQgJAWAAQAXABAPAKQAQALgBAOIgHERQgBAOgQAKQgPAJgVAAIgCgBg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(16).to({graphics:mask_3_graphics_16,x:17.6213,y:31.048}).wait(1).to({graphics:mask_3_graphics_17,x:17.8072,y:30.0481}).wait(1).to({graphics:mask_3_graphics_18,x:17.9784,y:28.9432}).wait(1).to({graphics:mask_3_graphics_19,x:18.1177,y:27.7967}).wait(1).to({graphics:mask_3_graphics_20,x:18.2162,y:26.669}).wait(1).to({graphics:mask_3_graphics_21,x:18.2736,y:25.6144}).wait(1).to({graphics:mask_3_graphics_22,x:18.2963,y:24.6792}).wait(1).to({graphics:mask_3_graphics_23,x:18.295,y:23.9002}).wait(1).to({graphics:mask_3_graphics_24,x:18.3482,y:23.5534}).wait(66));

	// line1 copy
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(4,1,1).p("A0PA2QA3AnBCAfQCEA+A3gmQATgOABgcQABgQgIgoQgPhNAjgVQAhgUBdAoQA5AaCBBKQCFBMA0AYQBaApAegUQAhgWgIg4QgEgigdhOQgehOgEgiQgIg4AigWQAmgZBrA+QBAAnCnByQCkBtB1AxQCkBECAgVQDhgkEEjDQCChiBVhb");
	this.shape_3.setTransform(129.602,21.3138);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(16).to({_off:false},0).wait(74));

	// mask1 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("AA5COIizhjQgJgFABgSQABgRALgTQALgTAOgLQAOgKAJAFICzBiQAJAFgBARQgBASgLATQgLAUgOAKQgKAHgHAAQgDAAgDgBg");
	var mask_4_graphics_1 = new cjs.Graphics().p("AA5COIizhjQgJgFABgSQABgRALgTQALgTAOgLQAOgKAJAFICzBiQAKAFgCARQgBASgKAUQgLATgOAKQgKAHgHAAQgEAAgDgBg");
	var mask_4_graphics_2 = new cjs.Graphics().p("AA8COIi2hkQgJgFABgSQABgRAKgTQALgTAOgLQAPgKAJAFIC2BkQAJAFgBARQgBASgLATQgLAUgOAKQgJAHgIAAQgDAAgDgCg");
	var mask_4_graphics_3 = new cjs.Graphics().p("ABACPIi6hmQgKgFABgSQABgRALgTQAKgUAPgKQAOgKAKAFIC6BmQAJAFgBARQAAASgLAUQgLATgOAKQgKAHgHAAQgEAAgDgCg");
	var mask_4_graphics_4 = new cjs.Graphics().p("ABGCRIjBhqQgKgFABgSQABgRAKgTQALgUAPgKQAOgKAKAFIDBBpQAKAGgBARQAAASgLAUQgLATgOAKQgKAHgHAAQgEAAgEgCg");
	var mask_4_graphics_5 = new cjs.Graphics().p("ABMCTIjLhuQgKgGAAgSQAAgRALgTQALgUAPgKQAPgKAKAGIDLBtQAKAGAAASQAAASgLATQgLAUgPAKQgJAGgIAAQgEAAgEgCg");
	var mask_4_graphics_6 = new cjs.Graphics().p("ABTCWIjYh0QgLgGAAgSQAAgRAKgUQALgUAPgKQAPgJALAGIDYBzQALAGAAASQAAASgKAUQgLAUgPAJQgKAGgIAAQgEAAgEgCg");
	var mask_4_graphics_7 = new cjs.Graphics().p("ABbCaIjoh8QgMgHgBgSQgBgSALgTQAKgUAQgKQAQgJAMAGIDoB8QAMAGABASQABATgLAUQgKATgQAKQgKAGgIAAQgFAAgFgDg");
	var mask_4_graphics_8 = new cjs.Graphics().p("ABmCfIj9iGQgNgHgCgSQgCgTALgUQAKgTARgKQAQgJANAHID9CFQANAHACATQACATgLATQgKAUgRAJQgJAGgJAAQgGAAgFgDg");
	var mask_4_graphics_9 = new cjs.Graphics().p("ABzCkIkXiRQgOgIgDgSQgDgTAKgUQALgUARgJQASgJAOAIIEXCQQAOAIADATQADATgKAUQgLAUgRAJQgKAFgIAAQgHAAgHgEg");
	var mask_4_graphics_10 = new cjs.Graphics().p("ACDCrIk2ifQgQgIgEgTQgEgUAKgUQAKgUATgIQASgJAQAIIE2CeQAQAJAEATQAEAUgKAUQgKAUgTAIQgJAFgJAAQgIAAgIgEg");
	var mask_4_graphics_11 = new cjs.Graphics().p("ACVCyIlaiuQgRgIgGgVQgFgUAKgUQAKgUATgIQAUgIASAJIFaCtQARAJAGAUQAFAVgKAUQgKAUgUAHQgJAEgJAAQgKAAgJgEg");
	var mask_4_graphics_12 = new cjs.Graphics().p("ACpC5ImAi8QgUgKgHgVQgHgVAKgUQAKgUAVgHQAVgIATAKIGAC8QAUAJAHAVQAHAVgKAUQgKAUgVAIQgJADgJAAQgLAAgLgFg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AC8C/ImmjKQgWgKgIgWQgIgVAJgVQAKgUAWgHQAWgHAWALIGmDKQAWAKAIAWQAIAVgJAVQgKAUgWAGQgJADgJAAQgNAAgNgGg");
	var mask_4_graphics_14 = new cjs.Graphics().p("ADPDFInLjXQgXgLgKgWQgKgWAKgUQAJgUAYgHQAXgGAYALIHKDWQAXALAKAWQAKAXgKAUQgJAUgYAGQgJADgIAAQgPAAgOgHg");
	var mask_4_graphics_15 = new cjs.Graphics().p("ADfDKInqjiQgZgLgMgXQgLgWAKgVQAJgUAYgGQAZgGAZALIHqDiQAaAMALAWQALAXgKAUQgJAUgZAGQgIACgJAAQgQAAgQgHg");
	var mask_4_graphics_16 = new cjs.Graphics().p("ADtDOIoGjrQgbgMgMgXQgMgXAJgUQAKgUAZgGQAZgGAbAMIIGDrQAbAMAMAXQAMAXgJAUQgKAUgZAGQgIACgJAAQgRAAgSgIg");
	var mask_4_graphics_17 = new cjs.Graphics().p("AD6DRIofjyQgcgMgNgYQgNgXAJgUQAKgVAagFQAagGAcANIIeDyQAcAMANAXQANAYgJAUQgJAUgbAGQgIACgJAAQgSAAgSgJg");
	var mask_4_graphics_18 = new cjs.Graphics().p("AEEDUIozj4QgdgNgOgYQgNgXAJgUQAJgVAbgFQAbgGAcANIIzD4QAdANANAXQAOAYgJAUQgJAVgbAFQgIACgIAAQgTAAgUgJg");
	var mask_4_graphics_19 = new cjs.Graphics().p("AEMDUIpDj+QgegNgOgYQgPgXAJgVQAJgUAcgFQAbgGAeANIJDD+QAeANAOAXQAPAYgJAUQgJAVgcAFQgIACgIAAQgUAAgVgJg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:-13.0896,y:14.3152}).wait(1).to({graphics:mask_4_graphics_1,x:-13.1007,y:14.3353}).wait(1).to({graphics:mask_4_graphics_2,x:-13.1361,y:14.3994}).wait(1).to({graphics:mask_4_graphics_3,x:-13.2001,y:14.5142}).wait(1).to({graphics:mask_4_graphics_4,x:-13.2977,y:14.6875}).wait(1).to({graphics:mask_4_graphics_5,x:-13.1009,y:14.9284}).wait(1).to({graphics:mask_4_graphics_6,x:-12.7309,y:15.247}).wait(1).to({graphics:mask_4_graphics_7,x:-12.248,y:15.6537}).wait(1).to({graphics:mask_4_graphics_8,x:-11.6326,y:16.1576}).wait(1).to({graphics:mask_4_graphics_9,x:-10.8674,y:16.7621}).wait(1).to({graphics:mask_4_graphics_10,x:-9.9462,y:17.4585}).wait(1).to({graphics:mask_4_graphics_11,x:-8.8869,y:18.2187}).wait(1).to({graphics:mask_4_graphics_12,x:-7.7409,y:18.9939}).wait(1).to({graphics:mask_4_graphics_13,x:-6.5836,y:19.7293}).wait(1).to({graphics:mask_4_graphics_14,x:-5.4865,y:20.3837}).wait(1).to({graphics:mask_4_graphics_15,x:-4.4957,y:20.9405}).wait(1).to({graphics:mask_4_graphics_16,x:-3.6295,y:21.4014}).wait(1).to({graphics:mask_4_graphics_17,x:-2.8873,y:21.7775}).wait(1).to({graphics:mask_4_graphics_18,x:-2.2597,y:22.0824}).wait(1).to({graphics:mask_4_graphics_19,x:-2.5851,y:22.0617}).wait(71));

	// line1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(4,1,1).p("A0PA2QA3AnBCAfQCEA+A3gmQATgOABgcQABgQgIgoQgPhNAjgVQAhgUBdAoQA5AaCBBKQCFBMA0AYQBaApAegUQAhgWgIg4QgEgigdhOQgehOgEgiQgIg4AigWQAmgZBrA+QBAAnCnByQCkBtB1AxQCkBECAgVQDhgkEEjDQCChiBVhb");
	this.shape_4.setTransform(129.602,21.3138);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(90));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2,-2,263.2,46.6);


(lib.spreadsheet = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_34 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(3));

	// mask copy 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_17 = new cjs.Graphics().p("AhGH/IAAiqICNAAIAACqg");
	var mask_graphics_18 = new cjs.Graphics().p("Ah3IAIAAiqIDvAAIAACqg");
	var mask_graphics_19 = new cjs.Graphics().p("AihIAIAAiqIFDAAIAACqg");
	var mask_graphics_20 = new cjs.Graphics().p("AjFIBIAAiqIGLAAIAACqg");
	var mask_graphics_21 = new cjs.Graphics().p("AjiIBIAAiqIHFAAIAACqg");
	var mask_graphics_22 = new cjs.Graphics().p("Aj5ICIAAiqIHzAAIAACqg");
	var mask_graphics_23 = new cjs.Graphics().p("AkJICIAAiqIITAAIAACqg");
	var mask_graphics_24 = new cjs.Graphics().p("AkTICIAAiqIInAAIAACqg");
	var mask_graphics_25 = new cjs.Graphics().p("AkWICIAAiqIItAAIAACqg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_graphics_17,x:-0.3201,y:51.1251}).wait(1).to({graphics:mask_graphics_18,x:5.1749,y:51.1896}).wait(1).to({graphics:mask_graphics_19,x:9.9372,y:51.2454}).wait(1).to({graphics:mask_graphics_20,x:13.9669,y:51.2927}).wait(1).to({graphics:mask_graphics_21,x:17.2639,y:51.3314}).wait(1).to({graphics:mask_graphics_22,x:19.8283,y:51.3615}).wait(1).to({graphics:mask_graphics_23,x:21.6599,y:51.3829}).wait(1).to({graphics:mask_graphics_24,x:22.7589,y:51.3958}).wait(1).to({graphics:mask_graphics_25,x:23.1812,y:51.4001}).wait(12));

	// Layer_1 copy 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(5).p("AGGHZIsLAAQgZAAgSgSQgRgRAAgZIAAs5QAAgZARgRQASgSAZAAIMLAAQAZAAASASQARARAAAZIAAM5QAAAZgRARQgSASgZAAg");
	this.shape.setTransform(45.002,47.2763);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(17).to({_off:false},0).wait(20));

	// mask copy 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_17 = new cjs.Graphics().p("AEuBHIAAiNICrAAIAACNg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AEvBzIAAjlICqAAIAADlg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AEvCbIAAk1ICqAAIAAE1g");
	var mask_1_graphics_20 = new cjs.Graphics().p("AEvC/IAAl9ICqAAIAAF9g");
	var mask_1_graphics_21 = new cjs.Graphics().p("AEvDhIAAnBICqAAIAAHBg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AEvD+IAAn7ICqAAIAAH7g");
	var mask_1_graphics_23 = new cjs.Graphics().p("AEvEZIAAoxICqAAIAAIxg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AEvEvIAApdICqAAIAAJdg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AEvFDIAAqFICqAAIAAKFg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AEvFSIAAqjICqAAIAAKjg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AEvFfIAAq9ICqAAIAAK9g");
	var mask_1_graphics_28 = new cjs.Graphics().p("AEvFnIAArNICqAAIAALNg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AEvFsIAArXICqAAIAALXg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AEuFuIAArbICrAAIAALbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(17).to({graphics:mask_1_graphics_17,x:47.25,y:0.4799}).wait(1).to({graphics:mask_1_graphics_18,x:47.2537,y:4.8829}).wait(1).to({graphics:mask_1_graphics_19,x:47.2571,y:8.9337}).wait(1).to({graphics:mask_1_graphics_20,x:47.2602,y:12.6322}).wait(1).to({graphics:mask_1_graphics_21,x:47.263,y:15.9785}).wait(1).to({graphics:mask_1_graphics_22,x:47.2655,y:18.9725}).wait(1).to({graphics:mask_1_graphics_23,x:47.2678,y:21.6143}).wait(1).to({graphics:mask_1_graphics_24,x:47.2697,y:23.9039}).wait(1).to({graphics:mask_1_graphics_25,x:47.2713,y:25.8412}).wait(1).to({graphics:mask_1_graphics_26,x:47.2726,y:27.4263}).wait(1).to({graphics:mask_1_graphics_27,x:47.2737,y:28.6591}).wait(1).to({graphics:mask_1_graphics_28,x:47.2744,y:29.5397}).wait(1).to({graphics:mask_1_graphics_29,x:47.2749,y:30.0681}).wait(1).to({graphics:mask_1_graphics_30,x:47.25,y:30.0239}).wait(7));

	// Layer_1 copy 2
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(5).p("AGGHZIsLAAQgZAAgSgSQgRgRAAgZIAAs5QAAgZARgRQASgSAZAAIMLAAQAZAAASASQARARAAAZIAAM5QAAAZgRARQgSASgZAAg");
	this.shape_1.setTransform(45.002,47.2763);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(17).to({_off:false},0).wait(20));

	// mask copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhUgLIAAgPICpAAIAAAPg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AhUgIIAAgTICpAAIAAATg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AhUACIAAgdICpAAIAAAdg");
	var mask_2_graphics_3 = new cjs.Graphics().p("AhUAUIAAgvICpAAIAAAvg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AhUAlIAAhJICpAAIAABJg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AhUA1IAAhpICpAAIAABpg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AhUBJIAAiRICpAAIAACRg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AhUBhIAAjBICpAAIAADBg");
	var mask_2_graphics_8 = new cjs.Graphics().p("AhUB8IAAj3ICpAAIAAD3g");
	var mask_2_graphics_9 = new cjs.Graphics().p("AhUCbIAAk1ICpAAIAAE1g");
	var mask_2_graphics_10 = new cjs.Graphics().p("AhUC+IAAl7ICpAAIAAF7g");
	var mask_2_graphics_11 = new cjs.Graphics().p("AhUDkIAAnHICpAAIAAHHg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AhUEOIAAobICpAAIAAIbg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AhUE7IAAp1ICpAAIAAJ1g");
	var mask_2_graphics_14 = new cjs.Graphics().p("AhUFsIAArXICpAAIAALXg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AhUGhIAAtBICpAAIAANBg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AhUHaIAAuzICpAAIAAOzg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AhUIWIAAwrICpAAIAAQrg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:-1.25,y:-2.75}).wait(1).to({graphics:mask_2_graphics_1,x:-1.2517,y:-2.7548}).wait(1).to({graphics:mask_2_graphics_2,x:-1.2569,y:-2.769}).wait(1).to({graphics:mask_2_graphics_3,x:-1.2656,y:-2.7928}).wait(1).to({graphics:mask_2_graphics_4,x:-1.2777,y:-1.9884}).wait(1).to({graphics:mask_2_graphics_5,x:-1.2933,y:-0.4352}).wait(1).to({graphics:mask_2_graphics_6,x:-1.3123,y:1.4631}).wait(1).to({graphics:mask_2_graphics_7,x:-1.3348,y:3.7066}).wait(1).to({graphics:mask_2_graphics_8,x:-1.3607,y:6.2953}).wait(1).to({graphics:mask_2_graphics_9,x:-1.3901,y:9.2291}).wait(1).to({graphics:mask_2_graphics_10,x:-1.423,y:12.508}).wait(1).to({graphics:mask_2_graphics_11,x:-1.4593,y:16.1321}).wait(1).to({graphics:mask_2_graphics_12,x:-1.4991,y:20.1014}).wait(1).to({graphics:mask_2_graphics_13,x:-1.5424,y:24.4158}).wait(1).to({graphics:mask_2_graphics_14,x:-1.5891,y:29.0754}).wait(1).to({graphics:mask_2_graphics_15,x:-1.6393,y:34.0801}).wait(1).to({graphics:mask_2_graphics_16,x:-1.6929,y:39.43}).wait(1).to({graphics:mask_2_graphics_17,x:-1.75,y:45.125}).wait(20));

	// Layer_1 copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(5).p("AGGHZIsLAAQgZAAgSgSQgRgRAAgZIAAs5QAAgZARgRQASgSAZAAIMLAAQAZAAASASQARARAAAZIAAM5QAAAZgRARQgSASgZAAg");
	this.shape_2.setTransform(45.002,47.2763);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(37));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("AgZBVIAAipIAPAAIAACpg");
	var mask_3_graphics_1 = new cjs.Graphics().p("AgZBVIAAipIASAAIAACpg");
	var mask_3_graphics_2 = new cjs.Graphics().p("AgZBVIAAipIAbAAIAACpg");
	var mask_3_graphics_3 = new cjs.Graphics().p("AgZBVIAAipIAsAAIAACpg");
	var mask_3_graphics_4 = new cjs.Graphics().p("AgiBVIAAipIBFAAIAACpg");
	var mask_3_graphics_5 = new cjs.Graphics().p("AgxBVIAAipIBjAAIAACpg");
	var mask_3_graphics_6 = new cjs.Graphics().p("AhEBVIAAipICJAAIAACpg");
	var mask_3_graphics_7 = new cjs.Graphics().p("AhaBVIAAipIC1AAIAACpg");
	var mask_3_graphics_8 = new cjs.Graphics().p("AhzBVIAAipIDnAAIAACpg");
	var mask_3_graphics_9 = new cjs.Graphics().p("AiQBVIAAipIEhAAIAACpg");
	var mask_3_graphics_10 = new cjs.Graphics().p("AiwBVIAAipIFhAAIAACpg");
	var mask_3_graphics_11 = new cjs.Graphics().p("AjUBVIAAipIGpAAIAACpg");
	var mask_3_graphics_12 = new cjs.Graphics().p("Aj7BVIAAipIH3AAIAACpg");
	var mask_3_graphics_13 = new cjs.Graphics().p("AkmBVIAAipIJNAAIAACpg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AlUBVIAAipIKpAAIAACpg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AmFBVIAAipIMLAAIAACpg");
	var mask_3_graphics_16 = new cjs.Graphics().p("Am6BVIAAipIN1AAIAACpg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AnyBVIAAipIPlAAIAACpg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-2.625,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_1,x:-2.625,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_2,x:-2.625,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_3,x:-2.625,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_4,x:-1.7799,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_5,x:-0.25,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_6,x:1.6198,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_7,x:3.8296,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_8,x:6.3794,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_9,x:9.2691,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_10,x:12.4988,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_11,x:16.0684,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_12,x:19.9781,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_13,x:24.2277,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_14,x:28.8172,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_15,x:33.7468,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_16,x:39.0163,y:-2.9999}).wait(1).to({graphics:mask_3_graphics_17,x:44.6258,y:-2.9999}).wait(20));

	// Layer_1
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(5).p("AGGHZIsLAAQgZAAgSgSQgRgRAAgZIAAs5QAAgZARgRQASgSAZAAIMLAAQAZAAASASQARARAAAZIAAM5QAAAZgRARQgSASgZAAg");
	this.shape_3.setTransform(45.002,47.2763);

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(37));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.5,-2.5,95,99.6);


(lib.shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.shadow_sq();
	this.instance.setTransform(0,0,0.865,0.8249);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,129.8,123.8), null);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2204,21.2204,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6126,21.2204,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2204,6.6126,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6126,6.6126,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1623,14.0567,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9521,13.9117,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.4906,13.9117,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("ABKAAIiTAA");
	this.shape.setTransform(7.425,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line, new cjs.Rectangle(-1.5,-1.5,17.9,3), null);


(lib.icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel_icon();
	this.instance.setTransform(12.6,14.6,1.33,1.33);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlAGfQheAAAAheIAAqBQAAheBeAAIKBAAQBeAAAABeIAAKBQAABeheAAg");
	this.shape.setTransform(41.5,41.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0,0,83,83), null);


(lib.grid_line_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line_sub, new cjs.Rectangle(-1,-1,244.5,2), null);


(lib.graph3_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag4DHQgLAAgIgIQgJgJAAgLIAAlVQAAgLAJgIQAIgJALAAIBxAAQALAAAJAJQAIAIAAALIAAFVQAAALgIAJQgJAIgLAAgAgxCkIBjAAIAAlHIhjAAg");
	this.shape.setTransform(8.475,19.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graph3_cache, new cjs.Rectangle(0,0,17,39.8), null);


(lib.graph2_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhSEJQgLABgIgJQgIgIgBgLIAAnbQABgLAIgIQAIgIALgBIClAAQALABAJAIQAHAIABALIAAHbQgBALgHAIQgJAJgLgBgAhKDmICWAAIAAnLIiWAAg");
	this.shape.setTransform(11.05,26.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graph2_cache, new cjs.Rectangle(0,0,22.1,53.1), null);


(lib.graph1_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3ChQgLgBgJgHQgIgJAAgLIAAkJQAAgLAIgIQAJgIALgBIBvAAQALABAJAIQAIAIAAALIAAEJQAAALgIAJQgJAHgLABgAgwB+IBhAAIAAj6IhhAAg");
	this.shape.setTransform(8.4,16.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graph1_cache, new cjs.Rectangle(0,0,16.8,32.1), null);


(lib.end_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excelscreen_END();
	this.instance.setTransform(0,0,1.9763,1.9762);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.end_UI, new cjs.Rectangle(0,0,375.5,251), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.line_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,1,1).p("ABDAAIiFAB");
	this.shape_1.setTransform(8.175,0.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_1, new cjs.Rectangle(0,-1.5,16.4,3.2), null);


(lib.cp_light_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#499F66").s().p("AiuGfQhRgig+g/Qg+g+gjhRQgjhUAAhaQAAhbAjhUQAjhRA+g+QA+g/BRgiQBTgjBbAAQBcAABTAjQBRAiA+A/QA+A+AjBRQAjBUAABbQAABagjBUQgjBRg+A+Qg+A/hRAiQhTAjhcAAQhbAAhTgjgAh6kjQg5AYgsAsQhdBcAACEQAACDBdBcQBcBdCDAAQCEAABchdQBdhcAAiDQAAiEhdhcQhchdiEAAQhAAAg6AZg");
	this.shape.setTransform(45,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cp_light_cache, new cjs.Rectangle(0,0,90,90), null);


(lib.chartpie2_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#367148").s().p("AiuGeQhQgjg/g+Qg9g+gjhQQgjhUAAhbQAAhaAjhUQAjhQA9g+QA/g+BQgjQBTgjBbAAQBcAABTAjQBQAjA/A+QA9A+AiBQQAkBUAABaQAABbgkBUQgiBQg9A+Qg/A+hQAjQhTAjhcAAQhbAAhTgjgAh6kiQg5AYgrArQhdBdgBCCQABCDBdBdQBbBcCDAAQCDAABchcQBehdAAiDQAAiChehdQhchciDAAQg/AAg7AZg");
	this.shape.setTransform(44.9,44.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chartpie2_c, new cjs.Rectangle(0,0,89.8,89.8), null);


(lib.chartpie_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#367148").s().p("AiuGfQhRgig+g/Qg+g+gjhRQgjhUAAhaQAAhbAjhUQAjhRA+g+QA+g/BRgiQBTgjBbAAQBcAABTAjQBRAiA+A/QA+A+AjBRQAjBUAABbQAABagjBUQgjBRg+A+Qg+A/hRAiQhTAjhcAAQhbAAhTgjgAh6kjQg5AYgsAsQhdBcAACEQAACDBdBcQBcBdCDAAQCEAABchdQBdhcAAiDQAAiEhdhcQhchdiEAAQhAAAg6AZg");
	this.shape.setTransform(45,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chartpie_c, new cjs.Rectangle(0,0,90,90), null);


(lib.bar_2c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#49A166").s().p("AihGFIAAsJIFDAAIAAMJg");
	this.shape.setTransform(16.175,38.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar_2c, new cjs.Rectangle(0,0,32.4,77.8), null);


(lib.bar_1_cache = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#367148").s().p("AiiIUIAAwoIFEAAIAAQog");
	this.shape.setTransform(16.25,53.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar_1_cache, new cjs.Rectangle(0,0,32.5,106.5), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ai6E+QiShagninQgmieBQiMIAIgPILBGzIgJAPQhZCGifAlQgzAMgxAAQhvAAhmg/g");
	var mask_graphics_1 = new cjs.Graphics().p("AjdEWQiBhxgMiqQgLijBlh9IAMgNIJwIgIgMAOQhuB1ijALIgfABQiXAAh2hng");
	var mask_graphics_2 = new cjs.Graphics().p("AAkF7QiqgRhuiFQhtiEARiqQAPijB5hqIANgMIIPKAIgOALQhuBUiIAAQgWAAgWgCg");
	var mask_graphics_3 = new cjs.Graphics().p("AgCF1QimgthWiUQhWiVAsilQAqieCIhVIAPgKIGfLNIgPAJQhbAxhiAAQg2AAg4gPg");
	var mask_graphics_4 = new cjs.Graphics().p("AgjFsQidhHg8igQg9igBHidQBDiVCUg+IAQgGIElMHIgRAGQhCAWhBAAQhVAAhUgmg");
	var mask_graphics_5 = new cjs.Graphics().p("Ag+FVQiPhggiioQghioBfiPQBaiICcglIARgDICjMsIgSAEQgjAFghAAQh4AAhphGg");
	var mask_graphics_6 = new cjs.Graphics().p("AhSEvQh9h2gGirQgGirB1h+QBvh3CggLIASgBIAbM8IgRABQihgBh2hvg");
	var mask_graphics_7 = new cjs.Graphics().p("ABtGbQidgbhkiBQhoiJAWipQAXirCIhoQCAhkCgAQIASABIhsM2IgSgCg");
	var mask_graphics_8 = new cjs.Graphics().p("AALGSQiXg1hNiQQhRiXAyikQAyilCXhRQCPhNCbAqIARAEIjxMaIgQgFg");
	var mask_graphics_9 = new cjs.Graphics().p("AhSGCQiNhMg1ibQg3ihBMibQBMiaCjg3QCag0CSBCIAQAHIluLnIgQgIg");
	var mask_graphics_10 = new cjs.Graphics().p("AioFuQh/higbihQgcipBliMQBkiLCpgcQChgbCFBZIAPAKInjKhIgOgKg");
	var mask_graphics_11 = new cjs.Graphics().p("Aj0FWQhuh2ABikQAAiqB6h6QB5h5CrAAQCjAAB2BuIAMAMIpKJJIgMgMg");
	var mask_graphics_12 = new cjs.Graphics().p("Ak0E6QhYiGAbihQAcipCMhjQCMhkCoAcQChAbBiB/IALAOIqjHhIgKgOg");
	var mask_graphics_13 = new cjs.Graphics().p("AllEcQhCiTA1iZQA4ijCahMQCahMCiA4QCbA1BLCNIAIAQIroFtIgHgQg");
	var mask_graphics_14 = new cjs.Graphics().p("AmID7QgoibBNiPQBRiYClgxQCkgyCXBSQCQBNAzCXIAGARIsaDvIgFgRg");
	var mask_graphics_15 = new cjs.Graphics().p("AmbDZQgOigBjiAQBpiICrgWQCqgWCIBpQCBBjAaCeIADARIs3BqIgCgRg");
	var mask_graphics_16 = new cjs.Graphics().p("AmeC5IABgRQAMigB3hvQB+h1CrAGQCsAHB1B9QBvB3AACgIAAASg");
	var mask_graphics_17 = new cjs.Graphics().p("AmaBUIADgRQAmibCIhaQCPhfCoAiQCoAiBfCPQBbCHgbCfIgDARg");
	var mask_graphics_18 = new cjs.Graphics().p("AmRgMIAGgRQA/iTCVhDQCdhHCfA+QChA9BGCcQBDCUg0CYIgFARg");
	var mask_graphics_19 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_20 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_21 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_22 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_23 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_24 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_25 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_26 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_27 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_28 = new cjs.Graphics().p("AmChoIAJgQQBViHCegqQCmgsCUBXQCVBXAsCmQApCdhMCNIgIAPg");
	var mask_graphics_29 = new cjs.Graphics().p("AmDhkIAJgQQBViICdgrQClgtCVBWQCWBVAtCmQAqCdhLCOIgIAPg");
	var mask_graphics_30 = new cjs.Graphics().p("AmFhYIAIgPQBSiKCcgvQCkgxCXBSQCXBSAxClQAvCchICPIgIAQg");
	var mask_graphics_31 = new cjs.Graphics().p("AmKhAIAIgPQBMiOCag1QCig4CaBLQCbBMA4CiQA1CZhBCTIgIAQg");
	var mask_graphics_32 = new cjs.Graphics().p("AmPgaIAGgQQBCiSCXhAQCehCCfBBQCfBABDCfQA/CVg4CXIgGAQg");
	var mask_graphics_33 = new cjs.Graphics().p("AmWAdIAFgRQA0iWCQhOQCXhRCkAxQClAxBRCYQBOCOgpCcIgFARg");
	var mask_graphics_34 = new cjs.Graphics().p("AmcBtIADgSQAgicCEhgQCLhkCpAbQCqAbBlCMQBfCDgUCfIgCASg");
	var mask_graphics_35 = new cjs.Graphics().p("AmeDBQAEihBxh0QB4h7CsgCQCrgDB7B4QB1BxAICgIABARIs9ANIAAgSg");
	var mask_graphics_36 = new cjs.Graphics().p("AmQDwQggidBViLQBZiTCngoQCmgpCTBZQCLBVAsCZIAFARIsmDFIgEgRg");
	var mask_graphics_37 = new cjs.Graphics().p("AlUEoQhLiPAsicQAtimCVhVQCWhVCkAtQCeArBUCJIAJAPIrQGaIgIgPg");
	var mask_graphics_38 = new cjs.Graphics().p("AjdFeQhzhwgJijQgJiqBziAQBziACrgJQCjgJB7BoIANALIoqJoIgNgMg");
	var mask_graphics_39 = new cjs.Graphics().p("AgyGIQiRhEg9iXQhBifBDieQBDieCfhBQCXg9CWA6IAQAGIlDL7IgQgHg");
	var mask_graphics_40 = new cjs.Graphics().p("ACHGdQiegVhph9QhuiEAPiqQAPirCEhvQB8hoChAIIARACIhKM5IgRgBg");
	var mask_graphics_41 = new cjs.Graphics().p("AhAFSQiOhigfipQgfioBiiOQBciGCcgiIARgEICWMvIgRADQggAFgeAAQh8AAhqhKg");
	var mask_graphics_42 = new cjs.Graphics().p("AgaFwQighAhEieQhEidBAifQA8iYCRhEIAQgIIFHL6IgQAGQhJAdhKAAQhNAAhMgfg");
	var mask_graphics_43 = new cjs.Graphics().p("AAMF1QiogihfiPQhgiPAhinQAgigCDheIAOgKIHMKxIgOAJQhkA9hvAAQgqAAgsgIg");
	var mask_graphics_44 = new cjs.Graphics().p("AAwF9QirgJhzh/Qh0iAAJiqQAIikBzhvIANgNIIsJmIgNAMQhyBgiVAAIgXAAg");
	var mask_graphics_45 = new cjs.Graphics().p("AjdEXQiBhxgMirQgLijBlh8IAMgOIJwIhIgMANQhuB1ijALIgfABQiXAAh2hmg");
	var mask_graphics_46 = new cjs.Graphics().p("AjKEuQiMhkgbiqQgaigBZiGIAKgOIKgHlIgKAOQhjB+ihAaQglAGgiAAQiAAAhthPg");
	var mask_graphics_47 = new cjs.Graphics().p("Ai6E+QiShagninQgmieBQiMIAIgPILBGzIgJAPQhZCGifAlQgzAMgxAAQhvAAhmg/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:9.5024,y:38.1224}).wait(1).to({graphics:mask_graphics_1,x:7.6135,y:38.0779}).wait(1).to({graphics:mask_graphics_2,x:5.2629,y:38.0846}).wait(1).to({graphics:mask_graphics_3,x:2.5251,y:37.5085}).wait(1).to({graphics:mask_graphics_4,x:-0.4683,y:36.0962}).wait(1).to({graphics:mask_graphics_5,x:-3.6236,y:35.1784}).wait(1).to({graphics:mask_graphics_6,x:-6.8871,y:34.8094}).wait(1).to({graphics:mask_graphics_7,x:-4.8277,y:34.6532}).wait(1).to({graphics:mask_graphics_8,x:-1.4865,y:33.9695}).wait(1).to({graphics:mask_graphics_9,x:1.7135,y:32.7961}).wait(1).to({graphics:mask_graphics_10,x:4.6911,y:31.1679}).wait(1).to({graphics:mask_graphics_11,x:7.3263,y:29.087}).wait(1).to({graphics:mask_graphics_12,x:9.4947,y:26.5564}).wait(1).to({graphics:mask_graphics_13,x:11.1908,y:23.6979}).wait(1).to({graphics:mask_graphics_14,x:12.41,y:20.6279}).wait(1).to({graphics:mask_graphics_15,x:13.1157,y:17.4237}).wait(1).to({graphics:mask_graphics_16,x:13.2813,y:15.601}).wait(1).to({graphics:mask_graphics_17,x:13.6601,y:19.0037}).wait(1).to({graphics:mask_graphics_18,x:14.5666,y:22.2936}).wait(1).to({graphics:mask_graphics_19,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_20,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_21,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_22,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_23,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_24,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_25,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_26,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_27,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_28,x:15.9263,y:25.3444}).wait(1).to({graphics:mask_graphics_29,x:15.8553,y:25.2113}).wait(1).to({graphics:mask_graphics_30,x:15.6307,y:24.7757}).wait(1).to({graphics:mask_graphics_31,x:15.2442,y:23.9669}).wait(1).to({graphics:mask_graphics_32,x:14.7076,y:22.6853}).wait(1).to({graphics:mask_graphics_33,x:14.073,y:20.7978}).wait(1).to({graphics:mask_graphics_34,x:13.4757,y:18.1342}).wait(1).to({graphics:mask_graphics_35,x:13.2241,y:15.0945}).wait(1).to({graphics:mask_graphics_36,x:12.6327,y:19.5826}).wait(1).to({graphics:mask_graphics_37,x:10.5355,y:24.7916}).wait(1).to({graphics:mask_graphics_38,x:6.4391,y:29.824}).wait(1).to({graphics:mask_graphics_39,x:0.5366,y:33.2908}).wait(1).to({graphics:mask_graphics_40,x:-5.7462,y:34.787}).wait(1).to({graphics:mask_graphics_41,x:-3.9737,y:35.1761}).wait(1).to({graphics:mask_graphics_42,x:0.3485,y:36.5027}).wait(1).to({graphics:mask_graphics_43,x:3.6166,y:38.1489}).wait(1).to({graphics:mask_graphics_44,x:5.9795,y:38.11}).wait(1).to({graphics:mask_graphics_45,x:7.6202,y:38.1132}).wait(1).to({graphics:mask_graphics_46,x:8.745,y:38.1366}).wait(1).to({graphics:mask_graphics_47,x:9.5024,y:38.1224}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AjMATQAAgiADgqQAGhTAMgfQAOAnAvB1IBajCIAEDJICRh/IhJCuIBHgIQBLgKAPAAQgQAWh1BMIA1ATQA3AUAIAFIhlAv");
	this.shape.setTransform(20.5,21);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,43,44);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AotCHIAAkNIRbAAIAAENg");
	this.shape.setTransform(50.05,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-5.7,0,111.60000000000001,27), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.square3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.square.cache(0,0,20,55,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.square = new lib.square3_c();
	this.square.name = "square";
	this.square.setTransform(9.6,25.8,1,1,0,0,0,9.6,25.8);

	this.timeline.addTween(cjs.Tween.get(this.square).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square3, new cjs.Rectangle(0,0,19.3,51.7), null);


(lib.square2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.square.cache(0,0,50,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.square = new lib.square_2_cache();
	this.square.name = "square";
	this.square.setTransform(23.4,9.6,1,1,0,0,0,23.4,9.6);

	this.timeline.addTween(cjs.Tween.get(this.square).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square2, new cjs.Rectangle(0,0,47,19.2), null);


(lib.square1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.square.cache(0,0,20,20,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.square = new lib.square_1_cache();
	this.square.name = "square";
	this.square.setTransform(9.6,9.6,1,1,0,0,0,9.6,9.6);

	this.timeline.addTween(cjs.Tween.get(this.square).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.square1, new cjs.Rectangle(0,0,19.3,19.2), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.popRight = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineR3 = new lib.line();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(0,4.55,0.5349,0.5349,0,-33.7472,146.2528,15.1,0.1);

	this.lineR2 = new lib.line();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(1.8,11.75,0.5349,0.5349,0,-2.7453,177.2547,15,0.1);

	this.lineR1 = new lib.line();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(-0.25,18.3,0.5349,0.5349,0,37.2543,-142.7457,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popRight, new cjs.Rectangle(-1.1,-1.1,11.799999999999999,25.3), null);


(lib.popLeft = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.lineL3 = new lib.line();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(9.8,4.55,0.5349,0.5349,33.7472,0,0,15.1,0.1);

	this.lineL2 = new lib.line();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(8,11.75,0.5349,0.5349,2.7453,0,0,15,0.1);

	this.lineL1 = new lib.line();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(10.05,18.3,0.5349,0.5349,-37.2543,0,0,15.1,0.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.popLeft, new cjs.Rectangle(-0.8,-1.1,11.8,25.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mobile = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.ExcelMobileUniversityBudgetAndroid111();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shadow = new lib.shadow();
	this.shadow.name = "shadow";
	this.shadow.setTransform(14,34,0.3989,0.7175,0,0,0,65.3,61.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mobile, new cjs.Rectangle(-12,-10.3,51.7,88.8), null);


(lib.grid_line = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.line.cache(0,0,250,10,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.line = new lib.grid_line_sub();
	this.line.name = "line";
	this.line.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get(this.line).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid_line, new cjs.Rectangle(-0.5,-0.5,243.5,1), null);


(lib.graph3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.graph.cache(0,0,20,40,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.graph = new lib.graph3_cache();
	this.graph.name = "graph";
	this.graph.setTransform(6.65,18.15,1,1,0,0,0,8.4,19.9);

	this.timeline.addTween(cjs.Tween.get(this.graph).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graph3, new cjs.Rectangle(-1.7,-1.7,16.9,39.7), null);


(lib.graph2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.graph.cache(0,0,25,55,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.graph = new lib.graph2_cache();
	this.graph.name = "graph";
	this.graph.setTransform(9.35,24.85,1,1,0,0,0,11.1,26.6);

	this.timeline.addTween(cjs.Tween.get(this.graph).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graph2, new cjs.Rectangle(-1.7,-1.7,22.099999999999998,53.1), null);


(lib.graph1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.graph = new lib.graph1_cache();
	this.graph.name = "graph";
	this.graph.setTransform(6.65,14.35,1,1,0,0,0,8.4,16.1);

	this.timeline.addTween(cjs.Tween.get(this.graph).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graph1, new cjs.Rectangle(-1.7,-1.7,16.8,32.1), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAhQAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_15 = new cjs.Graphics().p("EAg9AKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_16 = new cjs.Graphics().p("EAgEAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_17 = new cjs.Graphics().p("AelKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_18 = new cjs.Graphics().p("AcfKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_19 = new cjs.Graphics().p("AZ0KdIAAwnMBbvAAAIAAQng");
	var mask_graphics_20 = new cjs.Graphics().p("AWiKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_21 = new cjs.Graphics().p("ATRKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_22 = new cjs.Graphics().p("AQlKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_23 = new cjs.Graphics().p("AOgKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_24 = new cjs.Graphics().p("ANAKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_25 = new cjs.Graphics().p("AMHKdIAAwnMBbvAAAIAAQng");
	var mask_graphics_26 = new cjs.Graphics().p("AL0KdIAAwnMBbvAAAIAAQng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:799.9289,y:66.8845}).wait(1).to({graphics:mask_graphics_15,x:798.023,y:66.8845}).wait(1).to({graphics:mask_graphics_16,x:792.3053,y:66.8845}).wait(1).to({graphics:mask_graphics_17,x:782.7758,y:66.8845}).wait(1).to({graphics:mask_graphics_18,x:769.4345,y:66.8845}).wait(1).to({graphics:mask_graphics_19,x:752.2813,y:66.8845}).wait(1).to({graphics:mask_graphics_20,x:731.3164,y:66.8845}).wait(1).to({graphics:mask_graphics_21,x:710.3515,y:66.8845}).wait(1).to({graphics:mask_graphics_22,x:693.1983,y:66.8845}).wait(1).to({graphics:mask_graphics_23,x:679.857,y:66.8845}).wait(1).to({graphics:mask_graphics_24,x:670.3275,y:66.8845}).wait(1).to({graphics:mask_graphics_25,x:664.6098,y:66.8845}).wait(1).to({graphics:mask_graphics_26,x:662.7039,y:66.8845}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(528.8,74.8,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:883.2},12,cjs.Ease.quadInOut).wait(39).to({regX:0,regY:0.4,scaleX:2.3979,scaleY:2.3979,x:-14.2,y:7.35},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.instance_1 = new lib.Tween3("synched",0);
	this.instance_1.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_1.alpha = 0;

	this.instance_2 = new lib.MSFT_logo_sq();
	this.instance_2.setTransform(959.6,80.7,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_2}]},13).to({state:[{t:this.instance_2}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:959.55},13,cjs.Ease.quadOut).to({x:685.3},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4mAXhMAAAgvBMFxNAAAMAAAAvBg");
	this.shape.setTransform(993.6,80.85);

	this.instance_3 = new lib.Tween3("synched",0);
	this.instance_3.setTransform(993.55,80.85,2.4144,0.3635);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_3}]},65).to({state:[{t:this.instance_3}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187.9,-69.6,2363.1,301);


(lib.collabAnim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// graph3
	this.graph3 = new lib.graph3();
	this.graph3.name = "graph3";
	this.graph3.setTransform(503.65,-98.2,0.4617,0.4617,0,0,0,6.8,36.3);

	this.timeline.addTween(cjs.Tween.get(this.graph3).wait(1));

	// graph2
	this.graph2 = new lib.graph2();
	this.graph2.name = "graph2";
	this.graph2.setTransform(495.85,-98.2,0.4617,0.4617,0,0,0,9.3,49.4);

	this.timeline.addTween(cjs.Tween.get(this.graph2).wait(1));

	// graph1
	this.graph1 = new lib.graph1();
	this.graph1.name = "graph1";
	this.graph1.setTransform(488.05,-98.2,0.4617,0.4617,0,0,0,6.7,28.7);

	this.timeline.addTween(cjs.Tween.get(this.graph1).wait(1));

	// spreadsheet
	this.spreadsheet = new lib.spreadsheet();
	this.spreadsheet.name = "spreadsheet";
	this.spreadsheet.setTransform(483,-124.55,0.4617,0.4617,0,0,0,45.1,47.1);

	this.timeline.addTween(cjs.Tween.get(this.spreadsheet).wait(1));

	// charts
	this.square3 = new lib.square3();
	this.square3.name = "square3";
	this.square3.setTransform(470.75,-118.55,0.4617,0.4617,0,0,0,9.7,25.7);

	this.square2 = new lib.square2();
	this.square2.name = "square2";
	this.square2.setTransform(488.95,-138.25,0.4617,0.4617,0,0,0,23.7,9.6);

	this.square1 = new lib.square1();
	this.square1.name = "square1";
	this.square1.setTransform(470.75,-138.25,0.4617,0.4617,0,0,0,9.7,9.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.square1},{t:this.square2},{t:this.square3}]}).wait(1));

	// popLines
	this.lineR3 = new lib.line_1();
	this.lineR3.name = "lineR3";
	this.lineR3.setTransform(507.35,-90.7,0.6505,0.6505,-100.4412,0,0,14.6,0.2);

	this.lineR2 = new lib.line_1();
	this.lineR2.name = "lineR2";
	this.lineR2.setTransform(514.65,-95.3,0.6505,0.6505,-131.4435,0,0,14.5,0.1);

	this.lineR1 = new lib.line_1();
	this.lineR1.name = "lineR1";
	this.lineR1.setTransform(518,-102.2,0.6506,0.6506,-171.4508,0,0,14.6,-0.1);

	this.lineL3 = new lib.line_1();
	this.lineL3.name = "lineL3";
	this.lineL3.setTransform(464.9,-152.75,0.6506,0.6506,85.4367,0,0,14.6,-0.1);

	this.lineL2 = new lib.line_1();
	this.lineL2.name = "lineL2";
	this.lineL2.setTransform(457,-149.65,0.6505,0.6505,54.437,0,0,14.8,-0.2);

	this.lineL1 = new lib.line_1();
	this.lineL1.name = "lineL1";
	this.lineL1.setTransform(452.85,-143.15,0.6506,0.6506,14.4319,0,0,15.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.lineL1},{t:this.lineL2},{t:this.lineL3},{t:this.lineR1},{t:this.lineR2},{t:this.lineR3}]}).wait(1));

	// lines
	this.line1 = new lib.sq_line();
	this.line1.name = "line1";
	this.line1.setTransform(359.2,-112.2,0.7192,0.7192,0,0,0,129.7,21.2);

	this.timeline.addTween(cjs.Tween.get(this.line1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.collabAnim, new cjs.Rectangle(246.1,-162.3,281.5,81.20000000000002), null);


(lib.chartpie2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.cp.cache(0,0,90,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cp = new lib.chartpie2_c();
	this.cp.name = "cp";
	this.cp.setTransform(44.9,44.9,1,1,0,0,0,44.9,44.9);

	this.timeline.addTween(cjs.Tween.get(this.cp).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chartpie2, new cjs.Rectangle(0,0,89.8,89.8), null);


(lib.chartpie_light = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.cp.cache(0,0,90,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cp = new lib.cp_light_cache();
	this.cp.name = "cp";
	this.cp.setTransform(45,45.05,1.0022,1.0028,0,0,0,44.9,44.9);

	this.timeline.addTween(cjs.Tween.get(this.cp).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chartpie_light, new cjs.Rectangle(0,0,90.2,90.3), null);


(lib.chartpie = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.cp.cache(0,0,90,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.cp = new lib.chartpie_c();
	this.cp.name = "cp";
	this.cp.setTransform(44.9,44.9,1,1,0,0,0,44.9,44.9);

	this.timeline.addTween(cjs.Tween.get(this.cp).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chartpie, new cjs.Rectangle(0,0,90,90), null);


(lib.bar_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bar.cache(0,0,35,80,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bar = new lib.bar_2c();
	this.bar.name = "bar";
	this.bar.setTransform(15.85,67.75,1,1,0,0,0,16.1,38.9);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar_2, new cjs.Rectangle(-0.2,28.9,32.300000000000004,77.69999999999999), null);


(lib.bar_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bar.cache(0,0,35,110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bar = new lib.bar_1_cache();
	this.bar.name = "bar";
	this.bar.setTransform(16.2,53.2,1,1,0,0,0,16.2,53.2);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar_1, new cjs.Rectangle(0,0,32.5,106.5), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("ApYL3QhugvgthvQgthwAuhvQAwhvBwgtMAiMgNzQBvgtBuAuQBwAwAtBvQAuBwgwBvQgvBvhvAtMgiMAN0Qg2AWg3AAQg5AAg6gZg");
	var mask_graphics_54 = new cjs.Graphics().p("ApbL5QhugvguhwQgthvAvhwQAwhuBvgtMAiMgN0QBwgtBuAvQBwAvAtBwQAtBwgwBuQguBwhwAtMgiMANzQg2AWg3AAQg5AAg5gYg");
	var mask_graphics_55 = new cjs.Graphics().p("AppL+QhugvgthvQgthwAuhvQAwhvBwgtMAiMgNzQBvgtBuAuQBwAwAtBvQAtBwgwBvQguBvhvAtMgiMAN0Qg3AWg2AAQg5AAg6gZg");
	var mask_graphics_56 = new cjs.Graphics().p("AqFMKQhvgvgthwQgthvAuhwQAwhuBwgtMAiMgN0QBvgtBvAvQBwAvAtBwQAtBwgwBuQgvBwhvAtMgiMANzQg2AWg3AAQg5AAg5gYg");
	var mask_graphics_57 = new cjs.Graphics().p("Aq4MeQhugvgthvQgthwAuhvQAwhvBwgtMAiMgNzQBvgtBuAuQBwAwAtBvQAtBwgwBvQguBvhvAtMgiMAN0Qg3AVg2AAQg5AAg6gYg");
	var mask_graphics_58 = new cjs.Graphics().p("Ar8M6QhugvgthwQgthvAuhwQAwhuBwgtMAiLgN0QBwgtBuAvQBwAvAtBwQAtBvgwBvQguBwhwAtMgiLANzQg3AWg2AAQg5AAg6gYg");
	var mask_graphics_59 = new cjs.Graphics().p("As+NUQhugvgthvQgthwAuhvQAwhvBwgtMAiMgNzQBvgtBvAuQBvAwAuBvQAtBwgwBvQgvBvhvAtMgiMAN0Qg2AWg3AAQg5AAg6gZg");
	var mask_graphics_60 = new cjs.Graphics().p("AtyNpQhugugthwQgthwAuhvQAwhvBwgtMAiMgNzQBvgtBuAuQBwAwAtBwQAtBvgwBvQguBvhvAtMgiMAN0Qg3AWg2AAQg5AAg6gZg");
	var mask_graphics_61 = new cjs.Graphics().p("AuaN5QhugugthwQgthvAuhwQAwhvBwgtMAiMgNzQBvgtBuAvQBwAvAtBwQAtBvgwBvQguBvhvAsMgiMAN1Qg3AWg2AAQg5AAg6gZg");
	var mask_graphics_62 = new cjs.Graphics().p("Au4OGQhvgvgthvQgthwAuhvQAwhvBwgtMAiMgN0QBvgtBvAvQBwAwAtBvQAtBwgwBuQgvBwhvAsMgiMAN0Qg2AWg3AAQg5AAg5gYg");
	var mask_graphics_63 = new cjs.Graphics().p("AvQOQQhvgvgthwQgthvAuhwQAwhuBwguMAiMgNzQBvgtBvAvQBwAvAtBwQAtBvgwBvQgvBwhvAsMgiMAN0Qg2AWg3AAQg5AAg5gYg");
	var mask_graphics_64 = new cjs.Graphics().p("AvjOXQhugvguhvQgthwAvhvQAwhvBvgtMAiMgNzQBwgtBuAuQBwAwAtBvQAtBwgwBvQguBvhwAsMgiMAN1Qg2AWg3AAQg5AAg5gZg");
	var mask_graphics_65 = new cjs.Graphics().p("AvyOdQhugvgthvQgthwAuhvQAwhvBvgtMAiMgNzQBwgtBuAuQBwAwAtBvQAtBwgwBvQguBvhwAsMgiMAN1Qg2AWg2AAQg6AAg5gZg");
	var mask_graphics_66 = new cjs.Graphics().p("Av+OiQhugvgthvQgthwAuhvQAwhvBwgtMAiMgN0QBvgtBuAvQBwAwAtBvQAuBwgwBuQgvBvhvAtMgiMAN0Qg2AWg3AAQg5AAg6gYg");
	var mask_graphics_67 = new cjs.Graphics().p("AwHOlQhugugthwQgthvAuhwQAwhvBwgtMAiMgNzQBvgtBuAvQBwAvAtBwQAuBvgwBvQgvBuhvAuMgiMAN0Qg2AWg3AAQg5AAg6gZg");
	var mask_graphics_68 = new cjs.Graphics().p("AwNOoQhvgvgthvQgthwAvhvQAwhvBvgtMAiMgNzQBwgtBuAuQBwAwAtBvQAtBwgwBvQguBuhwAtMgiMAN1Qg2AWg3AAQg5AAg5gZg");
	var mask_graphics_69 = new cjs.Graphics().p("AwSOqQhugvgthvQguhwAvhvQAwhvBvgtMAiMgNzQBwgtBuAuQBwAwAtBvQAtBwgwBvQguBuhwAtMgiMAN1Qg2AWg2AAQg6AAg5gZg");
	var mask_graphics_70 = new cjs.Graphics().p("AwVOrQhvgugthwQgthvAuhwQAwhvBwgtMAiMgNzQBvgtBvAvQBwAvAtBwQAtBvgwBvQgvBuhvAuMgiMAN0Qg2AWg3AAQg5AAg5gZg");
	var mask_graphics_71 = new cjs.Graphics().p("AwXOsQhugvguhvQgthwAvhvQAwhvBvgtMAiMgNzQBwgtBuAuQBwAwAtBvQAtBwgwBvQguBuhwAtMgiMAN1Qg2AWg3AAQg5AAg5gZg");
	var mask_graphics_72 = new cjs.Graphics().p("AwYOsQhugugthwQgthvAuhwQAwhvBwgtMAiLgNzQBwgtBuAvQBwAvAtBwQAtBvgwBvQguBuhwAuMgiLAN0Qg3AWg2AAQg5AAg6gZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:199.4329,y:78.3586}).wait(1).to({graphics:mask_graphics_54,x:199.0652,y:78.507}).wait(1).to({graphics:mask_graphics_55,x:197.7174,y:79.052}).wait(1).to({graphics:mask_graphics_56,x:194.8474,y:80.2125}).wait(1).to({graphics:mask_graphics_57,x:189.8132,y:82.2481}).wait(1).to({graphics:mask_graphics_58,x:183.0059,y:85.0006}).wait(1).to({graphics:mask_graphics_59,x:176.4398,y:87.6556}).wait(1).to({graphics:mask_graphics_60,x:171.214,y:89.7687}).wait(1).to({graphics:mask_graphics_61,x:167.2205,y:91.3834}).wait(1).to({graphics:mask_graphics_62,x:164.1468,y:92.6263}).wait(1).to({graphics:mask_graphics_63,x:161.7513,y:93.5949}).wait(1).to({graphics:mask_graphics_64,x:159.8693,y:94.3559}).wait(1).to({graphics:mask_graphics_65,x:158.3882,y:94.9548}).wait(1).to({graphics:mask_graphics_66,x:157.2286,y:95.4237}).wait(1).to({graphics:mask_graphics_67,x:156.3331,y:95.7858}).wait(1).to({graphics:mask_graphics_68,x:155.6585,y:96.0585}).wait(1).to({graphics:mask_graphics_69,x:155.1721,y:96.2552}).wait(1).to({graphics:mask_graphics_70,x:154.8479,y:96.3863}).wait(1).to({graphics:mask_graphics_71,x:154.6653,y:96.4601}).wait(1).to({graphics:mask_graphics_72,x:154.6079,y:96.4836}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(103.65,146.8,0.9797,0.9797,0,0,0,42.1,16.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("AQiJoMgjegJ3Qh0ggg8hqQg6hoAgh0QAghzBog8QBqg7BzAgMAjeAJ3QB0AgA7BoQA8BqghBzQggB0hpA7QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AQiJsMgjegJ3Qh0ggg8hqQg6hoAghzQAgh0Bog8QBqg7BzAhMAjeAJ2QB0AgA7BoQA8BqghB0QggBzhpA7QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AQiJ4MgjegJ3Qh0ggg8hpQg6hoAgh0QAgh0Bog8QBqg6BzAgMAjeAJ2QB0AgA7BpQA8BpghB0QggB0hpA6QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AQiKLMgjegJ3Qh0ggg8hpQg6hoAgh0QAgh0Bog8QBqg6BzAgMAjeAJ2QB0AhA7BoQA8BpghB0QggB0hpA6QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AQiKjMgjegJ3Qh0ggg8hpQg6hoAgh0QAgh0Bog8QBqg6BzAgMAjeAJ2QB0AhA7BoQA8BpghB0QggB0hpA6QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AQiK+MgjegJ4Qh0ggg8hoQg6hpAghzQAgh0Bog8QBqg7BzAhMAjeAJ2QB0AgA7BoQA8BqghB0QggB0hpA6QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AQiLZMgjegJ4Qh0ggg8hpQg6hoAgh0QAghzBog8QBqg7BzAgMAjeAJ3QB0AgA7BoQA8BqghBzQggB0hpA7QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AQiLxMgjegJ4Qh0ggg8hpQg6hoAgh0QAghzBog8QBqg7BzAgMAjeAJ3QB0AgA7BoQA8BqghB0QggBzhpA7QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AQiMEMgjegJ4Qh0ggg8hqQg6hnAghzQAgh0Bog8QBqg7BzAhMAjeAJ2QB0AgA7BoQA8BqghB0QggBzhpA7QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AQiMQMgjegJ3Qh0ghg8hpQg6hnAgh0QAgh0Bog8QBqg6BzAgMAjeAJ2QB0AgA7BoQA8BqghB0QggB0hpA6QhEAnhJAAQgnAAgogLg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AQiMUMgjegJ3Qh0ghg8hpQg6hnAgh0QAgh0Bog8QBqg6BzAgMAjeAJ2QB0AgA7BpQA8BpghB0QggB0hpA6QhEAnhJAAQgnAAgogLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-91.8408,y:62.6757}).wait(1).to({graphics:mask_1_graphics_45,x:-88.7897,y:63.0986}).wait(1).to({graphics:mask_1_graphics_46,x:-79.9352,y:64.3249}).wait(1).to({graphics:mask_1_graphics_47,x:-66.1439,y:66.235}).wait(1).to({graphics:mask_1_graphics_48,x:-48.7659,y:68.6419}).wait(1).to({graphics:mask_1_graphics_49,x:-29.5022,y:71.3099}).wait(1).to({graphics:mask_1_graphics_50,x:-10.2385,y:73.9779}).wait(1).to({graphics:mask_1_graphics_51,x:7.1395,y:76.3847}).wait(1).to({graphics:mask_1_graphics_52,x:20.9308,y:78.2948}).wait(1).to({graphics:mask_1_graphics_53,x:29.7854,y:79.5211}).wait(1).to({graphics:mask_1_graphics_54,x:32.7092,y:79.9257}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(88.65,114.45,0.9797,0.9797,0,0,0,57.3,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AqCItQhog8gfh0Qgfh1A8hoQA9hoB0ggMAjmgJhQB0gfBnA8QBqA8AfB1QAfB0g9BoQg8Boh0AgMgjmAJhQgnALgmAAQhKAAhGgog");
	var mask_2_graphics_39 = new cjs.Graphics().p("AqiItQhog8gfh0Qgfh1A7hoQA9hoB1ggMAjlgJhQB0gfBoA8QBpA8AfB1QAgB0g+BoQg7Boh0AgMgjmAJhQgnALgmAAQhLAAhFgog");
	var mask_2_graphics_40 = new cjs.Graphics().p("Ar9ItQhng8gfh0Qgfh1A7hoQA9hoB0ggMAjmgJhQB0gfBoA8QBpA8AfB1QAfB0g9BoQg7Boh1AgMgjlAJhQgoALgmAAQhKAAhGgog");
	var mask_2_graphics_41 = new cjs.Graphics().p("At/ItQhog8gfh0Qgfh1A7hoQA+hoB0ggMAjlgJhQB1gfBnA8QBpA8AgB1QAfB0g9BoQg8Boh0AgMgjmAJhQgnALgmAAQhLAAhFgog");
	var mask_2_graphics_42 = new cjs.Graphics().p("AwQItQhog8gfh0Qgfh1A8hoQA9hoB0gfMAjlgJiQB1gfBnA8QBpA8AgB1QAfB0g9BoQg8Boh0AgMgjmAJhQgnALgmAAQhLAAhFgog");
	var mask_2_graphics_43 = new cjs.Graphics().p("AyTI6Qhng8gfh0Qgfh0A7hpQA9hoB0gfMAjmgJiQB0gfBoA8QBpA9AfB0QAfB0g9BoQg7Bph1AfMgjlAJiQgoAKgmAAQhKAAhGgog");
	var mask_2_graphics_44 = new cjs.Graphics().p("AztJSQhog8gfh0Qgfh0A8hpQA9hoB0gfMAjmgJhQB0ggBnA8QBqA9AfB0QAfB0g9BoQg8Bph0AeMgjmAJjQgnAKgmAAQhKAAhGgog");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0EJbQhog8gfh0Qgfh0A7hpQA9hoB0gfMAjmgJiQB0gfBoA8QBpA9AfB0QAfB0g9BoQg7Bph0AeMgjmAJiQgnALgmAAQhLAAhFgog");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:207.3177,y:33.9277}).wait(1).to({graphics:mask_2_graphics_39,x:204.0931,y:35.6608}).wait(1).to({graphics:mask_2_graphics_40,x:195.0577,y:40.5167}).wait(1).to({graphics:mask_2_graphics_41,x:182.0012,y:47.5336}).wait(1).to({graphics:mask_2_graphics_42,x:167.5095,y:55.3218}).wait(1).to({graphics:mask_2_graphics_43,x:154.4529,y:61.0063}).wait(1).to({graphics:mask_2_graphics_44,x:145.4175,y:63.4343}).wait(1).to({graphics:mask_2_graphics_45,x:141.3061,y:64.3008}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(91.75,82.25,0.9797,0.9797,0,0,0,60.5,16.5);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_32 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahBhlQhBhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_33 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahBhlQhBhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_34 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_35 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_36 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_37 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_38 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_39 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahBhlQhBhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");
	var mask_3_graphics_40 = new cjs.Graphics().p("ARCIYMgj/gH3Qh2gahChlQhAhlAah2QAZh1BlhCQBmhAB2AZMAj/AH4QB2AZBBBkQBBBmgZB2QgaB1hmBBQhJAvhRAAQggAAghgHg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-88.0381,y:13.1588}).wait(1).to({graphics:mask_3_graphics_32,x:-84.2297,y:14.0167}).wait(1).to({graphics:mask_3_graphics_33,x:-73.2638,y:16.4868}).wait(1).to({graphics:mask_3_graphics_34,x:-56.4631,y:20.2713}).wait(1).to({graphics:mask_3_graphics_35,x:-35.854,y:24.9137}).wait(1).to({graphics:mask_3_graphics_36,x:-13.9222,y:29.8539}).wait(1).to({graphics:mask_3_graphics_37,x:6.6869,y:34.4963}).wait(1).to({graphics:mask_3_graphics_38,x:23.4876,y:38.2808}).wait(1).to({graphics:mask_3_graphics_39,x:34.4535,y:40.7509}).wait(1).to({graphics:mask_3_graphics_40,x:38.2619,y:41.6088}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(92.35,53.4,0.9797,0.9797,0,0,0,59.7,13.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("AqyHfQhlhEgYh3QgYh4BDhmQBFhkB4gYMAkrgHUQB3gYBlBDQBnBFAYB3QAYB4hFBlQhDBmh4AXMgkrAHUQgfAHgeAAQhVAAhMgzg");
	var mask_4_graphics_20 = new cjs.Graphics().p("Aq2HfQhlhEgXh3QgYh4BDhmQBFhkB3gYMAkrgHUQB4gYBlBDQBmBFAYB3QAYB4hFBlQhDBmh4AXMgkqAHUQgfAHgeAAQhWAAhMgzg");
	var mask_4_graphics_21 = new cjs.Graphics().p("ArBHfQhlhEgYh3QgYh4BDhmQBFhkB4gYMAkqgHUQB4gYBkBDQBnBFAYB3QAYB4hFBlQhDBmh4AXMgkqAHUQgfAGgeAAQhVAAhMgyg");
	var mask_4_graphics_22 = new cjs.Graphics().p("ArYHeQhkhDgYh4QgYh3BDhmQBFhkB3gYMAkpgHUQB4gYBlBEQBmBEAYB4QAYB3hFBlQhDBmh3AXMgkpAHUQgfAGgeAAQhWAAhMgzg");
	var mask_4_graphics_23 = new cjs.Graphics().p("Ar8HeQhlhDgYh4QgYh3BDhmQBFhkB3gYMAkogHUQB3gXBlBDQBmBEAYB4QAYB3hFBlQhDBmh3AXMgknAHUQgfAGgeAAQhVAAhMgzg");
	var mask_4_graphics_24 = new cjs.Graphics().p("As0HdQhlhDgYh3QgYh3BDhmQBFhkB3gYMAklgHTQB3gYBlBEQBmBEAYB3QAXB4hEBkQhDBlh3AYMgklAHTQgfAGgdAAQhWAAhLgzg");
	var mask_4_graphics_25 = new cjs.Graphics().p("AuEHdQhlhDgXh4QgYh3BDhmQBEhjB3gYMAkhgHSQB3gYBkBDQBmBFAYB3QAYB3hFBlQhCBkh4AYMgkgAHSQgfAGgdAAQhVAAhMgyg");
	var mask_4_graphics_26 = new cjs.Graphics().p("AvoHcQhkhDgYh3QgYh3BDhmQBEhjB3gYMAkbgHRQB3gYBlBDQBlBEAYB3QAYB3hEBlQhDBkh3AYMgkbAHRQgfAGgeAAQhUAAhMgyg");
	var mask_4_graphics_27 = new cjs.Graphics().p("AxOHbQhkhDgYh3QgXh3BChlQBEhjB3gYMAkWgHQQB3gXBkBCQBlBEAYB3QAYB3hFBkQhCBkh3AYMgkWAHQQgeAGgeAAQhVAAhLgyg");
	var mask_4_graphics_28 = new cjs.Graphics().p("AykHaQhkhDgXh2QgYh3BChlQBEhjB3gYMAkRgHPQB3gXBkBCQBlBEAYB3QAXB2hEBkQhCBkh3AYMgkRAHPQgfAGgdAAQhVAAhLgyg");
	var mask_4_graphics_29 = new cjs.Graphics().p("AzlHZQhkhDgYh2QgXh2BChlQBEhjB2gYMAkPgHOQB2gYBjBDQBmBEAXB2QAYB2hEBkQhCBkh3AYMgkOAHOQgeAGgeAAQhUAAhLgyg");
	var mask_4_graphics_30 = new cjs.Graphics().p("A0VHYQhkhCgXh2QgYh2BChlQBEhjB2gYMAkMgHNQB2gYBkBDQBlBDAYB2QAXB2hEBkQhCBkh2AYMgkMAHNQgeAHgeAAQhUAAhLgzg");
	var mask_4_graphics_31 = new cjs.Graphics().p("A0nHYQhjhCgYh2QgXh2BChlQBEhjB2gYMAkKgHNQB2gYBjBDQBlBDAYB2QAXB2hDBkQhDBkh2AYMgkKAHNQgeAGgdAAQhVAAhLgyg");
	var mask_4_graphics_32 = new cjs.Graphics().p("A0mHYQhjhDgYh2QgXh1BChlQBDhjB2gYMAkJgHNQB2gXBkBCQBlBEAXB2QAYB2hEBjQhCBkh2AYMgkJAHNQgeAGgeAAQhUAAhLgyg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:211.6851,y:-9.4163}).wait(1).to({graphics:mask_4_graphics_20,x:211.3228,y:-9.2726}).wait(1).to({graphics:mask_4_graphics_21,x:210.0954,y:-8.7868}).wait(1).to({graphics:mask_4_graphics_22,x:207.7291,y:-7.8502}).wait(1).to({graphics:mask_4_graphics_23,x:203.8306,y:-6.3072}).wait(1).to({graphics:mask_4_graphics_24,x:197.8784,y:-3.9514}).wait(1).to({graphics:mask_4_graphics_25,x:189.4143,y:-0.6014}).wait(1).to({graphics:mask_4_graphics_26,x:178.8168,y:3.593}).wait(1).to({graphics:mask_4_graphics_27,x:167.9959,y:7.8758}).wait(1).to({graphics:mask_4_graphics_28,x:158.8761,y:11.4853}).wait(1).to({graphics:mask_4_graphics_29,x:151.9382,y:14.2313}).wait(1).to({graphics:mask_4_graphics_30,x:146.8626,y:16.2402}).wait(1).to({graphics:mask_4_graphics_31,x:141.5589,y:17.6798}).wait(1).to({graphics:mask_4_graphics_32,x:136.5612,y:18.6839}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(95.85,27.6,0.9797,0.9797,0,0,0,63.3,13.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-14.8,187.1,222.8);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-21.7,0.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.popLeft = new lib.popLeft();
	this.popLeft.name = "popLeft";
	this.popLeft.setTransform(-116.25,0.2,1,1,0,0,0,5,11.6);

	this.popRight = new lib.popRight();
	this.popRight.name = "popRight";
	this.popRight.setTransform(15.75,0.2,1,1,0,0,0,4.8,11.6);

	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100.6,-13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.CTAbg},{t:this.popRight},{t:this.popLeft}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-13.6,143.7,27), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.grid_line();
	this.instance.setTransform(121.2,105,1,1,0,0,0,121.2,0);

	this.instance_1 = new lib.grid_line();
	this.instance_1.setTransform(121.2,90,1,1,0,0,0,121.2,0);

	this.instance_2 = new lib.grid_line();
	this.instance_2.setTransform(121.2,75,1,1,0,0,0,121.2,0);

	this.instance_3 = new lib.grid_line();
	this.instance_3.setTransform(121.2,60,1,1,0,0,0,121.2,0);

	this.instance_4 = new lib.grid_line();
	this.instance_4.setTransform(121.2,45,1,1,0,0,0,121.2,0);

	this.instance_5 = new lib.grid_line();
	this.instance_5.setTransform(121.2,30,1,1,0,0,0,121.2,0);

	this.instance_6 = new lib.grid_line();
	this.instance_6.setTransform(121.2,15,1,1,0,0,0,121.2,0);

	this.instance_7 = new lib.grid_line();
	this.instance_7.setTransform(121.2,0,1,1,0,0,0,121.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-0.5,-0.5,243.5,106), null);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.grid_line();
	this.instance.setTransform(369.55,33.95,0.4977,1,90,0,0,121.2,-0.1);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(303.35,36.05,0.499,1,90,0,0,125.8,52.5);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(183.6,36.05,0.499,1,90,0,0,125.8,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_1
	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(252.95,31.9,1.0322,1,0,0,0,125.9,52.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(122.5,-26.9,251.3,121.5), null);


(lib.circle_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_29 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(29).call(this.frame_29).wait(1));

	// %
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#367148").s().p("AhLBkIB3i1QgVAEgeAAIgGAAQAHALAAAMQAAAQgLAOQgMANgUAAQgRAAgMgMQgNgMAAgSQAAgMAGgKQAFgJALgGQAKgGAKAAIAPACQAQAEASAAQAOAAAMgCQAMgCAUgFIAOAAIiCDHgAhDhIQgIAHAAAMQAAALAIAIQAIAHALABQALgBAIgHQAIgIAAgLQAAgMgIgHQgIgJgLABQgLgBgIAJgAAUBRQgNgNAAgRQAAgSANgMQAMgNASAAQARAAANANQAMAMAAASQAAARgMANQgNAMgRAAQgSAAgMgMgAAeAfQgHAJAAALQAAALAHAIQAIAIAMgBQALABAIgIQAIgIAAgLQAAgLgIgJQgIgHgLAAQgMAAgIAHg");
	this.shape.setTransform(57.625,43.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(30));

	// number
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#367148").s().p("AgtBOQgPgRAAgVQAAgPAIgMQAIgMATgJQgNgHgHgKQgHgKABgMQAAgLAGgMQAIgLAMgGQANgHANAAQAOAAAMAHQAMAGAHALQAHAMAAAMQAAAMgGAKQgHAJgNAHQATAIAHAMQAIAMAAAOQAAAVgNAQQgRAUgfAAQgdAAgQgRgAgdAMQgNAMAAARQAAAJAFAJQAGAJAKAFQAKAFALAAQATAAANgMQALgMAAgPQAAgPgMgMQgNgMgRAAQgSAAgMAMgAgXhDQgKAIAAAMQAAAMALAKQAKAKANAAQAJAAAHgEQAJgFAEgHQAFgIgBgIQAAgLgIgJQgJgJgRAAQgOAAgJAJg");
	this.shape_1.setTransform(40.85,43.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#367148").s().p("AAXBcIAAgqIhVAAIBkiNIADAAIAAB9IAWAAIAAAQIgWAAIAAAqgAgdAiIA0AAIAAhMg");
	this.shape_2.setTransform(26.9,43.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#367148").s().p("AghBVIAvhKQgKAEgHAAQgWAAgPgPQgOgQAAgWQAAgQAGgMQAIgNANgHQAOgIAOAAQAPAAANAHQAMAIAHANQAHANABAOQgBAMgEAMQgEAMgMAQIg2BSgAgahBQgLALAAAQQAAAPALAMQALALAPAAQAQAAALgLQALgMAAgPQAAgQgLgLQgMgLgPAAQgPAAgLALg");
	this.shape_3.setTransform(40.7,43.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#367148").s().p("AgfBVQgOgKgIgUQgHgTAAgkQgBgjAIgTQAIgUAOgKQAOgKARAAQAQAAAPAKQAOAKAIAVQAJAUgBAhQABAigJAUQgHAUgPALQgPAKgQAAQgRAAgOgKgAgWhFQgKAIgGAQQgGAQAAAdQAAAfAGAQQAGAPAKAIQALAIALAAQAMAAAKgIQALgHAFgQQAHgTgBgcQAAgagFgRQgHgSgKgIQgKgIgMAAQgMAAgKAIg");
	this.shape_4.setTransform(40.85,43.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#367148").s().p("AgoBPQgPgOgDgUIASAAQADAKAFAGQAEAHAJAEQAJAEAJgBQAQAAANgNQAMgOAAgUQAAgRgLgLQgMgMgRAAQgRAAgXAKIARhZIBOAAIAAAQIg/AAIgJAyQALgDAIAAQAZAAARAQQAPAQAAAZQAAASgIAPQgIAPgOAHQgPAJgRgBQgVAAgQgNg");
	this.shape_5.setTransform(26.85,43.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#367148").s().p("Ag8BcIBEhKQAVgVAGgMQAGgLAAgLQAAgQgLgKQgLgMgRAAQgQAAgMAMQgLAMgCAUIgRAAQABgaARgSQARgQAYAAQAZAAAQAPQAPARAAAWQAAAPgHAOQgIAMgVAXIgsAwIBSAAIAAARg");
	this.shape_6.setTransform(40.775,43.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#367148").s().p("AgoBPQgPgOgDgUIASAAQADAKAFAGQAEAHAJAEQAJAEAJgBQAQAAANgNQAMgOAAgUQAAgRgLgLQgMgMgRAAQgRAAgXAKIARhZIBOAAIAAAQIg/AAIgJAyQALgDAIAAQAZAAARAQQAPAQAAAZQAAASgIAPQgIAPgOAHQgPAJgRgBQgVAAgQgNg");
	this.shape_7.setTransform(26.85,43.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#367148").s().p("AgbBYQgNgIgIgNQgGgNAAgOQgBgLAFgNQAEgMAMgQIA2hSIAPAKIgwBKQAJgEAIAAQAWAAAPAPQAPAQAAAWQAAAQgIAMQgGANgOAHQgOAIgOAAQgOAAgNgHgAgaAMQgLALAAAQQAAAQALALQALALAPAAQAPAAAMgLQALgLAAgQQAAgQgLgLQgMgLgPAAQgPAAgLALg");
	this.shape_8.setTransform(27.2,43.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#367148").s().p("Ag1BVIBSigIhVAAIAAgQIBxAAIhfC3g");
	this.shape_9.setTransform(27.475,43.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#367148").s().p("AAFBaIAAiiIgbAAIALgRIAiAAIAACzg");
	this.shape_10.setTransform(39.775,43.275);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#367148").s().p("AgnBRQgQgNgEgaIARAAQAFARAJAIQALAKARAAQATAAAMgMQAMgLAAgQQAAgLgGgJQgGgJgKgFQgKgEgUgBIAAgQQALAAAKgEQAKgFAFgHQAFgGAAgIQAAgMgKgJQgJgIgOAAQgLAAgJAGQgIAHgGAQIgSAAQAFgXAOgMQAOgMATAAQAOAAAMAHQAMAGAHALQAGALAAAMQAAAXgXAOQANAFAJAJQALAPAAARQAAAQgIAOQgIAOgOAHQgOAIgQAAQgXAAgQgOg");
	this.shape_11.setTransform(40.825,43.275);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#367148").s().p("AAYBcIAAgqIhWAAIBkiNIADAAIAAB9IAWAAIAAAQIgWAAIAAAqgAgdAiIA1AAIAAhMg");
	this.shape_12.setTransform(40.85,43.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_2},{t:this.shape_3}]},3).to({state:[{t:this.shape_5,p:{x:26.85}},{t:this.shape_4}]},3).to({state:[{t:this.shape_5,p:{x:26.85}},{t:this.shape_6}]},3).to({state:[{t:this.shape_7},{t:this.shape_5,p:{x:40.8}}]},3).to({state:[{t:this.shape_8},{t:this.shape_4}]},3).to({state:[{t:this.shape_8},{t:this.shape_5,p:{x:40.8}}]},2).to({state:[{t:this.shape_9},{t:this.shape_4}]},2).to({state:[{t:this.shape_9},{t:this.shape_10}]},3).to({state:[{t:this.shape_9},{t:this.shape_11}]},2).to({state:[{t:this.shape_9},{t:this.shape_12}]},2).wait(4));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ABBIIQhygmh7h3Qh6h3Ajj1QASh7AqhkIHTCrIhyJLIgOABQgeAAgtgPg");
	var mask_graphics_1 = new cjs.Graphics().p("ABDIJQhygmh7h2Qh7h2Aij3QARh6AphjIHVCnIhvJMIgPABQgeAAgtgOg");
	var mask_graphics_2 = new cjs.Graphics().p("ABLILQhzgkh9h0Qh8h1Adj2QAQh7AohkIHWCgIhlJOQgIABgJAAQgeAAgrgNg");
	var mask_graphics_3 = new cjs.Graphics().p("ABYIOQh0ghh/hxQiAhxAXj3QAMh7AmhmIHaCVIhWJQQgJACgLAAQgdAAgpgMg");
	var mask_graphics_4 = new cjs.Graphics().p("ABqISQh0gciEhtQiEhsAPj5QAHh7AihmIHgCDIhBJSQgLADgPAAQgbAAgmgJg");
	var mask_graphics_5 = new cjs.Graphics().p("ACCIWQh2gWiIhnQiJhmAEj5QABh7AdhoIHmBtIgmJVQgOAEgTAAQgYAAgigHg");
	var mask_graphics_6 = new cjs.Graphics().p("AChIbQh4gQiNhfQiOhegLj4QgFh8AXhpIHqBRIgDJWQgSAGgbAAQgUAAgagDg");
	var mask_graphics_7 = new cjs.Graphics().p("AC0IeQh5gIiThUQiUhVgbj3QgOh7AQhrIHvAwIAlJVQgXAKgoAAIgcgBg");
	var mask_graphics_8 = new cjs.Graphics().p("AhIHYQibhJguj0QgXh7AIhqIHxAJIBSJRQgdAPg8AAIgFAAQh3AAiWhHg");
	var mask_graphics_9 = new cjs.Graphics().p("Ag0HuQigg7hDjwQgih4gChrIHwghICHJHQgcASg8AFQgVACgVAAQhqAAiEgxg");
	var mask_graphics_10 = new cjs.Graphics().p("AgbICQilgrhbjoQgth0gMhrIHqhRIC/I3QgaAUg7AMQgqAIgwAAQhXAAhqgcg");
	var mask_graphics_11 = new cjs.Graphics().p("AAAISQiogZhzjdQg5hugYhpIHfiGID6IfQgXAYg6ARQhEAWhWAAQg9AAhFgLg");
	var mask_graphics_12 = new cjs.Graphics().p("AAeIbQiqgFiMjNQhGhngkhmIHMi9IE5H+QgVAag3AYQhkAtiVAAIgggBg");
	var mask_graphics_13 = new cjs.Graphics().p("AkFFyQhThegwhgIGvj3IF4HSQgRAcg0AfQhnBAiqAQIgcACQiaAAiYiqg");
	var mask_graphics_14 = new cjs.Graphics().p("AjnGWQhehSg9hZIGMksIGxGdQgNAegwAmQhdBMinAmQgfAHghAAQiJAAiYiDg");
	var mask_graphics_15 = new cjs.Graphics().p("AjFGyQhnhGhGhRIFmlZIHeFnQgKAggqArQhVBWigA6QgvARgzAAQh6AAiShjg");
	var mask_graphics_16 = new cjs.Graphics().p("AigHIQhug7hPhJIE/l9IICExQgHAhglAvQhLBfiZBLQg8AdhGAAQhsAAiGhHg");
	var mask_graphics_17 = new cjs.Graphics().p("Ah7HYQh0gwhVhBIEYmbIIdD+QgDAhghAzQhBBmiRBZQhHAshaAAQhfAAh2gxg");
	var mask_graphics_18 = new cjs.Graphics().p("AhYHjQh3gmhbg5ID0myIIxDOQAAAhgcA1Qg4BsiJBlQhQA7hwAAQhTAAhjgfg");
	var mask_graphics_19 = new cjs.Graphics().p("Ag2HpQh6gchfgyIDRnDIJACiQACAhgYA3QgvBviBBwQhWBLiJAAQhEAAhPgTg");
	var mask_graphics_20 = new cjs.Graphics().p("AgYHtQh7gUhjgsICznQIJJB7QAFAhgVA4QgnBzh6B4QhbBaiiAAQg1AAg7gJg");
	var mask_graphics_21 = new cjs.Graphics().p("AABHuQh7gNhlgnICYnZIJQBaQAGAggRA6QghB0hzB/QhfBqi7AAQgmAAgpgEg");
	var mask_graphics_22 = new cjs.Graphics().p("AAXHtQh8gHhmgiICCngIJTA+QAHAhgOA6QgcB2hsCEQhiB3jUAAIgugBg");
	var mask_graphics_23 = new cjs.Graphics().p("AAoHsQh8gDhngeIBwnkIJVAoQAJAggMA7QgYB3hnCIQhkCDjrAAIgRAAg");
	var mask_graphics_24 = new cjs.Graphics().p("AiwHPIBknnIJWAZQAKAggLA7QgVB4hjCKQhkCLj5ABIgEAAQh5AAhngbg");
	var mask_graphics_25 = new cjs.Graphics().p("AipHSIBdnpIJWARQAKAfgKA7QgTB4hhCMQhiCMj4AFIgVAAQhwAAhggXg");
	var mask_graphics_26 = new cjs.Graphics().p("AimHSIBanpIJWAOQAKAfgJA7QgSB4hhCMQhhCNj5AGIgaABQhtAAhdgXg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:18.3133,y:53.5057}).wait(1).to({graphics:mask_graphics_1,x:18.3566,y:53.5364}).wait(1).to({graphics:mask_graphics_2,x:18.4862,y:53.6244}).wait(1).to({graphics:mask_graphics_3,x:18.6989,y:53.7586}).wait(1).to({graphics:mask_graphics_4,x:18.987,y:53.9208}).wait(1).to({graphics:mask_graphics_5,x:19.3335,y:54.0866}).wait(1).to({graphics:mask_graphics_6,x:19.7001,y:54.2281}).wait(1).to({graphics:mask_graphics_7,x:21.8664,y:54.3181}).wait(1).to({graphics:mask_graphics_8,x:24.4241,y:54.3441}).wait(1).to({graphics:mask_graphics_9,x:27.1807,y:54.315}).wait(1).to({graphics:mask_graphics_10,x:30.3072,y:54.2123}).wait(1).to({graphics:mask_graphics_11,x:33.9178,y:54.0659}).wait(1).to({graphics:mask_graphics_12,x:38.0105,y:53.9768}).wait(1).to({graphics:mask_graphics_13,x:41.4872,y:53.9832}).wait(1).to({graphics:mask_graphics_14,x:44.311,y:53.7439}).wait(1).to({graphics:mask_graphics_15,x:46.5878,y:53.2967}).wait(1).to({graphics:mask_graphics_16,x:48.3698,y:52.7144}).wait(1).to({graphics:mask_graphics_17,x:49.7201,y:52.0649}).wait(1).to({graphics:mask_graphics_18,x:50.7062,y:51.4069}).wait(1).to({graphics:mask_graphics_19,x:51.4061,y:50.7874}).wait(1).to({graphics:mask_graphics_20,x:51.8946,y:50.2397}).wait(1).to({graphics:mask_graphics_21,x:52.224,y:49.784}).wait(1).to({graphics:mask_graphics_22,x:52.4378,y:49.4276}).wait(1).to({graphics:mask_graphics_23,x:52.5708,y:49.1677}).wait(1).to({graphics:mask_graphics_24,x:52.6487,y:48.9945}).wait(1).to({graphics:mask_graphics_25,x:52.6888,y:48.8973}).wait(1).to({graphics:mask_graphics_26,x:52.7262,y:48.8665}).wait(4));

	// Layer_3
	this.instance = new lib.chartpie();
	this.instance.setTransform(44.9,44.9,1,1,0,0,0,44.9,44.9);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30));

	// Layer_4 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ag2GRQjbi1AOjhQAXlwD6h1QB9g6B5AQIABIEIheIpQhwgththbg");
	mask_1.setTransform(18.783,46.5866);

	// Layer_5
	this.instance_1 = new lib.chartpie2();
	this.instance_1.setTransform(44.9,44.9,1,1,0,0,0,44.9,44.9);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(30));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,90,90);


(lib.bars = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bar_2
	this.bar_2 = new lib.bar_2();
	this.bar_2.name = "bar_2";
	this.bar_2.setTransform(333.3,173.1,1,1,0,0,0,16,106.6);

	this.timeline.addTween(cjs.Tween.get(this.bar_2).wait(1));

	// bar_1
	this.bar_1 = new lib.bar_1();
	this.bar_1.name = "bar_1";
	this.bar_1.setTransform(300.55,173,1,1,0,0,0,16,106.5);

	this.timeline.addTween(cjs.Tween.get(this.bar_1).wait(1));

	// blank
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Al7JHIAAyNIL3AAIAASNg");
	this.shape.setTransform(318,118.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnpKcIAA03IPTAAIAAU3g");
	mask.setTransform(310.05,127.25);

	// Layer_3
	this.instance = new lib.ExcelUniversityBudgeting();
	this.instance.setTransform(0.25,0,0.9376,0.9376);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bars, new cjs.Rectangle(261.1,60.5,98,133.5), null);


(lib.countdown = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {shadow:0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// circle dark
	this.circle_anim = new lib.circle_anim();
	this.circle_anim.name = "circle_anim";
	this.circle_anim.setTransform(60.75,57.05,0.9971,1.0028,0,0,0,44.9,44.9);

	this.timeline.addTween(cjs.Tween.get(this.circle_anim).wait(1));

	// circle light
	this.instance = new lib.chartpie_light();
	this.instance.setTransform(61.1,57.05,1.0022,1.0028,0,0,0,45,44.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// white frame
	this.circBG = new lib.white_sq();
	this.circBG.name = "circBG";
	this.circBG.setTransform(61.4,56.5,1,1,0,0,0,51.1,51.5);

	this.timeline.addTween(cjs.Tween.get(this.circBG).wait(1));

	// shadow
	this.shadow = new lib.shadow();
	this.shadow.name = "shadow";
	this.shadow.setTransform(66.15,66,1,1,0,0,0,64.8,61.9);
	this.shadow.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.countdown, new cjs.Rectangle(0.6,4.1,130.5,123.80000000000001), null);


(lib.UI_screen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"shadow":0,"shadow":0,"shadow":0};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.setTransform(88.5,44.5,1,1,0,0,0,41.5,41.5);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// icon shadow1
	this.shadow1 = new lib.shadow();
	this.shadow1.name = "shadow1";
	this.shadow1.setTransform(83.2,52.75,0.8459,0.8459,0,0,0,64.8,61.9);

	this.timeline.addTween(cjs.Tween.get(this.shadow1).wait(1));

	// END screen
	this.end_UI = new lib.end_UI();
	this.end_UI.name = "end_UI";
	this.end_UI.setTransform(268.7,157.7,1.0005,0.9992,0,0,0,187.6,124.8);

	this.timeline.addTween(cjs.Tween.get(this.end_UI).wait(1));

	// countdown
	this.countdown = new lib.countdown();
	this.countdown.name = "countdown";
	this.countdown.setTransform(129.8,137.4,1,1,0,0,0,33.8,26.4);

	this.timeline.addTween(cjs.Tween.get(this.countdown).wait(1));

	// bars
	this.bars = new lib.bars();
	this.bars.name = "bars";
	this.bars.setTransform(427.15,147,1,1,0,0,0,345.9,114.2);

	this.timeline.addTween(cjs.Tween.get(this.bars).wait(1));

	// bars shadow3
	this.shadow3 = new lib.shadow();
	this.shadow3.name = "shadow3";
	this.shadow3.setTransform(393.3,170.1,0.9768,1.3835,0,0,0,65.3,62.1);
	this.shadow3.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.shadow3).wait(1));

	// screen
	this.instance = new lib.Excelscreen1();
	this.instance.setTransform(81,33,1.503,1.5029);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// screen shadow2
	this.shadow2 = new lib.shadow();
	this.shadow2.name = "shadow2";
	this.shadow2.setTransform(269.85,177.3,3.6774,2.3899,0,0,0,65,62);

	this.timeline.addTween(cjs.Tween.get(this.shadow2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI_screen, new cjs.Rectangle(28.4,0.4,479.6,324.5), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(710.8,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(668,46.05);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTAPopLines
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(681.65,45,1,1,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI_Screen
	this.screen = new lib.UI_screen();
	this.screen.name = "screen";
	this.screen.setTransform(359.95,65.35,0.41,0.4101,0,0,0,237.3,160.6);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(153.1,119.5,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// Phone
	this.phone = new lib.mobile();
	this.phone.name = "phone";
	this.phone.setTransform(156.5,62.75,0.63,0.63,0,0,0,15.5,44.8);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(440.35,29.15,0.6872,0.6872,0,0,0,3.6,39.8);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.collabAnim();
	this.anim.name = "anim";
	this.anim.setTransform(235.65,191.15,1,1,0,0,0,133.2,23.6);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(249.6,33.1,1,1,0,0,0,249.6,33.1);

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(221.35,81.9,1,1,0,0,0,93,104);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,-26.9,752.3,159.70000000000002), null);


// stage content:
(lib.M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		//mc.screen.countdown.shadow.visible = false;
		//mc.screen.bars.visible = false;
		mc.phone.visible = false;
		mc.screen.countdown.circBG.visible = false;
		mc.screen.bars.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//intro	
				this.tl1.from(exportRoot.intro1,{duration:0.8, x: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.anim.line1.play();}});
		
		
				//icon
				
				this.tl1.from(exportRoot,{duration:0.1, onComplete:function(){ mc.anim.spreadsheet.play();}}, "<+2.7");	
				this.tl1.from(mc.anim.square1,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, ">");
				this.tl1.from(mc.anim.square2,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+.2");	
				this.tl1.from(mc.anim.square3,{duration:.6, scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<+.2");	
				
				this.tl1.from(mc.anim.graph1,{duration:.6, scaleY: 0, alpha:0, ease:Back.easeOut}, "<+.3");	
				this.tl1.from(mc.anim.graph2,{duration:.6, scaleY: 0, alpha:0, ease:Back.easeOut}, "<+.3");	
				this.tl1.from(mc.anim.graph3,{duration:.6, scaleY: 0, alpha:0, ease:Back.easeOut}, "<+.3");	
				
				this.tl1.from([mc.anim.lineR1, mc.anim.lineR2, mc.anim.lineR3, mc.anim.lineL1, mc.anim.lineL2, mc.anim.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
		
				//transition to Excel screen
				this.tl1.to(exportRoot.intro1,{duration:0.6, x: "-=20", alpha: 0, stagger: 0.05, ease:Power4.easeIn}, "+=0.2");
				this.tl1.to(mc.anim,{duration:1.2, alpha: 0, ease:Power3.easeInOut}, "-=0.4");	
				this.tl1.from(mc.screen,{duration:1.5, scaleX:0.5, scaleY:0.5, alpha: 0, ease:Power3.easeInOut, onComplete:function(){mc.screen.countdown.circBG.visible = true;}}, "<+0.4");
				
				//countdown pop up
				this.tl1.to(mc.screen.countdown,{duration:1, scaleX:1.3, scaleY:1.3, y: "-=20", ease:Power3.easeInOut}, ">");	
				this.tl1.to(mc.screen.countdown.shadow,{duration:1, alpha: 1, ease:Power3.easeInOut}, "<");	
				this.tl1.from(exportRoot,{duration:0.1, onComplete:function(){ mc.screen.countdown.circle_anim.play();}}, "<.5");	
			
				//bar chart pop up
				this.tl1.to(mc.screen,{duration:1.5, scaleX:0.4, scaleY:0.4, x: "-=3", y: "+=13", ease:Power3.easeInOut}, ">0.9");
				this.tl1.from(mc.screen.icon,{duration:0.9, x: "-=100", y: "-=100", alpha: 0, ease:Power3.easeInOut}, "<");	
				this.tl1.from(mc.screen.shadow1,{duration:0.9, x: "-=100", y: "-=100", alpha: 0, ease:Power3.easeInOut}, "<");			
				this.tl1.to(mc.screen.countdown,{duration:1.5, scaleX:1, scaleY:1, y:"+=20", ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.screen.countdown.shadow,{duration:1, alpha: 0, ease:Power3.easeInOut}, "<");	
				
				this.tl1.to(mc.screen.bars,{duration:1, scaleX:2, scaleY:2, x: "-=32", y: "-=40", ease:Power3.easeInOut, onStart:function(){mc.bang.play(); mc.screen.bars.visible = true;}}, "<.7");
				this.tl1.to(mc.screen.shadow3,{duration:1, alpha: 1, ease:Power3.easeInOut}, "<");
				this.tl1.from(mc.screen.bars.bar_1, {duration:.6, scaleY: 0, ease: "back.out(0.5)"}, "<.5");
				this.tl1.from(mc.screen.bars.bar_2, {duration:.6, scaleY: 0, ease: "back.out(0.5)"}, "<.5");		
		
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut}, "<");		
				
				//final frame
				this.tl1.to(mc.screen,{duration:1.2, scaleX:.29, scaleY:.29, x: "-=136", y: "-=28", ease:Power3.easeInOut}, ">0.7");
				this.tl1.to(mc.bang, {duration:1.2, x:"-=139", y:"-=11", scaleX: .4, scaleY: .4, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");		
				this.tl1.to(mc.screen.bars,{duration:1.2, scaleX:1, scaleY:1, x: "+=32", y: "+=42", ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.screen.shadow3,{duration:1, alpha: 0, ease:Power3.easeInOut}, "<");		
				this.tl1.from(mc.screen.end_UI,{duration:.2, alpha:0, ease:Power3.easeOut}, "-=0.2");
		
		
				
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-.4");
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				//this.tl1.from(mc.finalFrameMC,{duration:.4, alpha:0, ease:Power3.easeOut}, "+=0");				
				//this.tl1.from([mc.cta.popRight.lineR1,mc.cta.popRight.lineR2,mc.cta.popRight.lineR3,mc.cta.popLeft.lineL1,mc.cta.popLeft.lineL2,mc.cta.popLeft.lineL3], {duration:.6, scaleX: 0, ease:Back.easeOut}, "<");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
		
		
				this.tl2 = gsap.timeline();	
				this.tl2.from(mc.phone,{duration:2, x:"-=120", y:"+=80",  ease:Power3.easeInOut, onStart:function(){mc.phone.visible=true;}});
				this.tl2.to(mc.phone,{duration:0, rotation:"-=10"}, "<");
				this.tl2.to(mc.phone,{duration:0, rotation:"+=15"}, ">+.5");
				this.tl2.to(mc.phone,{duration:0, rotation:"-=10"}, ">+.5");
				this.tl2.to(mc.phone,{duration:0, rotation:0}, ">+.5");
				
				
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(364,18.1,388.29999999999995,114.70000000000002);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622834482239", id:"M365_FY22Q1BTS_USA_728x90_BAN_Excel_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;