(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[0,0,300,400],[302,0,300,400],[604,0,300,400],[906,0,300,400],[0,402,300,400],[302,402,300,400],[604,402,300,400],[906,402,300,400],[0,804,300,400],[302,804,300,400],[1208,0,284,272],[1208,274,284,272],[1208,548,284,272],[927,822,284,272],[1213,822,284,272],[604,1048,284,272],[0,1206,284,272],[286,1206,284,272],[890,1096,284,272],[572,1322,284,272],[1176,1096,284,272],[0,1480,284,272],[286,1480,284,272],[858,1370,284,272],[572,1596,284,272],[1144,1370,284,272],[0,1754,284,272],[286,1754,284,272],[858,1644,284,272],[572,1870,284,272],[1144,1644,284,272],[0,2028,284,272],[286,2028,284,272],[858,1918,284,272],[572,2144,284,272],[1144,1918,284,272],[0,2302,284,272],[286,2302,284,272],[0,2576,284,272],[286,2576,284,272],[572,2418,284,272],[572,2692,284,272],[858,2192,284,272],[1144,2192,284,272],[858,2466,284,272],[1144,2466,284,272],[604,804,321,242]]},
		{name:"M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2", frames: [[713,1236,100,100],[815,1236,100,100],[917,1236,100,100],[1204,1322,100,100],[1306,1322,100,100],[0,1325,100,100],[1019,1335,100,100],[102,1338,100,100],[204,1338,100,100],[713,1338,100,100],[815,1338,100,100],[917,1338,100,100],[529,1345,100,100],[306,1383,100,100],[408,1383,100,100],[529,1236,100,107],[0,0,284,272],[286,0,284,272],[572,0,284,272],[858,0,284,272],[1144,0,284,272],[0,274,284,272],[286,274,284,272],[572,274,284,272],[858,274,284,272],[1144,274,284,272],[0,548,284,272],[286,548,284,272],[1323,806,170,170],[203,822,170,170],[375,822,170,170],[1323,978,170,170],[0,981,170,170],[1088,991,170,170],[172,994,170,170],[344,994,170,170],[516,1064,170,170],[688,1064,170,170],[860,1064,170,170],[1260,1150,170,170],[0,1153,170,170],[1032,1163,170,170],[172,1166,170,170],[1088,806,233,183],[572,548,256,256],[344,1236,183,145],[830,548,256,256],[0,822,201,157],[1088,548,256,256],[1346,655,120,120],[572,806,256,256],[631,1236,80,132],[1346,548,141,105],[830,806,256,256]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.applev2_001 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.applev2_002 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.applev2_003 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.applev2_004 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.applev2_005 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.applev2_006 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.applev2_007 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.applev2_008 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.applev2_009 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.applev2_010 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.applev2_011 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.applev2_012 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.applev2_013 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.applev2_014 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.applev2_015 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.apple2 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0070 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0071 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0072 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0073 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0074 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0075 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0076 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0077 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.bagpackcameramovs_1_0078 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0000 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0001pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0002pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0003pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0004pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0005pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0006pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0007pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0008pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0009pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0010pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0011pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0012pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0013pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0014pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0015pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0016pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0017pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0018pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0019pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0020pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0021pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0022pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0023pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0024pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0025pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0026pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0027pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0028pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0029pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0030pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0031pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0032pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0033pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0034pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0035pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0036pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0037pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0038pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0039pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0040pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0041pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0042pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0043pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0044pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0045pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0046pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0047pngcopy = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.bagpackopening_1_0048 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.book_01 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.book_02 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.book_03 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.book_04 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.book_05 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.book_06 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.book_07 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.book_08 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.book_09 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.book_10 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.book_11 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.book_12 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.book_13 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.book_14 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.book_15 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.Excel300x2502x = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.Excel_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.onedrive300x2502x = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.outlook300x2502x = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.pencil_0001 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.PowerPoint_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.ppt300x2502x = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.pptmobile300x2502x = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.word300x2502x = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.Word_256x256 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.wordicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Word_256x256();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.wordicon, new cjs.Rectangle(0,0,128,128), null);


(lib.word = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.word300x2502x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.word, new cjs.Rectangle(0,0,70.5,52.5), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.Score = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.score_num.textBaseline = "alphabetic";
		this.time_num.textBaseline = "alphabetic";
		//this.score_num.y+=26;
		this.time_num.y+=22;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.time_num = new cjs.Text(":10", "20px 'Segoe Pro'", "#0E7FE0");
	this.time_num.name = "time_num";
	this.time_num.textAlign = "right";
	this.time_num.lineHeight = 29;
	this.time_num.parent = this;
	this.time_num.setTransform(181.3009,-83.25);

	this.timeline.addTween(cjs.Tween.get(this.time_num).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Score, new cjs.Rectangle(-1,-85.2,184.3,147.9), null);


(lib.rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("ArVOpIAA9RIWrAAIAAdRg");
	this.shape.setTransform(0.025,-297.2666,1,1.3344);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.6,-422.2,145.3,250);


(lib.pptScreen = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#131313").s().p("Ah2DnIgPgHQgRgLghgaQg1gqgqgoIgegeQgHgGAEgHQADgGAJACIC9ApIg6hUQgog4gVgpIgNgZQgDgHAFgFQAFgFAHAEQAxAYA0AjIBZA7IADACIgViMIgIg8IgBgQQgBgGACgDQACgCAFgDIAEAAQAEACADAFIBEBhQAlAzAPAcIABABIABgCIAOgdQAWgsAvhWQAEgHAHABQAHACABAHQAGAgACASIAFA3IACAfIAAAwIAagWQAlgeApgaQAFgEAFACQAFACACAGIAAADIgbCIQgCAIgIABQgIAAgCgHQgBgDABgCIAWhwIgCABQgyAiggAdIgQAOQgFAGgHgDQgHgDABgIIABgeIABgkIgEg/IgGgsIAAgCIgBACQgvBXgVAtIgJAUQgDAHgGAAQgHAAgDgHQgQghgagkIhBhbIARBuIAKBMIABAKQABAHgGAEQgFADgGgEIg+goQhEgvgvgaIgEgCIACAEQASAgAYAkIBVB8QAEAGgDAGQgFAFgHgBIi0goIANAMQA8A4A/AtIAOAKQAFADAEAAQAEABACADQACAEgBAEQgCAJgHAAIgDAAg");
	this.shape.setTransform(162.05,9.95,0.3794,0.3797,0,57.1458,56.9286,0,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.ppt300x2502x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptScreen, new cjs.Rectangle(0,0,172.3,121), null);


(lib.pptMob = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pptmobile300x2502x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptMob, new cjs.Rectangle(0,0,40,66), null);


(lib.ppticon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PowerPoint_256x256();
	this.instance.setTransform(-13.95,-13.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ppticon, new cjs.Rectangle(-13.9,-13.9,128,128), null);


(lib.pencil2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pencil_0001();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.outlookicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Outlook_256x256();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlookicon, new cjs.Rectangle(0,0,128,128), null);


(lib.outlook = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.outlook300x2502x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlook, new cjs.Rectangle(0,0,100.5,78.5), null);


(lib.onedriveicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.OneDrive_256x256();
	this.instance.setTransform(-14,-14,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.onedriveicon, new cjs.Rectangle(-14,-14,128,128), null);


(lib.oneDrive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.onedrive300x2502x();
	this.instance.setTransform(45.75,36.25,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.oneDrive, new cjs.Rectangle(45.8,36.3,91.50000000000001,72.5), null);


(lib.cta_arrowcopyblu = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0E7FE0").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrowcopyblu, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_Grey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(54.875,54.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(17.1,54.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(54.875,17.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(17.1,17.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(215.625,34.775);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727272").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(432.275,36.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#727272").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(400.7,35.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#727272").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(368.475,35.975);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(54.875,54.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(17.1,54.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_10.setTransform(54.875,17.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_11.setTransform(17.1,17.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_12.setTransform(215.625,34.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_13.setTransform(432.275,36.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_14.setTransform(400.7,35.975);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_15.setTransform(368.475,35.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_Grey, new cjs.Rectangle(0,0,445.5,72), null);


(lib.excelicon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel_256x256();
	this.instance.setTransform(-14,-14,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excelicon, new cjs.Rectangle(-14,-14,128,128), null);


(lib.excel = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel300x2502x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel, new cjs.Rectangle(0,0,116.5,91.5), null);


(lib.centerbagframe = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0074();
	this.instance.setTransform(-87,-116,0.58,0.58);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87,-116,174,232);


(lib.BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");
	this.shape.setTransform(150,124.9988,0.9375,0.5208);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG, new cjs.Rectangle(0,0,300,250), null);


(lib.banana = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// book
	this.instance = new lib.book_01();
	this.instance.setTransform(0,0,0.5,0.5);

	this.instance_1 = new lib.book_02();
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.book_03();
	this.instance_2.setTransform(0,0,0.5,0.5);

	this.instance_3 = new lib.book_04();
	this.instance_3.setTransform(0,0,0.5,0.5);

	this.instance_4 = new lib.book_05();
	this.instance_4.setTransform(0,0,0.5,0.5);

	this.instance_5 = new lib.book_06();
	this.instance_5.setTransform(0,0,0.5,0.5);

	this.instance_6 = new lib.book_07();
	this.instance_6.setTransform(0,0,0.5,0.5);

	this.instance_7 = new lib.book_08();
	this.instance_7.setTransform(0,0,0.5,0.5);

	this.instance_8 = new lib.book_09();
	this.instance_8.setTransform(0,0,0.5,0.5);

	this.instance_9 = new lib.book_10();
	this.instance_9.setTransform(0,0,0.5,0.5);

	this.instance_10 = new lib.book_11();
	this.instance_10.setTransform(0,0,0.5,0.5);

	this.instance_11 = new lib.book_12();
	this.instance_11.setTransform(0,0,0.5,0.5);

	this.instance_12 = new lib.book_13();
	this.instance_12.setTransform(0,0,0.5,0.5);

	this.instance_13 = new lib.book_14();
	this.instance_13.setTransform(0,0,0.5,0.5);

	this.instance_14 = new lib.book_15();
	this.instance_14.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},21).to({state:[{t:this.instance_2}]},22).to({state:[{t:this.instance_3}]},22).to({state:[{t:this.instance_4}]},22).to({state:[{t:this.instance_5}]},20).to({state:[{t:this.instance_6}]},22).to({state:[{t:this.instance_7}]},22).to({state:[{t:this.instance_8}]},22).to({state:[{t:this.instance_9}]},22).to({state:[{t:this.instance_10}]},22).to({state:[{t:this.instance_11}]},22).to({state:[{t:this.instance_12}]},22).to({state:[{t:this.instance_13}]},20).to({state:[{t:this.instance_14}]},20).wait(20));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,85,85);


(lib.bagrxxx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0078();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.bagrxx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0077();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.bagrx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0076();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.bagr = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0075();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.baglxxx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0070();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.baglxx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0071();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.baglx = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0072();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.bagl = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.bagpackcameramovs_1_0073();
	this.instance.setTransform(0,0,0.5833,0.5833);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175,233.4);


(lib.arrowcopyblue = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0E7FE0").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowcopyblue, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.apple1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.applev2_001();
	this.instance.setTransform(0,0,0.7,0.7);

	this.instance_1 = new lib.applev2_002();
	this.instance_1.setTransform(0,0,0.7,0.7);

	this.instance_2 = new lib.applev2_003();
	this.instance_2.setTransform(0,0,0.7,0.7);

	this.instance_3 = new lib.applev2_004();
	this.instance_3.setTransform(0,0,0.7,0.7);

	this.instance_4 = new lib.applev2_005();
	this.instance_4.setTransform(0,0,0.7,0.7);

	this.instance_5 = new lib.applev2_006();
	this.instance_5.setTransform(0,0,0.7,0.7);

	this.instance_6 = new lib.applev2_007();
	this.instance_6.setTransform(0,0,0.7,0.7);

	this.instance_7 = new lib.applev2_008();
	this.instance_7.setTransform(0,0,0.7,0.7);

	this.instance_8 = new lib.applev2_009();
	this.instance_8.setTransform(0,0,0.7,0.7);

	this.instance_9 = new lib.applev2_010();
	this.instance_9.setTransform(0,0,0.7,0.7);

	this.instance_10 = new lib.applev2_011();
	this.instance_10.setTransform(0,0,0.7,0.7);

	this.instance_11 = new lib.applev2_012();
	this.instance_11.setTransform(0,0,0.7,0.7);

	this.instance_12 = new lib.applev2_013();
	this.instance_12.setTransform(0,0,0.7,0.7);

	this.instance_13 = new lib.applev2_014();
	this.instance_13.setTransform(0,0,0.7,0.7);

	this.instance_14 = new lib.applev2_015();
	this.instance_14.setTransform(0,0,0.7,0.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},19).to({state:[{t:this.instance_2}]},21).to({state:[{t:this.instance_3}]},19).to({state:[{t:this.instance_4}]},21).to({state:[{t:this.instance_5}]},19).to({state:[{t:this.instance_6}]},21).to({state:[{t:this.instance_7}]},19).to({state:[{t:this.instance_8}]},21).to({state:[{t:this.instance_9}]},20).to({state:[{t:this.instance_10}]},21).to({state:[{t:this.instance_10}]},20).to({state:[{t:this.instance_11}]},21).to({state:[{t:this.instance_12}]},20).to({state:[{t:this.instance_13}]},20).to({state:[{t:this.instance_14}]},20).wait(20));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,70,70);


(lib.apple2_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.apple2();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.apple2_1, new cjs.Rectangle(0,0,50,53.5), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.play = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// button
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0E7FE0").s().p("AnJDHIAAmNIOTAAIAAGNg");
	this.shape.setTransform(-1.425,16.725);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BG
	this.instance = new lib.BG();
	this.instance.setTransform(2.2,178.45,0.361,0.5176,0,0,0,159.7,240.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-55.4,-3.2,108.3,186.7);


(lib.msLogoGrey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Microsoft365_logo_Grey.ai
	this.logoGrey = new lib.logo_Grey();
	this.logoGrey.name = "logoGrey";
	this.logoGrey.setTransform(222.8,36,1,1,0,0,0,222.8,36);

	this.timeline.addTween(cjs.Tween.get(this.logoGrey).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoGrey, new cjs.Rectangle(0,0,445.5,72), null);


(lib.cta_arrowmocopyblue = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrowcopyblue();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrowcopyblue();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.icongroup3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.i_pencil = new lib.pencil2("synched",0);
	this.i_pencil.name = "i_pencil";
	this.i_pencil.setTransform(114.8,-32.6,1,1,0,0,0,19,33.5);

	this.i_banana = new lib.banana();
	this.i_banana.name = "i_banana";
	this.i_banana.setTransform(248.75,-65.6,1,1,0,0,0,25,34.5);

	this.i_ppt = new lib.ppticon();
	this.i_ppt.name = "i_ppt";
	this.i_ppt.setTransform(51.15,-35.15,1,1,0,0,0,50,50);

	this.i_apple1 = new lib.apple1();
	this.i_apple1.name = "i_apple1";
	this.i_apple1.setTransform(198,-35.15,0.8,0.8,0,0,0,25,34.5);

	this.i_onedrive = new lib.onedriveicon();
	this.i_onedrive.name = "i_onedrive";
	this.i_onedrive.setTransform(153.6,-27.35,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.i_onedrive},{t:this.i_apple1},{t:this.i_ppt},{t:this.i_banana},{t:this.i_pencil}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12.8,-100.1,321.6,136.8);


(lib.icongroup2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.i_word = new lib.wordicon();
	this.i_word.name = "i_word";
	this.i_word.setTransform(40.75,-35.35,1,1,0,0,0,64,64);

	this.i_apple2 = new lib.apple2_1();
	this.i_apple2.name = "i_apple2";
	this.i_apple2.setTransform(195.25,-34.1,1,1,0,0,0,25,26.9);

	this.i_excel = new lib.excelicon();
	this.i_excel.name = "i_excel";
	this.i_excel.setTransform(269.2,-36.25,1,1,0,0,0,50,50);

	this.i_onedrive = new lib.onedriveicon();
	this.i_onedrive.name = "i_onedrive";
	this.i_onedrive.setTransform(123.2,-27.8,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.i_onedrive},{t:this.i_excel},{t:this.i_apple2},{t:this.i_word}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icongroup2, new cjs.Rectangle(-23.2,-100.2,356.4,136.4), null);


(lib.icongroup1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// pencil2
	this.i_pencil = new lib.pencil2("synched",0);
	this.i_pencil.name = "i_pencil";
	this.i_pencil.setTransform(103.1,-35.5,1,1,0,0,0,19,33.5);

	this.timeline.addTween(cjs.Tween.get(this.i_pencil).wait(1));

	// i_banana
	this.i_banana = new lib.banana();
	this.i_banana.name = "i_banana";
	this.i_banana.setTransform(154.75,-64.7,1,1,0,0,0,25,34.5);

	this.timeline.addTween(cjs.Tween.get(this.i_banana).wait(1));

	// i_word
	this.i_word = new lib.wordicon();
	this.i_word.name = "i_word";
	this.i_word.setTransform(280.2,-34.25,1,1,0,0,0,64,64);

	this.timeline.addTween(cjs.Tween.get(this.i_word).wait(1));

	// i_outlook
	this.i_outlook = new lib.outlookicon();
	this.i_outlook.name = "i_outlook";
	this.i_outlook.setTransform(57,-33.8,1,1,0,0,0,64,64);

	this.timeline.addTween(cjs.Tween.get(this.i_outlook).wait(1));

	// i_ppt
	this.i_ppt = new lib.ppticon();
	this.i_ppt.name = "i_ppt";
	this.i_ppt.setTransform(280.2,-34.25,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.i_ppt).wait(1));

	// i_apple2
	this.i_apple2 = new lib.apple2_1();
	this.i_apple2.name = "i_apple2";
	this.i_apple2.setTransform(224.8,-35.9,1,1,0,0,0,25,26.9);

	this.timeline.addTween(cjs.Tween.get(this.i_apple2).wait(1));

	// i_apple1
	this.i_apple1 = new lib.apple1();
	this.i_apple1.name = "i_apple1";
	this.i_apple1.setTransform(167.45,-36.45,0.8,0.8,0,0,0,25.1,34.5);

	this.timeline.addTween(cjs.Tween.get(this.i_apple1).wait(1));

	// i_excel
	this.i_excel = new lib.excelicon();
	this.i_excel.name = "i_excel";
	this.i_excel.setTransform(40.65,-33.6,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.i_excel).wait(1));

	// i_onedrive
	this.i_onedrive = new lib.onedriveicon();
	this.i_onedrive.name = "i_onedrive";
	this.i_onedrive.setTransform(128,-27.3,1,1,0,0,0,50,50);

	this.timeline.addTween(cjs.Tween.get(this.i_onedrive).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icongroup1, new cjs.Rectangle(-23.3,-99.2,367.6,135.9), null);


(lib.bagrevolvemasked = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {lxxx:1,lxx:2,lx:3,l:4,c:5,r:6,rx:7,rxx:8,rxxx:9};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("ArjLFIEFzfQARhbABgbIAAhBQgBglABgWQAAgXAPgwQAPgxgEgTQgDgTAEgJQAEgJAHAAQAHAAAhAWQAqAbAGAEQAbAOAnAPQA0AVAnAHQAvAIAqACQAvACAxgGQBGgICuggQAogHA8gEQBKgFAWAFQAaAHAeAVQAfAWAMAUQASAcAqDAICFYWg");
	var mask_graphics_2 = new cjs.Graphics().p("AheMxQk0hGkghGIBQr8QBRsBABgUQABgRAhgUQAfgTgBgHQgCgNAEgCQAEgBANAJQAhAYA9AeQBeAsBKAGQBfAHAcgBQApAABTgMQAogGCAgYQBagRAjAAQB0AAAjA5QASAeAfB7QAcBxADAiQA0GHAeFwQA7LdhnABIgCAAQhsAApiiKg");
	var mask_graphics_3 = new cjs.Graphics().p("ApdBqQCOsSACgfQADgfAYhBIAYg7QgCgFAAgGQAAgKAMABQAJABBrA4QB/A5ByAEQArAHBPgNIB2gYQA0gKBMgOQBTgPAcgDQApgEAXAFQAlAJAUAgQATAgAeB8QAWBaAJA3QAEAVA1KiIA1KeI3VAUICNsOg");
	var mask_graphics_4 = new cjs.Graphics().p("AtmMLICisRQCisXAAgWQAAgXAqgSQAWgKAlgLQAOgGA/AXQAhAMAvAUQAiAMA6APQBSATA3ADQA9ACB4gRQB0gSBFgUQBXgaAagDQAygGAaAaQAeAdAPAjQAQAiAMA+IEuYhg");
	var mask_graphics_5 = new cjs.Graphics().p("Ar8tEICagaQCdgaASAAQATAABDAVIBYAcQAmAMBfATQByAYAhgCQApgDBvgUQBxgVAhgMQAfgLA7gKQA0gIATAAIAsgHQArgEAjAGQBuAVAMCBQAQCjARKaQASKkgOAFQgUAG26Bjg");
	var mask_graphics_6 = new cjs.Graphics().p("Ar7AJQA8uAACgHQADgNBqADQA2ABA9ADQATAABDAVIBYAcQAmAMBfATQByAYAigCQAogDBvgUQBxgVAhgOQAigOAzgQQA0gQAOAJQAFAEBXAHQBWAMAIAUQAPAjBrNGQBsNTgWAHQgTAH5YARIA8uAg");
	var mask_graphics_7 = new cjs.Graphics().p("AqatuQCggLAUgFQAfgJCjArQCiAqA/AFQA/AFA1gEQBlgGBXgfQBvgpAfgJQArgNAOAGQAIAEDTNWIDSNVI7BBog");
	var mask_graphics_8 = new cjs.Graphics().p("AoDopIAXiJQAWiLAGgMQAPghALgNQAcgeAuAHQAoAGB1AZQB/AaAYAEQCsAeBOgTQA8gPA6gSQBEgWAlgTQAjgTAYgDQAPgCASAEQANACABAOQAAAEgEAnQgDAaAIBCQAHA1AEAXQAFASAUB4IDmULI4rDUg");
	var mask_graphics_9 = new cjs.Graphics().p("Aoos3IA9ghQA/ghAKgCQAcgHA2ADQA5ACAwAMIBzAbQBIAQAvAEQBSAGAaAAQA6ABAvgJQAwgJAygSQAjgMAzgXIBHgeQAegLAIAFQAIAGgBAbIgEAuQgBAVABAkQABAnADAQQFXJIgyKjI5HGlQhRrFFHwbg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:61.75,y:160.225}).wait(1).to({graphics:mask_graphics_2,x:65.1744,y:160.2156}).wait(1).to({graphics:mask_graphics_3,x:59.625,y:154.0957}).wait(1).to({graphics:mask_graphics_4,x:63.025,y:155.7379}).wait(1).to({graphics:mask_graphics_5,x:63.5861,y:156.675}).wait(1).to({graphics:mask_graphics_6,x:69.0035,y:157.8542}).wait(1).to({graphics:mask_graphics_7,x:71.35,y:157.9803}).wait(1).to({graphics:mask_graphics_8,x:63.9,y:160.2917}).wait(1).to({graphics:mask_graphics_9,x:64.4431,y:159.6833}).wait(1));

	// Layer_5
	this.instance = new lib.baglxxx("synched",0);
	this.instance.setTransform(72.8,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_1 = new lib.baglxx("synched",0);
	this.instance_1.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_2 = new lib.baglx("synched",0);
	this.instance_2.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_3 = new lib.bagl("synched",0);
	this.instance_3.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_4 = new lib.centerbagframe("synched",0);
	this.instance_4.setTransform(72.65,126.3,1.0058,1.0056);

	this.instance_5 = new lib.bagr("synched",0);
	this.instance_5.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_6 = new lib.bagrx("synched",0);
	this.instance_6.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_7 = new lib.bagrxx("synched",0);
	this.instance_7.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_8 = new lib.bagrxxx("synched",0);
	this.instance_8.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	var maskedShapeInstanceList = [this.instance,this.instance_1,this.instance_2,this.instance_3,this.instance_4,this.instance_5,this.instance_6,this.instance_7,this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15,0,172.9,243);


(lib.bagrevolve = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {"lxxx":1,"lxx":2,"lx":3,"l":4,"c":5,"r":6,"rx":7,"rxx":8,"rxxx":9};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(10));

	// Layer_5
	this.instance = new lib.baglxxx("synched",0);
	this.instance.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_1 = new lib.baglxx("synched",0);
	this.instance_1.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_2 = new lib.baglx("synched",0);
	this.instance_2.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_3 = new lib.bagl("synched",0);
	this.instance_3.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_4 = new lib.centerbagframe("synched",0);
	this.instance_4.setTransform(72.65,126.3,1.0058,1.0056);

	this.instance_5 = new lib.bagr("synched",0);
	this.instance_5.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_6 = new lib.bagrx("synched",0);
	this.instance_6.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_7 = new lib.bagrxx("synched",0);
	this.instance_7.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.instance_8 = new lib.bagrxxx("synched",0);
	this.instance_8.setTransform(72.45,126.2,1,1,0,0,0,87.5,116.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15,0,175.2,243);


(lib.arrowMainblu = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrowcopyblu();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmocopyblue();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.anim_Bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_53 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(53).call(this.frame_53).wait(1));

	// OneDrive
	this.oneDrive = new lib.oneDrive();
	this.oneDrive.name = "oneDrive";
	this.oneDrive.setTransform(250.3,112.05,1,1,0,0,0,63.9,49.7);

	this.timeline.addTween(cjs.Tween.get(this.oneDrive).wait(54));

	// Excel
	this.excel = new lib.excel();
	this.excel.name = "excel";
	this.excel.setTransform(308.25,246.35,1,1,0,0,0,89.3,68.8);

	this.timeline.addTween(cjs.Tween.get(this.excel).wait(54));

	// Outlook
	this.outlook = new lib.outlook();
	this.outlook.name = "outlook";
	this.outlook.setTransform(56.8,225.25,1,1,0,0,0,65.8,50.1);

	this.timeline.addTween(cjs.Tween.get(this.outlook).wait(54));

	// Word
	this.word = new lib.word();
	this.word.name = "word";
	this.word.setTransform(25.45,131.45,1,1,0,0,0,51.9,37.1);

	this.timeline.addTween(cjs.Tween.get(this.word).wait(54));

	// PptMob
	this.pptMob = new lib.pptMob();
	this.pptMob.name = "pptMob";
	this.pptMob.setTransform(75.9,161.7,1,1,0,0,0,26.4,45.4);

	this.timeline.addTween(cjs.Tween.get(this.pptMob).wait(54));

	// PptScreen
	this.pptScreen = new lib.pptScreen();
	this.pptScreen.name = "pptScreen";
	this.pptScreen.setTransform(184.85,160.1,1,1,0,0,0,114.2,85);

	this.timeline.addTween(cjs.Tween.get(this.pptScreen).wait(54));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_34 = new cjs.Graphics().p("AkkPvQhtgvgthvQgthuAuhvQAwhuBvgtMAh+gNuQBvgtBtAvQBwAvAsBvQAtBvgwBuQguBuhuAsMgh/ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_35 = new cjs.Graphics().p("AkoPwQhtgugthvQgthvAuhvQAwhuBvgsMAh+gNuQBvgtBuAuQBvAvAtBvQAtBvgwBuQguBuhvAtMgh+ANvQg2AWg3AAQg4AAg6gZg");
	var mask_graphics_36 = new cjs.Graphics().p("Ak1P2QhtgvgthvQgthvAuhuQAwhuBvgtMAh+gNuQBvgtBtAvQBwAvAsBvQAtBvgwBuQguBthuAtMgh/ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_37 = new cjs.Graphics().p("AlRQBQhugugthvQgthvAuhvQAwhuBvgsMAh+gNuQBvgtBuAuQBvAwAtBuQAtBvgwBuQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gZg");
	var mask_graphics_38 = new cjs.Graphics().p("AmDQWQhugvgthvQgshvAthuQAwhuBvgtMAh+gNuQBvgtBuAvQBvAvAtBvQAtBvgwBtQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_39 = new cjs.Graphics().p("AnHQxQhtgugthvQgthvAuhvQAwhuBvgtMAh+gNuQBvgsBtAuQBwAvAsBvQAtBvgwBtQguBvhuAtMgh/ANvQg2AVg2AAQg5AAg5gYg");
	var mask_graphics_40 = new cjs.Graphics().p("AoIRMQhugvgshvQgthvAuhuQAvhuBvgtMAh/gNuQBvgtBtAvQBvAvAtBvQAtBvgwBtQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_41 = new cjs.Graphics().p("Ao8RhQhtgvgthvQgthvAuhuQAwhuBvgtMAh+gNuQBvgtBtAvQBvAvAtBvQAtBvgwBtQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_42 = new cjs.Graphics().p("ApkRxQhtgvgthuQgthvAuhvQAwhuBvgtMAh+gNuQBvgtBuAvQBvAvAtBvQAsBvgvBtQguBvhvAsMgh+ANvQg2AWg3AAQg5AAg5gYg");
	var mask_graphics_43 = new cjs.Graphics().p("AqCR9QhugugshvQgthvAuhvQAvhuBvgtMAh/gNtQBvgtBtAuQBvAvAtBvQAtBugwBuQguBvhvAtMgh+ANvQg2AWg2AAQg5AAg5gZg");
	var mask_graphics_44 = new cjs.Graphics().p("AqaSHQhtgvgthuQgthvAuhvQAwhuBvgtMAh+gNuQBvgtBtAvQBwAvAsBvQAtBugwBuQguBvhuAsMgh/ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_45 = new cjs.Graphics().p("AqtSPQhtgvgthvQgthvAuhuQAwhuBvgtMAh+gNuQBvgtBuAvQBvAvAtBvQAsBugvBuQguBuhvAtMgh+ANvQg2AWg3AAQg5AAg5gYg");
	var mask_graphics_46 = new cjs.Graphics().p("Aq7SVQhugvgthvQgshvAuhuQAvhuBvgtMAh/gNuQBugtBuAvQBvAvAtBvQAtBugwBuQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_47 = new cjs.Graphics().p("ArHSZQhtgugthvQgthvAuhvQAwhuBvgtMAh+gNtQBvgtBtAuQBwAvAsBvQAtBugvBuQguBvhvAtMgh/ANvQg2AVg2AAQg5AAg5gYg");
	var mask_graphics_48 = new cjs.Graphics().p("ArQSdQhtgvgthvQgthuAuhvQAwhuBvgtMAh+gNuQBvgtBuAvQBvAvAtBvQAsBugvBuQguBvhvAsMgh/ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_49 = new cjs.Graphics().p("ArWSgQhugvgthvQgshvAuhuQAvhuBvgtMAh+gNuQBvgtBuAvQBvAvAtBvQAtBugwBuQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_50 = new cjs.Graphics().p("ArbSiQhugvgthvQgshvAuhuQAvhuBvgtMAh/gNuQBvgtBtAuQBvAwAtBvQAtBugwBuQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_51 = new cjs.Graphics().p("AreSjQhugvgthvQgthuAuhvQAwhuBvgtMAh+gNuQBvgtBuAvQBvAvAtBvQAtBugwBuQguBvhvAsMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_52 = new cjs.Graphics().p("ArgSkQhugvgthvQgshvAuhuQAvhuBvgtMAh/gNuQBugtBuAvQBvAvAtBvQAtBugwBuQguBuhvAtMgh+ANvQg2AWg2AAQg5AAg5gYg");
	var mask_graphics_53 = new cjs.Graphics().p("AriSjQhtgvgthvQgthuAuhvQAwhuBvgtMAh+gNuQBvgtBtAvQBwAvAsBvQAtBugwBuQguBvhuAsMgh/ANvQg2AWg2AAQg5AAg5gYg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(34).to({graphics:mask_graphics_34,x:228.6053,y:103.1064}).wait(1).to({graphics:mask_graphics_35,x:228.2407,y:103.2549}).wait(1).to({graphics:mask_graphics_36,x:226.9031,y:103.799}).wait(1).to({graphics:mask_graphics_37,x:224.0545,y:104.9577}).wait(1).to({graphics:mask_graphics_38,x:219.0579,y:106.9902}).wait(1).to({graphics:mask_graphics_39,x:212.3015,y:109.7385}).wait(1).to({graphics:mask_graphics_40,x:205.7845,y:112.3895}).wait(1).to({graphics:mask_graphics_41,x:200.5978,y:114.4992}).wait(1).to({graphics:mask_graphics_42,x:196.6342,y:116.1115}).wait(1).to({graphics:mask_graphics_43,x:193.5834,y:117.3525}).wait(1).to({graphics:mask_graphics_44,x:191.2058,y:118.3196}).wait(1).to({graphics:mask_graphics_45,x:189.338,y:119.0795}).wait(1).to({graphics:mask_graphics_46,x:187.8679,y:119.6774}).wait(1).to({graphics:mask_graphics_47,x:186.717,y:120.1456}).wait(1).to({graphics:mask_graphics_48,x:185.8282,y:120.5071}).wait(1).to({graphics:mask_graphics_49,x:185.1587,y:120.7795}).wait(1).to({graphics:mask_graphics_50,x:184.6758,y:120.9759}).wait(1).to({graphics:mask_graphics_51,x:184.354,y:121.1068}).wait(1).to({graphics:mask_graphics_52,x:184.1728,y:121.1805}).wait(1).to({graphics:mask_graphics_53,x:184.0053,y:121.1064}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(163.85,196.5,0.9736,0.9736,0,0,0,42.2,17.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(34).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_25 = new cjs.Graphics().p("AQbNfMgjQgJzQhzggg7hpQg7hmAgh0QAghzBog7QBpg6BzAgMAjQAJyQBzAgA6BoQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogMg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AQbNkMgjQgJ0Qhzggg7hpQg7hnAghyQAghzBog8QBpg6BzAgMAjQAJyQBzAgA6BoQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogLg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AQbNwMgjQgJ0Qhzggg7hpQg7hnAghyQAghzBog8QBpg6BzAgMAjQAJyQBzAgA6BoQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogLg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AQbODMgjQgJ0Qhzggg7hpQg7hnAghyQAghzBog8QBpg6BzAgMAjQAJyQBzAgA6BoQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogLg");
	var mask_1_graphics_29 = new cjs.Graphics().p("AQbObMgjQgJ0Qhzggg7hpQg7hnAghyQAgh0Bog7QBpg6BzAgMAjQAJyQBzAgA6BoQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogLg");
	var mask_1_graphics_30 = new cjs.Graphics().p("AQbO1MgjQgJ0Qhzggg7hpQg7hnAghyQAghzBog8QBpg6BzAgMAjQAJzQBzAgA6BnQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogLg");
	var mask_1_graphics_31 = new cjs.Graphics().p("AQbPPMgjQgJzQhzggg7hpQg7hoAghyQAghzBog7QBpg6BzAgMAjQAJyQBzAgA6BnQA8BqggBzQggBzhpA6QhEAnhIAAQgnAAgogMg");
	var mask_1_graphics_32 = new cjs.Graphics().p("AQbPnMgjQgJzQhzggg7hpQg7hoAghzQAghyBog8QBpg6BzAgMAjQAJzQBzAgA6BnQA8BpggBzQggBzhpA7QhEAmhIAAQgnAAgogLg");
	var mask_1_graphics_33 = new cjs.Graphics().p("AQbP6MgjQgJzQhzggg7hpQg7hoAghzQAghyBog8QBpg6BzAgMAjQAJzQBzAgA6BnQA8BpggBzQggBzhpA6QhEAnhIAAQgnAAgogLg");
	var mask_1_graphics_34 = new cjs.Graphics().p("AQbQGMgjQgJzQhzggg7hpQg7hoAghzQAghyBog7QBpg7BzAgMAjQAJzQBzAgA6BnQA8BpggBzQggB0hpA6QhEAmhIAAQgnAAgogLg");
	var mask_1_graphics_35 = new cjs.Graphics().p("AQbQLMgjQgJzQhzggg7hpQg7hoAghzQAghyBog8QBpg6BzAgMAjQAJzQBzAgA6BnQA8BpggBzQggBzhpA7QhEAmhIAAQgnAAgogLg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(25).to({graphics:mask_1_graphics_25,x:-30.1411,y:87.4626}).wait(1).to({graphics:mask_1_graphics_26,x:-27.1103,y:87.8816}).wait(1).to({graphics:mask_1_graphics_27,x:-18.3146,y:89.0961}).wait(1).to({graphics:mask_1_graphics_28,x:-4.6148,y:90.9878}).wait(1).to({graphics:mask_1_graphics_29,x:12.6478,y:93.3714}).wait(1).to({graphics:mask_1_graphics_30,x:31.7837,y:96.0137}).wait(1).to({graphics:mask_1_graphics_31,x:50.9195,y:98.656}).wait(1).to({graphics:mask_1_graphics_32,x:68.1821,y:101.0397}).wait(1).to({graphics:mask_1_graphics_33,x:81.8819,y:102.9313}).wait(1).to({graphics:mask_1_graphics_34,x:90.6776,y:104.1459}).wait(1).to({graphics:mask_1_graphics_35,x:93.2589,y:104.6376}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(149.05,164.2,0.9736,0.9736,0,0,0,57.5,16.4);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_19 = new cjs.Graphics().p("AlOKlQhng7gfh0QgfhzA7hoQA9hoBzgfMAjYgJdQBzgfBnA7QBpA9AfBzQAfBzg9BoQg7BnhzAfMgjYAJfQgnAKgmAAQhKAAhFgog");
	var mask_2_graphics_20 = new cjs.Graphics().p("AluKuQhng8gfhzQgfhzA7hpQA9hnBzgfMAjYgJeQBzgfBnA8QBpA8AfB0QAfBzg9BnQg7Boh0AfMgjXAJeQgnALgmAAQhKAAhFgog");
	var mask_2_graphics_21 = new cjs.Graphics().p("AnILGQhng7gfh0QgfhzA7hpQA9hnBzgfMAjYgJeQB0gfBnA8QBoA8AfB0QAfBzg9BnQg7BohzAfMgjYAJeQgnALgmAAQhKAAhFgog");
	var mask_2_graphics_22 = new cjs.Graphics().p("ApKLpQhng8gfhzQgfhzA8hpQA8hnB0gfMAjXgJeQB0gfBnA8QBoA8AfB0QAfBzg8BmQg8BphzAfMgjYAJeQgnALgmAAQhKAAhFgog");
	var mask_2_graphics_23 = new cjs.Graphics().p("AraMQQhng8gfhzQgfh0A8hoQA8hnB0gfMAjXgJeQB0gfBnA8QBoA8AfBzQAfB0g8BmQg8BohzAfMgjYAJfQgnALgmAAQhKAAhFgog");
	var mask_2_graphics_24 = new cjs.Graphics().p("AtbMyQhng7gfhzQgfh0A7hoQA9hnBzgfMAjYgJeQBzgfBnA7QBpA9AfBzQAfBzg9BnQg7Boh0AfMgjXAJfQgoAKglAAQhKAAhFgog");
	var mask_2_graphics_25 = new cjs.Graphics().p("Au1NLQhng8gfhzQgfh0A7hoQA9hnBzgfMAjYgJeQBzgfBnA8QBpA8AfBzQAfBzg9BnQg7BohzAfMgjYAJfQgnALgmAAQhKAAhFgog");
	var mask_2_graphics_26 = new cjs.Graphics().p("AvVNTQhng7gfh0QgfhzA7hoQA9hoBzgfMAjYgJdQBzgfBnA7QBpA9AfBzQAfByg9BoQg7BohzAfMgjYAJfQgnAKgmAAQhKAAhFgog");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_2_graphics_19,x:236.4275,y:71.7161}).wait(1).to({graphics:mask_2_graphics_20,x:233.2243,y:72.5779}).wait(1).to({graphics:mask_2_graphics_21,x:224.2479,y:74.992}).wait(1).to({graphics:mask_2_graphics_22,x:211.2765,y:78.4804}).wait(1).to({graphics:mask_2_graphics_23,x:196.8794,y:82.3523}).wait(1).to({graphics:mask_2_graphics_24,x:183.9081,y:85.8407}).wait(1).to({graphics:mask_2_graphics_25,x:174.9316,y:88.2548}).wait(1).to({graphics:mask_2_graphics_26,x:171.7275,y:89.1161}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(152.05,132.4,0.9736,0.9736,0,0,0,60.6,16.8);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(19).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_12 = new cjs.Graphics().p("AQ8JEMgjygH0Qh1gahBhkQhAhkAZh1QAah1BkhBQBmhAB0AZMAjyAHzQB1AaBABkQBBBlgZB1QgaB1hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_13 = new cjs.Graphics().p("AQ8JIMgjygH0Qh1gZhBhlQhAhkAZh1QAah1BkhBQBmhAB0AZMAjyAH0QB1AZBABkQBBBmgZB1QgaB0hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AQ8JUMgjygH0Qh1gZhBhlQhAhkAZh1QAah0BkhCQBmhAB0AaMAjyAHzQB1AZBABkQBBBmgZB1QgaB1hlA/QhIAwhRAAQggAAgggIg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AQ8JnMgjygH0Qh1gZhBhlQhAhkAZh1QAah1BkhBQBmhAB0AaMAjyAHzQB1AZBABkQBBBmgZB1QgaB0hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_16 = new cjs.Graphics().p("AQ8J+MgjygH0Qh1gZhBhmQhAhjAZh1QAah1BkhBQBmhAB0AaMAjyAHzQB1AZBABkQBBBmgZB1QgaB0hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_17 = new cjs.Graphics().p("AQ8KXMgjygH0Qh1gahBhlQhAhjAZh1QAah1BkhBQBmhAB0AZMAjyAHzQB1AaBABkQBBBlgZB1QgaB1hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_18 = new cjs.Graphics().p("AQ8KuMgjygH0Qh1gahBhlQhAhjAZh1QAah1BkhBQBmhAB0AZMAjyAHzQB1AaBABkQBBBlgZB1QgaB1hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_19 = new cjs.Graphics().p("AQ8LBMgjygH0Qh1gahBhmQhAhjAZh0QAah1BkhCQBmhAB0AaMAjyAHzQB1AaBABkQBBBlgZB1QgaB1hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_20 = new cjs.Graphics().p("AQ8LNMgjygH0Qh1gahBhlQhAhjAZh1QAah1BkhBQBmhAB0AZMAjyAHzQB1AaBABkQBBBmgZB0QgaB1hlBAQhIAvhRAAQggAAgggHg");
	var mask_3_graphics_21 = new cjs.Graphics().p("AQ8LRMgjygH0Qh1gZhBhmQhAhjAZh1QAah1BkhBQBmhAB0AZMAjyAH0QB1AZBABkQBBBmgZB1QgaB0hlBAQhIAvhRAAQggAAgggHg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_3_graphics_12,x:-26.3385,y:58.7087}).wait(1).to({graphics:mask_3_graphics_13,x:-22.5476,y:59.1344}).wait(1).to({graphics:mask_3_graphics_14,x:-11.6321,y:60.3613}).wait(1).to({graphics:mask_3_graphics_15,x:5.0914,y:62.2411}).wait(1).to({graphics:mask_3_graphics_16,x:25.6058,y:64.5469}).wait(1).to({graphics:mask_3_graphics_17,x:47.4368,y:67.0007}).wait(1).to({graphics:mask_3_graphics_18,x:67.9512,y:69.3065}).wait(1).to({graphics:mask_3_graphics_19,x:84.6747,y:71.1862}).wait(1).to({graphics:mask_3_graphics_20,x:95.5902,y:72.4131}).wait(1).to({graphics:mask_3_graphics_21,x:98.7115,y:72.8337}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(152.75,103.5,0.9736,0.9736,0,0,0,59.8,13.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(12).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("AhOHUQhihCgYh1QgXh1BChkQBDhiB0gXMAj6gHKQB1gXBjBCQBkBDAYB1QAXB1hDBjQhCBjh1AXMgj6AHKQgeAGgeAAQhSAAhLgyg");
	var mask_4_graphics_1 = new cjs.Graphics().p("AhTHUQhihCgYh1QgXh1BChkQBDhiB0gXMAj6gHKQB1gXBjBCQBkBDAYB1QAXB1hDBjQhCBjh1AXMgj6AHKQgeAGgeAAQhSAAhLgyg");
	var mask_4_graphics_2 = new cjs.Graphics().p("AhjHUQhjhCgYh1QgXh1BChkQBDhiB0gXMAj6gHKQB2gXBiBCQBlBDAXB1QAXB1hDBjQhCBjh1AXMgj6AHKQgeAGgdAAQhTAAhKgyg");
	var mask_4_graphics_3 = new cjs.Graphics().p("AiEHUQhjhCgXh1QgXh1BChkQBDhiB1gXMAj5gHKQB1gXBjBCQBkBDAYB1QAXB1hDBjQhCBjh1AXMgj6AHKQgeAGgeAAQhSAAhLgyg");
	var mask_4_graphics_4 = new cjs.Graphics().p("Ai5HUQhjhBgXh2QgXh1BBhkQBEhiB1gXMAj5gHKQB1gXBjBCQBkBDAYB1QAXB1hDBjQhCBjh1AXMgj6AHKQgfAGgcAAQhTAAhLgyg");
	var mask_4_graphics_5 = new cjs.Graphics().p("AkKHVQhjhCgXh2QgYh1BChkQBDhiB1gXMAj6gHKQB1gXBjBBQBkBEAYB1QAXB1hDBjQhCBjh1AXMgj6AHKQgeAGgdAAQhUAAhKgxg");
	var mask_4_graphics_6 = new cjs.Graphics().p("Al+HVQhjhCgXh2QgXh1BBhkQBEhiB1gXMAj5gHKQB2gYBiBCQBlBDAXB2QAYB1hEBjQhBBjh2AXMgj5AHKQgeAGgeAAQhTAAhLgxg");
	var mask_4_graphics_7 = new cjs.Graphics().p("AoOHVQhjhCgYh2QgXh1BChkQBDhiB1gXMAj6gHKQB1gYBjBCQBkBDAYB2QAXB1hDBjQhCBjh1AXMgj6AHKQgeAGgdAAQhUAAhKgxg");
	var mask_4_graphics_8 = new cjs.Graphics().p("AqiHaQhjhCgXh1QgYh1BChkQBDhiB2gYMAj5gHKQB2gXBjBCQBkBDAXB1QAYB1hEBkQhBBjh2AXMgj6AHKQgeAGgdAAQhUAAhKgyg");
	var mask_4_graphics_9 = new cjs.Graphics().p("AsfH1QhjhCgXh1QgXh1BChkQBDhkB1gWMAj6gHKQB1gXBjBCQBlBDAXB1QAXB1hDBjQhCBjh1AYMgj6AHKQgeAGgdAAQhUAAhLgyg");
	var mask_4_graphics_10 = new cjs.Graphics().p("At9IKQhjhCgYh2QgXh1BChkQBDhjB1gXMAj7gHKQB1gXBjBCQBkBDAXB1QAYB1hDBjQhCBkh1AXMgj7AHKQgeAGgdAAQhUAAhKgxg");
	var mask_4_graphics_11 = new cjs.Graphics().p("AvDIYQhjhCgXh1QgXh1BChkQBDhjB1gYMAj6gHJQB2gXBjBCQBkBDAXB1QAYB1hEBjQhBBjh2AYMgj6AHKQgeAGgdAAQhUAAhLgyg");
	var mask_4_graphics_12 = new cjs.Graphics().p("Av0IjQhjhCgYh1QgXh1BChlQBDhjB1gXMAj7gHJQB1gYBjBCQBkBDAYB2QAXB1hDBiQhCBkh1AXMgj7AHLQgeAGgdAAQhUAAhKgyg");
	var mask_4_graphics_13 = new cjs.Graphics().p("AwXIrQhjhCgXh2QgYh1BChkQBEhjB1gYMAj6gHJQB1gXBjBCQBlBDAXB1QAYB1hEBiQhCBlh1AXMgj6AHKQgfAGgdAAQhTAAhLgxg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:266.9707,y:27.3841}).wait(1).to({graphics:mask_4_graphics_1,x:266.4767,y:27.5968}).wait(1).to({graphics:mask_4_graphics_2,x:264.8039,y:28.316}).wait(1).to({graphics:mask_4_graphics_3,x:261.5792,y:29.7025}).wait(1).to({graphics:mask_4_graphics_4,x:256.2665,y:31.9868}).wait(1).to({graphics:mask_4_graphics_5,x:248.1549,y:35.4744}).wait(1).to({graphics:mask_4_graphics_6,x:236.6203,y:40.4338}).wait(1).to({graphics:mask_4_graphics_7,x:222.1783,y:46.6432}).wait(1).to({graphics:mask_4_graphics_8,x:207.432,y:52.4145}).wait(1).to({graphics:mask_4_graphics_9,x:195.0037,y:55.0895}).wait(1).to({graphics:mask_4_graphics_10,x:185.5489,y:57.1245}).wait(1).to({graphics:mask_4_graphics_11,x:178.6321,y:58.6133}).wait(1).to({graphics:mask_4_graphics_12,x:173.6754,y:59.6801}).wait(1).to({graphics:mask_4_graphics_13,x:170.2167,y:60.4239}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(156.2,77.95,0.9736,0.9736,0,0,0,63.3,13.3);

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-26.4,35.8,361.9,233.3);


(lib.togetherMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {revolve:49};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_48 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(48).call(this.frame_48).wait(1).call(this.frame_49).wait(1));

	// bag revolve
	this.bagRevolve = new lib.bagrevolve();
	this.bagRevolve.name = "bagRevolve";
	this.bagRevolve.setTransform(87.35,116.95,1,1,0,0,0,87.5,116.7);

	this.timeline.addTween(cjs.Tween.get(this.bagRevolve).wait(50));

	// opening animation
	this.instance = new lib.bagpackopening_1_0001pngcopy();
	this.instance.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_1 = new lib.bagpackopening_1_0002pngcopy();
	this.instance_1.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_2 = new lib.bagpackopening_1_0003pngcopy();
	this.instance_2.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_3 = new lib.bagpackopening_1_0004pngcopy();
	this.instance_3.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_4 = new lib.bagpackopening_1_0005pngcopy();
	this.instance_4.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_5 = new lib.bagpackopening_1_0006pngcopy();
	this.instance_5.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_6 = new lib.bagpackopening_1_0007pngcopy();
	this.instance_6.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_7 = new lib.bagpackopening_1_0008pngcopy();
	this.instance_7.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_8 = new lib.bagpackopening_1_0009pngcopy();
	this.instance_8.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_9 = new lib.bagpackopening_1_0010pngcopy();
	this.instance_9.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_10 = new lib.bagpackopening_1_0011pngcopy();
	this.instance_10.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_11 = new lib.bagpackopening_1_0012pngcopy();
	this.instance_11.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_12 = new lib.bagpackopening_1_0013pngcopy();
	this.instance_12.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_13 = new lib.bagpackopening_1_0014pngcopy();
	this.instance_13.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_14 = new lib.bagpackopening_1_0015pngcopy();
	this.instance_14.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_15 = new lib.bagpackopening_1_0016pngcopy();
	this.instance_15.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_16 = new lib.bagpackopening_1_0017pngcopy();
	this.instance_16.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_17 = new lib.bagpackopening_1_0018pngcopy();
	this.instance_17.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_18 = new lib.bagpackopening_1_0019pngcopy();
	this.instance_18.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_19 = new lib.bagpackopening_1_0020pngcopy();
	this.instance_19.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_20 = new lib.bagpackopening_1_0021pngcopy();
	this.instance_20.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_21 = new lib.bagpackopening_1_0022pngcopy();
	this.instance_21.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_22 = new lib.bagpackopening_1_0023pngcopy();
	this.instance_22.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_23 = new lib.bagpackopening_1_0024pngcopy();
	this.instance_23.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_24 = new lib.bagpackopening_1_0025pngcopy();
	this.instance_24.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_25 = new lib.bagpackopening_1_0026pngcopy();
	this.instance_25.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_26 = new lib.bagpackopening_1_0027pngcopy();
	this.instance_26.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_27 = new lib.bagpackopening_1_0028pngcopy();
	this.instance_27.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_28 = new lib.bagpackopening_1_0029pngcopy();
	this.instance_28.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_29 = new lib.bagpackopening_1_0030pngcopy();
	this.instance_29.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_30 = new lib.bagpackopening_1_0031pngcopy();
	this.instance_30.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_31 = new lib.bagpackopening_1_0032pngcopy();
	this.instance_31.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_32 = new lib.bagpackopening_1_0033pngcopy();
	this.instance_32.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_33 = new lib.bagpackopening_1_0034pngcopy();
	this.instance_33.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_34 = new lib.bagpackopening_1_0035pngcopy();
	this.instance_34.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_35 = new lib.bagpackopening_1_0036pngcopy();
	this.instance_35.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_36 = new lib.bagpackopening_1_0037pngcopy();
	this.instance_36.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_37 = new lib.bagpackopening_1_0038pngcopy();
	this.instance_37.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_38 = new lib.bagpackopening_1_0039pngcopy();
	this.instance_38.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_39 = new lib.bagpackopening_1_0040pngcopy();
	this.instance_39.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_40 = new lib.bagpackopening_1_0041pngcopy();
	this.instance_40.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_41 = new lib.bagpackopening_1_0042pngcopy();
	this.instance_41.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_42 = new lib.bagpackopening_1_0043pngcopy();
	this.instance_42.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_43 = new lib.bagpackopening_1_0044pngcopy();
	this.instance_43.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_44 = new lib.bagpackopening_1_0045pngcopy();
	this.instance_44.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_45 = new lib.bagpackopening_1_0046pngcopy();
	this.instance_45.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_46 = new lib.bagpackopening_1_0047pngcopy();
	this.instance_46.setTransform(-4.3,14.9,0.5829,0.5829);

	this.instance_47 = new lib.bagpackopening_1_0048();
	this.instance_47.setTransform(-4.3,14.9,0.5829,0.5829);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).to({state:[{t:this.instance_29}]},1).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[]},1).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_1 = new cjs.Graphics().p("AsVHCQDGlSBYliIA5nDIDIAyIIsgzIDzgSIA8CZICxEVIgMJaIk6FHIqeBCg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(1).to({graphics:mask_graphics_1,x:61.575,y:173.475}).wait(49));

	// bag animation
	this.instance_48 = new lib.bagpackopening_1_0000();
	this.instance_48.setTransform(-14.9,9.7,0.5834,0.5833);

	var maskedShapeInstanceList = [this.instance_48];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_48).to({_off:true},49).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,0,176.20000000000002,243.1);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(76.75,1.3,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0E7FE0").s().p("A4/DcIAAm4MAx/AAAIAAG4g");
	this.shape.setTransform(-45,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-205,-21,320,44.1), null);


(lib.icons = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon6
	this.icons6 = new lib.icongroup1();
	this.icons6.name = "icons6";
	this.icons6.setTransform(174.5,173.7,1,1,0,0,0,174.5,173.7);

	this.timeline.addTween(cjs.Tween.get(this.icons6).wait(1));

	// icon5
	this.icons5 = new lib.icongroup3();
	this.icons5.name = "icons5";
	this.icons5.setTransform(154,184.2,1,1,0,0,0,154,184.2);

	this.timeline.addTween(cjs.Tween.get(this.icons5).wait(1));

	// icon4
	this.icons4 = new lib.icongroup2();
	this.icons4.name = "icons4";
	this.icons4.setTransform(168.1,201.6,1,1,0,0,0,168.1,201.6);

	this.timeline.addTween(cjs.Tween.get(this.icons4).wait(1));

	// icon3
	this.icons3 = new lib.icongroup3();
	this.icons3.name = "icons3";
	this.icons3.setTransform(154,184.2,1,1,0,0,0,154,184.2);

	this.timeline.addTween(cjs.Tween.get(this.icons3).wait(1));

	// icon2
	this.icons2 = new lib.icongroup2();
	this.icons2.name = "icons2";
	this.icons2.setTransform(168.1,201.6,1,1,0,0,0,168.1,201.6);

	this.timeline.addTween(cjs.Tween.get(this.icons2).wait(1));

	// icon1
	this.icons1 = new lib.icongroup1();
	this.icons1.name = "icons1";
	this.icons1.setTransform(174.5,173.7,1,1,0,0,0,174.5,173.7);

	this.timeline.addTween(cjs.Tween.get(this.icons1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icons, new cjs.Rectangle(-23.3,-100.2,367.6,136.9), null);


(lib.cta1st = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMainblu();
	this.arrow.name = "arrow";
	this.arrow.setTransform(288.2,-225.45,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,-331.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta1st, new cjs.Rectangle(0,-456.6,300,250.00000000000003), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// bg copy
	this.bg_fade = new lib.BG();
	this.bg_fade.name = "bg_fade";
	this.bg_fade.setTransform(160,240,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.bg_fade).wait(1));

	// logoGrey
	this.logoGrey = new lib.msLogoGrey();
	this.logoGrey.name = "logoGrey";
	this.logoGrey.setTransform(16,16.15,0.223,0.223);

	this.timeline.addTween(cjs.Tween.get(this.logoGrey).wait(1));

	// CTA final
	this.txtPlayAgain = new lib.cta();
	this.txtPlayAgain.name = "txtPlayAgain";
	this.txtPlayAgain.setTransform(17.6,229.75,1,1,0,0,0,0.7,0.1);

	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(271.9,229.45,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txtCta},{t:this.txtPlayAgain}]}).wait(1));

	// CTA_BG final
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(205.05,229);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// bag revolve 2nd layer
	this.bagRevolveMasked = new lib.bagrevolvemasked();
	this.bagRevolveMasked.name = "bagRevolveMasked";
	this.bagRevolveMasked.setTransform(166.35,222.85,0.8343,0.8343,0,0,0,87.8,116.7);

	this.timeline.addTween(cjs.Tween.get(this.bagRevolveMasked).wait(1));

	// icons
	this.icons = new lib.icons();
	this.icons.name = "icons";
	this.icons.setTransform(175.2,217.8,1,1,0,0,0,175.2,217.8);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	// track object
	this.trackObject = new lib.rectangle("synched",0);
	this.trackObject.name = "trackObject";
	this.trackObject.setTransform(162.6,422.6);
	this.trackObject.alpha = 0.0117;

	this.timeline.addTween(cjs.Tween.get(this.trackObject).wait(1));

	// time
	this.score_MC = new lib.Score();
	this.score_MC.name = "score_MC";
	this.score_MC.setTransform(110.6,88.9);

	this.timeline.addTween(cjs.Tween.get(this.score_MC).wait(1));

	// gameMain
	this.gameMain = new lib.togetherMC();
	this.gameMain.name = "gameMain";
	this.gameMain.setTransform(150.05,224.7,0.8343,0.8342,0,0,0,67.8,119.2);

	this.timeline.addTween(cjs.Tween.get(this.gameMain).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// play now txt
	this.playTxt = new lib.cta();
	this.playTxt.name = "playTxt";
	this.playTxt.setTransform(149.7,103.65,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.playTxt).wait(1));

	// play btn
	this.playBtn = new lib.play("synched",0);
	this.playBtn.name = "playBtn";
	this.playBtn.setTransform(151.5,86.4);

	this.timeline.addTween(cjs.Tween.get(this.playBtn).wait(1));

	// CTA 1st
	this.txtLearn = new lib.cta();
	this.txtLearn.name = "txtLearn";
	this.txtLearn.setTransform(279.95,229.45,1,1,0,0,0,0.7,0.1);

	this.cta1 = new lib.cta1st();
	this.cta1.name = "cta1";
	this.cta1.setTransform(0,456.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cta1},{t:this.txtLearn}]}).wait(1));

	// frameAnim
	this.finalFrame = new lib.anim_Bg();
	this.finalFrame.name = "finalFrame";
	this.finalFrame.setTransform(160,240,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.finalFrame).wait(1));

	// bg
	this.instance = new lib.BG();
	this.instance.setTransform(160,240,1,1,0,0,0,160,240);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-857.3,-100.2,1396.3,428.2), null);


// stage content:
(lib.M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		playFrame0();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(123.6,24.8,415.4,303.2);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1623230706447", id:"M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"},
		{src:"images/M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2.png?1623230706448", id:"M365_MobileFY22Q1BTS_USA_300x250_BAN_INTGame_EN_NA_Standard_ANI_LEA_NA_1_atlas_2"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;