(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1", frames: [[836,357,143,145],[0,0,750,500],[752,0,232,355],[0,502,439,851],[639,941,220,165],[639,1108,218,73],[441,772,500,167],[441,941,196,203],[441,502,393,268]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.ExcelLogo = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_CU = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.ExcelUI_FinalFrame = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Group103 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Layer2 = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.NewMeeting_lg_sh = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.NewSkypeMeeting_lg_sh = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.tileShadow = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.UIshadow = function() {
	this.initialize(ss["M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.UIShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.UIshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UIShadow, new cjs.Rectangle(0,0,393,268), null);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMdBAtMAAAiBYMCY7AAAMAAACBYg");
	this.shape.setTransform(0.0296,0.0053);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-489.3,-414,978.7,828.1);


(lib.scribble5SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AoZG9QhygyguhyQgvhzAxhzQAxhxBzgvINHlRQBzgvByAyQBzAxAuBzQAuBygwBzQgyBxhyAvItHFRQg4AXg4AAQg7AAg7gZg");
	this.shape.setTransform(72.0625,46.9809);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5SubSub, new cjs.Rectangle(0,0,144.2,94), null);


(lib.scribble4SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AHqHDIx4lFQh3gjg8hrQg9htAih3QAih3Btg8QBsg9B3AiIR4FFQB3AiA9BsQA9BsgiB3QgjB3hsA9QhGAnhJAAQgqAAgrgMg");
	this.shape.setTransform(87.3135,46.3032);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4SubSub, new cjs.Rectangle(0,0,174.6,92.6), null);


(lib.scribble3SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("ArvGpQhsg9ghh3Qghh4A+hsQA9hrB4giIS3lKQB3ggBsA+QBsA9AhB4QAhB3g+BsQg9Brh4AiIy3FJQgpAMgoAAQhLAAhHgpg");
	this.shape.setTransform(60.375,16.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3SubSub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2SubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AIVGnIypkFQh5gbhDhoQhEhoAbh5QAbh5BohDQBphDB5AaISpEFQB5AbBDBpQBDBogaB5QgbB4hpBEQhLAwhTAAQghAAgigIg");
	this.shape.setTransform(89.7148,43.102);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2SubSub, new cjs.Rectangle(0,0,179.5,86.2), null);


(lib.scribble1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEF000").s().p("AsbF/QhohEgZh5Qgah5BEhnQBEhpB6gaITvkIQB4gZBoBEQBpBEAaB5QAZB5hEBoQhEBoh6AaIzvEIQghAHgfAAQhVAAhMgyg");
	this.shape.setTransform(63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1_sub, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.pointerc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhKBlQgkgXgRihQgBgJAFgGQAGgGAIgBQAIgBAGAFQAHAFABAIQAFA3ALAtQAKAuAJAJQAMADAtgSQAtgSAxgaQAHgEAIADQAIACAEAHQAEAHgCAIQgDAJgHADQh2BAgzAAQgOAAgJgGg");
	this.shape.setTransform(12.8311,10.6417);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointerc, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.OutlookLogo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.ExcelLogo();
	this.instance.setTransform(-8.6,-19.65,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OutlookLogo, new cjs.Rectangle(-8.6,-19.6,114.39999999999999,116), null);


(lib.msLogoWhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(21.2204,21.2204,0.3867,0.3867);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(6.6126,21.2204,0.3867,0.3867);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(21.2204,6.6126,0.3867,0.3867);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(6.6126,6.6126,0.3867,0.3867);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAhgfAxAAQAOAAAJACQAKAAAJAEIAAA/IgNgGQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgWIAABbIBKAAIAAA8IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAJgDAGgEIAAA8QgIAEgPADQgPAEgRAAQguAAgXgZgAIrDBQgqgqAAhJQAAhMArgtQAsgtBNAAQBJAAAoArQApArAABJQAABLgrAtQgsAthKAAQhIAAgrgrgAJjAAQgWAaAAAxQAAAxAWAZQAWAaApAAQAoAAAVgaQAUgaAAgxQAAgzgVgYQgWgZgnAAQgoAAgWAagAE7DnQgXgFgRgHIAAhIQASANAZAJQAYAJARAAQAZAAAMgHQAMgIAAgQQAAgPgNgKQgKgJgkgPQgogRgRgVQgRgVAAghQAAgoAhgbQAigbA1AAQARAAATADQAVAEANAGIAABFQgPgKgTgHQgUgHgSAAQgUAAgMAIQgMAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAWAAAfQAAArgiAbQgiAbg5AAQgUAAgWgFgAgiDBQgrgpAAhKQAAhNAsgsQAqgtBNAAQBIAAAqArQAoAsAABIQAABMgrAsQgrAthLAAQhIAAgpgrgAAUAAQgVAbAAAwQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAoDDAQgrgqAAhEQAAhKAsgwQAsgwBQAAQAVAAAUAFQAWAFALAHIAABGQgRgNgRgGQgRgHgTAAQgrAAgbAbQgaAcAAAwQAAAvAZAaQAaAaArAAQARAAATgHQASgHASgNIAABDQgQAKgXAGQgYAFgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgYAUgPQAVgPAcAAQAJAAAHACQAHABAEACIAABJQgGgEgKgEQgLgDgQAAQgaAAgTAVQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQAOgNARAAQATAAANANQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(83.406,13.4513,0.3868,0.3868);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AhXDUQgegJgOgIIAAhDQAXARAYAHQAYAJAXgBQArABAagWQAagVAAglQAAgkgbgUQgbgUgxAAIhHAEIAPjkIDWAAIAAA+IiaAAIgHBqIATgCIATAAQBDAAAmAjQAlAjAAA8QAABBgrAnQgqAnhLAAQgfAAgcgIg");
	this.shape_5.setTransform(167.1623,14.0567,0.3867,0.3867);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhrCrQgpg1AAheQAAh5A2g/QA3g+BQAAQAaAAATADQAWADAMAGIAABBQgRgJgUgFQgTgFgTAAQg1AAggAqQggAogBBKIACAAQAMgXAagNQAZgMAfAAQAzAAAlAiQAmAhgBBBQABBFgqAnQgrAng9AAQhFAAgpg0gAgyAVQgUAWAAAhQAAAlAVAaQAVAZAgAAQAfAAAVgWQATgWAAgmQAAgogTgVQgTgVgiAAQgfAAgWAVg");
	this.shape_6.setTransform(154.9521,13.9117,0.3867,0.3867);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhXDZQgcgHgQgKIAAhGQAVAQAaAJQAcAJAbAAQAoAAAXgTQAXgTAAggQAAgigbgTQgcgSgyAAIgmAAIAAg6IAjAAQAvAAAWgRQAZgRAAghQAAgdgTgQQgTgRgiAAQgYAAgUAIQgWAIgUAPIAAhCQAVgLAagGQAagGAfAAQA3AAAlAdQAkAeAAAuQAAAqgWAbQgXAcgoAKIAAACQAuAFAbAaQAbAcAAApQAAA8grAjQgrAkhJAAQggAAgcgGg");
	this.shape_7.setTransform(142.4906,13.9117,0.3867,0.3867);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.msLogoWhite, new cjs.Rectangle(0,0,199.5,27.9), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mobile = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Group103();
	this.instance.setTransform(-68.2,33.95,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mobile, new cjs.Rectangle(-69.9,32.3,221.20000000000002,427.2), null);


(lib.gridpiece = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DDDDDD").ss(1,0,1).p("Ay8AAMAl5AAA");
	this.shape.setTransform(121.25,90);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#CCCCCC").ss(1,0,1).p("Ay8hKMAl5AAAAy8DhMAl5AAAAy8oMMAl5AAAAy8l2MAl5AAAAy8INMAl5AAAAy8BLMAl5AAAAy8jgMAl5AAA");
	this.shape_1.setTransform(121.25,52.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.gridpiece, new cjs.Rectangle(-1,-1,244.5,107), null);


(lib.fileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.tileShadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fileShadow, new cjs.Rectangle(0,0,196,203), null);


(lib.file4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.NewSkypeMeeting_lg_sh();
	this.instance.setTransform(12.9,36.7,0.94,0.94);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file4, new cjs.Rectangle(12.9,36.7,470,157), null);


(lib.file2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.Layer2();
	this.instance.setTransform(0,0,0.925,0.925);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file2, new cjs.Rectangle(0,0,203.5,152.6), null);


(lib.file1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.NewMeeting_lg_sh();
	this.instance.setTransform(19.55,61.8,0.9139,0.9139);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file1, new cjs.Rectangle(0,61.2,218.8,74.3), null);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.bang_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABTDbQgDgBgCgEQgCgEABgEQACgDAEgCIBRgmIgrgQIABAAIg1gTQgEgBgCgDQgCgEABgEQABgDADgDQBPgzAggaIg9AHIhHAJQgDAAgEgCQgDgCgBgDQgBgDACgEIA4iHIhxBjQgDACgEAAQgDAAgDgCQgDgDAAgEIgDieIhICbQgCAEgEABQgDACgEgCQgEgBgBgEIgzh/QgFAfgEAzQgDApAAAiQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEQAAgjADgpQAGhVANghQABgCACgCQADgCADAAQADAAADACQACACABACQANAkAoBjIBQitQABgDADgCQAEgCADABQADABADADQACACAAAEIADCzICBhxQADgCADAAQAEAAADACQADACABADQABAEgCADIhCCeIA2gHQBLgJAQAAQAEAAACACQADADABAEQAAAEgCADQgPAVhnBEIAhAMIAAAAQA5AVAIAFQAEADAAADQACAEgCADQgBADgEACIhlAvIgEABIgEgBg");
	this.shape.setTransform(20.5024,21.0027);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_sub, new cjs.Rectangle(-1,-1,43,44), null);


(lib.backCTA = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AovDXIAAmtIRfAAIAAGtg");
	this.shape.setTransform(50,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.backCTA, new cjs.Rectangle(-6,-8,112.1,43.1), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.arc_c = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AkCCeQgIgEgDgHQgDgIADgIQBrj0DbgmQBugTBcAeQAHADAEAHQADAIgCAIQgDAIgHADQgIAEgIgDQhXgdhjASQjCAlhhDfQgFAMgNAAIgIgBg");
	this.shape.setTransform(27.1896,15.9604);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc_c, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.scribble5Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,145,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble5SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(41.95,16.9,1,1,0,0,0,72,47);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble5Sub, new cjs.Rectangle(-30,-30.1,144.1,94), null);


(lib.scribble4Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,175,93,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble4SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(57.25,16.25,1,1,0,0,0,87.3,46.3);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble4Sub, new cjs.Rectangle(-30,-30,174.6,92.6), null);


(lib.scribble3Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,181,94,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble3SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(60.4,16.5,1,1,0,0,0,60.4,16.5);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble3Sub, new cjs.Rectangle(-30,-30,180.8,93.1), null);


(lib.scribble2sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.scribble.cache(0,0,180,86,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scribble = new lib.scribble2SubSub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(59.7,13.05,1,1,0,0,0,89.7,43.1);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble2sub, new cjs.Rectangle(-30,-30,179.5,86.2), null);


(lib.scribble1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.scribble = new lib.scribble1_sub();
	this.scribble.name = "scribble";
	this.scribble.setTransform(63.2,13.2,1,1,0,0,0,63.2,13.2);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scribble1, new cjs.Rectangle(-30,-30,186.5,86.5), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.pointer = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointer.cache(0,0,30,25,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointer = new lib.pointerc();
	this.pointer.name = "pointer";
	this.pointer.setTransform(12.8,10.7,1,1,0,0,0,12.8,10.7);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer, new cjs.Rectangle(0,0,25.7,21.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.grid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.gridpiece();
	this.instance.setTransform(248.55,188.65,1.47,1.47,90,0,0,125.8,52.4);

	this.instance_1 = new lib.gridpiece();
	this.instance_1.setTransform(72.45,188.65,1.47,1.47,90,0,0,125.8,52.4);

	this.instance_2 = new lib.gridpiece();
	this.instance_2.setTransform(168.3,266.15,1.47,1.47,0,0,0,125.8,52.6);

	this.instance_3 = new lib.gridpiece();
	this.instance_3.setTransform(168.3,89.85,1.47,1.47,0,0,0,125.8,52.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grid, new cjs.Rectangle(-17.3,3,357.90000000000003,358), null);


(lib.file3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.ExcelUI_FinalFrame();
	this.instance.setTransform(6.75,8.95,1.29,1.29);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.fileShadow = new lib.fileShadow();
	this.fileShadow.name = "fileShadow";
	this.fileShadow.setTransform(188.6,274.65,1.542,2.3385,0,0,0,98,101.7);

	this.timeline.addTween(cjs.Tween.get(this.fileShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.file3, new cjs.Rectangle(4,4.8,335.8,506.8), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.45,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.2,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_65 = function() {
		exportRoot.startAnim();
	}
	this.frame_99 = function() {
		this.stop()
		exportRoot.mainMC.logo.visible=true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(65).call(this.frame_65).wait(34).call(this.frame_99).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8595,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(73));

	// Layer 3
	this.instance = new lib.MSFT_Logo_anim();
	this.instance.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(39).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhRUB7CMAAAj2DMCipAAAMAAAD2Dg");
	this.shape.setTransform(301.525,344.5);

	this.instance_1 = new lib.MSFT_logo_sq();
	this.instance_1.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1}]},13).to({state:[{t:this.instance_1}]},12).to({state:[]},1).to({state:[]},72).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(73));

	// Layer_6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("EhRUB7CMAAAj2DMCipAAAMAAAD2Dg");
	this.shape_1.setTransform(301.525,344.5);

	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.setTransform(301.4,344.45,1.0635,1.9017);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1}]}).to({state:[{t:this.instance_2}]},65).to({state:[{t:this.instance_2}]},33).to({state:[]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(65).to({_off:false},0).to({alpha:0},33,cjs.Ease.cubicInOut).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-219,-442.9,1041,1574.8000000000002);


(lib.bang_icon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bang.cache(-60,-60,120,120,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bang = new lib.bang_sub();
	this.bang.name = "bang";
	this.bang.setTransform(20.5,21,1,1,0,0,0,20.5,21);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bang_icon, new cjs.Rectangle(-1,-1,43,44), null);


(lib.bang = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}
	this.frame_47 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(28).call(this.frame_47).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AjLF0Qighjgri2QgpitBXiYIAKgRIMCHcIgKAQQhiCSitApQg4ANg1AAQh6AAhvhFg");
	var mask_graphics_1 = new cjs.Graphics().p("AjxFJQiOh8gNi7QgMiyBviIIAMgOIKrJTIgNAOQh4CAiyAMIgjACQilAAiAhwg");
	var mask_graphics_2 = new cjs.Graphics().p("AAnG2Qi6gSh3iRQh4iRASi6QARiyCEh0IAOgMIJAK7IgPAMQh4BciUAAQgYAAgZgDg");
	var mask_graphics_3 = new cjs.Graphics().p("AgCGpQi2gxheiiQheijAwi0QAuitCVhdIAQgKIHGMQIgQAJQhkA1hrAAQg7AAg9gQg");
	var mask_graphics_4 = new cjs.Graphics().p("AgmGQQishNhCiwQhCivBNirQBJijCihEIASgHIFANQIgSAGQhIAZhHAAQheAAhbgqg");
	var mask_graphics_5 = new cjs.Graphics().p("AhEF1Qichpgli4Qgli3BoidQBjiUCqgoIATgFICyN5IgTAEQgmAGglAAQiDAAhzhNg");
	var mask_graphics_6 = new cjs.Graphics().p("AhaFLQiJiAgGi8QgGi7CAiJQB5iDCvgLIATgCIAeOKIgTABQivgBiCh6g");
	var mask_graphics_7 = new cjs.Graphics().p("AB3HBQisgdhsiOQhziVAZi5QAYi6CVhzQCNhsCvAQIATACIh3ODIgTgDg");
	var mask_graphics_8 = new cjs.Graphics().p("AAMG3Qilg5hVieQhYilA3izQA2i0CmhZQCchUCqAtIASAFIkHNjIgSgFg");
	var mask_graphics_9 = new cjs.Graphics().p("AhaGmQiahTg6ipQg8ixBTipQBUioCxg9QCpg5CgBIIARAIImRMtIgRgJg");
	var mask_graphics_10 = new cjs.Graphics().p("Ai4GQQiLhrgdixQgei4BtiZQBuiYC4gfQCxgdCSBiIAPAKIoQLgIgPgLg");
	var mask_graphics_11 = new cjs.Graphics().p("AkLF1Qh4iAABizQAAi7CFiEQCFiFC7AAQCyAACBB4IANANIqBKAIgNgOg");
	var mask_graphics_12 = new cjs.Graphics().p("AlRFXQhgiSAdiwQAfi5CZhtQCZhtC4AfQCwAdBrCLIAMAQIrhIOIgMgQg");
	var mask_graphics_13 = new cjs.Graphics().p("AmHE2QhHigA6ioQA8iyCphTQCphSCxA8QCpA6BSCbIAJARIstGOIgJgRg");
	var mask_graphics_14 = new cjs.Graphics().p("AmtESQgsipBVidQBZilC0g2QCzg2ClBYQCdBVA5ClIAGASItkEGIgGgTg");
	var mask_graphics_15 = new cjs.Graphics().p("AnBDtQgQivBtiMQBziVC6gYQC6gYCUBzQCOBtAcCsIADATIuDB0IgCgTg");
	var mask_graphics_16 = new cjs.Graphics().p("AnEDLIAAgUQANivCDh4QCJiAC7AGQC8AHCACKQB6CBgBCwIAAATg");
	var mask_graphics_17 = new cjs.Graphics().p("AnABcIADgSQAqiqCUhjQCdhoC3AmQC4AlBoCcQBjCUgdCtIgDATg");
	var mask_graphics_18 = new cjs.Graphics().p("Am3gNIAHgSQBFiiCjhJQCrhNCvBDQCvBDBNCrQBJCig4CmIgHASg");
	var mask_graphics_19 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_20 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_21 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_22 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_23 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_24 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_25 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_26 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_27 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_28 = new cjs.Graphics().p("AmmhyIAJgRQBeiUCtgtQC1gwCiBeQCiBfAwC2QAuCrhTCbIgKARg");
	var mask_graphics_29 = new cjs.Graphics().p("AmnhuIAJgQQBdiVCtgvQC0gxCjBdQCjBeAxC1QAvCrhSCbIgJARg");
	var mask_graphics_30 = new cjs.Graphics().p("AmqhgIAJgRQBaiXCrgzQCzg1ClBaQClBZA2C0QAzCqhPCdIgIASg");
	var mask_graphics_31 = new cjs.Graphics().p("AmuhGIAIgRQBTibCpg6QCwg9CpBSQCpBTA9CxQA6CohHCgIgIASg");
	var mask_graphics_32 = new cjs.Graphics().p("Am1gcIAIgSQBIigCkhFQCuhJCtBHQCuBHBJCtQBFCjg9ClIgGASg");
	var mask_graphics_33 = new cjs.Graphics().p("Am8AgIAGgSQA4ilCehVQClhZCzA2QC0A2BZClQBVCcgtCqIgFATg");
	var mask_graphics_34 = new cjs.Graphics().p("AnCB3IADgTQAjirCQhpQCZhuC4AeQC6AeBuCYQBoCQgWCuIgCATg");
	var mask_graphics_35 = new cjs.Graphics().p("AnFDTQAEiwB9h/QCDiGC8gDQC6gDCHCDQCAB7AJCwIABATIuKANIgBgTg");
	var mask_graphics_36 = new cjs.Graphics().p("Am1EHQgjisBciYQBiigC2gtQC2gtCgBiQCZBcAwCoIAFATItwDXIgFgSg");
	var mask_graphics_37 = new cjs.Graphics().p("Al0FDQhRibAvisQAxi1CkhdQCjhdC0AxQCsAwBdCVIAJAQIsTHBIgJgRg");
	var mask_graphics_38 = new cjs.Graphics().p("AjyF/Qh+h7gJiyQgKi6B+iMQB+iMC6gKQCzgJCGBxIAPAMIpeKhIgPgMg");
	var mask_graphics_39 = new cjs.Graphics().p("Ag2GtQifhLhDilQhHiuBJisQBKitCuhHQCkhDCkA/IASAHIlhNCIgRgHg");
	var mask_graphics_40 = new cjs.Graphics().p("ACTHDQitgWhyiJQh5iQARi6QARi8CQh4QCIhzCvAKIATABIhROHIgTgCg");
	var mask_graphics_41 = new cjs.Graphics().p("AhGFxQibhqgii5Qgii4BribQBliTCrglIASgEICkN7IgTADQgiAFgiAAQiHAAh0hRg");
	var mask_graphics_42 = new cjs.Graphics().p("AgdGYQiuhFhLitQhKisBFiuQBCimCfhLIASgIIFlNAIgRAIQhRAfhQAAQhUAAhUgig");
	var mask_graphics_43 = new cjs.Graphics().p("AANGwQi3glhpicQhoicAki3QAjiwCOhmIAQgLIH3LxIgQALQhsBCh6AAQguAAgwgJg");
	var mask_graphics_44 = new cjs.Graphics().p("AA0G4Qi6gJh/iLQh+iLAJi7QAJiyB+h7IAOgNIJgKfIgOANQh9BpiiAAIgagBg");
	var mask_graphics_45 = new cjs.Graphics().p("AjxFJQiOh8gNi7QgMixBviIIAMgPIKrJTIgNAPQh4CAiyAMIgjABQilAAiAhwg");
	var mask_graphics_46 = new cjs.Graphics().p("AjdFjQiZhugei6QgcivBiiSIAKgQILfISIgLAQQhsCKiwAdQgoAGgmAAQiLAAh4hWg");
	var mask_graphics_47 = new cjs.Graphics().p("AjLF0Qighjgri2QgpitBXiYIAKgRIMCHcIgKAQQhiCSitApQg4ANg1AAQh6AAhvhFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:7.7595,y:44.1078}).wait(1).to({graphics:mask_graphics_1,x:5.6968,y:44.0588}).wait(1).to({graphics:mask_graphics_2,x:3.1294,y:44.0656}).wait(1).to({graphics:mask_graphics_3,x:0.1388,y:44.1187}).wait(1).to({graphics:mask_graphics_4,x:-3.1312,y:44.1519}).wait(1).to({graphics:mask_graphics_5,x:-6.5783,y:43.323}).wait(1).to({graphics:mask_graphics_6,x:-10.1435,y:42.9187}).wait(1).to({graphics:mask_graphics_7,x:-7.8905,y:42.7471}).wait(1).to({graphics:mask_graphics_8,x:-4.2364,y:41.9988}).wait(1).to({graphics:mask_graphics_9,x:-0.7366,y:40.7153}).wait(1).to({graphics:mask_graphics_10,x:2.52,y:38.9347}).wait(1).to({graphics:mask_graphics_11,x:5.4026,y:36.6592}).wait(1).to({graphics:mask_graphics_12,x:7.7747,y:33.8921}).wait(1).to({graphics:mask_graphics_13,x:9.6306,y:30.7666}).wait(1).to({graphics:mask_graphics_14,x:10.9653,y:27.41}).wait(1).to({graphics:mask_graphics_15,x:11.7387,y:23.9067}).wait(1).to({graphics:mask_graphics_16,x:11.9216,y:21.9134}).wait(1).to({graphics:mask_graphics_17,x:12.3376,y:25.6318}).wait(1).to({graphics:mask_graphics_18,x:13.3305,y:29.227}).wait(1).to({graphics:mask_graphics_19,x:14.744,y:32.5806}).wait(1).to({graphics:mask_graphics_20,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_21,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_22,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_23,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_24,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_25,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_26,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_27,x:14.744,y:32.5805}).wait(1).to({graphics:mask_graphics_28,x:14.744,y:32.5806}).wait(1).to({graphics:mask_graphics_29,x:14.6664,y:32.4356}).wait(1).to({graphics:mask_graphics_30,x:14.4212,y:31.9614}).wait(1).to({graphics:mask_graphics_31,x:13.9992,y:31.0806}).wait(1).to({graphics:mask_graphics_32,x:13.4136,y:29.685}).wait(1).to({graphics:mask_graphics_33,x:12.722,y:27.629}).wait(1).to({graphics:mask_graphics_34,x:12.0729,y:24.7269}).wait(1).to({graphics:mask_graphics_35,x:11.8047,y:21.4155}).wait(1).to({graphics:mask_graphics_36,x:11.1692,y:26.3332}).wait(1).to({graphics:mask_graphics_37,x:8.8933,y:32.0371}).wait(1).to({graphics:mask_graphics_38,x:4.4361,y:37.5422}).wait(1).to({graphics:mask_graphics_39,x:-1.9947,y:41.328}).wait(1).to({graphics:mask_graphics_40,x:-8.8455,y:42.9528}).wait(1).to({graphics:mask_graphics_41,x:-6.8971,y:43.3643}).wait(1).to({graphics:mask_graphics_42,x:-2.1672,y:44.1968}).wait(1).to({graphics:mask_graphics_43,x:1.4068,y:44.1432}).wait(1).to({graphics:mask_graphics_44,x:3.9893,y:44.0955}).wait(1).to({graphics:mask_graphics_45,x:5.7812,y:44.0947}).wait(1).to({graphics:mask_graphics_46,x:7.0088,y:44.117}).wait(1).to({graphics:mask_graphics_47,x:7.7595,y:44.1078}).wait(1));

	// Layer_1
	this.instance = new lib.bang_icon();
	this.instance.setTransform(19.8,27.9,1.0931,1.0931,0,0,0,20.5,21.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,3.8,47,48.1);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.arc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.arc.cache(0,0,55,35,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.arc = new lib.arc_c();
	this.arc.name = "arc";
	this.arc.setTransform(27.2,16,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.arc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arc, new cjs.Rectangle(0,0,54.4,31.9), null);


(lib.Anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// grid
	this.grid = new lib.grid();
	this.grid.name = "grid";
	this.grid.setTransform(126,52.5,1,1,0,0,0,126,52.5);
	this.grid.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.grid).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Anim, new cjs.Rectangle(-17.3,3,358,357.9), null);


(lib.yellowBgScribble = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_72 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(72).call(this.frame_72).wait(1));

	// Layer_8 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_53 = new cjs.Graphics().p("AysZEQizhMhKi2QhJi2BLi1QBPi0C1hKMA3sgWfQC2hKCzBNQC2BNBKC2QBJC1hOC1QhLC0i2BKMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_54 = new cjs.Graphics().p("AyyZGQizhMhKi1QhJi2BLi2QBPi0C1hJMA3sgWgQC2hJCzBMQC2BNBKC2QBJC2hOC0QhLC1i2BJMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_55 = new cjs.Graphics().p("AzIZPQizhMhJi2QhKi1BLi2QBPi0C1hJMA3sgWgQC2hJCzBMQC2BNBKC2QBJC2hOC0QhLC1i2BJMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_56 = new cjs.Graphics().p("Az2ZiQi0hMhJi2QhKi1BMi2QBOi0C2hJMA3rgWgQC2hJCzBMQC3BNBJC2QBKC2hPC0QhLC0i2BKMg3rAWgQhZAkhZAAQhdAAhdgog");
	var mask_graphics_57 = new cjs.Graphics().p("A1IaEQi0hNhJi1QhKi2BMi2QBOi0C2hJMA3rgWgQC2hJCzBMQC3BOBJC1QBKC2hPC0QhLC1i2BJMg3rAWgQhZAkhZAAQhdAAhdgng");
	var mask_graphics_58 = new cjs.Graphics().p("A23axQi0hNhJi1QhKi2BMi2QBOi0C2hJMA3rgWgQC2hJCzBMQC3BOBJC1QBKC2hPCzQhLC2i2BJMg3rAWgQhZAkhYAAQheAAhdgng");
	var mask_graphics_59 = new cjs.Graphics().p("A4ibcQi0hMhJi2QhKi2BMi1QBOi0C2hKMA3rgWfQC2hKC0BNQC2BNBJC2QBKC1hPC0QhLC1i2BKMg3rAWgQhZAkhYAAQheAAhdgog");
	var mask_graphics_60 = new cjs.Graphics().p("A53b+Qi0hMhJi1QhKi2BMi2QBOi0C2hJMA3rgWgQC2hJCzBMQC3BNBJC2QBJC2hOCzQhLC2i2BJMg3rAWgQhZAkhZAAQhdAAhdgog");
	var mask_graphics_61 = new cjs.Graphics().p("A65cZQizhMhJi2QhKi2BMi1QBOi1C1hJMA3sgWfQC2hKCzBMQC3BOBJC2QBJC1hOC0QhLC1i2BJMg3sAWhQhYAjhZABQhdAAhegog");
	var mask_graphics_62 = new cjs.Graphics().p("A7rctQizhMhJi2QhKi2BLi1QBPi0C1hKMA3sgWfQC2hJCzBMQC2BNBKC2QBJC2hOCzQhLC1i2BKMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_63 = new cjs.Graphics().p("A8Sc9QizhMhJi2QhKi2BLi1QBPi0C1hKMA3sgWfQC2hKCzBNQC2BNBKC2QBJC1hOC0QhLC1i2BKMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_64 = new cjs.Graphics().p("A8wdJQi0hMhJi2QhKi1BMi2QBOi0C2hJMA3rgWgQC2hJC0BMQC2BNBJC2QBKC2hPCzQhLC2i2BJMg3rAWgQhZAkhYAAQheAAhdgog");
	var mask_graphics_65 = new cjs.Graphics().p("A9IdTQi0hMhJi2QhKi1BMi2QBOi0C2hKMA3rgWfQC2hJCzBMQC3BNBJC2QBKC1hPC0QhLC1i2BKMg3rAWgQhZAkhZAAQhdAAhdgog");
	var mask_graphics_66 = new cjs.Graphics().p("A9bdbQi0hMhJi2QhKi2BMi1QBOi1C2hJMA3rgWfQC2hKCzBMQC3BOBJC2QBKC0hPC1QhLC1i2BJMg3rAWhQhZAkhYAAQheAAhdgog");
	var mask_graphics_67 = new cjs.Graphics().p("A9qdhQizhMhKi2QhJi2BLi1QBOi1C2hJMA3sgWfQC1hKC0BMQC2BOBKC1QBJC1hOC0QhMC2i1BJMg3sAWhQhYAjhZAAQhdAAhegng");
	var mask_graphics_68 = new cjs.Graphics().p("A91dlQizhMhKi2QhJi1BLi2QBOi0C2hKMA3sgWfQC1hJC0BMQC2BNBKC2QBJC1hOC0QhLC1i2BKMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_69 = new cjs.Graphics().p("A99doQizhMhKi1QhJi2BLi2QBOi0C2hJMA3sgWgQC2hJCzBMQC2BNBKC2QBJC1hOC0QhLC2i2BJMg3sAWgQhYAkhZAAQhdAAhegog");
	var mask_graphics_70 = new cjs.Graphics().p("A+CdrQi0hNhJi1QhJi2BLi2QBOi0C2hJMA3sgWgQC1hJC0BMQC2BOBJC1QBKC1hOC0QhMC2i1BJMg3sAWgQhZAkhYAAQheAAhdgng");
	var mask_graphics_71 = new cjs.Graphics().p("A+FdsQi0hMhJi2QhJi2BLi1QBOi1C2hJMA3sgWfQC1hKC0BMQC2BOBJC2QBKC0hOC0QhMC2i1BJMg3sAWhQhZAjhYAAQheAAhdgng");
	var mask_graphics_72 = new cjs.Graphics().p("A+FdrQi0hMhJi2QhKi2BMi1QBOi1C2hJMA3rgWfQC2hKCzBMQC3BOBJC2QBJC0hOC0QhLC2i2BJMg3rAWhQhZAjhZAAQhdAAhdgng");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(53).to({graphics:mask_graphics_53,x:302.9379,y:164.3675}).wait(1).to({graphics:mask_graphics_54,x:302.3399,y:164.6107}).wait(1).to({graphics:mask_graphics_55,x:300.144,y:165.5011}).wait(1).to({graphics:mask_graphics_56,x:295.4678,y:167.3973}).wait(1).to({graphics:mask_graphics_57,x:287.2654,y:170.7233}).wait(1).to({graphics:mask_graphics_58,x:276.1741,y:175.2208}).wait(1).to({graphics:mask_graphics_59,x:265.4757,y:179.559}).wait(1).to({graphics:mask_graphics_60,x:256.9613,y:183.0115}).wait(1).to({graphics:mask_graphics_61,x:250.4546,y:185.65}).wait(1).to({graphics:mask_graphics_62,x:245.4464,y:187.6807}).wait(1).to({graphics:mask_graphics_63,x:241.5434,y:189.2634}).wait(1).to({graphics:mask_graphics_64,x:238.4771,y:190.5068}).wait(1).to({graphics:mask_graphics_65,x:236.0638,y:191.4853}).wait(1).to({graphics:mask_graphics_66,x:234.1745,y:192.2515}).wait(1).to({graphics:mask_graphics_67,x:232.7154,y:192.8431}).wait(1).to({graphics:mask_graphics_68,x:231.6163,y:193.2888}).wait(1).to({graphics:mask_graphics_69,x:230.8237,y:193.6102}).wait(1).to({graphics:mask_graphics_70,x:230.2955,y:193.8244}).wait(1).to({graphics:mask_graphics_71,x:229.998,y:193.945}).wait(1).to({graphics:mask_graphics_72,x:229.9629,y:193.8425}).wait(1));

	// Layer_3 copy 3
	this.instance = new lib.scribble5Sub();
	this.instance.setTransform(125.1,312.5,1.5955,1.5955,0,0,0,42.1,16.9);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(53).to({_off:false},0).wait(20));

	// Layer_7 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_44 = new cjs.Graphics().p("Aa6VZMg5xgQEQi8g1hiisQhfioA0i9QA1i8CqhiQCrhfC9A0MA5xAQEQC8A0BgCqQBhCsg0C8Qg0C9isBfQhvBAh2AAQhAAAhCgTg");
	var mask_1_graphics_45 = new cjs.Graphics().p("Aa6VgMg5xgQEQi8g1hiisQhfioA0i9QA1i8CqhiQCrhfC9A0MA5xAQEQC9A0BfCpQBhCtg0C8Qg0C9isBfQhvA/h2AAQhAAAhCgSg");
	var mask_1_graphics_46 = new cjs.Graphics().p("Aa6V0Mg5xgQEQi8g1hiisQhfioA0i9QA1i8CqhiQCrhfC9A0MA5xAQDQC8A1BgCpQBhCsg0C9Qg0C9isBfQhvA/h2AAQhAAAhCgSg");
	var mask_1_graphics_47 = new cjs.Graphics().p("Aa6WTMg5xgQEQi8g1hiisQhfipA0i8QA1i8CqhiQCrhfC9A0MA5xAQEQC9A0BfCpQBhCtg0C8Qg0C9isBfQhvBAh2AAQhAAAhCgTg");
	var mask_1_graphics_48 = new cjs.Graphics().p("Aa6W6Mg5xgQEQi8g0hiisQhfiqA0i7QA1i9CqhiQCrhfC9A0MA5xAQEQC9A0BfCqQBhCsg0C8Qg0C9isBfQhvBAh2AAQhAAAhCgTg");
	var mask_1_graphics_49 = new cjs.Graphics().p("Aa6XmMg5xgQEQi8g1hiisQhfipA0i8QA1i9CqhhQCrhfC9A0MA5xAQDQC9A1BfCpQBhCsg0C9Qg0C8isBgQhvA/h2AAQhAAAhCgSg");
	var mask_1_graphics_50 = new cjs.Graphics().p("Aa6YRMg5xgQEQi8g0hiitQhfipA0i8QA1i8CqhiQCrhfC9A0MA5xAQEQC8A0BgCqQBhCsg0C8Qg0C9isBfQhvBAh2AAQhAAAhCgTg");
	var mask_1_graphics_51 = new cjs.Graphics().p("Aa6Y5Mg5xgQFQi8g0hiisQhfiqA0i7QA1i9CqhiQCrhfC9A1MA5xAQDQC8A0BgCqQBhCsg0C8Qg0C9isBfQhvBAh2AAQhAAAhCgSg");
	var mask_1_graphics_52 = new cjs.Graphics().p("Aa6ZYMg5xgQFQi8g0hiisQhfiqA0i8QA1i8CqhiQCrhfC9A1MA5xAQDQC9A0BfCqQBhCsg0C9Qg0C8isBfQhvBAh2AAQhAAAhCgSg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Aa6ZsMg5xgQFQi8g0hiisQhfiqA0i8QA1i8CqhiQCrhfC9A1MA5xAQDQC8A0BgCqQBhCsg0C9Qg0C8isBfQhvBAh2AAQhAAAhCgSg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Aa6ZyMg5xgQEQi8g1hiisQhfipA0i9QA1i7CqhiQCrhfC9A0MA5xAQEQC8A0BgCqQBhCsg0C8Qg0C9isBfQhvBAh2AAQhAAAhCgTg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(44).to({graphics:mask_1_graphics_44,x:-193.2536,y:138.7531}).wait(1).to({graphics:mask_1_graphics_45,x:-188.2832,y:139.442}).wait(1).to({graphics:mask_1_graphics_46,x:-173.8586,y:141.4397}).wait(1).to({graphics:mask_1_graphics_47,x:-151.3917,y:144.5512}).wait(1).to({graphics:mask_1_graphics_48,x:-123.0818,y:148.4719}).wait(1).to({graphics:mask_1_graphics_49,x:-91.7,y:152.818}).wait(1).to({graphics:mask_1_graphics_50,x:-60.3182,y:157.1642}).wait(1).to({graphics:mask_1_graphics_51,x:-32.0083,y:161.0849}).wait(1).to({graphics:mask_1_graphics_52,x:-9.5414,y:164.1964}).wait(1).to({graphics:mask_1_graphics_53,x:4.8832,y:166.1941}).wait(1).to({graphics:mask_1_graphics_54,x:9.6464,y:166.8531}).wait(19));

	// Layer_3 copy 2
	this.instance_1 = new lib.scribble4Sub();
	this.instance_1.setTransform(100.7,259.7,1.5955,1.5955,0,0,0,57.3,16.3);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(44).to({_off:false},0).wait(29));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_38 = new cjs.Graphics().p("AzwQoQiphigzi9Qgyi9BhirQBjipC9gzMA5+gPhQC9gzCpBiQCrBjAzC9QAzC9hkCpQhgCqi+AzMg5+APiQhAARg+AAQh5AAhxhBg");
	var mask_2_graphics_39 = new cjs.Graphics().p("A0lQ2Qiohhgzi+Qgzi9BhirQBkipC9gzMA5+gPhQC9gzCpBiQCrBjAzC9QAyC9hjCpQhhCqi9AzMg5+APiQhAARg+AAQh5AAhyhBg");
	var mask_2_graphics_40 = new cjs.Graphics().p("A24ReQiphigyi9Qgzi9BhirQBjipC9gzMA5+gPhQC+gzCoBhQCsBjAyC9QAzC+hjCpQhhCqi9AyMg5+APjQhAARg/AAQh5AAhxhBg");
	var mask_2_graphics_41 = new cjs.Graphics().p("A6NSXQiohigzi9Qgzi9BhirQBkipC9gzMA5+gPhQC9gzCpBiQCrBiAzC+QAyC9hjCoQhhCri9AzMg5+APiQhAARg+AAQh5AAhyhBg");
	var mask_2_graphics_42 = new cjs.Graphics().p("A95TWQiohhgzi9Qgzi+BhiqQBjiqC+gyMA5+gPiQC9gyCpBhQCrBjAzC9QAyC9hjCpQhhCqi9AzMg5+APiQhAASg+AAQh5AAhyhCg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EggsAUPQiphhgzi9Qgyi9BgirQBkipC9gzMA5+gPiQC9gyCpBhQCrBjAzC9QAzC9hkCpQhhCri9AyMg5+APjQhAARg+AAQh5AAhxhCg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EggsAU3Qiphhgzi+Qgyi9BgirQBkipC9gzMA5+gPhQC9gzCpBiQCrBjAzC9QAzC9hkCoQhhCri9AzMg5+APiQhAARg+AAQh5AAhxhBg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EggsAVFQiphhgzi+Qgyi9BgiqQBkiqC9gyMA5+gPiQC9gzCpBiQCrBjAzC9QAzC8hkCpQhhCri9AzMg5+APiQhAARg+AAQh5AAhxhBg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(38).to({graphics:mask_2_graphics_38,x:315.8277,y:112.9231}).wait(1).to({graphics:mask_2_graphics_39,x:310.5742,y:114.3356}).wait(1).to({graphics:mask_2_graphics_40,x:295.854,y:118.2932}).wait(1).to({graphics:mask_2_graphics_41,x:274.5826,y:124.012}).wait(1).to({graphics:mask_2_graphics_42,x:250.9731,y:130.3594}).wait(1).to({graphics:mask_2_graphics_43,x:226.3891,y:136.0782}).wait(1).to({graphics:mask_2_graphics_44,x:196.9486,y:140.0358}).wait(1).to({graphics:mask_2_graphics_45,x:186.4414,y:141.4481}).wait(28));

	// Layer_3 copy
	this.instance_2 = new lib.scribble3Sub();
	this.instance_2.setTransform(105.65,207.5,1.5955,1.5955,0,0,0,60.4,16.6);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(38).to({_off:false},0).wait(35));

	// Layer_5 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_31 = new cjs.Graphics().p("AbwOJMg6pgMzQi/gqhrimQhpikAqi/QApi/ClhsQCmhoC/ApMA6pAM0QC/ApBpCkQBrCmgqDAQgpC/imBpQh3BNiEAAQg0AAg1gMg");
	var mask_3_graphics_32 = new cjs.Graphics().p("AbwOQMg6pgMzQi/gqhrimQhpikAqi/QApi/ClhsQCmhoC/ApMA6pAM0QC/ApBpCkQBrCmgqDAQgpC/imBpQh3BNiEAAQg0AAg1gMg");
	var mask_3_graphics_33 = new cjs.Graphics().p("AbwOkMg6pgMzQi/gqhrimQhpikAqi/QApi/ClhsQCmhoC/ApMA6pAMzQC/AqBpCkQBrCmgqDAQgpC/imBpQh3BNiEAAQg0AAg1gMg");
	var mask_3_graphics_34 = new cjs.Graphics().p("AbwPDMg6pgM0Qi/gphrimQhpikAqi/QApjAClhrQCmhpC/AqMA6pAMzQC/AqBpCjQBrCngqC/QgpDAimBoQh3BOiEAAQg0AAg1gMg");
	var mask_3_graphics_35 = new cjs.Graphics().p("AbwPpMg6pgM0Qi/gqhrilQhpikAqjAQApi/ClhrQCmhpC/AqMA6pAMyQC/AqBpCkQBrCngqC/QgpC/imBpQh3BNiEAAQg0AAg1gLg");
	var mask_3_graphics_36 = new cjs.Graphics().p("AbwQRMg6pgM0Qi/gqhrimQhpijAqi/QApjAClhrQCmhpC/AqMA6pAMzQC/ApBpCkQBrCngqC/QgpDAimBoQh3BNiEAAQg0AAg1gLg");
	var mask_3_graphics_37 = new cjs.Graphics().p("AbwQ2Mg6pgMzQi/gqhrimQhpijAqjAQApi/ClhrQCmhpC/AqMA6pAMyQC/AqBpCkQBrCngqC/QgpC/imBpQh3BNiEAAQg0AAg1gMg");
	var mask_3_graphics_38 = new cjs.Graphics().p("AbwRVMg6pgMzQi/gqhrinQhpijAqi/QApi/ClhsQCmhoC/ApMA6pAMzQC/AqBpCkQBrCmgqDAQgpC/imBpQh3BNiEAAQg0AAg1gMg");
	var mask_3_graphics_39 = new cjs.Graphics().p("AbwRpMg6pgMzQi/gqhrinQhpijAqi/QApi/ClhsQCmhoC/ApMA6pAMzQC/AqBpCkQBrCmgqDAQgpC/imBpQh3BNiEAAQg0AAg1gMg");
	var mask_3_graphics_40 = new cjs.Graphics().p("AbwRwMg6pgMzQi/gqhrinQhpijAqi/QApi/ClhsQCmhoC/ApMA6pAMzQC/AqBpCkQBrCmgqDAQgpC/imBpQh3BNiEAAQg0AAg1gMg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(31).to({graphics:mask_3_graphics_31,x:-187.0992,y:91.6933}).wait(1).to({graphics:mask_3_graphics_32,x:-180.8966,y:92.3898}).wait(1).to({graphics:mask_3_graphics_33,x:-163.0369,y:94.3955}).wait(1).to({graphics:mask_3_graphics_34,x:-135.6742,y:97.4683}).wait(1).to({graphics:mask_3_graphics_35,x:-102.1089,y:101.2377}).wait(1).to({graphics:mask_3_graphics_36,x:-66.3895,y:105.2489}).wait(1).to({graphics:mask_3_graphics_37,x:-32.8242,y:109.0183}).wait(1).to({graphics:mask_3_graphics_38,x:-5.4615,y:112.0911}).wait(1).to({graphics:mask_3_graphics_39,x:12.3982,y:114.0967}).wait(1).to({graphics:mask_3_graphics_40,x:18.6008,y:114.7933}).wait(33));

	// Layer_3
	this.instance_3 = new lib.scribble2sub();
	this.instance_3.setTransform(106.85,160.3,1.5955,1.5955,0,0,0,59.8,13.1);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).wait(42));

	// Layer_4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_19 = new cjs.Graphics().p("A0/MMQikhugnjDQgnjDBtimQBwikDDgnMA7vgL6QDDgnClBuQCnBvAmDDQAnDDhwClQhtCljDAnMg7vAL6QgyAKgxAAQiLAAh8hSg");
	var mask_4_graphics_20 = new cjs.Graphics().p("A1EMMQilhugnjDQgmjDBtimQBwikDDgnMA7ugL6QDDgnClBuQCnBvAnDDQAmDDhwClQhtCljDAnMg7uAL6QgzAKgwAAQiMAAh7hSg");
	var mask_4_graphics_21 = new cjs.Graphics().p("A1XMMQilhugmjDQgnjDBtimQBwikDDgnMA7tgL6QDDgnClBuQCnBvAnDDQAmDDhvClQhuCljDAnMg7tAL6QgzAKgwAAQiLAAh8hSg");
	var mask_4_graphics_22 = new cjs.Graphics().p("A17MLQilhtgnjDQgmjDBtinQBwijDCgnMA7sgL6QDDgmCkBtQCnBwAnDCQAnDDhwClQhtCljDAnMg7sAL6QgyAKgxAAQiLAAh7hTg");
	var mask_4_graphics_23 = new cjs.Graphics().p("A23MLQikhugnjDQgnjCBtinQBwijDDgnMA7ogL5QDDgnCkBuQCnBvAnDDQAmDChvClQhuCljCAnMg7pAL5QgyAKgxAAQiLAAh7hSg");
	var mask_4_graphics_24 = new cjs.Graphics().p("A4TMKQijhugnjCQgnjDBtimQBwijDCgnMA7kgL4QDCgnCkBuQCnBvAnDCQAmDDhvCkQhtCljDAnMg7kAL4QgyAKgwAAQiLAAh8hSg");
	var mask_4_graphics_25 = new cjs.Graphics().p("A6UMIQikhtgnjCQgmjCBtimQBvijDCgnMA7dgL2QDCgnCkBtQCmBvAnDCQAnDChwCkQhtCljCAnMg7dAL3QgyAKgwAAQiLAAh7hTg");
	var mask_4_graphics_26 = new cjs.Graphics().p("A83MHQijhtgnjCQgmjCBsilQBvijDCgnMA7VgL1QDCgmCjBtQCmBvAnDBQAmDChvCkQhtCkjBAnMg7VAL1QgyAKgxAAQiKAAh7hSg");
	var mask_4_graphics_27 = new cjs.Graphics().p("A/dMIQijhsgmjCQgnjBBtilQBviiDBgnMA7MgLzQDCgnCiBtQCmBvAmDBQAnDBhvCjQhsCkjBAnMg7NALzQgyAKgwAAQiKAAh7hSg");
	var mask_4_graphics_28 = new cjs.Graphics().p("EghpAMlQiihsgnjBQgmjBBsilQBviiDBgmMA7FgLyQDBgnCiBtQCmBuAmDBQAnDBhvCjQhsCkjBAmMg7GALyQgxAKgwAAQiKAAh7hSg");
	var mask_4_graphics_29 = new cjs.Graphics().p("EghoAM7QijhsgmjBQgmjABsilQBuijDBglMA7AgLxQDAgmCjBsQClBuAmDBQAmDAhuCjQhsCkjBAmMg7AALxQgxAKgwAAQiKAAh6hSg");
	var mask_4_graphics_30 = new cjs.Graphics().p("EghmANLQiihsgmjBQgnjABsikQBvijDAglMA68gLwQDAgnCiBtQClBuAnDAQAmDAhvCjQhrCjjBAnMg68ALwQgxAKgwAAQiKAAh6hSg");
	var mask_4_graphics_31 = new cjs.Graphics().p("EghkANXQiihtgnjAQgmjABsikQBuijDAglMA66gLwQDAgmCiBsQCkBuAnDAQAmDBhuCiQhsCjjAAnMg65ALvQgyAKgwAAQiJAAh6hRg");
	var mask_4_graphics_32 = new cjs.Graphics().p("EghjANfQiihsgmjAQgnjBBsikQBuiiDAgmMA64gLuQDAgnCiBsQCkBuAnDAQAmDAhuCjQhsCjjAAmMg63ALvQgyAKgwAAQiJAAh6hRg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(19).to({graphics:mask_4_graphics_19,x:322.9417,y:57.9235}).wait(1).to({graphics:mask_4_graphics_20,x:322.3522,y:58.1582}).wait(1).to({graphics:mask_4_graphics_21,x:320.3546,y:58.9519}).wait(1).to({graphics:mask_4_graphics_22,x:316.5036,y:60.482}).wait(1).to({graphics:mask_4_graphics_23,x:310.1593,y:63.0028}).wait(1).to({graphics:mask_4_graphics_24,x:300.4726,y:66.8516}).wait(1).to({graphics:mask_4_graphics_25,x:286.6981,y:72.3247}).wait(1).to({graphics:mask_4_graphics_26,x:269.4517,y:79.1772}).wait(1).to({graphics:mask_4_graphics_27,x:251.8419,y:85.8247}).wait(1).to({graphics:mask_4_graphics_28,x:237.0003,y:88.6923}).wait(1).to({graphics:mask_4_graphics_29,x:215.0237,y:90.8739}).wait(1).to({graphics:mask_4_graphics_30,x:198.7534,y:92.4698}).wait(1).to({graphics:mask_4_graphics_31,x:187.0938,y:93.6135}).wait(1).to({graphics:mask_4_graphics_32,x:178.7497,y:94.4318}).wait(41));

	// Layer_2
	this.instance_4 = new lib.scribble1();
	this.instance_4.setTransform(112.3,118.35,1.5955,1.5955,0,0,0,63.2,13.2);
	this.instance_4._off = true;

	var maskedShapeInstanceList = [this.instance_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).wait(54));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-38.6,0,299.70000000000005,387.4);


(lib.UISubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Logo
	this.pptLogo = new lib.OutlookLogo();
	this.pptLogo.name = "pptLogo";
	this.pptLogo.setTransform(-47.75,2.8,2.1677,2.1677,0,0,0,52.9,32.5);

	this.timeline.addTween(cjs.Tween.get(this.pptLogo).wait(1));

	//  files 1 - 2
	this.file2 = new lib.file2();
	this.file2.name = "file2";
	this.file2.setTransform(217,281.05,1,1,0,0,0,100.5,74);

	this.file1 = new lib.file1();
	this.file1.name = "file1";
	this.file1.setTransform(222.1,180.1,1,1,0,0,0,115.1,92.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.file1},{t:this.file2}]}).wait(1));

	// file 3
	this.file3 = new lib.file3();
	this.file3.name = "file3";
	this.file3.setTransform(323.3,465.9,1,1,0,0,0,163.2,249);

	this.timeline.addTween(cjs.Tween.get(this.file3).wait(1));

	// file 4
	this.file4 = new lib.file4();
	this.file4.name = "file4";
	this.file4.setTransform(343.25,192.15,1,1,0,0,0,248.6,115.5);

	this.timeline.addTween(cjs.Tween.get(this.file4).wait(1));

	// ODUI
	this.instance = new lib.ExcelUI_CU();
	this.instance.setTransform(-61.65,20.5,0.962,0.962);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// UIShadow
	this.UIShadow = new lib.UIShadow();
	this.UIShadow.name = "UIShadow";
	this.UIShadow.setTransform(210.85,161.5,1,1,0,0,0,196.5,134);

	this.timeline.addTween(cjs.Tween.get(this.UIShadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UISubSub, new cjs.Rectangle(-206.1,-504,1009.4,1514), null);


(lib.uiSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AhfJGQgHAAgHgGIgGgHIg9hZQgKgRgOgJQgPgKgXgCIo3AAIAAv/IZLAAIAASLg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:210.875,y:79.025}).wait(1).to({graphics:null,x:0,y:0}).wait(1));

	// Layer_1
	this.ui = new lib.UISubSub();
	this.ui.name = "ui";
	this.ui.setTransform(205.5,150.3,1,1,0,0,0,205.5,150.3);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-181,-110.2,840.9,838.6);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-18.1,0,0.68,0.68,0,0,0,13.6,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.CTAbg = new lib.backCTA();
	this.CTAbg.name = "CTAbg";
	this.CTAbg.setTransform(-100,-12.85);

	this.timeline.addTween(cjs.Tween.get(this.CTAbg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.1,-20.9,145.79999999999998,43.099999999999994), null);


(lib.cta_arrow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(1));

	// Layer_5 copy (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AAFDiIhLg4QgFgEAGgOQAGgOANgQQANgQAOgJQANgIAGAEIBKA4QAGAEgGAOQgGAPgNAPQgNARgOAIQgJAGgFAAIgFgCg");
	var mask_graphics_24 = new cjs.Graphics().p("AAFDiIhLg4QgFgEAGgOQAGgOANgQQANgQAOgJQANgIAGAEIBKA4QAGAEgGAOQgGAPgNAPQgNARgOAIQgJAGgFAAIgFgCg");
	var mask_graphics_25 = new cjs.Graphics().p("AAQDgIhghHQgHgFAFgPQAFgPANgQQANgQAPgIQAOgHAHAEIBgBHQAHAGgFAPQgEAPgNAPQgOARgPAHQgIAFgGAAQgEAAgDgCg");
	var mask_graphics_26 = new cjs.Graphics().p("AAaDeIh0hVQgIgGADgQQAEgQAOgQQANgQAQgHQAPgHAIAGIB0BVQAIAGgDAQQgEAQgNAQQgOAQgQAHQgIADgGAAQgFAAgEgCg");
	var mask_graphics_27 = new cjs.Graphics().p("AAjDbIiGhiQgKgHADgQQADgRANgQQAOgQAQgGQARgGAJAHICGBiQAKAHgDARQgDAQgNAQQgOAQgQAGQgIADgGAAQgHAAgFgEg");
	var mask_graphics_28 = new cjs.Graphics().p("AArDZIiXhuQgLgIADgRQACgRANgQQANgQASgFQARgGALAIICWBuQAMAIgCARQgDARgNAQQgNAQgSAGQgHACgGAAQgIAAgHgFg");
	var mask_graphics_29 = new cjs.Graphics().p("AAzDXIimh5QgMgJABgRQABgSANgQQAOgQASgFQASgFAMAJICmB5QAMAJgBASQgBARgNAQQgOAQgSAFQgGACgGAAQgKAAgIgGg");
	var mask_graphics_30 = new cjs.Graphics().p("AA6DVIi0iDQgOgJABgTQAAgSAOgQQANgQATgEQATgDANAIIC0CDQAOAKgBASQAAASgNAQQgOAQgTAFIgLABQgMAAgJgHg");
	var mask_graphics_31 = new cjs.Graphics().p("ABADUIjBiNQgOgKAAgTQAAgSANgQQAOgPATgEQAUgEANAKIDBCLQAPALAAATQAAASgNAQQgOAQgTAEIgKABQgOAAgKgHg");
	var mask_graphics_32 = new cjs.Graphics().p("ABGDSIjNiUQgPgLAAgTQgBgTANgPQAOgQAUgEQAUgDAPAKIDMCUQAQALAAATQABATgNAQQgOAQgUAEIgJAAQgPAAgLgIg");
	var mask_graphics_33 = new cjs.Graphics().p("ABLDRIjXicQgPgLgCgUQgBgTAOgPQANgQAVgDQAUgDAQALIDWCbQAQALACAUQABATgNAQQgOAQgVADIgIABQgQAAgMgJg");
	var mask_graphics_34 = new cjs.Graphics().p("ABPDQIjfijQgQgLgCgUQgCgTAOgQQANgQAVgCQAVgDAQALIDgChQAQAMACAUQACAUgNAQQgOAQgVADIgIAAQgQAAgOgJg");
	var mask_graphics_35 = new cjs.Graphics().p("ABTDPIjnioQgRgMgCgUQgCgTAOgQQANgQAWgCQAVgDARAMIDmCmQASANACAUQACAUgNAPQgOARgWACIgHABQgRAAgOgKg");
	var mask_graphics_36 = new cjs.Graphics().p("ABWDOIjtisQgRgMgDgVQgCgTAOgQQANgQAWgCQAWgCAQAMIDtCrQASAMADAVQACAUgNAPQgOARgWACIgGAAQgSAAgPgKg");
	var mask_graphics_37 = new cjs.Graphics().p("ABYDNIjxivQgSgNgCgTQgDgVANgQQAOgQAWgCQAWgCARANIDyCuQASANACAUQADAVgNAPQgOARgWACIgGAAQgSAAgQgLg");
	var mask_graphics_38 = new cjs.Graphics().p("ABaDNIj1iyQgSgNgDgTQgCgVANgQQANgQAXgCQAWgCARANID1CxQATANADAUQACAVgNAPQgNARgXACIgFAAQgTAAgQgLg");
	var mask_graphics_39 = new cjs.Graphics().p("ABbDNIj3i0QgSgNgDgTQgDgVAOgQQANgQAXgCQAWgBARAMID3CyQATAOADAUQADAVgNAPQgOARgXACIgFAAQgTAAgQgLg");
	var mask_graphics_40 = new cjs.Graphics().p("ABbDOIj3izQgSgNgDgUQgDgVANgQQAOgQAWgBQAXgCARAMID4CzQASAOADAUQADAVgNAPQgOARgWACIgFAAQgUAAgQgMg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:5.7023,y:22.7518}).wait(24).to({graphics:mask_graphics_24,x:5.7023,y:22.7518}).wait(1).to({graphics:mask_graphics_25,x:3.9434,y:22.5865}).wait(1).to({graphics:mask_graphics_26,x:2.2981,y:22.4386}).wait(1).to({graphics:mask_graphics_27,x:0.7663,y:22.3064}).wait(1).to({graphics:mask_graphics_28,x:-0.6522,y:22.1884}).wait(1).to({graphics:mask_graphics_29,x:-1.9572,y:22.0834}).wait(1).to({graphics:mask_graphics_30,x:-3.1489,y:21.9904}).wait(1).to({graphics:mask_graphics_31,x:-4.2271,y:21.9086}).wait(1).to({graphics:mask_graphics_32,x:-5.1918,y:21.837}).wait(1).to({graphics:mask_graphics_33,x:-6.043,y:21.7752}).wait(1).to({graphics:mask_graphics_34,x:-6.7807,y:21.7226}).wait(1).to({graphics:mask_graphics_35,x:-7.4048,y:21.6788}).wait(1).to({graphics:mask_graphics_36,x:-7.9155,y:21.6434}).wait(1).to({graphics:mask_graphics_37,x:-8.3126,y:21.6162}).wait(1).to({graphics:mask_graphics_38,x:-8.5963,y:21.5969}).wait(1).to({graphics:mask_graphics_39,x:-8.7666,y:21.5853}).wait(1).to({graphics:mask_graphics_40,x:-8.3713,y:21.7821}).wait(5));

	// Layer_2 copy
	this.instance = new lib.pointer();
	this.instance.setTransform(-6.9,20.05,1.3681,1.2412,0,12.7019,-167.2983,12.7,10.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45));

	// Layer_5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AAuBAQgRgCgVgJQgUgIgNgKQgMgLACgFIAkhOQADgGARACQARACAUAJQAWAIAMAKQANALgDAFIglBOQgCAFgJAAIgIgBg");
	var mask_1_graphics_16 = new cjs.Graphics().p("AAuBAQgRgCgVgJQgUgIgNgKQgMgLACgFIAkhOQADgGARACQARACAUAJQAWAIAMAKQANALgDAFIglBOQgCAFgJAAIgIgBg");
	var mask_1_graphics_17 = new cjs.Graphics().p("AAbBVQgSAAgUgJQgUgIgMgMQgMgMAEgIIAzhwQAEgJARABQASAAAUAIQAWAJAMAMQAMAMgEAIIg1BwQgDAIgQAAIgCAAg");
	var mask_1_graphics_18 = new cjs.Graphics().p("AgcBhQgVgIgLgOQgLgNAEgLIBDiPQADgKATgCQASgBAUAJQAWAIALAOQALANgFALIhCCPQgFAKgSACIgEAAQgQAAgSgIg");
	var mask_1_graphics_19 = new cjs.Graphics().p("AgsB0QgVgJgKgPQgLgPAGgMIBOiqQAFgNATgDQATgCAUAIQAWAJAKAPQALAPgGAMIhPCrQgFAMgSADIgJAAQgPAAgQgGg");
	var mask_1_graphics_20 = new cjs.Graphics().p("Ag6CEQgVgIgKgRQgKgQAGgOIBajDQAGgOATgEQAUgEAUAJQAWAIAJARQAKAQgGAOIhaDDQgGAOgTAEIgMABQgOAAgOgGg");
	var mask_1_graphics_21 = new cjs.Graphics().p("AhCCTQgVgJgKgRQgJgSAHgPIBjjYQAGgQAVgFQAUgFAUAIQAVAJAKARQAJASgHAQIhjDYQgGAPgUAFQgIACgHAAQgNAAgNgFg");
	var mask_1_graphics_22 = new cjs.Graphics().p("AhICfQgVgJgJgSQgJgTAIgQIBqjqQAIgSAVgFQAUgGAUAIQAWAJAJASQAJATgIARIhqDqQgIARgUAFQgJADgIAAQgMAAgNgFg");
	var mask_1_graphics_23 = new cjs.Graphics().p("AhMCoQgVgIgJgTQgIgTAIgSIBwj4QAJgTAVgHQAUgGAVAIQAVAJAJATQAIATgIASIhxD5QgIASgVAHQgJACgJAAQgLAAgMgFg");
	var mask_1_graphics_24 = new cjs.Graphics().p("AhQCwQgVgIgIgUQgIgUAIgSIB2kEQAJgUAVgHQAVgHAUAJQAWAIAIAUQAIAUgIATIh2EEQgJATgVAHQgJADgKAAQgLAAgMgFg");
	var mask_1_graphics_25 = new cjs.Graphics().p("AhSC2QgVgJgIgUQgIgUAIgTIB6kMQAJgUAVgIQAVgHAVAIQAVAJAIAUQAIAUgIAUIh6EMQgJATgVAIQgKADgKAAQgLAAgLgEg");
	var mask_1_graphics_26 = new cjs.Graphics().p("AhUC5QgVgJgIgUQgIgUAJgUIB8kRQAJgUAWgIQAVgHAUAIQAWAJAIAUQAIAUgJAUIh8ERQgJAUgVAIQgLADgKAAQgLAAgLgEg");
	var mask_1_graphics_27 = new cjs.Graphics().p("AhUC6QgVgIgIgVQgIgUAJgUIB8kSQAKgVAVgIQAVgIAVAJQAVAJAIAUQAIAUgJAUIh8ETQgJAUgWAIQgKAEgKAAQgLAAgLgFg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:10.2791,y:4.5364}).wait(16).to({graphics:mask_1_graphics_16,x:10.2791,y:4.5364}).wait(1).to({graphics:mask_1_graphics_17,x:10.1739,y:6.8108}).wait(1).to({graphics:mask_1_graphics_18,x:10.0848,y:8.869}).wait(1).to({graphics:mask_1_graphics_19,x:10.0096,y:10.7101}).wait(1).to({graphics:mask_1_graphics_20,x:9.9466,y:12.3346}).wait(1).to({graphics:mask_1_graphics_21,x:9.4911,y:13.7424}).wait(1).to({graphics:mask_1_graphics_22,x:8.9576,y:14.9336}).wait(1).to({graphics:mask_1_graphics_23,x:8.521,y:15.9083}).wait(1).to({graphics:mask_1_graphics_24,x:8.1815,y:16.6663}).wait(1).to({graphics:mask_1_graphics_25,x:7.939,y:17.2078}).wait(1).to({graphics:mask_1_graphics_26,x:7.7935,y:17.5327}).wait(1).to({graphics:mask_1_graphics_27,x:7.6905,y:17.762}).wait(18));

	// Layer_2
	this.instance_1 = new lib.pointer();
	this.instance_1.setTransform(-6.9,20.05,1.3681,1.2412,0,12.7019,-167.2983,12.7,10.8);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(45));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AugEFIADgQQBZmKFxjSQFzjQGyBiIASAEIjaPGg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AugEFIADgQQBZmKFxjSQFzjQGyBiIASAEIjaPGg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AugEFIADgQQBZmKFyjSQFyjQGyBiIASAEIjaPGg");
	var mask_2_graphics_3 = new cjs.Graphics().p("AugEDIAEgQQBamKFxjRQFzjQGyBjIASAFIjdPGg");
	var mask_2_graphics_4 = new cjs.Graphics().p("AufD9IAEgPQBcmKFyjPQF0jOGxBmIASAEIjhPFg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AudDzIADgQQBhmIF1jMQF2jKGvBqIASAEIjsPEg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AuaDiIAEgQQBnmHF4jGQF6jEGtByIASAEIj+PBg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AuWDIIAFgPQBymFF9i8QF+i7GpB8IASAFIkYO7g");
	var mask_2_graphics_8 = new cjs.Graphics().p("AuPCmIAFgQQCBmBGEivQGEiuGkCMIARAFIk8Ozg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AuEB4IAGgPQCUl8GLidQGLicGcCfIARAHIlsOkg");
	var mask_2_graphics_10 = new cjs.Graphics().p("At1A/IAHgPQCtlzGTiGQGUiEGQC3IAQAIImoOQg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AtggFIAIgOQDLloGdhoQGchmF/DVIAPAJInxNwg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AtDhVIAKgNQDulVGlhCQGkhBFmD3IAPAKIpINBg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AsbitIALgNQEXk5GqgVQGpgTFFEcIAOALIqrL+g");
	var mask_2_graphics_14 = new cjs.Graphics().p("ArmkKIANgLQFCkSGpAhQGpAiEaFCIAMAOIsUKfg");
	var mask_2_graphics_15 = new cjs.Graphics().p("ArUlhIAPgJQFrjgGhBdQGhBfDjFlIAKAPIt6Ikg");
	var mask_2_graphics_16 = new cjs.Graphics().p("Aq6mfIAQgHQGKiuGSCRQGSCTCwF8IAHAQIvFGqg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AqcnIIARgFQGfh/GAC8QGBC9CCGLIAGAQIv4E5g");
	var mask_2_graphics_18 = new cjs.Graphics().p("Ap8ngIARgDQGshYFuDeQFvDgBbGSIAEARIwYDXg");
	var mask_2_graphics_19 = new cjs.Graphics().p("ApfnsIASgDQG0g1FdD4QFdD6A8GXIADAQIwsCEg");
	var mask_2_graphics_20 = new cjs.Graphics().p("ApFnyIASgBQG4gaFPENQFOENAiGZIACARIw2A/g");
	var mask_2_graphics_21 = new cjs.Graphics().p("AovnzIASAAQG6gFFCEdQFCEcAOGYIABARIw7ALg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AoeHkIABvlIASAAQG7AME4EoQE4EngBGYIAAAQg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AofHVIAbvkIASABQG7AYExEvQExEwgLGWIgBARg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AofHKIAsviIASACQG7AgEsE0QErE0gSGWIAAARg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AogHEIA3vhIASACQG7AkEpE4QEpE3gXGVIgBARg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AogHAIA9vgIARACQG8AnEnE5QEnE5gZGVIgBARg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AogG/IA+vgIASACQG8AoEmE6QEmE5gZGVIgBARg");
	var mask_2_graphics_28 = new cjs.Graphics().p("AogG/IA/vgIARACQG8AoEmE6QEmE5gZGVIgBARg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:-92.9291,y:-19.2505}).wait(1).to({graphics:mask_2_graphics_1,x:-92.9291,y:-19.2505}).wait(1).to({graphics:mask_2_graphics_2,x:-92.9255,y:-19.2528}).wait(1).to({graphics:mask_2_graphics_3,x:-92.8946,y:-19.2647}).wait(1).to({graphics:mask_2_graphics_4,x:-92.8096,y:-19.2968}).wait(1).to({graphics:mask_2_graphics_5,x:-92.6398,y:-19.359}).wait(1).to({graphics:mask_2_graphics_6,x:-92.3473,y:-19.4607}).wait(1).to({graphics:mask_2_graphics_7,x:-91.882,y:-19.6097}).wait(1).to({graphics:mask_2_graphics_8,x:-91.1758,y:-19.8105}).wait(1).to({graphics:mask_2_graphics_9,x:-90.135,y:-20.061}).wait(1).to({graphics:mask_2_graphics_10,x:-88.6346,y:-20.348}).wait(1).to({graphics:mask_2_graphics_11,x:-86.5121,y:-20.6425}).wait(1).to({graphics:mask_2_graphics_12,x:-83.567,y:-20.8986}).wait(1).to({graphics:mask_2_graphics_13,x:-79.5651,y:-21.0651}).wait(1).to({graphics:mask_2_graphics_14,x:-74.2563,y:-21.0992}).wait(1).to({graphics:mask_2_graphics_15,x:-62.8642,y:-20.9164}).wait(1).to({graphics:mask_2_graphics_16,x:-52.8457,y:-20.5238}).wait(1).to({graphics:mask_2_graphics_17,x:-44.8132,y:-20.045}).wait(1).to({graphics:mask_2_graphics_18,x:-38.5222,y:-19.5862}).wait(1).to({graphics:mask_2_graphics_19,x:-33.6954,y:-19.2095}).wait(1).to({graphics:mask_2_graphics_20,x:-30.0651,y:-18.936}).wait(1).to({graphics:mask_2_graphics_21,x:-27.3938,y:-18.7581}).wait(1).to({graphics:mask_2_graphics_22,x:-25.5317,y:-17.1555}).wait(1).to({graphics:mask_2_graphics_23,x:-25.4732,y:-15.5971}).wait(1).to({graphics:mask_2_graphics_24,x:-25.4362,y:-14.5321}).wait(1).to({graphics:mask_2_graphics_25,x:-25.4148,y:-13.8783}).wait(1).to({graphics:mask_2_graphics_26,x:-25.4042,y:-13.5404}).wait(1).to({graphics:mask_2_graphics_27,x:-25.4004,y:-13.4155}).wait(1).to({graphics:mask_2_graphics_28,x:-25.3765,y:-13.7703}).wait(17));

	// Layer_1
	this.instance_2 = new lib.arc();
	this.instance_2.setTransform(-31.85,5.75,1.3681,1.2412,0,12.7019,-167.2983,27.2,16.1);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(45));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-72.4,-21.9,85.4,58.5);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.bgImg.cache(0,0,300,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// introAnim
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(159.65,225,0.3087,0.3087,0,0,0,300.8,295.5);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(302.9,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(58.5,415.1,1,1,0,0,0,36.3,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(71.65,414.5,1.3558,1.3558,0,0,0,-49.1,0);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// CTA_Arrow
	this.CTA_Arrow = new lib.cta_arrow_1();
	this.CTA_Arrow.name = "CTA_Arrow";
	this.CTA_Arrow.setTransform(85.4,351.05,1,1,0,0,0,27.2,16);

	this.timeline.addTween(cjs.Tween.get(this.CTA_Arrow).wait(1));

	// mobile
	this.mobile = new lib.mobile();
	this.mobile.name = "mobile";
	this.mobile.setTransform(187.55,202,1,1,0,0,0,50.5,92.5);

	this.timeline.addTween(cjs.Tween.get(this.mobile).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// UI
	this.ui = new lib.uiSub();
	this.ui.name = "ui";
	this.ui.setTransform(149.15,127.3,1,1,0,0,0,206.7,147.8);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// msLogo
	this.logo = new lib.msLogoWhite();
	this.logo.name = "logo";
	this.logo.setTransform(168.25,135.6,0.57,0.57,0,0,0,240.5,181.6);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// bang
	this.bang = new lib.bang();
	this.bang.name = "bang";
	this.bang.setTransform(277.85,162.7,1,1,0,0,0,19.9,34.9);

	this.timeline.addTween(cjs.Tween.get(this.bang).wait(1));

	// anim
	this.anim = new lib.Anim();
	this.anim.name = "anim";
	this.anim.setTransform(253,131.7,1,1,0,0,0,365.2,-36.5);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// scribble
	this.scribble = new lib.yellowBgScribble();
	this.scribble.name = "scribble";
	this.scribble.setTransform(151.6,147,1,1,0,0,0,93,108);

	this.timeline.addTween(cjs.Tween.get(this.scribble).wait(1));

	// bg image
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgY/AlgMAAAhK/MAx/AAAMAAABK/g");
	this.shape.setTransform(160,240);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-238.5,-130.7,840.8,838.5999999999999), null);


// stage content:
(lib.M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			exportRoot.isReplay = false;
		
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "intr" && data[keys[i]].length > 1) {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillIntro(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAs") {
							ctaMC = mc.cta.CTAbg
							popL = mc.cta.popLeft
							popR = mc.cta.popRight
							sclX = parseFloat(data[keys[i]][0])
							oldWidth = ctaMC.nominalBounds.width
							ctaMC.scaleX = sclX/100;
							stage.update();
							newWidth = (ctaMC.nominalBounds.width/100)*sclX
							ctaMC.x -= (newWidth-oldWidth)/2
							
							var scale = newWidth / ctaMC.nominalBounds.width;
							
							/*popL.x = mc.cta.CTAbg.x
							popL.x -= 15
							popR.x = mc.cta.CTAbg.x+newWidth
							popR.x += 15*/
							
							mc.cta.x +=data[keys[i]][1]
							mc.cta.y +=data[keys[i]][2]
		
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillIntro = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro ", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro Bold", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		mc.logo.visible = false;
		//mc.ui.ui.ad1.visible = false;
		
		this.runBanner = function() {	
			
				this.tl1 = gsap.timeline();
			
				//UI		
				this.tl1.to(mc.ui.ui,{duration:.6, y:"-=0", ease:Sine.easeOut, onComplete:function(){mc.ui.play();}}, ">+.1");
				
				this.tl1.from(mc.ui.ui.file1,{duration:.7, x:"-=140", y:"-=60", scaleX:.35, scaleY:.35, ease:Power3.easeInOut}, ">+.1");
				this.tl1.from(mc.ui.ui.file1,{duration:.1, alpha: 0, ease:Power4.easeInOut}, "<.1");		
				
				this.tl1.from(mc.ui.ui.file2,{duration:.7, x:"+=22", y:"+=8", scaleX:.559, scaleY:.559, ease:Power3.easeInOut}, ">-.4");
				
				this.tl1.to(mc.ui.ui,{duration:1, x:"-=18", y:"+=77", scaleX: .316, scaleY: .316, ease:Power3.easeInOut}, ">+.6");
				this.tl1.from(mc.ui.ui.UIShadow,{duration:1, x:"+=14", y:"+=17", alpha:0, ease:Power3.easeInOut}, "<");
		
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.5, x:"-=100", y:"-=100", scaleX: 3, scaleY: 3, ease:Power3.easeOut}, "<+.4");
				this.tl1.from(mc.ui.ui.pptLogo,{duration:.1, alpha:0}, "<");		
				this.tl1.from(mc.bang, {duration:.6 ,scaleX: .5, scaleY: .5, alpha:0, ease:Back.easeOut, onStart:function(){mc.bang.play();}}, "<");
				
				this.tl1.to(mc.ui.ui.file1,{duration:.7, x:"-=22", y:"-=8", scaleX:.559, scaleY:.559, ease:Power3.easeIn}, ">-1");
				this.tl1.to(mc.ui.ui.file1,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");
				this.tl1.to(mc.ui.ui.file2,{duration:.7,x:"+=22", y:"+=8", scaleX:.559, scaleY:.559, ease:Power3.easeIn}, "<-.5");
				this.tl1.to(mc.ui.ui.file2,{duration:.1, alpha:0, ease:Power3.easeInOut}, ">-.1");				
				
				this.tl1.from(mc.ui.ui.file3,{duration:.7, x:"+=2", y:"-=264", scaleX:.208, scaleY:.208, ease:Power3.easeInOut}, "<-.2");
				this.tl1.from(mc.ui.ui.file3.fileShadow,{duration:.6, x:"+=2", y:"-=264", scaleX:.208, scaleY:.208,  ease:Power3.easeInOut}, "<-.2");
				
				this.tl1.from(mc.ui.ui.file4,{duration:.7, x:"-=210", y:"-=125", scaleX:.2, scaleY:.2, alpha:0, ease:Power3.easeInOut}, ">-.4");
		
						
				this.tl1.to(mc.ui.ui,{duration:1.2, x:"-=300", ease:Power3.easeInOut}, ">+1.3");
				this.tl1.to(mc.bang, {duration:1.2, x:"-=300", ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<");
				this.tl1.to(mc.ui.ui.file4,{duration:1, x:"-=210", y:"-=125", scaleX:.2, scaleY:.2, alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.ui.ui.file3,{duration:1, x:"+=2", y:"-=264", scaleX:.208, scaleY:.208, alpha:0, ease:Power3.easeInOut}, "<");
				this.tl1.to(mc.bang, {duration:1, ease:Power3.easeInOut, onStart:function(){mc.bang.play();}}, "<-.2");
		
				this.tl1.from(exportRoot.headline1,{duration:0.8, y: "+=20", alpha: 0, stagger: 0.1, ease:Power4.easeOut, onStart:function(){mc.scribble.play();}}, ">-0");
				this.tl1.from(mc.mobile,{duration:1.2, y:"+=350", ease:Power3.easeInOut}, ">-1");		
				this.tl1.from(mc.cta , 0.8, { scaleX:0, scaleY:0,	ease:Power4.easeOut, onStart:function(){mc.CTA_Arrow.play();}}, ">+.3");
				this.tl1.from(mc.txtCta, 0.8, {alpha: 0, ease:Power4.easeOut}, "<+.3");
				this.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "<+.7");
		
				this.tl2 = gsap.timeline();	
		
				exportRoot.tl1.pause();
				exportRoot.tl2.pause();
				
				this.startAnim = function() {
					this.tlMaster = gsap.timeline();
					this.tlMaster.to(exportRoot.tl1, {time:exportRoot.tl1.duration(), duration:exportRoot.tl1.duration(), 
					ease:Linear.easeNone},"+=.5");
					this.tlMaster.to(exportRoot.tl2, {time:exportRoot.tl2.duration(), duration:exportRoot.tl2.duration(), 
					ease:SteppedEase.config(exportRoot.tl2.duration()*8)},">-3.45");
				}
				
			mc.logo_intro.gotoAndPlay(1);
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-78.6,109.3,680.9,598.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 320,
	height: 480,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1.png?1622738603244", id:"M365_MobileFY22Q1BTS_USA_320x480_BAN_Outlook_EN_NA_Standard_ANI_LEA_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;