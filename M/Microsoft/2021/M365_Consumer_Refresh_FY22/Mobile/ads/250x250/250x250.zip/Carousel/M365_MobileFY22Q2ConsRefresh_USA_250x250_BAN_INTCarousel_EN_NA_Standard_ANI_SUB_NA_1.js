(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1", frames: [[1102,648,180,53],[1980,548,44,43],[502,502,220,144],[1780,502,198,98],[1980,502,44,44],[0,0,500,500],[1612,502,166,163],[502,0,500,500],[1004,0,500,500],[724,502,220,144],[1780,602,198,98],[1980,593,44,43],[1506,0,500,500],[946,502,220,144],[502,648,198,98],[1980,638,44,43],[1168,502,220,144],[902,648,198,92],[0,502,500,500],[1284,648,44,43],[1390,502,220,144],[702,648,198,98]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Bitmap1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.editorIcon1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Excel_UI111 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Excel_UI_Reflection_3 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.excelIcon1111 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Exchange11 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.icon_shadow = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Mobile250x2501 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.OD = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_UI1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_UI_Reflection_3 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.onedriveIcon11 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Outlook = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_UI1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_UI_Reflection_3 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.outlookIcon1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.PowerPoint_UI1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.PowerPoint_UI_Reflection_3 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.PPT_BG_v0111111 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.pptIcon11 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Word_UI_Reflection1 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Word_UI_Reflection_2 = function() {
	this.initialize(ss["M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtIntro_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.scene5BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OD();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene5BG, new cjs.Rectangle(0,0,300,250), null);


(lib.scene5_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.OneDrive_UI_Reflection_3();
	this.instance.setTransform(-23.05,-14.1,0.9449,0.4941);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene5_UI_Reflection, new cjs.Rectangle(-85.8,-27.4,308.7,76.9), null);


(lib.scene5_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDrive_UI1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene5_UI, new cjs.Rectangle(0,0,220,144), null);


(lib.scene4BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Exchange11();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene4BG, new cjs.Rectangle(0,0,250,250), null);


(lib.scene4_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Word_UI_Reflection_2();
	this.instance.setTransform(-21.2,0.95,0.9285,0.9285);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene4_UI_Reflection, new cjs.Rectangle(-87.4,-9.8,311.9,101.8), null);


(lib.scene4_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Word_UI_Reflection1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene4_UI, new cjs.Rectangle(0,0,220,144), null);


(lib.scene3BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Outlook();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene3BG, new cjs.Rectangle(0,0,250,250), null);


(lib.scene3_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Outlook_UI_Reflection_3();
	this.instance.setTransform(-25.1,-11,0.9661,0.4515);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene3_UI_Reflection, new cjs.Rectangle(-84.5,-11,306.2,59.9), null);


(lib.scene3_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Outlook_UI1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene3_UI, new cjs.Rectangle(0,0,220,144), null);


(lib.scene2BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PPT_BG_v0111111();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene2BG, new cjs.Rectangle(0,0,250,250), null);


(lib.scene2_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.PowerPoint_UI_Reflection_3();
	this.instance.setTransform(-28.05,-1.4,1,0.5016);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene2_UI_Reflection, new cjs.Rectangle(-81.4,-8.7,300.4,94.10000000000001), null);


(lib.scene2_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.PowerPoint_UI1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene2_UI, new cjs.Rectangle(0,0,220,144), null);


(lib.scene1BG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mobile250x2501();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene1BG, new cjs.Rectangle(0,0,250,250), null);


(lib.scene1_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.Excel_UI_Reflection_3();
	this.instance.setTransform(-15.5,1.2,0.8683,0.8683);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene1_UI_Reflection, new cjs.Rectangle(-81,-8.9,300.5,95.2), null);


(lib.scene1_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Excel_UI111();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene1_UI, new cjs.Rectangle(0,0,220,144), null);


(lib.option_hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AhPBRIAAihICfAAIAAAuIAAA6IAAA5g");
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-8.1,16,16.2);


(lib.ms_white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFHA/QgGgHAAgPIAAguIghAAIAABJIgWAAIAAhJIgPAAIAAgSIAPAAIAAgOQAAgOAJgJQAKgJAPAAIAHAAIAFABIAAATIgEgBIgGgBQgGgBgEAFQgEAEAAAJIAAALIAhAAIAAgVIAVgHIAAAcIAWAAIAAASIgWAAIAAAqQAAAIAEADQACAEAHAAIAFgBIAEgCIAAASIgGACIgKABQgOABgHgIgACmA5QgNgMAAgWQAAgWANgNQANgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgVAAgNgNgAC3AAQgHAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAHgIAAgPQAAgPgHgHQgGgHgMAAQgMAAgGAHgABeBFIgMgDIAAgWQAGAEAHACQAHADAFAAQAIAAADgCQAEgCAAgFQAAgEgEgDQgDgEgLgEQgLgEgGgHQgFgGAAgKQAAgMAKgHQAKgJAQAAIALACIAKACIAAAVQgEgDgGgCQgGgCgGAAQgGAAgDACQgEADAAADQAAAEADADQADADAKAEQANAFAGAGQAFAIAAAIQAAANgKAJQgKAHgRAAIgNgBgAgJA5QgNgMAAgWQAAgXANgMQAMgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgWAAgLgNgAAGAAQgGAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAGgIAAgPQAAgPgGgHQgHgHgLAAQgMAAgHAHgAiZA5QgNgMAAgVQAAgVANgPQANgOAYAAQAGAAAHACIAKADIAAAVQgGgEgFgBQgFgCgGAAQgMgBgIAIQgIAJAAANQAAAOAHAJQAIAHANAAQAFAAAGgCIALgGIAAAVQgGACgGABQgHACgIAAQgUAAgNgNgAhNBEIAAhbIAWAAIAAAOIAAAAQADgHAGgFQAGgEAIAAIAFABIAEABIAAAVIgFgCIgIgBQgIAAgGAGQgFAGAAAPIAAAugAjLBEIAAhbIAWAAIAABbgAj2BEIAAhkIgBAAIgoBkIgOAAIgphkIgBAAIAABkIgUAAIAAiAIAgAAIAlBeIAAAAIAoheIAeAAIAACAgAjJgpQgEgEAAgFQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAFgEAEQgEAEgGgBQgFABgEgEg");
	this.shape.setTransform(-0.025,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_white, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.ms_grey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AFHA/QgGgHAAgPIAAguIghAAIAABJIgWAAIAAhJIgPAAIAAgSIAPAAIAAgOQAAgOAJgJQAKgJAPAAIAHAAIAFABIAAATIgEgBIgGgBQgGgBgEAFQgEAEAAAJIAAALIAhAAIAAgVIAVgHIAAAcIAWAAIAAASIgWAAIAAAqQAAAIAEADQACAEAHAAIAFgBIAEgCIAAASIgGACIgKABQgOABgHgIgACmA5QgNgMAAgWQAAgWANgNQANgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgVAAgNgNgAC3AAQgHAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAHgIAAgPQAAgPgHgHQgGgHgMAAQgMAAgGAHgABeBFIgMgDIAAgWQAGAEAHACQAHADAFAAQAIAAADgCQAEgCAAgFQAAgEgEgDQgDgEgLgEQgLgEgGgHQgFgGAAgKQAAgMAKgHQAKgJAQAAIALACIAKACIAAAVQgEgDgGgCQgGgCgGAAQgGAAgDACQgEADAAADQAAAEADADQADADAKAEQANAFAGAGQAFAIAAAIQAAANgKAJQgKAHgRAAIgNgBgAgJA5QgNgMAAgWQAAgXANgMQAMgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgWAAgLgNgAAGAAQgGAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAGgIAAgPQAAgPgGgHQgHgHgLAAQgMAAgHAHgAiZA5QgNgMAAgVQAAgVANgPQANgOAYAAQAGAAAHACIAKADIAAAVQgGgEgFgBQgFgCgGAAQgMgBgIAIQgIAJAAANQAAAOAHAJQAIAHANAAQAFAAAGgCIALgGIAAAVQgGACgGABQgHACgIAAQgUAAgNgNgAhNBEIAAhbIAWAAIAAAOIAAAAQADgHAGgFQAGgEAIAAIAFABIAEABIAAAVIgFgCIgIgBQgIAAgGAGQgFAGAAAPIAAAugAjLBEIAAhbIAWAAIAABbgAj2BEIAAhkIgBAAIgoBkIgOAAIgphkIgBAAIAABkIgUAAIAAiAIAgAAIAlBeIAAAAIAoheIAeAAIAACAgAjJgpQgEgEAAgFQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAFgEAEQgEAEgGgBQgFABgEgEg");
	this.shape.setTransform(-0.025,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_grey, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.introBg_Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(242,242,242,0)","rgba(242,242,242,0.141)","rgba(242,242,242,0.729)","#F2F2F2"],[0,0.173,0.463,1],-25,0,25,0).s().p("Aj5TiMAAAgnDIHzAAMAAAAnDg");
	this.shape.setTransform(25,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AzoTiMAAAgnDMAnRAAAMAAAAnDg");
	this.shape_1.setTransform(175.7,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg_Sub, new cjs.Rectangle(0,0,301.4,250), null);


(lib.icon_shadow_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.icon_shadow();
	this.instance.setTransform(0,0,0.28,0.28);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_shadow_1, new cjs.Rectangle(0,0,46.5,45.7), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_Logo_anim_Grey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.ms_grey.cache(-105,-16,210,32,1.4)
		//this.ms_white.cache(-105,-16,210,32,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// ms_white
	this.ms_white = new lib.ms_white();
	this.ms_white.name = "ms_white";
	this.ms_white.setTransform(13.65,1.05);

	this.timeline.addTween(cjs.Tween.get(this.ms_white).wait(1));

	// ms_grey
	this.ms_grey = new lib.ms_grey();
	this.ms_grey.name = "ms_grey";
	this.ms_grey.setTransform(13.65,1.05);

	this.timeline.addTween(cjs.Tween.get(this.ms_grey).wait(1));

	// ms_win
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_Grey, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.introBG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,350,250,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.introBg_Sub();
	this.sub.name = "sub";
	this.sub.setTransform(175.3,125,1,1,0,0,0,174.8,125);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBG, new cjs.Rectangle(0.5,0,301.4,250), null);


(lib.icon5_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.editorIcon1();
	this.instance.setTransform(7.8,4.8,0.7138,0.7138);

	this.instance_1 = new lib.icon_shadow_1();
	this.instance_1.setTransform(23.2,22.8,1,1,0,0,0,23.2,22.8);
	this.instance_1.alpha = 0.1797;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon5_sub, new cjs.Rectangle(0,0,46.5,45.7), null);


(lib.icon4_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.onedriveIcon11();
	this.instance.setTransform(7.35,4.15,0.7122,0.7122);

	this.instance_1 = new lib.icon_shadow_1();
	this.instance_1.setTransform(23.2,22.8,1,1,0,0,0,23.2,22.8);
	this.instance_1.alpha = 0.1797;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon4_sub, new cjs.Rectangle(0,0,46.5,45.7), null);


(lib.icon3_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.outlookIcon1();
	this.instance.setTransform(7.75,4.55,0.7114,0.7114);

	this.instance_1 = new lib.icon_shadow_1();
	this.instance_1.setTransform(23.2,22.8,1,1,0,0,0,23.2,22.8);
	this.instance_1.alpha = 0.1797;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon3_sub, new cjs.Rectangle(0,0,46.5,45.7), null);


(lib.icon2_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.pptIcon11();
	this.instance.setTransform(7.8,4.7,0.7133,0.7133);

	this.instance_1 = new lib.icon_shadow_1();
	this.instance_1.setTransform(23.2,22.8,1,1,0,0,0,23.2,22.8);
	this.instance_1.alpha = 0.1797;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon2_sub, new cjs.Rectangle(0,0,46.5,45.7), null);


(lib.icon1_sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.excelIcon1111();
	this.instance.setTransform(8.3,4.7,0.713,0.713);

	this.instance_1 = new lib.icon_shadow_1();
	this.instance_1.setTransform(23.2,22.8,1,1,0,0,0,23.2,22.8);
	this.instance_1.alpha = 0.1797;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon1_sub, new cjs.Rectangle(0,0,46.5,45.7), null);


(lib.excelIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon1_sub();
	this.sub.name = "sub";
	this.sub.setTransform(15.4,18.1,1,1,0,0,0,23.2,22.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excelIcon, new cjs.Rectangle(-7.8,-4.7,46.5,45.7), null);


(lib.editorIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon5_sub();
	this.sub.name = "sub";
	this.sub.setTransform(15.4,18.1,1,1,0,0,0,23.2,22.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.editorIcon, new cjs.Rectangle(-7.8,-4.7,46.5,45.7), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.Scene4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.editorIcon();
	this.icon.name = "icon";
	this.icon.setTransform(53.65,92.1,0.8734,0.8734,0,0,0,14.8,14.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene4_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(115.25,225.5,0.9633,0.9633,0,0,0,68.8,45.1);
	this.reflection.alpha = 0.6016;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene4_UI();
	this.ui.name = "ui";
	this.ui.setTransform(89.1,118.2,0.6262,0.625,0,0,0,68.9,45.3);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// Layer_2
	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-46,-32.8,2.1746,1.8208);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// scene1BG
	this.instance_1 = new lib.scene4BG();
	this.instance_1.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene4, new cjs.Rectangle(-46,-32.8,391.4,303.40000000000003), null);


(lib.Scene1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.excelIcon();
	this.icon.name = "icon";
	this.icon.setTransform(52.85,91.7,0.8584,0.8584,0,0,0,14.8,14.6);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene1_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(115.55,209,1.0258,0.5802,0,-3.8107,0,68.9,45.1);
	this.reflection.alpha = 0.6016;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene1_UI();
	this.ui.name = "ui";
	this.ui.setTransform(88.05,118.2,0.624,0.624,0,0,0,69,45.2);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// scene1BG
	this.instance = new lib.scene1BG();
	this.instance.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene1, new cjs.Rectangle(0,0,250,250), null);


(lib.pptIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon2_sub();
	this.sub.name = "sub";
	this.sub.setTransform(15.4,18.1,1,1,0,0,0,23.2,22.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptIcon, new cjs.Rectangle(-7.8,-4.7,46.5,45.7), null);


(lib.outlookIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon3_sub();
	this.sub.name = "sub";
	this.sub.setTransform(15.4,18.1,1,1,0,0,0,23.2,22.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlookIcon, new cjs.Rectangle(-7.8,-4.7,46.5,45.7), null);


(lib.onedriveIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon4_sub();
	this.sub.name = "sub";
	this.sub.setTransform(15.2,17.9,1,1,0,0,0,23.2,22.8);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.onedriveIcon, new cjs.Rectangle(-8,-4.9,46.5,45.699999999999996), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// CTA_arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(185.45,15.95,0.7084,0.65,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#B8B8B8","#EEEEEE","#FFFFFF"],[0,0.616,1],3.2,-43.9,3.2,4.1).s().p("AzhETIAAolMAnDAAAIAAIlg");
	this.shape.setTransform(125,18.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,-9.4,250,55), null);


(lib.Scene5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.onedriveIcon();
	this.icon.name = "icon";
	this.icon.setTransform(53.55,92.85,0.8834,0.8834,0,0,0,14.8,14.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene5_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(115.55,239.9,0.9723,0.9723,0,0,0,68.8,45.1);
	this.reflection.alpha = 0.6016;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene5_UI();
	this.ui.name = "ui";
	this.ui.setTransform(88.8,118.3,0.622,0.6181,0,0,0,68.8,45.1);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// scene1BG
	this.instance = new lib.scene5BG();
	this.instance.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene5, new cjs.Rectangle(0,0,250,250), null);


(lib.Scene3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.outlookIcon();
	this.icon.name = "icon";
	this.icon.setTransform(53.6,92.25,0.8703,0.8703,0,0,0,15,14.8);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene3_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(114.25,239.2,0.9818,0.9818,0,0,0,68.8,45.1);
	this.reflection.alpha = 0.6016;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene3_UI();
	this.ui.name = "ui";
	this.ui.setTransform(89.25,118,0.6203,0.6203,0,0,0,68.9,45.4);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// scene1BG
	this.instance = new lib.scene3BG();
	this.instance.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene3, new cjs.Rectangle(0,0,250,250), null);


(lib.Scene2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.pptIcon();
	this.icon.name = "icon";
	this.icon.setTransform(53.5,92.05,0.876,0.876,0,0,0,15,14.8);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene2_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(114.5,229.65,0.9724,0.9724,0,0,0,68.8,45.1);
	this.reflection.alpha = 0.6016;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene2_UI();
	this.ui.name = "ui";
	this.ui.setTransform(88.6,117.75,0.6217,0.6217,0,0,0,68.9,45.2);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// scene1BG
	this.instance = new lib.scene2BG();
	this.instance.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene2, new cjs.Rectangle(0,0,250,250), null);


(lib.Page_indicator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2).call(this.frame_2).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AzQCkIAApCQOrhmO4AAII+AAIgEQBInyAHIhiABQu9AAuMlhg");
	var mask_graphics_2 = new cjs.Graphics().p("AMUOdIAAvlIJXAAIAAPlg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:155.625,y:133.4713}).wait(2).to({graphics:mask_graphics_2,x:138.6771,y:92.469}).wait(1));

	// onedriveIcon
	this.icon5 = new lib.editorIcon();
	this.icon5.name = "icon5";
	this.icon5.setTransform(245.6,120.35,1,1,0,0,0,14.7,14.6);

	var maskedShapeInstanceList = [this.icon5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.icon5).wait(3));

	// outlookIcon
	this.icon3 = new lib.outlookIcon();
	this.icon3.name = "icon3";
	this.icon3.setTransform(155.65,120.45,1,1,0,0,0,14.7,14.7);

	var maskedShapeInstanceList = [this.icon3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.icon3).wait(3));

	// pptIcon
	this.icon2 = new lib.pptIcon();
	this.icon2.name = "icon2";
	this.icon2.setTransform(110.75,120.35,1,1,0,0,0,14.7,14.6);

	var maskedShapeInstanceList = [this.icon2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.icon2).wait(3));

	// excelIcon
	this.icon1 = new lib.excelIcon();
	this.icon1.name = "icon1";
	this.icon1.setTransform(66.65,123.65,1,1,0,0,0,15.5,17.9);

	var maskedShapeInstanceList = [this.icon1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.icon1).wait(3));

	// editorIcon
	this.icon4 = new lib.onedriveIcon();
	this.icon4.name = "icon4";
	this.icon4.setTransform(200.75,120.55,1,1,0,0,0,14.7,14.6);

	var maskedShapeInstanceList = [this.icon4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.icon4).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(43.4,101.1,226.20000000000002,45.599999999999994);


(lib.bgScreens = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1
	this.img1 = new lib.Scene1();
	this.img1.name = "img1";
	this.img1.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	// img2
	this.img2 = new lib.Scene2();
	this.img2.name = "img2";
	this.img2.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img3
	this.img3 = new lib.Scene3();
	this.img3.name = "img3";
	this.img3.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img4
	this.img4 = new lib.Scene5();
	this.img4.name = "img4";
	this.img4.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img5
	this.img5 = new lib.Scene4();
	this.img5.name = "img5";
	this.img5.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgScreens, new cjs.Rectangle(-46,-32.8,391.4,303.40000000000003), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// hit cta
	this.hitCta = new lib.option_hit();
	this.hitCta.name = "hitCta";
	this.hitCta.setTransform(126.2,222.9,15.7027,3.4295,0,0,0,0.1,0);
	new cjs.ButtonHelper(this.hitCta, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hitCta).wait(1));

	// navHits
	this.hit5 = new lib.option_hit();
	this.hit5.name = "hit5";
	this.hit5.setTransform(226.5,227.5,1.8749,2.7645,90);
	new cjs.ButtonHelper(this.hit5, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit4 = new lib.option_hit();
	this.hit4.name = "hit4";
	this.hit4.setTransform(226.2,194.3,1.8728,2.7645,90,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.hit4, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(226.2,161.65,1.8728,2.7645,90,0,0,-0.1,0.1);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(226.2,124.15,1.8728,2.7645,90,0,0,-0.1,0.1);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(226.2,88.95,1.8751,2.7643,90,0,0,0.1,0.1);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit4},{t:this.hit5}]}).wait(1));

	// nav
	this.nav = new lib.Page_indicator();
	this.nav.name = "nav";
	this.nav.setTransform(117.4,109.65,1.0213,1.0213,0,0,0,147.9,122.4);

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1));

	// hit
	this.hit = new lib.option_hit();
	this.hit.name = "hit";
	this.hit.setTransform(124.65,124.95,15.7027,15.4324);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// txt_Intro
	this.txtIntro = new lib.txtIntro_mc();
	this.txtIntro.name = "txtIntro";
	this.txtIntro.setTransform(70.5,124.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txtIntro).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.5,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo = new lib.MSFT_Logo_anim_Grey();
	this.logo.name = "logo";
	this.logo.setTransform(54.15,23.3,0.75,0.75,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// CTA_txt
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(64.7,222.5,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(0.2,205.7,1,1,0,0,0,0.2,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// introBG
	this.introBG = new lib.introBG();
	this.introBG.name = "introBG";
	this.introBG.setTransform(125,125,1,1,0,0,0,175,125);

	this.timeline.addTween(cjs.Tween.get(this.introBG).wait(1));

	// bgScreens
	this.screens = new lib.bgScreens();
	this.screens.name = "screens";
	this.screens.setTransform(124,94.5,1,1,0,0,0,124,94.5);

	this.timeline.addTween(cjs.Tween.get(this.screens).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F4F4F4","#DBDBDD"],[0,1],63.7,0,0,63.7,0,124.2).s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-49.5,-32.8,394.9,303.40000000000003), null);


// stage content:
(lib.M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		frame0();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9968,0.9997,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("A1F1FMAqLAAAMAAAAqLMgqLAAAg");
	this.shape.setTransform(125,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DBDBDD").s().p("A1FVGMAAAgqLMAqLAAAMAAAAqLg");
	this.shape_1.setTransform(125,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(75.7,92.2,268.6,178.3);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 250,
	height: 250,
	fps: 40,
	color: "#DBDBDD",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1.png?1631288594515", id:"M365_MobileFY22Q2ConsRefresh_USA_250x250_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;