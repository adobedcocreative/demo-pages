(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1", frames: [[0,0,406,649],[1871,604,166,166],[1703,604,166,170],[1400,677,198,98],[1733,0,300,202],[1064,0,315,642],[352,711,198,98],[408,0,334,709],[1064,644,166,166],[1703,458,220,144],[1381,239,320,217],[744,652,166,166],[1600,776,198,98],[1703,239,320,217],[1232,677,166,166],[0,651,350,129],[1381,0,350,237],[744,0,318,650],[1800,776,198,98],[1381,458,320,217]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.editorbg11 = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Editor2x = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Excel2x = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Excel_reflection = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Excel_U = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.excelBG = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.OD_reflections = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ODbg1 = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive2x = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_UI1 = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_UI = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Outlook2x = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_reflection = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_UI = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.PPT2x = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.ppt_reflection2 = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.PPT_UIpngcopy = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.pptbg11 = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Word_reflection = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Wordeditor_UI = function() {
	this.initialize(ss["M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txtIntro_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.scene5_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// reflection
	this.instance = new lib.OD_reflections();
	this.instance.setTransform(25,42.45,0.9543,0.9543);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene5_UI_Reflection, new cjs.Rectangle(25,42.5,189,93.5), null);


(lib.scene5_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.OneDrive_UI();
	this.instance.setTransform(8,2,0.6408,0.6408);

	this.instance_1 = new lib.OneDrive_UI1();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene5_UI, new cjs.Rectangle(0,0,220,144), null);


(lib.scene4_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// reflection
	this.instance = new lib.Word_reflection();
	this.instance.setTransform(21.8,45.4,0.9669,0.9669);

	this.instance_1 = new lib.Word_reflection();
	this.instance_1.setTransform(21.8,45.4,0.9669,0.9669);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene4_UI_Reflection, new cjs.Rectangle(21.8,45.4,191.5,94.79999999999998), null);


(lib.scene4_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Wordeditor_UI();
	this.instance.setTransform(7.85,1.9,0.6434,0.6434);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene4_UI, new cjs.Rectangle(7.9,1.9,205.9,139.6), null);


(lib.scene3_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// reflection
	this.instance = new lib.Outlook_reflection();
	this.instance.setTransform(14.6,40,0.9622,0.9622);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene3_UI_Reflection, new cjs.Rectangle(14.6,40,190.6,94.30000000000001), null);


(lib.scene3_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.instance = new lib.Outlook_UI();
	this.instance.setTransform(42.3,197.75,0.6438,0.6455);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene3_UI, new cjs.Rectangle(42.3,197.8,206,140), null);


(lib.scene2_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// reflection
	this.instance = new lib.ppt_reflection2();
	this.instance.setTransform(-11.45,-1.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene2_UI_Reflection, new cjs.Rectangle(-11.4,-1.8,350,129), null);


(lib.scene1_UI_Reflection = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// reflection
	this.instance = new lib.Excel_reflection();
	this.instance.setTransform(4.95,16.05,0.9245,0.9245);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene1_UI_Reflection, new cjs.Rectangle(5,16.1,183,90.6), null);


(lib.scene1_UI = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.Excel_U();
	this.instance.setTransform(8,3,0.6833,0.6832);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene1_UI, new cjs.Rectangle(8,3,205,138), null);


(lib.option_hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AhPBRIAAihICfAAIAAAuIAAA6IAAA5g");
	this.shape.setTransform(0,11.3,1,2.4122);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-8.2,16,39.099999999999994);


(lib.ms_white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFHA/QgGgHAAgPIAAguIghAAIAABJIgWAAIAAhJIgPAAIAAgSIAPAAIAAgOQAAgOAJgJQAKgJAPAAIAHAAIAFABIAAATIgEgBIgGgBQgGgBgEAFQgEAEAAAJIAAALIAhAAIAAgVIAVgHIAAAcIAWAAIAAASIgWAAIAAAqQAAAIAEADQACAEAHAAIAFgBIAEgCIAAASIgGACIgKABQgOABgHgIgACmA5QgNgMAAgWQAAgWANgNQANgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgVAAgNgNgAC3AAQgHAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAHgIAAgPQAAgPgHgHQgGgHgMAAQgMAAgGAHgABeBFIgMgDIAAgWQAGAEAHACQAHADAFAAQAIAAADgCQAEgCAAgFQAAgEgEgDQgDgEgLgEQgLgEgGgHQgFgGAAgKQAAgMAKgHQAKgJAQAAIALACIAKACIAAAVQgEgDgGgCQgGgCgGAAQgGAAgDACQgEADAAADQAAAEADADQADADAKAEQANAFAGAGQAFAIAAAIQAAANgKAJQgKAHgRAAIgNgBgAgJA5QgNgMAAgWQAAgXANgMQAMgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgWAAgLgNgAAGAAQgGAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAGgIAAgPQAAgPgGgHQgHgHgLAAQgMAAgHAHgAiZA5QgNgMAAgVQAAgVANgPQANgOAYAAQAGAAAHACIAKADIAAAVQgGgEgFgBQgFgCgGAAQgMgBgIAIQgIAJAAANQAAAOAHAJQAIAHANAAQAFAAAGgCIALgGIAAAVQgGACgGABQgHACgIAAQgUAAgNgNgAhNBEIAAhbIAWAAIAAAOIAAAAQADgHAGgFQAGgEAIAAIAFABIAEABIAAAVIgFgCIgIgBQgIAAgGAGQgFAGAAAPIAAAugAjLBEIAAhbIAWAAIAABbgAj2BEIAAhkIgBAAIgoBkIgOAAIgphkIgBAAIAABkIgUAAIAAiAIAgAAIAlBeIAAAAIAoheIAeAAIAACAgAjJgpQgEgEAAgFQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAFgEAEQgEAEgGgBQgFABgEgEg");
	this.shape.setTransform(-0.025,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_white, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.ms_grey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AFHA/QgGgHAAgPIAAguIghAAIAABJIgWAAIAAhJIgPAAIAAgSIAPAAIAAgOQAAgOAJgJQAKgJAPAAIAHAAIAFABIAAATIgEgBIgGgBQgGgBgEAFQgEAEAAAJIAAALIAhAAIAAgVIAVgHIAAAcIAWAAIAAASIgWAAIAAAqQAAAIAEADQACAEAHAAIAFgBIAEgCIAAASIgGACIgKABQgOABgHgIgACmA5QgNgMAAgWQAAgWANgNQANgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgVAAgNgNgAC3AAQgHAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAHgIAAgPQAAgPgHgHQgGgHgMAAQgMAAgGAHgABeBFIgMgDIAAgWQAGAEAHACQAHADAFAAQAIAAADgCQAEgCAAgFQAAgEgEgDQgDgEgLgEQgLgEgGgHQgFgGAAgKQAAgMAKgHQAKgJAQAAIALACIAKACIAAAVQgEgDgGgCQgGgCgGAAQgGAAgDACQgEADAAADQAAAEADADQADADAKAEQANAFAGAGQAFAIAAAIQAAANgKAJQgKAHgRAAIgNgBgAgJA5QgNgMAAgWQAAgXANgMQAMgNAXAAQAWAAAMAMQAMANAAAWQAAAWgNANQgNANgWAAQgWAAgLgNgAAGAAQgGAIAAAOQAAAPAGAIQAHAHAMAAQAMAAAGgHQAGgIAAgPQAAgPgGgHQgHgHgLAAQgMAAgHAHgAiZA5QgNgMAAgVQAAgVANgPQANgOAYAAQAGAAAHACIAKADIAAAVQgGgEgFgBQgFgCgGAAQgMgBgIAIQgIAJAAANQAAAOAHAJQAIAHANAAQAFAAAGgCIALgGIAAAVQgGACgGABQgHACgIAAQgUAAgNgNgAhNBEIAAhbIAWAAIAAAOIAAAAQADgHAGgFQAGgEAIAAIAFABIAEABIAAAVIgFgCIgIgBQgIAAgGAGQgFAGAAAPIAAAugAjLBEIAAhbIAWAAIAABbgAj2BEIAAhkIgBAAIgoBkIgOAAIgphkIgBAAIAABkIgUAAIAAiAIAgAAIAlBeIAAAAIAoheIAeAAIAACAgAjJgpQgEgEAAgFQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAFgEAEQgEAEgGgBQgFABgEgEg");
	this.shape.setTransform(-0.025,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms_grey, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(0.175,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.introBg_Sub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(242,242,242,0)","rgba(242,242,242,0.141)","rgba(242,242,242,0.729)","#F2F2F2"],[0,0.173,0.463,1],-25,0,25,0).s().p("EgD5Au4MAAAhdvIHzAAMAAABdvg");
	this.shape.setTransform(25,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("EgXYAu4MAAAhdvMAuxAAAMAAABdvg");
	this.shape_1.setTransform(199.75,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBg_Sub, new cjs.Rectangle(0,0,349.5,600), null);


(lib.icon5b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Editor2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon5b, new cjs.Rectangle(0,0,83,83), null);


(lib.icon4b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.OneDrive2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon4b, new cjs.Rectangle(0,0,83,83), null);


(lib.icon3b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Outlook2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon3b, new cjs.Rectangle(0,0,83,83), null);


(lib.icon2b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.PPT2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon2b, new cjs.Rectangle(0,0,83,83), null);


(lib.icon1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Excel2x();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon1b, new cjs.Rectangle(0,0,83,85), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgNAqIAfgfIhJAAIAAgUIBJAAIggggIAaAAIAsApIgsAqg");
	this.shape.setTransform(5.625,4.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.pptIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon2b();
	this.sub.name = "sub";
	this.sub.setTransform(0,0,1,1,0,0,0,41.5,41.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pptIcon, new cjs.Rectangle(-41.5,-41.5,83,83), null);


(lib.outlookIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon3b();
	this.sub.name = "sub";
	this.sub.setTransform(0,0,1,1,0,0,0,41.5,41.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.outlookIcon, new cjs.Rectangle(-41.5,-41.5,83,83), null);


(lib.onedriveIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon4b();
	this.sub.name = "sub";
	this.sub.setTransform(0,0,1,1,0,0,0,41.5,41.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.onedriveIcon, new cjs.Rectangle(-41.5,-41.5,83,83), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_Logo_anim_Grey = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// ms_white
	this.ms_white = new lib.ms_white();
	this.ms_white.name = "ms_white";
	this.ms_white.setTransform(13.65,1.05);

	this.timeline.addTween(cjs.Tween.get(this.ms_white).wait(1));

	// ms_grey
	this.ms_grey = new lib.ms_grey();
	this.ms_grey.name = "ms_grey";
	this.ms_grey.setTransform(13.65,1.05);

	this.timeline.addTween(cjs.Tween.get(this.ms_grey).wait(1));

	// ms_win
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_Grey, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.introBG = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.sub.cache(0,0,350,600,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.sub = new lib.introBg_Sub();
	this.sub.name = "sub";
	this.sub.setTransform(175.3,125,1,1,0,0,0,174.8,125);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.introBG, new cjs.Rectangle(0.5,0,349.5,600), null);


(lib.excelIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon1b();
	this.sub.name = "sub";
	this.sub.setTransform(0,1,1,1,0,0,0,41.5,42.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excelIcon, new cjs.Rectangle(-41.5,-41.5,83,85), null);


(lib.editorIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.sub = new lib.icon5b();
	this.sub.name = "sub";
	this.sub.setTransform(0,0,1,1,0,0,0,41.5,41.5);

	this.timeline.addTween(cjs.Tween.get(this.sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.editorIcon, new cjs.Rectangle(-41.5,-41.5,83,83), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(11,11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.8,0.8,20.5,20.5);


(lib.Scene5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.onedriveIcon();
	this.icon.name = "icon";
	this.icon.setTransform(67.45,225.4,0.6389,0.6389,0,0,0,14.8,14.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene5_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(73.95,384.7,1.6084,1.08,0,0,0,68.8,45.1);
	this.reflection.alpha = 0.5;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene5_UI();
	this.ui.name = "ui";
	this.ui.setTransform(109.95,255.3,1.0601,1.0601,0,0,0,68.8,45.1);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXvAvCMAAAheDMAvfAAAMAAABeDg");
	mask.setTransform(150,299);

	// new bg
	this.instance = new lib.ODbg1();
	this.instance.setTransform(-4.1,-61.45);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene5, new cjs.Rectangle(-2,-2,309.4,602), null);


(lib.Scene4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.editorIcon();
	this.icon.name = "icon";
	this.icon.setTransform(67.45,225.4,0.6389,0.6389,0,0,0,14.8,14.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene4_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(78.75,370.45,1.5209,1.08,0,0,0,68.6,45.1);
	this.reflection.alpha = 0.5;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene4_UI();
	this.ui.name = "ui";
	this.ui.setTransform(109.95,255.4,1.0602,1.0598,0,0,0,68.8,45.2);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXvAvCMAAAheDMAvfAAAMAAABeDg");
	mask.setTransform(150,299);

	// new bg
	this.instance = new lib.editorbg11();
	this.instance.setTransform(-47.75,-12.25);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene4, new cjs.Rectangle(-2,-2,304,602), null);


(lib.Scene3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.outlookIcon();
	this.icon.name = "icon";
	this.icon.setTransform(67.45,225.4,0.6389,0.6389,0,0,0,14.8,14.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene3_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(88.55,388,1.6084,1.0799,0,0,0,68.8,45.1);
	this.reflection.alpha = 0.5;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene3_UI();
	this.ui.name = "ui";
	this.ui.setTransform(73.05,48.1,1.0599,1.0597,0,0,0,68.9,45.4);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXvAvCMAAAheDMAvfAAAMAAABeDg");
	mask.setTransform(150,299);

	// new bg
	this.instance = new lib.ODbg1();
	this.instance.setTransform(-4.1,-61.45);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene3, new cjs.Rectangle(-2,-2,309.9,602), null);


(lib.Scene2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.pptIcon();
	this.icon.name = "icon";
	this.icon.setTransform(67.45,225.4,0.6389,0.6389,0,0,0,14.8,14.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene2_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(155.3,406.85,1.6198,1.08,0,0,0,163.9,67.4);
	this.reflection.alpha = 0.5;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.instance = new lib.PPT_UIpngcopy();
	this.instance.setTransform(46,209,0.6228,0.6203);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXvAvCMAAAheDMAvfAAAMAAABeDg");
	mask.setTransform(150,299);

	// new bg
	this.instance_1 = new lib.pptbg11();
	this.instance_1.setTransform(-16.45,-6);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene2, new cjs.Rectangle(-128.7,-2,566.9,602), null);


(lib.Scene1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// icon
	this.icon = new lib.excelIcon();
	this.icon.name = "icon";
	this.icon.setTransform(58.05,216.1,0.6387,0.6231,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// reflection
	this.reflection = new lib.scene1_UI_Reflection();
	this.reflection.name = "reflection";
	this.reflection.setTransform(110.8,397.85,1.6532,1.08,0,0,0,68.6,45.1);
	this.reflection.alpha = 0.5;
	this.reflection.compositeOperation = "hard-light";

	this.timeline.addTween(cjs.Tween.get(this.reflection).wait(1));

	// ui
	this.ui = new lib.scene1_UI();
	this.ui.name = "ui";
	this.ui.setTransform(37.1,207.8,1.06,1.06,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgXvAvCMAAAheDMAvfAAAMAAABeDg");
	mask.setTransform(150,299);

	// new bg
	this.instance = new lib.excelBG();
	this.instance.setTransform(-8.75,-6.2);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Scene1, new cjs.Rectangle(-2,-2,310.2,602), null);


(lib.Page_indicator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// excelIcon
	this.icon1 = new lib.excelIcon();
	this.icon1.name = "icon1";
	this.icon1.setTransform(150.35,127.3,0.986,0.986);

	this.timeline.addTween(cjs.Tween.get(this.icon1).wait(1));

	// pptIcon
	this.icon2 = new lib.pptIcon();
	this.icon2.name = "icon2";
	this.icon2.setTransform(150.35,216.2);

	this.timeline.addTween(cjs.Tween.get(this.icon2).wait(1));

	// outlookIcon
	this.icon3 = new lib.outlookIcon();
	this.icon3.name = "icon3";
	this.icon3.setTransform(150.35,303.7);

	this.timeline.addTween(cjs.Tween.get(this.icon3).wait(1));

	// oneDriveIcon
	this.icon4 = new lib.onedriveIcon();
	this.icon4.name = "icon4";
	this.icon4.setTransform(150.35,391.2);

	this.timeline.addTween(cjs.Tween.get(this.icon4).wait(1));

	// editorIcon
	this.icon5 = new lib.editorIcon();
	this.icon5.name = "icon5";
	this.icon5.setTransform(150.35,478.7);

	this.timeline.addTween(cjs.Tween.get(this.icon5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_indicator, new cjs.Rectangle(0,0,300,600), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// CTA_arrow
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(199.1,15.95,0.7084,0.65,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#B8B8B8","#EEEEEE","#FFFFFF"],[0,0.616,1],4.1,-39.2,4.1,3.7).s().p("A3bD2IAAnrMAu3AAAIAAHrg");
	this.shape.setTransform(150,13.525);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,-11,300,49.1), null);


(lib.bgScreens = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img1
	this.img1 = new lib.Scene1();
	this.img1.name = "img1";
	this.img1.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img1).wait(1));

	// img2
	this.img2 = new lib.Scene2();
	this.img2.name = "img2";
	this.img2.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img2).wait(1));

	// img3
	this.img3 = new lib.Scene3();
	this.img3.name = "img3";
	this.img3.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img3).wait(1));

	// img4
	this.img4 = new lib.Scene5();
	this.img4.name = "img4";
	this.img4.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img4).wait(1));

	// img5
	this.img5 = new lib.Scene4();
	this.img5.name = "img5";
	this.img5.setTransform(600,500,1,1,0,0,0,600,500);

	this.timeline.addTween(cjs.Tween.get(this.img5).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgScreens, new cjs.Rectangle(-128.7,-61.4,566.9,709), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// navHits
	this.hit5 = new lib.option_hit();
	this.hit5.name = "hit5";
	this.hit5.setTransform(279.3,396.15,3.0025,2.3652,90,0,0,0,0.1);
	new cjs.ButtonHelper(this.hit5, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit4 = new lib.option_hit();
	this.hit4.name = "hit4";
	this.hit4.setTransform(279.3,349,3.0009,2.3652,90,0,0,0,0.1);
	new cjs.ButtonHelper(this.hit4, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(279.3,301.55,3.001,2.3652,90,0,0,-0.1,0.1);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(279.3,254.4,3.001,2.3652,90,0,0,-0.1,0.1);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(279.3,207.55,2.9988,2.3652,90,0,0,0,0.1);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit4},{t:this.hit5}]}).wait(1));

	// nav
	this.nav = new lib.Page_indicator();
	this.nav.name = "nav";
	this.nav.setTransform(147.9,122.4,1,1,0,0,0,147.9,122.4);

	this.timeline.addTween(cjs.Tween.get(this.nav).wait(1));

	// hit
	this.hit = new lib.option_hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,124.95,18.7497,15.4324);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// txt_Intro
	this.txtIntro = new lib.txtIntro_mc();
	this.txtIntro.name = "txtIntro";
	this.txtIntro.setTransform(70.5,124.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txtIntro).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo = new lib.MSFT_Logo_anim_Grey();
	this.logo.name = "logo";
	this.logo.setTransform(71.2,39.35,0.75,0.75,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	// CTA_txt
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(0.2,576.5,1,1,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(0.2,562.7,1,1,0,0,0,0.2,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// introBG
	this.introBG = new lib.introBG();
	this.introBG.name = "introBG";
	this.introBG.setTransform(125,125,1,1,0,0,0,175,125);

	this.timeline.addTween(cjs.Tween.get(this.introBG).wait(1));

	// bgScreens
	this.screens = new lib.bgScreens();
	this.screens.name = "screens";
	this.screens.setTransform(124,94.5,1,1,0,0,0,124,94.5);

	this.timeline.addTween(cjs.Tween.get(this.screens).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F4F4F4","#DBDBDD"],[0,1],63.7,0,0,63.7,0,124.2).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-335.6,-61.4,773.8,709), null);


// stage content:
(lib.M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		frame0();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9968,0.9997,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	// stageBackground
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(0,0,0,0)").ss(1,1,1,3,true).p("EgY/gwbMAx/AAAMAAABg3Mgx/AAAg");
	this.shape.setTransform(150,300);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DBDBDD").s().p("EgY/AwcMAAAhg3MAx/AAAMAAABg3g");
	this.shape_1.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(21.7,238.6,415.1,408.79999999999995);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#DBDBDD",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1.png?1631281635273", id:"M365_FY22Q2ConsRefresh_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_SUB_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;