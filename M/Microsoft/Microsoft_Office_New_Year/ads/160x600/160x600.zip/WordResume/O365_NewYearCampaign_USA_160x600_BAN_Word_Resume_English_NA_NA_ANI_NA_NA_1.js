(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[355,117,336,51],[0,0,757,115],[0,117,353,196],[759,0,45,45]]}
];


// symbols:



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.laptopshadow = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.mobile_phone_300x600 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Word_icon = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.topbar_cache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// txt
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#535150").s().p("AhHBMIgBgEIACgDIAGgHIAwg0QgFgGgEgIQgDgHgBgLIABgOQACgGADgGIAIgLQAEgFAGgDQAFgEAGgCQAHgCAGAAQAHgBAHACIANAFIAKAHIAJAKQAEAHABAFQADAIAAAGIgBAOIgFAMQgDAFgFAFQgEAFgGADIgMAGIgOACQgHABgKgDQgJgDgGgFIg3A7QAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAIgEgBgAAUhCQgIAAgJAEQgFADgHAHQgFAGgDAHQgDAHAAAKQABAJADAHQAEAHAGAFQAFAFAIADQAHADAJAAQAKgBAGgDQAJgEAEgFQAGgGADgHQADgIgBgJQAAgIgEgIQgDgHgGgGQgFgFgJgDQgHgDgHAAIgCAAg");
	this.shape.setTransform(-23.8507,104.9949,0.1236,0.1236);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhMgmICZAAIhNBNg");
	this.shape_1.setTransform(-15.8,100.25,0.1594,0.1594,0,0,0,-0.5,-0.1);

	this.txt17 = new cjs.Text("Search", "2px 'Segoe Pro'", "#545251");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 6;
	this.txt17.lineWidth = 6;
	this.txt17.parent = this;
	this.txt17.setTransform(-21.95,105.5);

	this.txt16 = new cjs.Text("Help", "2px 'Segoe Pro'", "#545251");
	this.txt16.name = "txt16";
	this.txt16.textAlign = "center";
	this.txt16.lineHeight = 6;
	this.txt16.lineWidth = 6;
	this.txt16.parent = this;
	this.txt16.setTransform(-30.0989,105.5);

	this.txt14 = new cjs.Text("View", "2px 'Segoe Pro'", "#545251");
	this.txt14.name = "txt14";
	this.txt14.textAlign = "center";
	this.txt14.lineHeight = 6;
	this.txt14.lineWidth = 6;
	this.txt14.parent = this;
	this.txt14.setTransform(-37.0989,105.5);

	this.txt6 = new cjs.Text("Home", "2px 'Segoe Pro'", "#545251");
	this.txt6.name = "txt6";
	this.txt6.textAlign = "center";
	this.txt6.lineHeight = 6;
	this.txt6.lineWidth = 6;
	this.txt6.parent = this;
	this.txt6.setTransform(-113.7989,105.5);

	this.txt8 = new cjs.Text("Draw", "2px 'Segoe Pro'", "#545251");
	this.txt8.name = "txt8";
	this.txt8.textAlign = "center";
	this.txt8.lineHeight = 6;
	this.txt8.lineWidth = 6;
	this.txt8.parent = this;
	this.txt8.setTransform(-98.1489,105.5);

	this.txt7 = new cjs.Text("Insert", "2px 'Segoe Pro'", "#545251");
	this.txt7.name = "txt7";
	this.txt7.textAlign = "center";
	this.txt7.lineHeight = 6;
	this.txt7.lineWidth = 6;
	this.txt7.parent = this;
	this.txt7.setTransform(-105.7489,105.5);

	this.txt5 = new cjs.Text("File", "2px 'Segoe Pro'", "#545251");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 6;
	this.txt5.lineWidth = 6;
	this.txt5.parent = this;
	this.txt5.setTransform(-123.65,105.5);

	this.txt13 = new cjs.Text("Review", "2px 'Segoe Pro'", "#545251");
	this.txt13.name = "txt13";
	this.txt13.textAlign = "center";
	this.txt13.lineHeight = 6;
	this.txt13.lineWidth = 6;
	this.txt13.parent = this;
	this.txt13.setTransform(-44.849,105.5);

	this.txt12 = new cjs.Text("Mailings", "2px 'Segoe Pro'", "#545251");
	this.txt12.name = "txt12";
	this.txt12.textAlign = "center";
	this.txt12.lineHeight = 6;
	this.txt12.lineWidth = 8;
	this.txt12.parent = this;
	this.txt12.setTransform(-55.149,105.5);

	this.txt9 = new cjs.Text("Design", "2px 'Segoe Pro'", "#545251");
	this.txt9.name = "txt9";
	this.txt9.textAlign = "center";
	this.txt9.lineHeight = 6;
	this.txt9.lineWidth = 6;
	this.txt9.parent = this;
	this.txt9.setTransform(-89.8489,105.5);

	this.txt10 = new cjs.Text("Layout", "2px 'Segoe Pro'", "#545251");
	this.txt10.name = "txt10";
	this.txt10.textAlign = "center";
	this.txt10.lineHeight = 6;
	this.txt10.lineWidth = 6;
	this.txt10.parent = this;
	this.txt10.setTransform(-79.5489,105.5);

	this.txt11 = new cjs.Text("References", "2px 'Segoe Pro'", "#545251");
	this.txt11.name = "txt11";
	this.txt11.textAlign = "center";
	this.txt11.lineHeight = 6;
	this.txt11.lineWidth = 10;
	this.txt11.parent = this;
	this.txt11.setTransform(-67.199,105.5);

	this.txt4 = new cjs.Text("Aimee Owens", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 4;
	this.txt4.lineWidth = 17;
	this.txt4.parent = this;
	this.txt4.setTransform(16.8,101.55);

	this.txt3 = new cjs.Text("Aimee-Owens-Resume.docx - Saved to OneDrive", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.textAlign = "center";
	this.txt3.lineHeight = 5;
	this.txt3.lineWidth = 43;
	this.txt3.parent = this;
	this.txt3.setTransform(-39.0989,101.05);

	this.txt2 = new cjs.Text("On", "1px 'Segoe Pro'", "#1D60BF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 3;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(-114.7,101.55);

	this.txt1 = new cjs.Text("AutoSave", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 4;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(-123.1,101.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D60BF").s().p("AAAAxIAAhhIAAAAIAABhg");
	this.shape_2.setTransform(51.625,97.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt11},{t:this.txt10},{t:this.txt9},{t:this.txt12},{t:this.txt13},{t:this.txt5},{t:this.txt7},{t:this.txt8},{t:this.txt6},{t:this.txt14},{t:this.txt16},{t:this.txt17},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// icons
	this.txt18 = new cjs.Text("Share", "2px 'Segoe Pro'", "#1D60BF");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 5;
	this.txt18.lineWidth = 6;
	this.txt18.parent = this;
	this.txt18.setTransform(30.1,106.2);

	this.txt19 = new cjs.Text("Comments", "2px 'Segoe Pro'", "#1D60BF");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 5;
	this.txt19.lineWidth = 8;
	this.txt19.parent = this;
	this.txt19.setTransform(40.1,106.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D60BF").s().p("AgEAEIgCAAIAAgKIANAAIAAAKIgIAAIgDADgAgGADIADAAIAAACIACgCIAHAAIAAgIIgMAAg");
	this.shape_3.setTransform(38.6,105.425);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#EDEAE8").s().p("Ag/AQIgCgBIgBgBIAAgbIABgBIACgBIB/AAIACABIABABIAAAbIgBABIgCABgAhAgNIAAAbIAAABICAAAIABAAIAAgBIAAgbQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIh/AAQgBAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAg");
	this.shape_4.setTransform(43.425,105.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AnTB4QgIAAgGgGQgGgGAAgIIAAjHQAAgJAGgFQAGgGAIAAIOnAAQAIAAAGAGQAGAFAAAJIAADHQAAAIgGAGQgGAGgIAAg");
	this.shape_5.setTransform(43.3757,105.3819,0.137,0.137);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D60BF").s().p("AAGAUIgPABIgOAFIgNAHQgIAFgEAFIAAgIQAAgIACgGIAFgOIAJgKIALgIQAHgEAGgCQAGgCAIAAIAAgXIArAqIgrArgAgFgKIgHADIgJAFIgJAHIgGAKIgDALQAIgGAOgFQALgDAMAAIAIAAIAAAMIAYgYIgYgXIAAAMIgOAAg");
	this.shape_6.setTransform(28.452,105.0976,0.137,0.137);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D60BF").s().p("AgyAoIAAhPIAGAAIAABIIBZAAIAAgoIAFAAIAAAvg");
	this.shape_7.setTransform(28.1883,105.7073,0.137,0.137);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EDEAE8").s().p("Ak7B4QgIAAgGgGQgGgFAAgJIAAjHQAAgIAGgGQAGgGAIAAIJ3AAQAIAAAGAGQAGAGAAAIIAADHQAAAJgGAFQgGAGgIAAgAlChqQgDADAAAEIAADHQAAAEADADQADADAEAAIJ3AAQAEAAADgDQADgDAAgEIAAjHQAAgEgDgDQgDgDgEAAIp3AAQgEAAgDADg");
	this.shape_8.setTransform(30.7095,105.4253,0.1368,0.1368);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ak7B4QgIAAgGgGQgGgFAAgJIAAjHQAAgIAGgGQAGgGAIAAIJ3AAQAIAAAGAGQAGAGAAAIIAADHQAAAJgGAFQgGAGgIAAg");
	this.shape_9.setTransform(30.7095,105.4253,0.1368,0.1368);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAAAGIgrAsIgGgGIAsgsIgsgrIAGgGIArAtIAsgtIAGAGIgtArIAtAsIgGAGg");
	this.shape_10.setTransform(49.169,100.7549,0.1438,0.1438,0,180,0);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgzAFIAAgJIBoAAIAAAJg");
	this.shape_11.setTransform(36.8798,100.683,0.1438,0.1438,0,180,0);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdAFIAAgJIA7AAIAAAJg");
	this.shape_12.setTransform(-91.9283,100.1843,0.1925,0.1925,0,0,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgdgOIA7AAIgeAdg");
	this.shape_13.setTransform(-91.9283,100.9544,0.1925,0.1925,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FCFCFC").s().p("AgHAMIABAAIgXgXIAHgHIAWAWIAYgWIAHAHIgfAeg");
	this.shape_14.setTransform(-94.4175,100.6195,0.1299,0.1299);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FCFCFC").s().p("AgFBdQgKgCgGgIQgFgFgDgLQgHgUgIgNIgCgEQgKgQAEgHQADgGAJAAQAJAAAIAGIAAgEQgRgDgLgNQgMgOAAgSQAAgUAPgPQAOgPAVAAQATAAAPAPQAPAPAAAUQAAAJgDAHIgKAAQAEgIAAgIQAAgRgMgMQgMgMgQAAQgRAAgMAMQgMAMAAARQAAAOAJALQAIALAOADIAAgVQgBgMADgFQADgGAHgCQAIgCAFAFQAJAFgBARIgBASIAJABQAFACADAEQAEgCAFACQAHABADAGQAFABAGAEQAGAGABAKQABAHgCAOIgBAGQgCASgFAKQgFAMgUACIgLABQgOAAgJgDgAgsAMQAAABADAFIAEAHIACAEQAHANAIAWQADAJADAEQAEAFAHACQARADAOgCQAOgBADgHQAFgLABgOIABgHQACgNgBgFQAAgHgDgDIgFgCIgGAHIgCgKQgBgFgEgBQgBAAAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAIgIAIIgBgLQgBgDgEgBQgEAAgCABIgIAJIAAgmQABgKgDgDQgDgCgEABIgEACQgBADABAJIAAA/IgJgMQgIgMgKAAg");
	this.shape_15.setTransform(-96.2742,100.6942,0.1299,0.1299);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhAAyIAAhjICBAAIAABjgAg5AqIByAAIAAhTIhyAAg");
	this.shape_16.setTransform(31.1551,100.6101,0.1329,0.1329);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgEAjIAAgwIgQAOIgHgGIAbgdIAcAdIgHAGIgQgOIAAAwg");
	this.shape_17.setTransform(31.1518,100.7763,0.1329,0.1329);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag9AFIAAgJIB8AAIAAAJg");
	this.shape_18.setTransform(31.1551,100.2778,0.1329,0.1329);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgxAyIAAhPIAUAAIAAgUIBPAAIAABPIgUAAIAAAUgAgpAqIBAAAIAAg/IhAAAgAgWgdIA0AAIAAA0IAMAAIAAhAIhAAAg");
	this.shape_19.setTransform(43.253,100.6101,0.1329,0.1329);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("rgba(255,255,255,0.498)").s().p("AgdgOIA7AAIgeAdg");
	this.shape_20.setTransform(-102.0759,100.674,0.1299,0.1299);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("rgba(255,255,255,0.498)").s().p("AgUBOQgMgEgHgFQgHgEgJgIQgIgHgFgJQgFgJgDgKQgDgLAAgLQAAgKADgKQADgMAGgHQAFgLAHgGQAHgGALgHIgqAAIAAgKIA8AAIAAA8IgKAAIAAgrQgJAFgIAGQgGAGgGAJQgFAHgDAKQgDAKAAAJQAAAJADAKQADALADAFQAFAIAHAHQAGAGAIAEQAIAFAIADQAIACAKAAQALAAAHgCQAIgDAJgFQAJgFAGgFQAFgFAGgKQAFgHACgJQACgIAAgLQAAgLgDgKQgEgLgHgJQgIgJgIgHQgJgFgMgEIADgKQAOAEAJAHQAKAHAJALQAHAKAFANQAEANAAALQAAAKgCAMQgDAIgGALQgEAHgJAJQgHAIgIAEQgJAFgKAEQgJACgNAAQgMAAgIgCg");
	this.shape_21.setTransform(-99.3991,100.9014,0.1299,0.1299);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("rgba(255,255,255,0.498)").s().p("AgSBJIBChCQAFgGAEgHQAEgKAAgHQAAgJgEgJQgDgGgHgJQgFgFgJgEQgIgDgKAAQgJgBgGADQgEACgHAFIgqApIA1AAIAAAKIhGAAIAAhGIAKAAIAAA1IAlglIAIgHIAJgFIAJgDQAGgCAGAAQAGAAAJACQAHADAGADQAIAFADAEQAGAFADAGIAGANQACAGAAAJQAAAKgEAKQgFAJgHAIIhBBCg");
	this.shape_22.setTransform(-103.9309,100.8689,0.1299,0.1299);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Ag7BQIgUgVIAAiKICfAAIAACfgAAnAVIAAAwIAeAAIAAiJIgUAAIAAA+IhjAAIAAg+IgSAAIAAB7IAPAOIAPAAIAAgwgAgbBFIA3AAIAAgkIg3AAgAgngSIBNAAIAAgyIhNAAg");
	this.shape_23.setTransform(-107.7545,100.8689,0.1299,0.1299);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgOALQgEAAgEgEQgCgDAAgEQAAgEACgDQAEgDAEAAIAdAAQAEAAADADQADADAAAEQAAAEgDADQgDAEgEAAgAAMgDQgBABAAAAQAAAAgBABQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAABQABAAAAAAQAAABABAAQAAABAAAAQABAAAAAAQABABAAAAQABAAAAAAQABAAAAAAQAAAAABgBQAAAAABAAQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQgBAAAAAAQgBgBAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBABQAAAAAAAAg");
	this.shape_24.setTransform(-113.3,100.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.txt19},{t:this.txt18}]}).wait(1));

	// bg
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#F3F2F1").s().p("AuDAWIAAgrIcIAAIAAArg");
	this.shape_25.setTransform(-37.5,105.275);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#1D60BF").s().p("AuDAzIAAhlIcIAAIAABlg");
	this.shape_26.setTransform(-37.5,97.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.topbar_cache, new cjs.Rectangle(-127.5,92.8,180.1,21.400000000000006), null);


(lib.shadowcache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.laptopshadow();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.2549,1.2549);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadowcache, new cjs.Rectangle(0,0,950,144.3), null);


(lib.scrollbar_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#5E605F").s().p("AgrgVIBXAAIgsArg");
	this.shape.setTransform(1.15,1.05,0.1416,0.1412,180,0,0,-0.3,-0.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#ABABAB").ss(0.2).p("AhJhEICTAAIAACJIiTAAg");
	this.shape_1.setTransform(1.15,1,0.1416,0.1412,180,0,0,-0.3,-0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhJBFIAAiJICTAAIAACJg");
	this.shape_2.setTransform(1.15,1,0.1416,0.1412,180,0,0,-0.3,-0.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#5E605F").s().p("AgrgVIBXAAIgsArg");
	this.shape_3.setTransform(1.1,79.75,0.1416,0.1412,0,0,0,-0.3,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#ABABAB").ss(0.2).p("AhJhEICTAAIAACJIiTAAg");
	this.shape_4.setTransform(1.1,79.75,0.1416,0.1412,0,0,0,-0.3,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhJBFIAAiJICTAAIAACJg");
	this.shape_5.setTransform(1.1,79.75,0.1416,0.1412,0,0,0,-0.3,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#D2D2D2").ss(0.2).p("ABGffIiLAAMAAAg+9ICLAAg");
	this.shape_6.setTransform(1.05,16.15,0.1416,0.0633,0,0,0,-0.4,2.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWKTIAA0lIAtAAIAAUlg");
	this.shape_7.setTransform(1.1,16.15,0.4329,0.1938,0,0,0,0.3,1.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#DBDBDB").s().p("EgBLApHMAAAhSNICYAAMAAABSNg");
	this.shape_8.setTransform(1,40.6,0.1416,0.1471,0,0,0,-0.3,-1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.scrollbar_c, new cjs.Rectangle(-0.9,-1,4.2,82.7), null);


(lib.Ready_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Page 4 of 5 818 words", "2px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 4;
	this.txt.lineWidth = 24;
	this.txt.parent = this;
	this.txt.setTransform(1.65,11.05);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Ready_txt, new cjs.Rectangle(-0.3,9.1,27.5,12.1), null);


(lib.pwrd_by_lkndn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAIAWIAAgXQAAgKgIAAQgCAAgCADQgCADgBAEIAAAXIgMAAIAAgqIAMAAIAAAHIABAAQAEgIAJAAQANAAAAASIAAAZg");
	this.shape.setTransform(10.7822,0.5518,0.1338,0.1338);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgGAeIAAg7IANAAIAAA7g");
	this.shape_1.setTransform(10.2504,0.4448,0.1338,0.1338);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgQAaQgFgEAAgLQAAgLAFgFQAFgHAJABQAIAAADAFIAAgZIANAAIAAA+IgNAAIAAgFQgFAGgHAAQgJAAgEgGgAgFABQgDADAAAGQAAAGADADQACADADAAQAEAAADgDQACgEAAgFIAAgDQAAgEgCgDQgCgBgFAAQgDgBgCADg");
	this.shape_2.setTransform(9.7019,0.4281,0.1338,0.1338);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgOARQgFgGAAgKQAAgJAGgHQAGgGAIAAQAJAAAFAFQAFAFAAAKIAAAFIgaAAQAAAJAKAAQAIAAAFgDIAAAJQgGADgKAAQgJAAgGgFgAgEgKQgCADAAAEIAOAAQAAgJgHAAQgDAAgCACg");
	this.shape_3.setTransform(9.0598,0.5585,0.1338,0.1338);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAGAfIgNgUIAAAUIgNAAIAAg+IANAAIAAAnIAMgSIAPAAIgPATIAQAWg");
	this.shape_4.setTransform(8.4846,0.4214,0.1338,0.1338);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAHAWIAAgXQAAgKgHAAQgCAAgCADQgCACAAAFIAAAXIgOAAIAAgqIAOAAIAAAHQAEgIAIAAQAPAAAAASIAAAZg");
	this.shape_5.setTransform(7.7823,0.5518,0.1338,0.1338);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgFAfIAAgpIALAAIAAApgAgEgTQgCgCAAgCQAAgDACgDQADgCABAAQADAAACACQACADAAADQAAACgCACQgCACgDAAQgCAAgCgCg");
	this.shape_6.setTransform(7.2706,0.4214,0.1338,0.1338);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgRAeIAAg7IAOAAIAAAwIAVAAIAAALg");
	this.shape_7.setTransform(6.8526,0.4448,0.1338,0.1338);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUAeIAAgKQADABADAAQAFAAACgEIACgGIgRgpIAOAAIAIAaIAAAEIABAAIAJgeIANAAIgRAtQgGAQgMAAIgIgBg");
	this.shape_8.setTransform(5.9028,0.6923,0.1338,0.1338);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIAaIAAAFIgNAAIAAg+IANAAIAAAbQAGgIAHABQAIgBAFAGQAEAGAAAIQAAAMgFAGQgFAGgJAAQgGAAgFgGgAgFAAQgDADAAAFIAAAEQAAAEACADQADADADAAQAEAAACgEQADgCAAgHQAAgGgCgDQgCgBgFAAQgDAAgCABg");
	this.shape_9.setTransform(5.254,0.4281,0.1338,0.1338);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgRAaQgEgEAAgLQAAgLAFgFQAFgHAJABQAHAAADAFIABAAIAAgZIANAAIAAA+IgNAAIAAgFIgBAAQgEAGgHAAQgJAAgFgGgAgFABQgDAEAAAFQAAAFADAEQACADADAAQAEAAACgDQADgDAAgGIAAgDQAAgFgDgCQgBgBgFAAQgDgBgCADg");
	this.shape_10.setTransform(4.2005,0.4281,0.1338,0.1338);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgOARQgFgGAAgKQAAgJAFgHQAIgGAHAAQAJAAAGAFQAEAFAAAKIAAAFIgbAAQABAJALAAQAHAAAFgDIAAAJQgFADgLAAQgJAAgGgFgAgDgKQgDACgBAFIAPAAQAAgJgHAAQgDAAgBACg");
	this.shape_11.setTransform(3.5584,0.5585,0.1338,0.1338);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgNAWIAAgqIANAAIAAAIIAAAAQADgJAIAAIADABIAAAMIgGgBQgEAAgCADQgCAEAAAEIAAAUg");
	this.shape_12.setTransform(3.0567,0.5518,0.1338,0.1338);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgNARQgHgGABgKQAAgJAGgHQAGgGAIAAQAJAAAGAFQAEAFAAAKIAAAFIgaAAQAAAJALAAQAHAAAFgDIAAAJQgGADgKAAQgJAAgFgFgAgDgKQgCACgCAFIAPAAQAAgJgHAAQgCAAgCACg");
	this.shape_13.setTransform(2.4882,0.5585,0.1338,0.1338);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAIAVIgHgYIAAgFIgBAAIgHAdIgOAAIgMgpIAOAAIAGAbIAAAEIABAAIAAgFIAIgaIAMAAIAGAbIAAAEIABAAIABgEIAFgbIANAAIgNApg");
	this.shape_14.setTransform(1.7257,0.5585,0.1338,0.1338);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgQAQQgGgFAAgLQAAgJAGgGQAHgGAJAAQALAAAGAGQAGAGAAAJQAAAKgGAGQgHAGgKAAQgKAAgGgGgAgGgIQgDAEAAAEQAAAMAJAAQAJAAAAgMQAAgLgJAAQgEAAgCADg");
	this.shape_15.setTransform(0.923,0.5585,0.1338,0.1338);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgVAeIAAg7IAVAAQAWAAAAATQAAAKgHAEQgHAFgJAAIgHAAIAAAVgAgIAAIAGAAQAKAAAAgJQAAgKgKAAIgGAAg");
	this.shape_16.setTransform(0.291,0.4448,0.1338,0.1338);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.pwrd_by_lkndn, new cjs.Rectangle(0,0,11.1,1.1), null);


(lib.Percentage_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("150%", "2px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 4;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(2.6,15.85);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Percentage_txt, new cjs.Rectangle(0.6,13.9,10.200000000000001,9.999999999999998), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mobile_device = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mobile_phone_300x600();
	this.instance.parent = this;
	this.instance.setTransform(83.55,36.7,0.4996,0.4996);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(153,153,153,0.2)","rgba(153,153,153,0)"],[0,0.408],54.6,23.9,54.6,-43.4).s().p("AB0DFIuflYIZXgxIAAGJg");
	this.shape.setTransform(144.3463,102.4281,0.5959,0.5959);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mobile_device, new cjs.Rectangle(83.6,36.7,176.29999999999998,97.89999999999999), null);


(lib.logoc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AhlB3QgngpAAhNQAAhGArguQAqgtA/AAQA/gBAjApQAjApAABIIAAAaIjSAAQACArAZAXQAZAYArAAQAxgBApgdIAAA4QgpAahGABQhDgBgngqgAgrhXQgVAXgFAiICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape.setTransform(103.95,9,0.2104,0.2104,0,0,0,0.3,-0.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AhNB3QgrgrAAhEQAAhMAuguQAugvBKABQArgBAgAQIAABBQgggZglAAQgsAAgcAeQgcAfAAAvQAAAwAbAcQAZAbAtAAQAmAAAhgaIAAA8QglAWgyAAQhFgBgpgqg");
	this.shape_1.setTransform(98,9,0.2104,0.2104,0,0,0,0,-0.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgjDiIAAkzIBFAAIAAEzgAgdidQgMgMAAgRQAAgQAMgMQANgLAQAAQARAAANALQAMAMAAAQQAAAQgMAMQgNAMgRAAQgRAAgMgLg");
	this.shape_2.setTransform(93.9,7.5,0.2104,0.2104,0,0,0,0.1,-0.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgyAAAAA6IAAApIBHAAIAAA3IhHAAIAAD9g");
	this.shape_3.setTransform(90.5,7.35,0.2104,0.2104,0,0,0,0.2,-0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgzAAAAA6IAAApIBIAAIAAA3IhHAAIAAD9g");
	this.shape_4.setTransform(86.4,7.35,0.2104,0.2104,0,0,0,0.3,-0.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AiWCjQg4g9gBhhQABhnA5g+QA5g+BiAAQBaAAA4A8QA4A8gBBiQAABog4A+Qg5A9heAAQheAAg4g8gAhehzQglAtAABHQAABIAkAsQAkAsA7AAQA9AAAkgqQAkgqAAhLQgBhMgigrQgjgqg9AAQg7AAglAsg");
	this.shape_5.setTransform(79.65,7.75,0.2104,0.2104,0,0,0,0.3,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_6.setTransform(12.05,11.7,0.2104,0.2104,0,0,0,0,-0.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_7.setTransform(4.1,11.7,0.2104,0.2104,0,0,0,0,-0.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(12.05,3.7,0.2104,0.2104,0,0,0,0,-0.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(4.1,3.7,0.2104,0.2104,0,0,0,0,-0.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_10.setTransform(45.9,7.4,0.2104,0.2104,0,0,0,-0.1,-0.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_11.setTransform(126.45,7.8,0.2104,0.2104,0,0,0,0.3,-0.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_12.setTransform(120,7.75,0.2104,0.2104,0,0,0,0,-0.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_13.setTransform(113.4,7.75,0.2104,0.2104,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoc, new cjs.Rectangle(0.6,0.2,128.5,15.200000000000001), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.LinkedIn_icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#063A89").s().p("Ah5CWQgcAAAAgbIACj/QAGgRAUAAIDyAAQAVAAAGARIABAGIAAD4QABAcgdAAgAiMiCIgBD9QAAAUAUAAIDyAAQAUAAAAgVIAAj3IgBgFQgEgLgPAAIjyAAQgPAAgEALg");
	this.shape.setTransform(2.004,2.0141,0.134,0.134);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgPATQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAgBAAgBIAAgfQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAIAfAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIAAAfQAAABAAABQAAAAgBABQAAAAgBAAQAAAAgBAAgAAFAAQABAAAAAAQAAABABAAQAAAAAAAAQAAABABAAIAAACIAAAJIAFAAIAAgKIgBgDQgBgDgDgBQgDAAgCACIgBABIAAgCIgFAAIAAAQIAFAAIAAgKIABgCIABgBIABAAgAgMANIAGAAIAAgQIgGAAgAgLgLIgCABIABADIADABIACAAIABgCIAAgDIgCgBIgDABg");
	this.shape_1.setTransform(2,2.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.LinkedIn_icon, new cjs.Rectangle(0,0,4,4.1), null);


(lib.lines = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#436AA6").ss(0.2,1,1).p("AitAkIFbAAAitgjIFbAA");
	this.shape.setTransform(17.35,3.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.lines, new cjs.Rectangle(-1,-1,36.7,9.2), null);


(lib.Path_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfQANAAAJAKQAJAIAAANg");
	this.shape.setTransform(1.625,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3_0, new cjs.Rectangle(0,0,3.3,3.2), null);


(lib.Path_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAIIAAgPQAIAAADAFQAGADAAAHg");
	this.shape.setTransform(0.85,0.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,1.7,1.7), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Word_icon();
	this.instance.parent = this;
	this.instance.setTransform(38.5,70.9,0.9243,0.9243);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(38.5,70.9,41.599999999999994,41.599999999999994), null);


(lib.HWandF = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.2,1,1).p("AAAgJIAAAT");
	this.shape.setTransform(2,4.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).wait(4).to({x:3.3},0).wait(2).to({x:4.4},0).wait(2).to({x:5.4},0).wait(2).to({x:5.9},0).wait(2).to({x:6.45},0).wait(2).to({x:7.9501,y:4.5001},0).wait(2).to({x:8.4501},0).wait(3).to({x:8.45,y:4.5},0).wait(2).to({x:11.35},0).wait(2).to({x:12.3},0).wait(2).to({x:13.35},0).wait(2).to({x:14.4},0).wait(2).to({x:16},0).wait(2).to({x:16.5},0).wait(3).to({x:17.5},0).wait(2).to({x:18.55},0).wait(2).to({x:19.7},0).wait(2).to({x:20.2},0).wait(5).to({x:21.2},0).wait(2).to({x:21.65},0).wait(2).to({x:22.3},0).wait(2).to({x:23.4},0).wait(2).to({x:24.35},0).wait(4).to({x:26.15},0).wait(3).to({x:27.15},0).to({_off:true},6).wait(5).to({_off:false},0).to({_off:true},5).wait(5).to({_off:false},0).to({_off:true},6).wait(31));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_3 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_5 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_7 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_9 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_11 = new cjs.Graphics().p("AifARIAAghIFAAAIAAAhg");
	var mask_graphics_13 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_15 = new cjs.Graphics().p("AigAeIAAgiIFAAAIAAAig");
	var mask_graphics_17 = new cjs.Graphics().p("AigAeIAAgiIFBAAIAAAig");
	var mask_graphics_20 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_22 = new cjs.Graphics().p("AigARIAAghIFAAAIAAAhg");
	var mask_graphics_24 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_26 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_28 = new cjs.Graphics().p("AigARIAAghIFAAAIAAAhg");
	var mask_graphics_30 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_32 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_35 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_37 = new cjs.Graphics().p("AigARIAAghIFAAAIAAAhg");
	var mask_graphics_39 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_41 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_44 = new cjs.Graphics().p("AifARIAAghIE/AAIAAAhg");
	var mask_graphics_46 = new cjs.Graphics().p("AifARIAAghIFAAAIAAAhg");
	var mask_graphics_48 = new cjs.Graphics().p("AifARIAAghIFAAAIAAAhg");
	var mask_graphics_50 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");
	var mask_graphics_52 = new cjs.Graphics().p("AigARIAAghIFAAAIAAAhg");
	var mask_graphics_54 = new cjs.Graphics().p("AifARIAAghIFAAAIAAAhg");
	var mask_graphics_56 = new cjs.Graphics().p("AifARIAAghIFAAAIAAAhg");
	var mask_graphics_58 = new cjs.Graphics().p("AifARIAAghIFAAAIAAAhg");
	var mask_graphics_61 = new cjs.Graphics().p("AigARIAAghIFBAAIAAAhg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-14.05,y:4.225}).wait(3).to({graphics:mask_graphics_3,x:-14.05,y:4.225}).wait(2).to({graphics:mask_graphics_5,x:-12.75,y:4.225}).wait(2).to({graphics:mask_graphics_7,x:-11.65,y:4.225}).wait(2).to({graphics:mask_graphics_9,x:-10.65,y:4.225}).wait(2).to({graphics:mask_graphics_11,x:-10.15,y:4.225}).wait(2).to({graphics:mask_graphics_13,x:-9.6,y:4.225}).wait(2).to({graphics:mask_graphics_15,x:-8.1001,y:2.975}).wait(2).to({graphics:mask_graphics_17,x:-7.6001,y:2.975}).wait(3).to({graphics:mask_graphics_20,x:-7.6,y:4.225}).wait(2).to({graphics:mask_graphics_22,x:-4.7,y:4.225}).wait(2).to({graphics:mask_graphics_24,x:-3.75,y:4.225}).wait(2).to({graphics:mask_graphics_26,x:-2.7,y:4.225}).wait(2).to({graphics:mask_graphics_28,x:-1.65,y:4.225}).wait(2).to({graphics:mask_graphics_30,x:-0.05,y:4.225}).wait(2).to({graphics:mask_graphics_32,x:0.45,y:4.225}).wait(3).to({graphics:mask_graphics_35,x:1.45,y:4.225}).wait(2).to({graphics:mask_graphics_37,x:2.5,y:4.225}).wait(2).to({graphics:mask_graphics_39,x:3.65,y:4.225}).wait(2).to({graphics:mask_graphics_41,x:4.15,y:4.225}).wait(3).to({graphics:mask_graphics_44,x:4.15,y:4.225}).wait(2).to({graphics:mask_graphics_46,x:5.15,y:4.225}).wait(2).to({graphics:mask_graphics_48,x:5.6,y:4.225}).wait(2).to({graphics:mask_graphics_50,x:6.25,y:4.225}).wait(2).to({graphics:mask_graphics_52,x:7.35,y:4.225}).wait(2).to({graphics:mask_graphics_54,x:8.3,y:4.225}).wait(2).to({graphics:mask_graphics_56,x:8.3,y:4.225}).wait(2).to({graphics:mask_graphics_58,x:10.1,y:4.225}).wait(3).to({graphics:mask_graphics_61,x:11.1,y:4.225}).wait(58));

	// Layer_1
	this.text = new cjs.Text("Health, Wellness and Fitness", "2px 'Segoe Pro'", "#FFFFFF");
	this.text.lineHeight = 2;
	this.text.lineWidth = 40;
	this.text.parent = this;
	this.text.setTransform(2,3.1);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,2.5,28.2,4);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjvDIIAAmPIHfAAIAAGPg");
	mask.setTransform(24,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjvDIIAAmPIHfAAIAAGPg");
	this.shape.setTransform(24,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0,0,48,40), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah3B4IAAjvIDvAAIAADvg");
	mask.setTransform(12,12);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhUBVQgjgjAAgyQAAgwAjgkQAkgjAwAAQAyAAAjAjQAjAkAAAwQAAAygjAjQgjAjgyAAQgwAAgkgjgAhIhIQgfAeAAAqQAAArAfAfQAeAeAqAAQArAAAegeQAfgfgBgrQABgqgfgeQgegegrAAQgqAAgeAeg");
	this.shape.setTransform(12,12);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0,0,24,24), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2BQIAAifIBtAAIAACfg");
	mask.setTransform(5.5,8);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYBQIAAgKIAUAAIAAgKIgSAAQgIAAgEgCQgFgCgFgFIgHgKQgDgGAAgGIAAgdIAKAAIAAAVIABALQABAFACAEQACAEAFADQADACAIAAIAtAAQAIAAADgCQAFgCACgFQADgFABgEIABgLIgBgVIAKAAIAAAdQAAAHgDAFQgBAFgFAFQgFAFgFACQgFACgIAAIgSAAIAAAKIAUAAIAAAKgAgTAoIgFgBIgGgDQgCgCAAgDIgCgGIAAhZQAAgDACgCQAAgDACgDQADgCADAAQACgCADAAIAnAAIAGACQADABACABIADAGIABAFIAABZIgBAGIgDAFIgFADIgGABgAgXhDQAAAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIAABZQAAABAAAAQAAAAAAABQABAAAAABQAAAAAAABQABAAAAAAQABAAAAABQABAAAAAAQABAAAAAAIAnAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABgBAAAAQAAgBABAAQAAgBAAAAQAAAAAAgBIAAhZQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAIgnAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape.setTransform(5.5,8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0,11,16), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgSBOIAAibIAlAAIAACbg");
	mask.setTransform(1.975,7.825);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSBIQAcgeAAgqQAAgpgcgeIAHgGQAeAgAAAtQAAAugeAgg");
	this.shape.setTransform(1.925,7.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0.1,0,3.8,15.7), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("AgxA3QAAgrAegeQAegfAsAA");
	this.shape.setTransform(5.5,5.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0,0,11,11), null);


(lib.dropdown_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(80));

	// txt
	this.txt = new cjs.Text("Read more", "1px 'Segoe Pro'", "#2B579A");
	this.txt.name = "txt";
	this.txt.lineHeight = 1;
	this.txt.lineWidth = 15;
	this.txt.parent = this;
	this.txt.setTransform(6.1,56.45);

	this.txt1 = new cjs.Text("Is this example helpful? Yes No", "1px 'Segoe Pro'", "#838383");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 1;
	this.txt1.lineWidth = 15;
	this.txt1.parent = this;
	this.txt1.setTransform(24.7,56.35);

	this.txt2 = new cjs.Text("Joined efforts with company executives, writers, and\ndesigners to formulate cutting-edge marketing cam-\npaigns for a global beauty brand that emphasized key features\nBroadened exp...", "2px 'Segoe Pro'", "#838383");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 2;
	this.txt2.lineWidth = 36;
	this.txt2.parent = this;
	this.txt2.setTransform(5.85,45.2);

	this.txt3 = new cjs.Text("2017 - 2018", "1px 'Segoe Pro'", "#838383");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 3;
	this.txt3.lineWidth = 36;
	this.txt3.parent = this;
	this.txt3.setTransform(6.15,42.4);

	this.txt4 = new cjs.Text("Copywriter", "2px 'Segoe Pro'", "#838383");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 4;
	this.txt4.lineWidth = 20;
	this.txt4.parent = this;
	this.txt4.setTransform(5.85,40.5);

	this.txt5 = new cjs.Text("Read more", "1px 'Segoe Pro'", "#2B579A");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 1;
	this.txt5.lineWidth = 15;
	this.txt5.parent = this;
	this.txt5.setTransform(6.1,34.15);

	this.txt6 = new cjs.Text("Is this example helpful? Yes No", "1px 'Segoe Pro'", "#838383");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 1;
	this.txt6.lineWidth = 15;
	this.txt6.parent = this;
	this.txt6.setTransform(24.7,34.05);

	this.txt7 = new cjs.Text("Manage a proposal...", "2px 'Segoe Pro'", "#838383");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 0;
	this.txt7.lineWidth = 36;
	this.txt7.parent = this;
	this.txt7.setTransform(6.8,31.5);

	this.txt8 = new cjs.Text("Build and design records as required by \nSubject Matter Expers and content oweners", "2px 'Segoe Pro'", "#838383");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 0;
	this.txt8.lineWidth = 36;
	this.txt8.parent = this;
	this.txt8.setTransform(6.8,27.2);

	this.txt9 = new cjs.Text("Responsible for creating, updating, and \nproofreading changes to content.", "2px 'Segoe Pro'", "#838383");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 0;
	this.txt9.lineWidth = 36;
	this.txt9.parent = this;
	this.txt9.setTransform(6.8,22.75);

	this.txt10 = new cjs.Text("Jun 2009 - Jun 2015 ", "1px 'Segoe Pro'", "#838383");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 3;
	this.txt10.lineWidth = 36;
	this.txt10.parent = this;
	this.txt10.setTransform(6.05,19.7);

	this.txt11 = new cjs.Text("Website Copywriter Specialist", "2px 'Segoe Pro'", "#838383");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 4;
	this.txt11.lineWidth = 35;
	this.txt11.parent = this;
	this.txt11.setTransform(5.85,17.7);

	this.txt12 = new cjs.Text("Filter examples by top skills", "2px 'Segoe Pro'", "#838383");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 2;
	this.txt12.lineWidth = 32;
	this.txt12.parent = this;
	this.txt12.setTransform(8.8509,11.4);

	this.txt13 = new cjs.Text("Powered by Linkedin public profiles", "2px 'Segoe Pro'", "#838383");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 2;
	this.txt13.lineWidth = 32;
	this.txt13.parent = this;
	this.txt13.setTransform(4.5009,5.45);

	this.txt14 = new cjs.Text("Work experience examples", "2px 'Segoe Pro'", "#838383");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 2;
	this.txt14.lineWidth = 32;
	this.txt14.parent = this;
	this.txt14.setTransform(4.5509,3.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt14},{t:this.txt13},{t:this.txt12},{t:this.txt11},{t:this.txt10},{t:this.txt9},{t:this.txt8},{t:this.txt7},{t:this.txt6},{t:this.txt5},{t:this.txt4},{t:this.txt3},{t:this.txt2},{t:this.txt1},{t:this.txt}]}).wait(80));

	// text_boxes
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#E0E0E0").ss(0.2,1,1).p("Ai4jxIFxAAIAAAhIlxAAgAi4i7IFxAAIAADKIlxAAgAi4AnIFxAAIAADLIlxAAg");
	this.shape.setTransform(22.925,33.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(80));

	// Symbols
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#838383").s().p("Ag6gdIB1AAIg7A7g");
	this.shape_1.setTransform(39.5117,10.9323,0.1176,0.1176);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#838383").s().p("AgnATIAAgLIghAAIAAgOIAhAAIAAgMIAKAAIAAAMIBlAAIAAAOIhlAAIAAALg");
	this.shape_2.setTransform(6.3747,11.6233,0.1275,0.1275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#838383").s().p("AAeATIAAgLIhmAAIAAgOIBmAAIAAgMIAKAAIAAAMIAgAAIAAAOIggAAIAAALg");
	this.shape_3.setTransform(6.3747,11.0812,0.1275,0.1275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#838383").s().p("AgEATIAAgLIhDAAIAAgOIBDAAIAAgMIAJAAIAAAMIBEAAIAAAOIhEAAIAAALg");
	this.shape_4.setTransform(6.3953,10.5493,0.1275,0.1275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#838383").s().p("AgLAVQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBgBAAAAIAAgHQAAAAABgBQAAgBAAAAQABAAAAgBQABAAAAAAIAEAAIAAgPIgEAAQAAAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIAAgHQAAAAABgBQAAgBAAAAQABAAAAgBQABAAAAAAIAQAAQABAAABAAQAAABABAAQAAAAAAABQABABAAAAIAAAZIADAAQAAAAABAAQAAABABAAQAAAAAAABQAAABAAAAIAAAHQAAAAAAABQAAABAAAAQgBAAAAABQgBAAAAAAg");
	this.shape_5.setTransform(40.1164,4.0157,0.1171,0.1171);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#838383").s().p("AgHAIQgDgEAAgEQAAgDADgDQADgEAEAAQAEAAAEAEQADADAAADQAAAEgDAEQgEADgEAAQgEAAgDgDg");
	this.shape_6.setTransform(40.1193,3.5795,0.1171,0.1171);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#838383").s().p("Ag0A1QgVgWAAgfQAAgeAVgVQAWgWAeAAQAfAAAVAWQAWAWAAAdQAAAfgWAWQgVAVgfAAQgeAAgWgVgAglglQgQAQAAAVQAAAXAQAQQAPAPAWAAQAWAAAQgPQAQgQAAgXQAAgVgQgQQgQgQgWAAQgWAAgPAQg");
	this.shape_7.setTransform(40.1193,3.8693,0.1171,0.1171);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(80));

	// white_bg
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AjfEYIAAovIG/AAIAAIvg");
	this.shape_8.setTransform(22.375,28);

	this.timeline.addTween(cjs.Tween.get(this.shape_8).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,44.8,64.5);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.Copywriter = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(0.2,1,1).p("AAAgJIAAAT");
	this.shape.setTransform(2,4.5);
	this.shape._off = true;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFFFFF").ss(0.2,1,1).p("AAAgQIAAAh");
	this.shape_1.setTransform(3.4001,4.5059,1,0.573);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},3).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[{t:this.shape}]},2).to({state:[]},8).to({state:[{t:this.shape}]},10).to({state:[]},10).to({state:[{t:this.shape}]},10).to({state:[]},10).wait(8));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({_off:false},0).to({_off:true},3).wait(2).to({_off:false,x:4.35},0).wait(2).to({x:5.5},0).wait(2).to({x:6.45},0).wait(2).to({x:7.9002,y:4.5001},0).wait(2).to({x:8.7,y:4.5},0).wait(2).to({x:9.05},0).wait(2).to({x:9.75},0).wait(2).to({x:10.7},0).wait(2).to({x:11.4},0).wait(2).to({x:12.05},0).to({_off:true},8).wait(10).to({_off:false},0).to({_off:true},10).wait(10).to({_off:false,x:12.0502,y:4.5001},0).to({_off:true},10).wait(8));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_4 = new cjs.Graphics().p("Ag4AmIAAhFIBxAAIAABFg");
	var mask_graphics_6 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_8 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_10 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_12 = new cjs.Graphics().p("Ag4AmIAAhFIBxAAIAABFg");
	var mask_graphics_14 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_16 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_18 = new cjs.Graphics().p("Ag4AjIAAhFIBxAAIAABFg");
	var mask_graphics_20 = new cjs.Graphics().p("AhHAjIAAhFICQAAIAABFg");
	var mask_graphics_22 = new cjs.Graphics().p("Ag/AjIAAhFIB/AAIAABFg");
	var mask_graphics_24 = new cjs.Graphics().p("AhLAjIAAhFICXAAIAABFg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-3.825,y:4.05}).wait(4).to({graphics:mask_graphics_4,x:-2.275,y:3.7836}).wait(2).to({graphics:mask_graphics_6,x:-1.325,y:4.05}).wait(2).to({graphics:mask_graphics_8,x:-0.175,y:4.05}).wait(2).to({graphics:mask_graphics_10,x:0.775,y:4.05}).wait(2).to({graphics:mask_graphics_12,x:2.2251,y:3.7751}).wait(2).to({graphics:mask_graphics_14,x:3.025,y:4.05}).wait(2).to({graphics:mask_graphics_16,x:3.375,y:4.05}).wait(2).to({graphics:mask_graphics_18,x:4.075,y:4.05}).wait(2).to({graphics:mask_graphics_20,x:3.45,y:4.05}).wait(2).to({graphics:mask_graphics_22,x:5.025,y:4.05}).wait(2).to({graphics:mask_graphics_24,x:4.6,y:4.05}).wait(56));

	// Layer_1
	this.text = new cjs.Text("Copywriter", "2px 'Segoe Pro'", "#FFFFFF");
	this.text.lineHeight = 2;
	this.text.lineWidth = 22;
	this.text.parent = this;
	this.text.setTransform(2,3);

	var maskedShapeInstanceList = [this.text];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.text).wait(80));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,1,13.1,6.6);


(lib.caption = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("What role & industry would\nyou like to see examples for?", "2px 'Segoe Pro'", "#FFFFFF");
	this.text.lineHeight = 3;
	this.text.lineWidth = 38;
	this.text.parent = this;
	this.text.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.text).wait(1));

}).prototype = getMCSymbolPrototype(lib.caption, new cjs.Rectangle(0,0,42.1,10), null);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.text = new cjs.Text("", "8px 'SegoeUI-Light'", "#939393");
	this.text.textAlign = "center";
	this.text.lineHeight = 12;
	this.text.lineWidth = 100;
	this.text.parent = this;
	this.text.setTransform(100.55,26.95,1.0085,1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("ArzG4IAAtvIXnAAIAANvg");
	this.shape.setTransform(74.1,43.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.text}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(-1.5,0,154.5,88), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.AimeesResume = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Text
	this.txt2 = new cjs.Text("aimee.owens25@outlook.com • linkedin.com/in/aimee-owens25 • @aimeeowens25", "2px 'Segoe Pro'", "#939393");
	this.txt2.name = "txt2";
	this.txt2.textAlign = "center";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 104;
	this.txt2.parent = this;
	this.txt2.setTransform(-0.7981,-20.05);

	this.txt1 = new cjs.Text("Greater Seattle Area • 425 555 0199", "2px 'Segoe Pro'", "#2D5A99");
	this.txt1.name = "txt1";
	this.txt1.textAlign = "center";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 104;
	this.txt1.parent = this;
	this.txt1.setTransform(-1.0003,-22.45);

	this.txt = new cjs.Text("Aimee Owens", "8px 'Segoe Pro'", "#939393");
	this.txt.name = "txt";
	this.txt.textAlign = "center";
	this.txt.lineHeight = 13;
	this.txt.lineWidth = 104;
	this.txt.parent = this;
	this.txt.setTransform(-0.95,-27.8);

	this.txt14 = new cjs.Text("Supervise all activities related to the brand", "2px 'Segoe Pro'", "#939393");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 2;
	this.txt14.lineWidth = 73;
	this.txt14.parent = this;
	this.txt14.setTransform(-28.15,50.8);

	this.txt13 = new cjs.Text("Oversee the wide-reaching advertising initiatives, and direct the marketing\nresearch.", "2px 'Segoe Pro'", "#939393");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 2;
	this.txt13.lineWidth = 73;
	this.txt13.parent = this;
	this.txt13.setTransform(-28.15,44.3);

	this.txt11 = new cjs.Text("Brand Manager, First Up Consults - Seattle, WA", "2px 'Segoe Pro'", "#2D5A99");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 5;
	this.txt11.lineWidth = 44;
	this.txt11.parent = this;
	this.txt11.setTransform(-35.9479,32.85);

	this.txt10 = new cjs.Text("September 2012 - January 2015", "2px 'Segoe Pro'", "#939393");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 5;
	this.txt10.lineWidth = 30;
	this.txt10.parent = this;
	this.txt10.setTransform(-36.0479,30.35);

	this.txt12 = new cjs.Text("Planned, developed, and aided in marketing efforts for various brands and products", "2px 'Segoe Pro'", "#939393");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 2;
	this.txt12.lineWidth = 73;
	this.txt12.parent = this;
	this.txt12.setTransform(-28.15,38.6);

	this.txt9 = new cjs.Text("Supervise all activities related to the brand", "2px 'Segoe Pro'", "#939393");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 2;
	this.txt9.lineWidth = 40;
	this.txt9.parent = this;
	this.txt9.setTransform(-32.95,25.45);

	this.txt8 = new cjs.Text("Oversee the wide-reaching advertising initiatives, and direct the marketing research.", "2px 'Segoe Pro'", "#939393");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 2;
	this.txt8.lineWidth = 67;
	this.txt8.parent = this;
	this.txt8.setTransform(-32.95,19.8);

	this.txt7 = new cjs.Text("Responsiblbe for the marketing of a product or service in its entirety, from research and development through sales.", "2px 'Segoe Pro'", "#939393");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 2;
	this.txt7.lineWidth = 66;
	this.txt7.parent = this;
	this.txt7.setTransform(-32.95,14.15);

	this.txt6 = new cjs.Text("Senior Brand Manager, Contoso - Bellevue, WA", "2px 'Segoe Pro'", "#2D5A99");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 5;
	this.txt6.lineWidth = 44;
	this.txt6.parent = this;
	this.txt6.setTransform(-41.0479,9.15);

	this.txt5 = new cjs.Text("January 2015 - Present", "2px 'Segoe Pro'", "#939393");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 5;
	this.txt5.lineWidth = 26;
	this.txt5.parent = this;
	this.txt5.setTransform(-41.0479,6.75);

	this.txt4 = new cjs.Text("Experience", "5px 'Segoe Pro'", "#2D5A99");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 9;
	this.txt4.lineWidth = 27;
	this.txt4.parent = this;
	this.txt4.setTransform(-41.1,1.5);

	this.txt3 = new cjs.Text("Engaged, detail-oriented candidate in a senior brand management position seeks to service a global brand with a legacy of quality and performance in the marketplace.", "2px 'Segoe Pro'", "#939393");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 3;
	this.txt3.lineWidth = 87;
	this.txt3.parent = this;
	this.txt3.setTransform(-41.0479,-9.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#848484").s().p("AAWC3IgCgDIACgEIADgBIADABQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQgBABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAgAAWB2IgCgDIACgEIADgBIADABQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAgAAWA7IgCgDIACgEIADgBIADABQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAAAQgBABAAAAQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAAAgBgBQAAAAAAAAgAgchJIAAgDIAAgDIAEgBIADABQAAAAABABQAAAAAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBgBgAgch+IAAgDIAAgEIAEgBIADABQAAABABAAQAAAAAAABQAAAAAAABQABAAAAABQAAAAgBABQAAAAAAAAQAAABAAAAQgBAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAgAgciwIAAgDIAAgDIAEgBIADABQAAAAABABQAAAAAAAAQAAABAAAAQABABAAAAQAAABgBAAQAAABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBgBg");
	this.shape.setTransform(-34.05,32.275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt12},{t:this.txt10},{t:this.txt11},{t:this.txt13},{t:this.txt14},{t:this.txt},{t:this.txt1},{t:this.txt2}]}).wait(1));

	// Layer_4
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#C5C5C5").ss(0.2,1,1).p("AmDAAIMHAA");
	this.shape_1.setTransform(-0.2,-14);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#C5C5C5").ss(0.2,1,1).p("Aoao1IQ1AAIAARrIw1AAg");
	this.shape_2.setTransform(0.5,12.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AoaI2IAAxrIQ1AAIAARrg");
	this.shape_3.setTransform(0.5,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.AimeesResume, new cjs.Rectangle(-54.8,-44.8,110.19999999999999,115.2), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#13448F").s().p("AgXAiIAAgNQAKAIALAAQAOAAAAgLIgBgFIgEgDIgFgDIgOgHQgEAAgCgDQgDgDgBgDQgBgDAAgEQAAgFACgEQADgFADgCQAFgDAEgBIAKgBQAKAAAHADIAAAMQgIgFgLAAIgFAAIgEACIgDAEIgBAEIABAFIADADIATAJIAHAEIAEAFIABAIQAAAFgCAFQgCADgFADIgJAEIgKABQgKAAgJgEg");
	this.shape.setTransform(138.75,19.95,0.132,0.132,0,0,0,-0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#13448F").s().p("AgWAcQgJgJAAgTQAAgPAKgMQAKgKANAAQAPAAAHAJQAIAJAAARIAAAFIgzAAQAAALAHAIQAGAHAKAAQAMAAALgJIAAALQgJAHgQAAQgQAAgIgKgAgMgVQgFAGgCAJIAnAAQAAgKgFgGQgEgFgJAAQgHAAgHAGg");
	this.shape_1.setTransform(137.8487,19.9997,0.132,0.132);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#13448F").s().p("AgFA2IAAhrIALAAIAABrg");
	this.shape_2.setTransform(137.1,19.75,0.132,0.132,0,0,0,0,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#13448F").s().p("AghA2IAAhqIAMAAIAAANQAJgOAQAAQAOAAAIAKQAIAJAAARQAAASgJAKQgJALgQAAQgMAAgJgMIAAAsgAgPgkQgGAHAAALIAAAKQAAAIAGAGQAGAHAJAAQAKAAAGgJQAGgHAAgOQAAgMgGgHQgFgHgKAAQgKAAgGAHg");
	this.shape_3.setTransform(136.3,20.2,0.132,0.132,0,0,0,0.1,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#13448F").s().p("AAoAmIAAgqQAAgMgEgFQgDgGgJABQgIgBgFAHQgFAHAAAJIAAAqIgLAAIAAgrQAAgVgQAAQgJgBgFAHQgEAGAAAKIAAAqIgMAAIAAhJIAMAAIAAAMIAAAAQAHgNAPAAQAIAAAGADQAFAFACAGQAIgOAQAAQAYAAAAAeIAAAsg");
	this.shape_4.setTransform(134.9,19.95,0.132,0.132,0,0,0,-0.1,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#13448F").s().p("AgWAhQgGgGAAgKQAAgTAYgEIAVgDQAAgSgPAAQgMAAgLAJIAAgMQAMgHAMAAQAaAAAAAbIAAAvIgMAAIAAgMQgIANgOAAQgMAAgFgFgAAAACQgHABgFADQgEADAAAHQAAAGAEADQAFAEAFAAQAIAAAFgHQAGgGAAgJIAAgHg");
	this.shape_5.setTransform(133.5525,19.9997,0.132,0.132);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#13448F").s().p("AASAlIgSgeIAAAAIgRAeIgOAAIAZgkIgYglIAOAAIAQAfIABAAIASgfIANAAIgZAlIAYAkg");
	this.shape_6.setTransform(132.6384,19.9997,0.132,0.132);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#13448F").s().p("AgWAcQgJgJAAgTQAAgQAJgLQALgKAMAAQAPAAAIAJQAIAKAAAQIAAAFIgzAAQABAMAFAHQAIAHAJAAQAMAAALgJIAAALQgJAHgRAAQgPAAgIgKgAgMgVQgGAGAAAJIAmAAQAAgJgFgHQgFgFgJAAQgHAAgGAGg");
	this.shape_7.setTransform(131.698,19.9997,0.132,0.132);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#13448F").s().p("AgWAcQgJgJAAgTQAAgPAKgMQAKgKANAAQAOAAAIAJQAIAJAAARIAAAFIgyAAQgBALAHAIQAGAHAKAAQAMAAALgJIAAALQgJAHgQAAQgQAAgIgKgAgMgVQgFAGgBAJIAmAAQAAgKgFgGQgEgFgJAAQgHAAgHAGg");
	this.shape_8.setTransform(130.1538,19.9997,0.132,0.132);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#13448F").s().p("AgWAcQgJgJAAgTQAAgPAKgMQAKgKANAAQAOAAAIAJQAIAJAAARIAAAFIgyAAQgBAMAHAHQAGAHAKAAQAMAAALgJIAAALQgJAHgQAAQgQAAgIgKgAgMgVQgFAFgBAKIAmAAQAAgKgFgGQgEgFgJAAQgIAAgGAGg");
	this.shape_9.setTransform(129.144,19.9997,0.132,0.132);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#13448F").s().p("AgLA1IgOgDIgFgDIAAgOIAGAEIAHADIAPADQAKAAAFgFQAGgDgBgJIgBgHIgFgFIgagPIgIgGQgEgDgCgFQgCgFAAgFQAAgHADgFQAEgFAEgDQAEgEAIgBQAGgCAGAAQAPAAAHAEIAAANQgJgGgOAAIgHABIgIADIgFAEQgBAEAAADQAAAFABACQACADADADIAaANIAIAIQAEAEACAEQACAEAAAFQAAAIgDAFQgDAGgFADQgEADgIACQgGABgGAAg");
	this.shape_10.setTransform(128.1,19.8,0.132,0.132,0,0,0,0.1,-0.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#13448F").ss(0.2).p("ACWAaIkqAAQgLAAgIgIQgHgHAAgLQAAgJAHgIQAIgIALAAIEqAAQALAAAHAIQAIAIAAAJQAAALgIAHQgHAIgLAAg");
	this.shape_11.setTransform(133.4,19.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AxtDDQhRAAg5g5Qg5g5AAhRQAAhQA5g5QA5g5BRAAMAjbAAAQBQAAA6A5QA5A5AABQQAABRg5A5Qg6A5hQAAg");
	this.shape_12.setTransform(133.4073,19.9931,0.132,0.132);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(114.9,16.4,37.099999999999994,7.200000000000003), null);


(lib.topbar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bar.cache(-150,-150,300,300,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Top_Bar
	this.bar = new lib.topbar_cache();
	this.bar.name = "bar";
	this.bar.parent = this;
	this.bar.setTransform(671.25,135.5,1,1,0,0,0,-37.6,102.4);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

}).prototype = getMCSymbolPrototype(lib.topbar, new cjs.Rectangle(581.3,125.9,180.10000000000002,21.400000000000006), null);


(lib.scroll_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.scrollbar.cache(-5,-85,10,170,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.scrollbar = new lib.scrollbar_c();
	this.scrollbar.name = "scrollbar";
	this.scrollbar.parent = this;
	this.scrollbar.setTransform(1.2,40.7,1,1,0,0,0,1.2,40.7);

	this.timeline.addTween(cjs.Tween.get(this.scrollbar).wait(1));

}).prototype = getMCSymbolPrototype(lib.scroll_bar, new cjs.Rectangle(0,-0.1,2.4,80.89999999999999), null);


(lib.screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_189 = function() {
		exportRoot.tl1.play()
	}
	this.frame_215 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(189).call(this.frame_189).wait(26).call(this.frame_215).wait(3));

	// Copywriter
	this.instance = new lib.Copywriter("single",0);
	this.instance.parent = this;
	this.instance.setTransform(126.1,-157.55,1,1,0,0,0,13,5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2).to({mode:"synched"},0).wait(38).to({mode:"single",startPosition:38},0).wait(84).to({startPosition:79},0).to({y:-171.55},32,cjs.Ease.quadInOut).wait(62));

	// Industry
	this.instance_1 = new lib.HWandF("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(131.8,-150.5,1,1,0,0,0,18.7,5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(47).to({mode:"synched",loop:false},0).wait(77).to({mode:"single",startPosition:118},0).to({x:131.55,y:-164.25},32,cjs.Ease.quadInOut).wait(62));

	// Lines
	this.instance_2 = new lib.lines();
	this.instance_2.parent = this;
	this.instance_2.setTransform(132.55,-153.05,1,1,0,0,0,17.4,3.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(124).to({y:-167.05},32,cjs.Ease.quadInOut).wait(62));

	// Add_Industry
	this.text = new cjs.Text("Add industry (optional)", "3px 'Segoe Pro'", "#436AA6");
	this.text.lineHeight = 3;
	this.text.lineWidth = 33;
	this.text.parent = this;
	this.text.setTransform(115.1,-153.65);

	this.timeline.addTween(cjs.Tween.get(this.text).to({_off:true},42).wait(176));

	// See Examples
	this.instance_3 = new lib.ClipGroup();
	this.instance_3.parent = this;
	this.instance_3.setTransform(132.4,-139.8,1,1,0,0,0,133.6,20);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(125).to({regX:133.4,x:132.25,alpha:0.989},0).wait(1).to({y:-139.9,alpha:0.9673},0).wait(1).to({y:-140.05,alpha:0.9339},0).wait(1).to({y:-140.2,alpha:0.8879},0).wait(1).to({y:-140.45,alpha:0.8284},0).wait(1).to({y:-140.75,alpha:0.7544},0).wait(1).to({y:-141.1,alpha:0.6651},0).wait(1).to({y:-141.5,alpha:0.5602},0).wait(1).to({y:-141.95,alpha:0.4399},0).wait(1).to({y:-142.5,alpha:0.305},0).wait(1).to({y:-143.05,alpha:0.1574},0).wait(1).to({regX:134,regY:19.6,x:132.45,y:-143.7,alpha:0},0).wait(1).to({regX:133.4,regY:20,x:131.85,y:-143.8},0).wait(1).to({y:-144.3},0).wait(1).to({y:-144.85},0).wait(1).to({y:-145.35},0).wait(1).to({y:-145.8},0).wait(1).to({y:-146.3},0).wait(1).to({y:-146.7},0).wait(1).to({y:-147.1},0).wait(1).to({y:-147.5},0).wait(1).to({y:-147.8},0).wait(1).to({y:-148.1},0).wait(1).to({y:-148.35},0).wait(1).to({y:-148.6},0).wait(1).to({y:-148.8},0).wait(1).to({y:-148.95},0).wait(1).to({y:-149.1},0).wait(1).to({y:-149.2},0).wait(1).to({y:-149.3},0).wait(1).to({y:-149.35},0).wait(1).to({regX:133.6,regY:19.9,x:132.4,y:-149.85},0).wait(62));

	// Caption
	this.instance_4 = new lib.caption();
	this.instance_4.parent = this;
	this.instance_4.setTransform(134.2,-168.25,1,1,0,0,0,21.1,5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(125).to({y:-168.3,alpha:0.988},0).wait(1).to({y:-168.35,alpha:0.9655},0).wait(1).to({y:-168.5,alpha:0.9316},0).wait(1).to({y:-168.7,alpha:0.8856},0).wait(1).to({y:-168.95,alpha:0.8266},0).wait(1).to({y:-169.25,alpha:0.7537},0).wait(1).to({y:-169.65,alpha:0.6663},0).wait(1).to({y:-170.05,alpha:0.5636},0).wait(1).to({y:-170.55,alpha:0.4454},0).wait(1).to({y:-171.1,alpha:0.3116},0).wait(1).to({y:-171.75,alpha:0.1628},0).wait(1).to({y:-172.45,alpha:0},0).wait(1).to({y:-173.2},0).wait(1).to({y:-174.05},0).wait(1).to({y:-174.9},0).wait(1).to({y:-175.8},0).wait(1).to({y:-176.65},0).wait(1).to({y:-177.5},0).wait(1).to({y:-178.25},0).wait(1).to({y:-179},0).wait(1).to({y:-179.7},0).wait(1).to({y:-180.3},0).wait(1).to({y:-180.85},0).wait(1).to({y:-181.35},0).wait(1).to({y:-181.8},0).wait(1).to({y:-182.15},0).wait(1).to({y:-182.45},0).wait(1).to({y:-182.7},0).wait(1).to({y:-182.9},0).wait(1).to({y:-183.05},0).wait(1).to({y:-183.15},0).wait(1).to({y:-183.25},0).wait(62));

	// drop_menu
	this.instance_5 = new lib.dropdown_menu();
	this.instance_5.parent = this;
	this.instance_5.setTransform(133,-72,1,1,0,0,0,22.4,28);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(124).to({_off:false},0).to({y:-133.55,alpha:1},32,cjs.Ease.quadInOut).wait(62));

	// text
	this.text_1 = new cjs.Text("Word Resume Assistant", "3px 'Segoe Pro'", "#FFFFFF");
	this.text_1.lineHeight = 3;
	this.text_1.lineWidth = 38;
	this.text_1.parent = this;
	this.text_1.setTransform(115.1,-186.05);

	this.timeline.addTween(cjs.Tween.get(this.text_1).wait(218));

	// LinkedIn_icon
	this.instance_6 = new lib.LinkedIn_icon();
	this.instance_6.parent = this;
	this.instance_6.setTransform(116.9,-177.15,1,1,0,0,0,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(124).to({scaleX:0.642,scaleY:0.642,x:116.2,y:-178.65},32,cjs.Ease.quadInOut).wait(62));

	// LinkedIn
	this.instance_7 = new lib.pwrd_by_lkndn();
	this.instance_7.parent = this;
	this.instance_7.setTransform(144.45,-176.7,1,1,0,0,0,5.5,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(125).to({alpha:0.988},0).wait(1).to({alpha:0.9655},0).wait(1).to({alpha:0.9316},0).wait(1).to({alpha:0.8856},0).wait(1).to({scaleX:1.0001,alpha:0.8266},0).wait(1).to({alpha:0.7537},0).wait(1).to({scaleY:1.0001,alpha:0.6663},0).wait(1).to({alpha:0.5636},0).wait(1).to({scaleX:1.0002,x:144.5,alpha:0.4454},0).wait(1).to({alpha:0.3116},0).wait(1).to({alpha:0.1628},0).wait(1).to({scaleX:1.0003,y:-176.75,alpha:0},0).wait(1).to({scaleY:1.0002},0).wait(1).to({scaleX:1.0004},0).wait(1).to({scaleX:1.0005},0).wait(1).to({scaleY:1.0003},0).wait(1).to({scaleX:1.0006},0).wait(2).to({scaleX:1.0007},0).wait(1).to({scaleY:1.0004},0).wait(1).to({scaleX:1.0008},0).wait(2).to({scaleX:1.0009},0).wait(2).to({scaleY:1.0005},0).wait(2).to({scaleX:1.001},0).wait(5).to({regX:5.6,regY:0.5,x:144.55,y:-176.8},0).wait(62));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2B579A").s().p("AjfGfIAAs9IG/AAIAAM9g");
	this.shape.setTransform(132.975,-147.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(218));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-24.8,-196.7,180.4,161.2);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.logo = new lib.logoc();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(27.25,-15.4,1,1,0,0,0,73.2,7.2);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.logos, new cjs.Rectangle(-45.4,-22.4,128.6,15.2), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.laptop_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Camera
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0D0D0D").s().p("AgKAMQgFgFAAgHQAAgGAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAGQAAAGgFAGQgFAEgGAAQgFAAgFgEg");
	this.shape.setTransform(399,12.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D6E6E").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_1.setTransform(399,12.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgPgPQANAAAIAKQAKAIAAAN");
	this.shape_2.setTransform(400.6,10.45);

	this.instance = new lib.Path_3_0();
	this.instance.parent = this;
	this.instance.setTransform(400.55,10.45,1,1,0,0,0,1.6,1.6);
	this.instance.alpha = 0.25;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#272C2E").s().p("AgeAfQgNgNAAgSQAAgRANgNQANgNARAAQASAAANANQANANAAARQAAASgNANQgNANgSAAQgRAAgNgNg");
	this.shape_3.setTransform(399,12.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0D0D0D").s().p("AgFAGQgCgDgBgDQABgDACgCQACgDADAAQAEAAACADQACACABADQgBADgCADQgCACgEAAQgDAAgCgCg");
	this.shape_4.setTransform(379.75,12.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D6E6E").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_5.setTransform(379.75,12.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgIgHQAHAAAEAFQAFADAAAH");
	this.shape_6.setTransform(380.6,11.225);

	this.instance_1 = new lib.Path_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(380.55,11.2,1,1,0,0,0,0.8,0.8);
	this.instance_1.alpha = 0.25;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#272C2E").s().p("AgPAQQgHgGAAgKQAAgIAHgHQAHgHAIAAQAKAAAGAHQAHAHAAAIQAAAKgHAGQgGAHgKAAQgIAAgHgHg");
	this.shape_7.setTransform(379.75,12.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Screen
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0D0D0D").s().p("Eg4oAj7QhXAAg+g9Qg+g+AAhXMAAAhBbQAAhTA7g6QA6g7BTAAMBxNAAAQBeAABCBCQBCBCAABeMAAABAzQAABdhCBCQhBBBhdAAgEg5UggcMAAABAiQAAAEAEAAMByvAAAQAEAAABgEMAAAhAiQgBgEgEAAMhyvAAAQgEAAAAAEg");
	this.shape_8.setTransform(413.8,232.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6D7680").s().p("Eg4pAkWQhpAAhLhLQhLhKAAhpMAAAhA5QAAhlBIhHQBIhIBkAAMBxPAAAQBvAABQBPQBPBPAABwMAAABARQAABvhPBPQhPBOhuAAgEg5+AghMB0MAAAMAAAhBZMh0MAAAg");
	this.shape_9.setTransform(414.35,232.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Keyboard
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ACB6BF").s().p("AjOAjQgFAAgBgGIgFgYQgBgEgBAAIgDgFIgEgaQgCgFAGAAIGsABQAFAAABAGIAFAXIACAFQACAAABAFIAFAZQACAGgGAAg");
	this.shape_10.setTransform(703.4,504.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#ACB6BF").s().p("AjMAiQgGAAgCgFIgRg5QgCgGAGAAIGrABQAGAAACAFIAUA5QACAGgGAAg");
	this.shape_11.setTransform(749.9017,504.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#ACB6BF").s().p("AjOAiQgGAAgBgGIgMg4IAAgEQAAgBABAAQAAAAAAAAQABgBAAAAQABAAABAAIGrABQAGAAABAGIANA4QACAGgGAAg");
	this.shape_12.setTransform(656.5917,504.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#ACB6BF").s().p("AjSAiQgGAAgBgFIgJg5QgBgFAFAAIGsAAQAGAAABAFIAOA5QACAFgGAAg");
	this.shape_13.setTransform(610.1923,504.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ACB6BF").s().p("AjSAiQgFAAgBgFIgHg5QgBgFAGAAIGvAAQAGAAAAAFIAFA5QAAAFgFAAg");
	this.shape_14.setTransform(563.3173,504.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ACB6BF").s().p("A11AiQgEAAAAgFIAGg5QABgFAFAAMArcAAAQAFAAABAFIAGA5QgBAFgFAAg");
	this.shape_15.setTransform(398.9,504.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ACB6BF").s().p("AjsAiQgFAAABgFIAOg5QABgFAFAAIHJAAQAGAAgBAFIgJA5QAAAFgGAAg");
	this.shape_16.setTransform(232.5995,504.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ACB6BF").s().p("AjtAiQgGAAABgFIAOg5QACgFAFAAIHMAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgOA5QgCAFgFAAg");
	this.shape_17.setTransform(183.0373,504.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ACB6BF").s().p("AjvAiQgGAAABgFIAOg5QACgFAFAAIHPAAQABAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgUA5QgBAFgGAAg");
	this.shape_18.setTransform(133.6623,504.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#ACB6BF").s().p("AkAAiQgFAAABgFIARg5QABgFAGAAIHtAAQAGAAgCAFIgUA5QgCAFgFAAg");
	this.shape_19.setTransform(82.1433,504.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#63717F").s().p("AjRArQgFAAgCgFIgSg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBQABAAAAgBQAAAAABAAQAAgBABAAQABAAAAAAIGsABQAFAAACAFIAUA5IAAADIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAAAQAAABgBABQAAAAgBAAQAAABAAAAQgBAAgBAAg");
	this.shape_20.setTransform(749.4625,505.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#63717F").s().p("AjUAsQgFAAgCgFIgFgaQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQgEgBgBgEIgFgYQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAAAIABgBIAAgBIABgBIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABgBAAAAIGsABQAFAAABAGIAGAaQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAIAAAAQAEACABAEIAGAYIAAADIAAAAIAAAGIABABIAAAFIAAAAIAAADQAAAFgEgBg");
	this.shape_21.setTransform(702.8688,505.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#63717F").s().p("AjVAsQgGAAgBgFIgNg2IAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBQABgEADAAIGsABQAGAAABAGIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIANA1QABAGgGAAg");
	this.shape_22.setTransform(656.5327,505.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#63717F").s().p("AjXAuQgFAAgBgGIgKg4IAAgDIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBQABgDADAAIGsAAQAGAAABAFIAOA5IABABIAAAMIAAAAIAAAMQABAEgFAAg");
	this.shape_23.setTransform(609.8583,505.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#63717F").s().p("AjYAsQgGAAAAgFIgHg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAABAAIGvAAQAGAAAAAFIAAACIABAAIAAAEIAAAAIAAADIABAAIAAAFIAAAAIAAADIABAAIAAADIAEA5QAAAFgFAAg");
	this.shape_24.setTransform(562.925,505.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#63717F").s().p("A17AsQgFAAAAgFIAHg5IAAgBIAAAAIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQABgFAFAAMArcAAAQAEAAACAFIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAFA5QABAFgGAAg");
	this.shape_25.setTransform(398.9321,505.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#63717F").s().p("AjxAsQgFAAABgFIAAAAIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIAOg4QABgGAGAAIHIAAQAEAAABAEIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIgIA5QgBAFgFAAg");
	this.shape_26.setTransform(232.6173,505.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#63717F").s().p("Aj4AsQgGAAABgFIAOg5IAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgFAFAAIHMAAQABAAAAABQABAAAAAAQABAAAAABQAAAAAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAAAIAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAADIgOA5QgBAFgFAAg");
	this.shape_27.setTransform(183.3006,505.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#63717F").s().p("Aj9AsQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBIAAgBIgBAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgEIAQg4QABgGAGAAIHtAAQABAAABABQAAAAABAAQAAAAAAABQABAAAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgTA5QgCAFgFAAg");
	this.shape_28.setTransform(82.5,505.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#63717F").s().p("Aj5AsQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAIAAgEIANg5IABgCIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBQACgEAEAAIHPAAQABAAABABQAAAAABAAQAAAAABABQAAAAAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgUA5QgCAFgFAAg");
	this.shape_29.setTransform(133.3667,505.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#ACB6BF").s().p("Ap0AcQgGgBgBgFIgGgrQgBgGAFABITpAAQAFgBACAGIAPArQACAFgGABg");
	this.shape_30.setTransform(706.569,497.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#ACB6BF").s().p("AjYAcQgGgBgBgFIgGgrQgBgGAGABIG2AAQAGgBABAGIAJArQABAFgGABg");
	this.shape_31.setTransform(618.1505,497.55);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#ACB6BF").s().p("AjcAbQgGABAAgGIgCgrQgBgFAGgBIG6AAQAFABABAFIAFArQAAAGgFgBg");
	this.shape_32.setTransform(569.9429,497.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#ACB6BF").s().p("AjeAcQgFgBAAgFIAAgrQAAgGAFABIG4AAQAGgBAAAGIAEArQAAAFgFABg");
	this.shape_33.setTransform(521.925,497.55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGgBIG6AAQAFABABAFIADArQAAAFgGAAg");
	this.shape_34.setTransform(474.425,497.75);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIACgrQAAgFAGgBIG6AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_35.setTransform(426.325,497.75);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIADgrQAAgFAGgBIG5AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_36.setTransform(378.6429,497.75);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#ACB6BF").s().p("AjgAbQgGAAABgFIAGgrQAAgFAGgBIG6AAQAFABAAAFIgEArQAAAFgGAAg");
	this.shape_37.setTransform(330.2173,497.75);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGgBIG6AAQAGABgBAFIgGArQAAAFgGAAg");
	this.shape_38.setTransform(282.5321,497.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ACB6BF").s().p("AjiAbQgFAAAAgFIAHgrQABgFAFgBIG9AAQAGABgBAFIgKArQgBAFgFAAg");
	this.shape_39.setTransform(234.75,497.75);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#ACB6BF").s().p("AjkAbQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAIgBgEIAMgrQACgFAFgBIG5AAQABABABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAgBABIgLArQgCAFgFAAg");
	this.shape_40.setTransform(186.5617,497.75);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#ACB6BF").s().p("AoFAbQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIAQgsQADgFAFgBIP2AAQAGABgCAFIgMArQgBAFgGAAg");
	this.shape_41.setTransform(110.2167,497.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#63717F").s().p("Ap6ApQgFAAgBgFIgHgrIAAgDIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAITpAAQAFAAABAFIAJArIAHADIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAQgBABAAABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_42.setTransform(706.025,498.925);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#63717F").s().p("AjdApQgFAAgBgFIgGgrIAAgDIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBQABgDADAAIG3AAQAFAAACAFIAJArIgBADIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABQgBADgEAAg");
	this.shape_43.setTransform(617.7,498.925);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgBQABgFAEAAIG6AAQAEAAACAFIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAEArQABAGgFAAg");
	this.shape_44.setTransform(570.0077,498.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBQABgEAEAAIG3AAQAFAAABAFIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIAEAqQABAGgGAAg");
	this.shape_45.setTransform(521.7571,499.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIABABIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAAAIABACIACAqQAAAGgFAAg");
	this.shape_46.setTransform(474.375,499.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIACgsIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAAAIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAgBIABAAIAAgCQACgEADAAIG6AAQAFAAABAEIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAACIAAAqQAAAGgGAAg");
	this.shape_47.setTransform(426.35,499.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAAAIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAFAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIAAAqQAAAGgGAAg");
	this.shape_48.setTransform(378.625,499.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#63717F").s().p("AjoApQgEAAAAgFIAFgrIABgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBQACgEAEAAIG6AAQADAAACAEIAAAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAACIABAAIAAACIAAAAIAAACIABACIgEArQAAAFgFAAg");
	this.shape_49.setTransform(330.1,499.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#63717F").s().p("AjnApQgFAAABgFIAFgrIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAFAAIG6AAQAEAAABAEIAAABIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABACIgGArQgBAFgFAAg");
	this.shape_50.setTransform(282.4423,499.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBQABgEAFAAIG9AAQAEAAABAEIAAABIAAAAIAAACIABAAIAAADIAAABIAAACIABAAIAAABIAAABIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAADIgJArQgBAFgGAAg");
	this.shape_51.setTransform(234.6429,499.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#63717F").s().p("AjfApQgFAAAAgDIAAgBIAAAAIAAgBIgBgBIAAAAIAAgBIAAgBIgBgBIAAgBIAAgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIgBgBIAAgDIAMgrQACgFAFAAIG6AAQADAAAAAEIABAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIAAAAIAAADIgLArQgBAFgGAAg");
	this.shape_52.setTransform(186.95,499.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#63717F").s().p("AoCAnQAAAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAgBIAAAAIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAQgrQADgGAFAAIP2AAQAEAAAAADIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAADIgNArQgBAGgGAAg");
	this.shape_53.setTransform(110.525,498.875);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#ACB6BF").s().p("Am+AbQgFAAgBgFIgKgrQgBgFAGAAIN4AAQAFAAADAFIAXAsQADAEgGAAg");
	this.shape_54.setTransform(722.1314,491.825);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#ACB6BF").s().p("AjYAbQgGAAgBgFIgGgrQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIG2AAQAGAAABAFIAJArQABAFgGAAg");
	this.shape_55.setTransform(651.4014,491.825);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#ACB6BF").s().p("AjYAbQgFAAgBgFIgHgrQgBgFAGAAIG3AAQAFAAABAFIAJArQABAFgGAAg");
	this.shape_56.setTransform(603.9323,491.825);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#ACB6BF").s().p("AjcAbQgGAAAAgFIgDgrQAAgFAGAAIG5AAQAGAAABAFIAEArQABAFgGAAg");
	this.shape_57.setTransform(556.2571,491.825);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIAAgrQAAgFAFAAIG4AAQAFAAABAFIAEArQAAAFgFAAg");
	this.shape_58.setTransform(508.7,491.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGAAIG6AAQAGAAAAAFIADArQAAAFgFAAg");
	this.shape_59.setTransform(461.175,491.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIACgrQABgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_60.setTransform(413.3929,491.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIADgrQAAgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_61.setTransform(365.525,491.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGAAIG5AAQAGAAAAAFIgDArQgBAFgGAAg");
	this.shape_62.setTransform(318.15,491.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQABgFAFAAIG6AAQAGAAgCAFIgFArQgBAFgFAAg");
	this.shape_63.setTransform(270.2,491.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#ACB6BF").s().p("AjiAbQgGAAABgFIAHgrQABgFAFAAIG9AAQAGAAgBAFIgKArQgBAFgFAAg");
	this.shape_64.setTransform(222.6255,491.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#ACB6BF").s().p("AjkAbQgFAAABgFIAMgrQACgFAFAAIG5AAQABAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgLArQgCAFgFAAg");
	this.shape_65.setTransform(174.8117,491.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#ACB6BF").s().p("AnAAbQgGAAACgFIAQgsQACgEAGAAINtAAQAAAAABAAQABAAAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgNArQgCAFgFAAg");
	this.shape_66.setTransform(105.5183,491.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#63717F").s().p("AnDApQgGAAgBgGIgJgqQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBQABgDAEAAIN4AAQAFAAABAGIAbAqQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAABIAAABIgBAAQgBADgDAAg");
	this.shape_67.setTransform(721.725,493.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#63717F").s().p("AjeApQgEAAgBgGIgHgqQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAgBIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAAAIAAAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAQABgDAEAAIG2AAQAGAAAAAGIAJAqIAAAEIAAAAIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAIgBABIAAABQgBACgDAAg");
	this.shape_68.setTransform(650.85,493.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#63717F").s().p("AjdApQgFAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABgBQABgDADAAIG3AAQAGAAABAGIAIAqQABABAAAAQAAAAAAABQAAAAAAAAQAAAAgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABQgBADgDAAg");
	this.shape_69.setTransform(603.475,493.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#63717F").s().p("AjkArQgFgBAAgFIgDguIABAAIAAgBIAAgBIAAgCIABAAIAAgDIAAAAIAAgCIABgBIAAgBIAAAAIAAgDIABAAIAAgCIAAgBIAAgCIABAAIAAgBIAAgBIAAgCIABgBIAAgCIAAAAIAAgBIABgBQAAgFAFAAIG5AAQAFAAABAFIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIAFArQABAGgGAAg");
	this.shape_70.setTransform(556.3571,493.35);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAAAIAAgCIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAgBQACgEADAAIG4AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAADIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAAAIABACIAEAqQAAAGgFAAg");
	this.shape_71.setTransform(508.525,493.35);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#63717F").s().p("AjkApQgFAAgCgFIAAgtIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAAAIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgBIABAAQABgFAEAAIG7AAQAEAAACAFIAAABIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIADAsQAAAFgFAAg");
	this.shape_72.setTransform(461.15,493.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#63717F").s().p("AjmApQgFAAAAgFIACgrIABgBIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAEAAIG7AAQAEAAABAFIAAAAIAAAAIAAABIABABIAAABIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIAAABIAAABIABAAIAAAtQAAAFgGAAg");
	this.shape_73.setTransform(413.4,493.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#63717F").s().p("AjmApQgGAAABgFIADgsIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBQABgFAEAAIG6AAQAEAAABAFIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAArQAAAFgGAAg");
	this.shape_74.setTransform(365.5179,493.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#63717F").s().p("AjnApQgGAAABgFIAFgrIABgBIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAFAAIG6AAQAEAAABAEIAAABIAAABIABAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAABIABACIgEArQAAAFgGAAg");
	this.shape_75.setTransform(318.0429,493.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#63717F").s().p("AjmApQgGAAABgFIAFgrIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQACgFAEAAIG6AAQAEAAABAEIAAABIAAAAIAAABIABABIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABABIAAABIAAAAIAAACIABABIAAACIAAABIAAACIABAAIAAACIgGArQAAAFgGAAg");
	this.shape_76.setTransform(270.0929,493.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIAAgBIABAAIAAgDIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBQACgFAEAAIG9AAQAEAAABAEIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAADIAAACIgJArQgBAFgGAAg");
	this.shape_77.setTransform(222.5423,493.15);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#63717F").s().p("AjgApQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgCIAAAAIAAgBIAAgBIAAgCIALgrQACgGAFAAIG5AAQAEAAABAEIAAAAIAAABIABABIAAAAIAAABIAAABIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAADIgLArQgCAFgFAAg");
	this.shape_78.setTransform(175.2,493.15);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#63717F").s().p("Am9AnQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIAAgDIAQgsQACgFAFAAINtAAQABAAABAAQAAABABAAQAAAAABABQAAAAAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIgNArQgBAGgGAAg");
	this.shape_79.setTransform(105.8625,492.925);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#ACB6BF").s().p("Aj9AcQgEAAgCgGIgNgrQgCgGAGAAIIIAAQAEABACAEIAPAsQACAGgGAAg");
	this.shape_80.setTransform(739.45,486);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#ACB6BF").s().p("AjWAcQgGAAgBgGIgKgrQAAgGAFAAIG6AAQAFAAACAGIAJArQABAGgGAAg");
	this.shape_81.setTransform(687.9,486);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgFAAg");
	this.shape_82.setTransform(640.1,486);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgGAAg");
	this.shape_83.setTransform(592.125,486);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#ACB6BF").s().p("AjcAcQgGAAAAgGIgCgrQgBgGAGAAIG6AAQAFAAABAGIAEArQABAGgFAAg");
	this.shape_84.setTransform(544.2255,486);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIAAgrQAAgGAFAAIG4AAQAFAAABAGIAEArQABAGgGAAg");
	this.shape_85.setTransform(496.7071,486);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#ACB6BF").s().p("AjdAcQgGAAAAgGIgBgrQAAgGAGAAIG6AAQAFAAABAGIADArQAAAGgGAAg");
	this.shape_86.setTransform(448.775,486);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAFAAIG7AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_87.setTransform(400.725,486);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAHAAIG5AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_88.setTransform(352.85,486);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#ACB6BF").s().p("AjgAcQgGAAABgGIAGgrQABgGAFAAIG6AAQAFAAAAAGIgEArQAAAGgFAAg");
	this.shape_89.setTransform(305.0173,486);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#ACB6BF").s().p("AjgAcQgFAAAAgGIAGgrQABgGAFAAIG6AAQAGAAgCAGIgFArQgBAGgFAAg");
	this.shape_90.setTransform(257.25,486);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ACB6BF").s().p("AjiAcQgGAAACgGIAFgrQABgGAGAAIG9AAQAFAAgBAGIgJArQgBAGgGAAg");
	this.shape_91.setTransform(209.5,486);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#ACB6BF").s().p("AjjAcQgGAAABgGIAMgrQABgGAGAAIG5AAQAGAAgBAGIgMArQgBAGgGAAg");
	this.shape_92.setTransform(161.675,486);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#ACB6BF").s().p("AlyAcQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIARgsQACgEAFgBILQAAQABAAABABQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_93.setTransform(99.5617,486);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#63717F").s().p("AkAAsQgHAAAAgGIgOgrIAAgDIABgBIAAgBIAAAAIAAgCIABAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBQABgEAEAAIIIAAQAEAAACAFIAPAsQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAABIAAABIgBABIAAABIAAABIAAABIgBABIAAABIAAABIAAABQgBADgDAAg");
	this.shape_94.setTransform(739.05,487.625);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#63717F").s().p("AjbApQgGAAgBgFIgJgrQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBQABgDAEAAIG6AAQAFAAACAGIAIAqIAAADIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAQgBADgEAAg");
	this.shape_95.setTransform(687.425,487.35);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#63717F").s().p("AjdApQgGAAgBgGIgHgqIABgDIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQAAgDAEAAIG3AAQAGAAABAGIAJAqIgBAEIAAAAIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBABIAAAAIAAABIAAABIAAAAIAAABIgBAAIAAAAIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABQAAAAgBABQAAAAAAAAQgBABgBAAQAAAAgBAAg");
	this.shape_96.setTransform(639.55,487.35);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#63717F").s().p("AjcApQgGAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQABgDAEAAIG3AAQAFAAABAGIAIAqIAAAEIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABQAAADgEAAg");
	this.shape_97.setTransform(591.65,487.35);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAAAQAAgFAFAAIG6AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAEArQABAGgGAAg");
	this.shape_98.setTransform(544.3071,487.525);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#63717F").s().p("AjnArQgGAAAAgFIAAgrIABgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBQABgDAEAAIG4AAQAEAAACAEIAAACIAAABIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAABIAAABIABAAIAEAsQABAFgGAAg");
	this.shape_99.setTransform(496.5321,487.55);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIG7AAQAEAAABAEIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIACAqQAAAGgFAAg");
	this.shape_100.setTransform(448.725,487.35);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#63717F").s().p("AjmApQgGAAABgGIACgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAAsQAAAGgGAAg");
	this.shape_101.setTransform(400.7179,487.35);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAAsQAAAGgGAAg");
	this.shape_102.setTransform(352.825,487.35);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#63717F").s().p("AjoApQgFAAABgGIAFgqIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG6AAQADAAACADIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAABIABAAIAAACIAAABIAAACIgDAqQgBAGgFAAg");
	this.shape_103.setTransform(304.9173,487.35);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#63717F").s().p("AjmApQgGAAABgGIAFgqIABgCIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCQACgEAEAAIG6AAQAEAAABADIAAABIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAADIgGAqQAAAGgGAAg");
	this.shape_104.setTransform(257.1429,487.35);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#63717F").s().p("AjoApQgGAAABgGIAHgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgDIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCQABgEAFAAIG9AAQAEAAABADIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAADIgJArQgBAFgGAAg");
	this.shape_105.setTransform(209.3929,487.35);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#63717F").s().p("AjfApQgEAAgBgDIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgDIAMgqQABgGAGAAIG5AAQAEAAABADIAAABIAAAAIAAACIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAAAIAAACQAAABABAAQAAAAAAAAQAAABAAAAQgBAAAAABIgLArQgBAFgGAAg");
	this.shape_106.setTransform(162.075,487.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#63717F").s().p("AluAnQgBAAgBAAQgBgBAAAAQgBAAAAgBQAAAAgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgDIAQgsQACgFAGAAILQAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_107.setTransform(99.9,487.125);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#ACB6BF").s().p("AoJAbQgFAAgBgFIgIgrQgBgFAGAAIQXAAQAGAAABAFIALArQABABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_108.setTransform(711.0623,480.325);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#63717F").s().p("AoNApQgFAAgBgFIgHgrQAAgBgBAAQAAAAAAAAQAAgBAAAAQABAAAAAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBQAAgEAEAAIQYAAQAFAAACAFIALAsIAAADIgBAAIAAABIAAAAIAAABIgBABIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAABQgBADgEAAg");
	this.shape_109.setTransform(710.625,481.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#ACB6BF").s().p("AjOAbQgFAAgBgFIgHgrQgBgFAFAAIGnAAQAFAAABAFIAHArQAAAFgFAAg");
	this.shape_110.setTransform(633.9923,480.325);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#63717F").s().p("AjQApQgGAAgBgFIgHgrQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgDIABAAIAAgDIABAAIAAgCIAAgBIAAgDIABAAIAAgDIAAAAIAAgCIABAAIAAgEIAAAAIAAgCIABgBIAAgCIAAgBIAAAAQABgEADAAIGnAAQAFAAABAGIAHAqIAAADIAAABIgBABIAAACIAAABIAAADIgBABIAAACIAAAAIAAACIgBABIAAADIAAABIAAACIgBAAIAAACIgBACIAAACIAAABQAAADgEAAg");
	this.shape_111.setTransform(633.75,481.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_112.setTransform(588.3505,480.325);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#63717F").s().p("AjSApQgFAAgBgFIgGgrIAAgCIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAEAAIGmAAQAGAAABAGIAEAqIAAADIAAABIAAAAIgBABIAAABIAAABIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBABIAAAAIAAABIAAABIgBABIAAABIAAAAIAAADIgBAAIAAACQgBADgEAAg");
	this.shape_113.setTransform(587.975,481.7);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_114.setTransform(543.0505,480.325);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#63717F").s().p("AjTAmQgFAAgBgFIgFgrIAAgDIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAGAAABAFIAEArIAAACIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABQgBADgEAAg");
	this.shape_115.setTransform(542.675,481.425);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#ACB6BF").s().p("AjRAbQgFAAAAgFIgDgrQgBgFAGAAIGnAAQAFAAAAAFIACArQAAAFgFAAg");
	this.shape_116.setTransform(497.0929,480.325);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#63717F").s().p("AjXAmQgGAAAAgFIgCguIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAFAAABAEIAAABIABABIAAACIAAAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIADAtQAAAFgGAAg");
	this.shape_117.setTransform(496.9,481.425);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#ACB6BF").s().p("AjRAbQgFAAgBgFIgCgrQAAgFAFAAIGpAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_118.setTransform(451.475,480.325);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#63717F").s().p("AjVApQgGAAAAgFIgDgrIABgBIAAgDIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIGpAAQAFAAAAAGIAAADIABAAIAAAFIAAAAIAAAFIABAAIAAAFIAAABIAAADIABABIAAAvQAAAFgGAAg");
	this.shape_119.setTransform(451.275,481.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#ACB6BF").s().p("AjSAbQgGAAABgFIACgrQAAgFAGAAIGiAAQAGAAAAAFIAAArQAAAFgGAAg");
	this.shape_120.setTransform(405.7929,480.325);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#63717F").s().p("AjZApQgFAAAAgFIADgtIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIABAAIAAgBQABgFAEAAIGjAAQAFAAAAAFIAAABIABABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAADIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIAAAAIAAADIABABIAAArQAAAFgGAAg");
	this.shape_121.setTransform(405.7,481.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#ACB6BF").s().p("AjUAbQgFAAAAgFIACgrQABgFAFAAIGmAAQAFAAAAAFIgDArQAAAFgGAAg");
	this.shape_122.setTransform(360.275,480.325);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#63717F").s().p("AjaApQgGAAAAgFIACgrIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgFAEAAIGnAAQAEAAABAFIAAABIAAABIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAABIAAAEIABAAIAAADIAAAAIAAAEIABABIgDArQgBAFgFAAg");
	this.shape_123.setTransform(360.025,481.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#ACB6BF").s().p("AjVAbQgFAAABgFIADgrQABgFAGAAIGlAAQAFAAgBAFIgDArQgBAFgFAAg");
	this.shape_124.setTransform(314.6,480.325);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#63717F").s().p("AjdApQgGAAABgFIAEgrIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBQACgFAEAAIGlAAQAEAAABAEIAAAAIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAACIgEArQAAAFgGAAg");
	this.shape_125.setTransform(314.7679,481.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#ACB6BF").s().p("AjVAbQgGAAABgFIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_126.setTransform(268.7745,480.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#63717F").s().p("AjeApQgHAAACgFIAIgrIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAAAQACgFAEAAIGhAAQAEAAABAEIAAAAIABABIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABACIgFArQAAAFgGAAg");
	this.shape_127.setTransform(268.8015,481.7);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#ACB6BF").s().p("AjVAbQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_128.setTransform(223.2259,480.325);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#63717F").s().p("AjRApQgDAAgCgDIAAgBIAAAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAIgrQACgFAFAAIGhAAQADAAACAEIAAABIABAAIAAACIAAAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAADIgFArQgBAFgEAAg");
	this.shape_129.setTransform(223.6,481.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#ACB6BF").s().p("AjYAbQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAMgrQACgFAFAAIGhAAQAGAAgBAFIgJArQgCAFgFAAg");
	this.shape_130.setTransform(177.5744,480.325);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#63717F").s().p("AjUApQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBIAAAAIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAAAIAAgDIAMgsQABgFAGAAIGhAAQAEAAAAADIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIgJArQgBAFgFAAg");
	this.shape_131.setTransform(178.0125,481.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#ACB6BF").s().p("AjaAbQgFAAACgFIAPgrQABgFAGAAIGhAAQAGAAgCAFIgLArQgCAFgFAAg");
	this.shape_132.setTransform(132.1238,480.325);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#63717F").s().p("AjYApQgDAAgBgDIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgDIgBAAIAAgEIAAAAIAAgCIgBgBIAAAAIABgCIAPgsQABgFAGAAIGhAAQAEAAABAEIAAADIAAAAIAAACIABABIAAADIAAAAIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAAAIAAADIABAAIAAAEIgMArQgBAFgGAAg");
	this.shape_133.setTransform(132.325,481.7);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#ACB6BF").s().p("AjYAbQgFAAABgFIAQgrQACgFAGAAIGdAAQAFAAgBAFIgNArQgBAFgGAAg");
	this.shape_134.setTransform(86.291,480.325);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#63717F").s().p("AjSApQAAAAgBAAQgBAAAAgBQAAAAgBAAQAAgBAAgBIgBAAIAAAAIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAAAIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIAAgDIAQgsQABgFAGAAIGeAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAEIgNArQgCAFgFAAg");
	this.shape_135.setTransform(86.9375,481.7);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#ACB6BF").s().p("AjpAQQgFAAABgFIAHgVQACgFAFAAIHIAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_136.setTransform(90.1744,475.225);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#63717F").s().p("AjiAfQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAAAIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAAAIAAgCIAHgXQACgFAFAAIHIAAQADAAABADIAAAAIABAAIAAABIAAAAIAAABIABABIAAAAIABACIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABABIAAABIABAAIAAABIAAAAIAAABIABACIAAABIABAAIAAABIAAAAIAAABIABAAIAAAAIABABIAAABIAAAAIAAABIABAAIAAABIABACIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAQABABAAAAQAAABAAAAQAAAAAAABQAAAAAAABIgEAVQgBAGgFAAg");
	this.shape_137.setTransform(90.92,476.7);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#ACB6BF").s().p("AjjAQQgFAAgCgFIgFgVQgBgFAFAAIHPAAQAFAAACAFIAFAVQAAABAAAAQABABAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAg");
	this.shape_138.setTransform(739.2367,475.225);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#63717F").s().p("AjpAhQgFAAgCgGIgFgWIAAgDIAAgBIABAAIAAgBIAAAAIAAAAIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAIHPAAQAFAAACAGIAGAWIAAADIgBAAIAAABIgBAAIAAAAIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABQgBADgDAAg");
	this.shape_139.setTransform(738.6,476.875);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHPAAQAFAAABAFIADAVQABAFgFAAg");
	this.shape_140.setTransform(689.1255,475.225);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#63717F").s().p("AjqAhQgFAAgBgGIgEgWIAAgCIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAQAAgEAEAAIHPAAQAFAAABAGIAEAVIAAADIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAAAQgCAEgDAAg");
	this.shape_141.setTransform(688.6,476.875);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHOAAQAGAAABAFIADAVQABAFgFAAg");
	this.shape_142.setTransform(639.3255,475.225);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#63717F").s().p("AjqAfQgFAAgBgFIgDgWQgBgBAAAAQAAAAAAAAQAAAAAAgBQAAAAABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgDADAAIHPAAQAFAAABAFIAEAWIAAACIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABQgBADgEAAg");
	this.shape_143.setTransform(638.775,476.725);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAFAAIHPAAQAGAAABAFIADAVQABAFgGAAg");
	this.shape_144.setTransform(589.4745,475.225);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#63717F").s().p("AjrAfQgFAAgBgFIgEgWIABgDIAAgBIAAAAIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBQAAAAAAgBQABAAAAgBQABAAAAAAQABAAABAAIHPAAQAFAAABAFIAEAWIAAAeQAAAEgFAAg");
	this.shape_145.setTransform(588.825,476.725);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#ACB6BF").s().p("AjnAQQgGAAAAgFIAAgVQAAgFAGAAIHPAAQAFAAAAAFIAAAVQAAAFgFAAg");
	this.shape_146.setTransform(539.65,475.225);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#63717F").s().p("AjtAhQgFAAAAgGIAAgWIAAgCIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAdIAAAAIAAANIAAAAIAAALQgBAGgFAAg");
	this.shape_147.setTransform(539.05,476.875);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#ACB6BF").s().p("AjnAQQgFAAAAgFIAAgVQAAgFAFAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_148.setTransform(489.85,475.225);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#63717F").s().p("AjuAhQgFAAAAgGIAAgWIAAgCIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAVIAAADIAAAAIgBABIAAAAIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABQgBAEgEAAg");
	this.shape_149.setTransform(489.175,476.875);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#ACB6BF").s().p("AjnAQQgGAAABgFIAAgVQgBgFAGAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_150.setTransform(439.8,475.225);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#63717F").s().p("AjqAeQgGAAAAgFIAAgXIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCQABgEAEgBIHPAAQAGABAAAFIAAAXIgBAAIAAABIAAABIAAACIgBAAIAAABIAAABIAAABIgBABIAAACIAAAAIAAADIgBAAIAAABIAAAAIAAACIgBABIAAACIAAAAIAAACIgBABIAAABIAAAAIAAACIgBAAIAAACQgBAEgEAAg");
	this.shape_151.setTransform(439.475,476.65);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#ACB6BF").s().p("AjoAQQgGAAABgFIADgVQABgFAFAAIHLAAQAFAAABAFIABAVQAAAFgGAAg");
	this.shape_152.setTransform(389.7673,475.225);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#63717F").s().p("Aj0AeQgFAAABgFIADgWIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgEAEgBIHLAAQAEABABADIAAABIABAAIAAABIAAABIAAAAIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABADIABAVQAAAFgFAAg");
	this.shape_153.setTransform(389.7673,476.65);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAGgVQACgFAFAAIHLAAQAFAAAAAFIgCAVQAAAFgGAAg");
	this.shape_154.setTransform(339.7089,475.225);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#63717F").s().p("AjyAeQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIAAgEIAGgWIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQACgGAFAAIHKAAQAEABABADIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAABIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIgCAVQAAAFgGAAg");
	this.shape_155.setTransform(339.4917,476.65);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAHgVQABgFAGAAIHKAAQAGAAgBAFIgCAVQAAAFgGAAg");
	this.shape_156.setTransform(289.9161,475.225);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#63717F").s().p("AjyAeQgFAAABgFIAHgWIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAQABgGAGAAIHKAAQAFABAAAEIAAABIAAAAIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAABIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIgCAVQgBAFgFAAg");
	this.shape_157.setTransform(289.6417,476.65);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#ACB6BF").s().p("AjrAQQgFAAACgFIAHgVQACgFAGAAIHKAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_158.setTransform(240.0398,475.225);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#63717F").s().p("Aj3AeQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAABgBIAIgWIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBQACgEAFgBIHKAAQAEABABADIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAACIgEAWQgBAFgFAAg");
	this.shape_159.setTransform(239.6917,476.65);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#ACB6BF").s().p("AjrAQQgFAAABgFIAIgVQACgFAGAAIHKAAQAFAAAAAFIgEAVQgBAFgFAAg");
	this.shape_160.setTransform(190.3089,475.225);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#63717F").s().p("AjuAeQgEAAAAgDIAAgdIAIgWQACgGAGAAIHKAAQAEABAAADIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBABAAAAIgDAWQgBAFgFAAg");
	this.shape_161.setTransform(190.625,476.65);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#ACB6BF").s().p("AjoAQQgGAAACgFIAGgVQACgFAGAAIHHAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIABAEIgEAVQgBAFgFAAg");
	this.shape_162.setTransform(140.3923,475.225);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#63717F").s().p("AjnAhQgDAAgBgEIAAgEIgBAAIAAgGIAAAAIAAgFIgBgBIAAgFIAAAAIAAgGIgBAAIAAgEQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAHgXQACgFAFAAIHIAAQAFAAAAAFIAAAEIAAABIAAAFIABABIAAAFIAAAAIAAAFIABAAIAAAGIAAAAIAAAFIgDAWQgBAGgGAAg");
	this.shape_163.setTransform(140.525,476.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Base
	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#CCD1D6").s().p("Eg9IABfIgOgBQgzgFgygPQhSgYglgqIABhmQAGAJAdAJQA7ASB1AAMB8ngABQBegEAIgTIAEApQABAvgKAhQgCAFgFADQgbAQgqAMQhFAUhZAAg");
	this.shape_164.setTransform(414.7094,544.625);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#BFC5CC").s().p("Eg9/AF6QhygEgrgXQgVgMACgLID9qLQAMgeBbgOQAtgHArgBITOAAUBeOgAEACqAAEQBrADArAeQAWAQAAAOIDwKCQALAdhBANIhEAGg");
	this.shape_165.setTransform(414.5991,502.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_165},{t:this.shape_164}]}).wait(1));

	// white screen
	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("Eg6nAhgMAAAhC+MB1PAAAMAAABC+g");
	this.shape_166.setTransform(415.625,235.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_166).wait(1));

	// Shadow
	this.instance_2 = new lib.Bitmap3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-15.1,450.85,2.603,2.603);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_vector, new cjs.Rectangle(-15.1,0,874.6,583.6), null);


(lib.laptop_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.laptop = new lib.laptop_vector();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(0.2,-0.05,0.6058,0.6058,0,0,0,0.3,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_mc, new cjs.Rectangle(-9.1,0,529.8000000000001,353.5), null);


(lib.laptop_ai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop.cache(-560,-555,1120,1110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.laptop = new lib.laptop_mc();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(156.3,106.5,1,1,0,0,0,156.3,106.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_ai, new cjs.Rectangle(-9.1,0,529.8000000000001,353.5), null);


(lib.Group_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(12,12,1,1,0,0,0,12,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_0, new cjs.Rectangle(0,0,24,24), null);


(lib.Group_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(24,20,1,1,0,0,0,24,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0, new cjs.Rectangle(0,0,48,40), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(1.9,7.8,1,1,0,0,0,1.9,7.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,3.9,15.7), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_9();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(-0.2,0,11.7,11.5), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Layer_3
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);
	this.instance.alpha = 0.8008;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Layer_3
	this.instance = new lib.ClipGroup_8();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,11,11), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.aimees_resume = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.resume.cache(-110,-115,220,230,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Aime'sResume
	this.resume = new lib.AimeesResume();
	this.resume.name = "resume";
	this.resume.parent = this;
	this.resume.setTransform(-0.5,-0.75);

	this.timeline.addTween(cjs.Tween.get(this.resume).wait(1));

}).prototype = getMCSymbolPrototype(lib.aimees_resume, new cjs.Rectangle(-55.3,-44.6,109.3,113.4), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(6.05,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D60BF").s().p("AojCiIAAlDIRHAAIAAFDg");
	this.shape.setTransform(-27.3,0.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-82.1,-15.4,109.6,32.4), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_71 = function() {
		exportRoot.tl1.play()
	}
	this.frame_75 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(71).call(this.frame_71).wait(4).call(this.frame_75).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(69.3,907.65,0.2717,0.2717,0,0,0,-40,1.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:4.0497,scaleY:4.0497,x:69.35,y:907.45},13,cjs.Ease.quadOut).to({x:-86},12,cjs.Ease.quadInOut).to({_off:true},1).wait(49));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgS1BKuIAAvKMA5EAAAIAAPKg");
	var mask_graphics_15 = new cjs.Graphics().p("EgTCBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_16 = new cjs.Graphics().p("EgTnBKuIAAvKMA5EAAAIAAPKg");
	var mask_graphics_17 = new cjs.Graphics().p("EgUmBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_18 = new cjs.Graphics().p("EgV9BKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_19 = new cjs.Graphics().p("EgXtBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_20 = new cjs.Graphics().p("EgZ2BKuIAAvKMA5EAAAIAAPKg");
	var mask_graphics_21 = new cjs.Graphics().p("Egb/BKuIAAvKMA5EAAAIAAPKg");
	var mask_graphics_22 = new cjs.Graphics().p("EgciBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_23 = new cjs.Graphics().p("EgciBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_24 = new cjs.Graphics().p("EgciBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_25 = new cjs.Graphics().p("EgciBKuIAAvKMA5FAAAIAAPKg");
	var mask_graphics_26 = new cjs.Graphics().p("EgciBKuIAAvKMA5FAAAIAAPKg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:244.7264,y:478.2004}).wait(1).to({graphics:mask_graphics_15,x:243.4795,y:478.2004}).wait(1).to({graphics:mask_graphics_16,x:239.7389,y:478.2004}).wait(1).to({graphics:mask_graphics_17,x:233.5045,y:478.2004}).wait(1).to({graphics:mask_graphics_18,x:224.7764,y:478.2004}).wait(1).to({graphics:mask_graphics_19,x:213.5545,y:478.2004}).wait(1).to({graphics:mask_graphics_20,x:199.8389,y:478.2004}).wait(1).to({graphics:mask_graphics_21,x:186.1233,y:478.2004}).wait(1).to({graphics:mask_graphics_22,x:167.125,y:478.2004}).wait(1).to({graphics:mask_graphics_23,x:149.6688,y:478.2004}).wait(1).to({graphics:mask_graphics_24,x:137.2,y:478.2004}).wait(1).to({graphics:mask_graphics_25,x:129.7188,y:478.2004}).wait(1).to({graphics:mask_graphics_26,x:127.225,y:478.2004}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-108.3,902.1,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(74.8,902.2,4.0499,4.0436,0,0,0,0.2,0.3);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(26));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,regX:0.2,regY:0.3,scaleX:4.0499,scaleY:4.0436,x:74.8,y:902.2},12,cjs.Ease.quadInOut).wait(50));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EgoSCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgpBCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgsOCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EgvmCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EgzKCXaMAAAkuzMBQlAAAMAAAEuzg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Eg26CXaMAAAkuzMBQlAAAMAAAEuzg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:70.4586,y:901.4773}).wait(51).to({graphics:mask_1_graphics_51,x:70.4586,y:901.4773}).wait(1).to({graphics:mask_1_graphics_52,x:69.2897,y:901.4773}).wait(1).to({graphics:mask_1_graphics_53,x:65.7829,y:901.4773}).wait(1).to({graphics:mask_1_graphics_54,x:59.9382,y:901.4773}).wait(1).to({graphics:mask_1_graphics_55,x:51.7558,y:901.4773}).wait(1).to({graphics:mask_1_graphics_56,x:41.2354,y:901.4773}).wait(1).to({graphics:mask_1_graphics_57,x:28.3772,y:901.4773}).wait(1).to({graphics:mask_1_graphics_58,x:13.1812,y:901.4773}).wait(1).to({graphics:mask_1_graphics_59,x:-4.3527,y:901.4773}).wait(1).to({graphics:mask_1_graphics_60,x:-24.2245,y:901.4773}).wait(1).to({graphics:mask_1_graphics_61,x:-46.4341,y:901.4773}).wait(1).to({graphics:mask_1_graphics_62,x:-70.9816,y:901.4773}).wait(1).to({graphics:mask_1_graphics_63,x:-97.8669,y:901.4773}).wait(1).to({graphics:mask_1_graphics_64,x:-127.0901,y:901.4773}).wait(1).to({graphics:mask_1_graphics_65,x:-158.6511,y:901.4773}).wait(1).to({graphics:mask_1_graphics_66,x:-192.55,y:901.4773}).wait(1).to({graphics:mask_1_graphics_67,x:-228.7868,y:901.4773}).wait(1).to({graphics:mask_1_graphics_68,x:-262.635,y:901.4773}).wait(1).to({graphics:mask_1_graphics_69,x:-283.0912,y:901.4773}).wait(1).to({graphics:mask_1_graphics_70,x:-304.7164,y:901.4773}).wait(1).to({graphics:mask_1_graphics_71,x:-327.5104,y:901.4773}).wait(1).to({graphics:mask_1_graphics_72,x:-351.5,y:901.4773}).wait(4));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(74.4,902.05,4.0497,4.0497,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).to({_off:true},25).wait(1));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(70.4,901.35,0.5313,2.3812,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-445.15},21,cjs.Ease.quadIn).to({_off:true},3).wait(1));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(70.4,901.35,0.5313,2.3812,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({regX:485.6,x:-445},21,cjs.Ease.quadIn).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-703,-67.5,1031.4,1938.1);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_7();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(-0.2,0,11.7,11.5), null);


(lib.bottom_barc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgCAFIAAgBIACAAIACgBIABgDQgBAAAAABQAAAAgBAAQAAAAAAAAQgBABAAAAIgCgBIgBgCIABgDIADgBIACABIAAAEIAAAEQgBAAAAABQAAAAgBAAQAAAAgBAAQAAAAAAAAIgCAAgAgBgDIAAACIAAABIABABIACgBIABgBIgBgCIgCgBIgBABg");
	this.shape.setTransform(237.25,-90.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AABAFIAAgIIgBAAIgBABIAAgBIABgBIACgBIAAAAIAAAKg");
	this.shape_1.setTransform(236.45,-90.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgCAEIgBgEIABgDQAAAAABgBQAAAAAAAAQABAAAAAAQAAgBAAAAQAEABAAAEIgBAEQgBAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAIgCgBgAgBAAQAAAFABgBQABAAAAAAQABAAAAgBQAAAAAAgBQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBgBAAQAAgBgBAAQgBABAAADg");
	this.shape_2.setTransform(235.825,-90.25);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgCAFIAAAAIAAgCIABgBIABgBIABgBIABgCIgBgBIgBgBIgBAAIgBABIAAgBIABgBIABAAIACABIABACIgBACIgBABIgBABIgBABIAAABIAEAAIAAABg");
	this.shape_3.setTransform(234.975,-90.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgCAHIAEgNIABAAIgEANg");
	this.shape_4.setTransform(234.2,-90.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AABAFIAAgIIgBAAIgBABIAAgBIABgBIACgBIAAAAIAAAKg");
	this.shape_5.setTransform(233.55,-90.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgCAHIAEgNIABAAIgEANg");
	this.shape_6.setTransform(233,-90.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AABAFIAAgCIgEAAIAAgBIADgDIABgEIABAAIAAAHIACAAIAAABIgCAAIAAACgAgBABIAAABIACAAIAAgFIgCAEg");
	this.shape_7.setTransform(232.25,-90.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAEAGIAAgHIAAgCIAAABIgDAIIgBAAIgDgIIgBgBIAAACIAAAHIgBAAIAAgLIACAAIADAHIAAABIABgBIADgHIABAAIAAALg");
	this.shape_8.setTransform(238.25,-92.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAEAGIgBgEIgFAAIgBAEIgBAAIAEgLIAAAAIAFALgAAAgCIgBADIADAAIgCgDIAAgBIAAABg");
	this.shape_9.setTransform(237.05,-92.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgCAEIgBgEIABgDQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBAAAAQAEAAAAAFIgBAEQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAIgCgCgAgBAAQAAAFABgBQABAAAAAAQAAAAABgBQAAAAAAgBQAAgBAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQgBAAAAAEg");
	this.shape_10.setTransform(235.775,-92.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AABAGIAAgJIgBABIgBABIAAgCIABgBIACgBIAAAAIAAALg");
	this.shape_11.setTransform(235,-92.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAAAEIAAgBIAAgBIAAAAIABABIAAAAIAAABIgBABgAAAgCIAAAAIAAgBIAAgBIAAAAIABAAIAAABIAAABIgBAAg");
	this.shape_12.setTransform(233.925,-92.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgCAEIgBgEIABgDQABAAAAgBQAAAAABAAQAAAAAAAAQAAgBAAAAQAEAAAAAFIgBAEQAAAAgBABQAAAAAAAAQgBAAAAAAQgBABAAAAIgCgCgAgBAAQAAAFABgBQABAAAAAAQAAAAABgBQAAAAAAgBQAAgBAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQgBAAAAAEg");
	this.shape_13.setTransform(232.725,-92.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AABAGIAAgJIgBABIgBABIAAgCIABgBIACgBIAAAAIAAALg");
	this.shape_14.setTransform(231.95,-92.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AADAHIAAgFQAAgBAAgBQgBAAAAAAQAAAAgBAAQAAgBgBAAIgBABIgBACIAAAFIgBAAIAAgNIABAAIAAAGIABAAQAAAAAAgBQABAAAAAAQAAAAAAAAQAAgBABAAQADAAAAAEIAAAFg");
	this.shape_15.setTransform(94.175,-91.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgBAFIgBgCIgBgDQAAAAAAAAQAAAAABgBQAAAAAAgBQAAAAABAAQAAgBAAAAQABAAAAgBQAAAAAAAAQABAAAAAAIADABIAAABIgDgBIgBABIgBACIABADIABABIADgBIAAACIgDAAIgCAAg");
	this.shape_16.setTransform(93.175,-91.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgCAFIAAgJIACAAIAAACIAAAAIAAgBIACgBIABAAIAAACIgCAAIgBABIAAABIAAAFg");
	this.shape_17.setTransform(92.425,-91.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AACAFIAAgBQAAAAAAAAQgBAAAAABQAAAAgBAAQAAAAAAAAIgCAAIgBgDQAAAAAAgBQABAAAAgBQAAAAABAAQABAAAAAAIACgBQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBABAAAAQgBAAAAABIAAgCIACgBIAAAAQABAAABAAQAAAAABABQAAAAABABQAAABAAAAIAAAGgAAAAAIgBABIAAABIAAACIABAAIACgBIAAgCIAAgBg");
	this.shape_18.setTransform(91.475,-91.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgCAEIgBgEIAAgBIACgCIABgBIADABIABADIAAAAIgGAAIABADIACABIADgBIAAACIgEAAIgCgBgAgBgCIgBACIAFAAIgBgCIgCgBIgBABg");
	this.shape_19.setTransform(90.475,-91.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgCAFIAAgCIACABQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAgBIgBgBIgBgBIgCAAIAAgBIABgCIACgBIACAAIAAACIgCgBIgBABIgBABIABAAIABABIACAAIAAACIgBADIgCAAIgCAAg");
	this.shape_20.setTransform(89.55,-91.2);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgDAEIgBgEIABgDIADgBIAEABIABADIgBAEIgEABIgDgBgAgBgCIgBACIABADIABABIACgBIABgDIgBgCIgCgBIgBABg");
	this.shape_21.setTransform(88.125,-91.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AACAGQgBAAgBAAQAAAAAAAAQAAAAAAgBQgBAAAAgBIAAgFIgBAAIAAgCIABAAIAAgCIABAAIAAACIADAAIAAACIgDAAIAAAFIAAABIACAAIABAAIAAABIgBAAg");
	this.shape_22.setTransform(87.2,-91.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgCAEIgBgEIAAgBIACgCIABgBIADABIABADIAAAAIgGAAIABADIACABIADgBIAAACIgEAAIgCgBgAgBgCIgBACIAFAAIgBgCIgCgBIgBABg");
	this.shape_23.setTransform(85.875,-91.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgCAFIAAgJIACAAIAAACIAAAAIAAgBIACgBIABAAIAAACIgCAAIgBABIAAABIAAAFg");
	this.shape_24.setTransform(85.075,-91.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgCAEIgBgEIAAgBIACgCIABgBIADABIABADIAAAAIgGAAIABADIACABIADgBIAAACIgEAAIgCgBgAgBgCIgBACIAFAAIgBgCIgCgBIgBABg");
	this.shape_25.setTransform(84.125,-91.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AADAHIAAgFQAAgBAAgBQgBAAAAAAQAAAAgBAAQAAgBgBAAIgBABIgBACIAAAFIgBAAIAAgNIABAAIAAAGIABAAQAAAAAAgBQABAAAAAAQAAAAAAAAQAAgBABAAQADAAAAAEIAAAFg");
	this.shape_26.setTransform(83.025,-91.45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgCAEIgBgEIAAgBIACgCIABgBIADABIABADIAAAAIgGAAIABADIACABIADgBIAAACIgEAAIgCgBgAgBgCIgBACIAFAAIgBgCIgCgBIgBABg");
	this.shape_27.setTransform(81.475,-91.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgEAHIAAgNIACAAIAAACIAAAAQABgBAAAAQAAgBABAAQAAAAAAAAQAAAAAAAAIADABQABAAAAABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABgBAAQAAAAAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBgBIAAAAIAAAGgAgBgEIgBACIAAACIABABIABABIACgBIABgDIgBgCIgCgBIgBABg");
	this.shape_28.setTransform(80.425,-90.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgDAHIAAgBIABAAIABgBIABgCIgEgJIACAAIACAGIAAABIAAgBIADgGIACAAIgFAKQAAABAAABQAAAAAAAAQgBABAAAAQgBAAAAAAIgBAAg");
	this.shape_29.setTransform(79.325,-90.975);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AAAAHIAAgMIgEAAIAAgBIAJAAIAAABIgEAAIAAAMg");
	this.shape_30.setTransform(78.325,-91.4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AhJBKQgfgeAAgsQAAgrAfgeQAfgfAqAAQArAAAgAfQAeAeAAArQAAAsgeAeQggAfgrAAQgqAAgfgfgAg6g7QgaAZAAAiQAAAjAaAZQAYAYAiAAQAkAAAYgYQAYgZABgjQgBgigYgZQgZgYgjAAQgiAAgYAYg");
	this.shape_31.setTransform(75.0438,-91.3469,0.125,0.125);

	this.instance = new lib.Group_2_0();
	this.instance.parent = this;
	this.instance.setTransform(75.1,-91.35,0.125,0.125,0,0,0,12.4,11.6);
	this.instance.alpha = 0.3984;

	this.instance_1 = new lib.Group_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(220,-91.7,0.1352,0.1352,0,0,0,5.9,4.8);
	this.instance_1.alpha = 0.3984;

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAAgVIg2A2IgFgGIA7g7IA8A7IgFAGg");
	this.shape_32.setTransform(211.6735,-91.6934,0.1352,0.1352);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AAUA8IgdgeIgUAAIAAg7IAUAAIAdgeIAKAAIAAB3gAgTAUIAOAAIAZAaIAAhaIgWAWIgDADIgOAAg");
	this.shape_33.setTransform(223.53,-91.6968,0.1352,0.1352);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgKAeQALgNAAgRQAAgQgLgNIAHgHQAOAPAAAVQAAAWgOAPg");
	this.shape_34.setTransform(224.3274,-91.6934,0.1352,0.1352);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgOAzQATgVAAgeQAAgdgTgVIAHgHQAWAYAAAhQAAAigWAYg");
	this.shape_35.setTransform(224.6755,-91.6934,0.1352,0.1352);

	this.instance_2 = new lib.Group_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(225.05,-91.8,0.1352,0.1352,0,0,0,2.6,7.4);
	this.instance_2.alpha = 0.3984;

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgJAAQAAgJAJAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgJAAAAgKg");
	this.shape_36.setTransform(220.6064,-91.0209,0.1352,0.1352);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#FFFFFF").ss(0.1).p("AgiAoQAAgfAWgVQAVgWAfAA");
	this.shape_37.setTransform(220.2009,-91.4264,0.1352,0.1352);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#FFFFFF").ss(0.1).p("AgTAZQAAgTANgLQANgOASAA");
	this.shape_38.setTransform(220.4037,-91.2237,0.1352,0.1352);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Ag1AUIAAgnIBrAAIAAAng");
	this.shape_39.setTransform(215.7743,-91.6934,0.1352,0.1352);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgHAKIAAgTIAPAAIAAATg");
	this.shape_40.setTransform(216.8353,-91.6968,0.1352,0.1352);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AhKAoIAAhPICVAAIAABPgAhAAeICBAAIAAg7IiBAAg");
	this.shape_41.setTransform(215.7878,-91.6968,0.1352,0.1352);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgfBRIgCgEIACgFIADgFQgCgDAAgEIAAgOIABgCIAthcIgFgCIgSAmIgCACIgDABQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIABgDIASgmIADgEIAFgCIAGABIAFADIAFgLIACgDIADAAIACAAIAEgHIADgDIAEgBQADAAACACIAHADIAEAEIACAFIgBAFIgDAFIACACIABACIAAABIgBACIg5BxIgCACIgNAHIgFABIgCAAIgEAIIgCACIgCABIgEgCgAgUAwIAAAMIABABIACABIABAAIACgCIADgBIAHgEIA1hqIgQgIgAAqhCIAHADIACgFIgHgDgAgtBTQgIAAgGgDQgIgEgEgEQgEgEgEgIQgDgGAAgIQAAgHADgHQADgGAFgFQAFgFAHgDQAGgDAIAAIASAAIgGALIgMAAQgGAAgEACIgJAFQgDADgCAFQgCAFAAAFQAAAGACAEQACAGADADQAEADAFACQAEACAGAAIADAAIgBADIAAAFIABADgAAnAVIAFgLIASAAIAEAAIADgDIACgDIABgEIgBgDIgCgDIgDgDIgEAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAEAAAEACIAGAEQADADACAEQACADAAAEQAAAFgCADQgCAEgDADIgGAEQgEACgEAAg");
	this.shape_42.setTransform(228.4276,-91.6934,0.1352,0.1352);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAIAnIgJgwIAAgCIAAgCIAAgCIgBgCIAAACIgBAEIAAACIgJAuIgPAAIgOhGIANgBIAHAvIABABIAAACIAAADIAAACIABgCIAAgCIALg0IANgBIALAyIAAABIAAACIABADIAAACIAAgCIAAgCIABgCIAAgCIAJg0IAPgBIgSBPg");
	this.shape_43.setTransform(145.0706,-91.3599,0.1306,0.1306);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#2B579A").s().p("AgPAVIAAgpIAfgFIAAAzg");
	this.shape_44.setTransform(145.1586,-91.3041,0.5939,0.5939);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#2B579A").s().p("AgrAFIAAgJIBXAAIAAAJg");
	this.shape_45.setTransform(146.4162,-90.5532,0.1306,0.1306);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#2B579A").s().p("AgrAGIAAgKIBXAAIAAAKg");
	this.shape_46.setTransform(146.4162,-90.8733,0.1306,0.1306);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#2B579A").s().p("AgrAGIAAgLIBXAAIAAALg");
	this.shape_47.setTransform(146.4162,-91.1934,0.1306,0.1306);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#2B579A").s().p("AgrAFIAAgJIBXAAIAAAJg");
	this.shape_48.setTransform(146.4162,-91.5102,0.1306,0.1306);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#2B579A").s().p("AgrAFIAAgJIBXAAIAAAJg");
	this.shape_49.setTransform(146.4162,-91.8303,0.1306,0.1306);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#2B579A").s().p("AgrAFIAAgKIBXAAIAAAKg");
	this.shape_50.setTransform(146.4162,-92.1471,0.1306,0.1306);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#2B579A").s().p("Ag4BfQgIAAAAgIIAAitQAAgIAIAAIBxAAQAIAAAAAIIAACtQAAAIgIAAgAg4BXIBxAAIAAitIhxAAg");
	this.shape_51.setTransform(146.4881,-91.3338,0.1306,0.1306);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("Ag4BXIAAitIBxAAIAACtg");
	this.shape_52.setTransform(146.4881,-91.3338,0.1306,0.1306);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#76B9ED").s().p("AjvAKIAAgTIHfAAIAAATg");
	this.shape_53.setTransform(145.7826,-88.8548,0.1306,0.1306);

	this.instance_3 = new lib.Group_1_0();
	this.instance_3.parent = this;
	this.instance_3.setTransform(145.8,-91.35,0.1306,0.1306,0,0,0,24.1,19.9);
	this.instance_3.alpha = 0.1992;

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#3276BC").s().p("Ag2BdQgcgbAAgnQAAgeARgXQAPgXAbgLQgOAPgDAXIBUAAQAAgzgwAAQgdAAgeARQgeARgRAbQAGguAegeQAfgeAugBQAvABAeAfQAfAgAAAxIAAAaIiWAAQAAAYASANQASAOAbAAQAlgBAdgSIAAAzQghARgpAAQgqAAgcgbg");
	this.shape_54.setTransform(139.5084,-91.3371,0.1306,0.1306);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#7FBA00").s().p("AgXAYIAAgvIAvAAIAAAvg");
	this.shape_55.setTransform(133.5574,-91.3959,0.1306,0.1306);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFB900").s().p("AgXAYIAAgwIAvAAIAAAwg");
	this.shape_56.setTransform(133.5574,-90.6316,0.1306,0.1306);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#F25022").s().p("AgYAYIAAgvIAxAAIAAAvg");
	this.shape_57.setTransform(132.7899,-91.3959,0.1306,0.1306);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#00A4EF").s().p("AgYAYIAAgwIAxAAIAAAwg");
	this.shape_58.setTransform(132.7899,-90.6316,0.1306,0.1306);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AheBxQgHAAgGgFQgFgFAAgHIAAiVIBFAAIAAgOQAAgTANgNQANgNARAAQASAAANANQANANAAATIAAAOIALAAIAAgFIgBgKQAAgNgGgLQAPALAAAXIAAAFIAyAAIAACVQAAAHgFAFQgFAFgHAAgAAIhbQgKAEgGAJQgHAJAAALIAAAFIAxAAIAAgOQAAgOgKgLQgKgKgOAAQgNAAgKAKQgKALAAAOIAAAOIALAAIAAgFQAAgUAPgMQAEgCADAAIAIABg");
	this.shape_59.setTransform(133.172,-91.3991,0.1306,0.1306);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#3AB5E6").s().p("AAeAtIAAgxIg7AAIAAAxIgoAAIAAhMQAAgGAEgDQADgEAGAAIBwAAQAGAAAEAEQAEADAAAGIAABMg");
	this.shape_60.setTransform(126.9696,-90.6839,0.1306,0.1306);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#3AB5E6").s().p("AgEAHIAAgNIAJAAIAAANg");
	this.shape_61.setTransform(125.8591,-92.3496,0.1306,0.1306);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AgUAHIAAgNIApAAIAAANg");
	this.shape_62.setTransform(126.1694,-92.3496,0.1306,0.1306);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFE793").s().p("AhiBQQgFAAgDgDQgDgDAAgFIAAiAIBTAAQAJAAAFgFIANgPIBhAAQAFAAAEAEQADADAAAGIAACHQAAAFgDADQgEADgFAAg");
	this.shape_63.setTransform(126.9696,-91.2718,0.1306,0.1306);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FBD140").s().p("Ag4AZIAAgkQAAgFADgEQADgEAFAAIBHAAQAHAAAFAFIATATIgRATQgGAGgIAAg");
	this.shape_64.setTransform(126.3654,-92.3485,0.1406,0.1406);

	this.instance_4 = new lib.ClipGroup_16();
	this.instance_4.parent = this;
	this.instance_4.setTransform(114.65,-91.5,0.134,0.134,0,0,0,5.6,7.9);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("ABABQIAAhLIALAAIAABLgAAVBQIAAgVIhfAAIAAAVIgKAAIAAggIB0AAIAAAggAhUAlIAAhJIB0AAIAABJgAhKAbIBfAAIAAg1IhfAAgAA/gGQgCAAgDgDQgDgDAAgCIgCgGQAAgEACgDIADgFIAFgDIAGgBIAHABIAFADIADAFIABAHIgBAGIgDAFIgFADQgDACgEAAIgGgCgABAgvIAAggIALAAIAAAggAhUgvIAAggIAKAAIAAAVIBfAAIAAgVIALAAIAAAgg");
	this.shape_65.setTransform(120.735,-91.3771,0.131,0.131);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AggAWIAAg1IBBAAIAAA/g");
	this.shape_66.setTransform(68.7747,-90.9121,0.131,0.131);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgpAaIAAg/IBTAAIAABLg");
	this.shape_67.setTransform(69.8815,-90.8302,0.131,0.131);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AggAeIAAgyIBBgJIAAA7g");
	this.shape_68.setTransform(68.7747,-91.8748,0.131,0.131);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgpAlIAAg9IBTgMIAABJg");
	this.shape_69.setTransform(69.8815,-91.96,0.131,0.131);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AAABLQAAgFgBgHQgCgDgFgHQgFgDgEgDQgGgCgGAAQgIAAgEACIgKAGQgEAHgCADQgCAFAAAHIgKAAIABgLQACgGADgEQACgEAFgFIAJgGQgGgEgDgHQgDgGAAgHQAAgHACgEQACgEAEgGIAKgFQAEgDAIAAQAHAAAGADQAGAEAFAFQADgGAEgEQAEgFAGgDQgGgFgDgFQgDgHAAgHQAAgHACgEQABgEAGgGIAJgHQAFgCAHAAQAGAAAFACQAGACAEAFQAFAGABAEQADAFAAAGQAAAFgEAJQgCAFgHAFIAJAHQAGAEACAEQACAEACAFIACALIgKAAQAAgFgDgGQgBgEgFgGQgEgEgGgBQgFgDgGAAQgHAAgFADIgJAFQgGAGgBAEQgCAEAAAHQAAAGgDAHQgCAHgHAEIAJAGQAFAFABAEQADAEACAGIACALgAglgCQgDABgDACIgFAGIgBAIIABAIIAFAGIAGAFIAIABIAHgBIAHgFIAEgGIACgIIgCgIIgEgGQgDgCgEgBIgHgCIgIACgAAWg/QgEACgCADIgFAGIgBAIIABAHIAFAHIAGAEIAIACIAIgCIAGgEIAEgHIACgHIgCgIIgEgGQgDgDgDgCIgIgBIgIABg");
	this.shape_70.setTransform(206.9241,-91.4459,0.131,0.131);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgdAyIgyAAIAAiBICfAAIAACBIgyAAIgeAegAhFAoIAsAAIAZAaIAZgaIAtAAIAAhtIiLAAg");
	this.shape_71.setTransform(241.5032,-91.3804,0.131,0.131);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FAFAFA").s().p("AjgAaIAAgzIHCAAIAAAzg");
	this.shape_72.setTransform(95.05,-91.475);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AuCAxIAAhhIcFAAIAABhg");
	this.shape_73.setTransform(155.075,-89.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.instance_4},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.instance_3},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.instance_2},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.instance_1},{t:this.instance},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#706F6F").s().p("AgHACIAAgEIAPAAIAAAEg");
	this.shape_74.setTransform(197.3467,-94.6611,0.1691,0.1691);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#706F6F").s().p("AgSADIAAgFIAlAAIAAAFg");
	this.shape_75.setTransform(197.9768,-95.0163,0.1691,0.1691);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#706F6F").s().p("AgSADIAAgFIAlAAIAAAFg");
	this.shape_76.setTransform(197.9768,-95.2869,0.1691,0.1691);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#706F6F").s().p("AgSADIAAgFIAlAAIAAAFg");
	this.shape_77.setTransform(197.9768,-95.5491,0.1691,0.1691);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#706F6F").s().p("AgSADIAAgFIAlAAIAAAFg");
	this.shape_78.setTransform(197.9768,-95.8197,0.1691,0.1691);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#706F6F").s().p("AgSADIAAgFIAlAAIAAAFg");
	this.shape_79.setTransform(197.9768,-96.0819,0.1691,0.1691);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#706F6F").s().p("AgSADIAAgFIAlAAIAAAFg");
	this.shape_80.setTransform(197.9768,-96.3525,0.1691,0.1691);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#706F6F").s().p("AgRADIAAgFIAjAAIAAAFg");
	this.shape_81.setTransform(196.7293,-95.0163,0.1691,0.1691);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#706F6F").s().p("AgRADIAAgFIAjAAIAAAFg");
	this.shape_82.setTransform(196.7293,-95.2869,0.1691,0.1691);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#706F6F").s().p("AgRADIAAgFIAjAAIAAAFg");
	this.shape_83.setTransform(196.7293,-95.5491,0.1691,0.1691);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#706F6F").s().p("AgRADIAAgFIAjAAIAAAFg");
	this.shape_84.setTransform(196.7293,-95.8197,0.1691,0.1691);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#706F6F").s().p("AgRADIAAgFIAjAAIAAAFg");
	this.shape_85.setTransform(196.7293,-96.0819,0.1691,0.1691);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#706F6F").s().p("AgRADIAAgFIAjAAIAAAFg");
	this.shape_86.setTransform(196.7293,-96.3525,0.1691,0.1691);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#706F6F").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_87.setTransform(197.3467,-94.9317,0.1691,0.1691);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#706F6F").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_88.setTransform(197.3467,-95.2023,0.1691,0.1691);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#706F6F").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_89.setTransform(197.3467,-95.4645,0.1691,0.1691);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#706F6F").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_90.setTransform(197.3467,-95.7351,0.1691,0.1691);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#706F6F").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_91.setTransform(197.3467,-95.9973,0.1691,0.1691);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#706F6F").s().p("AgHACIAAgDIAPAAIAAADg");
	this.shape_92.setTransform(197.3467,-96.2679,0.1691,0.1691);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#706F6F").s().p("AgBA7IAAh1IADAAIAAB1g");
	this.shape_93.setTransform(197.3425,-95.5279,0.1691,0.1691);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#706F6F").s().p("AgHADIAAgFIAPAAIAAAFg");
	this.shape_94.setTransform(197.3467,-96.5386,0.1691,0.1691);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#706F6F").s().p("AgfA6IAAhzIA+AAIAAAFIg4AAIAABpIA4AAIAAAFg");
	this.shape_95.setTransform(196.6828,-95.6844,0.1691,0.1691);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#706F6F").s().p("AgfA6IAAgFIA6AAIAAhpIg6AAIAAgFIA+AAIAABzg");
	this.shape_96.setTransform(198.0106,-95.6844,0.1691,0.1691);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#706F6F").s().p("AhDA/IAAh9ICHAAIAAB9gAg+A6IB9AAIAAhzIh9AAg");
	this.shape_97.setTransform(202.0235,-95.5956,0.1691,0.1691);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#706F6F").s().p("AgzADIAAgFIBnAAIAAAFg");
	this.shape_98.setTransform(202.0277,-94.9275,0.1691,0.1691);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#706F6F").s().p("AgzACIAAgEIBnAAIAAAEg");
	this.shape_99.setTransform(202.0277,-95.1939,0.1691,0.1691);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#706F6F").s().p("AgzADIAAgFIBnAAIAAAFg");
	this.shape_100.setTransform(202.0277,-95.4603,0.1691,0.1691);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#706F6F").s().p("AgzACIAAgEIBnAAIAAAEg");
	this.shape_101.setTransform(202.0277,-95.7267,0.1691,0.1691);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#706F6F").s().p("AgzACIAAgDIBnAAIAAADg");
	this.shape_102.setTransform(202.0277,-95.9973,0.1691,0.1691);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#706F6F").s().p("AgzACIAAgEIBnAAIAAAEg");
	this.shape_103.setTransform(202.0277,-96.2595,0.1691,0.1691);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#747474").s().p("Ag7A3IAAhtIB3AAIAAA0IgEAAIAAgvIhvAAIAABjIA1AAIAAAFg");
	this.shape_104.setTransform(206.5185,-95.8155,0.1691,0.1691);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#747474").s().p("AgPADIAAgFIAfAAIAAAFg");
	this.shape_105.setTransform(206.121,-95.2827,0.1691,0.1691);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#747474").s().p("AgUADIAAgFIApAAIAAAFg");
	this.shape_106.setTransform(206.2056,-95.5491,0.1691,0.1691);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#747474").s().p("AgcADIAAgFIA5AAIAAAFg");
	this.shape_107.setTransform(206.3451,-95.8155,0.1691,0.1691);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#747474").s().p("AgnADIAAgFIBPAAIAAAFg");
	this.shape_108.setTransform(206.5185,-96.0861,0.1691,0.1691);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#747474").s().p("AgnADIAAgFIBPAAIAAAFg");
	this.shape_109.setTransform(206.5185,-96.3483,0.1691,0.1691);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#747474").s().p("AgbAcQgLgMAAgQQAAgPALgLQAMgMAPAAQARAAALAMQALALAAAPQAAAQgLAMQgLALgRAAQgPAAgMgLgAggAAQAAANAKAKQAKAKAMAAIAGgBIgBgEIgCgGIgDgMQgDgKgFgCIgEgBQgGgDgBgJIgCgDIgDgBIgBAAQgGAJgBAKgAAKgZIgBADIgGAIIgDAIIAAAEQAAACAHADIAWAJIABABQADgGAAgHQAAgSgSgKg");
	this.shape_110.setTransform(207.1951,-95.1347,0.1691,0.1691);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#797775").s().p("AgZA6IAAhzIAzAAIAABzg");
	this.shape_111.setTransform(221.5182,-95.7426,0.1684,0.1684);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#676767").s().p("AgeAMIAAgXIA+AAIAAAXg");
	this.shape_112.setTransform(210.3305,-95.7131,0.1684,0.1684);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#676767").s().p("AgGApIAAgiIgiAAIAAgNIAiAAIAAgiIAOAAIAAAiIAhAAIAAANIghAAIAAAig");
	this.shape_113.setTransform(230.4069,-95.7131,0.1684,0.1684);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#B3B0AD").s().p("AgEAZIAAgxIAJAAIAAAxg");
	this.shape_114.setTransform(220.436,-95.7131,0.1684,0.1684);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#B3B0AD").s().p("AoHAFIAAgJIQPAAIAAAJg");
	this.shape_115.setTransform(220.4445,-95.7384,0.1684,0.1684);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#707070").s().p("AghABIgBgBIABAAIAGgGIABgBIACABIARASIAggpIABAAIABAAIAHAFIABABIgBACIgoA0g");
	this.shape_116.setTransform(96.2241,-95.7076,0.1788,0.1788);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#707070").s().p("AgBA8QABgGgdAAIgnAAIAAhxIAZAAQAkAAAHAOQAKgOAhAAIAaAAIAAAYIgFAGIAAgZIgVAAQgoAAAAARIAABaQADgDAIAAIAyAAIAAgyIAFgEIAAA6IgnAAQgbAAAAAGgAhAAyIAjAAQAZAAADADIAAhaQAAgRgqAAIgVAAg");
	this.shape_117.setTransform(95.3837,-95.6317,0.1788,0.1788);

	this.instance_5 = new lib.Ready_txt();
	this.instance_5.parent = this;
	this.instance_5.setTransform(78.15,-100.05,1,1,0,0,0,11.5,6.7);

	this.instance_6 = new lib.Percentage_txt();
	this.instance_6.parent = this;
	this.instance_6.setTransform(241,-104.4,1,1,0,0,0,10.1,6.7);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#F3F2F1").s().p("EgjIAAzIAAhlMBGRAAAIAABlg");
	this.shape_118.setTransform(155.3784,-95.6139,0.397,0.3986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_118},{t:this.instance_6},{t:this.instance_5},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottom_barc, new cjs.Rectangle(65.2,-97.7,179.8,13.100000000000009), null);


(lib.bottombar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bar.cache(-350,-300,700,600,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bar = new lib.bottom_barc();
	this.bar.name = "bar";
	this.bar.parent = this;
	this.bar.setTransform(157.4,-110.85,1,1,0,0,0,157.4,-93.8);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottombar, new cjs.Rectangle(65.2,-114.7,179.8,13.100000000000009), null);


(lib.Word = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// top bar
	this.bar = new lib.topbar();
	this.bar.name = "bar";
	this.bar.parent = this;
	this.bar.setTransform(148.75,-2.75,1,1,0,0,0,672.1,135.8);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

	// Bottom_bar
	this.bar2 = new lib.bottombar();
	this.bar2.name = "bar2";
	this.bar2.parent = this;
	this.bar2.setTransform(146.9,87.9,1,1,0,0,0,155.4,-109.8);

	this.timeline.addTween(cjs.Tween.get(this.bar2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Word, new cjs.Rectangle(56.7,-12.7,181.3,108.8), null);


(lib.devices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Word
	this.instance = new lib.Word();
	this.instance.parent = this;
	this.instance.setTransform(180.7,206.95,1,1,0,0,0,150.1,45.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Screen
	this.screen = new lib.screen();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(146.2,189.75,0.9988,0.9988,0,0,0,68.6,-161.7);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// ScrollBar
	this.scroll_bar = new lib.scroll_bar();
	this.scroll_bar.name = "scroll_bar";
	this.scroll_bar.parent = this;
	this.scroll_bar.setTransform(186.6,204.45,1,1,0,0,0,1.2,40.7);

	this.timeline.addTween(cjs.Tween.get(this.scroll_bar).wait(1));

	// Aimee_resume
	this.resume_1 = new lib.aimees_resume();
	this.resume_1.name = "resume_1";
	this.resume_1.parent = this;
	this.resume_1.setTransform(96.3,167.3,0.7877,0.7877,0,0,0,-53.6,-44.1);

	this.timeline.addTween(cjs.Tween.get(this.resume_1).wait(1));

	// bg
	this.instance_1 = new lib.bg();
	this.instance_1.parent = this;
	this.instance_1.setTransform(177.2,200.35,1,1,0,0,0,88.5,40.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.devices, new cjs.Rectangle(87.2,148.7,181.5,108.80000000000001), null);


(lib.anim_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.parent = this;
	this.icon.setTransform(9.85,12.45,0.8902,0.8902,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("At5H7IAAv1IbzAAIAAP1g");
	mask.setTransform(149.775,143.175);

	// Devices
	this.devices = new lib.devices();
	this.devices.name = "devices";
	this.devices.parent = this;
	this.devices.setTransform(153.9,635.55,1,1,0,0,0,181.6,696.4);

	var maskedShapeInstanceList = [this.devices];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.devices).wait(1));

	// laptop
	this.instance = new lib.laptop_ai();
	this.instance.parent = this;
	this.instance.setTransform(111.95,129.15,0.3977,0.3977,0,0,0,156.7,106.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Shadow
	this.shadow = new lib.shadowcache();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(148.15,191.95,0.3954,0.3954,0,0,0,474.9,72.2);

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(46.85,194.35,0.6245,0.6245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shadow}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.anim_blue, new cjs.Rectangle(-39.6,75.5,375.6,151.9), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(145.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos_1();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(100.8,569.4,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(135.15,569.2,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Mobile
	this.mobile_device = new lib.mobile_device();
	this.mobile_device.name = "mobile_device";
	this.mobile_device.parent = this;
	this.mobile_device.setTransform(-138.5,305.9);

	this.timeline.addTween(cjs.Tween.get(this.mobile_device).wait(1));

	// anim
	this.anim_1 = new lib.anim_blue();
	this.anim_1.name = "anim_1";
	this.anim_1.parent = this;
	this.anim_1.setTransform(-26.95,212.05,0.9187,0.9187,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.anim_1).wait(1));

	// logo
	this.logo_1 = new lib.logos();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(62.15,40.2,1,1,0,0,0,0.4,0.7);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#ECEDEF","#FFFFFF"],[0,1],-4,197.6,-5.3,76.9).s().p("EgMjAu4MAAAhdvIZHAAMAAABdvg");
	this.shape.setTransform(80.4,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-63.3,-1.4,345.1,604.6999999999999), null);


// stage content:
(lib.O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var mobile = mc.mobile_device
		var devices = mc.anim_1
		var laptop = mc.anim_1.devices
		var scrollbar = mc.anim_1.devices.scroll_bar
		var resume = mc.anim_1.devices.resume_1
		var shadow = mc.anim_1.shadow
		
		mc.cta.alpha=0
		mc.anim_1.alpha=0
		mc.replay_btn.alpha=0
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.anim_1.alpha=1
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
			
				
				exportRoot.tl1.from(devices, 2, {x: "+=300", ease:Power3.easeOut}, "-=0.3");
				
				//Rock
				exportRoot.tl1.from(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.6");
		
		
				//your resume
				exportRoot.tl1.from(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0");
				exportRoot.tl1.from(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.25");
				
				
				exportRoot.tl1.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
				exportRoot.tl1.to(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
		
				//With
				exportRoot.tl1.from(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
		
				
				
				//AI-powered
				exportRoot.tl1.from(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.from(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.25");
			
				exportRoot.tl1.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.75");
				exportRoot.tl1.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				
				
				//features
				exportRoot.tl1.from(exportRoot.headline10, 0.01, {alpha: 0, ease:Power4.easeOut,onComplete:function(){laptop.screen.gotoAndPlay(1)}}, "-=0");
				exportRoot.tl1.to(exportRoot.headline10, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
		
				
				//in Word
				exportRoot.tl1.from(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.from(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeOut,onComplete:function(){exportRoot.tl1.stop()}}, "+=.25");
				
				exportRoot.tl1.to(exportRoot.headline6, 0.5, {alpha: 0, ease:Power4.easeIn}, "+=0.25");
				exportRoot.tl1.to(exportRoot.headline7, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
				
				
				//exportRoot.tl1.to(devices, 1.75, {x:"+=105", y:"+=6", scaleX:1, scaleY:1, ease:Power3.easeInOut}, "-=1");
				//exportRoot.tl1.to(shadow, 1.75, {alpha: 0.2, ease:Power3.easeInOut}, "-=1.75");
				//exportRoot.tl1.to(scrollbar, 1.75, {x:"-=42",  ease:Power3.easeInOut}, "-=1.75");
				//exportRoot.tl1.to(laptop.screen, 1.75, {x:"-=42",  ease:Power3.easeInOut}, "-=1.75");
				//exportRoot.tl1.to(resume, 1.75, {x:"-=8", y:"+=0", scaleX:0.75, scaleY:0.75,  ease:Power3.easeInOut}, "-=1.75");
		
		
				exportRoot.tl1.from(mobile, 1, {x:"-=100",alpha: 0, ease:Power3.easeOut}, "-=0.4");
		
						
				for (var i = 0; i < exportRoot.headline11.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.4");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline12.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=0.6");	
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=50",	ease:Power4.easeOut}, "-=0.6");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=50", ease:Power4.easeOut}, "-=0.7");
			
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(16.7,298.6,265.1,304.69999999999993);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574939719704", id:"O365_NewYearCampaign_USA_160x600_BAN_Word_Resume_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;