(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[0,0,336,51],[338,0,69,69],[0,53,266,43]]}
];


// symbols:



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ExcelIcon = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.phoneshadow = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A4/MAAAhx9MCXtAAAMAAABx9g");
	this.shape.setTransform(485.475,149.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,-214.9,971,729.5), null);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.phoneshadow();
	this.instance.parent = this;
	this.instance.setTransform(0,0,2.2121,2.2121);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,588.4,95.1), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.laptop_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Phone_vector resize.ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#121212").s().p("AABACIgBgBQgBgBAAAAQAAAAgBAAQAAgBABAAQAAAAAAgBIABACIADACIgCABIAAgBg");
	this.shape.setTransform(212.0139,22.1772,2.7448,2.5752);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B4B4B4").s().p("AgBgBIAAAAQACAAABADIAAAAIgBAAQgCAAAAgDg");
	this.shape_1.setTransform(212.1707,22.0811,2.7448,2.5752);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#060606").s().p("AgFAAQAAgFAFAAQAGAAAAAFQAAAGgGAAQgFAAAAgGg");
	this.shape_2.setTransform(211.3473,22.8983,2.7448,2.5752);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#121212").s().p("AABAJIgFgGQgIgFAHgHIAFAJQADAGAGAAQgCAEgDAAIgDgBg");
	this.shape_3.setTransform(252.2912,21.4968,2.7448,2.5752);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B4B4B4").s().p("AgDAEQgFgEABgHQANABADAMIgCACIgDAAQgEAAgDgEg");
	this.shape_4.setTransform(252.9081,21.137,2.7448,2.5752);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#060606").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAIAAAHAGQAGAGAAAIQAAAJgGAGQgHAGgIAAQgIAAgGgGg");
	this.shape_5.setTransform(250.0489,24.1859,2.7448,2.5752);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#929292").s().p("ArtBaQhUAAgxguQgtgqgIhJQAHA1AeAmQAyBCBkAAIXRAAQBmAAA0hEQAlguAEg9QgEBNgqAuQgzA4hhAAg");
	this.shape_6.setTransform(258.3957,954.2405,2.7427,2.5736);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E4E4E4").s().p("AODgNQg1hIhoAAI3MAAQhhAAg2BCQgmAugFA+QAEhIAlgsQAzg+BmAAIXNAAQBgAAA0A5QAqAvAEBLQgEg6gigtg");
	this.shape_7.setTransform(258.1558,22.916,2.7427,2.5736);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#121212").s().p("EggyBLvQiwgBh8h0Qh9h2AAilMAAAiJ0QAAjECTiKQCUiKDQAAMBAXAAAQCwAAB8B1QB9B0AACmMAAACK9QAAClh9B2Qh8B0iwABg");
	this.shape_8.setTransform(258.175,488.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B9B9B9").s().p("ArrdrQhZAAgzg1QgygzAAhbMAAAg1PQAAhaA0g0QA1g1BbgBIXLAAQBaABA1A1QA1A0AABaMAAAA1PQAABag1A0Qg1A1haAAg");
	this.shape_9.setTransform(258.1803,488.7475,2.743,2.5738);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#313131").s().p("AgDijQADAAABADQADACgBADIAAE3QAAAIgGAAg");
	this.shape_10.setTransform(516.5916,274.9664,2.7449,2.5754);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#313131").s().p("AABEmQgEAAAAgFIAApBQAAgFAEAAIADAAIAAJLg");
	this.shape_11.setTransform(-0.0707,228.1587,2.7449,2.5754);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_vector, new cjs.Rectangle(-1.1,-0.1,518.7,977.8000000000001), null);


(lib.Path_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfQANAAAJAKQAJAIAAANg");
	this.shape.setTransform(1.625,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3_0, new cjs.Rectangle(0,0,3.3,3.2), null);


(lib.Path_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAIIAAgPQAIAAADAFQAGADAAAHg");
	this.shape.setTransform(0.85,0.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,1.7,1.7), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ExcelIcon();
	this.instance.parent = this;
	this.instance.setTransform(-51.75,-51.75,1.5,1.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(-51.7,-51.7,103.5,103.5), null);


(lib.halfpie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4CA067").s().p("ACDQ5QjShZiiiiQijijhZjTQhcjZAAjvQAAjuBcjZQBZjTCjijQCiiiDShZQDZhcDugBMAAAAkrQjugBjZhcg");
	this.shape.setTransform(58.6254,117.3527);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.halfpie, new cjs.Rectangle(0,0,117.3,234.7), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhJWAdDMAAAg6FMCStAAAMAAAA6Fg");
	mask.setTransform(469.5,185.875);

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(0,0,0,0), null);


(lib.ClipGroup_51 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#484B4B").ss(1.5,1,1).p("Ag9gbIA9A5IA+g7");
	this.shape.setTransform(424.775,107.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#C6C6C6").ss(1,2,1).p("AAAidIAAE7");
	this.shape_1.setTransform(58.55,109.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#777777").ss(0.5).p("AAegbQABAAAAACIgCAHQAAABgBAAIgTAAQgIAigDAMQgMAngSAAQgLAAAAgIQAAgHAGAAQAFAAABAHQAAACACAAQAJAAAIglIAKgqIgRAAQgBAAAAgBIABgHQABgCABAAIARAAQAHgWAGgIQAIgKAKAAQANAAAAAJQAAAHgGAAQgFAAgBgGQAAgFgEAAQgGAAgFANQgCAFgEARg");
	this.shape_2.setTransform(33.7021,109.8863,1.5017,1.5017);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#777777").s().p("AhOBrQAAgMALAAQAJAAACANQAAABAAABQAAAAABABQAAAAABAAQAAABABAAQARAAAOhDIAShLIgfAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAIADgOIACgBIAgAAQAMgqALgOQAPgSASABQAXgBAAARQAAAMgKAAQgKAAgCgLQAAgIgHABQgLgBgIAWQgEAKgIAgIAkAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAIgDAOQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAIgjAAQgPA7gGAXQgVBGghAAQgTAAAAgPg");
	this.shape_3.setTransform(33.6537,109.7144,0.8333,0.8333);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#777777").ss(0.8).p("AgCgXIADAFIADAKIAFgHQACgDACgCIAFgDIACAAQADAAABABIABADIAAADQgCABgCAAIgCAAQgCgBgBAAIgDABQgEADgEAIIAGAWIABABIADgCQACgCADgEIABABQgDAGgFAEQgDADgCAAQgDAAgCgEIgDgRQgJAOgEAEQgEADgCAAQgDAAgBgCIgCgDQAAgCACgBQAAgBACAAQACAAACACQABABABAAIACgBQADgDADgGIAGgJIgDgNQgCgEgCgBQgCgBgDAAIgDAAIAAgCg");
	this.shape_4.setTransform(39.8087,112.5039,1.5017,1.5017);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#777777").s().p("AADAVIgDgSQgIAPgFAEQgDADgDAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAIgCgDQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAIADgBQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAABIACAAIACAAQADgDADgGIAHgJIgEgNIgEgFIgFgBIgDAAIAAgCIAOgDIADAGIADAKIAFgHIAFgFIAEgDIACgBQABAAABABQAAAAABAAQAAAAABAAQAAABABAAIABADIgBACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgCgBIgDgBIgDACQgEADgEAHIAGAXIABAAIADgBIAFgGIABABQgDAGgEAEIgGADQgCAAgDgEg");
	this.shape_5.setTransform(39.7966,112.5394,1.5017,1.5017);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(1.5,1,0,3).p("Ahfg9ICMAAQAaAAANATQANARgBAZQgBAZgNASQgOATgXAAIgWAA");
	this.shape_6.setTransform(220.8037,69.15);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(1.5,1,0,3).p("AAhg9Ig+A9IA+A/");
	this.shape_7.setTransform(213.5697,63.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#C6C6C6").ss(1,1,1).p("Egg/gCtMBB/AAAQAeAAAAAeIAAEfQAAAegeAAMhB/AAAQgeAAAAgeIAAkfQAAgeAeAAg");
	this.shape_8.setTransform(226.1527,109.3267,1.0001,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Egg/ACuQgeAAAAgeIAAkfQAAgeAeAAMBB/AAAQAeAAAAAeIAAEfQAAAegeAAg");
	this.shape_9.setTransform(226.1527,109.3267,1.0001,1);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_51, new cjs.Rectangle(10.9,55.9,430.5,71.9), null);


(lib.ClipGroup_50 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("AhUBWIgBAAIAAgDIALgvIAAgBIBwhxQAIgIANAAQALAAAIAIQAIAJAAAMQAAALgIAIIhwBxIgBAAIAAABIgvALgAhGBGQADADgDADIgDABIAhgHIADgPIgQADIgCAAIgBgBIAAgCIgBAAIAAgBIACgPIgNABIgJAhIADgDQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAAAIADACgAAmgUQABABAAABQABAAAAABQAAAAgBABQAAAAgBABIhFBFIAAAJIBUhVIgegfIhWBWIAKgBIBFhGQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAABQABAAAAABQAAAAgBABQAAAAgBABIhFBFIgCAPIAQgBIBFhGIACAAIACAAgAAbg5IAgAeIAEgEIgggfgAAlhCIAeAfIAEgFIgegfgAAthLIAeAfQALgOgMgPQgIgHgIAAQgHAAgGAFg");
	this.shape.setTransform(553.525,61.625);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AArBNIgQgwIg2AAIgPAwIgWAAIA1iZIAXAAIA1CZgAAXANIgPgrIgEgPIgEgNIgDANIgFAPIgOArIAtAAg");
	this.shape_1.setTransform(545.75,60.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Livello_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(1.5,1,0,3).p("AAeAfIg7g9");
	this.shape_2.setTransform(608,64.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(1.5,1,0,3).p("ABQAAQAAAhgYAXQgXAYghAAQggAAgYgYQgXgXAAghQAAggAXgYQAYgXAgAAQAhAAAXAXQAYAYAAAgg");
	this.shape_3.setTransform(599.275,56.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAGATQgHAAgHABIgOAEIgMAIQgGADgFAGIAAgHQAAgIACgGIAFgNQADgGAEgDIALgIQAEgDAIgDIAOgCIAAgWIAoAoIgoApgAgFgJIgGACIgJAGQgEABgEAFIgGAJQgCAEgBAGQAJgGALgDQALgEAMAAIAHAAIAAAMIAXgXIgXgWIAAAMIgGAAg");
	this.shape_4.setTransform(654.1195,54.9175,2.129,2.129);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhYBAIAAh/IAMAAIAABzICaAAIAAglIALAAIAAAxg");
	this.shape_5.setTransform(648.725,63.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_50, new cjs.Rectangle(533.3,41,130.70000000000005,38.599999999999994), null);


(lib.ClipGroup_49 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ClipGroup_47_B = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgTAUQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(1396.1,784.4,0.9599,0.9598,0,0,0,0.2,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgTAUQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_1.setTransform(1386.0532,784.3695,0.9599,0.9599);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgTAUQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_2.setTransform(1376.5532,784.3695,0.9599,0.9599);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_47_B, new cjs.Rectangle(1373.9,781.6,24.699999999999818,5.5), null);


(lib.ClipGroup_47 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#464646").s().p("AgTAUQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape.setTransform(1383.3032,784.4485,0.8,0.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#464646").s().p("AgTAUQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_1.setTransform(1375.4532,784.5104,0.8,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#464646").s().p("AgTAUQgIgIAAgMQAAgLAIgIQAIgIALAAQAMAAAIAIQAIAIAAALQAAAMgIAIQgIAIgMAAQgLAAgIgIg");
	this.shape_2.setTransform(1366.9532,784.5104,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_47, new cjs.Rectangle(1364.7,782.2,20.899999999999864,4.599999999999909), null);


(lib.ClipGroup_45 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag4AZIAAgkQAAgFADgEQADgEAFAAIBHAAQAHAAAFAFIATATIgRATQgGAGgIAAg");
	mask.setTransform(5.8,2.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F9D04C","#F9D04C"],[0,1],-5.7,0,7.2,0).s().p("Ag5AZIAAgxIBzAAIAAAxg");
	this.shape.setTransform(5.75,2.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_45, new cjs.Rectangle(0.1,0,11.4,5), null);


(lib.ClipGroup_43 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_43, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_42 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_42, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_41 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_41, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_40 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_40, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_39 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_39, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_38 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_37 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_37, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_36 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_34, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_33, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_30, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_28, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_25, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_23, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_20_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask.setTransform(12.5,0.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20_0, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhGBfIAAi9ICNgZIAADvg");
	mask.setTransform(7.1,12);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#1A171B"],[0,1],-6.9,0,6.9,0).s().p("AhGB4IAAjvICNAAIAADvg");
	this.shape.setTransform(7.1,12);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20, new cjs.Rectangle(0,0,14.2,24), null);


(lib.ClipGroup_19_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_18_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjvDIIAAmPIHfAAIAAGPg");
	mask.setTransform(24,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3677B9").s().p("AjvDIIAAmPIHfAAIAAGPg");
	this.shape.setTransform(24,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0,0,48,40), null);


(lib.ClipGroup_17_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjvDIIAAmPIHfAAIAAGPg");
	mask.setTransform(24,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjvDIIAAmPIHfAAIAAGPg");
	this.shape.setTransform(24,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0,0,48,40), null);


(lib.ClipGroup_16_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ah3B4IAAjvIDvAAIAADvg");
	mask.setTransform(12,12);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhUBVQgjgjAAgyQAAgwAjgkQAkgjAwAAQAyAAAjAjQAjAkAAAwQAAAygjAjQgjAjgyAAQgwAAgkgjgAhIhIQgfAeAAAqQAAArAfAfQAeAeAqAAQArAAAegeQAfgfgBgrQABgqgfgeQgegegrAAQgqAAgeAeg");
	this.shape.setTransform(12,12);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0,24,24), null);


(lib.ClipGroup_15_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_14_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2BQIAAifIBtAAIAACfg");
	mask.setTransform(5.5,8);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgYBQIAAgKIAUAAIAAgKIgSAAQgIAAgEgCQgFgCgFgFIgHgKQgDgGAAgGIAAgdIAKAAIAAAVIABALQABAFACAEQACAEAFADQADACAIAAIAtAAQAIAAADgCQAFgCACgFQADgFABgEIABgLIgBgVIAKAAIAAAdQAAAHgDAFQgBAFgFAFQgFAFgFACQgFACgIAAIgSAAIAAAKIAUAAIAAAKgAgTAoIgFgBIgGgDQgCgCAAgDIgCgGIAAhZQAAgDACgCQAAgDACgDQADgCADAAQACgCADAAIAnAAIAGACQADABACABIADAGIABAFIAABZIgBAGIgDAFIgFADIgGABgAgXhDQAAAAAAAAQAAABgBAAQAAABAAAAQAAABAAAAIAABZQAAABAAAAQAAAAAAABQABAAAAABQAAAAAAABQABAAAAAAQABAAAAABQABAAAAAAQABAAAAAAIAnAAQAAAAABAAQAAAAABAAQAAgBABAAQAAAAAAAAQABgBAAAAQAAgBABAAQAAgBAAAAQAAAAAAgBIAAhZQAAAAAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAAAIgnAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAAAgBABg");
	this.shape.setTransform(5.5,8);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0,0,11,16), null);


(lib.ClipGroup_13_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjvDIIAAmPIHfAAIAAGPg");
	mask.setTransform(24,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjvDIIAAmPIHfAAIAAGPg");
	this.shape.setTransform(24,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0,0,48,40), null);


(lib.ClipGroup_12_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AifDIIAAmPIE/AAIAAGPg");
	this.shape.setTransform(16,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_11_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgSBOIAAibIAlAAIAACbg");
	mask.setTransform(1.975,7.825);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSBIQAcgeAAgqQAAgpgcgeIAHgGQAeAgAAAtQAAAugeAgg");
	this.shape.setTransform(1.925,7.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0.1,0,3.8,15.7), null);


(lib.ClipGroup_10_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.5,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.5,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10_0, new cjs.Rectangle(0,0,1,20), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AifDIIAAmPIE/AAIAAGPg");
	this.shape.setTransform(16,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_9_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.55,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9_0, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_8_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.5,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.5,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8_0, new cjs.Rectangle(0,0,1,20), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("AgxA3QAAgrAegeQAegfAsAA");
	this.shape.setTransform(5.5,5.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_7_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.5,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.5,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7_0, new cjs.Rectangle(0,0,1,20), null);


(lib.ClipGroup_6_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask.setTransform(0.5,10);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape.setTransform(0.5,10);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6_0, new cjs.Rectangle(0,0,1,20), null);


(lib.ClipGroup_5_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#247247").s().p("AnCAKIAAgTIOFAAIAAATg");
	this.shape.setTransform(145.125,698.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AnCB2IAAjrIOFAAIAADrg");
	this.shape_1.setTransform(145.125,685.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#787878").s().p("AgTgkIAnAkIgnAlg");
	this.shape_2.setTransform(58.1,687.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#787878").s().p("AgTABIAnglIAABJg");
	this.shape_3.setTransform(28.725,687.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#787878").s().p("Ag4A5QgYgYAAghQAAghAYgXQAYgYAgAAQAiAAAXAYQAYAXAAAhQAAAhgYAYQgXAYgiAAQggAAgYgYgAgvgvQgUAUAAAbQAAAcAUAUQAUAUAbAAQAcAAAUgUQAUgUAAgcQAAgbgUgUQgUgUgcAAQgbAAgUAUg");
	this.shape_4.setTransform(211.225,687.625);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5_0, new cjs.Rectangle(26.7,673.6,192.60000000000002,25.699999999999932), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AifDIIAAmPIE/AAIAAGPg");
	this.shape.setTransform(16,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_4_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("AgEB1IAAjpIAJAAIAADpg");
	this.shape.setTransform(189.75,685.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgEB1IAAjpIAJAAIAADpg");
	this.shape_1.setTransform(100.5,685.525);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4_0, new cjs.Rectangle(100,673.8,90.30000000000001,23.5), null);


(lib.ClipGroup_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707070").s().p("AhBAEIAAgHICDAAIAAAHg");
	this.shape.setTransform(1098.45,714.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#707070").s().p("AhBAEIAAgHICDAAIAAAHg");
	this.shape_1.setTransform(1098.45,710.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#707070").s().p("AgDA+IAAh7IAHAAIAAB7g");
	this.shape_2.setTransform(1100.5,712.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#707070").s().p("AgDA+IAAh7IAHAAIAAB7g");
	this.shape_3.setTransform(1096.4,712.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#707070").s().p("AhBBBIAAiBICDAAIAACBgAg6A5IB0AAIAAhxIh0AAg");
	this.shape_4.setTransform(1098.4,712.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#707070").p("AAAgkIAABJ");
	this.shape_5.setTransform(1172.6,709.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#707070").s().p("AgtAmIAAhLIBbAAIAABLgAgkAeIBJAAIAAg6IhJAAg");
	this.shape_6.setTransform(1172.55,709.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#707070").s().p("AhEBCIAAiDICJAAIAACDgAg7A5IB4AAIAAhxIh4AAg");
	this.shape_7.setTransform(1174.85,712.175);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#707070").p("AgQAAIAgAA");
	this.shape_8.setTransform(1136.8,713.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#707070").p("AgQAAIAgAA");
	this.shape_9.setTransform(1136.8,712.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#707070").p("AgQAAIAgAA");
	this.shape_10.setTransform(1136.8,710.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#707070").p("AAgArIg/AAIAAhVIA/AAg");
	this.shape_11.setTransform(1136.775,712.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#707070").s().p("AhEBBIAAiBICJAAIAACBgAg8A5IB4AAIAAhxIh4AAg");
	this.shape_12.setTransform(1136.8,712.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#747474").s().p("AgXA8IAAh3IAvAAIAAB3g");
	this.shape_13.setTransform(1259.325,712.35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#ABABAB").p("An0AAIPpAA");
	this.shape_14.setTransform(1258.575,713.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#747474").s().p("AgeAJIAAgRIA9AAIAAARg");
	this.shape_15.setTransform(1201.925,712.725);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#747474").s().p("AgIAjIAAgaIgaAAIAAgRIAaAAIAAgbIARAAIAAAbIAaAAIAAARIgaAAIAAAag");
	this.shape_16.setTransform(1315.9,712.85);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_0, new cjs.Rectangle(1091.8,704.8,227.70000000000005,14.100000000000023), null);


(lib.ClipGroup_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask_1.setTransform(16,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AifDIIAAmPIE/AAIAAGPg");
	this.shape.setTransform(16,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_1, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AAAAaIgPAMIgIgFIACgUIgTgIQgBgFABgEIATgIIgCgUIAIgFIAPAMIARgMIAIAFIgCAUIASAIIAAAJIgSAIIACAUIgIAFgAgJgJQgEAEAAAFQAAAFAEAFQAEAEAFAAQAGAAAEgEQAEgFAAgFQAAgFgEgEQgEgEgGAAQgFAAgEAEg");
	this.shape.setTransform(972.5375,716.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F2F2").s().p("AAAAjIgOAMIgOgHIgEgEIACgTIgRgHIgBgFQgBgFABgFIABgFIARgHIgCgTIAJgGIAJgEIAOALIAQgLIAEABQAGADAEADIADADIAQAaIAAAFIAAAKIAAAFIgSAHIACATIgDAEIgOAHgAgFAAQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQAAAAABABQAAAAABAAQAAABABAAQAAAAAAAAQAGAAAAgGQAAgFgGAAQgFAAAAAFg");
	this.shape_1.setTransform(972.5375,716.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#505050").ss(0.5).p("AAAgOIAAAd");
	this.shape_2.setTransform(967.2,717.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#505050").ss(1,1).p("AgtAAIBbAA");
	this.shape_3.setTransform(968.6,718.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#505050").s().p("AhCAxQgFAAgDgCQgDgEAAgEIAAhOQAAgDADgDQADgEAFAAICGAAQAEAAADAEQADADAAADIAABOQAAAEgDAEQgDACgEAAg");
	this.shape_4.setTransform(968.1,710.3);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_0, new cjs.Rectangle(960.3,705.4,17.200000000000045,15.600000000000023), null);


(lib.ClipGroup_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgjgSIBHAAIgkAlg");
	this.shape.setTransform(793.1,17.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhuBOQgfAAgYgXQgWgWAAghQAAgfAWgXQAXgXAgAAIDcAAQAhAAAXAXQAXAXAAAfQAAAggXAXQgXAXghAAgABUgaQgLALAAAPQAAAQALALQALALAQAAQAQAAALgLQALgLAAgQQAAgPgLgLQgLgLgQAAQgQAAgLALg");
	this.shape_1.setTransform(99.1,15.825);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_0, new cjs.Rectangle(80.3,8,716.4000000000001,15.7), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AifDIIAAmPIE/AAIAAGPg");
	this.shape.setTransform(16,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtADIIAAmPMDVbAAAIAAGPg");
	mask.setTransform(683,20);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("EhqtADIIAAmPMDVbAAAIAAGPg");
	this.shape.setTransform(683,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(0,0,1366,40), null);


(lib.logoc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AhlB3QgngpAAhNQAAhGArguQAqgtA/AAQA/gBAjApQAjApAABIIAAAaIjSAAQACArAZAXQAZAYArAAQAxgBApgdIAAA4QgpAahGABQhDgBgngqgAgrhXQgVAXgFAiICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape.setTransform(209.9026,-127.8368,0.2091,0.2091);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AhNB3QgrgrAAhEQAAhMAuguQAugvBKABQArgBAgAQIAABBQgggZglAAQgsAAgcAeQgcAfAAAvQAAAwAbAcQAZAbAtAAQAmAAAhgaIAAA8QglAWgyAAQhFgBgpgqg");
	this.shape_1.setTransform(203.95,-127.8,0.2091,0.2091,0,0,0,-0.2,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgjDiIAAkzIBFAAIAAEzgAgdidQgMgMAAgRQAAgQAMgMQANgLAQAAQARAAANALQAMAMAAAQQAAAQgMAMQgNAMgRAAQgRAAgMgLg");
	this.shape_2.setTransform(199.9499,-129.3423,0.2091,0.2091);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgyAAAAA6IAAApIBHAAIAAA3IhHAAIAAD9g");
	this.shape_3.setTransform(196.4999,-129.4573,0.2091,0.2091);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgzAAAAA6IAAApIBIAAIAAA3IhHAAIAAD9g");
	this.shape_4.setTransform(192.454,-129.4573,0.2091,0.2091);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AiWCjQg4g9gBhhQABhnA5g+QA5g+BiAAQBaAAA4A8QA4A8gBBiQAABog4A+Qg5A9heAAQheAAg4g8gAhehzQglAtAABHQAABIAkAsQAkAsA7AAQA9AAAkgqQAkgqAAhLQgBhMgigrQgjgqg9AAQg7AAglAsg");
	this.shape_5.setTransform(185.7,-129.1,0.2091,0.2091,0,0,0,0,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_6.setTransform(118.6,-125.15,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_7.setTransform(110.7,-125.15,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(118.6,-133.05,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(110.7,-133.05,0.2091,0.2091,0,0,0,-0.1,-0.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_10.setTransform(152.15,-129.4,0.2091,0.2091,0,0,0,-0.2,-0.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_11.setTransform(232.2597,-129.0338,0.2091,0.2091);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_12.setTransform(225.872,-129.1123,0.2091,0.2091);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_13.setTransform(219.3327,-129.1123,0.2091,0.2091);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoc, new cjs.Rectangle(107.2,-136.6,127.8,15), null);


(lib.halfpie_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#4CA067").s().p("ACDQ5QjShZiiiiQijijhZjTQhcjZAAjvQAAjuBcjZQBZjTCjijQCiiiDShZQDZhcDugBMAAAAkrQjugBjZhcg");
	this.shape_1.setTransform(58.6254,117.3527);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.halfpie_1, new cjs.Rectangle(0,0,117.3,234.7), null);


(lib.ClipGroup_51_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask_1.setTransform(683,384);

	// Livello_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#787878").s().p("AgigRIBFAAIgjAjg");
	this.shape_10.setTransform(1352.75,665.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#ABABAB").s().p("AhKBLIAAiVICVAAIAACVgAhABBICBAAIAAiBIiBAAg");
	this.shape_11.setTransform(1352.75,664.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhFBGIAAiLICLAAIAACLg");
	this.shape_12.setTransform(1352.75,664.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#787878").s().p("AgiASIAigjIAjAjg");
	this.shape_13.setTransform(1352.75,125.325);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ABABAB").s().p("AhKBLIAAiVICVAAIAACVgAhABBICBAAIAAiBIiBAAg");
	this.shape_14.setTransform(1352.75,125.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhFBGIAAiLICLAAIAACLg");
	this.shape_15.setTransform(1352.75,125.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ABABAB").s().p("AhKfhMAAAg/BICVAAMAAAA/BgAhAfXICBAAMAAAg+tIiBAAg");
	this.shape_16.setTransform(1352.75,334.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhFfcMAAAg+3ICLAAMAAAA+3g");
	this.shape_17.setTransform(1352.75,334.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DBDBDB").s().p("EgBKAn4MAAAhPvICVAAMAAABPvg");
	this.shape_18.setTransform(1352.75,416.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#CACACA").s().p("AgVAtQgMgRgXgOQgDgCABgLQABgJAFAAQAIACALAHIAVARQAMgSAVgVQAVgVAKgGQAGgEABALQACAKgFAEQgWAVgYAbIgRAZQgDAEgEAAQgEAAgDgFg");
	this.shape_19.setTransform(192.1798,93.7752);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#777777").ss(0.5).p("AAegbQABAAAAACIgCAHQAAABgBAAIgTAAQgIAigDAMQgMAngSAAQgLAAAAgIQAAgHAGAAQAFAAABAHQAAACACAAQAJAAAIglIAKgqIgRAAQgBAAAAgBIABgHQABgCABAAIARAAQAHgWAGgIQAIgKAKAAQANAAAAAJQAAAHgGAAQgFAAgBgGQAAgFgEAAQgGAAgFANQgCAFgEARg");
	this.shape_20.setTransform(225.975,93.55);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#777777").s().p("AgrA8QAAgIAGABQAFAAABAHQAAAAAAABQABAAAAAAQAAABAAAAQABAAAAAAQAJAAAIglIAKgqIgRAAQgBAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAIABgHIACgBIARAAQAHgYAGgIQAIgJAKAAQANAAAAAJQAAAHgGAAQgFAAgBgHQAAgEgEAAQgGAAgFAMQgCAGgEASIATAAIABABIgCAHQAAAAAAABQAAAAAAAAQAAAAAAAAQgBAAAAAAIgTAAQgIAigDAMQgMAngSAAQgLAAAAgIg");
	this.shape_21.setTransform(225.975,93.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#777777").ss(0.8).p("AgCgXIADAFIADAKIAFgHQACgDACgCIAFgDIACAAQADAAABABIABADIAAADQgCABgCAAIgCAAQgCgBgBAAIgDABQgEADgEAIIAGAWIABABIADgCQACgCADgEIABABQgDAGgFAEQgDADgCAAQgDAAgCgEIgDgRQgJAOgEAEQgEADgCAAQgDAAgBgCIgCgDQAAgCACgBQAAgBACAAQACAAACACQABABABAAIACgBQADgDADgGIAGgJIgDgNQgCgEgCgBQgCgBgDAAIgDAAIAAgCg");
	this.shape_22.setTransform(230.0081,95.3264);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#777777").s().p("AADAVIgDgSQgIAPgFAEQgDADgDAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAIgCgDQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAIADgBQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAABIACAAIACAAQADgDADgGIAHgJIgEgNIgEgFIgFgBIgDAAIAAgCIAOgDIADAGIADAKIAFgHIAFgFIAEgDIACgBQABAAABABQAAAAABAAQAAAAABAAQAAABABAAIABADIgBACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgCgBIgDgBIgDACQgEADgEAHIAGAXIABAAIADgBIAFgGIABABQgDAGgEAEIgGADQgCAAgDgEg");
	this.shape_23.setTransform(230,95.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#CACACA").s().p("AgsAvQgHgDABgKQADgRAkgZIgdgYQgIgGABgEQAAgEAJAAQAPAAAXAZQAWgSAYgBIAFAAQgGADggAdQATAWAPAZIgDAHQgEgGgLgLQgNgPgPgMQgLALgLAQIgKAOQgFAEgEAAIgEAAg");
	this.shape_24.setTransform(155.7933,93.7474);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#5F6161").s().p("AgngTIBPAAIgoAng");
	this.shape_25.setTransform(96.15,92.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#777777").s().p("AglgOIAJgJIAcAcIAdgcIAJAJIgmAlg");
	this.shape_26.setTransform(1352.575,92.8);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#B3B3B3").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_27.setTransform(121.975,97.4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#B3B3B3").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_28.setTransform(121.975,93.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#B3B3B3").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_29.setTransform(121.975,89.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#C6C6C6").s().p("EhWyACEIAAkHMCtlAAAIAAEHgEhWoAB6MCtRAAAIAAjzMitRAAAg");
	this.shape_30.setTransform(805.525,93.475);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("EhWtAB/IAAj9MCtbAAAIAAD9g");
	this.shape_31.setTransform(805.525,93.475);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#C6C6C6").s().p("AooCEIAAkHIRRAAIAAEHgAoeB6IQ9AAIAAjzIw9AAg");
	this.shape_32.setTransform(191.575,93.475);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AojB/IAAj9IRHAAIAAD9g");
	this.shape_33.setTransform(191.575,93.475);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#C6C6C6").s().p("An+CEIAAkHIP9AAIAAEHgAn0B6IPpAAIAAjzIvpAAg");
	this.shape_34.setTransform(56,93.475);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("An5B/IAAj9IPzAAIAAD9g");
	this.shape_35.setTransform(56,93.475);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#51906E").s().p("AgzARQgIgIgEgJQgEgLAAgKQAAgIACgGIAFgNIAJgLQAEgFAHgEQAIgEAFgBQAGgCAIAAIAMABIAKADIAIAFIApAmIAAg1IAKAAIAABGIhFAAIAAgKIA0AAIgmgjQgGgFgGgCQgEgCgKAAQgJAAgIADQgIAEgGAGQgGAFgEAJQgDAHAAAKQAAAKADAHQADAGAHAHIBABCIgHAHg");
	this.shape_36.setTransform(205.075,18.225);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgTBLIBAhCQAGgFAEgIQADgJAAgIQAAgIgDgJQgEgIgGgGQgGgGgIgEQgIgDgKAAQgJAAgEACQgGACgGAFIgLAJIgbAaIA0AAIAAAKIhFAAIAAhGIAKAAIAAA1IAZgXIAIgIIAIgHIAIgFIAJgDIAMgBQAJAAAGACQAGABAHAEQAIAFADAEQAFAFAEAGIAFANIACAOQAAALgEAKQgDAIgJAJIhABBg");
	this.shape_37.setTransform(169.775,18.225);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AAqAyIgqgrIgpArIgHAAIAAgBIAAgGIAqgrIgqgqIAAgGIAAAAIAHAAIApAqIAqgqIAHAAIABAAIAAAGIgrAqIArArIAAAGIgBABg");
	this.shape_38.setTransform(1343.15,16.25);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgxA0IAAhSIAUAAIAAgVIBPAAIAABTIgUAAIAAAUgAgnAqIA7AAIAAg/Ig7AAgAgUgeIAyAAIAAA0IAKAAIAAg/Ig8AAg");
	this.shape_39.setTransform(1297.025,16.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgxAFIAAgJIBjAAIAAAJg");
	this.shape_40.setTransform(1250.975,16.525);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgEAfIAAgsIgMALIgGgGIAWgWIAXAWIgGAGIgMgLIAAAsg");
	this.shape_41.setTransform(1204.475,17.225);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AhAAyIAAhjICBAAIAABjgAg4ArIBwAAIAAg9IhwAAgAg4gaIBwAAIAAgQIhwAAg");
	this.shape_42.setTransform(1204.5,16.05);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Ag+BVIgWgWIAAiTICpAAIAAA8IgMAAIAAgwIgMAAIAAAwIgNAAIAAgwIhfAAIAAA9IAqAAQgHAGgEAFIgrAAIAAhIIgNAAIAACCIAPAPIAKAAIAAgxIAWAAIgBAMIgJAAIAAAlIAJAAIAAAMg");
	this.shape_43.setTransform(141.475,18.425);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgOAuQgHgCgHgEIgKgLIAAAKIgKAAIAAgdIAdAAIAAAJIgOAAQADAGADADIAIAGIAKAEIAJABQAIAAAFgCQAHgDAFgEQAFgEADgFQADgFACgHIAKACQgCAHgFAIQgEAHgGAFQgJAGgGACQgHADgJAAQgGAAgIgDgAgvgKQADgJAEgGQAEgHAGgFQAJgHAGgBQAHgDAIAAQAHAAAIADQAIACAGAEIAKALIAAgKIAKAAIAAAdIgdAAIAAgJIAOAAQgDgGgDgCIgIgHIgKgEIgKgBQgGAAgGACQgHADgEAEQgFADgEAGQgEAHgBAFg");
	this.shape_44.setTransform(145.175,22);

	var maskedShapeInstanceList = [this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_51_1, new cjs.Rectangle(4.9,10,1356.1999999999998,662.2), null);


(lib.ClipGroup_50_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#257247").s().p("AAGATQgHAAgHABIgOAEIgMAIQgGADgFAGIAAgHQAAgIACgGIAFgNQADgGAEgDIALgIQAEgDAIgDIAOgCIAAgWIAoAoIgoApgAgFgJIgGACIgJAGQgEABgEAFIgGAJQgCAEgBAGQAJgGALgDQALgEAMAAIAHAAIAAAMIAXgXIgXgWIAAAMIgGAAg");
	this.shape_6.setTransform(1190.2,53.225);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#257247").s().p("AgvAmIAAhLIAFAAIAABGIBVAAIAAgoIAFAAIAAAtg");
	this.shape_7.setTransform(1188.05,57.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#EBE9E7").s().p("Ak7B0QgIAAgHgGQgFgGAAgJIAAi9QAAgJAFgGQAHgGAIAAIJ2AAQAJAAAHAGQAFAGABAJIAAC9QgBAJgFAGQgHAGgJAAgAlGhpQgFAEAAAHIAAC9QAAAHAFAFQAFAEAGAAIJ2AAQAIAAAEgEQAEgFABgHIAAi9QgBgHgEgEQgFgFgHAAIp2AAQgGAAgFAFg");
	this.shape_8.setTransform(1208.85,55.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ak7ByQgHAAgFgGQgGgFAAgIIAAi9QAAgIAGgFQAFgGAHAAIJ2AAQAIAAAGAGQAFAFAAAIIAAC9QAAAIgFAFQgGAGgIAAg");
	this.shape_9.setTransform(1208.85,55.625);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#464646").s().p("AhDBEQAAAAgBgBQAAAAAAgBQAAAAAAgBQABAAAAgBIAygxQgNgPAAgSQAAgUAPgPQAOgPAUAAQAUAAAPAPQAPAPAAAUQAAAUgPAPQgPAOgUAAQgTAAgOgNIgyAyIgBABgAgMgyQgNANAAATQAAASANANQAMANATAAQATAAANgNQANgNAAgSQAAgTgNgNQgOgNgSAAQgTAAgMANg");
	this.shape_10.setTransform(625.625,56.3);

	var maskedShapeInstanceList = [this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_50_1, new cjs.Rectangle(618.8,44,623.7,23.299999999999997), null);


(lib.ClipGroup_49_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#257247").s().p("AgoAZIgOAAIAAhKIBsAAIAABKIhEAAIgaAZgAgvASIAOAAIAAAQIAPgQIBCAAIAAg8IhfAAg");
	this.shape.setTransform(1264.85,55.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBE9E7").s().p("AneB0QgIAAgHgGQgGgGAAgJIAAi9QAAgJAGgGQAHgGAIAAIO8AAQAJAAAHAGQAGAGAAAJIAAC9QAAAJgGAGQgHAGgJAAgAnphpQgFAEAAAHIAAC9QAAAHAFAFQAFAEAGAAIO8AAQAHAAAFgEQAFgFAAgHIAAi9QAAgHgFgEQgFgFgHAAIu8AAQgGAAgFAFg");
	this.shape_1.setTransform(1301.025,55.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AneByQgIAAgFgGQgFgFAAgIIAAi9QAAgIAFgFQAFgGAIAAIO8AAQAIAAAGAGQAFAFAAAIIAAC9QAAAIgFAFQgGAGgIAAg");
	this.shape_2.setTransform(1301.025,55.625);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_49_1, new cjs.Rectangle(1251.1,44,99.90000000000009,23.299999999999997), null);


(lib.ClipGroup_42_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask_1.setTransform(0.55,10);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape_1.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_42_1, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_40_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_40_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_39_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_39_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_38_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_38_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_36_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_36_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_35_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_35_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_32_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_32_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_31_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_31_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_29_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_29_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_27_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_27_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_26_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_26_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_24_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_24_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_22_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_22_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_21_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_21_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_20_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ah8AFIAAgJID5AAIAAAJg");
	mask_1.setTransform(12.5,0.5);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],12.5,0,-12.5,0).s().p("Ah8AFIAAgJID5AAIAAAJg");
	this.shape_1.setTransform(12.5,0.5);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_20_0_1, new cjs.Rectangle(0,0,25,1), null);


(lib.ClipGroup_19_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask_1.setTransform(0.55,10);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape_1.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19_0_1, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_18_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask_1.setTransform(0.55,10);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape_1.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18_0_1, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_17_0_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AgEBkIAAjHIAJAAIAADHg");
	mask_1.setTransform(0.55,10);

	// Livello_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#999999","#D3D3D3"],[0,1],0,10,0,-10).s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape_1.setTransform(0.525,10);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17_0_1, new cjs.Rectangle(0.1,0,1,20), null);


(lib.ClipGroup_3_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("EhJWAdDMAAAg6FMCStAAAMAAAA6Fg");
	mask_2.setTransform(469.5,185.875);

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3_2, new cjs.Rectangle(0,0,0,0), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_54 = function() {
		exportRoot.tl1.play()
	}
	this.frame_75 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(21).call(this.frame_75).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298,321.6,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:320.9},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(49));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AmofKIAAyrMBGZAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("Am4fKIAAyrMBGZAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("AnmfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("AozfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("AqefKIAAyrMBGZAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("AspfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("AvSfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("Ax7fKIAAyrMBGZAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("A0GfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("A1xfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("A2+fKIAAyrMBGZAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("A3sfKIAAyrMBGZAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("A38fKIAAyrMBGZAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:199.4334}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:199.4334}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:199.4334}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:199.4334}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:199.4334}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:199.4334}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:199.4334}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:199.4334}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:199.4334}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:199.4334}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:199.4334}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:199.4334}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:199.4334}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.9,314.25,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:300.35},12,cjs.Ease.quadInOut).to({_off:true},24).wait(26));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhM1CIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTjCIBMAAAkQBMCXtAAAMAAAEQBg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhanCIBMAAAkQBMCXtAAAMAAAEQBg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:289.9213}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:289.9213}).wait(1).to({graphics:mask_1_graphics_52,x:295.8271,y:289.9213}).wait(1).to({graphics:mask_1_graphics_53,x:289.2111,y:289.9213}).wait(1).to({graphics:mask_1_graphics_54,x:278.1844,y:289.9213}).wait(1).to({graphics:mask_1_graphics_55,x:262.7471,y:289.9213}).wait(1).to({graphics:mask_1_graphics_56,x:242.8992,y:289.9213}).wait(1).to({graphics:mask_1_graphics_57,x:218.6406,y:289.9213}).wait(1).to({graphics:mask_1_graphics_58,x:189.9713,y:289.9213}).wait(1).to({graphics:mask_1_graphics_59,x:156.8914,y:289.9213}).wait(1).to({graphics:mask_1_graphics_60,x:119.4008,y:289.9213}).wait(1).to({graphics:mask_1_graphics_61,x:77.4995,y:289.9213}).wait(1).to({graphics:mask_1_graphics_62,x:31.1876,y:289.9213}).wait(1).to({graphics:mask_1_graphics_63,x:-19.5349,y:289.9213}).wait(1).to({graphics:mask_1_graphics_64,x:-74.6682,y:289.9213}).wait(1).to({graphics:mask_1_graphics_65,x:-134.212,y:289.9213}).wait(1).to({graphics:mask_1_graphics_66,x:-198.1666,y:289.9213}).wait(1).to({graphics:mask_1_graphics_67,x:-266.5318,y:289.9213}).wait(1).to({graphics:mask_1_graphics_68,x:-339.3076,y:289.9213}).wait(1).to({graphics:mask_1_graphics_69,x:-416.4941,y:289.9213}).wait(1).to({graphics:mask_1_graphics_70,x:-491.7868,y:289.9213}).wait(1).to({graphics:mask_1_graphics_71,x:-534.7908,y:289.9213}).wait(1).to({graphics:mask_1_graphics_72,x:-580,y:289.9213}).wait(4));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.35,314.25,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({_off:true},25).wait(1));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({x:-674.6},21,cjs.Ease.quadIn).to({_off:true},3).wait(1));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-674.6},21,cjs.Ease.quadIn).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160,-580.6,1943.5,1741.1999999999998);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logoc();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(32.85,1.1,1,1,0,0,0,170.6,-129.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-30.6,-6.4,127.80000000000001,15), null);


(lib.laptop_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.laptop = new lib.laptop_vector();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(0.05,-1.3,0.6058,0.6058,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_mc, new cjs.Rectangle(-0.6,-1.3,314.20000000000005,592.3), null);


(lib.laptop_ai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop.cache(-320,-600,640,1200,1.2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.laptop = new lib.laptop_mc();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(148.5,295.2,1,1,0,0,0,148.5,295.2);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_ai, new cjs.Rectangle(-0.6,-1.3,314.20000000000005,592.3), null);


(lib.graphsphone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		
		//number setup
		
		
		
		//txt setup
		this.txt1.textBaseline = "alphabetic";
		this.txt2.textBaseline = "alphabetic";
		
		this.txt4.textBaseline = "alphabetic";
		this.txt5.textBaseline = "alphabetic";
		this.txt6.textBaseline = "alphabetic";
	}
	this.frame_39 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(1));

	// big number
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#357248").s().p("AjYEgIFWoLQg9AOhWAAIgTAAQAVAeAAAiQAAAwgiAmQghAmg3AAQgzAAgjgjQgjgkAAgyQAAgiAQgbQAQgcAdgRQAdgRAfAAQANAAAdAGQAvAKA0AAQAoAAAigFQAjgFA5gQIApAAIl5I/gAjDjRQgXAWABAgQgBAgAXAXQAXAWAfAAQAhAAAXgWQAWgXAAggQAAgggWgWQgXgXghAAQgfAAgXAXgAA3DoQgjgkAAgyQAAgzAjgjQAlgkAyAAQAyAAAjAkQAkAjAAAzQAAAygkAkQgjAjgyAAQgyAAglgjgABXBbQgWAWgBAhQABAgAWAWQAXAXAgAAQAfAAAXgXQAXgWAAggQAAghgXgWQgXgXgfAAQggAAgXAXg");
	this.shape.setTransform(127.95,173.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#357248").s().p("AhyDpQgsgmgOhLIAzAAQANAzAZAWQAgAcAxAAQA4AAAhgiQAjghAAguQAAgegRgaQgRgagdgOQgcgNg8gCIAAgwQAjAAAdgMQAdgNAOgTQAMgTAAgXQAAgigagZQgbgYgoAAQgigBgYAUQgYASgRAtIg1AAQAPg/AogjQApgiA4gBQAnAAAjATQAjASATAgQAUAfgBAiQAABChCAoQAlAPAYAcQAiApAAAzQAAAsgYAoQgXAognAVQgpAXgwgBQhDABgtgng");
	this.shape_1.setTransform(80,173.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#357248").s().p("AiuEJIDEjVQA8hAATgfQASggAAgiQAAgsghgeQghghgvAAQgwABghAhQghAhgEA7IgyAAQAChMAxgxQAxgxBHAAQBHAAAsAuQAsAuAAA/QAAAsgUAmQgVAlg9BCIiACLIDuAAIAAAyg");
	this.shape_2.setTransform(39.95,172.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#357248").s().p("ABDEJIAAh4Ij2AAIEfmZIAKAAIAAFoIA+AAIAAAxIg+AAIAAB4gAhWBgICZAAIAAjYg");
	this.shape_3.setTransform(80.05,172.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#357248").s().p("AhQD7QglgVgUglQgWglAAgqQABggANgjQAMgkAhgwICcjqIArAcIiLDUQAcgJAXAAQA/AAArArQArAsAABCQAAAsgWAkQgUAkgmAVQgnAWgqgBQgrAAgkgUgAhMAjQggAgAAAuQAAAsAgAgQAfAgAtAAQAtAAAfggQAhgggBgsQABgughggQgfgfgtAAQgsAAggAfg");
	this.shape_4.setTransform(80.95,173.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#357248").s().p("AjYEgIFXoLQg+AOhXAAIgTAAQAWAeAAAiQAAAwghAmQgiAmg3AAQgzAAgjgjQgjgkAAgyQAAgiAQgbQAQgcAdgRQAdgRAfAAQANAAAeAGQAtAKA1AAQAnAAAkgFQAigFA4gQIAqAAIl4I/gAjDjRQgWAWgBAgQABAgAWAXQAXAWAgAAQAfAAAXgWQAXgXAAggQAAgggXgWQgXgXgfAAQggAAgXAXgAA4DoQgkgkAAgyQAAgzAkgjQAjgkAzAAQAyAAAkAkQAjAjAAAzQAAAygjAkQgkAjgyAAQgzAAgjgjgABXBbQgXAWABAhQgBAgAXAWQAWAXAgAAQAhAAAWgXQAXgWAAggQAAghgXgWQgWgXghAAQggAAgWAXg");
	this.shape_5.setTransform(128.35,173.675);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#357248").s().p("AiuEJIDEjVQA8hAASgfQATgggBgiQABgsghgeQggghgwAAQgwABghAhQghAhgEA7IgyAAQAChMAxgxQAxgxBHAAQBIAAArAuQAsAuABA/QgBAsgUAmQgWAlg8BCIiACLIDuAAIAAAyg");
	this.shape_6.setTransform(80.25,172.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#357248").s().p("AhyDpQgsgmgOhLIAzAAQANAzAZAWQAgAcAxAAQA4AAAhgiQAjghAAguQAAgegRgaQgSgagcgOQgdgNg7gCIAAgwQAjAAAdgMQAdgNANgTQAOgTAAgXQAAgigbgZQgcgYgoAAQghgBgYAUQgZASgQAtIg1AAQAPg/AogjQApgiA3gBQAoAAAjATQAjASATAgQAUAfAAAiQAABChDAoQAlAPAYAcQAiApAAAzQAAAsgYAoQgXAogoAVQgoAXgxgBQhCABgtgng");
	this.shape_7.setTransform(40.5,173.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#357248").s().p("Ah0DjQgsgngIg9IA1AAQAGAeAOATQAOASAYALQAYAMAaAAQAyAAAkgnQAlgnAAg5QAAg1ghgfQghghg2AAQguAAhBAcIAwkBIDfAAIAAAxIi3AAIgaCNQAigKAaAAQBGAAAuAvQAuAvAABKQAAAzgXAqQgYArgoAWQgoAXg0AAQg/AAgrgmg");
	this.shape_8.setTransform(79.975,173.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#357248").s().p("AhyDpQgtgmgNhLIAyAAQAOAzAZAWQAgAcAyAAQA2AAAjgiQAighAAguQAAgegRgaQgSgagcgOQgdgNg6gCIAAgwQAiAAAdgMQAdgNAOgTQANgTgBgXQABgigbgZQgbgYgoAAQgigBgYAUQgZASgQAtIg1AAQAOg/ApgjQApgiA4gBQAnAAAjATQAjASATAgQATAfAAAiQAABChCAoQAlAPAYAcQAiApAAAzQAAAsgXAoQgXAogoAVQgpAXgwgBQhDABgtgng");
	this.shape_9.setTransform(40.1,173.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#357248").s().p("ABDEJIAAh4Ij2AAIEfmZIAKAAIAAFoIA/AAIAAAxIg/AAIAAB4gAhWBgICZAAIAAjYg");
	this.shape_10.setTransform(40.15,172.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#357248").s().p("AhcDzQgngcgWg4QgXg6ABhlQAAhlAVg4QAWg4AogdQAogcAygBQAxAAApAdQApAdAYA6QAYA7gBBgQABBigYA5QgYA6gpAdQgpAdgxAAQgyAAgogcgAhBjHQgeAXgQAuQgQAsAABXQAABXAQAtQAPAtAfAYQAeAXAjAAQAhAAAegXQAegWAQguQATg3AAhOQAAhNgRgyQgRgxgfgYQgfgXggAAQgjAAgeAXg");
	this.shape_11.setTransform(80.1,173.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#357248").s().p("AhQD7QglgVgVglQgUglAAgqQgBggANgjQANgkAhgwICdjqIAqAcIiLDUQAcgJAYAAQA9AAAsArQAqAsAABCQABAsgWAkQgUAkgnAVQglAWgsgBQgqAAgkgUgAhMAjQggAgAAAuQAAAsAgAgQAgAgAsAAQAtAAAfggQAgggABgsQgBguggggQgfgfgtAAQgtAAgfAfg");
	this.shape_12.setTransform(41.05,173.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#357248").s().p("AiaDzIDtnKIj2AAIAAgxIFHAAIkUIRg");
	this.shape_13.setTransform(41.8,173.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#357248").s().p("AAPECIAAnRIhQAAIAegyIBlAAIAAIDg");
	this.shape_14.setTransform(77.025,173.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#357248").s().p("AivEJIDFjVQA8hAATgfQARggABgiQgBgsgggeQghghgvAAQgxABggAhQghAhgFA7IgxAAQAChMAxgxQAxgxBHAAQBIAAAsAuQArAuAAA/QABAsgWAmQgUAlg9BCIiACLIDtAAIAAAyg");
	this.shape_15.setTransform(79.85,172.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2},{t:this.shape_3},{t:this.shape}]},1).to({state:[{t:this.shape_2},{t:this.shape_4},{t:this.shape}]},3).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]},3).to({state:[{t:this.shape_9},{t:this.shape_8,p:{x:79.975}},{t:this.shape}]},3).to({state:[{t:this.shape_10},{t:this.shape_4},{t:this.shape}]},5).to({state:[{t:this.shape_8,p:{x:40.075}},{t:this.shape_11},{t:this.shape}]},4).to({state:[{t:this.shape_12},{t:this.shape_1},{t:this.shape}]},4).to({state:[{t:this.shape_13},{t:this.shape_11},{t:this.shape}]},3).to({state:[{t:this.shape_13},{t:this.shape_14},{t:this.shape}]},5).to({state:[{t:this.shape_13},{t:this.shape_15},{t:this.shape}]},4).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_13},{t:this.shape_3},{t:this.shape}]},1).wait(1));

	// pie white
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AliNJQikhGh+h+Qh+h+hFikQhIipAAi6QAAi5BIipQBFikB+h+QB+h+CkhGQCqhHC4AAQC6AACpBHQCkBGB+B+QB+B+BGCkQBHCpAAC5QAAC6hHCpQhGCkh+B+Qh+B+ikBGQipBHi6AAQi4AAiqhHg");
	this.shape_16.setTransform(86.8512,174.6041,0.9096,0.9096);

	this.timeline.addTween(cjs.Tween.get(this.shape_16).wait(40));

	// pie mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AqcS4MAAAglvIU5AAMAAAAlvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:19.825,y:173.425}).wait(19).to({graphics:null,x:0,y:0}).wait(21));

	// pie animation 1
	this.instance = new lib.halfpie();
	this.instance.parent = this;
	this.instance.setTransform(86.4,174.75,1,1,99.6975,0,0,118.1,118.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:118,regY:118.2,rotation:0,x:87.5,y:175.45},19).wait(21));

	// pie animation 2
	this.instance_1 = new lib.halfpie();
	this.instance_1.parent = this;
	this.instance_1.setTransform(87.5,175.45,1,1,0,0,0,118,118.2);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(19).to({_off:false},0).to({rotation:-82.4525,x:87.6,y:175.4},20,cjs.Ease.quartOut).wait(1));

	// pie bg
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#357347").s().p("An1SlQjnhiizizQizizhijnQhljwAAkGQAAkFBljwQBijoCziyQCzizDnhiQDvhlEGAAQEGAADwBlQDoBiCyCzQCyCyBiDoQBmDwAAEFQAAEGhmDwQhiDniyCzQiyCzjoBiQjwBlkGAAQkGAAjvhlg");
	this.shape_17.setTransform(86.8512,174.6041,0.9096,0.9096);

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(40));

	// bg
	this.txt2 = new cjs.Text("Percentage of income spent", "15px 'Segoe Pro'", "#B7B2A6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 22;
	this.txt2.parent = this;
	this.txt2.setTransform(-30.85,31.6);

	this.txt1 = new cjs.Text("Budget Overview", "34px 'Segoe Pro'", "#357147");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 52;
	this.txt1.parent = this;
	this.txt1.setTransform(-30.85,10.75);

	this.txt6 = new cjs.Text("Total monthly expenses", "18px 'Segoe Pro'", "#357147");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 28;
	this.txt6.parent = this;
	this.txt6.setTransform(-32.15,409.1);

	this.txt5 = new cjs.Text("$3,750", "29px 'Segoe Pro'", "#357147");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 45;
	this.txt5.parent = this;
	this.txt5.setTransform(-30.55,374.3);

	this.txt4 = new cjs.Text("Total monthly income", "18px 'Segoe Pro'", "#357147");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 28;
	this.txt4.parent = this;
	this.txt4.setTransform(-30.55,332);

	this.instance_2 = new lib.ClipGroup_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.5,183.5,1,1,0,0,0,469.5,183.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt1},{t:this.txt2}]}).wait(40));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-79.3,-145.9,1018.3,613.7);


(lib.graphs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// small number
	this.smallNumber = new cjs.Text("$2,786", "29px 'Segoe Pro'", "#357147");
	this.smallNumber.name = "smallNumber";
	this.smallNumber.lineHeight = 45;
	this.smallNumber.parent = this;
	this.smallNumber.setTransform(308.1,170.45);

	this.timeline.addTween(cjs.Tween.get(this.smallNumber).wait(1));

	// chart
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4CA067").s().p("AnTMsIAA5XIOnAAIAAZXg");
	this.shape.setTransform(745.1883,207.4387,1,1.3003);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// big number
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#357248").s().p("AjqE4IFzo3QhCAQhfAAIgUAAQAXAgAAAlQAAA0gkApQgkApg8AAQg3AAgmgmQgmgmAAg3QAAglARgdQASgeAfgTQAggSAhAAQAOAAAgAHQAyAKA5AAQArAAAlgFQAngGA8gRIAtAAImYJvgAjTjjQgZAYAAAjQAAAjAZAYQAYAZAjAAQAiAAAZgZQAYgYAAgjQAAgjgYgYQgZgZgiAAQgjAAgYAZgAA8D7QgmgnAAg2QAAg3AmgmQAngnA3AAQA2AAAnAnQAmAmAAA3QAAA2gmAnQgnAng2AAQg3AAgngngABeBiQgYAZAAAjQAAAjAYAYQAZAYAiAAQAjAAAZgYQAYgYAAgjQAAgjgYgZQgZgYgjAAQgiAAgZAYg");
	this.shape_1.setTransform(173.275,213.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#357248").s().p("ABIEfIAAiCIkLAAIE3m7IAMAAIAAGGIBEAAIAAA1IhEAAIAACCgAhdBoIClAAIAAjrg");
	this.shape_2.setTransform(121.375,211.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#357248").s().p("AioEHIECnwIkLAAIAAg1IFjAAIkrI9g");
	this.shape_3.setTransform(79.975,213.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// pie white
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AliNJQikhGh+h+Qh+h+hFikQhIipAAi6QAAi5BIipQBFikB+h+QB+h+CkhGQCqhHC4AAQC6AACpBHQCkBGB+B+QB+B+BGCkQBHCpAAC5QAAC6hHCpQhGCkh+B+Qh+B+ikBGQipBHi6AAQi4AAiqhHg");
	this.shape_4.setTransform(128.7505,209.2482,0.9853,0.9853);

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(1));

	// pie animation 1
	this.instance = new lib.halfpie_1();
	this.instance.parent = this;
	this.instance.setTransform(129.4,210.15,1.0833,1.0833,0,0,0,118,118.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// pie animation 2
	this.instance_1 = new lib.halfpie_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(129.6,210.1,1.0833,1.0833,-82.4529,0,0,118,118.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// pie bg
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#357347").s().p("An1SlQjnhiizizQizizhijnQhljwAAkGQAAkFBljwQBijoCziyQCzizDnhiQDvhlEGAAQEGAADwBlQDoBiCyCzQCyCyBiDoQBmDwAAEFQAAEGhmDwQhiDniyCzQiyCzjoBiQjwBlkGAAQkGAAjvhlg");
	this.shape_5.setTransform(128.7505,209.2482,0.9853,0.9853);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	// bg
	this.txt3 = new cjs.Text("Summary", "18px 'Segoe Pro'", "#357147");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 28;
	this.txt3.parent = this;
	this.txt3.setTransform(308.1,16.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#E2DDD1").p("AR4AAMgjvAAA");
	this.shape_6.setTransform(699.3876,315.6049);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#E2DDD1").p("AAA4eMAAAAw8");
	this.shape_7.setTransform(584.9608,158.9525);

	this.txt2 = new cjs.Text("Percentage of income spent", "15px 'Segoe Pro'", "#B7B2A6");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 22;
	this.txt2.parent = this;
	this.txt2.setTransform(0,57.25);

	this.txt1 = new cjs.Text("Budget Overview", "34px 'Segoe Pro'", "#357147");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 52;
	this.txt1.parent = this;
	this.txt1.setTransform(0,25.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4CA067").s().p("AhBBCIAAiDICDAAIAACDg");
	this.shape_8.setTransform(708.2627,352.5055);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#357347").s().p("AhBBCIAAiDICDAAIAACDg");
	this.shape_9.setTransform(601.4361,352.5055);

	this.txt21 = new cjs.Text("Expense", "18px 'Segoe Pro'", "#B7B2A6");
	this.txt21.name = "txt21";
	this.txt21.lineHeight = 28;
	this.txt21.parent = this;
	this.txt21.setTransform(720.7,361.35);

	this.txt20 = new cjs.Text("Income", "18px 'Segoe Pro'", "#B7B2A6");
	this.txt20.name = "txt20";
	this.txt20.lineHeight = 28;
	this.txt20.parent = this;
	this.txt20.setTransform(614.2,360.7);

	this.txt19 = new cjs.Text("$0", "14px 'Segoe Pro'", "#357147");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 21;
	this.txt19.parent = this;
	this.txt19.setTransform(563.5,318.1);

	this.txt18 = new cjs.Text("$500", "14px 'Segoe Pro'", "#357147");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 21;
	this.txt18.parent = this;
	this.txt18.setTransform(549.5,281.15);

	this.txt17 = new cjs.Text("$1,000", "14px 'Segoe Pro'", "#357147");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 21;
	this.txt17.parent = this;
	this.txt17.setTransform(539.5,244.25);

	this.txt16 = new cjs.Text("$1,500", "14px 'Segoe Pro'", "#357147");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 21;
	this.txt16.parent = this;
	this.txt16.setTransform(539.5,207.3);

	this.txt15 = new cjs.Text("$2,000", "14px 'Segoe Pro'", "#357147");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 21;
	this.txt15.parent = this;
	this.txt15.setTransform(539.5,170.35);

	this.txt14 = new cjs.Text("$2,500", "14px 'Segoe Pro'", "#357147");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 21;
	this.txt14.parent = this;
	this.txt14.setTransform(539.5,133.4);

	this.txt13 = new cjs.Text("$3,000", "14px 'Segoe Pro'", "#357147");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 21;
	this.txt13.parent = this;
	this.txt13.setTransform(539.5,96.5);

	this.txt12 = new cjs.Text("$3,500", "14px 'Segoe Pro'", "#357147");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 21;
	this.txt12.parent = this;
	this.txt12.setTransform(539.5,59.55);

	this.txt11 = new cjs.Text("$4,000", "14px 'Segoe Pro'", "#357147");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 21;
	this.txt11.parent = this;
	this.txt11.setTransform(539.5,22.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#357347").s().p("AnTWbMAAAgs1IOnAAMAAAAs1g");
	this.shape_10.setTransform(651.5369,169.5027);

	this.txt10 = new cjs.Text("$414", "29px 'Segoe Pro'", "#357147");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 45;
	this.txt10.parent = this;
	this.txt10.setTransform(308.1,334.35);

	this.txt9 = new cjs.Text("Cash balance", "18px 'Segoe Pro'", "#357147");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 28;
	this.txt9.parent = this;
	this.txt9.setTransform(308.1,306.25);

	this.txt8 = new cjs.Text("$550", "29px 'Segoe Pro'", "#357147");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 45;
	this.txt8.parent = this;
	this.txt8.setTransform(308.1,251.55);

	this.txt7 = new cjs.Text("Total monthly savings", "18px 'Segoe Pro'", "#357147");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 28;
	this.txt7.parent = this;
	this.txt7.setTransform(308.1,223.45);

	this.txt6 = new cjs.Text("Total monthly expenses", "18px 'Segoe Pro'", "#357147");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 28;
	this.txt6.parent = this;
	this.txt6.setTransform(308.1,140.65);

	this.txt5 = new cjs.Text("$3,750", "29px 'Segoe Pro'", "#357147");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 45;
	this.txt5.parent = this;
	this.txt5.setTransform(308.1,85.9);

	this.txt4 = new cjs.Text("Total monthly income", "18px 'Segoe Pro'", "#357147");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 28;
	this.txt4.parent = this;
	this.txt4.setTransform(308.1,57.8);

	this.instance_2 = new lib.ClipGroup_3_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(469.5,183.5,1,1,0,0,0,469.5,183.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.shape_10},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt17},{t:this.txt18},{t:this.txt19},{t:this.txt20},{t:this.txt21},{t:this.shape_9},{t:this.shape_8},{t:this.txt1},{t:this.txt2},{t:this.shape_7},{t:this.shape_6},{t:this.txt3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.graphs, new cjs.Rectangle(-14.1,0,953.1,387.8), null);


(lib.Group_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_13();
	this.instance.parent = this;
	this.instance.setTransform(24,20,1,1,0,0,0,24,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_8, new cjs.Rectangle(0,0,48,40), null);


(lib.Group_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_7, new cjs.Rectangle(0,0,32,40), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_1();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,32,40), null);


(lib.Group_5_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_14();
	this.instance.parent = this;
	this.instance.setTransform(5.5,8,1,1,0,0,0,5.5,8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5_0, new cjs.Rectangle(0,0,11,16), null);


(lib.Group_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_16();
	this.instance.parent = this;
	this.instance.setTransform(12,12,1,1,0,0,0,12,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_0, new cjs.Rectangle(0,0,24,24), null);


(lib.Group_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_17();
	this.instance.parent = this;
	this.instance.setTransform(24,20,1,1,0,0,0,24,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_0, new cjs.Rectangle(0,0,48,40), null);


(lib.Group_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(24,20,1,1,0,0,0,24,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0, new cjs.Rectangle(0,0,48,40), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_11();
	this.instance.parent = this;
	this.instance.setTransform(1.9,7.8,1,1,0,0,0,1.9,7.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,3.9,15.7), null);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_8();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(-0.2,0,11.7,11.5), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_0();
	this.instance.parent = this;
	this.instance.setTransform(683,20,1,1,0,0,0,683,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,1366,40), null);


(lib.ClipGroup_48 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(683,748,1,1,0,0,0,683,20);
	this.instance.alpha = 0.8984;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_48, new cjs.Rectangle(0,728,1366,40), null);


(lib.ClipGroup_46 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABABQIAAhLIALAAIAABLgAAVBQIAAgVIhfAAIAAAVIgKAAIAAggIB0AAIAAAggAhUAlIAAhJIB0AAIAABJgAhKAbIBfAAIAAg1IhfAAgAA/gGQgCAAgDgDQgDgDAAgCIgCgGQAAgEACgDIADgFIAFgDIAGgBIAHABIAFADIADAFIABAHIgBAGIgDAFIgFADQgDACgEAAIgGgCgABAgvIAAggIALAAIAAAggAhUgvIAAggIAKAAIAAAVIBfAAIAAgVIALAAIAAAgg");
	this.shape.setTransform(415.975,748.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AggAWIAAg1IBBAAIAAA/g");
	this.shape_1.setTransform(19.275,751.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpAaIAAg/IBTAAIAABLg");
	this.shape_2.setTransform(27.725,752.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AggAeIAAgyIBBgJIAAA7g");
	this.shape_3.setTransform(19.275,744.225);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpAlIAAg9IBTgMIAABJg");
	this.shape_4.setTransform(27.725,743.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAABLQAAgGgBgGQgCgEgFgGQgFgEgEgCQgGgCgGAAQgIAAgEACIgKAGQgEAGgCAEQgCAFAAAHIgKAAIABgLQACgGADgEQACgEAFgFIAJgGQgGgEgDgHQgDgGAAgHQAAgHACgFQACgDAEgGIAKgFQAEgDAIAAQAHAAAGADQAGAEAFAFQADgGAEgEQAEgFAGgDQgGgEgDgGQgDgHAAgHQAAgHACgEQABgFAGgFIAJgHQAFgCAHAAQAGAAAFACQAGACAEAFQAFAFABAFQADAFAAAGQAAAFgEAJQgCAGgHAEIAJAGQAGAFACAEQACAFACAEIACALIgKAAQAAgFgDgHQgBgDgFgGQgEgDgGgCQgFgDgGAAQgHAAgFADIgJAFQgGAGgBADQgCAFAAAHQAAAGgDAHQgCAHgHAEIAJAGQAFAFABAEQADAEACAGIACALgAglgCQgDABgDACIgFAGIgBAIIABAIIAFAGIAGAFIAIABIAHgBIAHgFIAEgGIACgIIgCgIIgEgGQgDgCgEgBIgHgCIgIACgAAWg/QgEACgCADIgFAGIgBAIIABAIIAFAGIAGAEIAIACIAIgCIAGgEIAEgGIACgIIgCgIIgEgGQgDgDgDgCIgIgBIgIABg");
	this.shape_5.setTransform(1074,747.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdAyIgyAAIAAiBICfAAIAACBIgyAAIgeAegAhFAoIAsAAIAZAaIAZgaIAtAAIAAhtIiLAAg");
	this.shape_6.setTransform(1338,748);

	this.instance = new lib.Group_8();
	this.instance.parent = this;
	this.instance.setTransform(1338,748,1,1,0,0,0,24,20);
	this.instance.alpha = 0;

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_46, new cjs.Rectangle(16,728,1346,40), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhGB4IAAjvICNAAIAADvg");
	mask.setTransform(7.1,12);

	// Livello_3
	this.instance = new lib.ClipGroup_20();
	this.instance.parent = this;
	this.instance.setTransform(7.1,12,1,1,0,0,0,7.1,12);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0,0,14.2,24), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Livello_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);
	this.instance.alpha = 0.8008;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Livello_3
	this.instance = new lib.ClipGroup_7();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.instance = new lib.ClipGroup_5();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AifDIIAAmPIE/AAIAAGPg");
	mask.setTransform(16,20);

	// Livello_3
	this.instance = new lib.ClipGroup_3_1();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//top
		this.topTxt1.textBaseline = "alphabetic";
		this.topTxt3.textBaseline = "alphabetic";
		
		//menu
		
		
		
		//cell
		this.cellTxt1.textBaseline = "alphabetic";
		this.cellTxt2.textBaseline = "alphabetic";
		this.cellTxt3.textBaseline = "alphabetic";
		this.cellTxt4.textBaseline = "alphabetic";
		this.cellTxt5.textBaseline = "alphabetic";
		
		this.cellTxt18.textBaseline = "alphabetic";
		this.cellTxt19.textBaseline = "alphabetic";
		this.cellTxt20.textBaseline = "alphabetic";
		this.cellTxt21.textBaseline = "alphabetic";
		this.cellTxt22.textBaseline = "alphabetic";
		this.cellTxt23.textBaseline = "alphabetic";
		this.cellTxt24.textBaseline = "alphabetic";
		this.cellTxt25.textBaseline = "alphabetic";
		this.cellTxt26.textBaseline = "alphabetic";
		this.cellTxt27.textBaseline = "alphabetic";
		this.cellTxt28.textBaseline = "alphabetic";
		this.cellTxt29.textBaseline = "alphabetic";
		this.cellTxt30.textBaseline = "alphabetic";
		this.cellTxt31.textBaseline = "alphabetic";
		this.cellTxt32.textBaseline = "alphabetic";
		
		//other
		this.oTxt3.textBaseline = "alphabetic";
		this.oTxt4.textBaseline = "alphabetic";
		this.oTxt5.textBaseline = "alphabetic";
		this.oTxt6.textBaseline = "alphabetic";
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// FlashAICB
	this.cellTxt18 = new cjs.Text("1", "14px 'Segoe UI'", "#212120");
	this.cellTxt18.name = "cellTxt18";
	this.cellTxt18.lineHeight = 21;
	this.cellTxt18.parent = this;
	this.cellTxt18.setTransform(42.75,382.6,1.9717,1.9717);

	this.cellTxt19 = new cjs.Text("2", "14px 'Segoe UI'", "#212120");
	this.cellTxt19.name = "cellTxt19";
	this.cellTxt19.lineHeight = 21;
	this.cellTxt19.parent = this;
	this.cellTxt19.setTransform(42.85,467.15,1.9717,1.9717);

	this.cellTxt20 = new cjs.Text("3", "14px 'Segoe UI'", "#212120");
	this.cellTxt20.name = "cellTxt20";
	this.cellTxt20.lineHeight = 21;
	this.cellTxt20.parent = this;
	this.cellTxt20.setTransform(42.85,534.4,1.9717,1.9717);

	this.cellTxt21 = new cjs.Text("4", "14px 'Segoe UI'", "#212120");
	this.cellTxt21.name = "cellTxt21";
	this.cellTxt21.lineHeight = 21;
	this.cellTxt21.parent = this;
	this.cellTxt21.setTransform(42.2,614.75,1.9717,1.9717);

	this.cellTxt22 = new cjs.Text("5", "14px 'Segoe UI'", "#212120");
	this.cellTxt22.name = "cellTxt22";
	this.cellTxt22.lineHeight = 21;
	this.cellTxt22.parent = this;
	this.cellTxt22.setTransform(41.5,691.95,1.9717,1.9717);

	this.cellTxt23 = new cjs.Text("6", "14px 'Segoe UI'", "#212120");
	this.cellTxt23.name = "cellTxt23";
	this.cellTxt23.lineHeight = 21;
	this.cellTxt23.parent = this;
	this.cellTxt23.setTransform(42.85,774.8,1.9717,1.9717);

	this.cellTxt24 = new cjs.Text("7", "14px 'Segoe UI'", "#212120");
	this.cellTxt24.name = "cellTxt24";
	this.cellTxt24.lineHeight = 21;
	this.cellTxt24.lineWidth = 8;
	this.cellTxt24.parent = this;
	this.cellTxt24.setTransform(42.85,853.75,1.9717,1.9717);

	this.cellTxt25 = new cjs.Text("8", "14px 'Segoe UI'", "#212120");
	this.cellTxt25.name = "cellTxt25";
	this.cellTxt25.lineHeight = 21;
	this.cellTxt25.lineWidth = 8;
	this.cellTxt25.parent = this;
	this.cellTxt25.setTransform(42.85,936.65,1.9717,1.9717);

	this.cellTxt26 = new cjs.Text("9", "14px 'Segoe UI'", "#212120");
	this.cellTxt26.name = "cellTxt26";
	this.cellTxt26.lineHeight = 21;
	this.cellTxt26.lineWidth = 8;
	this.cellTxt26.parent = this;
	this.cellTxt26.setTransform(43.65,1016.95,1.9717,1.9717);

	this.cellTxt27 = new cjs.Text("10", "14px 'Segoe UI'", "#212120");
	this.cellTxt27.name = "cellTxt27";
	this.cellTxt27.lineHeight = 21;
	this.cellTxt27.lineWidth = 15;
	this.cellTxt27.parent = this;
	this.cellTxt27.setTransform(35.35,1098.35,1.9717,1.9717);

	this.cellTxt28 = new cjs.Text("11", "14px 'Segoe UI'", "#212120");
	this.cellTxt28.name = "cellTxt28";
	this.cellTxt28.lineHeight = 21;
	this.cellTxt28.lineWidth = 15;
	this.cellTxt28.parent = this;
	this.cellTxt28.setTransform(34.7,1187.05,1.9717,1.9717);

	this.cellTxt29 = new cjs.Text("12", "14px 'Segoe UI'", "#212120");
	this.cellTxt29.name = "cellTxt29";
	this.cellTxt29.lineHeight = 21;
	this.cellTxt29.lineWidth = 15;
	this.cellTxt29.parent = this;
	this.cellTxt29.setTransform(35.35,1246.15,1.9717,1.9717);

	this.cellTxt30 = new cjs.Text("13", "14px 'Segoe UI'", "#212120");
	this.cellTxt30.name = "cellTxt30";
	this.cellTxt30.lineHeight = 21;
	this.cellTxt30.lineWidth = 15;
	this.cellTxt30.parent = this;
	this.cellTxt30.setTransform(34.7,1304.5,1.9717,1.9717);

	this.cellTxt31 = new cjs.Text("14", "14px 'Segoe UI'", "#212120");
	this.cellTxt31.name = "cellTxt31";
	this.cellTxt31.lineHeight = 21;
	this.cellTxt31.lineWidth = 15;
	this.cellTxt31.parent = this;
	this.cellTxt31.setTransform(34.7,1367.7,1.9717,1.9717);

	this.cellTxt32 = new cjs.Text("15", "14px 'Segoe UI'", "#212120");
	this.cellTxt32.name = "cellTxt32";
	this.cellTxt32.lineHeight = 21;
	this.cellTxt32.lineWidth = 15;
	this.cellTxt32.parent = this;
	this.cellTxt32.setTransform(34.7,1429.35,1.9717,1.9717);

	this.cellTxt1 = new cjs.Text("A", "14px 'Segoe UI'", "#212120");
	this.cellTxt1.name = "cellTxt1";
	this.cellTxt1.lineHeight = 21;
	this.cellTxt1.parent = this;
	this.cellTxt1.setTransform(111.1,284,1.9717,1.9717);

	this.cellTxt2 = new cjs.Text("B", "14px 'Segoe UI'", "#212120");
	this.cellTxt2.name = "cellTxt2";
	this.cellTxt2.lineHeight = 21;
	this.cellTxt2.parent = this;
	this.cellTxt2.setTransform(267.55,283.9,1.9717,1.9717);

	this.cellTxt3 = new cjs.Text("C", "14px 'Segoe UI'", "#212120");
	this.cellTxt3.name = "cellTxt3";
	this.cellTxt3.lineHeight = 21;
	this.cellTxt3.parent = this;
	this.cellTxt3.setTransform(493.05,283.2,1.9717,1.9717);

	this.cellTxt4 = new cjs.Text("D", "14px 'Segoe UI'", "#212120");
	this.cellTxt4.name = "cellTxt4";
	this.cellTxt4.lineHeight = 21;
	this.cellTxt4.parent = this;
	this.cellTxt4.setTransform(634.95,283.2,1.9717,1.9717);

	this.cellTxt5 = new cjs.Text("E", "14px 'Segoe UI'", "#212120");
	this.cellTxt5.name = "cellTxt5";
	this.cellTxt5.lineHeight = 21;
	this.cellTxt5.parent = this;
	this.cellTxt5.setTransform(804.95,283.2,1.9717,1.9717);

	this.topTxt1 = new cjs.Text("1:16 PM", "16px 'Segoe UI Semibold'", "#FFFFFF");
	this.topTxt1.name = "topTxt1";
	this.topTxt1.lineHeight = 24;
	this.topTxt1.parent = this;
	this.topTxt1.setTransform(396.75,48.55,1.9717,1.9717);

	this.oTxt4 = new cjs.Text("100%", "12px 'Segoe UI'", "#505050");
	this.oTxt4.name = "oTxt4";
	this.oTxt4.lineHeight = 18;
	this.oTxt4.parent = this;
	this.oTxt4.setTransform(2620.95,1417.05,1.9717,1.9717);

	this.oTxt6 = new cjs.Text("4/1/2019", "12px 'Segoe UI Semilight'", "#FFFFFF");
	this.oTxt6.name = "oTxt6";
	this.oTxt6.lineHeight = 18;
	this.oTxt6.parent = this;
	this.oTxt6.setTransform(2489.65,1499.35,1.9717,1.9717);

	this.oTxt5 = new cjs.Text("10:10 AM", "12px 'Segoe UI Semilight'", "#FFFFFF");
	this.oTxt5.name = "oTxt5";
	this.oTxt5.lineHeight = 18;
	this.oTxt5.parent = this;
	this.oTxt5.setTransform(2487.8,1467.85,1.9717,1.9717);

	this.oTxt3 = new cjs.Text("Display Settings", "12px 'Segoe UI'", "#505050");
	this.oTxt3.name = "oTxt3";
	this.oTxt3.lineHeight = 18;
	this.oTxt3.parent = this;
	this.oTxt3.setTransform(1927.25,1418.5,1.9717,1.9717);

	this.topTxt3 = new cjs.Text("Personal-Budger-Sample", "15px 'Segoe UI Semibold'", "#FFFFFF");
	this.topTxt3.name = "topTxt3";
	this.topTxt3.lineHeight = 23;
	this.topTxt3.lineWidth = 198;
	this.topTxt3.parent = this;
	this.topTxt3.setTransform(276.75,90.2,1.9717,1.9717);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.topTxt3},{t:this.oTxt3},{t:this.oTxt5},{t:this.oTxt6},{t:this.oTxt4},{t:this.topTxt1},{t:this.cellTxt5},{t:this.cellTxt4},{t:this.cellTxt3},{t:this.cellTxt2},{t:this.cellTxt1},{t:this.cellTxt32},{t:this.cellTxt31},{t:this.cellTxt30},{t:this.cellTxt29},{t:this.cellTxt28},{t:this.cellTxt27},{t:this.cellTxt26},{t:this.cellTxt25},{t:this.cellTxt24},{t:this.cellTxt23},{t:this.cellTxt22},{t:this.cellTxt21},{t:this.cellTxt20},{t:this.cellTxt19},{t:this.cellTxt18}]}).wait(1));

	// Livello_3
	this.instance = new lib.ClipGroup_47();
	this.instance.parent = this;
	this.instance.setTransform(-555.35,725.25,1.9717,1.9717,0,0,0,683,384.1);

	this.instance_1 = new lib.ClipGroup_47_B();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-555.35,-663,1.9717,1.9717,0,0,0,683,384.1);

	this.instance_2 = new lib.ClipGroup_50();
	this.instance_2.parent = this;
	this.instance_2.setTransform(793.15,770.6,1.9717,1.9717,0,0,0,683,384.1);

	this.instance_3 = new lib.ClipGroup_42();
	this.instance_3.parent = this;
	this.instance_3.setTransform(90.7,279.1,1.9717,2.7062,0,0,0,0.5,10.1);

	this.instance_4 = new lib.ClipGroup_40();
	this.instance_4.parent = this;
	this.instance_4.setTransform(51.9,306.85,3.1009,1.9717,0,0,0,12.5,0.5);

	this.instance_5 = new lib.ClipGroup_20_0();
	this.instance_5.parent = this;
	this.instance_5.setTransform(51.25,1452.95,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_6 = new lib.ClipGroup_20_0();
	this.instance_6.parent = this;
	this.instance_6.setTransform(51.25,1386.95,3.1009,1.9717,0,0,0,12.5,0.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#BFBFBF").s().p("EhEwAAKIAAgTMCJhAAAIAAATg");
	this.shape.setTransform(438.6,1558.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("EhErAAKIAAgTMCJXAAAIAAATg");
	this.shape_1.setTransform(438.1,1465.775);

	this.instance_7 = new lib.ClipGroup_51();
	this.instance_7.parent = this;
	this.instance_7.setTransform(1345.25,753.55,1.9717,1.9717,0,0,0,683,384.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#257247").s().p("EhEZAMNIAA4ZMCIzAAAIAAYZg");
	this.shape_2.setTransform(436.375,85.425);

	this.instance_8 = new lib.ClipGroup_17_0();
	this.instance_8.parent = this;
	this.instance_8.setTransform(684.15,279.05,1.9717,2.7357,0,0,0,0.6,10);

	this.instance_9 = new lib.ClipGroup_18_0();
	this.instance_9.parent = this;
	this.instance_9.setTransform(602.8,279.2,1.9717,2.7357,0,0,0,0.5,10);

	this.instance_10 = new lib.ClipGroup_19_0();
	this.instance_10.parent = this;
	this.instance_10.setTransform(401.35,279.8,1.9717,2.6766,0,0,0,0.6,10);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B4B4B4").s().p("Ag7A8IB3h3IAAB3g");
	this.shape_3.setTransform(51.0559,281.1527,1.2816,1.2816);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("EhmbAAFIAAgJMDM3AAAIAAAJg");
	this.shape_4.setTransform(484.653,306.8058,0.6006,1.9717);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("EgAJBXmMAAAivLIATAAMAAACvLg");
	this.shape_5.setTransform(90.825,901.525);

	this.instance_11 = new lib.ClipGroup_20_0();
	this.instance_11.parent = this;
	this.instance_11.setTransform(51.25,1322.45,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_12 = new lib.ClipGroup_21();
	this.instance_12.parent = this;
	this.instance_12.setTransform(51.25,1256.95,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_13 = new lib.ClipGroup_22();
	this.instance_13.parent = this;
	this.instance_13.setTransform(51.25,1213.05,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_14 = new lib.ClipGroup_24();
	this.instance_14.parent = this;
	this.instance_14.setTransform(51.25,1139.5,3.1009,1.9717,0,0,0,12.5,0.5);

	this.instance_15 = new lib.ClipGroup_26();
	this.instance_15.parent = this;
	this.instance_15.setTransform(51.25,1030.3,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_16 = new lib.ClipGroup_27();
	this.instance_16.parent = this;
	this.instance_16.setTransform(51.25,977.25,3.1009,1.9717,0,0,0,12.5,0.5);

	this.instance_17 = new lib.ClipGroup_29();
	this.instance_17.parent = this;
	this.instance_17.setTransform(51.25,869.8,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_18 = new lib.ClipGroup_31();
	this.instance_18.parent = this;
	this.instance_18.setTransform(51.25,815.25,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_19 = new lib.ClipGroup_32();
	this.instance_19.parent = this;
	this.instance_19.setTransform(51.9,707.6,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_20 = new lib.ClipGroup_35();
	this.instance_20.parent = this;
	this.instance_20.setTransform(51.25,655.6,3.1009,1.9717,0,0,0,12.5,0.5);

	this.instance_21 = new lib.ClipGroup_36();
	this.instance_21.parent = this;
	this.instance_21.setTransform(51.25,547.05,3.1009,1.9717,0,0,0,12.5,0.5);

	this.instance_22 = new lib.ClipGroup_38();
	this.instance_22.parent = this;
	this.instance_22.setTransform(51.25,490.9,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_23 = new lib.ClipGroup_39();
	this.instance_23.parent = this;
	this.instance_23.setTransform(51.9,415.6,3.1009,1.9717,0,0,0,12.5,0.6);

	this.instance_24 = new lib.ClipGroup_40();
	this.instance_24.parent = this;
	this.instance_24.setTransform(51.9,321.15,3.1009,1.9717,0,0,0,12.5,0.5);

	this.instance_25 = new lib.ClipGroup_42();
	this.instance_25.parent = this;
	this.instance_25.setTransform(149.3,279.1,1.9717,2.7062,0,0,0,0.5,10.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("EhEQBhvMAAAjDdMCIiAAAMAAADDdg");
	this.shape_6.setTransform(437.3,934.225);

	this.instance_26 = new lib.ClipGroup_49();
	this.instance_26.parent = this;
	this.instance_26.setTransform(1345.25,753.55,1.9717,1.9717,0,0,0,683,384.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E6E6E6").s().p("EhGqBypMAAAjlRMCNVAAAMAAADlRg");
	this.shape_7.setTransform(450.8069,731.295,1,1.002);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#C6C6C6").ss(1,1,1).p("AAEkVIgHIr");
	this.shape_8.setTransform(117.025,212.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.instance_26},{t:this.shape_6},{t:this.instance_25},{t:this.instance_24},{t:this.instance_23},{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.shape_2},{t:this.instance_7},{t:this.shape_1},{t:this.shape},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(-442.8,-1360.5,3134.8,3521.6), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.softwarevector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.excel.cache(-2500,-1700,5000,3400,0.3)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 7
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3F3F").s().p("AgGA0QgEAAgDgDQgDgDAAgEIAAgOQAAgNgJgLQgLgKACgQQACgMAJgIQAKgJANAAQAOAAALAKQAKAKAAAOQAAANgJAJQgJAJAAAOIAAAOQAAAEgDADQgDADgEAAgAgKAqQAAAFAEAAIANAAQAFAAAAgFIAAgGIgWAAgAgTgmQgIAHgCAKQgBANAJAJQAKAMAAAPIAAADIAWAAIAAgDQAAgRALgJQAIgIAAgLQAAgMgJgIQgJgJgMAAQgLAAgIAIg");
	this.shape.setTransform(543.5036,1312.6274,4.7129,4.7129);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer 6
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#3F3F3F").s().p("AgNAbIgRgRQgCgDAAgDQAAgDACgDIADgCIADAEIgCABIgBADIABACIARARQACADADgDIAVgWQAAgBABAAQAAAAAAAAQAAgBAAgBQgBAAAAgBIgRgRIgCgBIgCABIgOAOIgDgEIAAAAIAIgIIABgBQgIACgDADQgBADACAEQADAFAEAAQAFABAIgEIgBAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAgBQABAAAAAAQAAgBAAAAQABAAAAAAQABgBAAAAQAGAAAAAHQAAAFgGAAIgCgBQgIAEgFAAIgDAAQgHgCgDgGQgEgHADgEQAFgJAOACIAFgFIASASQAGgBAFABQAJADgCAPQgDAbgDgbIgBgFQgBgCAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAIACABIgaAbQgDACgDAAQgDAAgDgCg");
	this.shape_1.setTransform(435.9738,1304.7875,4.7136,4.7136);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#3F3F3F").s().p("Ag2AOIAAgbIBtAAIAAAbg");
	this.shape_2.setTransform(434.0615,1330.6379,4.7143,4.7143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer 5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#3F3F3F").ss(0.8).p("AARAAIghAA");
	this.shape_3.setTransform(330.1398,1304.3557,4.7143,4.7143);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#9E83BF").s().p("AguBBIAAgKIBHhoIAAgBIhBAAIAAgOIBWAAIAAAKIhHBoIAAABIBIAAIAAAOg");
	this.shape_4.setTransform(296.25,1331.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#71A7D8").s().p("AAlBBIgPgpIgtAAIgNApIgRAAIAsiBIATAAIAtCBgAATALIgNglIgEgMIgCgLIAAAAIgDALIgDAMIgNAlIAmAAg");
	this.shape_5.setTransform(295.4,1307.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#3F3F3F").ss(0.8).p("AAYgpQAMAAABAHQABAEgEAFQgFAHgUAUIAAAhQAAAHgJAAQgEgBgCgDIgBgDIAAggQgTgNgIgPQgDgFACgEQADgGAMAAg");
	this.shape_6.setTransform(330.4751,1314.735,4.7143,4.7143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(1));

	// Layer 4
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#525252").s().p("AgSAMQgIgBgFgFIgBgDIABgCIACgBIADABQAEADAFAAIACACIABACIgBADIgDABIAAAAgAAVAMIgDAAIgHAAIgDgBIgBgDIABgDIADgBIAHAAIADAAIACABIABADIgBADIgCABIAAAAgAABAMIgJAAIgDgBIgBgDIABgDIADgBIAJAAIADABIABADIgBADIgDABIAAAAgAAdAHIgCgBIgBgDIABgCQAEgDAAgFIABgDIACgBIADABIABADQAAAHgGAGIgDABIAAAAgAghgDIgDgBIgBgCIAAgBIABgDIADgBIACABIABADIAAABIgBACIgCACIAAgBg");
	this.shape_7.setTransform(196.636,1311.8989,4.7143,4.7143);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#3F3F3F").ss(0.8).p("AANgJIgNAOIgMgN");
	this.shape_8.setTransform(222.7243,1327.4241,4.7143,4.7143);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#3F3F3F").ss(0.8).p("AAAgpIAABT");
	this.shape_9.setTransform(222.8004,1308.245,4.7143,4.7143);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#92BCA6").p("AAdAOIg4AAQgGAAAAgFIAAgQQAAgGAGAAIA4AAQAGAAAAAGIAAAQQAAAFgGAAg");
	this.shape_10.setTransform(196.636,1296.9306,4.7143,4.7143);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#92BCA6").s().p("AgcAOQgFABAAgGIAAgQQAAgHAFAAIA5AAQAGAAgBAHIAAAQQABAGgGgBg");
	this.shape_11.setTransform(196.636,1296.9306,4.7143,4.7143);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#525252").s().p("AAFAyIgBgDIABgCIADgCIAKAAIAEAAIADABIACACIgBADIgCABIgGABIgKAAIAAAAIgDgBgAgBAzIgKAAIgDgBIgBgDIABgCIADgCIAKAAIACACIABACIgBADIgCABIAAAAgAgVAyQgGgBgEgEIgDgEIgBgCIACgDIADAAIACABIACADQADACADABIADACIAAADIgCACIgBABIgBgBgAAeAqIgCgCIABgDQACgDAAgDIAAgDIABgDIACgBIADABIABADIAAADQAAAGgDAEIgDACIAAAAIgCgBgAghAiIgDgBIgBgDIAAgKIABgCIADgCIACACIABACIAAAKIgBADIgCABIAAAAgAAiAWIgCgBIgBgDIAAgKIABgDIACAAIADAAIABADIAAAKIgBADIgCABIgBAAgAghAOIgDgBIgBgDIAAgKIABgCIADgBIACABIABACIAAAKIgBADIgCABIAAAAgAAiACIgCgBIgBgCIAAgKIABgCIACgBIADABIABACIAAAKIgBACIgCABIgBAAgAghgFIgDgBIgBgDIAAgKIABgCIADgBIACABIABACIAAAKIgBADIgCABIAAAAgAAigRIgCgBIgBgDIAAgJIAAgBIABgCIACgBIADABIABACIAAABIAAAJIgBADIgCABIgBAAgAghgZIgDgBIgBgDIAAgBQAAgHAEgFIADgBIACABIACADIgBACQgDADAAAEIAAABIgBADIgCABIAAAAgAAagnQgDgEgFABIgBAAIgDgBIgBgDIABgDIADgBIABAAQAHAAAGAFIABADIgBACIgCABIAAABIgDgBgAgXgqIgCgDIABgDIACgBIAGgBIAEAAIADABIABADIgBADIgDABIgEAAIgEAAIgBAAIgCAAgAAHgqIgJAAIgDgBIgBgDIABgDIADgBIAJAAIADABIABADIgBADIgDABIAAAAg");
	this.shape_12.setTransform(196.636,1312.3692,4.7143,4.7143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7}]}).wait(1));

	// Layer 3
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#3F3F3F").p("AAOALIgbAAQgGAAAAgGIAAgJQAAgFAGAAIAbAAQAGAAAAAFIAAAJQAAAGgGAAg");
	this.shape_13.setTransform(67.8751,1330.8736,4.7143,4.7143);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#3F3F3F").p("AAAgKIAAAV");
	this.shape_14.setTransform(77.8841,1330.8304,4.7136,4.7136);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#3F3F3F").p("Ag1AAIBrAA");
	this.shape_15.setTransform(84.3654,1307.4979,4.7136,4.7136);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#3F3F3F").p("AAAgjIAABI");
	this.shape_16.setTransform(83.3048,1307.1443,4.7136,4.7136);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#3F3F3F").p("AAOALIgbAAQgFAAAAgFIAAgKQAAgFAFAAIAbAAQAFAAAAAFIAAAKQAAAFgFAAg");
	this.shape_17.setTransform(87.0858,1330.8736,4.7143,4.7143);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#92BCA6").s().p("AgNALQgGAAABgGIAAgJQgBgGAGABIAcAAQAEgBAAAGIAAAJQAAAGgEAAg");
	this.shape_18.setTransform(87.0858,1330.8736,4.7143,4.7143);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#3F3F3F").p("AAwAmIhgAAQgFAAAAgGIAAg/QAAgGAFAAIBgAAQAGAAAAAGIAAA/QAAAGgGAAg");
	this.shape_19.setTransform(84.7287,1307.6557,4.7143,4.7143);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgwAmQgFAAAAgGIAAg/QAAgGAFAAIBgAAQAGAAAAAGIAAA/QAAAGgGAAg");
	this.shape_20.setTransform(84.7287,1307.6557,4.7143,4.7143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13}]}).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg5LBp2MAAAjR8MB0tAAAMAAADR8g");
	mask.setTransform(380.9658,677.375);

	// Livello_1
	this.excel = new lib.ClipGroup();
	this.excel.name = "excel";
	this.excel.parent = this;
	this.excel.setTransform(597.55,336.25,0.8667,0.8667,0,0,0,683,383.9);

	var maskedShapeInstanceList = [this.excel];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.excel).wait(1));

}).prototype = getMCSymbolPrototype(lib.softwarevector, new cjs.Rectangle(15,11.1,747,1343.7), null);


(lib.screen_new = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// graphs
	this.graphs = new lib.graphsphone();
	this.graphs.name = "graphs";
	this.graphs.parent = this;
	this.graphs.setTransform(1231.25,737.85,2.1766,2.1766,0,0,0,468.8,181.3);

	this.timeline.addTween(cjs.Tween.get(this.graphs).wait(1));

	// software
	this.instance = new lib.softwarevector();
	this.instance.parent = this;
	this.instance.setTransform(585.7,328.15,1,1,0,0,0,591.9,332.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_new, new cjs.Rectangle(-1.8,-4.5,2334.2000000000003,1355.2), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(104.5,-5.3,0.6803,0.6051,0,0,0,13.7,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(60.6,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#338054").s().p("AmrBvIAAjdINXAAIAADdg");
	this.shape.setTransform(85.675,-6.475);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(42.9,-17.5,85.6,22.1), null);


(lib.Group_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(7.1,12,1,1,0,0,0,7.1,12);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_9, new cjs.Rectangle(0,0,14.2,24), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_2();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,32,40), null);


(lib.Group_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_4();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(0,0,32,40), null);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_6();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(-0.2,0,11.7,11.5), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.ClipGroup_9();
	this.instance.parent = this;
	this.instance.setTransform(16,20,1,1,0,0,0,16,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,32,40), null);


(lib.ClipGroup_44 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAOAuIgOgfIAAgCIAAgBIAAgCIAAAAIAAABIgCAFIgNAdIgTgCIAWgrIgVgqIAUgBIALAaIABACIABAFIABgFIANgeIAVgCIgZAvIAaAwg");
	this.shape.setTransform(603.3,748);

	this.instance = new lib.Group_9();
	this.instance.parent = this;
	this.instance.setTransform(603.7,748.05,1,1,0,0,0,7.1,12);
	this.instance.alpha = 0.0508;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#247247").s().p("AhGBfIAAi9ICNgZIAADvg");
	this.shape_1.setTransform(603.7,748.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_2.setTransform(612.225,753.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_3.setTransform(612.225,750.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_4.setTransform(612.225,748.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_5.setTransform(612.225,745.175);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_6.setTransform(612.225,742.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_7.setTransform(616.475,753.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_8.setTransform(616.475,750.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_9.setTransform(616.475,748.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_10.setTransform(616.475,745.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#247247").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_11.setTransform(616.475,742.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#247247").s().p("Ag+BeQgJAAAAgJIAAipQAAgJAJAAIB+AAQADAAACADQADACAAAEIAACpQAAAEgDACQgCADgDAAgAg+BVIB+AAIAAipIh+AAg");
	this.shape_12.setTransform(613,748.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("Ag+BZQgFAAAAgEIAAipQAAgEAFAAIB+AAQAEAAAAAEIAACpQAAAEgEAAg");
	this.shape_13.setTransform(612.975,748.025);

	this.instance_1 = new lib.Group_1_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(608,748,1,1,0,0,0,24,20);
	this.instance_1.alpha = 0;

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#7AB9EB").s().p("AjvAKIAAgTIHfAAIAAATg");
	this.shape_14.setTransform(608,767);

	this.instance_2 = new lib.Group_2_0();
	this.instance_2.parent = this;
	this.instance_2.setTransform(608,748,1,1,0,0,0,24,20);
	this.instance_2.alpha = 0.1992;

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AhJBKQgfgeAAgsQAAgrAfgeQAfgfAqAAQArAAAgAfQAeAeAAArQAAAsgeAeQggAfgrAAQgqAAgfgfgAg6g7QgaAZAAAiQAAAjAaAZQAYAYAiAAQAkAAAYgYQAYgZABgjQgBgigYgZQgZgYgjAAQgiAAgYAYg");
	this.shape_15.setTransform(67.95,748.025);

	this.instance_3 = new lib.Group_3_0();
	this.instance_3.parent = this;
	this.instance_3.setTransform(67.95,748,1,1,0,0,0,12,12);
	this.instance_3.alpha = 0.3984;

	this.instance_4 = new lib.Group_5_0();
	this.instance_4.parent = this;
	this.instance_4.setTransform(369.4,748,1,1,0,0,0,5.5,8);
	this.instance_4.alpha = 0.8008;

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FAFAFA").s().p("A63DIIAAmPMA1vAAAIAAGPg");
	this.shape_16.setTransform(219.925,748);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3977BA").s().p("Ag2BdQgcgcAAgmQAAgeARgXQAPgXAbgLQgOAPgDAXIBUAAQAAgzgwAAQgdAAgeARQgeARgRAbQAGgvAegdQAfgeAugBQAvABAeAfQAfAgAAAxIAAAaIiWAAQAAAYASAOQASAMAbAAQAlAAAdgSIAAAzQghARgpAAQgqAAgcgbg");
	this.shape_17.setTransform(559.975,748);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#7FB91D").s().p("AgXAYIAAgvIAvAAIAAAvg");
	this.shape_18.setTransform(514.425,747.55);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FCB926").s().p("AgXAYIAAgvIAvAAIAAAvg");
	this.shape_19.setTransform(514.425,753.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#EF522D").s().p("AgYAYIAAgvIAxAAIAAAvg");
	this.shape_20.setTransform(508.55,747.55);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#26A5ED").s().p("AgYAYIAAgvIAxAAIAAAvg");
	this.shape_21.setTransform(508.55,753.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AheBxQgHAAgGgFQgFgFAAgHIAAiVIBFAAIAAgOQAAgTANgNQANgNARAAQASAAANANQANANAAATIAAAOIALAAIAAgFIgBgKQAAgNgGgLQAPALAAAXIAAAFIAyAAIAACVQAAAHgFAFQgFAFgHAAgAAIhbQgKAEgGAJQgHAJAAALIAAAFIAxAAIAAgOQAAgOgKgLQgKgKgOAAQgNAAgKAKQgKALAAAOIAAAOIALAAIAAgFQAAgUAPgMQAEgCADAAIAIABg");
	this.shape_22.setTransform(511.475,747.525);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#45B5E4").s().p("AAeAtIAAgxIg7AAIAAAxIgoAAIAAhMQAAgGAEgDQADgEAGAAIBwAAQAGAAAEAEQAEADAAAGIAABMg");
	this.shape_23.setTransform(464,753);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#45B5E4").s().p("AgEAHIAAgNIAJAAIAAANg");
	this.shape_24.setTransform(455.5,740.25);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgUAHIAAgNIApAAIAAANg");
	this.shape_25.setTransform(457.875,740.25);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FDE797").s().p("AhiBQQgFAAgDgDQgDgEAAgEIAAiAIBTAAQAJAAAFgFIANgPIBhAAQAFAAAEAEQADADAAAGIAACHQAAAEgDAEQgEADgFAAg");
	this.shape_26.setTransform(464,748.5);

	var maskedShapeInstanceList = [this.shape,this.instance,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.instance_1,this.shape_14,this.instance_2,this.shape_15,this.instance_3,this.instance_4,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.instance_4},{t:this.instance_3},{t:this.shape_15},{t:this.instance_2},{t:this.shape_14},{t:this.instance_1},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_44, new cjs.Rectangle(48,728,584,40), null);


(lib.ClipGroup_47_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// Livello_3
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAAgVIg2A2IgFgGIA7g7IA8A7IgFAGg");
	this.shape_3.setTransform(1109.95,748.025);

	this.instance = new lib.Group_7();
	this.instance.parent = this;
	this.instance.setTransform(1110,748,1,1,0,0,0,16,20);
	this.instance.alpha = 0;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUA8IgdgeIgUAAIAAg7IAUAAIAdgeIAKAAIAAB3gAgTAUIAOAAIAZAaIAAhaIgWAWIgDADIgOAAg");
	this.shape_4.setTransform(1201,748);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgKAeQALgNAAgRQAAgQgLgNIAHgHQAOAPAAAVQAAAWgOAPg");
	this.shape_5.setTransform(1206.9,748.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOAzQATgVAAgeQAAgdgTgVIAHgHQAWAYAAAhQAAAigWAYg");
	this.shape_6.setTransform(1209.475,748.025);

	this.instance_1 = new lib.Group_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1212,748,1,1,0,0,0,1.9,7.8);
	this.instance_1.alpha = 0.3984;

	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1206,748,1,1,0,0,0,16,20);
	this.instance_2.alpha = 0;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJAAQAAgJAJAAQAEAAADADQADADAAADQAAAFgDADQgDACgEAAQgJAAAAgKg");
	this.shape_7.setTransform(1179,753);

	this.instance_3 = new lib.Group_3();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1174.6,748.8,1,1,0,0,0,5.6,5.8);
	this.instance_3.alpha = 0.3984;

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").p("AgiAoQAAgfAWgVQAVgWAfAA");
	this.shape_8.setTransform(1176,750);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").p("AgTAZQAAgTANgLQANgOASAA");
	this.shape_9.setTransform(1177.5,751.5);

	this.instance_4 = new lib.Group_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1174,748,1,1,0,0,0,16,20);
	this.instance_4.alpha = 0;

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag1AUIAAgnIBrAAIAAAng");
	this.shape_10.setTransform(1141.4,748.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgHAKIAAgTIAPAAIAAATg");
	this.shape_11.setTransform(1149.25,748);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhKAoIAAhPICVAAIAABPgAhAAeICBAAIAAg7IiBAAg");
	this.shape_12.setTransform(1141.5,748);

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(1142,748,1,1,0,0,0,16,20);
	this.instance_5.alpha = 0;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfBRIgCgEIACgFIADgFQgCgDAAgEIAAgOIABgCIAthcIgFgCIgSAmIgCACIgDABQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIABgDIASgmIADgEIAFgCIAGABIAFADIAFgLIACgDIADAAIACAAIAEgHIADgDIAEgBQADAAACACIAHADIAEAEIACAFIgBAFIgDAFIACACIABACIAAABIgBACIg5BxIgCACIgNAHIgFABIgCAAIgEAIIgCACIgCABIgEgCgAgUAwIAAAMIABABIACABIABAAIACgCIADgBIAHgEIA1hqIgQgIgAAqhCIAHADIACgFIgHgDgAgtBTQgIAAgGgDQgIgEgEgEQgEgEgEgIQgDgGAAgIQAAgHADgHQADgGAFgFQAFgFAHgDQAGgDAIAAIASAAIgGALIgMAAQgGAAgEACIgJAFQgDADgCAFQgCAFAAAFQAAAGACAEQACAGADADQAEADAFACQAEACAGAAIADAAIgBADIAAAFIABADgAAnAVIAFgLIASAAIAEAAIADgDIACgDIABgEIgBgDIgCgDIgDgDIgEAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAEAAAEACIAGAEQADADACAEQACADAAAEQAAAFgCADQgCAEgDADIgGAEQgEACgEAAg");
	this.shape_13.setTransform(1237.975,748.025);

	this.instance_6 = new lib.Group_6();
	this.instance_6.parent = this;
	this.instance_6.setTransform(1238,748,1,1,0,0,0,16,20);
	this.instance_6.alpha = 0;

	var maskedShapeInstanceList = [this.shape_3,this.instance,this.shape_4,this.shape_5,this.shape_6,this.instance_1,this.instance_2,this.shape_7,this.instance_3,this.shape_8,this.shape_9,this.instance_4,this.shape_10,this.shape_11,this.shape_12,this.instance_5,this.shape_13,this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.shape_13},{t:this.instance_5},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.instance_4},{t:this.shape_9},{t:this.shape_8},{t:this.instance_3},{t:this.shape_7},{t:this.instance_2},{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance},{t:this.shape_3}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_47_1, new cjs.Rectangle(1094,728,160,40), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//top
		this.txt1.textBaseline = "alphabetic";
		this.topTxt2.textBaseline = "alphabetic";
		this.txt3.textBaseline = "alphabetic";
		this.topTxt4.textBaseline = "alphabetic";
		
		//menu
		this.menuTxt1.textBaseline = "alphabetic";
		this.menuTxt2.textBaseline = "alphabetic";
		this.menuTxt3.textBaseline = "alphabetic";
		this.menuTxt4.textBaseline = "alphabetic";
		this.menuTxt5.textBaseline = "alphabetic";
		this.menuTxt6.textBaseline = "alphabetic";
		this.menuTxt7.textBaseline = "alphabetic";
		this.menuTxt8.textBaseline = "alphabetic";
		this.menuTxt9.textBaseline = "alphabetic";
		this.menuTxt10.textBaseline = "alphabetic";
		this.menuTxt11.textBaseline = "alphabetic";
		this.menuTxt12.textBaseline = "alphabetic";
		
		
		//cell
		this.celltxt1.textBaseline = "alphabetic";
		this.celltxt2.textBaseline = "alphabetic";
		this.celltxt3.textBaseline = "alphabetic";
		this.celltxt4.textBaseline = "alphabetic";
		this.celltxt5.textBaseline = "alphabetic";
		this.celltxt6.textBaseline = "alphabetic";
		this.celltxt7.textBaseline = "alphabetic";
		this.celltxt8.textBaseline = "alphabetic";
		this.celltxt9.textBaseline = "alphabetic";
		this.celltxt10.textBaseline = "alphabetic";
		this.celltxt11.textBaseline = "alphabetic";
		this.celltxt12.textBaseline = "alphabetic";
		this.celltxt13.textBaseline = "alphabetic";
		this.celltxt14.textBaseline = "alphabetic";
		this.celltxt15.textBaseline = "alphabetic";
		this.celltxt16.textBaseline = "alphabetic";
		this.celltxt17.textBaseline = "alphabetic";
		this.celltxt18.textBaseline = "alphabetic";
		this.celltxt19.textBaseline = "alphabetic";
		this.celltxt20.textBaseline = "alphabetic";
		this.celltxt21.textBaseline = "alphabetic";
		this.celltxt22.textBaseline = "alphabetic";
		this.celltxt23.textBaseline = "alphabetic";
		this.celltxt24.textBaseline = "alphabetic";
		this.celltxt25.textBaseline = "alphabetic";
		this.celltxt26.textBaseline = "alphabetic";
		this.celltxt27.textBaseline = "alphabetic";
		this.celltxt28.textBaseline = "alphabetic";
		this.celltxt29.textBaseline = "alphabetic";
		this.celltxt30.textBaseline = "alphabetic";
		this.celltxt31.textBaseline = "alphabetic";
		this.celltxt32.textBaseline = "alphabetic";
		this.celltxt33.textBaseline = "alphabetic";
		this.celltxt34.textBaseline = "alphabetic";
		this.celltxt35.textBaseline = "alphabetic";
		this.celltxt36.textBaseline = "alphabetic";
		this.celltxt37.textBaseline = "alphabetic";
		this.celltxt38.textBaseline = "alphabetic";
		this.celltxt39.textBaseline = "alphabetic";
		
		//other
		this.otxt1.textBaseline = "alphabetic";
		this.otxt2.textBaseline = "alphabetic";
		this.otxt3.textBaseline = "alphabetic";
		this.otxt4.textBaseline = "alphabetic";
		this.otxt5.textBaseline = "alphabetic";
		this.otxt6.textBaseline = "alphabetic";
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Livello_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	mask.setTransform(683,384);

	// FlashAICB
	this.celltxt18 = new cjs.Text("1", "14px 'Segoe Pro'", "#212120");
	this.celltxt18.name = "celltxt18";
	this.celltxt18.lineHeight = 21;
	this.celltxt18.parent = this;
	this.celltxt18.setTransform(9.95,151.05);

	this.celltxt19 = new cjs.Text("2", "14px 'Segoe Pro'", "#212120");
	this.celltxt19.name = "celltxt19";
	this.celltxt19.lineHeight = 21;
	this.celltxt19.parent = this;
	this.celltxt19.setTransform(10,175.65);

	this.celltxt20 = new cjs.Text("3", "14px 'Segoe Pro'", "#212120");
	this.celltxt20.name = "celltxt20";
	this.celltxt20.lineHeight = 21;
	this.celltxt20.parent = this;
	this.celltxt20.setTransform(10,201.05);

	this.celltxt21 = new cjs.Text("4", "14px 'Segoe Pro'", "#212120");
	this.celltxt21.name = "celltxt21";
	this.celltxt21.lineHeight = 21;
	this.celltxt21.parent = this;
	this.celltxt21.setTransform(9.65,226.4);

	this.celltxt22 = new cjs.Text("5", "14px 'Segoe Pro'", "#212120");
	this.celltxt22.name = "celltxt22";
	this.celltxt22.lineHeight = 21;
	this.celltxt22.parent = this;
	this.celltxt22.setTransform(9.3,251.4);

	this.celltxt23 = new cjs.Text("6", "14px 'Segoe Pro'", "#212120");
	this.celltxt23.name = "celltxt23";
	this.celltxt23.lineHeight = 21;
	this.celltxt23.parent = this;
	this.celltxt23.setTransform(10,276.35);

	this.celltxt24 = new cjs.Text("7", "14px 'Segoe Pro'", "#212120");
	this.celltxt24.name = "celltxt24";
	this.celltxt24.lineHeight = 21;
	this.celltxt24.lineWidth = 8;
	this.celltxt24.parent = this;
	this.celltxt24.setTransform(10,301.4);

	this.celltxt25 = new cjs.Text("8", "14px 'Segoe Pro'", "#212120");
	this.celltxt25.name = "celltxt25";
	this.celltxt25.lineHeight = 21;
	this.celltxt25.lineWidth = 8;
	this.celltxt25.parent = this;
	this.celltxt25.setTransform(10,325.95);

	this.celltxt26 = new cjs.Text("9", "14px 'Segoe Pro'", "#212120");
	this.celltxt26.name = "celltxt26";
	this.celltxt26.lineHeight = 21;
	this.celltxt26.lineWidth = 8;
	this.celltxt26.parent = this;
	this.celltxt26.setTransform(10.4,351.35);

	this.celltxt27 = new cjs.Text("10", "14px 'Segoe Pro'", "#212120");
	this.celltxt27.name = "celltxt27";
	this.celltxt27.lineHeight = 21;
	this.celltxt27.lineWidth = 15;
	this.celltxt27.parent = this;
	this.celltxt27.setTransform(6.2,376);

	this.celltxt28 = new cjs.Text("11", "14px 'Segoe Pro'", "#212120");
	this.celltxt28.name = "celltxt28";
	this.celltxt28.lineHeight = 21;
	this.celltxt28.lineWidth = 15;
	this.celltxt28.parent = this;
	this.celltxt28.setTransform(5.85,401.4);

	this.celltxt29 = new cjs.Text("12", "14px 'Segoe Pro'", "#212120");
	this.celltxt29.name = "celltxt29";
	this.celltxt29.lineHeight = 21;
	this.celltxt29.lineWidth = 15;
	this.celltxt29.parent = this;
	this.celltxt29.setTransform(6.2,426);

	this.celltxt30 = new cjs.Text("13", "14px 'Segoe Pro'", "#212120");
	this.celltxt30.name = "celltxt30";
	this.celltxt30.lineHeight = 21;
	this.celltxt30.lineWidth = 15;
	this.celltxt30.parent = this;
	this.celltxt30.setTransform(5.85,451);

	this.celltxt31 = new cjs.Text("14", "14px 'Segoe Pro'", "#212120");
	this.celltxt31.name = "celltxt31";
	this.celltxt31.lineHeight = 21;
	this.celltxt31.lineWidth = 15;
	this.celltxt31.parent = this;
	this.celltxt31.setTransform(5.85,476.8);

	this.celltxt32 = new cjs.Text("15", "14px 'Segoe Pro'", "#212120");
	this.celltxt32.name = "celltxt32";
	this.celltxt32.lineHeight = 21;
	this.celltxt32.lineWidth = 15;
	this.celltxt32.parent = this;
	this.celltxt32.setTransform(5.85,501.4);

	this.celltxt33 = new cjs.Text("16", "14px 'Segoe Pro'", "#212120");
	this.celltxt33.name = "celltxt33";
	this.celltxt33.lineHeight = 21;
	this.celltxt33.lineWidth = 15;
	this.celltxt33.parent = this;
	this.celltxt33.setTransform(6.2,526.4);

	this.celltxt34 = new cjs.Text("17", "14px 'Segoe Pro'", "#212120");
	this.celltxt34.name = "celltxt34";
	this.celltxt34.lineHeight = 21;
	this.celltxt34.lineWidth = 15;
	this.celltxt34.parent = this;
	this.celltxt34.setTransform(6.2,551.4);

	this.celltxt35 = new cjs.Text("18", "14px 'Segoe Pro'", "#212120");
	this.celltxt35.name = "celltxt35";
	this.celltxt35.lineHeight = 21;
	this.celltxt35.lineWidth = 15;
	this.celltxt35.parent = this;
	this.celltxt35.setTransform(6.2,576.4);

	this.celltxt36 = new cjs.Text("19", "14px 'Segoe Pro'", "#212120");
	this.celltxt36.name = "celltxt36";
	this.celltxt36.lineHeight = 21;
	this.celltxt36.lineWidth = 15;
	this.celltxt36.parent = this;
	this.celltxt36.setTransform(6.2,601.4);

	this.celltxt37 = new cjs.Text("20", "14px 'Segoe Pro'", "#212120");
	this.celltxt37.name = "celltxt37";
	this.celltxt37.lineHeight = 21;
	this.celltxt37.lineWidth = 15;
	this.celltxt37.parent = this;
	this.celltxt37.setTransform(5.85,626.35);

	this.celltxt38 = new cjs.Text("21", "14px 'Segoe Pro'", "#212120");
	this.celltxt38.name = "celltxt38";
	this.celltxt38.lineHeight = 21;
	this.celltxt38.lineWidth = 15;
	this.celltxt38.parent = this;
	this.celltxt38.setTransform(6.2,651.75);

	this.celltxt1 = new cjs.Text("A", "14px 'Segoe Pro'", "#212120");
	this.celltxt1.name = "celltxt1";
	this.celltxt1.lineHeight = 21;
	this.celltxt1.parent = this;
	this.celltxt1.setTransform(58.8,128.7);

	this.celltxt2 = new cjs.Text("B", "14px 'Segoe Pro'", "#212120");
	this.celltxt2.name = "celltxt2";
	this.celltxt2.lineHeight = 21;
	this.celltxt2.parent = this;
	this.celltxt2.setTransform(134.15,123.25);

	this.celltxt3 = new cjs.Text("C", "14px 'Segoe Pro'", "#212120");
	this.celltxt3.name = "celltxt3";
	this.celltxt3.lineHeight = 21;
	this.celltxt3.parent = this;
	this.celltxt3.setTransform(208.75,128.3);

	this.celltxt4 = new cjs.Text("D", "14px 'Segoe Pro'", "#212120");
	this.celltxt4.name = "celltxt4";
	this.celltxt4.lineHeight = 21;
	this.celltxt4.parent = this;
	this.celltxt4.setTransform(283,128.3);

	this.celltxt5 = new cjs.Text("E", "14px 'Segoe Pro'", "#212120");
	this.celltxt5.name = "celltxt5";
	this.celltxt5.lineHeight = 21;
	this.celltxt5.parent = this;
	this.celltxt5.setTransform(359.55,128.3);

	this.celltxt6 = new cjs.Text("F", "14px 'Segoe Pro'", "#212120");
	this.celltxt6.name = "celltxt6";
	this.celltxt6.lineHeight = 21;
	this.celltxt6.parent = this;
	this.celltxt6.setTransform(434.85,127.9);

	this.celltxt7 = new cjs.Text("G", "14px 'Segoe Pro'", "#212120");
	this.celltxt7.name = "celltxt7";
	this.celltxt7.lineHeight = 21;
	this.celltxt7.parent = this;
	this.celltxt7.setTransform(507.95,128.3);

	this.celltxt8 = new cjs.Text("H", "14px 'Segoe Pro'", "#212120");
	this.celltxt8.name = "celltxt8";
	this.celltxt8.lineHeight = 21;
	this.celltxt8.parent = this;
	this.celltxt8.setTransform(582.2,128.65);

	this.celltxt9 = new cjs.Text("I", "14px 'Segoe Pro'", "#212120");
	this.celltxt9.name = "celltxt9";
	this.celltxt9.lineHeight = 21;
	this.celltxt9.parent = this;
	this.celltxt9.setTransform(660.2,129.45);

	this.celltxt10 = new cjs.Text("J", "14px 'Segoe Pro'", "#212120");
	this.celltxt10.name = "celltxt10";
	this.celltxt10.lineHeight = 21;
	this.celltxt10.parent = this;
	this.celltxt10.setTransform(734.4,128.3);

	this.celltxt11 = new cjs.Text("K", "14px 'Segoe Pro'", "#212120");
	this.celltxt11.name = "celltxt11";
	this.celltxt11.lineHeight = 21;
	this.celltxt11.parent = this;
	this.celltxt11.setTransform(808.25,128.65);

	this.celltxt12 = new cjs.Text("L", "14px 'Segoe Pro'", "#212120");
	this.celltxt12.name = "celltxt12";
	this.celltxt12.lineHeight = 21;
	this.celltxt12.lineWidth = 7;
	this.celltxt12.parent = this;
	this.celltxt12.setTransform(883.55,128.3);

	this.celltxt13 = new cjs.Text("M", "14px 'Segoe Pro'", "#212120");
	this.celltxt13.name = "celltxt13";
	this.celltxt13.lineHeight = 21;
	this.celltxt13.lineWidth = 13;
	this.celltxt13.parent = this;
	this.celltxt13.setTransform(955.5,128.3);

	this.celltxt14 = new cjs.Text("N", "14px 'Segoe Pro'", "#212120");
	this.celltxt14.name = "celltxt14";
	this.celltxt14.lineHeight = 21;
	this.celltxt14.lineWidth = 13;
	this.celltxt14.parent = this;
	this.celltxt14.setTransform(1031.65,128.3);

	this.celltxt16 = new cjs.Text("P", "14px 'Segoe Pro'", "#212120");
	this.celltxt16.name = "celltxt16";
	this.celltxt16.lineHeight = 21;
	this.celltxt16.lineWidth = 13;
	this.celltxt16.parent = this;
	this.celltxt16.setTransform(1183.5,128.65);

	this.celltxt15 = new cjs.Text("O", "14px 'Segoe Pro'", "#212120");
	this.celltxt15.name = "celltxt15";
	this.celltxt15.lineHeight = 21;
	this.celltxt15.lineWidth = 13;
	this.celltxt15.parent = this;
	this.celltxt15.setTransform(1106.65,128.3);

	this.celltxt17 = new cjs.Text("Q", "14px 'Segoe Pro'", "#212120");
	this.celltxt17.name = "celltxt17";
	this.celltxt17.lineHeight = 21;
	this.celltxt17.lineWidth = 13;
	this.celltxt17.parent = this;
	this.celltxt17.setTransform(1256.65,128.65);

	this.menuTxt10 = new cjs.Text("Search", "13px 'Segoe Pro'", "#494846");
	this.menuTxt10.name = "menuTxt10";
	this.menuTxt10.lineHeight = 20;
	this.menuTxt10.lineWidth = 44;
	this.menuTxt10.parent = this;
	this.menuTxt10.setTransform(644.1,64.25);

	this.menuTxt9 = new cjs.Text("Help", "13px 'Segoe Pro'", "#494846");
	this.menuTxt9.name = "menuTxt9";
	this.menuTxt9.lineHeight = 20;
	this.menuTxt9.lineWidth = 44;
	this.menuTxt9.parent = this;
	this.menuTxt9.setTransform(563.85,64.25);

	this.menuTxt8 = new cjs.Text("View", "13px 'Segoe Pro'", "#494846");
	this.menuTxt8.name = "menuTxt8";
	this.menuTxt8.lineHeight = 20;
	this.menuTxt8.lineWidth = 44;
	this.menuTxt8.parent = this;
	this.menuTxt8.setTransform(507.4,64.25);

	this.menuTxt7 = new cjs.Text("Review", "13px 'Segoe Pro'", "#494846");
	this.menuTxt7.name = "menuTxt7";
	this.menuTxt7.lineHeight = 20;
	this.menuTxt7.lineWidth = 44;
	this.menuTxt7.parent = this;
	this.menuTxt7.setTransform(440.35,64.25);

	this.menuTxt6 = new cjs.Text("Data", "13px 'Segoe Pro'", "#494846");
	this.menuTxt6.name = "menuTxt6";
	this.menuTxt6.lineHeight = 20;
	this.menuTxt6.lineWidth = 27;
	this.menuTxt6.parent = this;
	this.menuTxt6.setTransform(384.3,64.25);

	this.menuTxt5 = new cjs.Text("Formulas", "13px 'Segoe Pro'", "#494846");
	this.menuTxt5.name = "menuTxt5";
	this.menuTxt5.lineHeight = 20;
	this.menuTxt5.parent = this;
	this.menuTxt5.setTransform(302.9,64.25);

	this.menuTxt4 = new cjs.Text("Page Layout", "13px 'Segoe Pro'", "#494846");
	this.menuTxt4.name = "menuTxt4";
	this.menuTxt4.lineHeight = 20;
	this.menuTxt4.parent = this;
	this.menuTxt4.setTransform(201.05,64.25);

	this.menuTxt3 = new cjs.Text("Insert", "13px 'Segoe Pro'", "#494846");
	this.menuTxt3.name = "menuTxt3";
	this.menuTxt3.lineHeight = 20;
	this.menuTxt3.parent = this;
	this.menuTxt3.setTransform(138.2,64.25);

	this.menuTxt2 = new cjs.Text("Home", "13px 'Segoe Pro'", "#494846");
	this.menuTxt2.name = "menuTxt2";
	this.menuTxt2.lineHeight = 20;
	this.menuTxt2.parent = this;
	this.menuTxt2.setTransform(73.85,64.25);

	this.menuTxt1 = new cjs.Text("File", "13px 'Segoe Pro'", "#494846");
	this.menuTxt1.name = "menuTxt1";
	this.menuTxt1.lineHeight = 20;
	this.menuTxt1.parent = this;
	this.menuTxt1.setTransform(20.45,63.9);

	this.topTxt2 = new cjs.Text("On", "11px 'Segoe Pro'", "#257147");
	this.topTxt2.name = "topTxt2";
	this.topTxt2.lineHeight = 17;
	this.topTxt2.parent = this;
	this.topTxt2.setTransform(85.15,22.2);

	this.txt1 = new cjs.Text("AutoSave", "13px 'Segoe Pro'", "#FFFFFF");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 20;
	this.txt1.parent = this;
	this.txt1.setTransform(21.2,21.45);

	this.otxt4 = new cjs.Text("100%", "12px 'Segoe Pro'", "#505050");
	this.otxt4.name = "otxt4";
	this.otxt4.lineHeight = 18;
	this.otxt4.parent = this;
	this.otxt4.setTransform(1330,720.6);

	this.otxt1 = new cjs.Text("Ready", "12px 'Segoe Pro'", "#505050");
	this.otxt1.name = "otxt1";
	this.otxt1.lineHeight = 19;
	this.otxt1.parent = this;
	this.otxt1.setTransform(8.05,716.15);

	this.otxt2 = new cjs.Text("Type here to search", "15px 'Segoe Pro'");
	this.otxt2.name = "otxt2";
	this.otxt2.lineHeight = 23;
	this.otxt2.parent = this;
	this.otxt2.setTransform(87.95,753.2);

	this.otxt6 = new cjs.Text("4/1/2019", "12px 'Segoe Pro'", "#FFFFFF");
	this.otxt6.name = "otxt6";
	this.otxt6.lineHeight = 19;
	this.otxt6.parent = this;
	this.otxt6.setTransform(1263.45,762.35);

	this.otxt5 = new cjs.Text("10:10 AM", "12px 'Segoe Pro'", "#FFFFFF");
	this.otxt5.name = "otxt5";
	this.otxt5.lineHeight = 19;
	this.otxt5.parent = this;
	this.otxt5.setTransform(1262.5,746.4);

	this.otxt3 = new cjs.Text("Display Settings", "12px 'Segoe Pro'", "#505050");
	this.otxt3.name = "otxt3";
	this.otxt3.lineHeight = 18;
	this.otxt3.parent = this;
	this.otxt3.setTransform(978.2,721.35);

	this.celltxt39 = new cjs.Text("Fitness", "16px 'Segoe Pro'", "#257247");
	this.celltxt39.name = "celltxt39";
	this.celltxt39.lineHeight = 25;
	this.celltxt39.parent = this;
	this.celltxt39.setTransform(120.55,685.4);

	this.topTxt4 = new cjs.Text("Daniella Duarte", "12px 'Segoe Pro'", "#FFFFFF");
	this.topTxt4.name = "topTxt4";
	this.topTxt4.lineHeight = 19;
	this.topTxt4.parent = this;
	this.topTxt4.setTransform(1089.7,22.4);

	this.txt3 = new cjs.Text("Fitness Vision – Saved to OneDrive", "13px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 20;
	this.txt3.parent = this;
	this.txt3.setTransform(577.45,20.7);

	this.menuTxt12 = new cjs.Text("Comments", "13px 'Segoe Pro'", "#257247");
	this.menuTxt12.name = "menuTxt12";
	this.menuTxt12.lineHeight = 19;
	this.menuTxt12.parent = this;
	this.menuTxt12.setTransform(1276.6,63.55);

	this.menuTxt11 = new cjs.Text("Share", "13px 'Segoe Pro'", "#257247");
	this.menuTxt11.name = "menuTxt11";
	this.menuTxt11.lineHeight = 19;
	this.menuTxt11.parent = this;
	this.menuTxt11.setTransform(1199.2,63.55);

	var maskedShapeInstanceList = [this.celltxt18,this.celltxt19,this.celltxt20,this.celltxt21,this.celltxt22,this.celltxt23,this.celltxt24,this.celltxt25,this.celltxt26,this.celltxt27,this.celltxt28,this.celltxt29,this.celltxt30,this.celltxt31,this.celltxt32,this.celltxt33,this.celltxt34,this.celltxt35,this.celltxt36,this.celltxt37,this.celltxt38,this.celltxt1,this.celltxt2,this.celltxt3,this.celltxt4,this.celltxt5,this.celltxt6,this.celltxt7,this.celltxt8,this.celltxt9,this.celltxt10,this.celltxt11,this.celltxt12,this.celltxt13,this.celltxt14,this.celltxt16,this.celltxt15,this.celltxt17,this.menuTxt10,this.menuTxt9,this.menuTxt8,this.menuTxt7,this.menuTxt6,this.menuTxt5,this.menuTxt4,this.menuTxt3,this.menuTxt2,this.menuTxt1,this.topTxt2,this.txt1,this.otxt4,this.otxt1,this.otxt2,this.otxt6,this.otxt5,this.otxt3,this.celltxt39,this.topTxt4,this.txt3,this.menuTxt12,this.menuTxt11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.menuTxt11},{t:this.menuTxt12},{t:this.txt3},{t:this.topTxt4},{t:this.celltxt39},{t:this.otxt3},{t:this.otxt5},{t:this.otxt6},{t:this.otxt2},{t:this.otxt1},{t:this.otxt4},{t:this.txt1},{t:this.topTxt2},{t:this.menuTxt1},{t:this.menuTxt2},{t:this.menuTxt3},{t:this.menuTxt4},{t:this.menuTxt5},{t:this.menuTxt6},{t:this.menuTxt7},{t:this.menuTxt8},{t:this.menuTxt9},{t:this.menuTxt10},{t:this.celltxt17},{t:this.celltxt15},{t:this.celltxt16},{t:this.celltxt14},{t:this.celltxt13},{t:this.celltxt12},{t:this.celltxt11},{t:this.celltxt10},{t:this.celltxt9},{t:this.celltxt8},{t:this.celltxt7},{t:this.celltxt6},{t:this.celltxt5},{t:this.celltxt4},{t:this.celltxt3},{t:this.celltxt2},{t:this.celltxt1},{t:this.celltxt38},{t:this.celltxt37},{t:this.celltxt36},{t:this.celltxt35},{t:this.celltxt34},{t:this.celltxt33},{t:this.celltxt32},{t:this.celltxt31},{t:this.celltxt30},{t:this.celltxt29},{t:this.celltxt28},{t:this.celltxt27},{t:this.celltxt26},{t:this.celltxt25},{t:this.celltxt24},{t:this.celltxt23},{t:this.celltxt22},{t:this.celltxt21},{t:this.celltxt20},{t:this.celltxt19},{t:this.celltxt18}]}).wait(1));

	// Livello_3
	this.instance_27 = new lib.ClipGroup_51_1();
	this.instance_27.parent = this;
	this.instance_27.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_28 = new lib.ClipGroup_1_0();
	this.instance_28.parent = this;
	this.instance_28.setTransform(683,384,1,1,0,0,0,683,384);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgaADIAAgFIA1AAIAAAFg");
	this.shape_9.setTransform(239.425,14.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgagOIA1AAIgbAdg");
	this.shape_10.setTransform(184.525,16.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#51906E").s().p("AgagPIA1AAIgbAfg");
	this.shape_11.setTransform(219.525,16.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgagOIA1AAIgbAdg");
	this.shape_12.setTransform(239.425,18.35);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#257247").s().p("EhqtACoIAAlQMDVbAAAIAAFQg");
	this.shape_13.setTransform(683,16.85);

	this.instance_29 = new lib.ClipGroup_2_0();
	this.instance_29.parent = this;
	this.instance_29.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_30 = new lib.ClipGroup_3_0();
	this.instance_30.parent = this;
	this.instance_30.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_31 = new lib.ClipGroup_4_0();
	this.instance_31.parent = this;
	this.instance_31.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_32 = new lib.ClipGroup_5_0();
	this.instance_32.parent = this;
	this.instance_32.setTransform(683,384,1,1,0,0,0,683,384);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#787878").s().p("AgJAoIAAgeIgeAAIAAgTIAeAAIAAgeIATAAIAAAeIAeAAIAAATIgeAAIAAAeg");
	this.shape_14.setTransform(211.375,687.625);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#787878").s().p("AgRABIAjgjIAABFg");
	this.shape_15.setTransform(633.225,688.25);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ABABAB").s().p("AhKBLIAAiVICVAAIAACVgAhABBICBAAIAAiBIiBAAg");
	this.shape_16.setTransform(633.55,688.25);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhFBGIAAiLICLAAIAACLg");
	this.shape_17.setTransform(633.55,688.25);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ABABAB").s().p("A4wBLIAAiVMAxhAAAIAACVgA4mBBMAxNAAAIAAiBMgxNAAAg");
	this.shape_18.setTransform(799.575,688.25);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("A4rBGIAAiLMAxXAAAIAACLg");
	this.shape_19.setTransform(799.575,688.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#787878").s().p("AgSgiIAlAiIglAjg");
	this.shape_20.setTransform(1328.4,688.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#ABABAB").s().p("AhKBLIAAiVICVAAIAACVgAhABBICBAAIAAiBIiBAAg");
	this.shape_21.setTransform(1328.05,688.25);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhFBGIAAiLICLAAIAACLg");
	this.shape_22.setTransform(1328.05,688.25);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#DBDBDB").s().p("Eg2RABLIAAiVMBsjAAAIAACVg");
	this.shape_23.setTransform(988.15,688.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#B3B2B3").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_24.setTransform(609.75,691.775);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#B3B2B3").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_25.setTransform(609.75,687.775);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#B3B2B3").s().p("AgJAKIAAgTIATAAIAAATg");
	this.shape_26.setTransform(609.75,683.775);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#F3F2F1").s().p("EhqtAB6IAAjyMDVbAAAIAADyg");
	this.shape_27.setTransform(683,714.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#BFBFBF").s().p("EhqtAAFIAAgJMDVbAAAIAAAJg");
	this.shape_28.setTransform(683,702.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#999999").s().p("EhoXAAFIAAgJMDQvAAAIAAAJg");
	this.shape_29.setTransform(668,674.3);

	this.instance_33 = new lib.ClipGroup_6_0();
	this.instance_33.parent = this;
	this.instance_33.setTransform(1299.25,134.3,1,1,0,0,0,0.5,10);

	this.instance_34 = new lib.ClipGroup_7_0();
	this.instance_34.parent = this;
	this.instance_34.setTransform(1224.35,134.3,1,1,0,0,0,0.5,10);

	this.instance_35 = new lib.ClipGroup_8_0();
	this.instance_35.parent = this;
	this.instance_35.setTransform(1149.4,134.3,1,1,0,0,0,0.5,10);

	this.instance_36 = new lib.ClipGroup_9_0();
	this.instance_36.parent = this;
	this.instance_36.setTransform(1074.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_37 = new lib.ClipGroup_10_0();
	this.instance_37.parent = this;
	this.instance_37.setTransform(999.4,134.3,1,1,0,0,0,0.5,10);

	this.instance_38 = new lib.ClipGroup_11_0();
	this.instance_38.parent = this;
	this.instance_38.setTransform(924.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_39 = new lib.ClipGroup_12_0();
	this.instance_39.parent = this;
	this.instance_39.setTransform(849.45,134.3,1,1,0,0,0,0.5,10);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D1D2D2").s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape_30.setTransform(774.5,134.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D1D2D2").s().p("AgEBkIAAjHIAJAAIAADHg");
	this.shape_31.setTransform(699.5,134.3);

	this.instance_40 = new lib.ClipGroup_13_0();
	this.instance_40.parent = this;
	this.instance_40.setTransform(624.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_41 = new lib.ClipGroup_14_0();
	this.instance_41.parent = this;
	this.instance_41.setTransform(549.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_42 = new lib.ClipGroup_15_0();
	this.instance_42.parent = this;
	this.instance_42.setTransform(475.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_43 = new lib.ClipGroup_16_0();
	this.instance_43.parent = this;
	this.instance_43.setTransform(400.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_44 = new lib.ClipGroup_17_0_1();
	this.instance_44.parent = this;
	this.instance_44.setTransform(325.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_45 = new lib.ClipGroup_18_0_1();
	this.instance_45.parent = this;
	this.instance_45.setTransform(250.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_46 = new lib.ClipGroup_19_0_1();
	this.instance_46.parent = this;
	this.instance_46.setTransform(175.45,134.3,1,1,0,0,0,0.5,10);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#B4B4B4").s().p("Ag7A8IB3h3IAAB3g");
	this.shape_32.setTransform(16,135.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#999999").s().p("EhmbAAFIAAgJMDM3AAAIAAAJg");
	this.shape_33.setTransform(680.625,144.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#E6E6E6").s().p("EhqtACLIAAkVMDVbAAAIAAEVg");
	this.shape_34.setTransform(683,688.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#999999").s().p("EgAEAq1MAAAhVpIAJAAMAAABVpg");
	this.shape_35.setTransform(25.5,418.4);

	this.instance_47 = new lib.ClipGroup_20_0_1();
	this.instance_47.parent = this;
	this.instance_47.setTransform(12.5,669.8,1,1,0,0,0,12.5,0.5);

	this.instance_48 = new lib.ClipGroup_21_1();
	this.instance_48.parent = this;
	this.instance_48.setTransform(12.5,644.8,1,1,0,0,0,12.5,0.5);

	this.instance_49 = new lib.ClipGroup_22_1();
	this.instance_49.parent = this;
	this.instance_49.setTransform(12.5,619.8,1,1,0,0,0,12.5,0.5);

	this.instance_50 = new lib.ClipGroup_23();
	this.instance_50.parent = this;
	this.instance_50.setTransform(12.5,594.8,1,1,0,0,0,12.5,0.5);

	this.instance_51 = new lib.ClipGroup_24_1();
	this.instance_51.parent = this;
	this.instance_51.setTransform(12.5,569.8,1,1,0,0,0,12.5,0.5);

	this.instance_52 = new lib.ClipGroup_25();
	this.instance_52.parent = this;
	this.instance_52.setTransform(12.5,544.8,1,1,0,0,0,12.5,0.5);

	this.instance_53 = new lib.ClipGroup_26_1();
	this.instance_53.parent = this;
	this.instance_53.setTransform(12.5,519.8,1,1,0,0,0,12.5,0.5);

	this.instance_54 = new lib.ClipGroup_27_1();
	this.instance_54.parent = this;
	this.instance_54.setTransform(12.5,494.8,1,1,0,0,0,12.5,0.5);

	this.instance_55 = new lib.ClipGroup_28();
	this.instance_55.parent = this;
	this.instance_55.setTransform(12.5,469.8,1,1,0,0,0,12.5,0.5);

	this.instance_56 = new lib.ClipGroup_29_1();
	this.instance_56.parent = this;
	this.instance_56.setTransform(12.5,444.8,1,1,0,0,0,12.5,0.5);

	this.instance_57 = new lib.ClipGroup_30();
	this.instance_57.parent = this;
	this.instance_57.setTransform(12.5,419.8,1,1,0,0,0,12.5,0.5);

	this.instance_58 = new lib.ClipGroup_31_1();
	this.instance_58.parent = this;
	this.instance_58.setTransform(12.5,394.8,1,1,0,0,0,12.5,0.5);

	this.instance_59 = new lib.ClipGroup_32_1();
	this.instance_59.parent = this;
	this.instance_59.setTransform(12.5,369.8,1,1,0,0,0,12.5,0.5);

	this.instance_60 = new lib.ClipGroup_33();
	this.instance_60.parent = this;
	this.instance_60.setTransform(12.5,344.8,1,1,0,0,0,12.5,0.5);

	this.instance_61 = new lib.ClipGroup_34();
	this.instance_61.parent = this;
	this.instance_61.setTransform(12.5,319.8,1,1,0,0,0,12.5,0.5);

	this.instance_62 = new lib.ClipGroup_35_1();
	this.instance_62.parent = this;
	this.instance_62.setTransform(12.5,294.8,1,1,0,0,0,12.5,0.5);

	this.instance_63 = new lib.ClipGroup_36_1();
	this.instance_63.parent = this;
	this.instance_63.setTransform(12.5,269.8,1,1,0,0,0,12.5,0.5);

	this.instance_64 = new lib.ClipGroup_37();
	this.instance_64.parent = this;
	this.instance_64.setTransform(12.5,244.8,1,1,0,0,0,12.5,0.5);

	this.instance_65 = new lib.ClipGroup_38_1();
	this.instance_65.parent = this;
	this.instance_65.setTransform(12.5,219.8,1,1,0,0,0,12.5,0.5);

	this.instance_66 = new lib.ClipGroup_39_1();
	this.instance_66.parent = this;
	this.instance_66.setTransform(12.5,194.85,1,1,0,0,0,12.5,0.5);

	this.instance_67 = new lib.ClipGroup_40_1();
	this.instance_67.parent = this;
	this.instance_67.setTransform(12.5,169.8,1,1,0,0,0,12.5,0.5);

	this.instance_68 = new lib.ClipGroup_41();
	this.instance_68.parent = this;
	this.instance_68.setTransform(12.5,144.8,1,1,0,0,0,12.5,0.5);

	this.instance_69 = new lib.ClipGroup_42_1();
	this.instance_69.parent = this;
	this.instance_69.setTransform(100.45,134.3,1,1,0,0,0,0.5,10);

	this.instance_70 = new lib.ClipGroup_43();
	this.instance_70.parent = this;
	this.instance_70.setTransform(25.45,134.3,1,1,0,0,0,0.5,10);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#999999").s().p("EgAEAqkMAAAhVHIAJAAMAAABVHg");
	this.shape_36.setTransform(1335.8,417.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Ehm0AqDMAAAhUFMDNpAAAMAAABUFg");
	this.shape_37.setTransform(680.1452,410.4573,0.9954,0.9861);

	this.instance_71 = new lib.ClipGroup_44();
	this.instance_71.parent = this;
	this.instance_71.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_72 = new lib.ClipGroup_45();
	this.instance_72.parent = this;
	this.instance_72.setTransform(458.75,741,1,1,0,0,0,5.8,2.5);

	this.instance_73 = new lib.ClipGroup_46();
	this.instance_73.parent = this;
	this.instance_73.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_74 = new lib.ClipGroup_47_1();
	this.instance_74.parent = this;
	this.instance_74.setTransform(683,384,1,1,0,0,0,683,384);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#707070").s().p("AgEDIIAAmPIAJAAIAAGPg");
	this.shape_38.setTransform(1362.5,748);

	this.instance_75 = new lib.ClipGroup_48();
	this.instance_75.parent = this;
	this.instance_75.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_76 = new lib.ClipGroup_49_1();
	this.instance_76.parent = this;
	this.instance_76.setTransform(683,384,1,1,0,0,0,683,384);

	this.instance_77 = new lib.ClipGroup_50_1();
	this.instance_77.parent = this;
	this.instance_77.setTransform(683,384,1,1,0,0,0,683,384);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#E6E6E6").s().p("EhqtA8AMAAAh3/MDVbAAAMAAAB3/g");
	this.shape_39.setTransform(683,384);

	var maskedShapeInstanceList = [this.instance_27,this.instance_28,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.instance_29,this.instance_30,this.instance_31,this.instance_32,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.instance_33,this.instance_34,this.instance_35,this.instance_36,this.instance_37,this.instance_38,this.instance_39,this.shape_30,this.shape_31,this.instance_40,this.instance_41,this.instance_42,this.instance_43,this.instance_44,this.instance_45,this.instance_46,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.instance_47,this.instance_48,this.instance_49,this.instance_50,this.instance_51,this.instance_52,this.instance_53,this.instance_54,this.instance_55,this.instance_56,this.instance_57,this.instance_58,this.instance_59,this.instance_60,this.instance_61,this.instance_62,this.instance_63,this.instance_64,this.instance_65,this.instance_66,this.instance_67,this.instance_68,this.instance_69,this.instance_70,this.shape_36,this.shape_37,this.instance_71,this.instance_72,this.instance_73,this.instance_74,this.shape_38,this.instance_75,this.instance_76,this.instance_77,this.shape_39];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_39},{t:this.instance_77},{t:this.instance_76},{t:this.instance_75},{t:this.shape_38},{t:this.instance_74},{t:this.instance_73},{t:this.instance_72},{t:this.instance_71},{t:this.shape_37},{t:this.shape_36},{t:this.instance_70},{t:this.instance_69},{t:this.instance_68},{t:this.instance_67},{t:this.instance_66},{t:this.instance_65},{t:this.instance_64},{t:this.instance_63},{t:this.instance_62},{t:this.instance_61},{t:this.instance_60},{t:this.instance_59},{t:this.instance_58},{t:this.instance_57},{t:this.instance_56},{t:this.instance_55},{t:this.instance_54},{t:this.instance_53},{t:this.instance_52},{t:this.instance_51},{t:this.instance_50},{t:this.instance_49},{t:this.instance_48},{t:this.instance_47},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.instance_46},{t:this.instance_45},{t:this.instance_44},{t:this.instance_43},{t:this.instance_42},{t:this.instance_41},{t:this.instance_40},{t:this.shape_31},{t:this.shape_30},{t:this.instance_39},{t:this.instance_38},{t:this.instance_37},{t:this.instance_36},{t:this.instance_35},{t:this.instance_34},{t:this.instance_33},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.instance_32},{t:this.instance_31},{t:this.instance_30},{t:this.instance_29},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.instance_28},{t:this.instance_27}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(0,0,1366,768), null);


(lib.devices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.parent = this;
	this.icon.setTransform(68.6,123.65,1.2495,1.2421,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// screen
	this.screen = new lib.screen_new();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(232.4,206.2,0.3809,0.3809,0,0,0,468.8,181.6);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// phone
	this.laptop = new lib.laptop_ai();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(198.85,208,1,1,0,0,0,156.5,106.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// shadow
	this.shadow = new lib.shadow();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(191.05,652.6,0.9366,0.9366,0,0,0,294.2,47.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.devices, new cjs.Rectangle(-84.5,59.3,1026.7,637.8000000000001), null);


(lib.anim_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Devices
	this.phone = new lib.devices();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(145.15,60.05,1,1,0,0,0,177.7,196.5);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

}).prototype = getMCSymbolPrototype(lib.anim_blue, new cjs.Rectangle(-117,-77.2,1026.6,637.8000000000001), null);


(lib.excel_layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.excel = new lib.ClipGroup_15();
	this.excel.name = "excel";
	this.excel.parent = this;
	this.excel.setTransform(591.9,332.7,0.8667,0.8667,0,0,0,683,383.9);

	this.timeline.addTween(cjs.Tween.get(this.excel).wait(1));

}).prototype = getMCSymbolPrototype(lib.excel_layout, new cjs.Rectangle(0,0,1183.9,676.5), null);


(lib.Excel_UI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// graphs
	this.graphs = new lib.graphs();
	this.graphs.name = "graphs";
	this.graphs.parent = this;
	this.graphs.setTransform(486.85,158.65,1.0889,1.0889,0,0,0,468.7,181.3);

	this.timeline.addTween(cjs.Tween.get(this.graphs).wait(1));

	// software
	this.instance = new lib.excel_layout();
	this.instance.parent = this;
	this.instance.setTransform(483.1,144.15,1,1,0,0,0,591.9,332.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Excel_UI, new cjs.Rectangle(-108.8,-188.6,1183.8999999999999,676.4), null);


(lib.phonecache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.parent = this;
	this.icon.setTransform(-13.75,-36.7,0.474,0.4712,0,0,0,-0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// Camera
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0D0D0D").s().p("AgKAMQgFgFAAgHQAAgGAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAGQAAAGgFAGQgFAEgGAAQgFAAgFgEg");
	this.shape.setTransform(92.5554,-37.5179,0.2931,0.2931);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D6E6E").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_1.setTransform(92.5554,-37.5179,0.2931,0.2931);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgPgPQANAAAIAKQAKAIAAAN");
	this.shape_2.setTransform(93.0244,-37.9869,0.2931,0.2931);

	this.instance = new lib.Path_3_0();
	this.instance.parent = this;
	this.instance.setTransform(93.2,-38,0.2936,0.2936,0,0,0,2.6,1.6);
	this.instance.alpha = 0.25;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#272C2E").s().p("AgeAfQgNgNAAgSQAAgRANgNQANgNARAAQASAAANANQANANAAARQAAASgNANQgNANgSAAQgRAAgNgNg");
	this.shape_3.setTransform(92.5554,-37.5179,0.2931,0.2931);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0D0D0D").s().p("AgFAGQgCgDgBgDQABgDACgCQACgDADAAQAEAAACADQACACABADQgBADgCADQgCACgEAAQgDAAgCgCg");
	this.shape_4.setTransform(86.9128,-37.5179,0.2931,0.2931);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D6E6E").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_5.setTransform(86.9128,-37.5179,0.2931,0.2931);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgIgHQAHAAAEAFQAFADAAAH");
	this.shape_6.setTransform(87.162,-37.7597,0.2931,0.2931);

	this.instance_1 = new lib.Path_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(87.35,-37.75,0.2936,0.2936,0,0,0,1.9,0.8);
	this.instance_1.alpha = 0.25;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#272C2E").s().p("AgPAQQgHgGAAgKQAAgIAHgHQAHgHAIAAQAKAAAGAHQAHAHAAAIQAAAKgHAGQgGAHgKAAQgIAAgHgHg");
	this.shape_7.setTransform(86.9128,-37.5179,0.2931,0.2931);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.screen = new lib.Excel_UI();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(95.55,34,0.1837,0.1837,0,0,0,468.9,181.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// Screen
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0D0D0D").s().p("AwoKjQgZAAgSgSQgTgSAAgaIAAzMQAAgZASgRQARgRAZAAMAhOAAAQAcAAATATQAUAUAAAbIAATBQAAAcgUATQgSATgcAAgAw0phIAAS8QAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAMAhsAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAgBAAAAIAAy8IgBgBMghsAAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_8.setTransform(97.1,27.25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6D7680").s().p("Eg4pAkWQhpAAhLhLQhLhKAAhpMAAAhA5QAAhlBIhHQBIhIBkAAMBxPAAAQBvAABQBPQBPBPAABwMAAABARQAABvhPBPQhPBOhuAAgEg5+AghMB0MAAAMAAAhBZMh0MAAAg");
	this.shape_9.setTransform(97.2824,27.2505,0.2937,0.2937);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Keyboard
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ACB6BF").s().p("AjOAjQgFAAgBgGIgFgYQgBgEgBAAIgDgFIgEgaQgCgFAGAAIGsABQAFAAABAGIAFAXIACAFQACAAABAFIAFAZQACAGgGAAg");
	this.shape_10.setTransform(181.3952,106.4941,0.2926,0.2926);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#ACB6BF").s().p("AjMAiQgGAAgCgFIgRg5QgCgGAGAAIGrABQAGAAACAFIAUA5QACAGgGAAg");
	this.shape_11.setTransform(195.0002,106.4575,0.2926,0.2926);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#ACB6BF").s().p("AjOAiQgGAAgBgGIgMg4IAAgEQAAgBABAAQAAAAAAAAQABgBAAAAQABAAABAAIGrABQAGAAABAGIANA4QACAGgGAAg");
	this.shape_12.setTransform(167.7004,106.4575,0.2926,0.2926);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#ACB6BF").s().p("AjSAiQgGAAgBgFIgJg5QgBgFAFAAIGsAAQAGAAABAFIAOA5QACAFgGAAg");
	this.shape_13.setTransform(154.1252,106.4429,0.2926,0.2926);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ACB6BF").s().p("AjSAiQgFAAgBgFIgHg5QgBgFAGAAIGvAAQAGAAAAAFIAFA5QAAAFgFAAg");
	this.shape_14.setTransform(140.4109,106.4429,0.2926,0.2926);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ACB6BF").s().p("A11AiQgEAAAAgFIAGg5QABgFAFAAMArcAAAQAFAAABAFIAGA5QgBAFgFAAg");
	this.shape_15.setTransform(92.307,106.4429,0.2926,0.2926);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ACB6BF").s().p("AjsAiQgFAAABgFIAOg5QABgFAFAAIHJAAQAGAAgBAFIgJA5QAAAFgGAAg");
	this.shape_16.setTransform(43.6521,106.4429,0.2926,0.2926);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ACB6BF").s().p("AjtAiQgGAAABgFIAOg5QACgFAFAAIHMAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgOA5QgCAFgFAAg");
	this.shape_17.setTransform(29.1516,106.4429,0.2926,0.2926);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ACB6BF").s().p("AjvAiQgGAAABgFIAOg5QACgFAFAAIHPAAQABAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgUA5QgBAFgGAAg");
	this.shape_18.setTransform(14.7059,106.4429,0.2926,0.2926);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#ACB6BF").s().p("AkAAiQgFAAABgFIARg5QABgFAGAAIHtAAQAGAAgCAFIgUA5QgCAFgFAAg");
	this.shape_19.setTransform(-0.3672,106.4429,0.2926,0.2926);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#63717F").s().p("AjRArQgFAAgCgFIgSg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBQABAAAAgBQAAAAABAAQAAgBABAAQABAAAAAAIGsABQAFAAACAFIAUA5IAAADIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAAAQAAABgBABQAAAAgBAAQAAABAAAAQgBAAgBAAg");
	this.shape_20.setTransform(195.2835,107.0056,0.2931,0.2931);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#63717F").s().p("AjUAsQgFAAgCgFIgFgaQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQgEgBgBgEIgFgYQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAAAIABgBIAAgBIABgBIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABgBAAAAIGsABQAFAAABAGIAGAaQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAIAAAAQAEACABAEIAGAYIAAADIAAAAIAAAGIABABIAAAFIAAAAIAAADQAAAFgEgBg");
	this.shape_21.setTransform(181.6258,107.0202,0.2931,0.2931);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#63717F").s().p("AjVAsQgGAAgBgFIgNg2IAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBQABgEADAAIGsABQAGAAABAGIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIANA1QABAGgGAAg");
	this.shape_22.setTransform(168.0437,107.0276,0.2931,0.2931);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#63717F").s().p("AjXAuQgFAAgBgGIgKg4IAAgDIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBQABgDADAAIGsAAQAGAAABAFIAOA5IABABIAAAMIAAAAIAAAMQABAEgFAAg");
	this.shape_23.setTransform(154.3625,107.0642,0.2931,0.2931);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#63717F").s().p("AjYAsQgGAAAAgFIgHg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAABAAIGvAAQAGAAAAAFIAAACIABAAIAAAEIAAAAIAAADIABAAIAAAFIAAAAIAAADIABAAIAAADIAEA5QAAAFgFAAg");
	this.shape_24.setTransform(140.6053,107.0056,0.2931,0.2931);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#63717F").s().p("A17AsQgFAAAAgFIAHg5IAAgBIAAAAIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQABgFAFAAMArcAAAQAEAAACAFIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAFA5QABAFgGAAg");
	this.shape_25.setTransform(92.5355,107.0202,0.2931,0.2931);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#63717F").s().p("AjxAsQgFAAABgFIAAAAIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIAOg4QABgGAGAAIHIAAQAEAAABAEIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIgIA5QgBAFgFAAg");
	this.shape_26.setTransform(43.7851,107.0202,0.2931,0.2931);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#63717F").s().p("Aj4AsQgGAAABgFIAOg5IAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgFAFAAIHMAAQABAAAAABQABAAAAAAQABAAAAABQAAAAAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAAAIAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAADIgOA5QgBAFgFAAg");
	this.shape_27.setTransform(29.3293,107.0202,0.2931,0.2931);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#63717F").s().p("Aj9AsQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBIAAgBIgBAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgEIAQg4QABgGAGAAIHtAAQABAAABABQAAAAABAAQAAAAAAABQABAAAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgTA5QgCAFgFAAg");
	this.shape_28.setTransform(-0.2175,107.0202,0.2931,0.2931);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#63717F").s().p("Aj5AsQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAIAAgEIANg5IABgCIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBQACgEAEAAIHPAAQABAAABABQAAAAABAAQAAAAABABQAAAAAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgUA5QgCAFgFAAg");
	this.shape_29.setTransform(14.6926,107.0202,0.2931,0.2931);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#ACB6BF").s().p("Ap0AcQgGgBgBgFIgGgrQgBgGAFABITpAAQAFgBACAGIAPArQACAFgGABg");
	this.shape_30.setTransform(182.3223,104.5192,0.2926,0.2926);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#ACB6BF").s().p("AjYAcQgGgBgBgFIgGgrQgBgGAGABIG2AAQAGgBABAGIAJArQABAFgGABg");
	this.shape_31.setTransform(156.4536,104.5192,0.2926,0.2926);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#ACB6BF").s().p("AjcAbQgGABAAgGIgCgrQgBgFAGgBIG6AAQAFABABAFIAFArQAAAGgFgBg");
	this.shape_32.setTransform(142.3493,104.4753,0.2926,0.2926);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#ACB6BF").s().p("AjeAcQgFgBAAgFIAAgrQAAgGAFABIG4AAQAGgBAAAGIAEArQAAAFgFABg");
	this.shape_33.setTransform(128.3007,104.5192,0.2926,0.2926);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGgBIG6AAQAFABABAFIADArQAAAFgGAAg");
	this.shape_34.setTransform(114.4035,104.5777,0.2926,0.2926);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIACgrQAAgFAGgBIG6AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_35.setTransform(100.3308,104.5777,0.2926,0.2926);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIADgrQAAgFAGgBIG5AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_36.setTransform(86.3803,104.5777,0.2926,0.2926);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#ACB6BF").s().p("AjgAbQgGAAABgFIAGgrQAAgFAGgBIG6AAQAFABAAAFIgEArQAAAFgGAAg");
	this.shape_37.setTransform(72.2123,104.5777,0.2926,0.2926);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGgBIG6AAQAGABgBAFIgGArQAAAFgGAAg");
	this.shape_38.setTransform(58.261,104.5777,0.2926,0.2926);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ACB6BF").s().p("AjiAbQgFAAAAgFIAHgrQABgFAFgBIG9AAQAGABgBAFIgKArQgBAFgFAAg");
	this.shape_39.setTransform(44.2813,104.5777,0.2926,0.2926);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#ACB6BF").s().p("AjkAbQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAIgBgEIAMgrQACgFAFgBIG5AAQABABABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAgBABIgLArQgCAFgFAAg");
	this.shape_40.setTransform(30.1827,104.5777,0.2926,0.2926);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#ACB6BF").s().p("AoFAbQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIAQgsQADgFAFgBIP2AAQAGABgCAFIgMArQgBAFgGAAg");
	this.shape_41.setTransform(7.8463,104.5777,0.2926,0.2926);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#63717F").s().p("Ap6ApQgFAAgBgFIgHgrIAAgDIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAITpAAQAFAAABAFIAJArIAHADIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAQgBABAAABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_42.setTransform(182.551,105.1956,0.2931,0.2931);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#63717F").s().p("AjdApQgFAAgBgFIgGgrIAAgDIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBQABgDADAAIG3AAQAFAAACAFIAJArIgBADIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABQgBADgEAAg");
	this.shape_43.setTransform(156.6611,105.1956,0.2931,0.2931);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgBQABgFAEAAIG6AAQAEAAACAFIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAEArQABAGgFAAg");
	this.shape_44.setTransform(142.6814,105.1956,0.2931,0.2931);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBQABgEAEAAIG3AAQAFAAABAFIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIAEAqQABAGgGAAg");
	this.shape_45.setTransform(128.5382,105.2469,0.2931,0.2931);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIABABIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAAAIABACIACAqQAAAGgFAAg");
	this.shape_46.setTransform(114.6494,105.2469,0.2931,0.2931);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIACgsIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAAAIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAgBIABAAIAAgCQACgEADAAIG6AAQAFAAABAEIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAACIAAAqQAAAGgGAAg");
	this.shape_47.setTransform(100.5723,105.2469,0.2931,0.2931);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAAAIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAFAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIAAAqQAAAGgGAAg");
	this.shape_48.setTransform(86.5831,105.2469,0.2931,0.2931);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#63717F").s().p("AjoApQgEAAAAgFIAFgrIABgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBQACgEAEAAIG6AAQADAAACAEIAAAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAACIABAAIAAACIAAAAIAAACIABACIgEArQAAAFgFAAg");
	this.shape_49.setTransform(72.3594,105.2469,0.2931,0.2931);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#63717F").s().p("AjnApQgFAAABgFIAFgrIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAFAAIG6AAQAEAAABAEIAAABIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABACIgGArQgBAFgFAAg");
	this.shape_50.setTransform(58.3899,105.2469,0.2931,0.2931);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBQABgEAFAAIG9AAQAEAAABAEIAAABIAAAAIAAACIABAAIAAADIAAABIAAACIABAAIAAABIAAABIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAADIgJArQgBAFgGAAg");
	this.shape_51.setTransform(44.3788,105.2469,0.2931,0.2931);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#63717F").s().p("AjfApQgFAAAAgDIAAgBIAAAAIAAgBIgBgBIAAAAIAAgBIAAgBIgBgBIAAgBIAAgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIgBgBIAAgDIAMgrQACgFAFAAIG6AAQADAAAAAEIABAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIAAAAIAAADIgLArQgBAFgGAAg");
	this.shape_52.setTransform(30.399,105.2469,0.2931,0.2931);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#63717F").s().p("AoCAnQAAAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAgBIAAAAIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAQgrQADgGAFAAIP2AAQAEAAAAADIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAADIgNArQgBAGgGAAg");
	this.shape_53.setTransform(7.9972,105.1809,0.2931,0.2931);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#ACB6BF").s().p("Am+AbQgFAAgBgFIgKgrQgBgFAGAAIN4AAQAFAAADAFIAXAsQADAEgGAAg");
	this.shape_54.setTransform(186.8754,102.8442,0.2926,0.2926);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#ACB6BF").s().p("AjYAbQgGAAgBgFIgGgrQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIG2AAQAGAAABAFIAJArQABAFgGAAg");
	this.shape_55.setTransform(166.1818,102.8442,0.2926,0.2926);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#ACB6BF").s().p("AjYAbQgFAAgBgFIgHgrQgBgFAGAAIG3AAQAFAAABAFIAJArQABAFgGAAg");
	this.shape_56.setTransform(152.2937,102.8442,0.2926,0.2926);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#ACB6BF").s().p("AjcAbQgGAAAAgFIgDgrQAAgFAGAAIG5AAQAGAAABAFIAEArQABAFgGAAg");
	this.shape_57.setTransform(138.3453,102.8442,0.2926,0.2926);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIAAgrQAAgFAFAAIG4AAQAFAAABAFIAEArQAAAFgFAAg");
	this.shape_58.setTransform(124.4314,102.8369,0.2926,0.2926);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGAAIG6AAQAGAAAAAFIADArQAAAFgFAAg");
	this.shape_59.setTransform(110.5269,102.8369,0.2926,0.2926);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIACgrQABgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_60.setTransform(96.5472,102.8369,0.2926,0.2926);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIADgrQAAgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_61.setTransform(82.5424,102.8369,0.2926,0.2926);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGAAIG5AAQAGAAAAAFIgDArQgBAFgGAAg");
	this.shape_62.setTransform(68.6818,102.8369,0.2926,0.2926);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQABgFAFAAIG6AAQAGAAgCAFIgFArQgBAFgFAAg");
	this.shape_63.setTransform(54.653,102.8369,0.2926,0.2926);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#ACB6BF").s().p("AjiAbQgGAAABgFIAHgrQABgFAFAAIG9AAQAGAAgBAFIgKArQgBAFgFAAg");
	this.shape_64.setTransform(40.734,102.8369,0.2926,0.2926);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#ACB6BF").s().p("AjkAbQgFAAABgFIAMgrQACgFAFAAIG5AAQABAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgLArQgCAFgFAAg");
	this.shape_65.setTransform(26.745,102.8369,0.2926,0.2926);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#ACB6BF").s().p("AnAAbQgGAAACgFIAQgsQACgEAGAAINtAAQAAAAABAAQABAAAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgNArQgCAFgFAAg");
	this.shape_66.setTransform(6.4717,102.8369,0.2926,0.2926);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#63717F").s().p("AnDApQgGAAgBgGIgJgqQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBQABgDAEAAIN4AAQAFAAABAGIAbAqQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAABIAAABIgBAAQgBADgDAAg");
	this.shape_67.setTransform(187.153,103.5174,0.2931,0.2931);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#63717F").s().p("AjeApQgEAAgBgGIgHgqQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAgBIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAAAIAAAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAQABgDAEAAIG2AAQAGAAAAAGIAJAqIAAAEIAAAAIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAIgBABIAAABQgBACgDAAg");
	this.shape_68.setTransform(166.378,103.5174,0.2931,0.2931);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#63717F").s().p("AjdApQgFAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABgBQABgDADAAIG3AAQAGAAABAGIAIAqQABABAAAAQAAAAAAABQAAAAAAAAQAAAAgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABQgBADgDAAg");
	this.shape_69.setTransform(152.4914,103.5174,0.2931,0.2931);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#63717F").s().p("AjkArQgFgBAAgFIgDguIABAAIAAgBIAAgBIAAgCIABAAIAAgDIAAAAIAAgCIABgBIAAgBIAAAAIAAgDIABAAIAAgCIAAgBIAAgCIABAAIAAgBIAAgBIAAgCIABgBIAAgCIAAAAIAAgBIABgBQAAgFAFAAIG5AAQAFAAABAFIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIAFArQABAGgGAAg");
	this.shape_70.setTransform(138.6802,103.5614,0.2931,0.2931);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAAAIAAgCIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAgBQACgEADAAIG4AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAADIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAAAIABACIAEAqQAAAGgFAAg");
	this.shape_71.setTransform(124.6595,103.5614,0.2931,0.2931);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#63717F").s().p("AjkApQgFAAgCgFIAAgtIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAAAIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgBIABAAQABgFAEAAIG7AAQAEAAACAFIAAABIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIADAsQAAAFgFAAg");
	this.shape_72.setTransform(110.7729,103.5028,0.2931,0.2931);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#63717F").s().p("AjmApQgFAAAAgFIACgrIABgBIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAEAAIG7AAQAEAAABAFIAAAAIAAAAIAAABIABABIAAABIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIAAABIAAABIABAAIAAAtQAAAFgGAAg");
	this.shape_73.setTransform(96.7764,103.5028,0.2931,0.2931);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#63717F").s().p("AjmApQgGAAABgFIADgsIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBQABgFAEAAIG6AAQAEAAABAFIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAArQAAAFgGAAg");
	this.shape_74.setTransform(82.7411,103.5028,0.2931,0.2931);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#63717F").s().p("AjnApQgGAAABgFIAFgrIABgBIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAFAAIG6AAQAEAAABAEIAAABIAAABIABAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAABIABACIgEArQAAAFgGAAg");
	this.shape_75.setTransform(68.8251,103.5028,0.2931,0.2931);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#63717F").s().p("AjmApQgGAAABgFIAFgrIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQACgFAEAAIG6AAQAEAAABAEIAAABIAAAAIAAABIABABIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABABIAAABIAAAAIAAACIABABIAAACIAAABIAAACIABAAIAAACIgGArQAAAFgGAAg");
	this.shape_76.setTransform(54.77,103.5028,0.2931,0.2931);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIAAgBIABAAIAAgDIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBQACgFAEAAIG9AAQAEAAABAEIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAADIAAACIgJArQgBAFgGAAg");
	this.shape_77.setTransform(40.8319,103.5028,0.2931,0.2931);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#63717F").s().p("AjgApQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgCIAAAAIAAgBIAAgBIAAgCIALgrQACgGAFAAIG5AAQAEAAABAEIAAAAIAAABIABABIAAAAIAAABIAAABIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAADIgLArQgCAFgFAAg");
	this.shape_78.setTransform(26.9549,103.5028,0.2931,0.2931);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#63717F").s().p("Am9AnQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIAAgDIAQgsQACgFAFAAINtAAQABAAABAAQAAABABAAQAAAAABABQAAAAAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIgNArQgBAGgGAAg");
	this.shape_79.setTransform(6.6306,103.4368,0.2931,0.2931);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#ACB6BF").s().p("Aj9AcQgEAAgCgGIgNgrQgCgGAGAAIIIAAQAEABACAEIAPAsQACAGgGAAg");
	this.shape_80.setTransform(191.9424,101.14,0.2926,0.2926);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#ACB6BF").s().p("AjWAcQgGAAgBgGIgKgrQAAgGAFAAIG6AAQAFAAACAGIAJArQABAGgGAAg");
	this.shape_81.setTransform(176.8603,101.14,0.2926,0.2926);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgFAAg");
	this.shape_82.setTransform(162.8754,101.14,0.2926,0.2926);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgGAAg");
	this.shape_83.setTransform(148.8392,101.14,0.2926,0.2926);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#ACB6BF").s().p("AjcAcQgGAAAAgGIgCgrQgBgGAGAAIG6AAQAFAAABAGIAEArQABAGgFAAg");
	this.shape_84.setTransform(134.8252,101.14,0.2926,0.2926);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIAAgrQAAgGAFAAIG4AAQAFAAABAGIAEArQABAGgGAAg");
	this.shape_85.setTransform(120.9226,101.14,0.2926,0.2926);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#ACB6BF").s().p("AjdAcQgGAAAAgGIgBgrQAAgGAGAAIG6AAQAFAAABAGIADArQAAAGgGAAg");
	this.shape_86.setTransform(106.899,101.14,0.2926,0.2926);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAFAAIG7AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_87.setTransform(92.8409,101.14,0.2926,0.2926);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAHAAIG5AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_88.setTransform(78.834,101.14,0.2926,0.2926);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#ACB6BF").s().p("AjgAcQgGAAABgGIAGgrQABgGAFAAIG6AAQAFAAAAAGIgEArQAAAGgFAAg");
	this.shape_89.setTransform(64.8395,101.14,0.2926,0.2926);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#ACB6BF").s().p("AjgAcQgFAAAAgGIAGgrQABgGAFAAIG6AAQAGAAgCAGIgFArQgBAGgFAAg");
	this.shape_90.setTransform(50.8642,101.14,0.2926,0.2926);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ACB6BF").s().p("AjiAcQgGAAACgGIAFgrQABgGAGAAIG9AAQAFAAgBAGIgJArQgBAGgGAAg");
	this.shape_91.setTransform(36.8938,101.14,0.2926,0.2926);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#ACB6BF").s().p("AjjAcQgGAAABgGIAMgrQABgGAGAAIG5AAQAGAAgBAGIgMArQgBAGgGAAg");
	this.shape_92.setTransform(22.9016,101.14,0.2926,0.2926);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#ACB6BF").s().p("AlyAcQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIARgsQACgEAFgBILQAAQABAAABABQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_93.setTransform(4.729,101.14,0.2926,0.2926);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#63717F").s().p("AkAAsQgHAAAAgGIgOgrIAAgDIABgBIAAgBIAAAAIAAgCIABAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBQABgEAEAAIIIAAQAEAAACAFIAPAsQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAABIAAABIgBABIAAABIAAABIAAABIgBABIAAABIAAABIAAABQgBADgDAAg");
	this.shape_94.setTransform(192.2313,101.8833,0.2931,0.2931);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#63717F").s().p("AjbApQgGAAgBgFIgJgrQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBQABgDAEAAIG6AAQAFAAACAGIAIAqIAAADIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAQgBADgEAAg");
	this.shape_95.setTransform(177.0989,101.8027,0.2931,0.2931);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#63717F").s().p("AjdApQgGAAgBgGIgHgqIABgDIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQAAgDAEAAIG3AAQAGAAABAGIAJAqIgBAEIAAAAIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBABIAAAAIAAABIAAABIAAAAIAAABIgBAAIAAAAIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABQAAAAgBABQAAAAAAAAQgBABgBAAQAAAAgBAAg");
	this.shape_96.setTransform(163.0658,101.8027,0.2931,0.2931);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#63717F").s().p("AjcApQgGAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQABgDAEAAIG3AAQAFAAABAGIAIAqIAAAEIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABQAAADgEAAg");
	this.shape_97.setTransform(149.0252,101.8027,0.2931,0.2931);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAAAQAAgFAFAAIG6AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAEArQABAGgGAAg");
	this.shape_98.setTransform(135.148,101.854,0.2931,0.2931);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#63717F").s().p("AjnArQgGAAAAgFIAAgrIABgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBQABgDAEAAIG4AAQAEAAACAEIAAACIAAABIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAABIAAABIABAAIAEAsQABAFgGAAg");
	this.shape_99.setTransform(121.1442,101.8613,0.2931,0.2931);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIG7AAQAEAAABAEIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIACAqQAAAGgFAAg");
	this.shape_100.setTransform(107.1309,101.8027,0.2931,0.2931);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#63717F").s().p("AjmApQgGAAABgGIACgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAAsQAAAGgGAAg");
	this.shape_101.setTransform(93.059,101.8027,0.2931,0.2931);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAAsQAAAGgGAAg");
	this.shape_102.setTransform(79.0205,101.8027,0.2931,0.2931);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#63717F").s().p("AjoApQgFAAABgGIAFgqIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG6AAQADAAACADIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAABIABAAIAAACIAAABIAAACIgDAqQgBAGgFAAg");
	this.shape_103.setTransform(64.9778,101.8027,0.2931,0.2931);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#63717F").s().p("AjmApQgGAAABgGIAFgqIABgCIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCQACgEAEAAIG6AAQAEAAABADIAAABIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAADIgGAqQAAAGgGAAg");
	this.shape_104.setTransform(50.9741,101.8027,0.2931,0.2931);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#63717F").s().p("AjoApQgGAAABgGIAHgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgDIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCQABgEAFAAIG9AAQAEAAABADIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAADIgJArQgBAFgGAAg");
	this.shape_105.setTransform(36.9775,101.8027,0.2931,0.2931);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#63717F").s().p("AjfApQgEAAgBgDIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgDIAMgqQABgGAGAAIG5AAQAEAAABADIAAABIAAAAIAAACIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAAAIAAACQAAABABAAQAAAAAAAAQAAABAAAAQgBAAAAABIgLArQgBAFgGAAg");
	this.shape_106.setTransform(23.1076,101.8027,0.2931,0.2931);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#63717F").s().p("AluAnQgBAAgBAAQgBgBAAAAQgBAAAAgBQAAAAgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgDIAQgsQACgFAGAAILQAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_107.setTransform(4.8828,101.7367,0.2931,0.2931);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#ACB6BF").s().p("AoJAbQgFAAgBgFIgIgrQgBgFAGAAIQXAAQAGAAABAFIALArQABABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_108.setTransform(183.2463,99.2158,0.292,0.292);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#63717F").s().p("AoNApQgFAAgBgFIgHgrQAAgBgBAAQAAAAAAAAQAAgBAAAAQABAAAAAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBQAAgEAEAAIQYAAQAFAAACAFIALAsIAAADIgBAAIAAABIAAAAIAAABIgBABIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAABQgBADgEAAg");
	this.shape_109.setTransform(183.509,99.8819,0.2926,0.2926);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#ACB6BF").s().p("AjOAbQgFAAgBgFIgHgrQgBgFAFAAIGnAAQAFAAABAFIAHArQAAAFgFAAg");
	this.shape_110.setTransform(160.7401,99.2158,0.292,0.292);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#63717F").s().p("AjQApQgGAAgBgFIgHgrQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgDIABAAIAAgDIABAAIAAgCIAAgBIAAgDIABAAIAAgDIAAAAIAAgCIABAAIAAgEIAAAAIAAgCIABgBIAAgCIAAgBIAAAAQABgEADAAIGnAAQAFAAABAGIAHAqIAAADIAAABIgBABIAAACIAAABIAAADIgBABIAAACIAAAAIAAACIgBABIAAADIAAABIAAACIgBAAIAAACIgBACIAAACIAAABQAAADgEAAg");
	this.shape_111.setTransform(161.0175,99.8819,0.2926,0.2926);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_112.setTransform(147.4117,99.2158,0.292,0.292);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#63717F").s().p("AjSApQgFAAgBgFIgGgrIAAgCIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAEAAIGmAAQAGAAABAGIAEAqIAAADIAAABIAAAAIgBABIAAABIAAABIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBABIAAAAIAAABIAAABIgBABIAAABIAAAAIAAADIgBAAIAAACQgBADgEAAg");
	this.shape_113.setTransform(147.625,99.8819,0.2926,0.2926);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_114.setTransform(134.1831,99.2158,0.292,0.292);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#63717F").s().p("AjTAmQgFAAgBgFIgFgrIAAgDIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAGAAABAFIAEArIAAACIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABQgBADgEAAg");
	this.shape_115.setTransform(134.3715,99.8015,0.2926,0.2926);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#ACB6BF").s().p("AjRAbQgFAAAAgFIgDgrQgBgFAGAAIGnAAQAFAAAAAFIACArQAAAFgFAAg");
	this.shape_116.setTransform(120.7624,99.2158,0.292,0.292);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#63717F").s().p("AjXAmQgGAAAAgFIgCguIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAFAAABAEIAAABIABABIAAACIAAAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIADAtQAAAFgGAAg");
	this.shape_117.setTransform(120.979,99.8015,0.2926,0.2926);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#ACB6BF").s().p("AjRAbQgFAAgBgFIgCgrQAAgFAFAAIGpAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_118.setTransform(107.441,99.2158,0.292,0.292);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#63717F").s().p("AjVApQgGAAAAgFIgDgrIABgBIAAgDIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIGpAAQAFAAAAAGIAAADIABAAIAAAFIAAAAIAAAFIABAAIAAAFIAAABIAAADIABABIAAAvQAAAFgGAAg");
	this.shape_119.setTransform(107.6304,99.8819,0.2926,0.2926);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#ACB6BF").s().p("AjSAbQgGAAABgFIACgrQAAgFAGAAIGiAAQAGAAAAAFIAAArQAAAFgGAAg");
	this.shape_120.setTransform(94.1007,99.2158,0.292,0.292);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#63717F").s().p("AjZApQgFAAAAgFIADgtIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIABAAIAAgBQABgFAEAAIGjAAQAFAAAAAFIAAABIABABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAADIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIAAAAIAAADIABABIAAArQAAAFgGAAg");
	this.shape_121.setTransform(94.2965,99.8819,0.2926,0.2926);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#ACB6BF").s().p("AjUAbQgFAAAAgFIACgrQABgFAFAAIGmAAQAFAAAAAFIgDArQAAAFgGAAg");
	this.shape_122.setTransform(80.8085,99.2158,0.292,0.292);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#63717F").s().p("AjaApQgGAAAAgFIACgrIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgFAEAAIGnAAQAEAAABAFIAAABIAAABIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAABIAAAEIABAAIAAADIAAAAIAAAEIABABIgDArQgBAFgFAAg");
	this.shape_123.setTransform(80.9332,99.8819,0.2926,0.2926);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#ACB6BF").s().p("AjVAbQgFAAABgFIADgrQABgFAGAAIGlAAQAFAAgBAFIgDArQgBAFgFAAg");
	this.shape_124.setTransform(67.4703,99.2158,0.292,0.292);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#63717F").s().p("AjdApQgGAAABgFIAEgrIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBQACgFAEAAIGlAAQAEAAABAEIAAAAIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAACIgEArQAAAFgGAAg");
	this.shape_125.setTransform(67.6923,99.8819,0.2926,0.2926);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#ACB6BF").s().p("AjVAbQgGAAABgFIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_126.setTransform(54.0882,99.2158,0.292,0.292);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#63717F").s().p("AjeApQgHAAACgFIAIgrIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAAAQACgFAEAAIGhAAQAEAAABAEIAAAAIABABIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABACIgFArQAAAFgGAAg");
	this.shape_127.setTransform(54.2438,99.8819,0.2926,0.2926);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#ACB6BF").s().p("AjVAbQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_128.setTransform(40.787,99.2158,0.292,0.292);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#63717F").s().p("AjRApQgDAAgCgDIAAgBIAAAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAIgrQACgFAFAAIGhAAQADAAACAEIAAABIABAAIAAACIAAAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAADIgFArQgBAFgEAAg");
	this.shape_129.setTransform(41.0191,99.8819,0.2926,0.2926);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#ACB6BF").s().p("AjYAbQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAMgrQACgFAFAAIGhAAQAGAAgBAFIgJArQgCAFgFAAg");
	this.shape_130.setTransform(27.4557,99.2158,0.292,0.292);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#63717F").s().p("AjUApQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBIAAAAIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAAAIAAgDIAMgsQABgFAGAAIGhAAQAEAAAAADIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIgJArQgBAFgFAAg");
	this.shape_131.setTransform(27.6815,99.8819,0.2926,0.2926);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#ACB6BF").s().p("AjaAbQgFAAACgFIAPgrQABgFAGAAIGhAAQAGAAgCAFIgLArQgCAFgFAAg");
	this.shape_132.setTransform(14.1831,99.2158,0.292,0.292);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#63717F").s().p("AjYApQgDAAgBgDIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgDIgBAAIAAgEIAAAAIAAgCIgBgBIAAAAIABgCIAPgsQABgFAGAAIGhAAQAEAAABAEIAAADIAAAAIAAACIABABIAAADIAAAAIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAAAIAAADIABAAIAAAEIgMArQgBAFgGAAg");
	this.shape_133.setTransform(14.3146,99.8819,0.2926,0.2926);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#ACB6BF").s().p("AjYAbQgFAAABgFIAQgrQACgFAGAAIGdAAQAFAAgBAFIgNArQgBAFgGAAg");
	this.shape_134.setTransform(0.7989,99.2158,0.292,0.292);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#63717F").s().p("AjSApQAAAAgBAAQgBAAAAgBQAAAAgBAAQAAgBAAgBIgBAAIAAAAIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAAAIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIAAgDIAQgsQABgFAGAAIGeAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAEIgNArQgCAFgFAAg");
	this.shape_135.setTransform(1.0355,99.8819,0.2926,0.2926);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#ACB6BF").s().p("AjpAQQgFAAABgFIAHgVQACgFAFAAIHIAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_136.setTransform(1.8834,97.4654,0.2915,0.2915);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#63717F").s().p("AjiAfQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAAAIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAAAIAAgCIAHgXQACgFAFAAIHIAAQADAAABADIAAAAIABAAIAAABIAAAAIAAABIABABIAAAAIABACIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABABIAAABIABAAIAAABIAAAAIAAABIABACIAAABIABAAIAAABIAAAAIAAABIABAAIAAAAIABABIAAABIAAAAIAAABIABAAIAAABIABACIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAQABABAAAAQAAABAAAAQAAAAAAABQAAAAAAABIgEAVQgBAGgFAAg");
	this.shape_137.setTransform(2.1507,98.1572,0.292,0.292);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#ACB6BF").s().p("AjjAQQgFAAgCgFIgFgVQgBgFAFAAIHPAAQAFAAACAFIAFAVQAAABAAAAQABABAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAg");
	this.shape_138.setTransform(191.0678,97.4654,0.2915,0.2915);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#63717F").s().p("AjpAhQgFAAgCgGIgFgWIAAgDIAAgBIABAAIAAgBIAAAAIAAAAIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAIHPAAQAFAAACAGIAGAWIAAADIgBAAIAAABIgBAAIAAAAIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABQgBADgDAAg");
	this.shape_139.setTransform(191.288,98.2083,0.292,0.292);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHPAAQAFAAABAFIADAVQABAFgFAAg");
	this.shape_140.setTransform(176.4618,97.4654,0.2915,0.2915);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#63717F").s().p("AjqAhQgFAAgBgGIgEgWIAAgCIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAQAAgEAEAAIHPAAQAFAAABAGIAEAVIAAADIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAAAQgCAEgDAAg");
	this.shape_141.setTransform(176.6868,98.2083,0.292,0.292);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHOAAQAGAAABAFIADAVQABAFgFAAg");
	this.shape_142.setTransform(161.9464,97.4654,0.2915,0.2915);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#63717F").s().p("AjqAfQgFAAgBgFIgDgWQgBgBAAAAQAAAAAAAAQAAAAAAgBQAAAAABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgDADAAIHPAAQAFAAABAFIAEAWIAAACIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABQgBADgEAAg");
	this.shape_143.setTransform(162.1368,98.1645,0.292,0.292);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAFAAIHPAAQAGAAABAFIADAVQABAFgGAAg");
	this.shape_144.setTransform(147.4161,97.4654,0.2915,0.2915);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#63717F").s().p("AjrAfQgFAAgBgFIgEgWIABgDIAAgBIAAAAIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBQAAAAAAgBQABAAAAgBQABAAAAAAQABAAABAAIHPAAQAFAAABAFIAEAWIAAAeQAAAEgFAAg");
	this.shape_145.setTransform(147.5503,98.1645,0.292,0.292);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#ACB6BF").s().p("AjnAQQgGAAAAgFIAAgVQAAgFAGAAIHPAAQAFAAAAAFIAAAVQAAAFgFAAg");
	this.shape_146.setTransform(132.8936,97.4654,0.2915,0.2915);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#63717F").s().p("AjtAhQgFAAAAgGIAAgWIAAgCIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAdIAAAAIAAANIAAAAIAAALQgBAGgFAAg");
	this.shape_147.setTransform(133.0148,98.2083,0.292,0.292);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#ACB6BF").s().p("AjnAQQgFAAAAgFIAAgVQAAgFAFAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_148.setTransform(118.3782,97.4654,0.2915,0.2915);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#63717F").s().p("AjuAhQgFAAAAgGIAAgWIAAgCIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAVIAAADIAAAAIgBABIAAAAIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABQgBAEgEAAg");
	this.shape_149.setTransform(118.4502,98.2083,0.292,0.292);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#ACB6BF").s().p("AjnAQQgGAAABgFIAAgVQgBgFAGAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_150.setTransform(103.79,97.4654,0.2915,0.2915);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#63717F").s().p("AjqAeQgGAAAAgFIAAgXIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCQABgEAEgBIHPAAQAGABAAAFIAAAXIgBAAIAAABIAAABIAAACIgBAAIAAABIAAABIAAABIgBABIAAACIAAAAIAAADIgBAAIAAABIAAAAIAAACIgBABIAAACIAAAAIAAACIgBABIAAABIAAAAIAAACIgBAAIAAACQgBAEgEAAg");
	this.shape_151.setTransform(103.9367,98.1426,0.292,0.292);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#ACB6BF").s().p("AjoAQQgGAAABgFIADgVQABgFAFAAIHLAAQAFAAABAFIABAVQAAAFgGAAg");
	this.shape_152.setTransform(89.2068,97.4654,0.2915,0.2915);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#63717F").s().p("Aj0AeQgFAAABgFIADgWIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgEAEgBIHLAAQAEABABADIAAABIABAAIAAABIAAABIAAAAIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABADIABAVQAAAFgFAAg");
	this.shape_153.setTransform(89.4209,98.1426,0.292,0.292);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAGgVQACgFAFAAIHLAAQAFAAAAAFIgCAVQAAAFgGAAg");
	this.shape_154.setTransform(74.6161,97.4654,0.2915,0.2915);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#63717F").s().p("AjyAeQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIAAgEIAGgWIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQACgGAFAAIHKAAQAEABABADIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAABIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIgCAVQAAAFgGAAg");
	this.shape_155.setTransform(74.7393,98.1426,0.292,0.292);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAHgVQABgFAGAAIHKAAQAGAAgBAFIgCAVQAAAFgGAAg");
	this.shape_156.setTransform(60.1028,97.4654,0.2915,0.2915);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#63717F").s().p("AjyAeQgFAAABgFIAHgWIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAQABgGAGAAIHKAAQAFABAAAEIAAABIAAAAIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAABIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIgCAVQgBAFgFAAg");
	this.shape_157.setTransform(60.1819,98.1426,0.292,0.292);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#ACB6BF").s().p("AjrAQQgFAAACgFIAHgVQACgFAGAAIHKAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_158.setTransform(45.5652,97.4654,0.2915,0.2915);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#63717F").s().p("Aj3AeQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAABgBIAIgWIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBQACgEAFgBIHKAAQAEABABADIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAACIgEAWQgBAFgFAAg");
	this.shape_159.setTransform(45.5954,98.1426,0.292,0.292);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#ACB6BF").s().p("AjrAQQgFAAABgFIAIgVQACgFAGAAIHKAAQAFAAAAAFIgEAVQgBAFgFAAg");
	this.shape_160.setTransform(31.07,97.4654,0.2915,0.2915);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#63717F").s().p("AjuAeQgEAAAAgDIAAgdIAIgWQACgGAGAAIHKAAQAEABAAADIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBABAAAAIgDAWQgBAFgFAAg");
	this.shape_161.setTransform(31.2668,98.1426,0.292,0.292);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#ACB6BF").s().p("AjoAQQgGAAACgFIAGgVQACgFAGAAIHHAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIABAEIgEAVQgBAFgFAAg");
	this.shape_162.setTransform(16.5206,97.4654,0.2915,0.2915);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#63717F").s().p("AjnAhQgDAAgBgEIAAgEIgBAAIAAgGIAAAAIAAgFIgBgBIAAgFIAAAAIAAgGIgBAAIAAgEQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAHgXQACgFAFAAIHIAAQAFAAAAAFIAAAEIAAABIAAAFIABABIAAAFIAAAAIAAAFIABAAIAAAGIAAAAIAAAFIgDAWQgBAGgGAAg");
	this.shape_163.setTransform(16.6365,98.2083,0.292,0.292);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Base
	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#CCD1D6").s().p("Eg9IABfIgOgBQgzgFgygPQhSgYglgqIABhmQAGAJAdAJQA7ASB1AAMB8ngABQBegEAIgTIAEApQABAvgKAhQgCAFgFADQgbAQgqAMQhFAUhZAAg");
	this.shape_164.setTransform(97.1602,118.5912,0.2931,0.2931);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#BFC5CC").s().p("Eg9/AF6QhygEgrgXQgVgMACgLID9qLQAMgeBbgOQAtgHArgBITOAAUBeOgAEACqAAEQBrADArAeQAWAQAAAOIDwKCQALAdhBANIhEAGg");
	this.shape_165.setTransform(97.1278,106.1922,0.2931,0.2931);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_165},{t:this.shape_164}]}).wait(1));

	// white screen
	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("AxNJ2IAAzqMAibAAAIAATqg");
	this.shape_166.setTransform(97.675,28);

	this.timeline.addTween(cjs.Tween.get(this.shape_166).wait(1));

	// Shadow
	this.instance_2 = new lib.Bitmap3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-28.8,91.3,0.7644,0.7644);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.phonecache, new cjs.Rectangle(-38.2,-61.1,266.3,191.4), null);


(lib.phonenew = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop.cache(-260,-190,520,380,1.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Livello_1
	this.laptop = new lib.phonecache();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(22.6,43.9,1,1,0,0,0,67.5,43.9);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.phonenew, new cjs.Rectangle(-83.1,-61.1,266.29999999999995,191.4), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(284.45,1.35,0.3475,0.3475,0,0,180,-2.8,-4.5);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(43.85,194,0.3479,0.3479);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(226.85,560.4,1,1,0,0,0,6,4.9);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(130.25,569.8,1.3794,1.3789,0,0,0,5.3,4.7);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// phone
	this.anim_1 = new lib.anim_blue();
	this.anim_1.name = "anim_1";
	this.anim_1.parent = this;
	this.anim_1.setTransform(69.4,239.85,0.5186,0.5186,0,0,0,12.8,12.8);

	this.timeline.addTween(cjs.Tween.get(this.anim_1).wait(1));

	// laptop
	this.laptop = new lib.phonenew();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(171.4,359.6,1.2899,1.2899,0,0,0,23,42.4);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(66.2,39.35,1.1275,1.1275,0,0,0,0.4,0.8);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#ECEDEF","#FFFFFF"],[0,1],5.6,300.8,5.8,177.3).s().p("EgXMAv+MAAAhf7MAuZAAAMAAABf7g");
	this.shape.setTransform(148.525,295);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-21.3,-12,555.6999999999999,614), null);


// stage content:
(lib.O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var phone = mc.anim_1.phone
		
		mc.cta.alpha=0
		mc.anim_1.alpha=0
		mc.replay_btn.alpha=0
		
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.anim_1.alpha=1
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
			
				
				exportRoot.tl1.from(phone, 2, {x: "+=300", ease:Power3.easeOut}, "+=0");
		
				//Manage your finance
				exportRoot.tl1.from(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.3");
				exportRoot.tl1.from(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.1");
				
				exportRoot.tl1.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.5");
				exportRoot.tl1.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				exportRoot.tl1.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				
				//year-round
				exportRoot.tl1.from(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
				exportRoot.tl1.from(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
				
				exportRoot.tl1.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=.5");
				exportRoot.tl1.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				
				//with
				exportRoot.tl1.from(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
				
				exportRoot.tl1.to(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.4");
				
				//budject-tracking
				exportRoot.tl1.from(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
				exportRoot.tl1.from(exportRoot.headline8, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
				
				exportRoot.tl1.to(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.55");
				exportRoot.tl1.to(exportRoot.headline8, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				
				//templates
				exportRoot.tl1.from(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0");
				
				exportRoot.tl1.to(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.3");
				//in Excel
				
				exportRoot.tl1.from(exportRoot.headline10, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
				exportRoot.tl1.from(exportRoot.headline11, 0.01, {alpha: 0, ease:Power4.easeOut, onStart: function(){phone.screen.graphs.gotoAndPlay(1);}}, "+=0.2");
				
				
				exportRoot.tl1.to(exportRoot.headline10, 0.5, {alpha: 0, ease:Power4.easeIn}, "+=1.5");
				exportRoot.tl1.to(exportRoot.headline11, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
				
			
				
				//devices.gotoAndStop(1);
				
				exportRoot.tl1.to(phone, 1.75, {x:"-=150", y:"+=180", scaleX: 0.445, scaleY: 0.445,  ease:Power3.easeInOut}, "-=0.5");
				exportRoot.tl1.to(phone.icon, 0.75, {alpha:0,  ease:Power3.easeInOut}, "-=1");
				exportRoot.tl1.from(mc.laptop, 1, {x:"+=300", ease:Power3.easeOut}, "-=0.7");
				
				
				
				
				for (var i = 0; i < exportRoot.headline12.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.8");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline13.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline13[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline13[i], 0.8, { x: "+=300", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=0.6");	
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=150",	ease:Power4.easeOut}, "-=0.6");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=150", ease:Power4.easeOut}, "-=0.7");
			
				exportRoot.tl1.stop();	
		
			
			mc.logo_intro.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(128.7,288,405.7,314);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574942346506", id:"O365_NewYearCampaign_USA_300x600_BAN_Excel_Budgeting_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;