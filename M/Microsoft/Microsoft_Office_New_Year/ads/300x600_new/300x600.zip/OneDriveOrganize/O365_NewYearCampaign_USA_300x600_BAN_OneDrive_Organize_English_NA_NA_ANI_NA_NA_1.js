(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[251,253,83,90],[369,348,99,140],[251,348,116,121],[365,0,135,214],[0,253,249,361],[365,216,113,130],[0,0,363,251]]}
];


// symbols:



(lib.Icon_OneDrive = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.image_dog = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.image_family = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.image_landscape = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Image_snowman = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.image_snowshoes = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.laptop_300x250 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgvvAFoIAArPMBfeAAAIAALPg");
	mask.setTransform(305.55,36);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AhlB3QgngpAAhNQAAhGArguQAqgtA/AAQA/gBAjApQAjApAABIIAAAaIjSAAQACArAZAXQAZAYArAAQAxgBApgdIAAA4QgpAahGABQhDgBgngqgAgrhXQgVAXgFAiICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape.setTransform(491.425,42.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AhNB3QgrgrAAhEQAAhMAuguQAugvBKABQArgBAgAQIAABBQgggZglAAQgsAAgcAeQgcAfAAAvQAAAwAbAcQAZAbAtAAQAmAAAhgaIAAA8QglAWgyAAQhFgBgpgqg");
	this.shape_1.setTransform(463.425,42.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgjDiIAAkzIBFAAIAAEzgAgdidQgMgMAAgRQAAgQAMgMQANgLAQAAQARAAANALQAMAMAAAQQAAAQgMAMQgNAMgRAAQgRAAgMgLg");
	this.shape_2.setTransform(443.825,34.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgyAAAAA6IAAApIBHAAIAAA3IhHAAIAAD9g");
	this.shape_3.setTransform(427.325,34.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgzAAAAA6IAAApIBIAAIAAA3IhHAAIAAD9g");
	this.shape_4.setTransform(407.975,34.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AiWCjQg4g9gBhhQABhnA5g+QA5g+BiAAQBaAAA4A8QA4A8gBBiQAABog4A+Qg5A9heAAQheAAg4g8gAhehzQglAtAABHQAABIAkAsQAkAsA7AAQA9AAAkgqQAkgqAAhLQgBhMgigrQgjgqg9AAQg7AAglAsg");
	this.shape_5.setTransform(375.9,35.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_6.setTransform(54.875,54.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_7.setTransform(17.1,54.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(54.875,17.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(17.1,17.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_10.setTransform(215.625,34.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_11.setTransform(598.35,36.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_12.setTransform(567.8,36.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_13.setTransform(536.525,36.05);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,611.1,72), null);


(lib.laptop_phone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.laptop_300x250();
	this.instance.parent = this;
	this.instance.setTransform(-181.5,-125.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_phone, new cjs.Rectangle(-181.5,-125.5,363,251), null);


(lib.img_snowshoes_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_snowshoes();
	this.instance.parent = this;
	this.instance.setTransform(-113,-130,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_snowshoes_in, new cjs.Rectangle(-113,-130,226,260), null);


(lib.img_snowman_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_snowman();
	this.instance.parent = this;
	this.instance.setTransform(-249,-361,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_snowman_in, new cjs.Rectangle(-249,-361,498,722), null);


(lib.img_family_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_family();
	this.instance.parent = this;
	this.instance.setTransform(-116,-121,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_family_in, new cjs.Rectangle(-116,-121,232,242), null);


(lib.img_dog_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_dog();
	this.instance.parent = this;
	this.instance.setTransform(-99,-140,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_dog_in, new cjs.Rectangle(-99,-140,198,280), null);


(lib.image_landscape_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_landscape();
	this.instance.parent = this;
	this.instance.setTransform(-135,-214,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.image_landscape_in, new cjs.Rectangle(-135,-214,270,428), null);


(lib.Icon_OneDrive_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon_OneDrive();
	this.instance.parent = this;
	this.instance.setTransform(-83,-90,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Icon_OneDrive_in, new cjs.Rectangle(-83,-90,166,180), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bg_fade_cache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","rgba(246,246,246,0)","rgba(246,246,246,0)","#FFFFFF"],[0.051,0.227,0.4,0.596],0.2,299.8,-0.2,-299.9).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_fade_cache, new cjs.Rectangle(0,0,300,600), null);


(lib.bg_cache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F6F6F6","#EBEBEB"],[0.055,0.984],-1,-21,0,-1,-21,122.4).s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150.0023,299.9992,1,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_cache, new cjs.Rectangle(0,0,300,600), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.image_landscape_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween4, new cjs.Rectangle(-135,-214,270,428), null);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_snowshoes_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween3, new cjs.Rectangle(-113,-130,226,260), null);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_dog_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween2, new cjs.Rectangle(-99,-140,198,280), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_family_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween1, new cjs.Rectangle(-116,-121,232,242), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.photo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_snowman_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.photo_1, new cjs.Rectangle(-249,-361,498,722), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(51.3,0.35,0.33,0.33,0,0,0,307,34.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-11,202.1,24.1), null);


(lib.Icon_OneDrive_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon_OneDrive_in();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Icon_OneDrive_1, new cjs.Rectangle(-83,-90,166,180), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance_1 = new lib.ms();
	this.instance_1.parent = this;
	this.instance_1.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_1}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_1, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.Devices_Isometric = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_108 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(108).call(this.frame_108).wait(1));

	// image_family.png
	this.img_family = new lib.Tween1();
	this.img_family.name = "img_family";
	this.img_family.parent = this;
	this.img_family.setTransform(167.75,60.95,0.28,0.28,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.img_family).wait(1).to({regX:0,regY:0,x:167.6949,y:60.9084},0).wait(3).to({regX:0.2,regY:0.2,x:167.75,y:60.95},0).wait(1).to({regX:0,regY:0,scaleX:0.2798,scaleY:0.2798,x:167.5983,y:60.8491},0).wait(1).to({scaleX:0.2796,scaleY:0.2796,x:167.5239,y:60.8036},0).wait(1).to({scaleX:0.2793,scaleY:0.2793,x:167.4082,y:60.7333},0).wait(1).to({scaleX:0.279,scaleY:0.279,x:167.2829,y:60.6577},0).wait(1).to({scaleX:0.2786,scaleY:0.2786,x:167.1301,y:60.5662},0).wait(1).to({scaleX:0.2782,scaleY:0.2782,x:166.9574,y:60.4638},0).wait(1).to({scaleX:0.2777,scaleY:0.2777,x:166.759,y:60.3475},0).wait(1).to({scaleX:0.2771,scaleY:0.2771,x:166.5359,y:60.2184},0).wait(1).to({scaleX:0.2765,scaleY:0.2765,x:166.2853,y:60.0757},0).wait(1).to({scaleX:0.2758,scaleY:0.2758,x:166.0062,y:59.9196},0).wait(1).to({scaleX:0.275,scaleY:0.275,x:165.6963,y:59.7498},0).wait(1).to({scaleX:0.2742,scaleY:0.2742,x:165.3536,y:59.5667},0).wait(1).to({scaleX:0.2732,scaleY:0.2732,x:164.9756,y:59.3704},0).wait(1).to({scaleX:0.2722,scaleY:0.2722,x:164.5593,y:59.1616},0).wait(1).to({scaleX:0.2711,scaleY:0.2711,x:164.1013,y:58.9413},0).wait(1).to({scaleX:0.2699,scaleY:0.2699,x:163.5979,y:58.711},0).wait(1).to({scaleX:0.2686,scaleY:0.2686,x:163.0442,y:58.4729},0).wait(1).to({scaleX:0.2673,scaleY:0.2673,x:162.4344,y:58.2308},0).wait(1).to({scaleX:0.2658,scaleY:0.2658,x:161.7614,y:57.9899},0).wait(1).to({scaleX:0.2642,scaleY:0.2642,x:161.0164,y:57.7589},0).wait(1).to({scaleX:0.2624,scaleY:0.2624,x:160.1876,y:57.5514},0).wait(1).to({scaleX:0.2606,scaleY:0.2606,x:159.255,y:57.3899},0).wait(1).to({scaleX:0.2586,scaleY:0.2586,x:158.2073,y:57.3169},0).wait(1).to({scaleX:0.2565,scaleY:0.2565,x:157.0224,y:57.4089},0).wait(1).to({scaleX:0.2543,scaleY:0.2543,x:155.7023,y:57.8097},0).wait(1).to({scaleX:0.2519,scaleY:0.2519,x:154.3378,y:58.738},0).wait(1).to({scaleX:0.2493,scaleY:0.2493,x:153.1742,y:60.2989},0).wait(1).to({scaleX:0.2466,scaleY:0.2466,x:152.4108,y:62.2155},0).wait(1).to({scaleX:0.2437,scaleY:0.2437,x:152.0084,y:64.2612},0).wait(1).to({scaleX:0.2406,scaleY:0.2406,x:151.7775,y:68.1137},0).wait(1).to({scaleX:0.2374,scaleY:0.2374,x:151.9125,y:72.2475},0).wait(1).to({scaleX:0.2339,scaleY:0.2339,x:152.2059,y:75.7579},0).wait(1).to({scaleX:0.2303,scaleY:0.2303,x:152.5547,y:78.8268},0).wait(1).to({scaleX:0.2265,scaleY:0.2265,x:152.9456,y:81.7308},0).wait(1).to({scaleX:0.2225,scaleY:0.2225,x:153.3768,y:84.5878},0).wait(1).to({scaleX:0.2184,scaleY:0.2184,x:153.8439,y:87.4292},0).wait(1).to({scaleX:0.2141,scaleY:0.2141,x:154.29,y:90.0905},0).wait(1).to({scaleX:0.2097,scaleY:0.2097,x:154.5907,y:91.9029},0).wait(1).to({scaleX:0.2052,scaleY:0.2052,x:154.9496,y:94.0919},0).wait(1).to({scaleX:0.2006,scaleY:0.2006,x:155.2895,y:96.195},0).wait(1).to({scaleX:0.1961,scaleY:0.1961,x:155.6322,y:98.3523},0).wait(1).to({scaleX:0.1915,scaleY:0.1915,x:155.964,y:100.4854},0).wait(1).to({scaleX:0.1871,scaleY:0.1871,x:156.2838,y:102.5961},0).wait(1).to({scaleX:0.1827,scaleY:0.1827,x:156.5861,y:104.6592},0).wait(1).to({scaleX:0.1785,scaleY:0.1785,x:156.8677,y:106.669},0).wait(1).to({scaleX:0.1745,scaleY:0.1745,x:157.1222,y:108.6038},0).wait(1).to({scaleX:0.1708,scaleY:0.1708,x:157.3441,y:110.4655},0).wait(1).to({scaleX:0.1672,scaleY:0.1672,x:157.5209,y:112.2478},0).wait(1).to({scaleX:0.1639,scaleY:0.1639,x:157.6169,y:113.9441},0).wait(1).to({scaleX:0.1609,scaleY:0.1609,x:157.5761,y:115.8696},0).wait(1).to({scaleX:0.1581,scaleY:0.1581,x:157.5041,y:116.7253},0).wait(1).to({scaleX:0.1555,scaleY:0.1555,x:157.3205,y:117.9408},0).wait(1).to({scaleX:0.1532,scaleY:0.1532,x:157.08,y:118.9036},0).wait(1).to({scaleX:0.1511,scaleY:0.1511,x:156.7135,y:119.8524},0).wait(1).to({scaleX:0.1493,scaleY:0.1493,x:156.197,y:120.6958},0).wait(1).to({scaleX:0.1476,scaleY:0.1476,x:155.4451,y:121.405},0).wait(1).to({scaleX:0.1461,scaleY:0.1461,x:154.3994,y:121.8467},0).wait(1).to({scaleX:0.1448,scaleY:0.1448,x:153.1838,y:121.9056},0).wait(1).to({scaleX:0.1437,scaleY:0.1437,x:152.1053,y:121.6984},0).wait(1).to({scaleX:0.1428,scaleY:0.1428,x:151.2988,y:121.4287},0).wait(1).to({scaleX:0.142,scaleY:0.142,x:150.7098,y:121.1818},0).wait(1).to({scaleX:0.1414,scaleY:0.1414,x:150.2702,y:120.9739},0).wait(1).to({scaleX:0.1408,scaleY:0.1408,x:149.9419,y:120.8064},0).wait(1).to({scaleX:0.1405,scaleY:0.1405,x:149.7039,y:120.6791},0).wait(1).to({scaleX:0.1402,scaleY:0.1402,x:149.5434,y:120.5904},0).wait(1).to({scaleX:0.14,scaleY:0.14,x:149.4515,y:120.5388},0).wait(1).to({regX:-1.4,regY:-1.1,x:149.45,y:120.55},0).to({x:149.15},1).wait(37));

	// image_landscape.png
	this.img_landscape = new lib.Tween4();
	this.img_landscape.name = "img_landscape";
	this.img_landscape.parent = this;
	this.img_landscape.setTransform(121.25,198,0.28,0.28,0,0,0,1.1,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.img_landscape).wait(1).to({regX:0,regY:0,x:120.9491,y:198.0514},0).wait(3).to({regX:1.1,regY:-0.2,x:121.25,y:198},0).wait(1).to({regX:0,regY:0,scaleX:0.2797,scaleY:0.2797,x:120.8547,y:197.9889},0).wait(1).to({scaleX:0.2793,scaleY:0.2793,x:120.7755,y:197.9363},0).wait(1).to({scaleX:0.2789,scaleY:0.2789,x:120.658,y:197.8578},0).wait(1).to({scaleX:0.2783,scaleY:0.2783,x:120.5263,y:197.7694},0).wait(1).to({scaleX:0.2776,scaleY:0.2776,x:120.3675,y:197.6622},0).wait(1).to({scaleX:0.2769,scaleY:0.2769,x:120.1864,y:197.539},0).wait(1).to({scaleX:0.276,scaleY:0.276,x:119.9792,y:197.397},0).wait(1).to({scaleX:0.275,scaleY:0.275,x:119.746,y:197.2356},0).wait(1).to({scaleX:0.2739,scaleY:0.2739,x:119.4853,y:197.0531},0).wait(1).to({scaleX:0.2726,scaleY:0.2726,x:119.1961,y:196.8481},0).wait(1).to({scaleX:0.2712,scaleY:0.2712,x:118.8769,y:196.6187},0).wait(1).to({scaleX:0.2697,scaleY:0.2697,x:118.5268,y:196.3628},0).wait(1).to({scaleX:0.268,scaleY:0.268,x:118.1443,y:196.0779},0).wait(1).to({scaleX:0.2662,scaleY:0.2662,x:117.7282,y:195.7613},0).wait(1).to({scaleX:0.2642,scaleY:0.2642,x:117.2774,y:195.4096},0).wait(1).to({scaleX:0.262,scaleY:0.262,x:116.7906,y:195.0189},0).wait(1).to({scaleX:0.2596,scaleY:0.2596,x:116.2672,y:194.5844},0).wait(1).to({scaleX:0.257,scaleY:0.257,x:115.7064,y:194.1005},0).wait(1).to({scaleX:0.2543,scaleY:0.2543,x:115.1083,y:193.5601},0).wait(1).to({scaleX:0.2513,scaleY:0.2513,x:114.4738,y:192.9542},0).wait(1).to({scaleX:0.2481,scaleY:0.2481,x:113.8056,y:192.2713},0).wait(1).to({scaleX:0.2446,scaleY:0.2446,x:113.1089,y:191.4964},0).wait(1).to({scaleX:0.2409,scaleY:0.2409,x:112.3912,y:190.6054},0).wait(1).to({scaleX:0.2369,scaleY:0.2369,x:111.6752,y:189.5735},0).wait(1).to({scaleX:0.2326,scaleY:0.2326,x:110.9986,y:188.3607},0).wait(1).to({scaleX:0.228,scaleY:0.228,x:110.4342,y:186.9067},0).wait(1).to({scaleX:0.2231,scaleY:0.2231,x:110.1346,y:185.1545},0).wait(1).to({scaleX:0.2179,scaleY:0.2179,x:110.3564,y:183.0971},0).wait(1).to({scaleX:0.2123,scaleY:0.2123,x:111.3265,y:180.9282},0).wait(1).to({scaleX:0.2065,scaleY:0.2065,x:112.9399,y:178.982},0).wait(1).to({scaleX:0.2003,scaleY:0.2003,x:116.1365,y:176.467},0).wait(1).to({scaleX:0.1937,scaleY:0.1937,x:120.1478,y:174.116},0).wait(1).to({scaleX:0.1869,scaleY:0.1869,x:123.7476,y:172.352},0).wait(1).to({scaleX:0.1799,scaleY:0.1799,x:126.943,y:170.9501},0).wait(1).to({scaleX:0.1726,scaleY:0.1726,x:129.9639,y:169.7252},0).wait(1).to({scaleX:0.1652,scaleY:0.1652,x:132.8948,y:168.6055},0).wait(1).to({scaleX:0.1578,scaleY:0.1578,x:136.1613,y:167.3727},0).wait(1).to({scaleX:0.1503,scaleY:0.1503,x:140.0095,y:165.9257},0).wait(1).to({scaleX:0.143,scaleY:0.143,x:143.3072,y:164.6886},0).wait(1).to({scaleX:0.1359,scaleY:0.1359,x:146.1182,y:163.6179},0).wait(1).to({scaleX:0.129,scaleY:0.129,x:148.3757,y:162.6857},0).wait(1).to({scaleX:0.1225,scaleY:0.1225,x:150.242,y:161.8553},0).wait(1).to({scaleX:0.1164,scaleY:0.1164,x:152.0599,y:160.9707},0).wait(1).to({scaleX:0.1108,scaleY:0.1108,x:153.7557,y:160.0405},0).wait(1).to({scaleX:0.1055,scaleY:0.1055,x:155.3459,y:159.006},0).wait(1).to({scaleX:0.1008,scaleY:0.1008,x:156.6335,y:157.9455},0).wait(1).to({scaleX:0.0964,scaleY:0.0964,x:157.4401,y:157.0396},0).wait(1).to({scaleX:0.0925,scaleY:0.0925,x:158.0991,y:155.853},0).wait(1).to({scaleX:0.0891,scaleY:0.0891,x:158.3111,y:154.3443},0).wait(1).to({scaleX:0.086,scaleY:0.086,x:157.7005,y:152.5638},0).wait(1).to({scaleX:0.0832,scaleY:0.0832,x:156.4469,y:151.0142},0).wait(1).to({scaleX:0.0809,scaleY:0.0809,x:155.265,y:149.9899},0).wait(1).to({scaleX:0.0788,scaleY:0.0788,x:154.3664,y:149.3346},0).wait(1).to({scaleX:0.0771,scaleY:0.0771,x:153.6708,y:148.8748},0).wait(1).to({scaleX:0.0756,scaleY:0.0756,x:153.1165,y:148.5312},0).wait(1).to({scaleX:0.0745,scaleY:0.0745,x:152.676,y:148.2703},0).wait(1).to({scaleX:0.0735,scaleY:0.0735,x:152.3342,y:148.0743},0).wait(1).to({scaleX:0.0728,scaleY:0.0728,x:152.0805,y:147.9322},0).wait(1).to({scaleX:0.0723,scaleY:0.0723,x:151.9069,y:147.8366},0).wait(1).to({scaleX:0.0721,scaleY:0.0721,x:151.8068,y:147.782},0).wait(1).to({regX:0.7,regY:-0.7,scaleX:0.072,scaleY:0.072,x:151.85,y:147.75},0).wait(44));

	// image_snowman
	this.img_snowman = new lib.photo_1();
	this.img_snowman.name = "img_snowman";
	this.img_snowman.parent = this;
	this.img_snowman.setTransform(251.6,90.85,0.09,0.09,0,0,0,1.7,0.6);

	this.timeline.addTween(cjs.Tween.get(this.img_snowman).wait(1).to({regX:0,regY:0,x:251.4515,y:90.7505},0).wait(3).to({regX:1.7,regY:0.6,x:251.6,y:90.85},0).wait(1).to({regX:0,regY:0,scaleX:0.0899,scaleY:0.0899,x:251.3689,y:90.7001},0).wait(1).to({scaleX:0.0898,scaleY:0.0898,x:251.2874,y:90.6504},0).wait(1).to({scaleX:0.0897,scaleY:0.0897,x:251.1787,y:90.5844},0).wait(1).to({scaleX:0.0896,scaleY:0.0896,x:251.0508,y:90.5071},0).wait(1).to({scaleX:0.0895,scaleY:0.0895,x:250.8996,y:90.4162},0).wait(1).to({scaleX:0.0893,scaleY:0.0893,x:250.7249,y:90.3118},0).wait(1).to({scaleX:0.0891,scaleY:0.0891,x:250.5253,y:90.1933},0).wait(1).to({scaleX:0.0889,scaleY:0.0889,x:250.2994,y:90.0603},0).wait(1).to({scaleX:0.0887,scaleY:0.0887,x:250.0458,y:89.9123},0).wait(1).to({scaleX:0.0884,scaleY:0.0884,x:249.7627,y:89.7488},0).wait(1).to({scaleX:0.0881,scaleY:0.0881,x:249.4484,y:89.5695},0).wait(1).to({scaleX:0.0878,scaleY:0.0878,x:249.1008,y:89.374},0).wait(1).to({scaleX:0.0874,scaleY:0.0874,x:248.7178,y:89.1619},0).wait(1).to({scaleX:0.087,scaleY:0.087,x:248.297,y:88.9329},0).wait(1).to({scaleX:0.0866,scaleY:0.0866,x:247.8355,y:88.6869},0).wait(1).to({scaleX:0.0862,scaleY:0.0862,x:247.3303,y:88.4238},0).wait(1).to({scaleX:0.0857,scaleY:0.0857,x:246.7781,y:88.1437},0).wait(1).to({scaleX:0.0851,scaleY:0.0851,x:246.175,y:87.8472},0).wait(1).to({scaleX:0.0846,scaleY:0.0846,x:245.5167,y:87.535},0).wait(1).to({scaleX:0.0839,scaleY:0.0839,x:244.7983,y:87.2083},0).wait(1).to({scaleX:0.0833,scaleY:0.0833,x:244.0142,y:86.8692},0).wait(1).to({scaleX:0.0825,scaleY:0.0825,x:243.158,y:86.5207},0).wait(1).to({scaleX:0.0818,scaleY:0.0818,x:242.2226,y:86.1671},0).wait(1).to({scaleX:0.0809,scaleY:0.0809,x:241.1988,y:85.8144},0).wait(1).to({scaleX:0.08,scaleY:0.08,x:240.0763,y:85.4715},0).wait(1).to({scaleX:0.0791,scaleY:0.0791,x:238.8464,y:85.1523},0).wait(1).to({scaleX:0.0781,scaleY:0.0781,x:237.4971,y:84.8759},0).wait(1).to({scaleX:0.077,scaleY:0.077,x:236.0137,y:84.6699},0).wait(1).to({scaleX:0.0759,scaleY:0.0759,x:234.3879,y:84.5759},0).wait(1).to({scaleX:0.0746,scaleY:0.0746,x:232.6149,y:84.6527},0).wait(1).to({scaleX:0.0733,scaleY:0.0733,x:230.7081,y:84.9803},0).wait(1).to({scaleX:0.072,scaleY:0.072,x:228.7137,y:85.6513},0).wait(1).to({scaleX:0.0706,scaleY:0.0706,x:226.6377,y:86.8148},0).wait(1).to({scaleX:0.0691,scaleY:0.0691,x:224.2725,y:88.8348},0).wait(1).to({scaleX:0.0675,scaleY:0.0675,x:222.1984,y:91.2814},0).wait(1).to({scaleX:0.066,scaleY:0.066,x:220.5036,y:93.8005},0).wait(1).to({scaleX:0.0643,scaleY:0.0643,x:219.0979,y:96.2797},0).wait(1).to({scaleX:0.0627,scaleY:0.0627,x:217.9186,y:98.6662},0).wait(1).to({scaleX:0.0611,scaleY:0.0611,x:216.9551,y:100.7079},0).wait(1).to({scaleX:0.0595,scaleY:0.0595,x:216.1107,y:102.4886},0).wait(1).to({scaleX:0.0579,scaleY:0.0579,x:215.2371,y:104.3158},0).wait(1).to({scaleX:0.0564,scaleY:0.0564,x:214.3018,y:106.1984},0).wait(1).to({scaleX:0.0549,scaleY:0.0549,x:213.2726,y:108.0113},0).wait(1).to({scaleX:0.0536,scaleY:0.0536,x:212.3081,y:109.4971},0).wait(1).to({scaleX:0.0523,scaleY:0.0523,x:211.2411,y:110.8868},0).wait(1).to({scaleX:0.0511,scaleY:0.0511,x:210.025,y:112.1331},0).wait(1).to({scaleX:0.05,scaleY:0.05,x:208.6821,y:113.1086},0).wait(1).to({scaleX:0.049,scaleY:0.049,x:207.1861,y:113.7819},0).wait(1).to({scaleX:0.0481,scaleY:0.0481,x:205.5508,y:114.1193},0).wait(1).to({scaleX:0.0473,scaleY:0.0473,x:203.9149,y:114.1181},0).wait(1).to({scaleX:0.0466,scaleY:0.0466,x:202.4347,y:113.8738},0).wait(1).to({scaleX:0.0459,scaleY:0.0459,x:201.1884,y:113.5137},0).wait(1).to({scaleX:0.0454,scaleY:0.0454,x:200.1705,y:113.1265},0).wait(1).to({scaleX:0.0449,scaleY:0.0449,x:199.3426,y:112.7552},0).wait(1).to({scaleX:0.0444,scaleY:0.0444,x:198.6682,y:112.4178},0).wait(1).to({scaleX:0.0441,scaleY:0.0441,x:198.1196,y:112.1215},0).wait(1).to({scaleX:0.0438,scaleY:0.0438,x:197.6766,y:111.8684},0).wait(1).to({scaleX:0.0435,scaleY:0.0435,x:197.3244,y:111.6588},0).wait(1).to({scaleX:0.0433,scaleY:0.0433,x:197.0519,y:111.4916},0).wait(1).to({scaleX:0.0432,scaleY:0.0432,x:196.8503,y:111.3652},0).wait(1).to({scaleX:0.0431,scaleY:0.0431,x:196.7126,y:111.2774},0).wait(1).to({scaleX:0.043,scaleY:0.043,x:196.6332,y:111.2264},0).wait(1).to({regX:4.7,regY:3.5,x:196.7,y:111.2},0).to({guide:{path:[196.7,111.2,196.7,111.3,196.7,111.3]}},1).wait(41));

	// image_dog.png
	this.img_dog = new lib.Tween2();
	this.img_dog.name = "img_dog";
	this.img_dog.parent = this;
	this.img_dog.setTransform(49.4,110.65,0.28,0.28,0,0,0,0.2,0.6);

	this.timeline.addTween(cjs.Tween.get(this.img_dog).wait(1).to({regX:0,regY:0,x:49.3628,y:110.4856},0).wait(3).to({regX:0.2,regY:0.6,x:49.4,y:110.65},0).wait(1).to({regX:0,regY:0,scaleX:0.2798,scaleY:0.2798,x:49.2358,y:110.373},0).wait(1).to({scaleX:0.2795,scaleY:0.2795,x:49.1887,y:110.3313},0).wait(1).to({scaleX:0.2792,scaleY:0.2792,x:49.0282,y:110.1886},0).wait(1).to({scaleX:0.2787,scaleY:0.2787,x:48.9318,y:110.1029},0).wait(1).to({scaleX:0.2783,scaleY:0.2783,x:48.7339,y:109.9263},0).wait(1).to({scaleX:0.2777,scaleY:0.2777,x:48.5859,y:109.794},0).wait(1).to({scaleX:0.2771,scaleY:0.2771,x:48.3466,y:109.5792},0).wait(1).to({scaleX:0.2764,scaleY:0.2764,x:48.1444,y:109.3971},0).wait(1).to({scaleX:0.2756,scaleY:0.2756,x:47.8595,y:109.1394},0).wait(1).to({scaleX:0.2747,scaleY:0.2747,x:47.6001,y:108.9036},0).wait(1).to({scaleX:0.2737,scaleY:0.2737,x:47.2655,y:108.5974},0).wait(1).to({scaleX:0.2726,scaleY:0.2726,x:46.9454,y:108.3024},0).wait(1).to({scaleX:0.2714,scaleY:0.2714,x:46.5565,y:107.9407},0).wait(1).to({scaleX:0.2701,scaleY:0.2701,x:46.1708,y:107.5782},0).wait(1).to({scaleX:0.2687,scaleY:0.2687,x:45.722,y:107.1507},0).wait(1).to({scaleX:0.2672,scaleY:0.2672,x:45.2638,y:106.7066},0).wait(1).to({scaleX:0.2655,scaleY:0.2655,x:44.7474,y:106.1944},0).wait(1).to({scaleX:0.2637,scaleY:0.2637,x:44.2072,y:105.6408},0).wait(1).to({scaleX:0.2618,scaleY:0.2618,x:43.6154,y:105.0031},0).wait(1).to({scaleX:0.2598,scaleY:0.2598,x:42.985,y:104.2558},0).wait(1).to({scaleX:0.2575,scaleY:0.2575,x:42.4103,y:103.3356},0).wait(1).to({scaleX:0.2551,scaleY:0.2551,x:45.8992,y:103.9486},0).wait(1).to({scaleX:0.2526,scaleY:0.2526,x:49.7988,y:105.9847},0).wait(1).to({scaleX:0.2499,scaleY:0.2499,x:52.5556,y:107.5449},0).wait(1).to({scaleX:0.2469,scaleY:0.2469,x:57.3315,y:110.3545},0).wait(1).to({scaleX:0.2438,scaleY:0.2438,x:62.2756,y:113.3377},0).wait(1).to({scaleX:0.2405,scaleY:0.2405,x:66.3672,y:115.8413},0).wait(1).to({scaleX:0.2369,scaleY:0.2369,x:69.8463,y:117.9876},0).wait(1).to({scaleX:0.2332,scaleY:0.2332,x:73.0958,y:120.0038},0).wait(1).to({scaleX:0.2292,scaleY:0.2292,x:76.3063,y:122.0047},0).wait(1).to({scaleX:0.2249,scaleY:0.2249,x:79.5461,y:124.0314},0).wait(1).to({scaleX:0.2205,scaleY:0.2205,x:82.8415,y:126.0996},0).wait(1).to({scaleX:0.2158,scaleY:0.2158,x:86.203,y:128.2154},0).wait(1).to({scaleX:0.2108,scaleY:0.2108,x:89.5811,y:130.3464},0).wait(1).to({scaleX:0.2057,scaleY:0.2057,x:92.3084,y:132.0662},0).wait(1).to({scaleX:0.2004,scaleY:0.2004,x:94.8873,y:133.6907},0).wait(1).to({scaleX:0.1949,scaleY:0.1949,x:97.6307,y:135.4166},0).wait(1).to({scaleX:0.1893,scaleY:0.1893,x:100.4088,y:137.1618},0).wait(1).to({scaleX:0.1837,scaleY:0.1837,x:103.2423,y:138.9387},0).wait(1).to({scaleX:0.178,scaleY:0.178,x:106.0843,y:140.7173},0).wait(1).to({scaleX:0.1724,scaleY:0.1724,x:108.9145,y:142.4843},0).wait(1).to({scaleX:0.1669,scaleY:0.1669,x:111.7045,y:144.2211},0).wait(1).to({scaleX:0.1616,scaleY:0.1616,x:114.4313,y:145.9128},0).wait(1).to({scaleX:0.1565,scaleY:0.1565,x:117.0815,y:147.5498},0).wait(1).to({scaleX:0.1517,scaleY:0.1517,x:119.6303,y:149.1156},0).wait(1).to({scaleX:0.1471,scaleY:0.1471,x:122.0791,y:150.609},0).wait(1).to({scaleX:0.1428,scaleY:0.1428,x:124.4252,y:152.0249},0).wait(1).to({scaleX:0.1389,scaleY:0.1389,x:126.6812,y:153.3636},0).wait(1).to({scaleX:0.1353,scaleY:0.1353,x:128.9974,y:154.6928},0).wait(1).to({scaleX:0.132,scaleY:0.132,x:129.9075,y:155.2013},0).wait(1).to({scaleX:0.129,scaleY:0.129,x:131.1078,y:155.8559},0).wait(1).to({scaleX:0.1263,scaleY:0.1263,x:131.8872,y:156.2691},0).wait(1).to({scaleX:0.1239,scaleY:0.1239,x:132.8419,y:156.7573},0).wait(1).to({scaleX:0.1218,scaleY:0.1218,x:133.5333,y:157.0949},0).wait(1).to({scaleX:0.1199,scaleY:0.1199,x:134.3003,y:157.4461},0).wait(1).to({scaleX:0.1182,scaleY:0.1182,x:134.9455,y:157.713},0).wait(1).to({scaleX:0.1168,scaleY:0.1168,x:135.6137,y:157.9393},0).wait(1).to({scaleX:0.1156,scaleY:0.1156,x:136.2716,y:158.0246},0).wait(1).to({scaleX:0.1146,scaleY:0.1146,x:135.3272,y:156.1182},0).wait(1).to({scaleX:0.1137,scaleY:0.1137,x:133.1223,y:153.9418},0).wait(1).to({scaleX:0.1131,scaleY:0.1131,x:132.4848,y:153.3555},0).wait(1).to({scaleX:0.1126,scaleY:0.1126,x:132.1603,y:153.0612},0).wait(1).to({scaleX:0.1122,scaleY:0.1122,x:131.9476,y:152.8696},0).wait(1).to({scaleX:0.112,scaleY:0.112,x:131.826,y:152.7605},0).wait(1).to({regX:-1.4,regY:-1.4,x:131.8,y:152.8},0).wait(40));

	// image_snowshoes.png
	this.img_shoes = new lib.Tween3();
	this.img_shoes.name = "img_shoes";
	this.img_shoes.parent = this;
	this.img_shoes.setTransform(234.75,183.95,0.28,0.28,0,0,0,0.6,0);

	this.timeline.addTween(cjs.Tween.get(this.img_shoes).wait(1).to({regX:0,x:234.5939,y:183.9575},0).wait(3).to({regX:0.6,x:234.75,y:183.95},0).wait(1).to({regX:0,scaleX:0.2798,scaleY:0.2798,x:234.5089,y:183.888},0).wait(1).to({scaleX:0.2795,scaleY:0.2795,x:234.4149,y:183.8111},0).wait(1).to({scaleX:0.2791,scaleY:0.2791,x:234.2937,y:183.7122},0).wait(1).to({scaleX:0.2787,scaleY:0.2787,x:234.148,y:183.5932},0).wait(1).to({scaleX:0.2782,scaleY:0.2782,x:233.9756,y:183.4527},0).wait(1).to({scaleX:0.2775,scaleY:0.2775,x:233.7755,y:183.2897},0).wait(1).to({scaleX:0.2769,scaleY:0.2769,x:233.5461,y:183.1032},0).wait(1).to({scaleX:0.2761,scaleY:0.2761,x:233.286,y:182.892},0).wait(1).to({scaleX:0.2752,scaleY:0.2752,x:232.9934,y:182.6549},0).wait(1).to({scaleX:0.2742,scaleY:0.2742,x:232.6665,y:182.3906},0).wait(1).to({scaleX:0.2731,scaleY:0.2731,x:232.3035,y:182.0976},0).wait(1).to({scaleX:0.2719,scaleY:0.2719,x:231.902,y:181.7744},0).wait(1).to({scaleX:0.2705,scaleY:0.2705,x:231.4599,y:181.4196},0).wait(1).to({scaleX:0.2691,scaleY:0.2691,x:230.9745,y:181.0312},0).wait(1).to({scaleX:0.2675,scaleY:0.2675,x:230.4431,y:180.6076},0).wait(1).to({scaleX:0.2657,scaleY:0.2657,x:229.8626,y:180.1467},0).wait(1).to({scaleX:0.2638,scaleY:0.2638,x:229.23,y:179.6465},0).wait(1).to({scaleX:0.2618,scaleY:0.2618,x:228.5414,y:179.1047},0).wait(1).to({scaleX:0.2595,scaleY:0.2595,x:227.7931,y:178.5192},0).wait(1).to({scaleX:0.2571,scaleY:0.2571,x:226.9809,y:177.8874},0).wait(1).to({scaleX:0.2545,scaleY:0.2545,x:226.1002,y:177.207},0).wait(1).to({scaleX:0.2517,scaleY:0.2517,x:225.146,y:176.4753},0).wait(1).to({scaleX:0.2487,scaleY:0.2487,x:224.1132,y:175.69},0).wait(1).to({scaleX:0.2455,scaleY:0.2455,x:222.9961,y:174.8485},0).wait(1).to({scaleX:0.242,scaleY:0.242,x:221.789,y:173.9489},0).wait(1).to({scaleX:0.2383,scaleY:0.2383,x:220.4858,y:172.9894},0).wait(1).to({scaleX:0.2343,scaleY:0.2343,x:219.0807,y:171.9688},0).wait(1).to({scaleX:0.2301,scaleY:0.2301,x:217.5662,y:170.8859},0).wait(1).to({scaleX:0.2256,scaleY:0.2256,x:215.9389,y:169.7429},0).wait(1).to({scaleX:0.2209,scaleY:0.2209,x:214.195,y:168.5431},0).wait(1).to({scaleX:0.2159,scaleY:0.2159,x:212.332,y:167.2916},0).wait(1).to({scaleX:0.2107,scaleY:0.2107,x:210.3477,y:165.9955},0).wait(1).to({scaleX:0.2052,scaleY:0.2052,x:208.247,y:164.6677},0).wait(1).to({scaleX:0.1997,scaleY:0.1997,x:206.0338,y:163.3223},0).wait(1).to({scaleX:0.194,scaleY:0.194,x:203.7177,y:161.9787},0).wait(1).to({scaleX:0.1883,scaleY:0.1883,x:201.311,y:160.6596},0).wait(1).to({scaleX:0.1826,scaleY:0.1826,x:198.8229,y:159.3798},0).wait(1).to({scaleX:0.177,scaleY:0.177,x:196.6192,y:158.2377},0).wait(1).to({scaleX:0.1716,scaleY:0.1716,x:194.7007,y:157.2095},0).wait(1).to({scaleX:0.1665,scaleY:0.1665,x:192.8046,y:156.1505},0).wait(1).to({scaleX:0.1616,scaleY:0.1616,x:190.9896,y:155.0773},0).wait(1).to({scaleX:0.1571,scaleY:0.1571,x:189.2032,y:153.9269},0).wait(1).to({scaleX:0.1529,scaleY:0.1529,x:187.243,y:152.5618},0).wait(1).to({scaleX:0.1491,scaleY:0.1491,x:185.1817,y:151.0415},0).wait(1).to({scaleX:0.1456,scaleY:0.1456,x:183.399,y:149.6674},0).wait(1).to({scaleX:0.1424,scaleY:0.1424,x:181.9033,y:148.4774},0).wait(1).to({scaleX:0.1396,scaleY:0.1396,x:180.6393,y:147.4484},0).wait(1).to({scaleX:0.1372,scaleY:0.1372,x:179.5635,y:146.557},0).wait(1).to({scaleX:0.135,scaleY:0.135,x:178.6464,y:145.7864},0).wait(1).to({scaleX:0.1331,scaleY:0.1331,x:177.8665,y:145.1241},0).wait(1).to({scaleX:0.1314,scaleY:0.1314,x:177.2076,y:144.5595},0).wait(1).to({scaleX:0.1301,scaleY:0.1301,x:176.6565,y:144.0839},0).wait(1).to({scaleX:0.1289,scaleY:0.1289,x:176.2022,y:143.6896},0).wait(1).to({scaleX:0.128,scaleY:0.128,x:175.8355,y:143.37},0).wait(1).to({scaleX:0.1272,scaleY:0.1272,x:175.5485,y:143.119},0).wait(1).to({scaleX:0.1267,scaleY:0.1267,x:175.3345,y:142.9313},0).wait(1).to({scaleX:0.1263,scaleY:0.1263,x:175.1876,y:142.8022},0).wait(1).to({scaleX:0.126,scaleY:0.126,x:175.1027,y:142.7275},0).wait(1).to({regX:3.6,regY:0.4,x:175.15,y:142.7},0).wait(46));

	// Layer_30
	this.instance = new lib.Icon_OneDrive_1();
	this.instance.parent = this;
	this.instance.setTransform(190.05,120.55,0.31,0.31,0,0,0,0.3,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:189.9546,y:120.3934},0).wait(3).to({regX:0.3,regY:0.5,x:190.05,y:120.55},0).wait(1).to({regX:0,regY:0,scaleX:0.3099,scaleY:0.3099,x:189.8451,y:120.3168},0).wait(1).to({scaleX:0.3097,scaleY:0.3097,x:189.73,y:120.2364},0).wait(1).to({scaleX:0.3095,scaleY:0.3095,x:189.5831,y:120.134},0).wait(1).to({scaleX:0.3093,scaleY:0.3093,x:189.4095,y:120.0131},0).wait(1).to({scaleX:0.309,scaleY:0.309,x:189.2064,y:119.872},0).wait(1).to({scaleX:0.3087,scaleY:0.3087,x:188.9729,y:119.71},0).wait(1).to({scaleX:0.3084,scaleY:0.3084,x:188.7076,y:119.5265},0).wait(1).to({scaleX:0.308,scaleY:0.308,x:188.409,y:119.3204},0).wait(1).to({scaleX:0.3075,scaleY:0.3075,x:188.0755,y:119.091},0).wait(1).to({scaleX:0.3071,scaleY:0.3071,x:187.7054,y:118.8373},0).wait(1).to({scaleX:0.3065,scaleY:0.3065,x:187.2969,y:118.5583},0).wait(1).to({scaleX:0.3059,scaleY:0.3059,x:186.848,y:118.253},0).wait(1).to({scaleX:0.3053,scaleY:0.3053,x:186.3566,y:117.9204},0).wait(1).to({scaleX:0.3046,scaleY:0.3046,x:185.8203,y:117.5593},0).wait(1).to({scaleX:0.3038,scaleY:0.3038,x:185.2366,y:117.1687},0).wait(1).to({scaleX:0.303,scaleY:0.303,x:184.6029,y:116.7472},0).wait(1).to({scaleX:0.3021,scaleY:0.3021,x:183.916,y:116.2937},0).wait(1).to({scaleX:0.3012,scaleY:0.3012,x:183.173,y:115.807},0).wait(1).to({scaleX:0.3001,scaleY:0.3001,x:182.3701,y:115.2856},0).wait(1).to({scaleX:0.299,scaleY:0.299,x:181.5037,y:114.7285},0).wait(1).to({scaleX:0.2978,scaleY:0.2978,x:180.5696,y:114.1342},0).wait(1).to({scaleX:0.2966,scaleY:0.2966,x:179.5632,y:113.5016},0).wait(1).to({scaleX:0.2952,scaleY:0.2952,x:178.4796,y:112.8295},0).wait(1).to({scaleX:0.2938,scaleY:0.2938,x:177.3135,y:112.117},0).wait(1).to({scaleX:0.2922,scaleY:0.2922,x:176.0589,y:111.3632},0).wait(1).to({scaleX:0.2906,scaleY:0.2906,x:174.7095,y:110.5676},0).wait(1).to({scaleX:0.2888,scaleY:0.2888,x:173.2583,y:109.7301},0).wait(1).to({scaleX:0.2869,scaleY:0.2869,x:171.6978,y:108.8513},0).wait(1).to({scaleX:0.285,scaleY:0.285,x:170.0194,y:107.9322},0).wait(1).to({scaleX:0.2828,scaleY:0.2828,x:168.2129,y:106.9744},0).wait(1).to({scaleX:0.2806,scaleY:0.2806,x:166.2713,y:105.9832},0).wait(1).to({scaleX:0.2783,scaleY:0.2783,x:164.1844,y:104.9644},0).wait(1).to({scaleX:0.2758,scaleY:0.2758,x:161.9414,y:103.9263},0).wait(1).to({scaleX:0.2732,scaleY:0.2732,x:159.5299,y:102.8803},0).wait(1).to({scaleX:0.2704,scaleY:0.2704,x:156.9408,y:101.8446},0).wait(1).to({scaleX:0.2676,scaleY:0.2676,x:154.1626,y:100.8422},0).wait(1).to({scaleX:0.2646,scaleY:0.2646,x:151.1848,y:99.9056},0).wait(1).to({scaleX:0.2615,scaleY:0.2615,x:147.9943,y:99.0788},0).wait(1).to({scaleX:0.2584,scaleY:0.2584,x:144.6105,y:98.4396},0).wait(1).to({scaleX:0.2552,scaleY:0.2552,x:141.3891,y:98.075},0).wait(1).to({scaleX:0.252,scaleY:0.252,x:138.0193,y:97.9661},0).wait(1).to({scaleX:0.2488,scaleY:0.2488,x:134.579,y:98.1643},0).wait(1).to({scaleX:0.2456,scaleY:0.2456,x:131.1379,y:98.7007},0).wait(1).to({scaleX:0.2425,scaleY:0.2425,x:127.7822,y:99.5774},0).wait(1).to({scaleX:0.2395,scaleY:0.2395,x:124.5821,y:100.7674},0).wait(1).to({scaleX:0.2366,scaleY:0.2366,x:120.8963,y:102.5226},0).wait(1).to({scaleX:0.2338,scaleY:0.2338,x:117.2533,y:104.4174},0).wait(1).to({scaleX:0.2312,scaleY:0.2312,x:114.7536,y:105.7381},0).wait(1).to({scaleX:0.2287,scaleY:0.2287,x:112.8142,y:106.6643},0).wait(1).to({scaleX:0.2265,scaleY:0.2265,x:110.8372,y:107.4715},0).wait(1).to({scaleX:0.2244,scaleY:0.2244,x:108.7369,y:108.0923},0).wait(1).to({scaleX:0.2224,scaleY:0.2224,x:106.5188,y:108.4369},0).wait(1).to({scaleX:0.2207,scaleY:0.2207,x:104.3113,y:108.476},0).wait(1).to({scaleX:0.2191,scaleY:0.2191,x:102.2583,y:108.2579},0).wait(1).to({scaleX:0.2177,scaleY:0.2177,x:100.4263,y:107.8681},0).wait(1).to({scaleX:0.2164,scaleY:0.2164,x:98.8371,y:107.3883},0).wait(1).to({scaleX:0.2152,scaleY:0.2152,x:97.4803,y:106.8791},0).wait(1).to({scaleX:0.2142,scaleY:0.2142,x:96.3319,y:106.3789},0).wait(1).to({scaleX:0.2133,scaleY:0.2133,x:95.3655,y:105.9103},0).wait(1).to({scaleX:0.2126,scaleY:0.2126,x:94.5572,y:105.4857},0).wait(1).to({scaleX:0.2119,scaleY:0.2119,x:93.887,y:105.1115},0).wait(1).to({scaleX:0.2114,scaleY:0.2114,x:93.3382,y:104.7905},0).wait(1).to({scaleX:0.2109,scaleY:0.2109,x:92.8974,y:104.5233},0).wait(1).to({scaleX:0.2106,scaleY:0.2106,x:92.5536,y:104.309},0).wait(1).to({scaleX:0.2103,scaleY:0.2103,x:92.2975,y:104.1461},0).wait(1).to({scaleX:0.2101,scaleY:0.2101,x:92.1217,y:104.0328},0).wait(1).to({scaleX:0.21,scaleY:0.21,x:92.0199,y:103.9665},0).wait(1).to({regX:-0.7,regY:-0.5,x:92.05,y:104.05},0).wait(37));

	// laptop
	this.laptop = new lib.laptop_phone();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(160.05,156.2,0.655,0.655,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(109));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,0,370,258);


(lib.BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bg.cache(0,0,300,600,1)
		this.bg_fade.cache(0,0,300,600,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.bg_fade = new lib.bg_fade_cache();
	this.bg_fade.name = "bg_fade";
	this.bg_fade.parent = this;
	this.bg_fade.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.bg_fade).wait(1));

	// Layer_1
	this.bg = new lib.bg_cache();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.BG, new cjs.Rectangle(0,0,300,600), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-8.45,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("Ap2CjIAAlFITtAAIAAFFg");
	this.shape.setTransform(-38.025,-1.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-101.1,-17.5,126.19999999999999,32.6), null);


(lib.MSFT_Logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo_1();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_34 = function() {
		exportRoot.tlpic1.play();
	}
	this.frame_42 = function() {
		exportRoot.tlpic5.play();
	}
	this.frame_51 = function() {
		exportRoot.tlpic2.play();
		exportRoot.tlpic4.play();
	}
	this.frame_59 = function() {
		exportRoot.tlpic3.play();
	}
	this.frame_68 = function() {
		exportRoot.tl1.play()
		exportRoot.tl2.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(8).call(this.frame_42).wait(9).call(this.frame_51).wait(8).call(this.frame_59).wait(9).call(this.frame_68).wait(6).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298,898.75,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:898.5},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgGoBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("EgG4BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("EgHmBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("EgIzBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("EgKeBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("EgMpBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("EgPSBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("EgR7BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("EgUGBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("EgVxBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("EgW+BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("EgXsBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("EgX8BK6IAAyrMBGZAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:479.4334}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:479.4334}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:479.4334}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:479.4334}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:479.4334}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:479.4334}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:479.4334}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:479.4334}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:479.4334}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:479.4334}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:479.4334}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:479.4334}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:479.4334}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.9,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:300.35},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhMxCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTfCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhaiCXxMAAAkvhMCXsAAAMAAAEvhg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:903.6504}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:903.6504}).wait(1).to({graphics:mask_1_graphics_52,x:295.8292,y:903.6504}).wait(1).to({graphics:mask_1_graphics_53,x:289.2197,y:903.6504}).wait(1).to({graphics:mask_1_graphics_54,x:278.2038,y:903.6504}).wait(1).to({graphics:mask_1_graphics_55,x:262.7816,y:903.6504}).wait(1).to({graphics:mask_1_graphics_56,x:242.953,y:903.6504}).wait(1).to({graphics:mask_1_graphics_57,x:218.7181,y:903.6504}).wait(1).to({graphics:mask_1_graphics_58,x:190.0769,y:903.6504}).wait(1).to({graphics:mask_1_graphics_59,x:157.0292,y:903.6504}).wait(1).to({graphics:mask_1_graphics_60,x:119.5753,y:903.6504}).wait(1).to({graphics:mask_1_graphics_61,x:77.7149,y:903.6504}).wait(1).to({graphics:mask_1_graphics_62,x:31.4483,y:903.6504}).wait(1).to({graphics:mask_1_graphics_63,x:-19.2247,y:903.6504}).wait(1).to({graphics:mask_1_graphics_64,x:-74.3041,y:903.6504}).wait(1).to({graphics:mask_1_graphics_65,x:-133.7898,y:903.6504}).wait(1).to({graphics:mask_1_graphics_66,x:-197.6819,y:903.6504}).wait(1).to({graphics:mask_1_graphics_67,x:-265.9803,y:903.6504}).wait(1).to({graphics:mask_1_graphics_68,x:-338.6851,y:903.6504}).wait(1).to({graphics:mask_1_graphics_69,x:-415.7962,y:903.6504}).wait(1).to({graphics:mask_1_graphics_70,x:-491.398,y:903.6504}).wait(1).to({graphics:mask_1_graphics_71,x:-534.3599,y:903.6504}).wait(1).to({graphics:mask_1_graphics_72,x:-579.525,y:903.6504}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-673.65},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-666.45},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1159,-67.6,1942.5,1942.6);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(283.6,4.7,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// intro_logo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(67,39,0.72,0.72);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(230.7,556.1,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(284.2,556.3,1,1,0,0,0,0.2,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// anim
	this.anim = new lib.Devices_Isometric();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(12,181.95);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// BG
	this.bg = new lib.BG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-0.9,-1.4,310,606.1), null);


// stage content:
(lib.O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var anim = exportRoot.mainMC.anim
		var laptop = exportRoot.mainMC.anim.laptop
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
			
			exportRoot.tl1.from(laptop, 2, {scaleX:.355, scaleY:.355, x:"-=50", y:"-=26", ease:Power3.easeInOut, onStart:function(){anim.gotoAndPlay(1);}}, "+=1.5");
			exportRoot.tl1.to(anim, 2, {scaleX:1.52, scaleY:1.52, x:"-=75", y:"-=52", ease:Power3.easeInOut}, "-=2");
		
			//exportRoot.tl1.to(anim, 1.5, {x:"+=70", ease:Power3.easeInOut}, "+=0");
			
			exportRoot.tl1.stop();	
				
			this.tl2 = new TimelineLite();
			//Organize your photos
			exportRoot.tl2.from(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.5");
			exportRoot.tl2.from(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
			exportRoot.tl2.from(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
				
			exportRoot.tl2.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
			exportRoot.tl2.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
			exportRoot.tl2.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
		
			//and
			exportRoot.tl2.from(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
			
			exportRoot.tl2.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.4");
			
			//keep them secure
			exportRoot.tl2.from(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
			exportRoot.tl2.from(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.25");
			exportRoot.tl2.from(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
				
			exportRoot.tl2.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
			exportRoot.tl2.to(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
			exportRoot.tl2.to(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
			
			//in OneDrive
			exportRoot.tl2.from(exportRoot.headline8, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
			exportRoot.tl2.from(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.25");
			
			exportRoot.tl2.to(exportRoot.headline8, 0.5, {alpha: 0, ease:Power4.easeIn}, "+=0.6");
			exportRoot.tl2.to(exportRoot.headline9, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
		
			exportRoot.tl2.from(mc.bg.bg_fade, 1.5, {alpha:0, ease:Power3.easeInOut}, "+=0");
			
			for (var i = 0; i < exportRoot.headline10.length; i++) {
			if (i==0) exportRoot.tl2.from(exportRoot.headline10[i], 0.8, { x: "-=300", alpha: 0, ease:Power4.easeOut}, "-=1");
			if (i!=0) exportRoot.tl2.from(exportRoot.headline10[i], 0.8, { x: "-=300", alpha: 0, ease:Power4.easeOut}, "-=0.7");
			}
				
			for (var i = 0; i < exportRoot.headline11.length; i++) {
			if (i==0) exportRoot.tl2.from(exportRoot.headline11[i], 0.8, { x: "-=300", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			if (i!=0) exportRoot.tl2.from(exportRoot.headline11[i], 0.8, { x: "-=300", alpha: 0, ease:Power4.easeOut}, "-=0.7");
			}
				
			exportRoot.tl2.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=0.4");	
			exportRoot.tl2.from(mc.txtCta, 0.7, { alpha: 0, x: "+=150",	ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl2.from(mc.cta, 0.7, {	alpha: 0, x: "+=150", ease:Power4.easeOut}, "-=0.7");
		
			
			exportRoot.tl2.stop();
				
			this.tlpic1 = new TimelineLite();
				
			exportRoot.tlpic1.to(anim.img_snowman.snowTest, 1, {x:"-=20", y:"+=60", ease:Power2.easeInOut});
			exportRoot.tlpic1.to(anim.img_snowman.snowTest, 2, {x:"+=40", y:"-=180", ease:Power2.easeInOut});
			exportRoot.tlpic1.to(anim.img_snowman.snowTest, 1, {x:"-=20", y:"+=60", ease:Power2.easeInOut});
		
			exportRoot.tlpic1.stop();
				
			this.tlpic2 = new TimelineLite();
				
			exportRoot.tlpic2.to(anim.img_family.snowTest, 1, {x:"+=10", y:"-=22.5", ease:Power2.easeInOut});
			exportRoot.tlpic2.to(anim.img_family.snowTest, 2, {x:"-=20", y:"+=45", ease:Power2.easeInOut});
			exportRoot.tlpic2.to(anim.img_family.snowTest, 1, {x:"+=10", y:"-=22.5", ease:Power2.easeInOut});
		
			exportRoot.tlpic2.stop();
		
			this.tlpic3 = new TimelineLite();
				
			exportRoot.tlpic3.to(anim.img_landscape.snowTest, 1, {x:"-=10", y:"+=15", ease:Power2.easeInOut});
			exportRoot.tlpic3.to(anim.img_landscape.snowTest, 2, {x:"+=20", y:"-=30", ease:Power2.easeInOut});
			exportRoot.tlpic3.to(anim.img_landscape.snowTest, 1, {x:"-=10", y:"+=15", ease:Power2.easeInOut});
			
			exportRoot.tlpic3.stop();
				
			this.tlpic4 = new TimelineLite();
				
			exportRoot.tlpic4.to(anim.img_dog.snowTest, 1, {x:"+=10", y:"-=25", ease:Power2.easeInOut});
			exportRoot.tlpic4.to(anim.img_dog.snowTest, 2, {x:"-=20", y:"+=50", ease:Power2.easeInOut});
			exportRoot.tlpic4.to(anim.img_dog.snowTest, 1, {x:"+=10", y:"-=25", ease:Power2.easeInOut});
			
			exportRoot.tlpic4.stop();
		
			this.tlpic5 = new TimelineLite();
			
			exportRoot.tlpic5.to(anim.img_shoes.snowTest, 1, {x:"-=10", y:"+=35", ease:Power2.easeInOut});
			exportRoot.tlpic5.to(anim.img_shoes.snowTest, 2, {x:"+=20", y:"-=70", ease:Power2.easeInOut});
			exportRoot.tlpic5.to(anim.img_shoes.snowTest, 1, {x:"-=10", y:"+=35", ease:Power2.easeInOut});
		
			exportRoot.tlpic5.stop();
				
			mc.logo_intro.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149.1,298.6,160.00000000000003,306.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574944756276", id:"O365_NewYearCampaign_USA_300x600_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;