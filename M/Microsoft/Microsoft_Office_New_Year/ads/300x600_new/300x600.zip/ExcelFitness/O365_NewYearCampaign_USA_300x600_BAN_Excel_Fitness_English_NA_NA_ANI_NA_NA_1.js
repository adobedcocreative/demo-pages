(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[0,117,336,51],[759,0,69,69],[0,0,757,115],[338,117,266,43]]}
];


// symbols:



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.ExcelIcon = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.laptopshadow = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.phoneshadow = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt4 = new cjs.Text("Sleep", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 7;
	this.txt4.parent = this;
	this.txt4.setTransform(104.95,65.6);

	this.txt3 = new cjs.Text("Me Time", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.parent = this;
	this.txt3.setTransform(69.8,65.6);

	this.txt2 = new cjs.Text("Calories", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.parent = this;
	this.txt2.setTransform(38.25,65.6);

	this.txt1 = new cjs.Text("Exercise", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.parent = this;
	this.txt1.setTransform(6.05,65.6);

	this.txt = new cjs.Text("Fitness Vision", "11px 'Segoe Pro'", "#2580BD");
	this.txt.name = "txt";
	this.txt.lineHeight = 17;
	this.txt.parent = this;
	this.txt.setTransform(26.5,13.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.txt, new cjs.Rectangle(4.1,11.5,112.5,61.5), null);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.topbar_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ag+BVIgWgWIAAiTICpAAIAAA8IgNAAIAAgwIgMAAIAAAwIgLAAIAAgwIhhAAIAAA9IArAAIgLALIgrAAIAAhIIgNAAIAACCIAPAOIAJAAIAAgwIAXAAIgBAIIAAAEIgKAAIAAAkIAKAAIAAANg");
	this.shape.setTransform(-127.25,205.1,0.1355,0.1355,0,0,0,-1.8,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAvQgHgCgHgFIgFgFIgFgGIAAAKIgKAAIAAgdIAdAAIAAAKIgOAAIAGAIQAFAEADACQAEACAGACQAFABAEAAQAFAAAIgCQAFgBAGgFQAEgDAFgHQADgFACgHIAKACQgCAJgFAGQgFAHgFAFQgFAFgKADQgGADgKAAQgIAAgGgCgAgvgKQADgJAEgGQAFgHAFgFQAFgFAKgDQAIgDAHAAQAJAAAGACQAHACAHAFIAKALIAAgKIAKAAIAAAdIgdAAIAAgKIAOAAIgGgIQgFgEgDgCIgKgEQgFgBgFAAQgFAAgHACQgGACgFAEQgGAGgDAEQgDAFgCAHg");
	this.shape_1.setTransform(-126.5037,205.6294,0.1355,0.1355);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgEAfIAAgsIgMALIgGgGIAWgWIAXAWIgGAGIgMgLIAAAsg");
	this.shape_2.setTransform(10.8951,205.1013,0.146,0.146);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhAAyIAAhjICBAAIAABjgAg4ArIBwAAIAAg9IhwAAgAg4gaIBwAAIAAgPIhwAAg");
	this.shape_3.setTransform(10.8988,204.9298,0.146,0.146);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(240,239,239,0.498)").s().p("AgdgOIA7AAIgeAdg");
	this.shape_4.setTransform(-117.5453,204.9646,0.1323,0.1323);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("rgba(255,255,255,0.498)").s().p("AgSBJIBChCQAFgGAEgHQAEgKAAgHQAAgJgEgJQgDgGgHgJQgFgFgJgEQgIgDgKAAQgJgBgGADQgEACgHAFIgqApIA1AAIAAAKIhGAAIAAhGIAKAAIAAA1IAlglIAIgHIAJgFIAJgDQAGgCAGAAQAGAAAJACQAHADAGADQAIAFADAEQAGAFADAGIAGANQACAGAAAJQAAAKgEAKQgFAJgHAIIhBBCg");
	this.shape_5.setTransform(-119.4166,205.163,0.1323,0.1323,0,0,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F0EFEF").s().p("AgdgOIA7AAIgeAdg");
	this.shape_6.setTransform(-121.2953,204.9646,0.1323,0.1323);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgSBJIBChCQAFgGAEgHQAEgKAAgHQAAgJgEgJQgDgGgHgJQgFgFgJgEQgIgDgKAAQgJgBgGADQgEACgHAFIgqApIA1AAIAAAKIhGAAIAAhGIAKAAIAAA1IAlglIAIgHIAJgFIAJgDQAGgCAGAAQAGAAAJACQAHADAGADQAIAFADAEQAGAFADAGIAGANQACAGAAAJQAAAKgEAKQgFAJgHAIIhBBCg");
	this.shape_7.setTransform(-123.1834,205.163,0.1323,0.1323);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgxAyIAAhPIAUAAIAAgUIBPAAIAABPIgUAAIAAAUgAgpAqIBAAAIAAg/IhAAAgAgWgdIA0AAIAAA0IAMAAIAAhAIhAAAg");
	this.shape_8.setTransform(23.0871,204.8476,0.1293,0.1293);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAAAGIgrAsIgGgGIAsgsIgsgrIAGgGIArAtIAsgtIAGAGIgtArIAtAsIgGAGg");
	this.shape_9.setTransform(28.9336,204.8476,0.1293,0.1293);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgzAFIAAgJIBoAAIAAAJg");
	this.shape_10.setTransform(17.0794,204.9123,0.1293,0.1293);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgdAFIAAgJIA7AAIAAAJg");
	this.shape_11.setTransform(-116.002,204.6501,0.1323,0.1323);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgdgOIA7AAIgeAdg");
	this.shape_12.setTransform(-116.002,205.1791,0.1323,0.1323);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhwBSQgiAAgYgYQgZgYAAgiQAAghAZgYQAYgYAiAAIDiAAQAhAAAYAYQAZAYAAAhQAAAigZAYQgYAYghAAgABWgaQgLAMAAAPQAAAQALALQALALARAAQAQAAALgLQALgLAAgQQAAgPgLgMQgLgLgQAAQgRAAgLALg");
	this.shape_13.setTransform(-132.753,204.7261,0.1323,0.1323);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#464646").s().p("AhDBEQAAAAAAgBQgBAAAAgBQAAAAABgBQAAAAAAAAIAygzQgNgOAAgSQAAgVAPgOQAPgPATAAQAVAAAOAPQAOAOAAAVQAAAUgOAOQgOAPgVAAQgTAAgNgNIgzAyIgCAAgAgMgyQgNAOAAASQAAASANANQANANASAAQATAAAMgNQAOgNAAgSQAAgSgOgOQgMgNgTAAQgSAAgNANg");
	this.shape_14.setTransform(-63.6,209.15,0.1387,0.1387);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AhMgmICZAAIhNBNg");
	this.shape_15.setTransform(-40.7728,205.0386,0.1529,0.1529);

	this.txt18 = new cjs.Text("Share", "2px 'Segoe Pro'", "#207346");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 5;
	this.txt18.lineWidth = 6;
	this.txt18.parent = this;
	this.txt18.setTransform(9.35,210.85);

	this.txt19 = new cjs.Text("Comments", "2px 'Segoe Pro'", "#207346");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 5;
	this.txt19.lineWidth = 8;
	this.txt19.parent = this;
	this.txt19.setTransform(19.35,210.8);

	this.txt17 = new cjs.Text("Search", "2px 'Segoe Pro'", "#545251");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 6;
	this.txt17.lineWidth = 16;
	this.txt17.parent = this;
	this.txt17.setTransform(-61.85,210.45);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#207346").s().p("AggAbIgWAAIAAhPIBtAAIAABPIg+AAIgZAagAgvAUIAVAAIAAAQIAQgQIA7AAIAAhAIhgAAg");
	this.shape_16.setTransform(17.5212,209.2245,0.1368,0.1368);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#EDEAE8").s().p("AnTB4QgIAAgGgGQgGgGAAgIIAAjHQAAgJAGgFQAGgGAIAAIOnAAQAIAAAGAGQAGAFAAAJIAADHQAAAIgGAGQgGAGgIAAgAndhjIAADHQAAAEADADQADADAEAAIOnAAQAEAAADgDQADgDAAgEIAAjHQAAgKgKAAIunAAQgKAAAAAKg");
	this.shape_17.setTransform(22.6786,209.1668,0.1367,0.1367);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AnTB4QgIAAgGgGQgGgGAAgIIAAjHQAAgJAGgFQAGgGAIAAIOnAAQAIAAAGAGQAGAFAAAJIAADHQAAAIgGAGQgGAGgIAAg");
	this.shape_18.setTransform(22.6654,209.1834,0.137,0.137);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#207346").s().p("AAGAUIgPABIgOAFIgNAHQgIAFgEAFIAAgIQAAgIACgGIAFgOIAJgKIALgIQAHgEAGgCQAGgCAIAAIAAgXIArAqIgrArgAgFgKIgHADIgJAFIgJAHIgGAKIgDALQAIgGAOgFQALgDAMAAIAIAAIAAAMIAYgYIgYgXIAAAMIgOAAg");
	this.shape_19.setTransform(7.0835,209.723,0.1365,0.1365);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#207346").s().p("AgyAoIAAhPIAGAAIAABIIBZAAIAAgoIAFAAIAAAvg");
	this.shape_20.setTransform(6.8207,210.3304,0.1365,0.1365);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#EDEAE8").s().p("Ak7B4QgIAAgGgGQgGgFAAgJIAAjHQAAgIAGgGQAGgGAIAAIJ3AAQAIAAAGAGQAGAGAAAIIAADHQAAAJgGAFQgGAGgIAAgAlChqQgDADAAAEIAADHQAAAEADADQADADAEAAIJ3AAQAEAAADgDQADgDAAgEIAAjHQAAgEgDgDQgDgDgEAAIp3AAQgEAAgDADg");
	this.shape_21.setTransform(9.6085,210.0608,0.1365,0.1365);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ak7B4QgIAAgGgGQgGgFAAgJIAAjHQAAgIAGgGQAGgGAIAAIJ3AAQAIAAAGAGQAGAGAAAIIAADHQAAAJgGAFQgGAGgIAAg");
	this.shape_22.setTransform(9.6085,210.0608,0.1365,0.1365);

	this.txt16 = new cjs.Text("Help", "2px 'Segoe Pro'", "#545251");
	this.txt16.name = "txt16";
	this.txt16.textAlign = "center";
	this.txt16.lineHeight = 6;
	this.txt16.lineWidth = 12;
	this.txt16.parent = this;
	this.txt16.setTransform(-69.849,210.5);

	this.txt14 = new cjs.Text("View", "2px 'Segoe Pro'", "#545251");
	this.txt14.name = "txt14";
	this.txt14.textAlign = "center";
	this.txt14.lineHeight = 6;
	this.txt14.lineWidth = 12;
	this.txt14.parent = this;
	this.txt14.setTransform(-77.099,210.5);

	this.txt6 = new cjs.Text("Home", "2px 'Segoe Pro'", "#545251");
	this.txt6.name = "txt6";
	this.txt6.textAlign = "center";
	this.txt6.lineHeight = 6;
	this.txt6.lineWidth = 15;
	this.txt6.parent = this;
	this.txt6.setTransform(-133.449,210.45);

	this.txt7 = new cjs.Text("Insert", "2px 'Segoe Pro'", "#545251");
	this.txt7.name = "txt7";
	this.txt7.textAlign = "center";
	this.txt7.lineHeight = 6;
	this.txt7.lineWidth = 14;
	this.txt7.parent = this;
	this.txt7.setTransform(-125.349,210.45);

	this.txt5 = new cjs.Text("File", "2px 'Segoe Pro'", "#545251");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 6;
	this.txt5.lineWidth = 8;
	this.txt5.parent = this;
	this.txt5.setTransform(-143.1,210.45);

	this.txt13 = new cjs.Text("Review", "2px 'Segoe Pro'", "#545251");
	this.txt13.name = "txt13";
	this.txt13.textAlign = "center";
	this.txt13.lineHeight = 6;
	this.txt13.lineWidth = 17;
	this.txt13.parent = this;
	this.txt13.setTransform(-84.999,210.45);

	this.txt12 = new cjs.Text("Data", "2px 'Segoe Pro'", "#545251");
	this.txt12.name = "txt12";
	this.txt12.textAlign = "center";
	this.txt12.lineHeight = 6;
	this.txt12.lineWidth = 12;
	this.txt12.parent = this;
	this.txt12.setTransform(-93.049,210.45);

	this.txt10 = new cjs.Text("Page Layout", "2px 'Segoe Pro'", "#545251");
	this.txt10.name = "txt10";
	this.txt10.textAlign = "center";
	this.txt10.lineHeight = 6;
	this.txt10.lineWidth = 30;
	this.txt10.parent = this;
	this.txt10.setTransform(-114.2991,210.45);

	this.txt11 = new cjs.Text("Formulas", "2px 'Segoe Pro'", "#545251");
	this.txt11.name = "txt11";
	this.txt11.textAlign = "center";
	this.txt11.lineHeight = 6;
	this.txt11.lineWidth = 22;
	this.txt11.parent = this;
	this.txt11.setTransform(-102.2991,210.45);

	this.txt4 = new cjs.Text("Daniela Duarte", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 5;
	this.txt4.lineWidth = 14;
	this.txt4.parent = this;
	this.txt4.setTransform(-5.8,205.65);

	this.txt3 = new cjs.Text("Fitness Vision - Saved to OneDrive", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 5;
	this.txt3.lineWidth = 66;
	this.txt3.parent = this;
	this.txt3.setTransform(-73.45,205.65);

	this.txt2 = new cjs.Text("On", "2px 'Segoe Pro'", "#207346");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 5;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(-134.65,205.85);

	this.txt1 = new cjs.Text("AutoSave", "2px 'Segoe Pro'", "#FFFFFF");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 5;
	this.txt1.lineWidth = 9;
	this.txt1.parent = this;
	this.txt1.setTransform(-144.05,205.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt11},{t:this.txt10},{t:this.txt12},{t:this.txt13},{t:this.txt5},{t:this.txt7},{t:this.txt6},{t:this.txt14},{t:this.txt16},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.txt17},{t:this.txt19},{t:this.txt18},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_4
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#207346").s().p("EhqtAF4IAArvMDVbAAAIAALvg");
	this.shape_23.setTransform(-56.5384,202.3149,0.1305,0.1378);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#F3F2F1").s().p("At6AnIAAhQIb1ADIAABQg");
	this.shape_24.setTransform(-56.5009,209.6282);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.topbar_2, new cjs.Rectangle(-146,197.2,178.6,22.600000000000023), null);


(lib.text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt4 = new cjs.Text("Sleep", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 7;
	this.txt4.parent = this;
	this.txt4.setTransform(104.95,58.65);

	this.txt3 = new cjs.Text("Me Time", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.parent = this;
	this.txt3.setTransform(69.8,58.65);

	this.txt2 = new cjs.Text("Calories", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.parent = this;
	this.txt2.setTransform(38.25,58.65);

	this.txt1 = new cjs.Text("Exercise", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.parent = this;
	this.txt1.setTransform(6.05,58.65);

	this.txt = new cjs.Text("Fitness Vision", "11px 'Segoe Pro'", "#2580BD");
	this.txt.name = "txt";
	this.txt.lineHeight = 17;
	this.txt.parent = this;
	this.txt.setTransform(28.65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.text, new cjs.Rectangle(4.1,13,112.5,53.099999999999994), null);


(lib.sleep_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(40));

	// Layer_4
	this.txt8 = new cjs.Text("0%", "4px 'Segoe Pro'", "#4354A4");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 7;
	this.txt8.parent = this;
	this.txt8.setTransform(1.35,20.65);

	this.timeline.addTween(cjs.Tween.get(this.txt8).wait(7).to({text:"0.3%",lineWidth:8},0).wait(2).to({text:"1.1%",lineWidth:7},0).wait(2).to({text:"2.3%",lineWidth:8},0).wait(2).to({text:"3.8%"},0).wait(2).to({text:"5.4%"},0).wait(2).to({text:"6.9%"},0).wait(2).to({text:"6.4%"},0).wait(2).to({text:"9.6%"},0).wait(2).to({text:"10.4%",lineWidth:9},0).wait(2).to({text:"10.5%"},0).wait(2).to({text:"10.7%"},0).wait(13));

	// Layer_3
	this.txt9 = new cjs.Text("56.0 hours", "4px 'Segoe Pro'", "#4354A4");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 7;
	this.txt9.lineWidth = 21;
	this.txt9.parent = this;
	this.txt9.setTransform(1.3501,11.3);

	this.timeline.addTween(cjs.Tween.get(this.txt9).wait(40));

	// Layer_1
	this.txt7 = new cjs.Text("0 hours", "4px 'Segoe Pro'", "#4354A4");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 7;
	this.txt7.lineWidth = 19;
	this.txt7.parent = this;
	this.txt7.setTransform(1.4,3.05);

	this.timeline.addTween(cjs.Tween.get(this.txt7).wait(7).to({text:"0.7 hours",lineWidth:22},0).wait(2).to({text:"1.5 hours",lineWidth:19},0).wait(2).to({text:"2.3 hours",lineWidth:23},0).wait(2).to({text:"3.1 hours",lineWidth:21},0).wait(2).to({text:"3.5 hours",lineWidth:22},0).wait(2).to({text:"4.4 hours",lineWidth:17},0).wait(2).to({text:"5.1 hours",lineWidth:19},0).wait(2).to({text:"5.3 hours",lineWidth:21},0).wait(2).to({text:"5.5 hours",lineWidth:19},0).wait(2).to({text:"6.4 hours"},0).wait(2).to({text:"6.0 hours",lineWidth:17},0).wait(12).to({lineWidth:18},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,1.1,26.900000000000002,27);


(lib.sleep_hours = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt8.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt8 = new cjs.Text("6.0 hours", "4px 'Segoe Pro'", "#4354A4");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 7;
	this.txt8.parent = this;
	this.txt8.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt8).wait(1));

}).prototype = getMCSymbolPrototype(lib.sleep_hours, new cjs.Rectangle(0,0,20.1,9.4), null);


(lib.shadowcache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.laptopshadow();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.2549,1.2549);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadowcache, new cjs.Rectangle(0,0,950,144.3), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.phoneshadow();
	this.instance.parent = this;
	this.instance.setTransform(0,0,2.2121,2.2121);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,588.4,95.1), null);


(lib.runtime_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt5.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(46));

	// Layer_3
	this.txt5 = new cjs.Text("300 minutes", "4px 'Segoe Pro'", "#2680BE");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 7;
	this.txt5.lineWidth = 25;
	this.txt5.parent = this;
	this.txt5.setTransform(3.6,12.1);

	this.timeline.addTween(cjs.Tween.get(this.txt5).wait(46));

	// Layer_1
	this.txt5_1 = new cjs.Text("0 minutes", "4px 'Segoe Pro'", "#2680BE");
	this.txt5_1.name = "txt5_1";
	this.txt5_1.lineHeight = 7;
	this.txt5_1.lineWidth = 25;
	this.txt5_1.parent = this;
	this.txt5_1.setTransform(3.6,3.1);

	this.timeline.addTween(cjs.Tween.get(this.txt5_1).wait(7).to({text:"7 minutes",lineWidth:27},0).wait(2).to({text:"14 minutes"},0).wait(2).to({text:"22 minutes",lineWidth:24},0).wait(2).to({text:"39 minutes",lineWidth:25},0).wait(2).to({text:"46 minutes",lineWidth:24},0).wait(2).to({text:"62 minutes"},0).wait(2).to({text:"76 minutes"},0).wait(2).to({text:"90 minutes"},0).wait(2).to({text:"101 minutes",lineWidth:26},0).wait(2).to({text:"111 minutes"},0).wait(2).to({text:"115 minutes"},0).wait(2).to({text:"117 minutes",lineWidth:27},0).wait(2).to({text:"119 minutes",lineWidth:25},0).wait(2).to({text:"120 minutes",lineWidth:26},0).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.6,1.1,31,19);


(lib.readytxt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Ready", "3px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 8;
	this.txt.parent = this;
	this.txt.setTransform(2.45,2.95);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.readytxt, new cjs.Rectangle(0.5,1,12.2,10), null);


(lib.purple = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4656A8").s().p("ApBODQCbgICQg9QCihFB7h8QB9h9BEihQBHioAAi2QAAi2hHinQhEiih9h8Qh7h9iihEQinhHi3AAIgCAAIAAloIACAAQEAAADqBjQDhBgCvCuQCuCvBgDiQBjDqAAD/QAAEAhjDqQhgDiiuCuQivCujhBgQjSBZjlAJg");
	this.shape.setTransform(188.875,125.925);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.purple, new cjs.Rectangle(125.8,0,126.2,251.9), null);


(lib.pink_circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E42364").s().p("AluNrQAtgOArgSQCihFB7h8QB9h9BEihQBHioAAi2QAAi2hHinQhEiih9h8Qh7h9iihEQinhHi3AAIgCAAIAAloIACAAQEAAADqBjQDhBgCvCuQCuCvBgDiQBjDqAAD/QAAEAhjDqQhgDiiuCuQivCujhBgQhvAwh1AYg");
	this.shape.setTransform(188.875,124.6125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.pink_circle, new cjs.Rectangle(125.8,0,126.2,249.3), null);


(lib.Percentagetxt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("100%", "3px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.parent = this;
	this.txt.setTransform(2.8,3.15);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Percentagetxt, new cjs.Rectangle(0.8,1.2,11,13.4), null);


(lib.orange_circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F15825").s().p("AmfN0QBGgRBDgdQCihEB7h9QB9h8BEiiQBHinAAi3QAAi2hHinQhEihh9h9Qh7h9iihEQinhHi3AAIgCAAIAAloIACAAQEAAADqBjQDhBgCvCvQCuCuBgDiQBjDqAAD/QAAEAhjDqQhgDiiuCuQivCvjhBgQiHA5iOAYg");
	this.shape.setTransform(188.875,125.0875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.orange_circle, new cjs.Rectangle(125.8,0,126.2,250.2), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.minutes = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt5.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt5 = new cjs.Text("120 minutes", "4px 'Segoe Pro'", "#2680BE");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 7;
	this.txt5.lineWidth = 26;
	this.txt5.parent = this;
	this.txt5.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt5).wait(1));

}).prototype = getMCSymbolPrototype(lib.minutes, new cjs.Rectangle(0,0,29.9,10), null);


(lib.Me_time_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(40));

	// Layer_3
	this.txt9 = new cjs.Text("140 minutes", "4px 'Segoe Pro'", "#E42364");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 7;
	this.txt9.lineWidth = 25;
	this.txt9.parent = this;
	this.txt9.setTransform(3.9,11.8);

	this.timeline.addTween(cjs.Tween.get(this.txt9).wait(40));

	// Layer_4
	this.txt8 = new cjs.Text("0%", "4px 'Segoe Pro'", "#E42364");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 7;
	this.txt8.parent = this;
	this.txt8.setTransform(4.25,20.65);

	this.timeline.addTween(cjs.Tween.get(this.txt8).wait(7).to({text:"0.3%",lineWidth:8},0).wait(2).to({text:"1.1%",lineWidth:7},0).wait(2).to({text:"2.3%",lineWidth:8},0).wait(2).to({text:"3.8%"},0).wait(2).to({text:"5.4%"},0).wait(2).to({text:"6.9%"},0).wait(2).to({text:"6.4%"},0).wait(2).to({text:"9.6%"},0).wait(2).to({text:"10.4%",lineWidth:9},0).wait(2).to({text:"10.5%"},0).wait(2).to({text:"10.7%"},0).wait(13));

	// Layer_1
	this.txt7 = new cjs.Text("0 minutes", "4px 'Segoe Pro'", "#E42364");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 7;
	this.txt7.lineWidth = 23;
	this.txt7.parent = this;
	this.txt7.setTransform(3.95,3.2);

	this.timeline.addTween(cjs.Tween.get(this.txt7).wait(7).to({text:"2 minutes"},0).wait(2).to({text:"4 minutes"},0).wait(2).to({text:"6 minutes"},0).wait(2).to({text:"8 minutes",lineWidth:24},0).wait(2).to({text:"10 minutes",lineWidth:23},0).wait(2).to({text:"11 minutes"},0).wait(2).to({text:"12 minutes"},0).wait(2).to({text:"13 minutes"},0).wait(2).to({text:"10 minutes"},0).wait(2).to({text:"14 minutes"},0).wait(2).to({text:"15 minutes"},0).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(1.9,1.2,29.1,26.900000000000002);


(lib.Me_time = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt7.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt7 = new cjs.Text("15 minutes", "4px 'Segoe Pro'", "#E42364");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 7;
	this.txt7.parent = this;
	this.txt7.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt7).wait(1));

}).prototype = getMCSymbolPrototype(lib.Me_time, new cjs.Rectangle(0,0,22.7,9.4), null);


(lib.mbl_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(0.5,1,1).p("EA3RgFXMhuhAAAEA3RAFYMhuhAAA");
	this.shape.setTransform(419.6,986.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Eg68BrAMAAAjV/MB15AAAMAAADV/g");
	this.shape_1.setTransform(377.275,684.825);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.mbl_bg, new cjs.Rectangle(0,0,774.3,1369.7), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.phone_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Phone_vector resize.ai
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#121212").s().p("AABACIgBgBQgBgBAAAAQAAAAgBAAQAAgBABAAQAAAAAAgBIABACIADACIgCABIAAgBg");
	this.shape.setTransform(211.9582,22.1638,2.7441,2.5737);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B4B4B4").s().p("AgBgBIAAAAQACAAABADIAAAAIgBAAQgCAAAAgDg");
	this.shape_1.setTransform(212.115,22.0678,2.7441,2.5737);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#060606").s().p("AgFAAQAAgFAFAAQAGAAAAAFQAAAGgGAAQgFAAAAgGg");
	this.shape_2.setTransform(211.2918,22.8845,2.7441,2.5737);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#121212").s().p("AABAJIgFgGQgIgFAHgHIAFAJQADAGAGAAQgCAEgDAAIgDgBg");
	this.shape_3.setTransform(252.225,21.4838,2.7441,2.5737);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B4B4B4").s().p("AgDAEQgFgEABgHQANABADAMIgCACIgDAAQgEAAgDgEg");
	this.shape_4.setTransform(252.8417,21.1243,2.7441,2.5737);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#060606").s().p("AgOAPQgGgGAAgJQAAgIAGgGQAGgGAIAAQAIAAAHAGQAGAGAAAIQAAAJgGAGQgHAGgIAAQgIAAgGgGg");
	this.shape_5.setTransform(249.9833,24.1713,2.7441,2.5737);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#929292").s().p("ArtBaQhUAAgxguQgtgqgIhJQAHA1AeAmQAyBCBkAAIXRAAQBmAAA0hEQAlguAEg9QgEBNgqAuQgzA4hhAAg");
	this.shape_6.setTransform(258.2182,953.652,2.7408,2.572);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#E4E4E4").s().p("AODgNQg1hIhoAAI3MAAQhhAAg2BCQgmAugFA+QAEhIAlgsQAzg+BmAAIXNAAQBgAAA0A5QAqAvAEBLQgEg6gigtg");
	this.shape_7.setTransform(257.9784,22.9017,2.7408,2.572);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#121212").s().p("EggyBLvQiwgBh8h0Qh9h2AAilMAAAiJ0QAAjECTiKQCUiKDQAAMBAXAAAQCwAAB8B1QB9B0AACmMAAACK9QAAClh9B2Qh8B0iwABg");
	this.shape_8.setTransform(258.175,488.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B9B9B9").s().p("ArrdrQhZAAgzg1QgygzAAhbMAAAg1PQAAhaA0g0QA1g1BbgBIXLAAQBaABA1A1QA1A0AABaMAAAA1PQAABag1A0Qg1A1haAAg");
	this.shape_9.setTransform(258.1803,488.7475,2.743,2.5738);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#313131").s().p("AgDijQADAAABADQADACgBADIAAE3QAAAIgGAAg");
	this.shape_10.setTransform(516.5916,274.9648,2.7449,2.5754);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#313131").s().p("AABEmQgEAAAAgFIAApBQAAgFAEAAIADAAIAAJLg");
	this.shape_11.setTransform(-0.0707,228.1573,2.7449,2.5754);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_vector, new cjs.Rectangle(-1.1,-0.1,518.7,977.8000000000001), null);


(lib.Path_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfQANAAAJAKQAJAIAAANg");
	this.shape.setTransform(1.625,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3_0, new cjs.Rectangle(0,0,3.3,3.2), null);


(lib.Path_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAIIAAgPQAIAAADAFQAGADAAAHg");
	this.shape.setTransform(0.85,0.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,1.7,1.7), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ExcelIcon();
	this.instance.parent = this;
	this.instance.setTransform(47,192.15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(47,192.2,69,69), null);


(lib.grey_circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B8B8C1").s().p("AnpSJQjihgiuivQiviuhgjiQhjjqAAkAQAAj/BjjqQBgjiCviuQCuivDihgQDqhjD/AAQEAAADqBjQDiBgCuCvQCvCuBgDiQBjDqAAD/QAAEAhjDqQhgDiivCuQiuCvjiBgQjqBjkAAAQj/AAjqhjgAlds8QihBEh9B9Qh9B9hEChQhHCnAAC2QAAC3BHCnQBECiB9B8QB9B9ChBEQCnBHC2AAQC2AACohHQChhEB9h9QB8h8BFiiQBHinAAi3QAAi2hHinQhFihh8h9Qh9h9ihhEQiohHi2AAQi2AAinBHg");
	this.shape.setTransform(126,125.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.grey_circle, new cjs.Rectangle(0,0,252,252), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//top
		this.topTxt1.textBaseline = "alphabetic";
		this.topTxt3.textBaseline = "alphabetic";
		
		//menu
		
		
		
		//cell
		this.cellTxt1.textBaseline = "alphabetic";
		this.cellTxt2.textBaseline = "alphabetic";
		this.cellTxt3.textBaseline = "alphabetic";
		this.cellTxt4.textBaseline = "alphabetic";
		this.cellTxt5.textBaseline = "alphabetic";
		
		this.cellTxt18.textBaseline = "alphabetic";
		this.cellTxt19.textBaseline = "alphabetic";
		this.cellTxt20.textBaseline = "alphabetic";
		this.cellTxt21.textBaseline = "alphabetic";
		this.cellTxt22.textBaseline = "alphabetic";
		this.cellTxt23.textBaseline = "alphabetic";
		this.cellTxt24.textBaseline = "alphabetic";
		this.cellTxt25.textBaseline = "alphabetic";
		this.cellTxt26.textBaseline = "alphabetic";
		this.cellTxt27.textBaseline = "alphabetic";
		this.cellTxt28.textBaseline = "alphabetic";
		this.cellTxt29.textBaseline = "alphabetic";
		this.cellTxt30.textBaseline = "alphabetic";
		this.cellTxt31.textBaseline = "alphabetic";
		this.cellTxt32.textBaseline = "alphabetic";
		this.cellTxt33.textBaseline = "alphabetic";
		this.cellTxt34.textBaseline = "alphabetic";
		this.cellTxt35.textBaseline = "alphabetic";
		this.cellTxt36.textBaseline = "alphabetic";
		this.cellTxt37.textBaseline = "alphabetic";
		this.cellTxt38.textBaseline = "alphabetic";
		this.cellTxt39.textBaseline = "alphabetic";
		this.cellTxt40.textBaseline = "alphabetic";
		this.cellTxt41.textBaseline = "alphabetic";
		this.cellTxt42.textBaseline = "alphabetic";
		this.cellTxt43.textBaseline = "alphabetic";
		this.cellTxt44.textBaseline = "alphabetic";
		this.cellTxt45.textBaseline = "alphabetic";
		this.cellTxt46.textBaseline = "alphabetic";
		
		//other
		/*this.oTxt3.textBaseline = "alphabetic";
		this.oTxt4.textBaseline = "alphabetic";
		this.oTxt5.textBaseline = "alphabetic";
		this.oTxt6.textBaseline = "alphabetic";*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7E7E7E").s().p("AirCxQgEAAgBgDQgBgDACgCIFYlYQACgCADABQADABAAAEIAAFYQAAAEgFAAg");
	this.shape.setTransform(51.2227,282.1571,0.6742,0.6742);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// icons
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#464646").s().p("ACBAgQgNgMAAgUQAAgSANgOQANgNAUAAQAUAAANANQANAOAAASQAAAUgNAMQgNAOgUAAQgUAAgNgOgAggAgQgNgMAAgUQAAgSANgOQANgNATAAQAUAAANANQANAOAAASQAAAUgNAMQgNAOgUAAQgTAAgNgOgAjCAgQgNgMAAgUQAAgSANgOQANgNAUAAQAUAAANANQANAOAAASQAAAUgNAMQgNAOgUAAQgUAAgNgOg");
	this.shape_1.setTransform(809.425,1514.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#3F3F3F").p("AAOALIgbAAQgGAAAAgGIAAgJQAAgFAGAAIAbAAQAGAAAAAFIAAAJQAAAGgGAAg");
	this.shape_2.setTransform(71.1483,1531.932,5.4856,5.4856);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#3F3F3F").p("AAAgKIAAAV");
	this.shape_3.setTransform(82.6525,1529.2936,5.4743,5.4743);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#3F3F3F").p("Ag1AAIBrAA");
	this.shape_4.setTransform(90.1796,1502.196,5.4743,5.4743);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#3F3F3F").p("AAAgjIAABI");
	this.shape_5.setTransform(88.9479,1501.7854,5.4743,5.4743);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#3F3F3F").p("AAOALIgbAAQgFAAAAgFIAAgKQAAgFAFAAIAbAAQAFAAAAAFIAAAKQAAAFgFAAg");
	this.shape_6.setTransform(93.502,1531.932,5.4856,5.4856);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#92BCA6").s().p("AgNALQgGAAABgGIAAgJQgBgGAGABIAcAAQAEgBAAAGIAAAJQAAAGgEAAg");
	this.shape_7.setTransform(93.502,1531.932,5.4856,5.4856);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#3F3F3F").p("AAwAmIhgAAQgFAAAAgGIAAg/QAAgGAFAAIBgAAQAGAAAAAGIAAA/QAAAGgGAAg");
	this.shape_8.setTransform(90.7592,1504.9156,5.4856,5.4856);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgwAmQgFAAAAgGIAAg/QAAgGAFAAIBgAAQAGAAAAAGIAAA/QAAAGgGAAg");
	this.shape_9.setTransform(90.7592,1504.9156,5.4856,5.4856);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#525252").s().p("AgSAMQgIgBgFgFIgBgDIABgCIACgBIADABQAEADAFAAIACACIABACIgBADIgDABIAAAAgAAVAMIgDAAIgHAAIgDgBIgBgDIABgDIADgBIAHAAIADAAIACABIABADIgBADIgCABIAAAAgAABAMIgJAAIgDgBIgBgDIABgDIADgBIAJAAIADABIABADIgBADIgDABIAAAAgAAdAHIgCgBIgBgDIABgCQAEgDAAgFIABgDIACgBIADABIABADQAAAHgGAGIgDABIAAAAgAghgDIgDgBIgBgCIAAgBIABgDIADgBIACABIABADIAAABIgBACIgCACIAAgBg");
	this.shape_10.setTransform(220.7693,1509.8882,5.3745,5.3745);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#3F3F3F").ss(0.8).p("AANgJIgNAOIgMgN");
	this.shape_11.setTransform(250.511,1527.5876,5.3745,5.3745);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#3F3F3F").ss(0.8).p("AAAgpIAABT");
	this.shape_12.setTransform(250.5978,1505.7226,5.3745,5.3745);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#92BCA6").p("AAdAOIg4AAQgGAAAAgFIAAgQQAAgGAGAAIA4AAQAGAAAAAGIAAAQQAAAFgGAAg");
	this.shape_13.setTransform(220.7693,1492.8238,5.3745,5.3745);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#92BCA6").s().p("AgcAOQgFABAAgGIAAgQQAAgHAFAAIA5AAQAGAAgBAHIAAAQQABAGgGgBg");
	this.shape_14.setTransform(220.7693,1492.8238,5.3745,5.3745);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#525252").s().p("AAFAyIgBgDIABgCIADgCIAKAAIAEAAIADABIACACIgBADIgCABIgGABIgKAAIAAAAIgDgBgAgBAzIgKAAIgDgBIgBgDIABgCIADgCIAKAAIACACIABACIgBADIgCABIAAAAgAgVAyQgGgBgEgEIgDgEIgBgCIACgDIADAAIACABIACADQADACADABIADACIAAADIgCACIgBABIgBgBgAAeAqIgCgCIABgDQACgDAAgDIAAgDIABgDIACgBIADABIABADIAAADQAAAGgDAEIgDACIAAAAIgCgBgAghAiIgDgBIgBgDIAAgKIABgCIADgCIACACIABACIAAAKIgBADIgCABIAAAAgAAiAWIgCgBIgBgDIAAgKIABgDIACAAIADAAIABADIAAAKIgBADIgCABIgBAAgAghAOIgDgBIgBgDIAAgKIABgCIADgBIACABIABACIAAAKIgBADIgCABIAAAAgAAiACIgCgBIgBgCIAAgKIABgCIACgBIADABIABACIAAAKIgBACIgCABIgBAAgAghgFIgDgBIgBgDIAAgKIABgCIADgBIACABIABACIAAAKIgBADIgCABIAAAAgAAigRIgCgBIgBgDIAAgJIAAgBIABgCIACgBIADABIABACIAAABIAAAJIgBADIgCABIgBAAgAghgZIgDgBIgBgDIAAgBQAAgHAEgFIADgBIACABIACADIgBACQgDADAAAEIAAABIgBADIgCABIAAAAgAAagnQgDgEgFABIgBAAIgDgBIgBgDIABgDIADgBIABAAQAHAAAGAFIABADIgBACIgCABIAAABIgDgBgAgXgqIgCgDIABgDIACgBIAGgBIAEAAIADABIABADIgBADIgDABIgEAAIgEAAIgBAAIgCAAgAAHgqIgJAAIgDgBIgBgDIABgDIADgBIAJAAIADABIABADIgBADIgDABIAAAAg");
	this.shape_15.setTransform(220.7693,1510.4244,5.3745,5.3745);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#3F3F3F").p("AARAAIghAA");
	this.shape_16.setTransform(374.3128,1501.1097,5.38,5.38);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#3F3F3F").p("ABxjEQA3AAAEAfQAFATgRAXQgSAZgyA5QgJAJgJAKQgPAQgQARIAACbQAAAhgvgCQgVgDgJgOIgFgQIAAiVQhZhBgkhGQgOgYAJgTQAMgcA5gCg");
	this.shape_17.setTransform(375.85,1513.7,1.1412,1.1412,0,0,0,1,0.6);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#9E83BF").s().p("Ag1BKIAAgLIBRh4IAAAAIhKAAIAAgQIBjAAIAAALIhRB3IAAABIBSAAIAAAQg");
	this.shape_18.setTransform(335.625,1531.675);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#71A7D8").s().p("AAqBKIgQguIg0AAIgPAuIgUAAIAyiTIAWAAIAzCTgAAWANIgPgqIgEgOIgDgNIgDANIgEAOIgPAqIAsAAg");
	this.shape_19.setTransform(334.625,1504.225);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3F3F3F").s().p("AgNAbIgRgRQgCgDAAgDQAAgDACgDIADgCIADAEIgCABIgBADIABACIARARQACADADgDIAVgWQAAgBABAAQAAAAAAAAQAAgBAAgBQgBAAAAgBIgRgRIgCgBIgCABIgOAOIgDgEIAAAAIAIgIIABgBQgIACgDADQgBADACAEQADAFAEAAQAFABAIgEIgBAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAgBQABAAAAAAQAAgBAAAAQABAAAAAAQABgBAAAAQAGAAAAAHQAAAFgGAAIgCgBQgIAEgFAAIgDAAQgHgCgDgGQgEgHADgEQAFgJAOACIAFgFIASASQAGgBAFABQAJADgCAPQgDAbgDgbIgBgFQgBgCAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAIACABIgaAbQgDACgDAAQgDAAgDgCg");
	this.shape_20.setTransform(496.1986,1499.6242,5.3896,5.3896);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3F3F3F").s().p("Ag2AOIAAgbIBtAAIAAAbg");
	this.shape_21.setTransform(494.5928,1530.8807,5.3972,5.3972);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3F3F3F").s().p("AgGA0QgEAAgDgDQgDgDAAgEIAAgOQAAgNgJgLQgLgKACgQQACgMAJgIQAKgJANAAQAOAAALAKQAKAKAAAOQAAANgJAJQgJAJAAAOIAAAOQAAAEgDADQgDADgEAAgAgKAqQAAAFAEAAIANAAQAFAAAAgFIAAgGIgWAAgAgTgmQgIAHgCAKQgBANAJAJQAKAMAAAPIAAADIAWAAIAAgDQAAgRALgJQAIgIAAgLQAAgMgJgIQgJgJgMAAQgLAAgIAIg");
	this.shape_22.setTransform(619.7062,1507.8736,5.2294,5.2294);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// grid
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#999999").ss(1,1,1).p("EAlRAEhIAApBEBDjAEhI+SAAMgsPAAAIAApBAYjEeIAAo+Eg3dAEhIsFAAEguQAEYIAAo4Eg3agEOIAAIvMAwcAAA");
	this.shape_23.setTransform(445.675,281.825);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#999999").ss(2,1,1).p("Eg3dgJCIsFAAEAtIAJEIAAxyEBDjgJCMh69AAA");
	this.shape_24.setTransform(445.675,1525.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23}]}).wait(1));

	// Layer 1
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#D3D3D3").s().p("EAGICysIAAhZIsjAAIAAgUIMjAAIAAlNIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAuhIsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAryIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAAuhIsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAuhIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAArzIsjAAIAAgUIMjAAIAAr0IsjAAIAAgUIMjAAIAAulIsjAAIAAgUIM3AAMAAAFlXg");
	this.shape_25.setTransform(32.5549,888.1003,0.5053,0.5053);

	this.timeline.addTween(cjs.Tween.get(this.shape_25).wait(1));

	// Layer_9
	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("EhEMAIQIAAwfMCIZAAAIAAQfg");
	this.shape_26.setTransform(440.625,1519.025);

	this.timeline.addTween(cjs.Tween.get(this.shape_26).wait(1));

	// txt
	this.cellTxt41 = new cjs.Text("16", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt41.name = "cellTxt41";
	this.cellTxt41.textAlign = "center";
	this.cellTxt41.lineHeight = 19;
	this.cellTxt41.lineWidth = 15;
	this.cellTxt41.parent = this;
	this.cellTxt41.setTransform(32,1275.75,1.9717,1.9717);

	this.cellTxt42 = new cjs.Text("17", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt42.name = "cellTxt42";
	this.cellTxt42.textAlign = "center";
	this.cellTxt42.lineHeight = 19;
	this.cellTxt42.lineWidth = 15;
	this.cellTxt42.parent = this;
	this.cellTxt42.setTransform(32,1314.8,1.9717,1.9717);

	this.cellTxt43 = new cjs.Text("18", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt43.name = "cellTxt43";
	this.cellTxt43.textAlign = "center";
	this.cellTxt43.lineHeight = 19;
	this.cellTxt43.lineWidth = 15;
	this.cellTxt43.parent = this;
	this.cellTxt43.setTransform(32,1353.4,1.9717,1.9717);

	this.cellTxt44 = new cjs.Text("19", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt44.name = "cellTxt44";
	this.cellTxt44.textAlign = "center";
	this.cellTxt44.lineHeight = 19;
	this.cellTxt44.lineWidth = 15;
	this.cellTxt44.parent = this;
	this.cellTxt44.setTransform(32,1401.2,1.9717,1.9717);

	this.cellTxt45 = new cjs.Text("20", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt45.name = "cellTxt45";
	this.cellTxt45.textAlign = "center";
	this.cellTxt45.lineHeight = 19;
	this.cellTxt45.lineWidth = 15;
	this.cellTxt45.parent = this;
	this.cellTxt45.setTransform(32,1440.45,1.9717,1.9717);

	this.cellTxt46 = new cjs.Text("21", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt46.name = "cellTxt46";
	this.cellTxt46.textAlign = "center";
	this.cellTxt46.lineHeight = 19;
	this.cellTxt46.lineWidth = 15;
	this.cellTxt46.parent = this;
	this.cellTxt46.setTransform(31.45,1479.65,1.9717,1.9717);

	this.cellTxt39 = new cjs.Text("14", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt39.name = "cellTxt39";
	this.cellTxt39.textAlign = "center";
	this.cellTxt39.lineHeight = 19;
	this.cellTxt39.lineWidth = 15;
	this.cellTxt39.parent = this;
	this.cellTxt39.setTransform(32,1196.35,1.9717,1.9717);

	this.cellTxt40 = new cjs.Text("15", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt40.name = "cellTxt40";
	this.cellTxt40.textAlign = "center";
	this.cellTxt40.lineHeight = 19;
	this.cellTxt40.lineWidth = 15;
	this.cellTxt40.parent = this;
	this.cellTxt40.setTransform(32,1235.55,1.9717,1.9717);

	this.cellTxt33 = new cjs.Text("16", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt33.name = "cellTxt33";
	this.cellTxt33.textAlign = "center";
	this.cellTxt33.lineHeight = 19;
	this.cellTxt33.lineWidth = 15;
	this.cellTxt33.parent = this;
	this.cellTxt33.setTransform(32,954.5,1.9717,1.9717);

	this.cellTxt34 = new cjs.Text("17", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt34.name = "cellTxt34";
	this.cellTxt34.textAlign = "center";
	this.cellTxt34.lineHeight = 19;
	this.cellTxt34.lineWidth = 15;
	this.cellTxt34.parent = this;
	this.cellTxt34.setTransform(32,993.55,1.9717,1.9717);

	this.cellTxt35 = new cjs.Text("18", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt35.name = "cellTxt35";
	this.cellTxt35.textAlign = "center";
	this.cellTxt35.lineHeight = 19;
	this.cellTxt35.lineWidth = 15;
	this.cellTxt35.parent = this;
	this.cellTxt35.setTransform(32,1032.15,1.9717,1.9717);

	this.cellTxt36 = new cjs.Text("19", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt36.name = "cellTxt36";
	this.cellTxt36.textAlign = "center";
	this.cellTxt36.lineHeight = 19;
	this.cellTxt36.lineWidth = 15;
	this.cellTxt36.parent = this;
	this.cellTxt36.setTransform(32,1079.95,1.9717,1.9717);

	this.cellTxt37 = new cjs.Text("20", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt37.name = "cellTxt37";
	this.cellTxt37.textAlign = "center";
	this.cellTxt37.lineHeight = 19;
	this.cellTxt37.lineWidth = 15;
	this.cellTxt37.parent = this;
	this.cellTxt37.setTransform(32,1119.2,1.9717,1.9717);

	this.cellTxt38 = new cjs.Text("21", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt38.name = "cellTxt38";
	this.cellTxt38.textAlign = "center";
	this.cellTxt38.lineHeight = 19;
	this.cellTxt38.lineWidth = 15;
	this.cellTxt38.parent = this;
	this.cellTxt38.setTransform(31.45,1158.4,1.9717,1.9717);

	this.cellTxt18 = new cjs.Text("1", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt18.name = "cellTxt18";
	this.cellTxt18.textAlign = "center";
	this.cellTxt18.lineHeight = 19;
	this.cellTxt18.parent = this;
	this.cellTxt18.setTransform(31.05,349.35,1.9717,1.9717);

	this.cellTxt19 = new cjs.Text("2", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt19.name = "cellTxt19";
	this.cellTxt19.textAlign = "center";
	this.cellTxt19.lineHeight = 19;
	this.cellTxt19.parent = this;
	this.cellTxt19.setTransform(31,389.3,1.9717,1.9717);

	this.cellTxt20 = new cjs.Text("3", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt20.name = "cellTxt20";
	this.cellTxt20.textAlign = "center";
	this.cellTxt20.lineHeight = 19;
	this.cellTxt20.parent = this;
	this.cellTxt20.setTransform(31.35,428.25,1.9717,1.9717);

	this.cellTxt21 = new cjs.Text("4", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt21.name = "cellTxt21";
	this.cellTxt21.textAlign = "center";
	this.cellTxt21.lineHeight = 19;
	this.cellTxt21.parent = this;
	this.cellTxt21.setTransform(31,467.4,1.9717,1.9717);

	this.cellTxt22 = new cjs.Text("5", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt22.name = "cellTxt22";
	this.cellTxt22.textAlign = "center";
	this.cellTxt22.lineHeight = 19;
	this.cellTxt22.parent = this;
	this.cellTxt22.setTransform(31,514.2,1.9717,1.9717);

	this.cellTxt23 = new cjs.Text("6", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt23.name = "cellTxt23";
	this.cellTxt23.textAlign = "center";
	this.cellTxt23.lineHeight = 19;
	this.cellTxt23.parent = this;
	this.cellTxt23.setTransform(31,553.85,1.9717,1.9717);

	this.cellTxt24 = new cjs.Text("7", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt24.name = "cellTxt24";
	this.cellTxt24.textAlign = "center";
	this.cellTxt24.lineHeight = 19;
	this.cellTxt24.lineWidth = 8;
	this.cellTxt24.parent = this;
	this.cellTxt24.setTransform(31.05,592.75,1.9717,1.9717);

	this.cellTxt25 = new cjs.Text("8", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt25.name = "cellTxt25";
	this.cellTxt25.textAlign = "center";
	this.cellTxt25.lineHeight = 19;
	this.cellTxt25.lineWidth = 8;
	this.cellTxt25.parent = this;
	this.cellTxt25.setTransform(31.05,632.2,1.9717,1.9717);

	this.cellTxt26 = new cjs.Text("9", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt26.name = "cellTxt26";
	this.cellTxt26.textAlign = "center";
	this.cellTxt26.lineHeight = 19;
	this.cellTxt26.lineWidth = 8;
	this.cellTxt26.parent = this;
	this.cellTxt26.setTransform(31.05,671.05,1.9717,1.9717);

	this.cellTxt27 = new cjs.Text("10", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt27.name = "cellTxt27";
	this.cellTxt27.textAlign = "center";
	this.cellTxt27.lineHeight = 19;
	this.cellTxt27.lineWidth = 15;
	this.cellTxt27.parent = this;
	this.cellTxt27.setTransform(32,710.4,1.9717,1.9717);

	this.cellTxt28 = new cjs.Text("11", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt28.name = "cellTxt28";
	this.cellTxt28.textAlign = "center";
	this.cellTxt28.lineHeight = 19;
	this.cellTxt28.lineWidth = 15;
	this.cellTxt28.parent = this;
	this.cellTxt28.setTransform(32,749.45,1.9717,1.9717);

	this.cellTxt29 = new cjs.Text("12", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt29.name = "cellTxt29";
	this.cellTxt29.textAlign = "center";
	this.cellTxt29.lineHeight = 19;
	this.cellTxt29.lineWidth = 15;
	this.cellTxt29.parent = this;
	this.cellTxt29.setTransform(32,788.05,1.9717,1.9717);

	this.cellTxt30 = new cjs.Text("13", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt30.name = "cellTxt30";
	this.cellTxt30.textAlign = "center";
	this.cellTxt30.lineHeight = 19;
	this.cellTxt30.lineWidth = 15;
	this.cellTxt30.parent = this;
	this.cellTxt30.setTransform(32,835.85,1.9717,1.9717);

	this.cellTxt31 = new cjs.Text("14", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt31.name = "cellTxt31";
	this.cellTxt31.textAlign = "center";
	this.cellTxt31.lineHeight = 19;
	this.cellTxt31.lineWidth = 15;
	this.cellTxt31.parent = this;
	this.cellTxt31.setTransform(32,875.1,1.9717,1.9717);

	this.cellTxt32 = new cjs.Text("15", "12px 'Segoe Pro'", "#2D2D2C");
	this.cellTxt32.name = "cellTxt32";
	this.cellTxt32.textAlign = "center";
	this.cellTxt32.lineHeight = 19;
	this.cellTxt32.lineWidth = 15;
	this.cellTxt32.parent = this;
	this.cellTxt32.setTransform(32,914.3,1.9717,1.9717);

	this.cellTxt1 = new cjs.Text("A", "14px 'Segoe Pro'", "#212120");
	this.cellTxt1.name = "cellTxt1";
	this.cellTxt1.lineHeight = 21;
	this.cellTxt1.parent = this;
	this.cellTxt1.setTransform(111.1,290.7,1.9717,1.9717);

	this.cellTxt2 = new cjs.Text("B", "14px 'Segoe Pro'", "#212120");
	this.cellTxt2.name = "cellTxt2";
	this.cellTxt2.lineHeight = 21;
	this.cellTxt2.parent = this;
	this.cellTxt2.setTransform(267.55,290.6,1.9717,1.9717);

	this.cellTxt3 = new cjs.Text("C", "14px 'Segoe Pro'", "#212120");
	this.cellTxt3.name = "cellTxt3";
	this.cellTxt3.lineHeight = 21;
	this.cellTxt3.parent = this;
	this.cellTxt3.setTransform(493.05,289.9,1.9717,1.9717);

	this.cellTxt4 = new cjs.Text("D", "14px 'Segoe Pro'", "#212120");
	this.cellTxt4.name = "cellTxt4";
	this.cellTxt4.lineHeight = 21;
	this.cellTxt4.parent = this;
	this.cellTxt4.setTransform(634.95,289.9,1.9717,1.9717);

	this.cellTxt5 = new cjs.Text("E", "14px 'Segoe Pro'", "#212120");
	this.cellTxt5.name = "cellTxt5";
	this.cellTxt5.lineHeight = 21;
	this.cellTxt5.parent = this;
	this.cellTxt5.setTransform(772.3,289.9,1.9717,1.9717);

	this.topTxt1 = new cjs.Text("1:16 PM", "16px 'Segoe Pro'", "#FFFFFF");
	this.topTxt1.name = "topTxt1";
	this.topTxt1.lineHeight = 24;
	this.topTxt1.parent = this;
	this.topTxt1.setTransform(396.75,48.55,1.9717,1.9717);

	this.topTxt3 = new cjs.Text("Fitness Vision", "15px 'Segoe Pro'", "#FFFFFF");
	this.topTxt3.name = "topTxt3";
	this.topTxt3.textAlign = "center";
	this.topTxt3.lineHeight = 23;
	this.topTxt3.lineWidth = 198;
	this.topTxt3.parent = this;
	this.topTxt3.setTransform(447.65,90.2,1.9717,1.9717);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.topTxt3},{t:this.topTxt1},{t:this.cellTxt5},{t:this.cellTxt4},{t:this.cellTxt3},{t:this.cellTxt2},{t:this.cellTxt1},{t:this.cellTxt32},{t:this.cellTxt31},{t:this.cellTxt30},{t:this.cellTxt29},{t:this.cellTxt28},{t:this.cellTxt27},{t:this.cellTxt26},{t:this.cellTxt25},{t:this.cellTxt24},{t:this.cellTxt23},{t:this.cellTxt22},{t:this.cellTxt21},{t:this.cellTxt20},{t:this.cellTxt19},{t:this.cellTxt18},{t:this.cellTxt38},{t:this.cellTxt37},{t:this.cellTxt36},{t:this.cellTxt35},{t:this.cellTxt34},{t:this.cellTxt33},{t:this.cellTxt40},{t:this.cellTxt39},{t:this.cellTxt46},{t:this.cellTxt45},{t:this.cellTxt44},{t:this.cellTxt43},{t:this.cellTxt42},{t:this.cellTxt41}]}).wait(1));

	// Layer 1
	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#136B3B").s().p("A+KAjIAAhFMA8VAAAIAABFg");
	this.shape_27.setTransform(779.049,308.5648,0.4916,0.4916);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#D2D2D2").s().p("A+KHXIAAutMA8VAAAIAAOtg");
	this.shape_28.setTransform(779.049,280.3988,0.4916,0.5969);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27}]}).wait(1));

	// UI_BG
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#F4F4F4").s().p("EgGTCyoMAAAllPIMoAAMAAAFlPg");
	this.shape_29.setTransform(32.3822,888.9847,0.5057,0.5057);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("ABVDfIjMjNQgHgIAAgKQAAgJAHgHIDMjOQAHgGAKgBQALABAHAGQAHAIAAAKQAAAKgHAHIi7C7IC7C8QAHAHAAALQAAAJgHAIQgHAGgLAAQgKAAgHgGg");
	this.shape_30.setTransform(56.8509,125.3521);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("ACBAgQgNgMAAgUQAAgSANgOQANgNAUAAQAUAAANANQANAOAAASQAAAUgNAMQgNAOgUAAQgUAAgNgOgAggAgQgNgMAAgUQAAgSANgOQANgNATAAQAUAAANANQANAOAAASQAAAUgNAMQgNAOgUAAQgTAAgNgOgAjCAgQgNgMAAgUQAAgSANgOQANgNAUAAQAUAAANANQANAOAAASQAAAUgNAMQgNAOgUAAQgUAAgNgOg");
	this.shape_31.setTransform(831.3877,126.5017);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#484B4B").ss(1.5,1,1).p("Ag9gbIA9A5IA+g7");
	this.shape_32.setTransform(832.0961,210.9596,1.961,1.961);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#C6C6C6").ss(1,2,1).p("AAAidIAAE7");
	this.shape_33.setTransform(113.9183,214.4405,1.961,1.961);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#777777").s().p("AhOBrQAAgMALAAQAJAAACANQAAABAAABQAAAAABABQAAAAABAAQAAABABAAQARAAAOhDIAShLIgfAAQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBAAAAIADgOIACgBIAgAAQAMgqALgOQAPgSASABQAXgBAAARQAAAMgKAAQgKAAgCgLQAAgIgHABQgLgBgIAWQgEAKgIAgIAkAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAIgDAOQAAAAAAABQAAAAgBABQAAAAAAAAQAAABgBAAIgjAAQgPA7gGAXQgVBGghAAQgTAAAAgPg");
	this.shape_34.setTransform(65.0672,215.1463,1.6331,1.6331);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#777777").ss(0.8).p("AgCgXIADAFIADAKIAFgHQACgDACgCIAFgDIACAAQADAAABABIABADIAAADQgCABgCAAIgCAAQgCgBgBAAIgDABQgEADgEAIIAGAWIABABIADgCQACgCADgEIABABQgDAGgFAEQgDADgCAAQgDAAgCgEIgDgRQgJAOgEAEQgEADgCAAQgDAAgBgCIgCgDQAAgCACgBQAAgBACAAQACAAACACQABABABAAIACgBQADgDADgGIAGgJIgDgNQgCgEgCgBQgCgBgDAAIgDAAIAAgCg");
	this.shape_35.setTransform(78.3535,222.8827,2.9434,2.9434);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#777777").s().p("AADAVIgDgSQgIAPgFAEQgDADgDAAQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBgBAAAAIgCgDQAAAAABgBQAAAAAAgBQAAAAAAAAQABgBAAAAIADgBQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAABIACAAIACAAQADgDADgGIAHgJIgEgNIgEgFIgFgBIgDAAIAAgCIAOgDIADAGIADAKIAFgHIAFgFIAEgDIACgBQABAAABABQAAAAABAAQAAAAABAAQAAABABAAIABADIgBACQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAIgCgBIgDgBIgDACQgEADgEAHIAGAXIABAAIADgBIAFgGIABABQgDAGgEAEIgGADQgCAAgDgEg");
	this.shape_36.setTransform(78.3297,222.9522,2.9434,2.9434);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#C6C6C6").ss(1,1,1).p("Egg/gCtMBB/AAAQAeAAAAAeIAAEfQAAAegeAAMhB/AAAQgeAAAAgeIAAkfQAAgeAeAAg");
	this.shape_37.setTransform(442.6224,214.4895,1.9612,1.961);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("Egg/ACuQgeAAAAgeIAAkfQAAgeAeAAMBB/AAAQAeAAAAAeIAAEfQAAAegeAAg");
	this.shape_38.setTransform(442.6224,214.4895,1.9612,1.961);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#FFFFFF").ss(1.5,1,0,3).p("Ahfg9ICMAAQAaAAANATQANARgBAZQgBAZgNASQgOATgXAAIgWAA");
	this.shape_39.setTransform(431.9475,135.6566,1.9603,1.9603);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#FFFFFF").ss(1.5,1,0,3).p("AAhg9Ig+A9IA+A/");
	this.shape_40.setTransform(417.7664,123.7966,1.9603,1.9603);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F2F2F2").s().p("AhUBWIgBAAIAAgDIALgvIAAgBIBwhxQAIgIANAAQALAAAIAIQAIAJAAAMQAAALgIAIIhwBxIgBAAIAAABIgvALgAhGBGQADADgDADIgDABIAhgHIADgPIgQADIgCAAIgBgBIAAgCIgBAAIAAgBIACgPIgNABIgJAhIADgDQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAAAAAIADACgAAmgUQABABAAABQABAAAAABQAAAAgBABQAAAAgBABIhFBFIAAAJIBUhVIgegfIhWBWIAKgBIBFhGQABAAAAAAQABAAAAAAQABAAAAAAQABAAAAAAQABABAAABQABAAAAABQAAAAgBABQAAAAgBABIhFBFIgCAPIAQgBIBFhGIACAAIACAAgAAbg5IAgAeIAEgEIgggfgAAlhCIAeAfIAEgFIgegfgAAthLIAeAfQALgOgMgPQgIgHgIAAQgHAAgGAFg");
	this.shape_41.setTransform(537.5514,134.9269,1.9461,1.9461);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#F2F2F2").s().p("ABUCWIgghfIhpAAIggBfIgnAAIBmkrIAuAAIBmErgAAtAaIgehWIgJgcIgGgbIAAAAIgIAbIgIAcIgdBWIBaAAg");
	this.shape_42.setTransform(522.4,133.05);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#FFFFFF").ss(2.5,1,0,3).p("AA7A9Ih1h5");
	this.shape_43.setTransform(645.0348,140.6772);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#FFFFFF").ss(2.5,1,0,3).p("ACcAAQAABAguAuQguAuhAAAQg/AAguguQguguAAhAQAAg/AuguQAuguA/AAQBAAAAuAuQAuAuAAA/g");
	this.shape_44.setTransform(628.0346,123.7269);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AAGATQgHAAgHABIgOAEIgMAIQgGADgFAGIAAgHQAAgIACgGIAFgNQADgGAEgDIALgIQAEgDAIgDIAOgCIAAgWIAoAoIgoApgAgFgJIgGACIgJAGQgEABgEAFIgGAJQgCAEgBAGQAJgGALgDQALgEAMAAIAHAAIAAAMIAXgXIgXgWIAAAMIgGAAg");
	this.shape_45.setTransform(735.8216,121.2731,4.2475,4.2475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AhYBAIAAh/IAMAAIAABzICaAAIAAglIALAAIAAAxg");
	this.shape_46.setTransform(725.0829,137.936,1.995,1.995);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#E6E6E6").s().p("EhEmALZIAA2xMCJNAAAIAAWxg");
	this.shape_47.setTransform(433.35,237.45);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#257247").s().p("EhEmAMOIAA4bMCJNAAAIAAYbg");
	this.shape_48.setTransform(433.3566,86.3513);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(-5.8,8.2,884.8,1576.1), null);


(lib.logoc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AhlB3QgngpAAhNQAAhGArguQAqgtA/AAQA/gBAjApQAjApAABIIAAAaIjSAAQACArAZAXQAZAYArAAQAxgBApgdIAAA4QgpAahGABQhDgBgngqgAgrhXQgVAXgFAiICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape.setTransform(223.15,-128.65,0.2361,0.2361,0,0,0,0.1,-0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AhNB3QgrgrAAhEQAAhMAuguQAugvBKABQArgBAgAQIAABBQgggZglAAQgsAAgcAeQgcAfAAAvQAAAwAbAcQAZAbAtAAQAmAAAhgaIAAA8QglAWgyAAQhFgBgpgqg");
	this.shape_1.setTransform(216.55,-128.65,0.2361,0.2361,0,0,0,0,-0.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgjDiIAAkzIBFAAIAAEzgAgdidQgMgMAAgRQAAgQAMgMQANgLAQAAQARAAANALQAMAMAAAQQAAAQgMAMQgNAMgRAAQgRAAgMgLg");
	this.shape_2.setTransform(211.9,-130.35,0.2361,0.2361,0,0,0,0.1,-0.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgyAAAAA6IAAApIBHAAIAAA3IhHAAIAAD9g");
	this.shape_3.setTransform(208.0346,-130.4787,0.2361,0.2361);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgzAAAAA6IAAApIBIAAIAAA3IhHAAIAAD9g");
	this.shape_4.setTransform(203.45,-130.45,0.2361,0.2361,0,0,0,0.1,-0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AiWCjQg4g9gBhhQABhnA5g+QA5g+BiAAQBaAAA4A8QA4A8gBBiQAABog4A+Qg5A9heAAQheAAg4g8gAhehzQglAtAABHQAABIAkAsQAkAsA7AAQA9AAAkgqQAkgqAAhLQgBhMgigrQgjgqg9AAQg7AAglAsg");
	this.shape_5.setTransform(195.9,-130.15,0.2361,0.2361,0,0,0,0.3,-0.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_6.setTransform(120.1,-125.65,0.2361,0.2361,0,0,0,0,-0.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_7.setTransform(111.15,-125.65,0.2361,0.2361,0,0,0,0.1,-0.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(120.1,-134.65,0.2361,0.2361,0,0,0,0,-0.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(111.15,-134.65,0.2361,0.2361,0,0,0,0.1,-0.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_10.setTransform(158.05,-130.4,0.2361,0.2361,0,0,0,0,-0.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_11.setTransform(248.4,-130.05,0.2361,0.2361,0,0,0,0.1,-0.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_12.setTransform(241.1985,-130.0892,0.2361,0.2361);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_13.setTransform(233.8,-130.05,0.2361,0.2361,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoc, new cjs.Rectangle(107.2,-138.6,144.2,17), null);


(lib.displaytxt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Display Settings", "3px 'Segoe Pro'", "#626262");
	this.txt.name = "txt";
	this.txt.lineHeight = 5;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(6.3,-2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.displaytxt, new cjs.Rectangle(4.3,-4,24.8,10), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.ColumnsAndRows_ = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.a.textBaseline = "alphabetic"
		this.b.textBaseline = "alphabetic"
		this.c.textBaseline = "alphabetic"
		this.d.textBaseline = "alphabetic"
		this.e.textBaseline = "alphabetic"
		this.f.textBaseline = "alphabetic"
		this.g.textBaseline = "alphabetic"
		this.h.textBaseline = "alphabetic"
		this.i.textBaseline = "alphabetic"
		this.j.textBaseline = "alphabetic"
		this.k.textBaseline = "alphabetic"
		this.l.textBaseline = "alphabetic"
		this.m.textBaseline = "alphabetic"
		this.n.textBaseline = "alphabetic"
		this.o.textBaseline = "alphabetic"
		this.p.textBaseline = "alphabetic"
		this.q.textBaseline = "alphabetic"
		this.num1.textBaseline = "alphabetic"
		this.num2.textBaseline = "alphabetic"
		this.num3.textBaseline = "alphabetic"
		this.num4.textBaseline = "alphabetic"
		this.num5.textBaseline = "alphabetic"
		this.num6.textBaseline = "alphabetic"
		this.num7.textBaseline = "alphabetic"
		this.num8.textBaseline = "alphabetic"
		this.num9.textBaseline = "alphabetic"
		this.num10.textBaseline = "alphabetic"
		this.num11.textBaseline = "alphabetic"
		this.num12.textBaseline = "alphabetic"
		this.num13.textBaseline = "alphabetic"
		this.num14.textBaseline = "alphabetic"
		this.num15.textBaseline = "alphabetic"
		this.num16.textBaseline = "alphabetic"
		this.num17.textBaseline = "alphabetic"
		this.num18.textBaseline = "alphabetic"
		this.num19.textBaseline = "alphabetic"
		this.num20.textBaseline = "alphabetic"
		this.num21.textBaseline = "alphabetic"
		this.num22.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// columns&rows
	this.num22 = new cjs.Text("22", "3px 'Segoe Pro'", "#2D2D2C");
	this.num22.name = "num22";
	this.num22.textAlign = "center";
	this.num22.lineHeight = 5;
	this.num22.lineWidth = 8;
	this.num22.parent = this;
	this.num22.setTransform(-79.9,22.25);

	this.num21 = new cjs.Text("21", "3px 'Segoe Pro'", "#2D2D2C");
	this.num21.name = "num21";
	this.num21.textAlign = "center";
	this.num21.lineHeight = 5;
	this.num21.lineWidth = 8;
	this.num21.parent = this;
	this.num21.setTransform(-79.9,18.45);

	this.num20 = new cjs.Text("20", "3px 'Segoe Pro'", "#2D2D2C");
	this.num20.name = "num20";
	this.num20.textAlign = "center";
	this.num20.lineHeight = 5;
	this.num20.lineWidth = 8;
	this.num20.parent = this;
	this.num20.setTransform(-79.9,14.9);

	this.num19 = new cjs.Text("19", "3px 'Segoe Pro'", "#2D2D2C");
	this.num19.name = "num19";
	this.num19.textAlign = "center";
	this.num19.lineHeight = 5;
	this.num19.lineWidth = 8;
	this.num19.parent = this;
	this.num19.setTransform(-79.9,11.7);

	this.num18 = new cjs.Text("18", "3px 'Segoe Pro'", "#2D2D2C");
	this.num18.name = "num18";
	this.num18.textAlign = "center";
	this.num18.lineHeight = 5;
	this.num18.lineWidth = 8;
	this.num18.parent = this;
	this.num18.setTransform(-79.9,8);

	this.num17 = new cjs.Text("17", "3px 'Segoe Pro'", "#2D2D2C");
	this.num17.name = "num17";
	this.num17.textAlign = "center";
	this.num17.lineHeight = 5;
	this.num17.lineWidth = 8;
	this.num17.parent = this;
	this.num17.setTransform(-79.9,5.2);

	this.num16 = new cjs.Text("16", "3px 'Segoe Pro'", "#2D2D2C");
	this.num16.name = "num16";
	this.num16.textAlign = "center";
	this.num16.lineHeight = 5;
	this.num16.lineWidth = 8;
	this.num16.parent = this;
	this.num16.setTransform(-79.9,1.55);

	this.num15 = new cjs.Text("15", "3px 'Segoe Pro'", "#2D2D2C");
	this.num15.name = "num15";
	this.num15.textAlign = "center";
	this.num15.lineHeight = 5;
	this.num15.lineWidth = 8;
	this.num15.parent = this;
	this.num15.setTransform(-79.9,-1.7);

	this.num14 = new cjs.Text("14", "3px 'Segoe Pro'", "#2D2D2C");
	this.num14.name = "num14";
	this.num14.textAlign = "center";
	this.num14.lineHeight = 5;
	this.num14.lineWidth = 8;
	this.num14.parent = this;
	this.num14.setTransform(-79.9,-4.85);

	this.num13 = new cjs.Text("13", "3px 'Segoe Pro'", "#2D2D2C");
	this.num13.name = "num13";
	this.num13.textAlign = "center";
	this.num13.lineHeight = 5;
	this.num13.lineWidth = 8;
	this.num13.parent = this;
	this.num13.setTransform(-79.9,-8.15);

	this.num12 = new cjs.Text("12", "3px 'Segoe Pro'", "#2D2D2C");
	this.num12.name = "num12";
	this.num12.textAlign = "center";
	this.num12.lineHeight = 5;
	this.num12.lineWidth = 8;
	this.num12.parent = this;
	this.num12.setTransform(-79.9,-11.35);

	this.num11 = new cjs.Text("11", "3px 'Segoe Pro'", "#2D2D2C");
	this.num11.name = "num11";
	this.num11.textAlign = "center";
	this.num11.lineHeight = 5;
	this.num11.lineWidth = 8;
	this.num11.parent = this;
	this.num11.setTransform(-79.9,-14.65);

	this.num10 = new cjs.Text("10", "3px 'Segoe Pro'", "#2D2D2C");
	this.num10.name = "num10";
	this.num10.textAlign = "center";
	this.num10.lineHeight = 5;
	this.num10.lineWidth = 8;
	this.num10.parent = this;
	this.num10.setTransform(-79.9,-18.05);

	this.num9 = new cjs.Text("9", "3px 'Segoe Pro'", "#2D2D2C");
	this.num9.name = "num9";
	this.num9.textAlign = "center";
	this.num9.lineHeight = 5;
	this.num9.lineWidth = 6;
	this.num9.parent = this;
	this.num9.setTransform(-79.85,-21.4);

	this.num8 = new cjs.Text("8", "3px 'Segoe Pro'", "#2D2D2C");
	this.num8.name = "num8";
	this.num8.textAlign = "center";
	this.num8.lineHeight = 5;
	this.num8.lineWidth = 6;
	this.num8.parent = this;
	this.num8.setTransform(-79.85,-24.55);

	this.num7 = new cjs.Text("7", "3px 'Segoe Pro'", "#2D2D2C");
	this.num7.name = "num7";
	this.num7.textAlign = "center";
	this.num7.lineHeight = 5;
	this.num7.lineWidth = 6;
	this.num7.parent = this;
	this.num7.setTransform(-79.85,-27.75);

	this.num6 = new cjs.Text("6", "3px 'Segoe Pro'", "#2D2D2C");
	this.num6.name = "num6";
	this.num6.textAlign = "center";
	this.num6.lineHeight = 5;
	this.num6.lineWidth = 6;
	this.num6.parent = this;
	this.num6.setTransform(-79.85,-31);

	this.num5 = new cjs.Text("5", "3px 'Segoe Pro'", "#2D2D2C");
	this.num5.name = "num5";
	this.num5.textAlign = "center";
	this.num5.lineHeight = 5;
	this.num5.lineWidth = 6;
	this.num5.parent = this;
	this.num5.setTransform(-79.85,-34.3);

	this.num4 = new cjs.Text("4", "3px 'Segoe Pro'", "#2D2D2C");
	this.num4.name = "num4";
	this.num4.textAlign = "center";
	this.num4.lineHeight = 5;
	this.num4.lineWidth = 6;
	this.num4.parent = this;
	this.num4.setTransform(-79.85,-37.55);

	this.num3 = new cjs.Text("3", "3px 'Segoe Pro'", "#2D2D2C");
	this.num3.name = "num3";
	this.num3.textAlign = "center";
	this.num3.lineHeight = 5;
	this.num3.lineWidth = 6;
	this.num3.parent = this;
	this.num3.setTransform(-79.85,-40.75);

	this.num2 = new cjs.Text("2", "3px 'Segoe Pro'", "#2D2D2C");
	this.num2.name = "num2";
	this.num2.textAlign = "center";
	this.num2.lineHeight = 5;
	this.num2.lineWidth = 6;
	this.num2.parent = this;
	this.num2.setTransform(-79.85,-43.95);

	this.num1 = new cjs.Text("1", "3px 'Segoe Pro'", "#2D2D2C");
	this.num1.name = "num1";
	this.num1.textAlign = "center";
	this.num1.lineHeight = 5;
	this.num1.lineWidth = 6;
	this.num1.parent = this;
	this.num1.setTransform(-79.85,-47.4);

	this.a = new cjs.Text("A", "3px 'Segoe Pro'", "#2D2D2C");
	this.a.name = "a";
	this.a.lineHeight = 5;
	this.a.lineWidth = 6;
	this.a.parent = this;
	this.a.setTransform(-75.05,-51.2);

	this.b = new cjs.Text("B", "3px 'Segoe Pro'", "#2D2D2C");
	this.b.name = "b";
	this.b.lineHeight = 5;
	this.b.lineWidth = 6;
	this.b.parent = this;
	this.b.setTransform(-65.2,-51.2);

	this.c = new cjs.Text("C", "3px 'Segoe Pro'", "#2D2D2C");
	this.c.name = "c";
	this.c.lineHeight = 5;
	this.c.lineWidth = 6;
	this.c.parent = this;
	this.c.setTransform(-55.35,-51.2);

	this.d = new cjs.Text("D", "3px 'Segoe Pro'", "#2D2D2C");
	this.d.name = "d";
	this.d.lineHeight = 5;
	this.d.lineWidth = 6;
	this.d.parent = this;
	this.d.setTransform(-45.45,-51.2);

	this.e = new cjs.Text("E", "3px 'Segoe Pro'", "#2D2D2C");
	this.e.name = "e";
	this.e.lineHeight = 5;
	this.e.lineWidth = 6;
	this.e.parent = this;
	this.e.setTransform(-35.65,-51.2);

	this.f = new cjs.Text("F", "3px 'Segoe Pro'", "#2D2D2C");
	this.f.name = "f";
	this.f.lineHeight = 5;
	this.f.lineWidth = 6;
	this.f.parent = this;
	this.f.setTransform(-25.8,-51.2);

	this.g = new cjs.Text("G", "3px 'Segoe Pro'", "#2D2D2C");
	this.g.name = "g";
	this.g.lineHeight = 5;
	this.g.lineWidth = 6;
	this.g.parent = this;
	this.g.setTransform(-16.15,-51.2);

	this.h = new cjs.Text("H", "3px 'Segoe Pro'", "#2D2D2C");
	this.h.name = "h";
	this.h.lineHeight = 5;
	this.h.lineWidth = 6;
	this.h.parent = this;
	this.h.setTransform(-7,-51.2);

	this.i = new cjs.Text("I", "3px 'Segoe Pro'", "#2D2D2C");
	this.i.name = "i";
	this.i.lineHeight = 5;
	this.i.lineWidth = 6;
	this.i.parent = this;
	this.i.setTransform(3.35,-51.2);

	this.j = new cjs.Text("J", "3px 'Segoe Pro'", "#2D2D2C");
	this.j.name = "j";
	this.j.lineHeight = 5;
	this.j.lineWidth = 6;
	this.j.parent = this;
	this.j.setTransform(13.45,-51.2);

	this.k = new cjs.Text("K", "3px 'Segoe Pro'", "#2D2D2C");
	this.k.name = "k";
	this.k.lineHeight = 5;
	this.k.lineWidth = 6;
	this.k.parent = this;
	this.k.setTransform(23.1,-51.2);

	this.l = new cjs.Text("L", "3px 'Segoe Pro'", "#2D2D2C");
	this.l.name = "l";
	this.l.lineHeight = 5;
	this.l.lineWidth = 6;
	this.l.parent = this;
	this.l.setTransform(32.95,-51.2);

	this.m = new cjs.Text("M", "3px 'Segoe Pro'", "#2D2D2C");
	this.m.name = "m";
	this.m.lineHeight = 5;
	this.m.lineWidth = 6;
	this.m.parent = this;
	this.m.setTransform(41.55,-51.2);

	this.n = new cjs.Text("N", "3px 'Segoe Pro'", "#2D2D2C");
	this.n.name = "n";
	this.n.lineHeight = 5;
	this.n.lineWidth = 6;
	this.n.parent = this;
	this.n.setTransform(51.7,-51.2);

	this.o = new cjs.Text("O", "3px 'Segoe Pro'", "#2D2D2C");
	this.o.name = "o";
	this.o.lineHeight = 5;
	this.o.lineWidth = 6;
	this.o.parent = this;
	this.o.setTransform(61.55,-51.2);

	this.p = new cjs.Text("P", "3px 'Segoe Pro'", "#2D2D2C");
	this.p.name = "p";
	this.p.lineHeight = 5;
	this.p.lineWidth = 6;
	this.p.parent = this;
	this.p.setTransform(71.7,-51.2);

	this.q = new cjs.Text("Q", "3px 'Segoe Pro'", "#2D2D2C");
	this.q.name = "q";
	this.q.lineHeight = 5;
	this.q.lineWidth = 6;
	this.q.parent = this;
	this.q.setTransform(81.3,-51.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.q},{t:this.p},{t:this.o},{t:this.n},{t:this.m},{t:this.l},{t:this.k},{t:this.j},{t:this.i},{t:this.h},{t:this.g},{t:this.f},{t:this.e},{t:this.d},{t:this.c},{t:this.b},{t:this.a},{t:this.num1},{t:this.num2},{t:this.num3},{t:this.num4},{t:this.num5},{t:this.num6},{t:this.num7},{t:this.num8},{t:this.num9},{t:this.num10},{t:this.num11},{t:this.num12},{t:this.num13},{t:this.num14},{t:this.num15},{t:this.num16},{t:this.num17},{t:this.num18},{t:this.num19},{t:this.num20},{t:this.num21},{t:this.num22}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ColumnsAndRows_, new cjs.Rectangle(-86.1,-53.2,175.39999999999998,83.5), null);


(lib.Calories_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(42));

	// Layer_3
	this.txt7 = new cjs.Text("14,000 calories", "4px 'Segoe Pro'", "#F05824");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 7;
	this.txt7.parent = this;
	this.txt7.setTransform(-10,6.15);

	this.timeline.addTween(cjs.Tween.get(this.txt7).wait(42));

	// Layer_4
	this.txt8 = new cjs.Text("0%", "4px 'Segoe Pro'", "#F05824");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 7;
	this.txt8.parent = this;
	this.txt8.setTransform(-9.95,15.4);

	this.timeline.addTween(cjs.Tween.get(this.txt8).wait(7).to({text:"1.5%",lineWidth:7},0).wait(2).to({text:"0.4%",lineWidth:8},0).wait(2).to({text:"3.1%",lineWidth:7},0).wait(2).to({text:"5.0%",lineWidth:8},0).wait(2).to({text:"7.1%",lineWidth:7},0).wait(2).to({text:"9.2%",lineWidth:8},0).wait(2).to({text:"11.1%"},0).wait(2).to({text:"12.7%",lineWidth:9},0).wait(2).to({text:"13.8%"},0).wait(2).to({text:"14.0%"},0).wait(2).to({text:"14.1%",lineWidth:8},0).wait(2).to({text:"14.2%",lineWidth:9},0).wait(13));

	// Layer_1
	this.txt6 = new cjs.Text("0 calories", "4px 'Segoe Pro'", "#F05824");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 7;
	this.txt6.lineWidth = 26;
	this.txt6.parent = this;
	this.txt6.setTransform(-9.95,-2.25);

	this.timeline.addTween(cjs.Tween.get(this.txt6).wait(7).to({x:-9.45,text:"125 calories"},0).wait(2).to({x:-9.95,text:"265 calories"},0).wait(2).to({text:"706 calories"},0).wait(2).to({text:"995 calories"},0).wait(2).to({text:"1,271 calories"},0).wait(2).to({text:"1,526 calories"},0).wait(2).to({text:"1,755 calories"},0).wait(2).to({text:"1,950 calories"},0).wait(2).to({text:"2,099 calories"},0).wait(2).to({text:"2,152 calories"},0).wait(2).to({text:"2,187 calories"},0).wait(2).to({text:"2,200 calories"},0).wait(13));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-12,-4.2,30.2,27);


(lib.Calories = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt6.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt6 = new cjs.Text("2,200 calories", "4px 'Segoe Pro'", "#F05824");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 7;
	this.txt6.parent = this;
	this.txt6.setTransform(-12.05,-3.2);

	this.timeline.addTween(cjs.Tween.get(this.txt6).wait(1));

}).prototype = getMCSymbolPrototype(lib.Calories, new cjs.Rectangle(-14,-5.2,27.6,9.4), null);


(lib.blue_circle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2580BC").s().p("AkaNXIAEgCQCihEB7h9QB9h8BEiiQBHinAAi3QAAi2hHinQhEihh9h9Qh7h9iihEQinhHi3AAIgCAAIAAloIACAAQEAAADqBjQDhBgCvCvQCuCuBgDiQBjDqAAD/QAAEAhjDqQhgDiiuCuQivCvjhBgQhHAehJAVg");
	this.shape.setTransform(188.875,123.575);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.blue_circle, new cjs.Rectangle(125.8,0,126.2,247.2), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.top_bar2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bar.cache(-150,-350,300,700,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Top_Bar
	this.bar = new lib.topbar_2();
	this.bar.name = "bar";
	this.bar.parent = this;
	this.bar.setTransform(668.5,300.7,1,1,0,0,0,-56.8,207.6);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

}).prototype = getMCSymbolPrototype(lib.top_bar2, new cjs.Rectangle(579.3,290.3,178.60000000000002,22.599999999999966), null);


(lib.SpaChart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Spa
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E52465").s().p("AglBlQgfgIgZgZQgZgXgKghQgHgSAAgUQAAgDAEAAQAUAAAVAGQAkAKAYAWQAVATAJAaQAMgbAUgSQAYgWAjgKQAVgGAUAAQABAAABAAQABAAAAABQABAAAAABQAAABAAAAQAAAUgGASQgLAhgZAXQgaAZgeAIQgRAFgVAAQgVAAgQgFgAgUgBQgNgMgPgJQALgzAjgfQACgDAEADQAhAeANA0QgQAJgNANQgMAJgJANQgKgOgKgJg");
	this.shape.setTransform(306.501,68.3197,3.5363,3.5363);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// mask_pink (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AP/SJQjihgiuiuQivivhfjiQhjjqAAkAQAAj/BjjqQBfjiCvivQCuiuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_7 = new cjs.Graphics().p("AQYSJQjihgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_8 = new cjs.Graphics().p("AQYSJQjihgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_9 = new cjs.Graphics().p("AQWSIQjihfiuivQivivhfjiQhjjqABj/QAAkBBjjpQBgjiCvivQCuiuDihfQDphjD/AAMgACAnXQj/gBjphjg");
	var mask_graphics_10 = new cjs.Graphics().p("AQRSHQjhhgiuivQiuivhfjjQhijqABj/QABkBBkjpQBgjiCviuQCviuDjhfQDphhD/AAMgAJAnXQj/gCjphjg");
	var mask_graphics_11 = new cjs.Graphics().p("AQJSFQjihiitiwQitiwhdjiQhhjrACj/QACkBBljpQBhjhCwitQCwitDjheQDqhgD/ABMgAVAnXQj/gDjohkg");
	var mask_graphics_12 = new cjs.Graphics().p("AP6SBQjghjisiyQirixhcjkQhfjrAEj/QAEkBBnjoQBjjhCyirQCxisDkhcQDqheD/ADMgApAnXQj/gFjohmg");
	var mask_graphics_13 = new cjs.Graphics().p("APlR7QjfhmiqizQipi0hZjlQhdjsAIj/QAHkBBpjnQBmjfC0iqQCzipDlhZQDshcD/AHMgBIAnWQj/gIjmhpg");
	var mask_graphics_14 = new cjs.Graphics().p("APHRzQjdhqini2Qimi3hWjmQhYjuAMj/QALkABujmQBpjdC3inQC2imDmhWQDthXD/ALMgBxAnVQj/gMjlhtg");
	var mask_graphics_15 = new cjs.Graphics().p("AOgRnQjbhuiji6Qiii6hQjoQhTjxARj+QARkABzjjQBujbC6ijQC6iiDohQQDwhTD+ARMgCpAnSQj/gRjihzg");
	var mask_graphics_16 = new cjs.Graphics().p("ANuRZQjYh1idi/Qidi+hKjrQhMjyAZj/QAYj/B5jgQB1jYC/idQC+idDrhKQDxhLD+AYMgDxAnNQj+gZjfh4g");
	var mask_graphics_17 = new cjs.Graphics().p("AMwRGQjUh9iWjEQiWjEhBjtQhEj2Aij9QAij+CBjcQB8jTDEiXQDFiWDshBQD1hDD9AhMgFLAnEQj9gijbiAg");
	var mask_graphics_18 = new cjs.Graphics().p("ALmQtQjOiFiOjLQiOjKg2jwQg5j4Atj8QAsj9CLjVQCGjPDKiNQDLiODwg3QD3g4D7AsMgG4Am0Qj7gtjViKg");
	var mask_graphics_19 = new cjs.Graphics().p("AKPQPQjHiQiDjSQiDjSgqjyQgsj6A6j6QA6j6CWjPQCQjHDSiDQDSiDDygqQD6grD5A5MgI6AmbQj5g6jNiVg");
	var mask_graphics_20 = new cjs.Graphics().p("AIrPqQi+ich2jaQh2jagbj0Qgcj8BJj3QBKj2CijFQCci+Dah2QDah1D0gbQD9gcD1BIMgLRAl1Qj1hJjEiig");
	var mask_graphics_21 = new cjs.Graphics().p("AG7O9QiyiqhmjhQhmjigJj2QgKj+BajxQBcjwCwi5QCpiyDihmQDihmD2gKQD+gJDwBaMgN/Ak9Qjvhbi4iwg");
	var mask_graphics_22 = new cjs.Graphics().p("AFBOHQiki4hTjqQhSjpAKj3QAMj+BujoQBvjpC/ipQC4ikDqhTQDqhTD2ALQD+AMDnBtMgRAAjtQjnhvipi+g");
	var mask_graphics_23 = new cjs.Graphics().p("AC/NHQiRjHg8jxQg8jxAijzQAkj9CDjdQCFjdDOiXQDHiSDxg8QDwg8D1AiQD8AjDcCEMgUWAh9QjbiFiXjNg");
	var mask_graphics_24 = new cjs.Graphics().p("AA7L8Qh6jWgjj2Qgij2A9jvQA+j4CajNQCcjPDeh/QDWh8D2giQD2gjDvA9QD3A+DNCbI35fnQjMiciAjcg");
	var mask_graphics_25 = new cjs.Graphics().p("AhEKlQhhjjgFj5QgEj4BZjnQBbjvC0i5QCzi6DshkQDjhhD5gFQD5gEDnBZQDuBcC5CyI7lciQi4izhjjrg");
	var mask_graphics_26 = new cjs.Graphics().p("Ai4JEQhCjvAdj3QAej3B3jZQB7jhDLifQDLihD4hDQDvhCD3AdQD3AeDZB3QDgB7CgDKI/OYmQiejLhDj2g");
	var mask_graphics_27 = new cjs.Graphics().p("AkVHZQgdj3BDjvQBCjxCXjFQCbjMDhiAQDhiAD/geQD3gdDwBCQDxBCDFCXQDLCcCADfMgimATrQh/jggej+g");
	var mask_graphics_28 = new cjs.Graphics().p("AlLFmQAMj4BpjiQBqjjC0ipQC8iwD0hZQD0haEBANQD4AMDjBpQDjBqCpC1QCvC8BZDyMglbANtQhYjzAMkAg");
	var mask_graphics_29 = new cjs.Graphics().p("AlOD7QA1j0COjNQCMjPDQiJQDXiPD/gwQEAgvD8A3QDzA1DPCNQDOCOCKDPQCNDVAwD/MgnQAHWQgvj/A3j6g");
	var mask_graphics_30 = new cjs.Graphics().p("AkkCiQBZjoCri3QCqi4DjhpQDqhsEEgJQEEgJDxBcQDpBZC4CrQC3CrBpDhQBsDpAKEDMgn+ABZQgJkDBcjwg");
	var mask_graphics_31 = new cjs.Graphics().p("Al0G/QAbkCB7jhQB4jbDCifQDCifDvhKQD3hMEDAaQEEAbDjB8QDbB3CfDDQCfDDBJDtQBMD2gZECg");
	var mask_graphics_32 = new cjs.Graphics().p("AlcDaQA5j9CWjRQCRjMDUiGQDViGD2gtQD/guD+A6QD/A5DTCXQDLCSCGDUQCHDUAsD2QAuD9g5D+g");
	var mask_graphics_33 = new cjs.Graphics().p("Ak4ASQBUj1CsjAQCmi7DihvQDihuD6gSQECgTD3BVQD4BVDBCsQC7CnBvDiQBvDhARD6QATEBhUD2g");
	var mask_graphics_34 = new cjs.Graphics().p("AkMiXQBrjtC9ivQC4irDrhZQDshZD7AGQEDAHDuBrQDvBsCwC+QCqC4BZDsQBZDrgGD6QgGEDhrDtg");
	var mask_graphics_35 = new cjs.Graphics().p("AjdkmQB/jkDKifQDGibDyhFQDzhFD5AbQECAcDlB/QDlB/CgDNQCbDFBFDzQBFDxgbD6QgbEBh/Dkg");
	var mask_graphics_36 = new cjs.Graphics().p("AiumeQCPjaDWiQQDQiMD3gzQD3g0D3AtQEAAuDbCPQDbCQCRDYQCMDQA0D2QA0D3gtD3QguD/iPDag");
	var mask_graphics_37 = new cjs.Graphics().p("AiBoAQCbjRDgiCQDYh/D6glQD6gkD0A8QD9A+DSCdQDSCdCDDgQB/DZAlD5QAkD6g8D0Qg+D7icDRg");
	var mask_graphics_38 = new cjs.Graphics().p("AhYpQQCmjIDmh3QDgh0D7gXQD8gXDwBJQD5BLDKCnQDKCoB3DnQB0DgAXD6QAXD8hIDwQhLD4inDJg");
	var mask_graphics_39 = new cjs.Graphics().p("Ag0qQQCvjBDshtQDkhpD8gNQD9gMDtBTQD2BWDCCxQDCCwBuDsQBpDlAND7QAMD9hTDtQhWD0ivDCg");
	var mask_graphics_40 = new cjs.Graphics().p("AgUrCQC2i7DuhkQDohiD9gDQD9gDDqBbQDzBfC8C3QC8C4BlDwQBhDnADD8QAED9hcDqQheDyi2C7g");
	var mask_graphics_41 = new cjs.Graphics().p("AAFrpQC8i2DyheQDqhbD9AEQD9AFDnBiQDwBlC3C9QC3C9BeDzQBbDqgED8QgED9hjDoQhlDui7C3g");
	var mask_graphics_42 = new cjs.Graphics().p("AAZsHQDAiyD0hYQDthWD9AKQD9AKDlBnQDtBrCzDBQCzDBBYD1QBWDsgKD8QgJD9hoDlQhrDti/Cyg");
	var mask_graphics_43 = new cjs.Graphics().p("AApsdQDDiuD2hVQDthRD9AOQD9AODkBrQDrBvCvDDQCwDEBVD3QBRDugOD7QgOD9hrDkQhuDqjDCvg");
	var mask_graphics_44 = new cjs.Graphics().p("AA0stQDGirD2hSQDvhPD9ARQD8ARDjBuQDqByCtDGQCtDGBSD3QBODvgQD8QgRD8huDjQhyDpjECtg");
	var mask_graphics_45 = new cjs.Graphics().p("AA8s3QDHiqD3hPQDwhND8ATQD8ATDiBvQDpB0CsDHQCrDIBQD4QBNDugTD9QgTD8hwDiQhzDojGCrg");
	var mask_graphics_46 = new cjs.Graphics().p("ABBs9QDHipD4hOQDwhMD8AUQD9AUDhBxQDoB1CrDIQCqDIBPD5QBMDvgVD8QgUD8hxDhQh0DojHCqg");
	var mask_graphics_47 = new cjs.Graphics().p("ABDtAQDIipD4hNQDwhMD8AVQD9AVDgBxQDpB2CqDIQCqDJBOD5QBLDvgVD8QgVD9hxDgQh1DojHCpg");
	var mask_graphics_48 = new cjs.Graphics().p("ABEtBQDIipD4hNQDwhLD9AVQD8AVDgByQDpB1CqDJQCqDJBND4QBLDwgVD8QgVD8hyDhQh1DnjHCqg");
	var mask_graphics_49 = new cjs.Graphics().p("ABEtCQDIioD4hNQDwhLD9AVQD8AVDgByQDpB1CqDJQCqDJBND5QBLDvgVD8QgVD8hyDhQh1DnjICqg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:151.126,y:67.7769}).wait(7).to({graphics:mask_graphics_7,x:153.576,y:67.7769}).wait(1).to({graphics:mask_graphics_8,x:153.5843,y:67.7769}).wait(1).to({graphics:mask_graphics_9,x:153.6426,y:67.777}).wait(1).to({graphics:mask_graphics_10,x:153.8009,y:67.777}).wait(1).to({graphics:mask_graphics_11,x:154.1092,y:67.7759}).wait(1).to({graphics:mask_graphics_12,x:154.6175,y:67.7708}).wait(1).to({graphics:mask_graphics_13,x:155.3759,y:67.7551}).wait(1).to({graphics:mask_graphics_14,x:156.4343,y:67.7177}).wait(1).to({graphics:mask_graphics_15,x:157.8421,y:67.6398}).wait(1).to({graphics:mask_graphics_16,x:159.6478,y:67.4934}).wait(1).to({graphics:mask_graphics_17,x:161.8976,y:67.2383}).wait(1).to({graphics:mask_graphics_18,x:164.6337,y:66.8196}).wait(1).to({graphics:mask_graphics_19,x:167.8916,y:66.1639}).wait(1).to({graphics:mask_graphics_20,x:171.695,y:65.1766}).wait(1).to({graphics:mask_graphics_21,x:176.0509,y:63.7361}).wait(1).to({graphics:mask_graphics_22,x:180.9403,y:61.6872}).wait(1).to({graphics:mask_graphics_23,x:186.3078,y:58.857}).wait(1).to({graphics:mask_graphics_24,x:192.0488,y:55.0646}).wait(1).to({graphics:mask_graphics_25,x:197.9932,y:50.1009}).wait(1).to({graphics:mask_graphics_26,x:203.8896,y:43.7308}).wait(1).to({graphics:mask_graphics_27,x:209.3886,y:35.8056}).wait(1).to({graphics:mask_graphics_28,x:214.0318,y:26.2206}).wait(1).to({graphics:mask_graphics_29,x:217.0425,y:16.0077}).wait(1).to({graphics:mask_graphics_30,x:218.2858,y:6.4831}).wait(1).to({graphics:mask_graphics_31,x:218.4952,y:10.6932}).wait(1).to({graphics:mask_graphics_32,x:218.6486,y:18.3628}).wait(1).to({graphics:mask_graphics_33,x:218.7707,y:25.0493}).wait(1).to({graphics:mask_graphics_34,x:218.8767,y:30.7716}).wait(1).to({graphics:mask_graphics_35,x:218.9756,y:35.5907}).wait(1).to({graphics:mask_graphics_36,x:219.0576,y:39.6072}).wait(1).to({graphics:mask_graphics_37,x:219.1229,y:42.9173}).wait(1).to({graphics:mask_graphics_38,x:219.1754,y:45.6118}).wait(1).to({graphics:mask_graphics_39,x:219.2191,y:47.7754}).wait(1).to({graphics:mask_graphics_40,x:219.2564,y:49.4859}).wait(1).to({graphics:mask_graphics_41,x:219.2883,y:50.8133}).wait(1).to({graphics:mask_graphics_42,x:219.3146,y:51.8202}).wait(1).to({graphics:mask_graphics_43,x:219.3348,y:52.5614}).wait(1).to({graphics:mask_graphics_44,x:219.3494,y:53.0842}).wait(1).to({graphics:mask_graphics_45,x:219.3593,y:53.4308}).wait(1).to({graphics:mask_graphics_46,x:219.3653,y:53.6396}).wait(1).to({graphics:mask_graphics_47,x:219.3684,y:53.7463}).wait(1).to({graphics:mask_graphics_48,x:219.3695,y:53.7855}).wait(1).to({graphics:mask_graphics_49,x:219.3567,y:53.6795}).wait(11));

	// pink_circle
	this.instance = new lib.pink_circle();
	this.instance.parent = this;
	this.instance.setTransform(307.4,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60));

	// Grey_circle copy 2
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(307.4,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(181.4,-58.2,251.99999999999997,252);


(lib.Spa_chart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Spa
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E52465").s().p("AglBlQgfgIgZgZQgZgXgKghQgHgSAAgUQAAgDAEAAQAUAAAVAGQAkAKAYAWQAVATAJAaQAMgbAUgSQAYgWAjgKQAVgGAUAAQABAAABAAQABAAAAABQABAAAAABQAAABAAAAQAAAUgGASQgLAhgZAXQgaAZgeAIQgRAFgVAAQgVAAgQgFgAgUgBQgNgMgPgJQALgzAjgfQACgDAEADQAhAeANA0QgQAJgNANQgMAJgJANQgKgOgKgJg");
	this.shape.setTransform(306.501,68.3197,3.5363,3.5363);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// mask_pink (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ABEtCQDIioD4hNQDwhLD9AVQD8AVDgByQDpB1CqDJQCqDJBND5QBLDvgVD8QgVD8hyDhQh1DnjICqg");
	mask.setTransform(219.3567,53.6795);

	// pink_circle
	this.instance = new lib.pink_circle();
	this.instance.parent = this;
	this.instance.setTransform(307.4,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Grey_circle copy 2
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(307.4,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Spa_chart, new cjs.Rectangle(181.4,-58.2,251.99999999999997,252), null);


(lib.RunChart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// run
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2680BE").s().p("AALCaQgKgDgDgJQgFgIADgKIAUhBIg+glQgQgKgFgQQgGgRAHgQIAchBIgLgDQgKgDgJAHIgdAXQgIAGgKgCQgKgBgGgIQgGgIACgJQABgKAIgGIAdgXQAbgUAhAIIA0APQAfAIAPAeIATAoIAhAAQAKAAAHAHQAHAHAAAKQAAAKgHAGQgHAHgKAAIgoAAQgKAAgJgFQgJgFgEgKIgPgeIgXA6IAtAaQALAGAEALQAFAMgEALIgXBLQgCAIgHAEQgGAFgIAAIgHgBg");
	this.shape.setTransform(-221.1127,78.0996,2.6938,2.6938);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2680BE").s().p("AgjAlQgKAAgHgHQgHgHAAgKQAAgKAHgGQAHgHAKAAIAwAAIALgaQAJAUATAMIAIAEIgGAPQgEAKgJAGQgJAGgLAAg");
	this.shape_1.setTransform(-251.3104,90.7263,2.6938,2.6938);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2680BE").s().p("AgYAZQgLgKAAgPQAAgOALgKQAKgLAOAAQAPAAAKALQALAKAAAOQAAAPgLAKQgKALgPAAQgOAAgKgLg");
	this.shape_2.setTransform(-213.0582,26.8828,2.6938,2.6938);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[]},1).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},6).wait(53));

	// mask_blue (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Av5SJQjihgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_7 = new cjs.Graphics().p("AvhSJQjihgiuiuQivivhgjiQhijqgBkAQABj/BijqQBgjiCvivQCuiuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_8 = new cjs.Graphics().p("AvhSJQjihgiviuQiuivhgjiQhjjqAAkAQABj/BjjqQBfjiCvivQCuiuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_9 = new cjs.Graphics().p("AviSIQjihgiuiuQivivhfjiQhjjqAAj/QABkBBjjqQBgjhCvivQCuiuDihfQDphjD/AAMgACAnXQj/gBjphjg");
	var mask_graphics_10 = new cjs.Graphics().p("AvlSHQjihgiuiwQiuivhejiQhijrABj/QAAkABkjqQBhjhCviuQCviuDihfQDqhhD/AAMgAKAnXQj/gCjohjg");
	var mask_graphics_11 = new cjs.Graphics().p("AvrSEQjihhisiwQitiwhejjQhhjrADj/QACkBBljpQBhjhCxitQCwitDihdQDqhhD/ACMgAWAnXQj/gDjohlg");
	var mask_graphics_12 = new cjs.Graphics().p("Av1SAQjhhjiriyQirixhcjkQhfjsAFj/QAEkABnjoQBkjhCxirQCyisDjhbQDrheD/AEMgAsAnWQj/gFjnhng");
	var mask_graphics_13 = new cjs.Graphics().p("AwER6QjfhnipizQipi0hZjlQhcjtAIj/QAIkABqjnQBmjfC0ipQC0ipDkhZQDshbD/AHMgBMAnVQj/gIjmhpg");
	var mask_graphics_14 = new cjs.Graphics().p("AwYRxQjdhrimi2Qimi3hVjmQhXjvAMj/QAMkABvjlQBqjdC3imQC2imDnhUQDthXD/ALMgB6AnUQj+gNjkhtg");
	var mask_graphics_15 = new cjs.Graphics().p("AwzRkQjbhvihi7Qiii6hPjpQhSjwATj/QASj/B0jjQBvjaC7iiQC7ihDohPQDvhSD/ASMgC2AnQQj+gTjhhzg");
	var mask_graphics_16 = new cjs.Graphics().p("AxVRUQjXh2icjAQici/hHjrQhLjyAaj+QAaj/B7jfQB2jXC/icQDAibDqhIQDyhKD+AZMgECAnJQj9gajeh6g");
	var mask_graphics_17 = new cjs.Graphics().p("Ax/Q/QjSh+iUjFQiVjGg/jtQhBj1Akj9QAkj+CDjaQB+jSDFiUQDFiVDug+QD0hBD9AjMgFhAm+Qj9gljZiCg");
	var mask_graphics_18 = new cjs.Graphics().p("AywQlQjMiIiLjMQiLjMg0jwQg2j4Awj7QAvj8CNjTQCIjNDMiLQDMiLDwgzQD3g2D7AvMgHVAmrQj7gwjSiMg");
	var mask_graphics_19 = new cjs.Graphics().p("AzqQEQjEiTh/jUQiAjTgmjyQgoj6A+j5QA9j5CZjLQCTjEDTiAQDUh/DygnQD6gnD3A9MgJeAmMQj3g+jLiXg");
	var mask_graphics_20 = new cjs.Graphics().p("A0qPbQi7ighxjbQhxjbgWj0QgYj8BOj0QBOj1CmjBQCfi6DchxQDbhxD0gXQD8gXDzBNMgL+AlgQjyhOjAilg");
	var mask_graphics_21 = new cjs.Graphics().p("A1xOqQiuiuhgjjQhgjjgDj2QgEj9BgjtQBhjuCzizQCuiuDjhgQDkhgD1gDQD9gEDsBgMgO0AkdQjshgiyizg");
	var mask_graphics_22 = new cjs.Graphics().p("A29NvQidi8hMjrQhLjrASj0QATj9B1jkQB1jkDDijQC8ieDrhLQDrhMD1ATQD8ATDiB0MgR+AjAQjjh1iijCg");
	var mask_graphics_23 = new cjs.Graphics().p("A4KMpQiJjLgzjyQg0jxArjwQAtj7CLjWQCMjYDSiOQDLiJDyg0QDxgzDyArQD5AsDVCKMgVbAhBQjWiLiOjSg");
	var mask_graphics_24 = new cjs.Graphics().p("A5ULYQhxjagXj2QgYj1BHjqQBIj0CjjFQCkjGDhh1QDahyD2gXQD1gXDrBGQDyBJDECiI5EeVQjEijh1jgg");
	var mask_graphics_25 = new cjs.Graphics().p("A6VJ7QhVjnAJj2QAIj2BkjgQBojoC7ivQC8ivDuhXQDnhVD2AJQD3AIDfBkQDnBoCuC6I8xa2Qiti7hXjtg");
	var mask_graphics_26 = new cjs.Graphics().p("A7HITQgyjwAsjzQArjyCEjPQCHjXDTiSQDTiSD4g0QDwgzDzAsQDzAsDOCDQDWCICSDRMggVAWbQiRjSg0j3g");
	var mask_graphics_27 = new cjs.Graphics().p("A7gGiQgMj1BTjoQBSjpCii3QCpi/DnhuQDnhvD+gLQD1gMDpBSQDnBSC4CjQC9CoBvDlMgjgAQ/QhtjmgMj9g");
	var mask_graphics_28 = new cjs.Graphics().p("A7XEuQAfjzB5jWQB5jXDAiZQDGifD3hFQD3hFD8AgQDzAfDWB5QDXB5CZDAQCeDGBFD0Mgl5AKoQhEj2Agj7g");
	var mask_graphics_29 = new cjs.Graphics().p("A6uDMQBGjrCajBQCZjBDWh4QDeh9D+gdQD/gcDzBIQDrBFDBCaQDBCZB4DWQB8DcAeD9MgnHAEcQgcj+BHjyg");
	var mask_graphics_30 = new cjs.Graphics().p("A7gI5QAIj/BqjlQBnjeC0ipQC0ipDkhYQDthcEAAIQEBAIDlBqQDfBnCpC0QCpC0BZDkQBbDsgID/g");
	var mask_graphics_31 = new cjs.Graphics().p("A7YFHQApj8CHjVQCCjQDIiQQDJiRDug6QD3g8D9ApQD9ApDWCHQDQCCCQDJQCQDIA6DtQA8D2goD8g");
	var mask_graphics_32 = new cjs.Graphics().p("A7IBzQBGj0CejGQCZi/DYh5QDXh4D0geQD8ggD2BGQD2BFDGCfQDACaB4DXQB5DWAeD0QAfD7hED1g");
	var mask_graphics_33 = new cjs.Graphics().p("A6zhBQBejtCxi1QCsivDjhiQDihiD2gFQD+gGDuBeQDtBeC1CyQCvCsBiDjQBiDhAGD2QAGD8hdDug");
	var mask_graphics_34 = new cjs.Graphics().p("A6cjaQBzjkDAikQC7ifDrhOQDqhND1AQQD9ARDlByQDkB0ClDBQCfC7BNDqQBODpgQD1QgRD9hyDkg");
	var mask_graphics_35 = new cjs.Graphics().p("A6ElZQCEjaDMiVQDHiQDvg8QDwg7DzAjQD7AkDaCEQDcCECVDOQCRDGA7DvQA7DvgiDzQgkD7iEDag");
	var mask_graphics_36 = new cjs.Graphics().p("A5unCQCSjRDWiHQDQiDDzgrQDzgsDwAzQD4A1DSCSQDSCTCHDXQCDDPAsDyQArDzgzDwQg0D4iRDRg");
	var mask_graphics_37 = new cjs.Graphics().p("A5ZoXQCejIDdh7QDXh3D1geQD1geDsBAQD2BDDICdQDKCfB7DeQB4DWAdD0QAeD1hADtQhCD0idDJg");
	var mask_graphics_38 = new cjs.Graphics().p("A5GpbQCnjBDihwQDchtD2gSQD2gTDqBLQDyBODBCnQDCCnBxDkQBtDcATD1QASD2hLDqQhNDwimDCg");
	var mask_graphics_39 = new cjs.Graphics().p("A42qQQCui7DnhnQDghlD2gJQD3gJDmBUQDuBXC8CuQC8CvBoDnQBkDgAJD2QAJD2hUDnQhWDuitC7g");
	var mask_graphics_40 = new cjs.Graphics().p("A4oq6QCzi1DqhhQDjhdD2gCQD3gBDkBbQDrBeC2C0QC3C0BhDrQBdDjACD1QABD3hbDkQhdDrizC2g");
	var mask_graphics_41 = new cjs.Graphics().p("A4erZQC4ixDshbQDlhYD3AEQD2AEDiBhQDpBjCyC4QCyC5BbDtQBYDlgED2QgED2hhDiQhjDpi3Cxg");
	var mask_graphics_42 = new cjs.Graphics().p("A4WrxQC7itDuhXQDmhUD3AJQD3AJDgBkQDnBoCuC7QCvC8BXDuQBUDngJD1QgID3hlDgQhnDni6Cug");
	var mask_graphics_43 = new cjs.Graphics().p("A4QsBQC+irDuhUQDohRD2AMQD3AMDeBnQDmBrCsC9QCsC+BUDwQBSDogMD1QgMD3hnDeQhrDmi8Crg");
	var mask_graphics_44 = new cjs.Graphics().p("A4MsMQC/ipDvhSQDphPD2AOQD2AODeBpQDlBtCqC/QCrC/BSDxQBPDogOD1QgOD3hpDdQhsDli+Cqg");
	var mask_graphics_45 = new cjs.Graphics().p("A4JsSQC/ipDwhQQDphOD2APQD2AQDeBqQDkBuCpC/QCqDBBRDxQBODogQD2QgPD2hqDdQhuDki+Cpg");
	var mask_graphics_46 = new cjs.Graphics().p("A4IsWQDAioDwhPQDphOD2AQQD3AQDcBrQDkBvCpDAQCpDBBQDxQBODpgQD1QgQD2hrDdQhuDki/Cog");
	var mask_graphics_47 = new cjs.Graphics().p("A4HsXQDAioDwhPQDphND2AQQD2AQDdBrQDkBvCoDAQCqDBBPDyQBNDogQD2QgQD2hrDdQhuDjjACpg");
	var mask_graphics_48 = new cjs.Graphics().p("A4HsXQDAioDwhPQDphND2AQQD3AQDcBrQDkBvCpDAQCpDBBQDyQBNDpgRD1QgQD2hrDdQhuDjjACpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-178.8,y:67.7769}).wait(1).to({graphics:null,x:0,y:0}).wait(6).to({graphics:mask_graphics_7,x:-176.35,y:67.7769}).wait(1).to({graphics:mask_graphics_8,x:-176.35,y:67.7768}).wait(1).to({graphics:mask_graphics_9,x:-176.35,y:67.7762}).wait(1).to({graphics:mask_graphics_10,x:-176.3501,y:67.7743}).wait(1).to({graphics:mask_graphics_11,x:-176.3504,y:67.7693}).wait(1).to({graphics:mask_graphics_12,x:-176.3509,y:67.7571}).wait(1).to({graphics:mask_graphics_13,x:-176.352,y:67.73}).wait(1).to({graphics:mask_graphics_14,x:-176.354,y:67.6744}).wait(1).to({graphics:mask_graphics_15,x:-176.3572,y:67.5686}).wait(1).to({graphics:mask_graphics_16,x:-176.3616,y:67.3802}).wait(1).to({graphics:mask_graphics_17,x:-176.3666,y:67.0631}).wait(1).to({graphics:mask_graphics_18,x:-176.3705,y:66.5547}).wait(1).to({graphics:mask_graphics_19,x:-176.3709,y:65.7718}).wait(1).to({graphics:mask_graphics_20,x:-176.3653,y:64.6073}).wait(1).to({graphics:mask_graphics_21,x:-176.3547,y:62.9233}).wait(1).to({graphics:mask_graphics_22,x:-176.3495,y:60.5471}).wait(1).to({graphics:mask_graphics_23,x:-176.3411,y:57.2969}).wait(1).to({graphics:mask_graphics_24,x:-176.317,y:52.9764}).wait(1).to({graphics:mask_graphics_25,x:-176.2927,y:47.3546}).wait(1).to({graphics:mask_graphics_26,x:-176.2864,y:40.2132}).wait(1).to({graphics:mask_graphics_27,x:-176.2577,y:31.4387}).wait(1).to({graphics:mask_graphics_28,x:-176.2305,y:21.209}).wait(1).to({graphics:mask_graphics_29,x:-176.1874,y:11.2925}).wait(1).to({graphics:mask_graphics_30,x:-176.1116,y:6.1764}).wait(1).to({graphics:mask_graphics_31,x:-175.2902,y:14.254}).wait(1).to({graphics:mask_graphics_32,x:-173.6897,y:21.3173}).wait(1).to({graphics:mask_graphics_33,x:-171.6138,y:27.3827}).wait(1).to({graphics:mask_graphics_34,x:-169.3038,y:32.4951}).wait(1).to({graphics:mask_graphics_35,x:-166.9434,y:36.7498}).wait(1).to({graphics:mask_graphics_36,x:-164.6658,y:40.2525}).wait(1).to({graphics:mask_graphics_37,x:-162.5626,y:43.1008}).wait(1).to({graphics:mask_graphics_38,x:-160.6912,y:45.3858}).wait(1).to({graphics:mask_graphics_39,x:-159.0822,y:47.1905}).wait(1).to({graphics:mask_graphics_40,x:-157.7456,y:48.5896}).wait(1).to({graphics:mask_graphics_41,x:-156.6759,y:49.6494}).wait(1).to({graphics:mask_graphics_42,x:-155.8558,y:50.4283}).wait(1).to({graphics:mask_graphics_43,x:-155.2599,y:50.9771}).wait(1).to({graphics:mask_graphics_44,x:-154.8565,y:51.3406}).wait(1).to({graphics:mask_graphics_45,x:-154.6103,y:51.5594}).wait(1).to({graphics:mask_graphics_46,x:-154.4835,y:51.6713}).wait(1).to({graphics:mask_graphics_47,x:-154.4367,y:51.7124}).wait(1).to({graphics:mask_graphics_48,x:-154.4115,y:51.6852}).wait(12));

	// Blue_circle
	this.instance = new lib.blue_circle();
	this.instance.parent = this;
	this.instance.setTransform(-226.7,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(6).to({_off:false},0).wait(53));

	// Grey_circle
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-226.7,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:true},1).wait(6).to({_off:false},0).wait(53));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-352.7,-58.2,252,252);


(lib.Run_chart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// run
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2680BE").s().p("AALCaQgKgDgDgJQgFgIADgKIAUhBIg+glQgQgKgFgQQgGgRAHgQIAchBIgLgDQgKgDgJAHIgdAXQgIAGgKgCQgKgBgGgIQgGgIACgJQABgKAIgGIAdgXQAbgUAhAIIA0APQAfAIAPAeIATAoIAhAAQAKAAAHAHQAHAHAAAKQAAAKgHAGQgHAHgKAAIgoAAQgKAAgJgFQgJgFgEgKIgPgeIgXA6IAtAaQALAGAEALQAFAMgEALIgXBLQgCAIgHAEQgGAFgIAAIgHgBg");
	this.shape.setTransform(-221.1127,78.0996,2.6938,2.6938);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2680BE").s().p("AgjAlQgKAAgHgHQgHgHAAgKQAAgKAHgGQAHgHAKAAIAwAAIALgaQAJAUATAMIAIAEIgGAPQgEAKgJAGQgJAGgLAAg");
	this.shape_1.setTransform(-251.3104,90.7263,2.6938,2.6938);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#2680BE").s().p("AgYAZQgLgKAAgPQAAgOALgKQAKgLAOAAQAPAAAKALQALAKAAAOQAAAPgLAKQgKALgPAAQgOAAgKgLg");
	this.shape_2.setTransform(-213.0582,26.8828,2.6938,2.6938);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// mask_blue (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A4HsXQDAioDwhPQDphND2AQQD3AQDcBrQDkBvCpDAQCpDBBQDyQBNDpgRD1QgQD2hrDdQhuDjjACpg");
	mask.setTransform(-154.4115,51.6852);

	// Blue_circle
	this.instance = new lib.blue_circle();
	this.instance.parent = this;
	this.instance.setTransform(-226.7,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Grey_circle
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-226.7,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Run_chart, new cjs.Rectangle(-352.7,-58.2,252,252), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.phone_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.laptop = new lib.phone_vector();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(0.05,-1.3,0.6058,0.6058,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_mc, new cjs.Rectangle(-0.6,-1.3,314.20000000000005,592.3), null);


(lib.phone_ai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mobile.cache(-320,-600,640,1200,1.2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mobile = new lib.phone_mc();
	this.mobile.name = "mobile";
	this.mobile.parent = this;
	this.mobile.setTransform(148.5,295.2,1,1,0,0,0,148.5,295.2);

	this.timeline.addTween(cjs.Tween.get(this.mobile).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_ai, new cjs.Rectangle(-0.6,-1.3,314.20000000000005,592.3), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_54 = function() {
		exportRoot.tl1.play()
	}
	this.frame_75 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(21).call(this.frame_75).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(298,898.75,0.3351,0.3351,0,0,0,-39.7,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5415,scaleY:5.5415,x:298.05,y:898.5},13,cjs.Ease.quadOut).to({x:78.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(49));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgGoBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("EgG4BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("EgHmBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("EgIzBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("EgKeBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("EgMpBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("EgPSBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("EgR7BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("EgUGBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("EgVxBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("EgW+BK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("EgXsBK6IAAyrMBGZAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("EgX8BK6IAAyrMBGZAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:408.0654,y:479.4334}).wait(1).to({graphics:mask_graphics_15,x:406.5275,y:479.4334}).wait(1).to({graphics:mask_graphics_16,x:401.914,y:479.4334}).wait(1).to({graphics:mask_graphics_17,x:394.2247,y:479.4334}).wait(1).to({graphics:mask_graphics_18,x:383.4598,y:479.4334}).wait(1).to({graphics:mask_graphics_19,x:369.6192,y:479.4334}).wait(1).to({graphics:mask_graphics_20,x:352.7029,y:479.4334}).wait(1).to({graphics:mask_graphics_21,x:335.7866,y:479.4334}).wait(1).to({graphics:mask_graphics_22,x:321.9459,y:479.4334}).wait(1).to({graphics:mask_graphics_23,x:311.181,y:479.4334}).wait(1).to({graphics:mask_graphics_24,x:303.4918,y:479.4334}).wait(1).to({graphics:mask_graphics_25,x:298.8782,y:479.4334}).wait(1).to({graphics:mask_graphics_26,x:297.3404,y:479.4334}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.parent = this;
	this.instance_1.setTransform(78.9,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:300.35},12,cjs.Ease.quadInOut).to({_off:true},24).wait(26));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhM1CXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTjCXxMAAAkvhMCXtAAAMAAAEvhg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhanCXxMAAAkvhMCXtAAAMAAAEvhg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:903.6504}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:903.6504}).wait(1).to({graphics:mask_1_graphics_52,x:295.8271,y:903.6504}).wait(1).to({graphics:mask_1_graphics_53,x:289.2111,y:903.6504}).wait(1).to({graphics:mask_1_graphics_54,x:278.1844,y:903.6504}).wait(1).to({graphics:mask_1_graphics_55,x:262.7471,y:903.6504}).wait(1).to({graphics:mask_1_graphics_56,x:242.8992,y:903.6504}).wait(1).to({graphics:mask_1_graphics_57,x:218.6406,y:903.6504}).wait(1).to({graphics:mask_1_graphics_58,x:189.9713,y:903.6504}).wait(1).to({graphics:mask_1_graphics_59,x:156.8914,y:903.6504}).wait(1).to({graphics:mask_1_graphics_60,x:119.4008,y:903.6504}).wait(1).to({graphics:mask_1_graphics_61,x:77.4995,y:903.6504}).wait(1).to({graphics:mask_1_graphics_62,x:31.1876,y:903.6504}).wait(1).to({graphics:mask_1_graphics_63,x:-19.5349,y:903.6504}).wait(1).to({graphics:mask_1_graphics_64,x:-74.6682,y:903.6504}).wait(1).to({graphics:mask_1_graphics_65,x:-134.212,y:903.6504}).wait(1).to({graphics:mask_1_graphics_66,x:-198.1666,y:903.6504}).wait(1).to({graphics:mask_1_graphics_67,x:-266.5318,y:903.6504}).wait(1).to({graphics:mask_1_graphics_68,x:-339.3076,y:903.6504}).wait(1).to({graphics:mask_1_graphics_69,x:-416.4941,y:903.6504}).wait(1).to({graphics:mask_1_graphics_70,x:-491.7868,y:903.6504}).wait(1).to({graphics:mask_1_graphics_71,x:-534.7908,y:903.6504}).wait(1).to({graphics:mask_1_graphics_72,x:-580,y:903.6504}).wait(4));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(300.35,891.85,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({_off:true},25).wait(1));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({x:-674.6},21,cjs.Ease.quadIn).to({_off:true},3).wait(1));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-674.6},21,cjs.Ease.quadIn).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160,-67.6,1943.5,1942.6);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logoc();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(32.85,1.1,1,1,0,0,0,170.6,-129.1);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-30.6,-8.4,144.3,17), null);


(lib.laptop_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Camera
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0D0D0D").s().p("AgKAMQgFgFAAgHQAAgGAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAGQAAAGgFAGQgFAEgGAAQgFAAgFgEg");
	this.shape.setTransform(399,12.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D6E6E").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_1.setTransform(399,12.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgPgPQANAAAIAKQAKAIAAAN");
	this.shape_2.setTransform(400.6,10.45);

	this.instance = new lib.Path_3_0();
	this.instance.parent = this;
	this.instance.setTransform(400.55,10.45,1,1,0,0,0,1.6,1.6);
	this.instance.alpha = 0.25;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#272C2E").s().p("AgeAfQgNgNAAgSQAAgRANgNQANgNARAAQASAAANANQANANAAARQAAASgNANQgNANgSAAQgRAAgNgNg");
	this.shape_3.setTransform(399,12.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0D0D0D").s().p("AgFAGQgCgDgBgDQABgDACgCQACgDADAAQAEAAACADQACACABADQgBADgCADQgCACgEAAQgDAAgCgCg");
	this.shape_4.setTransform(379.75,12.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D6E6E").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_5.setTransform(379.75,12.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgIgHQAHAAAEAFQAFADAAAH");
	this.shape_6.setTransform(380.6,11.225);

	this.instance_1 = new lib.Path_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(380.55,11.2,1,1,0,0,0,0.8,0.8);
	this.instance_1.alpha = 0.25;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#272C2E").s().p("AgPAQQgHgGAAgKQAAgIAHgHQAHgHAIAAQAKAAAGAHQAHAHAAAIQAAAKgHAGQgGAHgKAAQgIAAgHgHg");
	this.shape_7.setTransform(379.75,12.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Screen
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0D0D0D").s().p("Eg4oAj7QhXAAg+g9Qg+g+AAhXMAAAhBbQAAhTA7g6QA6g7BTAAMBxNAAAQBeAABCBCQBCBCAABeMAAABAzQAABdhCBCQhBBBhdAAgEg5UggcMAAABAiQAAAEAEAAMByvAAAQAEAAABgEMAAAhAiQgBgEgEAAMhyvAAAQgEAAAAAEg");
	this.shape_8.setTransform(413.8,232.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6D7680").s().p("Eg4pAkWQhpAAhLhLQhLhKAAhpMAAAhA5QAAhlBIhHQBIhIBkAAMBxPAAAQBvAABQBPQBPBPAABwMAAABARQAABvhPBPQhPBOhuAAgEg5+AghMB0MAAAMAAAhBZMh0MAAAg");
	this.shape_9.setTransform(414.35,232.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Keyboard
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ACB6BF").s().p("AjOAjQgFAAgBgGIgFgYQgBgEgBAAIgDgFIgEgaQgCgFAGAAIGsABQAFAAABAGIAFAXIACAFQACAAABAFIAFAZQACAGgGAAg");
	this.shape_10.setTransform(703.4,504.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#ACB6BF").s().p("AjMAiQgGAAgCgFIgRg5QgCgGAGAAIGrABQAGAAACAFIAUA5QACAGgGAAg");
	this.shape_11.setTransform(749.9017,504.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#ACB6BF").s().p("AjOAiQgGAAgBgGIgMg4IAAgEQAAgBABAAQAAAAAAAAQABgBAAAAQABAAABAAIGrABQAGAAABAGIANA4QACAGgGAAg");
	this.shape_12.setTransform(656.5917,504.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#ACB6BF").s().p("AjSAiQgGAAgBgFIgJg5QgBgFAFAAIGsAAQAGAAABAFIAOA5QACAFgGAAg");
	this.shape_13.setTransform(610.1923,504.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ACB6BF").s().p("AjSAiQgFAAgBgFIgHg5QgBgFAGAAIGvAAQAGAAAAAFIAFA5QAAAFgFAAg");
	this.shape_14.setTransform(563.3173,504.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ACB6BF").s().p("A11AiQgEAAAAgFIAGg5QABgFAFAAMArcAAAQAFAAABAFIAGA5QgBAFgFAAg");
	this.shape_15.setTransform(398.9,504.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ACB6BF").s().p("AjsAiQgFAAABgFIAOg5QABgFAFAAIHJAAQAGAAgBAFIgJA5QAAAFgGAAg");
	this.shape_16.setTransform(232.5995,504.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ACB6BF").s().p("AjtAiQgGAAABgFIAOg5QACgFAFAAIHMAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgOA5QgCAFgFAAg");
	this.shape_17.setTransform(183.0373,504.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ACB6BF").s().p("AjvAiQgGAAABgFIAOg5QACgFAFAAIHPAAQABAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgUA5QgBAFgGAAg");
	this.shape_18.setTransform(133.6623,504.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#ACB6BF").s().p("AkAAiQgFAAABgFIARg5QABgFAGAAIHtAAQAGAAgCAFIgUA5QgCAFgFAAg");
	this.shape_19.setTransform(82.1433,504.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#63717F").s().p("AjRArQgFAAgCgFIgSg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBQABAAAAgBQAAAAABAAQAAgBABAAQABAAAAAAIGsABQAFAAACAFIAUA5IAAADIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAAAQAAABgBABQAAAAgBAAQAAABAAAAQgBAAgBAAg");
	this.shape_20.setTransform(749.4625,505.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#63717F").s().p("AjUAsQgFAAgCgFIgFgaQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQgEgBgBgEIgFgYQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAAAIABgBIAAgBIABgBIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABgBAAAAIGsABQAFAAABAGIAGAaQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAIAAAAQAEACABAEIAGAYIAAADIAAAAIAAAGIABABIAAAFIAAAAIAAADQAAAFgEgBg");
	this.shape_21.setTransform(702.8688,505.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#63717F").s().p("AjVAsQgGAAgBgFIgNg2IAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBQABgEADAAIGsABQAGAAABAGIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIANA1QABAGgGAAg");
	this.shape_22.setTransform(656.5327,505.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#63717F").s().p("AjXAuQgFAAgBgGIgKg4IAAgDIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBQABgDADAAIGsAAQAGAAABAFIAOA5IABABIAAAMIAAAAIAAAMQABAEgFAAg");
	this.shape_23.setTransform(609.8583,505.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#63717F").s().p("AjYAsQgGAAAAgFIgHg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAABAAIGvAAQAGAAAAAFIAAACIABAAIAAAEIAAAAIAAADIABAAIAAAFIAAAAIAAADIABAAIAAADIAEA5QAAAFgFAAg");
	this.shape_24.setTransform(562.925,505.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#63717F").s().p("A17AsQgFAAAAgFIAHg5IAAgBIAAAAIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQABgFAFAAMArcAAAQAEAAACAFIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAFA5QABAFgGAAg");
	this.shape_25.setTransform(398.9321,505.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#63717F").s().p("AjxAsQgFAAABgFIAAAAIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIAOg4QABgGAGAAIHIAAQAEAAABAEIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIgIA5QgBAFgFAAg");
	this.shape_26.setTransform(232.6173,505.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#63717F").s().p("Aj4AsQgGAAABgFIAOg5IAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgFAFAAIHMAAQABAAAAABQABAAAAAAQABAAAAABQAAAAAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAAAIAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAADIgOA5QgBAFgFAAg");
	this.shape_27.setTransform(183.3006,505.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#63717F").s().p("Aj9AsQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBIAAgBIgBAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgEIAQg4QABgGAGAAIHtAAQABAAABABQAAAAABAAQAAAAAAABQABAAAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgTA5QgCAFgFAAg");
	this.shape_28.setTransform(82.5,505.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#63717F").s().p("Aj5AsQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAIAAgEIANg5IABgCIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBQACgEAEAAIHPAAQABAAABABQAAAAABAAQAAAAABABQAAAAAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgUA5QgCAFgFAAg");
	this.shape_29.setTransform(133.3667,505.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#ACB6BF").s().p("Ap0AcQgGgBgBgFIgGgrQgBgGAFABITpAAQAFgBACAGIAPArQACAFgGABg");
	this.shape_30.setTransform(706.569,497.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#ACB6BF").s().p("AjYAcQgGgBgBgFIgGgrQgBgGAGABIG2AAQAGgBABAGIAJArQABAFgGABg");
	this.shape_31.setTransform(618.1505,497.55);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#ACB6BF").s().p("AjcAbQgGABAAgGIgCgrQgBgFAGgBIG6AAQAFABABAFIAFArQAAAGgFgBg");
	this.shape_32.setTransform(569.9429,497.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#ACB6BF").s().p("AjeAcQgFgBAAgFIAAgrQAAgGAFABIG4AAQAGgBAAAGIAEArQAAAFgFABg");
	this.shape_33.setTransform(521.925,497.55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGgBIG6AAQAFABABAFIADArQAAAFgGAAg");
	this.shape_34.setTransform(474.425,497.75);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIACgrQAAgFAGgBIG6AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_35.setTransform(426.325,497.75);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIADgrQAAgFAGgBIG5AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_36.setTransform(378.6429,497.75);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#ACB6BF").s().p("AjgAbQgGAAABgFIAGgrQAAgFAGgBIG6AAQAFABAAAFIgEArQAAAFgGAAg");
	this.shape_37.setTransform(330.2173,497.75);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGgBIG6AAQAGABgBAFIgGArQAAAFgGAAg");
	this.shape_38.setTransform(282.5321,497.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ACB6BF").s().p("AjiAbQgFAAAAgFIAHgrQABgFAFgBIG9AAQAGABgBAFIgKArQgBAFgFAAg");
	this.shape_39.setTransform(234.75,497.75);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#ACB6BF").s().p("AjkAbQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAIgBgEIAMgrQACgFAFgBIG5AAQABABABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAgBABIgLArQgCAFgFAAg");
	this.shape_40.setTransform(186.5617,497.75);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#ACB6BF").s().p("AoFAbQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIAQgsQADgFAFgBIP2AAQAGABgCAFIgMArQgBAFgGAAg");
	this.shape_41.setTransform(110.2167,497.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#63717F").s().p("Ap6ApQgFAAgBgFIgHgrIAAgDIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAITpAAQAFAAABAFIAJArIAHADIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAQgBABAAABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_42.setTransform(706.025,498.925);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#63717F").s().p("AjdApQgFAAgBgFIgGgrIAAgDIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBQABgDADAAIG3AAQAFAAACAFIAJArIgBADIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABQgBADgEAAg");
	this.shape_43.setTransform(617.7,498.925);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgBQABgFAEAAIG6AAQAEAAACAFIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAEArQABAGgFAAg");
	this.shape_44.setTransform(570.0077,498.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBQABgEAEAAIG3AAQAFAAABAFIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIAEAqQABAGgGAAg");
	this.shape_45.setTransform(521.7571,499.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIABABIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAAAIABACIACAqQAAAGgFAAg");
	this.shape_46.setTransform(474.375,499.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIACgsIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAAAIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAgBIABAAIAAgCQACgEADAAIG6AAQAFAAABAEIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAACIAAAqQAAAGgGAAg");
	this.shape_47.setTransform(426.35,499.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAAAIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAFAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIAAAqQAAAGgGAAg");
	this.shape_48.setTransform(378.625,499.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#63717F").s().p("AjoApQgEAAAAgFIAFgrIABgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBQACgEAEAAIG6AAQADAAACAEIAAAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAACIABAAIAAACIAAAAIAAACIABACIgEArQAAAFgFAAg");
	this.shape_49.setTransform(330.1,499.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#63717F").s().p("AjnApQgFAAABgFIAFgrIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAFAAIG6AAQAEAAABAEIAAABIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABACIgGArQgBAFgFAAg");
	this.shape_50.setTransform(282.4423,499.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBQABgEAFAAIG9AAQAEAAABAEIAAABIAAAAIAAACIABAAIAAADIAAABIAAACIABAAIAAABIAAABIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAADIgJArQgBAFgGAAg");
	this.shape_51.setTransform(234.6429,499.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#63717F").s().p("AjfApQgFAAAAgDIAAgBIAAAAIAAgBIgBgBIAAAAIAAgBIAAgBIgBgBIAAgBIAAgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIgBgBIAAgDIAMgrQACgFAFAAIG6AAQADAAAAAEIABAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIAAAAIAAADIgLArQgBAFgGAAg");
	this.shape_52.setTransform(186.95,499.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#63717F").s().p("AoCAnQAAAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAgBIAAAAIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAQgrQADgGAFAAIP2AAQAEAAAAADIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAADIgNArQgBAGgGAAg");
	this.shape_53.setTransform(110.525,498.875);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#ACB6BF").s().p("Am+AbQgFAAgBgFIgKgrQgBgFAGAAIN4AAQAFAAADAFIAXAsQADAEgGAAg");
	this.shape_54.setTransform(722.1314,491.825);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#ACB6BF").s().p("AjYAbQgGAAgBgFIgGgrQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIG2AAQAGAAABAFIAJArQABAFgGAAg");
	this.shape_55.setTransform(651.4014,491.825);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#ACB6BF").s().p("AjYAbQgFAAgBgFIgHgrQgBgFAGAAIG3AAQAFAAABAFIAJArQABAFgGAAg");
	this.shape_56.setTransform(603.9323,491.825);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#ACB6BF").s().p("AjcAbQgGAAAAgFIgDgrQAAgFAGAAIG5AAQAGAAABAFIAEArQABAFgGAAg");
	this.shape_57.setTransform(556.2571,491.825);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIAAgrQAAgFAFAAIG4AAQAFAAABAFIAEArQAAAFgFAAg");
	this.shape_58.setTransform(508.7,491.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGAAIG6AAQAGAAAAAFIADArQAAAFgFAAg");
	this.shape_59.setTransform(461.175,491.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIACgrQABgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_60.setTransform(413.3929,491.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIADgrQAAgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_61.setTransform(365.525,491.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGAAIG5AAQAGAAAAAFIgDArQgBAFgGAAg");
	this.shape_62.setTransform(318.15,491.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQABgFAFAAIG6AAQAGAAgCAFIgFArQgBAFgFAAg");
	this.shape_63.setTransform(270.2,491.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#ACB6BF").s().p("AjiAbQgGAAABgFIAHgrQABgFAFAAIG9AAQAGAAgBAFIgKArQgBAFgFAAg");
	this.shape_64.setTransform(222.6255,491.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#ACB6BF").s().p("AjkAbQgFAAABgFIAMgrQACgFAFAAIG5AAQABAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgLArQgCAFgFAAg");
	this.shape_65.setTransform(174.8117,491.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#ACB6BF").s().p("AnAAbQgGAAACgFIAQgsQACgEAGAAINtAAQAAAAABAAQABAAAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgNArQgCAFgFAAg");
	this.shape_66.setTransform(105.5183,491.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#63717F").s().p("AnDApQgGAAgBgGIgJgqQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBQABgDAEAAIN4AAQAFAAABAGIAbAqQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAABIAAABIgBAAQgBADgDAAg");
	this.shape_67.setTransform(721.725,493.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#63717F").s().p("AjeApQgEAAgBgGIgHgqQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAgBIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAAAIAAAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAQABgDAEAAIG2AAQAGAAAAAGIAJAqIAAAEIAAAAIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAIgBABIAAABQgBACgDAAg");
	this.shape_68.setTransform(650.85,493.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#63717F").s().p("AjdApQgFAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABgBQABgDADAAIG3AAQAGAAABAGIAIAqQABABAAAAQAAAAAAABQAAAAAAAAQAAAAgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABQgBADgDAAg");
	this.shape_69.setTransform(603.475,493.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#63717F").s().p("AjkArQgFgBAAgFIgDguIABAAIAAgBIAAgBIAAgCIABAAIAAgDIAAAAIAAgCIABgBIAAgBIAAAAIAAgDIABAAIAAgCIAAgBIAAgCIABAAIAAgBIAAgBIAAgCIABgBIAAgCIAAAAIAAgBIABgBQAAgFAFAAIG5AAQAFAAABAFIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIAFArQABAGgGAAg");
	this.shape_70.setTransform(556.3571,493.35);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAAAIAAgCIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAgBQACgEADAAIG4AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAADIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAAAIABACIAEAqQAAAGgFAAg");
	this.shape_71.setTransform(508.525,493.35);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#63717F").s().p("AjkApQgFAAgCgFIAAgtIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAAAIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgBIABAAQABgFAEAAIG7AAQAEAAACAFIAAABIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIADAsQAAAFgFAAg");
	this.shape_72.setTransform(461.15,493.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#63717F").s().p("AjmApQgFAAAAgFIACgrIABgBIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAEAAIG7AAQAEAAABAFIAAAAIAAAAIAAABIABABIAAABIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIAAABIAAABIABAAIAAAtQAAAFgGAAg");
	this.shape_73.setTransform(413.4,493.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#63717F").s().p("AjmApQgGAAABgFIADgsIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBQABgFAEAAIG6AAQAEAAABAFIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAArQAAAFgGAAg");
	this.shape_74.setTransform(365.5179,493.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#63717F").s().p("AjnApQgGAAABgFIAFgrIABgBIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAFAAIG6AAQAEAAABAEIAAABIAAABIABAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAABIABACIgEArQAAAFgGAAg");
	this.shape_75.setTransform(318.0429,493.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#63717F").s().p("AjmApQgGAAABgFIAFgrIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQACgFAEAAIG6AAQAEAAABAEIAAABIAAAAIAAABIABABIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABABIAAABIAAAAIAAACIABABIAAACIAAABIAAACIABAAIAAACIgGArQAAAFgGAAg");
	this.shape_76.setTransform(270.0929,493.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIAAgBIABAAIAAgDIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBQACgFAEAAIG9AAQAEAAABAEIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAADIAAACIgJArQgBAFgGAAg");
	this.shape_77.setTransform(222.5423,493.15);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#63717F").s().p("AjgApQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgCIAAAAIAAgBIAAgBIAAgCIALgrQACgGAFAAIG5AAQAEAAABAEIAAAAIAAABIABABIAAAAIAAABIAAABIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAADIgLArQgCAFgFAAg");
	this.shape_78.setTransform(175.2,493.15);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#63717F").s().p("Am9AnQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIAAgDIAQgsQACgFAFAAINtAAQABAAABAAQAAABABAAQAAAAABABQAAAAAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIgNArQgBAGgGAAg");
	this.shape_79.setTransform(105.8625,492.925);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#ACB6BF").s().p("Aj9AcQgEAAgCgGIgNgrQgCgGAGAAIIIAAQAEABACAEIAPAsQACAGgGAAg");
	this.shape_80.setTransform(739.45,486);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#ACB6BF").s().p("AjWAcQgGAAgBgGIgKgrQAAgGAFAAIG6AAQAFAAACAGIAJArQABAGgGAAg");
	this.shape_81.setTransform(687.9,486);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgFAAg");
	this.shape_82.setTransform(640.1,486);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgGAAg");
	this.shape_83.setTransform(592.125,486);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#ACB6BF").s().p("AjcAcQgGAAAAgGIgCgrQgBgGAGAAIG6AAQAFAAABAGIAEArQABAGgFAAg");
	this.shape_84.setTransform(544.2255,486);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIAAgrQAAgGAFAAIG4AAQAFAAABAGIAEArQABAGgGAAg");
	this.shape_85.setTransform(496.7071,486);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#ACB6BF").s().p("AjdAcQgGAAAAgGIgBgrQAAgGAGAAIG6AAQAFAAABAGIADArQAAAGgGAAg");
	this.shape_86.setTransform(448.775,486);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAFAAIG7AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_87.setTransform(400.725,486);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAHAAIG5AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_88.setTransform(352.85,486);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#ACB6BF").s().p("AjgAcQgGAAABgGIAGgrQABgGAFAAIG6AAQAFAAAAAGIgEArQAAAGgFAAg");
	this.shape_89.setTransform(305.0173,486);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#ACB6BF").s().p("AjgAcQgFAAAAgGIAGgrQABgGAFAAIG6AAQAGAAgCAGIgFArQgBAGgFAAg");
	this.shape_90.setTransform(257.25,486);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ACB6BF").s().p("AjiAcQgGAAACgGIAFgrQABgGAGAAIG9AAQAFAAgBAGIgJArQgBAGgGAAg");
	this.shape_91.setTransform(209.5,486);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#ACB6BF").s().p("AjjAcQgGAAABgGIAMgrQABgGAGAAIG5AAQAGAAgBAGIgMArQgBAGgGAAg");
	this.shape_92.setTransform(161.675,486);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#ACB6BF").s().p("AlyAcQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIARgsQACgEAFgBILQAAQABAAABABQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_93.setTransform(99.5617,486);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#63717F").s().p("AkAAsQgHAAAAgGIgOgrIAAgDIABgBIAAgBIAAAAIAAgCIABAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBQABgEAEAAIIIAAQAEAAACAFIAPAsQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAABIAAABIgBABIAAABIAAABIAAABIgBABIAAABIAAABIAAABQgBADgDAAg");
	this.shape_94.setTransform(739.05,487.625);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#63717F").s().p("AjbApQgGAAgBgFIgJgrQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBQABgDAEAAIG6AAQAFAAACAGIAIAqIAAADIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAQgBADgEAAg");
	this.shape_95.setTransform(687.425,487.35);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#63717F").s().p("AjdApQgGAAgBgGIgHgqIABgDIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQAAgDAEAAIG3AAQAGAAABAGIAJAqIgBAEIAAAAIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBABIAAAAIAAABIAAABIAAAAIAAABIgBAAIAAAAIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABQAAAAgBABQAAAAAAAAQgBABgBAAQAAAAgBAAg");
	this.shape_96.setTransform(639.55,487.35);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#63717F").s().p("AjcApQgGAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQABgDAEAAIG3AAQAFAAABAGIAIAqIAAAEIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABQAAADgEAAg");
	this.shape_97.setTransform(591.65,487.35);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAAAQAAgFAFAAIG6AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAEArQABAGgGAAg");
	this.shape_98.setTransform(544.3071,487.525);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#63717F").s().p("AjnArQgGAAAAgFIAAgrIABgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBQABgDAEAAIG4AAQAEAAACAEIAAACIAAABIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAABIAAABIABAAIAEAsQABAFgGAAg");
	this.shape_99.setTransform(496.5321,487.55);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIG7AAQAEAAABAEIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIACAqQAAAGgFAAg");
	this.shape_100.setTransform(448.725,487.35);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#63717F").s().p("AjmApQgGAAABgGIACgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAAsQAAAGgGAAg");
	this.shape_101.setTransform(400.7179,487.35);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAAsQAAAGgGAAg");
	this.shape_102.setTransform(352.825,487.35);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#63717F").s().p("AjoApQgFAAABgGIAFgqIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG6AAQADAAACADIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAABIABAAIAAACIAAABIAAACIgDAqQgBAGgFAAg");
	this.shape_103.setTransform(304.9173,487.35);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#63717F").s().p("AjmApQgGAAABgGIAFgqIABgCIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCQACgEAEAAIG6AAQAEAAABADIAAABIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAADIgGAqQAAAGgGAAg");
	this.shape_104.setTransform(257.1429,487.35);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#63717F").s().p("AjoApQgGAAABgGIAHgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgDIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCQABgEAFAAIG9AAQAEAAABADIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAADIgJArQgBAFgGAAg");
	this.shape_105.setTransform(209.3929,487.35);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#63717F").s().p("AjfApQgEAAgBgDIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgDIAMgqQABgGAGAAIG5AAQAEAAABADIAAABIAAAAIAAACIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAAAIAAACQAAABABAAQAAAAAAAAQAAABAAAAQgBAAAAABIgLArQgBAFgGAAg");
	this.shape_106.setTransform(162.075,487.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#63717F").s().p("AluAnQgBAAgBAAQgBgBAAAAQgBAAAAgBQAAAAgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgDIAQgsQACgFAGAAILQAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_107.setTransform(99.9,487.125);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#ACB6BF").s().p("AoJAbQgFAAgBgFIgIgrQgBgFAGAAIQXAAQAGAAABAFIALArQABABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_108.setTransform(711.0623,480.325);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#63717F").s().p("AoNApQgFAAgBgFIgHgrQAAgBgBAAQAAAAAAAAQAAgBAAAAQABAAAAAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBQAAgEAEAAIQYAAQAFAAACAFIALAsIAAADIgBAAIAAABIAAAAIAAABIgBABIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAABQgBADgEAAg");
	this.shape_109.setTransform(710.625,481.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#ACB6BF").s().p("AjOAbQgFAAgBgFIgHgrQgBgFAFAAIGnAAQAFAAABAFIAHArQAAAFgFAAg");
	this.shape_110.setTransform(633.9923,480.325);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#63717F").s().p("AjQApQgGAAgBgFIgHgrQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgDIABAAIAAgDIABAAIAAgCIAAgBIAAgDIABAAIAAgDIAAAAIAAgCIABAAIAAgEIAAAAIAAgCIABgBIAAgCIAAgBIAAAAQABgEADAAIGnAAQAFAAABAGIAHAqIAAADIAAABIgBABIAAACIAAABIAAADIgBABIAAACIAAAAIAAACIgBABIAAADIAAABIAAACIgBAAIAAACIgBACIAAACIAAABQAAADgEAAg");
	this.shape_111.setTransform(633.75,481.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_112.setTransform(588.3505,480.325);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#63717F").s().p("AjSApQgFAAgBgFIgGgrIAAgCIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAEAAIGmAAQAGAAABAGIAEAqIAAADIAAABIAAAAIgBABIAAABIAAABIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBABIAAAAIAAABIAAABIgBABIAAABIAAAAIAAADIgBAAIAAACQgBADgEAAg");
	this.shape_113.setTransform(587.975,481.7);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_114.setTransform(543.0505,480.325);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#63717F").s().p("AjTAmQgFAAgBgFIgFgrIAAgDIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAGAAABAFIAEArIAAACIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABQgBADgEAAg");
	this.shape_115.setTransform(542.675,481.425);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#ACB6BF").s().p("AjRAbQgFAAAAgFIgDgrQgBgFAGAAIGnAAQAFAAAAAFIACArQAAAFgFAAg");
	this.shape_116.setTransform(497.0929,480.325);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#63717F").s().p("AjXAmQgGAAAAgFIgCguIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAFAAABAEIAAABIABABIAAACIAAAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIADAtQAAAFgGAAg");
	this.shape_117.setTransform(496.9,481.425);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#ACB6BF").s().p("AjRAbQgFAAgBgFIgCgrQAAgFAFAAIGpAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_118.setTransform(451.475,480.325);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#63717F").s().p("AjVApQgGAAAAgFIgDgrIABgBIAAgDIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIGpAAQAFAAAAAGIAAADIABAAIAAAFIAAAAIAAAFIABAAIAAAFIAAABIAAADIABABIAAAvQAAAFgGAAg");
	this.shape_119.setTransform(451.275,481.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#ACB6BF").s().p("AjSAbQgGAAABgFIACgrQAAgFAGAAIGiAAQAGAAAAAFIAAArQAAAFgGAAg");
	this.shape_120.setTransform(405.7929,480.325);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#63717F").s().p("AjZApQgFAAAAgFIADgtIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIABAAIAAgBQABgFAEAAIGjAAQAFAAAAAFIAAABIABABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAADIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIAAAAIAAADIABABIAAArQAAAFgGAAg");
	this.shape_121.setTransform(405.7,481.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#ACB6BF").s().p("AjUAbQgFAAAAgFIACgrQABgFAFAAIGmAAQAFAAAAAFIgDArQAAAFgGAAg");
	this.shape_122.setTransform(360.275,480.325);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#63717F").s().p("AjaApQgGAAAAgFIACgrIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgFAEAAIGnAAQAEAAABAFIAAABIAAABIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAABIAAAEIABAAIAAADIAAAAIAAAEIABABIgDArQgBAFgFAAg");
	this.shape_123.setTransform(360.025,481.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#ACB6BF").s().p("AjVAbQgFAAABgFIADgrQABgFAGAAIGlAAQAFAAgBAFIgDArQgBAFgFAAg");
	this.shape_124.setTransform(314.6,480.325);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#63717F").s().p("AjdApQgGAAABgFIAEgrIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBQACgFAEAAIGlAAQAEAAABAEIAAAAIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAACIgEArQAAAFgGAAg");
	this.shape_125.setTransform(314.7679,481.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#ACB6BF").s().p("AjVAbQgGAAABgFIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_126.setTransform(268.7745,480.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#63717F").s().p("AjeApQgHAAACgFIAIgrIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAAAQACgFAEAAIGhAAQAEAAABAEIAAAAIABABIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABACIgFArQAAAFgGAAg");
	this.shape_127.setTransform(268.8015,481.7);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#ACB6BF").s().p("AjVAbQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_128.setTransform(223.2259,480.325);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#63717F").s().p("AjRApQgDAAgCgDIAAgBIAAAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAIgrQACgFAFAAIGhAAQADAAACAEIAAABIABAAIAAACIAAAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAADIgFArQgBAFgEAAg");
	this.shape_129.setTransform(223.6,481.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#ACB6BF").s().p("AjYAbQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAMgrQACgFAFAAIGhAAQAGAAgBAFIgJArQgCAFgFAAg");
	this.shape_130.setTransform(177.5744,480.325);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#63717F").s().p("AjUApQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBIAAAAIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAAAIAAgDIAMgsQABgFAGAAIGhAAQAEAAAAADIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIgJArQgBAFgFAAg");
	this.shape_131.setTransform(178.0125,481.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#ACB6BF").s().p("AjaAbQgFAAACgFIAPgrQABgFAGAAIGhAAQAGAAgCAFIgLArQgCAFgFAAg");
	this.shape_132.setTransform(132.1238,480.325);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#63717F").s().p("AjYApQgDAAgBgDIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgDIgBAAIAAgEIAAAAIAAgCIgBgBIAAAAIABgCIAPgsQABgFAGAAIGhAAQAEAAABAEIAAADIAAAAIAAACIABABIAAADIAAAAIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAAAIAAADIABAAIAAAEIgMArQgBAFgGAAg");
	this.shape_133.setTransform(132.325,481.7);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#ACB6BF").s().p("AjYAbQgFAAABgFIAQgrQACgFAGAAIGdAAQAFAAgBAFIgNArQgBAFgGAAg");
	this.shape_134.setTransform(86.291,480.325);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#63717F").s().p("AjSApQAAAAgBAAQgBAAAAgBQAAAAgBAAQAAgBAAgBIgBAAIAAAAIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAAAIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIAAgDIAQgsQABgFAGAAIGeAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAEIgNArQgCAFgFAAg");
	this.shape_135.setTransform(86.9375,481.7);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#ACB6BF").s().p("AjpAQQgFAAABgFIAHgVQACgFAFAAIHIAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_136.setTransform(90.1744,475.225);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#63717F").s().p("AjiAfQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAAAIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAAAIAAgCIAHgXQACgFAFAAIHIAAQADAAABADIAAAAIABAAIAAABIAAAAIAAABIABABIAAAAIABACIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABABIAAABIABAAIAAABIAAAAIAAABIABACIAAABIABAAIAAABIAAAAIAAABIABAAIAAAAIABABIAAABIAAAAIAAABIABAAIAAABIABACIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAQABABAAAAQAAABAAAAQAAAAAAABQAAAAAAABIgEAVQgBAGgFAAg");
	this.shape_137.setTransform(90.92,476.7);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#ACB6BF").s().p("AjjAQQgFAAgCgFIgFgVQgBgFAFAAIHPAAQAFAAACAFIAFAVQAAABAAAAQABABAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAg");
	this.shape_138.setTransform(739.2367,475.225);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#63717F").s().p("AjpAhQgFAAgCgGIgFgWIAAgDIAAgBIABAAIAAgBIAAAAIAAAAIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAIHPAAQAFAAACAGIAGAWIAAADIgBAAIAAABIgBAAIAAAAIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABQgBADgDAAg");
	this.shape_139.setTransform(738.6,476.875);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHPAAQAFAAABAFIADAVQABAFgFAAg");
	this.shape_140.setTransform(689.1255,475.225);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#63717F").s().p("AjqAhQgFAAgBgGIgEgWIAAgCIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAQAAgEAEAAIHPAAQAFAAABAGIAEAVIAAADIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAAAQgCAEgDAAg");
	this.shape_141.setTransform(688.6,476.875);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHOAAQAGAAABAFIADAVQABAFgFAAg");
	this.shape_142.setTransform(639.3255,475.225);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#63717F").s().p("AjqAfQgFAAgBgFIgDgWQgBgBAAAAQAAAAAAAAQAAAAAAgBQAAAAABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgDADAAIHPAAQAFAAABAFIAEAWIAAACIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABQgBADgEAAg");
	this.shape_143.setTransform(638.775,476.725);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAFAAIHPAAQAGAAABAFIADAVQABAFgGAAg");
	this.shape_144.setTransform(589.4745,475.225);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#63717F").s().p("AjrAfQgFAAgBgFIgEgWIABgDIAAgBIAAAAIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBQAAAAAAgBQABAAAAgBQABAAAAAAQABAAABAAIHPAAQAFAAABAFIAEAWIAAAeQAAAEgFAAg");
	this.shape_145.setTransform(588.825,476.725);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#ACB6BF").s().p("AjnAQQgGAAAAgFIAAgVQAAgFAGAAIHPAAQAFAAAAAFIAAAVQAAAFgFAAg");
	this.shape_146.setTransform(539.65,475.225);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#63717F").s().p("AjtAhQgFAAAAgGIAAgWIAAgCIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAdIAAAAIAAANIAAAAIAAALQgBAGgFAAg");
	this.shape_147.setTransform(539.05,476.875);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#ACB6BF").s().p("AjnAQQgFAAAAgFIAAgVQAAgFAFAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_148.setTransform(489.85,475.225);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#63717F").s().p("AjuAhQgFAAAAgGIAAgWIAAgCIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAVIAAADIAAAAIgBABIAAAAIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABQgBAEgEAAg");
	this.shape_149.setTransform(489.175,476.875);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#ACB6BF").s().p("AjnAQQgGAAABgFIAAgVQgBgFAGAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_150.setTransform(439.8,475.225);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#63717F").s().p("AjqAeQgGAAAAgFIAAgXIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCQABgEAEgBIHPAAQAGABAAAFIAAAXIgBAAIAAABIAAABIAAACIgBAAIAAABIAAABIAAABIgBABIAAACIAAAAIAAADIgBAAIAAABIAAAAIAAACIgBABIAAACIAAAAIAAACIgBABIAAABIAAAAIAAACIgBAAIAAACQgBAEgEAAg");
	this.shape_151.setTransform(439.475,476.65);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#ACB6BF").s().p("AjoAQQgGAAABgFIADgVQABgFAFAAIHLAAQAFAAABAFIABAVQAAAFgGAAg");
	this.shape_152.setTransform(389.7673,475.225);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#63717F").s().p("Aj0AeQgFAAABgFIADgWIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgEAEgBIHLAAQAEABABADIAAABIABAAIAAABIAAABIAAAAIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABADIABAVQAAAFgFAAg");
	this.shape_153.setTransform(389.7673,476.65);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAGgVQACgFAFAAIHLAAQAFAAAAAFIgCAVQAAAFgGAAg");
	this.shape_154.setTransform(339.7089,475.225);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#63717F").s().p("AjyAeQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIAAgEIAGgWIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQACgGAFAAIHKAAQAEABABADIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAABIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIgCAVQAAAFgGAAg");
	this.shape_155.setTransform(339.4917,476.65);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAHgVQABgFAGAAIHKAAQAGAAgBAFIgCAVQAAAFgGAAg");
	this.shape_156.setTransform(289.9161,475.225);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#63717F").s().p("AjyAeQgFAAABgFIAHgWIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAQABgGAGAAIHKAAQAFABAAAEIAAABIAAAAIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAABIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIgCAVQgBAFgFAAg");
	this.shape_157.setTransform(289.6417,476.65);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#ACB6BF").s().p("AjrAQQgFAAACgFIAHgVQACgFAGAAIHKAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_158.setTransform(240.0398,475.225);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#63717F").s().p("Aj3AeQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAABgBIAIgWIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBQACgEAFgBIHKAAQAEABABADIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAACIgEAWQgBAFgFAAg");
	this.shape_159.setTransform(239.6917,476.65);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#ACB6BF").s().p("AjrAQQgFAAABgFIAIgVQACgFAGAAIHKAAQAFAAAAAFIgEAVQgBAFgFAAg");
	this.shape_160.setTransform(190.3089,475.225);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#63717F").s().p("AjuAeQgEAAAAgDIAAgdIAIgWQACgGAGAAIHKAAQAEABAAADIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBABAAAAIgDAWQgBAFgFAAg");
	this.shape_161.setTransform(190.625,476.65);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#ACB6BF").s().p("AjoAQQgGAAACgFIAGgVQACgFAGAAIHHAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIABAEIgEAVQgBAFgFAAg");
	this.shape_162.setTransform(140.3923,475.225);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#63717F").s().p("AjnAhQgDAAgBgEIAAgEIgBAAIAAgGIAAAAIAAgFIgBgBIAAgFIAAAAIAAgGIgBAAIAAgEQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAHgXQACgFAFAAIHIAAQAFAAAAAFIAAAEIAAABIAAAFIABABIAAAFIAAAAIAAAFIABAAIAAAGIAAAAIAAAFIgDAWQgBAGgGAAg");
	this.shape_163.setTransform(140.525,476.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Base
	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#CCD1D6").s().p("Eg9IABfIgOgBQgzgFgygPQhSgYglgqIABhmQAGAJAdAJQA7ASB1AAMB8ngABQBegEAIgTIAEApQABAvgKAhQgCAFgFADQgbAQgqAMQhFAUhZAAg");
	this.shape_164.setTransform(414.7094,544.625);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#BFC5CC").s().p("Eg9/AF6QhygEgrgXQgVgMACgLID9qLQAMgeBbgOQAtgHArgBITOAAUBeOgAEACqAAEQBrADArAeQAWAQAAAOIDwKCQALAdhBANIhEAGg");
	this.shape_165.setTransform(414.5991,502.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_165},{t:this.shape_164}]}).wait(1));

	// white screen
	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("Eg6nAhgMAAAhC+MB1PAAAMAAABC+g");
	this.shape_166.setTransform(415.625,235.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_166).wait(1));

	// Shadow
	this.instance_2 = new lib.Bitmap3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-15.1,450.85,2.603,2.603);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_vector, new cjs.Rectangle(-15.1,0,874.6,583.6), null);


(lib.laptop_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.laptop = new lib.laptop_vector();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(0.2,-0.05,0.6058,0.6058,0,0,0,0.3,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_mc, new cjs.Rectangle(-9.1,0,529.8000000000001,353.5), null);


(lib.laptop_ai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop.cache(-560,-555,1120,1110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.laptop = new lib.laptop_mc();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(156.3,106.5,1,1,0,0,0,156.3,106.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_ai, new cjs.Rectangle(-9.1,0,529.8000000000001,353.5), null);


(lib.innerui_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.ColumnsAndRows_();
	this.instance.parent = this;
	this.instance.setTransform(221.35,93.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape.setTransform(141.4,43.4,0.1303,0.1303,0,0,0,0.7,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_1.setTransform(143,41.95,0.1303,0.1303,0,0,0,1.7,1.2);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("EhmMAAFIAAgJMDMZAAAIAAAJg");
	this.shape_2.setTransform(228.2,43.35,0.1303,0.1303,0,0,0,0.7,1.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_3.setTransform(141.4,111.8,0.1303,0.1303,0,0,0,0.7,1.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_4.setTransform(141.4,108.55,0.1303,0.1303,0,0,0,0.7,1.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_5.setTransform(141.4,105.2,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_6.setTransform(141.4,101.95,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_7.setTransform(141.4,98.7,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_8.setTransform(141.4,95.45,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_9.setTransform(141.4,92.2,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_10.setTransform(141.4,88.9,0.1303,0.1303,0,0,0,0.7,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_11.setTransform(141.4,85.65,0.1303,0.1303,0,0,0,0.7,1.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_12.setTransform(141.4,82.4,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_13.setTransform(141.4,79.15,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_14.setTransform(141.4,75.9,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_15.setTransform(141.4,72.55,0.1303,0.1303,0,0,0,0.7,0.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_16.setTransform(141.4,69.4,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_17.setTransform(141.4,66.15,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_18.setTransform(141.4,62.8,0.1303,0.1303,0,0,0,0.7,0.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_19.setTransform(141.4,59.6,0.1303,0.1303,0,0,0,0.7,1.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_20.setTransform(141.4,56.3,0.1303,0.1303,0,0,0,0.7,1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_21.setTransform(141.4,53.1,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_22.setTransform(141.4,49.85,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_23.setTransform(309.1,41.95,0.1303,0.1303,0,0,0,0.9,1.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_24.setTransform(299.35,41.95,0.1303,0.1303,0,0,0,1.2,1.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_25.setTransform(289.65,41.95,0.1303,0.1303,0,0,0,1.5,1.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_26.setTransform(279.85,41.95,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_27.setTransform(270,41.95,0.1303,0.1303,0,0,0,0.9,1.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_28.setTransform(260.2,41.95,0.1303,0.1303,0,0,0,0.9,1.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_29.setTransform(250.5,41.95,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_30.setTransform(240.65,41.95,0.1303,0.1303,0,0,0,0.7,1.2);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_31.setTransform(230.9,41.95,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_32.setTransform(221.1,41.95,0.1303,0.1303,0,0,0,1.1,1.2);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_33.setTransform(211.2,41.95,0.1303,0.1303,0,0,0,0.1,1.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_34.setTransform(201.7,41.95,0.1303,0.1303,0,0,0,0.7,1.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_35.setTransform(191.85,41.95,0.1303,0.1303,0,0,0,0.4,1.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_36.setTransform(182.1,41.95,0.1303,0.1303,0,0,0,0.6,1.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_37.setTransform(172.35,41.95,0.1303,0.1303,0,0,0,1.2,1.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_38.setTransform(162.6,41.95,0.1303,0.1303,0,0,0,0.7,1.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#999999").s().p("AgEBoIAAjPIAJAAIAADPg");
	this.shape_39.setTransform(152.8,41.95,0.1303,0.1303,0,0,0,0.9,1.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#999999").s().p("Ah/AFIAAgJID+AAIAAAJg");
	this.shape_40.setTransform(141.4,46.5,0.1303,0.1303,0,0,0,0.7,0.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#B4B4B4").s().p("Ag7A8IB3h3IAAB3g");
	this.shape_41.setTransform(141.8,42.05,0.1303,0.1303,0,0,0,0.6,1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#999999").s().p("EgAEAqJMAAAhUSIAJAAMAAABUSg");
	this.shape_42.setTransform(143,78.4,0.1303,0.1303,0,0,0,0.7,0.9);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#999999").s().p("EgAEAqJMAAAhUSIAJAAMAAABUSg");
	this.shape_43.setTransform(313.4,78.4,0.1303,0.1303,0,0,0,0.9,0.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#999999").s().p("An3AFIAAgJIPvAAIAAAJg");
	this.shape_44.setTransform(146.3,113.6,0.1303,0.1303,0,0,0,0.6,1.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#999999").s().p("EhZQAAFIAAgJMCyhAAAIAAAJg");
	this.shape_45.setTransform(238.95,113.6,0.1303,0.1303,0,0,0,0.3,1.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#1E7446").s().p("AgaAmIAAgOQALAIANAAQAQAAAAgMQAAgDgCgCIgEgEIgGgDIgPgIIgHgEIgEgGQgCgDAAgFQAAgGADgEQACgEAFgDQAEgDAGgCIAKgBQAMAAAHADIAAANQgJgFgLAAIgGAAIgFADIgDADIgBAFIABAFIADAEIAVAKIAIAEQACACACAEQACAEAAAFQAAAHgDADQgCAFgFADQgEADgGABIgLABQgNAAgJgEg");
	this.shape_46.setTransform(161.55,115.2,0.1303,0.1303,0,0,0,0.7,0.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#1E7446").s().p("AgaAmIAAgOQAMAIALAAQAQAAABgMQgBgDgBgCIgEgEIgFgDIgQgIIgHgEQgEgCAAgEQgCgDAAgFQAAgGADgEQACgEAFgDIAKgFQAGgBAFAAQALAAAHADIAAANQgIgFgMAAIgGAAIgFADQgBAAAAABQgBAAAAAAQAAABgBAAQAAABAAAAIgBAFQgBADACACIADAEIAFADIARAHIAHAEIAEAGQACAEAAAFQAAAFgDAFQgDAFgEADQgDADgHABIgLABQgMAAgKgEg");
	this.shape_47.setTransform(160.6,115.2,0.1303,0.1303,0,0,0,0.3,0.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#1E7446").s().p("AgZAfQgJgKAAgVQAAgRAKgMQALgMAPAAQAQAAAJAKQAIALAAASIAAAFIg4AAQAAANAHAIQAHAIALAAQAOAAAMgJIAAAMQgLAHgSAAQgQAAgKgLgAgNgYQgGAHgCAKIArAAQAAgLgFgGQgGgGgJAAQgJAAgGAGg");
	this.shape_48.setTransform(159.6,115.2,0.1303,0.1303,0,0,0,0.2,0.6);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#1E7446").s().p("AAVAqIAAguQAAgZgTAAQgIAAgHAGQgHAJAAAKIAAAuIgNAAIAAhQIANAAIAAANIABAAQAJgQAQAAQANAAAIAJQAHAIAAARIAAAxg");
	this.shape_49.setTransform(158.5,115.2,0.1303,0.1303,0,0,0,0.6,0.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#1E7446").s().p("AgJAeIAAgvIgOAAIAAgLIAOAAIAAgUIAMgEIAAAYIAVAAIAAALIgVAAIAAAsQAAAIADAEQADADAGAAQAGAAADgCIAAALQgFACgHAAQgVAAAAgXg");
	this.shape_50.setTransform(157.5,115.05,0.1303,0.1303,0,0,0,0.4,0.9);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#1E7446").s().p("AgGA7IAAhQIAMAAIAABQgAgFgsQgCgCgBgEQABgEACgCQACgCADAAQADAAADACQADADgBADQABADgDADQgEADgCAAQgDAAgCgDg");
	this.shape_51.setTransform(156.9,114.95,0.1303,0.1303,0,0,0,0.8,0.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#1E7446").s().p("AgcA5IAAhxIA5AAIAAAMIgrAAIAAAnIAnAAIAAALIgnAAIAAAzg");
	this.shape_52.setTransform(156.2,115.05,0.1303,0.1303,0,0,0,0.6,1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#868686").s().p("Ag4A5QgYgXAAgiQAAghAYgXQAYgYAgAAQAiAAAXAYQAYAXAAAhQAAAhgYAYQgXAYgiAAQggAAgYgYgAgxgxQgVAUAAAdQAAAdAVAVQAVAVAcAAQAeAAAUgVQAVgVAAgdQAAgcgVgVQgUgVgeAAQgcAAgVAVg");
	this.shape_53.setTransform(167.3,115.25,0.1303,0.1303,0,0,0,0.5,0.6);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#868686").s().p("AgEAkIAAgfIgfAAQgFAAAAgFQAAgEAFAAIAfAAIAAgfQAAgFAEAAQAFAAAAAFIAAAfIAfAAQAFAAAAAEQAAAFgFAAIgfAAIAAAfQAAAFgFAAQgEAAAAgFg");
	this.shape_54.setTransform(167.3,115.25,0.1303,0.1303,0,0,0,0.5,0.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#B3B3B3").s().p("AgJAKQgEgEgBgGQABgFAEgEQAEgEAFAAQAGAAAFAEQADAEAAAFQAAAGgDAEQgFAEgGAAQgFAAgEgEg");
	this.shape_55.setTransform(219.35,115.85,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#B3B3B3").s().p("AgJAKQgEgEgBgGQABgFAEgEQAEgFAFABQAGgBAFAFQADAEAAAFQAAAGgDAEQgFAFgGAAQgFAAgEgFg");
	this.shape_56.setTransform(219.35,115.35,0.1303,0.1303,0,0,0,1,1.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#B3B3B3").s().p("AgJAKQgEgEgBgGQABgFAEgEQAEgFAFAAQAGAAAFAFQADAEAAAFQAAAGgDAEQgFAEgGABQgFgBgEgEg");
	this.shape_57.setTransform(219.35,114.8,0.1303,0.1303,0,0,0,1,1.1);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#5E605F").s().p("AgUgoIApAoIgpApg");
	this.shape_58.setTransform(147.45,115.2,0.1303,0.1303,0,0,0,1,0.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#5E605F").s().p("AgTAAIAngoIAABRg");
	this.shape_59.setTransform(143.6,115.2,0.1303,0.1303,0,0,0,0.3,0.6);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#5E605F").s().p("AgVAAIArgrIAABXg");
	this.shape_60.setTransform(222.35,115.45,0.1303,0.1303,0,0,0,0.9,1.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#ABABAB").ss(0.3).p("ABFBKIiJAAIAAiTICJAAg");
	this.shape_61.setTransform(222.4,115.45,0.1303,0.1303,0,0,0,0.8,1.1);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AhEBKIAAiTICJAAIAACTg");
	this.shape_62.setTransform(222.4,115.45,0.1303,0.1303,0,0,0,0.8,1.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#5E605F").s().p("AgVgrIArArIgrAsg");
	this.shape_63.setTransform(312.9,115.45,0.1303,0.1303,0,0,0,0.8,1.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#ABABAB").ss(0.3).p("AhEhJICJAAIAACTIiJAAg");
	this.shape_64.setTransform(312.95,115.45,0.1303,0.1303,0,0,0,1,1.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AhEBKIAAiTICJAAIAACTg");
	this.shape_65.setTransform(312.95,115.45,0.1303,0.1303,0,0,0,1,1.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#5E605F").s().p("AgrAWIArgrIAsArg");
	this.shape_66.setTransform(315.65,42.4,0.1303,0.1303,0,0,0,1,1.3);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#ABABAB").ss(0.3).p("ABKBFIiTAAIAAiJICTAAg");
	this.shape_67.setTransform(315.65,42.45,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AhJBFIAAiJICTAAIAACJg");
	this.shape_68.setTransform(315.65,42.45,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#5E605F").s().p("AgrgVIBXAAIgsArg");
	this.shape_69.setTransform(315.65,112.85,0.1303,0.1303,0,0,0,1,1.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#ABABAB").ss(0.3).p("AhJhEICTAAIAACJIiTAAg");
	this.shape_70.setTransform(315.65,112.85,0.1303,0.1303,0,0,0,1,1.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AhJBFIAAiJICTAAIAACJg");
	this.shape_71.setTransform(315.65,112.85,0.1303,0.1303,0,0,0,1,1.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#D2D2D2").ss(0.3).p("A4vhFMAxfAAAIAACKMgxfAAAg");
	this.shape_72.setTransform(243.9,115.45,0.1303,0.1303,0,0,0,0.8,1.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("A4vBFIAAiJMAxfAAAIAACJg");
	this.shape_73.setTransform(243.9,115.45,0.1303,0.1303,0,0,0,0.8,1.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#D2D2D2").ss(0.3).p("ABGffIiLAAMAAAg+9ICLAAg");
	this.shape_74.setTransform(315.6,69.75,0.1303,0.1303,0,0,0,1.3,1.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgWKTIAA0lIAtAAIAAUlg");
	this.shape_75.setTransform(315.65,69.8,0.3983,0.3983,0,0,0,0.6,0.2);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#DBDBDB").s().p("Eg1MABMIAAiYMBqZAAAIAACYg");
	this.shape_76.setTransform(267.7,115.35,0.1303,0.1303,0,0,0,1,0.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#DBDBDB").s().p("EgBLApHMAAAhSNICYAAMAAABSNg");
	this.shape_77.setTransform(315.65,77.55,0.1303,0.1303,0,0,0,1,0.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#8B8B8B").s().p("AgrgOIAOgOIAdAeIAegeIAOAOIgsArg");
	this.shape_78.setTransform(316.05,38.2,0.1303,0.1303,0,0,0,0.9,0.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#C5C5C5").s().p("AApArIgUgXIgUgVIgBAAIgBABIgTAVIgVAVQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAAAAAIAAgBQAAgNAKgRQAEgFAHgGIAMgJIABAAIghggIAAgBIAAAAQAPAAAPALQAHAEAGAJQATgNAVgKIABAAIAAABIgjAeIACABQAUAaAMAZIAAABg");
	this.shape_79.setTransform(159.95,38.3,0.1303,0.1303,0,0,0,0.3,0.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#777777").s().p("AgnBFQgEgBgCgCQgCgDAAgDQABgEADgCQAFgDAEAFIAEAFQABABAAAAQAAABABAAQAAAAABAAQABAAAAAAQAEgCADgFQAEgIABgJIAOg9IgOAAIACgGIAKAAQACAAABgEQABgJAGgJQAHgLAKgEQAJgEAHACQAFABABAFQABAEgCADQgFAFgGgFIgEgGIAAAAQgBgBAAAAQgBgBAAAAQgBAAAAAAQgBAAgBABQgDABgCAEIgFAOIgDAMIAAACIARAAIgBAGIgRAAIgNA9QgDAJgHAJQgHAHgGADQgFACgFAAIgFAAg");
	this.shape_80.setTransform(169.05,38.35,0.1303,0.1303,0,0,0,0.6,1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#777777").s().p("AgiAiQgBgBAAAAQgBAAAAgBQAAAAgBgBQAAgBAAAAQgCgHAHgCQADgBAFABIAEABIABAAIALgOIADgEQAAAAAAgBQAAAAABAAQAAgBAAAAQAAAAgBgBIgGgTIgCgFQgBgDgEAAIgJABIgCAAIACgEIAAAAIANgFQAJgDAEAJIAFAUIAAABIABgCIAIgMIAJgKQAFgDAEAAQAGAAABAFIAAADQAAABAAAAQAAABAAAAQAAABgBAAQAAAAgBABQgCACgDAAQgEABgGgCIgBAAQgHAHgHAMQAAAAAAAAQgBABAAAAQAAAAABAAQAAABAAAAIAFASQACAFADADQADABADAAIAJgBIABAAIgBAEIgBABIgMAEQgGABgEgCQgFgCgCgFIgEgSIgEAGQgGAKgGAFQgFAFgEAAQgEAAgCgBg");
	this.shape_81.setTransform(169.75,38.35,0.1303,0.1303,0,0,0,0.4,0.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#C5C5C5").s().p("Ag4AIQgDgDAAgDQAAgEADgCQADgDAFgBQAEABADADIAXAWIA9g8QADgEAEAAQAEAAADAEQADADAAADQAAAFgDACIhLBMg");
	this.shape_82.setTransform(164.75,38.25,0.1303,0.1303,0,0,0,0.4,0.9);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#5E605F").s().p("AgwgXIBgAAIgwAvg");
	this.shape_83.setTransform(152.3,38.1,0.1303,0.1303,0,0,0,1,0.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#B3B3B3").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_84.setTransform(155.65,38.9,0.1303,0.1303,0,0,0,0.7,1.4);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#B3B3B3").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_85.setTransform(155.65,38.3,0.1303,0.1303,0,0,0,0.7,1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#B3B3B3").s().p("AgJAKQgEgEAAgGQAAgFAEgEQAEgEAFAAQAGAAAEAEQAEAEAAAFQAAAGgEAEQgEAEgGAAQgFAAgEgEg");
	this.shape_86.setTransform(155.65,37.75,0.1303,0.1303,0,0,0,0.7,1.3);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#C5C5C5").ss(0.3).p("EBWyAB/MitjAAAIAAj9MCtjAAAg");
	this.shape_87.setTransform(244.4792,38.3711,0.1301,0.1301);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("EhWxAB/IAAj9MCtjAAAIAAD9g");
	this.shape_88.setTransform(244.4792,38.3711,0.1301,0.1301);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#C5C5C5").ss(0.3).p("AIiB/IxDAAIAAj9IRDAAg");
	this.shape_89.setTransform(164.3654,38.3419,0.1301,0.1301);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AohB/IAAj9IRCAAIAAD9g");
	this.shape_90.setTransform(164.3654,38.3419,0.1301,0.1301);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#C5C5C5").ss(0.3).p("AH4B/IvwAAIAAj9IPwAAg");
	this.shape_91.setTransform(146.915,38.3419,0.1301,0.1301);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AikAqIAAhTIFJAAIAABTg");
	this.shape_92.setTransform(146.9106,38.3525,0.3977,0.3977);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("Am/B1IAAjpIN/AAIAADpg");
	this.shape_93.setTransform(158.6028,115.0182,0.1301,0.1301);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#1E7446").s().p("Am/AIIAAgPIN/AAIAAAPg");
	this.shape_94.setTransform(158.6028,116.6475,0.1301,0.1301);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#E6E6E6").s().p("Ay8IvIAAxdMAl5AAAIAARdgAyRH+MAkVAAAIAAu+MgkTAAAg");
	this.shape_95.setTransform(228.5042,76.2358,0.7322,0.7322);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.innerui_2, new cjs.Rectangle(135.3,35.4,182.39999999999998,88.80000000000001), null);


(lib.inner_UI2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ui.cache(-350,-350,700,700,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.ui = new lib.innerui_2();
	this.ui.name = "ui";
	this.ui.parent = this;
	this.ui.setTransform(-4.65,-0.35,1,1,0,0,0,232.5,79.6);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

}).prototype = getMCSymbolPrototype(lib.inner_UI2, new cjs.Rectangle(-101.9,-44.6,182.10000000000002,88.9), null);


(lib.excel_ui_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// txt
	this.txt = new cjs.Text("Personal care", "34px 'Segoe Pro'", "#A2A2A2");
	this.txt.name = "txt";
	this.txt.lineHeight = 48;
	this.txt.lineWidth = 205;
	this.txt.parent = this;
	this.txt.setTransform(114.55,189.75);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg5TBpTMAAAjR8MB0sAAAMAAADR8g");
	mask.setTransform(380.0908,673.875);

	// Livello_1
	this.excel = new lib.ClipGroup();
	this.excel.name = "excel";
	this.excel.parent = this;
	this.excel.setTransform(595.8,329.25,0.8666,0.8666,0,0,0,683,383.9);

	var maskedShapeInstanceList = [this.excel];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.excel).wait(1));

}).prototype = getMCSymbolPrototype(lib.excel_ui_c, new cjs.Rectangle(13.3,4.1,746.9000000000001,1343.7), null);


(lib.CarrotChart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Carrot
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F15925").s().p("AgpAwIgGgGQgZgaACgfQABghAcgXQAWASAGAZQAGAZgLAWQAWgLAZAGQAZAGASAWQgXAcghABIgEABQgdAAgYgYg");
	this.shape.setTransform(70.7917,34.4095,2.6849,2.6849);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F15925").s().p("Ah+CJQgGgCgDgHQgDgHADgHIBgjEIAlAmQACADAGAAQAFAAADgDQAEgEAAgFQAAgEgEgEIgogpQAUgZAegHQAggHAdAOQAjARAMAkQANAlgRAiQgOAcgdAOIhMAlIgqgqQgDgEgFAAQgFAAgEAEQgDADAAAFQAAAFADADIAlAlIhkAxQgDACgEAAIgGgBg");
	this.shape_1.setTransform(24.2592,80.9797,2.6849,2.6849);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(60));

	// orange_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ACNSJQjhhgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDhhgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_7 = new cjs.Graphics().p("ACNSJQjhhgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDhhgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_8 = new cjs.Graphics().p("ACNSJQjhhgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDhhgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_9 = new cjs.Graphics().p("ACLSIQjghfivivQiuivhgjiQhijqAAj/QAAkABjjqQBgjiCuiuQCvivDhhfQDphiD/gBMgACAnXQj/gBjphjg");
	var mask_graphics_10 = new cjs.Graphics().p("ACISIQjghhiviuQiuivhfjjQhijqABj/QAAkABkjqQBgjiCviuQCviuDhhfQDphiD/AAMgAGAnXQj/gBjphjg");
	var mask_graphics_11 = new cjs.Graphics().p("ACCSGQjghhiuivQitiwhejjQhijqACj/QABkBBkjpQBhjhCwiuQCvitDihfQDphhD/ABMgAOAnXQj/gCjphkg");
	var mask_graphics_12 = new cjs.Graphics().p("AB4SDQjghiisiwQitixhdjjQhgjrADj/QADkBBmjpQBijgCwitQCxisDihdQDqhgD/ACMgAdAnXQj/gEjohlg");
	var mask_graphics_13 = new cjs.Graphics().p("ABpR/QjfhkiriyQiriyhbjkQhejsAFj/QAFkABojoQBkjgCyirQCyirDihbQDrheD/AFMgAyAnWQj/gGjnhng");
	var mask_graphics_14 = new cjs.Graphics().p("ABVR5Qjehmipi0Qipi0hYjlQhcjtAIj/QAIkABqjnQBnjfC0ipQC0ipDkhYQDshbD/AHMgBQAnVQj/gIjlhqg");
	var mask_graphics_15 = new cjs.Graphics().p("AA5RxQjchqimi2Qimi3hVjmQhYjvAMj+QAMkABujmQBqjdC3imQC2imDlhVQDuhXD+ALMgB2AnUQj/gMjkhug");
	var mask_graphics_16 = new cjs.Graphics().p("AAWRnQjahviji5Qiii6hQjoQhTjwARj/QARj/BzjjQBujbC6ijQC6iiDmhQQDwhTD+AQMgCpAnRQj+gRjihyg");
	var mask_graphics_17 = new cjs.Graphics().p("AgURaQjZh0idi+Qiei+hLjqQhNjyAYj+QAXj/B4jgQB0jYC+ieQC+ieDphKQDxhND+AXMgDoAnMQj9gYjeh3g");
	var mask_graphics_18 = new cjs.Graphics().p("AhJRJQjVh6iYjDQiXjChEjsQhFj0Afj+QAfj+B/jcQB6jVDDiYQDCiYDrhDQD0hFD9AeMgE0AnEQj9ggjah+g");
	var mask_graphics_19 = new cjs.Graphics().p("AiHQ1QjQiCiRjIQiRjIg6juQg9j3Apj8QAoj9CHjXQCCjQDIiRQDIiRDtg6QD2g9D8AoMgGPAm3Qj8gpjViGg");
	var mask_graphics_20 = new cjs.Graphics().p("AjPQcQjKiLiIjOQiIjOgxjwQgyj5A0j6QAzj7CQjSQCLjKDOiIQDNiIDwgwQD4gyD6AzMgH5AmjQj6g0jPiPg");
	var mask_graphics_21 = new cjs.Graphics().p("AkhP+QjDiVh+jUQh9jVgkjzQgmj6BAj4QBAj4CajKQCVjDDVh9QDTh+DzgkQD6glD3A/MgJ1AmHQj1hAjJiag");
	var mask_graphics_22 = new cjs.Graphics().p("Al9PaQi6ighxjbQhxjcgWj0QgXj8BOj0QBOj0CmjBQCgi6DchxQDahwD0gWQD8gXDzBNMgMBAlfQjyhPi/ilg");
	var mask_graphics_23 = new cjs.Graphics().p("AniOwQivishijiQhijjgGj1QgGj9BejuQBejvCyi1QCsivDjhiQDhhiD1gGQD9gGDuBdMgOeAkmQjthei0ixg");
	var mask_graphics_24 = new cjs.Graphics().p("ApON+Qiii4hRjpQhRjqANj0QANj9BwjnQBwjnC/inQC4iiDphQQDphRD1AMQD8ANDmBvMgRLAjaQjlhvimi/g");
	var mask_graphics_25 = new cjs.Graphics().p("ArANFQiSjGg8jvQg9jvAhjyQAij8CDjcQCDjdDNiWQDFiSDvg9QDvg9DzAiQD6AiDcCCMgUGAh1QjbiDiWjLg");
	var mask_graphics_26 = new cjs.Graphics().p("As0MCQh+jSgmj0Qgmj0A4jtQA6j4CXjPQCXjPDaiCQDSh/DzgmQD0gmDvA4QD2A6DOCWI3MfyQjOiXiCjZg");
	var mask_graphics_27 = new cjs.Graphics().p("AulK3QhojegMj2QgMj2BQjoQBUjwCsi9QCsi/DmhrQDfhnD1gNQD3gMDnBRQDvBTC+CrI6adLQi8irhrjmg");
	var mask_graphics_28 = new cjs.Graphics().p("AwOJkQhNjpAQj2QAQj1BrjdQBvjlDAipQDBipDyhPQDphOD1ARQD2AQDdBrQDjBuCpDAI9mZ7QiojAhPjwg");
	var mask_graphics_29 = new cjs.Graphics().p("AxhIRQgxjxAsjyQAtjyCEjPQCIjWDTiSQDTiRD5g0QDvgxDzAsQDzAtDOCEQDWCICRDRMggZAWWQiRjTgzj3g");
	var mask_graphics_30 = new cjs.Graphics().p("AyXHGQgZj0BGjrQBGjtCZjAQCejHDhh6QDhh7D9gZQDzgYDtBFQDsBGDACZQDGCdB7DgMgikAS0Qh5jggZj8g");
	var mask_graphics_31 = new cjs.Graphics().p("Ay4GFQgBj1BcjkQBcjlCqixQCwi3DshlQDrhlD9gBQD2gBDlBcQDlBcCxCqQC2CvBlDrMgkMAPeQhkjrgBj9g");
	var mask_graphics_32 = new cjs.Graphics().p("AzHFNQAUj1BvjbQBvjdC4iiQC/inDzhRQD0hQD8AUQD0AUDdBuQDcBvCiC5QCnC+BRDxMglXAMYQhQjyAUj8g");
	var mask_graphics_33 = new cjs.Graphics().p("AzJEcQAmjyB/jTQB/jTDEiUQDLiZD5g+QD5g+D6AoQDyAlDUB/QDTB/CUDFQCYDKA+D2MgmLAJjQg+j4Anj6g");
	var mask_graphics_34 = new cjs.Graphics().p("AzCDzQA2jvCNjKQCMjLDOiGQDUiLD8gtQD8guD4A4QDvA2DLCNQDLCMCGDOQCKDTAuD6MgmvAHAQgtj7A4j3g");
	var mask_graphics_35 = new cjs.Graphics().p("Ay1DQQBDjrCYjCQCZjCDVh6QDch+D+gfQD+gfD0BGQDsBEDCCYQDCCYB6DVQB+DbAfD9MgnEAEvQgej+BGjzg");
	var mask_graphics_36 = new cjs.Graphics().p("AymCzQBQjnCii6QChi7DbhvQDjhzD/gSQD/gSDwBTQDoBPC7CiQC6CiBvDZQBzDiASD+MgnQACxQgSj+BSjwg");
	var mask_graphics_37 = new cjs.Graphics().p("AyUCbQBZjjCqizQCpi0DghlQDnhpEAgHQD/gHDtBcQDkBaC0CpQCzCqBlDeQBpDnAID+MgnWABFQgHj/Bdjsg");
	var mask_graphics_38 = new cjs.Graphics().p("AzrJjQADj/BljoQBhjgCxitQCwitDjhdQDqhhD/ACQEBADDpBlQDhBiCtCwQCtCwBdDiQBhDqgCD/g");
	var mask_graphics_39 = new cjs.Graphics().p("AzqIqQAKj/BsjlQBojdC2inQC1ioDmhWQDthaD/AKQEBAKDlBtQDeBoCoC1QCnC2BXDkQBZDtgKD/g");
	var mask_graphics_40 = new cjs.Graphics().p("AzpH7QARj/BxjiQBujaC5ijQC6ijDnhRQDwhTD/AQQEAARDjByQDbBuCjC5QCjC5BRDnQBTDvgQD/g");
	var mask_graphics_41 = new cjs.Graphics().p("AzoHVQAWj+B1jfQBzjZC8ifQC9ifDphMQDyhPD+AWQD/AVDhB3QDZByCfC9QCgC8BMDoQBODxgVD+g");
	var mask_graphics_42 = new cjs.Graphics().p("AzoG4QAaj+B6jdQB1jXC/icQC/icDrhJQDzhLD9AaQEAAZDfB6QDXB2CcC/QCcC/BJDpQBKDygZD+g");
	var mask_graphics_43 = new cjs.Graphics().p("AznGiQAdj9B8jcQB4jWDBiaQDBiaDrhFQD0hJD9AdQD/AdDeB8QDVB4CaDBQCaDBBGDqQBIDzgcD9g");
	var mask_graphics_44 = new cjs.Graphics().p("AzmGSQAfj9B+jaQB6jVDCiZQDCiYDshEQD0hGD9AfQD/AfDcB+QDVB6CYDCQCZDCBDDrQBGDzgeD9g");
	var mask_graphics_45 = new cjs.Graphics().p("AzmGIQAhj9B/jaQB7jUDDiXQDDiYDshCQD1hFD9AgQD+AgDcCAQDUB7CXDDQCXDDBDDrQBED0gfD9g");
	var mask_graphics_46 = new cjs.Graphics().p("AzmGBQAij8CAjaQB7jUDEiWQDDiXDthBQD1hED9AhQD+AhDbCAQDUB8CXDDQCWDEBCDrQBDD0ggD9g");
	var mask_graphics_47 = new cjs.Graphics().p("AzlF+QAhj9CBjZQB8jTDEiXQDDiWDthBQD1hED9AiQD+AhDbCBQDUB8CWDEQCWDEBBDrQBDD0ggD9g");
	var mask_graphics_48 = new cjs.Graphics().p("AzlF9QAij9CAjZQB8jTDEiWQDEiXDthBQD1hDD8AiQD/AhDbCBQDTB8CWDEQCWDEBBDsQBDD0ghD9g");
	var mask_graphics_49 = new cjs.Graphics().p("AzlF9QAij9CAjZQB8jTDEiXQDEiWDthBQD1hDD8AiQD/AhDbCBQDTB8CWDEQCWDEBBDsQBDD0ghD9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-37.474,y:67.7769}).wait(7).to({graphics:mask_graphics_7,x:-32.574,y:67.7769}).wait(1).to({graphics:mask_graphics_8,x:-32.5682,y:67.7769}).wait(1).to({graphics:mask_graphics_9,x:-32.5277,y:67.7764}).wait(1).to({graphics:mask_graphics_10,x:-32.4177,y:67.7752}).wait(1).to({graphics:mask_graphics_11,x:-32.2034,y:67.7725}).wait(1).to({graphics:mask_graphics_12,x:-31.8503,y:67.7662}).wait(1).to({graphics:mask_graphics_13,x:-31.3237,y:67.753}).wait(1).to({graphics:mask_graphics_14,x:-30.5891,y:67.727}).wait(1).to({graphics:mask_graphics_15,x:-29.6122,y:67.6785}).wait(1).to({graphics:mask_graphics_16,x:-28.3593,y:67.5936}).wait(1).to({graphics:mask_graphics_17,x:-26.7972,y:67.4518}).wait(1).to({graphics:mask_graphics_18,x:-24.8937,y:67.2258}).wait(1).to({graphics:mask_graphics_19,x:-22.6189,y:66.8789}).wait(1).to({graphics:mask_graphics_20,x:-19.946,y:66.3643}).wait(1).to({graphics:mask_graphics_21,x:-16.8541,y:65.6224}).wait(1).to({graphics:mask_graphics_22,x:-13.3316,y:64.5792}).wait(1).to({graphics:mask_graphics_23,x:-9.3822,y:63.1431}).wait(1).to({graphics:mask_graphics_24,x:-5.034,y:61.201}).wait(1).to({graphics:mask_graphics_25,x:-0.3288,y:58.6343}).wait(1).to({graphics:mask_graphics_26,x:4.668,y:55.3198}).wait(1).to({graphics:mask_graphics_27,x:9.8421,y:51.1181}).wait(1).to({graphics:mask_graphics_28,x:15.0077,y:45.8681}).wait(1).to({graphics:mask_graphics_29,x:19.5313,y:40.0549}).wait(1).to({graphics:mask_graphics_30,x:23.0403,y:34.3945}).wait(1).to({graphics:mask_graphics_31,x:25.687,y:29.0235}).wait(1).to({graphics:mask_graphics_32,x:27.6131,y:24.0239}).wait(1).to({graphics:mask_graphics_33,x:28.9703,y:19.4645}).wait(1).to({graphics:mask_graphics_34,x:29.8883,y:15.3769}).wait(1).to({graphics:mask_graphics_35,x:30.473,y:11.7646}).wait(1).to({graphics:mask_graphics_36,x:30.811,y:8.6147}).wait(1).to({graphics:mask_graphics_37,x:30.9728,y:5.9042}).wait(1).to({graphics:mask_graphics_38,x:31.0212,y:4.7815}).wait(1).to({graphics:mask_graphics_39,x:31.0879,y:6.6939}).wait(1).to({graphics:mask_graphics_40,x:31.1872,y:8.2572}).wait(1).to({graphics:mask_graphics_41,x:31.2953,y:9.5071}).wait(1).to({graphics:mask_graphics_42,x:31.3969,y:10.4791}).wait(1).to({graphics:mask_graphics_43,x:31.4832,y:11.2086}).wait(1).to({graphics:mask_graphics_44,x:31.5502,y:11.7309}).wait(1).to({graphics:mask_graphics_45,x:31.5976,y:12.0807}).wait(1).to({graphics:mask_graphics_46,x:31.6273,y:12.2928}).wait(1).to({graphics:mask_graphics_47,x:31.6429,y:12.4017}).wait(1).to({graphics:mask_graphics_48,x:31.6486,y:12.4418}).wait(1).to({graphics:mask_graphics_49,x:31.6494,y:12.4489}).wait(11));

	// orange_circles
	this.instance = new lib.orange_circle();
	this.instance.parent = this;
	this.instance.setTransform(30.55,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(60));

	// Grey_circle copy
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(30.55,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(60));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95.4,-58.2,252,252);


(lib.Carrot_chart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Carrot
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F15925").s().p("AgpAwIgGgGQgZgaACgfQABghAcgXQAWASAGAZQAGAZgLAWQAWgLAZAGQAZAGASAWQgXAcghABIgEABQgdAAgYgYg");
	this.shape.setTransform(70.7917,34.4095,2.6849,2.6849);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F15925").s().p("Ah+CJQgGgCgDgHQgDgHADgHIBgjEIAlAmQACADAGAAQAFAAADgDQAEgEAAgFQAAgEgEgEIgogpQAUgZAegHQAggHAdAOQAjARAMAkQANAlgRAiQgOAcgdAOIhMAlIgqgqQgDgEgFAAQgFAAgEAEQgDADAAAFQAAAFADADIAlAlIhkAxQgDACgEAAIgGgBg");
	this.shape_1.setTransform(24.2592,80.9797,2.6849,2.6849);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// orange_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzlF9QAij9CAjZQB8jTDEiXQDEiWDthBQD1hDD8AiQD/AhDbCBQDTB8CWDEQCWDEBBDsQBDD0ghD9g");
	mask.setTransform(31.6494,12.4489);

	// orange_circles
	this.instance = new lib.orange_circle();
	this.instance.parent = this;
	this.instance.setTransform(30.55,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Grey_circle copy
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(30.55,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Carrot_chart, new cjs.Rectangle(-95.4,-58.2,252,252), null);


(lib.bottombar_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#707070").s().p("AgEDIIAAmPIAJAAIAAGPg");
	this.shape.setTransform(179.5982,7.0218,0.2197,0.1336);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#999999").s().p("AADAIIAAgHQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAIgBAAIAAABIAAAHIgCAAIAAgPIACAAIAAAHQAAgBAAAAQABAAAAgBQAAAAAAAAQAAAAABAAQADAAAAADIAAAHg");
	this.shape_1.setTransform(29.275,6.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#999999").s().p("AgBAFIgBgCIgBgDQAAAAAAAAQAAgBABAAQAAAAAAgBQAAAAABgBQAAAAABAAQAAgBAAAAQAAAAAAAAQABAAAAAAIADAAIAAACIgDgBIgBABIgBACIABADIABABIADgBIAAACIgDAAIgCAAg");
	this.shape_2.setTransform(28.275,6.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#999999").s().p("AgCAFIAAgJIACAAIAAACIAAgCIACAAIABAAIAAACIgCgBIgBABIAAACIAAAFg");
	this.shape_3.setTransform(27.475,6.925);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#999999").s().p("AACAFIAAgBQAAAAgBAAQAAABAAAAQgBAAAAAAQAAAAAAAAIgDAAIAAgCQAAgBAAgBQAAAAABgBQAAAAABAAQAAAAABAAIACAAQAAgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAIgCABIAAgBIABgBIACAAQADAAAAAEIAAAFgAgBABIgBABIABACIABAAIACgBIAAgCIAAgBIgCAAIgBABg");
	this.shape_4.setTransform(26.55,6.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#999999").s().p("AgDAEIAAgEIAAgCIABgCIACAAQABAAAAAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQABAAAAAAIAAABIgHAAIABACIABABIAEgBIAAACIgEAAIgDgBgAgBgCIgBACIAFAAIgBgCIgCgBIgBABg");
	this.shape_5.setTransform(25.55,6.925);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#999999").s().p("AgCAFIAAgCIACABQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAAAIAAgBIgBgBIgBgBIgBgBIABgCIACgBIACAAIAAACIgCgBIgBABIAAABIAAABIABAAIABABIABACIgBACIgCAAIgCAAg");
	this.shape_6.setTransform(24.6,6.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#999999").s().p("AgDAEIgBgEQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAABAAQAAABAAAAQAAABABAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAABQgBAAAAAAQAAABAAAAIgEABIgDgBgAgBgCIgBACIABADIABABIACgBIACgDIgCgCIgCgBIgBABg");
	this.shape_7.setTransform(23.1,6.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#999999").s().p("AABAHQAAAAgBgBQAAAAAAAAQAAgBAAAAQgBgBAAgBIAAgEIgBAAIAAgBIABAAIAAgDIABgBIAAAEIADAAIAAABIgDAAIAAAEIAAACIACABIABgBIAAACIgCAAg");
	this.shape_8.setTransform(22.2,6.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#999999").s().p("AgCAEIgBgEIAAgCIACgCIABAAQABAAAAAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQABAAAAAAIAAABIgHAAIABACIABABIAEgBIAAACIgEAAIgCgBgAgBgCIgBACIAEAAIAAgCIgCgBIgBABg");
	this.shape_9.setTransform(20.85,6.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#999999").s().p("AgCAFIAAgJIACAAIAAACIAAgCIACAAIABAAIAAACIgCgBIgBABIAAACIAAAFg");
	this.shape_10.setTransform(20.025,6.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#999999").s().p("AgDAEIgBgEIABgCIABgCIACAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAAAIAAABIgGAAIABACIACABIACgBIAAACIgDAAIgDgBgAgBgCIgBACIAFAAIgBgCIgCgBIgBABg");
	this.shape_11.setTransform(19.1,6.925);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#999999").s().p("AADAIIAAgHQAAAAAAgBQgBAAAAAAQAAAAgBAAQAAAAgBAAIgBAAIAAABIAAAHIgCAAIAAgPIACAAIAAAHQAAgBAAAAQABAAAAgBQAAAAAAAAQAAAAABAAQADAAAAADIAAAHg");
	this.shape_12.setTransform(17.975,6.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#999999").s().p("AgDAEIgBgEIABgCIABgCIACAAQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAABQAAAAAAABQAAAAAAAAIAAABIgGAAIABACIACABIACgBIAAACIgDAAIgDgBgAgBgCIgBACIAEAAIAAgCIgCgBIgBABg");
	this.shape_13.setTransform(16.4,6.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#999999").s().p("AgEAIIAAgOIACAAIAAABQABAAAAAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAABABQAAAAABAAQAAAAAAAAQABABAAAAIABAEIgBACQgBABAAAAQAAAAgBABQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAAAAAQgBgBAAAAQAAAAgBgBIAAAHgAgBgEIgBADIAAABIABABIABABQAAAAAAAAQABAAAAAAQAAgBABAAQAAAAAAgBIABgBIgBgDIgCgBIgBABg");
	this.shape_14.setTransform(15.275,7.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#999999").s().p("AgEAHIAAgCIABABIADgBIAAgCIgEgJIACAAIACAGIAAABIAAgBIADgGIACAAIgFAKQAAABAAABQAAAAAAABQgBAAAAAAQgBAAgBAAIgBAAg");
	this.shape_15.setTransform(14.15,7.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#999999").s().p("AAAAHIAAgMIgEAAIAAgBIAJAAIAAABIgEAAIAAAMg");
	this.shape_16.setTransform(13.15,6.725);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgCAGIAAgCIACABIABgBIABgEQAAABAAAAQgBAAAAAAQAAABgBAAQAAAAAAAAIgCgBIgBgCIABgCQAAgBABAAQAAAAAAAAQABgBAAAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAQAAAAABABIABADQAAAAAAABQAAABgBAAQAAABAAAAQAAABgBAAQAAABAAAAQgBAAAAAAQAAABgBAAQAAAAAAAAIgCAAgAgBgDIAAACIAAABIABABIACgBIAAgBIAAgCIgCAAIgBAAg");
	this.shape_17.setTransform(172.275,8.075);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAAAGIAAgJIAAABIgBAAIAAgBIABgBIABgBIABAAIAAALg");
	this.shape_18.setTransform(171.5,8.075);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgCAFIgBgFIABgDQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAAAQAEAAAAAFIgBAEQgBABAAAAQAAAAAAAAQgBABAAAAQgBAAAAAAIgCgBgAgBAAQAAAFABAAQABAAAAgBQAAAAABAAQAAgBAAgBQAAgBAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAAAgBAAQgBAAAAADg");
	this.shape_19.setTransform(170.825,8.075);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgCAGIAAgBIAAgBIABgCIABgBIABgBIABgBIgBgCIgBAAIgBAAIgBABIAAgBIABgBIABgBIACABIABACIgBACIgBABIgBACIgBABIAAABIAEAAIAAABg");
	this.shape_20.setTransform(169.925,8.075);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgCAGIAEgLIABAAIgEALg");
	this.shape_21.setTransform(169.225,8.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAAAGIAAgJIAAABIgBAAIAAgBIABgBIABgBIABAAIAAALg");
	this.shape_22.setTransform(168.55,8.075);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgCAGIAEgLIABAAIgEALg");
	this.shape_23.setTransform(168.025,8.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AABAFIAAgCIgEAAIAAgBIADgDIABgDIABAAIAAAGIACAAIAAABIgCAAIAAACgAgBABIAAABIACAAIAAgFIgCAEg");
	this.shape_24.setTransform(167.25,8.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAFAGIAAgHIAAgCIgBABIgEAIIAAAAIgDgIIAAgBIAAACIAAAHIgBAAIAAgKIABAAIADAGIAAACIAAgCIAEgGIACAAIAAAKg");
	this.shape_25.setTransform(172.05,6);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AADAGIgBgEIgDAAIgCAEIgBAAIAEgKIABAAIAEAKgAAAgCIgBADIADAAIgBgDIgBgBg");
	this.shape_26.setTransform(170.85,6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgCAFIgBgFIABgDQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAAAQAEAAAAAFIgBAEQAAABgBAAQAAAAgBAAQAAABAAAAQgBAAAAAAIgCgBgAgBAAQAAAFABAAQABAAAAgBQAAAAABAAQAAgBAAgBQAAgBAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAAAgBAAQgBAAAAADg");
	this.shape_27.setTransform(169.525,5.975);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AABAGIAAgJIgBABIgBAAIAAgBIABgBIACgBIAAAAIAAALg");
	this.shape_28.setTransform(168.75,5.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAAAEIAAAAIAAgBIAAgBIAAAAIABAAIAAABIAAABIgBAAgAAAgBIAAAAIAAgBIAAgBIAAAAIABAAIAAABIAAABIgBAAg");
	this.shape_29.setTransform(168.325,6.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgCAFIgBgFIABgDQABAAAAgBQAAAAABAAQAAgBAAAAQAAAAAAAAQAEAAAAAFIgBAEQAAABgBAAQAAAAgBAAQAAABAAAAQgBAAAAAAIgCgBgAgBAAQAAAFABAAQABAAAAgBQAAAAABAAQAAgBAAgBQAAgBAAgBQAAAAAAgBQAAgBAAAAQgBgBAAAAQAAAAgBAAQgBAAAAADg");
	this.shape_30.setTransform(167.725,5.975);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AABAGIAAgJIgBABIgBAAIAAgBIABgBIACgBIAAAAIAAALg");
	this.shape_31.setTransform(166.95,5.975);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAABLQAAgFgBgHQgCgDgFgHQgFgDgEgDQgGgCgGAAQgIAAgEACIgKAGQgEAHgCADQgCAFAAAHIgKAAIABgLQACgGADgEQACgEAFgFIAJgGQgGgEgDgHQgDgGAAgHQAAgHACgEQACgEAEgGIAKgFQAEgDAIAAQAHAAAGADQAGAEAFAFQADgGAEgEQAEgFAGgDQgGgFgDgFQgDgHAAgHQAAgHACgEQABgEAGgGIAJgHQAFgCAHAAQAGAAAFACQAGACAEAFQAFAGABAEQADAFAAAGQAAAFgEAJQgCAFgHAFIAJAHQAGAEACAEQACAEACAFIACALIgKAAQAAgFgDgGQgBgEgFgGQgEgEgGgBQgFgDgGAAQgHAAgFADIgJAFQgGAGgBAEQgCAEAAAHQAAAGgDAHQgCAHgHAEIAJAGQAFAFABAEQADAEACAGIACALgAglgCQgDABgDACIgFAGIgBAIIABAIIAFAGIAGAFIAIABIAHgBIAHgFIAEgGIACgIIgCgIIgEgGQgDgCgEgBIgHgCIgIACgAAWg/QgEACgCADIgFAGIgBAIIABAHIAFAHIAGAEIAIACIAIgCIAGgEIAEgHIACgHIgCgIIgEgGQgDgDgDgCIgIgBIgIABg");
	this.shape_32.setTransform(141.9018,6.8101,0.1313,0.1313);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgdAyIgyAAIAAiBICfAAIAACBIgyAAIgeAegAhFAoIAsAAIAZAaIAZgaIAtAAIAAhtIiLAAg");
	this.shape_33.setTransform(176.5615,6.8757,0.1313,0.1313);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(95,95,95,0.6)").ss(0.1).p("AgEAJQAAgFAEgEQADgDAGAA");
	this.shape_34.setTransform(154.903,6.774);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("rgba(255,255,255,0.4)").s().p("AgSBIQAcgeAAgqQAAgpgcgeIAHgGQAeAgAAAtQAAAugeAgg");
	this.shape_35.setTransform(160.0629,6.9334,0.1312,0.1312);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAAgVIg2A2IgFgGIA7g7IA8A7IgFAGg");
	this.shape_36.setTransform(146.653,6.9269,0.1312,0.1312);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAUA8IgdgeIgUAAIAAg7IAUAAIAdgeIAKAAIAAB3gAgTAUIAOAAIAZAaIAAhaIgWAWIgDADIgOAAg");
	this.shape_37.setTransform(158.597,6.9236,0.1312,0.1312);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgKAeQALgNAAgRQAAgQgLgNIAHgHQAOAPAAAVQAAAWgOAPg");
	this.shape_38.setTransform(159.3709,6.9269,0.1312,0.1312);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgOAzQATgVAAgeQAAgdgTgVIAHgHQAWAYAAAhQAAAigWAYg");
	this.shape_39.setTransform(159.7087,6.9269,0.1312,0.1312);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgJAAQAAgJAJAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgJAAAAgKg");
	this.shape_40.setTransform(155.711,7.5795,0.1312,0.1312);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#FFFFFF").ss(0.1).p("AgCAHQAAgEADgDQACgBAFAA");
	this.shape_41.setTransform(155.103,6.974);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#FFFFFF").ss(0.1).p("AAAAFQAAgCABgCQACgBACAA");
	this.shape_42.setTransform(155.328,7.199);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Ag1AUIAAgnIBrAAIAAAng");
	this.shape_43.setTransform(150.7786,6.9269,0.1312,0.1312);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgHAKIAAgTIAPAAIAAATg");
	this.shape_44.setTransform(151.8084,6.9236,0.1312,0.1312);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AhKAoIAAhPICVAAIAABPgAhAAeICBAAIAAg7IiBAAg");
	this.shape_45.setTransform(150.7918,6.9236,0.1312,0.1312);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgfBRIgCgEIACgFIADgFQgCgDAAgEIAAgOIABgCIAthcIgFgCIgSAmIgCACIgDABQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIABgDIASgmIADgEIAFgCIAGABIAFADIAFgLIACgCIADgBIACAAIAEgHIADgDIAEgBQADAAACACIAHADIAEAEQACACAAADIgBAFIgDAFIACACIABACIAAABIgBACIg5BxIgCACIgNAHIgFABIgCAAIgEAIIgCACIgCABIgEgCgAgUAwIAAAMIABABIACABIABAAIACgCIADgBIAHgEIA1hqIgQgIgAAqhCIAHADIACgFIgHgDgAgtBTQgIAAgGgDQgIgEgEgEQgEgEgEgIQgDgGAAgIQAAgHADgHQADgGAFgFQAFgFAHgDQAGgDAIAAIASAAIgGALIgMAAQgGAAgEACIgJAFQgDADgCAFQgCAFAAAFQAAAGACAEQACAGADADQAEADAFACQAEACAGAAIADAAIgBADIAAAFIABADgAAnAVIAFgLIASAAIAEAAIADgDIACgDIABgEIgBgDIgCgDIgDgDIgEAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAEAAAEACIAGAEQADADACAEQACADAAAEQAAAFgCADQgCAEgDADIgGAEQgEACgEAAg");
	this.shape_46.setTransform(163.4473,6.9269,0.1312,0.1312);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AggAWIAAg1IBBAAIAAA/g");
	this.shape_47.setTransform(3.6247,7.3656,0.1258,0.1258);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgpAaIAAg/IBTAAIAABLg");
	this.shape_48.setTransform(4.6876,7.4442,0.1258,0.1258);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AggAeIAAgyIBBgJIAAA7g");
	this.shape_49.setTransform(3.6247,6.441,0.1258,0.1258);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgpAlIAAg9IBTgMIAABJg");
	this.shape_50.setTransform(4.6876,6.3592,0.1258,0.1258);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("ABABQIAAhLIALAAIAABLgAAVBQIAAgVIhfAAIAAAVIgKAAIAAggIB0AAIAAAggAhUAlIAAhJIB0AAIAABJgAhKAbIBfAAIAAg1IhfAAgAA/gGQgCAAgDgDQgDgDAAgCIgCgGQAAgEACgDIADgFIAFgDIAGgBIAHABIAFADIADAFIABAHIgBAGIgDAFIgFADQgDACgEAAIgGgCgABAgvIAAggIALAAIAAAggAhUgvIAAggIAKAAIAAAVIBfAAIAAgVIALAAIAAAgg");
	this.shape_51.setTransform(55.6215,6.957,0.1377,0.1377);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("rgba(0,0,0,0.4)").s().p("AhUBVQgjgjAAgyQAAgwAjgkQAkgjAwAAQAyAAAjAjQAjAkAAAwQAAAygjAjQgjAjgyAAQgwAAgkgjgAhIhIQgfAeAAAqQAAArAfAfQAeAeAqAAQArAAAegeQAfgfgBgrQABgqgfgeQgegegrAAQgqAAgeAeg");
	this.shape_52.setTransform(10.0016,6.9516,0.1335,0.1335);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AAOAuIgOgfIAAgCIAAgBIAAgCIAAAAIAAABIgCAFIgNAdIgTgBIAWgsIgVgqIAUgBIALAaIABACIABAGIABgGIANgeIAVgCIgZAvIAaAwg");
	this.shape_53.setTransform(80.2422,6.8999,0.135,0.135);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#207346").s().p("AhGBfIAAi9ICNgZIAADvg");
	this.shape_54.setTransform(80.2962,6.9066,0.135,0.135);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_55.setTransform(81.447,7.6694,0.135,0.135);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_56.setTransform(81.447,7.288,0.135,0.135);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_57.setTransform(81.447,6.9033,0.135,0.135);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_58.setTransform(81.447,6.5185,0.135,0.135);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_59.setTransform(81.447,6.1372,0.135,0.135);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_60.setTransform(82.0207,7.6694,0.135,0.135);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_61.setTransform(82.0207,7.288,0.135,0.135);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_62.setTransform(82.0207,6.9033,0.135,0.135);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_63.setTransform(82.0207,6.5185,0.135,0.135);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#207346").s().p("AgNAHIAAgNIAbAAIAAANg");
	this.shape_64.setTransform(82.0207,6.1372,0.135,0.135);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#207346").s().p("Ag+BeQgJAAAAgJIAAipQAAgJAJAAIB+AAQADAAACADQADACAAAEIAACpQAAAEgDACQgCADgDAAgAg+BVIB+AAIAAipIh+AAg");
	this.shape_65.setTransform(81.5516,6.9033,0.135,0.135);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("Ag+BZQgFAAAAgEIAAipQAAgEAFAAIB+AAQAEAAAAAEIAACpQAAAEgEAAg");
	this.shape_66.setTransform(81.5483,6.9033,0.135,0.135);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#76B9ED").s().p("AjvAKIAAgTIHfAAIAAATg");
	this.shape_67.setTransform(80.8767,9.4648,0.135,0.135);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AhJBKQgfgeAAgsQAAgrAfgeQAegfArAAQAsAAAfAfQAeAeAAArQAAAsgeAeQgfAfgsAAQgrAAgegfgAg7g7QgZAZAAAiQAAAjAZAZQAZAYAiAAQAkAAAYgYQAZgZAAgjQAAgigZgZQgZgYgjAAQgiAAgZAYg");
	this.shape_68.setTransform(9.9868,6.9411,0.1335,0.1335);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FAFAFA").s().p("A63DIIAAmPMA1vAAAIAAGPg");
	this.shape_69.setTransform(29.9665,6.9471,0.1313,0.1349);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#3276BC").s().p("Ag2BdQgcgbAAgnQAAgeARgXQAPgXAbgLQgOAPgDAXIBUAAQAAgzgwAAQgdAAgeARQgeARgRAbQAGguAegeQAfgeAugBQAvABAeAfQAfAgAAAxIAAAaIiWAAQAAAYASANQASAOAbAAQAlgBAdgSIAAAzQghARgpAAQgqAAgcgbg");
	this.shape_70.setTransform(74.4935,6.8999,0.135,0.135);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#7FBA00").s().p("AgXAYIAAgvIAvAAIAAAvg");
	this.shape_71.setTransform(68.4945,6.8391,0.135,0.135);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFB900").s().p("AgXAYIAAgwIAvAAIAAAwg");
	this.shape_72.setTransform(68.4945,7.6289,0.135,0.135);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#F25022").s().p("AgYAYIAAgvIAxAAIAAAvg");
	this.shape_73.setTransform(67.7015,6.8391,0.135,0.135);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#00A4EF").s().p("AgYAYIAAgwIAxAAIAAAwg");
	this.shape_74.setTransform(67.7015,7.6289,0.135,0.135);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AheBxQgHAAgGgFQgFgFAAgHIAAiVIBFAAIAAgOQAAgTANgNQANgNARAAQASAAANANQANANAAATIAAAOIALAAIAAgFIgBgKQAAgNgGgLQAPALAAAXIAAAFIAyAAIAACVQAAAHgFAFQgFAFgHAAgAAIhbQgKAEgGAJQgHAJAAALIAAAFIAxAAIAAgOQAAgOgKgLQgKgKgOAAQgNAAgKAKQgKALAAAOIAAAOIALAAIAAgFQAAgUAPgMQAEgCADAAIAIABg");
	this.shape_75.setTransform(68.0963,6.8358,0.135,0.135);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#3AB5E6").s().p("AgEAHIAAgNIAJAAIAAANg");
	this.shape_76.setTransform(60.79,5.8537,0.135,0.135);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgUAHIAAgNIApAAIAAANg");
	this.shape_77.setTransform(61.1106,5.8537,0.135,0.135);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("rgba(255,255,255,0.2)").s().p("AjvDIIAAmPIHfAAIAAGPg");
	this.shape_78.setTransform(80.8399,6.8999,0.135,0.135);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FBD140").s().p("Ag4AZIAAgkQAAgFADgEQADgEAFAAIBHAAQAHAAAFAFIATATIgRATQgGAGgIAAg");
	this.shape_79.setTransform(61.133,5.8875,0.135,0.135);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#3AB5E6").s().p("AAeAtIAAgxIg7AAIAAAxIgoAAIAAhMQAAgGAEgDQADgEAGAAIBwAAQAGAAAEAEQAEADAAAGIAABMg");
	this.shape_80.setTransform(61.9375,7.5749,0.135,0.135);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFE793").s().p("AhiBQQgFAAgDgDQgDgDAAgFIAAiAIBTAAQAJAAAFgFIANgPIBhAAQAFAAAEAEQADADAAAGIAACHQAAAFgDADQgEADgFAAg");
	this.shape_81.setTransform(61.9375,6.9674,0.135,0.135);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("EgjKABKIAAiTMBGVAAAIAACTg");
	this.shape_82.setTransform(90.2039,7.7654,0.3989,0.5102);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_4
	this.instance = new lib.readytxt();
	this.instance.parent = this;
	this.instance.setTransform(13.35,5.9,1,1,0,0,0,11.5,6.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#626262").s().p("AgpApIAAhSIBTAAIAABSgAARAjIASAAIAAgUIgSAAgAgIAjIASAAIAAgUIgSAAgAgjAjIAUAAIAAgUIgUAAgAARAKIASAAIAAgSIgSAAgAgIAKIASAAIAAgSIgSAAgAgjAKIAUAAIAAgSIgUAAgAARgPIASAAIAAgTIgSAAgAgIgPIASAAIAAgTIgSAAgAgjgPIAUAAIAAgTIgUAAg");
	this.shape_83.setTransform(127.0812,1.9569,0.2887,0.2887);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#626262").s().p("AgqAqIAAhTIBVAAIAABTgAgkAjIBIAAIAAhGIgOAAIAAAsIg6AAgAgGAGIAXAAIAAgpIgXAAgAgkAGIAbAAIAAgpIgbAAg");
	this.shape_84.setTransform(141.0244,1.929,0.2899,0.2899);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#626262").s().p("AgPADIAAgFIAgAAIAAAFg");
	this.shape_85.setTransform(134.1744,1.9416,0.2946,0.2946);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#626262").s().p("AgPADIAAgFIAgAAIAAAFg");
	this.shape_86.setTransform(134.1744,1.5291,0.2946,0.2946);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#626262").s().p("AgPADIAAgFIAgAAIAAAFg");
	this.shape_87.setTransform(134.1744,1.1166,0.2946,0.2946);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#626262").s().p("AgcAhIAAhBIA5AAIAABBgAgWAbIAsAAIAAg1IgsAAg");
	this.shape_88.setTransform(134.1744,1.5291,0.2946,0.2946);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#626262").s().p("AgqAqIAAhTIBVAAIAABTgAgjAkIBIAAIAAhHIhIAAg");
	this.shape_89.setTransform(134.1744,1.5291,0.2946,0.2946);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#747474").s().p("AgQADIAAgFIAhAAIAAAFg");
	this.shape_90.setTransform(145.7969,1.6946,0.3034,0.3034);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#747474").s().p("AgNAnIAAhNIAaAAIAABNg");
	this.shape_91.setTransform(156.2193,1.243,0.3028,0.3028);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#CACAC9").s().p("AktAGIAAgLIJbAAIAAALg");
	this.shape_92.setTransform(156.0906,1.4322,0.3028,0.3028);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#626262").s().p("AgCAXIAAgUIgUAAIAAgFIAUAAIAAgUIAFAAIAAAUIAUAAIAAAFIgUAAIAAAUg");
	this.shape_93.setTransform(166.733,1.6946,0.3034,0.3034);

	this.instance_1 = new lib.displaytxt();
	this.instance_1.parent = this;
	this.instance_1.setTransform(109.7,11.5,1,1,0,0,0,10.1,6.7);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#505050").s().p("AANAhIgEgFIgJACIgKgCIgDAEQgDAEgEgDIgGgFQgEgCADgEIAFgGIgDgFIgJgBQgFAAABgEIAAgHQgBgFAFAAIAJAAIAFgIIgHgIQgDgEAFgDIAGgEQAEgDADAEIAGAJIAGgBIAHABIAGgIQACgEAEADIAGAEQAEADgDAEIgFAHQADAEABAFIAKAAQAFAAAAAEIAAAIQAAAEgFAAIgKAAIgCAGIADAGQADAEgEACIgGAFIgDABQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBgAgLgJQgGAFAAAGQAAAHAGAGQAFAFAGAAQAHAAAFgFQAFgGAAgHQAAgGgFgFQgFgFgHAAQgGAAgFAFg");
	this.shape_94.setTransform(103.9932,2.4598,0.2282,0.2282);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#F3F1F0").s().p("AAJAaIgCgEIgHABIgIgBIgCADQgCADgDgCIgFgEQgDgCACgDIAEgEIgCgEIgHAAQgBAAgBgBQAAAAgBAAQAAgBAAAAQAAgBAAgBIAAgFQAAgBAAgBQAAgBAAAAQABAAAAgBQABAAABAAIAHAAQABgDACgDIgEgHQgCgCADgDIAFgDQACgCADADIAFAHIAEgBIAFABIAFgHQACgCADABIAFAEQACACgBADIgFAGIAEAHIAHAAQABAAABAAQAAAAABAAQAAABAAABQABAAAAABIAAAFQAAABgBABQAAAAAAABQgBAAAAAAQgBABgBAAIgHAAIgDAFIAEAEQABADgCACIgFAEIgCAAIgEgBgAAAAQQgEgBgEgEQgEgEAAgHIAAgBIAAADQAAAGADAEQAFAEAEAAIAAAAg");
	this.shape_95.setTransform(103.9005,2.4344,0.3802,0.3802);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#505050").s().p("AgRAgIAAgFIAQAAIAAgLIgjAAIAAguIBJAAIAAAuIgjAAIAAALIAQAAIAAAFg");
	this.shape_96.setTransform(102.6934,1.9101,0.3802,0.3802);

	this.instance_2 = new lib.Percentagetxt();
	this.instance_2.parent = this;
	this.instance_2.setTransform(177.15,6.2,1,1,0,0,0,10.1,6.7);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#F3F2F1").s().p("EgjIAAzIAAhlMBGRAAAIAABlg");
	this.shape_97.setTransform(90.087,2.7942,0.3967,0.5552);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_97},{t:this.instance_2},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.instance_1},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottombar_2, new cjs.Rectangle(0.4,0,179.6,14.1), null);


(lib.bottom_part = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bottombar.cache(-180,-15,360,30,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_5
	this.bottombar = new lib.bottombar_2();
	this.bottombar.name = "bottombar";
	this.bottombar.parent = this;
	this.bottombar.setTransform(129.2,-68.8,1,1,0,0,0,90,5);

	this.timeline.addTween(cjs.Tween.get(this.bottombar).wait(1));

}).prototype = getMCSymbolPrototype(lib.bottom_part, new cjs.Rectangle(39.6,-73.8,179.6,14.099999999999994), null);


(lib.BedChart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Bed
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4355A5").s().p("AB4BVQgGAAAAgHIAAgVIjjAAIAAAVQAAAHgHAAIgOAAQgHAAAAgHIAAibQAAgHAHAAIAOAAQAHAAAAAHIAABbIBjAAIAAg/QAAgHAIAAIBiAAQAUAAAPAPQAPAOAAAVIAABUQAAAHgHAAgAhYgJQgLgLAAgPQAAgOALgLQAKgKAPAAQAPAAAKAKQALALAAAOQAAAPgLALQgKAJgPAAQgPAAgKgJg");
	this.shape.setTransform(614.4295,67.3244,2.7625,2.7625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(49));

	// mask_purple (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EAn9ASJQjjhgiuiuQivivhfjiQhjjqAAkAQAAj/BjjqQBfjiCvivQCuiuDjhgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_7 = new cjs.Graphics().p("EAoVASJQjihgiviuQiuivhgjiQhjjqAAkAQAAj/BjjqQBgjiCuivQCviuDihgQDphiD/gBMAAAAnXQj/gBjphig");
	var mask_graphics_8 = new cjs.Graphics().p("EAoUASJQjihgiuivQiviuhfjiQhjjqAAkAQAAkABjjqQBgjiCviuQCuivDihfQDphiD/gBMgABAnXQj/gBjphig");
	var mask_graphics_9 = new cjs.Graphics().p("EAoQASHQjihgiuivQiuivhfjiQhijrABj/QAAkABkjqQBgjiCvitQCviuDjhfQDphiD/AAMgAIAnXQj/gBjohkg");
	var mask_graphics_10 = new cjs.Graphics().p("EAoDASEQjhhiitiwQitixhdjjQhhjrADj/QADkABljpQBijhCwitQCwitDjhdQDqhgD/ACMgAZAnXQj/gDjohlg");
	var mask_graphics_11 = new cjs.Graphics().p("EAnqAR9QjghliqizQiriyhajlQhdjsAGj/QAHkBBojnQBljgCziqQCziqDkhaQDrhdD/AGMgA9AnWQj/gHjmhog");
	var mask_graphics_12 = new cjs.Graphics().p("EAnAARxQjdhqimi2Qimi3hVjmQhYjvANj/QAMkABujlQBqjeC3imQC2imDnhUQDthYD/AMMgB4AnVQj+gNjlhug");
	var mask_graphics_13 = new cjs.Graphics().p("EAmEARgQjahyigi8Qifi9hNjpQhQjxAVj/QAVkAB2jhQByjZC8igQC9igDphNQDwhPD/AVMgDPAnPQj+gVjgh1g");
	var mask_graphics_14 = new cjs.Graphics().p("EAkwARGQjUh8iWjEQiXjEhBjtQhEj1Ahj9QAij/CAjbQB8jUDEiWQDEiXDthBQD0hED9AhMgFHAnEQj9gijbiAg");
	var mask_graphics_15 = new cjs.Graphics().p("EAjDAQiQjLiJiKjOQiKjNgyjxQg0j5Ayj6QAxj8CPjTQCKjMDNiJQDNiKDxgyQD4g0D6AxMgHnAmrQj7gyjSiOg");
	var mask_graphics_16 = new cjs.Graphics().p("EAg9APxQjAiah4jYQh5jYgej0Qgfj7BGj3QBGj4CfjGQCajADZh4QDYh5D0geQD7gfD2BFMgKyAl9Qj2hHjFifg");
	var mask_graphics_17 = new cjs.Graphics().p("AeeOxQiwithhjkQhijjgFj2QgFj+BfjvQBfjvC0i1QCtivDjhiQDkhhD2gFQD9gFDuBeMgOpAkqQjthfi0iyg");
	var mask_graphics_18 = new cjs.Graphics().p("AbrNdQiYjBhFjvQhEjuAaj0QAbj+B8jgQB9jiDJidQDBiYDvhFQDuhED1AaQD8AaDhB8MgTJAilQjgh9idjIg");
	var mask_graphics_19 = new cjs.Graphics().p("AYwL0Qh6jWggj2Qggj3A/jtQBBj3CdjMQCdjNDeh9QDXh6D2ggQD2ggDvA/QD2BADLCcI4JfXQjLidh9jeg");
	var mask_graphics_20 = new cjs.Graphics().p("AV+J0QhSjpANj4QAMj3BojgQBrjoC/itQDAiuDxhUQDphSD4AMQD5AMDgBoQDnBrCtC+I9YanQisi+hUjxg");
	var mask_graphics_21 = new cjs.Graphics().p("ATxHgQggj2A/jvQBAjxCUjGQCZjODfiCQDgiDD+ggQD1ggDxA/QDxA/DGCUQDMCZCCDeMgiSAUBQiBjeghj9g");
	var mask_graphics_22 = new cjs.Graphics().p("ASvE8QAbj2B3jbQB3jbC/ieQDGijD4hKQD5hKD/AdQD2AbDcB3QDbB2CeDAQCiDFBKD2MgmIALWQhJj3Acj+g");
	var mask_graphics_23 = new cjs.Graphics().p("ATmCXQBejlCui0QCuizDjhlQDrhoEEgEQEDgEDvBhQDmBdC0CuQCzCuBlDjQBnDqAFECMgn4AAoQgEkDBgjtg");
	var mask_graphics_24 = new cjs.Graphics().p("ASxCVQBDj6CdjLQCYjFDZh+QDYh+D3gjQD/gkD8BCQD7BCDMCeQDFCZB+DYQB+DYAkD2QAkD/hCD6g");
	var mask_graphics_25 = new cjs.Graphics().p("AUgkVQB9jkDJigQDDicDxhHQDwhHD5AYQEBAaDlB8QDlB9ChDKQCcDDBHDxQBHDvgZD5QgZEAh7Dkg");
	var mask_graphics_26 = new cjs.Graphics().p("AW1pfQCpjFDnh0QDfhwD7gUQD6gUDvBLQD3BODGCpQDHCqB0DnQBwDgAUD5QAUD7hLDuQhND2ipDGg");
	var mask_graphics_27 = new cjs.Graphics().p("AZXtQQDKikD3hJQDwhHD7AYQD6AZDeB1QDmB4ClDKQCmDKBKD5QBHDvgZD7QgZD6h0DeQh4DljJClg");
	var mask_graphics_28 = new cjs.Graphics().p("Ab1v3QDgiFEAgjQD4giD0A+QD1A+DKCVQDRCZCFDhQCGDiAkEBQAiD3g+D0Qg/D1iUDKQiZDQjgCFg");
	var mask_graphics_29 = new cjs.Graphics().p("AeExnQDvhoEDgCQD7gDDrBcQDqBdC2CtQC9CzBoDwQBpDwADEDQACD7hcDrQhcDritC1QizC8jvBog");
	var mask_graphics_30 = new cjs.Graphics().p("Af/yuQD5hOECAYQD6AXDgB0QDhB0CjC/QCpDFBQD6QBPD6gYECQgXD6h0DhQh0Dgi/CjQjFCoj4BQg");
	var mask_graphics_31 = new cjs.Graphics().p("EAhmgTYQD+g6D/AtQD4ArDWCHQDWCGCTDMQCZDTA6D/QA7EAgtEAQgsD3iGDWQiHDWjLCTQjSCYj/A7g");
	var mask_graphics_32 = new cjs.Graphics().p("EAi3gTxQECgpD7A9QD1A7DNCUQDNCUCGDVQCLDcAqEDQAqEDg+D9Qg7D0iUDNQiUDNjVCGQjbCKkCArg");
	var mask_graphics_33 = new cjs.Graphics().p("EAj0gT+QEEgdD5BJQDxBIDGCdQDGCeB7DbQCADjAeEFQAdEEhKD6QhHDxidDGQieDGjbB7QjiB/kEAeg");
	var mask_graphics_34 = new cjs.Graphics().p("EAkggUFQEFgUD2BSQDvBQDACkQDBCkB0DgQB4DnAUEGQAVEFhTD3QhPDvikDAQilDBjfBzQjnB4kEAVg");
	var mask_graphics_35 = new cjs.Graphics().p("EAk+gUIQEFgOD1BYQDtBVC8CoQC9CpBuDiQBzDqAOEHQAPEFhYD1QhVDtipC9QipC8jiBvQjpBykFAPg");
	var mask_graphics_36 = new cjs.Graphics().p("EAlQgUKQEGgKDzBbQDrBZC7CrQC6CsBrDjQBwDsAKEGQALEGhbD0QhZDsirC6QisC6jjBsQjrBukFAMg");
	var mask_graphics_37 = new cjs.Graphics().p("EAlagUKQEFgJDyBdQDrBaC5CtQC5CtBqDkQBuDtAJEGQAJEGheD0QhaDrisC5QitC5jlBpQjrBtkGAKg");
	var mask_graphics_38 = new cjs.Graphics().p("EAldgUKQEGgIDyBdQDqBbC5CtQC5CuBpDkQBtDtAIEHQAIEGheDzQhaDriuC4QitC5jlBpQjsBskFAJg");
	var mask_graphics_39 = new cjs.Graphics().p("EAlegUKQEFgIDyBeQDrBaC5CuQC4CtBpDlQBtDtAIEGQAIEGheDzQhbDritC4QitC5jlBpQjsBskFAJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:304.451,y:67.7769}).wait(7).to({graphics:mask_graphics_7,x:306.901,y:67.7769}).wait(1).to({graphics:mask_graphics_8,x:306.925,y:67.7769}).wait(1).to({graphics:mask_graphics_9,x:307.0929,y:67.7766}).wait(1).to({graphics:mask_graphics_10,x:307.549,y:67.7737}).wait(1).to({graphics:mask_graphics_11,x:308.4371,y:67.7581}).wait(1).to({graphics:mask_graphics_12,x:309.9011,y:67.7043}).wait(1).to({graphics:mask_graphics_13,x:312.0833,y:67.5597}).wait(1).to({graphics:mask_graphics_14,x:315.1206,y:67.2317}).wait(1).to({graphics:mask_graphics_15,x:319.1366,y:66.5716}).wait(1).to({graphics:mask_graphics_16,x:324.2255,y:65.3573}).wait(1).to({graphics:mask_graphics_17,x:330.425,y:63.2695}).wait(1).to({graphics:mask_graphics_18,x:337.6729,y:59.8664}).wait(1).to({graphics:mask_graphics_19,x:345.7443,y:54.643}).wait(1).to({graphics:mask_graphics_20,x:354.1692,y:47.0084}).wait(1).to({graphics:mask_graphics_21,x:362.1387,y:36.3761}).wait(1).to({graphics:mask_graphics_22,x:368.4234,y:22.4237}).wait(1).to({graphics:mask_graphics_23,x:371.3531,y:5.2526}).wait(1).to({graphics:mask_graphics_24,x:371.648,y:20.5953}).wait(1).to({graphics:mask_graphics_25,x:371.8723,y:34.9153}).wait(1).to({graphics:mask_graphics_26,x:372.0534,y:46.0146}).wait(1).to({graphics:mask_graphics_27,x:372.2179,y:54.1514}).wait(1).to({graphics:mask_graphics_28,x:372.3628,y:59.836}).wait(1).to({graphics:mask_graphics_29,x:372.4669,y:63.6495}).wait(1).to({graphics:mask_graphics_30,x:372.5598,y:66.0793}).wait(1).to({graphics:mask_graphics_31,x:372.6292,y:67.564}).wait(1).to({graphics:mask_graphics_32,x:372.676,y:68.4329}).wait(1).to({graphics:mask_graphics_33,x:372.7077,y:68.9169}).wait(1).to({graphics:mask_graphics_34,x:372.7297,y:69.1728}).wait(1).to({graphics:mask_graphics_35,x:372.7447,y:69.3011}).wait(1).to({graphics:mask_graphics_36,x:372.754,y:69.3617}).wait(1).to({graphics:mask_graphics_37,x:372.7589,y:69.3878}).wait(1).to({graphics:mask_graphics_38,x:372.7608,y:69.3965}).wait(1).to({graphics:mask_graphics_39,x:372.7838,y:69.1911}).wait(10));

	// purple_circle
	this.instance = new lib.purple();
	this.instance.parent = this;
	this.instance.setTransform(614.05,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(49));

	// Grey_circle copy 3
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(614.05,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(49));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(488.1,-58.2,252,252);


(lib.bed_chart = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Bed
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4355A5").s().p("AB4BVQgGAAAAgHIAAgVIjjAAIAAAVQAAAHgHAAIgOAAQgHAAAAgHIAAibQAAgHAHAAIAOAAQAHAAAAAHIAABbIBjAAIAAg/QAAgHAIAAIBiAAQAUAAAPAPQAPAOAAAVIAABUQAAAHgHAAgAhYgJQgLgLAAgPQAAgOALgLQAKgKAPAAQAPAAAKAKQALALAAAOQAAAPgLALQgKAJgPAAQgPAAgKgJg");
	this.shape.setTransform(614.4295,67.3244,2.7625,2.7625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// mask_purple (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EAlegUKQEFgIDyBeQDrBaC5CuQC4CtBpDlQBtDtAIEGQAIEGheDzQhbDritC4QitC5jlBpQjsBskFAJg");
	mask.setTransform(372.7838,69.1911);

	// purple_circle
	this.instance = new lib.purple();
	this.instance.parent = this;
	this.instance.setTransform(614.05,67.8,1,1,0,0,0,126,126);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Grey_circle copy 3
	this.instance_1 = new lib.grey_circle();
	this.instance_1.parent = this;
	this.instance_1.setTransform(614.05,67.8,1,1,0,0,0,126,126);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.bed_chart, new cjs.Rectangle(488.1,-58.2,252,252), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.softwarevector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ui.cache(-1000,-1400,2000,2800,0.3)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// excel_ui
	this.ui = new lib.excel_ui_c();
	this.ui.name = "ui";
	this.ui.parent = this;
	this.ui.setTransform(384.3,676.45,1,1,0,0,0,382.3,669.6);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

}).prototype = getMCSymbolPrototype(lib.softwarevector, new cjs.Rectangle(0.9,10.5,766.8000000000001,1365.9), null);


(lib.screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Exercise
	this.instance = new lib.Run_chart();
	this.instance.parent = this;
	this.instance.setTransform(19.3,-145.3,0.102,0.102,0,0,0,-226.5,66.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Exercise_Minutes
	this.instance_1 = new lib.minutes();
	this.instance_1.parent = this;
	this.instance_1.setTransform(19.35,-110.5,1,1,0,0,0,13.6,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Carrots
	this.instance_2 = new lib.Carrot_chart();
	this.instance_2.parent = this;
	this.instance_2.setTransform(50.45,-143.6,0.102,0.102,0,0,0,30.4,83.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Calories
	this.instance_3 = new lib.Calories();
	this.instance_3.parent = this;
	this.instance_3.setTransform(50.85,-109.85);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Spa
	this.instance_4 = new lib.Spa_chart();
	this.instance_4.parent = this;
	this.instance_4.setTransform(81.5,-144.9,0.102,0.102,0,0,0,306.4,70.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Me_time
	this.instance_5 = new lib.Me_time();
	this.instance_5.parent = this;
	this.instance_5.setTransform(83.95,-110.4,1,1,0,0,0,12.5,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Bed
	this.instance_6 = new lib.bed_chart();
	this.instance_6.parent = this;
	this.instance_6.setTransform(112.75,-145.55,0.102,0.102,0,0,0,614.3,64.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(1));

	// sleep_hours
	this.instance_7 = new lib.sleep_hours();
	this.instance_7.parent = this;
	this.instance_7.setTransform(115.8,-110.4,1,1,0,0,0,10.8,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(1));

	// Text
	this.instance_8 = new lib.text();
	this.instance_8.parent = this;
	this.instance_8.setTransform(65.85,-144.35,1,1,0,0,0,60.1,35.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

	// Bar
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4354A4").s().p("AuXDLIAAmVIcvAAIAAGVg");
	this.shape.setTransform(115.4821,-121.875,0.1816,0.1909);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E42364").s().p("AtuDLIAAmVIbdAAIAAGVg");
	this.shape_1.setTransform(82.8205,-121.875,0.1816,0.1909);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F05824").s().p("At4DLIAAmVIbxAAIAAGVg");
	this.shape_2.setTransform(50.7263,-121.875,0.1816,0.1909);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2680BE").s().p("AuNDLIAAmVIcbAAIAAGVg");
	this.shape_3.setTransform(18.0692,-121.875,0.1816,0.1909);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen, new cjs.Rectangle(1.6,-166.5,130.6,61.3), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(6.05,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1A7041").s().p("ApzCnIAAlNITnAAIAAFNg");
	this.shape.setTransform(-21.275,-1.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-84.1,-18.1,125.69999999999999,33.400000000000006), null);


(lib.graphs = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_80 = function() {
		exportRoot.tl1.play()
	}
	this.frame_106 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(80).call(this.frame_80).wait(26).call(this.frame_106).wait(2));

	// Exercise
	this.instance = new lib.RunChart("synched",0,false);
	this.instance.parent = this;
	this.instance.setTransform(58,507.45,0.8723,0.8723,0,0,0,-226.5,66.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({startPosition:7},0).wait(107));

	// Exercise_Minutes
	this.instance_1 = new lib.runtime_txt("single",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(69.2,776.85,8.5532,8.5532,0,0,0,13.6,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({mode:"synched",loop:false},0).wait(107));

	// Carrots
	this.instance_2 = new lib.CarrotChart("single",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(326.5,519.9,0.8722,0.8722,0,0,0,30.4,83.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(23).to({mode:"synched",startPosition:7,loop:false},0).wait(85));

	// Calories
	this.instance_3 = new lib.Calories_txt("single",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(338.65,782.45,8.5532,8.5532);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(23).to({mode:"synched",loop:false},0).wait(85));

	// Spa
	this.instance_4 = new lib.SpaChart("single",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(609.1,510.85,0.8723,0.8723,0,0,0,306.4,70.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(45).to({mode:"synched",startPosition:7,loop:false},0).wait(63));

	// Me_time
	this.instance_5 = new lib.Me_time_txt("single",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(621.7,777.75,8.5532,8.5532,0,0,0,12.5,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(45).to({mode:"synched",loop:false},0).wait(63));

	// Bed
	this.instance_6 = new lib.BedChart("single",0);
	this.instance_6.parent = this;
	this.instance_6.setTransform(890.05,505.35,0.8723,0.8723,0,0,0,614.2,64.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(70).to({mode:"synched",startPosition:7,loop:false},0).wait(38));

	// sleep_hours
	this.instance_7 = new lib.sleep_txt("single",0);
	this.instance_7.parent = this;
	this.instance_7.setTransform(894.1,777.75,8.5532,8.5532,0,0,0,10.8,4.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(70).to({mode:"synched",loop:false},0).wait(38));

	// Text
	this.instance_8 = new lib.txt();
	this.instance_8.parent = this;
	this.instance_8.setTransform(466.95,457.7,8.5532,8.5532,0,0,0,60.1,35.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(108));

	// Bar
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4354A4").s().p("AuXDLIAAmVIcvAAIAAGVg");
	this.shape.setTransform(891.4738,707.8436,1.5531,1.6327);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E42364").s().p("AtuDLIAAmVIbdAAIAAGVg");
	this.shape_1.setTransform(612.1153,707.8436,1.5531,1.6327);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F05824").s().p("At4DLIAAmVIbxAAIAAGVg");
	this.shape_2.setTransform(337.6102,707.8436,1.5531,1.6327);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#2680BE").s().p("A2EFLIAAqVMAsJAAAIAAKVg");
	this.shape_3.setTransform(58.3,707.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(108));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-83,254.6,1117.4,722.9);


(lib.ExcelUI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// TopBar
	this.topbar = new lib.top_bar2();
	this.topbar.name = "topbar";
	this.topbar.parent = this;
	this.topbar.setTransform(136.75,46.45,1,1,0,0,0,667.6,300.3);

	this.timeline.addTween(cjs.Tween.get(this.topbar).wait(1));

	// Bottom_bar
	this.bottombar = new lib.bottom_part();
	this.bottombar.name = "bottombar";
	this.bottombar.parent = this;
	this.bottombar.setTransform(161.15,217.3,1,1,0,0,0,152.6,11.1);

	this.timeline.addTween(cjs.Tween.get(this.bottombar).wait(1));

	// innerUI
	this.ui = new lib.inner_UI2();
	this.ui.name = "ui";
	this.ui.parent = this;
	this.ui.setTransform(146.4,95.55);

	this.timeline.addTween(cjs.Tween.get(this.ui).wait(1));

}).prototype = getMCSymbolPrototype(lib.ExcelUI, new cjs.Rectangle(44.5,36.4,183.3,110.1), null);


(lib.screen_new = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// software
	this.instance = new lib.softwarevector();
	this.instance.parent = this;
	this.instance.setTransform(585.7,328.15,1,1,0,0,0,591.9,332.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// graphs
	this.graphs = new lib.graphs();
	this.graphs.name = "graphs";
	this.graphs.parent = this;
	this.graphs.setTransform(398.6,390.65,0.8919,0.8919,0,0,0,468.7,181.4);

	this.timeline.addTween(cjs.Tween.get(this.graphs).wait(1));

	// Layer_2
	this.instance_1 = new lib.mbl_bg();
	this.instance_1.parent = this;
	this.instance_1.setTransform(389.2,688.85,1,1,0,0,0,377.3,684.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_new, new cjs.Rectangle(-93.5,4.1,996.7,1369.6000000000001), null);


(lib.mobile_device = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// excel_icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.parent = this;
	this.icon.setTransform(1.1,0.95,0.9942,0.9942);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// screen_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("ArdUxMAAAgphIW7AAMAAAAphg");
	mask.setTransform(150.975,365.875);

	// screen
	this.screen = new lib.screen_new();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(168.2,267.85,0.1979,0.1979,0,0,0,468.8,182);

	var maskedShapeInstanceList = [this.screen];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// mobile
	this.laptop = new lib.phone_ai();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(151.15,269.15,0.5217,0.5124,0,0,0,156.5,106.8);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// shadow
	this.shadow = new lib.shadow();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(147.25,498.1,0.4841,0.4841,0,0,0,294.2,47.7);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.mobile_device, new cjs.Rectangle(4.8,192,284.9,329.1), null);


(lib.Laptop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Excel_ui
	this.instance = new lib.ExcelUI();
	this.instance.parent = this;
	this.instance.setTransform(175.4,206.75,1,1,0,0,0,136.2,94.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Screen
	this.screen = new lib.screen();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(174.65,191.85,0.9988,0.9988,0,0,0,68.6,-161.7);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("At0GUIAAsnIbpAAIAAMng");
	this.shape.setTransform(177.225,200.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Laptop, new cjs.Rectangle(83.7,149.1,183.2,110.00000000000003), null);


(lib.laptop_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.parent = this;
	this.icon.setTransform(-30.3,-117.15,0.5997,0.5997,0,0,0,0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsWJoIAAwQIbzAAIAAQQg");
	mask.setTransform(98.8518,61.5765);

	// Devices
	this.devices = new lib.Laptop();
	this.devices.name = "devices";
	this.devices.parent = this;
	this.devices.setTransform(113.3,561.2,1,1,0,0,0,181.6,696.4);

	var maskedShapeInstanceList = [this.devices];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.devices).wait(1));

	// laptop
	this.instance = new lib.laptop_ai();
	this.instance.parent = this;
	this.instance.setTransform(71.05,55.75,0.3977,0.3977,0,0,0,156.7,106.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Shadow
	this.shadow = new lib.shadowcache();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(107.25,118.55,0.3954,0.3954,0,0,0,474.9,72.2);

	this.instance_1 = new lib.Bitmap3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(5.95,120.95,0.6245,0.6245);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shadow}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_c, new cjs.Rectangle(-80.5,-1.8,375.6,155.8), null);


(lib.anim_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop.cache(-400,-160,800,320,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4
	this.laptop = new lib.laptop_c();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(148.8,147.4,1,1,0,0,0,107.7,73.8);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.anim_blue, new cjs.Rectangle(-39.4,71.8,375.59999999999997,155.8), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(222.05,554.6,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(261.6,555.15,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Mobile_device
	this.mob_scrn = new lib.mobile_device();
	this.mob_scrn.name = "mob_scrn";
	this.mob_scrn.parent = this;
	this.mob_scrn.setTransform(156.8,360,1,1,0,0,0,156.8,360);

	this.timeline.addTween(cjs.Tween.get(this.mob_scrn).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(62.15,40.2,1,1,0,0,0,0.4,0.7);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// anim
	this.anim_1 = new lib.anim_blue();
	this.anim_1.name = "anim_1";
	this.anim_1.parent = this;
	this.anim_1.setTransform(-24.95,116.05,1.5377,1.5377,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.anim_1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#ECEDEF","#FFFFFF"],[0,1],-8.6,197.5,-8.9,76.8).s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-85.7,-1.4,577.6,606.1), null);


// stage content:
(lib.O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var mobile = mc.mob_scrn
		var laptop = mc.anim_1
		var icon = mc.mob_scrn.icon
		
		mc.cta.alpha=0
		mc.anim_1.alpha=0
		mc.replay_btn.alpha=0
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.anim_1.alpha=1
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
			
		
				exportRoot.tl1.from(mobile, 2, {x: "+=300", ease:Power3.easeOut}, "-=0.5");
		
		
				//Get Motivated
				exportRoot.tl1.from(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0");
				exportRoot.tl1.from(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
						
				
				exportRoot.tl1.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.7");
				exportRoot.tl1.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
				
				//With
				exportRoot.tl1.from(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.4");
		
				
				//wellness template
				exportRoot.tl1.from(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.from(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.2");
						
		
				exportRoot.tl1.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
				exportRoot.tl1.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
		
				//in Excel
				exportRoot.tl1.from(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.from(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.2");
				
				exportRoot.tl1.to(exportRoot.headline6, 0.5, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
				exportRoot.tl1.to(exportRoot.headline7, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
				
				exportRoot.tl1.to(mobile, 0.1, {scaleX: 1, scaleY: 1, ease:Power3.easeInOut,onComplete:function(){mobile.screen.graphs.gotoAndPlay(1);exportRoot.tl1.stop()}}, "-=1");
		
				
				exportRoot.tl1.to(mobile, 1.75, {x:"-=88", y:"+=44", scaleX:0.435, scaleY:0.435, ease:Power3.easeInOut}, "-=.4");
				exportRoot.tl1.to(icon, 1, {alpha: 0, ease:Power3.easeInOut}, "-=1.75");
				//exportRoot.tl1.to(shadow, 1.75, {alpha: 0.2, ease:Power3.easeInOut}, "-=1.75");
				exportRoot.tl1.from(laptop, 1, {x:"+=100",alpha: 0, ease:Power3.easeOut}, "-=0.8");
		
				//exportRoot.tl1.from(mobile, 1, {x:"-=100",alpha: 0, ease:Power3.easeOut}, "-=0.8");
		
				
				for (var i = 0; i < exportRoot.headline11.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline12.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=0.6");	
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=50",	ease:Power4.easeOut}, "-=0.6");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=50", ease:Power4.easeOut}, "-=0.7");
			
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(64.3,298.6,427.59999999999997,306.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574683246488", id:"O365_NewYearCampaign_USA_300x600_BAN_Excel_Fitness_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;