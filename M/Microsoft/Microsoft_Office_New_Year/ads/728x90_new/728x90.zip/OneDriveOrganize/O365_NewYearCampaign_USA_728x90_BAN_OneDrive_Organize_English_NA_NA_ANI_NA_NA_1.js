(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[251,253,83,90],[369,348,99,140],[251,348,116,121],[365,0,135,214],[0,253,249,361],[365,216,113,130],[0,0,363,251]]}
];


// symbols:



(lib.Icon_OneDrive = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.image_dog = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.image_family = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.image_landscape = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Image_snowman = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.image_snowshoes = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.laptop_300x250 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgvvAFoIAArPMBfeAAAIAALPg");
	mask.setTransform(305.55,36);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AhlB3QgngpAAhNQAAhGArguQAqgtA/AAQA/gBAjApQAjApAABIIAAAaIjSAAQACArAZAXQAZAYArAAQAxgBApgdIAAA4QgpAahGABQhDgBgngqgAgrhXQgVAXgFAiICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape.setTransform(491.425,42.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AhNB3QgrgrAAhEQAAhMAuguQAugvBKABQArgBAgAQIAABBQgggZglAAQgsAAgcAeQgcAfAAAvQAAAwAbAcQAZAbAtAAQAmAAAhgaIAAA8QglAWgyAAQhFgBgpgqg");
	this.shape_1.setTransform(463.425,42.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgjDiIAAkzIBFAAIAAEzgAgdidQgMgMAAgRQAAgQAMgMQANgLAQAAQARAAANALQAMAMAAAQQAAAQgMAMQgNAMgRAAQgRAAgMgLg");
	this.shape_2.setTransform(443.825,34.95);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgyAAAAA6IAAApIBHAAIAAA3IhHAAIAAD9g");
	this.shape_3.setTransform(427.325,34.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgxQAAgyAggcQAfgcAwAAQAaAAAPAGIAAA6QgOgIgTAAQgzAAAAA6IAAApIBIAAIAAA3IhHAAIAAD9g");
	this.shape_4.setTransform(407.975,34.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AiWCjQg4g9gBhhQABhnA5g+QA5g+BiAAQBaAAA4A8QA4A8gBBiQAABog4A+Qg5A9heAAQheAAg4g8gAhehzQglAtAABHQAABIAkAsQAkAsA7AAQA9AAAkgqQAkgqAAhLQgBhMgigrQgjgqg9AAQg7AAglAsg");
	this.shape_5.setTransform(375.9,35.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_6.setTransform(54.875,54.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_7.setTransform(17.1,54.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_8.setTransform(54.875,17.125);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_9.setTransform(17.1,17.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_10.setTransform(215.625,34.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_11.setTransform(598.35,36.425);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_12.setTransform(567.8,36.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_13.setTransform(536.525,36.05);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12,this.shape_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,611.1,72), null);


(lib.laptop_phone = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.laptop_300x250();
	this.instance.parent = this;
	this.instance.setTransform(-181.5,-125.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_phone, new cjs.Rectangle(-181.5,-125.5,363,251), null);


(lib.img_snowshoes_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_snowshoes();
	this.instance.parent = this;
	this.instance.setTransform(-113,-130,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_snowshoes_in, new cjs.Rectangle(-113,-130,226,260), null);


(lib.img_snowman_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_snowman();
	this.instance.parent = this;
	this.instance.setTransform(-249,-361,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_snowman_in, new cjs.Rectangle(-249,-361,498,722), null);


(lib.img_family_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_family();
	this.instance.parent = this;
	this.instance.setTransform(-116,-121,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_family_in, new cjs.Rectangle(-116,-121,232,242), null);


(lib.img_dog_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_dog();
	this.instance.parent = this;
	this.instance.setTransform(-99,-140,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.img_dog_in, new cjs.Rectangle(-99,-140,198,280), null);


(lib.image_landscape_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image_landscape();
	this.instance.parent = this;
	this.instance.setTransform(-135,-214,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.image_landscape_in, new cjs.Rectangle(-135,-214,270,428), null);


(lib.Icon_OneDrive_in = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon_OneDrive();
	this.instance.parent = this;
	this.instance.setTransform(-83,-90,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Icon_OneDrive_in, new cjs.Rectangle(-83,-90,166,180), null);


(lib.whitecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whitecopy, new cjs.Rectangle(0,0,971,813.9), null);


(lib.mscopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mscopy, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.logo_boxcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_boxcopy, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bg_fade_cache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(246,246,246,0)","rgba(253,253,253,0.831)","#FFFFFF"],[0.157,0.655,0.953],-149.1,-2.1,0,-149.1,-2.1,89.2).s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_fade_cache, new cjs.Rectangle(0,0,728,90), null);


(lib.bg_cache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#F6F6F6","#EBEBEB"],[0.055,0.984],-2.4,-7.6,0,-2.4,-7.6,297.1).s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_cache, new cjs.Rectangle(0,0,728,90), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.image_landscape_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween4, new cjs.Rectangle(-135,-214,270,428), null);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_snowshoes_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween3, new cjs.Rectangle(-113,-130,226,260), null);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_dog_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween2, new cjs.Rectangle(-99,-140,198,280), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_family_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.Tween1, new cjs.Rectangle(-116,-121,232,242), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.photo_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.snowTest = new lib.img_snowman_in();
	this.snowTest.name = "snowTest";
	this.snowTest.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.snowTest).wait(1));

}).prototype = getMCSymbolPrototype(lib.photo_1, new cjs.Rectangle(-249,-361,498,722), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(51.3,0.35,0.33,0.33,0,0,0,307,34.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-11,202.1,24.1), null);


(lib.Icon_OneDrive_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon_OneDrive_in();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Icon_OneDrive_1, new cjs.Rectangle(-83,-90,166,180), null);


(lib.MSFT_logo_sqcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_boxcopy();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sqcopy, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_animcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.mscopy();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_animcopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.mscopy();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logocopy, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.Devices_Isometric = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_108 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(108).call(this.frame_108).wait(1));

	// image_family.png
	this.img_family = new lib.Tween1();
	this.img_family.name = "img_family";
	this.img_family.parent = this;
	this.img_family.setTransform(744.05,119.5,0.44,0.44,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.img_family).wait(1).to({regX:0,regY:0,x:743.89,y:119.34},0).wait(3).to({regX:0.3,regY:0.3,x:744.05,y:119.5},0).wait(1).to({regX:0,regY:0,scaleX:0.4396,scaleY:0.4396,x:743.1749,y:119.159},0).wait(1).to({scaleX:0.4391,scaleY:0.4391,x:742.0363,y:118.8745},0).wait(1).to({scaleX:0.4386,scaleY:0.4386,x:740.556,y:118.5113},0).wait(1).to({scaleX:0.4379,scaleY:0.4379,x:738.7525,y:118.079},0).wait(1).to({scaleX:0.437,scaleY:0.437,x:736.6259,y:117.5832},0).wait(1).to({scaleX:0.4361,scaleY:0.4361,x:734.1707,y:117.0288},0).wait(1).to({scaleX:0.435,scaleY:0.435,x:731.3803,y:116.4215},0).wait(1).to({scaleX:0.4338,scaleY:0.4338,x:728.2478,y:115.7674},0).wait(1).to({scaleX:0.4325,scaleY:0.4325,x:724.7665,y:115.0735},0).wait(1).to({scaleX:0.431,scaleY:0.431,x:720.9298,y:114.3472},0).wait(1).to({scaleX:0.4293,scaleY:0.4293,x:716.7311,y:113.5962},0).wait(1).to({scaleX:0.4275,scaleY:0.4275,x:712.1634,y:112.8286},0).wait(1).to({scaleX:0.4255,scaleY:0.4255,x:707.2197,y:112.0529},0).wait(1).to({scaleX:0.4233,scaleY:0.4233,x:701.8923,y:111.2774},0).wait(1).to({scaleX:0.421,scaleY:0.421,x:696.173,y:110.5106},0).wait(1).to({scaleX:0.4184,scaleY:0.4184,x:690.0531,y:109.7611},0).wait(1).to({scaleX:0.4157,scaleY:0.4157,x:683.528,y:109.0378},0).wait(1).to({scaleX:0.4127,scaleY:0.4127,x:676.5813,y:108.3484},0).wait(1).to({scaleX:0.4095,scaleY:0.4095,x:669.1999,y:107.7014},0).wait(1).to({scaleX:0.4061,scaleY:0.4061,x:661.3707,y:107.1052},0).wait(1).to({scaleX:0.4024,scaleY:0.4024,x:653.0795,y:106.5682},0).wait(1).to({scaleX:0.3985,scaleY:0.3985,x:644.3149,y:106.0993},0).wait(1).to({scaleX:0.3942,scaleY:0.3942,x:635.0592,y:105.7068},0).wait(1).to({scaleX:0.3897,scaleY:0.3897,x:625.2935,y:105.3994},0).wait(1).to({scaleX:0.3849,scaleY:0.3849,x:615.0021,y:105.1861},0).wait(1).to({scaleX:0.3797,scaleY:0.3797,x:604.1677,y:105.0758},0).wait(1).to({scaleX:0.3742,scaleY:0.3742,x:592.7719,y:105.0777},0).wait(1).to({scaleX:0.3684,scaleY:0.3684,x:580.8083,y:105.2013},0).wait(1).to({scaleX:0.3622,scaleY:0.3622,x:566.8679,y:105.4998},0).wait(1).to({scaleX:0.3556,scaleY:0.3556,x:549.007,y:106.0905},0).wait(1).to({scaleX:0.3487,scaleY:0.3487,x:530.2643,y:106.9166},0).wait(1).to({scaleX:0.3413,scaleY:0.3413,x:511.4987,y:107.9184},0).wait(1).to({scaleX:0.3335,scaleY:0.3335,x:492.7586,y:109.0654},0).wait(1).to({scaleX:0.3254,scaleY:0.3254,x:473.94,y:110.3435},0).wait(1).to({scaleX:0.3169,scaleY:0.3169,x:454.9512,y:111.7444},0).wait(1).to({scaleX:0.308,scaleY:0.308,x:435.771,y:113.259},0).wait(1).to({scaleX:0.2988,scaleY:0.2988,x:416.4262,y:114.8765},0).wait(1).to({scaleX:0.2894,scaleY:0.2894,x:397.1612,y:116.5863},0).wait(1).to({scaleX:0.2797,scaleY:0.2797,x:379.9135,y:118.1713},0).wait(1).to({scaleX:0.27,scaleY:0.27,x:364.8173,y:119.55},0).wait(1).to({scaleX:0.2602,scaleY:0.2602,x:348.8755,y:120.9935},0).wait(1).to({scaleX:0.2504,scaleY:0.2504,x:332.7547,y:122.4339},0).wait(1).to({scaleX:0.2409,scaleY:0.2409,x:316.0595,y:123.8879},0).wait(1).to({scaleX:0.2315,scaleY:0.2315,x:298.2219,y:125.3534},0).wait(1).to({scaleX:0.2226,scaleY:0.2226,x:283.3438,y:126.4902},0).wait(1).to({scaleX:0.214,scaleY:0.214,x:268.4387,y:127.5279},0).wait(1).to({scaleX:0.2059,scaleY:0.2059,x:253.9498,y:128.4074},0).wait(1).to({scaleX:0.1983,scaleY:0.1983,x:239.558,y:129.0979},0).wait(1).to({scaleX:0.1913,scaleY:0.1913,x:227.3057,y:129.4795},0).wait(1).to({scaleX:0.1847,scaleY:0.1847,x:218.4743,y:129.6144},0).wait(1).to({scaleX:0.1787,scaleY:0.1787,x:209.5016,y:129.6067},0).wait(1).to({scaleX:0.1733,scaleY:0.1733,x:201.4951,y:129.4532},0).wait(1).to({scaleX:0.1683,scaleY:0.1683,x:194.0986,y:129.163},0).wait(1).to({scaleX:0.1638,scaleY:0.1638,x:187.386,y:128.7499},0).wait(1).to({scaleX:0.1598,scaleY:0.1598,x:181.3051,y:128.2254},0).wait(1).to({scaleX:0.1563,scaleY:0.1563,x:175.8325,y:127.6026},0).wait(1).to({scaleX:0.1531,scaleY:0.1531,x:170.9416,y:126.8961},0).wait(1).to({scaleX:0.1504,scaleY:0.1504,x:166.6117,y:126.1228},0).wait(1).to({scaleX:0.148,scaleY:0.148,x:162.8179,y:125.3015},0).wait(1).to({scaleX:0.146,scaleY:0.146,x:159.5351,y:124.4536},0).wait(1).to({scaleX:0.1443,scaleY:0.1443,x:156.7479,y:123.6067},0).wait(1).to({scaleX:0.1429,scaleY:0.1429,x:154.4359,y:122.792},0).wait(1).to({scaleX:0.1418,scaleY:0.1418,x:152.5831,y:122.0466},0).wait(1).to({scaleX:0.141,scaleY:0.141,x:151.1721,y:121.4106},0).wait(1).to({scaleX:0.1404,scaleY:0.1404,x:150.1852,y:120.9235},0).wait(1).to({scaleX:0.1401,scaleY:0.1401,x:149.605,y:120.6183},0).wait(1).to({regX:-1.4,regY:-1.1,scaleX:0.14,scaleY:0.14,x:149.45,y:120.55},0).to({x:149.15},1).wait(37));

	// image_landscape.png
	this.img_landscape = new lib.Tween4();
	this.img_landscape.name = "img_landscape";
	this.img_landscape.parent = this;
	this.img_landscape.setTransform(458.35,144.95,0.44,0.44,0,0,0,1.2,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.img_landscape).wait(1).to({regX:0,regY:0,x:457.794,y:144.994},0).wait(3).to({regX:1.2,regY:-0.1,x:458.35,y:144.95},0).wait(1).to({regX:0,regY:0,scaleX:0.4395,scaleY:0.4395,x:457.4205,y:144.7521},0).wait(1).to({scaleX:0.4388,scaleY:0.4388,x:456.6262,y:144.2671},0).wait(1).to({scaleX:0.438,scaleY:0.438,x:455.3738,y:143.5714},0).wait(1).to({scaleX:0.437,scaleY:0.437,x:453.6624,y:142.7322},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:451.5459,y:141.8344},0).wait(1).to({scaleX:0.4345,scaleY:0.4345,x:449.1286,y:140.9564},0).wait(1).to({scaleX:0.4329,scaleY:0.4329,x:446.5083,y:140.1436},0).wait(1).to({scaleX:0.4311,scaleY:0.4311,x:443.7517,y:139.4129},0).wait(1).to({scaleX:0.4291,scaleY:0.4291,x:440.8864,y:138.7629},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:437.9113,y:138.1856},0).wait(1).to({scaleX:0.4245,scaleY:0.4245,x:434.8114,y:137.6731},0).wait(1).to({scaleX:0.4218,scaleY:0.4218,x:431.5685,y:137.2193},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,x:428.166,y:136.821},0).wait(1).to({scaleX:0.4155,scaleY:0.4155,x:424.59,y:136.4765},0).wait(1).to({scaleX:0.412,scaleY:0.412,x:420.8296,y:136.1856},0).wait(1).to({scaleX:0.4081,scaleY:0.4081,x:416.8673,y:135.9483},0).wait(1).to({scaleX:0.4039,scaleY:0.4039,x:412.6927,y:135.7658},0).wait(1).to({scaleX:0.3994,scaleY:0.3994,x:408.2916,y:135.6397},0).wait(1).to({scaleX:0.3945,scaleY:0.3945,x:403.6507,y:135.572},0).wait(1).to({scaleX:0.3892,scaleY:0.3892,x:398.7565,y:135.565},0).wait(1).to({scaleX:0.3835,scaleY:0.3835,x:393.5908,y:135.6204},0).wait(1).to({scaleX:0.3774,scaleY:0.3774,x:386.8434,y:135.7834},0).wait(1).to({scaleX:0.3708,scaleY:0.3708,x:378.0363,y:136.1241},0).wait(1).to({scaleX:0.3637,scaleY:0.3637,x:368.7485,y:136.6043},0).wait(1).to({scaleX:0.3561,scaleY:0.3561,x:359.5431,y:137.1764},0).wait(1).to({scaleX:0.348,scaleY:0.348,x:350.4236,y:137.8196},0).wait(1).to({scaleX:0.3393,scaleY:0.3393,x:341.2618,y:138.5296},0).wait(1).to({scaleX:0.3301,scaleY:0.3301,x:331.944,y:139.3074},0).wait(1).to({scaleX:0.3203,scaleY:0.3203,x:322.4089,y:140.1534},0).wait(1).to({scaleX:0.3099,scaleY:0.3099,x:312.6201,y:141.0676},0).wait(1).to({scaleX:0.2989,scaleY:0.2989,x:302.5658,y:142.0491},0).wait(1).to({scaleX:0.2874,scaleY:0.2874,x:292.5332,y:143.0537},0).wait(1).to({scaleX:0.2754,scaleY:0.2754,x:285.2942,y:143.7757},0).wait(1).to({scaleX:0.2629,scaleY:0.2629,x:277.2863,y:144.5702},0).wait(1).to({scaleX:0.25,scaleY:0.25,x:269.1907,y:145.3683},0).wait(1).to({scaleX:0.2369,scaleY:0.2369,x:260.8708,y:146.182},0).wait(1).to({scaleX:0.2237,scaleY:0.2237,x:252.4791,y:146.9946},0).wait(1).to({scaleX:0.2106,scaleY:0.2106,x:244.0738,y:147.7982},0).wait(1).to({scaleX:0.1976,scaleY:0.1976,x:235.7262,y:148.5827},0).wait(1).to({scaleX:0.185,scaleY:0.185,x:227.5402,y:149.3334},0).wait(1).to({scaleX:0.1729,scaleY:0.1729,x:219.5639,y:150.0371},0).wait(1).to({scaleX:0.1614,scaleY:0.1614,x:211.8485,y:150.6689},0).wait(1).to({scaleX:0.1507,scaleY:0.1507,x:203.6675,y:151.2059},0).wait(1).to({scaleX:0.1406,scaleY:0.1406,x:196.4988,y:151.5587},0).wait(1).to({scaleX:0.1314,scaleY:0.1314,x:191.0372,y:151.7491},0).wait(1).to({scaleX:0.1229,scaleY:0.1229,x:185.6207,y:151.8564},0).wait(1).to({scaleX:0.1153,scaleY:0.1153,x:180.7982,y:151.8688},0).wait(1).to({scaleX:0.1084,scaleY:0.1084,x:176.3806,y:151.7956},0).wait(1).to({scaleX:0.1022,scaleY:0.1022,x:172.4057,y:151.6439},0).wait(1).to({scaleX:0.0967,scaleY:0.0967,x:168.839,y:151.4209},0).wait(1).to({scaleX:0.0919,scaleY:0.0919,x:165.6598,y:151.1343},0).wait(1).to({scaleX:0.0877,scaleY:0.0877,x:162.8552,y:150.7933},0).wait(1).to({scaleX:0.0841,scaleY:0.0841,x:160.4046,y:150.4076},0).wait(1).to({scaleX:0.081,scaleY:0.081,x:158.2893,y:149.9883},0).wait(1).to({scaleX:0.0785,scaleY:0.0785,x:156.4942,y:149.5494},0).wait(1).to({scaleX:0.0764,scaleY:0.0764,x:155.0061,y:149.1084},0).wait(1).to({scaleX:0.0747,scaleY:0.0747,x:153.8128,y:148.6874},0).wait(1).to({scaleX:0.0735,scaleY:0.0735,x:152.903,y:148.313},0).wait(1).to({scaleX:0.0726,scaleY:0.0726,x:152.2658,y:148.0154},0).wait(1).to({scaleX:0.0721,scaleY:0.0721,x:151.8905,y:147.8234},0).wait(1).to({regX:0.7,regY:-0.7,scaleX:0.072,scaleY:0.072,x:151.85,y:147.75},0).wait(44));

	// image_snowman
	this.img_snowman = new lib.photo_1();
	this.img_snowman.name = "img_snowman";
	this.img_snowman.parent = this;
	this.img_snowman.setTransform(191,127.6,0.13,0.13,0,0,0,2.7,1.9);

	this.timeline.addTween(cjs.Tween.get(this.img_snowman).wait(1).to({regX:0,regY:0,x:190.6484,y:127.3526},0).wait(3).to({regX:2.7,regY:1.9,x:191,y:127.6},0).wait(1).to({regX:0,regY:0,scaleX:0.1299,scaleY:0.1299,x:190.5871,y:127.3149},0).wait(1).to({scaleX:0.1297,scaleY:0.1297,x:190.5385,y:127.2851},0).wait(1).to({scaleX:0.1295,scaleY:0.1295,x:190.4637,y:127.2391},0).wait(1).to({scaleX:0.1293,scaleY:0.1293,x:190.3819,y:127.1887},0).wait(1).to({scaleX:0.129,scaleY:0.129,x:190.2823,y:127.1272},0).wait(1).to({scaleX:0.1287,scaleY:0.1287,x:190.1694,y:127.0576},0).wait(1).to({scaleX:0.1284,scaleY:0.1284,x:190.0401,y:126.9776},0).wait(1).to({scaleX:0.128,scaleY:0.128,x:189.8949,y:126.8877},0).wait(1).to({scaleX:0.1276,scaleY:0.1276,x:189.7324,y:126.7868},0).wait(1).to({scaleX:0.1271,scaleY:0.1271,x:189.5521,y:126.6747},0).wait(1).to({scaleX:0.1265,scaleY:0.1265,x:189.353,y:126.5505},0).wait(1).to({scaleX:0.1259,scaleY:0.1259,x:189.1344,y:126.4138},0).wait(1).to({scaleX:0.1253,scaleY:0.1253,x:188.8951,y:126.2637},0).wait(1).to({scaleX:0.1245,scaleY:0.1245,x:188.6342,y:126.0994},0).wait(1).to({scaleX:0.1238,scaleY:0.1238,x:188.3507,y:125.9201},0).wait(1).to({scaleX:0.1229,scaleY:0.1229,x:188.0433,y:125.7249},0).wait(1).to({scaleX:0.122,scaleY:0.122,x:187.7109,y:125.5126},0).wait(1).to({scaleX:0.121,scaleY:0.121,x:187.3522,y:125.2823},0).wait(1).to({scaleX:0.1199,scaleY:0.1199,x:186.9659,y:125.0325},0).wait(1).to({scaleX:0.1188,scaleY:0.1188,x:186.5505,y:124.7621},0).wait(1).to({scaleX:0.1175,scaleY:0.1175,x:186.1049,y:124.4693},0).wait(1).to({scaleX:0.1162,scaleY:0.1162,x:185.6274,y:124.1526},0).wait(1).to({scaleX:0.1148,scaleY:0.1148,x:185.1167,y:123.8101},0).wait(1).to({scaleX:0.1132,scaleY:0.1132,x:184.5716,y:123.4396},0).wait(1).to({scaleX:0.1116,scaleY:0.1116,x:183.9908,y:123.0387},0).wait(1).to({scaleX:0.1098,scaleY:0.1098,x:183.3736,y:122.6047},0).wait(1).to({scaleX:0.1079,scaleY:0.1079,x:182.7195,y:122.1344},0).wait(1).to({scaleX:0.106,scaleY:0.106,x:182.029,y:121.6239},0).wait(1).to({scaleX:0.1038,scaleY:0.1038,x:181.2999,y:121.0656},0).wait(1).to({scaleX:0.1016,scaleY:0.1016,x:180.5412,y:120.4569},0).wait(1).to({scaleX:0.0992,scaleY:0.0992,x:179.7589,y:119.7871},0).wait(1).to({scaleX:0.0967,scaleY:0.0967,x:178.9651,y:119.0368},0).wait(1).to({scaleX:0.094,scaleY:0.094,x:178.2038,y:118.1781},0).wait(1).to({scaleX:0.0913,scaleY:0.0913,x:177.6263,y:117.1319},0).wait(1).to({scaleX:0.0884,scaleY:0.0884,x:178.5179,y:115.8795},0).wait(1).to({scaleX:0.0855,scaleY:0.0855,x:182.7934,y:115.6336},0).wait(1).to({scaleX:0.0825,scaleY:0.0825,x:186.2076,y:115.9368},0).wait(1).to({scaleX:0.0795,scaleY:0.0795,x:188.3519,y:116.2094},0).wait(1).to({scaleX:0.0765,scaleY:0.0765,x:190.019,y:116.4262},0).wait(1).to({scaleX:0.0735,scaleY:0.0735,x:191.1993,y:116.5769},0).wait(1).to({scaleX:0.0706,scaleY:0.0706,x:192.534,y:116.7415},0).wait(1).to({scaleX:0.0678,scaleY:0.0678,x:193.7557,y:116.8866},0).wait(1).to({scaleX:0.0651,scaleY:0.0651,x:194.95,y:117.0217},0).wait(1).to({scaleX:0.0626,scaleY:0.0626,x:196.0745,y:117.141},0).wait(1).to({scaleX:0.0602,scaleY:0.0602,x:197.139,y:117.2446},0).wait(1).to({scaleX:0.058,scaleY:0.058,x:198.1326,y:117.3297},0).wait(1).to({scaleX:0.056,scaleY:0.056,x:199.0602,y:117.3938},0).wait(1).to({scaleX:0.0541,scaleY:0.0541,x:199.9215,y:117.4309},0).wait(1).to({scaleX:0.0525,scaleY:0.0525,x:200.7159,y:117.4234},0).wait(1).to({scaleX:0.051,scaleY:0.051,x:201.5234,y:117.2851},0).wait(1).to({scaleX:0.0496,scaleY:0.0496,x:202.1783,y:116.9236},0).wait(1).to({scaleX:0.0484,scaleY:0.0484,x:201.9059,y:115.451},0).wait(1).to({scaleX:0.0474,scaleY:0.0474,x:199.7734,y:113.4276},0).wait(1).to({scaleX:0.0464,scaleY:0.0464,x:198.6182,y:112.5603},0).wait(1).to({scaleX:0.0457,scaleY:0.0457,x:198.0613,y:112.1653},0).wait(1).to({scaleX:0.045,scaleY:0.045,x:197.6628,y:111.8896},0).wait(1).to({scaleX:0.0444,scaleY:0.0444,x:197.3437,y:111.6724},0).wait(1).to({scaleX:0.044,scaleY:0.044,x:197.0883,y:111.5007},0).wait(1).to({scaleX:0.0436,scaleY:0.0436,x:196.8893,y:111.3681},0).wait(1).to({scaleX:0.0433,scaleY:0.0433,x:196.7412,y:111.2701},0).wait(1).to({scaleX:0.0431,scaleY:0.0431,x:196.6396,y:111.2031},0).wait(1).to({scaleX:0.043,scaleY:0.043,x:196.5809,y:111.1646},0).wait(1).to({regX:4.7,regY:3.5,x:196.7,y:111.2},0).to({guide:{path:[196.7,111.2,196.7,111.3,196.7,111.3]}},1).wait(41));

	// image_dog.png
	this.img_dog = new lib.Tween2();
	this.img_dog.name = "img_dog";
	this.img_dog.parent = this;
	this.img_dog.setTransform(289.4,194.5,0.44,0.44,0,0,0,0.4,0.7);

	this.timeline.addTween(cjs.Tween.get(this.img_dog).wait(1).to({regX:0,regY:0,x:289.196,y:194.192},0).wait(3).to({regX:0.4,regY:0.7,x:289.4,y:194.5},0).wait(1).to({regX:0,regY:0,scaleX:0.4396,scaleY:0.4396,x:289.0352,y:194.051},0).wait(1).to({scaleX:0.439,scaleY:0.439,x:288.8094,y:193.8545},0).wait(1).to({scaleX:0.4384,scaleY:0.4384,x:288.5253,y:193.6099},0).wait(1).to({scaleX:0.4376,scaleY:0.4376,x:288.1807,y:193.3172},0).wait(1).to({scaleX:0.4366,scaleY:0.4366,x:287.7722,y:192.9754},0).wait(1).to({scaleX:0.4355,scaleY:0.4355,x:287.2959,y:192.5841},0).wait(1).to({scaleX:0.4343,scaleY:0.4343,x:286.7473,y:192.1427},0).wait(1).to({scaleX:0.4329,scaleY:0.4329,x:286.1219,y:191.6512},0).wait(1).to({scaleX:0.4313,scaleY:0.4313,x:285.4145,y:191.1096},0).wait(1).to({scaleX:0.4296,scaleY:0.4296,x:284.6196,y:190.5187},0).wait(1).to({scaleX:0.4277,scaleY:0.4277,x:283.7311,y:189.8792},0).wait(1).to({scaleX:0.4255,scaleY:0.4255,x:282.7427,y:189.1927},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,x:281.6476,y:188.4613},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:280.4389,y:187.6874},0).wait(1).to({scaleX:0.418,scaleY:0.418,x:279.1092,y:186.8743},0).wait(1).to({scaleX:0.415,scaleY:0.415,x:277.651,y:186.0261},0).wait(1).to({scaleX:0.4117,scaleY:0.4117,x:276.0575,y:185.1476},0).wait(1).to({scaleX:0.4083,scaleY:0.4083,x:274.3204,y:184.244},0).wait(1).to({scaleX:0.4045,scaleY:0.4045,x:272.432,y:183.321},0).wait(1).to({scaleX:0.4005,scaleY:0.4005,x:270.3849,y:182.3854},0).wait(1).to({scaleX:0.3961,scaleY:0.3961,x:268.1721,y:181.4445},0).wait(1).to({scaleX:0.3915,scaleY:0.3915,x:265.7878,y:180.5063},0).wait(1).to({scaleX:0.3865,scaleY:0.3865,x:263.2244,y:179.5785},0).wait(1).to({scaleX:0.3811,scaleY:0.3811,x:260.4771,y:178.67},0).wait(1).to({scaleX:0.3754,scaleY:0.3754,x:257.5406,y:177.7891},0).wait(1).to({scaleX:0.3693,scaleY:0.3693,x:254.4103,y:176.9446},0).wait(1).to({scaleX:0.3628,scaleY:0.3628,x:251.0851,y:176.1447},0).wait(1).to({scaleX:0.3559,scaleY:0.3559,x:247.2465,y:175.3377},0).wait(1).to({scaleX:0.3486,scaleY:0.3486,x:241.9183,y:174.3968},0).wait(1).to({scaleX:0.3407,scaleY:0.3407,x:236.2966,y:173.5715},0).wait(1).to({scaleX:0.3325,scaleY:0.3325,x:230.7962,y:172.8894},0).wait(1).to({scaleX:0.3237,scaleY:0.3237,x:225.4018,y:172.3154},0).wait(1).to({scaleX:0.3146,scaleY:0.3146,x:220.035,y:171.8204},0).wait(1).to({scaleX:0.305,scaleY:0.305,x:214.6439,y:171.3871},0).wait(1).to({scaleX:0.2949,scaleY:0.2949,x:209.21,y:171.0057},0).wait(1).to({scaleX:0.2846,scaleY:0.2846,x:203.8599,y:170.6669},0).wait(1).to({scaleX:0.2739,scaleY:0.2739,x:199.5471,y:170.3822},0).wait(1).to({scaleX:0.263,scaleY:0.263,x:195.2874,y:170.083},0).wait(1).to({scaleX:0.252,scaleY:0.252,x:190.9112,y:169.7531},0).wait(1).to({scaleX:0.2409,scaleY:0.2409,x:186.5083,y:169.3937},0).wait(1).to({scaleX:0.23,scaleY:0.23,x:182.0923,y:168.9987},0).wait(1).to({scaleX:0.2193,scaleY:0.2193,x:177.7128,y:168.5628},0).wait(1).to({scaleX:0.2089,scaleY:0.2089,x:173.3892,y:168.074},0).wait(1).to({scaleX:0.1989,scaleY:0.1989,x:169.1415,y:167.5107},0).wait(1).to({scaleX:0.1895,scaleY:0.1895,x:164.9734,y:166.8249},0).wait(1).to({scaleX:0.1805,scaleY:0.1805,x:160.527,y:165.919},0).wait(1).to({scaleX:0.1722,scaleY:0.1722,x:157.1244,y:165.0952},0).wait(1).to({scaleX:0.1646,scaleY:0.1646,x:153.8465,y:164.1778},0).wait(1).to({scaleX:0.1575,scaleY:0.1575,x:150.8396,y:163.2145},0).wait(1).to({scaleX:0.1511,scaleY:0.1511,x:148.0874,y:162.216},0).wait(1).to({scaleX:0.1452,scaleY:0.1452,x:145.5902,y:161.1997},0).wait(1).to({scaleX:0.14,scaleY:0.14,x:143.3438,y:160.1831},0).wait(1).to({scaleX:0.1353,scaleY:0.1353,x:141.3409,y:159.1835},0).wait(1).to({scaleX:0.1311,scaleY:0.1311,x:139.5712,y:158.2175},0).wait(1).to({scaleX:0.1274,scaleY:0.1274,x:138.0229,y:157.3003},0).wait(1).to({scaleX:0.1242,scaleY:0.1242,x:136.6825,y:156.4454},0).wait(1).to({scaleX:0.1214,scaleY:0.1214,x:135.5362,y:155.6644},0).wait(1).to({scaleX:0.119,scaleY:0.119,x:134.5698,y:154.9666},0).wait(1).to({scaleX:0.117,scaleY:0.117,x:133.7691,y:154.3586},0).wait(1).to({scaleX:0.1154,scaleY:0.1154,x:133.1209,y:153.8449},0).wait(1).to({scaleX:0.1141,scaleY:0.1141,x:132.6125,y:153.4278},0).wait(1).to({scaleX:0.1132,scaleY:0.1132,x:132.2326,y:153.1075},0).wait(1).to({scaleX:0.1125,scaleY:0.1125,x:131.9713,y:152.8827},0).wait(1).to({scaleX:0.1121,scaleY:0.1121,x:131.8199,y:152.7507},0).wait(1).to({regX:-1.4,regY:-1.4,scaleX:0.112,scaleY:0.112,x:131.8,y:152.8},0).wait(40));

	// image_snowshoes.png
	this.img_shoes = new lib.Tween3();
	this.img_shoes.name = "img_shoes";
	this.img_shoes.parent = this;
	this.img_shoes.setTransform(603.1,173,0.44,0.44,0,0,0,0.6,0);

	this.timeline.addTween(cjs.Tween.get(this.img_shoes).wait(1).to({regX:0,x:602.8528,y:172.9962},0).wait(3).to({regX:0.6,x:603.1,y:173},0).wait(1).to({regX:0,scaleX:0.4395,scaleY:0.4395,x:602.3559,y:172.6353},0).wait(1).to({scaleX:0.4389,scaleY:0.4389,x:601.434,y:171.9866},0).wait(1).to({scaleX:0.4382,scaleY:0.4382,x:600.1145,y:171.1012},0).wait(1).to({scaleX:0.4373,scaleY:0.4373,x:598.4061,y:170.0227},0).wait(1).to({scaleX:0.4362,scaleY:0.4362,x:596.3129,y:168.7932},0).wait(1).to({scaleX:0.435,scaleY:0.435,x:593.841,y:167.4545},0).wait(1).to({scaleX:0.4336,scaleY:0.4336,x:591.0011,y:166.0465},0).wait(1).to({scaleX:0.432,scaleY:0.432,x:587.8076,y:164.6053},0).wait(1).to({scaleX:0.4302,scaleY:0.4302,x:584.2769,y:163.1609},0).wait(1).to({scaleX:0.4281,scaleY:0.4281,x:580.4281,y:161.7387},0).wait(1).to({scaleX:0.4259,scaleY:0.4259,x:576.2657,y:160.3536},0).wait(1).to({scaleX:0.4234,scaleY:0.4234,x:571.7927,y:159.0173},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:567.0086,y:157.7386},0).wait(1).to({scaleX:0.4177,scaleY:0.4177,x:561.9093,y:156.5239},0).wait(1).to({scaleX:0.4144,scaleY:0.4144,x:556.4869,y:155.3783},0).wait(1).to({scaleX:0.4109,scaleY:0.4109,x:550.7366,y:154.3071},0).wait(1).to({scaleX:0.407,scaleY:0.407,x:544.6401,y:153.313},0).wait(1).to({scaleX:0.4028,scaleY:0.4028,x:538.1825,y:152.3999},0).wait(1).to({scaleX:0.3983,scaleY:0.3983,x:531.3478,y:151.572},0).wait(1).to({scaleX:0.3934,scaleY:0.3934,x:524.1184,y:150.8334},0).wait(1).to({scaleX:0.3881,scaleY:0.3881,x:516.4737,y:150.1888},0).wait(1).to({scaleX:0.3824,scaleY:0.3824,x:508.4085,y:149.6469},0).wait(1).to({scaleX:0.3763,scaleY:0.3763,x:498.808,y:149.1842},0).wait(1).to({scaleX:0.3697,scaleY:0.3697,x:485.4879,y:148.792},0).wait(1).to({scaleX:0.3626,scaleY:0.3626,x:471.2137,y:148.6177},0).wait(1).to({scaleX:0.355,scaleY:0.355,x:457.0463,y:148.6392},0).wait(1).to({scaleX:0.3469,scaleY:0.3469,x:443.0444,y:148.8129},0).wait(1).to({scaleX:0.3383,scaleY:0.3383,x:429.0038,y:149.1123},0).wait(1).to({scaleX:0.3291,scaleY:0.3291,x:414.7689,y:149.524},0).wait(1).to({scaleX:0.3195,scaleY:0.3195,x:400.2627,y:150.0394},0).wait(1).to({scaleX:0.3093,scaleY:0.3093,x:385.4647,y:150.6515},0).wait(1).to({scaleX:0.2986,scaleY:0.2986,x:370.644,y:151.3518},0).wait(1).to({scaleX:0.2876,scaleY:0.2876,x:357.5909,y:151.9889},0).wait(1).to({scaleX:0.2762,scaleY:0.2762,x:345.2486,y:152.5824},0).wait(1).to({scaleX:0.2646,scaleY:0.2646,x:332.2165,y:153.1956},0).wait(1).to({scaleX:0.253,scaleY:0.253,x:318.8093,y:153.8046},0).wait(1).to({scaleX:0.2414,scaleY:0.2414,x:304.2527,y:154.4262},0).wait(1).to({scaleX:0.2301,scaleY:0.2301,x:290.064,y:154.9464},0).wait(1).to({scaleX:0.2191,scaleY:0.2191,x:277.2266,y:155.3062},0).wait(1).to({scaleX:0.2086,scaleY:0.2086,x:264.4858,y:155.5261},0).wait(1).to({scaleX:0.1987,scaleY:0.1987,x:252.0392,y:155.5587},0).wait(1).to({scaleX:0.1894,scaleY:0.1894,x:239.6338,y:155.358},0).wait(1).to({scaleX:0.1809,scaleY:0.1809,x:231.8781,y:155.0696},0).wait(1).to({scaleX:0.173,scaleY:0.173,x:223.8786,y:154.6091},0).wait(1).to({scaleX:0.1659,scaleY:0.1659,x:216.8273,y:154.0362},0).wait(1).to({scaleX:0.1595,scaleY:0.1595,x:210.3515,y:153.34},0).wait(1).to({scaleX:0.1538,scaleY:0.1538,x:204.5351,y:152.542},0).wait(1).to({scaleX:0.1488,scaleY:0.1488,x:199.3229,y:151.6522},0).wait(1).to({scaleX:0.1443,scaleY:0.1443,x:194.6955,y:150.6866},0).wait(1).to({scaleX:0.1404,scaleY:0.1404,x:190.6297,y:149.6629},0).wait(1).to({scaleX:0.1371,scaleY:0.1371,x:187.0978,y:148.601},0).wait(1).to({scaleX:0.1343,scaleY:0.1343,x:184.0717,y:147.5239},0).wait(1).to({scaleX:0.1319,scaleY:0.1319,x:181.5318,y:146.4625},0).wait(1).to({scaleX:0.13,scaleY:0.13,x:179.4528,y:145.4524},0).wait(1).to({scaleX:0.1285,scaleY:0.1285,x:177.812,y:144.5368},0).wait(1).to({scaleX:0.1274,scaleY:0.1274,x:176.583,y:143.7623},0).wait(1).to({scaleX:0.1266,scaleY:0.1266,x:175.7377,y:143.1742},0).wait(1).to({scaleX:0.1261,scaleY:0.1261,x:175.248,y:142.8088},0).wait(1).to({regX:3.6,regY:0.4,scaleX:0.126,scaleY:0.126,x:175.15,y:142.7},0).wait(46));

	// Layer_30
	this.instance = new lib.Icon_OneDrive_1();
	this.instance.parent = this;
	this.instance.setTransform(372.65,22.3,0.31,0.31,0,0,0,0.3,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:0,regY:0,x:372.5514,y:22.1477},0).wait(3).to({regX:0.3,regY:0.5,x:372.65,y:22.3},0).wait(1).to({regX:0,regY:0,scaleX:0.3099,scaleY:0.3099,x:372.2566,y:21.9684},0).wait(1).to({scaleX:0.3097,scaleY:0.3097,x:371.8714,y:21.7366},0).wait(1).to({scaleX:0.3095,scaleY:0.3095,x:371.3938,y:21.4529},0).wait(1).to({scaleX:0.3093,scaleY:0.3093,x:370.8188,y:21.1167},0).wait(1).to({scaleX:0.309,scaleY:0.309,x:370.1409,y:20.7279},0).wait(1).to({scaleX:0.3087,scaleY:0.3087,x:369.3537,y:20.2864},0).wait(1).to({scaleX:0.3084,scaleY:0.3084,x:368.4501,y:19.7929},0).wait(1).to({scaleX:0.308,scaleY:0.308,x:367.4224,y:19.2485},0).wait(1).to({scaleX:0.3075,scaleY:0.3075,x:366.262,y:18.6549},0).wait(1).to({scaleX:0.3071,scaleY:0.3071,x:364.9595,y:18.0149},0).wait(1).to({scaleX:0.3065,scaleY:0.3065,x:363.5044,y:17.3321},0).wait(1).to({scaleX:0.3059,scaleY:0.3059,x:361.8856,y:16.6116},0).wait(1).to({scaleX:0.3053,scaleY:0.3053,x:360.091,y:15.8596},0).wait(1).to({scaleX:0.3046,scaleY:0.3046,x:358.1077,y:15.0843},0).wait(1).to({scaleX:0.3038,scaleY:0.3038,x:355.9224,y:14.2957},0).wait(1).to({scaleX:0.303,scaleY:0.303,x:353.5212,y:13.5063},0).wait(1).to({scaleX:0.3021,scaleY:0.3021,x:350.8903,y:12.7307},0).wait(1).to({scaleX:0.3012,scaleY:0.3012,x:348.0163,y:11.9864},0).wait(1).to({scaleX:0.3001,scaleY:0.3001,x:344.8869,y:11.2934},0).wait(1).to({scaleX:0.299,scaleY:0.299,x:341.4922,y:10.6746},0).wait(1).to({scaleX:0.2978,scaleY:0.2978,x:337.8228,y:10.1546},0).wait(1).to({scaleX:0.2966,scaleY:0.2966,x:333.873,y:9.7599},0).wait(1).to({scaleX:0.2952,scaleY:0.2952,x:329.6402,y:9.5178},0).wait(1).to({scaleX:0.2938,scaleY:0.2938,x:325.1272,y:9.456},0).wait(1).to({scaleX:0.2922,scaleY:0.2922,x:320.3384,y:9.6007},0).wait(1).to({scaleX:0.2906,scaleY:0.2906,x:315.2818,y:9.9766},0).wait(1).to({scaleX:0.2888,scaleY:0.2888,x:309.9685,y:10.6055},0).wait(1).to({scaleX:0.2869,scaleY:0.2869,x:304.4113,y:11.5063},0).wait(1).to({scaleX:0.285,scaleY:0.285,x:298.6247,y:12.6941},0).wait(1).to({scaleX:0.2828,scaleY:0.2828,x:292.6269,y:14.1795},0).wait(1).to({scaleX:0.2806,scaleY:0.2806,x:285.5627,y:16.2516},0).wait(1).to({scaleX:0.2783,scaleY:0.2783,x:277.0685,y:19.1586},0).wait(1).to({scaleX:0.2758,scaleY:0.2758,x:268.351,y:22.5532},0).wait(1).to({scaleX:0.2732,scaleY:0.2732,x:259.7215,y:26.2726},0).wait(1).to({scaleX:0.2704,scaleY:0.2704,x:251.2079,y:30.2514},0).wait(1).to({scaleX:0.2676,scaleY:0.2676,x:242.7841,y:34.4587},0).wait(1).to({scaleX:0.2646,scaleY:0.2646,x:234.4281,y:38.8717},0).wait(1).to({scaleX:0.2615,scaleY:0.2615,x:226.1413,y:43.4621},0).wait(1).to({scaleX:0.2584,scaleY:0.2584,x:217.9425,y:48.1957},0).wait(1).to({scaleX:0.2552,scaleY:0.2552,x:209.4496,y:53.2764},0).wait(1).to({scaleX:0.252,scaleY:0.252,x:195.6967,y:61.7924},0).wait(1).to({scaleX:0.2488,scaleY:0.2488,x:182.608,y:69.9893},0).wait(1).to({scaleX:0.2456,scaleY:0.2456,x:173.6349,y:75.6306},0).wait(1).to({scaleX:0.2425,scaleY:0.2425,x:166.3631,y:80.1667},0).wait(1).to({scaleX:0.2395,scaleY:0.2395,x:160.5898,y:83.7083},0).wait(1).to({scaleX:0.2366,scaleY:0.2366,x:154.6457,y:87.2828},0).wait(1).to({scaleX:0.2338,scaleY:0.2338,x:148.847,y:90.6775},0).wait(1).to({scaleX:0.2312,scaleY:0.2312,x:143.1298,y:93.8987},0).wait(1).to({scaleX:0.2287,scaleY:0.2287,x:137.2496,y:97.0129},0).wait(1).to({scaleX:0.2265,scaleY:0.2265,x:132.119,y:99.5321},0).wait(1).to({scaleX:0.2244,scaleY:0.2244,x:127.5989,y:101.5746},0).wait(1).to({scaleX:0.2224,scaleY:0.2224,x:123.2267,y:103.3613},0).wait(1).to({scaleX:0.2207,scaleY:0.2207,x:119.0632,y:104.8534},0).wait(1).to({scaleX:0.2191,scaleY:0.2191,x:115.0881,y:106.043},0).wait(1).to({scaleX:0.2177,scaleY:0.2177,x:111.25,y:106.9156},0).wait(1).to({scaleX:0.2164,scaleY:0.2164,x:107.905,y:107.4024},0).wait(1).to({scaleX:0.2152,scaleY:0.2152,x:105.2616,y:107.5762},0).wait(1).to({scaleX:0.2142,scaleY:0.2142,x:102.7741,y:107.5389},0).wait(1).to({scaleX:0.2133,scaleY:0.2133,x:100.5462,y:107.3113},0).wait(1).to({scaleX:0.2126,scaleY:0.2126,x:98.5782,y:106.9305},0).wait(1).to({scaleX:0.2119,scaleY:0.2119,x:96.8838,y:106.4441},0).wait(1).to({scaleX:0.2114,scaleY:0.2114,x:95.4662,y:105.906},0).wait(1).to({scaleX:0.2109,scaleY:0.2109,x:94.3195,y:105.37},0).wait(1).to({scaleX:0.2106,scaleY:0.2106,x:93.4283,y:104.8829},0).wait(1).to({scaleX:0.2103,scaleY:0.2103,x:92.7712,y:104.4798},0).wait(1).to({scaleX:0.2101,scaleY:0.2101,x:92.3252,y:104.1832},0).wait(1).to({scaleX:0.21,scaleY:0.21,x:92.0694,y:104.0041},0).wait(1).to({regX:-0.7,regY:-0.5,x:92.05,y:104.05},0).wait(37));

	// laptop
	this.laptop = new lib.laptop_phone();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(160.05,156.2,0.655,0.655,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(109));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(41.1,-17,753.9,272.8);


(lib.BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bg.cache(0,0,728,90,1)
		this.bg_fade.cache(0,0,728,90,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_3
	this.bg_fade = new lib.bg_fade_cache();
	this.bg_fade.name = "bg_fade";
	this.bg_fade.parent = this;
	this.bg_fade.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.bg_fade).wait(1));

	// Layer_1
	this.bg = new lib.bg_cache();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.BG, new cjs.Rectangle(0,0,728,90), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-8.45,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("Ap2CjIAAlFITtAAIAAFFg");
	this.shape.setTransform(-38.025,-1.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-101.1,-17.5,126.19999999999999,32.6), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logocopy();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logoscopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_34 = function() {
		exportRoot.tlpic1.play();
	}
	this.frame_42 = function() {
		exportRoot.tlpic5.play();
	}
	this.frame_51 = function() {
		exportRoot.tlpic2.play();
		exportRoot.tlpic4.play();
	}
	this.frame_59 = function() {
		exportRoot.tlpic3.play();
	}
	this.frame_68 = function() {
		exportRoot.tl1.play()
		exportRoot.tl2.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(34).call(this.frame_34).wait(8).call(this.frame_42).wait(9).call(this.frame_51).wait(8).call(this.frame_59).wait(9).call(this.frame_68).wait(6).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sqcopy();
	this.instance.parent = this;
	this.instance.setTransform(980.95,81,0.2717,0.2717,0,0,0,-40,1.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({scaleX:4.4931,scaleY:4.4931,x:981.05,y:80.85},13,cjs.Ease.quadOut).to({x:802.75},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EA0YAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_15 = new cjs.Graphics().p("EA0LAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_16 = new cjs.Graphics().p("EAzmAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_17 = new cjs.Graphics().p("EAyoAKJIAAvJMA5FAAAIAAPJg");
	var mask_graphics_18 = new cjs.Graphics().p("EAxQAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_19 = new cjs.Graphics().p("EAvgAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_20 = new cjs.Graphics().p("EAtXAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_21 = new cjs.Graphics().p("EArOAKJIAAvJMA5FAAAIAAPJg");
	var mask_graphics_22 = new cjs.Graphics().p("EApeAKJIAAvJMA5FAAAIAAPJg");
	var mask_graphics_23 = new cjs.Graphics().p("EAoGAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_24 = new cjs.Graphics().p("EAnIAKJIAAvJMA5GAAAIAAPJg");
	var mask_graphics_25 = new cjs.Graphics().p("EAmjAKJIAAvJMA5FAAAIAAPJg");
	var mask_graphics_26 = new cjs.Graphics().p("EAmWAKJIAAvJMA5GAAAIAAPJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:700.5514,y:64.8754}).wait(1).to({graphics:mask_graphics_15,x:699.3045,y:64.8754}).wait(1).to({graphics:mask_graphics_16,x:695.5639,y:64.8754}).wait(1).to({graphics:mask_graphics_17,x:689.3295,y:64.8754}).wait(1).to({graphics:mask_graphics_18,x:680.6014,y:64.8754}).wait(1).to({graphics:mask_graphics_19,x:669.3795,y:64.8754}).wait(1).to({graphics:mask_graphics_20,x:655.6639,y:64.8754}).wait(1).to({graphics:mask_graphics_21,x:641.9483,y:64.8754}).wait(1).to({graphics:mask_graphics_22,x:630.7264,y:64.8754}).wait(1).to({graphics:mask_graphics_23,x:621.9983,y:64.8754}).wait(1).to({graphics:mask_graphics_24,x:615.7639,y:64.8754}).wait(1).to({graphics:mask_graphics_25,x:612.0233,y:64.8754}).wait(1).to({graphics:mask_graphics_26,x:610.7764,y:64.8754}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(803.35,75.45,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_animcopy();
	this.instance_2.parent = this;
	this.instance_2.setTransform(982.9,75.45,4.4931,4.4931,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:982.9},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_51 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_52 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_55 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_56 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_59 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_60 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_61 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_63 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_65 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_66 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_67 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_68 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Ei3jAYyMAAAgxjMFvHAAAMAAAAxjg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EjGHAYyMAAAgxjMFvIAAAMAAAAxjg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:987.3838,y:91.0174}).wait(51).to({graphics:mask_1_graphics_51,x:987.3838,y:91.0174}).wait(1).to({graphics:mask_1_graphics_52,x:982.0583,y:91.0174}).wait(1).to({graphics:mask_1_graphics_53,x:966.0818,y:91.0174}).wait(1).to({graphics:mask_1_graphics_54,x:939.4542,y:91.0174}).wait(1).to({graphics:mask_1_graphics_55,x:902.1756,y:91.0174}).wait(1).to({graphics:mask_1_graphics_56,x:854.246,y:91.0174}).wait(1).to({graphics:mask_1_graphics_57,x:795.6654,y:91.0174}).wait(1).to({graphics:mask_1_graphics_58,x:726.4338,y:91.0174}).wait(1).to({graphics:mask_1_graphics_59,x:646.5511,y:91.0174}).wait(1).to({graphics:mask_1_graphics_60,x:556.0175,y:91.0174}).wait(1).to({graphics:mask_1_graphics_61,x:454.8328,y:91.0174}).wait(1).to({graphics:mask_1_graphics_62,x:342.9971,y:91.0174}).wait(1).to({graphics:mask_1_graphics_63,x:220.5103,y:91.0174}).wait(1).to({graphics:mask_1_graphics_64,x:87.3726,y:91.0174}).wait(1).to({graphics:mask_1_graphics_65,x:-56.4162,y:91.0174}).wait(1).to({graphics:mask_1_graphics_66,x:-210.856,y:91.0174}).wait(1).to({graphics:mask_1_graphics_67,x:-375.9468,y:91.0174}).wait(1).to({graphics:mask_1_graphics_68,x:-551.6887,y:91.0174}).wait(1).to({graphics:mask_1_graphics_69,x:-738.0815,y:91.0174}).wait(1).to({graphics:mask_1_graphics_70,x:-935.1254,y:91.0174}).wait(1).to({graphics:mask_1_graphics_71,x:-1142.8203,y:91.0174}).wait(1).to({graphics:mask_1_graphics_72,x:-1268,y:91.0174}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_animcopy();
	this.instance_3.parent = this;
	this.instance_3.setTransform(982.9,75.45,4.4931,4.4931,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_4 = new lib.whitecopy();
	this.instance_4.parent = this;
	this.instance_4.setTransform(987.2,90.95,2.42,0.3896,0,0,0,485.4,406.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-1361.35},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.whitecopy();
	this.instance_5.parent = this;
	this.instance_5.setTransform(987.2,90.95,2.42,0.3896,0,0,0,485.4,406.8);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-1361.35},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2536,-67.5,4698.2,317.2);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(711.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// intro_logo
	this.logo_intro = new lib.logoscopy();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(669.7,59.15,0.855,0.855,0,0,0,0.8,0.2);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(715.25,60.25,0.855,0.855,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(48.5,23.5,0.63,0.63,0,0,0,0.8,0.8);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// anim
	this.anim = new lib.Devices_Isometric();
	this.anim.name = "anim";
	this.anim.parent = this;
	this.anim.setTransform(145.15,-30.3,0.49,0.49,0,0,0,-0.1,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.anim).wait(1));

	// BG
	this.bg = new lib.BG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(300,250,1,1,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-0.9,-32.9,737.4,130.5), null);


// stage content:
(lib.O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var anim = exportRoot.mainMC.anim
		var laptop = exportRoot.mainMC.anim.laptop
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
			
			exportRoot.tl1.from(laptop, 2, {y:"+=180", ease:Power3.easeInOut, onStart:function(){anim.gotoAndPlay(1);}}, "+=1.5");
		
			//exportRoot.tl1.to(anim, 1.5, {x:"+=70", ease:Power3.easeInOut}, "+=0");
			
			exportRoot.tl1.stop();	
			
			
			//exportRoot.tl1.to(anim, 1.5, {scaleX:.975, scaleY:.975, y:"+=6", x:"+=24", ease:Power3.easeInOut}, "+=0.5");
		
			this.tl2 = new TimelineLite();
			
			//Organize your photos
			exportRoot.tl2.from(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=3.5");
			exportRoot.tl2.from(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
			exportRoot.tl2.from(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
				
			exportRoot.tl2.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
			exportRoot.tl2.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
			exportRoot.tl2.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
		
			//and
			exportRoot.tl2.from(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
			
			exportRoot.tl2.to(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.4");
			
			//keep them secure
			exportRoot.tl2.from(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
			exportRoot.tl2.from(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.25");
			exportRoot.tl2.from(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0.2");
				
			exportRoot.tl2.to(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0.8");
			exportRoot.tl2.to(exportRoot.headline6, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
			exportRoot.tl2.to(exportRoot.headline7, 0.01, {alpha: 0, ease:Power4.easeIn}, "-=0.01");
			
			//in OneDrive
			exportRoot.tl2.from(exportRoot.headline8, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.01");
			exportRoot.tl2.from(exportRoot.headline9, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.25");
			
			exportRoot.tl2.to(exportRoot.headline8, 0.5, {alpha: 0, ease:Power4.easeIn}, "+=0.6");
			exportRoot.tl2.to(exportRoot.headline9, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
		
			exportRoot.tl2.from(mc.bg.bg_fade, 1.5, {alpha:0, ease:Power3.easeInOut}, "-=.5");
		
			
			for (var i = 0; i < exportRoot.headline10.length; i++) {
			if (i==0) exportRoot.tl2.from(exportRoot.headline10[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=1");
			if (i!=0) exportRoot.tl2.from(exportRoot.headline10[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.7");
			}
				
			for (var i = 0; i < exportRoot.headline11.length; i++) {
			if (i==0) exportRoot.tl2.from(exportRoot.headline11[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			if (i!=0) exportRoot.tl2.from(exportRoot.headline11[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.7");
			}
				
			exportRoot.tl2.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=0.4");	
			exportRoot.tl2.from(mc.txtCta, 0.7, { alpha: 0, x: "+=150",	ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl2.from(mc.cta, 0.7, {	alpha: 0, x: "+=150", ease:Power4.easeOut}, "-=0.7");
		
			
			exportRoot.tl2.stop();
				
			this.tlpic1 = new TimelineLite();
				
			exportRoot.tlpic1.to(anim.img_snowman.snowTest, 1, {x:"-=20", y:"+=60", ease:Power2.easeInOut});
			exportRoot.tlpic1.to(anim.img_snowman.snowTest, 2, {x:"+=40", y:"-=180", ease:Power2.easeInOut});
			exportRoot.tlpic1.to(anim.img_snowman.snowTest, 1, {x:"-=20", y:"+=60", ease:Power2.easeInOut});
		
			exportRoot.tlpic1.stop();
				
			this.tlpic2 = new TimelineLite();
				
			exportRoot.tlpic2.to(anim.img_family.snowTest, 1, {x:"+=10", y:"-=22.5", ease:Power2.easeInOut});
			exportRoot.tlpic2.to(anim.img_family.snowTest, 2, {x:"-=20", y:"+=45", ease:Power2.easeInOut});
			exportRoot.tlpic2.to(anim.img_family.snowTest, 1, {x:"+=10", y:"-=22.5", ease:Power2.easeInOut});
		
			exportRoot.tlpic2.stop();
		
			this.tlpic3 = new TimelineLite();
				
			exportRoot.tlpic3.to(anim.img_landscape.snowTest, 1, {x:"-=10", y:"+=15", ease:Power2.easeInOut});
			exportRoot.tlpic3.to(anim.img_landscape.snowTest, 2, {x:"+=20", y:"-=30", ease:Power2.easeInOut});
			exportRoot.tlpic3.to(anim.img_landscape.snowTest, 1, {x:"-=10", y:"+=15", ease:Power2.easeInOut});
			
			exportRoot.tlpic3.stop();
				
			this.tlpic4 = new TimelineLite();
				
			exportRoot.tlpic4.to(anim.img_dog.snowTest, 1, {x:"+=10", y:"-=25", ease:Power2.easeInOut});
			exportRoot.tlpic4.to(anim.img_dog.snowTest, 2, {x:"-=20", y:"+=50", ease:Power2.easeInOut});
			exportRoot.tlpic4.to(anim.img_dog.snowTest, 1, {x:"+=10", y:"-=25", ease:Power2.easeInOut});
			
			exportRoot.tlpic4.stop();
		
			this.tlpic5 = new TimelineLite();
			
			exportRoot.tlpic5.to(anim.img_shoes.snowTest, 1, {x:"-=10", y:"+=35", ease:Power2.easeInOut});
			exportRoot.tlpic5.to(anim.img_shoes.snowTest, 2, {x:"+=20", y:"-=70", ease:Power2.easeInOut});
			exportRoot.tlpic5.to(anim.img_shoes.snowTest, 1, {x:"-=10", y:"+=35", ease:Power2.easeInOut});
		
			exportRoot.tlpic5.stop();
				
			mc.logo_intro.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(363.1,12.1,373.4,85.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574944842250", id:"O365_NewYearCampaign_USA_728x90_BAN_OneDrive_Organize_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;