(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_", frames: [[314,117,336,51],[0,0,757,115],[969,0,49,86],[747,277,266,43],[652,117,93,172],[176,249,69,69],[0,117,174,281],[176,117,136,130],[759,0,208,275],[425,170,172,49],[314,170,109,98],[969,88,17,150]]}
];


// symbols:



(lib.Bitmap3 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.laptopshadow = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.mob_display = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.phoneshadow = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.phone = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.PPTIcon = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Step1 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Step3 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Step4 = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Step2_ears = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Step2_eyes = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.thumbs = function() {
	this.initialize(ss["O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tmb_select = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#D1492A").ss(4,1,1).p("AuSoCIclAAIAAQFI8lAAg");
	this.shape.setTransform(93.475,53.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.tmb_select, new cjs.Rectangle(0,0.4,187,107), null);


(lib.shadowcache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Livello_1
	this.instance = new lib.laptopshadow();
	this.instance.parent = this;
	this.instance.setTransform(0,0,1.2549,1.2549);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.shadowcache, new cjs.Rectangle(0,0,950,144.3), null);


(lib.phonecache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// screen blank
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjDFdIAAq5IGHAAIAAK5g");
	this.shape.setTransform(67.525,42.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// phone
	this.instance = new lib.phone();
	this.instance.parent = this;
	this.instance.setTransform(44.9,0,0.4913,0.4913);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.instance_1 = new lib.phoneshadow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,65.9,0.5071,0.5071);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.phonecache, new cjs.Rectangle(0,0,134.9,87.7), null);


(lib.msoft_logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MS-symbol
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#727272").s().p("AggAnQgNgOAAgYQAAgXAOgPQAPgPASAAQAVAAAMANQALANAAAZIAAAIIhDAAQgBAOAJAHQAJAIAMAAQARAAANgKIAAATQgOAIgWAAQgWAAgMgOgAgNgbQgHAGgBAMIAtAAQAAgMgGgHQgGgHgKAAQgIAAgHAIg");
	this.shape.setTransform(164.9709,13.6022,1.0219,1.0219);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#727272").s().p("AgYAnQgOgOgBgXQABgYAPgOQAPgQAXAAQANAAAMAFIAAAWQgLgJgMAAQgOAAgJAKQgJALAAAOQAAAPAJAKQAHAJAPAAQANAAALgJIAAAUQgNAHgQAAQgWAAgNgOg");
	this.shape_1.setTransform(155.6206,13.6022,1.0219,1.0219);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#727272").s().p("AgLBKIAAhkIAWAAIAABkgAgJgzQgEgDAAgGQAAgGAEgDQAEgEAFAAQAGAAAEAEQAEADAAAGQAAAGgEADQgEAEgGAAQgFAAgEgEg");
	this.shape_2.setTransform(149.0549,11.2007,1.0219,1.0219);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#727272").s().p("AgPBMIAAhSIgSAAIAAgSIASAAIAAgRQAAgQAKgJQAKgJAPAAQAJAAAFACIAAATQgFgDgGAAQgRAAAAATIAAAOIAYAAIAAASIgXAAIAABSg");
	this.shape_3.setTransform(143.5367,11.0219,1.0219,1.0219);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("AgQBMIAAhSIgRAAIAAgSIARAAIAAgRQAAgQALgJQAJgJAQAAQAJAAAFACIAAATQgGgDgFAAQgQAAAAATIAAAOIAXAAIAAASIgXAAIAABSg");
	this.shape_4.setTransform(137.0732,11.0219,1.0219,1.0219);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#727272").s().p("AgwA1QgTgUAAgfQAAgiATgUQASgUAgAAQAeAAASAUQASATAAAgQAAAigSAUQgUAUgeAAQgeAAgSgUgAgeglQgMAOAAAXQAAAYAMAOQAMAOASAAQAVAAALgNQAMgOgBgYQAAgYgLgPQgLgNgVAAQgSAAgMAOg");
	this.shape_5.setTransform(126.3433,11.5584,1.0219,1.0219);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFB800").s().p("Ag3A4IAAhvIBvAAIAABvg");
	this.shape_6.setTransform(18.993,17.8941,1.0219,1.0219);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#00A2EE").s().p("Ag3A4IAAhvIBvAAIAABvg");
	this.shape_7.setTransform(6.3726,17.8941,1.0219,1.0219);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#7EB900").s().p("Ag3A4IAAhvIBvAAIAABvg");
	this.shape_8.setTransform(18.993,5.2226,1.0219,1.0219);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#F25127").s().p("Ag3A4IAAhvIBvAAIAABvg");
	this.shape_9.setTransform(6.3726,5.2226,1.0219,1.0219);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#727272").s().p("AFmBFQgHgIAAgQIAAgzIgkAAIAABQIgXAAIAAhQIgRAAIAAgUIARAAIAAgOQAAgPAKgLQAKgKARAAIAIABIAFABIAAAUIgEgBIgHgBQgHgBgEAFQgEAGgBAIIAAAMIAkAAIAAgWIAYgIIAAAeIAZAAIAAAUIgZAAIAAAvQAAAIADAEQAFAEAHABIAEgCIAGgCIAAATQgDACgFABIgKABQgPAAgJgIgAC2A/QgOgNAAgZQAAgYAOgOQAOgPAZAAQAZAAAMAOQAOAOAAAYQAAAZgOANQgOAPgZAAQgYAAgNgOgADIAAQgHAHAAASQAAARAHAHQAIAJANAAQANAAAGgJQAHgIAAgRQAAgRgHgHQgHgIgMAAQgNAAgIAIgABnBMIgNgFIAAgWIAOAGQAJADAEAAQAJAAAEgCQADgCAAgFQAAgGgDgDQgDgCgNgGQgOgFgFgIQgFgGAAgLQAAgMALgJQAKgJASAAIAMABQAGABAFACIAAAXIgLgGQgGgCgGAAQgHAAgEACQgEAEAAADQAAAEADAEQAEADALAFQANAEAHAIQAFAHABAKQgBAOgKAKQgMAIgSAAIgOgBgAgLA/QgNgNAAgZQAAgYAOgOQANgPAZAAQAZAAANAOQANAOgBAYQABAZgOANQgOAPgZAAQgYAAgNgOgAAGAAQgGAIAAARQAAAPAGAJQAIAJANAAQANAAAHgJQAHgIAAgRQAAgQgHgIQgHgIgNAAQgNAAgIAIgAioA/QgOgPAAgVQAAgYAPgPQAOgQAaAAQAHAAAHABQAFABAGAEIAAAWQgGgEgGgCQgEgCgIAAQgOAAgIAIQgJAJAAAQQAAAQAIAIQAJAIAOABQAFAAAHgDIAMgGIAAAVQgIAEgGACQgHABgIAAQgXAAgOgOgAhUBKIAAhkIAXAAIAAAQIABAAQADgJAHgDQAGgGAJABIAGAAIADABIAAAYIgFgCIgJgCQgIABgHAFQgGAIAAAQIAAAygAjeBKIAAhkIAXAAIAABkgAkOBKIAAhtIgBAAIgrBtIgQAAIgthtIAABtIgXAAIAAiLIAjAAIAoBnIABAAIArhnIAhAAIAACLgAjcguQgFgDAAgGQAAgFAFgFQAFgEAFAAQAGAAAEAEQAEAEAAAGQAAAGgEAEQgEADgGAAQgHAAgDgEg");
	this.shape_10.setTransform(72.7448,11.1496,1.0219,1.0219);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#727272").s().p("AgpBCIAAgWQAPAKANAAQAOAAAIgIQAJgHAAgMQAAgMgJgHQgIgHgQAAIgXABIAFhJIBEAAIAAAUIgxAAIgDAjIANAAQAWAAALALQANALAAAUQAAAUgPANQgNANgYAAQgVAAgKgGg");
	this.shape_11.setTransform(200.7629,11.6861,1.0219,1.0219);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#727272").s().p("AgiA4QgMgSAAgeQgBgYAIgRQAIgUAOgJQAOgKAQAAQAQAAAJAEIAAAUQgMgFgLAAQgRAAgLAOQgKAPAAAXIAAAAQAFgHAJgFQAHgFAJABQATAAAKAMQAMAJgBAVQAAAOgFALQgHALgKAGQgLAGgNAAQgVAAgOgRgAgPAHQgHAHAAAKQAAAIADAHQADAHAGAEQAGAFAFAAQALAAAGgIQAHgHAAgNQgBgNgGgHQgGgHgLAAQgKAAgGAHg");
	this.shape_12.setTransform(190.5183,11.5584,1.0219,1.0219);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#727272").s().p("AgcBHQgJgCgFgDIAAgXQAFAEALAEQAIAEAKAAQALAAAJgHQAHgHABgKQAAgLgKgHQgJgFgQgBIgNAAIAAgSIAMAAQAPABAHgGQAJgGgBgKQAAgLgGgFQgGgGgLABQgOAAgOAKIAAgVQAFgDAKgDQAJgCAKAAQAMAAAJAEQALAFADAIQAGAHAAAKQAAAPgIAIQgHAJgNADIAAABQAPACAJAHQAJAJAAAOQAAAUgOALQgPAMgWAAQgLAAgJgCg");
	this.shape_13.setTransform(180.095,11.5584,1.0219,1.0219);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.msoft_logo, new cjs.Rectangle(0.7,-0.5,204.4,24.1), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#737373").s().p("AhlB4QgmgqAAhNQAAhHAqgtQAqgtA/gBQA/AAAjApQAiApABBIIAAAaIjSAAQABArAaAXQAYAXArAAQAzAAAogeIAAA5QgqAahFAAQhDAAgngpgAgrhXQgUAVgGAkICOAAQAAglgSgVQgRgVgfAAQgdAAgVAWg");
	this.shape_9.setTransform(86.031,2.1774,0.2949,0.2949);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#737373").s().p("AhNB3QgrgrABhFQAAhLAtguQAtgvBLAAQApAAAiAPIAABBQghgYgkAAQgsAAgcAeQgdAeABAwQAAAwAbAbQAZAcAtAAQAmAAAhgbIAAA9QglAVgyAAQhEAAgqgqg");
	this.shape_10.setTransform(77.7736,2.1774,0.2949,0.2949);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#737373").s().p("AgjDjIAAk1IBFAAIAAE1gAgdidQgMgLAAgRQAAgSAMgMQAMgKARgBQASABAMAKQAMAMAAASQAAAQgMAMQgNALgRAAQgQAAgNgLg");
	this.shape_11.setTransform(71.9935,0.054,0.2949,0.2949);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgyQAAgxAggcQAfgcAwAAQAZAAAQAFIAAA7QgPgJgRABQgzAAAAA5IAAAqIBHAAIAAA3IhHAAIAAD9g");
	this.shape_12.setTransform(67.1201,-0.1082,0.2949,0.2949);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#737373").s().p("AgxDoIAAj9Ig1AAIAAg3IA1AAIAAgyQAAgwAggdQAfgcAwAAQAZAAAQAFIAAA7QgPgJgSABQgyAAAAA5IAAAqIBHAAIAAA3IhHAAIAAD9g");
	this.shape_13.setTransform(61.4137,-0.1082,0.2949,0.2949);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#737373").s().p("AiXCjQg4g9AAhhQAAhnA5g+QA6g+BhAAQBbAAA4A8QA3A9AABhQAABog4A+Qg5A9hfAAQheAAg4g8gAhehzQgmAsAABIQAABIAlAsQAlAsA6AAQA8AAAlgqQAjgqAAhMQAAhMgigqQgkgqg9AAQg6AAglAsg");
	this.shape_14.setTransform(51.9693,0.3563,0.2949,0.2949);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#737373").s().p("Ah/DKIAAhDQArAdAsAAQAqgBAbgWQAbgWAAglQAAglgbgVQgbgVgyABQgOAAg5ADIAQjiIDTAAIAAA8IiaAAIgHBsIAmgBQBEAAAlAjQAlAjAAA8QAABBgqAmQgrAnhKAAQhAAAgfgSg");
	this.shape_15.setTransform(117.5565,0.4816,0.2949,0.2949);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#737373").s().p("AhoCrQgog1AAhdQAAhKAXg4QAWg4ArgfQArgeA1AAQAzAAAaAMIAAA/QglgTgkAAQg1AAgfAtQggAsAABKIACAAQANgZAZgOQAYgOAdAAQA6AAAgAkQAiAjAAA+QAAAqgSAiQgTAhghATQgfASgpAAQhDAAgog0gAgxAVQgUAVAAAhQAAAXAJAWQAKAWAQALQAQANAWAAQAhAAATgXQASgXABglQAAgogTgWQgTgVgiAAQgfAAgVAVg");
	this.shape_16.setTransform(108.5472,0.3711,0.2949,0.2949);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#737373").s().p("AhWDYQgegGgOgKIAAhFQATAQAcAKQAcAJAbAAQAoAAAXgTQAYgUAAghQAAgjgbgSQgcgTg0AAIgmAAIAAg4IAkAAQAtAAAZgSQAZgRAAghQAAgegUgRQgTgRgjAAQgtAAgoAfIAAg/QAUgLAbgHQAdgGAbAAQAnAAAdANQAdAOAPAYQAPAYAAAeQAAAqgWAbQgXAbgpALIAAACQAvAFAbAaQAcAcgBApQABA6gsAlQgrAkhJAAQgcAAgegHg");
	this.shape_17.setTransform(99.3313,0.3711,0.2949,0.2949);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-36.4,-7,157.7,14.1);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mask_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhmAgIhGgxIFYgeIhBBfg");
	this.shape.setTransform(17.2503,4.8257);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_35, new cjs.Rectangle(0,0,34.5,9.7), null);


(lib.mask_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ABQAeIjRgQIhGgxIGFgjIAJCNg");
	this.shape.setTransform(19.9503,7.0758);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_34, new cjs.Rectangle(0,0,39.9,14.2), null);


(lib.mask_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiIgKIhFgyIGagsIABB5Ij3BYg");
	this.shape.setTransform(20.6003,10.5258);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_33, new cjs.Rectangle(0,0,41.2,21.1), null);


(lib.mask_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Aj7gxIDTgpIEUgdIAQCKIjWBlg");
	this.shape.setTransform(25.1754,11.9508);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_32, new cjs.Rectangle(0,0,50.4,23.9), null);


(lib.mask_30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlOCdICgiNIG+iAIAJhxIiTAZQgDgDgBguQgCgzAJgQQCHgDAmgFIAIgCIARCOIhLCmIhcD0IjUBlg");
	this.shape.setTransform(33.5,32.675);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_30, new cjs.Rectangle(0,0,67,65.4), null);


(lib.mask_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AlGCdIChiNIGVh9IhihbQgDgDgBguQgBgzAIgQQCIgDAmgFIAIgCIiWIoIjVBlg");
	this.shape.setTransform(32.6778,32.6771);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_29, new cjs.Rectangle(0,0,65.4,65.4), null);


(lib.mask_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak5DGIEhlGICZhIQgCgDgCguQgBgzAIgQQCIgDAmgFIAIgCIiWIoIjUBlg");
	this.shape.setTransform(31.4028,32.6771);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_28, new cjs.Rectangle(0,0,62.8,65.4), null);


(lib.mask_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak5DIICzm0IBbgZQgCgCADgPQADgRAIgRQCAgCB6gHIBggGIiXIrIjVBlg");
	this.shape.setTransform(31.4528,32.8521);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_27, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak5DIICzm0IBbgZQgCgCADgPQADgRAIgRQCAgCB6gHIBggGIiXIrIjVBlg");
	this.shape.setTransform(31.4528,32.8521);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_26, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak5DIICEl+Ih7hDQgCgBADgPQAEgSAHgQQDQgEGPgYIiXIrIjVBlg");
	this.shape.setTransform(31.4528,32.8521);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_25, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak5DIIBhkeIhYijQgCgBADgPQAEgSAHgQQDQgEGPgYIiXIrIjVBlg");
	this.shape.setTransform(31.4528,32.8521);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_24, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkJDIIhhldIBrhkQgCgBADgPQADgSAIgQQDQgEGOgYIiXIrIjUBlg");
	this.shape.setTransform(36.3277,32.8521);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_23, new cjs.Rectangle(0,0,72.7,65.7), null);


(lib.mask_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkGDIIgbi5IhMlKQgCgBFvgHIFugEIiXIrIjVBlg");
	this.shape.setTransform(36.6022,32.8521);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_22, new cjs.Rectangle(0,0,73.2,65.7), null);


(lib.mask_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixCDQgWgFgOgPQgNgOgRAAIDWiQIBTAhQADgQAGgTQALglAMgLQAcgYADgOIAdAjIBiBzIkIBuQgwgLgeAOQgSAIgWAAQgSAAgVgFg");
	this.shape.setTransform(24.3782,13.5454);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_21, new cjs.Rectangle(0,0,48.8,27.1), null);


(lib.mask_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixCJQgWgFgOgPQgNgOgRAAIDWiQIg8g0IAMgHQAVgHAtgEQAsgEApgNQAUgHALgGIApAvIBiBzIkIBuQgwgLgeAOQgSAIgWAAQgSAAgVgFg");
	this.shape.setTransform(24.3782,14.2079);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_20, new cjs.Rectangle(0,0,48.8,28.4), null);


(lib.mask_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixCsQgWgFgOgPQgNgOgRAAIDWiQIh1hiQgQgQgGgRQgOgjAtgEQAtgEBnAlQA0ASAqATIApAvIBiBzIkIBuQgwgLgeAOQgSAIgWAAQgSAAgVgFg");
	this.shape.setTransform(24.3782,17.713);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_19, new cjs.Rectangle(0,0,48.8,35.4), null);


(lib.mask_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhyDzQgWgFgPgQQgMgNgRgBIDUiQIhthaQhIgdg/geQh/g8AtgEQAtgEBogvQAzgYArgXIBwDZID1CdIkIBuQgvgLgfAOQgRAIgXAAQgRAAgVgFg");
	this.shape.setTransform(30.6627,24.7577);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_18, new cjs.Rectangle(0,0,61.3,49.5), null);


(lib.mask_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhwDzQgWgFgOgQQgNgNgRgBIAXgzIgUh7QgvgsgmgtQhMhaAtgEQAtgEBngvQA0gYAqgXIBwDZID2CdIkJBuQgvgLgeAOQgSAIgWAAQgSAAgVgFg");
	this.shape.setTransform(30.8697,24.7577);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_17, new cjs.Rectangle(0,0,61.8,49.5), null);


(lib.mask_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Al6C0QhHgQg2gBIDkh3IBRhgQAHgWAQgXQAeguAtgEQAtgEBngvQAzgXAqgXIByDZID1CcIpUB0IkehBg");
	this.shape.setTransform(50.4028,24.528);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_16, new cjs.Rectangle(0,0,100.8,49.1), null);


(lib.mask_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkkC0QgmgJh1gRQh1gQgagBIEThwICaA5QAUg4Adg3QA5hyAugEQArgEBogvQA0gXAqgXIBxDZID2CcIpVB0IkehBg");
	this.shape.setTransform(59.0526,24.528);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_15, new cjs.Rectangle(0,0,118.1,49.1), null);


(lib.mask_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkrC0QkVg/gGAAIF5ipIBbAAQAGgWAQgXQAeguAtgEQAsgEBogvQAzgXArgXIBxDZID1CcIpUB0IkehBg");
	this.shape.setTransform(58.3151,24.528);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_14, new cjs.Rectangle(0,0,116.7,49.1), null);


(lib.mask_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkrC0QkVg/gGAAIF5ipQgGgzAEgxQAIhiAvAMQAkAJAhAuQAdAoAlgEQAsgEBogvQAzgXArgXIBxDZID1CcIpUB0IkehBg");
	this.shape.setTransform(58.3151,24.528);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask_13, new cjs.Rectangle(0,0,116.7,49.1), null);


(lib.mask__31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkoAvICgiMIGxh7IhbFNIjUBkg");
	this.shape.setTransform(29.7005,21.7007);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask__31, new cjs.Rectangle(0,0,59.4,43.4), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Path_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAQIAAgfQANAAAJAKQAJAIAAANg");
	this.shape.setTransform(1.625,1.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3_0, new cjs.Rectangle(0,0,3.3,3.2), null);


(lib.Path_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIAIIAAgPQAIAAADAFQAGADAAAHg");
	this.shape.setTransform(0.85,0.825);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,1.7,1.7), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.PPTIcon();
	this.instance.parent = this;
	this.instance.setTransform(-65.9,-50.1,1.5617,1.5617);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(-65.9,-50.1,107.80000000000001,107.80000000000001), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.box_w = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C5C5C5").s().p("AuZIJIAAwSIczAAIAAQSgAuSIDIcmAAIAAwGI8mAAg");
	this.shape.setTransform(92.1517,52.151);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AuTIEIAAwHIcnAAIAAQHg");
	this.shape_1.setTransform(92.1767,52.126);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.box_w, new cjs.Rectangle(0,0,184.3,104.3), null);


(lib.bg_page = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#DADADA").ss(1,1,1).p("A7wvhMA3hAAAIAAfDMg3hAAAg");
	this.shape.setTransform(177.675,99.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A7wPiIAA/DMA3hAAAIAAfDg");
	this.shape_1.setTransform(177.675,99.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg_page, new cjs.Rectangle(-1,-1,357.4,200.8), null);


(lib.Group_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F3F2F1").s().p("EhqtACvIAAldMDVbAAAIAAFdg");
	this.shape.setTransform(683,17.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3, new cjs.Rectangle(0,0,1366,35), null);


(lib.ClipGroup_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtACqIAAlTMDVbAAAIAAFTg");
	mask.setTransform(683,17);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhwBSQgiAAgYgYQgZgYAAgiQAAghAZgYQAYgYAiAAIDiAAQAhAAAYAYQAZAYAAAhQAAAigZAYQgYAYghAAgABWgaQgLAMAAAPQAAAQALALQALALARAAQAQAAALgLQALgLAAgQQAAgPgLgMQgLgLgQAAQgRAAgLALg");
	this.shape.setTransform(99.4,16.075);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2, new cjs.Rectangle(79.9,7.9,39.099999999999994,16.4), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtACqIAAlTMDVbAAAIAAFTg");
	mask.setTransform(683,17);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAAAGIgrAsIgGgGIAsgsIgsgrIAGgGIArAtIAsgtIAGAGIgtArIAtAsIgGAGg");
	this.shape.setTransform(1342,17);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgzAFIAAgJIBoAAIAAAJg");
	this.shape_1.setTransform(1250.3,17.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdAFIAAgJIA7AAIAAAJg");
	this.shape_2.setTransform(263.475,15.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgdgOIA7AAIgeAdg");
	this.shape_3.setTransform(263.475,19.5);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(260.5,12,1086.5,10), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtACqIAAlTMDVbAAAIAAFTg");
	mask.setTransform(683,17);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhAAyIAAhjICBAAIAABjgAg5AqIByAAIAAhTIhyAAg");
	this.shape.setTransform(1203.5,17);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgEAjIAAgwIgQAOIgHgGIAbgdIAcAdIgHAGIgQgOIAAAwg");
	this.shape_1.setTransform(1203.475,18.25);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9AFIAAgJIB8AAIAAAJg");
	this.shape_2.setTransform(1203.5,14.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgxAyIAAhPIAUAAIAAgUIBPAAIAABPIgUAAIAAAUgAgpAqIBAAAIAAg/IhAAAgAgWgdIA0AAIAAA0IAMAAIAAhAIhAAAg");
	this.shape_3.setTransform(1296,17);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F0EFEF").s().p("AgdgOIA7AAIgeAdg");
	this.shape_4.setTransform(185.65,17.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgUBOQgMgEgHgFQgHgEgJgIQgIgHgFgJQgFgJgDgKQgDgLAAgLQAAgKADgKQADgMAGgHQAFgLAHgGQAHgGALgHIgqAAIAAgKIA8AAIAAA8IgKAAIAAgrQgJAFgIAGQgGAGgGAJQgFAHgDAKQgDAKAAAJQAAAJADAKQADALADAFQAFAIAHAHQAGAGAIAEQAIAFAIADQAIACAKAAQALAAAHgCQAIgDAJgFQAJgFAGgFQAFgFAGgKQAFgHACgJQACgIAAgLQAAgLgDgKQgEgLgHgJQgIgJgIgHQgJgFgMgEIADgKQAOAEAJAHQAKAHAJALQAHAKAFANQAEANAAALQAAAKgCAMQgDAIgGALQgEAHgJAJQgHAIgIAEQgJAFgKAEQgJACgNAAQgMAAgIgCg");
	this.shape_5.setTransform(206.25,19.25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgSBJIBChCQAFgGAEgHQAEgKAAgHQAAgJgEgJQgDgGgHgJQgFgFgJgEQgIgDgKAAQgJgBgGADQgEACgHAFIgqApIA1AAIAAAKIhGAAIAAhGIAKAAIAAA1IAlglIAIgHIAJgFIAJgDQAGgCAGAAQAGAAAJACQAHADAGADQAIAFADAEQAGAFADAGIAGANQACAGAAAJQAAAKgEAKQgFAJgHAIIhBBCg");
	this.shape_6.setTransform(171.375,19);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag7BQIgUgVIAAiKICfAAIAACfgAAnAVIAAAwIAeAAIAAiJIgUAAIAAA+IhjAAIAAg+IgSAAIAAB7IAPAOIAPAAIAAgwgAgbBFIA3AAIAAgkIg3AAgAgngSIBNAAIAAgyIhNAAg");
	this.shape_7.setTransform(141.95,19);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgWgYIAtAYIgtAZg");
	this.shape_8.setTransform(234.975,15.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgEAeIAAg7IAJAAIAAA7g");
	this.shape_9.setTransform(234.475,22.45);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgsAFIAAgJIBZAAIAAAJg");
	this.shape_10.setTransform(234.475,25.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhKAFIAAgJICVAAIAAAJg");
	this.shape_11.setTransform(234.475,11.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("Ag7AtQgFAAAAgFIAAhPQAAgFAFAAIB3AAQAFAAAAAFIAABPQAAAFgFAAgAg2AjIBtAAIAAhFIhtAAg");
	this.shape_12.setTransform(234.45,15.5);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.shape_11,this.shape_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(134,11,1167,16.3), null);


(lib.ClipGroup_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhjBkIAAjHIDHAAIAADHg");
	mask.setTransform(10,10);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaBgQgMgDgMgHQgMgHgIgIQgIgJgHgMQgIgLgCgNQgEgMAAgOQAAgOAEgMQACgNAIgKQAHgNAIgIQAIgIAMgHQAMgHAMgEQAMgDAOAAQAPAAAMADQAMAEALAHQANAHAHAIQAIAIAIANQAHAKADANQAEAOAAAMQAAANgEANQgDANgHALQgIAMgIAJQgHAIgNAHQgLAHgMADQgOAEgNAAQgNAAgNgEgAgWhSQgMACgIAHQgKAFgIAIQgIAIgGAJQgFAJgEAMQgCAKAAAMQAAAMACALQAEALAFAJQAGAKAIAIQAIAHAKAGQAIAGAMADQAKADAMAAQAMAAAKgDQAMgDAJgGQALgGAGgHQAJgIAFgKQAGgJADgLQADgLAAgMQAAgMgDgKQgDgMgGgJQgFgJgJgIQgGgIgLgFQgJgHgMgCQgKgDgMAAQgMAAgKADg");
	this.shape.setTransform(10,10.05);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_18, new cjs.Rectangle(0,0.1,20,19.9), null);


(lib.ClipGroup_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkXDIIAAmPIIvAAIAAGPg");
	mask.setTransform(28,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkXDIIAAmPIIvAAIAAGPg");
	this.shape.setTransform(28,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_17, new cjs.Rectangle(0,0,56,40), null);


(lib.ClipGroup_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjvDIIAAmPIHfAAIAAGPg");
	mask.setTransform(24,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjvDIIAAmPIHfAAIAAGPg");
	this.shape.setTransform(24,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_16, new cjs.Rectangle(0,0,48,40), null);


(lib.ClipGroup_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjHCnIAAlNIGPAAIAAFNg");
	this.shape.setTransform(20,20.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_15, new cjs.Rectangle(0,3.4,40,33.300000000000004), null);


(lib.ClipGroup_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").p("AgxA3QAAgrAegeQAegfAsAA");
	this.shape.setTransform(5.5,5.5);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_13, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjHCnIAAlNIGPAAIAAFNg");
	this.shape.setTransform(20,20.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_9, new cjs.Rectangle(0,3.4,40,33.300000000000004), null);


(lib.ClipGroup_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AgTBOIAAibIAmAAIAACbg");
	mask.setTransform(1.95,7.825);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSBIQAcgeAAgqQAAgpgcgeIAHgGQAeAgAAAtQAAAugeAgg");
	this.shape.setTransform(1.925,7.825);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_7, new cjs.Rectangle(0,0,3.9,15.7), null);


(lib.ClipGroup_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjHCnIAAlNIGPAAIAAFNg");
	this.shape.setTransform(20,20.025);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_6, new cjs.Rectangle(0,3.4,40,33.300000000000004), null);


(lib.ClipGroup_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjHDIIAAmPIGPAAIAAGPg");
	this.shape.setTransform(20,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_4, new cjs.Rectangle(0,0,40,40), null);


(lib.ClipGroup_2_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AkXDIIAAmPIIvAAIAAGPg");
	mask_1.setTransform(28,20);

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#EBEBEC").s().p("AkXDIIAAmPIIvAAIAAGPg");
	this.shape_1.setTransform(28,20);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_2_1, new cjs.Rectangle(0,0,56,40), null);


(lib.ClipGroup_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkXDIIAAmPIIvAAIAAGPg");
	mask.setTransform(28,20);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AkXDIIAAmPIIvAAIAAGPg");
	this.shape.setTransform(28,20);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_0, new cjs.Rectangle(0,0,56,40), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.thumb_select = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.box.cache(-188,-108,376,216,0.2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.box = new lib.tmb_select();
	this.box.name = "box";
	this.box.parent = this;
	this.box.setTransform(93.3,53.3,1,1,0,0,0,93.3,53.3);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

}).prototype = getMCSymbolPrototype(lib.thumb_select, new cjs.Rectangle(0,0.4,187,107), null);


(lib.selected = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Step 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgPUAl3MAAAhLtIeoAAMAAABLtg");
	mask.setTransform(118.85,367.675);

	// Step 2
	this.instance = new lib.thumbs();
	this.instance.parent = this;
	this.instance.setTransform(83.75,16.85,3.9528,3.9528);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(269));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AFNGGQgRgDgSgHQgkgOgKgWQgdhEgfiPQgsjOAbh4QAdh+DhAPQBVAGBTAZQBOAYAbAZQAsApgdECQgPCBgXB5Ih3BVIhZAug");
	mask_1.setTransform(72.8561,45.5757);

	// Step 1
	this.instance_1 = new lib.thumbs();
	this.instance_1.parent = this;
	this.instance_1.setTransform(83.75,16.85,3.9528,3.9528);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(269));

	// Layer_5
	this.instance_2 = new lib.Step2_ears();
	this.instance_2.parent = this;
	this.instance_2.setTransform(86.45,550.8,0.3143,0.3143);

	this.instance_3 = new lib.thumb_select();
	this.instance_3.parent = this;
	this.instance_3.setTransform(115.1,558.05,1,1,0,0,0,93.4,53.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D1492A").s().p("AgcAxIAAgNQAKAHAMAAQAFAAAEgCIAIgEQADgDACgFQABgEAAgFQAAgKgHgGQgHgFgMAAIgEAAIgFAAIgEABIgEAAIADg0IAwAAIAAAKIglAAIgCAfIAEAAIAFAAQAHAAAHACQAHACAEAEQAFADACAGQACAGAAAHQAAAIgCAGQgDAGgFAFQgEAEgHADQgHACgIAAQgOAAgHgEg");
	this.shape.setTransform(6.175,513.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape},{t:this.instance_3},{t:this.instance_2}]},168).wait(101));

	// Layer_4
	this.instance_4 = new lib.thumb_select();
	this.instance_4.parent = this;
	this.instance_4.setTransform(115.1,433.9,1,1,0,0,0,93.4,53.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1492A").s().p("AAMA0IAAgYIgwAAIAAgLIAOgQIANgRIALgSIAJgRIANAAIAABEIANAAIAAALIgNAAIAAAYgAACgQIgJANIgIAKIgIAKIAjAAIAAgzIgKASg");
	this.shape_1.setTransform(5.875,388.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.instance_4}]},121).to({state:[]},47).to({state:[]},1).wait(100));

	// Layer_3
	this.instance_5 = new lib.thumb_select();
	this.instance_5.parent = this;
	this.instance_5.setTransform(115,308.7,1,1,0,0,0,93.3,53.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#D1492A").s().p("AgdAwIAAgMQAKAIAOAAQAFAAAEgCQAEgBADgDQAEgCABgEQACgEAAgEQAAgVgcAAIgJAAIAAgJIAIAAQAZAAAAgTQAAgSgSAAQgMAAgJAHIAAgLQAKgGAOAAQAFAAAFACQAGABAEAEQADADACAFQADAEAAAGQAAAUgVAGIAAABQAFAAAEABQAFACADADQAEAEABAEQACAEAAAGQAAAHgCAGQgDAFgFAEQgFAFgHACQgGACgHAAQgPAAgJgGg");
	this.shape_2.setTransform(5.975,263.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2},{t:this.instance_5}]},56).to({state:[]},65).to({state:[]},39).wait(109));

	// Layer_2
	this.instance_6 = new lib.thumb_select();
	this.instance_6.parent = this;
	this.instance_6.setTransform(115.4,183.7,1,1,0,0,0,93.3,53.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#D1492A").s().p("AgfA1IAAgFQAAgHABgFQACgFADgEQADgFAGgFIANgKIAJgHIAGgHIADgIIABgIQAAgFgBgDIgEgGQgDgDgEgBQgDgBgDAAIgHABIgHADIgGAEIgFAFIAAgNQAFgFAGgDQAGgCAJAAQAGAAAFACQAGACAEADQAEAEACAFQACAFAAAHQAAAGgBAFIgEAKIgIAHIgKAJIgLAJIgIAHQgDADgBADIgBAIIAzAAIAAAKg");
	this.shape_3.setTransform(6.075,138.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.instance_6}]},20).to({state:[]},36).to({state:[]},72).wait(141));

	// Layer_1
	this.instance_7 = new lib.thumb_select();
	this.instance_7.parent = this;
	this.instance_7.setTransform(115.35,57.9,1,1,0,0,0,93.3,53.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D1492A").s().p("AAGA2IAAhaIgEADIgFAEIgHADIgHACIAAgLIAIgEIAJgDIAHgGIAHgEIAEAAIAABqg");
	this.shape_4.setTransform(5.525,12.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.instance_7}]}).to({state:[]},20).to({state:[]},108).wait(141));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,209.1,612.2);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.phonenew = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.phone.cache(-45,0,270,180,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// screen
	this.instance = new lib.mob_display();
	this.instance.parent = this;
	this.instance.setTransform(2.7,7.35,0.8143,0.8143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// phone
	this.phone = new lib.phonecache();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(22.6,43.9,1,1,0,0,0,67.5,43.9);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

}).prototype = getMCSymbolPrototype(lib.phonenew, new cjs.Rectangle(-44.9,0,134.9,87.7), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2);
		this.ms.gotoAndStop(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_54 = function() {
		exportRoot.tl1.play()
	}
	this.frame_75 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(54).call(this.frame_54).wait(21).call(this.frame_75).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(990.6,77.55,0.3349,0.3349,0,0,0,-40,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regY:1.4,scaleX:5.5415,scaleY:5.5415},13,cjs.Ease.quadOut).to({x:738.4},12,cjs.Ease.quadInOut).to({_off:true},1).wait(49));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EAvdAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_15 = new cjs.Graphics().p("EAvMAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_16 = new cjs.Graphics().p("EAuXAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_17 = new cjs.Graphics().p("EAs/AKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_18 = new cjs.Graphics().p("EArEAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_19 = new cjs.Graphics().p("EAolAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_20 = new cjs.Graphics().p("EAljAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_21 = new cjs.Graphics().p("EAiiAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_22 = new cjs.Graphics().p("EAgDAKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_23 = new cjs.Graphics().p("AeIKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_24 = new cjs.Graphics().p("AcwKzIAAyrMBGaAAAIAASrg");
	var mask_graphics_25 = new cjs.Graphics().p("Ab7KzIAAyrMBGaAAAIAASrg");
	var mask_graphics_26 = new cjs.Graphics().p("AbpKzIAAyrMBGaAAAIAASrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:754.3404,y:69.0584}).wait(1).to({graphics:mask_graphics_15,x:752.5789,y:69.0584}).wait(1).to({graphics:mask_graphics_16,x:747.2945,y:69.0584}).wait(1).to({graphics:mask_graphics_17,x:738.4872,y:69.0584}).wait(1).to({graphics:mask_graphics_18,x:726.157,y:69.0584}).wait(1).to({graphics:mask_graphics_19,x:710.3039,y:69.0584}).wait(1).to({graphics:mask_graphics_20,x:690.9279,y:69.0584}).wait(1).to({graphics:mask_graphics_21,x:671.5518,y:69.0584}).wait(1).to({graphics:mask_graphics_22,x:655.6987,y:69.0584}).wait(1).to({graphics:mask_graphics_23,x:643.3685,y:69.0584}).wait(1).to({graphics:mask_graphics_24,x:634.5612,y:69.0584}).wait(1).to({graphics:mask_graphics_25,x:629.2768,y:69.0584}).wait(1).to({graphics:mask_graphics_26,x:627.5154,y:69.0584}).wait(1).to({graphics:null,x:0,y:0}).wait(49));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.parent = this;
	this.instance_1.setTransform(771.45,70.9,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:960.7},12,cjs.Ease.quadInOut).to({_off:true},25).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_51 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_52 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_53 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_54 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_55 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_56 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_59 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_60 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_61 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_63 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_65 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_66 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_67 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_68 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Ei4jAW3MAAAgttMFxHAAAMAAAAttg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EjHTAW3MAAAgttMFxHAAAMAAAAttg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(51).to({graphics:mask_1_graphics_51,x:993.7026,y:78.6643}).wait(1).to({graphics:mask_1_graphics_52,x:988.3429,y:78.6643}).wait(1).to({graphics:mask_1_graphics_53,x:972.2636,y:78.6643}).wait(1).to({graphics:mask_1_graphics_54,x:945.4649,y:78.6643}).wait(1).to({graphics:mask_1_graphics_55,x:907.9466,y:78.6643}).wait(1).to({graphics:mask_1_graphics_56,x:859.7089,y:78.6643}).wait(1).to({graphics:mask_1_graphics_57,x:800.7516,y:78.6643}).wait(1).to({graphics:mask_1_graphics_58,x:731.0748,y:78.6643}).wait(1).to({graphics:mask_1_graphics_59,x:650.6786,y:78.6643}).wait(1).to({graphics:mask_1_graphics_60,x:559.5628,y:78.6643}).wait(1).to({graphics:mask_1_graphics_61,x:457.7276,y:78.6643}).wait(1).to({graphics:mask_1_graphics_62,x:345.1728,y:78.6643}).wait(1).to({graphics:mask_1_graphics_63,x:221.8985,y:78.6643}).wait(1).to({graphics:mask_1_graphics_64,x:87.9048,y:78.6643}).wait(1).to({graphics:mask_1_graphics_65,x:-56.8085,y:78.6643}).wait(1).to({graphics:mask_1_graphics_66,x:-212.2413,y:78.6643}).wait(1).to({graphics:mask_1_graphics_67,x:-378.3935,y:78.6643}).wait(1).to({graphics:mask_1_graphics_68,x:-555.2653,y:78.6643}).wait(1).to({graphics:mask_1_graphics_69,x:-742.8566,y:78.6643}).wait(1).to({graphics:mask_1_graphics_70,x:-941.1673,y:78.6643}).wait(1).to({graphics:mask_1_graphics_71,x:-1150.1976,y:78.6643}).wait(1).to({graphics:mask_1_graphics_72,x:-1275.55,y:78.6643}).wait(4));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(960.7,70.9,5.5415,5.5415,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).to({_off:true},25).wait(1));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.parent = this;
	this.instance_3.setTransform(993.5,280.45,2.433,0.8553,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({x:-1370.15},21,cjs.Ease.quadIn).to({_off:true},3).wait(1));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(993.5,280.45,2.433,0.8553,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({_off:false},0).to({x:-1370.15},21,cjs.Ease.quadIn).to({_off:true},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2551.1,-67.6,4726,292.6);


(lib.menus = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#545251").s().p("AhGBOIgBgEIACgDIA2g5QgGgGgDgIQgDgIAAgJQgBgGACgHQACgHADgFQAEgHAEgEIAKgIQADgDAIgCQACgBgBgGQgBgFADAAQADAAAJAFIALAGIAMAFQAGADAFAFIAIAKIAFAMIACANQAAAHgBAHQgCAFgDAGQgDAGgFAEIgKAIIgMAGIgNACQgJAAgIgDQgGgCgJgGIg3A5IgDABQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAgAAVg7QgJAAgHAEQgHADgFAGQgFAFgDAIQgDAHAAAJQAAAJADAHQAEAHAFAFQAFAFAIADQAHAEAJgBQAJAAAHgDQAGgDAHgGQAGgHACgFQADgIAAgJQgBgKgDgGQgDgHgGgFQgEgFgJgEQgGgDgGAAIgEAAg");
	this.shape.setTransform(857.225,49.825);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#545251").s().p("AAQAuIAAgkQAAgSgPAAQgGAAgFAFQgFAFAAAJIAAAjIgKAAIAAhbIAKAAIAAAoIAAAAQAIgMAMAAQAVAAAAAZIAAAmg");
	this.shape_1.setTransform(907.15,50.325);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#545251").s().p("AgPAYQgHgJgBgOQAAgOAJgJQAJgKAOAAQAIAAAHADIAAALQgHgFgJAAQgIAAgGAHQgHAGABALQAAALAFAGQAGAGAJAAQAIAAAHgFIAAAJQgHAFgKAAQgMAAgJgJg");
	this.shape_2.setTransform(900.5,51.825);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#545251").s().p("AgPAgIAAg+IAKAAIAAANIAAAAQACgGAEgEQAEgEAFAAIAGABIAAAKQgCgCgFAAQgHAAgDAGQgEAGAAAKIAAAgg");
	this.shape_3.setTransform(895.725,51.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#545251").s().p("AgSAcQgGgFAAgIQAAgRAVgDIASgCQAAgQgNAAQgLAAgJAHIAAgKQAKgGALAAQAWAAAAAYIAAAnIgKAAIAAgKIgBAAQgGAMgMAAQgJAAgFgFgAAAACQgGABgEACQgEADAAAGQAAAEAEADQADADAFAAQAHAAAFgFQAFgFAAgIIAAgGg");
	this.shape_4.setTransform(889.525,51.825);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_5.setTransform(883.025,51.825);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#545251").s().p("AgJAtIgGgBIgGgCIgFgCIAAgMIAGADIAFADIAHABIAGABQAIAAAFgDQAEgEABgHQgBgDgBgDIgEgFIgHgEIgHgEIgIgEQgFgCgCgDIgFgGQgBgEgBgFQABgGACgEQADgFAEgDIAKgEQAFgBAFAAQANAAAGADIAAALQgIgFgMAAIgGABIgGACIgEAEQgCADAAADQAAAEABACIAEAEIAGAEIAHAFIAJADQAEADADADIAGAHQABAEAAAFQAAAGgCAFQgCAEgFADQgEADgGABQgGABgEAAIgGAAg");
	this.shape_6.setTransform(876.2,50.575);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B8543E").s().p("AgVAdIAAgNQAHAGAKAAQAMAAAAgHIgBgEIgDgDIgEgCIgFgCIgHgDIgFgDIgDgFIgBgGQAAgFACgDQACgEAEgCQADgCAFgBQAEgCAFAAQAIAAAHADIAAAMQgGgEgJAAIgEAAIgEACIgCACIgBADIABAEIACACIAEACIAFACIAHADIAFADIAEAFIABAHQAAAFgCADQgCAEgEACIgJAEIgJABQgKAAgHgEg");
	this.shape_7.setTransform(1336.95,51.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B8543E").s().p("AgIAYIAAgjIgLAAIAAgLIALAAIAAgOIANgEIAAASIAPAAIAAALIgPAAIAAAfQAAAFACADQACACAFAAQADAAADgCIAAALQgEACgHAAQgRAAAAgRg");
	this.shape_8.setTransform(1331.675,51.075);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B8543E").s().p("AAOAgIAAgiQgBgSgLAAQgGAAgFAFQgDAFAAAHIAAAjIgPAAIAAg+IAPAAIAAALQAGgMANAAQAKAAAGAHQAFAHAAAMIAAAlg");
	this.shape_9.setTransform(1325.6,51.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#B8543E").s().p("AgTAYQgIgIAAgQQAAgNAJgJQAIgKAMAAQAMAAAHAJQAIAIgBAOIAAAFIgpAAQAAAJAGAEQAFAFAHAAQAKAAAJgGIAAALQgJAGgOAAQgNAAgHgJgAgHgRQgFAFgBAHIAcAAQAAgIgEgEQgDgEgGAAQgGAAgDAEg");
	this.shape_10.setTransform(1318.35,51.925);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B8543E").s().p("AAhAgIAAghQAAgKgDgEQgDgFgGAAQgGAAgEAGQgEAFAAAIIAAAhIgNAAIAAgiQAAgSgMAAQgGABgEAFQgDAFAAAIIAAAhIgPAAIAAg+IAPAAIAAAKQAHgLANAAQAGAAAFADQAEAEACAGQAGgNAOAAQAVAAAAAaIAAAlg");
	this.shape_11.setTransform(1309.275,51.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B8543E").s().p("AAhAgIAAghQAAgKgDgEQgDgFgGAAQgGAAgEAGQgEAFAAAIIAAAhIgNAAIAAgiQAAgSgMAAQgGABgEAFQgDAFAAAIIAAAhIgPAAIAAg+IAPAAIAAAKQAHgLANAAQAGAAAFADQAEAEACAGQAGgNAOAAQAVAAAAAaIAAAlg");
	this.shape_12.setTransform(1297.975,51.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B8543E").s().p("AgWAYQgJgJAAgOQAAgPAJgJQAJgJAOAAQAPAAAIAJQAIAIAAAPQAAAPgJAJQgIAJgPAAQgOAAgIgJgAgMgPQgFAGAAAJQAAAKAFAGQAFAFAHAAQAJAAAEgFQAFgGAAgKQAAgJgFgGQgEgFgJAAQgHAAgFAFg");
	this.shape_13.setTransform(1288.425,51.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B8543E").s().p("AgVAhQgMgMAAgTQABgUANgNQANgNASAAQANAAAJADIAAAPQgJgFgLAAQgOAAgIAJQgJAJAAAOQAAAOAIAJQAJAJAMAAQAMAAAKgGIAAANQgKAFgPAAQgTAAgLgMg");
	this.shape_14.setTransform(1280.55,50.675);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#B8543E").s().p("AggAbIgWAAIAAhPIBtAAIAABPIg+AAIgZAagAgvAUIAVAAIAAAQIAQgQIA7AAIAAhAIhgAAg");
	this.shape_15.setTransform(1266.2,49.9);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#EDEAE8").s().p("AnTB4QgIAAgGgGQgGgGAAgIIAAjHQAAgJAGgFQAGgGAIAAIOnAAQAIAAAGAGQAGAFAAAJIAADHQAAAIgGAGQgGAGgIAAgAndhjIAADHQAAAEADADQADADAEAAIOnAAQAEAAADgDQADgDAAgEIAAjHQAAgKgKAAIunAAQgKAAAAAKg");
	this.shape_16.setTransform(1301.2,49.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AnTB4QgIAAgGgGQgGgGAAgIIAAjHQAAgJAGgFQAGgGAIAAIOnAAQAIAAAGAGQAGAFAAAJIAADHQAAAIgGAGQgGAGgIAAg");
	this.shape_17.setTransform(1301.2,49.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B8543E").s().p("AgTAYQgJgIABgQQgBgNAKgJQAIgKAMAAQANAAAGAJQAIAIgBAOIAAAFIgpAAQABAJAEAEQAGAFAIAAQAJAAAJgGIAAALQgJAGgOAAQgNAAgHgJgAgIgRQgEAFgBAHIAcAAQAAgIgEgEQgDgEgHAAQgFAAgEAEg");
	this.shape_18.setTransform(1231.25,51.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B8543E").s().p("AgRAgIAAg+IAOAAIAAANQACgGAEgEQAEgEAFAAIAGABIAAAOQgCgCgFAAQgGAAgFAFQgDAGAAAJIAAAeg");
	this.shape_19.setTransform(1225.725,51.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B8543E").s().p("AgUAcQgFgFAAgJQAAgQAUgDIASgDQAAgNgNAAQgKAAgJAIIAAgNQAKgGAMAAQAXAAAAAYIAAAnIgNAAIAAgKIgBAAQgGAMgMAAQgJAAgFgFgAAAACQgFABgEACQgDADAAAFQAAAEADACQADADAFAAQAFAAAFgFQAEgEAAgHIAAgFg");
	this.shape_20.setTransform(1219.325,51.875);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B8543E").s().p("AANAuIAAgiQAAgRgMAAQgFAAgFAFQgEAEAAAJIAAAhIgOAAIAAhbIAOAAIAAAoQAIgMAMAAQAVAAAAAZIAAAmg");
	this.shape_21.setTransform(1212.4,50.375);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B8543E").s().p("AgJAtIgHgBIgGgCIgFgCIAAgPIAFAEIAGACIAGACIAGAAQAIAAAEgDQAFgDAAgGQAAgDgCgCIgEgEIgGgEIgHgEIgIgEIgHgFQgDgDgBgDQgCgEAAgFQAAgGADgFQADgEAEgDQAFgDAFgCIALgBQAOAAAGADIAAAOQgHgFgMAAIgFAAIgGACIgEAEQgCACAAADIABAFIAEAEIAGAEIAHADIAIAFIAHAFIAFAHQACAEAAAFQAAAHgDAEQgCAFgFADQgEADgGABQgGABgGAAIgFAAg");
	this.shape_22.setTransform(1205.125,50.625);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B8543E").s().p("AAGAUIgPABIgOAFIgNAHQgIAFgEAFIAAgIQAAgIACgGIAFgOIAJgKIALgIQAHgEAGgCQAGgCAIAAIAAgXIArAqIgrArgAgFgKIgHADIgJAFIgJAHIgGAKIgDALQAIgGAOgFQALgDAMAAIAIAAIAAAMIAYgYIgYgXIAAAMIgOAAg");
	this.shape_23.setTransform(1192.275,47.425);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#B8543E").s().p("AgyAoIAAhPIAGAAIAABIIBZAAIAAgoIAFAAIAAAvg");
	this.shape_24.setTransform(1190.35,51.875);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#EDEAE8").s().p("Ak7B4QgIAAgGgGQgGgFAAgJIAAjHQAAgIAGgGQAGgGAIAAIJ3AAQAIAAAGAGQAGAGAAAIIAADHQAAAJgGAFQgGAGgIAAgAlChqQgDADAAAEIAADHQAAAEADADQADADAEAAIJ3AAQAEAAADgDQADgDAAgEIAAjHQAAgEgDgDQgDgDgEAAIp3AAQgEAAgDADg");
	this.shape_25.setTransform(1210.775,49.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Ak7B4QgIAAgGgGQgGgFAAgJIAAjHQAAgIAGgGQAGgGAIAAIJ3AAQAIAAAGAGQAGAGAAAIIAADHQAAAJgGAFQgGAGgIAAg");
	this.shape_26.setTransform(1210.775,49.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#545251").s().p("AgcAuIAAhZIALAAIAAALQAHgNANAAQAMAAAHAIQAGAJABAOQAAAOgIAKQgHAJgNAAQgMAAgGgLIAAAmgAgNgeQgEAFAAAKIAAAIQAAAHAEAFQAFAFAIABQAIgBAFgGQAFgGABgMQgBgLgFgFQgEgGgIgBQgIABgGAGg");
	this.shape_27.setTransform(817.75,53.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#545251").s().p("AgEAuIAAhbIAJAAIAABbg");
	this.shape_28.setTransform(812.4,50.25);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#545251").s().p("AgSAYQgIgJAAgPQAAgNAIgJQAIgKALABQAMgBAHAJQAHAHAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAIgHIAAAJQgHAHgOgBQgMAAgHgIgAgJgSQgGAFgBAIIAhAAQAAgIgFgGQgEgEgHAAQgGAAgEAFg");
	this.shape_29.setTransform(807.7,51.75);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#545251").s().p("AAXArIAAgnIgsAAIAAAnIgKAAIAAhVIAKAAIAAAmIAsAAIAAgmIAKAAIAABVg");
	this.shape_30.setTransform(800,50.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#545251").s().p("AgTAdIAAgLQAHAGAKAAQAMAAAAgJIgBgEIgDgDIgFgCIgEgCIgHgEIgGgDIgCgEIgBgGQAAgFACgDIAEgGIAIgEIAIAAQAIAAAHACIAAAKQgIgEgIAAIgEABIgEABIgCADIgBAEIABADIACAEIAEACIAEACIAIADIAGADQACACABADQACADgBADQAAAFgBAEQgDADgDACQgEACgEABIgIABQgKAAgGgDg");
	this.shape_31.setTransform(765.85,51.75);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgPAAQgGAAgFAFQgFAGAAAIIAAAjIgKAAIAAg9IAKAAIAAAKQAHgMANAAQAKAAAFAHQAGAGAAANIAAAlg");
	this.shape_32.setTransform(759.725,51.675);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#545251").s().p("AgEAtIAAg9IAJAAIAAA9gAgDghQgBgBAAAAQgBgBAAAAQAAgBAAgBQAAAAAAgBQAAgDACgCQAAAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQADAAACABQACACgBADQAAABAAAAQAAABAAABQAAAAAAABQgBAAAAABQgCACgDAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_33.setTransform(754.65,50.325);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#545251").s().p("AgQAEIAAgHIAhAAIAAAHg");
	this.shape_34.setTransform(750.725,51.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#545251").s().p("AgUAmQgIgIABgOQAAgQAHgIQAIgJAMAAQANAAAFAKIAAgnIAKAAIAABbIgKAAIAAgKQgGAMgOAAQgMAAgGgJgAgMgCQgGAFAAAMQAAALAGAGQAEAGAIAAQAIAAAGgGQAEgGAAgJIAAgJQAAgHgEgFQgGgFgHAAQgIAAgFAHg");
	this.shape_35.setTransform(744.35,50.325);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#545251").s().p("AgUAmQgIgIABgOQAAgQAHgIQAIgJAMAAQANAAAFAKIAAgnIAKAAIAABbIgKAAIAAgKQgHAMgNAAQgMAAgGgJgAgNgCQgEAFAAAMQAAALAEAGQAGAGAHAAQAIAAAFgGQAGgGgBgJIAAgJQABgHgGgFQgFgFgHAAQgIAAgGAHg");
	this.shape_36.setTransform(737.05,50.325);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#545251").s().p("AAbArIgJgYIgkAAIgJAYIgKAAIAhhVIAJAAIAhBVgAgBgaIgOAkIAeAAIgOgkIgBgGIAAAAIgBAGg");
	this.shape_37.setTransform(729.6,50.5);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#545251").s().p("AAPAfIgNgsIgBgFIgBAFIgOAsIgKAAIgSg9IAKAAIANAtIABAGIAAAAIABgGIAPgtIAIAAIANAtIAAAHIABAAIABgHIANgtIAJAAIgSA9g");
	this.shape_38.setTransform(692.175,51.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#545251").s().p("AgSAYQgIgJAAgPQAAgNAIgJQAIgKALABQAMgBAHAJQAHAHAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAJQgIAHgOgBQgMAAgHgIgAgJgSQgFAFgCAIIAhAAQAAgIgFgGQgEgEgHAAQgGAAgEAFg");
	this.shape_39.setTransform(684.5,51.75);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#545251").s().p("AgEAtIAAg9IAJAAIAAA9gAgEghQAAgBAAAAQgBgBAAAAQAAgBAAgBQgBAAAAgBQAAgDACgCQABAAABAAQAAgBABAAQAAAAABAAQAAAAAAAAQADAAACABQABACAAADQAAABAAAAQAAABAAABQAAAAAAABQgBAAAAABQgCACgDAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBgBAAg");
	this.shape_40.setTransform(679.7,50.325);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#545251").s().p("AgFArIgghVIAMAAIAYBDIABAIIAAAAIACgIIAYhDIALAAIgfBVg");
	this.shape_41.setTransform(674.35,50.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_42.setTransform(105.825,51.725);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#545251").s().p("AAiAgIAAgjQAAgKgDgFQgDgFgHABQgHAAgEAFQgFAGAAAIIAAAjIgJAAIAAgkQAAgSgOAAQgHgBgEAGQgFAFABAJIAAAjIgKAAIAAg+IAKAAIAAAKIAAAAQAHgLANAAQAFAAAFADQAEAEACAGQAHgNANAAQAWAAAAAaIAAAlg");
	this.shape_43.setTransform(96.85,51.65);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#545251").s().p("AgWAYQgIgJAAgOQAAgPAJgJQAIgJAOAAQAOAAAIAJQAIAIAAAPQAAAPgJAJQgIAJgOAAQgNAAgJgJgAgOgRQgGAHAAAKQAAALAGAHQAGAGAIAAQAKAAAFgGQAFgGAAgMQAAgLgFgGQgFgGgKAAQgIAAgGAGg");
	this.shape_44.setTransform(87.425,51.725);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#545251").s().p("AAXAsIAAgoIgtAAIAAAoIgKAAIAAhXIAKAAIAAAnIAtAAIAAgnIAKAAIAABXg");
	this.shape_45.setTransform(79,50.475);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#545251").s().p("AAPAfIgNgrIgBgGIgBAAIAAAFIgOAsIgKAAIgTg9IALAAIANAuIABAFIABgFIAOguIAJAAIANAuIABAFIABgFIANguIAKAAIgTA9g");
	this.shape_46.setTransform(223.625,51.725);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#545251").s().p("AgSAcQgGgFAAgIQAAgRAVgDIASgCQAAgQgNAAQgLAAgJAHIAAgKQAKgGALAAQAWAAAAAYIAAAnIgKAAIAAgKIgBAAQgGAMgMAAQgJAAgFgFgAAAACQgGABgEACQgEADAAAGQAAAEAEADQADADAFAAQAHAAAFgFQAFgFAAgIIAAgGg");
	this.shape_47.setTransform(215.475,51.725);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#545251").s().p("AgPAgIAAg+IAKAAIAAANIAAAAQACgGAEgEQAEgEAFAAIAGABIAAAKQgCgCgFAAQgHAAgDAGQgEAGAAAKIAAAgg");
	this.shape_48.setTransform(210.425,51.675);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#545251").s().p("AgiAsIAAhXIAYAAQAtAAAAArQAAATgNAMQgNANgUAAgAgYAiIANAAQAQAAAKgJQAJgJAAgQQAAghgiAAIgOAAg");
	this.shape_49.setTransform(203.425,50.475);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#545251").s().p("AgGAXIAAgkIgLAAIAAgJIALAAIAAgPIAJgDIAAASIAPAAIAAAJIgPAAIAAAiQAAAGACADQACADAFAAQAEAAACgCIAAAIQgDACgGAAQgPAAAAgSg");
	this.shape_50.setTransform(168.125,50.875);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#545251").s().p("AgPAgIAAg+IAKAAIAAANIAAAAQACgGAEgEQAEgEAFAAIAGABIAAAKQgCgCgFAAQgHAAgDAGQgEAGAAAKIAAAgg");
	this.shape_51.setTransform(163.825,51.675);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_52.setTransform(157.825,51.725);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#545251").s().p("AgUAdIAAgLQAIAGAKAAQAMAAAAgIIgBgFIgDgDIgEgCIgFgCIgHgEIgGgDIgDgEIgBgHQAAgEACgDQACgEAEgCIAHgEIAIgBQAIAAAHADIAAAKQgHgEgJAAIgEAAIgEACIgDADIgBADIABAFIADADIAEACIAFACIAHADIAGADIADAFQACADAAAEQAAAEgCAEIgGAFQgDADgFABIgIABQgKAAgHgEg");
	this.shape_53.setTransform(151.775,51.725);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgOAAQgHgBgFAGQgFAFAAAJIAAAjIgKAAIAAg+IAKAAIAAALIABAAQAGgMANAAQAKAAAGAHQAFAGAAANIAAAlg");
	this.shape_54.setTransform(145.45,51.65);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#545251").s().p("AgEAsIAAhXIAJAAIAABXg");
	this.shape_55.setTransform(140,50.475);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_56.setTransform(37.075,51.725);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#545251").s().p("AgEAuIAAhbIAJAAIAABbg");
	this.shape_57.setTransform(31.85,50.225);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#545251").s().p("AgEAuIAAg+IAJAAIAAA+gAgEghQgCgCAAgDQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABABAAQAAABAAAAQABABAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAABgBAAQAAABAAAAQgBABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_58.setTransform(28.5,50.275);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#545251").s().p("AgVAsIAAhXIArAAIAAAKIghAAIAAAeIAfAAIAAAIIgfAAIAAAng");
	this.shape_59.setTransform(23.875,50.475);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#545251").s().p("AAPAfIgNgrIgBgGIgBAAIAAAFIgOAsIgKAAIgTg9IALAAIANAuIABAFIABgFIAOguIAJAAIANAuIABAFIABgFIANguIAKAAIgTA9g");
	this.shape_60.setTransform(637.075,51.725);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_61.setTransform(629.075,51.725);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#545251").s().p("AgFAuIAAg+IAJAAIAAA+gAgEghQgBgCgBgDQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAAAQABABAAAAQABABAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_62.setTransform(624,50.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#545251").s().p("AgFAfIgXg9IALAAIAPAsIACAJIACgJIAQgsIALAAIgZA9g");
	this.shape_63.setTransform(619.225,51.725);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_64.setTransform(612.725,51.725);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#545251").s().p("AATAsIgOgZIgEgGIgDgEIgEgCIgGAAIgIAAIAAAlIgKAAIAAhXIAaAAQAFAAAEACQAFABAEADQADADACAEQACAFAAAGIgBAIIgEAHIgGAEIgIADIAEADIADADIADADIADAFIAQAbgAgUgCIAOAAIAGgBIAGgDQACgCABgEQACgDAAgEQAAgHgFgEQgEgDgIAAIgOAAg");
	this.shape_65.setTransform(606.275,50.475);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#545251").s().p("AAPAfIgNgrIgBgGIgBAAIAAAFIgOAsIgKAAIgTg9IALAAIANAuIABAFIABgFIAOguIAJAAIANAuIABAFIABgFIANguIAKAAIgTA9g");
	this.shape_66.setTransform(568.675,51.725);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#545251").s().p("AgWAYQgIgJAAgOQAAgPAJgJQAIgJAOAAQAOAAAIAJQAIAIAAAPQAAAPgJAJQgIAJgOAAQgNAAgJgJgAgOgRQgGAHAAAKQAAALAGAHQAGAGAIAAQAKAAAFgGQAFgGAAgMQAAgLgFgGQgFgGgKAAQgIAAgGAGg");
	this.shape_67.setTransform(560.275,51.725);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#545251").s().p("AAQAuIAAgkQAAgSgPAAQgGAAgFAFQgFAFAAAJIAAAjIgKAAIAAhbIAKAAIAAAoIAAAAQAIgMAMAAQAVAAAAAZIAAAmg");
	this.shape_68.setTransform(552.9,50.225);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#545251").s().p("AgJAtIgGgBIgGgCIgFgCIAAgMIAGADIAFADIAHABIAGABQAIAAAFgDQAFgEAAgHQAAgDgCgDIgEgFIgHgEIgHgEIgJgEQgEgCgCgDIgFgGQgBgEgBgFQABgGACgEQADgFAEgDIAKgEQAFgBAFAAQANAAAGADIAAALQgIgFgMAAIgGABIgGACIgEAEQgCADAAADQAAAEABACIAEAEIAGAEIAHAFIAJADQAEADADADIAGAHQACAEAAAFQgBAGgCAFQgCAEgFADQgEADgGABQgFABgGAAIgFAAg");
	this.shape_69.setTransform(545.8,50.475);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_70.setTransform(535.275,51.725);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#545251").s().p("AgVAnQgHgJAAgPQAAgPAIgIQAIgKAMAAQANABAFAJIABAAIAAgmIAKAAIAABbIgKAAIAAgKIgBAAQgGAMgOAAQgMAAgHgIgAgMgCQgGAGAAALQAAALAFAGQAFAGAIABQAIgBAGgGQAFgGAAgJIAAgJQAAgHgFgFQgFgFgIAAQgIAAgFAHg");
	this.shape_71.setTransform(527.825,50.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#545251").s().p("AgEAuIAAg+IAJAAIAAA+gAgEghQgCgCAAgDQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABABAAQAAABAAAAQABABAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAABgBAAQAAABAAAAQgBABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_72.setTransform(522.6,50.275);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#545251").s().p("AgEAuIAAhbIAJAAIAABbg");
	this.shape_73.setTransform(519.25,50.225);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#545251").s().p("AgJAtIgGgBIgGgCIgFgCIAAgMIAFADIAHADIAGABIAGABQAIAAAFgDQAEgEAAgHQABgDgCgDIgEgFIgGgEIgIgEIgIgEQgEgCgDgDIgFgGQgCgEAAgFQAAgGADgEQADgFAEgDIAKgEQAFgBAFAAQANAAAGADIAAALQgIgFgMAAIgGABIgGACIgEAEQgCADAAADQAAAEACACIADAEIAGAEIAHAFIAJADQAFADADADIAEAHQACAEAAAFQAAAGgCAFQgDAEgEADQgEADgGABQgGABgEAAIgGAAg");
	this.shape_74.setTransform(514.25,50.475);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgOAAQgHgBgFAGQgFAFAAAJIAAAjIgKAAIAAg+IAKAAIAAALIABAAQAGgMANAAQAKAAAGAHQAFAGAAANIAAAlg");
	this.shape_75.setTransform(292.05,51.65);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#545251").s().p("AgXAqIAAgKQAKAGAKAAQAWAAAAgYIAAgHIgBAAQgHAMgNAAQgMAAgHgJQgHgIAAgNQAAgQAIgJQAHgKANAAQAMAAAGAKIABAAIAAgIIAKAAIAAA4QAAAjggAAQgMAAgIgFgAgMgfQgGAHAAAMQAAALAFAFQAFAGAIAAQAIAAAFgGQAGgFAAgJIAAgJQAAgIgFgFQgFgFgIAAQgIAAgFAGg");
	this.shape_76.setTransform(284.325,53.125);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#545251").s().p("AgFAuIAAg+IAJAAIAAA+gAgEghQgCgCABgDQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAAAQABABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_77.setTransform(279.1,50.275);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#545251").s().p("AgUAdIAAgLQAIAGAKAAQAMAAAAgIIgBgFIgDgDIgEgCIgFgCIgHgEIgGgDIgDgEIgBgHQAAgEACgDQACgEAEgCIAHgEIAIgBQAIAAAHADIAAAKQgHgEgJAAIgEAAIgEACIgDADIgBADIABAFIADADIAEACIAFACIAHADIAGADIADAFQACADAAAEQAAAEgCAEIgGAFQgDADgFABIgIABQgKAAgHgEg");
	this.shape_78.setTransform(274.725,51.725);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#545251").s().p("AgTAYQgHgIAAgQQAAgNAIgJQAIgKALAAQANAAAGAIQAHAIAAAOIAAAFIgrAAQAAAKAGAGQAFAFAIAAQALAAAJgHIAAAKQgIAGgOAAQgMAAgIgJgAgKgSQgFAFgBAIIAhAAQAAgJgEgEQgEgFgIAAQgGAAgFAFg");
	this.shape_79.setTransform(268.525,51.725);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#545251").s().p("AgiAsIAAhXIAYAAQAtAAAAArQAAATgNAMQgNANgUAAgAgYAiIANAAQAQAAAKgJQAJgJAAgQQAAghgiAAIgOAAg");
	this.shape_80.setTransform(260.875,50.475);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#545251").s().p("AgUAdIAAgLQAIAGAKAAQAMAAAAgIIgBgFIgDgDIgEgCIgFgCIgHgEIgGgDIgDgEIgBgHQAAgEACgDQACgEAEgCIAHgEIAIgBQAIAAAHADIAAAKQgHgEgJAAIgEAAIgEACIgDADIgBADIABAFIADADIAEACIAFACIAHADIAGADIADAFQACADAAAEQAAAEgCAEIgGAFQgDADgFABIgIABQgKAAgHgEg");
	this.shape_81.setTransform(382.875,51.725);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgPAAQgGgBgFAGQgFAFAAAJIAAAjIgKAAIAAg+IAKAAIAAALIABAAQAGgMANAAQAKAAAGAHQAFAGAAANIAAAlg");
	this.shape_82.setTransform(376.45,51.65);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#545251").s().p("AgWAYQgIgJAAgOQAAgPAJgJQAIgJAOAAQAOAAAIAJQAIAIAAAPQAAAPgJAJQgIAJgOAAQgNAAgJgJgAgOgRQgGAHAAAKQAAALAGAHQAGAGAIAAQAKAAAFgGQAFgGAAgMQAAgLgFgGQgFgGgKAAQgIAAgGAGg");
	this.shape_83.setTransform(368.975,51.725);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#545251").s().p("AgFAuIAAg+IAJAAIAAA+gAgEghQgBgCgBgDQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAAAQABABAAAAQABABAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_84.setTransform(363.55,50.275);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#545251").s().p("AgGAXIAAgkIgLAAIAAgJIALAAIAAgPIAJgDIAAASIAPAAIAAAJIgPAAIAAAiQAAAGACADQACADAFAAQAEAAACgCIAAAIQgDACgGAAQgPAAAAgSg");
	this.shape_85.setTransform(359.575,50.875);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#545251").s().p("AgEAuIAAg+IAJAAIAAA+gAgEghQgBgCAAgDQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABABAAQAAABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABAAAAQgBABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_86.setTransform(355.75,50.275);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#545251").s().p("AgUAdIAAgLQAIAGAKAAQAMAAAAgIIgBgFIgDgDIgEgCIgFgCIgHgEIgGgDIgDgEIgBgHQAAgEACgDQACgEAEgCIAHgEIAIgBQAIAAAHADIAAAKQgHgEgJAAIgEAAIgEACIgDADIgBADIABAFIADADIAEACIAFACIAHADIAGADIADAFQACADAAAEQAAAEgCAEIgGAFQgDADgFABIgIABQgKAAgHgEg");
	this.shape_87.setTransform(351.375,51.725);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgPAAQgGgBgFAGQgFAFAAAJIAAAjIgKAAIAAg+IAKAAIAAALIABAAQAGgMANAAQAKAAAGAHQAFAGAAANIAAAlg");
	this.shape_88.setTransform(344.95,51.65);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#545251").s().p("AgSAcQgGgFAAgIQAAgRAVgDIASgCQAAgQgNAAQgLAAgJAHIAAgKQAKgGALAAQAWAAAAAYIAAAnIgKAAIAAgKIgBAAQgGAMgMAAQgJAAgFgFgAAAACQgGABgEACQgEADAAAGQAAAEAEADQADADAFAAQAHAAAFgFQAFgFAAgIIAAgGg");
	this.shape_89.setTransform(337.775,51.725);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#545251").s().p("AgPAgIAAg+IAKAAIAAANIAAAAQACgGAEgEQAEgEAFAAIAGABIAAAKQgCgCgFAAQgHAAgDAGQgEAGAAAKIAAAgg");
	this.shape_90.setTransform(332.775,51.675);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#545251").s().p("AgEAsIAAhNIgZAAIAAgKIA7AAIAAAKIgZAAIAABNg");
	this.shape_91.setTransform(327.725,50.475);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#545251").s().p("AgUAdIAAgLQAIAGAKAAQAMAAAAgIIgBgFIgDgDIgEgCIgFgCIgHgEIgGgDIgDgEIgBgHQAAgEACgDQACgEAEgCIAHgEIAIgBQAIAAAHADIAAAKQgHgEgJAAIgEAAIgEACIgDADIgBADIABAFIADADIAEACIAFACIAHADIAGADIADAFQACADAAAEQAAAEgCAEIgGAFQgDADgFABIgIABQgKAAgHgEg");
	this.shape_92.setTransform(477.725,51.725);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgPAAQgGgBgFAGQgFAFAAAJIAAAjIgKAAIAAg+IAKAAIAAALIAAAAQAIgMAMAAQAKAAAFAHQAGAGAAANIAAAlg");
	this.shape_93.setTransform(471.3,51.65);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#545251").s().p("AgWAYQgIgJAAgOQAAgPAJgJQAIgJAOAAQAOAAAIAJQAIAIAAAPQAAAPgJAJQgIAJgOAAQgNAAgJgJgAgOgRQgGAHAAAKQAAALAGAHQAGAGAIAAQAKAAAFgGQAFgGAAgMQAAgLgFgGQgFgGgKAAQgIAAgGAGg");
	this.shape_94.setTransform(463.825,51.725);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#545251").s().p("AgFAuIAAg+IAJAAIAAA+gAgEghQgBgCgBgDQAAgBABAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAAAQABABAAAAQABABAAAAQAAABAAABQABAAAAABQAAAAgBABQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_95.setTransform(458.4,50.275);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#545251").s().p("AgGAXIAAgkIgLAAIAAgJIALAAIAAgPIAJgDIAAASIAPAAIAAAJIgPAAIAAAiQAAAGACADQACADAFAAQAEAAACgCIAAAIQgDACgGAAQgPAAAAgSg");
	this.shape_96.setTransform(454.425,50.875);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#545251").s().p("AgSAcQgGgFAAgIQAAgRAVgDIASgCQAAgQgNAAQgLAAgJAHIAAgKQAKgGALAAQAWAAAAAYIAAAnIgKAAIAAgKIgBAAQgGAMgMAAQgJAAgFgFgAAAACQgGABgEACQgEADAAAGQAAAEAEADQADADAFAAQAHAAAFgFQAFgFAAgIIAAgGg");
	this.shape_97.setTransform(448.775,51.725);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#545251").s().p("AAiAgIAAgjQAAgKgDgFQgDgFgHABQgHAAgEAFQgFAGAAAIIAAAjIgJAAIAAgkQAAgSgOAAQgHgBgEAGQgFAFABAJIAAAjIgKAAIAAg+IAKAAIAAAKIAAAAQAHgLANAAQAFAAAFADQAEAEACAGQAHgNANAAQAWAAAAAaIAAAlg");
	this.shape_98.setTransform(440.2,51.65);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#545251").s().p("AgFAuIAAg+IAJAAIAAA+gAgEghQgCgCABgDQAAgBAAAAQAAgBAAgBQAAAAAAgBQABAAAAgBQACgCACAAQABAAAAAAQABABAAAAQABAAAAAAQABABAAAAQABABAAAAQABABAAAAQAAABAAABQAAAAAAABQAAAAAAABQAAABAAAAQAAABgBAAQAAABgBAAQAAABgBAAQAAAAgBABQAAAAgBAAQAAAAgBAAQgCAAgCgBg");
	this.shape_99.setTransform(433,50.275);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#545251").s().p("AAQAgIAAgjQAAgTgPAAQgGgBgFAGQgFAFAAAJIAAAjIgKAAIAAg+IAKAAIAAALIABAAQAGgMANAAQAKAAAGAHQAFAGAAANIAAAlg");
	this.shape_100.setTransform(427.75,51.65);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#545251").s().p("AAcAsIgKgZIgkAAIgIAZIgMAAIAihXIAJAAIAiBXgAgBgaIgNAkIAdAAIgOgkIgBgGIgBAGg");
	this.shape_101.setTransform(419.875,50.475);

	this.instance = new lib.Group_3();
	this.instance.parent = this;
	this.instance.setTransform(683,51.5,1,1,0,0,0,683,17.5);
	this.instance.shadow = new cjs.Shadow("rgba(45,45,45,0.098)",0,1,6);

	this.instance_1 = new lib.ClipGroup();
	this.instance_1.parent = this;
	this.instance_1.setTransform(683,17,1,1,0,0,0,683,17);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgSAXQgHgIAAgPQAAgNAIgJQAIgIALgBQALAAAHAIQAGAIAAANIAAAEIgpAAQAAALAFAFQAFAGAIgBQALAAAIgGIAAAJQgIAFgNAAQgMABgHgJgAgJgRQgFAFgBAHIAfAAQAAgIgEgEQgEgGgHAAQgFAAgFAGg");
	this.shape_102.setTransform(1168.775,18.2);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgGAWIAAgjIgKAAIAAgIIAKAAIAAgOIAIgEIAAASIAQAAIAAAIIgQAAIAAAhQAAAGACADQACACAFAAQAEAAADgCIAAAJQgEACgFAAQgPAAAAgSg");
	this.shape_103.setTransform(1163.55,17.375);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgPAfIAAg7IAKAAIAAAMQACgHAEgDQAEgEAFABIAGABIAAAJQgDgCgEABQgHgBgDAGQgEAGAAAJIAAAfg");
	this.shape_104.setTransform(1159.925,18.15);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgRAbQgGgFAAgIQABgQATgDIARgCQAAgQgNAAQgJABgJAHIAAgKQAJgFAKgBQAWABAAAWIAAAmIgKAAIAAgKQgHAMgLgBQgIAAgFgEgAAAACQgGABgDACQgEADAAAFQAAAFAEACQACADAGAAQAGAAAFgEQAEgGAAgIIAAgFg");
	this.shape_105.setTransform(1154.2,18.2);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgYAFIAAgjIAKAAIAAAiQAAATAOAAQAGAAAFgGQAEgFAAgIIAAgiIAKAAIAAA7IgKAAIAAgJQgGALgLAAQgWAAAAgag");
	this.shape_106.setTransform(1147.825,18.275);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AghAqIAAhTIAXAAQAsAAAAApQAAASgMAMQgNAMgTAAgAgXAhIANAAQAPAAAJgJQAKgJAAgPQAAgggiAAIgNAAg");
	this.shape_107.setTransform(1140.575,17);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgRAbQgGgFABgIQgBgQAUgDIARgCQAAgQgMAAQgKABgJAHIAAgKQAJgFALgBQAUABAAAWIAAAmIgJAAIAAgKQgHAMgLgBQgJAAgEgEgAAAACQgGABgEACQgDADAAAFQAAAFADACQAEADAEAAQAHAAAFgEQAEgGAAgIIAAgFg");
	this.shape_108.setTransform(1129.6,18.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgEAtIAAhYIAJAAIAABYg");
	this.shape_109.setTransform(1125.25,16.75);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgSAXQgHgIAAgPQAAgNAIgJQAIgIALgBQALAAAHAIQAGAIAAANIAAAEIgpAAQAAALAFAFQAFAGAIgBQALAAAIgGIAAAJQgIAFgNAAQgMABgHgJgAgJgRQgFAFgBAHIAfAAQAAgIgEgEQgEgGgHAAQgFAAgFAGg");
	this.shape_110.setTransform(1120.725,18.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgEAsIAAg7IAJAAIAAA7gAgDggQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQABAAAAABQABAAAAABQAAAAABABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAABQAAAAgBABQAAAAgBABQAAAAgBAAQAAAAgBABQgBAAAAAAQAAAAAAAAQgBgBAAAAQgBAAAAAAQgBgBAAAAg");
	this.shape_111.setTransform(1116.125,16.825);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AAPAfIAAghQAAgUgOAAQgGAAgFAGQgEAFAAAJIAAAhIgKAAIAAg7IAKAAIAAAKQAHgMAMAAQAKAAAFAHQAFAGAAAMIAAAkg");
	this.shape_112.setTransform(1111.3,18.125);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("AgSAbQgEgFAAgIQAAgQATgDIARgCQAAgQgMAAQgKABgJAHIAAgKQAJgFALgBQAUABAAAWIAAAmIgJAAIAAgKQgGAMgLgBQgJAAgGgEgAAAACQgGABgEACQgDADAAAFQAAAFADACQADADAFAAQAHAAAEgEQAFgGAAgIIAAgFg");
	this.shape_113.setTransform(1104.65,18.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("AghAqIAAhTIAXAAQAsAAAAApQAAASgMAMQgNAMgTAAgAgXAhIANAAQAPAAAJgJQAKgJAAgPQAAgggiAAIgNAAg");
	this.shape_114.setTransform(1097.825,17);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("AgGAWIAAgjIgKAAIAAgIIAKAAIAAgOIAIgEIAAASIAQAAIAAAIIgQAAIAAAhQAAAGACADQADACAEAAQAEAAADgCIAAAJQgEACgFAAQgPAAAAgSg");
	this.shape_115.setTransform(858.35,18.225);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("AAPAfIAAghQAAgUgOAAQgGAAgFAGQgEAFAAAJIAAAhIgKAAIAAg7IAKAAIAAAKQAHgMAMAAQAKAAAFAHQAFAGAAAMIAAAkg");
	this.shape_116.setTransform(853,18.975);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("AgEAsIAAg7IAJAAIAAA7gAgDggQgBgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQABgBAAAAQAAgBABAAQAAgBABAAQAAAAAAAAQABgBABAAQAAAAAAAAQAAAAABAAQABAAAAABQABAAAAAAQABAAAAABQABAAAAABQAAAAABABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQgBAAAAABQAAAAgBABQAAAAgBABQAAAAgBAAQAAABgBAAQgBAAAAAAQAAAAAAAAQgBAAgBgBQAAAAAAAAQgBgBAAAAg");
	this.shape_117.setTransform(848.125,17.675);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("AgUAXQgJgIAAgPQABgNAIgJQAIgJANABQAOgBAHAJQAIAIAAAOQgBAOgHAJQgJAJgNAAQgNAAgHgJgAgNgQQgFAGgBAKQABALAFAGQAGAGAHABQAKAAAFgHQAFgFAAgMQAAgKgFgGQgFgHgKABQgHgBgGAHg");
	this.shape_118.setTransform(843.1,19.05);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAXAAQANAAAHAHQAIAGAAAMQAAAMgJAGQgIAIgNAAIgLAAIAAAggAgPABIAKAAQAKABAFgFQAFgEAAgJQAAgQgSAAIgMAAg");
	this.shape_119.setTransform(836.975,17.85);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#FFFFFF").s().p("AgPAeIAAg7IAKAAIAAANQACgHAEgDQAEgDAFgBIAGABIAAAKQgDgBgEgBQgHABgDAFQgEAGAAAJIAAAeg");
	this.shape_120.setTransform(831.675,19);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#FFFFFF").s().p("AgSAYQgHgJAAgPQAAgNAIgIQAIgJALAAQALgBAHAIQAGAIAAAOIAAADIgpAAQAAAKAFAGQAFAFAIABQALAAAIgIIAAAKQgIAFgNABQgMgBgHgHgAgJgSQgFAFgBAJIAfAAQAAgJgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_121.setTransform(826.075,19.05);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#FFFFFF").s().p("AAOAeIgNgqIgBgGIAAAGIgOAqIgJAAIgSg7IAKAAIANAsIAAAFIABAAIABgFIAOgsIAIAAIAMAsIAAAFIABAAIABgFIANgsIAJAAIgSA7g");
	this.shape_122.setTransform(818.6,19.05);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#FFFFFF").s().p("AgUAXQgJgIAAgPQABgNAIgJQAIgJANABQAOgBAHAJQAIAIAAAOQgBAOgHAJQgJAJgNAAQgNAAgHgJgAgNgQQgFAGgBAKQABALAFAGQAGAGAHABQAKAAAFgHQAFgFAAgMQAAgKgFgGQgFgHgKABQgHgBgGAHg");
	this.shape_123.setTransform(810.7,19.05);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#FFFFFF").s().p("AgZAqIAAhTIAXAAQANAAAHAHQAIAGAAAMQAAAMgJAGQgIAIgNAAIgLAAIAAAggAgPABIAKAAQAKABAFgFQAFgEAAgJQAAgQgSAAIgMAAg");
	this.shape_124.setTransform(804.575,17.85);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#FFFFFF").s().p("AgPAEIAAgHIAfAAIAAAHg");
	this.shape_125.setTransform(793.05,18.725);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#FFFFFF").s().p("AgSAYQgHgJAAgPQAAgNAIgIQAIgJALAAQALgBAHAIQAGAIAAAOIAAADIgpAAQAAAKAFAGQAFAFAIABQALAAAIgIIAAAKQgIAFgNABQgMgBgHgHgAgJgSQgFAFgBAJIAfAAQAAgJgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_126.setTransform(781.375,19.05);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#FFFFFF").s().p("AgEAeIgXg7IALAAIAOArQACAFAAADIAAAAIACgIIAQgrIAKAAIgYA7g");
	this.shape_127.setTransform(775.35,19.05);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#FFFFFF").s().p("AgEAsIAAg7IAJAAIAAA7gAgDggQgBgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAgBAAAAQAAgBABAAQAAgBABAAQAAgBABAAQAAAAAAAAQABgBABAAQAAAAAAAAQABAAAAAAQABAAAAABQABAAAAAAQABAAAAABQABAAAAABQABAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAABQAAAAgBABQAAAAgBABQAAAAgBABQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAAAAAQgBAAgBgBQAAAAAAAAQgBgBAAAAg");
	this.shape_128.setTransform(771.025,17.675);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#FFFFFF").s().p("AgPAeIAAg7IAKAAIAAANQACgHAEgDQAEgDAFgBIAGABIAAAKQgDgBgEgBQgHABgDAFQgEAGAAAJIAAAeg");
	this.shape_129.setTransform(767.925,19);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#FFFFFF").s().p("AghAqIAAhTIAXAAQAsAAAAApQAAATgMALQgNAMgTAAgAgXAhIANAAQAPAAAJgJQAKgJAAgPQAAgggiAAIgNAAg");
	this.shape_130.setTransform(761.475,17.85);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#FFFFFF").s().p("AgSAYQgHgJAAgPQAAgNAIgIQAIgJALAAQALgBAHAIQAGAIAAAOIAAADIgpAAQAAAKAFAGQAFAFAIABQALAAAIgIIAAAKQgIAFgNABQgMgBgHgHgAgJgSQgFAFgBAJIAfAAQAAgJgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_131.setTransform(753.925,19.05);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#FFFFFF").s().p("AAQAfIAAghQAAgUgPAAQgFAAgFAGQgFAFAAAJIAAAhIgKAAIAAg7IAKAAIAAAKQAHgMAMAAQAJAAAGAHQAFAGAAAMIAAAkg");
	this.shape_132.setTransform(747.4,18.975);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#FFFFFF").s().p("AgcAfQgLgLAAgTQAAgTALgNQALgMASAAQARAAALAMQALAMAAATQAAAUgLALQgLANgSAAQgRAAgLgNgAgUgYQgIAJAAAPQAAAPAIAKQAIAKAMAAQANgBAIgIQAIgKAAgPQAAgQgHgJQgIgKgOAAQgMAAgIAKg");
	this.shape_133.setTransform(739.425,17.85);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#FFFFFF").s().p("AgUAXQgIgIAAgPQgBgNAJgJQAIgJANABQANgBAIAJQAHAIAAAOQABAOgJAJQgHAJgOAAQgNAAgHgJgAgNgQQgGAGABAKQgBALAGAGQAFAGAIABQAKAAAFgHQAFgFAAgMQAAgKgFgGQgFgHgKABQgIgBgFAHg");
	this.shape_134.setTransform(728.05,19.05);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#FFFFFF").s().p("AgGAWIAAgjIgLAAIAAgIIALAAIAAgOIAJgEIAAASIAOAAIAAAIIgOAAIAAAhQAAAGACADQABACAGAAQADAAACgCIAAAJQgDACgGAAQgOAAAAgSg");
	this.shape_135.setTransform(722.5,18.225);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#FFFFFF").s().p("AgUAlQgHgIAAgOQAAgPAIgIQAHgJAMAAQAMAAAGAKIAAAAIAAglIAKAAIAABYIgKAAIAAgKIAAAAQgHALgNAAQgLAAgHgIgAgMgCQgFAFAAAMQAAAKAFAGQAFAGAHAAQAIAAAFgGQAFgGAAgIIAAgJQAAgHgFgFQgFgFgHAAQgIAAgFAHg");
	this.shape_136.setTransform(713.475,17.675);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#FFFFFF").s().p("AgSAYQgHgJAAgPQAAgNAIgIQAIgJALAAQALgBAHAIQAGAIAAAOIAAADIgpAAQAAAKAFAGQAFAFAIABQALAAAIgIIAAAKQgIAFgNABQgMgBgHgHgAgJgSQgFAFgBAJIAfAAQAAgJgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_137.setTransform(707.075,19.05);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#FFFFFF").s().p("AgFAeIgWg7IAKAAIAQArQABAFAAADIAAAAIACgIIAQgrIAKAAIgYA7g");
	this.shape_138.setTransform(701.05,19.05);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#FFFFFF").s().p("AgSAaQgEgEAAgIQAAgQATgCIARgDQAAgPgNAAQgJgBgJAIIAAgKQAJgGAKABQAWAAAAAWIAAAmIgKAAIAAgKQgGAMgLAAQgKgBgFgFgAAAABQgGABgEADQgDACAAAHQAAAEADACQADAEAGAAQAGAAAEgGQAFgFAAgHIAAgGg");
	this.shape_139.setTransform(694.95,19.05);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#FFFFFF").s().p("AgIArIgHgBIgFgCIgFgCIAAgLIAGADIAFACIAGACIAGABQAIAAAEgEQAFgDAAgHQAAgDgCgCIgEgFIgGgEIgHgEIgHgDIgHgGIgFgGQgCgEAAgEQABgFACgFQACgEAFgDIAJgEIAKgCQAMABAGACIAAAMQgIgGgLAAIgFABIgGACIgFAFQgBACAAADQAAADABACIAEAFIAFAEIAHADIAJAFIAHAFIAFAGQABAEABAFQgBAGgCAEQgCAFgEACQgFADgFABQgFACgGAAIgEgBg");
	this.shape_140.setTransform(688.9,17.85);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#FFFFFF").s().p("AgPAEIAAgHIAfAAIAAAHg");
	this.shape_141.setTransform(680,18.725);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#FFFFFF").s().p("AgGAWIAAgjIgLAAIAAgIIALAAIAAgOIAJgEIAAASIAOAAIAAAIIgOAAIAAAhQAAAGACADQABACAGAAQADAAACgCIAAAJQgDACgGAAQgOAAAAgSg");
	this.shape_142.setTransform(672.2,18.225);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#FFFFFF").s().p("AgbAtIAAhXIAKAAIAAALQAHgMANAAQAMAAAGAIQAHAHAAAOQAAAPgIAJQgHAIgNABQgKgBgHgJIAAAkgAgMgeQgFAHAAAIIAAAJQAAAGAFAFQAFAFAHABQAIAAAFgIQAFgFAAgMQAAgKgFgGQgEgFgIAAQgIAAgFAFg");
	this.shape_143.setTransform(666.875,20.35);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#FFFFFF").s().p("AgbAtIAAhXIAKAAIAAALQAHgMANAAQAMAAAGAIQAHAHAAAOQAAAPgIAJQgHAIgNABQgKgBgHgJIAAAkgAgMgeQgFAHAAAIIAAAJQAAAGAFAFQAFAFAHABQAIAAAFgIQAFgFAAgMQAAgKgFgGQgEgFgIAAQgIAAgFAFg");
	this.shape_144.setTransform(659.825,20.35);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#FFFFFF").s().p("AgDAFQgDgCAAgDQAAAAABAAQAAgBAAgBQAAAAABgBQAAAAABgBQAAAAABgBQAAAAABAAQAAAAABgBQAAAAAAAAQADAAACACQAAABABAAQAAABAAAAQAAABAAABQABAAAAAAQgBADgBACQgCACgDAAQAAAAAAAAQgBAAAAgBQgBAAAAAAQgBgBAAAAg");
	this.shape_145.setTransform(654.8,21.525);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#FFFFFF").s().p("AAOAeIgNgqIAAgGIgBAGIgOAqIgJAAIgSg7IAKAAIANAsIAAAFIABAAIABgFIANgsIAIAAIANAsIABAFIAAAAIABgFIAMgsIAKAAIgSA7g");
	this.shape_146.setTransform(649.2,19.05);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#FFFFFF").s().p("AgRAaQgFgEgBgIQABgQATgCIARgDQAAgPgNAAQgJgBgJAIIAAgKQAJgGAKABQAWAAAAAWIAAAmIgKAAIAAgKQgHAMgLAAQgJgBgEgFgAAAABQgGABgDADQgEACAAAHQAAAEAEACQACAEAGAAQAGAAAEgGQAFgFAAgHIAAgGg");
	this.shape_147.setTransform(641.65,19.05);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#FFFFFF").s().p("AgPAeIAAg7IAKAAIAAANQACgHAEgDQAEgDAFgBIAGABIAAAKQgDgBgEgBQgHABgDAFQgEAGAAAJIAAAeg");
	this.shape_148.setTransform(637.125,19);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#FFFFFF").s().p("AghAqIAAhTIAXAAQAsAAAAApQAAATgMALQgNAMgTAAgAgXAhIANAAQAPAAAJgJQAKgJAAgPQAAgggiAAIgNAAg");
	this.shape_149.setTransform(630.675,17.85);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#FFFFFF").s().p("AgUAXQgJgIABgPQAAgNAIgJQAIgJANABQAOgBAHAJQAIAIgBAOQAAAOgHAJQgIAJgOAAQgNAAgHgJgAgNgQQgFAGgBAKQABALAFAGQAGAGAHABQAKAAAFgHQAFgFAAgMQAAgKgFgGQgFgHgKABQgHgBgGAHg");
	this.shape_150.setTransform(619.35,19.05);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#FFFFFF").s().p("AgGAWIAAgjIgKAAIAAgIIAKAAIAAgOIAJgEIAAASIAOAAIAAAIIgOAAIAAAhQAAAGACADQABACAGAAQADAAACgCIAAAJQgDACgGAAQgOAAAAgSg");
	this.shape_151.setTransform(613.8,18.225);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#FFFFFF").s().p("AAPAfIAAghQABgUgOAAQgGAAgGAGQgEAFAAAJIAAAhIgKAAIAAg7IAKAAIAAAKQAHgMAMAAQAKAAAFAHQAFAGAAAMIAAAkg");
	this.shape_152.setTransform(605.15,18.975);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#FFFFFF").s().p("AgPAeIAAg7IAKAAIAAANQACgHAEgDQAEgDAFgBIAGABIAAAKQgDgBgEgBQgHABgDAFQgEAGAAAJIAAAeg");
	this.shape_153.setTransform(600.075,19);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#FFFFFF").s().p("AgSAaQgEgEAAgIQAAgQATgCIARgDQAAgPgMAAQgKgBgJAIIAAgKQAJgGALABQAUAAABAWIAAAmIgKAAIAAgKQgGAMgLAAQgJgBgGgFgAAAABQgGABgEADQgDACAAAHQAAAEADACQADAEAFAAQAHAAAEgGQAFgFAAgHIAAgGg");
	this.shape_154.setTransform(594.35,19.05);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#FFFFFF").s().p("AgSAYQgHgJAAgPQAAgNAIgIQAIgJALAAQALgBAHAIQAGAIAAAOIAAADIgpAAQAAAKAFAGQAFAFAIABQALAAAIgIIAAAKQgIAFgNABQgMgBgHgHgAgJgSQgFAFgBAJIAfAAQAAgJgEgFQgEgEgHAAQgFAAgFAEg");
	this.shape_155.setTransform(588.375,19.05);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#FFFFFF").s().p("AgVAqIAAhTIAKAAIAABKIAhAAIAAAJg");
	this.shape_156.setTransform(582.825,17.85);

	this.instance_2 = new lib.ClipGroup_1();
	this.instance_2.parent = this;
	this.instance_2.setTransform(683,17,1,1,0,0,0,683,17);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#B8543E").s().p("AANAaIAAgcQAAgQgMAAQgFAAgEAEQgEAFAAAHIAAAcIgIAAIAAgyIAIAAIAAAJQAGgKAKAAQAIAAAFAFQAEAGAAAKIAAAeg");
	this.shape_157.setTransform(96.475,16.875);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#B8543E").s().p("AgYAbQgJgKAAgQQAAgRAJgKQAKgKAPAAQAPAAAJAKQAJAKAAAQQAAARgJAKQgJAKgQAAQgOAAgKgKgAgRgUQgHAIAAAMQAAAOAHAIQAHAHAKAAQALABAHgIQAIgIAAgOQAAgNgIgHQgGgJgMABQgKAAgHAIg");
	this.shape_158.setTransform(89.5,15.9);

	this.instance_3 = new lib.ClipGroup_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(683,17,1,1,0,0,0,683,17);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#FFFFFF").s().p("AgTAYQgHgJAAgPQAAgNAIgJQAIgJALAAQAMAAAHAIQAHAHAAAOIAAAEIgrAAQAAALAGAFQAFAGAIAAQALAAAIgHIAAAJQgIAGgNAAQgMAAgIgIgAgKgSQgFAFgBAIIAhAAQgBgIgEgFQgEgFgHAAQgGAAgFAFg");
	this.shape_159.setTransform(72.175,17.675);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#FFFFFF").s().p("AgFAfIgXg9IALAAIAQAsIABAJIACgJIAQgsIALAAIgZA9g");
	this.shape_160.setTransform(65.875,17.675);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#FFFFFF").s().p("AgSAbQgFgFAAgIQAAgQAUgDIARgCQAAgQgMAAQgKAAgJAIIAAgKQAJgGALAAQAVAAAAAXIAAAnIgKAAIAAgKQgGALgMAAQgJAAgFgFgAAAACQgGABgEACQgDADAAAGQAAAEADADQADADAGAAQAGAAAFgFQAEgFAAgIIAAgGg");
	this.shape_161.setTransform(59.475,17.675);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#FFFFFF").s().p("AgIAsIgHgBIgFgBIgFgCIAAgNIAFAEIAFACIAHACIAGAAQAIABAFgEQAEgDABgHQgBgDgBgDIgFgFIgGgEIgGgEIgJgEIgHgFQgDgCgCgEQgBgEAAgEQAAgGACgFQADgEAEgDQAFgDAFgBQAFgCAFAAQAMAAAHAEIAAALQgIgGgMAAIgGABIgFADQgDABgCACQgCADAAAEIABAFIAFAFIAFADIAHAFIAJADIAHAGQADADACAEQACADAAAGQAAAFgCAFQgDAFgEACQgEADgGABQgFACgFgBIgFAAg");
	this.shape_162.setTransform(53.15,16.45);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#FFFFFF").s().p("AgVAYQgIgJAAgOQAAgPAIgIQAIgJAOAAQAOAAAHAIQAIAJAAAOQAAAOgIAJQgJAJgNAAQgNAAgIgIgAgOgQQgFAGAAAKQAAALAFAHQAGAGAIAAQAKAAAFgGQAFgGAAgMQAAgKgFgHQgFgGgKAAQgIAAgGAHg");
	this.shape_163.setTransform(45.975,17.675);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#FFFFFF").s().p("AgGAWIAAgjIgLAAIAAgJIALAAIAAgOIAJgEIAAASIAPAAIAAAJIgPAAIAAAhQAAAGABADQADADAFAAQADAAADgCIAAAIQgDACgGAAQgPABAAgTg");
	this.shape_164.setTransform(40.15,16.85);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#FFFFFF").s().p("AgZAFIAAgkIALAAIAAAiQAAAUAOAAQAHAAAEgFQAFgGAAgIIAAgjIAJAAIAAA9IgJAAIAAgKIgBAAQgFAMgMgBQgXAAAAgag");
	this.shape_165.setTransform(34.45,17.75);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#FFFFFF").s().p("AAbArIgJgYIgkAAIgIAYIgLAAIAhhVIAJAAIAhBVgAgBgaIgNAkIAdAAIgOgkIgBgFIgBAFg");
	this.shape_166.setTransform(26.975,16.45);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#B8543E").s().p("EhqtACqIAAlTMDVbAAAIAAFTg");
	this.shape_167.setTransform(683,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_167},{t:this.shape_166},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.instance_3},{t:this.shape_158},{t:this.shape_157},{t:this.instance_2},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.instance_1},{t:this.instance},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.menus, new cjs.Rectangle(-7,0,1384,80), null);


(lib.mask35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask35.cache(-35,-10,70,20,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask35 = new lib.mask_35();
	this.mask35.name = "mask35";
	this.mask35.parent = this;
	this.mask35.setTransform(17.3,48.25,1,1,0,0,0,17.3,4.8);

	this.timeline.addTween(cjs.Tween.get(this.mask35).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask35, new cjs.Rectangle(0,43.5,34.5,9.600000000000001), null);


(lib.mask34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask34.cache(-45,-20,90,40,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask34 = new lib.mask_34();
	this.mask34.name = "mask34";
	this.mask34.parent = this;
	this.mask34.setTransform(19.9,50.05,1,1,0,0,0,19.9,7);

	this.timeline.addTween(cjs.Tween.get(this.mask34).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask34, new cjs.Rectangle(0,43.1,39.9,14.100000000000001), null);


(lib.mask33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask33.cache(-45,-25,90,50,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask33 = new lib.mask_33();
	this.mask33.name = "mask33";
	this.mask33.parent = this;
	this.mask33.setTransform(20.6,52.6,1,1,0,0,0,20.6,10.5);

	this.timeline.addTween(cjs.Tween.get(this.mask33).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask33, new cjs.Rectangle(0,42.1,41.2,21.1), null);


(lib.mask32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask32.cache(-52,-25,104,50,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask32 = new lib.mask_32();
	this.mask32.name = "mask32";
	this.mask32.parent = this;
	this.mask32.setTransform(25.2,52.5,1,1,0,0,0,25.2,12);

	this.timeline.addTween(cjs.Tween.get(this.mask32).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask32, new cjs.Rectangle(0,40.5,50.4,23.900000000000006), null);


(lib.mask31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask31.cache(-64,-45,128,90,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask31 = new lib.mask__31();
	this.mask31.name = "mask31";
	this.mask31.parent = this;
	this.mask31.setTransform(29.7,42.7,1,1,0,0,0,29.7,21.7);

	this.timeline.addTween(cjs.Tween.get(this.mask31).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask31, new cjs.Rectangle(0,21,59.4,43.400000000000006), null);


(lib.mask30 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask30.cache(-68,-70,136,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask30 = new lib.mask_30();
	this.mask30.name = "mask30";
	this.mask30.parent = this;
	this.mask30.setTransform(32.6,32.6,1,1,0,0,0,32.6,32.6);

	this.timeline.addTween(cjs.Tween.get(this.mask30).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask30, new cjs.Rectangle(0,0,67,65.4), null);


(lib.mask29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask29.cache(-70,-70,140,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask29 = new lib.mask_29();
	this.mask29.name = "mask29";
	this.mask29.parent = this;
	this.mask29.setTransform(32.6,32.6,1,1,0,0,0,32.6,32.6);

	this.timeline.addTween(cjs.Tween.get(this.mask29).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask29, new cjs.Rectangle(0,0,65.4,65.4), null);


(lib.mask28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask28.cache(-64,-70,128,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask28 = new lib.mask_28();
	this.mask28.name = "mask28";
	this.mask28.parent = this;
	this.mask28.setTransform(31.4,32.6,1,1,0,0,0,31.4,32.6);

	this.timeline.addTween(cjs.Tween.get(this.mask28).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask28, new cjs.Rectangle(0,0,62.8,65.4), null);


(lib.mask27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask27.cache(-64,-70,128,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask27 = new lib.mask_27();
	this.mask27.name = "mask27";
	this.mask27.parent = this;
	this.mask27.setTransform(31.4,32.9,1,1,0,0,0,31.4,32.9);

	this.timeline.addTween(cjs.Tween.get(this.mask27).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask27, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask26.cache(-64,-70,128,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask26 = new lib.mask_26();
	this.mask26.name = "mask26";
	this.mask26.parent = this;
	this.mask26.setTransform(31.4,32.9,1,1,0,0,0,31.4,32.9);

	this.timeline.addTween(cjs.Tween.get(this.mask26).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask26, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask25.cache(-64,-70,128,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask25 = new lib.mask_25();
	this.mask25.name = "mask25";
	this.mask25.parent = this;
	this.mask25.setTransform(31.4,32.9,1,1,0,0,0,31.4,32.9);

	this.timeline.addTween(cjs.Tween.get(this.mask25).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask25, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask24.cache(-70,-70,140,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask24 = new lib.mask_24();
	this.mask24.name = "mask24";
	this.mask24.parent = this;
	this.mask24.setTransform(31.4,32.9,1,1,0,0,0,31.4,32.9);

	this.timeline.addTween(cjs.Tween.get(this.mask24).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask24, new cjs.Rectangle(0,0,62.9,65.7), null);


(lib.mask23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask23.cache(-75,-70,150,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask23 = new lib.mask_23();
	this.mask23.name = "mask23";
	this.mask23.parent = this;
	this.mask23.setTransform(36.3,32.9,1,1,0,0,0,36.3,32.9);

	this.timeline.addTween(cjs.Tween.get(this.mask23).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask23, new cjs.Rectangle(0,0,72.7,65.7), null);


(lib.mask22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask22.cache(-75,-70,150,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask22 = new lib.mask_22();
	this.mask22.name = "mask22";
	this.mask22.parent = this;
	this.mask22.setTransform(36.6,32.9,1,1,0,0,0,36.6,32.9);

	this.timeline.addTween(cjs.Tween.get(this.mask22).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask22, new cjs.Rectangle(0,0,73.2,65.7), null);


(lib.mask21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask21.cache(-50,-30,100,60,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask21 = new lib.mask_21();
	this.mask21.name = "mask21";
	this.mask21.parent = this;
	this.mask21.setTransform(24.4,13.6,1,1,0,0,0,24.4,13.6);

	this.timeline.addTween(cjs.Tween.get(this.mask21).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask21, new cjs.Rectangle(0,0,48.8,27.1), null);


(lib.mask20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask20.cache(-50,-30,100,60,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask20 = new lib.mask_20();
	this.mask20.name = "mask20";
	this.mask20.parent = this;
	this.mask20.setTransform(24.4,14.2,1,1,0,0,0,24.4,14.2);

	this.timeline.addTween(cjs.Tween.get(this.mask20).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask20, new cjs.Rectangle(0,0,48.8,28.4), null);


(lib.mask19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask19.cache(-50,-36,100,72,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask19 = new lib.mask_19();
	this.mask19.name = "mask19";
	this.mask19.parent = this;
	this.mask19.setTransform(24.4,17.7,1,1,0,0,0,24.4,17.7);

	this.timeline.addTween(cjs.Tween.get(this.mask19).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask19, new cjs.Rectangle(0,0,48.8,35.4), null);


(lib.mask18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask18.cache(-62,-50,124,100,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask18 = new lib.mask_18();
	this.mask18.name = "mask18";
	this.mask18.parent = this;
	this.mask18.setTransform(30.7,24.8,1,1,0,0,0,30.7,24.8);

	this.timeline.addTween(cjs.Tween.get(this.mask18).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask18, new cjs.Rectangle(0,0,61.3,49.5), null);


(lib.mask17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask17.cache(-64,-50,128,100,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask17 = new lib.mask_17();
	this.mask17.name = "mask17";
	this.mask17.parent = this;
	this.mask17.setTransform(30.9,24.8,1,1,0,0,0,30.9,24.8);

	this.timeline.addTween(cjs.Tween.get(this.mask17).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask17, new cjs.Rectangle(0,0,61.8,49.5), null);


(lib.mask16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask16.cache(-102,-50,204,100,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask16 = new lib.mask_16();
	this.mask16.name = "mask16";
	this.mask16.parent = this;
	this.mask16.setTransform(50.4,24.5,1,1,0,0,0,50.4,24.5);

	this.timeline.addTween(cjs.Tween.get(this.mask16).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask16, new cjs.Rectangle(0,0,100.8,49.1), null);


(lib.mask15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask15.cache(-120,-50,240,100,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask15 = new lib.mask_15();
	this.mask15.name = "mask15";
	this.mask15.parent = this;
	this.mask15.setTransform(59.1,24.5,1,1,0,0,0,59.1,24.5);

	this.timeline.addTween(cjs.Tween.get(this.mask15).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask15, new cjs.Rectangle(0,0,118.1,49.1), null);


(lib.mask14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask14.cache(-120,-50,240,100,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask14 = new lib.mask_14();
	this.mask14.name = "mask14";
	this.mask14.parent = this;
	this.mask14.setTransform(58.3,24.5,1,1,0,0,0,58.3,24.5);

	this.timeline.addTween(cjs.Tween.get(this.mask14).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask14, new cjs.Rectangle(0,0,116.7,49.1), null);


(lib.mask13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.mask13.cache(-120,-50,240,100,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.mask13 = new lib.mask_13();
	this.mask13.name = "mask13";
	this.mask13.parent = this;
	this.mask13.setTransform(58.3,24.5,1,1,0,0,0,58.3,24.5);

	this.timeline.addTween(cjs.Tween.get(this.mask13).wait(1));

}).prototype = getMCSymbolPrototype(lib.mask13, new cjs.Rectangle(0,0,116.7,49.1), null);


(lib.logo_office365 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo.cache(-205,-25,410,50,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.logo = new lib.msoft_logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(5.25,1.15,1,1,0,0,0,55.7,11.9);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_office365, new cjs.Rectangle(-49.8,-11.2,204.39999999999998,24.1), null);


(lib.laptop_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Camera
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0D0D0D").s().p("AgKAMQgFgFAAgHQAAgGAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAGQAAAGgFAGQgFAEgGAAQgFAAgFgEg");
	this.shape.setTransform(399,12.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#6D6E6E").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape_1.setTransform(399,12.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgPgPQANAAAIAKQAKAIAAAN");
	this.shape_2.setTransform(400.6,10.45);

	this.instance = new lib.Path_3_0();
	this.instance.parent = this;
	this.instance.setTransform(400.55,10.45,1,1,0,0,0,1.6,1.6);
	this.instance.alpha = 0.25;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#272C2E").s().p("AgeAfQgNgNAAgSQAAgRANgNQANgNARAAQASAAANANQANANAAARQAAASgNANQgNANgSAAQgRAAgNgNg");
	this.shape_3.setTransform(399,12.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0D0D0D").s().p("AgFAGQgCgDgBgDQABgDACgCQACgDADAAQAEAAACADQACACABADQgBADgCADQgCACgEAAQgDAAgCgCg");
	this.shape_4.setTransform(379.75,12.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#6D6E6E").s().p("AgGAHQgDgDAAgEQAAgDADgDQADgDADAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_5.setTransform(379.75,12.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#A1A1A2").ss(0.3,1).p("AgIgHQAHAAAEAFQAFADAAAH");
	this.shape_6.setTransform(380.6,11.225);

	this.instance_1 = new lib.Path_3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(380.55,11.2,1,1,0,0,0,0.8,0.8);
	this.instance_1.alpha = 0.25;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#272C2E").s().p("AgPAQQgHgGAAgKQAAgIAHgHQAHgHAIAAQAKAAAGAHQAHAHAAAIQAAAKgHAGQgGAHgKAAQgIAAgHgHg");
	this.shape_7.setTransform(379.75,12.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.instance},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Screen
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0D0D0D").s().p("Eg4oAj7QhXAAg+g9Qg+g+AAhXMAAAhBbQAAhTA7g6QA6g7BTAAMBxNAAAQBeAABCBCQBCBCAABeMAAABAzQAABdhCBCQhBBBhdAAgEg5UggcMAAABAiQAAAEAEAAMByvAAAQAEAAABgEMAAAhAiQgBgEgEAAMhyvAAAQgEAAAAAEg");
	this.shape_8.setTransform(413.8,232.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#6D7680").s().p("Eg4pAkWQhpAAhLhLQhLhKAAhpMAAAhA5QAAhlBIhHQBIhIBkAAMBxPAAAQBvAABQBPQBPBPAABwMAAABARQAABvhPBPQhPBOhuAAgEg5+AghMB0MAAAMAAAhBZMh0MAAAg");
	this.shape_9.setTransform(414.35,232.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Keyboard
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#ACB6BF").s().p("AjOAjQgFAAgBgGIgFgYQgBgEgBAAIgDgFIgEgaQgCgFAGAAIGsABQAFAAABAGIAFAXIACAFQACAAABAFIAFAZQACAGgGAAg");
	this.shape_10.setTransform(703.4,504.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#ACB6BF").s().p("AjMAiQgGAAgCgFIgRg5QgCgGAGAAIGrABQAGAAACAFIAUA5QACAGgGAAg");
	this.shape_11.setTransform(749.9017,504.175);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#ACB6BF").s().p("AjOAiQgGAAgBgGIgMg4IAAgEQAAgBABAAQAAAAAAAAQABgBAAAAQABAAABAAIGrABQAGAAABAGIANA4QACAGgGAAg");
	this.shape_12.setTransform(656.5917,504.175);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#ACB6BF").s().p("AjSAiQgGAAgBgFIgJg5QgBgFAFAAIGsAAQAGAAABAFIAOA5QACAFgGAAg");
	this.shape_13.setTransform(610.1923,504.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#ACB6BF").s().p("AjSAiQgFAAgBgFIgHg5QgBgFAGAAIGvAAQAGAAAAAFIAFA5QAAAFgFAAg");
	this.shape_14.setTransform(563.3173,504.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#ACB6BF").s().p("A11AiQgEAAAAgFIAGg5QABgFAFAAMArcAAAQAFAAABAFIAGA5QgBAFgFAAg");
	this.shape_15.setTransform(398.9,504.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#ACB6BF").s().p("AjsAiQgFAAABgFIAOg5QABgFAFAAIHJAAQAGAAgBAFIgJA5QAAAFgGAAg");
	this.shape_16.setTransform(232.5995,504.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#ACB6BF").s().p("AjtAiQgGAAABgFIAOg5QACgFAFAAIHMAAQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgOA5QgCAFgFAAg");
	this.shape_17.setTransform(183.0373,504.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#ACB6BF").s().p("AjvAiQgGAAABgFIAOg5QACgFAFAAIHPAAQABAAABAAQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgUA5QgBAFgGAAg");
	this.shape_18.setTransform(133.6623,504.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#ACB6BF").s().p("AkAAiQgFAAABgFIARg5QABgFAGAAIHtAAQAGAAgCAFIgUA5QgCAFgFAAg");
	this.shape_19.setTransform(82.1433,504.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#63717F").s().p("AjRArQgFAAgCgFIgSg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBQABAAAAgBQAAAAABAAQAAgBABAAQABAAAAAAIGsABQAFAAACAFIAUA5IAAADIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAAAQAAABgBABQAAAAgBAAQAAABAAAAQgBAAgBAAg");
	this.shape_20.setTransform(749.4625,505.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#63717F").s().p("AjUAsQgFAAgCgFIgFgaQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAgBQgEgBgBgEIgFgYQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAAAIABgBIAAgBIABgBIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAQABgBAAAAQABgBAAAAQABAAAAAAQABgBAAAAIGsABQAFAAABAGIAGAaQAAAAAAAAQAAABAAAAQAAABAAAAQAAABgBAAIAAAAQAEACABAEIAGAYIAAADIAAAAIAAAGIABABIAAAFIAAAAIAAADQAAAFgEgBg");
	this.shape_21.setTransform(702.8688,505.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#63717F").s().p("AjVAsQgGAAgBgFIgNg2IAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBQABgEADAAIGsABQAGAAABAGIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIANA1QABAGgGAAg");
	this.shape_22.setTransform(656.5327,505.175);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#63717F").s().p("AjXAuQgFAAgBgGIgKg4IAAgDIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBQABgDADAAIGsAAQAGAAABAFIAOA5IABABIAAAMIAAAAIAAAMQABAEgFAAg");
	this.shape_23.setTransform(609.8583,505.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#63717F").s().p("AjYAsQgGAAAAgFIgHg5IABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAAAAAgBQABAAAAAAQABgBAAAAQABAAABAAIGvAAQAGAAAAAFIAAACIABAAIAAAEIAAAAIAAADIABAAIAAAFIAAAAIAAADIABAAIAAADIAEA5QAAAFgFAAg");
	this.shape_24.setTransform(562.925,505.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#63717F").s().p("A17AsQgFAAAAgFIAHg5IAAgBIAAAAIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQABgFAFAAMArcAAAQAEAAACAFIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAFA5QABAFgGAAg");
	this.shape_25.setTransform(398.9321,505.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#63717F").s().p("AjxAsQgFAAABgFIAAAAIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgDIAOg4QABgGAGAAIHIAAQAEAAABAEIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIgIA5QgBAFgFAAg");
	this.shape_26.setTransform(232.6173,505.15);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#63717F").s().p("Aj4AsQgGAAABgFIAOg5IAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgFAFAAIHMAAQABAAAAABQABAAAAAAQABAAAAABQAAAAAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAAAIAAABIABAAIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAAAIABABIAAAAIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAADIgOA5QgBAFgFAAg");
	this.shape_27.setTransform(183.3006,505.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#63717F").s().p("Aj9AsQAAAAgBAAQAAAAgBAAQAAAAgBgBQAAAAAAgBIAAgBIgBAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgEIAQg4QABgGAGAAIHtAAQABAAABABQAAAAABAAQAAAAAAABQABAAAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIAAAAIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgTA5QgCAFgFAAg");
	this.shape_28.setTransform(82.5,505.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#63717F").s().p("Aj5AsQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAgBgBAAIAAgEIANg5IABgCIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAAAIAAAAIAAgBIABAAIAAgBQACgEAEAAIHPAAQABAAABABQAAAAABAAQAAAAABABQAAAAAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAIgUA5QgCAFgFAAg");
	this.shape_29.setTransform(133.3667,505.15);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#ACB6BF").s().p("Ap0AcQgGgBgBgFIgGgrQgBgGAFABITpAAQAFgBACAGIAPArQACAFgGABg");
	this.shape_30.setTransform(706.569,497.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#ACB6BF").s().p("AjYAcQgGgBgBgFIgGgrQgBgGAGABIG2AAQAGgBABAGIAJArQABAFgGABg");
	this.shape_31.setTransform(618.1505,497.55);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#ACB6BF").s().p("AjcAbQgGABAAgGIgCgrQgBgFAGgBIG6AAQAFABABAFIAFArQAAAGgFgBg");
	this.shape_32.setTransform(569.9429,497.4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#ACB6BF").s().p("AjeAcQgFgBAAgFIAAgrQAAgGAFABIG4AAQAGgBAAAGIAEArQAAAFgFABg");
	this.shape_33.setTransform(521.925,497.55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGgBIG6AAQAFABABAFIADArQAAAFgGAAg");
	this.shape_34.setTransform(474.425,497.75);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIACgrQAAgFAGgBIG6AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_35.setTransform(426.325,497.75);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIADgrQAAgFAGgBIG5AAQAFABAAAFIAAArQAAAFgFAAg");
	this.shape_36.setTransform(378.6429,497.75);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#ACB6BF").s().p("AjgAbQgGAAABgFIAGgrQAAgFAGgBIG6AAQAFABAAAFIgEArQAAAFgGAAg");
	this.shape_37.setTransform(330.2173,497.75);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGgBIG6AAQAGABgBAFIgGArQAAAFgGAAg");
	this.shape_38.setTransform(282.5321,497.75);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#ACB6BF").s().p("AjiAbQgFAAAAgFIAHgrQABgFAFgBIG9AAQAGABgBAFIgKArQgBAFgFAAg");
	this.shape_39.setTransform(234.75,497.75);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#ACB6BF").s().p("AjkAbQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAgBAAAAIgBgEIAMgrQACgFAFgBIG5AAQABABABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAAAgBABIgLArQgCAFgFAAg");
	this.shape_40.setTransform(186.5617,497.75);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#ACB6BF").s().p("AoFAbQgBAAAAAAQgBAAAAAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAAAAAAAIAQgsQADgFAFgBIP2AAQAGABgCAFIgMArQgBAFgGAAg");
	this.shape_41.setTransform(110.2167,497.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#63717F").s().p("Ap6ApQgFAAgBgFIgHgrIAAgDIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAITpAAQAFAAABAFIAJArIAHADIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAQgBABAAABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_42.setTransform(706.025,498.925);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#63717F").s().p("AjdApQgFAAgBgFIgGgrIAAgDIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBQABgDADAAIG3AAQAFAAACAFIAJArIgBADIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABQgBADgEAAg");
	this.shape_43.setTransform(617.7,498.925);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgBQABgFAEAAIG6AAQAEAAACAFIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAEArQABAGgFAAg");
	this.shape_44.setTransform(570.0077,498.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBQABgEAEAAIG3AAQAFAAABAFIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIAEAqQABAGgGAAg");
	this.shape_45.setTransform(521.7571,499.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIABABIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAAAIABACIACAqQAAAGgFAAg");
	this.shape_46.setTransform(474.375,499.1);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIACgsIABAAIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAAAIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABgBIAAgBIABAAIAAgCQACgEADAAIG6AAQAFAAABAEIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAACIAAAqQAAAGgGAAg");
	this.shape_47.setTransform(426.35,499.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAAAIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBQABgEAFAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIAAAqQAAAGgGAAg");
	this.shape_48.setTransform(378.625,499.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#63717F").s().p("AjoApQgEAAAAgFIAFgrIABgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBQACgEAEAAIG6AAQADAAACAEIAAAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAACIABAAIAAACIAAAAIAAACIABACIgEArQAAAFgFAAg");
	this.shape_49.setTransform(330.1,499.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#63717F").s().p("AjnApQgFAAABgFIAFgrIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAFAAIG6AAQAEAAABAEIAAABIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABACIgGArQgBAFgFAAg");
	this.shape_50.setTransform(282.4423,499.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBQABgEAFAAIG9AAQAEAAABAEIAAABIAAAAIAAACIABAAIAAADIAAABIAAACIABAAIAAABIAAABIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAADIgJArQgBAFgGAAg");
	this.shape_51.setTransform(234.6429,499.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#63717F").s().p("AjfApQgFAAAAgDIAAgBIAAAAIAAgBIgBgBIAAAAIAAgBIAAgBIgBgBIAAgBIAAgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIgBgBIAAgDIAMgrQACgFAFAAIG6AAQADAAAAAEIABAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIAAAAIAAADIgLArQgBAFgGAAg");
	this.shape_52.setTransform(186.95,499.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#63717F").s().p("AoCAnQAAAAgBAAQAAgBgBAAQAAAAgBgBQAAAAAAgBIAAAAIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIAQgrQADgGAFAAIP2AAQAEAAAAADIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAADIgNArQgBAGgGAAg");
	this.shape_53.setTransform(110.525,498.875);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#ACB6BF").s().p("Am+AbQgFAAgBgFIgKgrQgBgFAGAAIN4AAQAFAAADAFIAXAsQADAEgGAAg");
	this.shape_54.setTransform(722.1314,491.825);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#ACB6BF").s().p("AjYAbQgGAAgBgFIgGgrQAAAAAAgBQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQAAAAABAAIG2AAQAGAAABAFIAJArQABAFgGAAg");
	this.shape_55.setTransform(651.4014,491.825);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#ACB6BF").s().p("AjYAbQgFAAgBgFIgHgrQgBgFAGAAIG3AAQAFAAABAFIAJArQABAFgGAAg");
	this.shape_56.setTransform(603.9323,491.825);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#ACB6BF").s().p("AjcAbQgGAAAAgFIgDgrQAAgFAGAAIG5AAQAGAAABAFIAEArQABAFgGAAg");
	this.shape_57.setTransform(556.2571,491.825);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIAAgrQAAgFAFAAIG4AAQAFAAABAFIAEArQAAAFgFAAg");
	this.shape_58.setTransform(508.7,491.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#ACB6BF").s().p("AjdAbQgGAAAAgFIgBgrQAAgFAGAAIG6AAQAGAAAAAFIADArQAAAFgFAAg");
	this.shape_59.setTransform(461.175,491.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#ACB6BF").s().p("AjeAbQgGAAABgFIACgrQABgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_60.setTransform(413.3929,491.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#ACB6BF").s().p("AjeAbQgFAAAAgFIADgrQAAgFAFAAIG6AAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_61.setTransform(365.525,491.8);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQAAgFAGAAIG5AAQAGAAAAAFIgDArQgBAFgGAAg");
	this.shape_62.setTransform(318.15,491.8);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#ACB6BF").s().p("AjgAbQgFAAAAgFIAGgrQABgFAFAAIG6AAQAGAAgCAFIgFArQgBAFgFAAg");
	this.shape_63.setTransform(270.2,491.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#ACB6BF").s().p("AjiAbQgGAAABgFIAHgrQABgFAFAAIG9AAQAGAAgBAFIgKArQgBAFgFAAg");
	this.shape_64.setTransform(222.6255,491.8);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#ACB6BF").s().p("AjkAbQgFAAABgFIAMgrQACgFAFAAIG5AAQABAAABAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABAAAAQABABAAAAQAAABAAAAQAAABgBAAIgLArQgCAFgFAAg");
	this.shape_65.setTransform(174.8117,491.8);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#ACB6BF").s().p("AnAAbQgGAAACgFIAQgsQACgEAGAAINtAAQAAAAABAAQABAAAAAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIgNArQgCAFgFAAg");
	this.shape_66.setTransform(105.5183,491.8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#63717F").s().p("AnDApQgGAAgBgGIgJgqQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBQABgDAEAAIN4AAQAFAAABAGIAbAqQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAABIAAABIgBAAQgBADgDAAg");
	this.shape_67.setTransform(721.725,493.2);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#63717F").s().p("AjeApQgEAAgBgGIgHgqQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAgBIAAAAIAAgBIAAgBIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAAAIAAAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAQABgDAEAAIG2AAQAGAAAAAGIAJAqIAAAEIAAAAIgBABIAAAAIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAIgBABIAAABQgBACgDAAg");
	this.shape_68.setTransform(650.85,493.2);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#63717F").s().p("AjdApQgFAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABgBQABgDADAAIG3AAQAGAAABAGIAIAqQABABAAAAQAAAAAAABQAAAAAAAAQAAAAgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABQgBADgDAAg");
	this.shape_69.setTransform(603.475,493.2);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#63717F").s().p("AjkArQgFgBAAgFIgDguIABAAIAAgBIAAgBIAAgCIABAAIAAgDIAAAAIAAgCIABgBIAAgBIAAAAIAAgDIABAAIAAgCIAAgBIAAgCIABAAIAAgBIAAgBIAAgCIABgBIAAgCIAAAAIAAgBIABgBQAAgFAFAAIG5AAQAFAAABAFIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIAFArQABAGgGAAg");
	this.shape_70.setTransform(556.3571,493.35);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#63717F").s().p("AjnArQgGAAAAgGIAAgqIABgDIAAAAIAAAAIAAgCIABAAIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAgBIAAAAIABgBIAAgBIAAAAIAAAAIABgBIAAgBQACgEADAAIG4AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAADIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAAAIABACIAEAqQAAAGgFAAg");
	this.shape_71.setTransform(508.525,493.35);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#63717F").s().p("AjkApQgFAAgCgFIAAgtIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAAAIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgBIABAAQABgFAEAAIG7AAQAEAAACAFIAAABIAAAAIAAABIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABABIAAABIAAABIADAsQAAAFgFAAg");
	this.shape_72.setTransform(461.15,493.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#63717F").s().p("AjmApQgFAAAAgFIACgrIABgBIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAEAAIG7AAQAEAAABAFIAAAAIAAAAIAAABIABABIAAABIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIABAAIAAACIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIAAABIAAABIABAAIAAAtQAAAFgGAAg");
	this.shape_73.setTransform(413.4,493.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#63717F").s().p("AjmApQgGAAABgFIADgsIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBQABgFAEAAIG6AAQAEAAABAFIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAArQAAAFgGAAg");
	this.shape_74.setTransform(365.5179,493.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#63717F").s().p("AjnApQgGAAABgFIAFgrIABgBIAAgBIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAAAQABgFAFAAIG6AAQAEAAABAEIAAABIAAABIABAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAACIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAABIABACIgEArQAAAFgGAAg");
	this.shape_75.setTransform(318.0429,493.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#63717F").s().p("AjmApQgGAAABgFIAFgrIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgBQACgFAEAAIG6AAQAEAAABAEIAAABIAAAAIAAABIABABIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABABIAAABIAAAAIAAACIABABIAAACIAAABIAAACIABAAIAAACIgGArQAAAFgGAAg");
	this.shape_76.setTransform(270.0929,493.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#63717F").s().p("AjoApQgGAAABgFIAHgrIAAgBIAAgBIAAgBIABAAIAAgDIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBQACgFAEAAIG9AAQAEAAABAEIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAADIAAACIgJArQgBAFgGAAg");
	this.shape_77.setTransform(222.5423,493.15);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#63717F").s().p("AjgApQgBAAAAAAQgBAAAAgBQgBAAAAgBQAAAAAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgBIgBAAIAAgCIAAAAIAAgBIgBgBIAAgCIAAAAIAAgBIAAgBIAAgCIALgrQACgGAFAAIG5AAQAEAAABAEIAAAAIAAABIABABIAAAAIAAABIAAABIABAAIAAACIAAABIAAABIABABIAAABIAAAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAABIAAADIgLArQgCAFgFAAg");
	this.shape_78.setTransform(175.2,493.15);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#63717F").s().p("Am9AnQgBAAgBAAQAAgBgBAAQAAAAAAgBQgBAAAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIAAgDIAQgsQACgFAFAAINtAAQABAAABAAQAAABABAAQAAAAABABQAAAAAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAABQAAABAAAAQAAAAAAABQAAAAAAABQAAAAAAAAIgNArQgBAGgGAAg");
	this.shape_79.setTransform(105.8625,492.925);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#ACB6BF").s().p("Aj9AcQgEAAgCgGIgNgrQgCgGAGAAIIIAAQAEABACAEIAPAsQACAGgGAAg");
	this.shape_80.setTransform(739.45,486);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#ACB6BF").s().p("AjWAcQgGAAgBgGIgKgrQAAgGAFAAIG6AAQAFAAACAGIAJArQABAGgGAAg");
	this.shape_81.setTransform(687.9,486);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgFAAg");
	this.shape_82.setTransform(640.1,486);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#ACB6BF").s().p("AjYAcQgFAAgBgGIgHgrQgBgGAGAAIG3AAQAFAAABAGIAJArQABAGgGAAg");
	this.shape_83.setTransform(592.125,486);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#ACB6BF").s().p("AjcAcQgGAAAAgGIgCgrQgBgGAGAAIG6AAQAFAAABAGIAEArQABAGgFAAg");
	this.shape_84.setTransform(544.2255,486);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIAAgrQAAgGAFAAIG4AAQAFAAABAGIAEArQABAGgGAAg");
	this.shape_85.setTransform(496.7071,486);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#ACB6BF").s().p("AjdAcQgGAAAAgGIgBgrQAAgGAGAAIG6AAQAFAAABAGIADArQAAAGgGAAg");
	this.shape_86.setTransform(448.775,486);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAFAAIG7AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_87.setTransform(400.725,486);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#ACB6BF").s().p("AjeAcQgFAAAAgGIACgrQAAgGAHAAIG5AAQAFAAAAAGIAAArQAAAGgFAAg");
	this.shape_88.setTransform(352.85,486);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#ACB6BF").s().p("AjgAcQgGAAABgGIAGgrQABgGAFAAIG6AAQAFAAAAAGIgEArQAAAGgFAAg");
	this.shape_89.setTransform(305.0173,486);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#ACB6BF").s().p("AjgAcQgFAAAAgGIAGgrQABgGAFAAIG6AAQAGAAgCAGIgFArQgBAGgFAAg");
	this.shape_90.setTransform(257.25,486);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#ACB6BF").s().p("AjiAcQgGAAACgGIAFgrQABgGAGAAIG9AAQAFAAgBAGIgJArQgBAGgGAAg");
	this.shape_91.setTransform(209.5,486);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#ACB6BF").s().p("AjjAcQgGAAABgGIAMgrQABgGAGAAIG5AAQAGAAgBAGIgMArQgBAGgGAAg");
	this.shape_92.setTransform(161.675,486);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#ACB6BF").s().p("AlyAcQAAAAgBgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQAAAAgBgBQAAAAAAgBQAAAAAAgBQAAgBAAAAIARgsQACgEAFgBILQAAQABAAABABQAAAAABAAQAAAAAAAAQABABAAAAQAAAAAAABQABAAAAABQAAAAAAABQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_93.setTransform(99.5617,486);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#63717F").s().p("AkAAsQgHAAAAgGIgOgrIAAgDIABgBIAAgBIAAAAIAAgCIABAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBQABgEAEAAIIIAAQAEAAACAFIAPAsQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIAAABIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAACIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAABIAAABIgBABIAAABIAAABIAAABIgBABIAAABIAAABIAAABQgBADgDAAg");
	this.shape_94.setTransform(739.05,487.625);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#63717F").s().p("AjbApQgGAAgBgFIgJgrQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBQABgDAEAAIG6AAQAFAAACAGIAIAqIAAADIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAABIAAAAQgBADgEAAg");
	this.shape_95.setTransform(687.425,487.35);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#63717F").s().p("AjdApQgGAAgBgGIgHgqIABgDIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQAAgDAEAAIG3AAQAGAAABAGIAJAqIgBAEIAAAAIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBABIAAAAIAAABIAAABIAAAAIAAABIgBAAIAAAAIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABQAAAAgBABQAAAAAAAAQgBABgBAAQAAAAgBAAg");
	this.shape_96.setTransform(639.55,487.35);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#63717F").s().p("AjcApQgGAAgBgGIgHgqIABgDIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAAAIAAgCIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBQABgDAEAAIG3AAQAFAAABAGIAIAqIAAAEIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBABIAAABIAAAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABQAAADgEAAg");
	this.shape_97.setTransform(591.65,487.35);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#63717F").s().p("AjjArQgGAAAAgGIgDgtIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAgBIAAgCIABAAIAAAAQAAgFAFAAIG6AAQAEAAABAFIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAEArQABAGgGAAg");
	this.shape_98.setTransform(544.3071,487.525);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#63717F").s().p("AjnArQgGAAAAgFIAAgrIABgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBQABgDAEAAIG4AAQAEAAACAEIAAACIAAABIAAACIABAAIAAABIAAABIAAABIABABIAAACIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABABIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAACIAAABIAAABIABAAIAEAsQABAFgGAAg");
	this.shape_99.setTransform(496.5321,487.55);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#63717F").s().p("AjlApQgFAAAAgGIgBgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIG7AAQAEAAABAEIABABIAAACIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABIABACIACAqQAAAGgFAAg");
	this.shape_100.setTransform(448.725,487.35);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#63717F").s().p("AjmApQgGAAABgGIACgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBQABgEAEAAIG7AAQAEAAABAEIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAAsQAAAGgGAAg");
	this.shape_101.setTransform(400.7179,487.35);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#63717F").s().p("AjmApQgFAAAAgGIADgqIAAgCIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG5AAQAEAAABAEIAAABIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAADIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAAsQAAAGgGAAg");
	this.shape_102.setTransform(352.825,487.35);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#63717F").s().p("AjoApQgFAAABgGIAFgqIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgCQACgEAEAAIG6AAQADAAACADIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAABIABAAIAAACIAAABIAAACIgDAqQgBAGgFAAg");
	this.shape_103.setTransform(304.9173,487.35);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#63717F").s().p("AjmApQgGAAABgGIAFgqIABgCIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgCQACgEAEAAIG6AAQAEAAABADIAAABIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABAAIAAABIAAABIAAACIABAAIAAADIgGAqQAAAGgGAAg");
	this.shape_104.setTransform(257.1429,487.35);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#63717F").s().p("AjoApQgGAAABgGIAHgqIAAgCIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgCIAAAAIAAgDIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCQABgEAFAAIG9AAQAEAAABADIAAACIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAADIAAAAIAAACIABAAIAAACIAAABIAAADIgJArQgBAFgGAAg");
	this.shape_105.setTransform(209.3929,487.35);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#63717F").s().p("AjfApQgEAAgBgDIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgCIgBAAIAAgDIAMgqQABgGAGAAIG5AAQAEAAABADIAAABIAAAAIAAACIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAABIAAABIABAAIAAABIAAAAIAAACQAAABABAAQAAAAAAAAQAAABAAAAQgBAAAAABIgLArQgBAFgGAAg");
	this.shape_106.setTransform(162.075,487.35);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#63717F").s().p("AluAnQgBAAgBAAQgBgBAAAAQgBAAAAgBQAAAAgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgDIAQgsQACgFAGAAILQAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAACIAAAAIAAACIABAAIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABABIAAABIAAAAIAAABQABAAAAABQAAAAAAAAQAAABAAAAQAAABgBAAIgMArQgCAGgFAAg");
	this.shape_107.setTransform(99.9,487.125);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#ACB6BF").s().p("AoJAbQgFAAgBgFIgIgrQgBgFAGAAIQXAAQAGAAABAFIALArQABABAAAAQAAABAAAAQAAABgBAAQAAAAAAABQAAAAgBAAQAAABAAAAQgBAAAAAAQgBAAgBAAg");
	this.shape_108.setTransform(711.0623,480.325);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#63717F").s().p("AoNApQgFAAgBgFIgHgrQAAgBgBAAQAAAAAAAAQAAgBAAAAQABAAAAAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBQAAgEAEAAIQYAAQAFAAACAFIALAsIAAADIgBAAIAAABIAAAAIAAABIgBABIAAACIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAABQgBADgEAAg");
	this.shape_109.setTransform(710.625,481.7);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#ACB6BF").s().p("AjOAbQgFAAgBgFIgHgrQgBgFAFAAIGnAAQAFAAABAFIAHArQAAAFgFAAg");
	this.shape_110.setTransform(633.9923,480.325);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#63717F").s().p("AjQApQgGAAgBgFIgHgrQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgDIABAAIAAgDIABAAIAAgCIAAgBIAAgDIABAAIAAgDIAAAAIAAgCIABAAIAAgEIAAAAIAAgCIABgBIAAgCIAAgBIAAAAQABgEADAAIGnAAQAFAAABAGIAHAqIAAADIAAABIgBABIAAACIAAABIAAADIgBABIAAACIAAAAIAAACIgBABIAAADIAAABIAAACIgBAAIAAACIgBACIAAACIAAABQAAADgEAAg");
	this.shape_111.setTransform(633.75,481.7);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_112.setTransform(588.3505,480.325);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#63717F").s().p("AjSApQgFAAgBgFIgGgrIAAgCIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBQABgEAEAAIGmAAQAGAAABAGIAEAqIAAADIAAABIAAAAIgBABIAAABIAAABIAAACIgBAAIAAACIAAAAIAAABIgBAAIAAACIAAAAIAAACIgBAAIAAACIAAAAIAAACIgBABIAAAAIAAABIAAABIgBABIAAABIAAAAIAAADIgBAAIAAACQgBADgEAAg");
	this.shape_113.setTransform(587.975,481.7);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#ACB6BF").s().p("AjPAbQgFAAgBgFIgGgrQgBgFAGAAIGmAAQAGAAABAFIAEArQABAFgFAAg");
	this.shape_114.setTransform(543.0505,480.325);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#63717F").s().p("AjTAmQgFAAgBgFIgFgrIAAgDIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAGAAABAFIAEArIAAACIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAABIAAABIAAABQgBADgEAAg");
	this.shape_115.setTransform(542.675,481.425);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#ACB6BF").s().p("AjRAbQgFAAAAgFIgDgrQgBgFAGAAIGnAAQAFAAAAAFIACArQAAAFgFAAg");
	this.shape_116.setTransform(497.0929,480.325);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#63717F").s().p("AjXAmQgGAAAAgFIgCguIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBQABgDAEAAIGmAAQAFAAABAEIAAABIABABIAAACIAAAAIAAACIAAABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIADAtQAAAFgGAAg");
	this.shape_117.setTransform(496.9,481.425);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#ACB6BF").s().p("AjRAbQgFAAgBgFIgCgrQAAgFAFAAIGpAAQAFAAAAAFIAAArQAAAFgFAAg");
	this.shape_118.setTransform(451.475,480.325);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#63717F").s().p("AjVApQgGAAAAgFIgDgrIABgBIAAgDIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgCIAAAAIAAgBIABgBIAAgBIAAgBIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgCQABgEAEAAIGpAAQAFAAAAAGIAAADIABAAIAAAFIAAAAIAAAFIABAAIAAAFIAAABIAAADIABABIAAAvQAAAFgGAAg");
	this.shape_119.setTransform(451.275,481.7);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#ACB6BF").s().p("AjSAbQgGAAABgFIACgrQAAgFAGAAIGiAAQAGAAAAAFIAAArQAAAFgGAAg");
	this.shape_120.setTransform(405.7929,480.325);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#63717F").s().p("AjZApQgFAAAAgFIADgtIAAAAIAAgCIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIABAAIAAgBQABgFAEAAIGjAAQAFAAAAAFIAAABIABABIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAADIABAAIAAADIAAAAIAAACIABABIAAABIAAABIAAACIAAAAIAAADIABABIAAArQAAAFgGAAg");
	this.shape_121.setTransform(405.7,481.7);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#ACB6BF").s().p("AjUAbQgFAAAAgFIACgrQABgFAFAAIGmAAQAFAAAAAFIgDArQAAAFgGAAg");
	this.shape_122.setTransform(360.275,480.325);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#63717F").s().p("AjaApQgGAAAAgFIACgrIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgFAEAAIGnAAQAEAAABAFIAAABIAAABIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAABIAAAEIABAAIAAADIAAAAIAAAEIABABIgDArQgBAFgFAAg");
	this.shape_123.setTransform(360.025,481.7);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#ACB6BF").s().p("AjVAbQgFAAABgFIADgrQABgFAGAAIGlAAQAFAAgBAFIgDArQgBAFgFAAg");
	this.shape_124.setTransform(314.6,480.325);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#63717F").s().p("AjdApQgGAAABgFIAEgrIAAgBIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgBIAAAAIAAgCIABAAIAAgCIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgBIABgBIAAgBQACgFAEAAIGlAAQAEAAABAEIAAAAIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAACIAAACIgEArQAAAFgGAAg");
	this.shape_125.setTransform(314.7679,481.7);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#ACB6BF").s().p("AjVAbQgGAAABgFIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_126.setTransform(268.7745,480.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#63717F").s().p("AjeApQgHAAACgFIAIgrIABgBIAAgBIAAgBIAAgBIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAAAQACgFAEAAIGhAAQAEAAABAEIAAAAIABABIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABABIAAABIAAABIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAACIABACIgFArQAAAFgGAAg");
	this.shape_127.setTransform(268.8015,481.7);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#ACB6BF").s().p("AjVAbQgBAAAAAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAAAIAIgrQABgFAGAAIGhAAQAGAAgBAFIgFArQgBAFgFAAg");
	this.shape_128.setTransform(223.2259,480.325);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#63717F").s().p("AjRApQgDAAgCgDIAAgBIAAAAIAAgCIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAgBIAAgBIgBAAIAAgCIAAgBIAAgBIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBAAIAAgBQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIAIgrQACgFAFAAIGhAAQADAAACAEIAAABIABAAIAAACIAAAAIAAABIAAAAIAAACIABAAIAAABIAAABIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABABIAAABIABAAIAAABIAAAAIAAACIABAAIAAACIAAAAIAAADIgFArQgBAFgEAAg");
	this.shape_129.setTransform(223.6,481.7);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#ACB6BF").s().p("AjYAbQAAAAgBAAQAAAAgBAAQAAAAAAgBQgBAAAAAAQAAgBgBAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIAMgrQACgFAFAAIGhAAQAGAAgBAFIgJArQgCAFgFAAg");
	this.shape_130.setTransform(177.5744,480.325);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#63717F").s().p("AjUApQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBIAAAAIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBgBIAAgBIAAAAIAAgCIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgCIAAAAIAAgBIgBgBIAAgBIAAAAIAAAAIAAgDIAMgsQABgFAGAAIGhAAQAEAAAAADIAAABIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAACIAAABIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAACIAAAAIAAABIABAAIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAABIgJArQgBAFgFAAg");
	this.shape_131.setTransform(178.0125,481.7);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#ACB6BF").s().p("AjaAbQgFAAACgFIAPgrQABgFAGAAIGhAAQAGAAgCAFIgLArQgCAFgFAAg");
	this.shape_132.setTransform(132.1238,480.325);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#63717F").s().p("AjYApQgDAAgBgDIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgEIgBAAIAAgDIAAAAIAAgDIgBAAIAAgEIAAAAIAAgCIgBgBIAAAAIABgCIAPgsQABgFAGAAIGhAAQAEAAABAEIAAADIAAAAIAAACIABABIAAADIAAAAIAAADIABAAIAAADIAAABIAAADIABAAIAAADIAAAAIAAADIABAAIAAAEIgMArQgBAFgGAAg");
	this.shape_133.setTransform(132.325,481.7);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#ACB6BF").s().p("AjYAbQgFAAABgFIAQgrQACgFAGAAIGdAAQAFAAgBAFIgNArQgBAFgGAAg");
	this.shape_134.setTransform(86.291,480.325);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#63717F").s().p("AjSApQAAAAgBAAQgBAAAAgBQAAAAgBAAQAAgBAAgBIgBAAIAAAAIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAgBIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAgBIAAAAIAAAAIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgCIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIAAgDIAQgsQABgFAGAAIGeAAQAAAAABAAQAAAAABABQAAAAABAAQAAABAAAAIABAAIAAACIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAABIAAAAIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAEIgNArQgCAFgFAAg");
	this.shape_135.setTransform(86.9375,481.7);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#ACB6BF").s().p("AjpAQQgFAAABgFIAHgVQACgFAFAAIHIAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_136.setTransform(90.1744,475.225);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#63717F").s().p("AjiAfQAAAAgBAAQAAAAgBgBQAAAAgBAAQAAgBAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBgBIAAAAIAAAAIAAgBIgBgBIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAgBIAAAAIAAAAIgBgBIAAAAIAAgBIAAAAIgBAAIAAgBIAAgBIAAgBIgBAAIAAgBIAAAAIAAgBIgBAAIAAAAIAAgCIAHgXQACgFAFAAIHIAAQADAAABADIAAAAIABAAIAAABIAAAAIAAABIABABIAAAAIABACIAAABIAAAAIAAABIABAAIAAABIAAAAIAAAAIABABIAAABIABAAIAAABIAAAAIAAABIABACIAAABIABAAIAAABIAAAAIAAABIABAAIAAAAIABABIAAABIAAAAIAAABIABAAIAAABIABACIAAAAIAAABIAAABIABAAIAAABIAAAAIAAAAIABABIAAAAQABABAAAAQAAABAAAAQAAAAAAABQAAAAAAABIgEAVQgBAGgFAAg");
	this.shape_137.setTransform(90.92,476.7);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#ACB6BF").s().p("AjjAQQgFAAgCgFIgFgVQgBgFAFAAIHPAAQAFAAACAFIAFAVQAAABAAAAQABABAAAAQgBABAAAAQAAAAAAABQgBAAAAAAQAAABgBAAQAAAAgBAAQAAAAgBAAg");
	this.shape_138.setTransform(739.2367,475.225);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#63717F").s().p("AjpAhQgFAAgCgGIgFgWIAAgDIAAgBIABAAIAAgBIAAAAIAAAAIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABAAIAAgBQAAgBABAAQAAgBABAAQAAAAABgBQAAAAABAAIHPAAQAFAAACAGIAGAWIAAADIgBAAIAAABIgBAAIAAAAIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABQgBADgDAAg");
	this.shape_139.setTransform(738.6,476.875);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHPAAQAFAAABAFIADAVQABAFgFAAg");
	this.shape_140.setTransform(689.1255,475.225);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#63717F").s().p("AjqAhQgFAAgBgGIgEgWIAAgCIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAQAAgEAEAAIHPAAQAFAAABAGIAEAVIAAADIgBAAIAAABIAAABIAAAAIgBAAIAAABIAAABIAAABIgBAAIAAACIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBABIAAABIAAAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAAAQgCAEgDAAg");
	this.shape_141.setTransform(688.6,476.875);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAGAAIHOAAQAGAAABAFIADAVQABAFgFAAg");
	this.shape_142.setTransform(639.3255,475.225);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#63717F").s().p("AjqAfQgFAAgBgFIgDgWQgBgBAAAAQAAAAAAAAQAAAAAAgBQAAAAABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAQABgDADAAIHPAAQAFAAABAFIAEAWIAAACIgBABIAAAAIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAACIgBAAIAAABIAAAAIAAABIgBAAIAAACIAAAAIAAABIgBAAIAAABIAAABIAAABIgBAAIAAABIAAAAIAAABQgBADgEAAg");
	this.shape_143.setTransform(638.775,476.725);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#ACB6BF").s().p("AjkAQQgGAAgBgFIgDgVQgBgFAFAAIHPAAQAGAAABAFIADAVQABAFgGAAg");
	this.shape_144.setTransform(589.4745,475.225);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#63717F").s().p("AjrAfQgFAAgBgFIgEgWIABgDIAAgBIAAAAIABAAIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBQAAAAAAgBQABAAAAgBQABAAAAAAQABAAABAAIHPAAQAFAAABAFIAEAWIAAAeQAAAEgFAAg");
	this.shape_145.setTransform(588.825,476.725);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#ACB6BF").s().p("AjnAQQgGAAAAgFIAAgVQAAgFAGAAIHPAAQAFAAAAAFIAAAVQAAAFgFAAg");
	this.shape_146.setTransform(539.65,475.225);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#63717F").s().p("AjtAhQgFAAAAgGIAAgWIAAgCIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAdIAAAAIAAANIAAAAIAAALQgBAGgFAAg");
	this.shape_147.setTransform(539.05,476.875);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#ACB6BF").s().p("AjnAQQgFAAAAgFIAAgVQAAgFAFAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_148.setTransform(489.85,475.225);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#63717F").s().p("AjuAhQgFAAAAgGIAAgWIAAgCIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAAAIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAAAQACgEADAAIHPAAQAFAAAAAGIAAAVIAAADIAAAAIgBABIAAAAIAAABIAAAAIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBABIAAAAIAAABIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABIAAABIAAAAIgBABIAAABIAAAAIAAABIgBAAIAAABIAAAAIAAABIgBAAIAAABQgBAEgEAAg");
	this.shape_149.setTransform(489.175,476.875);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#ACB6BF").s().p("AjnAQQgGAAABgFIAAgVQgBgFAGAAIHPAAQAGAAAAAFIAAAVQAAAFgGAAg");
	this.shape_150.setTransform(439.8,475.225);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#63717F").s().p("AjqAeQgGAAAAgFIAAgXIABAAIAAgCIAAAAIAAgBIABgBIAAgCIAAAAIAAgCIABAAIAAgCIAAAAIAAgCIABgBIAAgBIAAgBIAAgBIABAAIAAgCIAAgBIAAgCIABAAIAAgCIAAAAIAAgCIABAAIAAgCQABgEAEgBIHPAAQAGABAAAFIAAAXIgBAAIAAABIAAABIAAACIgBAAIAAABIAAABIAAABIgBABIAAACIAAAAIAAADIgBAAIAAABIAAAAIAAACIgBABIAAACIAAAAIAAACIgBABIAAABIAAAAIAAACIgBAAIAAACQgBAEgEAAg");
	this.shape_151.setTransform(439.475,476.65);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#ACB6BF").s().p("AjoAQQgGAAABgFIADgVQABgFAFAAIHLAAQAFAAABAFIABAVQAAAFgGAAg");
	this.shape_152.setTransform(389.7673,475.225);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#63717F").s().p("Aj0AeQgFAAABgFIADgWIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAAAIAAgBIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBQACgEAEgBIHLAAQAEABABADIAAABIABAAIAAABIAAABIAAAAIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAABIAAAAIABABIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABAAIAAABIAAAAIAAABIABABIAAAAIAAAAIAAABIABADIABAVQAAAFgFAAg");
	this.shape_153.setTransform(389.7673,476.65);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAGgVQACgFAFAAIHLAAQAFAAAAAFIgCAVQAAAFgGAAg");
	this.shape_154.setTransform(339.7089,475.225);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#63717F").s().p("AjyAeQgBAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAIAAgEIAGgWIAAAAIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBQACgGAFAAIHKAAQAEABABADIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAABIAAACIABAAIAAABIAAAAIAAACIABABIAAABIAAABIAAACIABAAIAAACIAAAAIAAACIABAAIAAACIAAAAIAAACIABAAIAAADIgCAVQAAAFgGAAg");
	this.shape_155.setTransform(339.4917,476.65);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#ACB6BF").s().p("AjqAQQgFAAABgFIAHgVQABgFAGAAIHKAAQAGAAgBAFIgCAVQAAAFgGAAg");
	this.shape_156.setTransform(289.9161,475.225);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#63717F").s().p("AjyAeQgFAAABgFIAHgWIAAAAIAAgBIABAAIAAgBIAAgBIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgCIABAAIAAgBIAAgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAQABgGAGAAIHKAAQAFABAAAEIAAABIAAAAIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAABIAAACIABAAIAAADIAAAAIAAADIABAAIAAACIAAAAIAAACIABABIAAACIAAAAIAAACIgCAVQgBAFgFAAg");
	this.shape_157.setTransform(289.6417,476.65);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#ACB6BF").s().p("AjrAQQgFAAACgFIAHgVQACgFAGAAIHKAAQAGAAgBAFIgEAVQgBAFgFAAg");
	this.shape_158.setTransform(240.0398,475.225);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#63717F").s().p("Aj3AeQAAAAgBAAQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQAAAAABgBIAIgWIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIABgBIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAAAIABgBIAAAAIAAgBIAAAAIABgBIAAAAIAAAAIAAgBIABAAIAAgCIAAAAIAAgBIABgBIAAAAIABgBIAAgBIAAAAIAAAAIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAgBIAAAAIAAgBIABgBIAAgBIABAAIAAgBIAAAAIAAgBIABAAIAAAAIAAgBQACgEAFgBIHKAAQAEABABADIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAAAIAAABIABABIAAACIAAAAIAAABIABAAIAAABIAAABIAAABIABAAIAAABIAAABIAAACIABAAIAAABIAAAAIAAACIABAAIAAABIAAAAIAAABIABABIAAABIAAABIAAAAIABABIAAACIgEAWQgBAFgFAAg");
	this.shape_159.setTransform(239.6917,476.65);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#ACB6BF").s().p("AjrAQQgFAAABgFIAIgVQACgFAGAAIHKAAQAFAAAAAFIgEAVQgBAFgFAAg");
	this.shape_160.setTransform(190.3089,475.225);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#63717F").s().p("AjuAeQgEAAAAgDIAAgdIAIgWQACgGAGAAIHKAAQAEABAAADIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAADIABAAIAAACIAAAAIAAACIABAAIAAADIAAAAIAAACIABABIAAACIAAAAIAAACIABAAIAAACIAAAAIAAABQAAAAABAAQAAABAAAAQAAAAAAAAQgBABAAAAIgDAWQgBAFgFAAg");
	this.shape_161.setTransform(190.625,476.65);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#ACB6BF").s().p("AjoAQQgGAAACgFIAGgVQACgFAGAAIHHAAQABAAAAAAQABAAAAAAQABAAAAABQABAAAAAAIABAEIgEAVQgBAFgFAAg");
	this.shape_162.setTransform(140.3923,475.225);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#63717F").s().p("AjnAhQgDAAgBgEIAAgEIgBAAIAAgGIAAAAIAAgFIgBgBIAAgFIAAAAIAAgGIgBAAIAAgEQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAHgXQACgFAFAAIHIAAQAFAAAAAFIAAAEIAAABIAAAFIABABIAAAFIAAAAIAAAFIABAAIAAAGIAAAAIAAAFIgDAWQgBAGgGAAg");
	this.shape_163.setTransform(140.525,476.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152},{t:this.shape_151},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134},{t:this.shape_133},{t:this.shape_132},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128},{t:this.shape_127},{t:this.shape_126},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Base
	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#CCD1D6").s().p("Eg9IABfIgOgBQgzgFgygPQhSgYglgqIABhmQAGAJAdAJQA7ASB1AAMB8ngABQBegEAIgTIAEApQABAvgKAhQgCAFgFADQgbAQgqAMQhFAUhZAAg");
	this.shape_164.setTransform(414.7094,544.625);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#BFC5CC").s().p("Eg9/AF6QhygEgrgXQgVgMACgLID9qLQAMgeBbgOQAtgHArgBITOAAUBeOgAEACqAAEQBrADArAeQAWAQAAAOIDwKCQALAdhBANIhEAGg");
	this.shape_165.setTransform(414.5991,502.325);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_165},{t:this.shape_164}]}).wait(1));

	// white screen
	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#000000").s().p("Eg6nAhgMAAAhC+MB1PAAAMAAABC+g");
	this.shape_166.setTransform(415.625,235.1);

	this.timeline.addTween(cjs.Tween.get(this.shape_166).wait(1));

	// Shadow
	this.instance_2 = new lib.Bitmap3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-15.1,450.85,2.603,2.603);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_vector, new cjs.Rectangle(-15.1,0,874.6,583.6), null);


(lib.laptopshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.shadow.cache(-950,-145,1900,290,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Livello_1
	this.shadow = new lib.shadowcache();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(474.9,72.2,1,1,0,0,0,474.9,72.2);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptopshadow_1, new cjs.Rectangle(0,0,950,144.3), null);


(lib.laptop_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.laptop = new lib.laptop_vector();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(0.2,-0.05,0.6058,0.6058,0,0,0,0.3,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_mc, new cjs.Rectangle(-9.1,0,529.8000000000001,353.5), null);


(lib.laptop_ai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.laptop.cache(-560,-555,1120,1110,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgjIATlMAAAgnJMBGRAAAMAAAAnJg");
	mask.setTransform(251.125,140.375);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgmMAW0MAAAgtnMBMZAAAMAAAAtng");
	this.shape.setTransform(252.5,140.075);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.laptop = new lib.laptop_mc();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(156.3,106.5,1,1,0,0,0,156.3,106.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop_ai, new cjs.Rectangle(-9.1,0,529.8000000000001,353.5), null);


(lib.grey_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bg_page();
	this.instance.parent = this;
	this.instance.setTransform(264.95,123.05,1,1,0,0,0,177.7,99.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E6E6E6").s().p("Egi2ATRMAAAgmhMBFtAAAMAAAAmhg");
	this.shape.setTransform(223.075,123.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.grey_bg, new cjs.Rectangle(0,0,446.2,246.6), null);


(lib.box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.box.cache(-186,-105,372,210,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.box = new lib.box_w();
	this.box.name = "box";
	this.box.parent = this;
	this.box.setTransform(92.2,52.1,1,1,0,0,0,92.2,52.1);

	this.timeline.addTween(cjs.Tween.get(this.box).wait(1));

}).prototype = getMCSymbolPrototype(lib.box, new cjs.Rectangle(0,0,184.3,104.3), null);


(lib.bar_top = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.menus.cache(-1367,-70,2734,140,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.menus = new lib.menus();
	this.menus.name = "menus";
	this.menus.parent = this;
	this.menus.setTransform(683,34.5,1,1,0,0,0,683,34.5);

	this.timeline.addTween(cjs.Tween.get(this.menus).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar_top, new cjs.Rectangle(-7,0,1384,80), null);


(lib.Group_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_18();
	this.instance.parent = this;
	this.instance.setTransform(10,10,1,1,0,0,0,10,10);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_6, new cjs.Rectangle(0,0,20,20.1), null);


(lib.Group_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_0();
	this.instance.parent = this;
	this.instance.setTransform(28,20,1,1,0,0,0,28,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_5, new cjs.Rectangle(0,0,56,40), null);


(lib.Group_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_2_1();
	this.instance.parent = this;
	this.instance.setTransform(28,20,1,1,0,0,0,28,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4, new cjs.Rectangle(0,0,56,40), null);


(lib.Group_2_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_16();
	this.instance.parent = this;
	this.instance.setTransform(24,20,1,1,0,0,0,24,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2_0, new cjs.Rectangle(0,0,48,40), null);


(lib.Group_1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_17();
	this.instance.parent = this;
	this.instance.setTransform(28,20,1,1,0,0,0,28,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1_0, new cjs.Rectangle(0,0,56,40), null);


(lib.Group_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_7();
	this.instance.parent = this;
	this.instance.setTransform(1.9,7.8,1,1,0,0,0,1.9,7.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_1, new cjs.Rectangle(0,0,3.9,15.7), null);


(lib.Group_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_13();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_0, new cjs.Rectangle(-0.2,0,11.7,11.5), null);


(lib.ClipGroup_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.instance = new lib.ClipGroup_15();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_14, new cjs.Rectangle(0,0,40,40), null);


(lib.ClipGroup_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Layer_3
	this.instance = new lib.Group_0();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);
	this.instance.alpha = 0.8008;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_12, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag2A3IAAhtIBtAAIAABtg");
	mask.setTransform(5.5,5.5);

	// Layer_3
	this.instance = new lib.ClipGroup_12();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_11, new cjs.Rectangle(0,0,11,11), null);


(lib.ClipGroup_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.instance = new lib.ClipGroup_9();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_8, new cjs.Rectangle(0,0,40,40), null);


(lib.ClipGroup_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.instance = new lib.ClipGroup_6();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_5, new cjs.Rectangle(0,0,40,40), null);


(lib.ClipGroup_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AjHDIIAAmPIGPAAIAAGPg");
	mask.setTransform(20,20);

	// Layer_3
	this.instance = new lib.ClipGroup_4();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_3, new cjs.Rectangle(0,0,40,40), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.slides = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.box();
	this.instance.parent = this;
	this.instance.setTransform(115.1,565.95,1,1,0,0,0,92.3,52.1);

	this.instance_1 = new lib.box();
	this.instance_1.parent = this;
	this.instance_1.setTransform(115.1,441.75,1,1,0,0,0,92.3,52.1);

	this.instance_2 = new lib.box();
	this.instance_2.parent = this;
	this.instance_2.setTransform(114.9,316.55,1,1,0,0,0,92.1,52.1);

	this.instance_3 = new lib.box();
	this.instance_3.parent = this;
	this.instance_3.setTransform(115.3,191.55,1,1,0,0,0,92.1,52.1);

	this.instance_4 = new lib.box();
	this.instance_4.parent = this;
	this.instance_4.setTransform(115.35,65.8,1,1,0,0,0,92.2,52.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#494949").s().p("AgcAxIAAgNQAKAHAMAAQAFAAAEgCIAIgEQADgDACgFQABgEAAgFQAAgKgHgGQgHgFgMAAIgEAAIgFAAIgEABIgEAAIADg0IAwAAIAAAKIglAAIgCAfIAEAAIAFAAQAHAAAHACQAHACAEAEQAFADACAGQACAGAAAHQAAAIgCAGQgDAGgFAFQgEAEgHADQgHACgIAAQgOAAgHgEg");
	this.shape.setTransform(6.175,520.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#A9A9A9").s().p("AhKUtMAAAgpZICVAAMAAAApZgAhAUjICBAAMAAAgpFIiBAAg");
	this.shape_1.setTransform(238.0536,147.5023);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhKUtMAAAgpZICVAAMAAAApZg");
	this.shape_2.setTransform(238.0536,147.5023);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#747677").s().p("AgigRIBFAAIgjAig");
	this.shape_3.setTransform(238.3036,614.6094);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#A9A9A9").s().p("AhKBLIAAiVICVAAIAACVgAhABBICBAAIAAiBIiBAAg");
	this.shape_4.setTransform(238.3536,613.9094);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhKBLIAAiVICVAAIAACVg");
	this.shape_5.setTransform(238.3536,613.9094);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#747677").s().p("AgiASIAigiIAjAig");
	this.shape_6.setTransform(238.1036,6.8501);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#A9A9A9").s().p("AhKBLIAAiVICVAAIAACVgAhABBICBAAIAAiBIiBAAg");
	this.shape_7.setTransform(238.0536,7.5001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhKBLIAAiVICVAAIAACVg");
	this.shape_8.setTransform(238.0536,7.5001);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#DADADA").s().p("EgBKAm7MAAAhN1ICVAAMAAABN1g");
	this.shape_9.setTransform(238.3536,372.4057);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#BEBEBE").s().p("EgAEAwjMAAAhhFIAJAAMAAABhFg");
	this.shape_10.setTransform(249.0538,310.7047);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#494949").s().p("AAMA0IAAgYIgwAAIAAgLIAOgQIANgRIALgSIAJgRIANAAIAABEIANAAIAAALIgNAAIAAAYgAACgQIgJANIgIAKIgIAKIAjAAIAAgzIgKASg");
	this.shape_11.setTransform(5.875,396.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#494949").s().p("AgdAwIAAgMQAKAIAOAAQAFAAAEgCQAEgBADgDQAEgCABgEQACgEAAgEQAAgVgcAAIgJAAIAAgJIAIAAQAZAAAAgTQAAgSgSAAQgMAAgJAHIAAgLQAKgGAOAAQAFAAAFACQAGABAEAEQADADACAFQADAEAAAGQAAAUgVAGIAAABQAFAAAEABQAFACADADQAEAEABAEQACAEAAAGQAAAHgCAGQgDAFgFAEQgFAFgHACQgGACgHAAQgPAAgJgGg");
	this.shape_12.setTransform(5.975,271.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#494949").s().p("AgfA1IAAgFQAAgHABgFQACgFADgEQADgFAGgFIANgKIAJgHIAGgHIADgIIABgIQAAgFgBgDIgEgGQgDgDgEgBQgDgBgDAAIgHABIgHADIgGAEIgFAFIAAgNQAFgFAGgDQAGgCAJAAQAGAAAFACQAGACAEADQAEAEACAFQACAFAAAHQAAAGgBAFIgEAKIgIAHIgKAJIgLAJIgIAHQgDADgBADIgBAIIAzAAIAAAKg");
	this.shape_13.setTransform(6.075,146.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#494949").s().p("AAGA2IAAhaIgEADIgFAEIgHADIgHACIAAgLIAIgDIAJgFIAHgEIAHgGIAEAAIAABrg");
	this.shape_14.setTransform(5.525,20.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.slides, new cjs.Rectangle(0,0,249.6,621.5), null);


(lib.screen_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.grey.cache(-447,-247,894,494,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.grey = new lib.grey_bg();
	this.grey.name = "grey";
	this.grey.parent = this;
	this.grey.setTransform(223.1,123.3,1,1,0,0,0,223.1,123.3);

	this.timeline.addTween(cjs.Tween.get(this.grey).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_bg, new cjs.Rectangle(0,0,446.2,246.6), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(6.05,0.2,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D73601").s().p("AoRCjIAAlFIQjAAIAAFFg");
	this.shape.setTransform(-27.875,-1.225);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-80.9,-17.5,106.10000000000001,32.6), null);


(lib.Group_4_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_11();
	this.instance.parent = this;
	this.instance.setTransform(5.6,5.8,1,1,0,0,0,5.6,5.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_4_0, new cjs.Rectangle(-0.2,0,11.7,11.5), null);


(lib.Group_3_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_14();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_0, new cjs.Rectangle(0,0,40,40), null);


(lib.Group_3_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_3();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_3_1, new cjs.Rectangle(0,0,40,40), null);


(lib.Group_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_5();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group_2, new cjs.Rectangle(0,0,40,40), null);


(lib.Group = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_8();
	this.instance.parent = this;
	this.instance.setTransform(20,20,1,1,0,0,0,20,20);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Group, new cjs.Rectangle(0,0,40,40), null);


(lib.ClipGroup_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EhqtAE7IAAp1MDVbAAAIAAJ1g");
	mask.setTransform(683,31.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAABLQAAgGgCgFQgBgFgFgFQgEgFgFgBQgGgDgGAAQgHAAgFADIgJAGQgGAFgBAFQgCAEAAAHIgKAAIACgLQABgFADgFQACgEAFgEIAJgHQgGgFgDgFQgDgHAAgHQAAgHACgFQACgDAFgGIAJgGQAFgCAHAAQAHAAAHADQAFAEAFAFQADgGAEgFQAEgEAGgDQgGgEgDgHQgDgGAAgHQAAgHACgFQABgDAFgHIAKgFQAEgDAIAAQAHAAAEADQAFACAFADQAFAHACADQACAHAAAFQAAAGgDAHQgEAHgFAEIAJAGQAEAFADAEQACAEACAFIACALIgKAAQAAgGgCgGQgCgDgFgGQgFgEgFgCQgEgCgHAAQgIAAgEACIgKAGQgFAGgBADQgCAFAAAHQAAAFgDAJQgCAFgHAFIAJAHQAFAEABAEQADAFACAFIACALgAglgDQgDACgDACIgFAGIgBAIIABAHIAFAHIAGAEIAIACIAHgCIAHgEIAEgHIACgHIgCgIIgEgGQgDgCgEgCIgHgBIgIABgAAWg+QgDABgEADIgDAGIgCAIIACAIIADAGIAHAFIAIABIAIgBIAGgFIAEgGIACgIIgCgIIgEgGQgDgDgDgBIgIgCIgIACg");
	this.shape.setTransform(1063,42.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgXBUQgKgCgKgGQgLgHgHgHQgHgHgHgLQgGgKgDgLQgCgLAAgMQAAgLACgLQADgLAGgKQAHgLAHgHQAHgHALgHQAKgFAKgDQANgEAKAAQAKAAANAEQAKADALAFQALAHAGAHQAIAHAHALQAFAKADALQAEANgBAJQABAKgEANQgDALgFAKQgHALgIAHQgGAHgLAHQgLAGgKACQgNAEgKAAQgKAAgNgEgAgShDQgIACgJAFQgJAGgFAFQgFAFgGAJQgFAKgCAHQgDAIABAKQgBALADAIQACAHAFAKQAGAJAFAFQAFAFAJAGQAJAFAIACQAIACAKAAQALAAAIgCQAHgCAKgFQAIgGAFgFQAGgFAFgJQAGgKABgHQADgIAAgLQAAgKgDgIQgBgHgGgKQgFgJgGgFQgFgFgIgGQgKgFgHgCQgIgCgLAAQgKAAgIACg");
	this.shape_1.setTransform(172,43.025);

	this.instance = new lib.Group_6();
	this.instance.parent = this;
	this.instance.setTransform(172,43,1,1,0,0,0,10,10);
	this.instance.alpha = 0.5;

	this.instance_1 = new lib.Group_1_0();
	this.instance_1.parent = this;
	this.instance_1.setTransform(172,43,1,1,0,0,0,28,20);
	this.instance_1.alpha = 0;

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgdAyIgyAAIAAiBICfAAIAACBIgyAAIgeAegAhFAoIAsAAIAZAaIAagaIAsAAIAAhtIiLAAg");
	this.shape_2.setTransform(1337,43);

	this.instance_2 = new lib.Group_2_0();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1342,43,1,1,0,0,0,24,20);
	this.instance_2.alpha = 0;

	this.instance_3 = new lib.Group_3_0();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1143,43,1,1,0,0,0,20,20);
	this.instance_3.alpha = 0;

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgJAAQAAgJAJAAQAEAAADADQADADAAADQAAAEgDADQgDADgEAAQgJAAAAgKg");
	this.shape_3.setTransform(1147.5,47.5);

	this.instance_4 = new lib.Group_4_0();
	this.instance_4.parent = this;
	this.instance_4.setTransform(1143.1,43.3,1,1,0,0,0,5.6,5.8);
	this.instance_4.alpha = 0.3984;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").p("AgiAoQAAgfAWgVQAVgWAfAA");
	this.shape_4.setTransform(1144.5,44.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").p("AgTAZQAAgTANgLQANgOASAA");
	this.shape_5.setTransform(1146,46);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.instance,this.instance_1,this.shape_2,this.instance_2,this.instance_3,this.shape_3,this.instance_4,this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.instance_4},{t:this.shape_3},{t:this.instance_3},{t:this.instance_2},{t:this.shape_2},{t:this.instance_1},{t:this.instance},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_10, new cjs.Rectangle(144,23,1222,40), null);


(lib.ClipGroup_1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhqtAE7IAAp1MDVbAAAIAAJ1g");
	mask_1.setTransform(683,31.5);

	// Layer_3
	this.instance = new lib.Group();
	this.instance.parent = this;
	this.instance.setTransform(1183,43,1,1,0,0,0,20,20);
	this.instance.alpha = 0;

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAUA8IgdgeIgUAAIAAg7IAUAAIAdgeIAKAAIAAB3gAgTAUIAOAAIAZAaIAAhbIgWAYIgDACIgOAAg");
	this.shape_4.setTransform(1178,43);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgKAeQALgNAAgRQAAgQgLgNIAHgHQAOAPAAAVQAAAWgOAPg");
	this.shape_5.setTransform(1183.9,43.025);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgOAzQATgVAAgeQAAgdgTgVIAHgHQAWAYAAAhQAAAigWAYg");
	this.shape_6.setTransform(1186.475,43.025);

	this.instance_1 = new lib.Group_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(1189,43,1,1,0,0,0,1.9,7.8);
	this.instance_1.alpha = 0.3984;

	this.instance_2 = new lib.Group_2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(1103,43,1,1,0,0,0,20,20);
	this.instance_2.alpha = 0;

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Ag2AUIAAgnIBtAAIAAAng");
	this.shape_7.setTransform(1102.5,43.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgGAKIAAgTIANAAIAAATg");
	this.shape_8.setTransform(1110.25,43);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhKAoIAAhPICVAAIAABPgAhAAeICBAAIAAg7IiBAAg");
	this.shape_9.setTransform(1102.5,43);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgfBRIgCgEIACgFIADgFQgCgDAAgEIAAgOIABgCIAthcIgFgCIgSAmIgCACIgDABQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAIABgDIASgmIADgEIAFgCIAGABIAFADIAFgLIACgDIADAAIACAAIAEgHIADgDIAEgBQADAAACACIAHADIAEAEIACAFIgBAFIgDAFIACACIABACIAAABIgBACIg5BxIgCACIgNAHIgFABIgCAAIgEAIIgCACIgCABIgEgCgAgUAwIAAAMIABABIACABIABAAIACgCIADgBIAHgEIA1hqIgQgIgAAqhCIAHADIACgFIgHgDgAgtBTQgIAAgGgDQgIgEgEgEQgEgEgEgIQgDgGAAgIQAAgHADgHQADgGAFgFQAFgFAHgDQAGgDAIAAIASAAIgGALIgMAAQgGAAgEACIgJAFQgDADgCAFQgCAFAAAFQAAAGACAEQACAGADADQAEADAFACQAEACAGAAIADAAIgBADIAAAFIABADgAAnAVIAFgLIASAAIAEAAIADgDIACgDIABgEIgBgDIgCgDIgDgDIgEAAQgBAAAAAAQgBAAAAgBQgBAAAAAAQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAAAAABAAQAEAAAEACIAHAEIAEAHQACADAAAEQAAAFgCADIgEAHIgHAEQgEACgEAAg");
	this.shape_10.setTransform(1222.975,43.025);

	this.instance_3 = new lib.Group_3_1();
	this.instance_3.parent = this;
	this.instance_3.setTransform(1223,43,1,1,0,0,0,20,20);
	this.instance_3.alpha = 0;

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgFBQIAAhKIBjAAIAABYgAhdBEIAAg+IBLAAIAABIgAgFgFIAAhKIBjgOIAABYgAhdgFIAAg9IBLgLIAABIg");
	this.shape_11.setTransform(27.375,42.375);

	this.instance_4 = new lib.Group_4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(28,43,1,1,0,0,0,28,20);
	this.instance_4.alpha = 0;

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AhjAAIBchbIAIAJIhMBNICvAAIAAALIivAAIBMBNIgIAJg");
	this.shape_12.setTransform(99.95,42.825);

	this.instance_5 = new lib.Group_5();
	this.instance_5.parent = this;
	this.instance_5.setTransform(100,43,1,1,0,0,0,28,20);
	this.instance_5.alpha = 0;

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("ABABQIAAhLIALAAIAABLgAAVBQIAAgVIhfAAIAAAVIgKAAIAAggIB0AAIAAAggAhUAlIAAhJIB0AAIAABJgAhKAbIBfAAIAAg1IhfAAgAA/gGQgDgBgCgCQgCgCgBgDIgCgGQAAgEACgDIADgFIAFgDIAGgBIAHABIAFADIADAFIABAHIgBAGIgDAFIgFADQgDACgEAAIgGgCgABAgvIAAggIALAAIAAAggAhUgvIAAggIAKAAIAAAVIBfAAIAAgVIALAAIAAAgg");
	this.shape_13.setTransform(243.975,43.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#2D2D2D").s().p("EhqtADIIAAmPMDVbAAAIAAGPg");
	this.shape_14.setTransform(683,43);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#5A5A5A").s().p("AAJAhQgEgFAAgIQAAgKAEgFQAGgFAIAAQAHAAAEAFQAFAFAAAIQAAAJgFAGQgFAFgHAAQgIAAgFgFgAAPAJQgEAEAAAGQAAAGAEAEQACADAFAAQAFAAADgDQADgEAAgGQAAgHgDgDQgDgDgFAAQgFAAgCADgAgbAlIAuhJIAIAAIguBJgAgigEQgEgFAAgIQAAgJAFgGQAEgFAJAAQAHAAAFAFQAEAFAAAJQAAAIgFAGQgFAEgHAAQgIAAgFgEgAgdgcQgCAEAAAGQAAAGACAEQADADAFAAQAFAAADgDQACgEABgGQgBgGgCgEQgDgDgEAAQgGAAgDADg");
	this.shape_15.setTransform(1316.05,10.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#5A5A5A").s().p("AgJAlQgEgCgDgDQgEgCgBgEQgCgFAAgEIABgGIACgGIAFgEIAFgDQgEgCgDgEQgCgFgBgFQABgEABgDIAEgHIAHgDQAEgCADAAQAFAAADACIAHADIAEAHQACADAAAEQAAAFgDAFQgDAEgEACIAFADIAFAEIACAGIABAGQAAAEgCAFQgCAEgDACQgDADgFACQgEABgFAAQgFAAgEgBgAgFACIgFADIgCAFQgCADAAADIACAGIACAFQACACADABIAFAAIAGAAIAFgDIADgFIABgGIgBgGIgDgFQgCgCgDgBIgGgBIgFABgAgEgdIgEADIgDAEIAAAFIABAEIACAFIAFACIADABIAFgBIADgCIADgFIABgEIAAgFIgEgEQAAgBAAAAQgBAAAAgBQgBAAAAAAQgBAAAAgBIgFgBIgEABg");
	this.shape_16.setTransform(1308.95,10.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#5A5A5A").s().p("AgJAkQgEgDgDgEQgDgEgBgHQgCgGAAgIQAAgIACgIQACgIAEgFQAEgGAGgDQAEgDAHAAQAHAAAFACIAAAIQgGgDgGAAQgFAAgDACQgEADgDAEQgDAEgBAFQgBAGAAAGQAFgIAKAAQAFAAAEABQAEACACADQADACACAEQABAEABAFQAAAGgCAEQgCAFgDADQgDADgFACQgEACgFAAQgFAAgEgCgAgEAAIgFACIgDAFIgBAGIABAHIADAGQACACADABIAEACIAHgBIAEgEIADgFIABgHIgBgGIgDgGIgEgCQgDgBgEAAIgEABg");
	this.shape_17.setTransform(1303.35,10.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#7E7C7B").s().p("AgYA4IAAhvIAxAAIAABvg");
	this.shape_18.setTransform(1211.45,10.45);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#6D6E6E").s().p("AgdAKIAAgTIA7AAIAAATg");
	this.shape_19.setTransform(1170.95,11);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#6E6F6F").s().p("AgiAKIAAgTIBFAAIAAATg");
	this.shape_20.setTransform(1285,11);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#6E6F6F").s().p("AgJAjIAAhFIATAAIAABFg");
	this.shape_21.setTransform(1285,11);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#ACADAD").s().p("AgEAZIAAgxIAJAAIAAAxg");
	this.shape_22.setTransform(1228.5,11.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#ACADAD").s().p("AnzAFIAAgJIPnAAIAAAJg");
	this.shape_23.setTransform(1228,11.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#5A5A5A").s().p("AgaANIAagZIAbAZg");
	this.shape_24.setTransform(951.475,6.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#5A5A5A").s().p("AgdAFIAAgJIA7AAIAAAJg");
	this.shape_25.setTransform(949,16.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#5A5A5A").s().p("Ag2AFIAAgJIBtAAIAAAJg");
	this.shape_26.setTransform(951.5,13.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#5A5A5A").s().p("Ag2AFIAAgJIBtAAIAAAJg");
	this.shape_27.setTransform(951.5,10.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#5A5A5A").s().p("AgRAaIAAgKQAHAGAJgBQAKAAAAgHIgBgEIgCgDIgEgCIgEgCIgHgDIgEgCIgDgFIgBgFQAAgEACgCQABgEADgCIAHgDIAHgBQAHAAAGACIAAAJQgGgDgIAAIgEAAIgDACIgCACIgBAEIABADIACACIAEACIAEADIAGACIAFADIADAEIABAGQAAAEgBADIgFAFIgHADIgHABQgJAAgGgDg");
	this.shape_28.setTransform(989.375,12.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#5A5A5A").s().p("AgQAVQgHgHAAgOQAAgMAHgHQAHgJAKAAQAMAAAFAHQAGAHAAANIAAADIgmAAQABAJAEAGQAFAEAHAAQAJAAAIgFIAAAIQgHAFgMAAQgKAAgHgIgAgIgQQgFAFgBAGIAdAAQAAgHgEgEQgDgFgHABQgFgBgEAFg");
	this.shape_29.setTransform(984,12.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#5A5A5A").s().p("AgFAUIAAgfIgKAAIAAgIIAKAAIAAgNIAHgDIAAAQIAOAAIAAAIIgOAAIAAAeQAAAFACADQACACAEAAQADAAADgCIAAAIQgDABgGAAQgMAAAAgQg");
	this.shape_30.setTransform(979,11.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#5A5A5A").s().p("AgTAVQgHgIAAgNQAAgMAHgIQAIgIAMAAQAMAAAHAIQAHAIAAAMQAAANgHAIQgIAIgMAAQgMAAgHgIgAgMgPQgFAGAAAJQAAAKAFAGQAFAFAHAAQAJABAEgGQAFgGAAgKQAAgJgFgGQgEgGgJABQgHAAgFAFg");
	this.shape_31.setTransform(973.725,12.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#5A5A5A").s().p("AAUAmIgmg8IgDgEIAAAAIAAAKIAAA2IgJAAIAAhLIAMAAIAlA7IAEAFIgBgLIAAg1IAJAAIAABLg");
	this.shape_32.setTransform(966.2,11.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#767676").s().p("AgYAPIAAgdIAxAAIAAAdgAgOAFIAdAAIAAgJIgdAAg");
	this.shape_33.setTransform(1031.5,8.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#767676").s().p("AgxAFIAAgJIBjAAIAAAJg");
	this.shape_34.setTransform(1031.6,12.55);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#767676").s().p("AgEA8IAAh3IAJAAIAAB3g");
	this.shape_35.setTransform(1026.5,10.65);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#767676").s().p("AhFBBIAAiBICLAAIAACBgAg7A3IB3AAIAAhtIh3AAg");
	this.shape_36.setTransform(1030,10.5);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#79797A").s().p("AgEATIAAglIAJAAIAAAlg");
	this.shape_37.setTransform(1143.5,14.475);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#79797A").s().p("AgYAFIAAgJIAxAAIAAAJg");
	this.shape_38.setTransform(1143.5,16.5);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#79797A").s().p("AgiAFIAAgJIBFAAIAAAJg");
	this.shape_39.setTransform(1143.45,8.55);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#79797A").s().p("AhAAKIAAgTICBAAIAAATg");
	this.shape_40.setTransform(1143.5,6);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#79797A").s().p("AgrAoQgEAAgEgDQgDgDAAgFIAAg5QAAgEADgEQAEgDAEAAIBXAAQAEAAAEADQADAEAAAEIAAA5QAAAFgDADQgEADgEAAgAgsgcIAAA5QAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAIBXAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAIAAg5IgBgBIhXAAg");
	this.shape_41.setTransform(1143.5,9.025);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_42.setTransform(1105.5,13.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_43.setTransform(1105.5,11.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_44.setTransform(1105.5,9.5);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_45.setTransform(1105.5,7.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_46.setTransform(1108.5,12.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_47.setTransform(1108.5,10.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_48.setTransform(1108.5,8.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_49.setTransform(1108.5,6.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_50.setTransform(1102.5,12.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_51.setTransform(1102.5,10.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_52.setTransform(1102.5,8.5);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#767676").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_53.setTransform(1102.5,6.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#767676").p("AAAg4IAABx");
	this.shape_54.setTransform(1105.5,11.3);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#767676").p("AgdglQAAgKAHgDQAHgDAYAAIAVAAIAABkIggAAQgbgBAAAN");
	this.shape_55.setTransform(1108.5,9.875);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#767676").p("AAeglQAAgKgHgDQgIgDgYAAIgUAAIAABkIAfAAQAcAAAAAM");
	this.shape_56.setTransform(1102.5,9.85);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#79797A").s().p("Ag1BBQgFAAgDgDQgDgEAAgEIAAhrQAAgEADgEQADgDAFAAIBqAAQAFAAAEADQADAEAAAEIAABrQAAAEgDAEQgEADgFAAgAg2g1IAABrIABABIBqAAIACgBIAAhrIgCgBIhqAAg");
	this.shape_57.setTransform(1341.5,10.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#79797A").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_58.setTransform(1341.5,6.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#79797A").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape_59.setTransform(1341.5,7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#79797A").s().p("AgOAFIAAgJIAdAAIAAAJg");
	this.shape_60.setTransform(1341.5,14.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#79797A").s().p("AgEAUIAAgnIAJAAIAAAng");
	this.shape_61.setTransform(1341.5,14);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#79797A").s().p("AgEAPIAAgdIAJAAIAAAdg");
	this.shape_62.setTransform(1345.5,10.5);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#79797A").s().p("AgTAFIAAgJIAnAAIAAAJg");
	this.shape_63.setTransform(1345,10.5);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#79797A").s().p("AgEAPIAAgdIAJAAIAAAdg");
	this.shape_64.setTransform(1337.5,10.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#79797A").s().p("AgTAFIAAgJIAnAAIAAAJg");
	this.shape_65.setTransform(1338,10.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#79797A").s().p("AgdAZIAAgxIA7AAIAAAxgAgTAPIAnAAIAAgdIgnAAg");
	this.shape_66.setTransform(1072,14.55);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#79797A").s().p("AgdAZIAAgxIA7AAIAAAxgAgTAPIAnAAIAAgdIgnAAg");
	this.shape_67.setTransform(1063.95,14.55);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#79797A").s().p("AgdAZIAAgxIA7AAIAAAxgAgTAPIAnAAIAAgdIgnAAg");
	this.shape_68.setTransform(1072,6.55);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#79797A").s().p("AgdAZIAAgxIA7AAIAAAxgAgTAPIAnAAIAAgdIgnAAg");
	this.shape_69.setTransform(1063.95,6.55);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#C8C6C4").s().p("Ai9BuIAAjbIF7AAIAADbg");
	this.shape_70.setTransform(1030,11);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#F2F2F2").s().p("AggAFIgCgDQgCgCAAgCQAAgDADgDIAGgGQADgCACAAIADABIADACIALALIAVgdQADgDADAAQAEAAABACIAHAFIACACIABAEQAAADgCACIgnAzgAgXgIIgFAFIgBABIAAABIACABIAXAYIAigsIAAgBIAAAAIAAgBIgHgFIgBAAIgBABIgaAiIgQgRIgBAAg");
	this.shape_71.setTransform(96.125,9.875);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#767676").s().p("AggAAIAAgBQAAgBAAAAQAAgBAAAAQAAAAABgBQAAAAAAAAIAGgGQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAIABAAIADABIANANIAYgeQAAgBABAAQAAgBAAAAQABAAAAAAQABAAAAAAIACAAIAIAGIABABIAAACIAAADIglAvg");
	this.shape_72.setTransform(96.125,9.775);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#767676").p("AAAg3IAABv");
	this.shape_73.setTransform(91.45,11.4);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#767676").p("AgdgmQAAgRAmAAIAVAAIAABjIgfAAQgLAAgJAGQgIAFAAAF");
	this.shape_74.setTransform(94.45,10.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#767676").p("AAegmQAAgRgmAAIgVAAIAABjIAgAAQAKAAAJAGQAIAFAAAF");
	this.shape_75.setTransform(88.45,10.1);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#545251").s().p("AgJAlQgFgCgDgFQgDgEgCgHQgCgGABgIQAAgKABgHQADgJAEgGQAEgFAGgEQAFgDAHAAQAIAAAFADIAAAIQgHgDgGgBQgFAAgDADQgEACgDAEIgFALQgCAFABAHIAAAAQAFgIAMAAQAFAAAEABIAHAFQADACABAFQABAEAAAFQAAAGgCAFIgEAIQgDADgFACQgEACgGAAQgFAAgEgDgAgEAAIgGACIgDAGQgBACAAAEQAAAEABADIADAGIAGAEQACACADAAQADAAACgCQAEgBACgDIACgFIABgHIgBgHQgBgEgBgCQgCgCgEAAIgFgBIgFABg");
	this.shape_76.setTransform(66.7,9.95);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#545251").s().p("AAEAnIAAhBIgDACIgDADIgFACIgGACIAAgJIAHgCIAGgDIAFgEIAFgDIADAAIAABNg");
	this.shape_77.setTransform(60.25,9.875);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#545251").s().p("AgGApIAAguIgJAAIAAgIIAJAAIAAgJQAAgIAEgFQAFgFAHAAIAGABIAAAIQgCgCgDAAQgKAAABAMIAAAIIAMAAIAAAIIgMAAIAAAug");
	this.shape_78.setTransform(53.2,9.675);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#545251").s().p("AgTAVQgHgHAAgOQAAgMAHgIQAIgIAMAAQAMAAAHAIQAHAIAAAMQAAANgHAIQgIAIgMAAQgMAAgHgIgAgMgOQgFAFAAAJQAAAKAFAFQAFAGAHABQAJAAAEgGQAFgFAAgLQAAgJgFgGQgEgFgJAAQgHgBgFAHg");
	this.shape_79.setTransform(48.025,11.05);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#545251").s().p("AAJAmIAAgSIgjAAIAAgHIAKgNIAKgLIAHgOIAHgMIAJAAIAAAxIAKAAIAAAIIgKAAIAAASgAABgMIgGALIgGAHIgGAGIAaAAIAAglIgIANg");
	this.shape_80.setTransform(38.675,9.95);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#545251").s().p("AgQAWQgHgIAAgOQAAgLAIgJQAGgIALAAQAKAAAGAHQAGAHAAANIAAADIglAAQgBAKAFAEQAFAFAHABQAJgBAJgGIAAAJQgIAFgMAAQgLAAgGgHgAgIgQQgEAEgBAIIAcAAQAAgIgDgEQgEgEgGAAQgGAAgEAEg");
	this.shape_81.setTransform(30.05,11.05);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#545251").s().p("AgSAiQgGgIgBgMQAAgOAIgHQAGgJALABQALAAAGAJIAAgiIAJAAIAABQIgJAAIAAgJQgHALgLgBQgLAAgGgHgAgKgCQgGAFAAALQABAJAEAGQAEAFAHAAQAHAAAFgFQAFgGAAgIIAAgIQAAgHgFgDQgFgFgGAAQgHAAgEAGg");
	this.shape_82.setTransform(23.7,9.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#545251").s().p("AgDAoIAAg2IAHAAIAAA2gAgDgdQAAgBgBAAQAAAAAAgBQgBAAAAgBQAAgBAAAAQAAgBAAAAQAAgBABgBQAAAAAAAAQABgBAAAAQABgBAAAAQABAAAAgBQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABABAAAAQABAAAAABQABAAAAABQAAAAAAAAQABABAAABQAAAAAAABIgCAEQAAAAgBAAQAAABgBAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAgBgBQAAAAgBAAg");
	this.shape_83.setTransform(19.325,9.775);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#545251").s().p("AgDApIAAhRIAHAAIAABRg");
	this.shape_84.setTransform(16.675,9.725);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#545251").s().p("AgHAnIgGgBIgFgBIgEgBIAAgLIAEACIAGADIAFABIAFABQAIgBAEgDQAEgCAAgHIgBgEIgEgFIgGgDIgGgFIgIgCIgGgFIgEgFQgBgEAAgEQAAgGACgDQACgEAEgDQAEgDAFAAIAJgCQALAAAFADIAAAKQgHgFgKABIgFAAIgFACIgEADQgCADAAADIABAFIAEAEIAFADIAGAEIAIADQAEACACAEQADACACADQABAEAAAEQAAAGgCADQgCAFgEACQgEADgFAAQgEACgFAAIgEgBg");
	this.shape_85.setTransform(12.475,9.95);

	var maskedShapeInstanceList = [this.instance,this.shape_4,this.shape_5,this.shape_6,this.instance_1,this.instance_2,this.shape_7,this.shape_8,this.shape_9,this.shape_10,this.instance_3,this.shape_11,this.instance_4,this.shape_12,this.instance_5,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.shape_28,this.shape_29,this.shape_30,this.shape_31,this.shape_32,this.shape_33,this.shape_34,this.shape_35,this.shape_36,this.shape_37,this.shape_38,this.shape_39,this.shape_40,this.shape_41,this.shape_42,this.shape_43,this.shape_44,this.shape_45,this.shape_46,this.shape_47,this.shape_48,this.shape_49,this.shape_50,this.shape_51,this.shape_52,this.shape_53,this.shape_54,this.shape_55,this.shape_56,this.shape_57,this.shape_58,this.shape_59,this.shape_60,this.shape_61,this.shape_62,this.shape_63,this.shape_64,this.shape_65,this.shape_66,this.shape_67,this.shape_68,this.shape_69,this.shape_70,this.shape_71,this.shape_72,this.shape_73,this.shape_74,this.shape_75,this.shape_76,this.shape_77,this.shape_78,this.shape_79,this.shape_80,this.shape_81,this.shape_82,this.shape_83,this.shape_84,this.shape_85];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.instance_5},{t:this.shape_12},{t:this.instance_4},{t:this.shape_11},{t:this.instance_3},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.instance_2},{t:this.instance_1},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1_1, new cjs.Rectangle(0,0,1366,63), null);


(lib.ClipGroup_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EhqtAE7IAAp1MDVbAAAIAAJ1g");
	mask_1.setTransform(683,31.5);

	// Layer_3
	this.instance = new lib.ClipGroup_10();
	this.instance.parent = this;
	this.instance.setTransform(683,31.5,1,1,0,0,0,683,31.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgUApIAAgIQAHAEAHAAQALAAAHgKQAGgKAAgSQgGAMgNAAQgFAAgEgDQgFgBgDgEQgDgDgCgEQgCgFAAgFQAAgHACgFQACgFAEgDQADgFAFgBQAFgCAFAAQAGAAAEACQAFADADAFQAEAEABAHQACAIAAAJQAAALgCAIQgCAKgFAGQgEAGgGADQgGAEgIgBQgHAAgGgCgAgGgiIgGAEQgCADgBADQgCAEAAAFQAAAEACAEQABADACADQACACAEACIAGABIAHgBIAGgEIADgFQACgDAAgEQAAgFgCgEIgDgIIgGgEQgDgCgEAAIgGACg");
	this.shape_13.setTransform(1299.125,51.75);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAGArIAAhKIgEADIgFAEIgFACIgFACIAAgHQAHgCAGgEIAMgJIACAAIAABVg");
	this.shape_14.setTransform(1293.375,51.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgKAoQgFgCgDgFQgEgGgCgHQgCgIAAgKQABgWAHgLQAHgLAMAAQAZAAAAAqQAAAKgBAJQgCAHgEAGQgDAGgFACQgFADgGAAQgGAAgEgDgAgMgbQgGAKAAASQABARAEAKQAFAJAIAAQAEAAAEgDQAEgCACgEQACgFACgHIAAgPQAAglgSAAQgIAAgEAJg");
	this.shape_15.setTransform(1288.4,51.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgYArIAAgEQAAgGACgEQABgEADgEIAHgHIAKgIIAHgGIAFgFIADgGQACgEAAgEQAAgEgCgDIgDgFQgCgCgDgBIgGgBQgGAAgFADQgFACgEAFIAAgJQAEgDAFgDQAGgCAFAAIACAAIACABQAEAAAEACIAGAEQADADABAEQABAEAAAEQAAAGgBAEIgEAIIgGAGIgJAGIgHAHIgGAFIgEAFQgBACAAAEIgBABIAAACIApAAIAAAHg");
	this.shape_16.setTransform(1282.075,51.675);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgXAxIAohhIAHAAIgoBhg");
	this.shape_17.setTransform(1276.675,52.45);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAGArIAAhKIgEADIgFAEIgFACIgFACIAAgHQAHgCAGgEIAMgJIACAAIAABVg");
	this.shape_18.setTransform(1271.825,51.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgXAxIAohhIAHAAIgoBhg");
	this.shape_19.setTransform(1267.625,52.45);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAJAqIAAgVIgmAAIAAgHIALgNIALgOIAIgPIAIgNIAIAAIAAA3IANAAIAAAHIgNAAIAAAVgAABgPIgHAMIgIAJIgHAIIAeAAIAAgrIgIAOg");
	this.shape_20.setTransform(1262.125,51.75);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAhAqIAAg5IABgPIgBAAIgBAFIgBADIgdBAIgCAAIgeg/IgDgJIAAAAIAAAGIAAAJIAAA5IgHAAIAAhTIAJAAIAcA+IADAEIAAAFIABAAIABgEIABgFIAdg+IAJAAIAABTg");
	this.shape_21.setTransform(1298.1,35.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAbAqIgJgZIgjAAIgJAZIgJAAIAghTIAHAAIAgBTgAAAgdIgBADIgOAkIAeAAIgOgkIAAgDIgBgDIAAADg");
	this.shape_22.setTransform(1289.075,35.75);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgKAoQgFgCgDgFQgEgGgCgHQgCgIAAgKQABgVAHgMQAHgLAMAAQAZgBABArQAAAKgCAJQgCAHgEAGQgDAFgFADQgFADgGABQgGgBgEgDgAgNgaQgEAJAAASQAAASAEAJQAFAJAIAAQAFAAADgCQAEgDACgEQACgFACgHIAAgPQAAglgRAAQgIAAgGAKg");
	this.shape_23.setTransform(1278.85,35.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAGArIAAhKIgEADIgFAEIgFACIgFACIAAgHQAHgCAGgEIAMgJIACAAIAABVg");
	this.shape_24.setTransform(1273.075,35.65);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AAAAfIgDgCQgBAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBQAAAAABgBQAAAAAAgBQAAAAABgBQAAAAABAAQAAAAAAgBQABAAABAAQAAAAAAAAIACAAIACABIABADIABACIgBACIgBABIgCACIgCAAgAgBgTIgCgBIgBgDIgBgCQAAAAAAgBQAAAAABgBQAAAAAAgBQAAAAABAAIADgCIACAAIACACIABABIABACIgBACIgBADIgCABIgCAAIgBAAg");
	this.shape_25.setTransform(1269.875,36.95);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgKAoQgFgCgDgFQgEgGgCgHQgCgIAAgKQABgVAHgMQAHgLAMAAQAagBgBArQAAAKgBAJQgCAHgEAGQgDAFgFADQgFADgGABQgFgBgFgDgAgNgaQgFAJAAASQABASAEAJQAFAJAIAAQAFAAADgCQAEgDACgEQACgFABgHIABgPQAAglgSAAQgIAAgFAKg");
	this.shape_26.setTransform(1265.45,35.75);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAGArIAAhKIgEADIgFAEIgFACIgFACIAAgHQAHgCAGgEIAMgJIACAAIAABVg");
	this.shape_27.setTransform(1259.675,35.65);

	this.instance_1 = new lib.ClipGroup_1_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(683,31.5,1,1,0,0,0,683,31.5);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F2F2F2").s().p("EhqtABuIAAjbMDVbAAAIAADbg");
	this.shape_28.setTransform(683,12);

	var maskedShapeInstanceList = [this.instance,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19,this.shape_20,this.shape_21,this.shape_22,this.shape_23,this.shape_24,this.shape_25,this.shape_26,this.shape_27,this.instance_1,this.shape_28];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.instance_1},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup_19, new cjs.Rectangle(0,0,1366,63), null);


(lib.bar2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup_19();
	this.instance.parent = this;
	this.instance.setTransform(683,31.5,1,1,0,0,0,683,31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar2, new cjs.Rectangle(0,0,1366,63), null);


(lib.bar_btm = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.bar.cache(-1367,-64,2734,128,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bar = new lib.bar2();
	this.bar.name = "bar";
	this.bar.parent = this;
	this.bar.setTransform(683,31.5,1,1,0,0,0,683,31.5);

	this.timeline.addTween(cjs.Tween.get(this.bar).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar_btm, new cjs.Rectangle(0,0,1366,63), null);


(lib.screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_245 = function() {
		exportRoot.tl1.play()
	}
	this.frame_260 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(245).call(this.frame_245).wait(15).call(this.frame_260).wait(33));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgixAR2MAAAgjrMBFjAAAMAAAAjrg");
	mask.setTransform(152.175,139.825);

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_176 = new cjs.Graphics().p("AOsEIQAAAEADAEIgDAAQgFAAAFgIgAOuEEIAHgJIAHgHQAAABgNARIgBgCgAOeDwQgLgDgGgEQgngagXAHQhKAXgGAAQgkAFAqgxQAWgZAtgGQA7gHACgCQAMAQAmAoQAQARgRASQgCADgEgBQAAgBgBAAQgBAAAAAAQAAABgBAAQAAAAAAABQgFgFgKgCg");
	var mask_1_graphics_177 = new cjs.Graphics().p("AM6EpQgbgKgUgVQgzg1Atg0QAWgZAtgGQA7gHACgCQAMAQAmAoQAQARgRASQgQASAJAKIgHADIACADQAGAKgWAcQgOAHgmAMQgGABgGAAQgOAAgSgHg");
	var mask_1_graphics_178 = new cjs.Graphics().p("AKzFCQgMhRhVgTIg3gIQgWgEADgJQARgzBggSQA7gKASgGQApgMAWgaQAWgZAtgFQA7gIACgBQAMAPAmApQAQARgRASQgQARAJAKQgMAEgNAYQgVAmgRAWIgFAaQgGAggIAeQgJAhgNAMQgKAJgXAAQhqAAgJhBg");
	var mask_1_graphics_180 = new cjs.Graphics().p("AJBHOQATgKgPAAQgGAAABgQQACgYgJgVQACgKgDgKIgFgTQgFgeAWg9QAchNgsgfIghgSQgOgIADgJQARgzBggRQA7gLASgGQApgMAWgYQAWgZAtgGQA7gIACgBQAMAPAmAoQAQARgRASQgQASAJAJQgMAEgNAZQgVAmgRAVIgFAaQgGAggIAeQgPA7g/A/QhYBXh+ALIgBAAQgHAAAQgIg");
	var mask_1_graphics_181 = new cjs.Graphics().p("AGYHqQgJgDgLgZQADgSAHgRQARgpARgvQBIjCAQgwQASg2BZgWIBMgRQAsgKAagSQAegUAqgIQAzgJAFgDQAMAPAmApQAQAQgRASQgQASAJAJQgMAEgNAZQgVAmgRAVIgFAaQgGAggIAeQgNAyhDA9QhXBQh9AdQhvAagUAKQgHAEgEAAIgNACIgGgBg");
	var mask_1_graphics_182 = new cjs.Graphics().p("AFuHlQACgnBAi0QBIjCAQgwQARgzBegTQA/gNANgEQAqgMAYgWQAcgaArgGQA3gHACgBQAMAQAmAoQAQARgRASQgQASAJAKQgMADgNAYQgVAmgRAVIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA1QgKASAAAXIAAAgQgCAWgQAIIgQAEQgKg2ABgZg");
	var mask_1_graphics_185 = new cjs.Graphics().p("AFuHlQACgnBAi0QBIjCAQgwQAUg8BSgbQAvgQBogSQBLgSA1gWQAMAQAmAoQAQARgRASQgQASAJAKQgMADgNAYQgVAmgRAVIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA1QgKASAAAXIAAAgQgCAWgQAIIgQAEQgKg2ABgZg");
	var mask_1_graphics_186 = new cjs.Graphics().p("ADWHlQABgTAghPIBAicQBUjXgugmQgxgoAKgjQAKglBHgRQBDgQCNglQBjgZAygJQCBgXCpAcQBUAPgZAGIhyANQjqAdAsBYQACAEBHBMQgmAJgdAKQg3AVgYAeIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA1QgKASAAAXIAAAgQgCAWgQAIIgQAEQgKg2ABgZg");
	var mask_1_graphics_187 = new cjs.Graphics().p("ADMHjQgCgMAJgyQAPhNADgWQATiKgvgnQgXgTgKgtQgLgrAFgwQAMh2BGgRQE3hKB3gQQDFgcCvAeQBUAPgZAGIhyANQjqAdAsBYQACAEBHBMQgmAJgdAKQg3AVgYAeIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA1QgKASAAAXIAAAgQgCAWgQAIIgQAEQgJgigKgvg");
	var mask_1_graphics_189 = new cjs.Graphics().p("ADXIfQgIgbAAgeQAAgkg1gVIgogOQgVgIgFgHQh7ioAhiiQAiitDIg3QEChGCxgSQC/gTC8AgQBUAPgZAGIhyANQjqAdAsBYQACAEBHBMQgmAJgdAKQg3AVgYAeIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA1QgKASAAAXIAAAgQgCAWgQAIIgQAEQgEgIgEgNg");
	var mask_1_graphics_191 = new cjs.Graphics().p("ACMKKQhJgMgLggQg2kaATjXQAck1C3gyQEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAEBHBMQgmAKgdAKQg3AVgYAeIgFAZQgGAhgIAdQgNAzhDA9QhXBQh9AdQh4AcgeA0QgKASAAAXIAAAhQgDAigrC4QgiAAglgGg");
	var mask_1_graphics_192 = new cjs.Graphics().p("AA6LkQgagagVikQgViyAHi5QAHjfAziQQA9iuB0ggQEChGCxgSQC/gTC8AgQBUAPgZAGIhyANQjqAdAsBYQACADBHBMQgmAKgdALQg3AUgYAfIgFAaQgGAggIAeQgNAyhDA8QhXBQh9AdQh4AcgeA0QgKASAAAXIAAAhQgCAVABCgIABCbQg5BcgYAgQgUAdgRABIgBAAQgcAAg0g0g");
	var mask_1_graphics_194 = new cjs.Graphics().p("ACgODQg1gCg0g1QgagagVjGQgVjUAIjfQAIkNAzirQA+jPB0ggQEChGCxgSQC/gTC8AgQBUAPgZAGIhyANQjqAdAsBYQACAEBHBMQgmAJgdALQg3AUgYAfIgFAaQgGAggIAeQgNAyhDA9QhXBPh9AdQh4AcgeA0QgKASAAAXIAAAhQgCAVABCgIABCbQgfEygMAmQgJAagnAAIgGgBg");
	var mask_1_graphics_196 = new cjs.Graphics().p("AASO6QgZgagPjlQgQj0APkEQAQk2A4jGQBDjuB0gfQEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAEBHBMQgmAKgdAKQg3AVgYAeIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA0QgKASAAAXIAAAgQgCAWABCfIABCcIAlDmQAhDpgRASQghAiheAWQgnAJgfAAQg9AAgigig");
	var mask_1_graphics_197 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAEBHBMQgmAKgdAKQg3AVgYAeIgFAaQgGAhgIAdQgNAzhDA9QhXBPh9AdQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEg");
	var mask_1_graphics_202 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAEBHBMQgiAMg5BJIg3BHQgeAtg3AyQhsBlh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEg");
	var mask_1_graphics_203 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAEBHBMQgiAMg5BJIgUBaQgnAog/AuQh+Bbh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEg");
	var mask_1_graphics_204 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXIBPBxQBKBnAgBNIh+A8QgIgEgPAGQgNAFgbgXIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEgAPlh4IgCAHQgFgDAHgEg");
	var mask_1_graphics_205 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAFBtBzQBpBwAgBMIAXB8QgHgEgVAKQgYAMgMAAQghACgagMIgagPQgjgMhbhMIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEg");
	var mask_1_graphics_206 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAFBtBzQBpBwAgBMIAsDwIgmA0QhSiegygRQgjgMhbhMIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEg");
	var mask_1_graphics_207 = new cjs.Graphics().p("AECQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBUAOgZAGIhyAOQjqAdAsBXQACAFBtBzQBpBwAgBMIA2EeIgQBFQh0jegwgQQgjgMhbhMIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgSAAQgPAAgXgEg");
	var mask_1_graphics_211 = new cjs.Graphics().p("AD4QdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBXAPgCAOQgCAIg6AZQhCAcgbAZQgqApAZAzIAyBgQAqBVAiBQIAWEgIgcA2QguhYgagrQg5hegdgKQgjgMhbhMIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgRAAQgQAAgXgEg");
	var mask_1_graphics_212 = new cjs.Graphics().p("ADuQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAmrQDTg5QEChHCxgRQC/gTC8AgQBaAPAMANQAKAKgiAWQgxAigSAWQglAsAHA4IAFBiQAEBRANA/IA8EnIgcA5QguhYgagrQg5hegdgKQgjgMhbhMIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_213 = new cjs.Graphics().p("ADVQdQgzgIg7gWQiXg5gGg+QgIhNgFjAQgIkTANjqQAnrQDSg5QEChHCxgRQC/gTC8AgQCnAcgNBkQgFAkgfBAIg3ByQgDAHgJAGQgKAGgDAHQgNAaAQBpIATD7IgZA8QguhYgagrQg5hegdgKQgjgMhbhMIhUhJQgbAmgyArQhlBXh2AbQh4AcgeA1QgKASAAAWIAAAgQgCAWABCfIABCcIAqFJQAmFMgRASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_214 = new cjs.Graphics().p("AC3QdQgzgIg7gWQiWg5gHg+QgIhNgFjAQgHkTANjqQAnrQDRg5QEDhHCxgRQC+gTC8AgQCsAdAiB+QAVBNggCtQgUBsgbAIQgJACgRgHQgUgHgKAAIADEBIg8AsQguhYgagrQg4hegdgKQgkgMhbhMIhUhJQgaAmgzArQhkBXh2AbQh4AcgeA1QgKASgBAWIAAAgQgCAWABCfIABCcIAqFJQAnFMgSASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_215 = new cjs.Graphics().p("AC3QdQgzgIg7gWQiWg5gHg+QgIhNgFjAQgHkTANjqQAnrQDRg5QEDhHCxgRQC+gTC8AgQCsAdAiB+QAVBNggCtQgPBRAECAQABAsgDAPQgEAVgPAAIhEBIIg8AsQguhYgagrQg4hegdgKQgkgMhbhMIhUhJQgaAmgzArQhkBXh2AbQh4AcgeA1QgKASgBAWIAAAgQgCAWABCfIABCcIAqFJQAnFMgSASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_217 = new cjs.Graphics().p("ACTQdQgzgIg7gWQiWg5gHg+QgIhNgFjAQgHkTANjqQAnrQDRg5QEDhHCxgRQC+gTC8AgQCqAdBNFdQAdCDAICQQAGCAgNBFQgWB6gbAwQgWApgkAAIi5gZIAPiBQAKgYAIgeQASg7gEgZQgFgjg1hGQg5hMgngNQgkgMhbhMIhUhJQgaAmgzArQhkBXh2AbQh4AcgeA1QgKASgBAWIAAAgQgCAWABCfIABCcIAqFJQAnFMgSASQgFAFgSAAQgPAAgYgEg");
	var mask_1_graphics_219 = new cjs.Graphics().p("ACVQdQgzgIg7gWQiWg5gHg+QgIhNgFjAQgHkTANjqQAnrQDRg5QEDhHCxgRQC+gTC8AgQCpAdBNHbQAcCvAHC5QAGCngNBHQgWBzgrA2QghApgoAAIhrhnIh1hYQAghOAehTQA+imgEgZQgFgjg1hGQg5hMgngNQgkgMhbhMIhUhJQgaAmgzArQhkBXh2AbQh4AcgeA1QgKASgBAWIAAAgQgCAWABCfIABCcIAqFJQAnFMgSASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_220 = new cjs.Graphics().p("ACVQdQgzgIg7gWQiWg5gHg+QgIhNgFjAQgHkTANjqQAnrQDRg5QEDhHCxgRQC+gTC8AgQCpAcBNI0QAcDMAHDYQAGDDgNBHQgUBohMA+QgUAQgiAVQgcAQgEAHIhYimIhcjZQAghOAehTQA+imgEgZQgFgjg1hGQg5hMgngNQgkgMhbhMIhUhJQgaAmgzArQhkBXh2AbQh4AcgeA1QgKASgBAWIAAAgQgCAWABCfIABCcIAqFJQAnFMgSASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_222 = new cjs.Graphics().p("ACVQdQgzgIg7gWQiWg5gHg+QgIhNgFjAQgHkTANjqQAnrQDRg5QEDhHCxgRQC+gTC8AgQCpAcBNI0QAcDMAHDYQAGDDgNBHQgUBrhOCBQgoBCgwA/IkagsIBqneQAghOAehTQA+imgEgZQgFgjg1hGQg5hMgngNQgkgMhbhMIhUhJQgaAmgzArQhkBXh2AbQh4AcgeA1QgKASgBAWIAAAgQgCAWABCfIABCcIAqFJQAnFMgSASQgGAFgRAAQgPAAgYgEg");
	var mask_1_graphics_223 = new cjs.Graphics().p("ALnNoIBqneQAghNAehTQA+imgEgaQgFgig1hGQg5hMgngOQgkgMhbhLIhUhJQgaAmgzArQhkBWh2AcQh4AcgeA0QgKASgBAWIAAAhQgCAVABCgIABCbIAqFJQAnFMgSASQgKALg0gJQgzgJg7gWQiWg5gHg+QgIhMgFjAQgHkTANjrQAnrPDRg6QEDhGCxgSQC+gTC8AgQCpAdBNI0QAcDMAHDYQAGDCgNBHQgVBxhGDCQg+CqgUAeg");
	var mask_1_graphics_227 = new cjs.Graphics().p("ALnNoIBqneQAghNAehTQA+imgEgaQgFgig1hGQg5hMgngOQgkgMhbhLIhUhJQgaAmgzArQhkBWh2AcQh1AbAGA9QACARAOAcQANAbAAAIQgDAjhMEeIAqFJQAnFMgSASQgKALg0gJQgzgJg7gWQiWg5gHg+QgIhMgFjAQgHkTANjrQAnrPDRg6QEDhGCxgSQC+gTC8AgQCpAdBNI0QAcDMAHDYQAGDCgNBHQgVBxhGDCQg+CqgUAeg");
	var mask_1_graphics_229 = new cjs.Graphics().p("ALnNoIBqneQAghNAehTQA+imgEgaQgFgig1hGQg5hMgngOQgkgMhbhLIhUhJQgJA+ghBEQhCCKh0AhQg8ARgFA2QgDAeAIAvQgBAKgaARQguAdgLAKQhTBBgFBoQgEBXArEzQAmEPgOAOQgKALg0gJQgzgJg7gWQiWg5gHg+QgIhMgFjAQgHkTANjrQAnrPDRg6QEDhGCxgSQC+gTC8AgQCpAdBNI0QAcDMAHDYQAGDCgNBHQgVBxhGDCQg+CqgUAeg");
	var mask_1_graphics_230 = new cjs.Graphics().p("ALnNoIBqneQAghNAehTQA+imgEgaQgFgig1hGQg5hMgngOQgkgMhbhLIhUhJIAJAcQAKAlADAnQAKB9g8BoQgZAtgZA4QgcBAgCAYQgBAKg0AQQhcAcgWAIQilA+gFBoQgEBXAmESQAgDugOAOQgKALg0gJQgzgJg7gWQiWg5gHg+QgIhMgFjAQgHkTANjrQAnrPDRg6QEDhGCxgSQC+gTC8AgQCpAdBNI0QAcDMAHDYQAGDCgNBHQgVBxhGDCQg+CqgUAeg");
	var mask_1_graphics_234 = new cjs.Graphics().p("ALnNoIBqneQAghNAehTQA+imgEgaQgFgig1hGQg5hMgngOQgkgMhbhLIgMgLQARASAPASQBlB5gOB3QgDAbAVBHQAUBEgIAtQgBAKhoAMQi2AUgtAHQlJAwgFBoQgEBXAmESQAgDugOAOQgKALg0gJQgzgJg7gWQiWg5gHg+QgIhMgFjAQgHkTANjrQAnrPDRg6QEDhGCxgSQC+gTC8AgQCpAdBNI0QAcDMAHDYQAGDCgNBHQgVBxhGDCQg+CqgUAeg");
	var mask_1_graphics_235 = new cjs.Graphics().p("ALnNoIBqneQAghNAehTQA+imgEgaQgFgig1hGQg5hMgngOQgkgMhbhLIgMgLIA7A6QApAoAaAgQBNBfgIBHQgCATALARIAUAbQASAmhBBYQgFAHhvAMQiiARhKALQlRAzgFBpQgEBXAmESQAgDugOAOQgKALg0gJQgzgJg7gWQiWg5gHg+QgIhMgFjAQgHkTANjrQAnrPDRg6QEDhGCxgSQC+gTC8AgQCpAdBNI0QAcDMAHDYQAGDCgNBHQgVBxhGDCQg+CqgUAeg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(176).to({graphics:mask_1_graphics_176,x:95.8705,y:27.2347}).wait(1).to({graphics:mask_1_graphics_177,x:95.8705,y:30.4423}).wait(1).to({graphics:mask_1_graphics_178,x:95.8706,y:38.7009}).wait(2).to({graphics:mask_1_graphics_180,x:95.8706,y:46.9811}).wait(1).to({graphics:mask_1_graphics_181,x:95.8707,y:49.0662}).wait(1).to({graphics:mask_1_graphics_182,x:95.8708,y:56.3514}).wait(3).to({graphics:mask_1_graphics_185,x:95.8708,y:56.3514}).wait(1).to({graphics:mask_1_graphics_186,x:111.0878,y:56.3515}).wait(1).to({graphics:mask_1_graphics_187,x:111.0878,y:56.3515}).wait(2).to({graphics:mask_1_graphics_189,x:111.0879,y:56.3515}).wait(2).to({graphics:mask_1_graphics_191,x:111.0879,y:65.6018}).wait(1).to({graphics:mask_1_graphics_192,x:111.0879,y:79.1781}).wait(2).to({graphics:mask_1_graphics_194,x:111.0879,y:89.9594}).wait(2).to({graphics:mask_1_graphics_196,x:111.088,y:98.8279}).wait(1).to({graphics:mask_1_graphics_197,x:111.088,y:105.7357}).wait(5).to({graphics:mask_1_graphics_202,x:111.088,y:105.7357}).wait(1).to({graphics:mask_1_graphics_203,x:111.088,y:105.7357}).wait(1).to({graphics:mask_1_graphics_204,x:111.088,y:105.7357}).wait(1).to({graphics:mask_1_graphics_205,x:111.088,y:105.7357}).wait(1).to({graphics:mask_1_graphics_206,x:111.088,y:105.7357}).wait(1).to({graphics:mask_1_graphics_207,x:111.088,y:105.7357}).wait(4).to({graphics:mask_1_graphics_211,x:112.0811,y:105.7357}).wait(1).to({graphics:mask_1_graphics_212,x:113.0576,y:105.7357}).wait(1).to({graphics:mask_1_graphics_213,x:115.5746,y:105.7357}).wait(1).to({graphics:mask_1_graphics_214,x:118.5438,y:105.7357}).wait(1).to({graphics:mask_1_graphics_215,x:118.5438,y:105.7357}).wait(2).to({graphics:mask_1_graphics_217,x:122.1112,y:105.7357}).wait(2).to({graphics:mask_1_graphics_219,x:121.9476,y:105.7357}).wait(1).to({graphics:mask_1_graphics_220,x:121.9476,y:105.7357}).wait(2).to({graphics:mask_1_graphics_222,x:121.9476,y:105.7357}).wait(1).to({graphics:mask_1_graphics_223,x:121.9476,y:105.778}).wait(4).to({graphics:mask_1_graphics_227,x:121.9476,y:105.778}).wait(2).to({graphics:mask_1_graphics_229,x:121.9476,y:105.778}).wait(1).to({graphics:mask_1_graphics_230,x:121.9476,y:105.778}).wait(4).to({graphics:mask_1_graphics_234,x:121.9476,y:105.778}).wait(1).to({graphics:mask_1_graphics_235,x:121.9476,y:105.778}).wait(2).to({graphics:null,x:0,y:0}).wait(56));

	// Step 4
	this.instance = new lib.Step4();
	this.instance.parent = this;
	this.instance.setTransform(111.35,41.8,0.631,0.631);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(176).to({_off:false},0).wait(117));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_127 = new cjs.Graphics().p("AKfINIgPi6IgDgDIC5gJIAvCtIjMAig");
	var mask_2_graphics_128 = new cjs.Graphics().p("AIRFpIB8ghIC5gJIAvCtIjMAiIhrAQg");
	var mask_2_graphics_129 = new cjs.Graphics().p("AHKHQIAGg/IAWhfIFggiIAvCtIlAAiIgsBug");
	var mask_2_graphics_130 = new cjs.Graphics().p("AHQFmIAWheIFggjIAvCtIhrB7IjZBOIgoAdg");
	var mask_2_graphics_132 = new cjs.Graphics().p("AI4KZIhrlXIAWheIFggjIAvCtIAGDNIhkBhg");
	var mask_2_graphics_134 = new cjs.Graphics().p("AHrKZIhrlXIAWheIGfgGICQCgIiaC9IhkBhg");
	var mask_2_graphics_135 = new cjs.Graphics().p("AGsKZIhrlXIAWheII5gfIB0CnIjPCGIitCqg");
	var mask_2_graphics_136 = new cjs.Graphics().p("AF5KZIhrlXIAWheIMSgGIgjCwIjYAiIjmDsg");
	var mask_2_graphics_137 = new cjs.Graphics().p("AFqKZIhrlXIAVheIMyAAIg1E0IhoiEIhSAGIkRECg");
	var mask_2_graphics_138 = new cjs.Graphics().p("AFqKZIhrlXIAVheIMyAAIhFGGIhbAMIiOjGIjSDsg");
	var mask_2_graphics_139 = new cjs.Graphics().p("AFqKZIhrlXIAVheIMyAAIhFGGIiXAfIiNhOIiXBhg");
	var mask_2_graphics_142 = new cjs.Graphics().p("AHVLyIhri8IhrlXIAVheIMyAAIhFGGIiBCpIjfBPg");
	var mask_2_graphics_144 = new cjs.Graphics().p("AFqHZIhrlXIAVheIMyAAIhFGGIiBCpIjfBPIigC6g");
	var mask_2_graphics_145 = new cjs.Graphics().p("AH/NLIiXmDIhrlXIAWhfIMyAAIhFGHIj5DWIg/AGIAHD7g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(127).to({graphics:mask_2_graphics_127,x:88.5015,y:53.426}).wait(1).to({graphics:mask_2_graphics_128,x:88.5016,y:54.226}).wait(1).to({graphics:mask_2_graphics_129,x:88.5017,y:58.9261}).wait(1).to({graphics:mask_2_graphics_130,x:88.5017,y:63.1763}).wait(2).to({graphics:mask_2_graphics_132,x:88.8017,y:66.8014}).wait(2).to({graphics:mask_2_graphics_134,x:96.5019,y:66.8014}).wait(1).to({graphics:mask_2_graphics_135,x:102.7771,y:66.8014}).wait(1).to({graphics:mask_2_graphics_136,x:107.8273,y:66.8014}).wait(1).to({graphics:mask_2_graphics_137,x:109.4023,y:66.8014}).wait(1).to({graphics:mask_2_graphics_138,x:109.4023,y:66.8014}).wait(1).to({graphics:mask_2_graphics_139,x:109.4023,y:66.8014}).wait(3).to({graphics:mask_2_graphics_142,x:109.4023,y:76.7017}).wait(2).to({graphics:mask_2_graphics_144,x:109.4023,y:85.9769}).wait(1).to({graphics:mask_2_graphics_145,x:109.2523,y:88.002}).wait(3).to({graphics:null,x:0,y:0}).wait(145));

	// Step 3
	this.instance_1 = new lib.Step3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(134.05,91.65,0.631,0.631);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(127).to({_off:false},0).wait(166));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_90 = new cjs.Graphics().p("AFKFjIlEikQAAgCHugbIHtgbIBJDNIh+H3InOAPg");
	var mask_3_graphics_91 = new cjs.Graphics().p("AECF5Ii0gTIhIinQAAgCHugbIHtgbIBJDNIh+H3InOAPg");
	var mask_3_graphics_92 = new cjs.Graphics().p("AEbIjIijgvIhyk1QAAgCHugbIHtgbIBJDNIh+H3InOAPg");
	var mask_3_graphics_98 = new cjs.Graphics().p("ACbK4IiigvIhxk1QAAgBKQgXIKRgXIgpDdIjSAJIh1CrInOAPg");
	var mask_3_graphics_99 = new cjs.Graphics().p("ACbK4IiigvIhxk1QAAgBKQgXIKRgXIhCF0IjAhxIiECQIm4ANg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(90).to({graphics:mask_3_graphics_90,x:106.5774,y:85.8019}).wait(1).to({graphics:mask_3_graphics_91,x:106.5774,y:85.8019}).wait(1).to({graphics:mask_3_graphics_92,x:106.5774,y:85.8019}).wait(6).to({graphics:mask_3_graphics_98,x:119.301,y:70.9003}).wait(1).to({graphics:mask_3_graphics_99,x:119.301,y:70.9003}).wait(1).to({graphics:null,x:0,y:0}).wait(193));

	// step 2 ears
	this.instance_2 = new lib.Step2_ears();
	this.instance_2.parent = this;
	this.instance_2.setTransform(122.05,107.4,0.631,0.631);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(90).to({_off:false},0).wait(203));

	// mask
	this.instance_3 = new lib.mask22();
	this.instance_3.parent = this;
	this.instance_3.setTransform(177.2,140.05,1,1,0,0,0,36.6,32.9);

	this.instance_4 = new lib.mask23();
	this.instance_4.parent = this;
	this.instance_4.setTransform(177.45,140.05,1,1,0,0,0,36.3,32.9);

	this.instance_5 = new lib.mask24();
	this.instance_5.parent = this;
	this.instance_5.setTransform(182.3,140.05,1,1,0,0,0,31.4,32.9);

	this.instance_6 = new lib.mask25();
	this.instance_6.parent = this;
	this.instance_6.setTransform(182.3,140.05,1,1,0,0,0,31.4,32.9);

	this.instance_7 = new lib.mask26();
	this.instance_7.parent = this;
	this.instance_7.setTransform(182.3,140.05,1,1,0,0,0,31.4,32.9);

	this.instance_8 = new lib.mask27();
	this.instance_8.parent = this;
	this.instance_8.setTransform(182.3,140.05,1,1,0,0,0,31.4,32.9);

	this.instance_9 = new lib.mask28();
	this.instance_9.parent = this;
	this.instance_9.setTransform(182.3,140.1,1,1,0,0,0,31.4,32.6);

	this.instance_10 = new lib.mask29();
	this.instance_10.parent = this;
	this.instance_10.setTransform(180.95,140.1,1,1,0,0,0,32.6,32.6);

	this.instance_11 = new lib.mask30();
	this.instance_11.parent = this;
	this.instance_11.setTransform(180.95,140.1,1,1,0,0,0,32.6,32.6);

	this.instance_12 = new lib.mask31();
	this.instance_12.parent = this;
	this.instance_12.setTransform(178.05,140.65,1,1,0,0,0,29.7,32.2);

	this.instance_13 = new lib.mask32();
	this.instance_13.parent = this;
	this.instance_13.setTransform(173.55,140.65,1,1,0,0,0,25.2,32.2);

	this.instance_14 = new lib.mask33();
	this.instance_14.parent = this;
	this.instance_14.setTransform(178.1,140.05,1,1,0,0,0,20.6,31.6);

	this.instance_15 = new lib.mask34();
	this.instance_15.parent = this;
	this.instance_15.setTransform(177.4,137.05,1,1,0,0,0,19.9,28.6);

	this.instance_16 = new lib.mask35();
	this.instance_16.parent = this;
	this.instance_16.setTransform(176.9,135.05,1,1,0,0,0,19.4,26.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},36).to({state:[{t:this.instance_4}]},25).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},6).to({state:[{t:this.instance_14}]},3).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_16}]},1).to({state:[]},3).wait(206));

	// step 2 mouth
	this.instance_17 = new lib.Step2_eyes();
	this.instance_17.parent = this;
	this.instance_17.setTransform(142.1,107.4,0.631,0.631);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(36).to({_off:false},0).wait(257));

	// mask
	this.instance_18 = new lib.mask13();
	this.instance_18.parent = this;
	this.instance_18.setTransform(173.45,196.75,1,1,0,0,0,58.3,24.5);

	this.instance_19 = new lib.mask14();
	this.instance_19.parent = this;
	this.instance_19.setTransform(173.45,196.75,1,1,0,0,0,58.3,24.5);

	this.instance_20 = new lib.mask15();
	this.instance_20.parent = this;
	this.instance_20.setTransform(172.8,196.75,1,1,0,0,0,59.1,24.5);

	this.instance_21 = new lib.mask16();
	this.instance_21.parent = this;
	this.instance_21.setTransform(181.4,196.75,1,1,0,0,0,50.4,24.5);

	this.instance_22 = new lib.mask17();
	this.instance_22.parent = this;
	this.instance_22.setTransform(200.95,197.05,1,1,0,0,0,30.9,24.8);

	this.instance_23 = new lib.mask18();
	this.instance_23.parent = this;
	this.instance_23.setTransform(201.2,197.05,1,1,0,0,0,30.7,24.8);

	this.instance_24 = new lib.mask19();
	this.instance_24.parent = this;
	this.instance_24.setTransform(207.45,204.05,1,1,0,0,0,24.4,17.7);

	this.instance_25 = new lib.mask20();
	this.instance_25.parent = this;
	this.instance_25.setTransform(207.45,207.55,1,1,0,0,0,24.4,14.2);

	this.instance_26 = new lib.mask21();
	this.instance_26.parent = this;
	this.instance_26.setTransform(207.45,208.25,1,1,0,0,0,24.4,13.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_18}]}).to({state:[{t:this.instance_19}]},23).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},2).to({state:[{t:this.instance_23}]},2).to({state:[{t:this.instance_24}]},3).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[]},2).wait(257));

	// Step 1
	this.instance_27 = new lib.Step1();
	this.instance_27.parent = this;
	this.instance_27.setTransform(122.05,40.5,0.631,0.631);

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(293));

	// selected
	this.instance_28 = new lib.selected("synched",0);
	this.instance_28.parent = this;
	this.instance_28.setTransform(-35.35,129.3,0.327,0.327,0,0,0,104.5,305.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(293));

	// left slides
	this.instance_29 = new lib.slides();
	this.instance_29.parent = this;
	this.instance_29.setTransform(-28.65,128.35,0.327,0.327,0,0,0,125,310.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(293));

	// top bar
	this.instance_30 = new lib.bar_top();
	this.instance_30.parent = this;
	this.instance_30.setTransform(152.15,14.15,0.327,0.327,0,0,0,683,34.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(293));

	// bar_btm
	this.instance_31 = new lib.bar_btm();
	this.instance_31.parent = this;
	this.instance_31.setTransform(152.8,244.55,0.327,0.327,0,0,0,683.1,31.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_31).wait(293));

	// BG
	this.instance_32 = new lib.screen_bg();
	this.instance_32.parent = this;
	this.instance_32.setTransform(152.5,126.85,1,1,0,0,0,223.1,123.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(293));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.2,2.9,464,252);


(lib.devices = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.parent = this;
	this.icon.setTransform(-41.2,56.7,0.9971,0.9912,0,0,0,-0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// Screen
	this.screen = new lib.screen();
	this.screen.name = "screen";
	this.screen.parent = this;
	this.screen.setTransform(98.6,-107.7,1.0032,1.0032,0,0,0,68.9,-161.3);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// laptop
	this.instance = new lib.laptop_ai();
	this.instance.parent = this;
	this.instance.setTransform(88.1,150.95,1,1,0,0,0,156.3,106.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// shadow
	this.shadow = new lib.laptopshadow_1();
	this.shadow.name = "shadow";
	this.shadow.parent = this;
	this.shadow.setTransform(178.9,316.35,1,1,0,0,0,474.9,72.2);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

}).prototype = getMCSymbolPrototype(lib.devices, new cjs.Rectangle(-296,6.9,950,391.1), null);


(lib.anim_blue = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Devices
	this.laptop = new lib.devices();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(145.15,137.5,1,1,0,0,0,177.7,196.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

}).prototype = getMCSymbolPrototype(lib.anim_blue, new cjs.Rectangle(-328.5,-52.1,949.9,391.1), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(712.15,3.8,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(669.9,60,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(705,60.55,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// phone
	this.phone = new lib.phonenew();
	this.phone.name = "phone";
	this.phone.parent = this;
	this.phone.setTransform(177.55,62.7,0.5245,0.5245,0,0,0,22.9,42.3);

	this.timeline.addTween(cjs.Tween.get(this.phone).wait(1));

	// anim
	this.anim_1 = new lib.anim_blue();
	this.anim_1.name = "anim_1";
	this.anim_1.parent = this;
	this.anim_1.setTransform(196.6,18.85,0.1974,0.1974,0,0,0,12.7,12.7);

	this.timeline.addTween(cjs.Tween.get(this.anim_1).wait(1));

	// logo
	this.logo_1 = new lib.logo_office365();
	this.logo_1.name = "logo_1";
	this.logo_1.parent = this;
	this.logo_1.setTransform(47.3,23.5,0.6234,0.6234,0,0,0,0.7,0.8);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// BG
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#ECEDEF","#FFFFFF"],[0,1],13.7,44.1,14.2,26).s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,0,729.3,90.4), null);


// stage content:
(lib.O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var laptop = mc.anim_1.laptop
		
		mc.cta.alpha=0
		mc.anim_1.alpha=0
		mc.replay_btn.alpha=0
		
		
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.anim_1.alpha=1
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
			
				laptop.shadow.alpha = 0.2;
				
				exportRoot.tl1.from(mc.phone, 2, {x:"+=50", alpha:0, ease:Power3.easeOut}, "+=0.5");
				exportRoot.tl1.from(laptop, 2, {x: "+=200", alpha:0, ease:Power3.easeOut}, "-=1.75");
		
				//Manage your finance
				exportRoot.tl1.from(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeOut, onStart: function(){laptop.screen.gotoAndPlay(1);}}, "-=1.5");
				exportRoot.tl1.from(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=1");
				exportRoot.tl1.from(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeOut}, "-=0.75");
				
				exportRoot.tl1.to(exportRoot.headline1, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=1");
				exportRoot.tl1.to(exportRoot.headline2, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0");
				exportRoot.tl1.to(exportRoot.headline3, 0.01, {alpha: 0, ease:Power4.easeIn}, "+=0");
				
				//budject-tracking
				exportRoot.tl1.from(exportRoot.headline4, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=0");
				exportRoot.tl1.from(exportRoot.headline5, 0.01, {alpha: 0, ease:Power4.easeOut}, "+=.25");
				
				//exportRoot.tl1.to(devices, 0.1, {scaleX: 0.593, scaleY: 0.593, ease:Power3.easeInOut,onComplete:function(){devices.screen.gotoAndPlay(1)}}, "-=0.5");
				
				
				exportRoot.tl1.to(exportRoot.headline4, 0.5, {alpha: 0, ease:Power4.easeIn}, "+=1");
				exportRoot.tl1.to(exportRoot.headline5, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
				//exportRoot.tl1.to(exportRoot.headline6, 0.5, {alpha: 0, ease:Power4.easeIn}, "-=0.5");
				
				
				
				
				
				
				
		
				//devices.gotoAndStop(1);
				
				//exportRoot.tl1.to(laptop, 1.75, {x:"+=261.15", y:"+=17",  ease:Power3.easeInOut}, "-=0");
				//exportRoot.tl1.to(laptop.shadow, 1.75, {alpha: 0.2, ease:Power3.easeInOut}, "-=1.75");
				
				
				
				
				
				for (var i = 0; i < exportRoot.headline11.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "+=50", alpha: 0, ease:Power4.easeOut}, "-=0");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline11[i], 0.8, { x: "+=50", alpha: 0, ease:Power4.easeOut}, "-=0");
				}
				
				for (var i = 0; i < exportRoot.headline12.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=50", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline12[i], 0.8, { x: "+=50", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=0.6");	
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=150",	ease:Power4.easeOut}, "-=0.6");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=150", ease:Power4.easeOut}, "-=0.7");
			
				exportRoot.tl1.stop();	
		
			
			mc.logo_intro.gotoAndPlay(1)
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(364,45.1,365.29999999999995,45.300000000000004);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_.png?1574349954005", id:"O365_NewYearCampaign_USA_728x90_BAN_PPT_Draw_English_NA_NA_ANI_NA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;