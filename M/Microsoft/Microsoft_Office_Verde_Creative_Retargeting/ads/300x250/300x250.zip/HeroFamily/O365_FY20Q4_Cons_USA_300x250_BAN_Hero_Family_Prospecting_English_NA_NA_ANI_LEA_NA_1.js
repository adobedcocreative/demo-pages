(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[799,0,200,200],[0,0,797,600],[799,202,120,111]]}
];


// symbols:



(lib.Clock = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.image = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whitebg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApXUsMAAAgpXISvAAMAAAApXg");
	this.shape.setTransform(90,132.427,1.5,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebg, new cjs.Rectangle(0,0,180,264.9), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.tile_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.mainImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.image();
	this.instance.setTransform(0,0,0.5527,0.5527);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainImage, new cjs.Rectangle(0,0,440.5,331.6), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.clockImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Clock();
	this.instance.setTransform(-0.05,0.05,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.clockImage, new cjs.Rectangle(0,0.1,120,120), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		exportRoot.tl1.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(24).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhM1A/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTjA/xMAAAh/hMCXtAAAMAAAB/hg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhanA/xMAAAh/hMCXtAAAMAAAB/hg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:340.5185}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:340.5185}).wait(1).to({graphics:mask_1_graphics_52,x:295.8271,y:340.5185}).wait(1).to({graphics:mask_1_graphics_53,x:289.2111,y:340.5185}).wait(1).to({graphics:mask_1_graphics_54,x:278.1844,y:340.5185}).wait(1).to({graphics:mask_1_graphics_55,x:262.7471,y:340.5185}).wait(1).to({graphics:mask_1_graphics_56,x:242.8992,y:340.5185}).wait(1).to({graphics:mask_1_graphics_57,x:218.6406,y:340.5185}).wait(1).to({graphics:mask_1_graphics_58,x:189.9713,y:340.5185}).wait(1).to({graphics:mask_1_graphics_59,x:156.8914,y:340.5185}).wait(1).to({graphics:mask_1_graphics_60,x:119.4008,y:340.5185}).wait(1).to({graphics:mask_1_graphics_61,x:77.4995,y:340.5185}).wait(1).to({graphics:mask_1_graphics_62,x:31.1876,y:340.5185}).wait(1).to({graphics:mask_1_graphics_63,x:-19.5349,y:340.5185}).wait(1).to({graphics:mask_1_graphics_64,x:-74.6682,y:340.5185}).wait(1).to({graphics:mask_1_graphics_65,x:-134.212,y:340.5185}).wait(1).to({graphics:mask_1_graphics_66,x:-198.1666,y:340.5185}).wait(1).to({graphics:mask_1_graphics_67,x:-266.5318,y:340.5185}).wait(1).to({graphics:mask_1_graphics_68,x:-339.3076,y:340.5185}).wait(1).to({graphics:mask_1_graphics_69,x:-416.4941,y:340.5185}).wait(1).to({graphics:mask_1_graphics_70,x:-491.7868,y:340.5185}).wait(1).to({graphics:mask_1_graphics_71,x:-534.7908,y:340.5185}).wait(1).to({graphics:mask_1_graphics_72,x:-580,y:340.5185}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(222.05,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({scaleY:2.3668,y:895.45},0).to({x:-674.6},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(297.95,903.5,1,2.3867,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({scaleY:2.3671,y:895.55},0).wait(2).to({scaleY:2.3867,x:-674.6,y:903.5},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160,-67.6,1943.5,816.3000000000001);


(lib.icon_teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.clock = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_26 = function() {
		exportRoot.tlClock.play()
	}
	this.frame_124 = function() {
		this.stop();
		exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(26).call(this.frame_26).wait(98).call(this.frame_124).wait(1));

	// smiles mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ACfHxQizgthgifQgUghgNgiIGnilIAtHBIgnABQg/AAg6gOg");
	var mask_graphics_86 = new cjs.Graphics().p("ACfHxQizgthgifQgUghgNgiIGnilIAtHBIgnABQg/AAg6gOg");
	var mask_graphics_87 = new cjs.Graphics().p("ACeHwQiygshgifQgTghgOgiIGnilIAtHBIgnABQg/AAg7gPg");
	var mask_graphics_88 = new cjs.Graphics().p("ACeHwQiygthgifQgTghgNgiIGmikIAtHBIgmABQhAAAg7gPg");
	var mask_graphics_89 = new cjs.Graphics().p("ACdHwQiygvhfifQgTghgNgjIGoihIApHBIgiABQhCAAg8gPg");
	var mask_graphics_90 = new cjs.Graphics().p("ACaHuQixgwhdihQgTghgMgiIGpidIAlHBIgdABQhEAAhAgRg");
	var mask_graphics_91 = new cjs.Graphics().p("ACXHsQixg0haiiQgSgigMgiIGsiVIAdHCIgTAAQhKAAhDgTg");
	var mask_graphics_92 = new cjs.Graphics().p("ACRHoQivg5hVikQgSgigLgjIGwiJIAQHCIgCAAQhTAAhKgXg");
	var mask_graphics_93 = new cjs.Graphics().p("ACJHiQitg/hPioQgQgjgKgjIG1h4IgBHDQhUgDhKgbg");
	var mask_graphics_94 = new cjs.Graphics().p("ABzHZQiphHhGisQgPgkgHgjIG6hiIgYHCQhUgHhJgfg");
	var mask_graphics_95 = new cjs.Graphics().p("ABZHOQilhTg6iwQgNgkgFgkIHAhFIg1HAQhUgNhGgjg");
	var mask_graphics_96 = new cjs.Graphics().p("AA5G/Qidhggti1QgJglgCgkIHEggIhaG6QhSgThDgpg");
	var mask_graphics_97 = new cjs.Graphics().p("AAUGqQiThvgai4QgFgmABgkIHFAOIiFGuQhQgbg/gwg");
	var mask_graphics_98 = new cjs.Graphics().p("AgUGQQiFiAgEi5QgBgnAGgkIHABEIi4GcQhMglg4g3g");
	var mask_graphics_99 = new cjs.Graphics().p("Ag+FwQhyiSAXi5QAEglALgiIGyCBIjwF+QhFgvgxg+g");
	var mask_graphics_100 = new cjs.Graphics().p("AhhFNQhcigAwizQAKglAQghIGbC+IkkFYQg9g5gohEg");
	var mask_graphics_101 = new cjs.Graphics().p("Ah4EvQhIiqBFisQAOgjAUgfIGBDuIlKEyQg3g/gfhJg");
	var mask_graphics_102 = new cjs.Graphics().p("AiHEWQg3ixBWijQASgiAWgdIFoETIlnEQQgwhFgYhLg");
	var mask_graphics_103 = new cjs.Graphics().p("AiQEBQgoi0BjicQAUggAZgbIFQEvIl8DyQgrhJgRhNg");
	var mask_graphics_104 = new cjs.Graphics().p("AiVDxQgci3BtiVQAWgfAbgZIE7FFImLDYQgmhLgMhOg");
	var mask_graphics_105 = new cjs.Graphics().p("AiYDkQgTi4B1iPQAYgeAcgYIEqFVImVDEQgihNgJhPg");
	var mask_graphics_106 = new cjs.Graphics().p("AiZDbQgMi5B6iKQAagdAbgXIEeFgImcC0QgghOgFhPg");
	var mask_graphics_107 = new cjs.Graphics().p("AiZDUQgHi5B+iHQAagcAcgWIEUFoImhCoQgdhPgDhPg");
	var mask_graphics_108 = new cjs.Graphics().p("AiZDQQgEi5CBiFQAagcAdgVIENFtImkCgQgchPgBhPg");
	var mask_graphics_109 = new cjs.Graphics().p("AiZDNQgCi5CCiDQAagcAegVIEJFwImmCcQgbhQAAhPg");
	var mask_graphics_110 = new cjs.Graphics().p("AiZDMQgBi5CDiDQAagbAegVIEHFxImnCaQgahQAAhPg");
	var mask_graphics_111 = new cjs.Graphics().p("AiZDLQAAi5CDiCQAagbAegVIEGFyImnCYQgahQAAhPg");
	var mask_graphics_112 = new cjs.Graphics().p("AiZDMQAAi6CDiCQAagbAegVIEGFyImnCYQgahQAAhOg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:31.9115,y:51.1155}).wait(86).to({graphics:mask_graphics_86,x:31.9115,y:51.1155}).wait(1).to({graphics:mask_graphics_87,x:31.9047,y:51.1154}).wait(1).to({graphics:mask_graphics_88,x:31.8572,y:51.116}).wait(1).to({graphics:mask_graphics_89,x:31.7282,y:51.1179}).wait(1).to({graphics:mask_graphics_90,x:31.4768,y:51.1221}).wait(1).to({graphics:mask_graphics_91,x:31.0619,y:51.1303}).wait(1).to({graphics:mask_graphics_92,x:30.4421,y:51.1462}).wait(1).to({graphics:mask_graphics_93,x:29.6445,y:51.1596}).wait(1).to({graphics:mask_graphics_94,x:29.6426,y:51.1266}).wait(1).to({graphics:mask_graphics_95,x:29.6404,y:50.9982}).wait(1).to({graphics:mask_graphics_96,x:29.6379,y:50.703}).wait(1).to({graphics:mask_graphics_97,x:29.6351,y:50.1421}).wait(1).to({graphics:mask_graphics_98,x:29.6322,y:49.1867}).wait(1).to({graphics:mask_graphics_99,x:29.6294,y:47.6788}).wait(1).to({graphics:mask_graphics_100,x:29.6274,y:45.7892}).wait(1).to({graphics:mask_graphics_101,x:29.6261,y:43.9194}).wait(1).to({graphics:mask_graphics_102,x:29.6255,y:42.1913}).wait(1).to({graphics:mask_graphics_103,x:29.6252,y:40.6749}).wait(1).to({graphics:mask_graphics_104,x:29.6251,y:39.4019}).wait(1).to({graphics:mask_graphics_105,x:29.6251,y:38.3782}).wait(1).to({graphics:mask_graphics_106,x:29.6252,y:37.5921}).wait(1).to({graphics:mask_graphics_107,x:29.6252,y:37.0206}).wait(1).to({graphics:mask_graphics_108,x:29.6253,y:36.634}).wait(1).to({graphics:mask_graphics_109,x:29.6253,y:36.3981}).wait(1).to({graphics:mask_graphics_110,x:29.6253,y:36.2766}).wait(1).to({graphics:mask_graphics_111,x:29.6253,y:36.2318}).wait(1).to({graphics:mask_graphics_112,x:29.6253,y:36.2504}).wait(13));

	// smiles slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(117,190,221,0.749)").s().p("AjgBqQAAi4CDiEQAbgaAegWIEFFyImnCTQgahKAAhPg");
	this.shape.setTransform(36.725,46.0125);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(125));

	// memory mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("ABKEUImVjAQBHiaCfhHQCehHCvBFQCvBFA/CHQA+CHgLBmg");
	var mask_1_graphics_43 = new cjs.Graphics().p("ABKEUImVjAQBHiaCfhHQCehHCvBFQCvBFA/CHQA+CHgLBmg");
	var mask_1_graphics_44 = new cjs.Graphics().p("ABKEUImUjAQBGiaCfhHQCfhHCvBFQCvBFA+CHQA+CIgLBlg");
	var mask_1_graphics_45 = new cjs.Graphics().p("ABKETImUjCQBHiaCghGQCfhGCvBGQCuBGA+CHQA9CIgLBlg");
	var mask_1_graphics_46 = new cjs.Graphics().p("ABKEQImRjHQBIiYChhFQCghECtBIQCuBIA8CIQA8CIgNBmg");
	var mask_1_graphics_47 = new cjs.Graphics().p("ABKELImNjQQBNiXCihBQChhACsBMQCsBMA5CJQA5CKgQBlg");
	var mask_1_graphics_48 = new cjs.Graphics().p("ABKECImEjfQBSiUCkg6QCkg6CpBSQCpBTAzCLQA0CMgUBkg");
	var mask_1_graphics_49 = new cjs.Graphics().p("ABKD2Il3j1QBbiPCngxQCngxCkBcQCkBdArCOQArCOgZBjg");
	var mask_1_graphics_50 = new cjs.Graphics().p("ABKDkIlikRQBmiICrgjQCqgkCcBpQCcBqAgCQQAfCSggBhg");
	var mask_1_graphics_51 = new cjs.Graphics().p("ABKDOIlDk2QB0h8CtgRQCugRCQB5QCQB5AQCTQAQCVgrBcg");
	var mask_1_graphics_52 = new cjs.Graphics().p("ABJCyIkVlfQCDhrCuAHQCuAHB+CLQB+CLgECVQgECVg3BWg");
	var mask_1_graphics_53 = new cjs.Graphics().p("ABHCSIjVmJQCThTCrAkQCqAlBlCfQBkCegdCSQgeCShFBMg");
	var mask_1_graphics_54 = new cjs.Graphics().p("ABHByIh/mtQChg0CgBIQCfBHBCCwQBBCwg7CJQg7CIhTA8g");
	var mask_1_graphics_55 = new cjs.Graphics().p("ABJBUIgRm/QCpgKCJBtQCJBsAUC6QATC7hbB2QhbB2hfAlg");
	var mask_1_graphics_56 = new cjs.Graphics().p("ABIBBIBymwQClAoBjCQQBjCPgjC4QgkC5h6BWQh6BWhlAIg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AAAH4IBGm5IDrl9QCSBWA2CnQA1ClhYCmQhYCniOAvQhgAghNAAQgkAAgfgIg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AhrHZICxmaIFDk3QB4B5AKCtQAKCuh+CLQh/CMiUAKQgcACgZAAQhwAAhKgmg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AAmH+QiSgVhQhAIEDlsIF8jtQBdCOgbCsQgaCsiYBuQiBBdh9AAQgXAAgYgDg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AgkHxQiOgthEhNIE9k7IGfipQBDCbg3CmQg3CmipBSQhtA1hiAAQg2AAgxgQg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AhfHfQiGhAg4hWIFkkMIGzhvQAtCjhNCcQhOCdiyA7QhVAchMAAQhRAAhHgig");
	var mask_1_graphics_62 = new cjs.Graphics().p("AiKHMQh/hPguhaIF/jmIG8g/QAbCmhdCUQheCTi4AoQg9ANg3AAQhtAAhVg0g");
	var mask_1_graphics_63 = new cjs.Graphics().p("AipG6Qh4hYgnheIGQjGIHAgdQAOCphpCMQhpCLi7AZQgoAFglAAQiGAAhfhFg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ai+GsQhzhfgihgIGbivIHBgDQAECqhxCFQhwCFi8AOQgYACgWAAQibAAhlhTg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AjLGhQhwhjgehhIGiifIHAAOQgDCqh1CBQh2CBi8AGIgXABQirAAhoheg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AjTGbQhthmgchiIGliVIHAAZQgHCph4B/Qh5B+i8ACIgIAAQi2AAhqhkg");
	var mask_1_graphics_67 = new cjs.Graphics().p("ABPH/Qi7AAhrhoQhshngbhiIGniQIHAAeQgJCqh6B8Qh6B9i8AAIgBAAg");
	var mask_1_graphics_68 = new cjs.Graphics().p("ABOH/Qi8gBhrhoQhrhogahiIGniOIG/AgQgJCqh6B8Qh6B7i7AAIgCAAg");
	var mask_1_graphics_69 = new cjs.Graphics().p("ABNH/Qi7gChrhnQhrhogbhjIGoiNIG/AgQgJCqh7B8Qh6B7i6AAIgDAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:52.2478,y:29.7806}).wait(43).to({graphics:mask_1_graphics_43,x:52.2478,y:29.7806}).wait(1).to({graphics:mask_1_graphics_44,x:52.2482,y:29.7948}).wait(1).to({graphics:mask_1_graphics_45,x:52.2501,y:29.8936}).wait(1).to({graphics:mask_1_graphics_46,x:52.2547,y:30.1616}).wait(1).to({graphics:mask_1_graphics_47,x:52.2609,y:30.683}).wait(1).to({graphics:mask_1_graphics_48,x:52.264,y:31.54}).wait(1).to({graphics:mask_1_graphics_49,x:52.2554,y:32.8101}).wait(1).to({graphics:mask_1_graphics_50,x:52.228,y:34.5591}).wait(1).to({graphics:mask_1_graphics_51,x:52.2027,y:36.826}).wait(1).to({graphics:mask_1_graphics_52,x:52.3105,y:39.5976}).wait(1).to({graphics:mask_1_graphics_53,x:52.4487,y:42.7661}).wait(1).to({graphics:mask_1_graphics_54,x:52.4053,y:46.0706}).wait(1).to({graphics:mask_1_graphics_55,x:52.2081,y:49.0269}).wait(1).to({graphics:mask_1_graphics_56,x:52.3024,y:50.8737}).wait(1).to({graphics:mask_1_graphics_57,x:52.4519,y:51.1505}).wait(1).to({graphics:mask_1_graphics_58,x:52.3937,y:51.102}).wait(1).to({graphics:mask_1_graphics_59,x:52.3164,y:51.3127}).wait(1).to({graphics:mask_1_graphics_60,x:52.2827,y:51.3471}).wait(1).to({graphics:mask_1_graphics_61,x:52.2342,y:51.2755}).wait(1).to({graphics:mask_1_graphics_62,x:52.181,y:51.1871}).wait(1).to({graphics:mask_1_graphics_63,x:52.1377,y:51.1235}).wait(1).to({graphics:mask_1_graphics_64,x:52.1093,y:51.092}).wait(1).to({graphics:mask_1_graphics_65,x:52.0911,y:51.083}).wait(1).to({graphics:mask_1_graphics_66,x:52.0683,y:51.084}).wait(1).to({graphics:mask_1_graphics_67,x:52.0519,y:51.0868}).wait(1).to({graphics:mask_1_graphics_68,x:52.0451,y:51.0881}).wait(1).to({graphics:mask_1_graphics_69,x:52.0192,y:51.0633}).wait(56));

	// memories slice
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(98,123,157,0.749)").s().p("AlKBZQhLhLgghcIGriOIAAABIHAAhQgSCkhyBvQiDCEi6AAQi6AAiFiEg");
	this.shape_1.setTransform(60.375,79.2875);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(125));

	// family mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AgnFxQh+iKAHi5QAHi5CJh9QASgSAUgPIENFnIAAAAIhgG9QiJgdhjhtg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AgoFxQh+iKAIi5QAHi6CJh8QASgSAVgPIEMFnIAAAAIhgG9QiKgdhjhtg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AgpFwQh9iKAIi5QAIi6CJh8QATgSAUgPIELFoIAAAAIhhG8QiKgdhjhtg");
	var mask_2_graphics_3 = new cjs.Graphics().p("AgsFtQh8iMAKi5QAKi5CKh7QATgSAVgOIEHFqIAAABIhmG7QiJgfhihug");
	var mask_2_graphics_4 = new cjs.Graphics().p("AgyFnQh5iOAOi4QANi5CNh5QATgRAVgOIEAFwIAAAAIhuG5QiJghhghxg");
	var mask_2_graphics_5 = new cjs.Graphics().p("Ag7FeQh0iSATi4QAUi5CPhzQAUgRAWgNID0F3IAAABIh8G1QiIgmhchzg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AhIFQQhtiXAci3QAci4CVhsQAVgQAWgNIDjGEIAAAAIiSGvQiGgshWh4g");
	var mask_2_graphics_7 = new cjs.Graphics().p("AhZE8QhjieAoi0QApi2CchiQAWgOAXgLIDIGRIAAAAIivGkQiBg1hPh9g");
	var mask_2_graphics_8 = new cjs.Graphics().p("AhtEhQhUimA4ivQA5iyCjhUQAYgMAYgJICjGhIAAABIjTGTQh8hBhEiEg");
	var mask_2_graphics_9 = new cjs.Graphics().p("AiBD/QhCiuBMioQBNiqCshBQAZgJAZgHIByGyIAAAAIj/F4Qh0hOg0iLg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AiTDVQgoi2BjibQBjieC1gnQAagGAZgDIAzG+IAAAAIkxFQQhphegfiRg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AiqCkQgIi5B9iJQB9iKC5gHQAagBAZABIgaHAIgBAAIlmEWQhXhvgGiUg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AjSBuQAfi2CWhsQCXhtC2AfQAaAEAZAHIh3GwIAAABImZDFQg+h+AZiTg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AjlA5QBLiqCrhEQCuhECpBKQAYALAWANIjdGGIAAAAIm9BbQgdiKA8iHg");
	var mask_2_graphics_14 = new cjs.Graphics().p("Ak4EIQAFiMBbh1QByiSC3gYQC5gYCSByQAVAQASARIk2FFIAAAAg");
	var mask_2_graphics_15 = new cjs.Graphics().p("ABvEdIm3hyQAiiJBxheQCPh4C3APQC6APB4CNQARATAOAVIlzD+g");
	var mask_2_graphics_16 = new cjs.Graphics().p("ABcEdImdi8QA5iACBhKQCgheCzAvQC1AvBdCfQANAXAKAXImZC5g");
	var mask_2_graphics_17 = new cjs.Graphics().p("ABREeIl+j2QBLh2CKg4QCrhFCrBHQCsBJBGCqQAJAZAHAYImvB+g");
	var mask_2_graphics_18 = new cjs.Graphics().p("ABLEeIlfkfQBYhuCPgnQCzgyChBbQCjBcAxCxQAHAZAEAZIm7BMg");
	var mask_2_graphics_19 = new cjs.Graphics().p("ABIEeIlEk9QBihlCSgbQC2ghCZBoQCaBpAhC2QAFAaACAZInAAkg");
	var mask_2_graphics_20 = new cjs.Graphics().p("ABIEeIkulSQBoheCSgRQC5gVCSByQCSBzAVC4QADAaAAAZInBAGg");
	var mask_2_graphics_21 = new cjs.Graphics().p("ABIEXIAAgBIkelgQBthZCSgKQC6gMCMB5QCNB6AMC5QACAagBAZg");
	var mask_2_graphics_22 = new cjs.Graphics().p("ABIEPIAAAAIkSlpQBvhWCTgFQC6gGCIB+QCJB+AGC5QABAagCAZg");
	var mask_2_graphics_23 = new cjs.Graphics().p("ABIELIAAAAIkLluQBwhUCUgCQC6gDCFCBQCHCAACC5QABAbgDAZg");
	var mask_2_graphics_24 = new cjs.Graphics().p("ABIEJIAAAAIkIlxQByhTCTgBQC7AACECCQCFCCAAC5QABAagDAZg");
	var mask_2_graphics_25 = new cjs.Graphics().p("ABIEIIgBAAIkFlyQByhSCTAAQC6AACECCQCECCABC5QAAAbgDAZg");
	var mask_2_graphics_26 = new cjs.Graphics().p("ABIEIIgBAAIkGlzQBzhSCTAAQC6AACECDQCECCAAC5QAAAbgCAZg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:29.3366,y:50.6549}).wait(1).to({graphics:mask_2_graphics_1,x:29.3367,y:50.6522}).wait(1).to({graphics:mask_2_graphics_2,x:29.3374,y:50.6339}).wait(1).to({graphics:mask_2_graphics_3,x:29.3393,y:50.5828}).wait(1).to({graphics:mask_2_graphics_4,x:29.3432,y:50.477}).wait(1).to({graphics:mask_2_graphics_5,x:29.3496,y:50.2845}).wait(1).to({graphics:mask_2_graphics_6,x:29.3593,y:49.9558}).wait(1).to({graphics:mask_2_graphics_7,x:29.3732,y:49.4154}).wait(1).to({graphics:mask_2_graphics_8,x:29.3921,y:48.5526}).wait(1).to({graphics:mask_2_graphics_9,x:29.417,y:47.2147}).wait(1).to({graphics:mask_2_graphics_10,x:29.4486,y:45.2055}).wait(1).to({graphics:mask_2_graphics_11,x:30.8097,y:42.2989}).wait(1).to({graphics:mask_2_graphics_12,x:35.477,y:38.2744}).wait(1).to({graphics:mask_2_graphics_13,x:40.6375,y:32.9929}).wait(1).to({graphics:mask_2_graphics_14,x:45.1196,y:28.4688}).wait(1).to({graphics:mask_2_graphics_15,x:48.1803,y:28.5042}).wait(1).to({graphics:mask_2_graphics_16,x:50.1138,y:28.5389}).wait(1).to({graphics:mask_2_graphics_17,x:51.233,y:28.5688}).wait(1).to({graphics:mask_2_graphics_18,x:51.811,y:28.5933}).wait(1).to({graphics:mask_2_graphics_19,x:52.0596,y:28.6124}).wait(1).to({graphics:mask_2_graphics_20,x:52.1288,y:28.6267}).wait(1).to({graphics:mask_2_graphics_21,x:52.1371,y:29.4126}).wait(1).to({graphics:mask_2_graphics_22,x:52.1432,y:30.1397}).wait(1).to({graphics:mask_2_graphics_23,x:52.1476,y:30.58}).wait(1).to({graphics:mask_2_graphics_24,x:52.1502,y:30.8058}).wait(1).to({graphics:mask_2_graphics_25,x:52.1512,y:30.889}).wait(1).to({graphics:mask_2_graphics_26,x:52.1263,y:30.8759}).wait(99));

	// family slice
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(222,108,95,0.749)").s().p("AhcDMIgBAAIkGlyQByhSCUAAQC5AACECCQCECDAAC5QAAAagCAZg");
	this.shape_2.setTransform(68.6125,36.825);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(125));

	// Layer_1
	this.instance = new lib.clockImage();
	this.instance.setTransform(59.3,58.2,1.0289,1.0289,0,0,0,59.9,59.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(125));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-716.6,-3.4,978.9000000000001,277.9);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-15.4,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-61.15,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ApvCeIAAk7ITfAAIAAE7g");
	this.shape.setTransform(-50.7097,-0.7,1.1516,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.5,-16.5,143.6,31.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(217.7,219.75,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(280.75,220,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(165.35,14.95,0.9568,0.9568,0,0,0,-52.6,-23.8);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// bg img
	this.white = new lib.whitebg();
	this.white.name = "white";
	this.white.setTransform(360,127.9,1,1,0,0,0,60,132.4);

	this.clock = new lib.clock();
	this.clock.name = "clock";
	this.clock.setTransform(254.75,34.35,1,1,0,0,0,60,60);

	this.backImage = new lib.mainImage();
	this.backImage.name = "backImage";
	this.backImage.setTransform(141.8,132.95,1,1,0,0,0,220.2,165.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("ApX0rISvAAMAAAApXIyvAAg");
	this.shape.setTransform(364.2,128.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.backImage},{t:this.clock},{t:this.white}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-678.9,-32.8,1158.9,331.6), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "cloc") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillClock(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillClock = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.clock.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var phone = mc.phone
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
		
		
			this.tl1 = new TimelineLite();
				
				exportRoot.tl1.from(mc.backImage, 1.4, {x:"+=100", ease:Power4.easeOut},"+=0");
				exportRoot.tl1.from(mc.clock, 1.4, {x:"+=100", ease:Power4.easeOut, onComplete:function(){mc.clock.play(); exportRoot.tl1.stop();}},"-=1");
				
				
				exportRoot.tl1.to(mc.backImage, 1.4, {x:"-=77.2", ease:Power4.easeInOut},"+=0.7");
				exportRoot.tl1.to(mc.clock, 1.4, {x:"-=156.8", ease:Power4.easeInOut},"-=1.4");
				exportRoot.tl1.to(mc.white, 1.4, {x:"-=150", ease:Power4.easeInOut},"-=1.4");
				exportRoot.tl1.from(mc.logo_1, 1.4, {x:"+=150", ease:Power4.easeInOut},"-=1.2");
				
				
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=1");
					if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.8");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
					if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
			exportRoot.tlClock = new TimelineLite();
				for (var i = 0; i < exportRoot.clockText1.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText1[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText1[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				for (var i = 0; i < exportRoot.clockText2.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText2[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "+=0.5");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText2[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				for (var i = 0; i < exportRoot.clockText3.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText3[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "+=0.1");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText3[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				exportRoot.tlClock.stop()
				//exportRoot.tl1.to(mc.clock, 1.4, {x:"-=153.15", ease:Power4.easeOut},"0");
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
				
				
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(71.6,92.2,408.4,206.60000000000002);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1582630438382", id:"O365_FY20Q4_Cons_USA_300x250_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;