(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,351,264,153],[0,186,274,163],[579,166,265,154],[302,0,275,164],[579,322,265,154],[579,0,275,164],[276,332,265,154],[302,166,275,164],[0,0,300,184],[543,478,264,153]]}
];


// symbols:



(lib.Screen_Excel1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Screen_Excel_blur = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Screen_OneDrive1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Screen_OneDrive_blur1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Screen_Outlook1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Screen_Outlook_blur1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Screen_Powerpoint1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Screen_Powerpoint_blur1 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Screen_shadow11 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Screen_Word11 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg8HDe5MAAAm9xMB4OAAAMAAAG9xg");
	this.shape.setTransform(-1.25,0.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-386,-1426.4,769.5,2853);


(lib.Screen_shad = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Screen_shadow11();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_shad, new cjs.Rectangle(0,0,300,184), null);


(lib.screen_powerpoint_blur = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Screen_Powerpoint_blur1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_powerpoint_blur, new cjs.Rectangle(0,0,275,164), null);


(lib.screen_outlook_blur = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Screen_Outlook_blur1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_outlook_blur, new cjs.Rectangle(0,0,275,164), null);


(lib.screen_onedrive_blur = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Screen_OneDrive_blur1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_onedrive_blur, new cjs.Rectangle(0,0,275,164), null);


(lib.screen_excel_blur = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Screen_Excel_blur();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_excel_blur, new cjs.Rectangle(0,0,274,163), null);


(lib.pointer2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoCvQgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgFQgDgHACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAhuQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAEQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gdQgGAFgBAHQgCAGAEAFIBXBvQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhkQAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACVQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgNIgRgUQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,19.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCbIAAgeQAAgMgHgIIhXhvQgEgFACgGQABgHAGgFQALgJANAKIARAUIAFANQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAiVQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAABkQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,19.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2_sub, new cjs.Rectangle(0,2.4,29.6,35), null);


(lib.pointer1_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoC7QgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgGQgDgGACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAiGQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAcQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gRQgGAFgBAHQgCAFAEAFIBXBwQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAh8QAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACtQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgOIgRgTQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,18.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCnIAAgeQAAgMgHgIIhXhwQgEgFACgFQABgHAGgFQALgJANAKIARATIAFAOQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAitQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAAB8QAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,18.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1_sub, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.overlay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.098)").s().p("Aq1CYIAAkvIVrAAIAAEvg");
	this.shape.setTransform(69.425,15.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlay, new cjs.Rectangle(0,0,138.9,30.3), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.menu_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	// this.txt1 = new cjs.Text("Learn more", "12px 'Segoe Pro'");
	this.txt1 = new cjs.Text((dynamicData.dropdownText1 ? dynamicData.dropdownText1 : "Learn more"), (dynamicData.dropdownTextFont1 ? dynamicData.dropdownTextFont1 : 12) + "px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 12;
	this.txt1.lineWidth = 137;
	this.txt1.parent = this;
	this.txt1.setTransform(2,2);

	// this.txt2 = new cjs.Text("Monthly subscription", "12px 'Segoe Pro'");
	this.txt2 = new cjs.Text((dynamicData.dropdownText2 ? dynamicData.dropdownText2 : "Monthly subscription"), (dynamicData.dropdownTextFont2 ? dynamicData.dropdownTextFont2 : 12) + "px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 137;
	this.txt2.parent = this;
	this.txt2.setTransform(2, (this.txt2.text.indexOf('\n') == -1 ? 32 : 25));

	// this.txt3 = new cjs.Text("SAVE 16%\nAnnual subscription", "12px 'Segoe Pro'", "#0078D3");
	this.txt3 = new cjs.Text((dynamicData.dropdownText3 ? dynamicData.dropdownText3 : "SAVE 16%\nAnnual subscription"), (dynamicData.dropdownTextFont3 ? dynamicData.dropdownTextFont3 : 12) + "px 'Segoe Pro'", "#0078D3");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 12;
	this.txt3.lineWidth = 137;
	this.txt3.parent = this;
	this.txt3.setTransform(2, (this.txt3.text.indexOf('\n') == -1 ? 61.5 : 54.5));

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt3},{t:this.txt2},{t:this.txt1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.menu_text, new cjs.Rectangle(0,0,141.1,84.9), null);


(lib.mainBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFEFEF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.dropDownMenuBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s().p("Aq8CWIAAkrIV5AAIAAErg");
	this.shape.setTransform(70.125,15);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,140.3,30);


(lib.choice_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	// this.txt = new cjs.Text("BUY NOW", "12px 'Segoe Pro'", "#0078D3");
	this.txt = new cjs.Text((dynamicData.dropdownText ? dynamicData.dropdownText : "BUY NOW"), (dynamicData.dropdownTextFont ? dynamicData.dropdownTextFont : 11) + "px 'Segoe Pro'", "#0078D3");
	this.txt.name = "txt";
	this.txt.lineHeight = 17;
	this.txt.lineWidth = 216;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.choice_text, new cjs.Rectangle(0,0,219.8,26.6), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(80.0011,299.9992,0.5333,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,160,600), null);


(lib.Word_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Screen_Word.png
	this.instance = new lib.Screen_Word11();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_11
	this.shad = new lib.Screen_shad();
	this.shad.name = "shad";
	this.shad.setTransform(266.05,170.1,1,1,0,0,0,300,184);

	this.timeline.addTween(cjs.Tween.get(this.shad).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word_screen, new cjs.Rectangle(-33.9,-13.9,300,184), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Powerpoint_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Screen_Powerpoint.png
	this.blur = new lib.screen_powerpoint_blur();
	this.blur.name = "blur";
	this.blur.setTransform(264.5,153.5,1,1,0,0,0,274.5,163.5);
	this.blur.alpha = 0.3008;

	this.timeline.addTween(cjs.Tween.get(this.blur).wait(1));

	// Screen_Powerpoint.png
	this.instance = new lib.Screen_Powerpoint1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_11
	this.shad = new lib.Screen_shad();
	this.shad.name = "shad";
	this.shad.setTransform(266.05,170.1,1,1,0,0,0,300,184);

	this.timeline.addTween(cjs.Tween.get(this.shad).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint_screen, new cjs.Rectangle(-33.9,-13.9,300,184), null);


(lib.pointer2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer2_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(11.35,8.3,1,1,-3.4817,0,0,11.3,8.3);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2, new cjs.Rectangle(-0.3,1.3,31.6,36.7), null);


(lib.pointer1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer1_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_1
	this.instance = new lib.pointer1();
	this.instance.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.instance_1 = new lib.pointer2();
	this.instance_1.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0,31.6,38);


(lib.Outlook_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.blur = new lib.screen_outlook_blur();
	this.blur.name = "blur";
	this.blur.setTransform(264.5,153.5,1,1,0,0,0,274.5,163.5);
	this.blur.alpha = 0.8008;

	this.timeline.addTween(cjs.Tween.get(this.blur).wait(1));

	// Screen_Outlook.png
	this.instance = new lib.Screen_Outlook1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_11
	this.shad = new lib.Screen_shad();
	this.shad.name = "shad";
	this.shad.setTransform(266.05,170.1,1,1,0,0,0,300,184);

	this.timeline.addTween(cjs.Tween.get(this.shad).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_screen, new cjs.Rectangle(-33.9,-13.9,300,184), null);


(lib.OneDrive_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_12
	this.blur = new lib.screen_onedrive_blur();
	this.blur.name = "blur";
	this.blur.setTransform(264.5,153.5,1,1,0,0,0,274.5,163.5);

	this.timeline.addTween(cjs.Tween.get(this.blur).wait(1));

	// Screen_OneDrive.png
	this.instance = new lib.Screen_OneDrive1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_11
	this.shad = new lib.Screen_shad();
	this.shad.name = "shad";
	this.shad.setTransform(266.05,170.1,1,1,0,0,0,300,184);

	this.timeline.addTween(cjs.Tween.get(this.shad).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive_screen, new cjs.Rectangle(-33.9,-13.9,300,184), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		exportRoot.tlicons.play()
	}
	this.frame_86 = function() {
		exportRoot.tl1.play()
		//exportRoot.mainMC.screen.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(17).call(this.frame_86).wait(14).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:0.3,scaleX:3.2298,scaleY:3.2298,x:166.95,y:-920.35},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(298.9,337.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.1,-1088.8,769.5,2853);


(lib.menuChoice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.choice_text.cache(0,-20,220,27,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3F3F").s().p("AgkASIAkgjIAlAjg");
	this.shape.setTransform(173.675,195.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Outline
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#292929").s().p("Aq3CYIAAkvIAHAAIVoAAIAAEvgAqwCSIVhAAIAAkgI1hAAg");
	this.shape_1.setTransform(122.95,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Text
	this.choice_text = new lib.choice_text();
	this.choice_text.name = "choice_text";
	this.choice_text.setTransform(174.9,211.5,1,1,0,0,0,109.9,13.3);

	this.timeline.addTween(cjs.Tween.get(this.choice_text).wait(1));

	// Layer_2
	this.txt2 = new cjs.Text("", "11px 'Segoe Pro'", "#D84739");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 17;
	this.txt2.lineWidth = 216;
	this.txt2.parent = this;
	this.txt2.setTransform(67,200.2);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqzCVIAAkpIVnAAIAAEpg");
	this.shape_2.setTransform(122.925,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(53.4,180.4,231.4,44.400000000000006);


(lib.Menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.menu_text.cache(0,-10,150,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.btn1 = new lib.dropDownMenuBtn();
	this.btn1.name = "btn1";
	this.btn1.setTransform(0.15,-0.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn2 = new lib.dropDownMenuBtn();
	this.btn2.name = "btn2";
	this.btn2.setTransform(0.15,29.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn3 = new lib.dropDownMenuBtn();
	this.btn3.name = "btn3";
	this.btn3.setTransform(0.15,58.9,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn3},{t:this.btn2},{t:this.btn1}]}).wait(1));

	// Outline
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#292929").s().p("AKzG+IAAgBI1lAAIAAABIgHAAIAAt7IVyAAIAAN7gAqyG2IVlAAIAAkeI1lAAgAqyCRIVlAAIAAkeI1lAAgAqyiUIVlAAIAAkiI1lAAg");
	this.shape.setTransform(69.15,43.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// txt_backup
	this.menu_text = new lib.menu_text();
	this.menu_text.name = "menu_text";
	this.menu_text.setTransform(81.75,59.5,1,1,0,0,0,70.5,42.5);

	this.timeline.addTween(cjs.Tween.get(this.menu_text).wait(1));

	// rollOver
	this.ro3 = new lib.overlay();
	this.ro3.name = "ro3";
	this.ro3.setTransform(114.2,73.1,1,0.9439,0,0,0,114.4,15.2);
	this.ro3.alpha = 0;

	this.ro2 = new lib.overlay();
	this.ro2.name = "ro2";
	this.ro2.setTransform(114.2,43.9,1,0.9439,0,0,0,114.4,15.2);
	this.ro2.alpha = 0;

	this.ro1 = new lib.overlay();
	this.ro1.name = "ro1";
	this.ro1.setTransform(114.2,14.65,1,1,0,0,0,114.4,15.2);
	this.ro1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ro1},{t:this.ro2},{t:this.ro3}]}).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AqzG6IAAtzIVnAAIAANzg");
	this.shape_1.setTransform(68.925,43.575);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-0.9,152.9,102.80000000000001);


(lib.Excel_screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.blur = new lib.screen_excel_blur();
	this.blur.name = "blur";
	this.blur.setTransform(264.5,153.5,1,1,0,0,0,274.5,163.5);
	this.blur.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.blur).wait(1));

	// Screen_Excel.png
	this.instance = new lib.Screen_Excel1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_11
	this.shad = new lib.Screen_shad();
	this.shad.name = "shad";
	this.shad.setTransform(266.05,170.1,1,1,0,0,0,300,184);

	this.timeline.addTween(cjs.Tween.get(this.shad).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_screen, new cjs.Rectangle(-33.9,-13.9,300,184), null);


(lib.drop_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// pointer
	this.pointer = new lib.pointer();
	this.pointer.name = "pointer";
	this.pointer.setTransform(117.8,232.6,0.6379,0.6379,0,0,0,14.8,18.8);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsHCkIAAlHIYPAAIAAFHg");
	mask.setTransform(90.4,220.825);

	// Menu
	this.selectorBox = new lib.menuChoice();
	this.selectorBox.name = "selectorBox";
	this.selectorBox.setTransform(138.45,114.6,1,1,0,0,0,175.3,90.5);

	var maskedShapeInstanceList = [this.selectorBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.selectorBox).wait(1));

	// Layer_6 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ay1HhIAAvBMAlrAAAIAAPBg");
	mask_1.setTransform(133.4,157.025);

	// Menu copy
	this.menu = new lib.Menu();
	this.menu.name = "menu";
	this.menu.setTransform(16.5,205.3,1,1,0,0,0,-0.5,-0.7);

	var maskedShapeInstanceList = [this.menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.menu).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.drop_menu, new cjs.Rectangle(16.4,204.5,152.9,40), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,160,600,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,160,600), null);


(lib.laptop_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Word
	this.screen_word = new lib.Word_screen();
	this.screen_word.name = "screen_word";
	this.screen_word.setTransform(268.45,-86.2,0.47,0.47,0,0,0,116.2,80.8);

	this.timeline.addTween(cjs.Tween.get(this.screen_word).wait(1));

	// Excel
	this.screen_excel = new lib.Excel_screen();
	this.screen_excel.name = "screen_excel";
	this.screen_excel.setTransform(360.05,-40.15,0.47,0.47,0,0,0,112.7,81);

	this.timeline.addTween(cjs.Tween.get(this.screen_excel).wait(1));

	// Powerpoint
	this.screen_powerpoint = new lib.Powerpoint_screen();
	this.screen_powerpoint.name = "screen_powerpoint";
	this.screen_powerpoint.setTransform(253.55,-5.75,0.4703,0.4703,0,0,0,114.6,85);

	this.timeline.addTween(cjs.Tween.get(this.screen_powerpoint).wait(1));

	// Outlook
	this.screen_outlook = new lib.Outlook_screen();
	this.screen_outlook.name = "screen_outlook";
	this.screen_outlook.setTransform(344.05,38.95,0.47,0.47,0,0,0,120.9,70.5);

	this.timeline.addTween(cjs.Tween.get(this.screen_outlook).wait(1));

	// OneDrive
	this.screen_onedrive = new lib.OneDrive_screen();
	this.screen_onedrive.name = "screen_onedrive";
	this.screen_onedrive.setTransform(282.5,-156.85,0.47,0.47,0,0,0,111.3,84);

	this.timeline.addTween(cjs.Tween.get(this.screen_onedrive).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.laptop_anim, new cjs.Rectangle(183.7,-202.8,248.40000000000003,288.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// drop_menu
	this.dropdown = new lib.drop_menu();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(-6,349.25);
	this.dropdown.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// icons
	this.screens = new lib.laptop_anim();
	this.screens.name = "screens";
	this.screens.setTransform(84.65,430.25,1,1,0,0,0,284.2,24.8);
	this.screens.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.screens).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(80.7,300.6,0.22,0.22,0,0,0,298.7,339.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(143.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// dropDownMenuBtn
	this.dropDownMenuBtn = new lib.dropDownMenuBtn();
	this.dropDownMenuBtn.name = "dropDownMenuBtn";
	this.dropDownMenuBtn.setTransform(126,635.75,1,1,0,0,0,116,81.5);
	new cjs.ButtonHelper(this.dropDownMenuBtn, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.dropDownMenuBtn).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// BG
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-15.8,-13.5,679.1999999999999,995.8), null);


// stage content:
(lib.Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						}
				}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var screen = mc.screen
		var phone = mc.phone
		
		this.runBanner = function() {
			
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
				
				//exportRoot.tl1.from(mc.bg, 1, { alpha:0,	ease:Quart.easeInOut}, "=0");
						
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "+=0.3");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
			exportRoot.tl1.from(mc.dropdown, 0.8, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.5");
			exportRoot.tl1.to(mc.dropdown, 0.1, {alpha: 1, ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "+=0.4");
				
			exportRoot.tl1.from(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {alpha:1, onStart:function(){mc.dropdown.pointer.gotoAndPlay(1);exportRoot.showMenu()}}, "+=0.2");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power3.easeIn}, "+=0.5");
				
			exportRoot.tl1.stop();
			
			this.tlicons = new TimelineLite();		
				
				exportRoot.tlicons.to(mc.screens, 0.1, {alpha:1}, "=0");
				exportRoot.tlicons.from(mc.screens.screen_outlook, 4, {scaleX: .4, scaleY:.4, x: "+=250",  y: "+=250",	ease:Quart.easeOut}, "-=0");
				exportRoot.tlicons.from(mc.screens.screen_outlook.shad, 4, {x: "+=40",  y: "+=80",	ease:Quart.easeOut}, "-=4");
				exportRoot.tlicons.to(mc.screens.screen_outlook.blur, 4, { alpha:0,	ease:Quart.easeInOut}, "-=4");
				exportRoot.tlicons.from(mc.screens, 3, {scaleX: 1.4, scaleY:1.5, y: "-=50",	ease:Power4.easeOut}, "-=4");
				exportRoot.tlicons.from(mc.screens.screen_onedrive, 4, {x: "+=300", y: "+=400",	ease:Quart.easeOut}, "-=3.9");
				exportRoot.tlicons.from(mc.screens.screen_onedrive.shad, 4, {y: "+=28",	ease:Quart.easeOut}, "-=4");
				exportRoot.tlicons.to(mc.screens.screen_onedrive.blur, 4, { alpha:0,	ease:Quart.easeInOut}, "-=4");
				exportRoot.tlicons.from(mc.screens.screen_excel, 4, {scaleX: .5, scaleY:.5, x: "+=375",  y: "+=200",	ease:Quart.easeOut}, "-=3.9");
				exportRoot.tlicons.from(mc.screens.screen_excel.shad, 4, {alpha:40, x: "+=60",  y: "+=120",	ease:Quart.easeOut}, "-=4");
				exportRoot.tlicons.to(mc.screens.screen_excel.blur, 4, { alpha:0,	ease:Quart.easeInOut}, "-=4");
				exportRoot.tlicons.from(mc.screens.screen_powerpoint, 4, {scaleX: 1.4, scaleY:1.4, x: "+=350",  y: "+=400",	ease:Quart.easeOut}, "-=3.8");
				exportRoot.tlicons.from(mc.screens.screen_powerpoint.shad, 4, {alpha:60, x: "+=70",  y: "+=140",	ease:Quart.easeOut}, "-=4");
				exportRoot.tlicons.to(mc.screens.screen_powerpoint.blur, 4, { alpha:0,	ease:Quart.easeInOut}, "-=4");
				exportRoot.tlicons.from(mc.screens.screen_word, 4, {scaleX: 1.4, scaleY:1.4, x: "+=300",  y: "-=400",	ease:Quart.easeOut}, "-=3.8");
				exportRoot.tlicons.from(mc.screens.screen_word.shad, 4, {alpha:20, x: "+=150",  y: "+=300",	ease:Quart.easeOut}, "-=4");
				
				exportRoot.tlicons.stop();
		
			mc.logo_intro.gotoAndPlay(1);
		}
		exportRoot.myTimer = function() {
			exportRoot.hideMenu()
		}
		
		exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		
		
		var theMenu = exportRoot.mainMC.dropdown.menu
		var theMenuBtn = exportRoot.mainMC.dropDownMenuBtn
		var menuClosed = true
		
		exportRoot.btn1 = theMenu.btn1; var ro1 = theMenu.ro1;
		exportRoot.btn2 = theMenu.btn2; var ro2 = theMenu.ro2;
		exportRoot.btn3 = theMenu.btn3; var ro3 = theMenu.ro3;
		exportRoot.btn1.enabled = false
		exportRoot.btn2.enabled = false
		exportRoot.btn3.enabled = false
		
		theMenuBtn.addEventListener("click", function(event) { exportRoot.menuClick() })
		
		this.menuClick = function() {
			TweenMax.killTweensOf(theMenu);
			if (menuClosed) exportRoot.showMenu()
			if (!menuClosed) exportRoot.hideMenu()
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		
		this.showMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:117, ease:Power4.easeOut, onComplete:function(){menuClosed = false}});
			exportRoot.btn1.enabled = true
			exportRoot.btn2.enabled = true
			exportRoot.btn3.enabled = true
			
		}
		this.hideMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:206.3, ease:Power4.easeOut, onComplete:function(){menuClosed = true}});
			exportRoot.btn1.enabled = false
			exportRoot.btn2.enabled = false
			exportRoot.btn3.enabled = false
		}
		
		exportRoot.btn1.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(1) })
		exportRoot.btn2.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(2) })
		exportRoot.btn3.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(3) })
		
		
		exportRoot.btn1.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(1) })
		exportRoot.btn2.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(2) })
		exportRoot.btn3.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(3) })
		
		exportRoot.rollOverAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:1});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		exportRoot.rollOutAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:0});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	// btn
	this.btn = new lib.mainBtn();
	this.btn.name = "btn";
	this.btn.setTransform(102.5,92,1,1,0,0,0,102.5,92);
	new cjs.ButtonHelper(this.btn, 0, 1, 2, false, new lib.mainBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(64.2,286.5,183.8,370.70000000000005);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_.png?1582292690134", id:"Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_AI_Screens_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;