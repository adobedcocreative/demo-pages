(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[0,0,391,650],[0,652,200,200]]}
];


// symbols:



(lib.bg_image = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Clock = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.mainImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#88857C").s().p("A4GU6MAAAgp0MAwNAAAMAAAAp0g");
	this.shape.setTransform(131.975,165.35);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.bg_image();
	this.instance.setTransform(-21.5,124.05,0.7852,0.7852);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainImage, new cjs.Rectangle(-22.3,31.5,308.6,602.9), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.clockImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Clock();
	this.instance.setTransform(-0.05,0.05,0.6,0.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.clockImage, new cjs.Rectangle(0,0.1,120,120), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		exportRoot.tl1.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(24).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(66.5,886.1,0.1849,0.1849,0,0,0,-39.5,1.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.0594,scaleY:3.0594,x:66.4},13,cjs.Ease.quadOut).to({x:-103.6},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgUrBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_15 = new cjs.Graphics().p("EgU3BHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_16 = new cjs.Graphics().p("EgVaBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_17 = new cjs.Graphics().p("EgWVBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_18 = new cjs.Graphics().p("EgXoBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_19 = new cjs.Graphics().p("EgZSBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_20 = new cjs.Graphics().p("EgbUBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_21 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_22 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_23 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_24 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_25 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_26 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:231.7572,y:459.506}).wait(1).to({graphics:mask_graphics_15,x:230.575,y:459.506}).wait(1).to({graphics:mask_graphics_16,x:227.0284,y:459.506}).wait(1).to({graphics:mask_graphics_17,x:221.1174,y:459.506}).wait(1).to({graphics:mask_graphics_18,x:212.842,y:459.506}).wait(1).to({graphics:mask_graphics_19,x:202.2023,y:459.506}).wait(1).to({graphics:mask_graphics_20,x:189.1981,y:459.506}).wait(1).to({graphics:mask_graphics_21,x:170.3212,y:459.506}).wait(1).to({graphics:mask_graphics_22,x:149.0417,y:459.506}).wait(1).to({graphics:mask_graphics_23,x:132.491,y:459.506}).wait(1).to({graphics:mask_graphics_24,x:120.669,y:459.506}).wait(1).to({graphics:mask_graphics_25,x:113.5758,y:459.506}).wait(1).to({graphics:mask_graphics_26,x:111.3476,y:459.506}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-200.65,882.4,3.0594,3.0594,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:19.15},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgqKCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgtbCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Egw4CaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Eg0hCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Eg4UCaqMAAAk1TMBSHAAAMAAAE1Tg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:68.2273,y:916.1858}).wait(51).to({graphics:mask_1_graphics_51,x:68.2273,y:916.1858}).wait(1).to({graphics:mask_1_graphics_52,x:67.0331,y:916.1858}).wait(1).to({graphics:mask_1_graphics_53,x:63.4503,y:916.1858}).wait(1).to({graphics:mask_1_graphics_54,x:57.479,y:916.1858}).wait(1).to({graphics:mask_1_graphics_55,x:49.1193,y:916.1858}).wait(1).to({graphics:mask_1_graphics_56,x:38.371,y:916.1858}).wait(1).to({graphics:mask_1_graphics_57,x:25.2342,y:916.1858}).wait(1).to({graphics:mask_1_graphics_58,x:9.7088,y:916.1858}).wait(1).to({graphics:mask_1_graphics_59,x:-8.205,y:916.1858}).wait(1).to({graphics:mask_1_graphics_60,x:-28.5073,y:916.1858}).wait(1).to({graphics:mask_1_graphics_61,x:-51.1982,y:916.1858}).wait(1).to({graphics:mask_1_graphics_62,x:-76.2775,y:916.1858}).wait(1).to({graphics:mask_1_graphics_63,x:-103.7454,y:916.1858}).wait(1).to({graphics:mask_1_graphics_64,x:-133.6018,y:916.1858}).wait(1).to({graphics:mask_1_graphics_65,x:-165.8467,y:916.1858}).wait(1).to({graphics:mask_1_graphics_66,x:-200.4801,y:916.1858}).wait(1).to({graphics:mask_1_graphics_67,x:-237.502,y:916.1858}).wait(1).to({graphics:mask_1_graphics_68,x:-269.8699,y:916.1858}).wait(1).to({graphics:mask_1_graphics_69,x:-290.7693,y:916.1858}).wait(1).to({graphics:mask_1_graphics_70,x:-312.8631,y:916.1858}).wait(1).to({graphics:mask_1_graphics_71,x:-336.151,y:916.1858}).wait(1).to({graphics:mask_1_graphics_72,x:-360.525,y:916.1858}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(19.15,882.4,3.0594,3.0594,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(68.2,2281.7,0.5414,5.7885,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({scaleY:5.7403,y:2262.05},0).to({regX:484.9,x:-458.55},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(68.2,2281.7,0.5414,5.7885,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({scaleY:5.741,y:2262.35},0).wait(2).to({regX:484.9,scaleY:5.7885,x:-458.55,y:2281.7},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-721,-73.6,1052.1,1979.6);


(lib.clock = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_26 = function() {
		exportRoot.tlClock.play()
	}
	this.frame_124 = function() {
		this.stop();
		exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(26).call(this.frame_26).wait(98).call(this.frame_124).wait(1));

	// smiles mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ACQIOQjJgzhsizQgXglgOgmIHci6IAzH6QgXABgVAAQhHAAhCgQg");
	var mask_graphics_86 = new cjs.Graphics().p("ACQIOQjJgzhsizQgXglgOgmIHci6IAzH6QgXABgVAAQhHAAhCgQg");
	var mask_graphics_87 = new cjs.Graphics().p("ACQIOQjJgzhsizQgXglgOgmIHci6IAzH6QgXABgVAAQhHAAhCgQg");
	var mask_graphics_88 = new cjs.Graphics().p("ACPINQjJgzhrizQgXglgOgmIHci5IAyH6IgqABQhIAAhDgRg");
	var mask_graphics_89 = new cjs.Graphics().p("ACOINQjJg0hri0QgVglgPgnIHei2IAvH6IgnABQhKAAhEgRg");
	var mask_graphics_90 = new cjs.Graphics().p("ACLILQjIg2hpi1QgVgmgOgmIHgixIApH6IggABQhOAAhHgTg");
	var mask_graphics_91 = new cjs.Graphics().p("ACHIIQjHg6hli3QgVglgOgnIHjioIAgH7IgVAAQhTAAhMgWg");
	var mask_graphics_92 = new cjs.Graphics().p("ACBIEQjGhAhgi5QgUgngMgnIHniaIASH7IgDABQhdgBhTgag");
	var mask_graphics_93 = new cjs.Graphics().p("AB3H9QjDhHhZi9QgSgngLgoIHtiHIgBH8QhfgEhUgeg");
	var mask_graphics_94 = new cjs.Graphics().p("ABfH0Qi/hRhPjCQgQgogJgoIHzhuIgbH7QhfgIhSgig");
	var mask_graphics_95 = new cjs.Graphics().p("ABBHnQi5hehCjGQgOgpgGgoIH5hOIg8H5QhegOhQgog");
	var mask_graphics_96 = new cjs.Graphics().p("AAdHWQixhtgyjLQgKgqgDgpIH+gjIhlHyQhdgWhMgug");
	var mask_graphics_97 = new cjs.Graphics().p("AgLG/Qinh+gdjPQgGgqABgqIH/AQIiXHlQhZgfhGg1g");
	var mask_graphics_98 = new cjs.Graphics().p("Ag5GhQiWiQgFjRQAAgrAGgoIH5BMIjQHPQhVgpg/g+g");
	var mask_graphics_99 = new cjs.Graphics().p("AhoF8QiBikAajPQAFgqAMgoIHpCTIkPGtQhNg0g3hHg");
	var mask_graphics_100 = new cjs.Graphics().p("AiPFWQhoi1A2jJQALgqASglIHPDWIlIGDQhGg/gshNg");
	var mask_graphics_101 = new cjs.Graphics().p("AiqE0QhRjABOjBQAQgoAWgjIGyEMIl0FZQg+hHgjhSg");
	var mask_graphics_102 = new cjs.Graphics().p("Ai6EXQg+jHBgi4QAUgmAaghIGVE3ImUEyQg3hOgahVg");
	var mask_graphics_103 = new cjs.Graphics().p("AjFEAQgtjLBwiwQAXgkAbgfIF7FXImsEQQgwhSgUhXg");
	var mask_graphics_104 = new cjs.Graphics().p("AjKDuQggjOB7ioQAZgjAegcIFjFuIm9DzQgrhUgNhYg");
	var mask_graphics_105 = new cjs.Graphics().p("AjNDgQgWjQCEihQAbgiAfgbIFQGBInJDcQgmhXgJhYg");
	var mask_graphics_106 = new cjs.Graphics().p("AjPDVQgNjQCJicQAdghAggZIFBGMInRDLQgjhYgGhZg");
	var mask_graphics_107 = new cjs.Graphics().p("AjPDOQgIjQCOiZQAdggAhgZIE2GWInWC+QghhZgDhZg");
	var mask_graphics_108 = new cjs.Graphics().p("AjPDJQgEjQCQiXQAegfAigYIEuGbInZC1QgghZgBhZg");
	var mask_graphics_109 = new cjs.Graphics().p("AjPDGQgCjQCSiVQAfgfAggYIErGfInbCwQgehagBhZg");
	var mask_graphics_110 = new cjs.Graphics().p("AjPDEQgBjPCUiVQAegeAhgYIEoGgIncCtQgehaAAhZg");
	var mask_graphics_111 = new cjs.Graphics().p("AjPDEQAAjQCTiUQAfgeAggYIEoGhIndCsQgdhaAAhZg");
	var mask_graphics_112 = new cjs.Graphics().p("AjQDDQAAjPCUiUQAegeAhgYIEoGhIndCsQgehbAAhZg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:32.464,y:54.2155}).wait(86).to({graphics:mask_graphics_86,x:32.464,y:54.2155}).wait(1).to({graphics:mask_graphics_87,x:32.4564,y:54.2154}).wait(1).to({graphics:mask_graphics_88,x:32.403,y:54.2161}).wait(1).to({graphics:mask_graphics_89,x:32.2579,y:54.2183}).wait(1).to({graphics:mask_graphics_90,x:31.9752,y:54.223}).wait(1).to({graphics:mask_graphics_91,x:31.5086,y:54.2323}).wait(1).to({graphics:mask_graphics_92,x:30.8115,y:54.2502}).wait(1).to({graphics:mask_graphics_93,x:29.9144,y:54.2655}).wait(1).to({graphics:mask_graphics_94,x:29.9145,y:54.2285}).wait(1).to({graphics:mask_graphics_95,x:29.9147,y:54.0843}).wait(1).to({graphics:mask_graphics_96,x:29.9152,y:53.7524}).wait(1).to({graphics:mask_graphics_97,x:29.916,y:53.1216}).wait(1).to({graphics:mask_graphics_98,x:29.9172,y:52.0467}).wait(1).to({graphics:mask_graphics_99,x:29.919,y:50.3502}).wait(1).to({graphics:mask_graphics_100,x:29.9212,y:48.2241}).wait(1).to({graphics:mask_graphics_101,x:29.9232,y:46.1201}).wait(1).to({graphics:mask_graphics_102,x:29.925,y:44.1754}).wait(1).to({graphics:mask_graphics_103,x:29.9266,y:42.4689}).wait(1).to({graphics:mask_graphics_104,x:29.9279,y:41.0363}).wait(1).to({graphics:mask_graphics_105,x:29.9289,y:39.8843}).wait(1).to({graphics:mask_graphics_106,x:29.9297,y:38.9995}).wait(1).to({graphics:mask_graphics_107,x:29.9302,y:38.3564}).wait(1).to({graphics:mask_graphics_108,x:29.9306,y:37.9213}).wait(1).to({graphics:mask_graphics_109,x:29.9308,y:37.6558}).wait(1).to({graphics:mask_graphics_110,x:29.9309,y:37.5191}).wait(1).to({graphics:mask_graphics_111,x:29.931,y:37.4686}).wait(1).to({graphics:mask_graphics_112,x:29.8747,y:37.4614}).wait(13));

	// smiles slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(117,190,221,0.749)").s().p("Aj9B3QAAjQCUiTQAegfAigXIEnGgIncCmQgfhUAAhZg");
	this.shape.setTransform(34.425,45.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(125));

	// memory mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AAwEVInHjYQBOitC0hQQCzhQDFBNQDFBOBGCYQBGCZgMByg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AAwEVInHjYQBOitC0hQQCzhQDFBNQDFBOBGCYQBGCZgMByg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AAwEVInHjYQBPiuCzhQQCzhQDFBOQDFBPBGCXQBGCZgMByg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AAwEUInGjaQBPitC0hQQCzhPDFBPQDFBPBFCYQBGCZgOByg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AAwERInEjgQBSisC1hNQC0hNDEBRQDEBSBDCZQBECZgPByg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AAwELIm/jqQBWiqC3hJQC2hJDCBWQDBBWBACaQBACcgRBxg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AAwECIm1j8QBcimC6hCQC4hCC+BdQC/BdA6CdQA5CegVBxg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AAwDzImmkTQBmiiC9g3QC7g3C5BoQC5BoAxCgQAwChgcBvg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AAwDgImOk0QByiaDBgoQC/gnCwB2QCwB3AkCjQAkCkglBtg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AAwDGIlrldQCCiMDDgTQDEgTCiCIQCiCJASCmQASCngwBog");
	var mask_1_graphics_52 = new cjs.Graphics().p("AAvCnIk4mLQCUh6DDAIQDFAICOCdQCOCegFCnQgFCog+Bgg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AAtCDIjwm6QCnhfC/ApQDAAqBxCzQByCygiClQghCkhOBVg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AAuBeIiQnjQC2g6C0BQQCzBRBKDGQBKDGhDCaQhDCahdBDg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AAvA9IgTn4QC/gLCaB6QCaB7AWDRQAWDThmCFQhnCFhrAqg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AAuAoICAnoQC6AuBwCiQBwChgoDPQgpDRiJBhQiJBhhyAIg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AgjIWIBPnxIEJmtQClBhA8C8QA7C6hjC7QhjC8ifA1QhtAkhWAAQgpAAgjgJg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AibH0IDHnPIFsleQCHCIAMDDQALDEiOCdQiPCdinAMQgfACgdAAQh+AAhTgqg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AAIIdQilgXhZhJIEjmaIGskLQBpCggeDCQgdDCisB8QiRBoiNAAQgaAAgbgDg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AhMIPQigg0hMhWIFlljIHUi+QBLCvg+C6Qg+C7i+BdQh7A8huAAQg8AAg5gSg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AiNH6QiYhIg/hgIGSkvIHph9QAzC4hXCwQhXCxjJBCQhgAfhVAAQhcAAhPgmg");
	var mask_1_graphics_62 = new cjs.Graphics().p("Ai+HkQiPhYg1hmIGwkCIH0hIQAfC8hpCmQhpCmjQAsQhFAPg+AAQh7AAhfg7g");
	var mask_1_graphics_63 = new cjs.Graphics().p("AjhHQQiHhjgshqIHDjfIH4ggQAQC+h3CeQh2CdjSAbQgtAGgrAAQiXAAhqhOg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Aj4HAQiChrgmhsIHPjEIH5gEQAFC/h/CWQh/CXjTAPQgbACgZAAQivAAhxheg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AkIG1Qh9hwgihuIHWiyIH5APQgDDAiECRQiFCRjUAIIgZAAQjBAAh2hpg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AkRGtQh7hygfhvIHainIH5AbQgHC/iICOQiICPjUACIgJAAQjNAAh4hxg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AA3IeQjTAAh5h1Qh6h0gehvIHdihIH4AhQgKC/iJCNQiKCMjUAAIAAAAg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AA1IeQjTgBh5h1Qh5h1gdhvIHdifIH4AjQgLC/iKCMQiJCLjSAAIgDAAg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AA0IeQjTgCh5h1Qh5h1gdhvIHdifIH4AkQgKC/iLCMQiJCLjSAAIgDAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:55.3577,y:30.1964}).wait(43).to({graphics:mask_1_graphics_43,x:55.3577,y:30.1964}).wait(1).to({graphics:mask_1_graphics_44,x:55.3579,y:30.2122}).wait(1).to({graphics:mask_1_graphics_45,x:55.3601,y:30.3234}).wait(1).to({graphics:mask_1_graphics_46,x:55.3653,y:30.6251}).wait(1).to({graphics:mask_1_graphics_47,x:55.3724,y:31.2117}).wait(1).to({graphics:mask_1_graphics_48,x:55.3761,y:32.1761}).wait(1).to({graphics:mask_1_graphics_49,x:55.3668,y:33.6055}).wait(1).to({graphics:mask_1_graphics_50,x:55.3367,y:35.5737}).wait(1).to({graphics:mask_1_graphics_51,x:55.3093,y:38.125}).wait(1).to({graphics:mask_1_graphics_52,x:55.4325,y:41.2443}).wait(1).to({graphics:mask_1_graphics_53,x:55.591,y:44.8107}).wait(1).to({graphics:mask_1_graphics_54,x:55.546,y:48.5304}).wait(1).to({graphics:mask_1_graphics_55,x:55.3292,y:51.8589}).wait(1).to({graphics:mask_1_graphics_56,x:55.4418,y:53.9395}).wait(1).to({graphics:mask_1_graphics_57,x:55.6162,y:54.2539}).wait(1).to({graphics:mask_1_graphics_58,x:55.5548,y:54.2031}).wait(1).to({graphics:mask_1_graphics_59,x:55.4705,y:54.4446}).wait(1).to({graphics:mask_1_graphics_60,x:55.4339,y:54.4873}).wait(1).to({graphics:mask_1_graphics_61,x:55.38,y:54.4102}).wait(1).to({graphics:mask_1_graphics_62,x:55.3203,y:54.3133}).wait(1).to({graphics:mask_1_graphics_63,x:55.2713,y:54.2439}).wait(1).to({graphics:mask_1_graphics_64,x:55.2392,y:54.21}).wait(1).to({graphics:mask_1_graphics_65,x:55.2185,y:54.2008}).wait(1).to({graphics:mask_1_graphics_66,x:55.1928,y:54.2026}).wait(1).to({graphics:mask_1_graphics_67,x:55.1742,y:54.2061}).wait(1).to({graphics:mask_1_graphics_68,x:55.1665,y:54.2077}).wait(1).to({graphics:mask_1_graphics_69,x:55.1093,y:54.1516}).wait(56));

	// memories slice
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(98,123,157,0.749)").s().p("Al0BkQhVhUgjhoIHgifIH5AlQgUC5iAB9QiVCUjQAAQjSAAiWiUg");
	this.shape_1.setTransform(61.1,82.625);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(125));

	// family mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AhPF+QiOibAIjRQAIjRCaiMQAWgVAXgQIEuGUIAAAAIhtH1Qibgghvh7g");
	var mask_2_graphics_1 = new cjs.Graphics().p("AhQF+QiOibAJjRQAIjRCaiNQAWgUAXgRIEuGVIAAAAIhtH1Qibgghwh7g");
	var mask_2_graphics_2 = new cjs.Graphics().p("AhRF9QiNicAJjQQAJjSCaiMQAWgUAXgQIEtGVIAAABIhvH0Qibghhvh7g");
	var mask_2_graphics_3 = new cjs.Graphics().p("AhUF5QiMidALjQQALjRCciLQAWgTAXgRIEpGZIAAAAIh0HzQiagihuh9g");
	var mask_2_graphics_4 = new cjs.Graphics().p("AhbFzQiJigAQjQQAPjQCeiIQAXgTAXgQIEhGeIAAAAIh9HxQiaglhsh/g");
	var mask_2_graphics_5 = new cjs.Graphics().p("AhlFoQiEijAWjPQAWjRCjiDQAXgSAXgPIEUGnIAAAAIiNHtQiZgqhniDg");
	var mask_2_graphics_6 = new cjs.Graphics().p("Ah0FZQh8iqAgjOQAgjPCph7QAXgRAZgPID/G1IAAAAIikHlQiWgxhiiHg");
	var mask_2_graphics_7 = new cjs.Graphics().p("AiHFCQhwiyAujKQAujNCvhvQAZgQAagNIDhHFIAAAAIjEHZQiSg7hZiOg");
	var mask_2_graphics_8 = new cjs.Graphics().p("AidEkQhgi7A/jGQBAjIC5hfQAagNAbgKIC4HWIAAAAIjtHGQiMhIhMiVg");
	var mask_2_graphics_9 = new cjs.Graphics().p("Ai1D+QhJjFBVi9QBXjADChJQAcgKAbgHICBHoIAAAAIkfGoQiDhYg7icg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AjJDPQgtjOBwivQBxixDKgtQAdgGAdgDIA6H2IAAAAIlYF6Qh2hpgkijg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AjjCXQgJjRCNiaQCNibDQgJQAegBAcACIgeH4IAAABImUE5Qhih9gHing");
	var mask_2_graphics_12 = new cjs.Graphics().p("AkQBbQAjjPCqh5QCqh7DNAjQAdAFAcAIIiGHnIgBAAInMDeQhGiOAcikg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AklAeQBUi/DDhNQDChNC/BUQAbAMAZAOIj5G4IgBAAIn0BnQghibBDiZg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AmDEIQAGifBniCQCBimDOgbQDQgbClCAQAXATAUATIldFuIAAAAg");
	var mask_2_graphics_15 = new cjs.Graphics().p("ABaEfInviBQAniZB/hrQChiHDPARQDSARCGCfQATAXAQAWImiEeg");
	var mask_2_graphics_16 = new cjs.Graphics().p("ABFEfInRjUQBAiQCRhUQC1hpDJA0QDMA2BoCzQAPAZAMAaInNDSg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AA4EgImukVQBViFCbg+QDBhPDBBRQDCBRBODAQALAcAHAbInlCOg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AAyEgImMlDQBjh8ChgsQDKg4C2BmQC3BnA4DIQAHAdAFAcInzBVg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AAvEgIltllQBuhyCkgeQDNgmCtB2QCtB3AlDMQAGAdACAdIn5Aog");
	var mask_2_graphics_20 = new cjs.Graphics().p("AAuEgIlUl8QB1hrCmgTQDQgYCjCCQClCBAYDPQADAdABAdIn6AHg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AAuEYIAAAAIlCmNQB6hlCmgLQDSgOCdCJQCfCJAODQQABAegBAdg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AAuEQIAAAAIk1mXQB+hhClgGQDSgHCZCOQCaCOAHDRQABAdgCAdg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AAuELIAAAAIktmdQB/heCmgDQDSgDCWCRQCYCRADDRQAAAdgCAdg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AAuEJIAAgBIkpmfQCAheCmAAQDSgBCVCSQCWCTABDQQAAAegDAcg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AAuEIIAAgBIknmgQCAhdCmAAQDSAACUCTQCWCTAADQQAAAegDAcg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AAuEIIgBgBIknmhQCBhcCmAAQDSAACUCTQCVCTAADQQAAAegDAcg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:29.5529,y:53.7045}).wait(1).to({graphics:mask_2_graphics_1,x:29.5531,y:53.7015}).wait(1).to({graphics:mask_2_graphics_2,x:29.5538,y:53.6808}).wait(1).to({graphics:mask_2_graphics_3,x:29.5559,y:53.6228}).wait(1).to({graphics:mask_2_graphics_4,x:29.56,y:53.5029}).wait(1).to({graphics:mask_2_graphics_5,x:29.5669,y:53.2848}).wait(1).to({graphics:mask_2_graphics_6,x:29.5774,y:52.9127}).wait(1).to({graphics:mask_2_graphics_7,x:29.5926,y:52.3014}).wait(1).to({graphics:mask_2_graphics_8,x:29.6136,y:51.3262}).wait(1).to({graphics:mask_2_graphics_9,x:29.6417,y:49.8149}).wait(1).to({graphics:mask_2_graphics_10,x:29.678,y:47.5469}).wait(1).to({graphics:mask_2_graphics_11,x:31.2131,y:44.2673}).wait(1).to({graphics:mask_2_graphics_12,x:36.4741,y:39.7286}).wait(1).to({graphics:mask_2_graphics_13,x:42.2926,y:33.7747}).wait(1).to({graphics:mask_2_graphics_14,x:47.3476,y:28.6763}).wait(1).to({graphics:mask_2_graphics_15,x:50.8009,y:28.7164}).wait(1).to({graphics:mask_2_graphics_16,x:52.9833,y:28.7569}).wait(1).to({graphics:mask_2_graphics_17,x:54.2475,y:28.7927}).wait(1).to({graphics:mask_2_graphics_18,x:54.9011,y:28.8224}).wait(1).to({graphics:mask_2_graphics_19,x:55.1829,y:28.846}).wait(1).to({graphics:mask_2_graphics_20,x:55.262,y:28.8638}).wait(1).to({graphics:mask_2_graphics_21,x:55.2721,y:29.7505}).wait(1).to({graphics:mask_2_graphics_22,x:55.2795,y:30.5704}).wait(1).to({graphics:mask_2_graphics_23,x:55.2848,y:31.067}).wait(1).to({graphics:mask_2_graphics_24,x:55.2878,y:31.3216}).wait(1).to({graphics:mask_2_graphics_25,x:55.289,y:31.4154}).wait(1).to({graphics:mask_2_graphics_26,x:55.2328,y:31.4288}).wait(99));

	// family slice
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(222,108,95,0.749)").s().p("AhoDmIgBAAIknmhQCAhdCnAAQDRAACUCTQCWCTAADRQAAAegEAcg");
	this.shape_2.setTransform(70.35,34.775);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(125));

	// Layer_1
	this.instance = new lib.clockImage();
	this.instance.setTransform(59.65,58.7,1.1524,1.1524,0,0,0,59.8,59.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(125));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-51.4,-215,180.4,600);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-15.4,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-61.15,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ApkCeIAAk7ITJAAIAAE7g");
	this.shape.setTransform(-55,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-116.3,-16.5,122.6,31.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(145.7,1.4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(92.15,569.95,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(155.2,570.2,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(15.95,15.6,1.0367,1.0367,0,0,0,-52.4,-23.6);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// bg img
	this.clock = new lib.clock();
	this.clock.name = "clock";
	this.clock.setTransform(111.5,275.1,1,1,0,0,0,60,60);

	this.backImage = new lib.mainImage();
	this.backImage.name = "backImage";
	this.backImage.setTransform(141.8,132.95,1,1,0,0,0,220.2,165.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.backImage},{t:this.clock}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-100.7,-1.7,308.6,611.1), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "cloc") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillClock(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillClock = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.clock.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var phone = mc.phone
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
		
		
			this.tl1 = new TimelineLite();
				
				exportRoot.tl1.from(mc.backImage, 1.4, {x:"+=200", ease:Power4.easeOut},"+=0");
				exportRoot.tl1.from(mc.clock, 1.4, {x:"+=200", ease:Power4.easeOut, onComplete:function(){mc.clock.play(); exportRoot.tl1.stop();}},"-=1.3");
				
				
				//exportRoot.tl1.to(mc.backImage, 1.4, {x:"-=77.2", ease:Power4.easeInOut},"+=0.7");
				//exportRoot.tl1.to(mc.clock, 1.4, {x:"-=156.8", ease:Power4.easeInOut},"-=1.4");
				//exportRoot.tl1.to(mc.white, 1.4, {x:"-=150", ease:Power4.easeInOut},"-=1.4");
				//exportRoot.tl1.from(mc.logo_1, 1.4, {x:"+=150", ease:Power4.easeInOut},"-=1.2");
				
				
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0");
					if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
					if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
			exportRoot.tlClock = new TimelineLite();
				for (var i = 0; i < exportRoot.clockText1.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText1[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText1[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				for (var i = 0; i < exportRoot.clockText2.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText2[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "+=0.5");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText2[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				for (var i = 0; i < exportRoot.clockText3.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText3[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "+=0.1");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText3[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				exportRoot.tlClock.stop()
				//exportRoot.tl1.to(mc.clock, 1.4, {x:"-=153.15", ease:Power4.easeOut},"0");
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
				
				
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-20.7,298.3,228.6,311.09999999999997);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1582630117840", id:"O365_FY20Q4_Cons_USA_160x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;