(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[0,0,374,600],[376,385,326,91],[376,478,295,72],[673,478,42,95],[376,0,374,383]]}
];


// symbols:



(lib.BG = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Hero_Achieve_300x250_0000_clouds_2 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Hero_Achieve_300x250_0001_clouds_1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Rock_2 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Rock_3 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Mountain_rock_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock_2();
	this.instance.setTransform(-19.4,63.1,0.9333,0.9333);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_4, new cjs.Rectangle(-19.4,63.1,39.2,88.70000000000002), null);


(lib.Mountain_rock_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock_3();
	this.instance.setTransform(-150.3,19.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_3, new cjs.Rectangle(-150.3,19.6,374,383), null);


(lib.Mountain_rock_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A9NZAIAA14IAjgEQAWgCANACQAfAFA8ASQA1AJApgqIAygzQAXgdABgmQABgrArggQApggAvAAQAKAAAPgIIAXgNQAQgGAigUQAcgPAOAFQAhAMAcgNQASgIAZgZQAnglAvgSQArgRA4gCQARgBAkgGQAigIASAAQAgAAA/gJQA3gCAlAXQApAZAugEQAogCApgZQA7glAOgEQAqgPApAaIgsgnIA/gtIA8gpIAsgdQAagPAVgHQAhgLAlAMQAYAHAoAaQAPAKAcAAQAaAAAIgKQAKgMAcgdQARgcgbggQgIgHgBgTQgBgOADgQQAGgggCgPQgCgagQgTQgEgGABgLQACgNAFgFICcizQALgMAEgCQAwgXBHg9QBOhDAmgXQBshABrgQQBvgSBzAhQAWAGAOgGQANgFAOgSQAOgRAagVIAqgjIAKgJQAHgFABgFQAmhIA9gZQAWgIAzgYQAvgVAbgLQAQgFAagBIAtgCQBSgJBQgLQAFAAAHgJQAzg+BlgvIBXglQA0gWAhgRMAAAAx/g");
	mask.setTransform(34.3,239.75);

	// Layer_2
	this.instance = new lib.Rock_3();
	this.instance.setTransform(-150.3,19.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_2, new cjs.Rectangle(-150.3,79.8,371.6,320), null);


(lib.Mountain_rock_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A9IfdIAAr1QBmgZAzhNQANgTASgFQA+gPBBhPQBKhZAogUIADgEQAZgtAwgkQAbgVBBgmQA6ghAmAHQAlAGAvAyQAHAJAQAGQAQAFAIgDQAcgMA+ggQA5gdAggNQA4gWBOgbICHguQAGgCAKAAIASADQBGAJAXgBQAzgDAjgjQAIgHASgGQAVgIAHgEIAlgaIAkgZIAXgPQAOgHAIACQBWAYBOg8QAJgHAJAAIECgVQAMhDBbASQAZgwA0gdQAZgOBIgZIAOg5QAHghAIgWIArh2QAahHAKgwQAMg7A4gQQA4gPBCgmQAngWBLgwQATgMAmgcQAigYAagFQA+gNBVgJICUgQQAigDAWACQAfAEAaASQAeAUAxgkQAwgjANgvQAUhEAdgXQApggA9gnIBohCQAEgDAIgCIAPgEMAAAAp+g");
	mask.setTransform(33.6528,201.3271);

	// Layer_3
	this.instance = new lib.Rock_3();
	this.instance.setTransform(-150.3,19.6);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_1, new cjs.Rectangle(-150.3,134,370.5,268.6), null);


(lib.Mountain_cloud_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hero_Achieve_300x250_0000_clouds_2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_cloud_2, new cjs.Rectangle(0,0,326,91), null);


(lib.Mountain_Cloud_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hero_Achieve_300x250_0001_clouds_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_Cloud_1, new cjs.Rectangle(0,0,295,72), null);


(lib.Mountain_BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.BG();
	this.instance.setTransform(-153,-198.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_BG, new cjs.Rectangle(-153,-198.1,374,600), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.line_blip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgqAqQgRgSAAgYQAAgYARgSQASgRAYAAQAYAAASARQASASAAAYQAAAYgSASQgSASgYAAQgYAAgSgSg");
	this.shape.setTransform(6,6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_blip, new cjs.Rectangle(0,0,12,12), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.Mountain_rock_3_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		/*exportRoot.tl2.play();*/
	}
	this.frame_149 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(130).call(this.frame_149).wait(13));

	// Layer_6
	this.blip_1 = new lib.line_blip();
	this.blip_1.name = "blip_1";
	this.blip_1.setTransform(164.05,66.55,0.2,0.2,0,0,0,6.3,6);
	this.blip_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1).wait(115).to({_off:false},0).to({regX:6,scaleX:1.25,scaleY:1.25,x:164,y:66.5},11,cjs.Ease.cubicOut).to({regX:6.1,scaleX:1,scaleY:1,x:164.05},5,cjs.Ease.cubicInOut).wait(31));

	// Layer_5
	this.blip_1_1 = new lib.line_blip();
	this.blip_1_1.name = "blip_1_1";
	this.blip_1_1.setTransform(89.65,115.65,0.2,0.2,0,0,0,6,6);
	this.blip_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1_1).wait(78).to({_off:false},0).to({regY:6.1,scaleX:1.25,scaleY:1.25,x:89.6},11,cjs.Ease.cubicOut).to({regY:6,scaleX:1,scaleY:1,x:89.65},5,cjs.Ease.cubicInOut).wait(68));

	// Layer_4
	this.blip_1_2 = new lib.line_blip();
	this.blip_1_2.name = "blip_1_2";
	this.blip_1_2.setTransform(-22.45,155,0.2,0.2,0,0,0,6.3,6.3);
	this.blip_1_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1_2).wait(19).to({_off:false},0).to({regX:6,regY:6,scaleX:1.25,scaleY:1.25},11,cjs.Ease.cubicOut).to({scaleX:1,scaleY:1,x:-22.4},5,cjs.Ease.cubicInOut).wait(127));

	// Layer_10 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AteMEIBUgqIDcG2IhUAqg");
	var mask_graphics_1 = new cjs.Graphics().p("AteMEIBbgtIDcG1IhbAug");
	var mask_graphics_2 = new cjs.Graphics().p("AteMEIBxg4IDbG1IhwA5g");
	var mask_graphics_3 = new cjs.Graphics().p("AteMEICUhKIDcG1IiUBLg");
	var mask_graphics_4 = new cjs.Graphics().p("AteMEIDHhjIDbG1IjGBkg");
	var mask_graphics_5 = new cjs.Graphics().p("AteMEIEHiEIDcG2IkHCEg");
	var mask_graphics_6 = new cjs.Graphics().p("AteMEIFWirIDbG1IlVCsg");
	var mask_graphics_7 = new cjs.Graphics().p("AteMEIGzjaIDbG2ImyDag");
	var mask_graphics_8 = new cjs.Graphics().p("AtdMEIIdkPIDcG1IoeEQg");
	var mask_graphics_9 = new cjs.Graphics().p("AtdMEIKXlMIDaG1IqWFNg");
	var mask_graphics_10 = new cjs.Graphics().p("AtdMEIMbmPIDbG2IsbGPg");
	var mask_graphics_11 = new cjs.Graphics().p("AtdMEIOUnMIDbG2IuUHMg");
	var mask_graphics_12 = new cjs.Graphics().p("AtdMEIP/oCIDcG2IwAICg");
	var mask_graphics_13 = new cjs.Graphics().p("AtdMEIRcowIDcG1IxcIxg");
	var mask_graphics_14 = new cjs.Graphics().p("AtdMEISrpYIDbG2IyqJYg");
	var mask_graphics_15 = new cjs.Graphics().p("AtdMEITrp4IDcG1IzrJ5g");
	var mask_graphics_16 = new cjs.Graphics().p("AtdMEIUdqRIDcG1I0dKSg");
	var mask_graphics_17 = new cjs.Graphics().p("AtdMEIVBqjIDbG1I1AKkg");
	var mask_graphics_18 = new cjs.Graphics().p("AtdMEIVWquIDcG2I1WKug");
	var mask_graphics_19 = new cjs.Graphics().p("AtdMEIVeqyIDbG2I1dKxg");
	var mask_graphics_20 = new cjs.Graphics().p("AtdMEIVeqyIDcG1I1eKyg");
	var mask_graphics_21 = new cjs.Graphics().p("AtdMEIVgqzIDcG1I1gKzg");
	var mask_graphics_22 = new cjs.Graphics().p("AtdMEIVjq1IDcG2I1jK0g");
	var mask_graphics_23 = new cjs.Graphics().p("AtdMEIVnq3IDcG2I1nK2g");
	var mask_graphics_24 = new cjs.Graphics().p("AtdMEIVtq5IDbG1I1sK5g");
	var mask_graphics_25 = new cjs.Graphics().p("AtdMEIVzq9IDcG2I1zK8g");
	var mask_graphics_26 = new cjs.Graphics().p("AtdMEIV7rBIDcG2I17LAg");
	var mask_graphics_27 = new cjs.Graphics().p("AtdMEIWErFIDcG1I2ELFg");
	var mask_graphics_28 = new cjs.Graphics().p("AtdMEIWPrKIDbG1I2OLKg");
	var mask_graphics_29 = new cjs.Graphics().p("AtdMEIWarQIDcG1I2aLQg");
	var mask_graphics_30 = new cjs.Graphics().p("AtdMEIWnrWIDbG1I2mLWg");
	var mask_graphics_31 = new cjs.Graphics().p("AtdMEIW1rdIDbG1I20Ldg");
	var mask_graphics_32 = new cjs.Graphics().p("AtdMEIXErlIDbG1I3DLlg");
	var mask_graphics_33 = new cjs.Graphics().p("AtdMEIXUrtIDbG1I3TLtg");
	var mask_graphics_34 = new cjs.Graphics().p("AtgMEIXlr2IDcG2I3lL1g");
	var mask_graphics_35 = new cjs.Graphics().p("AtpMEIX4r/IDbG1I34L/g");
	var mask_graphics_36 = new cjs.Graphics().p("AtzMEIYMsIIDbG0I4MMJg");
	var mask_graphics_37 = new cjs.Graphics().p("At+MEIYhsTIDcG1I4hMTg");
	var mask_graphics_38 = new cjs.Graphics().p("AuJMEIY3seIDcG0I43Mfg");
	var mask_graphics_39 = new cjs.Graphics().p("AuVMEIZPsqIDcG1I5PMqg");
	var mask_graphics_40 = new cjs.Graphics().p("AuhMEIZns2IDcG0I5nM3g");
	var mask_graphics_41 = new cjs.Graphics().p("AuuMEIaBtDIDcG0I6BNEg");
	var mask_graphics_42 = new cjs.Graphics().p("Au8MEIadtRIDcG1I6dNRg");
	var mask_graphics_43 = new cjs.Graphics().p("AvKMEIa5tfIDcG0I65Ngg");
	var mask_graphics_44 = new cjs.Graphics().p("AvZMEIbXtuIDcG1I7XNug");
	var mask_graphics_45 = new cjs.Graphics().p("AvoMEIb1t9IDcG0I71N+g");
	var mask_graphics_46 = new cjs.Graphics().p("Av4MEIcVuNIDcG0I8VOOg");
	var mask_graphics_47 = new cjs.Graphics().p("AwIMEIc2ueIDbG0I82Ofg");
	var mask_graphics_48 = new cjs.Graphics().p("AwaMEIdZuvIDcG0I9ZOwg");
	var mask_graphics_49 = new cjs.Graphics().p("AwrMEId8vBIDbG0I98PCg");
	var mask_graphics_50 = new cjs.Graphics().p("Aw9MEIefvSIDcG0I+fPTg");
	var mask_graphics_51 = new cjs.Graphics().p("AxNMEIfAvjIDbG1I/APjg");
	var mask_graphics_52 = new cjs.Graphics().p("AxdMEIfgvzIDbG1I/gPzg");
	var mask_graphics_53 = new cjs.Graphics().p("AxsMEIf+wCIDbG0I/+QDg");
	var mask_graphics_54 = new cjs.Graphics().p("Ax7MEMAgcgQRIDbG0MggcAQSg");
	var mask_graphics_55 = new cjs.Graphics().p("AyJMEMAg4gQfIDbG0Mgg4AQgg");
	var mask_graphics_56 = new cjs.Graphics().p("AyXMEMAhTgQtIDcG0MghTAQug");
	var mask_graphics_57 = new cjs.Graphics().p("AykMEMAhtgQ6IDcG0MghtAQ7g");
	var mask_graphics_58 = new cjs.Graphics().p("AywMEMAiGgRGIDbG0MgiGARHg");
	var mask_graphics_59 = new cjs.Graphics().p("Ay8MEMAiegRSIDbG0MgieARTg");
	var mask_graphics_60 = new cjs.Graphics().p("AzHMEMAi0gRdIDbG0Mgi0AReg");
	var mask_graphics_61 = new cjs.Graphics().p("AzSMEMAjJgRoIDcG0MgjJARpg");
	var mask_graphics_62 = new cjs.Graphics().p("AzcMEMAjdgRyIDcG0MgjdAR0g");
	var mask_graphics_63 = new cjs.Graphics().p("AzlMEMAjwgR7IDbG0MgjwAR9g");
	var mask_graphics_64 = new cjs.Graphics().p("AzuMEMAkBgSEIDcG0MgkBASGg");
	var mask_graphics_65 = new cjs.Graphics().p("Az2MEMAkRgSMIDcG0MgkRASOg");
	var mask_graphics_66 = new cjs.Graphics().p("Az+MEMAkhgSUIDcG1MgkhASVg");
	var mask_graphics_67 = new cjs.Graphics().p("A0FMEMAkvgSbIDcG1MgkvAScg");
	var mask_graphics_68 = new cjs.Graphics().p("A0LMEMAk7gShIDcG0Mgk7ASjg");
	var mask_graphics_69 = new cjs.Graphics().p("A0RMEMAlHgSnIDcG1MglHASog");
	var mask_graphics_70 = new cjs.Graphics().p("A0WMEMAlRgSsIDcG0MglRASug");
	var mask_graphics_71 = new cjs.Graphics().p("A0aMEMAlagSxIDbG1MglaASyg");
	var mask_graphics_72 = new cjs.Graphics().p("A0eMEMAligS1IDbG1MgliAS2g");
	var mask_graphics_73 = new cjs.Graphics().p("A0hMEMAlogS4IDbG1MgloAS5g");
	var mask_graphics_74 = new cjs.Graphics().p("A0kMEMAlugS7IDbG2MgluAS7g");
	var mask_graphics_75 = new cjs.Graphics().p("A0mMEMAlygS9IDbG2MglyAS9g");
	var mask_graphics_76 = new cjs.Graphics().p("A0oMEMAl1gS+IDcG1Mgl1AS/g");
	var mask_graphics_77 = new cjs.Graphics().p("A0pMEMAl3gS/IDcG1Mgl3ATAg");
	var mask_graphics_78 = new cjs.Graphics().p("A0pMEMAl3gTAIDcG2Mgl3AS/g");
	var mask_graphics_79 = new cjs.Graphics().p("A0qMEMAl5gTAIDcG1Mgl5ATAg");
	var mask_graphics_80 = new cjs.Graphics().p("A0rMEMAl8gTCIDbG1Mgl8ATCg");
	var mask_graphics_81 = new cjs.Graphics().p("A0uMEMAmCgTFIDbG2MgmCATEg");
	var mask_graphics_82 = new cjs.Graphics().p("A0yMEMAmKgTJIDbG1MgmKATJg");
	var mask_graphics_83 = new cjs.Graphics().p("A03MEMAmUgTOIDbG1MgmUATOg");
	var mask_graphics_84 = new cjs.Graphics().p("A0+MEMAmhgTVIDcG2MgmhATUg");
	var mask_graphics_85 = new cjs.Graphics().p("A1FMEMAmwgTcIDbG1MgmwATcg");
	var mask_graphics_86 = new cjs.Graphics().p("A1OMEMAnBgTlIDcG2MgnBATkg");
	var mask_graphics_87 = new cjs.Graphics().p("A1YMEMAnVgTvIDcG2MgnVATug");
	var mask_graphics_88 = new cjs.Graphics().p("A1jMEMAnrgT6IDcG2MgnrAT5g");
	var mask_graphics_89 = new cjs.Graphics().p("A1vMEMAoDgUGIDcG2MgoDAUFg");
	var mask_graphics_90 = new cjs.Graphics().p("A18MEMAoegUTIDbG1MgoeAUTg");
	var mask_graphics_91 = new cjs.Graphics().p("A2LMEMAo7gUiIDcG2Mgo7AUhg");
	var mask_graphics_92 = new cjs.Graphics().p("A2aMEMApagUxIDbG1MgpaAUxg");
	var mask_graphics_93 = new cjs.Graphics().p("A2rMEMAp7gVCIDcG1Mgp7AVCg");
	var mask_graphics_94 = new cjs.Graphics().p("A29MEMAqfgVUIDcG1MgqfAVUg");
	var mask_graphics_95 = new cjs.Graphics().p("A3QMEMArFgVnIDcG1MgrFAVng");
	var mask_graphics_96 = new cjs.Graphics().p("A3kMEMArugV8IDbG2MgruAV7g");
	var mask_graphics_97 = new cjs.Graphics().p("A35MEMAsYgWRIDbG2MgsYAWQg");
	var mask_graphics_98 = new cjs.Graphics().p("A4OMEMAtBgWlIDcG2MgtBAWkg");
	var mask_graphics_99 = new cjs.Graphics().p("A4hMEMAtngW4IDcG1MgtnAW4g");
	var mask_graphics_100 = new cjs.Graphics().p("A4zMEMAuLgXKIDcG1MguLAXKg");
	var mask_graphics_101 = new cjs.Graphics().p("A5DMEMAusgXbIDbG2MgusAXag");
	var mask_graphics_102 = new cjs.Graphics().p("A5TMEMAvLgXqIDcG1MgvLAXqg");
	var mask_graphics_103 = new cjs.Graphics().p("A5hMEMAvogX5IDbG2MgvoAX4g");
	var mask_graphics_104 = new cjs.Graphics().p("A5vMEMAwDgYGIDcG1MgwDAYGg");
	var mask_graphics_105 = new cjs.Graphics().p("A57MEMAwbgYSIDcG1MgwbAYSg");
	var mask_graphics_106 = new cjs.Graphics().p("A6GMEMAwxgYdIDcG1MgwxAYdg");
	var mask_graphics_107 = new cjs.Graphics().p("A6QMEMAxFgYnIDcG1MgxFAYng");
	var mask_graphics_108 = new cjs.Graphics().p("A6YMEMAxWgYwIDbG1MgxWAYwg");
	var mask_graphics_109 = new cjs.Graphics().p("A6gMEMAxlgY4IDcG2MgxlAY3g");
	var mask_graphics_110 = new cjs.Graphics().p("A6mMEMAxygY+IDbG2MgxyAY9g");
	var mask_graphics_111 = new cjs.Graphics().p("A6rMEMAx8gZDIDbG1Mgx8AZDg");
	var mask_graphics_112 = new cjs.Graphics().p("A6vMEMAyEgZHIDbG1MgyEAZHg");
	var mask_graphics_113 = new cjs.Graphics().p("A6yMEMAyKgZKIDbG1MgyKAZKg");
	var mask_graphics_114 = new cjs.Graphics().p("A60MEMAyNgZMIDcG2MgyNAZLg");
	var mask_graphics_115 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_116 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_117 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_118 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_119 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_120 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_121 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_122 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_123 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_124 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_125 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_126 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_127 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_128 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_129 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_130 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_131 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_132 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_133 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_134 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_135 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_136 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_137 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_138 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_139 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_140 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_141 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_142 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_143 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_144 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_145 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_146 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_147 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_148 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_149 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_150 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_151 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_152 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_153 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_154 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_155 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_156 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_157 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_158 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_159 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_160 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");
	var mask_graphics_161 = new cjs.Graphics().p("A61MEMAyPgZNIDcG2MgyPAZMg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-86.275,y:120.9742}).wait(1).to({graphics:mask_graphics_1,x:-86.2745,y:120.9741}).wait(1).to({graphics:mask_graphics_2,x:-86.2731,y:120.9739}).wait(1).to({graphics:mask_graphics_3,x:-86.2708,y:120.9735}).wait(1).to({graphics:mask_graphics_4,x:-86.2675,y:120.9729}).wait(1).to({graphics:mask_graphics_5,x:-86.2632,y:120.9722}).wait(1).to({graphics:mask_graphics_6,x:-86.2581,y:120.9713}).wait(1).to({graphics:mask_graphics_7,x:-86.252,y:120.9703}).wait(1).to({graphics:mask_graphics_8,x:-86.2449,y:120.9691}).wait(1).to({graphics:mask_graphics_9,x:-86.2369,y:120.9677}).wait(1).to({graphics:mask_graphics_10,x:-86.2282,y:120.9663}).wait(1).to({graphics:mask_graphics_11,x:-86.2202,y:120.9649}).wait(1).to({graphics:mask_graphics_12,x:-86.2132,y:120.9637}).wait(1).to({graphics:mask_graphics_13,x:-86.2071,y:120.9627}).wait(1).to({graphics:mask_graphics_14,x:-86.2019,y:120.9618}).wait(1).to({graphics:mask_graphics_15,x:-86.1977,y:120.9611}).wait(1).to({graphics:mask_graphics_16,x:-86.1944,y:120.9605}).wait(1).to({graphics:mask_graphics_17,x:-86.192,y:120.9601}).wait(1).to({graphics:mask_graphics_18,x:-86.1906,y:120.9599}).wait(1).to({graphics:mask_graphics_19,x:-86.175,y:120.9242}).wait(1).to({graphics:mask_graphics_20,x:-86.1748,y:120.9242}).wait(1).to({graphics:mask_graphics_21,x:-86.1748,y:120.9242}).wait(1).to({graphics:mask_graphics_22,x:-86.1748,y:120.9243}).wait(1).to({graphics:mask_graphics_23,x:-86.1749,y:120.9244}).wait(1).to({graphics:mask_graphics_24,x:-86.1749,y:120.9246}).wait(1).to({graphics:mask_graphics_25,x:-86.1749,y:120.9248}).wait(1).to({graphics:mask_graphics_26,x:-86.1749,y:120.925}).wait(1).to({graphics:mask_graphics_27,x:-86.175,y:120.9253}).wait(1).to({graphics:mask_graphics_28,x:-86.175,y:120.9255}).wait(1).to({graphics:mask_graphics_29,x:-86.1751,y:120.9259}).wait(1).to({graphics:mask_graphics_30,x:-86.1751,y:120.9262}).wait(1).to({graphics:mask_graphics_31,x:-86.1752,y:120.9266}).wait(1).to({graphics:mask_graphics_32,x:-86.1753,y:120.9271}).wait(1).to({graphics:mask_graphics_33,x:-86.1753,y:120.9276}).wait(1).to({graphics:mask_graphics_34,x:-85.8645,y:120.9281}).wait(1).to({graphics:mask_graphics_35,x:-84.9296,y:120.9286}).wait(1).to({graphics:mask_graphics_36,x:-83.9343,y:120.9292}).wait(1).to({graphics:mask_graphics_37,x:-82.8787,y:120.9298}).wait(1).to({graphics:mask_graphics_38,x:-81.7628,y:120.9304}).wait(1).to({graphics:mask_graphics_39,x:-80.5865,y:120.9311}).wait(1).to({graphics:mask_graphics_40,x:-79.35,y:120.9318}).wait(1).to({graphics:mask_graphics_41,x:-78.0531,y:120.9326}).wait(1).to({graphics:mask_graphics_42,x:-76.6959,y:120.9333}).wait(1).to({graphics:mask_graphics_43,x:-75.2784,y:120.9342}).wait(1).to({graphics:mask_graphics_44,x:-73.8005,y:120.935}).wait(1).to({graphics:mask_graphics_45,x:-72.2624,y:120.9359}).wait(1).to({graphics:mask_graphics_46,x:-70.6639,y:120.9368}).wait(1).to({graphics:mask_graphics_47,x:-69.0051,y:120.9378}).wait(1).to({graphics:mask_graphics_48,x:-67.286,y:120.9388}).wait(1).to({graphics:mask_graphics_49,x:-65.5216,y:120.9398}).wait(1).to({graphics:mask_graphics_50,x:-63.8025,y:120.9408}).wait(1).to({graphics:mask_graphics_51,x:-62.1437,y:120.9417}).wait(1).to({graphics:mask_graphics_52,x:-60.5452,y:120.9426}).wait(1).to({graphics:mask_graphics_53,x:-59.0071,y:120.9435}).wait(1).to({graphics:mask_graphics_54,x:-57.5293,y:120.9444}).wait(1).to({graphics:mask_graphics_55,x:-56.1117,y:120.9452}).wait(1).to({graphics:mask_graphics_56,x:-54.7545,y:120.946}).wait(1).to({graphics:mask_graphics_57,x:-53.4577,y:120.9467}).wait(1).to({graphics:mask_graphics_58,x:-52.2211,y:120.9474}).wait(1).to({graphics:mask_graphics_59,x:-51.0449,y:120.9481}).wait(1).to({graphics:mask_graphics_60,x:-49.929,y:120.9487}).wait(1).to({graphics:mask_graphics_61,x:-48.8734,y:120.9493}).wait(1).to({graphics:mask_graphics_62,x:-47.8781,y:120.9499}).wait(1).to({graphics:mask_graphics_63,x:-46.9431,y:120.9505}).wait(1).to({graphics:mask_graphics_64,x:-46.0685,y:120.951}).wait(1).to({graphics:mask_graphics_65,x:-45.2542,y:120.9514}).wait(1).to({graphics:mask_graphics_66,x:-44.5002,y:120.9519}).wait(1).to({graphics:mask_graphics_67,x:-43.8065,y:120.9523}).wait(1).to({graphics:mask_graphics_68,x:-43.1731,y:120.9526}).wait(1).to({graphics:mask_graphics_69,x:-42.6001,y:120.9529}).wait(1).to({graphics:mask_graphics_70,x:-42.0874,y:120.9532}).wait(1).to({graphics:mask_graphics_71,x:-41.635,y:120.9535}).wait(1).to({graphics:mask_graphics_72,x:-41.2429,y:120.9537}).wait(1).to({graphics:mask_graphics_73,x:-40.9111,y:120.9539}).wait(1).to({graphics:mask_graphics_74,x:-40.6397,y:120.9541}).wait(1).to({graphics:mask_graphics_75,x:-40.4286,y:120.9542}).wait(1).to({graphics:mask_graphics_76,x:-40.2778,y:120.9543}).wait(1).to({graphics:mask_graphics_77,x:-40.1873,y:120.9543}).wait(1).to({graphics:mask_graphics_78,x:-40.1483,y:120.9242}).wait(1).to({graphics:mask_graphics_79,x:-40.0907,y:120.9242}).wait(1).to({graphics:mask_graphics_80,x:-39.9177,y:120.9243}).wait(1).to({graphics:mask_graphics_81,x:-39.6294,y:120.9244}).wait(1).to({graphics:mask_graphics_82,x:-39.2258,y:120.9247}).wait(1).to({graphics:mask_graphics_83,x:-38.7068,y:120.9249}).wait(1).to({graphics:mask_graphics_84,x:-38.0726,y:120.9253}).wait(1).to({graphics:mask_graphics_85,x:-37.323,y:120.9257}).wait(1).to({graphics:mask_graphics_86,x:-36.4581,y:120.9261}).wait(1).to({graphics:mask_graphics_87,x:-35.4778,y:120.9266}).wait(1).to({graphics:mask_graphics_88,x:-34.3823,y:120.9272}).wait(1).to({graphics:mask_graphics_89,x:-33.1714,y:120.9278}).wait(1).to({graphics:mask_graphics_90,x:-31.8452,y:120.9285}).wait(1).to({graphics:mask_graphics_91,x:-30.4037,y:120.9293}).wait(1).to({graphics:mask_graphics_92,x:-28.8469,y:120.9301}).wait(1).to({graphics:mask_graphics_93,x:-27.1747,y:120.931}).wait(1).to({graphics:mask_graphics_94,x:-25.3873,y:120.9319}).wait(1).to({graphics:mask_graphics_95,x:-23.4845,y:120.9329}).wait(1).to({graphics:mask_graphics_96,x:-21.4663,y:120.934}).wait(1).to({graphics:mask_graphics_97,x:-19.3617,y:120.9351}).wait(1).to({graphics:mask_graphics_98,x:-17.3436,y:120.9362}).wait(1).to({graphics:mask_graphics_99,x:-15.4408,y:120.9372}).wait(1).to({graphics:mask_graphics_100,x:-13.6533,y:120.9381}).wait(1).to({graphics:mask_graphics_101,x:-11.9812,y:120.939}).wait(1).to({graphics:mask_graphics_102,x:-10.4244,y:120.9398}).wait(1).to({graphics:mask_graphics_103,x:-8.9828,y:120.9406}).wait(1).to({graphics:mask_graphics_104,x:-7.6566,y:120.9412}).wait(1).to({graphics:mask_graphics_105,x:-6.4458,y:120.9419}).wait(1).to({graphics:mask_graphics_106,x:-5.3502,y:120.9425}).wait(1).to({graphics:mask_graphics_107,x:-4.37,y:120.943}).wait(1).to({graphics:mask_graphics_108,x:-3.5051,y:120.9434}).wait(1).to({graphics:mask_graphics_109,x:-2.7555,y:120.9438}).wait(1).to({graphics:mask_graphics_110,x:-2.1212,y:120.9442}).wait(1).to({graphics:mask_graphics_111,x:-1.6023,y:120.9444}).wait(1).to({graphics:mask_graphics_112,x:-1.1987,y:120.9446}).wait(1).to({graphics:mask_graphics_113,x:-0.9104,y:120.9448}).wait(1).to({graphics:mask_graphics_114,x:-0.7374,y:120.9449}).wait(1).to({graphics:mask_graphics_115,x:-0.5969,y:120.9242}).wait(1).to({graphics:mask_graphics_116,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_117,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_118,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_119,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_120,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_121,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_122,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_123,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_124,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_125,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_126,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_127,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_128,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_129,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_130,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_131,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_132,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_133,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_134,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_135,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_136,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_137,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_138,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_139,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_140,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_141,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_142,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_143,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_144,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_145,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_146,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_147,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_148,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_149,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_150,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_151,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_152,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_153,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_154,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_155,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_156,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_157,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_158,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_159,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_160,x:-0.5969,y:120.9241}).wait(1).to({graphics:mask_graphics_161,x:-0.5969,y:120.9242}).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF001").ss(5,1,1).p("A08LLINxpPINxj1QHVkTHCk+");
	this.shape.setTransform(30,138.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FFF001").ss(4.5,1,1).p("AjcAKIG5gT");
	this.shape_1.setTransform(-127.05,211.275);

	var maskedShapeInstanceList = [this.shape,this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(162));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-151.4,59,666.1999999999999,246.60000000000002);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// rock_3_txt
	this.rock_3_txt = new lib.Mountain_rock_3_txt();
	this.rock_3_txt.name = "rock_3_txt";
	this.rock_3_txt.setTransform(286.05,143.45,1.63,1.63,0,0,0,175.5,88);

	this.timeline.addTween(cjs.Tween.get(this.rock_3_txt).wait(1));

	// rock_1
	this.rock_1 = new lib.Mountain_rock_1();
	this.rock_1.name = "rock_1";
	this.rock_1.setTransform(163.8,75.8,1.63,1.63,0,0,0,100.5,46.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_1).wait(1));

	// rock_2
	this.rock_2 = new lib.Mountain_rock_2();
	this.rock_2.name = "rock_2";
	this.rock_2.setTransform(267.3,108.4,1.63,1.63,0,0,0,164,66.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_2).wait(1));

	// rock_3_img
	this.rock_3_img = new lib.Mountain_rock_3();
	this.rock_3_img.name = "rock_3_img";
	this.rock_3_img.setTransform(286.05,143.45,1.63,1.63,0,0,0,175.5,88);

	this.timeline.addTween(cjs.Tween.get(this.rock_3_img).wait(1));

	// rock_4
	this.rock_4 = new lib.Mountain_rock_4();
	this.rock_4.name = "rock_4";
	this.rock_4.setTransform(19.55,44.8,1.63,1.63,0,0,0,12,27.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_4).wait(1));

	// cloud_2
	this.cloud_2 = new lib.Mountain_cloud_2();
	this.cloud_2.name = "cloud_2";
	this.cloud_2.setTransform(95.1,-248.35,1.63,1.63,0,0,0,163,45.5);

	this.timeline.addTween(cjs.Tween.get(this.cloud_2).wait(1));

	// cloud_1
	this.cloud_1 = new lib.Mountain_Cloud_1();
	this.cloud_1.name = "cloud_1";
	this.cloud_1.setTransform(121.65,-114.6,1.63,1.63,0,0,0,147.5,36);

	this.timeline.addTween(cjs.Tween.get(this.cloud_1).wait(1));

	// bg
	this.bg = new lib.Mountain_BG();
	this.bg.name = "bg";
	this.bg.setTransform(332.5,203.75,1.63,1.63,0,0,0,204,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(-281.2,-322.9,645.9,979.1999999999999), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		exportRoot.tl1.play();
		exportRoot.tlbg.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(24).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.5,897.95,0.2,0.2,0,0,0,-39.8,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4,y:897.45},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSYBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_15 = new cjs.Graphics().p("EgSrBKRIAAwpMBbtAAAIAAQpg");
	var mask_graphics_16 = new cjs.Graphics().p("EgTlBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_17 = new cjs.Graphics().p("EgVEBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_18 = new cjs.Graphics().p("EgXJBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_19 = new cjs.Graphics().p("EgZ1BKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_20 = new cjs.Graphics().p("EgdHBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_21 = new cjs.Graphics().p("EggYBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_23 = new cjs.Graphics().p("EglJBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_25 = new cjs.Graphics().p("EgniBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1BKRIAAwpMBbuAAAIAAQpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:475.2595}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:475.2595}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:475.2595}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:475.2595}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:475.2595}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:475.2595}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:475.2595}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:475.2595}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:475.2595}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:475.2595}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:475.2595}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:475.2595}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:475.2595}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,891.55,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhM1CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTjCYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhanCYiMAAAkxDMCXtAAAMAAAExDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:908.6054}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:908.6054}).wait(1).to({graphics:mask_1_graphics_52,x:295.8271,y:908.6054}).wait(1).to({graphics:mask_1_graphics_53,x:289.2111,y:908.6054}).wait(1).to({graphics:mask_1_graphics_54,x:278.1844,y:908.6054}).wait(1).to({graphics:mask_1_graphics_55,x:262.7471,y:908.6054}).wait(1).to({graphics:mask_1_graphics_56,x:242.8992,y:908.6054}).wait(1).to({graphics:mask_1_graphics_57,x:218.6406,y:908.6054}).wait(1).to({graphics:mask_1_graphics_58,x:189.9713,y:908.6054}).wait(1).to({graphics:mask_1_graphics_59,x:156.8914,y:908.6054}).wait(1).to({graphics:mask_1_graphics_60,x:119.4008,y:908.6054}).wait(1).to({graphics:mask_1_graphics_61,x:77.4995,y:908.6054}).wait(1).to({graphics:mask_1_graphics_62,x:31.1876,y:908.6054}).wait(1).to({graphics:mask_1_graphics_63,x:-19.5349,y:908.6054}).wait(1).to({graphics:mask_1_graphics_64,x:-74.6682,y:908.6054}).wait(1).to({graphics:mask_1_graphics_65,x:-134.212,y:908.6054}).wait(1).to({graphics:mask_1_graphics_66,x:-198.1666,y:908.6054}).wait(1).to({graphics:mask_1_graphics_67,x:-266.5318,y:908.6054}).wait(1).to({graphics:mask_1_graphics_68,x:-339.3076,y:908.6054}).wait(1).to({graphics:mask_1_graphics_69,x:-416.4941,y:908.6054}).wait(1).to({graphics:mask_1_graphics_70,x:-491.7868,y:908.6054}).wait(1).to({graphics:mask_1_graphics_71,x:-534.7908,y:908.6054}).wait(1).to({graphics:mask_1_graphics_72,x:-580,y:908.6054}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(222.05,891.55,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(297.95,2254.65,1,5.7086,0,0,0,485.4,406.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({regY:406.9,scaleY:5.7085,x:-674.6,y:2255.2},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(297.95,2255.25,1,5.7085,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-674.6},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160,-67.6,1943.5,1953.1999999999998);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(3,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ApxCeIAAk7ITjAAIAAE7g");
	this.shape.setTransform(-41.025,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.6,-16.5,125.19999999999999,31.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(235.3,556.1,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(280.05,556.35,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(30.4,31.05,0.9721,0.9721,0,0,0,-52.6,-23.7);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// people
	this.mountain = new lib.mountain_anim();
	this.mountain.name = "mountain";
	this.mountain.setTransform(253.35,213.55,0.614,0.614,0,0,0,284.2,24.8);

	this.timeline.addTween(cjs.Tween.get(this.mountain).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-93.8,0,396.5,602.8), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "moun") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillMountain(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillMountain = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.mountain.rock_3_txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		//mc.txtCta.alpha=0
		//mc.cta.alpha=0
		//mc.replay_btn.alpha=0
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
		
			this.tl1 = new TimelineLite();
				
				exportRoot.tl1.from(mc.logo_1, 0.7, { x: "+=200",	ease:Power4.easeOut}, "+=0");
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { x: "+=200",	ease:Power4.easeOut}, "-=0");
				exportRoot.tl1.from(mc.cta, 0.7, { x: "+=200", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.2");	
		
				exportRoot.tl1.stop();
				
				this.tlbg = new TimelineLite();
					
				
				exportRoot.tlbg.from(mc.mountain.rock_1, 5, { x: "+=340",	ease:Power4.easeOut}, "-=0");
				exportRoot.tlbg.from(mc.mountain.rock_2, 5, { x: "+=260",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_3_img, 5, { x: "+=180",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_3_txt, 5, { x: "+=180",	ease:Power4.easeOut, onStart:function(){mc.mountain.rock_3_txt.play();}}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_4, 5, { x: "+=160",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.cloud_1, 14, { x: "+=200",	ease:Power2.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.cloud_2, 14, { x: "+=120",	ease:Power2.easeOut}, "-=14");
				exportRoot.tlbg.from(mc.mountain.bg, 14, { x: "+=120",	ease:Power4.easeOut}, "-=14");
				
				exportRoot.tlbg.stop();
				
				this.tl2 = new TimelineLite();
				
					for (var i = 0; i < exportRoot.mountainText1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText1[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=5");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText1[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
						for (var i = 0; i < exportRoot.mountainText2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText2[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=3.1");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText2[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
								for (var i = 0; i < exportRoot.mountainText3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText3[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=2.4");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText3[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl2.stop();
				
				
			mc.logo_intro.gotoAndPlay(1)
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(56.2,300,246.5,302.79999999999995);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1583789021849", id:"O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;