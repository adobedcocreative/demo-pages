(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[741,515,268,215],[811,0,209,162],[0,0,809,513],[811,164,209,162],[811,328,209,162],[741,732,209,162],[741,896,209,162],[0,515,739,490],[0,1007,209,161]]}
];


// symbols:



(lib.Bitmap1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Excel_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Excel_money_screen_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.OneNote_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Outlook_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Powerpoint_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ScreenShadow = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Word_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Word_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Word = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Excel_300x600();
	this.instance.setTransform(114.8,122.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word, new cjs.Rectangle(100.1,112.7,231.00000000000003,180.8), null);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCX8MAAAkv3MCZbAAAMAAAEv3g");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-972.3,982,1944.6999999999998);


(lib.Screen_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.ScreenShadow();
	this.instance.setTransform(28.1,-45.55,1.4999,1.4999,-0.7881);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_Shadow, new cjs.Rectangle(28.1,-60.8,1118.4,750.0999999999999), null);


(lib.Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel_money_screen_300x600();
	this.instance.setTransform(206.1,79.3,1,1,-0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen, new cjs.Rectangle(121,33.1,926.5999999999999,577.6), null);


(lib.Powerpoint_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.pointer2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoCvQgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgFQgDgHACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAhuQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAEQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gdQgGAFgBAHQgCAGAEAFIBXBvQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhkQAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACVQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgNIgRgUQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,19.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCbIAAgeQAAgMgHgIIhXhvQgEgFACgGQABgHAGgFQALgJANAKIARAUIAFANQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAiVQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAABkQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,19.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2_sub, new cjs.Rectangle(0,2.4,29.6,35), null);


(lib.pointer1_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoC7QgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgGQgDgGACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAiGQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAcQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gRQgGAFgBAHQgCAFAEAFIBXBwQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAh8QAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACtQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgOIgRgTQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,18.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCnIAAgeQAAgMgHgIIhXhwQgEgFACgFQABgHAGgFQALgJANAKIARATIAFAOQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAitQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAAB8QAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,18.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1_sub, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.overlay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.098)").s().p("Ar5CYIAAkvIXzAAIAAEvg");
	this.shape.setTransform(76.175,15.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlay, new cjs.Rectangle(0,0,152.4,30.3), null);


(lib.Outlook_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.OneDrive_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.menu_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	// this.txt1 = new cjs.Text("Learn more", "12px 'Segoe Pro'");
	this.txt1 = new cjs.Text((dynamicData.dropdownText1 ? dynamicData.dropdownText1 : "Learn more"), (dynamicData.dropdownTextFont1 ? dynamicData.dropdownTextFont1 : 12) + "px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 12;
	this.txt1.lineWidth = 137;
	this.txt1.parent = this;
	this.txt1.setTransform(2,2);

	// this.txt2 = new cjs.Text("Monthly subscription", "12px 'Segoe Pro'");
	this.txt2 = new cjs.Text((dynamicData.dropdownText2 ? dynamicData.dropdownText2 : "Monthly subscription"), (dynamicData.dropdownTextFont2 ? dynamicData.dropdownTextFont2 : 12) + "px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 137;
	this.txt2.parent = this;
	this.txt2.setTransform(2, (this.txt2.text.indexOf('\n') == -1 ? 32 : 25));

	// this.txt3 = new cjs.Text("SAVE 16%\nAnnual subscription", "12px 'Segoe Pro'", "#0078D3");
	this.txt3 = new cjs.Text((dynamicData.dropdownText3 ? dynamicData.dropdownText3 : "SAVE 16%\nAnnual subscription"), (dynamicData.dropdownTextFont3 ? dynamicData.dropdownTextFont3 : 12) + "px 'Segoe Pro'", "#0078D3");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 12;
	this.txt3.lineWidth = 137;
	this.txt3.parent = this;
	this.txt3.setTransform(2, (this.txt3.text.indexOf('\n') == -1 ? 61.5 : 54.5));

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt3},{t:this.txt2},{t:this.txt1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.menu_text, new cjs.Rectangle(0,0,141.1,84.9), null);


(lib.mainBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFEFEF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Excel_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.dropDownMenuBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s().p("AsBCWIAAkrIYDAAIAAErg");
	this.shape.setTransform(77,15);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,154,30);


(lib.choice_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	// this.txt = new cjs.Text("BUY NOW", "12px 'Segoe Pro'", "#0078D3");
	this.txt = new cjs.Text((dynamicData.dropdownText ? dynamicData.dropdownText : "BUY NOW"), (dynamicData.dropdownTextFont ? dynamicData.dropdownTextFont : 12) + "px 'Segoe Pro'", "#0078D3");
	this.txt.name = "txt";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 216;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.choice_text, new cjs.Rectangle(0,0,219.8,26.6), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,600), null);


(lib.Aimes_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Aimes_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Wordcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Excel_300x600();
	this.instance.setTransform(113.9,121.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Excel_Shadow();
	this.instance_1.setTransform(213.9,234.85,0.95,0.95,0,0,0,134,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Wordcopy2, new cjs.Rectangle(86.6,113.3,254.6,223.7), null);


(lib.Wordcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Word_Shadow();
	this.instance.setTransform(211.9,232.15,0.95,0.95,0,0,0,134.1,107.5);
	this.instance.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Wordcopy, new cjs.Rectangle(84.5,130.1,254.60000000000002,204.20000000000002), null);


(lib.Teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.OneNote_300x600();
	this.instance.setTransform(110.15,100.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Aimes_Shadow();
	this.instance_1.setTransform(211.15,212.1,0.95,0.95,0,0,0,134,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Teams, new cjs.Rectangle(83.9,90.6,254.6,223.70000000000002), null);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_119 = function() {
		exportRoot.tlmove.play()
	}
	this.frame_207 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(119).call(this.frame_119).wait(88).call(this.frame_207).wait(1));

	// Word
	this.instance = new lib.Word();
	this.instance.setTransform(-143.8,-215.15,0.0754,0.0754,0,0,0,220.8,196.3);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(185).to({_off:false},0).to({regY:196.5,scaleX:0.5889,scaleY:0.5889,x:-8.25,y:-255.1},22,cjs.Ease.cubicOut).wait(1));

	// Word Shadow
	this.instance_1 = new lib.Wordcopy();
	this.instance_1.setTransform(-143.8,-215.15,0.0754,0.0754,0,0,0,220.8,196.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(185).to({_off:false},0).to({regY:196.5,scaleX:0.5889,scaleY:0.5889,x:-8.25,y:-255.1},22,cjs.Ease.cubicOut).wait(1));

	// Screen
	this.instance_2 = new lib.Screen();
	this.instance_2.setTransform(504.5,592.55,1,1,0,0,0,581.6,357.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:161.5,y:43.15},119).wait(1).to({regX:614.1,regY:330.1,x:191.6,y:10.85},0).wait(1).to({x:189.15,y:6.15},0).wait(1).to({x:186.65,y:1.35},0).wait(1).to({x:184.1,y:-3.5},0).wait(1).to({x:181.55,y:-8.4},0).wait(1).to({x:178.95,y:-13.35},0).wait(1).to({x:176.35,y:-18.3},0).wait(1).to({x:173.75,y:-23.35},0).wait(1).to({x:171.1,y:-28.35},0).wait(1).to({x:168.5,y:-33.4},0).wait(1).to({x:165.85,y:-38.4},0).wait(1).to({x:163.25,y:-43.4},0).wait(1).to({x:160.65,y:-48.3},0).wait(1).to({x:158.15,y:-53.2},0).wait(1).to({x:155.65,y:-57.95},0).wait(1).to({x:153.2,y:-62.65},0).wait(1).to({x:150.8,y:-67.2},0).wait(1).to({x:148.5,y:-71.65},0).wait(1).to({x:146.25,y:-75.9},0).wait(1).to({x:144.1,y:-80},0).wait(1).to({x:142.05,y:-83.95},0).wait(1).to({x:140.05,y:-87.75},0).wait(1).to({x:138.2,y:-91.35},0).wait(1).to({x:136.4,y:-94.8},0).wait(1).to({x:134.7,y:-98.05},0).wait(1).to({x:133.1,y:-101.1},0).wait(1).to({x:131.55,y:-104},0).wait(1).to({x:130.15,y:-106.75},0).wait(1).to({x:128.8,y:-109.3},0).wait(1).to({x:127.55,y:-111.7},0).wait(1).to({x:126.35,y:-113.95},0).wait(1).to({x:125.25,y:-116.1},0).wait(1).to({x:124.2,y:-118.05},0).wait(1).to({x:123.25,y:-119.9},0).wait(1).to({x:122.35,y:-121.6},0).wait(1).to({x:121.5,y:-123.2},0).wait(1).to({x:120.75,y:-124.7},0).wait(1).to({x:120.05,y:-126.05},0).wait(1).to({x:119.35,y:-127.35},0).wait(1).to({x:118.75,y:-128.5},0).wait(1).to({x:118.2,y:-129.6},0).wait(1).to({x:117.7,y:-130.55},0).wait(1).to({x:117.2,y:-131.45},0).wait(1).to({x:116.75,y:-132.3},0).wait(1).to({x:116.4,y:-133.05},0).wait(1).to({regX:581.6,regY:357.8,x:83.5,y:-106.05},0).wait(1).to({regX:614.1,regY:330.1,scaleX:0.9979,scaleY:0.9979,x:116.95,y:-134.15},0).wait(1).to({scaleX:0.9951,scaleY:0.9951,x:118.15,y:-134.8},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:119.65,y:-135.5},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:121.45,y:-136.4},0).wait(1).to({scaleX:0.9824,scaleY:0.9824,x:123.6,y:-137.45},0).wait(1).to({scaleX:0.9766,scaleY:0.9766,x:126.05,y:-138.65},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:128.85,y:-140.05},0).wait(1).to({scaleX:0.9627,scaleY:0.9627,x:132,y:-141.65},0).wait(1).to({scaleX:0.9544,scaleY:0.9544,x:135.5,y:-143.4},0).wait(1).to({scaleX:0.9454,scaleY:0.9454,x:139.4,y:-145.3},0).wait(1).to({scaleX:0.9355,scaleY:0.9355,x:143.65,y:-147.4},0).wait(1).to({scaleX:0.9249,scaleY:0.9249,x:148.2,y:-149.6},0).wait(1).to({scaleX:0.9135,scaleY:0.9135,x:153.05,y:-152},0).wait(1).to({scaleX:0.9015,scaleY:0.9015,x:158.25,y:-154.6},0).wait(1).to({scaleX:0.8889,scaleY:0.8889,x:163.65,y:-157.25},0).wait(1).to({scaleX:0.8758,scaleY:0.8758,x:169.2,y:-160},0).wait(1).to({scaleX:0.8625,scaleY:0.8625,x:174.9,y:-162.85},0).wait(1).to({scaleX:0.849,scaleY:0.849,x:180.7,y:-165.7},0).wait(1).to({scaleX:0.8355,scaleY:0.8355,x:186.5,y:-168.55},0).wait(1).to({scaleX:0.8222,scaleY:0.8222,x:192.2,y:-171.35},0).wait(1).to({scaleX:0.8091,scaleY:0.8091,x:197.75,y:-174.1},0).wait(1).to({scaleX:0.7965,scaleY:0.7965,x:203.2,y:-176.8},0).wait(1).to({scaleX:0.7843,scaleY:0.7843,x:208.4,y:-179.35},0).wait(1).to({scaleX:0.7728,scaleY:0.7728,x:213.3,y:-181.8},0).wait(1).to({scaleX:0.762,scaleY:0.762,x:217.95,y:-184.1},0).wait(1).to({scaleX:0.7518,scaleY:0.7518,x:222.35,y:-186.25},0).wait(1).to({scaleX:0.7424,scaleY:0.7424,x:226.35,y:-188.25},0).wait(1).to({scaleX:0.7337,scaleY:0.7337,x:230.1,y:-190.05},0).wait(1).to({scaleX:0.7258,scaleY:0.7258,x:233.45,y:-191.75},0).wait(1).to({scaleX:0.7186,scaleY:0.7186,x:236.5,y:-193.3},0).wait(1).to({scaleX:0.7122,scaleY:0.7122,x:239.3,y:-194.6},0).wait(1).to({scaleX:0.7064,scaleY:0.7064,x:241.75,y:-195.85},0).wait(1).to({scaleX:0.7013,scaleY:0.7013,x:243.9,y:-196.95},0).wait(1).to({scaleX:0.6969,scaleY:0.6969,x:245.85,y:-197.85},0).wait(1).to({scaleX:0.6931,scaleY:0.6931,x:247.45,y:-198.65},0).wait(1).to({scaleX:0.6898,scaleY:0.6898,x:248.85,y:-199.35},0).wait(1).to({scaleX:0.6872,scaleY:0.6872,x:250,y:-199.9},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:250.9,y:-200.35},0).wait(1).to({scaleX:0.6834,scaleY:0.6834,x:251.6,y:-200.7},0).wait(1).to({scaleX:0.6823,scaleY:0.6823,x:252.05,y:-200.95},0).wait(1).to({scaleX:0.6817,scaleY:0.6817,x:252.35,y:-201.1},0).wait(1).to({regX:581.7,regY:357.6,scaleX:0.6815,scaleY:0.6815,x:230.3,y:-182.3},0).wait(1));

	// Screen Shadow
	this.instance_3 = new lib.Screen_Shadow();
	this.instance_3.setTransform(504.5,592.55,1,1,0,0,0,581.6,357.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:161.5,y:43.15},119).wait(1).to({regX:587.3,regY:314.3,x:164.8,y:-4.95},0).wait(1).to({x:162.35,y:-9.65},0).wait(1).to({x:159.85,y:-14.45},0).wait(1).to({x:157.3,y:-19.3},0).wait(1).to({x:154.75,y:-24.2},0).wait(1).to({x:152.15,y:-29.15},0).wait(1).to({x:149.55,y:-34.1},0).wait(1).to({x:146.95,y:-39.15},0).wait(1).to({x:144.3,y:-44.15},0).wait(1).to({x:141.7,y:-49.2},0).wait(1).to({x:139.05,y:-54.2},0).wait(1).to({x:136.45,y:-59.2},0).wait(1).to({x:133.85,y:-64.1},0).wait(1).to({x:131.35,y:-69},0).wait(1).to({x:128.85,y:-73.75},0).wait(1).to({x:126.4,y:-78.45},0).wait(1).to({x:124,y:-83},0).wait(1).to({x:121.7,y:-87.45},0).wait(1).to({x:119.45,y:-91.7},0).wait(1).to({x:117.3,y:-95.8},0).wait(1).to({x:115.25,y:-99.75},0).wait(1).to({x:113.25,y:-103.55},0).wait(1).to({x:111.4,y:-107.15},0).wait(1).to({x:109.6,y:-110.6},0).wait(1).to({x:107.9,y:-113.85},0).wait(1).to({x:106.3,y:-116.9},0).wait(1).to({x:104.75,y:-119.8},0).wait(1).to({x:103.35,y:-122.55},0).wait(1).to({x:102,y:-125.1},0).wait(1).to({x:100.75,y:-127.5},0).wait(1).to({x:99.55,y:-129.75},0).wait(1).to({x:98.45,y:-131.9},0).wait(1).to({x:97.4,y:-133.85},0).wait(1).to({x:96.45,y:-135.7},0).wait(1).to({x:95.55,y:-137.4},0).wait(1).to({x:94.7,y:-139},0).wait(1).to({x:93.95,y:-140.5},0).wait(1).to({x:93.25,y:-141.85},0).wait(1).to({x:92.55,y:-143.15},0).wait(1).to({x:91.95,y:-144.3},0).wait(1).to({x:91.4,y:-145.4},0).wait(1).to({x:90.9,y:-146.35},0).wait(1).to({x:90.4,y:-147.25},0).wait(1).to({x:89.95,y:-148.1},0).wait(1).to({x:89.6,y:-148.85},0).wait(1).to({regX:581.6,regY:357.8,x:83.5,y:-106.05},0).wait(1).to({regX:587.3,regY:314.3,scaleX:0.9979,scaleY:0.9979,x:90.2,y:-149.95},0).wait(1).to({scaleX:0.9951,scaleY:0.9951,x:91.5,y:-150.5},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:93.1,y:-151.15},0).wait(1).to({scaleX:0.9873,scaleY:0.9873,x:95,y:-152},0).wait(1).to({scaleX:0.9824,scaleY:0.9824,x:97.3,y:-153},0).wait(1).to({scaleX:0.9766,scaleY:0.9766,x:99.85,y:-154.1},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:102.85,y:-155.35},0).wait(1).to({scaleX:0.9627,scaleY:0.9627,x:106.2,y:-156.85},0).wait(1).to({scaleX:0.9544,scaleY:0.9544,x:109.95,y:-158.45},0).wait(1).to({scaleX:0.9454,scaleY:0.9454,x:114.1,y:-160.2},0).wait(1).to({scaleX:0.9355,scaleY:0.9355,x:118.6,y:-162.15},0).wait(1).to({scaleX:0.9249,scaleY:0.9249,x:123.4,y:-164.2},0).wait(1).to({scaleX:0.9135,scaleY:0.9135,x:128.6,y:-166.45},0).wait(1).to({scaleX:0.9015,scaleY:0.9015,x:134.05,y:-168.85},0).wait(1).to({scaleX:0.8889,scaleY:0.8889,x:139.8,y:-171.3},0).wait(1).to({scaleX:0.8758,scaleY:0.8758,x:145.7,y:-173.85},0).wait(1).to({scaleX:0.8625,scaleY:0.8625,x:151.8,y:-176.45},0).wait(1).to({scaleX:0.849,scaleY:0.849,x:157.95,y:-179.1},0).wait(1).to({scaleX:0.8355,scaleY:0.8355,x:164.1,y:-181.75},0).wait(1).to({scaleX:0.8222,scaleY:0.8222,x:170.15,y:-184.35},0).wait(1).to({scaleX:0.8091,scaleY:0.8091,x:176.05,y:-186.9},0).wait(1).to({scaleX:0.7965,scaleY:0.7965,x:181.85,y:-189.4},0).wait(1).to({scaleX:0.7843,scaleY:0.7843,x:187.4,y:-191.75},0).wait(1).to({scaleX:0.7728,scaleY:0.7728,x:192.6,y:-194},0).wait(1).to({scaleX:0.762,scaleY:0.762,x:197.55,y:-196.1},0).wait(1).to({scaleX:0.7518,scaleY:0.7518,x:202.2,y:-198.1},0).wait(1).to({scaleX:0.7424,scaleY:0.7424,x:206.45,y:-199.95},0).wait(1).to({scaleX:0.7337,scaleY:0.7337,x:210.4,y:-201.65},0).wait(1).to({scaleX:0.7258,scaleY:0.7258,x:214,y:-203.25},0).wait(1).to({scaleX:0.7186,scaleY:0.7186,x:217.25,y:-204.65},0).wait(1).to({scaleX:0.7122,scaleY:0.7122,x:220.2,y:-205.85},0).wait(1).to({scaleX:0.7064,scaleY:0.7064,x:222.8,y:-207.05},0).wait(1).to({scaleX:0.7013,scaleY:0.7013,x:225.15,y:-208.05},0).wait(1).to({scaleX:0.6969,scaleY:0.6969,x:227.15,y:-208.85},0).wait(1).to({scaleX:0.6931,scaleY:0.6931,x:228.9,y:-209.6},0).wait(1).to({scaleX:0.6898,scaleY:0.6898,x:230.4,y:-210.25},0).wait(1).to({scaleX:0.6872,scaleY:0.6872,x:231.55,y:-210.75},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:232.55,y:-211.2},0).wait(1).to({scaleX:0.6834,scaleY:0.6834,x:233.3,y:-211.5},0).wait(1).to({scaleX:0.6823,scaleY:0.6823,x:233.75,y:-211.75},0).wait(1).to({scaleX:0.6817,scaleY:0.6817,x:234.1,y:-211.85},0).wait(1).to({regX:581.7,regY:357.6,scaleX:0.6815,scaleY:0.6815,x:230.3,y:-182.3},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-470,-524.6,1539.4,1448.7);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Powerpoint = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Word_300x600();
	this.instance.setTransform(105.5,122.65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(205.15,231.9,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint, new cjs.Rectangle(77.8,114.2,254.59999999999997,219.90000000000003), null);


(lib.pointer2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer2_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(11.35,8.3,1,1,-3.4817,0,0,11.3,8.3);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2, new cjs.Rectangle(-0.3,1.3,31.6,36.7), null);


(lib.pointer1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer1_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_1
	this.instance = new lib.pointer1();
	this.instance.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.instance_1 = new lib.pointer2();
	this.instance_1.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0,31.6,38);


(lib.Outlook = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Outlook_300x600();
	this.instance.setTransform(111.9,119.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook, new cjs.Rectangle(84.5,110.5,254.60000000000002,223.7), null);


(lib.OneDrive = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.OneDrive_300x600();
	this.instance.setTransform(111.8,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3 copy
	this.instance_1 = new lib.OneDrive_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive, new cjs.Rectangle(84.5,110.5,254.60000000000002,223.7), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		exportRoot.mainMC.icons.play()
	}
	this.frame_86 = function() {
		exportRoot.tl1.play()
		exportRoot.mainMC.screen.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(17).call(this.frame_86).wait(14).call(this.frame_100).wait(10));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(83));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(83));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({scaleX:2.2,scaleY:2.2,x:24.2,y:-515.55},41,cjs.Ease.quadInOut).to({_off:true},1).wait(9));

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCX8MAAAkv3MCZbAAAMAAAEv3g");
	this.shape.setTransform(299.85,339.425);

	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,339.4);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.instance_2}]},59).to({state:[{t:this.instance_2}]},41).wait(10));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(59).to({_off:false},0).to({alpha:0},41,cjs.Ease.cubicInOut).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-632.9,982,1944.6999999999998);


(lib.menuChoice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.choice_text.cache(0,-20,220,27,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3F3F").s().p("AgkASIAkgjIAlAjg");
	this.shape.setTransform(185.425,195.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Outline
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#292929").s().p("Ar7CYIAAkvIAHAAIXwAAIAAEvgAr0CSIXpAAIAAkgI3pAAg");
	this.shape_1.setTransform(129.775,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Text
	this.choice_text = new lib.choice_text();
	this.choice_text.name = "choice_text";
	this.choice_text.setTransform(173.9,211.5,1,1,0,0,0,109.9,13.3);

	this.timeline.addTween(cjs.Tween.get(this.choice_text).wait(1));

	// Layer_2
	this.txt2 = new cjs.Text("", "11px 'Segoe Pro'", "#D84739");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 17;
	this.txt2.lineWidth = 216;
	this.txt2.parent = this;
	this.txt2.setTransform(66,200.2);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ar2CVIAAkpIXtAAIAAEpg");
	this.shape_2.setTransform(129.675,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(53.4,180.4,230.4,44.400000000000006);


(lib.Menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.menu_text.cache(0,-10,150,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.btn1 = new lib.dropDownMenuBtn();
	this.btn1.name = "btn1";
	this.btn1.setTransform(0.15,-0.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn2 = new lib.dropDownMenuBtn();
	this.btn2.name = "btn2";
	this.btn2.setTransform(0.15,29.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn3 = new lib.dropDownMenuBtn();
	this.btn3.name = "btn3";
	this.btn3.setTransform(0.15,58.9,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn3},{t:this.btn2},{t:this.btn1}]}).wait(1));

	// Outline
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#292929").s().p("AL2G+IAAgBI3rAAIAAABIgHAAIAAt7IX5AAIAAN7gAr1G2IXrAAIAAkeI3rAAgAr1CRIXrAAIAAkeI3rAAgAr1iUIXrAAIAAkiI3rAAg");
	this.shape.setTransform(75.9,43.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// txt_backup
	this.menu_text = new lib.menu_text();
	this.menu_text.name = "menu_text";
	this.menu_text.setTransform(81,59.5,1,1,0,0,0,70.5,42.5);

	this.timeline.addTween(cjs.Tween.get(this.menu_text).wait(1));

	// rollOver
	this.ro3 = new lib.overlay();
	this.ro3.name = "ro3";
	this.ro3.setTransform(114.2,73.1,1,0.9439,0,0,0,114.4,15.2);
	this.ro3.alpha = 0;

	this.ro2 = new lib.overlay();
	this.ro2.name = "ro2";
	this.ro2.setTransform(114.2,43.9,1,0.9439,0,0,0,114.4,15.2);
	this.ro2.alpha = 0;

	this.ro1 = new lib.overlay();
	this.ro1.name = "ro1";
	this.ro1.setTransform(114.2,14.65,1,1,0,0,0,114.4,15.2);
	this.ro1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ro1},{t:this.ro2},{t:this.ro3}]}).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ar5G6IAAtzIXzAAIAANzg");
	this.shape_1.setTransform(75.925,43.575);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-0.9,153,102.80000000000001);


(lib.Excel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Powerpoint_300x600();
	this.instance.setTransform(126,133.85);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Powerpoint_Shadow();
	this.instance_1.setTransform(202.7,235.85,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel, new cjs.Rectangle(75.3,124.4,268.7,213.6), null);


(lib.drop_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// pointer
	this.pointer = new lib.pointer();
	this.pointer.name = "pointer";
	this.pointer.setTransform(117.8,232.6,0.6379,0.6379,0,0,0,14.8,18.8);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsOCkIAAlHIYdAAIAAFHg");
	mask.setTransform(91.1,220.825);

	// Menu
	this.selectorBox = new lib.menuChoice();
	this.selectorBox.name = "selectorBox";
	this.selectorBox.setTransform(138.45,114.6,1,1,0,0,0,175.3,90.5);

	var maskedShapeInstanceList = [this.selectorBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.selectorBox).wait(1));

	// Layer_6 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ay1HhIAAvBMAlrAAAIAAPBg");
	mask_1.setTransform(133.4,157.025);

	// Menu copy
	this.menu = new lib.Menu();
	this.menu.name = "menu";
	this.menu.setTransform(16.5,205.3,1,1,0,0,0,-0.5,-0.7);

	var maskedShapeInstanceList = [this.menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.menu).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.drop_menu, new cjs.Rectangle(16.4,204.5,153,40), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,600,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,600), null);


(lib.laptop_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_219 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(219).call(this.frame_219).wait(1));

	// OneDrive
	this.instance = new lib.OneDrive();
	this.instance.setTransform(337.85,167.2,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-196.1,y:-785.4},179).wait(1).to({regX:211.8,regY:227,x:-207.6,y:-760.3},0).wait(1).to({x:-210.5,y:-765.55},0).wait(1).to({x:-213.45,y:-770.9},0).wait(1).to({x:-216.45,y:-776.3},0).wait(1).to({x:-219.5,y:-781.85},0).wait(1).to({x:-222.6,y:-787.45},0).wait(1).to({x:-225.75,y:-793.2},0).wait(1).to({x:-229,y:-799.05},0).wait(1).to({x:-232.3,y:-805.05},0).wait(1).to({x:-235.7,y:-811.15},0).wait(1).to({x:-239.15,y:-817.4},0).wait(1).to({x:-242.65,y:-823.8},0).wait(1).to({x:-246.3,y:-830.35},0).wait(1).to({x:-250,y:-837.05},0).wait(1).to({x:-253.8,y:-843.95},0).wait(1).to({x:-257.7,y:-851},0).wait(1).to({x:-261.7,y:-858.25},0).wait(1).to({x:-265.8,y:-865.75},0).wait(1).to({x:-270.05,y:-873.45},0).wait(1).to({x:-274.45,y:-881.35},0).wait(1).to({x:-278.95,y:-889.5},0).wait(1).to({x:-283.6,y:-897.95},0).wait(1).to({x:-288.45,y:-906.7},0).wait(1).to({x:-293.4,y:-915.7},0).wait(1).to({x:-298.55,y:-925.05},0).wait(1).to({x:-303.95,y:-934.75},0).wait(1).to({x:-309.5,y:-944.8},0).wait(1).to({x:-315.25,y:-955.25},0).wait(1).to({x:-321.25,y:-966.15},0).wait(1).to({x:-327.5,y:-977.5},0).wait(1).to({x:-334.05,y:-989.3},0).wait(1).to({x:-340.85,y:-1001.6},0).wait(1).to({x:-347.95,y:-1014.5},0).wait(1).to({x:-355.35,y:-1027.9},0).wait(1).to({x:-363.1,y:-1041.95},0).wait(1).to({x:-371.2,y:-1056.65},0).wait(1).to({x:-379.7,y:-1071.95},0).wait(1).to({x:-388.5,y:-1087.95},0).wait(1).to({regX:220.5,regY:196.8,x:-389.05,y:-1134.85},0).to({_off:true},1).wait(1));

	// Outlook
	this.instance_1 = new lib.Outlook();
	this.instance_1.setTransform(313.95,355.4,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-220,y:-597.2},179).wait(1).to({regX:211.8,regY:227,x:-231.5,y:-572.1},0).wait(1).to({x:-234.4,y:-577.35},0).wait(1).to({x:-237.35,y:-582.7},0).wait(1).to({x:-240.35,y:-588.1},0).wait(1).to({x:-243.4,y:-593.65},0).wait(1).to({x:-246.5,y:-599.25},0).wait(1).to({x:-249.65,y:-605},0).wait(1).to({x:-252.9,y:-610.85},0).wait(1).to({x:-256.2,y:-616.85},0).wait(1).to({x:-259.6,y:-622.95},0).wait(1).to({x:-263.05,y:-629.2},0).wait(1).to({x:-266.55,y:-635.6},0).wait(1).to({x:-270.2,y:-642.15},0).wait(1).to({x:-273.9,y:-648.85},0).wait(1).to({x:-277.7,y:-655.75},0).wait(1).to({x:-281.6,y:-662.8},0).wait(1).to({x:-285.6,y:-670.05},0).wait(1).to({x:-289.7,y:-677.55},0).wait(1).to({x:-293.95,y:-685.25},0).wait(1).to({x:-298.35,y:-693.15},0).wait(1).to({x:-302.85,y:-701.3},0).wait(1).to({x:-307.5,y:-709.75},0).wait(1).to({x:-312.35,y:-718.5},0).wait(1).to({x:-317.3,y:-727.5},0).wait(1).to({x:-322.45,y:-736.85},0).wait(1).to({x:-327.85,y:-746.55},0).wait(1).to({x:-333.4,y:-756.6},0).wait(1).to({x:-339.15,y:-767.05},0).wait(1).to({x:-345.15,y:-777.95},0).wait(1).to({x:-351.4,y:-789.3},0).wait(1).to({x:-357.95,y:-801.1},0).wait(1).to({x:-364.75,y:-813.4},0).wait(1).to({x:-371.85,y:-826.3},0).wait(1).to({x:-379.25,y:-839.7},0).wait(1).to({x:-387,y:-853.75},0).wait(1).to({x:-395.1,y:-868.45},0).wait(1).to({x:-403.6,y:-883.75},0).wait(1).to({x:-412.4,y:-899.75},0).wait(1).to({regX:220.5,regY:196.8,x:-412.95,y:-946.65},0).to({_off:true},1).wait(1));

	// Aimes
	this.instance_2 = new lib.Teams();
	this.instance_2.setTransform(511.6,312.75,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-38.6,y:-639.85},179).wait(1).to({regX:211.1,regY:207.1,x:-50.8,y:-634.65},0).wait(1).to({x:-53.7,y:-639.9},0).wait(1).to({x:-56.65,y:-645.25},0).wait(1).to({x:-59.65,y:-650.65},0).wait(1).to({x:-62.7,y:-656.2},0).wait(1).to({x:-65.8,y:-661.8},0).wait(1).to({x:-68.95,y:-667.55},0).wait(1).to({x:-72.2,y:-673.4},0).wait(1).to({x:-75.5,y:-679.4},0).wait(1).to({x:-78.9,y:-685.5},0).wait(1).to({x:-82.35,y:-691.75},0).wait(1).to({x:-85.85,y:-698.15},0).wait(1).to({x:-89.5,y:-704.7},0).wait(1).to({x:-93.2,y:-711.4},0).wait(1).to({x:-97,y:-718.3},0).wait(1).to({x:-100.9,y:-725.35},0).wait(1).to({x:-104.9,y:-732.6},0).wait(1).to({x:-109,y:-740.1},0).wait(1).to({x:-113.25,y:-747.8},0).wait(1).to({x:-117.65,y:-755.7},0).wait(1).to({x:-122.15,y:-763.85},0).wait(1).to({x:-126.8,y:-772.3},0).wait(1).to({x:-131.65,y:-781.05},0).wait(1).to({x:-136.6,y:-790.05},0).wait(1).to({x:-141.75,y:-799.4},0).wait(1).to({x:-147.15,y:-809.1},0).wait(1).to({x:-152.7,y:-819.15},0).wait(1).to({x:-158.45,y:-829.6},0).wait(1).to({x:-164.45,y:-840.5},0).wait(1).to({x:-170.7,y:-851.85},0).wait(1).to({x:-177.25,y:-863.65},0).wait(1).to({x:-184.05,y:-875.95},0).wait(1).to({x:-191.15,y:-888.85},0).wait(1).to({x:-198.55,y:-902.25},0).wait(1).to({x:-206.3,y:-916.3},0).wait(1).to({x:-214.4,y:-931},0).wait(1).to({x:-222.9,y:-946.3},0).wait(1).to({x:-231.7,y:-962.3},0).wait(1).to({regX:220.5,regY:196.8,x:-231.55,y:-989.3},0).to({_off:true},1).wait(1));

	// Word
	this.instance_3 = new lib.Powerpoint();
	this.instance_3.setTransform(498.4,491.3,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-35.55,y:-461.3},179).wait(1).to({regX:205,regY:228.3,x:-53.85,y:-434.9},0).wait(1).to({x:-56.75,y:-440.15},0).wait(1).to({x:-59.7,y:-445.5},0).wait(1).to({x:-62.7,y:-450.9},0).wait(1).to({x:-65.75,y:-456.45},0).wait(1).to({x:-68.85,y:-462.05},0).wait(1).to({x:-72,y:-467.8},0).wait(1).to({x:-75.25,y:-473.65},0).wait(1).to({x:-78.55,y:-479.65},0).wait(1).to({x:-81.95,y:-485.75},0).wait(1).to({x:-85.4,y:-492},0).wait(1).to({x:-88.9,y:-498.4},0).wait(1).to({x:-92.55,y:-504.95},0).wait(1).to({x:-96.25,y:-511.65},0).wait(1).to({x:-100.05,y:-518.55},0).wait(1).to({x:-103.95,y:-525.6},0).wait(1).to({x:-107.95,y:-532.85},0).wait(1).to({x:-112.05,y:-540.35},0).wait(1).to({x:-116.3,y:-548.05},0).wait(1).to({x:-120.7,y:-555.95},0).wait(1).to({x:-125.2,y:-564.1},0).wait(1).to({x:-129.85,y:-572.55},0).wait(1).to({x:-134.7,y:-581.3},0).wait(1).to({x:-139.65,y:-590.3},0).wait(1).to({x:-144.8,y:-599.65},0).wait(1).to({x:-150.2,y:-609.35},0).wait(1).to({x:-155.75,y:-619.4},0).wait(1).to({x:-161.5,y:-629.85},0).wait(1).to({x:-167.5,y:-640.75},0).wait(1).to({x:-173.75,y:-652.1},0).wait(1).to({x:-180.3,y:-663.9},0).wait(1).to({x:-187.1,y:-676.2},0).wait(1).to({x:-194.2,y:-689.1},0).wait(1).to({x:-201.6,y:-702.5},0).wait(1).to({x:-209.35,y:-716.55},0).wait(1).to({x:-217.45,y:-731.25},0).wait(1).to({x:-225.95,y:-746.55},0).wait(1).to({x:-234.75,y:-762.55},0).wait(1).to({regX:220.5,regY:196.8,x:-228.5,y:-810.75},0).to({_off:true},1).wait(1));

	// PowerPoint
	this.instance_4 = new lib.Excel();
	this.instance_4.setTransform(677.9,412.35,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:143.95,y:-540.25},179).wait(1).to({regX:205.2,regY:235.9,x:125.85,y:-506.25},0).wait(1).to({x:122.95,y:-511.5},0).wait(1).to({x:120,y:-516.85},0).wait(1).to({x:117,y:-522.25},0).wait(1).to({x:113.95,y:-527.8},0).wait(1).to({x:110.85,y:-533.4},0).wait(1).to({x:107.7,y:-539.15},0).wait(1).to({x:104.45,y:-545},0).wait(1).to({x:101.15,y:-551},0).wait(1).to({x:97.75,y:-557.1},0).wait(1).to({x:94.3,y:-563.35},0).wait(1).to({x:90.8,y:-569.75},0).wait(1).to({x:87.15,y:-576.3},0).wait(1).to({x:83.45,y:-583},0).wait(1).to({x:79.65,y:-589.9},0).wait(1).to({x:75.75,y:-596.95},0).wait(1).to({x:71.75,y:-604.2},0).wait(1).to({x:67.65,y:-611.7},0).wait(1).to({x:63.4,y:-619.4},0).wait(1).to({x:59,y:-627.3},0).wait(1).to({x:54.5,y:-635.45},0).wait(1).to({x:49.85,y:-643.9},0).wait(1).to({x:45,y:-652.65},0).wait(1).to({x:40.05,y:-661.65},0).wait(1).to({x:34.9,y:-671},0).wait(1).to({x:29.5,y:-680.7},0).wait(1).to({x:23.95,y:-690.75},0).wait(1).to({x:18.2,y:-701.2},0).wait(1).to({x:12.2,y:-712.1},0).wait(1).to({x:5.95,y:-723.45},0).wait(1).to({x:-0.6,y:-735.25},0).wait(1).to({x:-7.4,y:-747.55},0).wait(1).to({x:-14.5,y:-760.45},0).wait(1).to({x:-21.9,y:-773.85},0).wait(1).to({x:-29.65,y:-787.9},0).wait(1).to({x:-37.75,y:-802.6},0).wait(1).to({x:-46.25,y:-817.9},0).wait(1).to({x:-55.05,y:-833.9},0).wait(1).to({regX:220.5,regY:196.8,x:-49,y:-889.7},0).to({_off:true},1).wait(1));

	// Excel
	this.instance_5 = new lib.Wordcopy2();
	this.instance_5.setTransform(698.85,608.5,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:161.85,y:-339.8},179).wait(1).to({regX:213.9,regY:229.1,x:152.5,y:-312.5},0).wait(1).to({x:149.65,y:-317.65},0).wait(1).to({x:146.75,y:-322.85},0).wait(1).to({x:143.8,y:-328.15},0).wait(1).to({x:140.8,y:-333.6},0).wait(1).to({x:137.75,y:-339.1},0).wait(1).to({x:134.6,y:-344.7},0).wait(1).to({x:131.45,y:-350.45},0).wait(1).to({x:128.2,y:-356.3},0).wait(1).to({x:124.85,y:-362.3},0).wait(1).to({x:121.45,y:-368.4},0).wait(1).to({x:118,y:-374.7},0).wait(1).to({x:114.45,y:-381.1},0).wait(1).to({x:110.8,y:-387.65},0).wait(1).to({x:107.05,y:-394.4},0).wait(1).to({x:103.2,y:-401.3},0).wait(1).to({x:99.3,y:-408.45},0).wait(1).to({x:95.2,y:-415.75},0).wait(1).to({x:91.05,y:-423.3},0).wait(1).to({x:86.75,y:-431.05},0).wait(1).to({x:82.3,y:-439.05},0).wait(1).to({x:77.7,y:-447.3},0).wait(1).to({x:73,y:-455.85},0).wait(1).to({x:68.1,y:-464.65},0).wait(1).to({x:63,y:-473.85},0).wait(1).to({x:57.75,y:-483.3},0).wait(1).to({x:52.3,y:-493.2},0).wait(1).to({x:46.6,y:-503.4},0).wait(1).to({x:40.7,y:-514.1},0).wait(1).to({x:34.55,y:-525.15},0).wait(1).to({x:28.1,y:-536.75},0).wait(1).to({x:21.4,y:-548.8},0).wait(1).to({x:14.45,y:-561.4},0).wait(1).to({x:7.15,y:-574.55},0).wait(1).to({x:-0.5,y:-588.3},0).wait(1).to({x:-8.45,y:-602.65},0).wait(1).to({x:-16.8,y:-617.7},0).wait(1).to({x:-25.45,y:-633.35},0).wait(1).to({regX:220.5,regY:196.8,x:-27.95,y:-682},0).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-548.9,-1211.8,1564.1,2069.8);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// icons
	this.icons = new lib.laptop_anim();
	this.icons.name = "icons";
	this.icons.setTransform(319.3,515.65,0.85,0.85,0,0,0,283.9,24.8);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,196,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// drop_menu
	this.dropdown = new lib.drop_menu();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(102.5,335.25);

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// dropDownMenuBtn
	this.dropDownMenuBtn = new lib.dropDownMenuBtn();
	this.dropDownMenuBtn.name = "dropDownMenuBtn";
	this.dropDownMenuBtn.setTransform(234.5,621.75,1,1,0,0,0,116,81.5);
	new cjs.ButtonHelper(this.dropDownMenuBtn, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.dropDownMenuBtn).wait(1));

	// screen
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(319.3,515.65,0.85,0.85,0,0,0,283.9,24.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// BG
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-1,0,987.9,1280), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						}
				}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var screen = mc.screen
		var phone = mc.phone
		
		this.runBanner = function() {
			
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "+=0", alpha: 0, ease:Power4.easeIn}, "+=1.8");
				if (i!=0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "+=0", alpha: 0, ease:Power4.easeIn}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=1.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}		
		
			exportRoot.tl1.from(mc.dropdown, 0.8, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.5");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "+=0.5");
				
			exportRoot.tl1.from(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {alpha:1, onStart:function(){mc.dropdown.pointer.gotoAndPlay(1);exportRoot.showMenu()}}, "+=0.2");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power3.easeIn}, "+=0.5");
				
			exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1);
		}
		exportRoot.myTimer = function() {
			exportRoot.hideMenu()
		}
		
		exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		
		
		var theMenu = exportRoot.mainMC.dropdown.menu
		var theMenuBtn = exportRoot.mainMC.dropDownMenuBtn
		var menuClosed = true
		
		exportRoot.btn1 = theMenu.btn1; var ro1 = theMenu.ro1;
		exportRoot.btn2 = theMenu.btn2; var ro2 = theMenu.ro2;
		exportRoot.btn3 = theMenu.btn3; var ro3 = theMenu.ro3;
		exportRoot.btn1.enabled = false
		exportRoot.btn2.enabled = false
		exportRoot.btn3.enabled = false
		
		theMenuBtn.addEventListener("click", function(event) { exportRoot.menuClick() })
		
		this.menuClick = function() {
			TweenMax.killTweensOf(theMenu);
			if (menuClosed) exportRoot.showMenu()
			if (!menuClosed) exportRoot.hideMenu()
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		
		this.showMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:117, ease:Power4.easeOut, onComplete:function(){menuClosed = false}});
			exportRoot.btn1.enabled = true
			exportRoot.btn2.enabled = true
			exportRoot.btn3.enabled = true
			
		}
		this.hideMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:206.3, ease:Power4.easeOut, onComplete:function(){menuClosed = true}});
			exportRoot.btn1.enabled = false
			exportRoot.btn2.enabled = false
			exportRoot.btn3.enabled = false
		}
		
		exportRoot.btn1.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(1) })
		exportRoot.btn2.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(2) })
		exportRoot.btn3.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(3) })
		
		
		exportRoot.btn1.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(1) })
		exportRoot.btn2.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(2) })
		exportRoot.btn3.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(3) })
		
		exportRoot.rollOverAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:1});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		exportRoot.rollOutAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:0});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	// btn
	this.btn = new lib.mainBtn();
	this.btn.name = "btn";
	this.btn.setTransform(102.5,92,1,1,0,0,0,102.5,92);
	new cjs.ButtonHelper(this.btn, 0, 1, 2, false, new lib.mainBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(149,300,837.9,980);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_.png?1582726404156", id:"O365_FY20Q4_Cons_USA_300x600_BAN_MoneyInExcel_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;