(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[0,561,450,123],[1159,0,326,91],[1159,347,295,72],[1159,93,229,125],[1456,93,29,65],[1159,220,219,125],[0,0,1157,559]]}
];


// symbols:



(lib.bg_grey = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Hero_Achieve_300x250_0000_clouds_2 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Hero_Achieve_300x250_0001_clouds_1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Rock_1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Rock_2pngcopy = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.rock_3 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Untitled3 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Mountain_rock_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock_2pngcopy();
	this.instance.setTransform(49,-97.45);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_4, new cjs.Rectangle(49,-97.4,29,65), null);


(lib.Mountain_rock_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.rock_3();
	this.instance.setTransform(5.1,-130.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.1,-130.2,219,124.99999999999999);


(lib.Mountain_rock_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Rock_1();
	this.instance.setTransform(-1.35,-126.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_rock_2, new cjs.Rectangle(-1.3,-126.1,229,125), null);


(lib.Mountain_cloud_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hero_Achieve_300x250_0000_clouds_2();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_cloud_2, new cjs.Rectangle(0,0,326,91), null);


(lib.Mountain_Cloud_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Hero_Achieve_300x250_0001_clouds_1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_Cloud_1, new cjs.Rectangle(0,0,295,72), null);


(lib.Mountain_BG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.bg_grey();
	this.instance.setTransform(-224.1,-133.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Mountain_BG, new cjs.Rectangle(-224.1,-133.7,450,122.99999999999999), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.line_blip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgqAqQgRgSAAgYQAAgYARgSQASgRAYAAQAYAAASARQASASAAAYQAAAYgSASQgSASgYAAQgYAAgSgSg");
	this.shape.setTransform(6,6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.line_blip, new cjs.Rectangle(0,0,12,12), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.Mountain_rock_3_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		/*exportRoot.tl2.play();*/
	}
	this.frame_132 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(113).call(this.frame_132).wait(1));

	// Layer_6
	this.blip_1 = new lib.line_blip();
	this.blip_1.name = "blip_1";
	this.blip_1.setTransform(187.3,-98.75,0.2,0.2,0,0,0,6.3,6);
	this.blip_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1).wait(114).to({_off:false},0).to({regX:6,scaleX:1.2,scaleY:1.2,x:187.25},11,cjs.Ease.cubicOut).to({regX:6.1,regY:6.1,scaleX:1,scaleY:1,x:187.3},5,cjs.Ease.cubicInOut).wait(3));

	// Layer_5
	this.blip_1_1 = new lib.line_blip();
	this.blip_1_1.name = "blip_1_1";
	this.blip_1_1.setTransform(137.65,-69.55,0.2,0.2,0,0,0,6,6);
	this.blip_1_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1_1).wait(84).to({_off:false},0).to({scaleX:1.2,scaleY:1.2},11,cjs.Ease.cubicOut).to({scaleX:1,scaleY:1},5,cjs.Ease.cubicInOut).wait(33));

	// Layer_4
	this.blip_1_2 = new lib.line_blip();
	this.blip_1_2.name = "blip_1_2";
	this.blip_1_2.setTransform(68.85,-44.5,0.2,0.2,0,0,0,6.3,6.3);
	this.blip_1_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.blip_1_2).wait(41).to({_off:false},0).to({regX:6,regY:6,scaleX:1.2,scaleY:1.2},11,cjs.Ease.cubicOut).to({scaleX:1,scaleY:1,y:-44.45},5,cjs.Ease.cubicInOut).wait(76));

	// Layer_11 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ah1hkIBxg2IB6D/IhxA2g");
	var mask_graphics_1 = new cjs.Graphics().p("Ah1hkIBxg2IB6D/IhxA2g");
	var mask_graphics_2 = new cjs.Graphics().p("Ah2hjIBzg4IB6D/IhzA4g");
	var mask_graphics_3 = new cjs.Graphics().p("Ah4hiIB3g6IB6D/Ih3A6g");
	var mask_graphics_4 = new cjs.Graphics().p("Ah7hhIB7g8IB8D/Ih8A8g");
	var mask_graphics_5 = new cjs.Graphics().p("Ah+hgICBg/IB8EAIiBA/g");
	var mask_graphics_6 = new cjs.Graphics().p("AiCheICJhCIB8D/IiJBCg");
	var mask_graphics_7 = new cjs.Graphics().p("AiGhcICShHIB7EAIiSBHg");
	var mask_graphics_8 = new cjs.Graphics().p("AiMhZICdhMIB8D/IidBMg");
	var mask_graphics_9 = new cjs.Graphics().p("AiShWICphSIB8D/IipBSg");
	var mask_graphics_10 = new cjs.Graphics().p("AiYhTIC2hYIB7D/Ii2BYg");
	var mask_graphics_11 = new cjs.Graphics().p("AighPIDFhgIB8D/IjFBgg");
	var mask_graphics_12 = new cjs.Graphics().p("AiohLIDVhoIB8D/IjVBog");
	var mask_graphics_13 = new cjs.Graphics().p("AixhHIDnhwIB8D/IjnBwg");
	var mask_graphics_14 = new cjs.Graphics().p("Ai6hDID6h5IB7EAIj6B5g");
	var mask_graphics_15 = new cjs.Graphics().p("AjFg+IEPiDIB8EAIkPCDg");
	var mask_graphics_16 = new cjs.Graphics().p("AjQg4IEliOIB8D/IklCOg");
	var mask_graphics_17 = new cjs.Graphics().p("AjbgzIE8iZIB7EAIk8CZg");
	var mask_graphics_18 = new cjs.Graphics().p("AjogtIFVikIB8D/IlVCkg");
	var mask_graphics_19 = new cjs.Graphics().p("Aj1gmIFviyIB8D/IlvCyg");
	var mask_graphics_20 = new cjs.Graphics().p("AkDggIGLi+IB8D/ImLC+g");
	var mask_graphics_21 = new cjs.Graphics().p("AkRgZIGojMIB7D/ImoDMg");
	var mask_graphics_22 = new cjs.Graphics().p("AkggSIHFjaIB8D/InFDag");
	var mask_graphics_23 = new cjs.Graphics().p("AktgLIHgjoIB7D/IngDog");
	var mask_graphics_24 = new cjs.Graphics().p("Ak6gFIH6j0IB7D/In6D0g");
	var mask_graphics_25 = new cjs.Graphics().p("AlHAAIITj/IB8D/IoTEAg");
	var mask_graphics_26 = new cjs.Graphics().p("AlSAGIIqkLIB7EAIoqELg");
	var mask_graphics_27 = new cjs.Graphics().p("AldALIJAkVIB7EAIpAEVg");
	var mask_graphics_28 = new cjs.Graphics().p("AloAQIJVkfIB8EAIpVEfg");
	var mask_graphics_29 = new cjs.Graphics().p("AlxAVIJokpIB7EAIpoEpg");
	var mask_graphics_30 = new cjs.Graphics().p("Al6AZIJ6kxIB7EAIp6Exg");
	var mask_graphics_31 = new cjs.Graphics().p("AmCAdIKKk5IB7EAIqKE5g");
	var mask_graphics_32 = new cjs.Graphics().p("AmKAgIKZlAIB8EBIqZFAg");
	var mask_graphics_33 = new cjs.Graphics().p("AmQAkIKmlHIB7EBIqmFGg");
	var mask_graphics_34 = new cjs.Graphics().p("AmWAmIKylMIB7EBIqyFMg");
	var mask_graphics_35 = new cjs.Graphics().p("AmcApIK9lRIB8EAIq9FRg");
	var mask_graphics_36 = new cjs.Graphics().p("AmgArILGlVIB7EAIrGFVg");
	var mask_graphics_37 = new cjs.Graphics().p("AmkAtILOlZIB7EAIrOFZg");
	var mask_graphics_38 = new cjs.Graphics().p("AmnAvILUldIB7EAIrUFdg");
	var mask_graphics_39 = new cjs.Graphics().p("AmqAwILZlfIB8EAIrZFfg");
	var mask_graphics_40 = new cjs.Graphics().p("AmsAxILdlhIB8EAIrdFhg");
	var mask_graphics_41 = new cjs.Graphics().p("AmtAxILflhIB8EAIrfFhg");
	var mask_graphics_42 = new cjs.Graphics().p("AmtAxILgliIB7EBIrgFig");
	var mask_graphics_43 = new cjs.Graphics().p("AmtAxILgliIB7EBIrgFig");
	var mask_graphics_44 = new cjs.Graphics().p("AmuAyILiljIB7EAIriFjg");
	var mask_graphics_45 = new cjs.Graphics().p("AmwAzILmllIB7EAIrmFlg");
	var mask_graphics_46 = new cjs.Graphics().p("AmzA0ILrlnIB8EAIrrFng");
	var mask_graphics_47 = new cjs.Graphics().p("Am2A1ILxlqIB8EBIrxFqg");
	var mask_graphics_48 = new cjs.Graphics().p("Am5A3IL4luIB7EBIr4Fug");
	var mask_graphics_49 = new cjs.Graphics().p("Am+A5IMBlyIB8EBIsBFyg");
	var mask_graphics_50 = new cjs.Graphics().p("AnDA8IMMl3IB7EAIsMF3g");
	var mask_graphics_51 = new cjs.Graphics().p("AnJA/IMYl9IB7EAIsYF9g");
	var mask_graphics_52 = new cjs.Graphics().p("AnQBCIMlmDIB8EAIslGDg");
	var mask_graphics_53 = new cjs.Graphics().p("AnXBFIMzmKIB8EBIszGKg");
	var mask_graphics_54 = new cjs.Graphics().p("AnfBJINDmSIB8EBItDGSg");
	var mask_graphics_55 = new cjs.Graphics().p("AnnBNINUmaIB7EBItUGag");
	var mask_graphics_56 = new cjs.Graphics().p("AnxBSINnmjIB8EAItnGjg");
	var mask_graphics_57 = new cjs.Graphics().p("An7BXIN7mtIB8EAIt7Gtg");
	var mask_graphics_58 = new cjs.Graphics().p("AoFBcIOQm3IB7EAIuQG3g");
	var mask_graphics_59 = new cjs.Graphics().p("AoRBhIOnnCIB8EBIunHCg");
	var mask_graphics_60 = new cjs.Graphics().p("AodBnIO/nOIB8EBIu/HOg");
	var mask_graphics_61 = new cjs.Graphics().p("AoqBtIPZnaIB8EBIvZHag");
	var mask_graphics_62 = new cjs.Graphics().p("Ao3B0IP0nnIB7EAIv0Hng");
	var mask_graphics_63 = new cjs.Graphics().p("ApFB7IQQn1IB7EAIwQH1g");
	var mask_graphics_64 = new cjs.Graphics().p("ApUCCIQuoDIB7EAIwuIDg");
	var mask_graphics_65 = new cjs.Graphics().p("ApiCJIRKoRIB7EAIxKIRg");
	var mask_graphics_66 = new cjs.Graphics().p("ApwCPIRlodIB8EAIxlIdg");
	var mask_graphics_67 = new cjs.Graphics().p("Ap9CVIR/oqIB8EBIx/Iqg");
	var mask_graphics_68 = new cjs.Graphics().p("AqJCbISXo1IB8EAIyXI1g");
	var mask_graphics_69 = new cjs.Graphics().p("AqUChISupBIB7EAIyuJBg");
	var mask_graphics_70 = new cjs.Graphics().p("AqfCmITDpLIB8EAIzDJLg");
	var mask_graphics_71 = new cjs.Graphics().p("AqpCrITXpVIB8EAIzXJVg");
	var mask_graphics_72 = new cjs.Graphics().p("AqyCvITqpdIB7EAIzqJdg");
	var mask_graphics_73 = new cjs.Graphics().p("Aq7CzIT7pmIB8EBIz7Jmg");
	var mask_graphics_74 = new cjs.Graphics().p("ArDC3IULptIB8EAI0LJtg");
	var mask_graphics_75 = new cjs.Graphics().p("ArKC7IUZp1IB8EAI0ZJ1g");
	var mask_graphics_76 = new cjs.Graphics().p("ArQC+IUmp7IB7EAI0mJ7g");
	var mask_graphics_77 = new cjs.Graphics().p("ArWDBIUyqBIB7EAI0yKBg");
	var mask_graphics_78 = new cjs.Graphics().p("ArcDDIU9qFIB8EAI09KFg");
	var mask_graphics_79 = new cjs.Graphics().p("ArgDFIVGqKIB7EBI1GKKg");
	var mask_graphics_80 = new cjs.Graphics().p("ArkDHIVNqNIB8EAI1NKNg");
	var mask_graphics_81 = new cjs.Graphics().p("ArnDJIVTqRIB8EAI1TKRg");
	var mask_graphics_82 = new cjs.Graphics().p("ArpDKIVYqTIB7EAI1YKTg");
	var mask_graphics_83 = new cjs.Graphics().p("ArrDLIVcqVIB7EAI1cKVg");
	var mask_graphics_84 = new cjs.Graphics().p("ArsDLIVeqVIB7EAI1eKVg");
	var mask_graphics_85 = new cjs.Graphics().p("ArsDLIVeqWIB7EBI1eKWg");
	var mask_graphics_86 = new cjs.Graphics().p("ArtDLIVfqWIB8EBI1fKWg");
	var mask_graphics_87 = new cjs.Graphics().p("AruDMIVhqXIB8EAI1hKXg");
	var mask_graphics_88 = new cjs.Graphics().p("ArwDNIVlqZIB8EAI1lKZg");
	var mask_graphics_89 = new cjs.Graphics().p("AryDOIVpqbIB8EAI1pKbg");
	var mask_graphics_90 = new cjs.Graphics().p("Ar1DPIVwqeIB7EBI1wKeg");
	var mask_graphics_91 = new cjs.Graphics().p("Ar5DRIV3qiIB8EBI13Khg");
	var mask_graphics_92 = new cjs.Graphics().p("Ar9DTIWAqmIB7EBI2AKmg");
	var mask_graphics_93 = new cjs.Graphics().p("AsDDWIWLqrIB8EAI2LKrg");
	var mask_graphics_94 = new cjs.Graphics().p("AsIDZIWWqxIB7EAI2WKxg");
	var mask_graphics_95 = new cjs.Graphics().p("AsPDcIWjq3IB8EAI2kK3g");
	var mask_graphics_96 = new cjs.Graphics().p("AsWDfIWyq+IB7EBI2yK+g");
	var mask_graphics_97 = new cjs.Graphics().p("AseDjIXCrFIB7EAI3CLFg");
	var mask_graphics_98 = new cjs.Graphics().p("AsnDnIXTrOIB8EBI3TLOg");
	var mask_graphics_99 = new cjs.Graphics().p("AswDsIXmrXIB7EAI3mLXg");
	var mask_graphics_100 = new cjs.Graphics().p("As6DxIX6rhIB7EAI36Lhg");
	var mask_graphics_101 = new cjs.Graphics().p("AtFD2IYPrrIB8EAI4PLrg");
	var mask_graphics_102 = new cjs.Graphics().p("AtQD7IYmr2IB7EBI4mL2g");
	var mask_graphics_103 = new cjs.Graphics().p("AtcEBIY+sBIB7EAI4+MBg");
	var mask_graphics_104 = new cjs.Graphics().p("AtpEHIZYsOIB7EBI5YMOg");
	var mask_graphics_105 = new cjs.Graphics().p("At3EOIZzsbIB8EAI5zMbg");
	var mask_graphics_106 = new cjs.Graphics().p("AuFEVIaPspIB8EAI6PMpg");
	var mask_graphics_107 = new cjs.Graphics().p("AuUEcIats3IB8EAI6tM3g");
	var mask_graphics_108 = new cjs.Graphics().p("AuiEjIbJtFIB8EAI7JNFg");
	var mask_graphics_109 = new cjs.Graphics().p("AuvEpIbktRIB7EAI7kNRg");
	var mask_graphics_110 = new cjs.Graphics().p("Au8EvIb9teIB8EBI79Neg");
	var mask_graphics_111 = new cjs.Graphics().p("AvIE1IcWtpIB7EAI8WNpg");
	var mask_graphics_112 = new cjs.Graphics().p("AvTE7Icst1IB7EAI8sN1g");
	var mask_graphics_113 = new cjs.Graphics().p("AveFAIdCt/IB7EAI9CN/g");
	var mask_graphics_114 = new cjs.Graphics().p("AvoFFIdWuJIB7EAI9WOJg");
	var mask_graphics_115 = new cjs.Graphics().p("AvyFJIdpuRIB8EAI9pORg");
	var mask_graphics_116 = new cjs.Graphics().p("Av6FNId6uZIB7EAI96OZg");
	var mask_graphics_117 = new cjs.Graphics().p("AwCFRIeKuhIB7EAI+KOhg");
	var mask_graphics_118 = new cjs.Graphics().p("AwJFVIeYupIB7EAI+YOpg");
	var mask_graphics_119 = new cjs.Graphics().p("AwQFYIeluvIB8EAI+lOvg");
	var mask_graphics_120 = new cjs.Graphics().p("AwWFbIexu1IB8EAI+xO1g");
	var mask_graphics_121 = new cjs.Graphics().p("AwbFdIe7u5IB8EAI+7O5g");
	var mask_graphics_122 = new cjs.Graphics().p("AwfFfIfEu9IB7EAI/EO9g");
	var mask_graphics_123 = new cjs.Graphics().p("AwjFhIfMvBIB7EAI/MPBg");
	var mask_graphics_124 = new cjs.Graphics().p("AwmFjIfSvFIB7EAI/SPFg");
	var mask_graphics_125 = new cjs.Graphics().p("AwpFkIfXvHIB8EAI/XPHg");
	var mask_graphics_126 = new cjs.Graphics().p("AwrFlIfbvJIB8EAI/bPJg");
	var mask_graphics_127 = new cjs.Graphics().p("AwsFlIfdvJIB8EAI/dPJg");
	var mask_graphics_128 = new cjs.Graphics().p("AwsFlIfdvJIB8EAI/dPJg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:3.6046,y:-5.6976}).wait(1).to({graphics:mask_graphics_1,x:3.6399,y:-5.7148}).wait(1).to({graphics:mask_graphics_2,x:3.7459,y:-5.7661}).wait(1).to({graphics:mask_graphics_3,x:3.9224,y:-5.8516}).wait(1).to({graphics:mask_graphics_4,x:4.1696,y:-5.9713}).wait(1).to({graphics:mask_graphics_5,x:4.4874,y:-6.1253}).wait(1).to({graphics:mask_graphics_6,x:4.8758,y:-6.3134}).wait(1).to({graphics:mask_graphics_7,x:5.3349,y:-6.5358}).wait(1).to({graphics:mask_graphics_8,x:5.8645,y:-6.7923}).wait(1).to({graphics:mask_graphics_9,x:6.4648,y:-7.0831}).wait(1).to({graphics:mask_graphics_10,x:7.1357,y:-7.4081}).wait(1).to({graphics:mask_graphics_11,x:7.8773,y:-7.7673}).wait(1).to({graphics:mask_graphics_12,x:8.6894,y:-8.1607}).wait(1).to({graphics:mask_graphics_13,x:9.5722,y:-8.5883}).wait(1).to({graphics:mask_graphics_14,x:10.5256,y:-9.0501}).wait(1).to({graphics:mask_graphics_15,x:11.5497,y:-9.5461}).wait(1).to({graphics:mask_graphics_16,x:12.6443,y:-10.0764}).wait(1).to({graphics:mask_graphics_17,x:13.8096,y:-10.6408}).wait(1).to({graphics:mask_graphics_18,x:15.0455,y:-11.2395}).wait(1).to({graphics:mask_graphics_19,x:16.352,y:-11.8723}).wait(1).to({graphics:mask_graphics_20,x:17.7291,y:-12.5394}).wait(1).to({graphics:mask_graphics_21,x:19.1769,y:-13.2407}).wait(1).to({graphics:mask_graphics_22,x:20.6247,y:-13.942}).wait(1).to({graphics:mask_graphics_23,x:22.0018,y:-14.609}).wait(1).to({graphics:mask_graphics_24,x:23.3083,y:-15.2419}).wait(1).to({graphics:mask_graphics_25,x:24.5442,y:-15.8406}).wait(1).to({graphics:mask_graphics_26,x:25.7095,y:-16.405}).wait(1).to({graphics:mask_graphics_27,x:26.8041,y:-16.9352}).wait(1).to({graphics:mask_graphics_28,x:27.8282,y:-17.4313}).wait(1).to({graphics:mask_graphics_29,x:28.7816,y:-17.8931}).wait(1).to({graphics:mask_graphics_30,x:29.6644,y:-18.3207}).wait(1).to({graphics:mask_graphics_31,x:30.4765,y:-18.7141}).wait(1).to({graphics:mask_graphics_32,x:31.218,y:-19.0733}).wait(1).to({graphics:mask_graphics_33,x:31.889,y:-19.3983}).wait(1).to({graphics:mask_graphics_34,x:32.4893,y:-19.6891}).wait(1).to({graphics:mask_graphics_35,x:33.0189,y:-19.9456}).wait(1).to({graphics:mask_graphics_36,x:33.478,y:-20.168}).wait(1).to({graphics:mask_graphics_37,x:33.8664,y:-20.3561}).wait(1).to({graphics:mask_graphics_38,x:34.1842,y:-20.5101}).wait(1).to({graphics:mask_graphics_39,x:34.4314,y:-20.6298}).wait(1).to({graphics:mask_graphics_40,x:34.6079,y:-20.7153}).wait(1).to({graphics:mask_graphics_41,x:34.7139,y:-20.7666}).wait(1).to({graphics:mask_graphics_42,x:34.7544,y:-20.7308}).wait(1).to({graphics:mask_graphics_43,x:34.7888,y:-20.7474}).wait(1).to({graphics:mask_graphics_44,x:34.892,y:-20.7971}).wait(1).to({graphics:mask_graphics_45,x:35.0639,y:-20.8801}).wait(1).to({graphics:mask_graphics_46,x:35.3046,y:-20.9963}).wait(1).to({graphics:mask_graphics_47,x:35.6141,y:-21.1456}).wait(1).to({graphics:mask_graphics_48,x:35.9923,y:-21.3281}).wait(1).to({graphics:mask_graphics_49,x:36.4393,y:-21.5439}).wait(1).to({graphics:mask_graphics_50,x:36.9551,y:-21.7928}).wait(1).to({graphics:mask_graphics_51,x:37.5397,y:-22.0749}).wait(1).to({graphics:mask_graphics_52,x:38.193,y:-22.3902}).wait(1).to({graphics:mask_graphics_53,x:38.9152,y:-22.7386}).wait(1).to({graphics:mask_graphics_54,x:39.706,y:-23.1203}).wait(1).to({graphics:mask_graphics_55,x:40.5657,y:-23.5351}).wait(1).to({graphics:mask_graphics_56,x:41.4941,y:-23.9832}).wait(1).to({graphics:mask_graphics_57,x:42.4913,y:-24.4644}).wait(1).to({graphics:mask_graphics_58,x:43.5573,y:-24.9788}).wait(1).to({graphics:mask_graphics_59,x:44.6921,y:-25.5264}).wait(1).to({graphics:mask_graphics_60,x:45.8956,y:-26.1072}).wait(1).to({graphics:mask_graphics_61,x:47.1679,y:-26.7212}).wait(1).to({graphics:mask_graphics_62,x:48.509,y:-27.3684}).wait(1).to({graphics:mask_graphics_63,x:49.9188,y:-28.0487}).wait(1).to({graphics:mask_graphics_64,x:51.3802,y:-28.754}).wait(1).to({graphics:mask_graphics_65,x:52.7901,y:-29.4343}).wait(1).to({graphics:mask_graphics_66,x:54.1311,y:-30.0815}).wait(1).to({graphics:mask_graphics_67,x:55.4034,y:-30.6954}).wait(1).to({graphics:mask_graphics_68,x:56.6069,y:-31.2762}).wait(1).to({graphics:mask_graphics_69,x:57.7417,y:-31.8238}).wait(1).to({graphics:mask_graphics_70,x:58.8077,y:-32.3383}).wait(1).to({graphics:mask_graphics_71,x:59.8049,y:-32.8195}).wait(1).to({graphics:mask_graphics_72,x:60.7333,y:-33.2675}).wait(1).to({graphics:mask_graphics_73,x:61.593,y:-33.6824}).wait(1).to({graphics:mask_graphics_74,x:62.3838,y:-34.064}).wait(1).to({graphics:mask_graphics_75,x:63.106,y:-34.4125}).wait(1).to({graphics:mask_graphics_76,x:63.7593,y:-34.7278}).wait(1).to({graphics:mask_graphics_77,x:64.3439,y:-35.0099}).wait(1).to({graphics:mask_graphics_78,x:64.8597,y:-35.2588}).wait(1).to({graphics:mask_graphics_79,x:65.3067,y:-35.4745}).wait(1).to({graphics:mask_graphics_80,x:65.6849,y:-35.6571}).wait(1).to({graphics:mask_graphics_81,x:65.9944,y:-35.8064}).wait(1).to({graphics:mask_graphics_82,x:66.2351,y:-35.9226}).wait(1).to({graphics:mask_graphics_83,x:66.407,y:-36.0055}).wait(1).to({graphics:mask_graphics_84,x:66.5102,y:-36.0553}).wait(1).to({graphics:mask_graphics_85,x:66.5446,y:-36.0719}).wait(1).to({graphics:mask_graphics_86,x:66.579,y:-36.0884}).wait(1).to({graphics:mask_graphics_87,x:66.6822,y:-36.1378}).wait(1).to({graphics:mask_graphics_88,x:66.8542,y:-36.2201}).wait(1).to({graphics:mask_graphics_89,x:67.0951,y:-36.3354}).wait(1).to({graphics:mask_graphics_90,x:67.4047,y:-36.4837}).wait(1).to({graphics:mask_graphics_91,x:67.7832,y:-36.6648}).wait(1).to({graphics:mask_graphics_92,x:68.2305,y:-36.8789}).wait(1).to({graphics:mask_graphics_93,x:68.7466,y:-37.126}).wait(1).to({graphics:mask_graphics_94,x:69.3315,y:-37.406}).wait(1).to({graphics:mask_graphics_95,x:69.9852,y:-37.7189}).wait(1).to({graphics:mask_graphics_96,x:70.7077,y:-38.0648}).wait(1).to({graphics:mask_graphics_97,x:71.4991,y:-38.4436}).wait(1).to({graphics:mask_graphics_98,x:72.3592,y:-38.8554}).wait(1).to({graphics:mask_graphics_99,x:73.2882,y:-39.3001}).wait(1).to({graphics:mask_graphics_100,x:74.2859,y:-39.7777}).wait(1).to({graphics:mask_graphics_101,x:75.3525,y:-40.2883}).wait(1).to({graphics:mask_graphics_102,x:76.4879,y:-40.8318}).wait(1).to({graphics:mask_graphics_103,x:77.6921,y:-41.4082}).wait(1).to({graphics:mask_graphics_104,x:78.9652,y:-42.0176}).wait(1).to({graphics:mask_graphics_105,x:80.307,y:-42.66}).wait(1).to({graphics:mask_graphics_106,x:81.7176,y:-43.3353}).wait(1).to({graphics:mask_graphics_107,x:83.1799,y:-44.0352}).wait(1).to({graphics:mask_graphics_108,x:84.5905,y:-44.7105}).wait(1).to({graphics:mask_graphics_109,x:85.9324,y:-45.3529}).wait(1).to({graphics:mask_graphics_110,x:87.2054,y:-45.9623}).wait(1).to({graphics:mask_graphics_111,x:88.4096,y:-46.5387}).wait(1).to({graphics:mask_graphics_112,x:89.545,y:-47.0822}).wait(1).to({graphics:mask_graphics_113,x:90.6116,y:-47.5928}).wait(1).to({graphics:mask_graphics_114,x:91.6094,y:-48.0704}).wait(1).to({graphics:mask_graphics_115,x:92.5383,y:-48.5151}).wait(1).to({graphics:mask_graphics_116,x:93.3985,y:-48.9269}).wait(1).to({graphics:mask_graphics_117,x:94.1898,y:-49.3057}).wait(1).to({graphics:mask_graphics_118,x:94.9123,y:-49.6516}).wait(1).to({graphics:mask_graphics_119,x:95.5661,y:-49.9645}).wait(1).to({graphics:mask_graphics_120,x:96.151,y:-50.2445}).wait(1).to({graphics:mask_graphics_121,x:96.6671,y:-50.4916}).wait(1).to({graphics:mask_graphics_122,x:97.1143,y:-50.7057}).wait(1).to({graphics:mask_graphics_123,x:97.4928,y:-50.8869}).wait(1).to({graphics:mask_graphics_124,x:97.8025,y:-51.0351}).wait(1).to({graphics:mask_graphics_125,x:98.0433,y:-51.1504}).wait(1).to({graphics:mask_graphics_126,x:98.2153,y:-51.2327}).wait(1).to({graphics:mask_graphics_127,x:98.3185,y:-51.2821}).wait(1).to({graphics:mask_graphics_128,x:98.6916,y:-51.5173}).wait(5));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFF001").ss(4.5,1,1).p("AuGHUIJKmAIHoh3ILbmw");
	this.shape.setTransform(97.25,-52.15);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(133));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(4.8,-105.9,527.3000000000001,206.8);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Untitled3();
	this.instance.setTransform(-757.05,-468.15);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// rock_3_txt
	this.rock_3_txt = new lib.Mountain_rock_3_txt();
	this.rock_3_txt.name = "rock_3_txt";
	this.rock_3_txt.setTransform(286.05,143.45,1.63,1.63,0,0,0,175.5,88);

	this.timeline.addTween(cjs.Tween.get(this.rock_3_txt).wait(1));

	// rock_2
	this.rock_2 = new lib.Mountain_rock_2();
	this.rock_2.name = "rock_2";
	this.rock_2.setTransform(267.3,108.4,1.63,1.63,0,0,0,164,66.5);

	this.timeline.addTween(cjs.Tween.get(this.rock_2).wait(1));

	// rock_3_img
	this.rock_3 = new lib.Mountain_rock_3();
	this.rock_3.name = "rock_3";
	this.rock_3.setTransform(286.05,143.45,1.63,1.63,0,0,0,175.5,88);

	this.timeline.addTween(cjs.Tween.get(this.rock_3).wait(1));

	// rock_4
	this.rock_4 = new lib.Mountain_rock_4();
	this.rock_4.name = "rock_4";
	this.rock_4.setTransform(-45.95,64.6,1.63,1.63,0,0,0,-28.2,38.4);

	this.timeline.addTween(cjs.Tween.get(this.rock_4).wait(1));

	// cloud_2
	this.cloud_2 = new lib.Mountain_cloud_2();
	this.cloud_2.name = "cloud_2";
	this.cloud_2.setTransform(90.05,-142.4,1.63,1.63,0,0,0,163,45.5);

	this.timeline.addTween(cjs.Tween.get(this.cloud_2).wait(1));

	// cloud_1
	this.cloud_1 = new lib.Mountain_Cloud_1();
	this.cloud_1.name = "cloud_1";
	this.cloud_1.setTransform(149.3,-159.5,1.63,1.63,0,0,0,147.5,36);

	this.timeline.addTween(cjs.Tween.get(this.cloud_1).wait(1));

	// bg
	this.bg = new lib.Mountain_BG();
	this.bg.name = "bg";
	this.bg.setTransform(-32.1,-114.9,1.63,1.63,0,0,0,-19.7,-70.5);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(-757,-468.1,1157,559), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		exportRoot.tl1.play();
		exportRoot.tlbg.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(24).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(990.5,76.45,0.3376,0.3376,0,0,0,-39.9,1.7);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.5854,scaleY:5.5854,x:990.45,y:76.4},13,cjs.Ease.quadOut).to({x:679.9},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AeJKrIAAy1MBn5AAAIAAS1g");
	var mask_graphics_15 = new cjs.Graphics().p("Ad0KrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_16 = new cjs.Graphics().p("AczKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_17 = new cjs.Graphics().p("AbHKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_18 = new cjs.Graphics().p("AYwKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_19 = new cjs.Graphics().p("AVuKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_20 = new cjs.Graphics().p("ASBKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_21 = new cjs.Graphics().p("AOTKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_22 = new cjs.Graphics().p("ALRKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_23 = new cjs.Graphics().p("AI6KrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_24 = new cjs.Graphics().p("AHOKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_25 = new cjs.Graphics().p("AGNKrIAAy1MBn4AAAIAAS1g");
	var mask_graphics_26 = new cjs.Graphics().p("AF3KrIAAy1MBn5AAAIAAS1g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:857.7513,y:68.2537}).wait(1).to({graphics:mask_graphics_15,x:855.5934,y:68.2537}).wait(1).to({graphics:mask_graphics_16,x:849.1197,y:68.2537}).wait(1).to({graphics:mask_graphics_17,x:838.3302,y:68.2537}).wait(1).to({graphics:mask_graphics_18,x:823.2249,y:68.2537}).wait(1).to({graphics:mask_graphics_19,x:803.8038,y:68.2537}).wait(1).to({graphics:mask_graphics_20,x:780.0669,y:68.2537}).wait(1).to({graphics:mask_graphics_21,x:756.33,y:68.2537}).wait(1).to({graphics:mask_graphics_22,x:736.9088,y:68.2537}).wait(1).to({graphics:mask_graphics_23,x:721.8035,y:68.2537}).wait(1).to({graphics:mask_graphics_24,x:711.014,y:68.2537}).wait(1).to({graphics:mask_graphics_25,x:704.5403,y:68.2537}).wait(1).to({graphics:mask_graphics_26,x:702.3513,y:68.2537}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(502.65,69.7,5.5854,5.5854,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:903.95},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_51 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_52 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_53 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_54 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_55 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_56 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_57 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_58 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_59 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_60 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_61 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_62 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_63 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_65 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_66 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_67 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_68 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_69 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_71 = new cjs.Graphics().p("Ei5xAXgMAAAgu/MFzjAAAMAAAAu/g");
	var mask_1_graphics_72 = new cjs.Graphics().p("EjJxAXgMAAAgu/MFzjAAAMAAAAu/g");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:987.99,y:82.9417}).wait(51).to({graphics:mask_1_graphics_51,x:987.99,y:82.9417}).wait(1).to({graphics:mask_1_graphics_52,x:982.5888,y:82.9417}).wait(1).to({graphics:mask_1_graphics_53,x:966.3851,y:82.9417}).wait(1).to({graphics:mask_1_graphics_54,x:939.3789,y:82.9417}).wait(1).to({graphics:mask_1_graphics_55,x:901.5703,y:82.9417}).wait(1).to({graphics:mask_1_graphics_56,x:852.9591,y:82.9417}).wait(1).to({graphics:mask_1_graphics_57,x:793.5455,y:82.9417}).wait(1).to({graphics:mask_1_graphics_58,x:723.3295,y:82.9417}).wait(1).to({graphics:mask_1_graphics_59,x:642.3109,y:82.9417}).wait(1).to({graphics:mask_1_graphics_60,x:550.4899,y:82.9417}).wait(1).to({graphics:mask_1_graphics_61,x:447.8665,y:82.9417}).wait(1).to({graphics:mask_1_graphics_62,x:334.4405,y:82.9417}).wait(1).to({graphics:mask_1_graphics_63,x:210.2121,y:82.9417}).wait(1).to({graphics:mask_1_graphics_64,x:75.1812,y:82.9417}).wait(1).to({graphics:mask_1_graphics_65,x:-70.6522,y:82.9417}).wait(1).to({graphics:mask_1_graphics_66,x:-227.288,y:82.9417}).wait(1).to({graphics:mask_1_graphics_67,x:-394.7263,y:82.9417}).wait(1).to({graphics:mask_1_graphics_68,x:-572.9671,y:82.9417}).wait(1).to({graphics:mask_1_graphics_69,x:-762.0103,y:82.9417}).wait(1).to({graphics:mask_1_graphics_70,x:-961.856,y:82.9417}).wait(1).to({graphics:mask_1_graphics_71,x:-1172.5042,y:82.9417}).wait(1).to({graphics:mask_1_graphics_72,x:-1291.35,y:82.9417}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(903.95,69.7,5.5854,5.5854,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(987.8,290.4,2.4491,0.8798,0,0,0,485.4,406.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({regY:406.9,scaleY:0.8724,y:287.5},0).to({x:-1393.9},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(987.8,290.4,2.4491,0.8798,0,0,0,485.4,406.8);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({regY:406.9,scaleY:0.8725,y:287.55},0).wait(2).to({regY:406.8,scaleY:0.8798,x:-1393.9,y:290.4},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2582.7,-67.5,4759.7,300.9);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(3,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("ArTCeIAAk7IWnAAIAAE7g");
	this.shape.setTransform(-40.0209,-1.4265,0.8896,1.0378);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-104.4,-17.8,128.8,32.8), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(712.85,3.35,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(661.8,60.4,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(706.2,60.65,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(16.1,15.95,0.9726,0.9726,0,0,0,-52.5,-23.7);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A24HqIAAvTMAtxAAAIAAPTg");
	mask.setTransform(141.525,44.55);

	// people
	this.mountain = new lib.mountain_anim();
	this.mountain.name = "mountain";
	this.mountain.setTransform(251.55,109.2,0.4519,0.4519,0,0,0,284.3,24.8);

	var maskedShapeInstanceList = [this.mountain];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.mountain).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-4.9,-4.4,734.9,98), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "moun") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillMountain(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillMountain = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.mountain.rock_3_txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		
		//mc.txtCta.alpha=0
		//mc.cta.alpha=0
		//mc.replay_btn.alpha=0
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
		
			this.tl1 = new TimelineLite();
				
				exportRoot.tl1.from(mc.logo_1, 0.7, { x: "+=200",	ease:Power4.easeOut}, "+=0");
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "+=2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { x: "+=200",	ease:Power4.easeOut}, "-=0.6");
				exportRoot.tl1.from(mc.cta, 0.7, { x: "+=200", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.2");	
		
				exportRoot.tl1.stop();
				
				this.tlbg = new TimelineLite();
					
				exportRoot.tlbg.from(mc.mountain.bg, 5, { x: "+=40",	ease:Power4.easeOut}, "-=0");
				//exportRoot.tlbg.from(mc.mountain.rock_1, 5, { x: "+=340",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_2, 5, { x: "+=260",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_3, 5, { x: "+=180",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_3_txt, 5, { x: "+=180",	ease:Power4.easeOut, onStart:function(){mc.mountain.rock_3_txt.play();}}, "-=5");
				exportRoot.tlbg.from(mc.mountain.rock_4, 5, { x: "+=160",	ease:Power4.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.cloud_1, 14, { x: "+=200",	ease:Power2.easeOut}, "-=5");
				exportRoot.tlbg.from(mc.mountain.cloud_2, 14, { x: "+=120",	ease:Power2.easeOut}, "-=14");
				
				exportRoot.tlbg.stop();
				
				this.tl2 = new TimelineLite();
				
					for (var i = 0; i < exportRoot.mountainText1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText1[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=3.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText1[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
						for (var i = 0; i < exportRoot.mountainText2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText2[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=2.35");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText2[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
								for (var i = 0; i < exportRoot.mountainText3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.mountainText3[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=1.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.mountainText3[i], 0.8, { y: "+=20", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				exportRoot.tl2.stop();
				
				
			mc.logo_intro.gotoAndPlay(1)
				
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(144.9,-68.5,585.1,207.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1583766592698", id:"O365_FY20Q4_Cons_USA_728x90_BAN_Hero_Achieve_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;