(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[603,0,302,192],[0,0,299,213],[0,368,74,126],[301,202,158,129],[701,387,107,56],[102,215,131,104],[326,420,84,53],[235,411,89,65],[601,465,51,43],[235,333,156,76],[547,465,52,43],[158,427,75,50],[810,412,122,39],[654,465,52,41],[412,420,76,52],[849,453,53,43],[235,215,47,69],[490,420,55,55],[76,427,80,48],[887,306,131,104],[547,453,300,10],[907,0,100,151],[563,202,30,52],[563,256,31,48],[563,306,31,46],[708,465,31,45],[741,465,30,44],[773,465,30,43],[805,465,30,43],[907,153,100,151],[461,202,100,151],[0,215,100,151],[235,286,56,45],[301,0,300,200],[934,412,85,53],[603,194,282,191],[393,355,152,63],[547,387,152,61],[102,321,131,104]]}
];


// symbols:



(lib.basicUIhalf = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bg_img_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.bodyResize_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.chart_big_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.chart_sml_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Excel_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.girllefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Grass_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.guylefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.leafA_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.LeafB_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.percent_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.PPT_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Render0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Render0109sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Render0110sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Render0111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Render0112sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Render0113sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Render0114sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Render0115sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Render0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Render0117 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Render0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.secondimagesml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Word_icon_sml_update = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.WordIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.iconcache.cache(-260,-230,520,460,0.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Word_icon_sml_update();
	this.instance.setTransform(108,121,1.9,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(108,121,248.89999999999998,197.60000000000002), null);


(lib.whitebar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixGAIAAr/IFjAAIAAL/g");
	this.shape.setTransform(17.825,38.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebar, new cjs.Rectangle(0,0,35.7,76.8), null);


(lib.whitecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitecopy, new cjs.Rectangle(0,0,300,250), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AsGrUIYXAAIAAWdI4hAMg");
	this.shape.setTransform(-0.0003,-0.0264);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.5,-72.5,157.1,145);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.Topbar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape.setTransform(268.579,5.5001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#437F5B").s().p("AgJgEIATAAIgKAJg");
	this.shape_1.setTransform(72.0759,5.5001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUAbIgGgGIAAgwIA1AAIAAATIgCAAIAAgQIgGAAIAAAQIgCAAIAAgQIggAAIAAAXIANAAIgBABIgPAAIAAgYIgGAAIAAArIAFAGIAFAAIAAgQIAGAAIAAADIgEAAIAAANIAGAAIAAACg");
	this.shape_2.setTransform(46.425,6.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMABIAAAEIgCAAIAAgJIAJAAIAAADIgGAAQAEAFAHAAQAKAAADgJIACABQgDAKgMAAQgIAAgEgFg");
	this.shape_3.setTransform(47.6,8.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAGIACgGQAFgGAHAAQAHAAAGAGIAAgEIACAAIAAAJIgKAAIAAgDIAHAAQgFgFgHAAQgFAAgFAEIgCAGg");
	this.shape_4.setTransform(47.6,6.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAQIgOgOIgNAOIgCAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAOgOIgOgNIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAABIANANIAOgNIACAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgOANIAOAOQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_5.setTransform(442.325,5.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQARIAAgaIAHAAIAAgHIAaAAIAAAaIgHAAIAAAHgAgNAOIAVAAIAAgUIgVAAgAgHgJIARAAIAAAQIAEAAIAAgUIgVAAg");
	this.shape_6.setTransform(427.1,5.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.3).p("AgRAAIAjAA");
	this.shape_7.setTransform(411.95,5.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUARIAAghIApAAIAAAhgAABAOIASAAIAAgUIglAAIAAAUIASAAIAAgOIgGAEIgBgCIAHgHIAIAHIgBACIgGgEgAgSgJIAlAAIAAgEIglAAg");
	this.shape_8.setTransform(396.625,5.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIABIAAgBIARAAIAAABg");
	this.shape_9.setTransform(78.65,4.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_10.setTransform(78.675,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_11.setTransform(60.575,5.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#437F5B").s().p("AgQAFQgFgFABgHQABgHAFgFIABAAQAFgFAHAAQAHACAEAEIAJAKIAAgTIACAAIAAAYIgWAAIAAgDIASAAIgJgKQgDgEgGgBQgFAAgFADIgCABQgEAEgBAGQAAAHAEADIAUAXIgCABg");
	this.shape_12.setTransform(67.2167,6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAaIAUgXQAEgDAAgHQgBgFgFgFIgBgBQgFgDgFAAQgGABgDAEIgJAKIASAAIAAADIgWAAIAAgYIACAAIAAATIAJgKQAEgEAGgCQAHAAAGAFIABAAQAFAFABAHQAAAHgEAFIgUAWg");
	this.shape_13.setTransform(55.625,6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AglAaQgKAAgIgIQgIgHAAgLQAAgKAIgHQAIgIAKAAIBLAAQALAAAHAIQAIAHAAAKQAAALgIAHQgHAIgLAAgAAdgIQgEAEAAAEQAAAFAEAEQADADAGAAQAFAAADgDQADgEAAgFQAAgEgDgEQgDgDgFAAQgGAAgDADg");
	this.shape_14.setTransform(32.4,5.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#227347").s().p("EgjJAA3IAAhuMBGTAAAIAABug");
	this.shape_15.setTransform(225,5.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Topbar, new cjs.Rectangle(0,0,450,11.1), null);


(lib.top_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt13 = new cjs.Text("Comments", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 7;
	this.txt13.lineWidth = 23;
	this.txt13.parent = this;
	this.txt13.setTransform(416.2,18.75);

	this.txt13_1 = new cjs.Text("Share", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13_1.name = "txt13_1";
	this.txt13_1.lineHeight = 7;
	this.txt13_1.lineWidth = 15;
	this.txt13_1.parent = this;
	this.txt13_1.setTransform(390.7,15.7);

	this.txt13_2 = new cjs.Text("Search", "5px 'Segoe Pro'", "#474747");
	this.txt13_2.name = "txt13_2";
	this.txt13_2.lineHeight = 8;
	this.txt13_2.lineWidth = 15;
	this.txt13_2.parent = this;
	this.txt13_2.setTransform(208,15.55);

	this.txt12 = new cjs.Text("Help", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 15;
	this.txt12.parent = this;
	this.txt12.setTransform(181,18.55);

	this.txt11 = new cjs.Text("View", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 15;
	this.txt11.parent = this;
	this.txt11.setTransform(162.95,18.55);

	this.txt10 = new cjs.Text("Review", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 15;
	this.txt10.parent = this;
	this.txt10.setTransform(140.55,18.55);

	this.txt9 = new cjs.Text("Date", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 15;
	this.txt9.parent = this;
	this.txt9.setTransform(122.5,18.55);

	this.txt8 = new cjs.Text("Formulas", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 24;
	this.txt8.parent = this;
	this.txt8.setTransform(95.4,18.55);

	this.txt7 = new cjs.Text("Page Layout", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 33;
	this.txt7.parent = this;
	this.txt7.setTransform(62.2,18.55);

	this.txt6 = new cjs.Text("Insert", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 13;
	this.txt6.parent = this;
	this.txt6.setTransform(41.25,18.55);

	this.txt5 = new cjs.Text("Home", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 13;
	this.txt5.parent = this;
	this.txt5.setTransform(19.9,18.55);

	this.txt4 = new cjs.Text("File", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 8;
	this.txt4.parent = this;
	this.txt4.setTransform(2.3,18.55);

	this.txt3 = new cjs.Text("Daniella Duarte", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 30;
	this.txt3.parent = this;
	this.txt3.setTransform(355.05,7.2);

	this.txt2 = new cjs.Text("Family Budget - Saved to OneDrive", "5px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 105;
	this.txt2.parent = this;
	this.txt2.setTransform(185.3,6.5);

	this.txt1 = new cjs.Text("On", "3px 'Segoe Pro'", "#227347");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 6;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(24.15,6.6);

	this.txt = new cjs.Text("AutoSave", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 7;
	this.txt.lineWidth = 19;
	this.txt.parent = this;
	this.txt.setTransform(2,6.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13_2},{t:this.txt13_1},{t:this.txt13}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_text, new cjs.Rectangle(0,4.5,441.2,22.3), null);


(lib.titleshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.textanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#44724B").s().p("AhZB4ICOjaQgaAHgjAAIgIAAQAJAMAAAOQAAAUgOAQQgOAQgXAAQgWAAgOgPQgPgPAAgVQAAgOAHgMQAHgLAMgHQAMgHANAAQAFAAANADQATAEAVAAQAQAAAPgCQAPgCAXgHIARAAIicDvgAhRhXQgJAKAAANQAAAOAJAIQAKAKANAAQANAAAKgKQAJgIAAgOQAAgNgJgKQgKgKgNAAQgNAAgKAKgAAXBhQgPgQAAgUQAAgWAPgOQAPgPAVAAQAVAAAPAPQAPAOAAAWQAAAUgPAQQgPAPgVAAQgVAAgPgPgAAkAmQgJAJAAAOQAAANAJAJQAKAJANAAQANAAAKgJQAJgJAAgNQAAgOgJgJQgKgKgNAAQgNAAgKAKg");
	this.shape.setTransform(46.925,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAFgIQAGgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgcARQAQAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_1.setTransform(26.9,20.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#44724B").s().p("AhIBuIBRhZQAZgaAIgNQAHgNAAgOQAAgSgNgNQgOgNgUAAQgTAAgOAOQgOAOgCAZIgUAAQABggAUgVQAVgVAdABQAdAAATATQASATAAAaQAAATgJAQQgIAOgaAcIg0A6IBiAAIAAAUg");
	this.shape_2.setTransform(10.225,20.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_3.setTransform(26.925,20.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAdABATATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_4.setTransform(26.9,20.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_5.setTransform(27.3,20.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#44724B").s().p("AhABlIBji+IhmAAIAAgUICHAAIhyDbg");
	this.shape_6.setTransform(27.625,20.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#44724B").s().p("Ag1BdQgTgVAAgYQAAgSAKgPQAJgOAXgKQgQgJgHgMQgJgMAAgOQABgOAIgNQAIgOAPgHQAPgIAQAAQARAAAPAIQAOAHAIAOQAIANAAAPQAAAOgIAMQgHALgPAJQAVAJAJAOQAKAOAAASQAAAZgRATQgTAXglAAQgjAAgSgUgAgjAPQgPAOAAATQAAAMAGALQAHAKALAGQAMAGAOAAQAXAAAOgOQAPgOAAgTQAAgSgPgOQgPgOgVAAQgVAAgPAPgAgchRQgMALAAAOQAAAPANALQAMAMAQAAQAKAAAKgFQAJgGAGgJQAGgJAAgJQAAgNgLgLQgKgLgVAAQgRAAgLAKg");
	this.shape_7.setTransform(26.95,20.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#44724B").s().p("AgoBmIA5hYQgMADgJAAQgZAAgTgRQgSgTAAgbQABgSAIgPQAJgPAQgJQAQgJARAAQASAAAPAIQAPAJAIAQQAKAPgBASQAAANgFAPQgFAOgOAUIhBBhgAgfhOQgNANAAATQAAATANANQAOANARAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgRAAgOANg");
	this.shape_8.setTransform(26.75,20.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#44724B").s().p("AglBlQgRgMgJgXQgJgYAAgqQAAgqAJgXQAJgXARgMQAQgMAVAAQAUAAARAMQARAMAKAYQAJAYAAAoQAAApgJAYQgKAYgRAMQgRAMgUAAQgVAAgQgMgAgahSQgNAJgGATQgHATAAAkQAAAkAHATQAGASANAKQANAKANAAQAOAAANgKQAMgJAHgTQAIgXAAggQgBgggHgVQgHgVgMgJQgNgKgOAAQgNAAgNAKg");
	this.shape_9.setTransform(26.95,20.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAGgIQAFgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgbARQAPAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_10.setTransform(10.25,20.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#44724B").s().p("AAGBsIAAjCIghAAIANgVIAqAAIAADXg");
	this.shape_11.setTransform(25.675,20.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_12.setTransform(10.275,20.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAeABASATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_13.setTransform(10.25,20.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_14.setTransform(10.65,20.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},7).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_4},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_12},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_14},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},4).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,66.4,39.8);


(lib.text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlleftcontributionsml();
	this.instance.setTransform(0.1,-0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,-0.2,89.1,65.2), null);


(lib.text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.tablet_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,-4,0,4.6,-4,8.6).s().p("AgMASQgKgKgGgKQgEgHgCgIIgCgKIgBgIIAAgGIBLAAIAAABIAABSQgegCgUgWg");
	this.shape.setTransform(-10.0002,11.9003);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-3.6,18.3,4.7,18.3).s().p("AglCAIAAghIABAHIACAKQACAJAEAHgAglBYIAAjXIBLAAIAADXg");
	this.shape_1.setTransform(-10.0002,-1.1249);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,4.1,0,4.6,4.1,8.6).s().p("AglAqIAAgCIAAAAQABgiAYgXQAUgWAegCIAABSIAAABg");
	this.shape_2.setTransform(-10.0002,-18.1502);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,4.2,-18.2,-4.2).s().p("ABkAqIjgAAIgDAAIAAgBIAAhSID/AAIAAABIAAAAIAABSg");
	this.shape_3.setTransform(6.5751,12.0003);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,-4.1,0,-4,-4.1,8.6).s().p("AgoAqIgBAAIAAhSIAAAAIAAgBIABAAIBSAAIAAABIAAADQAAAhgYAVQgXAZgiAAg");
	this.shape_4.setTransform(23.6253,12.0003);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],4.3,21.6,-4.1,21.6).s().p("AApBwIAAAAIhSAAIAAjaIBSAAIAAgFIABAAIAADfg");
	this.shape_5.setTransform(23.7003,-3.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ACABtIkAAAIAAgBIAAjXIAAgBIEAAAIABAAIAADZg");
	this.shape_6.setTransform(6.6251,-3.1249);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,-4.1,-18.2,4.3).s().p("Ah/AqIAAhSIAAgBIADAAIDgAAIAcAAIAABSIAAABg");
	this.shape_7.setTransform(6.5751,-18.2502);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,4.2,0,-4,4.2,8.6).s().p("AgoAqIgBAAIAAgBIAAhSIABAAIABAAQAiAAAXAYQAXAWABAfIAAAGg");
	this.shape_8.setTransform(23.6253,-18.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,5,1.1,-5).s().p("AkLAyIAAAAIABAAIABAAIACAAIAAgCIAAhhIGwAAIBjAAIAABhIAAACIgCAAIAAAAIAAAAg");
	this.shape_9.setTransform(36.375,89.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,-4.8,0,4.9,-4.8,10.2).s().p("AAwAyIgBAAIgCAAQgngBgagcQgdgbAAgoIAAgDIBhAAIACAAIAAABIAABhIAAABg");
	this.shape_10.setTransform(5,89.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-4.9,0.1,5.1,0.1).s().p("AAwFyIhhAAIAArjIBhAAIACAAIAALjg");
	this.shape_11.setTransform(5,47.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,4.8,0,4.9,4.8,10.2).s().p("AAwAzIhhAAIAAgCIAAgBQAAgpAdgbQAagcAngBIACAAIABAAIACAAIAABiIAAACg");
	this.shape_12.setTransform(5,5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,-5,1.1,5).s().p("ACpAyImwAAIAAhiIgCAAIgBAAIgBAAIAAgBIIVAAIAAABIAAAAIACAAIAABig");
	this.shape_13.setTransform(36.375,5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,5,0,-5).s().p("AECAyIoVAAIgDAAIAAAAIAAAAIACAAIAAgCIAAhhIAWAAIB8AAIEgAAIB3AAIAABhIAAACIABAAIABAAIAAAAg");
	this.shape_14.setTransform(90.875,89.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,-4.8,0,-4.8,-4.8,10.2).s().p("AgwAyIgBAAIAAgBIAAhhIAAgBIACAAIBhAAIAAADQgBAogdAbQgaAdgpAAIgBAAg");
	this.shape_15.setTransform(123.6,89.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,-5,0,5).s().p("ACeAyIkgAAIh8AAIgWAAIAAhiIgCAAIAAAAIAAgBIItAAIAAABIgBAAIgBAAIAABig");
	this.shape_16.setTransform(90.875,5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AGoFzIkhAAIh9AAIgUAAIhjAAImxAAIAAgBIAArjIAAgBIGxAAIBjAAIAUAAIB9AAIEhAAIB3AAIAAABIAALjIAAABg");
	this.shape_17.setTransform(64.3,47.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],5,0.1,-5,0.1).s().p("AgvFyIgCAAIAArjIACAAIBhAAIAALjg");
	this.shape_18.setTransform(123.6,47.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,4.8,0,-4.8,4.8,10.2).s().p("AgvAzIgCAAIAAgCIAAhiIABAAIABAAQApAAAaAdQAdAbABApIAAABIAAACg");
	this.shape_19.setTransform(123.6,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_sub, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.small_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_sml_msml();
	this.instance.setTransform(198,132,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.small_pie, new cjs.Rectangle(0,0,420,420), null);


(lib.secondimage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.secondimagesml();
	this.instance.setTransform(-0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage, new cjs.Rectangle(-0.4,0,85,53.3), null);


(lib.screenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.basicUIhalf();
	this.instance.setTransform(-0.35,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.rowsandcells = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//columns
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		
		//rows
		this.txt01.textBaseline = "alphabetic"
		this.txt02.textBaseline = "alphabetic"
		this.txt03.textBaseline = "alphabetic"
		this.txt04.textBaseline = "alphabetic"
		this.txt05.textBaseline = "alphabetic"
		this.txt06.textBaseline = "alphabetic"
		this.txt07.textBaseline = "alphabetic"
		this.txt08.textBaseline = "alphabetic"
		this.txt09.textBaseline = "alphabetic"
		this.txt010.textBaseline = "alphabetic"
		this.txt011.textBaseline = "alphabetic"
		this.txt012.textBaseline = "alphabetic"
		this.txt013.textBaseline = "alphabetic"
		this.txt014.textBaseline = "alphabetic"
		this.txt015.textBaseline = "alphabetic"
		this.txt016.textBaseline = "alphabetic"
		this.txt017.textBaseline = "alphabetic"
		this.txt018.textBaseline = "alphabetic"
		this.txt019.textBaseline = "alphabetic"
		this.txt020.textBaseline = "alphabetic"
		this.txt021.textBaseline = "alphabetic"
		this.txt022.textBaseline = "alphabetic"
		this.txt023.textBaseline = "alphabetic"
		this.txt024.textBaseline = "alphabetic"
		this.txt025.textBaseline = "alphabetic"
		this.txt026.textBaseline = "alphabetic"
		this.txt027.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt027 = new cjs.Text("27", "5px 'Segoe Pro'", "#474747");
	this.txt027.name = "txt027";
	this.txt027.lineHeight = 8;
	this.txt027.lineWidth = 6;
	this.txt027.parent = this;
	this.txt027.setTransform(-11,241.15);

	this.txt026 = new cjs.Text("26", "5px 'Segoe Pro'", "#474747");
	this.txt026.name = "txt026";
	this.txt026.lineHeight = 8;
	this.txt026.lineWidth = 6;
	this.txt026.parent = this;
	this.txt026.setTransform(-11,232.95);

	this.txt025 = new cjs.Text("25", "5px 'Segoe Pro'", "#474747");
	this.txt025.name = "txt025";
	this.txt025.lineHeight = 8;
	this.txt025.lineWidth = 6;
	this.txt025.parent = this;
	this.txt025.setTransform(-11,224.65);

	this.txt024 = new cjs.Text("24", "5px 'Segoe Pro'", "#474747");
	this.txt024.name = "txt024";
	this.txt024.lineHeight = 8;
	this.txt024.lineWidth = 6;
	this.txt024.parent = this;
	this.txt024.setTransform(-11,216.35);

	this.txt023 = new cjs.Text("23", "5px 'Segoe Pro'", "#474747");
	this.txt023.name = "txt023";
	this.txt023.lineHeight = 8;
	this.txt023.lineWidth = 6;
	this.txt023.parent = this;
	this.txt023.setTransform(-11,208.2);

	this.txt022 = new cjs.Text("22", "5px 'Segoe Pro'", "#474747");
	this.txt022.name = "txt022";
	this.txt022.lineHeight = 8;
	this.txt022.lineWidth = 6;
	this.txt022.parent = this;
	this.txt022.setTransform(-11,200);

	this.txt021 = new cjs.Text("21", "5px 'Segoe Pro'", "#474747");
	this.txt021.name = "txt021";
	this.txt021.lineHeight = 8;
	this.txt021.lineWidth = 6;
	this.txt021.parent = this;
	this.txt021.setTransform(-11,191.7);

	this.txt020 = new cjs.Text("20", "5px 'Segoe Pro'", "#474747");
	this.txt020.name = "txt020";
	this.txt020.lineHeight = 8;
	this.txt020.lineWidth = 6;
	this.txt020.parent = this;
	this.txt020.setTransform(-11,183.35);

	this.txt019 = new cjs.Text("19", "5px 'Segoe Pro'", "#474747");
	this.txt019.name = "txt019";
	this.txt019.lineHeight = 8;
	this.txt019.lineWidth = 6;
	this.txt019.parent = this;
	this.txt019.setTransform(-10.5,175.1);

	this.txt018 = new cjs.Text("18", "5px 'Segoe Pro'", "#474747");
	this.txt018.name = "txt018";
	this.txt018.lineHeight = 8;
	this.txt018.lineWidth = 6;
	this.txt018.parent = this;
	this.txt018.setTransform(-10.5,166.9);

	this.txt017 = new cjs.Text("17", "5px 'Segoe Pro'", "#474747");
	this.txt017.name = "txt017";
	this.txt017.lineHeight = 8;
	this.txt017.lineWidth = 6;
	this.txt017.parent = this;
	this.txt017.setTransform(-10.5,158.7);

	this.txt016 = new cjs.Text("16", "5px 'Segoe Pro'", "#474747");
	this.txt016.name = "txt016";
	this.txt016.lineHeight = 8;
	this.txt016.lineWidth = 6;
	this.txt016.parent = this;
	this.txt016.setTransform(-10.5,150.45);

	this.txt015 = new cjs.Text("15", "5px 'Segoe Pro'", "#474747");
	this.txt015.name = "txt015";
	this.txt015.lineHeight = 8;
	this.txt015.lineWidth = 6;
	this.txt015.parent = this;
	this.txt015.setTransform(-10.5,142.15);

	this.txt014 = new cjs.Text("14", "5px 'Segoe Pro'", "#474747");
	this.txt014.name = "txt014";
	this.txt014.lineHeight = 8;
	this.txt014.lineWidth = 6;
	this.txt014.parent = this;
	this.txt014.setTransform(-10.5,133.85);

	this.txt013 = new cjs.Text("13", "5px 'Segoe Pro'", "#474747");
	this.txt013.name = "txt013";
	this.txt013.lineHeight = 8;
	this.txt013.lineWidth = 6;
	this.txt013.parent = this;
	this.txt013.setTransform(-10.5,125.8);

	this.txt012 = new cjs.Text("12", "5px 'Segoe Pro'", "#474747");
	this.txt012.name = "txt012";
	this.txt012.lineHeight = 8;
	this.txt012.lineWidth = 6;
	this.txt012.parent = this;
	this.txt012.setTransform(-10.5,117.5);

	this.txt011 = new cjs.Text("11", "5px 'Segoe Pro'", "#474747");
	this.txt011.name = "txt011";
	this.txt011.lineHeight = 8;
	this.txt011.lineWidth = 6;
	this.txt011.parent = this;
	this.txt011.setTransform(-10.5,109.3);

	this.txt010 = new cjs.Text("10", "5px 'Segoe Pro'", "#474747");
	this.txt010.name = "txt010";
	this.txt010.lineHeight = 8;
	this.txt010.lineWidth = 6;
	this.txt010.parent = this;
	this.txt010.setTransform(-10.5,101.05);

	this.txt09 = new cjs.Text("9", "5px 'Segoe Pro'", "#474747");
	this.txt09.name = "txt09";
	this.txt09.lineHeight = 8;
	this.txt09.lineWidth = 6;
	this.txt09.parent = this;
	this.txt09.setTransform(-9.7,92.8);

	this.txt08 = new cjs.Text("8", "5px 'Segoe Pro'", "#474747");
	this.txt08.name = "txt08";
	this.txt08.lineHeight = 8;
	this.txt08.lineWidth = 6;
	this.txt08.parent = this;
	this.txt08.setTransform(-9.7,84.6);

	this.txt07 = new cjs.Text("7", "5px 'Segoe Pro'", "#474747");
	this.txt07.name = "txt07";
	this.txt07.lineHeight = 8;
	this.txt07.lineWidth = 6;
	this.txt07.parent = this;
	this.txt07.setTransform(-9.7,76.35);

	this.txt06 = new cjs.Text("6", "5px 'Segoe Pro'", "#474747");
	this.txt06.name = "txt06";
	this.txt06.lineHeight = 8;
	this.txt06.lineWidth = 6;
	this.txt06.parent = this;
	this.txt06.setTransform(-9.7,68.1);

	this.txt05 = new cjs.Text("5", "5px 'Segoe Pro'", "#474747");
	this.txt05.name = "txt05";
	this.txt05.lineHeight = 8;
	this.txt05.lineWidth = 6;
	this.txt05.parent = this;
	this.txt05.setTransform(-9.7,59.85);

	this.txt04 = new cjs.Text("4", "5px 'Segoe Pro'", "#474747");
	this.txt04.name = "txt04";
	this.txt04.lineHeight = 8;
	this.txt04.lineWidth = 6;
	this.txt04.parent = this;
	this.txt04.setTransform(-9.7,51.6);

	this.txt03 = new cjs.Text("3", "5px 'Segoe Pro'", "#474747");
	this.txt03.name = "txt03";
	this.txt03.lineHeight = 8;
	this.txt03.lineWidth = 6;
	this.txt03.parent = this;
	this.txt03.setTransform(-9.7,43.25);

	this.txt02 = new cjs.Text("2", "5px 'Segoe Pro'", "#474747");
	this.txt02.name = "txt02";
	this.txt02.lineHeight = 8;
	this.txt02.lineWidth = 6;
	this.txt02.parent = this;
	this.txt02.setTransform(-9.7,35.1);

	this.txt01 = new cjs.Text("1", "5px 'Segoe Pro'", "#474747");
	this.txt01.name = "txt01";
	this.txt01.lineHeight = 8;
	this.txt01.lineWidth = 6;
	this.txt01.parent = this;
	this.txt01.setTransform(-9.35,26.7);

	this.txt16 = new cjs.Text("Q", "5px 'Segoe Pro'", "#474747");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 8;
	this.txt16.lineWidth = 6;
	this.txt16.parent = this;
	this.txt16.setTransform(401.15,18.5);

	this.txt15 = new cjs.Text("P", "5px 'Segoe Pro'", "#474747");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 8;
	this.txt15.lineWidth = 6;
	this.txt15.parent = this;
	this.txt15.setTransform(376.95,18.5);

	this.txt14 = new cjs.Text("O", "5px 'Segoe Pro'", "#474747");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 8;
	this.txt14.lineWidth = 6;
	this.txt14.parent = this;
	this.txt14.setTransform(351.85,18.5);

	this.txt13 = new cjs.Text("N", "5px 'Segoe Pro'", "#474747");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 8;
	this.txt13.lineWidth = 6;
	this.txt13.parent = this;
	this.txt13.setTransform(327.05,18.5);

	this.txt12 = new cjs.Text("M", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 6;
	this.txt12.parent = this;
	this.txt12.setTransform(302,18.5);

	this.txt11 = new cjs.Text("L", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 6;
	this.txt11.parent = this;
	this.txt11.setTransform(278.35,18.5);

	this.txt10 = new cjs.Text("K", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 6;
	this.txt10.parent = this;
	this.txt10.setTransform(253.35,18.5);

	this.txt9 = new cjs.Text("J", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 6;
	this.txt9.parent = this;
	this.txt9.setTransform(229.05,18.5);

	this.txt8 = new cjs.Text("I", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 6;
	this.txt8.parent = this;
	this.txt8.setTransform(204.65,18.5);

	this.txt7 = new cjs.Text("H", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 6;
	this.txt7.parent = this;
	this.txt7.setTransform(178.85,18.5);

	this.txt6 = new cjs.Text("G", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 6;
	this.txt6.parent = this;
	this.txt6.setTransform(154.5,18.5);

	this.txt5 = new cjs.Text("F", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 6;
	this.txt5.parent = this;
	this.txt5.setTransform(130.3,18.5);

	this.txt4 = new cjs.Text("E", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 6;
	this.txt4.parent = this;
	this.txt4.setTransform(105.5,18.5);

	this.txt3 = new cjs.Text("D", "5px 'Segoe Pro'", "#474747");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 8;
	this.txt3.lineWidth = 6;
	this.txt3.parent = this;
	this.txt3.setTransform(80.45,18.5);

	this.txt2 = new cjs.Text("C", "5px 'Segoe Pro'", "#474747");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(55.95,18.5);

	this.txt1 = new cjs.Text("B", "5px 'Segoe Pro'", "#474747");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 8;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(31.3,18.5);

	this.txt = new cjs.Text("A", "5px 'Segoe Pro'", "#474747");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(6.4,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt01},{t:this.txt02},{t:this.txt03},{t:this.txt04},{t:this.txt05},{t:this.txt06},{t:this.txt07},{t:this.txt08},{t:this.txt09},{t:this.txt010},{t:this.txt011},{t:this.txt012},{t:this.txt013},{t:this.txt014},{t:this.txt015},{t:this.txt016},{t:this.txt017},{t:this.txt018},{t:this.txt019},{t:this.txt020},{t:this.txt021},{t:this.txt022},{t:this.txt023},{t:this.txt024},{t:this.txt025},{t:this.txt026},{t:this.txt027}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rowsandcells, new cjs.Rectangle(-13,16.5,422.2,232.7), null);


(lib.roundshadowshape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.roundshadow1sml();
	this.instance.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45.3), null);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bodyResize_sml();
	this.instance.setTransform(8,4,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(0,0,114,181), null);


(lib.percantage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.percent_msml();
	this.instance.setTransform(194,187,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.percantage, new cjs.Rectangle(0,0,420,420), null);


(lib.Page_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(242,242,242,0)","#F2F2F2"],[0,0.282],-213,0,213,0).s().p("EghRATiMAAAgnDMBCjAAAMAAAAnDg");
	this.shape.setTransform(87.05,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_bg, new cjs.Rectangle(-125.9,0,649.6999999999999,250), null);


(lib.option_hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.2)").s().p("A4SC+IAAl7MAwlAAAIAAF7g");
	this.shape.setTransform(155.5,19);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("A4SC+IAAl7MAwlAAAIAAF7g");
	this.shape_1.setTransform(155.5,19);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,311,38);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAIAqIAhgfIh3AAIAAgUIB3AAIghggIAbAAIAsApIgsAqg");
	this.shape.setTransform(-2.1,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-10,-4.1,15.8,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(172.2024,63.4258);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(172.2024,63.4258);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],20.7,54.8,0,20.7,54.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(172.2024,71.5759);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(0,0,344.4,135), null);


(lib.main_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
		this.txt20.textBaseline = "alphabetic"
		this.txt21.textBaseline = "alphabetic"
		this.txt22.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.txt22 = new cjs.Text("Expense", "7px 'Segoe Pro'", "#227347");
	this.txt22.name = "txt22";
	this.txt22.lineHeight = 11;
	this.txt22.lineWidth = 32;
	this.txt22.parent = this;
	this.txt22.setTransform(356.25,158);

	this.txt21 = new cjs.Text("Income", "7px 'Segoe Pro'", "#227347");
	this.txt21.name = "txt21";
	this.txt21.lineHeight = 11;
	this.txt21.lineWidth = 32;
	this.txt21.parent = this;
	this.txt21.setTransform(311.35,158);

	this.txt20 = new cjs.Text("$0", "6px 'Segoe Pro'", "#227347");
	this.txt20.name = "txt20";
	this.txt20.lineHeight = 10;
	this.txt20.lineWidth = 18;
	this.txt20.parent = this;
	this.txt20.setTransform(290,140.1);

	this.txt19 = new cjs.Text("$100", "6px 'Segoe Pro'", "#227347");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 10;
	this.txt19.lineWidth = 18;
	this.txt19.parent = this;
	this.txt19.setTransform(283.55,125.2);

	this.txt18 = new cjs.Text("$200", "6px 'Segoe Pro'", "#227347");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 10;
	this.txt18.lineWidth = 18;
	this.txt18.parent = this;
	this.txt18.setTransform(283.55,110.5);

	this.txt17 = new cjs.Text("$300", "6px 'Segoe Pro'", "#227347");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 10;
	this.txt17.lineWidth = 18;
	this.txt17.parent = this;
	this.txt17.setTransform(283.55,95.8);

	this.txt16 = new cjs.Text("$400", "6px 'Segoe Pro'", "#227347");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 10;
	this.txt16.lineWidth = 18;
	this.txt16.parent = this;
	this.txt16.setTransform(283.55,80.75);

	this.txt15 = new cjs.Text("$500", "6px 'Segoe Pro'", "#227347");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 10;
	this.txt15.lineWidth = 18;
	this.txt15.parent = this;
	this.txt15.setTransform(283.55,66.25);

	this.txt14 = new cjs.Text("$600", "6px 'Segoe Pro'", "#227347");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 10;
	this.txt14.lineWidth = 18;
	this.txt14.parent = this;
	this.txt14.setTransform(283.55,51.55);

	this.txt13 = new cjs.Text("$700", "6px 'Segoe Pro'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 10;
	this.txt13.lineWidth = 18;
	this.txt13.parent = this;
	this.txt13.setTransform(283.55,36.65);

	this.txt12 = new cjs.Text("$800", "6px 'Segoe Pro'", "#227347");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 10;
	this.txt12.lineWidth = 18;
	this.txt12.parent = this;
	this.txt12.setTransform(283.55,22.35);

	this.txt11 = new cjs.Text("$900", "6px 'Segoe Pro'", "#227347");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 10;
	this.txt11.lineWidth = 18;
	this.txt11.parent = this;
	this.txt11.setTransform(283.55,7.45);

	this.txt9 = new cjs.Text("Cash Balance", "7px 'Segoe Pro'", "#227347");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 11;
	this.txt9.lineWidth = 100;
	this.txt9.parent = this;
	this.txt9.setTransform(152.7,133.5);

	this.txt7 = new cjs.Text("Total monthly savings", "7px 'Segoe Pro'", "#227347");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 11;
	this.txt7.lineWidth = 100;
	this.txt7.parent = this;
	this.txt7.setTransform(152.7,98.7);

	this.txt5 = new cjs.Text("Total monthly expenses", "7px 'Segoe Pro'", "#227347");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 11;
	this.txt5.lineWidth = 100;
	this.txt5.parent = this;
	this.txt5.setTransform(152.7,64.1);

	this.txt10 = new cjs.Text("$130", "12px 'Segoe Pro'", "#227347");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 18;
	this.txt10.lineWidth = 100;
	this.txt10.parent = this;
	this.txt10.setTransform(152.7,150.1);

	this.txt8 = new cjs.Text("$100", "12px 'Segoe Pro'", "#227347");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 18;
	this.txt8.lineWidth = 100;
	this.txt8.parent = this;
	this.txt8.setTransform(152.7,115.5);

	this.txt6 = new cjs.Text("$670", "12px 'Segoe Pro'", "#227347");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 18;
	this.txt6.lineWidth = 100;
	this.txt6.parent = this;
	this.txt6.setTransform(152.7,80.65);

	this.txt4 = new cjs.Text("$900", "12px 'Segoe Pro'", "#227347");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 18;
	this.txt4.lineWidth = 100;
	this.txt4.parent = this;
	this.txt4.setTransform(152.7,45.85);

	this.txt3 = new cjs.Text("Total monthly income", "7px 'Segoe Pro'", "#227347");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 11;
	this.txt3.lineWidth = 100;
	this.txt3.parent = this;
	this.txt3.setTransform(152.7,29.3);

	this.txt2 = new cjs.Text("Summary", "8px 'Segoe Pro'", "#227347");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(152.7,11.2);

	this.txt1 = new cjs.Text("Percentage of income spent", "6px 'Segoe Pro'", "#B7B2A6");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 10;
	this.txt1.lineWidth = 100;
	this.txt1.parent = this;
	this.txt1.setTransform(2,26.4);

	this.txt = new cjs.Text("School Budget", "14px 'Segoe Pro'", "#227347");
	this.txt.name = "txt";
	this.txt.lineHeight = 20;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(2,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt6},{t:this.txt8},{t:this.txt10},{t:this.txt5},{t:this.txt7},{t:this.txt9},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt17},{t:this.txt18},{t:this.txt19},{t:this.txt20},{t:this.txt21},{t:this.txt22}]}).wait(1));

	// Graph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#49A166").s().p("AitJYIAAg5IA4AAIAAA5gAjBGUIAAvrIGDAAIAAPrg");
	this.shape.setTransform(365.3,97.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#337446").s().p("AjVMGIAAg4IA5AAIAAA4gAiqJCIAA1HIGAAAIAAFdIAAPqg");
	this.shape_1.setTransform(324.475,80.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E4DFD4").ss(0.3).p("ATPKLIqoABIkUAAIAAiFIAAyXAkvJ0IufAAAkvEOIufAAAkvhCIufAAAkvmfIufAA");
	this.shape_2.setTransform(271.7253,74.2752);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_txt, new cjs.Rectangle(0,3.1,395.9,166.4), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.LeafB_sml();
	this.instance.setTransform(0.15,0.55,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110.2,110.6), null);


(lib.leafA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA_sml();
	this.instance.setTransform(90.6,19.3,2.64,2.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA, new cjs.Rectangle(0,0,214.7,245.5), null);


(lib.Layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt = new cjs.Text("Budget", "5px 'Segoe Pro Semibold'", "#1C7347");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(39.3,248.65);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C7347").s().p("AiUAFIAAgIIEpAAIAAAIg");
	this.shape.setTransform(47.6,252.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.txt}]}).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#777777").s().p("AAAAFIgKgIIACgDIAIAJIAJgJIACADIgLAKg");
	this.shape_1.setTransform(445.4568,7.2001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C9C9C9").s().p("AgMAQQgEgBABgEIABgBIAGgIIAGgEIgJgGIAAgBQgDgCACgDQACgCADABIAIAKQAGgEAJgCIgNAJQAHAGAGAKQgFgFgLgJIgEAGIgEAHIAAABQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(50.8146,7.4594);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C9C9C9").s().p("AgNAVQAAAAgBgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIABABIABACIAAAAIACgCIACgDIAEgVIAAAAIgDAAIAAgBIAAgBIADAAIAAgBIABgDQACgEADgCIAFgDIADABIABACIgBACIgBAAIgCgBIgBgBIgBgBIgCABIgBAEIgBAFIgBABIAGAAIAAAAIgBACIgFAAIgEASQAAAEgCACIgEADIgEABg");
	this.shape_3.setTransform(74.0886,7.4251);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C9C9C9").s().p("AACAIIgCgBIAAgFIAAAAIgCAEIgCACIgDAAIgBgBQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAABAAIABAAIABAAIADgDIAAgBIABgBIgCgDIAAgBIgCgBIgBAAIgBAAIAAAAIABgBIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABABIABAFIAAAAIAAAAIACgDIACgCIACgBIACABIAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgDAEIAAAAIABAEIACACIABAAIACAAIAAABIgDABg");
	this.shape_4.setTransform(75.4618,8.0251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#C9C9C9").ss(0.5,1).p("AATgNQgSARgFAKQgBABgBgBIgMgM");
	this.shape_5.setTransform(63.0759,7.3251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAGAAIAAAFg");
	this.shape_6.setTransform(39.8006,8.7251);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAGAAIAAAGg");
	this.shape_7.setTransform(39.8006,7.4001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B3B3B3").s().p("AgDADIAAgGIAGAAIAAAGg");
	this.shape_8.setTransform(39.8006,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5F6060").s().p("AgNgGIAbAAIgOANg");
	this.shape_9.setTransform(31.3005,7.1001);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#C5C5C5").ss(0.3).p("AclAqMg5JAAAIAAhTMA5JAAAg");
	this.shape_10.setTransform(265.179,7.4251);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A8kAqIAAhTMA5JAAAIAABTg");
	this.shape_11.setTransform(265.179,7.4251);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C5C5C5").ss(0.3).p("ACzAqIllAAIAAhTIFlAAg");
	this.shape_12.setTransform(62.6509,7.4251);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiyAqIAAhTIFmAAIAABTg");
	this.shape_13.setTransform(62.6509,7.4251);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#C5C5C5").ss(0.3).p("ACnAqIlNAAIAAhTIFNAAg");
	this.shape_14.setTransform(18.0503,7.4251);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimAqIAAhTIFNAAIAABTg");
	this.shape_15.setTransform(18.0503,7.4251);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#787878").s().p("AgGAAIANgNIAAAbg");
	this.shape_16.setTransform(9.4,248.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#787878").s().p("AgGgNIANANIgNAOg");
	this.shape_17.setTransform(18.975,248.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#787878").s().p("AgCAOIAAgLIgLAAIAAgFIALAAIAAgLIAEAAIAAALIAMAAIAAAFIgMAAIAAALg");
	this.shape_18.setTransform(69.425,248.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#787878").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIgAgRgRQgHAIAAAJQAAAKAHAHQAIAIAJAAQAKAAAIgIQAHgHAAgKQAAgJgHgIQgIgHgKAAQgJAAgIAHg");
	this.shape_19.setTransform(69.425,248.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#999999").s().p("A9PSuIAAhUIlIAAIAAgDIBQAAIAAgNIhQAAIAAgDIBQAAIAAhVIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhOIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhCIADAAIAABCID2AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID0AAIAAhCIADAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIDyAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCIDzAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIB4AAMAAAAjEMg69AAAIAABUgEghEARXID3AAIAABUIElAAIAAhUMA6+AAAMAAAgi+MhDaAAAg");
	this.shape_20.setTransform(220.0284,133.1024);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B4B4B4").s().p("AgTAUIAngnIAAAng");
	this.shape_21.setTransform(5.125,16.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E6E6E6").s().p("EgjJAT0MAAAgnnMBGTAAAMAAAAnngEgh2ASYID2AAIAABUIEpAAIAAhUMA67AAAMAAAgjBMhDaAAAg");
	this.shape_22.setTransform(225,126.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Layout, new cjs.Rectangle(0,0,450,259.3), null);


(lib.image01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrightcontributionsml();
	this.instance.setTransform(-0.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel_icon_sml();
	this.instance.setTransform(16.5,28.85,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0,0,129.6,125.7), null);


(lib.hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.grass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Grass_sml();
	this.instance.setTransform(371.2,0.5,2.5,2.4999,0,0,180);

	this.instance_1 = new lib.Grass_sml();
	this.instance_1.setTransform(0.7,0.55,2.4999,2.4999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass, new cjs.Rectangle(0,0,372.1,126), null);


(lib.graphGreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#459F69").s().p("AmYGZQiqipAAjwQAAjuCqiqQCpiqDvAAQDvAACqCqQCqCqAADuQAADwiqCpIAAABQiqCpjvAAQjvAAipiqgAmiAAQAACuB7B6QB6B7CtAAQCtAAB7h7QB7h6AAiuQAAish7h7Qh7h7itAAQitAAh6B7IAAAAQh7B7AACsg");
	this.shape.setTransform(57.875,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphGreen, new cjs.Rectangle(0,0,115.8,115.8), null);


(lib.firstimage_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(-1.05,-0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(-1,-0.9,84,53), null);


(lib.fill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlrighticonsml();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girllefticonsml();
	this.instance.setTransform(-0.15,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(-0.1,-0.2,51.1,43.2), null);


(lib.face02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guylefticonsml();
	this.instance.setTransform(0.1,0.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52.1,41.1), null);


(lib.face01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrighticon1sml();
	this.instance.setTransform(-0.05,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,-0.1,53,43.1), null);


(lib.excel_screen_white_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjMASVMAAAgkpMBGZAAAMAAAAkpg");
	this.shape.setTransform(225.25,141.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white_sub, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.ribboncopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_75 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(75).call(this.frame_75).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_52 = new cjs.Graphics().p("AAWIAICQgyIC3ISIiQAyg");
	var mask_graphics_53 = new cjs.Graphics().p("AiWIAIHqipIC2ISInrCog");
	var mask_graphics_54 = new cjs.Graphics().p("Ak1IAIMnkWIC3ISIsnEVg");
	var mask_graphics_55 = new cjs.Graphics().p("AnFIAIRIl5IC2IRIxHF5g");
	var mask_graphics_56 = new cjs.Graphics().p("ApHIAIVMnTIC2ISI1MHSg");
	var mask_graphics_57 = new cjs.Graphics().p("Aq8IAIY2ojIC3IRI43Ijg");
	var mask_graphics_58 = new cjs.Graphics().p("AslIAIcIprIC3IRI8JJrg");
	var mask_graphics_59 = new cjs.Graphics().p("AuDIAIfEqrIC2IQI/EKsg");
	var mask_graphics_60 = new cjs.Graphics().p("AvVIAMAhogLkIC3IRMghpALkg");
	var mask_graphics_61 = new cjs.Graphics().p("AwdIAMAj4gMVIC3IQMgj5AMWg");
	var mask_graphics_62 = new cjs.Graphics().p("AxcIAMAl2gNAIC2IQMgl2ANBg");
	var mask_graphics_63 = new cjs.Graphics().p("AyRIAMAnggNlIC3IQMgnhANmg");
	var mask_graphics_64 = new cjs.Graphics().p("Ay/IAMAo8gOEIC2IQMgo7AOFg");
	var mask_graphics_65 = new cjs.Graphics().p("AzlIAMAqIgOeIC2IQMgqHAOfg");
	var mask_graphics_66 = new cjs.Graphics().p("A0EIAMArGgO0IC2IRMgrFAO0g");
	var mask_graphics_67 = new cjs.Graphics().p("A0cIAMAr2gPFIC3IRMgr3APFg");
	var mask_graphics_68 = new cjs.Graphics().p("A0wIAMAsegPSIC2IQMgsdAPTg");
	var mask_graphics_69 = new cjs.Graphics().p("A0+IAMAs6gPcIC3IQMgs7APdg");
	var mask_graphics_70 = new cjs.Graphics().p("A1JIAMAtQgPjIC2IQMgtPAPkg");
	var mask_graphics_71 = new cjs.Graphics().p("A1QIAMAtegPoIC2IRMgtdAPog");
	var mask_graphics_72 = new cjs.Graphics().p("A1UIAMAtmgPrIC2IRMgtlAPrg");
	var mask_graphics_73 = new cjs.Graphics().p("A1WIAMAtqgPsIC2IQMgtqAPtg");
	var mask_graphics_74 = new cjs.Graphics().p("A1XIAMAtsgPtIC2IRMgtrAPtg");
	var mask_graphics_75 = new cjs.Graphics().p("A1VH/MAtsgPtIC2IRMgtsAPug");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_graphics_52,x:34.8614,y:104.1502}).wait(1).to({graphics:mask_graphics_53,x:52.2231,y:104.1483}).wait(1).to({graphics:mask_graphics_54,x:68.0761,y:104.1468}).wait(1).to({graphics:mask_graphics_55,x:82.489,y:104.1453}).wait(1).to({graphics:mask_graphics_56,x:95.5304,y:104.144}).wait(1).to({graphics:mask_graphics_57,x:107.2688,y:104.1429}).wait(1).to({graphics:mask_graphics_58,x:117.7727,y:104.1418}).wait(1).to({graphics:mask_graphics_59,x:127.1109,y:104.1409}).wait(1).to({graphics:mask_graphics_60,x:135.3517,y:104.1401}).wait(1).to({graphics:mask_graphics_61,x:142.5639,y:104.1393}).wait(1).to({graphics:mask_graphics_62,x:148.816,y:104.1387}).wait(1).to({graphics:mask_graphics_63,x:154.1766,y:104.1382}).wait(1).to({graphics:mask_graphics_64,x:158.7143,y:104.1378}).wait(1).to({graphics:mask_graphics_65,x:162.4975,y:104.1374}).wait(1).to({graphics:mask_graphics_66,x:165.595,y:104.1371}).wait(1).to({graphics:mask_graphics_67,x:168.0753,y:104.1368}).wait(1).to({graphics:mask_graphics_68,x:170.0069,y:104.1366}).wait(1).to({graphics:mask_graphics_69,x:171.4585,y:104.1365}).wait(1).to({graphics:mask_graphics_70,x:172.4986,y:104.1364}).wait(1).to({graphics:mask_graphics_71,x:173.1958,y:104.1363}).wait(1).to({graphics:mask_graphics_72,x:173.6187,y:104.1363}).wait(1).to({graphics:mask_graphics_73,x:173.8359,y:104.1362}).wait(1).to({graphics:mask_graphics_74,x:173.9159,y:104.1362}).wait(1).to({graphics:mask_graphics_75,x:174.1059,y:104.0752}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AselkIY+DSI5AH3g");
	this.shape.setTransform(102.8826,174.2367,0.6439,0.6439);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(52).to({_off:false},0).wait(24));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_52 = new cjs.Graphics().p("AAWIAICQgyIC3ISIiQAyg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AiWIAIHqipIC2ISInrCog");
	var mask_1_graphics_54 = new cjs.Graphics().p("Ak1IAIMnkWIC3ISIsnEVg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AnFIAIRIl5IC2IRIxHF5g");
	var mask_1_graphics_56 = new cjs.Graphics().p("ApHIAIVMnTIC2ISI1MHSg");
	var mask_1_graphics_57 = new cjs.Graphics().p("Aq8IAIY2ojIC3IRI43Ijg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AslIAIcIprIC3IRI8JJrg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AuDIAIfEqrIC2IQI/EKsg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AvVIAMAhogLkIC3IRMghpALkg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AwdIAMAj4gMVIC3IQMgj5AMWg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AxcIAMAl2gNAIC2IQMgl2ANBg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AyRIAMAnggNlIC3IQMgnhANmg");
	var mask_1_graphics_64 = new cjs.Graphics().p("Ay/IAMAo8gOEIC2IQMgo7AOFg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AzlIAMAqIgOeIC2IQMgqHAOfg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A0EIAMArGgO0IC2IRMgrFAO0g");
	var mask_1_graphics_67 = new cjs.Graphics().p("A0cIAMAr2gPFIC3IRMgr3APFg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A0wIAMAsegPSIC2IQMgsdAPTg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A0+IAMAs6gPcIC3IQMgs7APdg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A1JIAMAtQgPjIC2IQMgtPAPkg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A1QIAMAtegPoIC2IRMgtdAPog");
	var mask_1_graphics_72 = new cjs.Graphics().p("A1UIAMAtmgPrIC2IRMgtlAPrg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A1WIAMAtqgPsIC2IQMgtqAPtg");
	var mask_1_graphics_74 = new cjs.Graphics().p("A1XIAMAtsgPtIC2IRMgtrAPtg");
	var mask_1_graphics_75 = new cjs.Graphics().p("A1VH/MAtsgPtIC2IRMgtsAPug");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_1_graphics_52,x:34.8614,y:104.1502}).wait(1).to({graphics:mask_1_graphics_53,x:52.2231,y:104.1483}).wait(1).to({graphics:mask_1_graphics_54,x:68.0761,y:104.1468}).wait(1).to({graphics:mask_1_graphics_55,x:82.489,y:104.1453}).wait(1).to({graphics:mask_1_graphics_56,x:95.5304,y:104.144}).wait(1).to({graphics:mask_1_graphics_57,x:107.2688,y:104.1429}).wait(1).to({graphics:mask_1_graphics_58,x:117.7727,y:104.1418}).wait(1).to({graphics:mask_1_graphics_59,x:127.1109,y:104.1409}).wait(1).to({graphics:mask_1_graphics_60,x:135.3517,y:104.1401}).wait(1).to({graphics:mask_1_graphics_61,x:142.5639,y:104.1393}).wait(1).to({graphics:mask_1_graphics_62,x:148.816,y:104.1387}).wait(1).to({graphics:mask_1_graphics_63,x:154.1766,y:104.1382}).wait(1).to({graphics:mask_1_graphics_64,x:158.7143,y:104.1378}).wait(1).to({graphics:mask_1_graphics_65,x:162.4975,y:104.1374}).wait(1).to({graphics:mask_1_graphics_66,x:165.595,y:104.1371}).wait(1).to({graphics:mask_1_graphics_67,x:168.0753,y:104.1368}).wait(1).to({graphics:mask_1_graphics_68,x:170.0069,y:104.1366}).wait(1).to({graphics:mask_1_graphics_69,x:171.4585,y:104.1365}).wait(1).to({graphics:mask_1_graphics_70,x:172.4986,y:104.1364}).wait(1).to({graphics:mask_1_graphics_71,x:173.1958,y:104.1363}).wait(1).to({graphics:mask_1_graphics_72,x:173.6187,y:104.1363}).wait(1).to({graphics:mask_1_graphics_73,x:173.8359,y:104.1362}).wait(1).to({graphics:mask_1_graphics_74,x:173.9159,y:104.1362}).wait(1).to({graphics:mask_1_graphics_75,x:174.1059,y:104.0752}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A2FDaMAsKgNVIAAHDMgq0AM0g");
	this.shape_1.setTransform(192.95,129.375);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(52).to({_off:false},0).wait(24));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_29 = new cjs.Graphics().p("ATpSEIBEosIKZBRIhDIsg");
	var mask_2_graphics_30 = new cjs.Graphics().p("APcRjIBDosIOnByIhEIsg");
	var mask_2_graphics_31 = new cjs.Graphics().p("ALTRDIBDosISwCSIhEIsg");
	var mask_2_graphics_32 = new cjs.Graphics().p("AHTQkIBEosIWuCxIhEIsg");
	var mask_2_graphics_33 = new cjs.Graphics().p("ADiQHIBEosIafDOIhEIsg");
	var mask_2_graphics_34 = new cjs.Graphics().p("AACPsIBEosId+DpIhDIsg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AjJPTIBEosMAhJAECIhEIsg");
	var mask_2_graphics_36 = new cjs.Graphics().p("AmCO8IBEosMAkCAEZIhEIsg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AonOoIBEosMAmmAEtIhDIsg");
	var mask_2_graphics_38 = new cjs.Graphics().p("Aq5OWIBDosMAo5AE/IhEIsg");
	var mask_2_graphics_39 = new cjs.Graphics().p("As7OGIBDorMAq7AFOIhEIsg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AuuN4IBDorMAsuAFcIhEIsg");
	var mask_2_graphics_41 = new cjs.Graphics().p("AwUNsIBEosMAuTAFpIhEIsg");
	var mask_2_graphics_42 = new cjs.Graphics().p("AxtNhIBEosMAvsAF0IhEIsg");
	var mask_2_graphics_43 = new cjs.Graphics().p("Ay8NYIBEosMAw6AF9IhDIsg");
	var mask_2_graphics_44 = new cjs.Graphics().p("A0BNPIBEosMAx/AGGIhDIsg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A0+NIIBEosMAy8AGNIhEIsg");
	var mask_2_graphics_46 = new cjs.Graphics().p("A1zNBIBDosMAzyAGUIhEIsg");
	var mask_2_graphics_47 = new cjs.Graphics().p("A2iM8IBEosMA0gAGZIhEIsg");
	var mask_2_graphics_48 = new cjs.Graphics().p("A3LM3IBEosMA1JAGeIhEIsg");
	var mask_2_graphics_49 = new cjs.Graphics().p("A3uMyIBDosMA1tAGjIhEIsg");
	var mask_2_graphics_50 = new cjs.Graphics().p("A4NMvIBEosMA2LAGmIhEIsg");
	var mask_2_graphics_51 = new cjs.Graphics().p("A4nMrIBDorMA2mAGpIhEIsg");
	var mask_2_graphics_52 = new cjs.Graphics().p("A4+MoIBDosMA28AGtIhEIsg");
	var mask_2_graphics_75 = new cjs.Graphics().p("A4+MoIBDosMA28AGtIhEIsg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_2_graphics_29,x:199.0364,y:123.725}).wait(1).to({graphics:mask_2_graphics_30,x:198.993,y:123.7235}).wait(1).to({graphics:mask_2_graphics_31,x:198.9503,y:123.722}).wait(1).to({graphics:mask_2_graphics_32,x:198.9092,y:123.7205}).wait(1).to({graphics:mask_2_graphics_33,x:198.8704,y:123.7191}).wait(1).to({graphics:mask_2_graphics_34,x:198.8344,y:123.7178}).wait(1).to({graphics:mask_2_graphics_35,x:198.8014,y:123.7166}).wait(1).to({graphics:mask_2_graphics_36,x:198.7717,y:123.7155}).wait(1).to({graphics:mask_2_graphics_37,x:198.7452,y:123.7145}).wait(1).to({graphics:mask_2_graphics_38,x:198.7215,y:123.7137}).wait(1).to({graphics:mask_2_graphics_39,x:198.7006,y:123.7129}).wait(1).to({graphics:mask_2_graphics_40,x:198.6821,y:123.7122}).wait(1).to({graphics:mask_2_graphics_41,x:198.6658,y:123.7116}).wait(1).to({graphics:mask_2_graphics_42,x:198.6514,y:123.7111}).wait(1).to({graphics:mask_2_graphics_43,x:198.6388,y:123.7107}).wait(1).to({graphics:mask_2_graphics_44,x:198.6276,y:123.7102}).wait(1).to({graphics:mask_2_graphics_45,x:198.6178,y:123.7099}).wait(1).to({graphics:mask_2_graphics_46,x:198.6092,y:123.7096}).wait(1).to({graphics:mask_2_graphics_47,x:198.6017,y:123.7093}).wait(1).to({graphics:mask_2_graphics_48,x:198.5951,y:123.7091}).wait(1).to({graphics:mask_2_graphics_49,x:198.5894,y:123.7089}).wait(1).to({graphics:mask_2_graphics_50,x:198.5844,y:123.7087}).wait(1).to({graphics:mask_2_graphics_51,x:198.5802,y:123.7085}).wait(1).to({graphics:mask_2_graphics_52,x:198.5114,y:123.65}).wait(23).to({graphics:mask_2_graphics_75,x:198.5114,y:123.65}).wait(1));

	// bottom
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,0,0,0.008)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_2.setTransform(168,131);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A5zAMIAAnFMAznAGhIg7HSg");
	this.shape_3.setTransform(216.6,196.025);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},29).to({state:[{t:this.shape_3}]},46).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(18,6,363.8,250);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AAnJCICQgxIC2IRIiQAyg");
	var mask_graphics_69 = new cjs.Graphics().p("AklJCIMskYIC2ISIssEYg");
	var mask_graphics_70 = new cjs.Graphics().p("Ao2JCIVQnVIC2ISI1QHUg");
	var mask_graphics_71 = new cjs.Graphics().p("AsRJCIcHprIC3IRI8IJrg");
	var mask_graphics_72 = new cjs.Graphics().p("Au7JBMAhdgLgIC2IRMghdALhg");
	var mask_graphics_73 = new cjs.Graphics().p("Aw7JBMAlegM4IC2IQMgleAM6g");
	var mask_graphics_74 = new cjs.Graphics().p("AyXJBMAoWgN4IC2IRMgoVAN5g");
	var mask_graphics_75 = new cjs.Graphics().p("AzUJBMAqRgOiIC2IQMgqRAOkg");
	var mask_graphics_76 = new cjs.Graphics().p("Az5JBMArcgO8IC2IQMgrcAO+g");
	var mask_graphics_77 = new cjs.Graphics().p("A0MJBMAsCgPJIC2IQMgsCAPLg");
	var mask_graphics_78 = new cjs.Graphics().p("A0TJBMAsQgPOIC2IQMgsQAPQg");
	var mask_graphics_79 = new cjs.Graphics().p("A0UJBMAsSgPPIC2IQMgsSAPQg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:36.5114,y:110.8002}).wait(1).to({graphics:mask_graphics_69,x:70.1141,y:110.7641}).wait(1).to({graphics:mask_graphics_70,x:97.6245,y:110.7346}).wait(1).to({graphics:mask_graphics_71,x:119.6524,y:110.711}).wait(1).to({graphics:mask_graphics_72,x:136.8072,y:110.6926}).wait(1).to({graphics:mask_graphics_73,x:149.6985,y:110.6788}).wait(1).to({graphics:mask_graphics_74,x:158.9353,y:110.6689}).wait(1).to({graphics:mask_graphics_75,x:165.127,y:110.6623}).wait(1).to({graphics:mask_graphics_76,x:168.8826,y:110.6582}).wait(1).to({graphics:mask_graphics_77,x:170.8111,y:110.6562}).wait(1).to({graphics:mask_graphics_78,x:171.5216,y:110.6554}).wait(1).to({graphics:mask_graphics_79,x:171.6351,y:110.6252}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(133.7925,184.7491,0.6439,0.6439);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_68 = new cjs.Graphics().p("AAnJCICQgxIC2IRIiQAyg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AklJCIMskYIC2ISIssEYg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ao2JCIVQnVIC2ISI1QHUg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AsRJCIcHprIC3IRI8IJrg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Au7JBMAhdgLgIC2IRMghdALhg");
	var mask_1_graphics_73 = new cjs.Graphics().p("Aw7JBMAlegM4IC2IQMgleAM6g");
	var mask_1_graphics_74 = new cjs.Graphics().p("AyXJBMAoWgN4IC2IRMgoVAN5g");
	var mask_1_graphics_75 = new cjs.Graphics().p("AzUJBMAqRgOiIC2IQMgqRAOkg");
	var mask_1_graphics_76 = new cjs.Graphics().p("Az5JBMArcgO8IC2IQMgrcAO+g");
	var mask_1_graphics_77 = new cjs.Graphics().p("A0MJBMAsCgPJIC2IQMgsCAPLg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A0TJBMAsQgPOIC2IQMgsQAPQg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A0UJBMAsSgPPIC2IQMgsSAPQg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_1_graphics_68,x:36.5114,y:110.8002}).wait(1).to({graphics:mask_1_graphics_69,x:70.1141,y:110.7641}).wait(1).to({graphics:mask_1_graphics_70,x:97.6245,y:110.7346}).wait(1).to({graphics:mask_1_graphics_71,x:119.6524,y:110.711}).wait(1).to({graphics:mask_1_graphics_72,x:136.8072,y:110.6926}).wait(1).to({graphics:mask_1_graphics_73,x:149.6985,y:110.6788}).wait(1).to({graphics:mask_1_graphics_74,x:158.9353,y:110.6689}).wait(1).to({graphics:mask_1_graphics_75,x:165.127,y:110.6623}).wait(1).to({graphics:mask_1_graphics_76,x:168.8826,y:110.6582}).wait(1).to({graphics:mask_1_graphics_77,x:170.8111,y:110.6562}).wait(1).to({graphics:mask_1_graphics_78,x:171.5216,y:110.6554}).wait(1).to({graphics:mask_1_graphics_79,x:171.6351,y:110.6252}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(193.2887,141.3477,0.6446,0.6446);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_58 = new cjs.Graphics().p("ATvQgIACowIAgABIgCIwg");
	var mask_2_graphics_59 = new cjs.Graphics().p("ATpQgIACowIAmABIgCIwg");
	var mask_2_graphics_60 = new cjs.Graphics().p("ATBQgIACowIBOABIgCIwg");
	var mask_2_graphics_61 = new cjs.Graphics().p("ARWQgIABowIC6ABIgCIwg");
	var mask_2_graphics_62 = new cjs.Graphics().p("AODQgIACowIGMABIgCIvg");
	var mask_2_graphics_63 = new cjs.Graphics().p("AIpQfIACowILmACIgCIvg");
	var mask_2_graphics_64 = new cjs.Graphics().p("ABTQdIACowIS7AEIgCIwg");
	var mask_2_graphics_65 = new cjs.Graphics().p("AkHQcIACowIYVAFIgCIwg");
	var mask_2_graphics_66 = new cjs.Graphics().p("AnZQbIACowIbnAGIgCIwg");
	var mask_2_graphics_67 = new cjs.Graphics().p("ApFQaIACowIdTAHIgCIwg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AptQaIACowId7AHIgCIwg");
	var mask_2_graphics_69 = new cjs.Graphics().p("ApzQaIACowId/AGIgBIwg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_2_graphics_58,x:129.7211,y:105.65}).wait(1).to({graphics:mask_2_graphics_59,x:129.7206,y:105.6501}).wait(1).to({graphics:mask_2_graphics_60,x:129.717,y:105.6501}).wait(1).to({graphics:mask_2_graphics_61,x:129.7072,y:105.6502}).wait(1).to({graphics:mask_2_graphics_62,x:129.6882,y:105.6502}).wait(1).to({graphics:mask_2_graphics_63,x:129.6568,y:105.6503}).wait(1).to({graphics:mask_2_graphics_64,x:129.6142,y:105.6504}).wait(1).to({graphics:mask_2_graphics_65,x:129.5828,y:105.6505}).wait(1).to({graphics:mask_2_graphics_66,x:129.5638,y:105.6505}).wait(1).to({graphics:mask_2_graphics_67,x:129.554,y:105.6505}).wait(1).to({graphics:mask_2_graphics_68,x:129.5504,y:105.6505}).wait(1).to({graphics:mask_2_graphics_69,x:129.4461,y:105.625}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(190.7263,184.8769,0.6446,0.6446);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_58 = new cjs.Graphics().p("ATvQgIACowIAgABIgCIwg");
	var mask_3_graphics_59 = new cjs.Graphics().p("ATpQgIACowIAmABIgCIwg");
	var mask_3_graphics_60 = new cjs.Graphics().p("ATBQgIACowIBOABIgCIwg");
	var mask_3_graphics_61 = new cjs.Graphics().p("ARWQgIABowIC6ABIgCIwg");
	var mask_3_graphics_62 = new cjs.Graphics().p("AODQgIACowIGMABIgCIvg");
	var mask_3_graphics_63 = new cjs.Graphics().p("AIpQfIACowILmACIgCIvg");
	var mask_3_graphics_64 = new cjs.Graphics().p("ABTQdIACowIS7AEIgCIwg");
	var mask_3_graphics_65 = new cjs.Graphics().p("AkHQcIACowIYVAFIgCIwg");
	var mask_3_graphics_66 = new cjs.Graphics().p("AnZQbIACowIbnAGIgCIwg");
	var mask_3_graphics_67 = new cjs.Graphics().p("ApFQaIACowIdTAHIgCIwg");
	var mask_3_graphics_68 = new cjs.Graphics().p("AptQaIACowId7AHIgCIwg");
	var mask_3_graphics_69 = new cjs.Graphics().p("ApzQaIACowId/AGIgBIwg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_3_graphics_58,x:129.7211,y:105.65}).wait(1).to({graphics:mask_3_graphics_59,x:129.7206,y:105.6501}).wait(1).to({graphics:mask_3_graphics_60,x:129.717,y:105.6501}).wait(1).to({graphics:mask_3_graphics_61,x:129.7072,y:105.6502}).wait(1).to({graphics:mask_3_graphics_62,x:129.6882,y:105.6502}).wait(1).to({graphics:mask_3_graphics_63,x:129.6568,y:105.6503}).wait(1).to({graphics:mask_3_graphics_64,x:129.6142,y:105.6504}).wait(1).to({graphics:mask_3_graphics_65,x:129.5828,y:105.6505}).wait(1).to({graphics:mask_3_graphics_66,x:129.5638,y:105.6505}).wait(1).to({graphics:mask_3_graphics_67,x:129.554,y:105.6505}).wait(1).to({graphics:mask_3_graphics_68,x:129.5504,y:105.6505}).wait(1).to({graphics:mask_3_graphics_69,x:129.4461,y:105.625}).wait(11));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(162.0077,184.8769,0.6446,0.6446);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_29 = new cjs.Graphics().p("An8RoIJ5jaIC2ISIp5Dag");
	var mask_4_graphics_30 = new cjs.Graphics().p("An8RoIM8kdIC2IRIs8Eeg");
	var mask_4_graphics_31 = new cjs.Graphics().p("ApZRoIP9lgIC2ISIv9Fgg");
	var mask_4_graphics_32 = new cjs.Graphics().p("Aq3RoIS5mhIC2ISIy5Ggg");
	var mask_4_graphics_33 = new cjs.Graphics().p("AsTRoIVxngIC2IRI1xHgg");
	var mask_4_graphics_34 = new cjs.Graphics().p("AtsRoIYjodIC2IRI4jIdg");
	var mask_4_graphics_35 = new cjs.Graphics().p("AvARoIbLpXIC2IRI7LJXg");
	var mask_4_graphics_36 = new cjs.Graphics().p("AwQRoIdqqOIC3IRI9qKOg");
	var mask_4_graphics_37 = new cjs.Graphics().p("AxaRnIf/rAIC2IRI//LBg");
	var mask_4_graphics_38 = new cjs.Graphics().p("AyfRnMAiJgLwIC2IRMgiJALxg");
	var mask_4_graphics_39 = new cjs.Graphics().p("AzgRnMAkKgMdIC3ISMgkKAMdg");
	var mask_4_graphics_40 = new cjs.Graphics().p("A0bRnMAmAgNFIC3IRMgmAANGg");
	var mask_4_graphics_41 = new cjs.Graphics().p("A1RRnMAntgNrIC2ISMgntANrg");
	var mask_4_graphics_42 = new cjs.Graphics().p("A2DRnMApRgONIC2IRMgpRAOOg");
	var mask_4_graphics_43 = new cjs.Graphics().p("A2xRnMAqsgOtIC3ISMgqsAOtg");
	var mask_4_graphics_44 = new cjs.Graphics().p("A3aRnMAr/gPKIC2ISMgr/APKg");
	var mask_4_graphics_45 = new cjs.Graphics().p("A4BRnMAtMgPkIC3ISMgtMAPkg");
	var mask_4_graphics_46 = new cjs.Graphics().p("A4kRnMAuSgP8IC3ISMguSAP7g");
	var mask_4_graphics_47 = new cjs.Graphics().p("A5DRnMAvRgQSIC2ISMgvRAQRg");
	var mask_4_graphics_48 = new cjs.Graphics().p("A5hRnMAwMgQmIC3IRMgwMAQmg");
	var mask_4_graphics_49 = new cjs.Graphics().p("A57RnMAxBgQ4IC2IRMgxBAQ4g");
	var mask_4_graphics_50 = new cjs.Graphics().p("A6TRnMAxxgRJIC2IRMgxxARJg");
	var mask_4_graphics_51 = new cjs.Graphics().p("A6pRnMAydgRYIC2IRMgydARYg");
	var mask_4_graphics_52 = new cjs.Graphics().p("A6+RnMAzGgRmIC3IRMgzGARmg");
	var mask_4_graphics_53 = new cjs.Graphics().p("A7QRnMAzrgRyIC2IRMgzrARyg");
	var mask_4_graphics_54 = new cjs.Graphics().p("A7gRnMA0LgR9IC2IQMg0LAR+g");
	var mask_4_graphics_55 = new cjs.Graphics().p("A7vRnMA0pgSIIC2IRMg0pASIg");
	var mask_4_graphics_56 = new cjs.Graphics().p("A79RnMA1FgSRIC2IQMg1FASSg");
	var mask_4_graphics_57 = new cjs.Graphics().p("A8JRnMA1dgSaIC2IRMg1dASag");
	var mask_4_graphics_58 = new cjs.Graphics().p("A8VRnMA10gShIC3IQMg10ASig");
	var mask_4_graphics_59 = new cjs.Graphics().p("A8eRnMA2HgSoIC2IRMg2HASog");
	var mask_4_graphics_60 = new cjs.Graphics().p("A8nRnMA2ZgSuIC2IQMg2ZASvg");
	var mask_4_graphics_61 = new cjs.Graphics().p("A8vRnMA2pgSzIC2IQMg2pAS0g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_4_graphics_29,x:-50.925,y:165.7752}).wait(1).to({graphics:mask_4_graphics_30,x:-50.8928,y:165.7643}).wait(1).to({graphics:mask_4_graphics_31,x:-41.5364,y:165.7537}).wait(1).to({graphics:mask_4_graphics_32,x:-32.0103,y:165.7432}).wait(1).to({graphics:mask_4_graphics_33,x:-22.7548,y:165.7331}).wait(1).to({graphics:mask_4_graphics_34,x:-13.8526,y:165.7233}).wait(1).to({graphics:mask_4_graphics_35,x:-5.3733,y:165.714}).wait(1).to({graphics:mask_4_graphics_36,x:2.6316,y:165.7052}).wait(1).to({graphics:mask_4_graphics_37,x:10.1296,y:165.697}).wait(1).to({graphics:mask_4_graphics_38,x:17.1071,y:165.6893}).wait(1).to({graphics:mask_4_graphics_39,x:23.5662,y:165.6823}).wait(1).to({graphics:mask_4_graphics_40,x:29.5211,y:165.6757}).wait(1).to({graphics:mask_4_graphics_41,x:34.9946,y:165.6697}).wait(1).to({graphics:mask_4_graphics_42,x:40.0147,y:165.6642}).wait(1).to({graphics:mask_4_graphics_43,x:44.6118,y:165.6592}).wait(1).to({graphics:mask_4_graphics_44,x:48.8174,y:165.6546}).wait(1).to({graphics:mask_4_graphics_45,x:52.6619,y:165.6503}).wait(1).to({graphics:mask_4_graphics_46,x:56.1748,y:165.6465}).wait(1).to({graphics:mask_4_graphics_47,x:59.3832,y:165.643}).wait(1).to({graphics:mask_4_graphics_48,x:62.3126,y:165.6397}).wait(1).to({graphics:mask_4_graphics_49,x:64.9861,y:165.6368}).wait(1).to({graphics:mask_4_graphics_50,x:67.4248,y:165.6341}).wait(1).to({graphics:mask_4_graphics_51,x:69.6478,y:165.6317}).wait(1).to({graphics:mask_4_graphics_52,x:71.6724,y:165.6295}).wait(1).to({graphics:mask_4_graphics_53,x:73.5143,y:165.6275}).wait(1).to({graphics:mask_4_graphics_54,x:75.1875,y:165.6256}).wait(1).to({graphics:mask_4_graphics_55,x:76.7048,y:165.624}).wait(1).to({graphics:mask_4_graphics_56,x:78.0779,y:165.6224}).wait(1).to({graphics:mask_4_graphics_57,x:79.317,y:165.6211}).wait(1).to({graphics:mask_4_graphics_58,x:80.4317,y:165.6199}).wait(1).to({graphics:mask_4_graphics_59,x:81.4306,y:165.6188}).wait(1).to({graphics:mask_4_graphics_60,x:82.3215,y:165.6178}).wait(1).to({graphics:mask_4_graphics_61,x:83.0655,y:165.6252}).wait(19));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.008)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_4.setTransform(168,131);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_5.setTransform(93.1764,242.4269,0.6446,0.6446);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_5}]},29).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-67,6,385,314.9);


(lib.Icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.PPT_icon_sml();
	this.instance.setTransform(-7.75,-6.45,0.82,0.82);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon, new cjs.Rectangle(-7.7,-6.4,168.79999999999998,128), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Render0116();
	this.instance.setTransform(-2.6,17.85);

	this.instance_1 = new lib.Render0115sml();
	this.instance_1.setTransform(14.8,46.2,2,2);

	this.instance_2 = new lib.Render0114sml();
	this.instance_2.setTransform(14.65,45.45,2,2);

	this.instance_3 = new lib.Render0113sml();
	this.instance_3.setTransform(15.05,43.7,2,2);

	this.instance_4 = new lib.Render0112sml();
	this.instance_4.setTransform(15,40.15,2,2);

	this.instance_5 = new lib.Render0111sml();
	this.instance_5.setTransform(15.65,38.25,2,2);

	this.instance_6 = new lib.Render0110sml();
	this.instance_6.setTransform(15.9,34.3,2,2);

	this.instance_7 = new lib.Render0109sml();
	this.instance_7.setTransform(17.2,26.35,2,2);

	this.instance_8 = new lib.Render0108();
	this.instance_8.setTransform(-2.6,17.85);

	this.instance_9 = new lib.Render0117();
	this.instance_9.setTransform(-2.6,17.85);

	this.instance_10 = new lib.Render0118();
	this.instance_10.setTransform(-2.6,17.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance_2}]},3).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_7}]},7).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance_9}]},4).to({state:[{t:this.instance_10}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.6,17.9,100,151);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.circleSegment = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkgEMQAHjiCiihQCoipDwgBIAAJCg");
	mask.setTransform(28.925,28.95);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#36724B").ss(16,1,1).p("AHzAAQAADPiSCSQiTCSjOAAQjOAAiSiSQiSiSAAjPQAAjNCSiSQCSiTDOAAQDOAACTCTQCSCSAADNg");
	this.shape.setTransform(57.8259,57.8759);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circleSegment, new cjs.Rectangle(0,0,57.9,57.9), null);


(lib.circle_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.498)","rgba(0,0,0,0.247)","rgba(0,0,0,0.039)","rgba(0,0,0,0)"],[0.239,0.502,0.769,1],-0.1,-0.1,0,-0.1,-0.1,54.1).s().p("Al8F7QicidAAjeQAAjeCcieQCeicDeAAQDeAACdCcQCeCeAADeQAADeieCdQidCejeAAQjeAAieieg");
	this.shape.setTransform(128.5,128.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#000000","rgba(0,0,0,0.322)","rgba(0,0,0,0.047)","rgba(0,0,0,0)"],[0.769,0.875,0.945,0.976],0,0,0,0,0,130.4).s().p("AuMONQl4l5AAoUQAAoUF4l4QF4l4IUAAQIVAAF3F4QF5F4AAIUQAAIUl5F5Ql3F4oVAAQoUAAl4l4gAq4q4QkgEhAAGXQAAGYEgEhQEhEgGXAAQGYAAEgkgQEgkhABmYQgBmXkgkhQkgkgmYAAQmXAAkhEgg");
	this.shape_1.setTransform(128.5,128.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.039)","rgba(0,0,0,0.247)","#000000"],[0.655,0.718,0.808,1],0,0,0,0,0,80.1).s().p("AoyIyQjojpAAlJQAAlJDojpQDpjoFJAAQFJAADpDoQDpDpAAFJQAAFJjpDpQjpDplJAAQlJAAjpjpg");
	this.shape_2.setTransform(128.45,128.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Aq4K5QkgkhAAmYQAAmXEgkhQEhkgGXAAQGYAAEgEgQEhEhAAGXQAAGYkhEhQkgEgmYAAQmXAAkhkggAoyoyQjoDpAAFJQAAFJDoDpQDpDpFJAAQFJAADpjpQDpjpAAlJQAAlJjpjpQjpjolJAAQlJAAjpDog");
	this.shape_3.setTransform(128.45,128.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circle_shadow, new cjs.Rectangle(0,0,257,257), null);


(lib.chart_mask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApOJ2IAAzrIScAAIAATrg");
	this.shape.setTransform(59.05,62.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_mask, new cjs.Rectangle(0,0,118.1,125.9), null);


(lib.btn_frame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(0.5,1,1).p("AvYiJIexAAIAAETI+xAAg");
	this.shape.setTransform(98.5,13.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.898)").s().p("AvYCKIAAkTIexAAIAAETg");
	this.shape_1.setTransform(98.5,13.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_frame, new cjs.Rectangle(-1,-1,199,29.5), null);


(lib.boxshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bottom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt3 = new cjs.Text("100%", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 31;
	this.txt3.parent = this;
	this.txt3.setTransform(438.2,5.15);

	this.txt2 = new cjs.Text("Display Settings", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.lineWidth = 31;
	this.txt2.parent = this;
	this.txt2.setTransform(321.85,4.9);

	this.txt1 = new cjs.Text("Ready", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.lineWidth = 14;
	this.txt1.parent = this;
	this.txt1.setTransform(2.3,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4F4F4F").s().p("AgBAMIAAgKIgKAAIAAgDIAKAAIAAgKIADAAIAAAKIAKAAIAAADIgKAAIAAAKg");
	this.shape.setTransform(433.2,3.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#757575").s().p("AgEAUIAAgQIifAAIAAgDICfAAIAAgUIAPAAIAAAUICZAAIAAADIiZAAIAAAQg");
	this.shape_1.setTransform(414.3,3.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4F4F4F").s().p("AgKAEIAAgHIAVAAIAAAHg");
	this.shape_2.setTransform(395.675,3.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgSATIAlAAIAAglIgLAAIAAAVIgaAAgAgEAAIAKAAIAAgSIgKAAgAgSAAIALAAIAAgSIgLAAg");
	this.shape_3.setTransform(386.7,3.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_4.setTransform(374.175,4.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_5.setTransform(374.175,3.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_6.setTransform(374.175,2.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4F4F4F").s().p("AgLARIAAghIAXAAIAAAhgAgJAOIASAAIAAgbIgSAAg");
	this.shape_7.setTransform(374.2,3.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgTATIAmAAIAAglIgmAAg");
	this.shape_8.setTransform(374.2,3.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAAJATIAKAAIAAgKIgKAAgAgEATIAKAAIAAgKIgKAAgAgSATIAMAAIAAgKIgMAAgAAJAGIAKAAIAAgKIgKAAgAgEAGIAKAAIAAgKIgKAAgAgSAGIAMAAIAAgKIgMAAgAAJgGIAKAAIAAgMIgKAAgAgEgGIAKAAIAAgMIgKAAgAgSgGIAMAAIAAgMIgMAAg");
	this.shape_9.setTransform(361.525,3.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4F4F4F").s().p("AgPAXIAAgEIALAAIAAgJIgSAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIAtAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIAAAaQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgBAAIgBgDIAAgBQAAAAABgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgCgBQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAABIgBABIgCAAIgBgBQAAgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAIgCAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAABIAAABIgBACIgBABIgBAAIgCABIgBAAIAAAJIAFAAIAAAEg");
	this.shape_10.setTransform(318.725,3.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4F4F4F").s().p("AAEALIgCgCQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAIgCACIgBAAIgCgBIAAgBIABgCQgCgCgBgDIgCAAIgBgBIAAgBIABAAIACgBIABgCIACgDIAAgCQgBgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIABAAIABACIAEAAIABgCIABAAIACABIAAABIgBACQACACABADIADABIAAAAIAAABIAAABIgDAAIgBACIgCAEIABACIgBABIgBAAgAgFgCQgEAFAHAEQAFADAEgGQADgGgGgEIgEgBQgDAAgCAFg");
	this.shape_11.setTransform(320.075,4.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F3F1F0").s().p("EgjPAAwIAAhfMBGfAAAIAABfg");
	this.shape_12.setTransform(225.575,4.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottom, new cjs.Rectangle(0,0,471.4,13.6), null);


(lib.big_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_big_msml();
	this.instance.setTransform(136,152,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_pie, new cjs.Rectangle(-0.2,0,420.2,420), null);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384549").s().p("A4MPeIAA7rIgBgWIgEgUIATgFQAUgFADABQARAFAQAAQAIAAAOgFQAPgFAJAAQALAAAGAGIAHAIIBSAoIAdACQADgGAHgEQAEgCAdgBIAcgBIARAKIALgGIAiAGIANgSIARAAIAOAKIBKgCIAKAHIBCgDIAJgHIAWACIAKgEIAfAAIAJgGQALgGAIAAQAOAAANAOIAigBIAJgHIAJADIAYAUIATAAIATAOIAWAAIAVAQIABANIANAAIADAOIAVAXIAOACIAAAKIASAIIABAIIALAAIAGAJIANABIgBALIAKAAIAOAKIABAJIAWAJIAXgUIALgFIAAgIIAjgMIADgJIAUgBIAVATIALAAIAeAcIANgJIATANQASgBADgBIANgLIAHAIIAJgGIALABIAJgEIARgDIALAKIAFgLIARgBIAHgCIAJADIAbAEIAJAIIAKgGIAKABIAGgRIASgQIAUgEQAEgBATADIA7AAIALgCIAMAGIANAAIAMgIIAQAKIAWAXIATABIAbAXIAMgCIAUAUIARACQAEAAAGAEIAHAHIAIANIAfALIAHAAIAEAHIA3AAIAGgGIAJAEIAeAAIAigoIAIAAIgCgJIAIgJIADgKQAQgJABgEQABgDAEgFIAGgEIAIgDIAAgSQAKACAAgDIgDgRIAIgBIAEgNIALgNQAOgOADgCQAEgCAPgCIATgNIAKABIAFgNIASAAIAAgQIAPgFIAHgKIAGgDQAFgEAEAAIAlADIAKACIAGAHIAdgdIABgOIAMAAIAZgNIAdgHIACgKIAIACIAEgJIALAAIABgJIATgLIACgMIANgCIANgLIABgJIAfgWIAQgGIAFAKIAQABIAXAPIASgUIAMgBIAGgHIAOAAIAOgMIANAAIAHAFIAhAAIAVAJIATgJIAgAAQApgDAOADQAOAEAQAKIAmABIAOgIIAQAGIACAHIBWABQAEAAAPgIQAPgHABAAQAEACAigBIAFgIIAJgCIAGAGIAWgLIAngBIAmgJIAOgHIAxAaIgITYIAALJg");
	this.shape.setTransform(155.4,98.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(0,0,310.8,198), null);


(lib.Background_img = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Bg_img_sml();
	this.instance.setTransform(11.5,145);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Background_img, new cjs.Rectangle(11.5,145,299,213), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAKBIIA5g1IjHAAIAAgkIDHAAIg5g2IAuAAIBNBHIhMBIg");
	this.shape.setTransform(3.5846,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(-4.1,0,15.4,8.4), null);


(lib.WordUI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.tablet_shadow_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tablet_shadow.cache(-30,-30,200,200,.25)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.tablet_shadow = new lib.tablet_shadow_sub();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(64.3,47.1,1,1,0,0,0,64.3,47.1);

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_vector, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.squareshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.tablet_shadow = new lib.tablet_shadow_vector();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.roundshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0.3,56,45), null);


(lib.Ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_26 = new cjs.Graphics().p("AgVjBIAmgNIgGGQIgmANg");
	var mask_graphics_27 = new cjs.Graphics().p("AgVjAIAngOIgGGPIgnAOg");
	var mask_graphics_28 = new cjs.Graphics().p("AgVi/IAwgRIgGGQIgwARg");
	var mask_graphics_29 = new cjs.Graphics().p("Aggi7IBIgZIgHGQIhIAZg");
	var mask_graphics_30 = new cjs.Graphics().p("Ag4izIB4gpIgHGPIh4Aqg");
	var mask_graphics_31 = new cjs.Graphics().p("AhfilIDGhFIgHGQIjGBFg");
	var mask_graphics_32 = new cjs.Graphics().p("AiaiRIE7htIgGGQIk7Btg");
	var mask_graphics_33 = new cjs.Graphics().p("Ajsh1IHfilIgGGQInfClg");
	var mask_graphics_34 = new cjs.Graphics().p("AlYhPIK3jxIgGGQIq3Dxg");
	var mask_graphics_35 = new cjs.Graphics().p("AnjgeIPNlTIgGGQIvNFTg");
	var mask_graphics_36 = new cjs.Graphics().p("AqRAeIUpnMIgGGRI0pHMg");
	var mask_graphics_37 = new cjs.Graphics().p("AtlBqIbRpkIgGGRI7RJkg");
	var mask_graphics_38 = new cjs.Graphics().p("AxjDGMAjMgMcIgFGRMgjMAMcg");
	var mask_graphics_39 = new cjs.Graphics().p("A2OE0MAsigP4IgFGRMgsiAP4g");
	var mask_graphics_40 = new cjs.Graphics().p("A7rG2MA3bgT9IgEGSMg3bAT9g");
	var mask_graphics_41 = new cjs.Graphics().p("Egh8AJPMBD9gYvIgEGSMhD9AYvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_graphics_26,x:-2.798,y:20.3129}).wait(1).to({graphics:mask_graphics_27,x:-2.7989,y:20.2916}).wait(1).to({graphics:mask_graphics_28,x:-2.8055,y:20.1424}).wait(1).to({graphics:mask_graphics_29,x:-1.6637,y:19.7375}).wait(1).to({graphics:mask_graphics_30,x:0.6443,y:18.9482}).wait(1).to({graphics:mask_graphics_31,x:4.4485,y:17.6448}).wait(1).to({graphics:mask_graphics_32,x:10.1221,y:15.6957}).wait(1).to({graphics:mask_graphics_33,x:18.0367,y:12.9657}).wait(1).to({graphics:mask_graphics_34,x:28.5628,y:9.3154}).wait(1).to({graphics:mask_graphics_35,x:42.0684,y:4.5992}).wait(1).to({graphics:mask_graphics_36,x:58.9186,y:-1.3369}).wait(1).to({graphics:mask_graphics_37,x:79.475,y:-8.6567}).wait(1).to({graphics:mask_graphics_38,x:104.0945,y:-17.5367}).wait(1).to({graphics:mask_graphics_39,x:133.1281,y:-28.1685}).wait(1).to({graphics:mask_graphics_40,x:166.9201,y:-40.7616}).wait(1).to({graphics:mask_graphics_41,x:210.7451,y:-57.4513}).wait(9));

	// Layer_5 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("Ak1iPIJrA9IprDig");
	this.shape.setTransform(30.5125,20.425);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(26).to({_off:false},0).wait(24));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("EgiLAJ7MBEXgYZIAAEaMhEXAYkg");
	this.shape_1.setTransform(217.775,-57.75);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(26).to({_off:false},0).wait(24));

	// Layer_8 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("EgsDAFYMApQgO5IAAgBMAu3gQ7IAAVGMgpQAO5IAAABMgu3AQ7g");
	mask_1.setTransform(18.775,87.075);

	// Layer_9
	this.bg_img = new lib.Background_img();
	this.bg_img.name = "bg_img";
	this.bg_img.setTransform(144.95,12.55,1,1,0,0,0,155.5,233.3);
	this.bg_img.alpha = 0;
	this.bg_img._off = true;

	var maskedShapeInstanceList = [this.bg_img];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.bg_img).wait(25).to({_off:false},0).to({alpha:1},19,cjs.Ease.cubicInOut).wait(6));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_10 = new cjs.Graphics().p("AYrFoIAmmNIBcAIIgmGOg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AYoFoIAnmOIBeAJIgmGOg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AYVFmIAnmOIBxALIgnGOg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AXiFhIAnmNICiAPIgmGOg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AV/FYIAmmOIEEAZIgmGOg");
	var mask_2_graphics_15 = new cjs.Graphics().p("ATbFIIAmmOIGlApIgmGNg");
	var mask_2_graphics_16 = new cjs.Graphics().p("APmEwIAnmNIKUA/IgmGOg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AKREPIAmmNIPjBfIgmGOg");
	var mask_2_graphics_18 = new cjs.Graphics().p("ADLDkIAmmOIWgCKIgmGOg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AlZCvIAmmOIe5C+IgmGOg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AsfCDIAmmOMAl2ADpIgmGOg");
	var mask_2_graphics_21 = new cjs.Graphics().p("Ax1BiIAnmOMArEAEKIgmGNg");
	var mask_2_graphics_22 = new cjs.Graphics().p("A1pBKIAmmNMAu0AEgIgmGOg");
	var mask_2_graphics_23 = new cjs.Graphics().p("A4NA6IAmmNMAxVAEwIgmGNg");
	var mask_2_graphics_24 = new cjs.Graphics().p("A5uAxIAmmOMAy3AE6IgmGNg");
	var mask_2_graphics_25 = new cjs.Graphics().p("A6HAsIAmmOMAzpAE+IgmGOg");
	var mask_2_graphics_26 = new cjs.Graphics().p("A6QAqIAmmOMAz7AFAIgmGOg");
	var mask_2_graphics_27 = new cjs.Graphics().p("A6RArIAmmOMAz9AFAIgmGOg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_2_graphics_10,x:170.8938,y:36.9}).wait(1).to({graphics:mask_2_graphics_11,x:170.8884,y:36.8994}).wait(1).to({graphics:mask_2_graphics_12,x:170.8505,y:36.8955}).wait(1).to({graphics:mask_2_graphics_13,x:170.7478,y:36.8848}).wait(1).to({graphics:mask_2_graphics_14,x:170.5478,y:36.8641}).wait(1).to({graphics:mask_2_graphics_15,x:170.2181,y:36.8298}).wait(1).to({graphics:mask_2_graphics_16,x:169.7262,y:36.7787}).wait(1).to({graphics:mask_2_graphics_17,x:169.0397,y:36.7073}).wait(1).to({graphics:mask_2_graphics_18,x:168.1262,y:36.6123}).wait(1).to({graphics:mask_2_graphics_19,x:167.0222,y:36.4973}).wait(1).to({graphics:mask_2_graphics_20,x:166.1087,y:36.4022}).wait(1).to({graphics:mask_2_graphics_21,x:165.4223,y:36.3306}).wait(1).to({graphics:mask_2_graphics_22,x:164.9304,y:36.2793}).wait(1).to({graphics:mask_2_graphics_23,x:164.6007,y:36.2449}).wait(1).to({graphics:mask_2_graphics_24,x:164.1118,y:36.2241}).wait(1).to({graphics:mask_2_graphics_25,x:161.4045,y:36.2134}).wait(1).to({graphics:mask_2_graphics_26,x:160.407,y:36.2094}).wait(1).to({graphics:mask_2_graphics_27,x:160.2948,y:36.3}).wait(23));

	// Layer_5 copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("Ak7BTIJ3jjIgEEhg");
	this.shape_2.setTransform(297.4,53.05);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(10).to({_off:false},0).wait(40));

	// Layer_5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A5vgRIABkiMAzeAFFIgFEig");
	this.shape_3.setTransform(164.275,36.775);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(10).to({_off:false},0).wait(40));

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("AjUJ1IGpiSIgHGQImpCTg");
	var mask_3_graphics_1 = new cjs.Graphics().p("AoJJ5IQZluIgGGRIwZFtg");
	var mask_3_graphics_2 = new cjs.Graphics().p("AsYJ8IY2ovIgFGRI42Ivg");
	var mask_3_graphics_3 = new cjs.Graphics().p("Av/J+MAgEgLVIgFGQMggEALWg");
	var mask_3_graphics_4 = new cjs.Graphics().p("AzCKAMAmKgNlIgFGRMgmKANmg");
	var mask_3_graphics_5 = new cjs.Graphics().p("A1lKCMArQgPeIgFGQMgrQAPgg");
	var mask_3_graphics_6 = new cjs.Graphics().p("A3qKDMAvagRCIgFGSMgvaARCg");
	var mask_3_graphics_7 = new cjs.Graphics().p("A5VKFMAyvgSUIgEGSMgyvASTg");
	var mask_3_graphics_8 = new cjs.Graphics().p("A6nKFMA1UgTSIgFGSMg1UATSg");
	var mask_3_graphics_9 = new cjs.Graphics().p("A7mKGMA3RgUCIgEGSMg3RAUCg");
	var mask_3_graphics_10 = new cjs.Graphics().p("A8SKHMA4pgUlIgEGTMg4pAUkg");
	var mask_3_graphics_11 = new cjs.Graphics().p("A8wKHMA5lgU7IgEGSMg5lAU7g");
	var mask_3_graphics_12 = new cjs.Graphics().p("A9CKHMA6JgVJIgEGSMg6JAVJg");
	var mask_3_graphics_13 = new cjs.Graphics().p("A9LKHMA6bgVQIgEGSMg6bAVQg");
	var mask_3_graphics_14 = new cjs.Graphics().p("A9PKHMA6jgVTIgEGSMg6jAVTg");
	var mask_3_graphics_15 = new cjs.Graphics().p("A9PKFMA6jgVTIgEGSMg6jAVTg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-21.973,y:102.9733}).wait(1).to({graphics:mask_3_graphics_1,x:8.2823,y:103.344}).wait(1).to({graphics:mask_3_graphics_2,x:34.746,y:103.6646}).wait(1).to({graphics:mask_3_graphics_3,x:57.392,y:103.939}).wait(1).to({graphics:mask_3_graphics_4,x:76.5292,y:104.1709}).wait(1).to({graphics:mask_3_graphics_5,x:92.4623,y:104.364}).wait(1).to({graphics:mask_3_graphics_6,x:105.4917,y:104.5219}).wait(1).to({graphics:mask_3_graphics_7,x:115.9146,y:104.6483}).wait(1).to({graphics:mask_3_graphics_8,x:124.0258,y:104.7466}).wait(1).to({graphics:mask_3_graphics_9,x:130.1176,y:104.8204}).wait(1).to({graphics:mask_3_graphics_10,x:134.4806,y:104.8733}).wait(1).to({graphics:mask_3_graphics_11,x:137.4044,y:104.9087}).wait(1).to({graphics:mask_3_graphics_12,x:139.1775,y:104.9302}).wait(1).to({graphics:mask_3_graphics_13,x:140.0879,y:104.9413}).wait(1).to({graphics:mask_3_graphics_14,x:140.4233,y:104.9453}).wait(1).to({graphics:mask_3_graphics_15,x:141.2828,y:104.7083}).wait(35));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("EgiLAJ8MBEXgYbIAAEbMhEXAYjg");
	this.shape_4.setTransform(218.7783,92.7519);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-150.5,429.5,336);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.option_btn_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#505050").ss(1,2,0,3).p("AggASIAggjIAhAj");
	this.shape.setTransform(184.7249,13.1817);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#505050").ss(1,2,0,3).p("AgggRIAgAjIAhgj");
	this.shape_1.setTransform(184.7249,13.9683);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,197.5,28);


(lib.option_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,197.5,28);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:3.6,x:-0.1},0).wait(1).to({x:-1},0).wait(1).to({x:-2.1},0).wait(1).to({x:-2.8},0).wait(1).to({regX:5.6,x:-1.05},0).wait(1).to({regX:3.6,x:-2.95},0).wait(1).to({x:-2.6},0).wait(1).to({x:-2.15},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.5},0).wait(1).to({regX:5.6,x:0.55},0).wait(1).to({regX:3.6,x:-1.45},0).wait(1).to({x:-1.6},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.9},0).wait(1).to({x:-2},0).wait(1).to({regX:5.6,x:-0.05},0).wait(1).to({regX:3.6,x:-2},0).wait(1).to({x:-1.95},0).wait(1).to({x:-1.9},0).wait(1).to({x:-1.85},0).wait(1).to({regX:5.6,x:0.15},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(1).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(35));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.ribbon = new lib.Ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(218.8,205.15,1,1,0,0,0,218.8,92.8);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(-263.2,0,700.8,368.9), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.TL_MainScreen.tweenFromTo("frame0", "frame1");
		//exportRoot.TL_Clouds.tweenFromTo("frame0", "frame1");
	}
	this.frame_89 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(30).call(this.frame_89).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(63));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(63));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.5,scaleX:2.42,scaleY:2.42,x:-12.2,y:8.75},30,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,340.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},16,cjs.Ease.cubicInOut).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-68,982,816.8);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask.setTransform(147.1518,94.651);

	// LeafA
	this.instance = new lib.leafA();
	this.instance.setTransform(58.25,128.95,0.6362,0.6362,0,0,0,99,122.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(105));

	// ScreenMaskA copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_1.setTransform(147.1518,94.651);

	// Grass
	this.instance_1 = new lib.grass();
	this.instance_1.setTransform(172.05,168.85,0.6595,0.6595,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(105));

	// ScreenMaskA copy 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_2.setTransform(147.1518,94.651);

	// LeafB
	this.instance_2 = new lib.leafB();
	this.instance_2.setTransform(255.85,101.15,0.6995,0.6995,0,0,0,55.1,54.6);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(150,70.95,0.7954,0.7954,0,0,0,50.2,75.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(55).to({mode:"synched",loop:false},0).to({y:72.9,startPosition:4},4,cjs.Ease.quadInOut).to({y:68.1,startPosition:16},12,cjs.Ease.quadInOut).to({startPosition:36},20,cjs.Ease.quadInOut).to({y:69.55,startPosition:44},8,cjs.Ease.quadInOut).wait(5).to({mode:"single",startPosition:49},0).wait(1));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(151.4,176.55,0.7338,0.7338,0,0,0,58.1,159.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55).to({regY:159.6,y:176.95},4,cjs.Ease.quadInOut).to({regY:159.7,scaleY:0.7573,y:175.65},16,cjs.Ease.quadInOut).to({scaleY:0.7571,y:175.6},12,cjs.Ease.quadInOut).to({scaleY:0.7338,y:176.55},12,cjs.Ease.quadInOut).wait(6));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_3.setTransform(147.1518,94.651);

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(167.9,158.75,0.8242,0.8242,0,0,0,155.3,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_4.setTransform(147.1518,94.651);

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(166.1,87.6,0.7852,0.7852,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(105));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(0,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(105));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,22.2,300,201);


(lib.main_ui = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MainText
	this.instance = new lib.main_txt();
	this.instance.setTransform(78.55,84.7,1,1,0,0,0,52,12.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Rows_Cells
	this.instance_1 = new lib.rowsandcells();
	this.instance_1.setTransform(233.3,34.55,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Top_bar_txt
	this.instance_2 = new lib.top_text();
	this.instance_2.setTransform(224.6,11.15,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Top_bar
	this.instance_3 = new lib.Topbar();
	this.instance_3.setTransform(225,5.5,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Top_grey
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#227347").s().p("AgOAIIgDAAIAAgYIAjAAIAAAYIgVAAIgLAJgAgPAGIAEAAIAAAGIAHgGIATAAIAAgTIgeAAg");
	this.shape.setTransform(416.4564,17.2001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#EEEDEC").ss(0.3).p("ACcAlIk3AAQgDAAgCgCQgCgCAAgDIAAg6QAAgIAHAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_1.setTransform(428.3065,17.1751);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibAlQgDAAgCgCQgCgCgBgDIAAg6QAAgIAIAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_2.setTransform(428.3065,17.1751);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#227347").s().p("AACAHQgJAAgFAEIgCABIAAgDIADgHQAEgGAJAAIAAgIIANAMIgNAOgAADAFIABAAIAAACIAHgHIgHgGIAAAEIgBAAQgLAAgDAJQAFgDAGABg");
	this.shape_3.setTransform(391.881,16.4001);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#227347").s().p("AgQANIAAgZIADAAIAAAWIAbAAIAAgLIADAAIAAAOg");
	this.shape_4.setTransform(391.106,17.9251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#474747").s().p("AgWAXQAAAAgBgBQAAAAAAAAQAAAAAAAAQABgBAAAAIARgRQgDgEAAgFQAAgHAFgFQADgFAHAAQAHAAAFAFQAFAFAAAHQAAAGgFAFQgFAEgHAAQgHAAgEgEIgRARgAgCgPQgEAEAAAGQAAAFAEAEQADAEAGAAQAGAAAEgEQAEgEAAgFQAAgGgEgEQgEgFgGABQgGgBgDAFg");
	this.shape_5.setTransform(205.7781,17.4501);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#EEEDEC").ss(0.3).p("ABnAlIjMAAQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_6.setTransform(397.9561,17.2001);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhlAlQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_7.setTransform(397.9561,17.2001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F0F0F0").s().p("EgjJAA9IAAh5MBGTAAAIAAB5g");
	this.shape_8.setTransform(225,17.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Scroll_bars
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#ABABAB").ss(0.3).p("AqYAXIAAgtIUxAAIAAAtg");
	this.shape_9.setTransform(277.1512,272.3786);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqXAXIAAgtIUvAAIAAAtg");
	this.shape_10.setTransform(277.1512,272.3786);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#787878").s().p("AgFgLIALALIgLAMg");
	this.shape_11.setTransform(437.3786,272.4286);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#787878").s().p("AgFAAIALgLIAAAXg");
	this.shape_12.setTransform(208.3001,272.4286);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_13.setTransform(437.2536,272.3786);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAXIAAgtIAsAAIAAAtg");
	this.shape_14.setTransform(437.2536,272.3786);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_15.setTransform(208.4251,272.4036);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAXIAAgsIAtAAIAAAsg");
	this.shape_16.setTransform(208.4251,272.4036);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#DBDBDB").ss(0.3).p("AxhAXIAAgtMAjDAAAIAAAtg");
	this.shape_17.setTransform(322.8519,272.3786);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DBDBDB").s().p("AxgAXIAAgtMAjCAAAIAAAtg");
	this.shape_18.setTransform(322.8519,272.3786);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#ABABAB").ss(0.3).p("AAXKZIgtAAIAA0xIAtAAg");
	this.shape_19.setTransform(445.3787,110.0511);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWKYIAA0vIAtAAIAAUvg");
	this.shape_20.setTransform(445.3787,110.0511);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAHAAIAAAFg");
	this.shape_21.setTransform(200.65,273.4536);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B3B3B3").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_22.setTransform(200.65,272.1536);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAHAAIAAAGg");
	this.shape_23.setTransform(200.65,270.8535);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787878").s().p("AgMAGIAMgLIAMALg");
	this.shape_24.setTransform(445.4037,41.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#787878").s().p("AgMgFIAYAAIgMALg");
	this.shape_25.setTransform(445.4037,265.2785);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_26.setTransform(445.3787,41.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_27.setTransform(445.3787,41.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_28.setTransform(445.4037,265.1285);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAsAAIAAAtg");
	this.shape_29.setTransform(445.4037,265.1285);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DBDBDB").ss(0.3).p("AAXRIIgtAAMAAAgiPIAtAAg");
	this.shape_30.setTransform(445.3787,153.2267);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DBDBDB").s().p("AgWRIMAAAgiPIAtAAMAAAAiPg");
	this.shape_31.setTransform(445.3787,153.2267);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// layout
	this.instance_4 = new lib.Layout();
	this.instance_4.setTransform(225,150.15,1,1,0,0,0,225,126.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Bottom
	this.instance_5 = new lib.bottom();
	this.instance_5.setTransform(225.6,281.85,1,1,0,0,0,225.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer_2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#E4DFD4").ss(1,1,1).p("EgifgVxMBE/AAAMAAAArjMhE/AAAg");
	this.shape_32.setTransform(223.225,143.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("EgifAVyMAAAgrjMBE/AAAMAAAArjg");
	this.shape_33.setTransform(223.225,143.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_ui, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.guyrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,-0.1,53,43), null);


(lib.guyrightcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.guylefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon, new cjs.Rectangle(0.1,0.1,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.graphLG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.graphGreen();
	this.instance.setTransform(49.9,49.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphLG, new cjs.Rectangle(-8,-8,115.8,115.8), null);


(lib.GraphCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// WhiteCoverOuter
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCAAQAADwiqCoQioCqjwAAQjvAAipiqQipioAAjwQAAjvCpipQCpipDvAAQDwAACoCpQCqCpAADvg");
	this.shape.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// WhiteCoverMid
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkpEpQh6h7AAiuQAAitB6h8QB8h6CtAAQCuAAB7B6QB7B8AACtQAACuh7B7Qh7B7iuAAQitAAh8h7g");
	this.shape_1.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(60));

	// Layer_3
	this.instance = new lib.circleSegment();
	this.instance.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:28.9,regY:29,rotation:-0.029,x:28.9,y:29},0).wait(1).to({rotation:-0.1186,x:28.85,y:29.05},0).wait(1).to({rotation:-0.273,x:28.8,y:29.1},0).wait(1).to({rotation:-0.4968,x:28.7,y:29.25},0).wait(1).to({rotation:-0.7954,x:28.55,y:29.4},0).wait(1).to({rotation:-1.1745,x:28.35,y:29.55},0).wait(1).to({rotation:-1.6408,x:28.15,y:29.8},0).wait(1).to({rotation:-2.2019,x:27.85,y:30.15},0).wait(1).to({rotation:-2.8662,x:27.5,y:30.45},0).wait(1).to({rotation:-3.6437,x:27.15,y:30.85},0).wait(1).to({rotation:-4.5458,x:26.7,y:31.35},0).wait(1).to({rotation:-5.5858,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7793,x:25.7,y:32.6},0).wait(1).to({rotation:-8.145,x:25.1,y:33.35},0).wait(1).to({rotation:-9.7052,x:24.5,y:34.3},0).wait(1).to({rotation:-11.4869,x:23.75,y:35.3},0).wait(1).to({rotation:-13.5237,x:23,y:36.55},0).wait(1).to({rotation:-15.8573,x:22.1,y:38},0).wait(1).to({rotation:-18.5409,x:21.2,y:39.7},0).wait(1).to({rotation:-21.6437,x:20.3,y:41.7},0).wait(1).to({rotation:-25.2575,x:19.35,y:44.1},0).wait(1).to({rotation:-29.5072,x:18.45,y:47},0).wait(1).to({rotation:-34.5678,x:17.65,y:50.55},0).wait(1).to({rotation:-40.6901,x:17.05,y:54.85},0).wait(1).to({rotation:-48.2363,y:60.25},0).wait(1).to({rotation:-57.704,x:18,y:66.9},0).wait(1).to({rotation:-69.5952,x:20.75,y:74.95},0).wait(1).to({rotation:-83.7062,x:25.95,y:83.5},0).wait(1).to({rotation:-98.1499,x:33.35,y:90.7},0).wait(1).to({rotation:-110.7267,x:41.05,y:95.2},0).wait(1).to({rotation:-120.8736,x:47.9,y:97.6},0).wait(1).to({rotation:-128.9999,x:53.6,y:98.6},0).wait(1).to({rotation:-135.6121,x:58.35,y:98.85},0).wait(1).to({rotation:-141.095,x:62.2,y:98.6},0).wait(1).to({rotation:-145.7175,x:65.5,y:98.1},0).wait(1).to({rotation:-149.667,x:68.25,y:97.45},0).wait(1).to({rotation:-153.0773,x:70.65,y:96.8},0).wait(1).to({rotation:-156.0464,x:72.6,y:96.1},0).wait(1).to({rotation:-158.6477,x:74.3,y:95.4},0).wait(1).to({rotation:-160.9377,x:75.8,y:94.7},0).wait(1).to({rotation:-162.9604,x:77.05,y:94.05},0).wait(1).to({rotation:-164.7513,x:78.2,y:93.4},0).wait(1).to({rotation:-166.3388,x:79.15,y:92.8},0).wait(1).to({rotation:-167.7463,x:80,y:92.3},0).wait(1).to({rotation:-168.9936,x:80.8,y:91.85},0).wait(1).to({rotation:-170.0968,x:81.45,y:91.4},0).wait(1).to({rotation:-171.0701,x:82,y:90.95},0).wait(1).to({rotation:-171.9252,x:82.45,y:90.65},0).wait(1).to({rotation:-172.6727,x:82.9,y:90.3},0).wait(1).to({rotation:-173.3213,x:83.25,y:90},0).wait(1).to({regX:57.9,regY:57.9,rotation:-173.879,x:57.85,y:57.95},0).wait(1).to({regX:28.9,regY:29,rotation:-173.9985,x:83.7,y:89.65},0).wait(1).to({rotation:-174.0984,x:83.75,y:89.6},0).wait(1).to({rotation:-174.1799,x:83.8,y:89.55},0).wait(1).to({rotation:-174.2445,x:83.85},0).wait(1).to({rotation:-174.2931,x:83.9},0).wait(1).to({rotation:-174.3267,y:89.5},0).wait(1).to({rotation:-174.3463},0).wait(1).to({regX:57.7,regY:57.8,rotation:-174.3527,x:58,y:57.95},0).wait(1));

	// Layer_2
	this.instance_1 = new lib.circleSegment();
	this.instance_1.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:28.9,regY:29,rotation:-0.0144,x:28.9,y:29},0).wait(1).to({rotation:-0.059},0).wait(1).to({rotation:-0.1357,x:28.85,y:29.05},0).wait(1).to({rotation:-0.247,x:28.8,y:29.1},0).wait(1).to({rotation:-0.3955,x:28.75,y:29.2},0).wait(1).to({rotation:-0.584,x:28.65,y:29.25},0).wait(1).to({rotation:-0.8159,x:28.5,y:29.4},0).wait(1).to({rotation:-1.0949,x:28.4,y:29.55},0).wait(1).to({rotation:-1.4252,x:28.2,y:29.75},0).wait(1).to({rotation:-1.8118,x:28,y:29.95},0).wait(1).to({rotation:-2.2604,x:27.85,y:30.15},0).wait(1).to({rotation:-2.7775,x:27.55,y:30.4},0).wait(1).to({rotation:-3.371,x:27.25,y:30.75},0).wait(1).to({rotation:-4.05,x:27,y:31.1},0).wait(1).to({rotation:-4.8258,x:26.6,y:31.5},0).wait(1).to({rotation:-5.7118,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7245,x:25.75,y:32.55},0).wait(1).to({rotation:-7.8849,x:25.3,y:33.25},0).wait(1).to({rotation:-9.2193,x:24.7,y:34},0).wait(1).to({rotation:-10.7621,x:24.05,y:34.9},0).wait(1).to({rotation:-12.559,x:23.35,y:35.95},0).wait(1).to({rotation:-14.6721,x:22.55,y:37.25},0).wait(1).to({rotation:-17.1885,x:21.65,y:38.8},0).wait(1).to({rotation:-20.2327,x:20.75,y:40.75},0).wait(1).to({rotation:-23.985,x:19.7,y:43.25},0).wait(1).to({rotation:-28.6927,x:18.6,y:46.45},0).wait(1).to({rotation:-34.6055,x:17.65,y:50.5},0).wait(1).to({rotation:-41.622,x:17.05,y:55.5},0).wait(1).to({rotation:-48.8041,x:17.1,y:60.6},0).wait(1).to({rotation:-55.0577,x:17.6,y:65.05},0).wait(1).to({rotation:-60.1032,x:18.45,y:68.55},0).wait(1).to({rotation:-64.1439,x:19.3,y:71.3},0).wait(1).to({rotation:-67.4317,x:20.15,y:73.5},0).wait(1).to({rotation:-70.1581,x:20.95,y:75.3},0).wait(1).to({rotation:-72.4565,x:21.65,y:76.75},0).wait(1).to({rotation:-74.4204,x:22.3,y:78},0).wait(1).to({rotation:-76.1161,x:22.95,y:79.05},0).wait(1).to({rotation:-77.5925,x:23.45,y:79.95},0).wait(1).to({rotation:-78.886,x:23.95,y:80.7},0).wait(1).to({rotation:-80.0246,x:24.45,y:81.35},0).wait(1).to({rotation:-81.0304,x:24.85,y:81.95},0).wait(1).to({rotation:-81.9209,x:25.25,y:82.5},0).wait(1).to({rotation:-82.7103,x:25.55,y:82.95},0).wait(1).to({rotation:-83.4102,x:25.9,y:83.35},0).wait(1).to({rotation:-84.0303,x:26.2,y:83.65},0).wait(1).to({rotation:-84.5789,x:26.45,y:84},0).wait(1).to({rotation:-85.0629,x:26.65,y:84.2},0).wait(1).to({rotation:-85.4881,x:26.8,y:84.5},0).wait(1).to({rotation:-85.8597,x:27,y:84.7},0).wait(1).to({rotation:-86.1822,x:27.15,y:84.85},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.4596,x:57.95,y:57.85},0).wait(1).to({regX:28.9,regY:29,rotation:-86.5188,x:27.35,y:85},0).wait(1).to({rotation:-86.5683,y:85.05},0).wait(1).to({rotation:-86.6087},0).wait(1).to({rotation:-86.6407,x:27.4},0).wait(1).to({rotation:-86.6647,y:85.1},0).wait(1).to({rotation:-86.6814,x:27.35},0).wait(1).to({rotation:-86.6911,y:85.05},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.6943,x:57.9,y:57.85},0).wait(1));

	// Layer_1
	this.instance_2 = new lib.circleSegment();
	this.instance_2.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-5.8,127.5,127.5);


(lib.girlrigthcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon, new cjs.Rectangle(-0.1,-0.2,51,43), null);


(lib.girlleftcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution, new cjs.Rectangle(0.1,-0.2,89,65), null);


(lib.excel_screen_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.white.cache(0,0,460,310,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.white = new lib.excel_screen_white_sub();
	this.white.name = "white";
	this.white.setTransform(225.3,151.3,1,1,0,0,0,225.3,151.3);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.shadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// a
	this.tablet_shadow_1 = new lib.tablet_shadow_vector();
	this.tablet_shadow_1.name = "tablet_shadow_1";
	this.tablet_shadow_1.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_2, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_124 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(124).call(this.frame_124).wait(1));

	// Icon
	this.instance = new lib.Icon();
	this.instance.setTransform(63.7,114.6,0.4734,0.4734,0,0,0,50.1,50.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({scaleX:0.6241,scaleY:0.6241,x:84.95,y:155.95},30,cjs.Ease.cubicInOut).wait(6));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(86.7,98.25,0.542,0.5022,0,-29.3001,-16.7953,58.8,15.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regY:15.2,scaleX:0.7146,scaleY:0.6621,skewX:-29.3006,skewY:-16.797,x:115.3,y:134.35,startPosition:104},30,cjs.Ease.cubicInOut).wait(6));

	// Shadow
	this.instance_2 = new lib.shadow_2();
	this.instance_2.setTransform(143.15,116.6,0.6,0.6,0,0,0,176.9,127.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(89).to({regX:176.8,regY:127.6,x:143.1,y:116.55},0).to({scaleX:0.75,scaleY:0.75,x:187.85,y:165.15},30,cjs.Ease.cubicInOut).wait(6));

	// Layer_2
	this.ribbon = new lib.ribboncopy();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-15.7,-5.25,1,1,0,0,0,-0.1,-0.1);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,355,284.3);


(lib.chart_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.circle_shadow.cache(0,0,260,260);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_5
	this.circle_shadow = new lib.circle_shadow();
	this.circle_shadow.name = "circle_shadow";
	this.circle_shadow.setTransform(227.55,275.55,1,1,0,0,0,128.5,128.5);
	this.circle_shadow.alpha = 0.1484;

	this.timeline.addTween(cjs.Tween.get(this.circle_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_shadow, new cjs.Rectangle(0,0,420,420), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._3D_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{grow:1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		exportRoot.mainMC.page.obj1.screen.screen.gotoAndPlay("vanish");
	}
	this.frame_37 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(36).call(this.frame_37).wait(1));

	// percentage
	this.percantage = new lib.percantage();
	this.percantage.name = "percantage";
	this.percantage.setTransform(-43.15,-17.45,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.percantage.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.percantage).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-43.05,y:-17.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:247.2,regY:218.9,scaleX:0.6925,scaleY:0.6708,skewY:-4.1654,x:-16.5,y:-14.55},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1122,x:-15.15,y:-16},0).wait(1).to({scaleX:0.7169,scaleY:0.6939,skewY:-4.045,x:-13.5,y:-17.95},0).wait(1).to({scaleX:0.7333,scaleY:0.7094,skewY:-3.9642,x:-11.4,y:-20.2},0).wait(1).to({scaleX:0.7524,scaleY:0.7275,skewY:-3.8698,x:-9.1,y:-22.85},0).wait(1).to({scaleX:0.7742,scaleY:0.7481,skewY:-3.7625,x:-6.35,y:-25.85},0).wait(1).to({scaleX:0.7985,scaleY:0.7711,skewY:-3.6427,x:-3.35,y:-29.2},0).wait(1).to({scaleX:0.8252,scaleY:0.7964,skewY:-3.5111,x:-0.05,y:-32.85},0).wait(1).to({scaleX:0.8541,scaleY:0.8237,skewY:-3.3686,x:3.55,y:-36.85},0).wait(1).to({scaleX:0.885,scaleY:0.853,skewY:-3.2162,x:7.35,y:-41.1},0).wait(1).to({scaleX:0.9177,scaleY:0.8839,skewY:-3.0551,x:11.4,y:-45.6},0).wait(1).to({scaleX:0.9518,scaleY:0.9162,skewY:-2.8865,x:15.65,y:-50.3},0).wait(1).to({scaleX:0.9872,scaleY:0.9497,skewY:-2.7119,x:20.05,y:-55.15},0).wait(1).to({scaleX:1.0236,scaleY:0.9841,skewY:-2.5328,x:24.55,y:-60.15},0).wait(1).to({scaleX:1.0605,scaleY:1.019,skewY:-2.3508,x:29.15,y:-65.15},0).wait(1).to({scaleX:1.0977,scaleY:1.0542,skewY:-2.1675,x:33.75,y:-70.2},0).wait(1).to({scaleX:1.1348,scaleY:1.0893,skewY:-1.9845,x:38.35,y:-75.25},0).wait(1).to({scaleX:1.1715,scaleY:1.1241,skewY:-1.8033,x:42.9,y:-80.2},0).wait(1).to({scaleX:1.2076,scaleY:1.1582,skewY:-1.6255,x:47.4,y:-85.05},0).wait(1).to({scaleX:1.2427,scaleY:1.1914,skewY:-1.4525,x:51.75,y:-89.85},0).wait(1).to({scaleX:1.2765,scaleY:1.2234,skewY:-1.2856,x:55.9,y:-94.45},0).wait(1).to({scaleX:1.3089,scaleY:1.254,skewY:-1.126,x:59.95,y:-98.8},0).wait(1).to({scaleX:1.3395,scaleY:1.2831,skewY:-0.9748,x:63.75,y:-102.95},0).wait(1).to({scaleX:1.3683,scaleY:1.3103,skewY:-0.8327,x:67.3,y:-106.75},0).wait(1).to({scaleX:1.3952,scaleY:1.3357,skewY:-0.7006,x:70.6,y:-110.35},0).wait(1).to({scaleX:1.4198,scaleY:1.359,skewY:-0.5791,x:73.65,y:-113.65},0).wait(1).to({scaleX:1.4422,scaleY:1.3802,skewY:-0.4686,x:76.45,y:-116.7},0).wait(1).to({scaleX:1.4623,scaleY:1.3992,skewY:-0.3696,x:78.9,y:-119.35},0).wait(1).to({scaleX:1.48,scaleY:1.416,skewY:-0.2821,x:81.15,y:-121.75},0).wait(1).to({scaleX:1.4953,scaleY:1.4305,skewY:-0.2065,x:83.05,y:-123.8},0).wait(1).to({scaleX:1.5083,scaleY:1.4427,skewY:-0.1428,x:84.65,y:-125.55},0).wait(1).to({scaleX:1.5188,scaleY:1.4527,skewY:-0.0909,x:85.95,y:-126.9},0).wait(1).to({scaleX:1.5269,scaleY:1.4604,skewY:-0.0509,x:86.95,y:-128.05},0).wait(1).to({scaleX:1.5327,scaleY:1.4658,skewY:0,x:87.65,y:-128.8},0).wait(1).to({scaleX:1.5361,scaleY:1.4691,x:88.05,y:-129.25},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:30.7,y:-142.9},0).wait(1));

	// Big
	this.b_pie = new lib.big_pie();
	this.b_pie.name = "b_pie";
	this.b_pie.setTransform(-38.8,-25.9,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.b_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.b_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-38.7,y:-26.1,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:241.1,regY:237.8,scaleX:0.6924,scaleY:0.6707,skewY:-4.1658,x:-16.4,y:-9.95},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1121,x:-15.15,y:-11.1},0).wait(1).to({scaleX:0.7173,scaleY:0.6943,skewY:-4.0428,x:-13.55,y:-12.7},0).wait(1).to({scaleX:0.7347,scaleY:0.7108,skewY:-3.9571,x:-11.55,y:-14.6},0).wait(1).to({scaleX:0.7555,scaleY:0.7305,skewY:-3.8546,x:-9.15,y:-16.9},0).wait(1).to({scaleX:0.7798,scaleY:0.7534,skewY:-3.735,x:-6.4,y:-19.6},0).wait(1).to({scaleX:0.8075,scaleY:0.7796,skewY:-3.5984,x:-3.25,y:-22.6},0).wait(1).to({scaleX:0.8385,scaleY:0.809,skewY:-3.4452,x:0.3,y:-26.05},0).wait(1).to({scaleX:0.8727,scaleY:0.8414,skewY:-3.2766,x:4.2,y:-29.85},0).wait(1).to({scaleX:0.9097,scaleY:0.8764,skewY:-3.0943,x:8.45,y:-33.9},0).wait(1).to({scaleX:0.949,scaleY:0.9136,skewY:-2.9004,x:12.9,y:-38.2},0).wait(1).to({scaleX:0.9901,scaleY:0.9524,skewY:-2.6979,x:17.65,y:-42.65},0).wait(1).to({scaleX:1.0323,scaleY:0.9923,skewY:-2.4899,x:22.45,y:-47.3},0).wait(1).to({scaleX:1.0749,scaleY:1.0327,skewY:-2.2798,x:27.3,y:-51.9},0).wait(1).to({scaleX:1.1173,scaleY:1.0727,skewY:-2.0709,x:32.15,y:-56.5},0).wait(1).to({scaleX:1.1587,scaleY:1.112,skewY:-1.8662,x:36.85,y:-61},0).wait(1).to({scaleX:1.1988,scaleY:1.15,skewY:-1.6685,x:41.45,y:-65.35},0).wait(1).to({scaleX:1.2371,scaleY:1.1862,skewY:-1.4798,x:45.85,y:-69.5},0).wait(1).to({scaleX:1.2733,scaleY:1.2203,skewY:-1.3016,x:49.95,y:-73.35},0).wait(1).to({scaleX:1.307,scaleY:1.2523,skewY:-1.1352,x:53.8,y:-77},0).wait(1).to({scaleX:1.3383,scaleY:1.2819,skewY:-0.981,x:57.4,y:-80.3},0).wait(1).to({scaleX:1.367,scaleY:1.309,skewY:-0.8395,x:60.7,y:-83.45},0).wait(1).to({scaleX:1.3931,scaleY:1.3338,skewY:-0.7105,x:63.65,y:-86.25},0).wait(1).to({scaleX:1.4168,scaleY:1.3561,skewY:-0.594,x:66.35,y:-88.75},0).wait(1).to({scaleX:1.438,scaleY:1.3762,skewY:-0.4895,x:68.75,y:-91},0).wait(1).to({scaleX:1.4568,scaleY:1.394,skewY:-0.3967,x:70.9,y:-93.05},0).wait(1).to({scaleX:1.4733,scaleY:1.4097,skewY:-0.3151,x:72.8,y:-94.8},0).wait(1).to({scaleX:1.4877,scaleY:1.4233,skewY:-0.2441,x:74.5,y:-96.35},0).wait(1).to({scaleX:1.5001,scaleY:1.435,skewY:-0.1833,x:75.85,y:-97.6},0).wait(1).to({scaleX:1.5105,scaleY:1.4448,skewY:-0.1321,x:77.05,y:-98.75},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.09,x:78,y:-99.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0565,x:78.8,y:-100.35},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:79.4,y:-100.95},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:79.8,y:-101.35},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:80.05,y:-101.5},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:32.05,y:-142.9},0).wait(1));

	// Small
	this.s_pie = new lib.small_pie();
	this.s_pie.name = "s_pie";
	this.s_pie.setTransform(-40.3,-18.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.s_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.s_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-40.2,y:-18.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:269.2,regY:169.2,scaleX:0.6927,scaleY:0.6711,skewY:-4.1641,x:1.55,y:-50.05},0).wait(1).to({scaleX:0.7048,scaleY:0.6824,skewY:-4.1049,x:3.3,y:-52.3},0).wait(1).to({scaleX:0.7213,scaleY:0.6981,skewY:-4.0234,x:5.65,y:-55.3},0).wait(1).to({scaleX:0.7432,scaleY:0.7188,skewY:-3.9155,x:8.75,y:-59.4},0).wait(1).to({scaleX:0.7714,scaleY:0.7455,skewY:-3.7762,x:12.75,y:-64.6},0).wait(1).to({scaleX:0.8071,scaleY:0.7792,skewY:-3.6003,x:17.85,y:-71.2},0).wait(1).to({scaleX:0.8509,scaleY:0.8207,skewY:-3.3844,x:24.05,y:-79.25},0).wait(1).to({scaleX:0.9026,scaleY:0.8697,skewY:-3.1291,x:31.4,y:-88.75},0).wait(1).to({scaleX:0.9607,scaleY:0.9247,skewY:-2.8425,x:39.7,y:-99.4},0).wait(1).to({scaleX:1.0219,scaleY:0.9825,skewY:-2.541,x:48.4,y:-110.6},0).wait(1).to({scaleX:1.0823,scaleY:1.0396,skewY:-2.2435,x:57,y:-121.55},0).wait(1).to({scaleX:1.1388,scaleY:1.0931,skewY:-1.9646,x:65.05,y:-131.85},0).wait(1).to({scaleX:1.1901,scaleY:1.1416,skewY:-1.7118,x:72.3,y:-141.1},0).wait(1).to({scaleX:1.2357,scaleY:1.1848,skewY:-1.4869,x:78.85,y:-149.35},0).wait(1).to({scaleX:1.2759,scaleY:1.2229,skewY:-1.2886,x:84.55,y:-156.55},0).wait(1).to({scaleX:1.3113,scaleY:1.2563,skewY:-1.1142,x:89.55,y:-162.9},0).wait(1).to({scaleX:1.3423,scaleY:1.2857,skewY:-0.961,x:94,y:-168.45},0).wait(1).to({scaleX:1.3697,scaleY:1.3116,skewY:-0.8262,x:97.85,y:-173.35},0).wait(1).to({scaleX:1.3937,scaleY:1.3343,skewY:-0.7076,x:101.3,y:-177.7},0).wait(1).to({scaleX:1.4149,scaleY:1.3544,skewY:-0.603,x:104.3,y:-181.45},0).wait(1).to({scaleX:1.4336,scaleY:1.3721,skewY:-0.5109,x:106.95,y:-184.8},0).wait(1).to({scaleX:1.4501,scaleY:1.3876,skewY:-0.4298,x:109.35,y:-187.65},0).wait(1).to({scaleX:1.4646,scaleY:1.4013,skewY:-0.3585,x:111.4,y:-190.25},0).wait(1).to({scaleX:1.4772,scaleY:1.4134,skewY:-0.2959,x:113.2,y:-192.5},0).wait(1).to({scaleX:1.4883,scaleY:1.4238,skewY:-0.2411,x:114.75,y:-194.5},0).wait(1).to({scaleX:1.498,scaleY:1.433,skewY:-0.1936,x:116.15,y:-196.2},0).wait(1).to({scaleX:1.5063,scaleY:1.4409,skewY:-0.1524,x:117.35,y:-197.7},0).wait(1).to({scaleX:1.5135,scaleY:1.4476,skewY:-0.1172,x:118.3,y:-198.95},0).wait(1).to({scaleX:1.5195,scaleY:1.4533,skewY:-0.0874,x:119.2,y:-200},0).wait(1).to({scaleX:1.5245,scaleY:1.4581,skewY:-0.0627,x:119.9,y:-200.9},0).wait(1).to({scaleX:1.5286,scaleY:1.462,skewY:0,x:120.5,y:-201.65},0).wait(1).to({scaleX:1.5318,scaleY:1.465,x:120.95,y:-202.2},0).wait(1).to({scaleX:1.5343,scaleY:1.4673,x:121.25,y:-202.65},0).wait(1).to({scaleX:1.5359,scaleY:1.4689,x:121.5,y:-202.9},0).wait(1).to({scaleX:1.5369,scaleY:1.4698,x:121.7,y:-203.1},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.45,y:-143.4},0).wait(1));

	// Shadow
	this.c_shadow = new lib.chart_shadow();
	this.c_shadow.name = "c_shadow";
	this.c_shadow.setTransform(-26.45,-49.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.c_shadow.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.c_shadow).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,y:-49.55},1,cjs.Ease.cubicInOut).wait(1).to({regX:227.6,regY:275.6,scaleX:0.6926,scaleY:0.6709,skewY:-4.165,x:-13.6,y:-7.15,alpha:0.0512},0).wait(1).to({scaleX:0.7037,scaleY:0.6815,skewY:-4.1099,x:-12.65,y:-7.75,alpha:0.1221},0).wait(1).to({scaleX:0.7181,scaleY:0.6951,skewY:-4.0387,x:-11.45,y:-8.4,alpha:0.2138},0).wait(1).to({scaleX:0.7359,scaleY:0.7119,skewY:-3.9508,x:-9.95,y:-9.3,alpha:0.327},0).wait(1).to({scaleX:0.7572,scaleY:0.7321,skewY:-3.8458,x:-8.15,y:-10.35,alpha:0.4622},0).wait(1).to({scaleX:0.782,scaleY:0.7555,skewY:-3.7235,x:-6.1,y:-11.55,alpha:0.6198},0).wait(1).to({scaleX:0.8102,scaleY:0.7823,skewY:-3.5841,x:-3.7,y:-12.95,alpha:0.7993},0).wait(1).to({regX:209.8,regY:209.8,scaleX:0.8418,scaleY:0.8121,skewY:-3.4282,x:-16,y:-66.95,alpha:1},0).wait(1).to({regX:227.6,regY:275.6,scaleX:0.8765,scaleY:0.8449,skewY:-3.2574,x:1.9,y:-16.1},0).wait(1).to({scaleX:0.9138,scaleY:0.8803,skewY:-3.0733,x:5.05,y:-17.9},0).wait(1).to({scaleX:0.9534,scaleY:0.9177,skewY:-2.8783,x:8.35,y:-19.8},0).wait(1).to({scaleX:0.9945,scaleY:0.9566,skewY:-2.6753,x:11.85,y:-21.8},0).wait(1).to({scaleX:1.0367,scaleY:0.9965,skewY:-2.4676,x:15.45,y:-23.8},0).wait(1).to({scaleX:1.0791,scaleY:1.0367,skewY:-2.2583,x:18.95,y:-25.9},0).wait(1).to({scaleX:1.1212,scaleY:1.0765,skewY:-2.0509,x:22.5,y:-27.85},0).wait(1).to({scaleX:1.1623,scaleY:1.1154,skewY:-1.8481,x:26,y:-29.85},0).wait(1).to({scaleX:1.2021,scaleY:1.153,skewY:-1.6524,x:29.35,y:-31.7},0).wait(1).to({scaleX:1.2399,scaleY:1.1888,skewY:-1.4658,x:32.55,y:-33.45},0).wait(1).to({scaleX:1.2756,scaleY:1.2226,skewY:-1.2898,x:35.55,y:-35.2},0).wait(1).to({scaleX:1.309,scaleY:1.2541,skewY:-1.1253,x:38.35,y:-36.75},0).wait(1).to({scaleX:1.3399,scaleY:1.2834,skewY:-0.973,x:40.95,y:-38.25},0).wait(1).to({scaleX:1.3682,scaleY:1.3102,skewY:-0.8331,x:43.4,y:-39.55},0).wait(1).to({scaleX:1.3941,scaleY:1.3347,skewY:-0.7055,x:45.5,y:-40.75},0).wait(1).to({scaleX:1.4175,scaleY:1.3569,skewY:-0.5901,x:47.5,y:-41.85},0).wait(1).to({scaleX:1.4385,scaleY:1.3767,skewY:-0.4866,x:49.3,y:-42.9},0).wait(1).to({scaleX:1.4572,scaleY:1.3944,skewY:-0.3946,x:50.85,y:-43.7},0).wait(1).to({scaleX:1.4736,scaleY:1.4099,skewY:-0.3136,x:52.25,y:-44.45},0).wait(1).to({scaleX:1.4879,scaleY:1.4235,skewY:-0.2431,x:53.45,y:-45.15},0).wait(1).to({scaleX:1.5002,scaleY:1.4351,skewY:-0.1826,x:54.5,y:-45.75},0).wait(1).to({scaleX:1.5105,scaleY:1.4449,skewY:-0.1317,x:55.35,y:-46.2},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.0897,x:56.05,y:-46.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0564,x:56.6,y:-46.9},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:57.1,y:-47.15},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:57.35,y:-47.3},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:57.5,y:-47.4},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.2,y:-144.25},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140,-257.9,395.1,399.29999999999995);


(lib.UI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.mainUI.cache(-475,-300,950,600,0.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Main_UI
	this.mainUI = new lib.main_ui();
	this.mainUI.name = "mainUI";

	this.timeline.addTween(cjs.Tween.get(this.mainUI).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.screenanimation_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_172 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(172).call(this.frame_172).wait(1));

	// guy right icon.png
	this.instance_3 = new lib.guyrighticon();
	this.instance_3.setTransform(198.85,-85.15,1,1,0,0,0,26.4,21.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({_off:false},0).to({x:171.9,y:-0.1,alpha:1},36,cjs.Ease.quadOut).wait(1).to({regX:26.5,regY:21.4,x:172,y:-0.2},0).wait(23).to({regX:26.4,regY:21.5,x:171.9,y:-0.1},0).wait(1).to({regX:26.5,regY:21.4,scaleX:0.9982,scaleY:0.9982,x:172.85,y:0.75},0).wait(1).to({scaleX:0.9956,scaleY:0.9956,x:174.1,y:2.15},0).wait(1).to({scaleX:0.9922,scaleY:0.9922,x:175.75,y:3.95},0).wait(1).to({scaleX:0.988,scaleY:0.988,x:177.75,y:6.15},0).wait(1).to({scaleX:0.983,scaleY:0.983,x:180.2,y:8.85},0).wait(1).to({scaleX:0.9771,scaleY:0.9771,x:183.05,y:11.9},0).wait(1).to({scaleX:0.9704,scaleY:0.9704,x:186.25,y:15.45},0).wait(1).to({scaleX:0.963,scaleY:0.963,x:189.85,y:19.4},0).wait(1).to({scaleX:0.9548,scaleY:0.9548,x:193.8,y:23.7},0).wait(1).to({scaleX:0.9461,scaleY:0.9461,x:197.95,y:28.3},0).wait(1).to({scaleX:0.9369,scaleY:0.9369,x:202.45,y:33.15},0).wait(1).to({scaleX:0.9274,scaleY:0.9274,x:207.05,y:38.15},0).wait(1).to({scaleX:0.9178,scaleY:0.9178,x:211.65,y:43.25},0).wait(1).to({scaleX:0.9083,scaleY:0.9083,x:216.25,y:48.3},0).wait(1).to({scaleX:0.899,scaleY:0.899,x:220.75,y:53.25},0).wait(1).to({scaleX:0.8901,scaleY:0.8901,x:225.05,y:57.95},0).wait(1).to({scaleX:0.8817,scaleY:0.8817,x:229.1,y:62.35},0).wait(1).to({scaleX:0.8739,scaleY:0.8739,x:232.85,y:66.45},0).wait(1).to({scaleX:0.8669,scaleY:0.8669,x:236.2,y:70.2},0).wait(1).to({scaleX:0.8607,scaleY:0.8607,x:239.25,y:73.45},0).wait(1).to({scaleX:0.8552,scaleY:0.8552,x:241.85,y:76.35},0).wait(1).to({scaleX:0.8505,scaleY:0.8505,x:244.15,y:78.85},0).wait(1).to({scaleX:0.8467,scaleY:0.8467,x:246,y:80.85},0).wait(1).to({scaleX:0.8436,scaleY:0.8436,x:247.5,y:82.5},0).wait(1).to({scaleX:0.8412,scaleY:0.8412,x:248.65,y:83.75},0).wait(1).to({scaleX:0.8396,scaleY:0.8396,x:249.4,y:84.6},0).wait(1).to({scaleX:0.8386,scaleY:0.8386,x:249.85,y:85.15},0).wait(1).to({regX:26.4,regY:21.6,scaleX:0.8383,scaleY:0.8383,x:249.95,y:85.45},0).wait(1).to({regX:26.5,regY:21.4,x:250,y:85.3},0).wait(8).to({regX:26.4,regY:21.6,x:249.95,y:85.45},0).wait(1).to({regX:26.5,regY:21.4,scaleX:0.8381,scaleY:0.8381,x:250,y:85.25},0).wait(1).to({scaleX:0.8378,scaleY:0.8378},0).wait(1).to({scaleX:0.8372,scaleY:0.8372,x:250.05,y:85.15},0).wait(1).to({scaleX:0.8365,scaleY:0.8365,y:85.1},0).wait(1).to({scaleX:0.8355,scaleY:0.8355,x:250.1,y:85},0).wait(1).to({scaleX:0.8343,scaleY:0.8343,y:84.85},0).wait(1).to({scaleX:0.8328,scaleY:0.8328,x:250.15,y:84.7},0).wait(1).to({scaleX:0.831,scaleY:0.831,x:250.2,y:84.55},0).wait(1).to({scaleX:0.8289,scaleY:0.8289,x:250.3,y:84.3},0).wait(1).to({scaleX:0.8263,scaleY:0.8263,x:250.4,y:84.05},0).wait(1).to({scaleX:0.8233,scaleY:0.8233,x:250.5,y:83.7},0).wait(1).to({scaleX:0.8198,scaleY:0.8198,x:250.6,y:83.35},0).wait(1).to({scaleX:0.8155,scaleY:0.8155,x:250.8,y:82.9},0).wait(1).to({scaleX:0.8105,scaleY:0.8105,x:251,y:82.4},0).wait(1).to({scaleX:0.8045,scaleY:0.8045,x:251.15,y:81.75},0).wait(1).to({scaleX:0.7972,scaleY:0.7972,x:251.4,y:81},0).wait(1).to({scaleX:0.7882,scaleY:0.7882,x:251.75,y:80.1},0).wait(1).to({scaleX:0.7769,scaleY:0.7769,x:252.15,y:78.95},0).wait(1).to({scaleX:0.7624,scaleY:0.7624,x:252.65,y:77.45},0).wait(1).to({scaleX:0.743,scaleY:0.743,x:253.35,y:75.45},0).wait(1).to({scaleX:0.7175,scaleY:0.7175,x:254.25,y:72.85},0).wait(1).to({scaleX:0.6882,scaleY:0.6882,x:255.3,y:69.85},0).wait(1).to({scaleX:0.662,scaleY:0.662,x:256.2,y:67.1},0).wait(1).to({scaleX:0.642,scaleY:0.642,x:256.9,y:65.1},0).wait(1).to({scaleX:0.6268,scaleY:0.6268,x:257.45,y:63.5},0).wait(1).to({scaleX:0.615,scaleY:0.615,x:257.85,y:62.25},0).wait(1).to({scaleX:0.6055,scaleY:0.6055,x:258.2,y:61.3},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:258.5,y:60.5},0).wait(1).to({scaleX:0.5912,scaleY:0.5912,x:258.7,y:59.85},0).wait(1).to({scaleX:0.5857,scaleY:0.5857,x:258.85,y:59.3},0).wait(1).to({scaleX:0.581,scaleY:0.581,x:259.05,y:58.8},0).wait(1).to({scaleX:0.577,scaleY:0.577,x:259.2,y:58.4},0).wait(1).to({scaleX:0.5736,scaleY:0.5736,x:259.3,y:58.05},0).wait(1).to({scaleX:0.5707,scaleY:0.5707,x:259.4,y:57.7},0).wait(1).to({scaleX:0.5682,scaleY:0.5682,x:259.5,y:57.45},0).wait(1).to({scaleX:0.566,scaleY:0.566,x:259.6,y:57.25},0).wait(1).to({scaleX:0.5642,scaleY:0.5642,x:259.65,y:57.05},0).wait(1).to({scaleX:0.5626,scaleY:0.5626,x:259.7,y:56.9},0).wait(1).to({scaleX:0.5613,scaleY:0.5613,y:56.75},0).wait(1).to({scaleX:0.5602,scaleY:0.5602,x:259.8,y:56.65},0).wait(1).to({scaleX:0.5594,scaleY:0.5594,y:56.55},0).wait(1).to({scaleX:0.5587,scaleY:0.5587,x:259.85,y:56.5},0).wait(1).to({scaleX:0.5582,scaleY:0.5582,y:56.45},0).wait(1).to({scaleX:0.5579,scaleY:0.5579,x:259.9,y:56.4},0).wait(1).to({scaleX:0.5577,scaleY:0.5577},0).wait(1).to({regX:26.4,regY:21.5,scaleX:0.5576,scaleY:0.5576,x:259.8,y:56.5},0).wait(1));

	// guy left icon.png
	this.instance_4 = new lib.guylefticon();
	this.instance_4.setTransform(-108.15,55.1,1,1,0,0,0,25.9,20.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({x:46.95,y:17.4,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:26.1,regY:20.6,x:47.15,y:17.6},0).wait(22).to({regX:25.9,regY:20.4,x:46.95,y:17.4},0).wait(1).to({regX:26.1,regY:20.6,scaleX:0.9962,scaleY:0.9962,x:48.9,y:18.55},0).wait(1).to({scaleX:0.9912,scaleY:0.9912,x:51.2,y:19.9},0).wait(1).to({scaleX:0.9848,scaleY:0.9848,x:54.25,y:21.5},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:57.9,y:23.55},0).wait(1).to({scaleX:0.9677,scaleY:0.9677,x:62.2,y:25.9},0).wait(1).to({scaleX:0.9569,scaleY:0.9569,x:67.3,y:28.7},0).wait(1).to({scaleX:0.9444,scaleY:0.9444,x:73.1,y:31.9},0).wait(1).to({scaleX:0.9304,scaleY:0.9304,x:79.7,y:35.5},0).wait(1).to({scaleX:0.9147,scaleY:0.9147,x:87,y:39.55},0).wait(1).to({scaleX:0.8976,scaleY:0.8976,x:95.05,y:44},0).wait(1).to({scaleX:0.879,scaleY:0.879,x:103.7,y:48.75},0).wait(1).to({scaleX:0.8593,scaleY:0.8593,x:112.95,y:53.85},0).wait(1).to({scaleX:0.8386,scaleY:0.8386,x:122.6,y:59.15},0).wait(1).to({scaleX:0.8173,scaleY:0.8173,x:132.55,y:64.65},0).wait(1).to({scaleX:0.7959,scaleY:0.7959,x:142.5,y:70.2},0).wait(1).to({scaleX:0.7747,scaleY:0.7747,x:152.45,y:75.65},0).wait(1).to({scaleX:0.7542,scaleY:0.7542,x:162.1,y:80.95},0).wait(1).to({scaleX:0.7346,scaleY:0.7346,x:171.2,y:86},0).wait(1).to({scaleX:0.7163,scaleY:0.7163,x:179.75,y:90.7},0).wait(1).to({scaleX:0.6996,scaleY:0.6996,x:187.55,y:95},0).wait(1).to({scaleX:0.6845,scaleY:0.6845,x:194.6,y:98.9},0).wait(1).to({scaleX:0.6712,scaleY:0.6712,x:200.8,y:102.35},0).wait(1).to({scaleX:0.6598,scaleY:0.6598,x:206.2,y:105.3},0).wait(1).to({scaleX:0.65,scaleY:0.65,x:210.75,y:107.8},0).wait(1).to({scaleX:0.642,scaleY:0.642,x:214.5,y:109.85},0).wait(1).to({scaleX:0.6357,scaleY:0.6357,x:217.5,y:111.5},0).wait(1).to({scaleX:0.6309,scaleY:0.6309,x:219.7,y:112.75},0).wait(1).to({scaleX:0.6275,scaleY:0.6275,x:221.3,y:113.6},0).wait(1).to({scaleX:0.6256,scaleY:0.6256,x:222.2,y:114.1},0).wait(1).to({regX:26,regY:20.5,scaleX:0.625,scaleY:0.625,x:222.35,y:114.15},0).wait(1).to({regX:26.1,regY:20.6,x:222.4,y:114.25},0).wait(6).to({regX:26,regY:20.5,x:222.35,y:114.15},0).wait(1).to({regX:26.1,regY:20.6,x:222.4,y:114.25},0).wait(1).to({regX:26,regY:20.5,x:222.35,y:114.15},0).wait(1).to({regX:26.1,regY:20.6},0).wait(1).to({scaleX:0.6249,scaleY:0.6249,x:222.25,y:114.1},0).wait(1).to({scaleX:0.6248,scaleY:0.6248,x:222.1,y:114},0).wait(1).to({scaleX:0.6246,scaleY:0.6246,x:221.9,y:113.9},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:221.65,y:113.75},0).wait(1).to({scaleX:0.6242,scaleY:0.6242,x:221.35,y:113.55},0).wait(1).to({scaleX:0.6239,scaleY:0.6239,x:220.95,y:113.3},0).wait(1).to({scaleX:0.6235,scaleY:0.6235,x:220.45,y:113},0).wait(1).to({scaleX:0.623,scaleY:0.623,x:219.85,y:112.65},0).wait(1).to({scaleX:0.6224,scaleY:0.6224,x:219.15,y:112.15},0).wait(1).to({scaleX:0.6217,scaleY:0.6217,x:218.25,y:111.65},0).wait(1).to({scaleX:0.6208,scaleY:0.6208,x:217.15,y:110.95},0).wait(1).to({scaleX:0.6198,scaleY:0.6198,x:215.8,y:110.1},0).wait(1).to({scaleX:0.6184,scaleY:0.6184,x:214.1,y:109.05},0).wait(1).to({scaleX:0.6166,scaleY:0.6166,x:211.85,y:107.7},0).wait(1).to({scaleX:0.6143,scaleY:0.6143,x:208.9,y:105.85},0).wait(1).to({scaleX:0.611,scaleY:0.611,x:204.75,y:103.3},0).wait(1).to({scaleX:0.6065,scaleY:0.6065,x:199.1,y:99.8},0).wait(1).to({scaleX:0.6017,scaleY:0.6017,x:192.95,y:96},0).wait(1).to({scaleX:0.5978,scaleY:0.5978,x:188.1,y:93},0).wait(1).to({scaleX:0.5951,scaleY:0.5951,x:184.65,y:90.85},0).wait(1).to({scaleX:0.593,scaleY:0.593,x:182.05,y:89.25},0).wait(1).to({scaleX:0.5914,scaleY:0.5914,x:180.05,y:88.05},0).wait(1).to({scaleX:0.5902,scaleY:0.5902,x:178.45,y:87.05},0).wait(1).to({scaleX:0.5892,scaleY:0.5892,x:177.2,y:86.25},0).wait(1).to({scaleX:0.5883,scaleY:0.5883,x:176.1,y:85.6},0).wait(1).to({scaleX:0.5876,scaleY:0.5876,x:175.25,y:85.05},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:174.5,y:84.6},0).wait(1).to({scaleX:0.5866,scaleY:0.5866,x:173.9,y:84.25},0).wait(1).to({scaleX:0.5862,scaleY:0.5862,x:173.4,y:83.9},0).wait(1).to({scaleX:0.5858,scaleY:0.5858,x:173,y:83.65},0).wait(1).to({scaleX:0.5855,scaleY:0.5855,x:172.65,y:83.4},0).wait(1).to({scaleX:0.5853,scaleY:0.5853,x:172.35,y:83.25},0).wait(1).to({scaleX:0.5851,scaleY:0.5851,x:172.1,y:83.1},0).wait(1).to({scaleX:0.585,scaleY:0.585,x:171.9,y:83},0).wait(1).to({scaleX:0.5849,scaleY:0.5849,x:171.8,y:82.95},0).wait(1).to({scaleX:0.5848,scaleY:0.5848,x:171.7,y:82.85},0).wait(1).to({x:171.65},0).wait(1).to({x:171.6,y:82.8},0).wait(6));

	// girl right icon.png
	this.instance_5 = new lib.girlrighticon();
	this.instance_5.setTransform(188.95,241.45,1,1,0,0,0,25.9,21.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({x:141.6,y:173.75,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:26,x:141.7},0).wait(23).to({regX:25.9,x:141.6},0).wait(1).to({regX:26,scaleX:0.9961,scaleY:0.9961,x:143.65,y:173.9},0).wait(1).to({scaleX:0.9915,scaleY:0.9915,x:145.95,y:174.15},0).wait(1).to({scaleX:0.9862,scaleY:0.9862,x:148.55,y:174.45},0).wait(1).to({scaleX:0.9802,scaleY:0.9802,x:151.55,y:174.7},0).wait(1).to({scaleX:0.9736,scaleY:0.9736,x:154.8,y:175.1},0).wait(1).to({scaleX:0.9662,scaleY:0.9662,x:158.45,y:175.45},0).wait(1).to({scaleX:0.9583,scaleY:0.9583,x:162.4,y:175.85},0).wait(1).to({scaleX:0.9499,scaleY:0.9499,x:166.6,y:176.25},0).wait(1).to({scaleX:0.9409,scaleY:0.9409,x:171.05,y:176.75},0).wait(1).to({scaleX:0.9316,scaleY:0.9316,x:175.65,y:177.25},0).wait(1).to({scaleX:0.922,scaleY:0.922,x:180.45,y:177.7},0).wait(1).to({scaleX:0.9123,scaleY:0.9123,x:185.25,y:178.2},0).wait(1).to({scaleX:0.9026,scaleY:0.9026,x:190.1,y:178.7},0).wait(1).to({scaleX:0.893,scaleY:0.893,x:194.9,y:179.2},0).wait(1).to({scaleX:0.8836,scaleY:0.8836,x:199.55,y:179.7},0).wait(1).to({scaleX:0.8746,scaleY:0.8746,x:204.05,y:180.15},0).wait(1).to({scaleX:0.866,scaleY:0.866,x:208.3,y:180.55},0).wait(1).to({scaleX:0.858,scaleY:0.858,x:212.3,y:181},0).wait(1).to({scaleX:0.8506,scaleY:0.8506,x:215.95,y:181.4},0).wait(1).to({scaleX:0.8438,scaleY:0.8438,x:219.35,y:181.7},0).wait(1).to({scaleX:0.8377,scaleY:0.8377,x:222.4,y:182},0).wait(1).to({scaleX:0.8323,scaleY:0.8323,x:225.05,y:182.3},0).wait(1).to({scaleX:0.8276,scaleY:0.8276,x:227.4,y:182.55},0).wait(1).to({scaleX:0.8236,scaleY:0.8236,x:229.4,y:182.75},0).wait(1).to({scaleX:0.8203,scaleY:0.8203,x:231.05,y:182.95},0).wait(1).to({scaleX:0.8176,scaleY:0.8176,x:232.35,y:183.05},0).wait(1).to({scaleX:0.8156,scaleY:0.8156,x:233.4,y:183.15},0).wait(1).to({scaleX:0.8142,scaleY:0.8142,x:234.1,y:183.25},0).wait(1).to({scaleX:0.8133,scaleY:0.8133,x:234.5,y:183.3},0).wait(1).to({regY:21.6,scaleX:0.813,scaleY:0.813,x:234.6},0).wait(1).to({regY:21.5,y:183.25},0).wait(6).to({regY:21.6,y:183.3},0).wait(1).to({regY:21.5,y:183.25},0).wait(2).to({regY:21.6,y:183.3},0).wait(1).to({regY:21.5,scaleX:0.8129,scaleY:0.8129,x:234.55,y:183.15},0).wait(1).to({scaleX:0.8125,scaleY:0.8125,x:234.45,y:182.95},0).wait(1).to({scaleX:0.8119,scaleY:0.8119,x:234.4,y:182.7},0).wait(1).to({scaleX:0.8111,scaleY:0.8111,x:234.35,y:182.4},0).wait(1).to({scaleX:0.8101,scaleY:0.8101,x:234.15,y:181.95},0).wait(1).to({scaleX:0.8088,scaleY:0.8088,x:234.05,y:181.45},0).wait(1).to({scaleX:0.8072,scaleY:0.8072,x:233.85,y:180.75},0).wait(1).to({scaleX:0.8053,scaleY:0.8053,x:233.6,y:179.9},0).wait(1).to({scaleX:0.8029,scaleY:0.8029,x:233.3,y:178.9},0).wait(1).to({scaleX:0.8001,scaleY:0.8001,x:232.9,y:177.75},0).wait(1).to({scaleX:0.7967,scaleY:0.7967,x:232.45,y:176.35},0).wait(1).to({scaleX:0.7927,scaleY:0.7927,x:231.95,y:174.65},0).wait(1).to({scaleX:0.7878,scaleY:0.7878,x:231.35,y:172.6},0).wait(1).to({scaleX:0.7819,scaleY:0.7819,x:230.6,y:170.1},0).wait(1).to({scaleX:0.7747,scaleY:0.7747,x:229.65,y:167.05},0).wait(1).to({scaleX:0.7657,scaleY:0.7657,x:228.5,y:163.2},0).wait(1).to({scaleX:0.7541,scaleY:0.7541,x:227,y:158.35},0).wait(1).to({scaleX:0.7388,scaleY:0.7388,x:225.05,y:151.95},0).wait(1).to({scaleX:0.718,scaleY:0.718,x:222.35,y:143.15},0).wait(1).to({scaleX:0.6908,scaleY:0.6908,x:218.9,y:131.7},0).wait(1).to({scaleX:0.6625,scaleY:0.6625,x:215.25,y:119.75},0).wait(1).to({scaleX:0.6397,scaleY:0.6397,x:212.35,y:110.15},0).wait(1).to({scaleX:0.6228,scaleY:0.6228,x:210.2,y:103.05},0).wait(1).to({scaleX:0.6101,scaleY:0.6101,x:208.55,y:97.6},0).wait(1).to({scaleX:0.6001,scaleY:0.6001,x:207.25,y:93.4},0).wait(1).to({scaleX:0.592,scaleY:0.592,x:206.25,y:90.05},0).wait(1).to({scaleX:0.5854,scaleY:0.5854,x:205.35,y:87.25},0).wait(1).to({scaleX:0.5799,scaleY:0.5799,x:204.7,y:84.9},0).wait(1).to({scaleX:0.5753,scaleY:0.5753,x:204.1,y:83},0).wait(1).to({scaleX:0.5714,scaleY:0.5714,x:203.6,y:81.35},0).wait(1).to({scaleX:0.5681,scaleY:0.5681,x:203.15,y:79.95},0).wait(1).to({scaleX:0.5653,scaleY:0.5653,x:202.8,y:78.75},0).wait(1).to({scaleX:0.5629,scaleY:0.5629,x:202.5,y:77.75},0).wait(1).to({scaleX:0.5609,scaleY:0.5609,x:202.25,y:76.9},0).wait(1).to({scaleX:0.5592,scaleY:0.5592,x:202.05,y:76.15},0).wait(1).to({scaleX:0.5578,scaleY:0.5578,x:201.85,y:75.6},0).wait(1).to({scaleX:0.5566,scaleY:0.5566,x:201.7,y:75.1},0).wait(1).to({scaleX:0.5557,scaleY:0.5557,x:201.6,y:74.7},0).wait(1).to({scaleX:0.555,scaleY:0.555,x:201.5,y:74.45},0).wait(1).to({scaleX:0.5544,scaleY:0.5544,x:201.4,y:74.15},0).wait(1).to({scaleX:0.5541,scaleY:0.5541,x:201.35,y:74},0).wait(1).to({scaleX:0.5538,scaleY:0.5538,y:73.95},0).wait(1).to({regX:26.2,regY:21.7,y:74},0).wait(1));

	// girl left icon.png
	this.instance_6 = new lib.girllefticon();
	this.instance_6.setTransform(-119.4,159.2,1,1,0,0,0,25.3,21.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(22).to({_off:false},0).to({x:32.1,y:115.5,alpha:1},41,cjs.Ease.quadOut).wait(1).to({regX:25.4,x:32.2},0).wait(25).to({regX:25.3,x:32.1},0).wait(1).to({regX:25.4,scaleX:0.9969,scaleY:0.9969,x:33.75,y:115.75},0).wait(1).to({scaleX:0.9926,scaleY:0.9926,x:35.95,y:116.05},0).wait(1).to({scaleX:0.9872,scaleY:0.9872,x:38.75,y:116.45},0).wait(1).to({scaleX:0.9805,scaleY:0.9805,x:42.2,y:116.95},0).wait(1).to({scaleX:0.9725,scaleY:0.9725,x:46.35,y:117.55},0).wait(1).to({scaleX:0.9631,scaleY:0.9631,x:51.15,y:118.25},0).wait(1).to({scaleX:0.9524,scaleY:0.9524,x:56.7,y:119.05},0).wait(1).to({scaleX:0.9401,scaleY:0.9401,x:63,y:119.95},0).wait(1).to({scaleX:0.9265,scaleY:0.9265,x:70,y:121},0).wait(1).to({scaleX:0.9114,scaleY:0.9114,x:77.75,y:122.1},0).wait(1).to({scaleX:0.895,scaleY:0.895,x:86.2,y:123.35},0).wait(1).to({scaleX:0.8774,scaleY:0.8774,x:95.25,y:124.7},0).wait(1).to({scaleX:0.8587,scaleY:0.8587,x:104.85,y:126.1},0).wait(1).to({scaleX:0.8393,scaleY:0.8393,x:114.85,y:127.6},0).wait(1).to({scaleX:0.8193,scaleY:0.8193,x:125.15,y:129.05},0).wait(1).to({scaleX:0.7991,scaleY:0.7991,x:135.55,y:130.55},0).wait(1).to({scaleX:0.7791,scaleY:0.7791,x:145.8,y:132.1},0).wait(1).to({scaleX:0.7597,scaleY:0.7597,x:155.85,y:133.55},0).wait(1).to({scaleX:0.741,scaleY:0.741,x:165.4,y:134.95},0).wait(1).to({scaleX:0.7234,scaleY:0.7234,x:174.45,y:136.25},0).wait(1).to({scaleX:0.7072,scaleY:0.7072,x:182.85,y:137.45},0).wait(1).to({scaleX:0.6924,scaleY:0.6924,x:190.45,y:138.6},0).wait(1).to({scaleX:0.6791,scaleY:0.6791,x:197.3,y:139.6},0).wait(1).to({scaleX:0.6674,scaleY:0.6674,x:203.3,y:140.45},0).wait(1).to({scaleX:0.6573,scaleY:0.6573,x:208.5,y:141.25},0).wait(1).to({scaleX:0.6487,scaleY:0.6487,x:212.9,y:141.85},0).wait(1).to({scaleX:0.6417,scaleY:0.6417,x:216.5,y:142.4},0).wait(1).to({scaleX:0.6361,scaleY:0.6361,x:219.4,y:142.85},0).wait(1).to({scaleX:0.6319,scaleY:0.6319,x:221.6,y:143.15},0).wait(1).to({scaleX:0.6289,scaleY:0.6289,x:223.05,y:143.35},0).wait(1).to({scaleX:0.6272,scaleY:0.6272,x:224,y:143.5},0).wait(1).to({regX:25.3,regY:21.4,scaleX:0.6267,scaleY:0.6267,x:224.2,y:143.55},0).wait(1).to({regX:25.4,regY:21.3,x:224.25,y:143.5},0).wait(4).to({regX:25.3,regY:21.4,x:224.2,y:143.55},0).wait(1).to({regX:25.4,regY:21.3,x:224.25,y:143.5},0).wait(4).to({regX:25.3,regY:21.4,x:224.2,y:143.55},0).wait(1).to({regX:25.4,regY:21.3,scaleX:0.6266,scaleY:0.6266,x:224.25,y:143.4},0).wait(1).to({scaleX:0.6265,scaleY:0.6265,y:143.3},0).wait(1).to({scaleX:0.6264,scaleY:0.6264,y:143.1},0).wait(1).to({scaleX:0.6261,scaleY:0.6261,x:224.3,y:142.85},0).wait(1).to({scaleX:0.6258,scaleY:0.6258,x:224.35,y:142.5},0).wait(1).to({scaleX:0.6254,scaleY:0.6254,y:142.05},0).wait(1).to({scaleX:0.6249,scaleY:0.6249,x:224.4,y:141.5},0).wait(1).to({scaleX:0.6243,scaleY:0.6243,x:224.45,y:140.85},0).wait(1).to({scaleX:0.6236,scaleY:0.6236,x:224.55,y:140.05},0).wait(1).to({scaleX:0.6227,scaleY:0.6227,x:224.6,y:139.05},0).wait(1).to({scaleX:0.6216,scaleY:0.6216,x:224.7,y:137.9},0).wait(1).to({scaleX:0.6204,scaleY:0.6204,x:224.8,y:136.45},0).wait(1).to({scaleX:0.6188,scaleY:0.6188,x:224.9,y:134.75},0).wait(1).to({scaleX:0.6168,scaleY:0.6168,x:225.1,y:132.6},0).wait(1).to({scaleX:0.6144,scaleY:0.6144,x:225.3,y:129.95},0).wait(1).to({scaleX:0.6113,scaleY:0.6113,x:225.6,y:126.45},0).wait(1).to({scaleX:0.6071,scaleY:0.6071,x:225.95,y:121.9},0).wait(1).to({scaleX:0.6014,scaleY:0.6014,x:226.5,y:115.55},0).wait(1).to({scaleX:0.5937,scaleY:0.5937,x:227.15,y:107.1},0).wait(1).to({scaleX:0.5856,scaleY:0.5856,x:227.85,y:98.05},0).wait(1).to({scaleX:0.579,scaleY:0.579,x:228.45,y:90.9},0).wait(1).to({scaleX:0.5743,scaleY:0.5743,x:228.85,y:85.6},0).wait(1).to({scaleX:0.5707,scaleY:0.5707,x:229.2,y:81.65},0).wait(1).to({scaleX:0.5679,scaleY:0.5679,x:229.45,y:78.6},0).wait(1).to({scaleX:0.5657,scaleY:0.5657,x:229.6,y:76.15},0).wait(1).to({scaleX:0.5639,scaleY:0.5639,x:229.75,y:74.15},0).wait(1).to({scaleX:0.5624,scaleY:0.5624,x:229.9,y:72.5},0).wait(1).to({scaleX:0.5612,scaleY:0.5612,x:230,y:71.1},0).wait(1).to({scaleX:0.5601,scaleY:0.5601,x:230.15,y:70},0).wait(1).to({scaleX:0.5592,scaleY:0.5592,x:230.2,y:68.95},0).wait(1).to({scaleX:0.5585,scaleY:0.5585,x:230.25,y:68.15},0).wait(1).to({scaleX:0.5578,scaleY:0.5578,x:230.3,y:67.5},0).wait(1).to({scaleX:0.5573,scaleY:0.5573,x:230.35,y:66.85},0).wait(1).to({scaleX:0.5569,scaleY:0.5569,x:230.4,y:66.4},0).wait(1).to({scaleX:0.5565,scaleY:0.5565,x:230.45,y:66},0).wait(1).to({scaleX:0.5562,scaleY:0.5562,y:65.7},0).wait(1).to({scaleX:0.556,scaleY:0.556,y:65.45},0).wait(1).to({scaleX:0.5559,scaleY:0.5559,y:65.3},0).wait(1).to({scaleX:0.5557,scaleY:0.5557,y:65.15},0).wait(1).to({x:230.5,y:65.1},0).wait(1).to({regY:21.4,x:230.45,y:65.15},0).wait(1));

	// guy right contribution
	this.instance_7 = new lib.guyrightcontribution();
	this.instance_7.setTransform(240.6,-78.2,1,1,0,0,0,38.1,26.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29).to({_off:false},0).to({x:213.65,y:6.85,alpha:1},37,cjs.Ease.quadOut).wait(1).to({regX:37.5,regY:26,x:213.05,y:6.65},0).wait(22).to({regX:38.1,regY:26.2,x:213.65,y:6.85},0).wait(1).to({regX:37.5,regY:26,scaleX:0.9985,scaleY:0.9979,x:213.6,y:7.45},0).wait(1).to({scaleX:0.9965,scaleY:0.995,skewY:-0.0565,x:214.35,y:8.45},0).wait(1).to({scaleX:0.9939,scaleY:0.9913,skewY:-0.0988,x:215.35,y:9.85},0).wait(1).to({scaleX:0.9906,scaleY:0.9867,skewY:-0.1514,x:216.65,y:11.6},0).wait(1).to({scaleX:0.9866,scaleY:0.981,skewY:-0.2149,x:218.15,y:13.65},0).wait(1).to({scaleX:0.982,scaleY:0.9744,skewY:-0.2901,x:219.9,y:16.1},0).wait(1).to({scaleX:0.9765,scaleY:0.9667,skewY:-0.3773,x:222,y:18.9},0).wait(1).to({scaleX:0.9703,scaleY:0.9579,skewY:-0.4772,x:224.4,y:22.15},0).wait(1).to({scaleX:0.9633,scaleY:0.948,skewY:-0.5897,x:227.05,y:25.75},0).wait(1).to({scaleX:0.9555,scaleY:0.9369,skewY:-0.7147,x:230.1,y:29.8},0).wait(1).to({scaleX:0.947,scaleY:0.9249,skewY:-0.8515,x:233.35,y:34.2},0).wait(1).to({scaleX:0.9378,scaleY:0.9119,skewY:-0.9987,x:236.85,y:39},0).wait(1).to({scaleX:0.9281,scaleY:0.8981,skewY:-1.1543,x:240.55,y:44.05},0).wait(1).to({scaleX:0.9181,scaleY:0.8839,skewY:-1.3153,x:244.4,y:49.3},0).wait(1).to({scaleX:0.9079,scaleY:0.8695,skewY:-1.4783,x:248.3,y:54.5},0).wait(1).to({scaleX:0.8979,scaleY:0.8553,skewY:-1.6395,x:252.15,y:59.8},0).wait(1).to({scaleX:0.8881,scaleY:0.8416,skewY:-1.7953,x:255.85,y:64.85},0).wait(1).to({scaleX:0.879,scaleY:0.8286,skewY:-1.9422,x:259.35,y:69.6},0).wait(1).to({scaleX:0.8706,scaleY:0.8166,skewY:-2.0777,x:262.55,y:74},0).wait(1).to({scaleX:0.863,scaleY:0.8059,skewY:-2.1999,x:265.5,y:77.95},0).wait(1).to({scaleX:0.8562,scaleY:0.7963,skewY:-2.3077,x:268.1,y:81.45},0).wait(1).to({scaleX:0.8504,scaleY:0.7881,skewY:-2.4007,x:270.3,y:84.45},0).wait(1).to({scaleX:0.8455,scaleY:0.7812,skewY:-2.4791,x:272.2,y:87},0).wait(1).to({scaleX:0.8415,scaleY:0.7755,skewY:-2.5433,x:273.7,y:89.05},0).wait(1).to({scaleX:0.8384,scaleY:0.7711,skewY:-2.5939,x:274.9,y:90.75},0).wait(1).to({scaleX:0.836,scaleY:0.7677,skewY:-2.6319,x:275.8,y:91.95},0).wait(1).to({scaleX:0.8344,scaleY:0.7654,skewY:-2.658,x:276.45,y:92.8},0).wait(1).to({scaleX:0.8334,scaleY:0.7641,skewY:-2.673,x:276.75,y:93.3},0).wait(1).to({regX:38.3,regY:26.3,scaleX:0.8331,scaleY:0.7637,skewY:-2.6778,x:277.45,y:93.6},0).wait(55));

	// guy left contribution
	this.instance_8 = new lib.guyleftcontribution_1();
	this.instance_8.setTransform(-59.8,65.85,1,1,0,0,0,30.4,9.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(33).to({_off:false},0).to({x:95.3,y:28.15,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:30.5,regY:9.7,x:95.4,y:28.05},0).wait(22).to({regX:30.4,regY:9.8,x:95.3,y:28.15},0).wait(1).to({regX:30.5,regY:9.7,scaleX:0.9967,scaleY:0.9967,skewX:-0.0654,skewY:-0.0111,x:96.6,y:28.85},0).wait(1).to({scaleX:0.9921,scaleY:0.9923,skewX:-0.1546,skewY:-0.0262,x:98.25,y:30.05},0).wait(1).to({scaleX:0.9862,scaleY:0.9865,skewX:-0.2692,skewY:-0.0456,x:100.4,y:31.55},0).wait(1).to({scaleX:0.979,scaleY:0.9794,skewX:-0.4109,skewY:-0.0697,x:102.95,y:33.4},0).wait(1).to({scaleX:0.9702,scaleY:0.9708,skewX:-0.5817,skewY:-0.0987,x:106.15,y:35.65},0).wait(1).to({scaleX:0.9599,scaleY:0.9606,skewX:-0.7833,skewY:-0.1328,x:109.95,y:38.35},0).wait(1).to({scaleX:0.9479,scaleY:0.9489,skewX:-1.0175,skewY:-0.1726,x:114.2,y:41.4},0).wait(1).to({scaleX:0.9342,scaleY:0.9354,skewX:-1.2855,skewY:-0.218,x:119.2,y:44.9},0).wait(1).to({scaleX:0.9187,scaleY:0.9202,skewX:-1.5884,skewY:-0.2694,x:124.8,y:48.9},0).wait(1).to({scaleX:0.9014,scaleY:0.9032,skewX:-1.9261,skewY:-0.3267,x:131.1,y:53.35},0).wait(1).to({scaleX:0.8823,scaleY:0.8845,skewX:-2.2978,skewY:-0.3897,x:137.95,y:58.2},0).wait(1).to({scaleX:0.8617,scaleY:0.8642,skewX:-2.7009,skewY:-0.458,x:145.45,y:63.55},0).wait(1).to({scaleX:0.8396,scaleY:0.8426,skewX:-3.1309,skewY:-0.531,x:153.4,y:69.2},0).wait(1).to({scaleX:0.8166,scaleY:0.8199,skewX:-3.5814,skewY:-0.6074,x:161.75,y:75.15},0).wait(1).to({scaleX:0.7929,scaleY:0.7967,skewX:-4.044,skewY:-0.6858,x:170.35,y:81.2},0).wait(1).to({scaleX:0.769,scaleY:0.7733,skewX:-4.5086,skewY:-0.7646,x:178.95,y:87.35},0).wait(1).to({scaleX:0.7457,scaleY:0.7504,skewX:-4.9649,skewY:-0.842,x:187.4,y:93.3},0).wait(1).to({scaleX:0.7232,scaleY:0.7283,skewX:-5.4027,skewY:-0.9163,x:195.5,y:99.1},0).wait(1).to({scaleX:0.7022,scaleY:0.7077,skewX:-5.8133,skewY:-0.9859,x:203.1,y:104.55},0).wait(1).to({scaleX:0.6829,scaleY:0.6888,skewX:-6.19,skewY:-1.0498,x:210.05,y:109.45},0).wait(1).to({scaleX:0.6656,scaleY:0.6718,skewX:-6.5283,skewY:-1.1071,x:216.4,y:113.85},0).wait(1).to({scaleX:0.6503,scaleY:0.6568,skewX:-6.8258,skewY:-1.1576,x:221.9,y:117.85},0).wait(1).to({scaleX:0.6372,scaleY:0.6439,skewX:-7.082,skewY:-1.201,x:226.65,y:121.2},0).wait(1).to({scaleX:0.6262,scaleY:0.6331,skewX:-7.2974,skewY:-1.2376,x:230.65,y:124.05},0).wait(1).to({scaleX:0.6172,scaleY:0.6242,skewX:-7.4736,skewY:-1.2674,x:233.9,y:126.35},0).wait(1).to({scaleX:0.61,scaleY:0.6172,skewX:-7.6125,skewY:-1.291,x:236.45,y:128.2},0).wait(1).to({scaleX:0.6047,scaleY:0.612,skewX:-7.7164,skewY:-1.3086,x:238.4,y:129.55},0).wait(1).to({scaleX:0.6011,scaleY:0.6084,skewX:-7.7878,skewY:-1.3207,x:239.75,y:130.5},0).wait(1).to({scaleX:0.5989,scaleY:0.6063,skewX:-7.829,skewY:-1.3277,x:240.45,y:131.05},0).wait(1).to({regX:30.6,regY:9.8,scaleX:0.5983,scaleY:0.6057,skewX:-7.8423,skewY:-1.33,x:240.7,y:131.25},0).wait(54));

	// girl left contribution
	this.instance_9 = new lib.girlleftcontribution();
	this.instance_9.setTransform(-71.15,171.05,1,1,0,0,0,44,32.3);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(22).to({_off:false},0).to({x:80.35,y:127.35,alpha:1},42,cjs.Ease.quadOut).wait(1).to({regX:44.6,x:80.95},0).wait(24).to({regX:44,x:80.35},0).wait(1).to({regX:44.6,scaleX:0.9959,scaleY:0.9959,x:82.3,y:127.5},0).wait(1).to({scaleX:0.9903,scaleY:0.9903,x:84.25,y:127.8},0).wait(1).to({scaleX:0.9831,scaleY:0.9831,x:86.7,y:128.15},0).wait(1).to({scaleX:0.9743,scaleY:0.9743,x:89.75,y:128.6},0).wait(1).to({scaleX:0.9637,scaleY:0.9637,x:93.4,y:129.15},0).wait(1).to({scaleX:0.9512,scaleY:0.9512,x:97.65,y:129.75},0).wait(1).to({scaleX:0.9367,scaleY:0.9367,x:102.65,y:130.45},0).wait(1).to({scaleX:0.9202,scaleY:0.9202,x:108.25,y:131.3},0).wait(1).to({scaleX:0.9017,scaleY:0.9017,x:114.6,y:132.2},0).wait(1).to({scaleX:0.881,scaleY:0.881,x:121.7,y:133.25},0).wait(1).to({scaleX:0.8584,scaleY:0.8584,x:129.5,y:134.35},0).wait(1).to({scaleX:0.8338,scaleY:0.8338,x:137.9,y:135.6},0).wait(1).to({scaleX:0.8076,scaleY:0.8076,x:146.8,y:136.9},0).wait(1).to({scaleX:0.7802,scaleY:0.7802,x:156.25,y:138.3},0).wait(1).to({scaleX:0.7519,scaleY:0.7519,x:165.95,y:139.7},0).wait(1).to({scaleX:0.7233,scaleY:0.7233,x:175.75,y:141.1},0).wait(1).to({scaleX:0.6949,scaleY:0.6949,x:185.45,y:142.55},0).wait(1).to({scaleX:0.6675,scaleY:0.6675,x:194.85,y:143.9},0).wait(1).to({scaleX:0.6414,scaleY:0.6414,x:203.8,y:145.2},0).wait(1).to({scaleX:0.6171,scaleY:0.6171,x:212.1,y:146.4},0).wait(1).to({scaleX:0.5949,scaleY:0.5949,x:219.75,y:147.5},0).wait(1).to({scaleX:0.575,scaleY:0.575,x:226.55,y:148.5},0).wait(1).to({scaleX:0.5575,scaleY:0.5575,x:232.5,y:149.35},0).wait(1).to({scaleX:0.5424,scaleY:0.5424,x:237.7,y:150.1},0).wait(1).to({scaleX:0.5297,scaleY:0.5297,x:242.05,y:150.75},0).wait(1).to({scaleX:0.5193,scaleY:0.5193,x:245.6,y:151.25},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:248.45,y:151.7},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:250.5,y:152},0).wait(1).to({scaleX:0.5007,scaleY:0.5007,x:252,y:152.2},0).wait(1).to({scaleX:0.4982,scaleY:0.4982,x:252.8,y:152.35},0).wait(1).to({regX:44.3,regY:32.5,scaleX:0.4974,scaleY:0.4974,x:252.85},0).wait(53));

	// girl rigth contribution
	this.instance_10 = new lib.girlrigthcontribution();
	this.instance_10.setTransform(253.5,242.7,1,1,0,0,0,39.1,19.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(25).to({_off:false},0).to({x:206.15,y:175,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:206.05,y:174.9},0).wait(23).to({regX:39.1,regY:19.1,x:206.15,y:175},0).wait(1).to({regX:39,regY:19,scaleX:0.9965,scaleY:0.9965,x:206.45,y:174.9},0).wait(1).to({scaleX:0.9918,scaleY:0.9918,x:207.05,y:174.85},0).wait(1).to({scaleX:0.9858,scaleY:0.9858,x:207.8},0).wait(1).to({scaleX:0.9785,scaleY:0.9785,x:208.65,y:174.8},0).wait(1).to({scaleX:0.9697,scaleY:0.9697,x:209.75,y:174.75},0).wait(1).to({scaleX:0.9594,scaleY:0.9594,x:211},0).wait(1).to({scaleX:0.9474,scaleY:0.9474,x:212.5,y:174.7},0).wait(1).to({scaleX:0.9337,scaleY:0.9337,x:214.2,y:174.65},0).wait(1).to({scaleX:0.9183,scaleY:0.9183,x:216.1,y:174.6},0).wait(1).to({scaleX:0.901,scaleY:0.901,x:218.25,y:174.55},0).wait(1).to({scaleX:0.8818,scaleY:0.8818,x:220.6,y:174.5},0).wait(1).to({scaleX:0.8609,scaleY:0.8609,x:223.2,y:174.4},0).wait(1).to({scaleX:0.8384,scaleY:0.8384,x:225.95,y:174.35},0).wait(1).to({scaleX:0.8144,scaleY:0.8144,x:228.9,y:174.25},0).wait(1).to({scaleX:0.7892,scaleY:0.7892,x:232,y:174.2},0).wait(1).to({scaleX:0.7634,scaleY:0.7634,x:235.15,y:174.1},0).wait(1).to({scaleX:0.7374,scaleY:0.7374,x:238.35,y:174},0).wait(1).to({scaleX:0.7116,scaleY:0.7116,x:241.55,y:173.9},0).wait(1).to({scaleX:0.6868,scaleY:0.6868,x:244.6,y:173.85},0).wait(1).to({scaleX:0.6632,scaleY:0.6632,x:247.5,y:173.75},0).wait(1).to({scaleX:0.6414,scaleY:0.6414,x:250.2,y:173.7},0).wait(1).to({scaleX:0.6215,scaleY:0.6215,x:252.65,y:173.65},0).wait(1).to({scaleX:0.6038,scaleY:0.6038,x:254.8,y:173.55},0).wait(1).to({scaleX:0.5883,scaleY:0.5883,x:256.75},0).wait(1).to({scaleX:0.575,scaleY:0.575,x:258.35,y:173.45},0).wait(1).to({scaleX:0.5638,scaleY:0.5638,x:259.75},0).wait(1).to({scaleX:0.5546,scaleY:0.5546,x:260.9},0).wait(1).to({scaleX:0.5474,scaleY:0.5474,x:261.75,y:173.4},0).wait(1).to({scaleX:0.542,scaleY:0.542,x:262.45},0).wait(1).to({scaleX:0.5383,scaleY:0.5383,x:262.9},0).wait(1).to({scaleX:0.5362,scaleY:0.5362,x:263.15,y:173.35},0).wait(1).to({regX:39.1,regY:19.2,scaleX:0.5355,scaleY:0.5355,x:263.3,y:173.45},0).wait(52));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_22 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_66 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_67 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_68 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_69 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_70 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_71 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_72 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_73 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_74 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_75 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_76 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_77 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_78 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_79 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_80 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_81 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_82 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_83 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_84 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_85 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_86 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_87 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_88 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_89 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_90 = new cjs.Graphics().p("Azui6QAdgKPSkuIPWkvIIYPkI+9Jfg");
	var mask_graphics_91 = new cjs.Graphics().p("Azyi6QAegMPQksIPdkxIIZPmI/BJhg");
	var mask_graphics_92 = new cjs.Graphics().p("Az3i7QAhgMPLkrIPnk1IIcPrI/LJkg");
	var mask_graphics_93 = new cjs.Graphics().p("Az+i9QAkgNPGkpIP0k4IIfPwI/VJng");
	var mask_graphics_94 = new cjs.Graphics().p("A0Gi/QAngNO/knIQFk+IIiP2I/iJsg");
	var mask_graphics_95 = new cjs.Graphics().p("A0RjBQArgPO4kkQH9icIcinIInP+I/zJxg");
	var mask_graphics_96 = new cjs.Graphics().p("A0ejDQAxgROukhQIFidIsitIItQHMggHAJ4g");
	var mask_graphics_97 = new cjs.Graphics().p("A0tjGQA3gTOkkdQIMigJAiyII0QSMggfAKAg");
	var mask_graphics_98 = new cjs.Graphics().p("A09jKQA9gVOYkXQIWiiJWi7II7QfMgg5AKIg");
	var mask_graphics_99 = new cjs.Graphics().p("A1QjOQBFgXOKkTQIgikJwjDIJCQtMghVAKSg");
	var mask_graphics_100 = new cjs.Graphics().p("A1ljSQBPgZN6kOQIrinKLjMIJMQ9Mgh2AKcg");
	var mask_graphics_101 = new cjs.Graphics().p("A17jWQBYgcNqkIQI3iqKojWIJWRNMgiYAKog");
	var mask_graphics_102 = new cjs.Graphics().p("A2SjbQBhgeNakCQJEitLGjgIJgReMgi8AKzg");
	var mask_graphics_103 = new cjs.Graphics().p("A2qjgQBsgiNIj7QJRivLmjrIJpRwMgjfAK/g");
	var mask_graphics_104 = new cjs.Graphics().p("A3BjlQB2gkM2j1QJdizMGj0IJ0SBMgkFALKg");
	var mask_graphics_105 = new cjs.Graphics().p("A3XjpQB+gnMmjvQJqi2Mjj+IJ+SSMgknALVg");
	var mask_graphics_106 = new cjs.Graphics().p("A3tjtQCIgrMWjpQJ1i4NBkIIKHSiMglJALhg");
	var mask_graphics_107 = new cjs.Graphics().p("A4BjxQCQgtMIjkQKAi6NbkSIKQSyMgloALqg");
	var mask_graphics_108 = new cjs.Graphics().p("A4Uj1QCZgvL6jfQKKi9NzkZIKYS/MgmFAL0g");
	var mask_graphics_109 = new cjs.Graphics().p("A4kj4QCfgxLujbQKVi/OIkgIKfTKMgmfAL9g");
	var mask_graphics_110 = new cjs.Graphics().p("A4yj8QClgyLjjWQKdjCObkmIKlTVMgm0AMEg");
	var mask_graphics_111 = new cjs.Graphics().p("A4/j9QCrg1LZjUQKkjCOsksIKrTfMgnJAMKg");
	var mask_graphics_112 = new cjs.Graphics().p("A5JkAQCvg2LRjQQKqjEO6kxIKvTnMgnYAMQg");
	var mask_graphics_113 = new cjs.Graphics().p("A5TkCQCzg2LLjOQKvjFPGk1IKzTtMgnnAMUg");
	var mask_graphics_114 = new cjs.Graphics().p("A5akEQC2g3LGjMQKyjGPQk4IK3TzMgnyAMYg");
	var mask_graphics_115 = new cjs.Graphics().p("A5fkEQC3g5LDjKQK1jHPXk7IK6T4Mgn7AMbg");
	var mask_graphics_116 = new cjs.Graphics().p("A5kkFQC6g5K/jKQK3jHPek8IK7T6MgoCAMdg");
	var mask_graphics_117 = new cjs.Graphics().p("A5nkGQC8g5K7jJQK6jHPhk+IK9T9MgoHAMeg");
	var mask_graphics_118 = new cjs.Graphics().p("A5pkGQC8g6K7jIQK7jIPkk+IK9T+MgoKAMfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_22,x:155,y:94.225}).wait(44).to({graphics:mask_graphics_66,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_67,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_68,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_69,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_70,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_71,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_72,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_73,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_74,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_75,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_76,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_77,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_78,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_79,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_80,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_81,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_82,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_83,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_84,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_85,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_86,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_87,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_88,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_89,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_90,x:155.325,y:94.525}).wait(1).to({graphics:mask_graphics_91,x:155.9,y:95.025}).wait(1).to({graphics:mask_graphics_92,x:156.7,y:95.725}).wait(1).to({graphics:mask_graphics_93,x:157.775,y:96.7}).wait(1).to({graphics:mask_graphics_94,x:159.125,y:97.9}).wait(1).to({graphics:mask_graphics_95,x:160.775,y:99.325}).wait(1).to({graphics:mask_graphics_96,x:162.725,y:101.075}).wait(1).to({graphics:mask_graphics_97,x:165.025,y:103.1}).wait(1).to({graphics:mask_graphics_98,x:167.6,y:105.4}).wait(1).to({graphics:mask_graphics_99,x:170.5,y:107.975}).wait(1).to({graphics:mask_graphics_100,x:173.7,y:110.775}).wait(1).to({graphics:mask_graphics_101,x:177.05,y:113.8}).wait(1).to({graphics:mask_graphics_102,x:180.6,y:116.9}).wait(1).to({graphics:mask_graphics_103,x:184.2,y:120.125}).wait(1).to({graphics:mask_graphics_104,x:187.8,y:123.3}).wait(1).to({graphics:mask_graphics_105,x:191.3,y:126.4}).wait(1).to({graphics:mask_graphics_106,x:194.6,y:129.325}).wait(1).to({graphics:mask_graphics_107,x:197.675,y:132.05}).wait(1).to({graphics:mask_graphics_108,x:200.5,y:134.525}).wait(1).to({graphics:mask_graphics_109,x:203.025,y:136.775}).wait(1).to({graphics:mask_graphics_110,x:205.225,y:138.75}).wait(1).to({graphics:mask_graphics_111,x:207.175,y:140.45}).wait(1).to({graphics:mask_graphics_112,x:208.8,y:141.925}).wait(1).to({graphics:mask_graphics_113,x:210.2,y:143.125}).wait(1).to({graphics:mask_graphics_114,x:211.325,y:144.15}).wait(1).to({graphics:mask_graphics_115,x:212.2,y:144.925}).wait(1).to({graphics:mask_graphics_116,x:212.9,y:145.525}).wait(1).to({graphics:mask_graphics_117,x:213.35,y:145.925}).wait(1).to({graphics:mask_graphics_118,x:213.625,y:146.175}).wait(55));

	// r guy i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(188.7,-72.65,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(29).to({_off:false},0).to({x:165.95,y:17.55,alpha:0.1602},36,cjs.Ease.quadOut).wait(1).to({regX:28,x:165.75},0).wait(23).to({regX:28.2,x:165.95},0).wait(1).to({regX:28,scaleX:0.9985,scaleY:0.9985,x:166.45,y:18.2},0).wait(1).to({scaleX:0.9965,scaleY:0.9965,x:167.5,y:19.1},0).wait(1).to({scaleX:0.9938,scaleY:0.9938,x:168.8,y:20.3},0).wait(1).to({scaleX:0.9905,scaleY:0.9905,x:170.45,y:21.8},0).wait(1).to({scaleX:0.9864,scaleY:0.9864,x:172.4,y:23.55},0).wait(1).to({scaleX:0.9816,scaleY:0.9816,x:174.8,y:25.65},0).wait(1).to({scaleX:0.976,scaleY:0.976,x:177.6,y:28.1},0).wait(1).to({scaleX:0.9695,scaleY:0.9695,x:180.75,y:30.95},0).wait(1).to({scaleX:0.9622,scaleY:0.9622,x:184.35,y:34.2},0).wait(1).to({scaleX:0.954,scaleY:0.954,x:188.4,y:37.8},0).wait(1).to({scaleX:0.945,scaleY:0.945,x:192.8,y:41.75},0).wait(1).to({scaleX:0.9353,scaleY:0.9353,x:197.65,y:46},0).wait(1).to({scaleX:0.925,scaleY:0.925,x:202.7,y:50.6},0).wait(1).to({scaleX:0.9144,scaleY:0.9144,x:207.95,y:55.25},0).wait(1).to({scaleX:0.9036,scaleY:0.9036,x:213.25,y:60},0).wait(1).to({scaleX:0.893,scaleY:0.893,x:218.45,y:64.65},0).wait(1).to({scaleX:0.883,scaleY:0.883,x:223.4,y:69.1},0).wait(1).to({scaleX:0.8736,scaleY:0.8736,x:228.05,y:73.2},0).wait(1).to({scaleX:0.8651,scaleY:0.8651,x:232.25,y:76.95},0).wait(1).to({scaleX:0.8576,scaleY:0.8576,x:235.95,y:80.25},0).wait(1).to({scaleX:0.8511,scaleY:0.8511,x:239.15,y:83.1},0).wait(1).to({scaleX:0.8457,scaleY:0.8457,x:241.85,y:85.55},0).wait(1).to({scaleX:0.8412,scaleY:0.8412,x:244,y:87.5},0).wait(1).to({scaleX:0.8378,scaleY:0.8378,x:245.75,y:89},0).wait(1).to({scaleX:0.8352,scaleY:0.8352,x:247.05,y:90.15},0).wait(1).to({scaleX:0.8334,scaleY:0.8334,x:247.9,y:90.95},0).wait(1).to({scaleX:0.8324,scaleY:0.8324,x:248.4,y:91.4},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.832,scaleY:0.832,x:248.75,y:91.55},0).wait(1).to({regX:28,regY:22.8,x:248.5,y:91.45},0).wait(8).to({regX:28.3,regY:22.9,x:248.75,y:91.55},0).wait(1).to({regX:28,regY:22.8,scaleX:0.8318,scaleY:0.8318,x:248.5,y:91.4},0).wait(1).to({scaleX:0.8315,scaleY:0.8315},0).wait(1).to({scaleX:0.831,scaleY:0.831,y:91.35},0).wait(1).to({scaleX:0.8302,scaleY:0.8302,x:248.55,y:91.25},0).wait(1).to({scaleX:0.8293,scaleY:0.8293,y:91.15},0).wait(1).to({scaleX:0.8281,scaleY:0.8281,x:248.65,y:91},0).wait(1).to({scaleX:0.8266,scaleY:0.8266,x:248.7,y:90.85},0).wait(1).to({scaleX:0.8248,scaleY:0.8248,x:248.75,y:90.65},0).wait(1).to({scaleX:0.8227,scaleY:0.8227,x:248.85,y:90.4},0).wait(1).to({scaleX:0.8201,scaleY:0.8201,x:248.9,y:90.15},0).wait(1).to({scaleX:0.8172,scaleY:0.8172,x:249.05,y:89.8},0).wait(1).to({scaleX:0.8136,scaleY:0.8136,x:249.2,y:89.4},0).wait(1).to({scaleX:0.8094,scaleY:0.8094,x:249.3,y:88.95},0).wait(1).to({scaleX:0.8044,scaleY:0.8044,x:249.5,y:88.4},0).wait(1).to({scaleX:0.7984,scaleY:0.7984,x:249.7,y:87.7},0).wait(1).to({scaleX:0.7912,scaleY:0.7912,x:250,y:86.9},0).wait(1).to({scaleX:0.7823,scaleY:0.7823,x:250.3,y:85.95},0).wait(1).to({scaleX:0.7711,scaleY:0.7711,x:250.75,y:84.7},0).wait(1).to({scaleX:0.7567,scaleY:0.7567,x:251.3,y:83.05},0).wait(1).to({scaleX:0.7375,scaleY:0.7375,x:252,y:80.95},0).wait(1).to({scaleX:0.7121,scaleY:0.7121,x:252.95,y:78.15},0).wait(1).to({scaleX:0.683,scaleY:0.683,x:254,y:74.85},0).wait(1).to({scaleX:0.6571,scaleY:0.6571,x:255,y:72.05},0).wait(1).to({scaleX:0.6372,scaleY:0.6372,x:255.75,y:69.8},0).wait(1).to({scaleX:0.6221,scaleY:0.6221,x:256.3,y:68.15},0).wait(1).to({scaleX:0.6104,scaleY:0.6104,x:256.75,y:66.8},0).wait(1).to({scaleX:0.6009,scaleY:0.6009,x:257.1,y:65.75},0).wait(1).to({scaleX:0.5932,scaleY:0.5932,x:257.4,y:64.9},0).wait(1).to({scaleX:0.5867,scaleY:0.5867,x:257.65,y:64.2},0).wait(1).to({scaleX:0.5813,scaleY:0.5813,x:257.85,y:63.6},0).wait(1).to({scaleX:0.5767,scaleY:0.5767,x:258,y:63.1},0).wait(1).to({scaleX:0.5727,scaleY:0.5727,x:258.15,y:62.65},0).wait(1).to({scaleX:0.5693,scaleY:0.5693,x:258.3,y:62.3},0).wait(1).to({scaleX:0.5664,scaleY:0.5664,x:258.4,y:61.9},0).wait(1).to({scaleX:0.5639,scaleY:0.5639,x:258.5,y:61.65},0).wait(1).to({scaleX:0.5618,scaleY:0.5618,x:258.6,y:61.4},0).wait(1).to({scaleX:0.5599,scaleY:0.5599,x:258.65,y:61.2},0).wait(1).to({scaleX:0.5584,scaleY:0.5584,x:258.7,y:61.05},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:258.75,y:60.9},0).wait(1).to({scaleX:0.556,scaleY:0.556,y:60.8},0).wait(1).to({scaleX:0.5552,scaleY:0.5552,x:258.8,y:60.7},0).wait(1).to({scaleX:0.5545,scaleY:0.5545,x:258.85,y:60.6},0).wait(1).to({scaleX:0.554,scaleY:0.554},0).wait(1).to({scaleX:0.5537,scaleY:0.5537,y:60.5},0).wait(1).to({scaleX:0.5535,scaleY:0.5535},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.5534,scaleY:0.5534,x:259.05,y:60.55},0).wait(1));

	// l guy i shadow
	this.instance_12 = new lib.roundshadow();
	this.instance_12.setTransform(-116,82.3,1,1,0,0,0,28.2,22.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({x:41.05,y:37.85,alpha:0.1602},33,cjs.Ease.quadOut).wait(1).to({regX:28,x:40.85},0).wait(22).to({regX:28.2,x:41.05},0).wait(1).to({regX:28,scaleX:0.9968,scaleY:0.9968,x:42.35,y:38.55},0).wait(1).to({scaleX:0.9924,scaleY:0.9924,x:44.5,y:39.5},0).wait(1).to({scaleX:0.9867,scaleY:0.9867,x:47.25,y:40.7},0).wait(1).to({scaleX:0.9797,scaleY:0.9797,x:50.6,y:42.2},0).wait(1).to({scaleX:0.9713,scaleY:0.9713,x:54.65,y:44},0).wait(1).to({scaleX:0.9613,scaleY:0.9613,x:59.45,y:46.1},0).wait(1).to({scaleX:0.9498,scaleY:0.9498,x:65,y:48.6},0).wait(1).to({scaleX:0.9367,scaleY:0.9367,x:71.35,y:51.45},0).wait(1).to({scaleX:0.9218,scaleY:0.9218,x:78.45,y:54.6},0).wait(1).to({scaleX:0.9054,scaleY:0.9054,x:86.4,y:58.15},0).wait(1).to({scaleX:0.8873,scaleY:0.8873,x:95.1,y:62.05},0).wait(1).to({scaleX:0.8679,scaleY:0.8679,x:104.5,y:66.25},0).wait(1).to({scaleX:0.8472,scaleY:0.8472,x:114.4,y:70.65},0).wait(1).to({scaleX:0.8257,scaleY:0.8257,x:124.75,y:75.3},0).wait(1).to({scaleX:0.8037,scaleY:0.8037,x:135.35,y:80},0).wait(1).to({scaleX:0.7818,scaleY:0.7818,x:145.95,y:84.7},0).wait(1).to({scaleX:0.7603,scaleY:0.7603,x:156.3,y:89.35},0).wait(1).to({scaleX:0.7398,scaleY:0.7398,x:166.15,y:93.75},0).wait(1).to({scaleX:0.7205,scaleY:0.7205,x:175.4,y:97.9},0).wait(1).to({scaleX:0.7029,scaleY:0.7029,x:183.95,y:101.7},0).wait(1).to({scaleX:0.687,scaleY:0.687,x:191.6,y:105.05},0).wait(1).to({scaleX:0.673,scaleY:0.673,x:198.35,y:108.1},0).wait(1).to({scaleX:0.661,scaleY:0.661,x:204.1,y:110.65},0).wait(1).to({scaleX:0.6508,scaleY:0.6508,x:209,y:112.85},0).wait(1).to({scaleX:0.6425,scaleY:0.6425,x:213.05,y:114.65},0).wait(1).to({scaleX:0.6359,scaleY:0.6359,x:216.2,y:116.05},0).wait(1).to({scaleX:0.631,scaleY:0.631,x:218.55,y:117.15},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:220.2,y:117.85},0).wait(1).to({scaleX:0.6256,scaleY:0.6256,x:221.15,y:118.25},0).wait(1).to({regX:28.3,scaleX:0.625,scaleY:0.625,x:221.65,y:118.4},0).wait(1).to({regX:28,x:221.45},0).wait(6).to({regX:28.3,x:221.65},0).wait(1).to({regX:28,x:221.45},0).wait(1).to({regX:28.3,x:221.65},0).wait(1).to({regX:28,x:221.4,y:118.35},0).wait(1).to({scaleX:0.6249,scaleY:0.6249,x:221.3,y:118.3},0).wait(1).to({scaleX:0.6248,scaleY:0.6248,x:221.15,y:118.2},0).wait(1).to({scaleX:0.6246,scaleY:0.6246,x:220.95,y:118.1},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:220.75,y:117.95},0).wait(1).to({scaleX:0.6242,scaleY:0.6242,x:220.4,y:117.75},0).wait(1).to({scaleX:0.6239,scaleY:0.6239,x:219.95,y:117.45},0).wait(1).to({scaleX:0.6235,scaleY:0.6235,x:219.5,y:117.15},0).wait(1).to({scaleX:0.623,scaleY:0.623,x:218.9,y:116.8},0).wait(1).to({scaleX:0.6224,scaleY:0.6224,x:218.2,y:116.35},0).wait(1).to({scaleX:0.6217,scaleY:0.6217,x:217.25,y:115.75},0).wait(1).to({scaleX:0.6208,scaleY:0.6208,x:216.2,y:115.1},0).wait(1).to({scaleX:0.6198,scaleY:0.6198,x:214.8,y:114.3},0).wait(1).to({scaleX:0.6184,scaleY:0.6184,x:213.1,y:113.2},0).wait(1).to({scaleX:0.6166,scaleY:0.6166,x:210.9,y:111.8},0).wait(1).to({scaleX:0.6143,scaleY:0.6143,x:207.95,y:109.95},0).wait(1).to({scaleX:0.611,scaleY:0.611,x:203.8,y:107.4},0).wait(1).to({scaleX:0.6065,scaleY:0.6065,x:198.15,y:103.9},0).wait(1).to({scaleX:0.6017,scaleY:0.6017,x:192,y:100},0).wait(1).to({scaleX:0.5978,scaleY:0.5978,x:187.2,y:97.05},0).wait(1).to({scaleX:0.5951,scaleY:0.5951,x:183.7,y:94.85},0).wait(1).to({scaleX:0.593,scaleY:0.593,x:181.1,y:93.2},0).wait(1).to({scaleX:0.5914,scaleY:0.5914,x:179.1,y:92},0).wait(1).to({scaleX:0.5902,scaleY:0.5902,x:177.55,y:91},0).wait(1).to({scaleX:0.5892,scaleY:0.5892,x:176.25,y:90.25},0).wait(1).to({scaleX:0.5883,scaleY:0.5883,x:175.2,y:89.55},0).wait(1).to({scaleX:0.5876,scaleY:0.5876,x:174.35,y:89},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:173.6,y:88.55},0).wait(1).to({scaleX:0.5866,scaleY:0.5866,x:172.95,y:88.15},0).wait(1).to({scaleX:0.5862,scaleY:0.5862,x:172.45,y:87.85},0).wait(1).to({scaleX:0.5858,scaleY:0.5858,x:172.05,y:87.6},0).wait(1).to({scaleX:0.5855,scaleY:0.5855,x:171.7,y:87.35},0).wait(1).to({scaleX:0.5853,scaleY:0.5853,x:171.45,y:87.2},0).wait(1).to({scaleX:0.5851,scaleY:0.5851,x:171.2,y:87.05},0).wait(1).to({scaleX:0.585,scaleY:0.585,x:171.05,y:86.95},0).wait(1).to({scaleX:0.5849,scaleY:0.5849,x:170.9,y:86.9},0).wait(1).to({scaleX:0.5848,scaleY:0.5848,x:170.85,y:86.8},0).wait(1).to({x:170.75},0).wait(1).to({regX:28.4,regY:22.9,x:170.9},0).wait(6));

	// r girl i shadow
	this.instance_13 = new lib.roundshadow();
	this.instance_13.setTransform(198.25,263.3,1,1,0,0,0,28.2,22.8);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(25).to({_off:false},0).to({x:130.85,y:192.2,alpha:0.1602},39,cjs.Ease.quadOut).wait(1).to({regX:28,x:131.05,y:191.7},0).wait(1).to({x:131.45,y:191.2},0).wait(1).to({x:131.85,y:190.65},0).wait(1).to({x:132.25,y:190.15},0).wait(1).to({x:132.7,y:189.65},0).wait(1).to({x:133.1,y:189.15},0).wait(1).to({x:133.5,y:188.65},0).wait(1).to({x:133.9,y:188.15},0).wait(1).to({x:134.35,y:187.65},0).wait(1).to({x:134.75,y:187.1},0).wait(1).to({x:135.2,y:186.6},0).wait(1).to({x:135.6,y:186.1},0).wait(1).to({x:136,y:185.6},0).wait(1).to({x:136.45,y:185.05},0).wait(1).to({x:136.85,y:184.55},0).wait(1).to({x:137.3,y:184},0).wait(1).to({x:137.7,y:183.5},0).wait(1).to({x:138.15,y:183},0).wait(1).to({x:138.6,y:182.45},0).wait(1).to({x:139,y:181.95},0).wait(1).to({x:139.45,y:181.4},0).wait(1).to({x:139.85,y:180.85},0).wait(1).to({x:140.3,y:180.35},0).wait(1).to({x:140.75,y:179.8},0).wait(1).to({regX:28.2,x:141.4,y:179.3},0).wait(1).to({regX:28,scaleX:0.9984,scaleY:0.9984,x:142,y:179.35},0).wait(1).to({scaleX:0.9963,scaleY:0.9963,x:143.15,y:179.45},0).wait(1).to({scaleX:0.9935,scaleY:0.9935,x:144.6,y:179.6},0).wait(1).to({scaleX:0.99,scaleY:0.99,x:146.4,y:179.75},0).wait(1).to({scaleX:0.9859,scaleY:0.9859,x:148.6,y:180.05},0).wait(1).to({scaleX:0.981,scaleY:0.981,x:151.15,y:180.25},0).wait(1).to({scaleX:0.9754,scaleY:0.9754,x:154.15,y:180.55},0).wait(1).to({scaleX:0.969,scaleY:0.969,x:157.55,y:180.9},0).wait(1).to({scaleX:0.9618,scaleY:0.9618,x:161.3,y:181.3},0).wait(1).to({scaleX:0.9538,scaleY:0.9538,x:165.45,y:181.7},0).wait(1).to({scaleX:0.9452,scaleY:0.9452,x:170,y:182.15},0).wait(1).to({scaleX:0.936,scaleY:0.936,x:174.85,y:182.65},0).wait(1).to({scaleX:0.9263,scaleY:0.9263,x:180,y:183.1},0).wait(1).to({scaleX:0.9162,scaleY:0.9162,x:185.3,y:183.65},0).wait(1).to({scaleX:0.906,scaleY:0.906,x:190.65,y:184.15},0).wait(1).to({scaleX:0.8959,scaleY:0.8959,x:196,y:184.75},0).wait(1).to({scaleX:0.8861,scaleY:0.8861,x:201.15,y:185.2},0).wait(1).to({scaleX:0.8767,scaleY:0.8767,x:206.1,y:185.7},0).wait(1).to({scaleX:0.8679,scaleY:0.8679,x:210.7,y:186.2},0).wait(1).to({scaleX:0.8598,scaleY:0.8598,x:215,y:186.6},0).wait(1).to({scaleX:0.8526,scaleY:0.8526,x:218.75,y:187},0).wait(1).to({scaleX:0.8462,scaleY:0.8462,x:222.15,y:187.3},0).wait(1).to({scaleX:0.8407,scaleY:0.8407,x:225.05,y:187.55},0).wait(1).to({scaleX:0.836,scaleY:0.836,x:227.5,y:187.8},0).wait(1).to({scaleX:0.8322,scaleY:0.8322,x:229.5,y:188},0).wait(1).to({scaleX:0.8291,scaleY:0.8291,x:231.1,y:188.2},0).wait(1).to({scaleX:0.8268,scaleY:0.8268,x:232.3,y:188.3},0).wait(1).to({scaleX:0.8252,scaleY:0.8252,x:233.15,y:188.4},0).wait(1).to({scaleX:0.8243,scaleY:0.8243,x:233.65,y:188.45},0).wait(1).to({regX:28.2,scaleX:0.824,scaleY:0.824,x:234},0).wait(1).to({regX:28,x:233.8},0).wait(6).to({regX:28.2,x:234},0).wait(1).to({regX:28,x:233.8},0).wait(2).to({regX:28.2,x:234},0).wait(1).to({regX:28,scaleX:0.8238,scaleY:0.8238,x:233.75,y:188.35},0).wait(1).to({scaleX:0.8235,scaleY:0.8235,x:233.7,y:188.15},0).wait(1).to({scaleX:0.8229,scaleY:0.8229,x:233.65,y:187.9},0).wait(1).to({scaleX:0.8221,scaleY:0.8221,x:233.55,y:187.6},0).wait(1).to({scaleX:0.8211,scaleY:0.8211,x:233.45,y:187.15},0).wait(1).to({scaleX:0.8197,scaleY:0.8197,x:233.25,y:186.6},0).wait(1).to({scaleX:0.8181,scaleY:0.8181,x:233.05,y:185.9},0).wait(1).to({scaleX:0.8161,scaleY:0.8161,x:232.8,y:185.05},0).wait(1).to({scaleX:0.8138,scaleY:0.8138,x:232.5,y:184.05},0).wait(1).to({scaleX:0.8109,scaleY:0.8109,x:232.15,y:182.9},0).wait(1).to({scaleX:0.8075,scaleY:0.8075,x:231.7,y:181.4},0).wait(1).to({scaleX:0.8034,scaleY:0.8034,x:231.2,y:179.7},0).wait(1).to({scaleX:0.7985,scaleY:0.7985,x:230.6,y:177.6},0).wait(1).to({scaleX:0.7925,scaleY:0.7925,x:229.85,y:175.1},0).wait(1).to({scaleX:0.7852,scaleY:0.7852,x:228.95,y:172},0).wait(1).to({scaleX:0.776,scaleY:0.776,x:227.8,y:168.15},0).wait(1).to({scaleX:0.7643,scaleY:0.7643,x:226.3,y:163.2},0).wait(1).to({scaleX:0.7488,scaleY:0.7488,x:224.35,y:156.65},0).wait(1).to({scaleX:0.7277,scaleY:0.7277,x:221.7,y:147.75},0).wait(1).to({scaleX:0.7001,scaleY:0.7001,x:218.2,y:136.1},0).wait(1).to({scaleX:0.6714,scaleY:0.6714,x:214.6,y:123.95},0).wait(1).to({scaleX:0.6483,scaleY:0.6483,x:211.7,y:114.25},0).wait(1).to({scaleX:0.6312,scaleY:0.6312,x:209.55,y:107.05},0).wait(1).to({scaleX:0.6183,scaleY:0.6183,x:207.95,y:101.55},0).wait(1).to({scaleX:0.6081,scaleY:0.6081,x:206.7,y:97.25},0).wait(1).to({scaleX:0.6,scaleY:0.6,x:205.65,y:93.85},0).wait(1).to({scaleX:0.5933,scaleY:0.5933,x:204.8,y:91.05},0).wait(1).to({scaleX:0.5877,scaleY:0.5877,x:204.1,y:88.65},0).wait(1).to({scaleX:0.5831,scaleY:0.5831,x:203.55,y:86.7},0).wait(1).to({scaleX:0.5791,scaleY:0.5791,x:203,y:85},0).wait(1).to({scaleX:0.5758,scaleY:0.5758,x:202.55,y:83.65},0).wait(1).to({scaleX:0.5729,scaleY:0.5729,x:202.25,y:82.4},0).wait(1).to({scaleX:0.5705,scaleY:0.5705,x:201.9,y:81.4},0).wait(1).to({scaleX:0.5684,scaleY:0.5684,x:201.65,y:80.5},0).wait(1).to({scaleX:0.5667,scaleY:0.5667,x:201.45,y:79.75},0).wait(1).to({scaleX:0.5653,scaleY:0.5653,x:201.3,y:79.2},0).wait(1).to({scaleX:0.5641,scaleY:0.5641,x:201.15,y:78.7},0).wait(1).to({scaleX:0.5632,scaleY:0.5632,x:201,y:78.3},0).wait(1).to({scaleX:0.5624,scaleY:0.5624,x:200.9,y:77.95},0).wait(1).to({scaleX:0.5619,scaleY:0.5619,x:200.85,y:77.75},0).wait(1).to({scaleX:0.5615,scaleY:0.5615,x:200.8,y:77.6},0).wait(1).to({scaleX:0.5613,scaleY:0.5613,x:200.75,y:77.5},0).wait(1).to({regX:28.3,scaleX:0.5612,scaleY:0.5612,x:200.95},0).wait(1));

	// l girl i shadow
	this.instance_14 = new lib.roundshadow();
	this.instance_14.setTransform(-129.35,179.15,1,1,0,0,0,28.2,22.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(22).to({_off:false},0).to({x:26.85,y:132.55,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:28,x:26.65},0).wait(25).to({regX:28.2,x:26.85},0).wait(1).to({regX:28,scaleX:0.9968,scaleY:0.9968,x:28.3,y:132.7},0).wait(1).to({scaleX:0.9925,scaleY:0.9925,x:30.55,y:132.85},0).wait(1).to({scaleX:0.987,scaleY:0.987,x:33.5,y:133.05},0).wait(1).to({scaleX:0.9802,scaleY:0.9802,x:37.05,y:133.3},0).wait(1).to({scaleX:0.972,scaleY:0.972,x:41.3,y:133.65},0).wait(1).to({scaleX:0.9625,scaleY:0.9625,x:46.3,y:134.05},0).wait(1).to({scaleX:0.9516,scaleY:0.9516,x:52.05,y:134.45},0).wait(1).to({scaleX:0.9392,scaleY:0.9392,x:58.55,y:134.95},0).wait(1).to({scaleX:0.9254,scaleY:0.9254,x:65.75,y:135.5},0).wait(1).to({scaleX:0.9101,scaleY:0.9101,x:73.8,y:136.15},0).wait(1).to({scaleX:0.8936,scaleY:0.8936,x:82.45,y:136.75},0).wait(1).to({scaleX:0.8758,scaleY:0.8758,x:91.75,y:137.5},0).wait(1).to({scaleX:0.857,scaleY:0.857,x:101.65,y:138.25},0).wait(1).to({scaleX:0.8375,scaleY:0.8375,x:111.9,y:139.05},0).wait(1).to({scaleX:0.8174,scaleY:0.8174,x:122.4,y:139.85},0).wait(1).to({scaleX:0.7972,scaleY:0.7972,x:132.95,y:140.7},0).wait(1).to({scaleX:0.7772,scaleY:0.7772,x:143.45,y:141.45},0).wait(1).to({scaleX:0.7578,scaleY:0.7578,x:153.65,y:142.25},0).wait(1).to({scaleX:0.7392,scaleY:0.7392,x:163.45,y:143},0).wait(1).to({scaleX:0.7216,scaleY:0.7216,x:172.6,y:143.7},0).wait(1).to({scaleX:0.7054,scaleY:0.7054,x:181.1,y:144.35},0).wait(1).to({scaleX:0.6906,scaleY:0.6906,x:188.9,y:144.95},0).wait(1).to({scaleX:0.6774,scaleY:0.6774,x:195.8,y:145.45},0).wait(1).to({scaleX:0.6657,scaleY:0.6657,x:201.95,y:145.95},0).wait(1).to({scaleX:0.6556,scaleY:0.6556,x:207.25,y:146.35},0).wait(1).to({scaleX:0.6471,scaleY:0.6471,x:211.7,y:146.65},0).wait(1).to({scaleX:0.64,scaleY:0.64,x:215.4,y:146.95},0).wait(1).to({scaleX:0.6344,scaleY:0.6344,x:218.35,y:147.15},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:220.6,y:147.35},0).wait(1).to({scaleX:0.6273,scaleY:0.6273,x:222.1,y:147.45},0).wait(1).to({scaleX:0.6256,scaleY:0.6256,x:223,y:147.5},0).wait(1).to({regX:28.3,scaleX:0.625,scaleY:0.625,x:223.5,y:147.55},0).wait(1).to({regX:28,x:223.3},0).wait(4).to({regX:28.3,x:223.5},0).wait(1).to({regX:28,x:223.3},0).wait(4).to({regX:28.3,x:223.5},0).wait(1).to({regX:28,scaleX:0.6249,scaleY:0.6249,x:223.3,y:147.45},0).wait(1).to({scaleX:0.6248,scaleY:0.6248,y:147.35},0).wait(1).to({scaleX:0.6247,scaleY:0.6247,y:147.15},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:223.35,y:146.9},0).wait(1).to({scaleX:0.6241,scaleY:0.6241,x:223.4,y:146.55},0).wait(1).to({scaleX:0.6237,scaleY:0.6237,x:223.35,y:146.1},0).wait(1).to({scaleX:0.6232,scaleY:0.6232,x:223.45,y:145.55},0).wait(1).to({scaleX:0.6226,scaleY:0.6226,x:223.5,y:144.9},0).wait(1).to({scaleX:0.6219,scaleY:0.6219,x:223.55,y:144.1},0).wait(1).to({scaleX:0.621,scaleY:0.621,x:223.65,y:143.1},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:223.7,y:141.95},0).wait(1).to({scaleX:0.6187,scaleY:0.6187,x:223.8,y:140.5},0).wait(1).to({scaleX:0.6171,scaleY:0.6171,x:224,y:138.75},0).wait(1).to({scaleX:0.6152,scaleY:0.6152,x:224.15,y:136.6},0).wait(1).to({scaleX:0.6128,scaleY:0.6128,x:224.35,y:133.9},0).wait(1).to({scaleX:0.6096,scaleY:0.6096,x:224.6,y:130.45},0).wait(1).to({scaleX:0.6055,scaleY:0.6055,x:225,y:125.8},0).wait(1).to({scaleX:0.5998,scaleY:0.5998,x:225.55,y:119.45},0).wait(1).to({scaleX:0.5921,scaleY:0.5921,x:226.2,y:110.95},0).wait(1).to({scaleX:0.584,scaleY:0.584,x:226.95,y:101.9},0).wait(1).to({scaleX:0.5775,scaleY:0.5775,x:227.5,y:94.65},0).wait(1).to({scaleX:0.5727,scaleY:0.5727,x:227.95,y:89.35},0).wait(1).to({scaleX:0.5691,scaleY:0.5691,x:228.25,y:85.4},0).wait(1).to({scaleX:0.5664,scaleY:0.5664,x:228.5,y:82.3},0).wait(1).to({scaleX:0.5642,scaleY:0.5642,x:228.7,y:79.85},0).wait(1).to({scaleX:0.5624,scaleY:0.5624,x:228.85,y:77.85},0).wait(1).to({scaleX:0.5609,scaleY:0.5609,x:229,y:76.2},0).wait(1).to({scaleX:0.5596,scaleY:0.5596,x:229.1,y:74.8},0).wait(1).to({scaleX:0.5586,scaleY:0.5586,x:229.2,y:73.65},0).wait(1).to({scaleX:0.5577,scaleY:0.5577,x:229.25,y:72.65},0).wait(1).to({scaleX:0.5569,scaleY:0.5569,x:229.35,y:71.85},0).wait(1).to({scaleX:0.5563,scaleY:0.5563,x:229.4,y:71.15},0).wait(1).to({scaleX:0.5558,scaleY:0.5558,x:229.45,y:70.55},0).wait(1).to({scaleX:0.5554,scaleY:0.5554,x:229.5,y:70.05},0).wait(1).to({scaleX:0.555,scaleY:0.555,y:69.7},0).wait(1).to({scaleX:0.5547,scaleY:0.5547,x:229.55,y:69.35},0).wait(1).to({scaleX:0.5545,scaleY:0.5545,x:229.6,y:69.15},0).wait(1).to({scaleX:0.5543,scaleY:0.5543,x:229.55,y:68.95},0).wait(1).to({scaleX:0.5542,scaleY:0.5542,y:68.85},0).wait(1).to({y:68.75},0).wait(1).to({regX:28.3,regY:23,scaleX:0.5541,scaleY:0.5541,x:229.8},0).wait(1));

	// l girl box shadow
	this.instance_15 = new lib.squareshadow();
	this.instance_15.setTransform(-77.95,180.65,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(22).to({_off:false},0).to({x:82.6,y:140.55,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:82.45},0).wait(25).to({regX:70.8,x:82.6},0).wait(1).to({regX:70.6,scaleX:0.6772,scaleY:0.6772,x:83.85,y:140.6,alpha:0.1588},0).wait(1).to({scaleX:0.6734,scaleY:0.6734,x:85.75,y:140.8,alpha:0.1571},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,x:88.2,y:141,alpha:0.1548},0).wait(1).to({scaleX:0.6626,scaleY:0.6626,x:91.2,y:141.2,alpha:0.152},0).wait(1).to({scaleX:0.6554,scaleY:0.6554,x:94.75,y:141.5,alpha:0.1486},0).wait(1).to({scaleX:0.647,scaleY:0.647,x:98.95,y:141.85,alpha:0.1447},0).wait(1).to({scaleX:0.6373,scaleY:0.6373,x:103.75,y:142.2,alpha:0.1402},0).wait(1).to({scaleX:0.6264,scaleY:0.6264,x:109.25,y:142.65,alpha:0.135},0).wait(1).to({scaleX:0.6141,scaleY:0.6141,x:115.4,y:143.1,alpha:0.1292},0).wait(1).to({scaleX:0.6005,scaleY:0.6005,x:122.2,y:143.65,alpha:0.1229},0).wait(1).to({scaleX:0.5856,scaleY:0.5856,x:129.6,y:144.25,alpha:0.1159},0).wait(1).to({scaleX:0.5696,scaleY:0.5696,x:137.6,y:144.9,alpha:0.1084},0).wait(1).to({scaleX:0.5526,scaleY:0.5526,x:146.1,y:145.55,alpha:0.1004},0).wait(1).to({scaleX:0.5348,scaleY:0.5348,x:155,y:146.25,alpha:0.0921},0).wait(1).to({scaleX:0.5164,scaleY:0.5164,x:164.2,y:147,alpha:0.0835},0).wait(1).to({scaleX:0.4978,scaleY:0.4978,x:173.5,y:147.7,alpha:0.0748},0).wait(1).to({scaleX:0.4794,scaleY:0.4794,x:182.7,y:148.4,alpha:0.0661},0).wait(1).to({scaleX:0.4613,scaleY:0.4613,x:191.7,y:149.15,alpha:0.0577},0).wait(1).to({scaleX:0.444,scaleY:0.444,x:200.35,y:149.85,alpha:0.0496},0).wait(1).to({scaleX:0.4278,scaleY:0.4278,x:208.5,y:150.45,alpha:0.0419},0).wait(1).to({scaleX:0.4127,scaleY:0.4127,x:216.05,y:151.1,alpha:0.0349},0).wait(1).to({scaleX:0.3989,scaleY:0.3989,x:222.9,y:151.55,alpha:0.0284},0).wait(1).to({scaleX:0.3866,scaleY:0.3866,x:229.05,y:152.1,alpha:0.0227},0).wait(1).to({scaleX:0.3758,scaleY:0.3758,x:234.5,y:152.5,alpha:0.0176},0).wait(1).to({scaleX:0.3664,scaleY:0.3664,x:239.1,y:152.85,alpha:0.0132},0).wait(1).to({scaleX:0.3586,scaleY:0.3586,x:243.05,y:153.2,alpha:0.0095},0).wait(1).to({scaleX:0.3521,scaleY:0.3521,x:246.3,y:153.45,alpha:0.0065},0).wait(1).to({scaleX:0.3469,scaleY:0.3469,x:248.9,y:153.65,alpha:0.004},0).wait(1).to({scaleX:0.343,scaleY:0.343,x:250.85,y:153.8,alpha:0.0022},0).wait(1).to({scaleX:0.3403,scaleY:0.3403,x:252.2,y:153.9,alpha:0.001},0).wait(1).to({scaleX:0.3388,scaleY:0.3388,x:252.95,y:153.95,alpha:0.0002},0).wait(1).to({regX:71.1,regY:48.1,scaleX:0.3383,scaleY:0.3383,x:253.3,y:154,alpha:0},0).wait(52));

	// r girl box shadow
	this.instance_16 = new lib.fill();
	this.instance_16.setTransform(253.7,154,1,1,0,0,0,32.5,30.1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(109).to({_off:false},0).to({alpha:1},9).wait(55));

	// r guy box shadow
	this.instance_17 = new lib.squareshadow();
	this.instance_17.setTransform(226.05,-55.6,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	var maskedShapeInstanceList = [this.instance_17];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(29).to({_off:false},0).to({x:210.2,y:22.9,alpha:0.1602},37,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:210.1},0).wait(22).to({regX:70.7,x:210.2},0).wait(1).to({regX:70.6,scaleX:0.544,scaleY:0.5433,x:211.55,y:24.45},0).wait(1).to({scaleX:0.542,scaleY:0.5405,x:213.25,y:26.25},0).wait(1).to({scaleX:0.5397,scaleY:0.5373,x:215.25,y:28.35},0).wait(1).to({scaleX:0.5371,scaleY:0.5337,x:217.5,y:30.75},0).wait(1).to({scaleX:0.5342,scaleY:0.5296,x:220,y:33.4},0).wait(1).to({scaleX:0.5311,scaleY:0.5252,x:222.8,y:36.35},0).wait(1).to({scaleX:0.5276,scaleY:0.5204,x:225.75,y:39.5},0).wait(1).to({scaleX:0.5239,scaleY:0.5152,x:228.95,y:42.95},0).wait(1).to({scaleX:0.5201,scaleY:0.5098,x:232.3,y:46.45},0).wait(1).to({scaleX:0.516,scaleY:0.5042,x:235.8,y:50.2},0).wait(1).to({scaleX:0.5119,scaleY:0.4984,x:239.4,y:53.95},0).wait(1).to({scaleX:0.5078,scaleY:0.4926,x:243,y:57.85},0).wait(1).to({scaleX:0.5036,scaleY:0.4868,x:246.6,y:61.65},0).wait(1).to({scaleX:0.4996,scaleY:0.4811,x:250.1,y:65.4},0).wait(1).to({scaleX:0.4956,scaleY:0.4756,x:253.55,y:69.05},0).wait(1).to({scaleX:0.4919,scaleY:0.4703,x:256.8,y:72.55},0).wait(1).to({scaleX:0.4883,scaleY:0.4654,x:259.9,y:75.75},0).wait(1).to({scaleX:0.4851,scaleY:0.4608,x:262.7,y:78.8},0).wait(1).to({scaleX:0.4821,scaleY:0.4566,x:265.3,y:81.55},0).wait(1).to({scaleX:0.4794,scaleY:0.4528,x:267.65,y:84.05},0).wait(1).to({scaleX:0.477,scaleY:0.4495,x:269.7,y:86.25},0).wait(1).to({scaleX:0.4749,scaleY:0.4465,x:271.55,y:88.2},0).wait(1).to({scaleX:0.4731,scaleY:0.444,x:273.1,y:89.85},0).wait(1).to({scaleX:0.4716,scaleY:0.442,x:274.35,y:91.2},0).wait(1).to({scaleX:0.4705,scaleY:0.4403,x:275.4,y:92.3},0).wait(1).to({scaleX:0.4695,scaleY:0.4391,x:276.15,y:93.15},0).wait(1).to({scaleX:0.4689,scaleY:0.4382,x:276.7,y:93.7},0).wait(1).to({scaleX:0.4685,scaleY:0.4377,x:277.05,y:94},0).wait(1).to({regX:70.7,regY:48,scaleX:0.4684,scaleY:0.4375,x:277.2,y:94.15},0).wait(55));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(30.9,74.85,0.2637,0.2637,0,0,0,225.1,236.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(67).to({regX:232.4,regY:219.8,x:32.85,y:70.4},0).wait(22).to({regX:225.1,regY:236.7,x:30.9,y:74.85},0).wait(1).to({regX:232.4,regY:219.8,scaleX:0.2642,scaleY:0.2642,x:33,y:70.65},0).wait(1).to({scaleX:0.2649,scaleY:0.2649,x:33.2,y:71.1},0).wait(1).to({scaleX:0.266,scaleY:0.266,x:33.5,y:71.65},0).wait(1).to({scaleX:0.2674,scaleY:0.2674,x:33.95,y:72.5},0).wait(1).to({scaleX:0.2692,scaleY:0.2692,x:34.45,y:73.55},0).wait(1).to({scaleX:0.2715,scaleY:0.2715,x:35.1,y:74.75},0).wait(1).to({scaleX:0.2741,scaleY:0.2741,x:35.85,y:76.25},0).wait(1).to({scaleX:0.2771,scaleY:0.2771,x:36.75,y:77.95},0).wait(1).to({scaleX:0.2806,scaleY:0.2806,x:37.75,y:79.95},0).wait(1).to({scaleX:0.2845,scaleY:0.2845,x:38.85,y:82.1},0).wait(1).to({scaleX:0.2887,scaleY:0.2887,x:40.1,y:84.5},0).wait(1).to({scaleX:0.2933,scaleY:0.2933,x:41.4,y:87.05},0).wait(1).to({scaleX:0.298,scaleY:0.298,x:42.75,y:89.7},0).wait(1).to({scaleX:0.3029,scaleY:0.3029,x:44.2,y:92.45},0).wait(1).to({scaleX:0.3077,scaleY:0.3077,x:45.55,y:95.2},0).wait(1).to({scaleX:0.3124,scaleY:0.3124,x:46.9,y:97.8},0).wait(1).to({scaleX:0.3168,scaleY:0.3168,x:48.15,y:100.3},0).wait(1).to({scaleX:0.3209,scaleY:0.3209,x:49.4,y:102.65},0).wait(1).to({scaleX:0.3247,scaleY:0.3247,x:50.45,y:104.75},0).wait(1).to({scaleX:0.3281,scaleY:0.3281,x:51.45,y:106.65},0).wait(1).to({scaleX:0.331,scaleY:0.331,x:52.3,y:108.3},0).wait(1).to({scaleX:0.3336,scaleY:0.3336,x:53.05,y:109.8},0).wait(1).to({scaleX:0.3358,scaleY:0.3358,x:53.7,y:111},0).wait(1).to({scaleX:0.3377,scaleY:0.3377,x:54.25,y:112.05},0).wait(1).to({scaleX:0.3392,scaleY:0.3392,x:54.65,y:112.9},0).wait(1).to({scaleX:0.3404,scaleY:0.3404,x:55,y:113.6},0).wait(1).to({scaleX:0.3413,scaleY:0.3413,x:55.25,y:114.1},0).wait(1).to({scaleX:0.3419,scaleY:0.3419,x:55.4,y:114.45},0).wait(1).to({regX:225,regY:236.8,scaleX:0.3423,scaleY:0.3423,x:53,y:120.45},0).wait(55));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(101.95,79.4,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(27).to({regY:15.2,scaleX:0.7599,scaleY:0.7599,x:84,y:86.75},21,cjs.Ease.quadInOut).wait(19).to({regX:38,regY:15.3,x:84.1,y:86.85},0).wait(22).to({regX:37.9,regY:15.2,x:84,y:86.75},0).wait(1).to({regX:38,regY:15.3,scaleX:0.7612,scaleY:0.7612,x:84.3,y:87.1},0).wait(1).to({scaleX:0.7634,scaleY:0.7634,x:84.65,y:87.6},0).wait(1).to({scaleX:0.7665,scaleY:0.7665,x:85.2,y:88.25},0).wait(1).to({scaleX:0.7706,scaleY:0.7706,x:85.85,y:89.15},0).wait(1).to({scaleX:0.7759,scaleY:0.7759,x:86.75,y:90.25},0).wait(1).to({scaleX:0.7822,scaleY:0.7822,x:87.75,y:91.65},0).wait(1).to({scaleX:0.7898,scaleY:0.7898,x:89.05,y:93.3},0).wait(1).to({scaleX:0.7986,scaleY:0.7986,x:90.55,y:95.2},0).wait(1).to({scaleX:0.8086,scaleY:0.8086,x:92.25,y:97.35},0).wait(1).to({scaleX:0.8198,scaleY:0.8198,x:94.1,y:99.8},0).wait(1).to({scaleX:0.8321,scaleY:0.8321,x:96.15,y:102.5},0).wait(1).to({scaleX:0.8452,scaleY:0.8452,x:98.3,y:105.35},0).wait(1).to({scaleX:0.8588,scaleY:0.8588,x:100.65,y:108.3},0).wait(1).to({scaleX:0.8728,scaleY:0.8728,x:102.95,y:111.3},0).wait(1).to({scaleX:0.8867,scaleY:0.8867,x:105.3,y:114.3},0).wait(1).to({scaleX:0.9001,scaleY:0.9001,x:107.55,y:117.2},0).wait(1).to({scaleX:0.9129,scaleY:0.9129,x:109.7,y:120},0).wait(1).to({scaleX:0.9248,scaleY:0.9248,x:111.7,y:122.6},0).wait(1).to({scaleX:0.9357,scaleY:0.9357,x:113.5,y:124.95},0).wait(1).to({scaleX:0.9454,scaleY:0.9454,x:115.15,y:127.05},0).wait(1).to({scaleX:0.954,scaleY:0.954,x:116.6,y:128.95},0).wait(1).to({scaleX:0.9615,scaleY:0.9615,x:117.85,y:130.55},0).wait(1).to({scaleX:0.9679,scaleY:0.9679,x:118.9,y:131.95},0).wait(1).to({scaleX:0.9732,scaleY:0.9732,x:119.8,y:133.1},0).wait(1).to({scaleX:0.9776,scaleY:0.9776,x:120.5,y:134.05},0).wait(1).to({scaleX:0.981,scaleY:0.981,x:121.1,y:134.8},0).wait(1).to({scaleX:0.9836,scaleY:0.9836,x:121.55,y:135.35},0).wait(1).to({scaleX:0.9854,scaleY:0.9854,x:121.85,y:135.75},0).wait(1).to({regX:37.9,regY:15.2,scaleX:0.9864,scaleY:0.9864,x:121.95,y:135.85},0).wait(55));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(96.85,82.55,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(27).to({regX:37.7,regY:15.7,scaleX:0.7718,scaleY:0.7718,x:84,y:86.75},21,cjs.Ease.quadInOut).to({alpha:0},18,cjs.Ease.quadOut).wait(107));

	// first image
	this.instance_18 = new lib.firstimage_1();
	this.instance_18.setTransform(211.45,64.75,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(32).to({regX:42,regY:26.6,scaleX:0.576,scaleY:0.576,x:214.6,y:73.55},22,cjs.Ease.quadInOut).wait(13).to({regX:41,regY:25.6,x:214,y:73},0).wait(22).to({regX:42,regY:26.6,x:214.6,y:73.55},0).wait(1).to({regX:41,regY:25.6,scaleX:0.577,scaleY:0.577,x:214.45,y:73.25},0).wait(1).to({scaleX:0.5786,scaleY:0.5786,x:215.15,y:73.7},0).wait(1).to({scaleX:0.581,scaleY:0.581,x:216.25,y:74.35},0).wait(1).to({scaleX:0.5841,scaleY:0.5841,x:217.7,y:75.25},0).wait(1).to({scaleX:0.5881,scaleY:0.5881,x:219.5,y:76.4},0).wait(1).to({scaleX:0.5929,scaleY:0.5929,x:221.7,y:77.8},0).wait(1).to({scaleX:0.5986,scaleY:0.5986,x:224.3,y:79.4},0).wait(1).to({scaleX:0.6053,scaleY:0.6053,x:227.35,y:81.3},0).wait(1).to({scaleX:0.6129,scaleY:0.6129,x:230.85,y:83.45},0).wait(1).to({scaleX:0.6214,scaleY:0.6214,x:234.7,y:85.8},0).wait(1).to({scaleX:0.6307,scaleY:0.6307,x:238.9,y:88.45},0).wait(1).to({scaleX:0.6406,scaleY:0.6406,x:243.4,y:91.25},0).wait(1).to({scaleX:0.651,scaleY:0.651,x:248.15,y:94.2},0).wait(1).to({scaleX:0.6616,scaleY:0.6616,x:252.95,y:97.2},0).wait(1).to({scaleX:0.6721,scaleY:0.6721,x:257.75,y:100.15},0).wait(1).to({scaleX:0.6823,scaleY:0.6823,x:262.4,y:103.05},0).wait(1).to({scaleX:0.692,scaleY:0.692,x:266.8,y:105.8},0).wait(1).to({scaleX:0.701,scaleY:0.701,x:270.95,y:108.35},0).wait(1).to({scaleX:0.7092,scaleY:0.7092,x:274.7,y:110.7},0).wait(1).to({scaleX:0.7166,scaleY:0.7166,x:278.1,y:112.8},0).wait(1).to({scaleX:0.7231,scaleY:0.7231,x:281.05,y:114.6},0).wait(1).to({scaleX:0.7288,scaleY:0.7288,x:283.6,y:116.2},0).wait(1).to({scaleX:0.7336,scaleY:0.7336,x:285.85,y:117.6},0).wait(1).to({scaleX:0.7376,scaleY:0.7376,x:287.65,y:118.75},0).wait(1).to({scaleX:0.7409,scaleY:0.7409,x:289.15,y:119.65},0).wait(1).to({scaleX:0.7436,scaleY:0.7436,x:290.35,y:120.4},0).wait(1).to({scaleX:0.7455,scaleY:0.7455,x:291.2,y:121},0).wait(1).to({scaleX:0.7469,scaleY:0.7469,x:291.85,y:121.35},0).wait(1).to({regX:42.1,regY:26.7,scaleX:0.7477,scaleY:0.7477,x:293.05,y:122.3},0).wait(55));

	// square shadow
	this.instance_19 = new lib.squareshadow();
	this.instance_19.setTransform(209.9,68.35,0.4651,0.4621,0,0,0,71,48);
	this.instance_19.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(32).to({regX:71.3,regY:48.3,scaleX:0.325,scaleY:0.3131,x:214.4,y:73.65},22,cjs.Ease.quadInOut).to({_off:true},1).wait(118));

	// second image
	this.instance_20 = new lib.secondimage();
	this.instance_20.setTransform(225.95,91.45,0.7473,0.7473,0,0,0,41.9,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(35).to({regX:42,regY:26.4,scaleX:0.5752,scaleY:0.5752,y:94.6},22,cjs.Ease.quadInOut).wait(10).to({regX:42.1,regY:26.8,x:226,y:94.8},0).wait(22).to({regX:42,regY:26.4,x:225.95,y:94.6},0).wait(1).to({regX:42.1,regY:26.8,scaleX:0.5762,scaleY:0.5762,x:226.45,y:95.1},0).wait(1).to({scaleX:0.5778,scaleY:0.5778,x:227.25,y:95.65},0).wait(1).to({scaleX:0.5802,scaleY:0.5802,x:228.35,y:96.4},0).wait(1).to({scaleX:0.5833,scaleY:0.5833,x:229.85,y:97.4},0).wait(1).to({scaleX:0.5872,scaleY:0.5872,x:231.75,y:98.7},0).wait(1).to({scaleX:0.5921,scaleY:0.5921,x:234.05,y:100.2},0).wait(1).to({scaleX:0.5978,scaleY:0.5978,x:236.75,y:102.05},0).wait(1).to({scaleX:0.6045,scaleY:0.6045,x:239.95,y:104.2},0).wait(1).to({scaleX:0.6121,scaleY:0.6121,x:243.55,y:106.65},0).wait(1).to({scaleX:0.6205,scaleY:0.6205,x:247.6,y:109.4},0).wait(1).to({scaleX:0.6298,scaleY:0.6298,x:252.05,y:112.35},0).wait(1).to({scaleX:0.6397,scaleY:0.6397,x:256.8,y:115.55},0).wait(1).to({scaleX:0.6501,scaleY:0.6501,x:261.7,y:118.85},0).wait(1).to({scaleX:0.6606,scaleY:0.6606,x:266.7,y:122.25},0).wait(1).to({scaleX:0.6711,scaleY:0.6711,x:271.75,y:125.65},0).wait(1).to({scaleX:0.6813,scaleY:0.6813,x:276.6,y:128.9},0).wait(1).to({scaleX:0.691,scaleY:0.691,x:281.25,y:132},0).wait(1).to({scaleX:0.7,scaleY:0.7,x:285.5,y:134.9},0).wait(1).to({scaleX:0.7082,scaleY:0.7082,x:289.4,y:137.55},0).wait(1).to({scaleX:0.7156,scaleY:0.7156,x:292.95,y:139.9},0).wait(1).to({scaleX:0.7221,scaleY:0.7221,x:296.05,y:142},0).wait(1).to({scaleX:0.7277,scaleY:0.7277,x:298.75,y:143.8},0).wait(1).to({scaleX:0.7326,scaleY:0.7326,x:301.05,y:145.35},0).wait(1).to({scaleX:0.7366,scaleY:0.7366,x:302.95,y:146.65},0).wait(1).to({scaleX:0.7399,scaleY:0.7399,x:304.55,y:147.75},0).wait(1).to({scaleX:0.7425,scaleY:0.7425,x:305.75,y:148.55},0).wait(1).to({scaleX:0.7445,scaleY:0.7445,x:306.7,y:149.2},0).wait(1).to({scaleX:0.7458,scaleY:0.7458,x:307.35,y:149.65},0).wait(1).to({regY:26.4,scaleX:0.7466,scaleY:0.7466,x:307.75,y:149.55},0).wait(55));

	// square shadow
	this.instance_21 = new lib.squareshadow();
	this.instance_21.setTransform(224.6,95.95,0.4651,0.4621,0,0,0,70.9,48.1);
	this.instance_21.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(35).to({regX:71.2,regY:48.4,scaleX:0.3475,scaleY:0.2831,x:226.05,y:95.2},22,cjs.Ease.quadInOut).to({_off:true},1).wait(115));

	// screen
	this.instance_22 = new lib.WordUI();
	this.instance_22.setTransform(155.1,94.8,0.8368,0.8368,0,0,0,151,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(67).to({regX:150.7,regY:96.1,x:154.85,y:94.95},0).wait(22).to({regX:151,regY:95.9,x:155.1,y:94.8},0).wait(1).to({regX:150.7,regY:96.1,scaleX:0.8383,scaleY:0.8383,x:155.2,y:95.25},0).wait(1).to({scaleX:0.8407,scaleY:0.8407,x:155.75,y:95.75},0).wait(1).to({scaleX:0.8441,scaleY:0.8441,x:156.55,y:96.45},0).wait(1).to({scaleX:0.8487,scaleY:0.8487,x:157.65,y:97.4},0).wait(1).to({scaleX:0.8544,scaleY:0.8544,x:159,y:98.55},0).wait(1).to({scaleX:0.8614,scaleY:0.8614,x:160.65,y:100.05},0).wait(1).to({scaleX:0.8698,scaleY:0.8698,x:162.6,y:101.75},0).wait(1).to({scaleX:0.8795,scaleY:0.8795,x:164.95,y:103.75},0).wait(1).to({scaleX:0.8905,scaleY:0.8905,x:167.55,y:106.05},0).wait(1).to({scaleX:0.9028,scaleY:0.9028,x:170.45,y:108.55},0).wait(1).to({scaleX:0.9163,scaleY:0.9163,x:173.65,y:111.35},0).wait(1).to({scaleX:0.9307,scaleY:0.9307,x:177.05,y:114.35},0).wait(1).to({scaleX:0.9458,scaleY:0.9458,x:180.6,y:117.45},0).wait(1).to({scaleX:0.9612,scaleY:0.9612,x:184.25,y:120.6},0).wait(1).to({scaleX:0.9764,scaleY:0.9764,x:187.85,y:123.8},0).wait(1).to({scaleX:0.9913,scaleY:0.9913,x:191.35,y:126.85},0).wait(1).to({scaleX:1.0054,scaleY:1.0054,x:194.7,y:129.75},0).wait(1).to({scaleX:1.0185,scaleY:1.0185,x:197.8,y:132.45},0).wait(1).to({scaleX:1.0304,scaleY:1.0304,x:200.65,y:134.9},0).wait(1).to({scaleX:1.0411,scaleY:1.0411,x:203.15,y:137.15},0).wait(1).to({scaleX:1.0506,scaleY:1.0506,x:205.4,y:139.1},0).wait(1).to({scaleX:1.0588,scaleY:1.0588,x:207.3,y:140.8},0).wait(1).to({scaleX:1.0659,scaleY:1.0659,x:208.95,y:142.25},0).wait(1).to({scaleX:1.0717,scaleY:1.0717,x:210.35,y:143.45},0).wait(1).to({scaleX:1.0765,scaleY:1.0765,x:211.55,y:144.45},0).wait(1).to({scaleX:1.0803,scaleY:1.0803,x:212.4,y:145.2},0).wait(1).to({scaleX:1.0832,scaleY:1.0832,x:213.1,y:145.85},0).wait(1).to({scaleX:1.0851,scaleY:1.0851,x:213.55,y:146.25},0).wait(1).to({regX:151,regY:95.9,scaleX:1.0863,scaleY:1.0863,x:214.2,y:146.3},0).wait(55));

	// screen shadow
	this.instance_23 = new lib.shadow_1();
	this.instance_23.setTransform(128.5,74.8,0.7,0.7,0,0,0,180.7,119.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(66).to({regX:180.6,regY:119.8,x:128.4,y:74.85},0).wait(1).to({regX:189.8,regY:149.6,x:134.85,y:95.7},0).wait(22).to({regX:180.6,regY:119.8,x:128.4,y:74.85},0).wait(1).to({regX:189.8,regY:149.6,scaleX:0.7011,scaleY:0.7011,x:135.1,y:96.1},0).wait(1).to({scaleX:0.7031,scaleY:0.7031,x:135.7,y:96.65},0).wait(1).to({scaleX:0.7058,scaleY:0.7058,x:136.4,y:97.4},0).wait(1).to({scaleX:0.7095,scaleY:0.7095,x:137.4,y:98.45},0).wait(1).to({scaleX:0.7141,scaleY:0.7141,x:138.65,y:99.75},0).wait(1).to({scaleX:0.7197,scaleY:0.7197,x:140.2,y:101.35},0).wait(1).to({scaleX:0.7264,scaleY:0.7264,x:142,y:103.25},0).wait(1).to({scaleX:0.7342,scaleY:0.7342,x:144.1,y:105.5},0).wait(1).to({scaleX:0.743,scaleY:0.743,x:146.5,y:108},0).wait(1).to({scaleX:0.7529,scaleY:0.7529,x:149.2,y:110.85},0).wait(1).to({scaleX:0.7637,scaleY:0.7637,x:152.1,y:113.9},0).wait(1).to({scaleX:0.7753,scaleY:0.7753,x:155.25,y:117.2},0).wait(1).to({scaleX:0.7873,scaleY:0.7873,x:158.55,y:120.65},0).wait(1).to({scaleX:0.7997,scaleY:0.7997,x:161.85,y:124.15},0).wait(1).to({scaleX:0.8119,scaleY:0.8119,x:165.2,y:127.6},0).wait(1).to({scaleX:0.8238,scaleY:0.8238,x:168.45,y:131},0).wait(1).to({scaleX:0.8351,scaleY:0.8351,x:171.5,y:134.25},0).wait(1).to({scaleX:0.8456,scaleY:0.8456,x:174.35,y:137.25},0).wait(1).to({scaleX:0.8552,scaleY:0.8552,x:176.95,y:140},0).wait(1).to({scaleX:0.8638,scaleY:0.8638,x:179.3,y:142.4},0).wait(1).to({scaleX:0.8714,scaleY:0.8714,x:181.35,y:144.6},0).wait(1).to({scaleX:0.8779,scaleY:0.8779,x:183.15,y:146.45},0).wait(1).to({scaleX:0.8836,scaleY:0.8836,x:184.65,y:148.1},0).wait(1).to({scaleX:0.8883,scaleY:0.8883,x:185.95,y:149.4},0).wait(1).to({scaleX:0.8921,scaleY:0.8921,x:186.95,y:150.5},0).wait(1).to({scaleX:0.8952,scaleY:0.8952,x:187.8,y:151.35},0).wait(1).to({scaleX:0.8974,scaleY:0.8974,x:188.45,y:152},0).wait(1).to({scaleX:0.899,scaleY:0.899,x:188.85,y:152.5},0).wait(1).to({regX:181,regY:120,scaleX:0.9,scaleY:0.9,x:180.9,y:126},0).wait(55));

	// Layer_2
	this.ribbon_1 = new lib.ribbon();
	this.ribbon_1.name = "ribbon_1";
	this.ribbon_1.setTransform(-71.95,-81,1.2761,1.2761,0,0,0,-0.1,-0.1);
	this.ribbon_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon_1).wait(84).to({_off:false},0).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-144.8,-106.7,1662.2,382.5);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{chart:4,vanish:55});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(74).call(this.frame_74).wait(1));

	// Layer_7
	this.instance = new lib.excel_screen_white();
	this.instance.setTransform(115.65,-128.65,1,1,0,0,0,225.3,151.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61).to({_off:false},0).to({alpha:0.6016},13,cjs.Ease.cubicInOut).wait(1));

	// Layer_5
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(-19.5,-91.65);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({alpha:1},2,cjs.Ease.cubicInOut).wait(14));

	// Layer_3
	this.instance_2 = new lib.Rectangle111sml();
	this.instance_2.setTransform(-109.45,7.9,1.5099,1.5099);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75));

	// SmallGraphCover
	this.instance_3 = new lib.whitebar();
	this.instance_3.setTransform(284.05,-150.1,1.1639,1.0777,0,0,0,17.8,38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({regX:17.9,scaleX:1.4222,x:288.8},0).to({scaleX:1.2503,scaleY:0.5617,x:285.75,y:-189.9},51,cjs.Ease.quartInOut).wait(20));

	// SmallGraph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4AA167").s().p("Ai/JMIAAyXIF/AAIAASXg");
	this.shape.setTransform(282.6,-128.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#327545").s().p("Ai/KhIAA1BIF/AAIAACpIAASYg");
	this.shape_1.setTransform(244.175,-136.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(75));

	// Layer_6
	this.chart_mask = new lib.chart_mask();
	this.chart_mask.name = "chart_mask";
	this.chart_mask.setTransform(-29.15,-97.5,1,1,0,0,0,59.1,63);
	this.chart_mask.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.chart_mask).wait(75));

	// Text
	this.instance_4 = new lib.textanimation("synched",0,false);
	this.instance_4.setTransform(-26.65,-93.55,1,1,0,0,0,33.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(75));

	// GraphMask
	this.instance_5 = new lib.GraphCover("synched",0,false);
	this.instance_5.setTransform(-57.95,-124.7,1,1,0,0,0,28.9,28.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(75));

	// Graph_LG
	this.instance_6 = new lib.graphLG();
	this.instance_6.setTransform(-28.95,-95.65,1,1,0,0,0,49.9,49.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(75));

	// UI
	this.instance_7 = new lib.UI();
	this.instance_7.setTransform(115.85,-274.1,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,-279.6,471.79999999999995,305.70000000000005);


(lib.Pop_up_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.opt3 = new lib.option_btn();
	this.opt3.name = "opt3";
	this.opt3.setTransform(134.5,70.3,1,1,0,0,0,134.5,14.3);

	this.opt2 = new lib.option_btn();
	this.opt2.name = "opt2";
	this.opt2.setTransform(134.5,42.8,1,1,0,0,0,134.5,14.3);

	this.opt1 = new lib.option_btn();
	this.opt1.name = "opt1";
	this.opt1.setTransform(0,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.opt1},{t:this.opt2},{t:this.opt3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Pop_up_menu, new cjs.Rectangle(-0.2,0.8,197.5,83), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(83.3,14.5,0.6,0.6,0,0,0,13.8,10.8);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(57.4,15.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("An1CLIAAkVIPrAAIAAEVg");
	this.shape.setTransform(50.125,13.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D7").s().p("An2CMIAAkXIPsAAIAAEXg");
	this.shape_1.setTransform(50.2,13.925);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,-0.1,100.5,28.1), null);


(lib.screenanimationexcel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		//this.title_s.cache(-38,-15.7,152,63,2);
	}
	this.frame_44 = function() {
		this.screen.gotoAndPlay("chart");
	}
	this.frame_99 = function() {
		this.td_graph.gotoAndPlay("grow");
	}
	this.frame_160 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(55).call(this.frame_99).wait(61).call(this.frame_160).wait(1));

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.setTransform(23.15,1.55,0.7883,0.7883,0,0,0,64.7,62.9);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(89).to({scaleX:0.9951,scaleY:0.9951,x:51.35,y:48.15},30,cjs.Ease.cubicInOut).wait(42));

	// td_graph
	this.td_graph = new lib._3D_price();
	this.td_graph.name = "td_graph";
	this.td_graph.setTransform(94.7,59,0.3993,0.3586,0,0,0,5,0.7);

	this.timeline.addTween(cjs.Tween.get(this.td_graph).wait(89).to({regY:0.8,scaleX:0.5041,scaleY:0.4526,x:141.6,y:120.65},30,cjs.Ease.cubicInOut).wait(42));

	// screen3
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(140,22.85,0.4713,0.3772,0,-28.3398,-17.0422,107.4,-133.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(89).to({regX:107.5,regY:-133.7,scaleX:0.5949,scaleY:0.4762,skewX:-28.3389,skewY:-17.0407,x:198.85,y:74.95},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_2
	this.instance = new lib.shadow_1();
	this.instance.setTransform(120,6.25,0.72,0.72,0,0,0,180.6,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:180.8,regY:119.4,x:120.15,y:5.95},0).to({regX:180.6,regY:119.8,scaleX:0.9,scaleY:0.9,x:172.05,y:56},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_4
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-56.7,-136.2,1.25,1.25,0,0,0,-0.1,-0.1);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.1,-128.6,410.5,334.6);


(lib.object_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.screen = new lib.screenanimation_1();
	this.screen.name = "screen";
	this.screen.setTransform(6.7,175.4,0.79,0.79,0,0,0,196.9,130.8);

	this.screen_1 = new lib.screenanimation();
	this.screen_1.name = "screen_1";
	this.screen_1.setTransform(9.3,146.35,1,1,0,0,0,197.1,130.8);

	this.screen_2 = new lib.screenanimationexcel();
	this.screen_2.name = "screen_2";
	this.screen_2.setTransform(14.2,230.5,0.79,0.79,0,0,0,196.9,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen}]}).to({state:[{t:this.screen_1}]},1).to({state:[{t:this.screen_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187,16.1,300,250.00000000000003);


(lib.Page = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// obj1
	this.obj1 = new lib.object_1();
	this.obj1.name = "obj1";
	this.obj1.setTransform(315.8,204.5,1,1,0,0,0,127.8,219.5);

	this.timeline.addTween(cjs.Tween.get(this.obj1).wait(1));

	// bg
	this.bg = new lib.Page_bg();
	this.bg.name = "bg";
	this.bg.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page, new cjs.Rectangle(-125.9,0,426.4,250.5), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(953.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(35.75,218.1,0.9555,0.9555,0,0,0,0.8,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(0.1,205.9,1,1,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// page
	this.page = new lib.Page();
	this.page.name = "page";
	this.page.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.page).wait(1));

	// option_hits
	this.hit_down = new lib.option_hit();
	this.hit_down.name = "hit_down";
	this.hit_down.setTransform(173.2,317.45,0.6329,0.7256,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit_down, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit_opts = new lib.option_hit();
	this.hit_opts.name = "hit_opts";
	this.hit_opts.setTransform(173.2,217.75,0.6329,0.7256,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit_opts, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(173.2,190.05,0.6329,0.7256,0,0,0,134.6,14.3);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(173.2,162.35,0.6329,0.7256,0,0,0,134.6,14.3);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(173.2,134.7,0.6329,0.7256,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit_opts},{t:this.hit_down}]}).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bGfIAAs9MAu2AAAIAAM9g");
	mask.setTransform(149.95,165.85);

	// options
	this.popup_menu = new lib.Pop_up_menu();
	this.popup_menu.name = "popup_menu";
	this.popup_menu.setTransform(167.5,159.4,1,1,0,0,0,79.5,35.9);

	var maskedShapeInstanceList = [this.popup_menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.popup_menu).wait(1));

	// opts
	this.opts = new lib.option_btn_menu();
	this.opts.name = "opts";
	this.opts.setTransform(222.5,221.55,1,1,0,0,0,134.5,14.3);

	this.timeline.addTween(cjs.Tween.get(this.opts).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// first_frame
	this.background = new lib.mountain_anim();
	this.background.name = "background";
	this.background.setTransform(284.4,25.1,1,1,0,0,0,284.4,25.1);

	this.timeline.addTween(cjs.Tween.get(this.background).wait(1));

	// Bg
	this.instance = new lib.whitecopy();
	this.instance.setTransform(483.1,169.9,1,1,0,0,0,483.1,169.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-263.2,0,1228.6,368.9), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var frequency = 5; 
		stage.enableMouseOver(frequency);
		
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "page") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillPage(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt1") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_1(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt2") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_2(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt3") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_3(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opts") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillPage = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.page.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.opts.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_1 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt1.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_2 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt2.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_3 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt3.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		var opt1 = mc.popup_menu.opt1
		var opt2 = mc.popup_menu.opt2
		var opt3 = mc.popup_menu.opt3
		var opts = mc.opts
		
		var hit1 = mc.hit1
		var hit2 = mc.hit2
		var hit3 = mc.hit3
		var hit_opts = mc.hit_opts
		var hit_down = mc.hit_down
		
		this.runBanner = function() {
			
			mc.replay_btn.visible=false
			mc.page.alpha=0
			
			mc.cta.alpha=0
			mc.txtCta.alpha=0
			
			this.TL_Popup = new TimelineMax();	
			exportRoot.TL_Popup.add('frame0');
				exportRoot.TL_Popup.to(hit_opts, 0.1, {y: "+=100"}, "-=0");
				exportRoot.TL_Popup.from(opt1, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0");
				exportRoot.TL_Popup.from(hit1, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");		
				exportRoot.TL_Popup.from(opt2, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit2, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(opt3, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit3, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.to(hit_down, 0.1, {y: "-=100"}, "-=0");
			exportRoot.TL_Popup.add('frame1');
			exportRoot.TL_Popup.stop();
			
				this.TL_MainScreen = new TimelineMax();
				exportRoot.TL_MainScreen.add('frame0')
				
				exportRoot.TL_MainScreen.from(mc.background, 0.1, {x: "+=200", ease:Power2.easeOut, onStart:function(){mc.background.ribbon.play();}}, "+=0");
		
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
		
				}
				exportRoot.TL_MainScreen.from(opts, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.4");
				exportRoot.TL_MainScreen.from(hit_opts, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");		
				
				//exportRoot.TL_MainScreen.stop();
				exportRoot.TL_MainScreen.add('frame1');
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "+=0");
					if (i!=0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "-=0.5");
				}
				
				exportRoot.TL_MainScreen.to(mc.background, 0.8, {x: "-=150", ease:Power3.easeIn}, "-=0.6");
				exportRoot.TL_MainScreen.to(opts, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.7");
				exportRoot.TL_MainScreen.to(hit_opts, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit_down, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt1, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit1, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt2, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit2, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt3, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit3, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
		
				exportRoot.TL_MainScreen.add('frame2')
							
				exportRoot.TL_MainScreen.stop();	
				
				/*exportRoot.TL_Clouds = new TimelineMax();
				exportRoot.TL_Clouds.add('frame0')
				exportRoot.TL_Clouds.from(mc.background.ribbon, 3, { x: "+=20",	ease:Power4.easeOut, onStart:function(){mc.background.ribbon.play();}}, "0");
				exportRoot.TL_Clouds.add('frame1')		
				exportRoot.TL_Clouds.to(mc.background.ribbon, 2, { x: "-=20",	ease:Power4.easeIn}, "+=0");
				exportRoot.TL_Clouds.add('frame2')
				exportRoot.TL_Clouds.stop();*/
				
				mc.logo_intro.gotoAndPlay(1)
				
			exportRoot.tltxt1 = new TimelineMax();
			exportRoot.tltxt1.add('frame0')
			for (var i = 0; i < exportRoot.page_1_1.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_1_2.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt1.add('frame1')	
			exportRoot.tltxt1.stop();
			
			exportRoot.tltxt2 = new TimelineMax();
			exportRoot.tltxt2.add('frame0')
			for (var i = 0; i < exportRoot.page_2_1.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_2_2.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt2.add('frame1')	
			exportRoot.tltxt2.stop();
			
			/*var screen3 = mc.page.screen.screen3
			var icon = mc.page.screen.icon
			var shadow = mc.page.screen.shadow
			var mask = mc.page.screen.screen3.chart_mask
			var graph = mc.page.screen.td_graph*/
			
			exportRoot.tltxt3 = new TimelineMax();
			exportRoot.tltxt3.add('frame0')
			for (var i = 0; i < exportRoot.page_3_1.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_3_2.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
				
			exportRoot.tltxt3.add('frame1')	
			exportRoot.tltxt3.stop();
			
			//
			//   FRAME 2 ANIMATION IN / OUT
			//
			exportRoot.TL_Frame2_IN = new TimelineMax();
			
			mc.cta.alpha=1
			mc.txtCta.alpha=1
				
			exportRoot.TL_Frame2_IN.add('frame0')
			exportRoot.TL_Frame2_IN.from(mc.page.bg, 1, {x: "+=450",  ease:Power4.easeOut}, "+=0.3");
			//exportRoot.TL_Frame2_IN.from(mc.page.ribbon, 2, {x: "+=400",  ease:Power4.easeOut}, "-=1");
			exportRoot.TL_Frame2_IN.from(mc.page.obj1, 1.5, {x: "+=400",  ease:Power4.easeOut, onStart:function(){mc.page.obj1.screen.play();}}, "-=1");
		
			exportRoot.TL_Frame2_IN.from(mc.txtCta, 1, { alpha: 0, x: "-=100", ease:Power4.easeOut}, "+=1.8");
			exportRoot.TL_Frame2_IN.from(mc.cta, 1, {	alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=1");
			
			exportRoot.TL_Frame2_IN.add('frame1')
			
			exportRoot.TL_Frame2_IN.stop()	
		}
		
		exportRoot.selectedOption = function(id) {
			
			//exportRoot.TL_MainScreen.timeScale(1)
			//exportRoot.TL_Clouds.tweenFromTo("frame1", "frame2");
			exportRoot.TL_MainScreen.tweenFromTo("frame1", "frame2");
				
			exportRoot.selectedScreenIn(id)
				
		}
		exportRoot.mainScreenOut = function() {
		
		}
		var IDtest = 0
		//mc.hit.mouseEnabled = false
		exportRoot.selectedScreenIn = function(id) {
			IDtest = id
			mc.page.obj1.gotoAndStop(id-1)
			
			mc.page.alpha=1
			var pageID = id
			mc.page.obj1.visible=true
			mc.page.obj1.alpha = 1
		
			if (id==1) {
				exportRoot.tltxt1.tweenFromTo("frame0", "frame1",{delay:.3});
				//myFT.tracker("Answer1_WorkingVirtually");
				};
			if (id==2) {
				exportRoot.tltxt2.tweenFromTo("frame0", "frame1",{delay:.3});
				//myFT.tracker("Answer2_KeepingMyKidsEngaged");
				};
			if (id==3) {
				exportRoot.tltxt3.tweenFromTo("frame0", "frame1",{delay:.3});
				//myFT.tracker("Answer3_SavingMoney");
				};
		
			exportRoot.TL_Frame2_IN.tweenFromTo("frame0", "frame1",{delay:.3});
			//mc.hit.mouseEnabled = true
		}
		
		function mainOver() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(1);
		}
		function mainOut() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-113.2,125,1078.6,243.89999999999998);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593188139810", id:"M365_FY21Q1_BTS_USA_300x250_BAN_InteractiveParent_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;