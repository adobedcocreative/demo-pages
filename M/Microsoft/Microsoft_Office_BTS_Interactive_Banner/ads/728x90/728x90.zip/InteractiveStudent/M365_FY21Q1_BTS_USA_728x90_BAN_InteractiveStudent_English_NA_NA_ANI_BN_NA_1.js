(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[302,0,302,192],[606,193,237,96],[926,324,74,126],[845,193,158,129],[0,386,107,56],[102,202,131,104],[772,389,84,53],[506,194,89,65],[218,439,51,43],[102,308,156,76],[164,439,52,43],[661,397,75,50],[109,386,122,39],[271,439,52,41],[501,397,76,52],[109,439,53,43],[235,202,47,69],[858,389,55,55],[579,397,80,48],[506,291,131,104],[109,427,300,10],[890,0,100,151],[992,0,30,52],[260,273,31,48],[738,397,31,46],[325,439,31,45],[992,54,30,44],[992,100,30,43],[992,145,30,43],[302,194,100,151],[404,194,100,151],[0,202,100,151],[414,402,56,45],[0,0,300,200],[414,347,85,53],[606,0,282,191],[772,324,152,63],[260,347,152,61],[639,291,131,104]]}
];


// symbols:



(lib.basicUIhalf = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bg_img_728x90_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.bodyResize_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.chart_big_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.chart_sml_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Excel_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.girllefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Grass_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.guylefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.leafA_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.LeafB_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.percent_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.PPT_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Render0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Render0109sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Render0110sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Render0111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Render0112sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Render0113sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Render0114sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Render0115sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Render0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Render0117 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Render0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.secondimagesml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Word_icon_sml_update = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.WordIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.iconcache.cache(-260,-230,520,460,0.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Word_icon_sml_update();
	this.instance.setTransform(108,121,1.9,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(108,121,248.89999999999998,197.60000000000002), null);


(lib.whitebar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixGAIAAr/IFjAAIAAL/g");
	this.shape.setTransform(17.825,38.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebar, new cjs.Rectangle(0,0,35.7,76.8), null);


(lib.whitecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitecopy, new cjs.Rectangle(0,0,728,90), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AsGrUIYXAAIAAWdI4hAMg");
	this.shape.setTransform(-0.0003,-0.0264);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.5,-72.5,157.1,145);


(lib.Topbar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape.setTransform(268.579,5.5001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#437F5B").s().p("AgJgEIATAAIgKAJg");
	this.shape_1.setTransform(72.0759,5.5001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUAbIgGgGIAAgwIA1AAIAAATIgCAAIAAgQIgGAAIAAAQIgCAAIAAgQIggAAIAAAXIANAAIgBABIgPAAIAAgYIgGAAIAAArIAFAGIAFAAIAAgQIAGAAIAAADIgEAAIAAANIAGAAIAAACg");
	this.shape_2.setTransform(46.425,6.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMABIAAAEIgCAAIAAgJIAJAAIAAADIgGAAQAEAFAHAAQAKAAADgJIACABQgDAKgMAAQgIAAgEgFg");
	this.shape_3.setTransform(47.6,8.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAGIACgGQAFgGAHAAQAHAAAGAGIAAgEIACAAIAAAJIgKAAIAAgDIAHAAQgFgFgHAAQgFAAgFAEIgCAGg");
	this.shape_4.setTransform(47.6,6.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAQIgOgOIgNAOIgCAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAOgOIgOgNIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAABIANANIAOgNIACAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgOANIAOAOQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_5.setTransform(442.325,5.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQARIAAgaIAHAAIAAgHIAaAAIAAAaIgHAAIAAAHgAgNAOIAVAAIAAgUIgVAAgAgHgJIARAAIAAAQIAEAAIAAgUIgVAAg");
	this.shape_6.setTransform(427.1,5.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.3).p("AgRAAIAjAA");
	this.shape_7.setTransform(411.95,5.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUARIAAghIApAAIAAAhgAABAOIASAAIAAgUIglAAIAAAUIASAAIAAgOIgGAEIgBgCIAHgHIAIAHIgBACIgGgEgAgSgJIAlAAIAAgEIglAAg");
	this.shape_8.setTransform(396.625,5.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIABIAAgBIARAAIAAABg");
	this.shape_9.setTransform(78.65,4.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_10.setTransform(78.675,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_11.setTransform(60.575,5.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#437F5B").s().p("AgQAFQgFgFABgHQABgHAFgFIABAAQAFgFAHAAQAHACAEAEIAJAKIAAgTIACAAIAAAYIgWAAIAAgDIASAAIgJgKQgDgEgGgBQgFAAgFADIgCABQgEAEgBAGQAAAHAEADIAUAXIgCABg");
	this.shape_12.setTransform(67.2167,6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAaIAUgXQAEgDAAgHQgBgFgFgFIgBgBQgFgDgFAAQgGABgDAEIgJAKIASAAIAAADIgWAAIAAgYIACAAIAAATIAJgKQAEgEAGgCQAHAAAGAFIABAAQAFAFABAHQAAAHgEAFIgUAWg");
	this.shape_13.setTransform(55.625,6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AglAaQgKAAgIgIQgIgHAAgLQAAgKAIgHQAIgIAKAAIBLAAQALAAAHAIQAIAHAAAKQAAALgIAHQgHAIgLAAgAAdgIQgEAEAAAEQAAAFAEAEQADADAGAAQAFAAADgDQADgEAAgFQAAgEgDgEQgDgDgFAAQgGAAgDADg");
	this.shape_14.setTransform(32.4,5.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#227347").s().p("EgjJAA3IAAhuMBGTAAAIAABug");
	this.shape_15.setTransform(225,5.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Topbar, new cjs.Rectangle(0,0,450,11.1), null);


(lib.top_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt13 = new cjs.Text("Comments", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 7;
	this.txt13.lineWidth = 23;
	this.txt13.parent = this;
	this.txt13.setTransform(416.2,18.75);

	this.txt13_1 = new cjs.Text("Share", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13_1.name = "txt13_1";
	this.txt13_1.lineHeight = 7;
	this.txt13_1.lineWidth = 15;
	this.txt13_1.parent = this;
	this.txt13_1.setTransform(390.7,15.7);

	this.txt13_2 = new cjs.Text("Search", "5px 'Segoe Pro'", "#474747");
	this.txt13_2.name = "txt13_2";
	this.txt13_2.lineHeight = 8;
	this.txt13_2.lineWidth = 15;
	this.txt13_2.parent = this;
	this.txt13_2.setTransform(208,15.55);

	this.txt12 = new cjs.Text("Help", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 15;
	this.txt12.parent = this;
	this.txt12.setTransform(181,18.55);

	this.txt11 = new cjs.Text("View", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 15;
	this.txt11.parent = this;
	this.txt11.setTransform(162.95,18.55);

	this.txt10 = new cjs.Text("Review", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 15;
	this.txt10.parent = this;
	this.txt10.setTransform(140.55,18.55);

	this.txt9 = new cjs.Text("Date", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 15;
	this.txt9.parent = this;
	this.txt9.setTransform(122.5,18.55);

	this.txt8 = new cjs.Text("Formulas", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 24;
	this.txt8.parent = this;
	this.txt8.setTransform(95.4,18.55);

	this.txt7 = new cjs.Text("Page Layout", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 33;
	this.txt7.parent = this;
	this.txt7.setTransform(62.2,18.55);

	this.txt6 = new cjs.Text("Insert", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 13;
	this.txt6.parent = this;
	this.txt6.setTransform(41.25,18.55);

	this.txt5 = new cjs.Text("Home", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 13;
	this.txt5.parent = this;
	this.txt5.setTransform(19.9,18.55);

	this.txt4 = new cjs.Text("File", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 8;
	this.txt4.parent = this;
	this.txt4.setTransform(2.3,18.55);

	this.txt3 = new cjs.Text("Daniella Duarte", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 30;
	this.txt3.parent = this;
	this.txt3.setTransform(355.05,7.2);

	this.txt2 = new cjs.Text("Family Budget - Saved to OneDrive", "5px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 105;
	this.txt2.parent = this;
	this.txt2.setTransform(185.3,6.5);

	this.txt1 = new cjs.Text("On", "3px 'Segoe Pro'", "#227347");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 6;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(24.15,6.6);

	this.txt = new cjs.Text("AutoSave", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 7;
	this.txt.lineWidth = 19;
	this.txt.parent = this;
	this.txt.setTransform(2,6.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13_2},{t:this.txt13_1},{t:this.txt13}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_text, new cjs.Rectangle(0,4.5,441.2,22.3), null);


(lib.titleshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.textanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#44724B").s().p("AhZB4ICOjaQgaAHgjAAIgIAAQAJAMAAAOQAAAUgOAQQgOAQgXAAQgWAAgOgPQgPgPAAgVQAAgOAHgMQAHgLAMgHQAMgHANAAQAFAAANADQATAEAVAAQAQAAAPgCQAPgCAXgHIARAAIicDvgAhRhXQgJAKAAANQAAAOAJAIQAKAKANAAQANAAAKgKQAJgIAAgOQAAgNgJgKQgKgKgNAAQgNAAgKAKgAAXBhQgPgQAAgUQAAgWAPgOQAPgPAVAAQAVAAAPAPQAPAOAAAWQAAAUgPAQQgPAPgVAAQgVAAgPgPgAAkAmQgJAJAAAOQAAANAJAJQAKAJANAAQANAAAKgJQAJgJAAgNQAAgOgJgJQgKgKgNAAQgNAAgKAKg");
	this.shape.setTransform(46.925,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAFgIQAGgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgcARQAQAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_1.setTransform(26.9,20.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#44724B").s().p("AhIBuIBRhZQAZgaAIgNQAHgNAAgOQAAgSgNgNQgOgNgUAAQgTAAgOAOQgOAOgCAZIgUAAQABggAUgVQAVgVAdABQAdAAATATQASATAAAaQAAATgJAQQgIAOgaAcIg0A6IBiAAIAAAUg");
	this.shape_2.setTransform(10.225,20.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_3.setTransform(26.925,20.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAdABATATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_4.setTransform(26.9,20.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_5.setTransform(27.3,20.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#44724B").s().p("AhABlIBji+IhmAAIAAgUICHAAIhyDbg");
	this.shape_6.setTransform(27.625,20.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#44724B").s().p("Ag1BdQgTgVAAgYQAAgSAKgPQAJgOAXgKQgQgJgHgMQgJgMAAgOQABgOAIgNQAIgOAPgHQAPgIAQAAQARAAAPAIQAOAHAIAOQAIANAAAPQAAAOgIAMQgHALgPAJQAVAJAJAOQAKAOAAASQAAAZgRATQgTAXglAAQgjAAgSgUgAgjAPQgPAOAAATQAAAMAGALQAHAKALAGQAMAGAOAAQAXAAAOgOQAPgOAAgTQAAgSgPgOQgPgOgVAAQgVAAgPAPgAgchRQgMALAAAOQAAAPANALQAMAMAQAAQAKAAAKgFQAJgGAGgJQAGgJAAgJQAAgNgLgLQgKgLgVAAQgRAAgLAKg");
	this.shape_7.setTransform(26.95,20.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#44724B").s().p("AgoBmIA5hYQgMADgJAAQgZAAgTgRQgSgTAAgbQABgSAIgPQAJgPAQgJQAQgJARAAQASAAAPAIQAPAJAIAQQAKAPgBASQAAANgFAPQgFAOgOAUIhBBhgAgfhOQgNANAAATQAAATANANQAOANARAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgRAAgOANg");
	this.shape_8.setTransform(26.75,20.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#44724B").s().p("AglBlQgRgMgJgXQgJgYAAgqQAAgqAJgXQAJgXARgMQAQgMAVAAQAUAAARAMQARAMAKAYQAJAYAAAoQAAApgJAYQgKAYgRAMQgRAMgUAAQgVAAgQgMgAgahSQgNAJgGATQgHATAAAkQAAAkAHATQAGASANAKQANAKANAAQAOAAANgKQAMgJAHgTQAIgXAAggQgBgggHgVQgHgVgMgJQgNgKgOAAQgNAAgNAKg");
	this.shape_9.setTransform(26.95,20.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAGgIQAFgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgbARQAPAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_10.setTransform(10.25,20.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#44724B").s().p("AAGBsIAAjCIghAAIANgVIAqAAIAADXg");
	this.shape_11.setTransform(25.675,20.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_12.setTransform(10.275,20.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAeABASATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_13.setTransform(10.25,20.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_14.setTransform(10.65,20.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},7).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_4},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_12},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_14},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},4).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,66.4,39.8);


(lib.text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlleftcontributionsml();
	this.instance.setTransform(0.1,-0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,-0.2,89.1,65.2), null);


(lib.text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.tablet_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,-4,0,4.6,-4,8.6).s().p("AgMASQgKgKgGgKQgEgHgCgIIgCgKIgBgIIAAgGIBLAAIAAABIAABSQgegCgUgWg");
	this.shape.setTransform(-10.0002,11.9003);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-3.6,18.3,4.7,18.3).s().p("AglCAIAAghIABAHIACAKQACAJAEAHgAglBYIAAjXIBLAAIAADXg");
	this.shape_1.setTransform(-10.0002,-1.1249);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,4.1,0,4.6,4.1,8.6).s().p("AglAqIAAgCIAAAAQABgiAYgXQAUgWAegCIAABSIAAABg");
	this.shape_2.setTransform(-10.0002,-18.1502);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,4.2,-18.2,-4.2).s().p("ABkAqIjgAAIgDAAIAAgBIAAhSID/AAIAAABIAAAAIAABSg");
	this.shape_3.setTransform(6.5751,12.0003);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,-4.1,0,-4,-4.1,8.6).s().p("AgoAqIgBAAIAAhSIAAAAIAAgBIABAAIBSAAIAAABIAAADQAAAhgYAVQgXAZgiAAg");
	this.shape_4.setTransform(23.6253,12.0003);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],4.3,21.6,-4.1,21.6).s().p("AApBwIAAAAIhSAAIAAjaIBSAAIAAgFIABAAIAADfg");
	this.shape_5.setTransform(23.7003,-3.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ACABtIkAAAIAAgBIAAjXIAAgBIEAAAIABAAIAADZg");
	this.shape_6.setTransform(6.6251,-3.1249);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,-4.1,-18.2,4.3).s().p("Ah/AqIAAhSIAAgBIADAAIDgAAIAcAAIAABSIAAABg");
	this.shape_7.setTransform(6.5751,-18.2502);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,4.2,0,-4,4.2,8.6).s().p("AgoAqIgBAAIAAgBIAAhSIABAAIABAAQAiAAAXAYQAXAWABAfIAAAGg");
	this.shape_8.setTransform(23.6253,-18.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,5,1.1,-5).s().p("AkLAyIAAAAIABAAIABAAIACAAIAAgCIAAhhIGwAAIBjAAIAABhIAAACIgCAAIAAAAIAAAAg");
	this.shape_9.setTransform(36.375,89.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,-4.8,0,4.9,-4.8,10.2).s().p("AAwAyIgBAAIgCAAQgngBgagcQgdgbAAgoIAAgDIBhAAIACAAIAAABIAABhIAAABg");
	this.shape_10.setTransform(5,89.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-4.9,0.1,5.1,0.1).s().p("AAwFyIhhAAIAArjIBhAAIACAAIAALjg");
	this.shape_11.setTransform(5,47.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,4.8,0,4.9,4.8,10.2).s().p("AAwAzIhhAAIAAgCIAAgBQAAgpAdgbQAagcAngBIACAAIABAAIACAAIAABiIAAACg");
	this.shape_12.setTransform(5,5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,-5,1.1,5).s().p("ACpAyImwAAIAAhiIgCAAIgBAAIgBAAIAAgBIIVAAIAAABIAAAAIACAAIAABig");
	this.shape_13.setTransform(36.375,5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,5,0,-5).s().p("AECAyIoVAAIgDAAIAAAAIAAAAIACAAIAAgCIAAhhIAWAAIB8AAIEgAAIB3AAIAABhIAAACIABAAIABAAIAAAAg");
	this.shape_14.setTransform(90.875,89.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,-4.8,0,-4.8,-4.8,10.2).s().p("AgwAyIgBAAIAAgBIAAhhIAAgBIACAAIBhAAIAAADQgBAogdAbQgaAdgpAAIgBAAg");
	this.shape_15.setTransform(123.6,89.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,-5,0,5).s().p("ACeAyIkgAAIh8AAIgWAAIAAhiIgCAAIAAAAIAAgBIItAAIAAABIgBAAIgBAAIAABig");
	this.shape_16.setTransform(90.875,5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AGoFzIkhAAIh9AAIgUAAIhjAAImxAAIAAgBIAArjIAAgBIGxAAIBjAAIAUAAIB9AAIEhAAIB3AAIAAABIAALjIAAABg");
	this.shape_17.setTransform(64.3,47.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],5,0.1,-5,0.1).s().p("AgvFyIgCAAIAArjIACAAIBhAAIAALjg");
	this.shape_18.setTransform(123.6,47.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,4.8,0,-4.8,4.8,10.2).s().p("AgvAzIgCAAIAAgCIAAhiIABAAIABAAQApAAAaAdQAdAbABApIAAABIAAACg");
	this.shape_19.setTransform(123.6,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_sub, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.small_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_sml_msml();
	this.instance.setTransform(198,132,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.small_pie, new cjs.Rectangle(0,0,420,420), null);


(lib.secondimage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.secondimagesml();
	this.instance.setTransform(-0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage, new cjs.Rectangle(-0.4,0,85,53.3), null);


(lib.screenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.basicUIhalf();
	this.instance.setTransform(-0.35,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.rowsandcells = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//columns
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		
		//rows
		this.txt01.textBaseline = "alphabetic"
		this.txt02.textBaseline = "alphabetic"
		this.txt03.textBaseline = "alphabetic"
		this.txt04.textBaseline = "alphabetic"
		this.txt05.textBaseline = "alphabetic"
		this.txt06.textBaseline = "alphabetic"
		this.txt07.textBaseline = "alphabetic"
		this.txt08.textBaseline = "alphabetic"
		this.txt09.textBaseline = "alphabetic"
		this.txt010.textBaseline = "alphabetic"
		this.txt011.textBaseline = "alphabetic"
		this.txt012.textBaseline = "alphabetic"
		this.txt013.textBaseline = "alphabetic"
		this.txt014.textBaseline = "alphabetic"
		this.txt015.textBaseline = "alphabetic"
		this.txt016.textBaseline = "alphabetic"
		this.txt017.textBaseline = "alphabetic"
		this.txt018.textBaseline = "alphabetic"
		this.txt019.textBaseline = "alphabetic"
		this.txt020.textBaseline = "alphabetic"
		this.txt021.textBaseline = "alphabetic"
		this.txt022.textBaseline = "alphabetic"
		this.txt023.textBaseline = "alphabetic"
		this.txt024.textBaseline = "alphabetic"
		this.txt025.textBaseline = "alphabetic"
		this.txt026.textBaseline = "alphabetic"
		this.txt027.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt027 = new cjs.Text("27", "5px 'Segoe Pro'", "#474747");
	this.txt027.name = "txt027";
	this.txt027.lineHeight = 8;
	this.txt027.lineWidth = 6;
	this.txt027.parent = this;
	this.txt027.setTransform(-11,241.15);

	this.txt026 = new cjs.Text("26", "5px 'Segoe Pro'", "#474747");
	this.txt026.name = "txt026";
	this.txt026.lineHeight = 8;
	this.txt026.lineWidth = 6;
	this.txt026.parent = this;
	this.txt026.setTransform(-11,232.95);

	this.txt025 = new cjs.Text("25", "5px 'Segoe Pro'", "#474747");
	this.txt025.name = "txt025";
	this.txt025.lineHeight = 8;
	this.txt025.lineWidth = 6;
	this.txt025.parent = this;
	this.txt025.setTransform(-11,224.65);

	this.txt024 = new cjs.Text("24", "5px 'Segoe Pro'", "#474747");
	this.txt024.name = "txt024";
	this.txt024.lineHeight = 8;
	this.txt024.lineWidth = 6;
	this.txt024.parent = this;
	this.txt024.setTransform(-11,216.35);

	this.txt023 = new cjs.Text("23", "5px 'Segoe Pro'", "#474747");
	this.txt023.name = "txt023";
	this.txt023.lineHeight = 8;
	this.txt023.lineWidth = 6;
	this.txt023.parent = this;
	this.txt023.setTransform(-11,208.2);

	this.txt022 = new cjs.Text("22", "5px 'Segoe Pro'", "#474747");
	this.txt022.name = "txt022";
	this.txt022.lineHeight = 8;
	this.txt022.lineWidth = 6;
	this.txt022.parent = this;
	this.txt022.setTransform(-11,200);

	this.txt021 = new cjs.Text("21", "5px 'Segoe Pro'", "#474747");
	this.txt021.name = "txt021";
	this.txt021.lineHeight = 8;
	this.txt021.lineWidth = 6;
	this.txt021.parent = this;
	this.txt021.setTransform(-11,191.7);

	this.txt020 = new cjs.Text("20", "5px 'Segoe Pro'", "#474747");
	this.txt020.name = "txt020";
	this.txt020.lineHeight = 8;
	this.txt020.lineWidth = 6;
	this.txt020.parent = this;
	this.txt020.setTransform(-11,183.35);

	this.txt019 = new cjs.Text("19", "5px 'Segoe Pro'", "#474747");
	this.txt019.name = "txt019";
	this.txt019.lineHeight = 8;
	this.txt019.lineWidth = 6;
	this.txt019.parent = this;
	this.txt019.setTransform(-10.5,175.1);

	this.txt018 = new cjs.Text("18", "5px 'Segoe Pro'", "#474747");
	this.txt018.name = "txt018";
	this.txt018.lineHeight = 8;
	this.txt018.lineWidth = 6;
	this.txt018.parent = this;
	this.txt018.setTransform(-10.5,166.9);

	this.txt017 = new cjs.Text("17", "5px 'Segoe Pro'", "#474747");
	this.txt017.name = "txt017";
	this.txt017.lineHeight = 8;
	this.txt017.lineWidth = 6;
	this.txt017.parent = this;
	this.txt017.setTransform(-10.5,158.7);

	this.txt016 = new cjs.Text("16", "5px 'Segoe Pro'", "#474747");
	this.txt016.name = "txt016";
	this.txt016.lineHeight = 8;
	this.txt016.lineWidth = 6;
	this.txt016.parent = this;
	this.txt016.setTransform(-10.5,150.45);

	this.txt015 = new cjs.Text("15", "5px 'Segoe Pro'", "#474747");
	this.txt015.name = "txt015";
	this.txt015.lineHeight = 8;
	this.txt015.lineWidth = 6;
	this.txt015.parent = this;
	this.txt015.setTransform(-10.5,142.15);

	this.txt014 = new cjs.Text("14", "5px 'Segoe Pro'", "#474747");
	this.txt014.name = "txt014";
	this.txt014.lineHeight = 8;
	this.txt014.lineWidth = 6;
	this.txt014.parent = this;
	this.txt014.setTransform(-10.5,133.85);

	this.txt013 = new cjs.Text("13", "5px 'Segoe Pro'", "#474747");
	this.txt013.name = "txt013";
	this.txt013.lineHeight = 8;
	this.txt013.lineWidth = 6;
	this.txt013.parent = this;
	this.txt013.setTransform(-10.5,125.8);

	this.txt012 = new cjs.Text("12", "5px 'Segoe Pro'", "#474747");
	this.txt012.name = "txt012";
	this.txt012.lineHeight = 8;
	this.txt012.lineWidth = 6;
	this.txt012.parent = this;
	this.txt012.setTransform(-10.5,117.5);

	this.txt011 = new cjs.Text("11", "5px 'Segoe Pro'", "#474747");
	this.txt011.name = "txt011";
	this.txt011.lineHeight = 8;
	this.txt011.lineWidth = 6;
	this.txt011.parent = this;
	this.txt011.setTransform(-10.5,109.3);

	this.txt010 = new cjs.Text("10", "5px 'Segoe Pro'", "#474747");
	this.txt010.name = "txt010";
	this.txt010.lineHeight = 8;
	this.txt010.lineWidth = 6;
	this.txt010.parent = this;
	this.txt010.setTransform(-10.5,101.05);

	this.txt09 = new cjs.Text("9", "5px 'Segoe Pro'", "#474747");
	this.txt09.name = "txt09";
	this.txt09.lineHeight = 8;
	this.txt09.lineWidth = 6;
	this.txt09.parent = this;
	this.txt09.setTransform(-9.7,92.8);

	this.txt08 = new cjs.Text("8", "5px 'Segoe Pro'", "#474747");
	this.txt08.name = "txt08";
	this.txt08.lineHeight = 8;
	this.txt08.lineWidth = 6;
	this.txt08.parent = this;
	this.txt08.setTransform(-9.7,84.6);

	this.txt07 = new cjs.Text("7", "5px 'Segoe Pro'", "#474747");
	this.txt07.name = "txt07";
	this.txt07.lineHeight = 8;
	this.txt07.lineWidth = 6;
	this.txt07.parent = this;
	this.txt07.setTransform(-9.7,76.35);

	this.txt06 = new cjs.Text("6", "5px 'Segoe Pro'", "#474747");
	this.txt06.name = "txt06";
	this.txt06.lineHeight = 8;
	this.txt06.lineWidth = 6;
	this.txt06.parent = this;
	this.txt06.setTransform(-9.7,68.1);

	this.txt05 = new cjs.Text("5", "5px 'Segoe Pro'", "#474747");
	this.txt05.name = "txt05";
	this.txt05.lineHeight = 8;
	this.txt05.lineWidth = 6;
	this.txt05.parent = this;
	this.txt05.setTransform(-9.7,59.85);

	this.txt04 = new cjs.Text("4", "5px 'Segoe Pro'", "#474747");
	this.txt04.name = "txt04";
	this.txt04.lineHeight = 8;
	this.txt04.lineWidth = 6;
	this.txt04.parent = this;
	this.txt04.setTransform(-9.7,51.6);

	this.txt03 = new cjs.Text("3", "5px 'Segoe Pro'", "#474747");
	this.txt03.name = "txt03";
	this.txt03.lineHeight = 8;
	this.txt03.lineWidth = 6;
	this.txt03.parent = this;
	this.txt03.setTransform(-9.7,43.25);

	this.txt02 = new cjs.Text("2", "5px 'Segoe Pro'", "#474747");
	this.txt02.name = "txt02";
	this.txt02.lineHeight = 8;
	this.txt02.lineWidth = 6;
	this.txt02.parent = this;
	this.txt02.setTransform(-9.7,35.1);

	this.txt01 = new cjs.Text("1", "5px 'Segoe Pro'", "#474747");
	this.txt01.name = "txt01";
	this.txt01.lineHeight = 8;
	this.txt01.lineWidth = 6;
	this.txt01.parent = this;
	this.txt01.setTransform(-9.35,26.7);

	this.txt16 = new cjs.Text("Q", "5px 'Segoe Pro'", "#474747");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 8;
	this.txt16.lineWidth = 6;
	this.txt16.parent = this;
	this.txt16.setTransform(401.15,18.5);

	this.txt15 = new cjs.Text("P", "5px 'Segoe Pro'", "#474747");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 8;
	this.txt15.lineWidth = 6;
	this.txt15.parent = this;
	this.txt15.setTransform(376.95,18.5);

	this.txt14 = new cjs.Text("O", "5px 'Segoe Pro'", "#474747");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 8;
	this.txt14.lineWidth = 6;
	this.txt14.parent = this;
	this.txt14.setTransform(351.85,18.5);

	this.txt13 = new cjs.Text("N", "5px 'Segoe Pro'", "#474747");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 8;
	this.txt13.lineWidth = 6;
	this.txt13.parent = this;
	this.txt13.setTransform(327.05,18.5);

	this.txt12 = new cjs.Text("M", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 6;
	this.txt12.parent = this;
	this.txt12.setTransform(302,18.5);

	this.txt11 = new cjs.Text("L", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 6;
	this.txt11.parent = this;
	this.txt11.setTransform(278.35,18.5);

	this.txt10 = new cjs.Text("K", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 6;
	this.txt10.parent = this;
	this.txt10.setTransform(253.35,18.5);

	this.txt9 = new cjs.Text("J", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 6;
	this.txt9.parent = this;
	this.txt9.setTransform(229.05,18.5);

	this.txt8 = new cjs.Text("I", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 6;
	this.txt8.parent = this;
	this.txt8.setTransform(204.65,18.5);

	this.txt7 = new cjs.Text("H", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 6;
	this.txt7.parent = this;
	this.txt7.setTransform(178.85,18.5);

	this.txt6 = new cjs.Text("G", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 6;
	this.txt6.parent = this;
	this.txt6.setTransform(154.5,18.5);

	this.txt5 = new cjs.Text("F", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 6;
	this.txt5.parent = this;
	this.txt5.setTransform(130.3,18.5);

	this.txt4 = new cjs.Text("E", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 6;
	this.txt4.parent = this;
	this.txt4.setTransform(105.5,18.5);

	this.txt3 = new cjs.Text("D", "5px 'Segoe Pro'", "#474747");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 8;
	this.txt3.lineWidth = 6;
	this.txt3.parent = this;
	this.txt3.setTransform(80.45,18.5);

	this.txt2 = new cjs.Text("C", "5px 'Segoe Pro'", "#474747");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(55.95,18.5);

	this.txt1 = new cjs.Text("B", "5px 'Segoe Pro'", "#474747");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 8;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(31.3,18.5);

	this.txt = new cjs.Text("A", "5px 'Segoe Pro'", "#474747");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(6.4,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt01},{t:this.txt02},{t:this.txt03},{t:this.txt04},{t:this.txt05},{t:this.txt06},{t:this.txt07},{t:this.txt08},{t:this.txt09},{t:this.txt010},{t:this.txt011},{t:this.txt012},{t:this.txt013},{t:this.txt014},{t:this.txt015},{t:this.txt016},{t:this.txt017},{t:this.txt018},{t:this.txt019},{t:this.txt020},{t:this.txt021},{t:this.txt022},{t:this.txt023},{t:this.txt024},{t:this.txt025},{t:this.txt026},{t:this.txt027}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rowsandcells, new cjs.Rectangle(-13,16.5,422.2,232.7), null);


(lib.roundshadowshape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.roundshadow1sml();
	this.instance.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45.3), null);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bodyResize_sml();
	this.instance.setTransform(8,4,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(0,0,114,181), null);


(lib.percantage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.percent_msml();
	this.instance.setTransform(194,187,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.percantage, new cjs.Rectangle(0,0,420,420), null);


(lib.Page_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(242,242,242,0)","#F2F2F2"],[0,0.282],-427.5,80,-1.5,80).s().p("EhCyAHCIAAuDMCFlAAAIAAODg");
	this.shape.setTransform(301.55,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_bg, new cjs.Rectangle(-125.9,0,855,90), null);


(lib.option_hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.2)").s().p("AzwCaIAAkzMAngAAAIAAEzg");
	this.shape.setTransform(126.45,15.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AzyCbIAAk1MAnkAAAIAAE1g");
	this.shape_1.setTransform(126.65,15.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,253.3,31.1);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAIAqIAhgfIh3AAIAAgUIB3AAIghggIAbAAIAsApIgsAqg");
	this.shape.setTransform(-2.1,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-10,-4.1,15.8,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(172.2024,63.4258);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(172.2024,63.4258);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],20.7,54.8,0,20.7,54.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(172.2024,71.5759);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(0,0,344.4,135), null);


(lib.main_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
		this.txt20.textBaseline = "alphabetic"
		this.txt21.textBaseline = "alphabetic"
		this.txt22.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.txt22 = new cjs.Text("Expense", "7px 'Segoe Pro'", "#227347");
	this.txt22.name = "txt22";
	this.txt22.lineHeight = 11;
	this.txt22.lineWidth = 32;
	this.txt22.parent = this;
	this.txt22.setTransform(356.25,158);

	this.txt21 = new cjs.Text("Income", "7px 'Segoe Pro'", "#227347");
	this.txt21.name = "txt21";
	this.txt21.lineHeight = 11;
	this.txt21.lineWidth = 32;
	this.txt21.parent = this;
	this.txt21.setTransform(311.35,158);

	this.txt20 = new cjs.Text("$0", "6px 'Segoe Pro'", "#227347");
	this.txt20.name = "txt20";
	this.txt20.lineHeight = 10;
	this.txt20.lineWidth = 18;
	this.txt20.parent = this;
	this.txt20.setTransform(290,140.1);

	this.txt19 = new cjs.Text("$100", "6px 'Segoe Pro'", "#227347");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 10;
	this.txt19.lineWidth = 18;
	this.txt19.parent = this;
	this.txt19.setTransform(283.55,125.2);

	this.txt18 = new cjs.Text("$200", "6px 'Segoe Pro'", "#227347");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 10;
	this.txt18.lineWidth = 18;
	this.txt18.parent = this;
	this.txt18.setTransform(283.55,110.5);

	this.txt17 = new cjs.Text("$300", "6px 'Segoe Pro'", "#227347");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 10;
	this.txt17.lineWidth = 18;
	this.txt17.parent = this;
	this.txt17.setTransform(283.55,95.8);

	this.txt16 = new cjs.Text("$400", "6px 'Segoe Pro'", "#227347");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 10;
	this.txt16.lineWidth = 18;
	this.txt16.parent = this;
	this.txt16.setTransform(283.55,80.75);

	this.txt15 = new cjs.Text("$500", "6px 'Segoe Pro'", "#227347");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 10;
	this.txt15.lineWidth = 18;
	this.txt15.parent = this;
	this.txt15.setTransform(283.55,66.25);

	this.txt14 = new cjs.Text("$600", "6px 'Segoe Pro'", "#227347");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 10;
	this.txt14.lineWidth = 18;
	this.txt14.parent = this;
	this.txt14.setTransform(283.55,51.55);

	this.txt13 = new cjs.Text("$700", "6px 'Segoe Pro'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 10;
	this.txt13.lineWidth = 18;
	this.txt13.parent = this;
	this.txt13.setTransform(283.55,36.65);

	this.txt12 = new cjs.Text("$800", "6px 'Segoe Pro'", "#227347");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 10;
	this.txt12.lineWidth = 18;
	this.txt12.parent = this;
	this.txt12.setTransform(283.55,22.35);

	this.txt11 = new cjs.Text("$900", "6px 'Segoe Pro'", "#227347");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 10;
	this.txt11.lineWidth = 18;
	this.txt11.parent = this;
	this.txt11.setTransform(283.55,7.45);

	this.txt9 = new cjs.Text("Cash Balance", "7px 'Segoe Pro'", "#227347");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 11;
	this.txt9.lineWidth = 100;
	this.txt9.parent = this;
	this.txt9.setTransform(152.7,133.5);

	this.txt7 = new cjs.Text("Total monthly savings", "7px 'Segoe Pro'", "#227347");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 11;
	this.txt7.lineWidth = 100;
	this.txt7.parent = this;
	this.txt7.setTransform(152.7,98.7);

	this.txt5 = new cjs.Text("Total monthly expenses", "7px 'Segoe Pro'", "#227347");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 11;
	this.txt5.lineWidth = 100;
	this.txt5.parent = this;
	this.txt5.setTransform(152.7,64.1);

	this.txt10 = new cjs.Text("$130", "12px 'Segoe Pro'", "#227347");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 18;
	this.txt10.lineWidth = 100;
	this.txt10.parent = this;
	this.txt10.setTransform(152.7,150.1);

	this.txt8 = new cjs.Text("$100", "12px 'Segoe Pro'", "#227347");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 18;
	this.txt8.lineWidth = 100;
	this.txt8.parent = this;
	this.txt8.setTransform(152.7,115.5);

	this.txt6 = new cjs.Text("$670", "12px 'Segoe Pro'", "#227347");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 18;
	this.txt6.lineWidth = 100;
	this.txt6.parent = this;
	this.txt6.setTransform(152.7,80.65);

	this.txt4 = new cjs.Text("$900", "12px 'Segoe Pro'", "#227347");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 18;
	this.txt4.lineWidth = 100;
	this.txt4.parent = this;
	this.txt4.setTransform(152.7,45.85);

	this.txt3 = new cjs.Text("Total monthly income", "7px 'Segoe Pro'", "#227347");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 11;
	this.txt3.lineWidth = 100;
	this.txt3.parent = this;
	this.txt3.setTransform(152.7,29.3);

	this.txt2 = new cjs.Text("Summary", "8px 'Segoe Pro'", "#227347");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(152.7,11.2);

	this.txt1 = new cjs.Text("Percentage of income spent", "6px 'Segoe Pro'", "#B7B2A6");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 10;
	this.txt1.lineWidth = 100;
	this.txt1.parent = this;
	this.txt1.setTransform(2,26.4);

	this.txt = new cjs.Text("School Budget", "14px 'Segoe Pro'", "#227347");
	this.txt.name = "txt";
	this.txt.lineHeight = 20;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(2,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt6},{t:this.txt8},{t:this.txt10},{t:this.txt5},{t:this.txt7},{t:this.txt9},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt17},{t:this.txt18},{t:this.txt19},{t:this.txt20},{t:this.txt21},{t:this.txt22}]}).wait(1));

	// Graph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#49A166").s().p("AitJYIAAg5IA4AAIAAA5gAjBGUIAAvrIGDAAIAAPrg");
	this.shape.setTransform(365.3,97.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#337446").s().p("AjVMGIAAg4IA5AAIAAA4gAiqJCIAA1HIGAAAIAAFdIAAPqg");
	this.shape_1.setTransform(324.475,80.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E4DFD4").ss(0.3).p("ATPKLIqoABIkUAAIAAiFIAAyXAkvmfIufAAAkvhCIufAAAkvEOIufAAAkvJ0IufAA");
	this.shape_2.setTransform(271.7253,74.2752);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_txt, new cjs.Rectangle(0,3.1,395.9,166.4), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.LeafB_sml();
	this.instance.setTransform(0.15,0.55,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110.2,110.6), null);


(lib.leafA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA_sml();
	this.instance.setTransform(90.6,19.3,2.64,2.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA, new cjs.Rectangle(0,0,214.7,245.5), null);


(lib.Layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt = new cjs.Text("Budget", "5px 'Segoe Pro Semibold'", "#1C7347");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(39.3,248.65);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C7347").s().p("AiUAFIAAgIIEpAAIAAAIg");
	this.shape.setTransform(47.6,252.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.txt}]}).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#777777").s().p("AAAAFIgKgIIACgDIAIAJIAJgJIACADIgLAKg");
	this.shape_1.setTransform(445.4568,7.2001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C9C9C9").s().p("AgMAQQgEgBABgEIABgBIAGgIIAGgEIgJgGIAAgBQgDgCACgDQACgCADABIAIAKQAGgEAJgCIgNAJQAHAGAGAKQgFgFgLgJIgEAGIgEAHIAAABQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(50.8146,7.4594);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C9C9C9").s().p("AgNAVQAAAAgBgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIABABIABACIAAAAIACgCIACgDIAEgVIAAAAIgDAAIAAgBIAAgBIADAAIAAgBIABgDQACgEADgCIAFgDIADABIABACIgBACIgBAAIgCgBIgBgBIgBgBIgCABIgBAEIgBAFIgBABIAGAAIAAAAIgBACIgFAAIgEASQAAAEgCACIgEADIgEABg");
	this.shape_3.setTransform(74.0886,7.4251);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C9C9C9").s().p("AACAIIgCgBIAAgFIAAAAIgCAEIgCACIgDAAIgBgBQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAABAAIABAAIABAAIADgDIAAgBIABgBIgCgDIAAgBIgCgBIgBAAIgBAAIAAAAIABgBIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABABIABAFIAAAAIAAAAIACgDIACgCIACgBIACABIAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgDAEIAAAAIABAEIACACIABAAIACAAIAAABIgDABg");
	this.shape_4.setTransform(75.4618,8.0251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#C9C9C9").ss(0.5,1).p("AATgNQgSARgFAKQgBABgBgBIgMgM");
	this.shape_5.setTransform(63.0759,7.3251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAGAAIAAAFg");
	this.shape_6.setTransform(39.8006,8.7251);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAGAAIAAAGg");
	this.shape_7.setTransform(39.8006,7.4001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B3B3B3").s().p("AgDADIAAgGIAGAAIAAAGg");
	this.shape_8.setTransform(39.8006,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5F6060").s().p("AgNgGIAbAAIgOANg");
	this.shape_9.setTransform(31.3005,7.1001);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#C5C5C5").ss(0.3).p("AclAqMg5JAAAIAAhTMA5JAAAg");
	this.shape_10.setTransform(265.179,7.4251);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A8kAqIAAhTMA5JAAAIAABTg");
	this.shape_11.setTransform(265.179,7.4251);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C5C5C5").ss(0.3).p("ACzAqIllAAIAAhTIFlAAg");
	this.shape_12.setTransform(62.6509,7.4251);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiyAqIAAhTIFmAAIAABTg");
	this.shape_13.setTransform(62.6509,7.4251);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#C5C5C5").ss(0.3).p("ACnAqIlNAAIAAhTIFNAAg");
	this.shape_14.setTransform(18.0503,7.4251);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimAqIAAhTIFNAAIAABTg");
	this.shape_15.setTransform(18.0503,7.4251);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#787878").s().p("AgGAAIANgNIAAAbg");
	this.shape_16.setTransform(9.4,248.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#787878").s().p("AgGgNIANANIgNAOg");
	this.shape_17.setTransform(18.975,248.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#787878").s().p("AgCAOIAAgLIgLAAIAAgFIALAAIAAgLIAEAAIAAALIAMAAIAAAFIgMAAIAAALg");
	this.shape_18.setTransform(69.425,248.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#787878").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIgAgRgRQgHAIAAAJQAAAKAHAHQAIAIAJAAQAKAAAIgIQAHgHAAgKQAAgJgHgIQgIgHgKAAQgJAAgIAHg");
	this.shape_19.setTransform(69.425,248.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#999999").s().p("A9PSuIAAhUIlIAAIAAgDIBQAAIAAgNIhQAAIAAgDIBQAAIAAhVIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhOIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhCIADAAIAABCID2AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID0AAIAAhCIADAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIDyAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCIDzAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIB4AAMAAAAjEMg69AAAIAABUgEghEARXID3AAIAABUIElAAIAAhUMA6+AAAMAAAgi+MhDaAAAg");
	this.shape_20.setTransform(220.0284,133.1024);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B4B4B4").s().p("AgTAUIAngnIAAAng");
	this.shape_21.setTransform(5.125,16.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E6E6E6").s().p("EgjJAT0MAAAgnnMBGTAAAMAAAAnngEgh2ASYID2AAIAABUIEpAAIAAhUMA67AAAMAAAgjBMhDaAAAg");
	this.shape_22.setTransform(225,126.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Layout, new cjs.Rectangle(0,0,450,259.3), null);


(lib.image01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrightcontributionsml();
	this.instance.setTransform(-0.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel_icon_sml();
	this.instance.setTransform(16.5,28.85,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0,0,129.6,125.7), null);


(lib.hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,728,90);


(lib.grass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Grass_sml();
	this.instance.setTransform(371.2,0.5,2.5,2.4999,0,0,180);

	this.instance_1 = new lib.Grass_sml();
	this.instance_1.setTransform(0.7,0.55,2.4999,2.4999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass, new cjs.Rectangle(0,0,372.1,126), null);


(lib.graphGreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#459F69").s().p("AmYGZQiqipAAjwQAAjuCqiqQCpiqDvAAQDvAACqCqQCqCqAADuQAADwiqCpIAAABQiqCpjvAAQjvAAipiqgAmiAAQAACuB7B6QB6B7CtAAQCtAAB7h7QB7h6AAiuQAAish7h7Qh7h7itAAQitAAh6B7IAAAAQh7B7AACsg");
	this.shape.setTransform(57.875,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphGreen, new cjs.Rectangle(0,0,115.8,115.8), null);


(lib.firstimage_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(-1.05,-0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(-1,-0.9,84,53), null);


(lib.fill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlrighticonsml();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girllefticonsml();
	this.instance.setTransform(-0.15,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(-0.1,-0.2,51.1,43.2), null);


(lib.face02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guylefticonsml();
	this.instance.setTransform(0.1,0.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52.1,41.1), null);


(lib.face01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrighticon1sml();
	this.instance.setTransform(-0.05,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,-0.1,53,43.1), null);


(lib.excel_screen_white_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjMASVMAAAgkpMBGZAAAMAAAAkpg");
	this.shape.setTransform(225.25,141.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white_sub, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ei4OAWyMAAAgtjMFwdAAAMAAAAtjg");
	this.shape.setTransform(0.0046,0.0301);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1179.1,-145.7,2358.3,291.5);


(lib.ribboncopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_75 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(75).call(this.frame_75).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_52 = new cjs.Graphics().p("AAWIAICQgyIC3ISIiQAyg");
	var mask_graphics_53 = new cjs.Graphics().p("AiqIAIISi3IC2ISIoTC2g");
	var mask_graphics_54 = new cjs.Graphics().p("AlbIAIN0kwIC2IRIt0Ewg");
	var mask_graphics_55 = new cjs.Graphics().p("An8IAIS2mfIC2ISIy1Geg");
	var mask_graphics_56 = new cjs.Graphics().p("AqNIAIXYoCIC2IRI3YICg");
	var mask_graphics_57 = new cjs.Graphics().p("AsQIAIbepcIC2IRI7dJcg");
	var mask_graphics_58 = new cjs.Graphics().p("AuFIAIfIqsIC2IQI/IKtg");
	var mask_graphics_59 = new cjs.Graphics().p("AvtIAMAiYgL0IC2IRMgiYAL0g");
	var mask_graphics_60 = new cjs.Graphics().p("AxJIAMAlQgMzIC2IQMglQAM0g");
	var mask_graphics_61 = new cjs.Graphics().p("AyZIAMAnxgNqIC2IQMgnxANrg");
	var mask_graphics_62 = new cjs.Graphics().p("AzfIAMAp8gOaIC3IQMgp9AObg");
	var mask_graphics_63 = new cjs.Graphics().p("A0bIAMAr0gPEIC2IRMgrzAPEg");
	var mask_graphics_64 = new cjs.Graphics().p("A1NIAMAtZgPmIC2IQMgtZAPng");
	var mask_graphics_65 = new cjs.Graphics().p("A13IAMAutgQDIC2IQMgutAQEg");
	var mask_graphics_66 = new cjs.Graphics().p("A2aIAMAvygQbIC3IRMgvzAQbg");
	var mask_graphics_67 = new cjs.Graphics().p("A22IAMAwqgQuIC2IRMgwpAQug");
	var mask_graphics_68 = new cjs.Graphics().p("A3LIAMAxVgQ9IC2ISMgxVAQ8g");
	var mask_graphics_69 = new cjs.Graphics().p("A3bIAMAx1gRIIC2IRMgx1ARIg");
	var mask_graphics_70 = new cjs.Graphics().p("A3nIAMAyMgRQIC3IRMgyNARQg");
	var mask_graphics_71 = new cjs.Graphics().p("A3vIAMAycgRVIC2IRMgybARVg");
	var mask_graphics_72 = new cjs.Graphics().p("A3zIAMAylgRZIC2ISMgylARYg");
	var mask_graphics_73 = new cjs.Graphics().p("A32IAMAyqgRaIC3IRMgyrARag");
	var mask_graphics_74 = new cjs.Graphics().p("A33IAMAysgRbIC2ISMgyrARag");
	var mask_graphics_75 = new cjs.Graphics().p("A31H/MAysgRbIC3IRMgysARcg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_graphics_52,x:34.8614,y:104.1502}).wait(1).to({graphics:mask_graphics_53,x:54.2246,y:104.1499}).wait(1).to({graphics:mask_graphics_54,x:71.9053,y:104.1498}).wait(1).to({graphics:mask_graphics_55,x:87.9798,y:104.1497}).wait(1).to({graphics:mask_graphics_56,x:102.5246,y:104.1496}).wait(1).to({graphics:mask_graphics_57,x:115.6163,y:104.1496}).wait(1).to({graphics:mask_graphics_58,x:127.3312,y:104.1495}).wait(1).to({graphics:mask_graphics_59,x:137.746,y:104.1494}).wait(1).to({graphics:mask_graphics_60,x:146.9369,y:104.1494}).wait(1).to({graphics:mask_graphics_61,x:154.9806,y:104.1493}).wait(1).to({graphics:mask_graphics_62,x:161.9535,y:104.1493}).wait(1).to({graphics:mask_graphics_63,x:167.9321,y:104.1493}).wait(1).to({graphics:mask_graphics_64,x:172.9929,y:104.1492}).wait(1).to({graphics:mask_graphics_65,x:177.2123,y:104.1492}).wait(1).to({graphics:mask_graphics_66,x:180.6669,y:104.1492}).wait(1).to({graphics:mask_graphics_67,x:183.4331,y:104.1492}).wait(1).to({graphics:mask_graphics_68,x:185.5875,y:104.1491}).wait(1).to({graphics:mask_graphics_69,x:187.2064,y:104.1491}).wait(1).to({graphics:mask_graphics_70,x:188.3664,y:104.1491}).wait(1).to({graphics:mask_graphics_71,x:189.144,y:104.1491}).wait(1).to({graphics:mask_graphics_72,x:189.6157,y:104.1491}).wait(1).to({graphics:mask_graphics_73,x:189.8579,y:104.1491}).wait(1).to({graphics:mask_graphics_74,x:189.9471,y:104.1491}).wait(1).to({graphics:mask_graphics_75,x:190.1736,y:104.0502}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AselkIY+DSI5AH3g");
	this.shape.setTransform(102.8826,174.2367,0.6439,0.6439);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(52).to({_off:false},0).wait(24));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_52 = new cjs.Graphics().p("AAWIAICQgyIC3ISIiQAyg");
	var mask_1_graphics_53 = new cjs.Graphics().p("AiqIAIISi3IC2ISIoTC2g");
	var mask_1_graphics_54 = new cjs.Graphics().p("AlbIAIN0kwIC2IRIt0Ewg");
	var mask_1_graphics_55 = new cjs.Graphics().p("An8IAIS2mfIC2ISIy1Geg");
	var mask_1_graphics_56 = new cjs.Graphics().p("AqNIAIXYoCIC2IRI3YICg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AsQIAIbepcIC2IRI7dJcg");
	var mask_1_graphics_58 = new cjs.Graphics().p("AuFIAIfIqsIC2IQI/IKtg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AvtIAMAiYgL0IC2IRMgiYAL0g");
	var mask_1_graphics_60 = new cjs.Graphics().p("AxJIAMAlQgMzIC2IQMglQAM0g");
	var mask_1_graphics_61 = new cjs.Graphics().p("AyZIAMAnxgNqIC2IQMgnxANrg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AzfIAMAp8gOaIC3IQMgp9AObg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A0bIAMAr0gPEIC2IRMgrzAPEg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A1NIAMAtZgPmIC2IQMgtZAPng");
	var mask_1_graphics_65 = new cjs.Graphics().p("A13IAMAutgQDIC2IQMgutAQEg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A2aIAMAvygQbIC3IRMgvzAQbg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A22IAMAwqgQuIC2IRMgwpAQug");
	var mask_1_graphics_68 = new cjs.Graphics().p("A3LIAMAxVgQ9IC2ISMgxVAQ8g");
	var mask_1_graphics_69 = new cjs.Graphics().p("A3bIAMAx1gRIIC2IRMgx1ARIg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A3nIAMAyMgRQIC3IRMgyNARQg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A3vIAMAycgRVIC2IRMgybARVg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A3zIAMAylgRZIC2ISMgylARYg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A32IAMAyqgRaIC3IRMgyrARag");
	var mask_1_graphics_74 = new cjs.Graphics().p("A33IAMAysgRbIC2ISMgyrARag");
	var mask_1_graphics_75 = new cjs.Graphics().p("A31H/MAysgRbIC3IRMgysARcg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_1_graphics_52,x:34.8614,y:104.1502}).wait(1).to({graphics:mask_1_graphics_53,x:54.2246,y:104.1499}).wait(1).to({graphics:mask_1_graphics_54,x:71.9053,y:104.1498}).wait(1).to({graphics:mask_1_graphics_55,x:87.9798,y:104.1497}).wait(1).to({graphics:mask_1_graphics_56,x:102.5246,y:104.1496}).wait(1).to({graphics:mask_1_graphics_57,x:115.6163,y:104.1496}).wait(1).to({graphics:mask_1_graphics_58,x:127.3312,y:104.1495}).wait(1).to({graphics:mask_1_graphics_59,x:137.746,y:104.1494}).wait(1).to({graphics:mask_1_graphics_60,x:146.9369,y:104.1494}).wait(1).to({graphics:mask_1_graphics_61,x:154.9806,y:104.1493}).wait(1).to({graphics:mask_1_graphics_62,x:161.9535,y:104.1493}).wait(1).to({graphics:mask_1_graphics_63,x:167.9321,y:104.1493}).wait(1).to({graphics:mask_1_graphics_64,x:172.9929,y:104.1492}).wait(1).to({graphics:mask_1_graphics_65,x:177.2123,y:104.1492}).wait(1).to({graphics:mask_1_graphics_66,x:180.6669,y:104.1492}).wait(1).to({graphics:mask_1_graphics_67,x:183.4331,y:104.1492}).wait(1).to({graphics:mask_1_graphics_68,x:185.5875,y:104.1491}).wait(1).to({graphics:mask_1_graphics_69,x:187.2064,y:104.1491}).wait(1).to({graphics:mask_1_graphics_70,x:188.3664,y:104.1491}).wait(1).to({graphics:mask_1_graphics_71,x:189.144,y:104.1491}).wait(1).to({graphics:mask_1_graphics_72,x:189.6157,y:104.1491}).wait(1).to({graphics:mask_1_graphics_73,x:189.8579,y:104.1491}).wait(1).to({graphics:mask_1_graphics_74,x:189.9471,y:104.1491}).wait(1).to({graphics:mask_1_graphics_75,x:190.1736,y:104.0502}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A4+EcMAx9gPaIAAHDMgwnAO6g");
	this.shape_1.setTransform(211.45,122.725);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(52).to({_off:false},0).wait(24));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_1 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_2 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_3 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_4 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_5 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_6 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_7 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_8 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_9 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_10 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_11 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_12 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_13 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_14 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_15 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_16 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_17 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_18 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_19 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_20 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_21 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_22 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_23 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_24 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_25 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_26 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_27 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_28 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_29 = new cjs.Graphics().p("EAjYAT9IBEosIBVAKIhEIsg");
	var mask_2_graphics_30 = new cjs.Graphics().p("EAjXAT9IBEosIBWAKIhEIsg");
	var mask_2_graphics_31 = new cjs.Graphics().p("EAjNAT8IBEosIBgALIhEIsg");
	var mask_2_graphics_32 = new cjs.Graphics().p("EAizAT4IBDosIB7APIhEIsg");
	var mask_2_graphics_33 = new cjs.Graphics().p("EAh/ATyIBEosICuAVIhEIsg");
	var mask_2_graphics_34 = new cjs.Graphics().p("EAgqAToIBEosIEDAfIhEIsg");
	var mask_2_graphics_35 = new cjs.Graphics().p("AerTYIBEosIGBAvIhDIsg");
	var mask_2_graphics_36 = new cjs.Graphics().p("Ab6TDIBDosIIzBEIhEIsg");
	var mask_2_graphics_37 = new cjs.Graphics().p("AYOSmIBEosIMdBhIhDIsg");
	var mask_2_graphics_38 = new cjs.Graphics().p("ATfSBIBEosIRMCGIhEIsg");
	var mask_2_graphics_39 = new cjs.Graphics().p("ANlRTIBEorIXFCzIhEIsg");
	var mask_2_graphics_40 = new cjs.Graphics().p("AGXQbIBEosIeRDsIhDIsg");
	var mask_2_graphics_41 = new cjs.Graphics().p("Ah5PbIBDosMAmhAEsIhEIrg");
	var mask_2_graphics_42 = new cjs.Graphics().p("ApHOiIBEosMAttAFkIhEIsg");
	var mask_2_graphics_43 = new cjs.Graphics().p("AvBN0IBEosMAzmAGSIhEIsg");
	var mask_2_graphics_44 = new cjs.Graphics().p("AzwNPIBEosMA4UAG3IhEIsg");
	var mask_2_graphics_45 = new cjs.Graphics().p("A3cMyIBEosMA8AAHUIhEIsg");
	var mask_2_graphics_46 = new cjs.Graphics().p("A6NMdIBEosMA+wAHpIhEIsg");
	var mask_2_graphics_47 = new cjs.Graphics().p("A8MMNIBEosMBAvAH5IhEIsg");
	var mask_2_graphics_48 = new cjs.Graphics().p("A9hMDIBEosMBCEAIDIhEIsg");
	var mask_2_graphics_49 = new cjs.Graphics().p("A+UL8IBDosMBC3AIKIhDIsg");
	var mask_2_graphics_50 = new cjs.Graphics().p("A+vL5IBEosMBDRAINIhDIsg");
	var mask_2_graphics_51 = new cjs.Graphics().p("A+5L4IBEosMBDbAIOIhDIsg");
	var mask_2_graphics_52 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_53 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_54 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_55 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_56 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_57 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_58 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_59 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_60 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_61 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_62 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_63 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_64 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_65 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_66 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_67 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_68 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_69 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_70 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_71 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_72 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_73 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_74 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");
	var mask_2_graphics_75 = new cjs.Graphics().p("A+4L4IBEosMBDdAIOIhEIsg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:241.7114,y:128.725}).wait(1).to({graphics:mask_2_graphics_1,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_2,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_3,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_4,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_5,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_6,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_7,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_8,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_9,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_10,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_11,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_12,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_13,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_14,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_15,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_16,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_17,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_18,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_19,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_20,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_21,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_22,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_23,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_24,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_25,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_26,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_27,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_28,x:241.7114,y:128.7251}).wait(1).to({graphics:mask_2_graphics_29,x:241.7114,y:128.725}).wait(1).to({graphics:mask_2_graphics_30,x:241.711,y:128.725}).wait(1).to({graphics:mask_2_graphics_31,x:241.7085,y:128.7247}).wait(1).to({graphics:mask_2_graphics_32,x:241.7018,y:128.7237}).wait(1).to({graphics:mask_2_graphics_33,x:241.6886,y:128.7219}).wait(1).to({graphics:mask_2_graphics_34,x:241.667,y:128.7188}).wait(1).to({graphics:mask_2_graphics_35,x:241.6346,y:128.7142}).wait(1).to({graphics:mask_2_graphics_36,x:241.5895,y:128.7079}).wait(1).to({graphics:mask_2_graphics_37,x:241.5295,y:128.6994}).wait(1).to({graphics:mask_2_graphics_38,x:241.4524,y:128.6885}).wait(1).to({graphics:mask_2_graphics_39,x:241.3562,y:128.6748}).wait(1).to({graphics:mask_2_graphics_40,x:241.2386,y:128.6582}).wait(1).to({graphics:mask_2_graphics_41,x:241.1037,y:128.639}).wait(1).to({graphics:mask_2_graphics_42,x:240.9861,y:128.6223}).wait(1).to({graphics:mask_2_graphics_43,x:240.8899,y:128.6087}).wait(1).to({graphics:mask_2_graphics_44,x:240.8128,y:128.5977}).wait(1).to({graphics:mask_2_graphics_45,x:240.7528,y:128.5892}).wait(1).to({graphics:mask_2_graphics_46,x:240.7077,y:128.5827}).wait(1).to({graphics:mask_2_graphics_47,x:240.6754,y:128.5782}).wait(1).to({graphics:mask_2_graphics_48,x:240.6537,y:128.5751}).wait(1).to({graphics:mask_2_graphics_49,x:240.6406,y:128.5732}).wait(1).to({graphics:mask_2_graphics_50,x:240.6338,y:128.5722}).wait(1).to({graphics:mask_2_graphics_51,x:240.6313,y:128.5719}).wait(1).to({graphics:mask_2_graphics_52,x:240.8614,y:128.625}).wait(1).to({graphics:mask_2_graphics_53,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_54,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_55,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_56,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_57,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_58,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_59,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_60,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_61,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_62,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_63,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_64,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_65,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_66,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_67,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_68,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_69,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_70,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_71,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_72,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_73,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_74,x:240.8614,y:128.6251}).wait(1).to({graphics:mask_2_graphics_75,x:240.8614,y:128.625}).wait(1));

	// bottom
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,0,0,0.008)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_2.setTransform(168,131);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("EgkVgBiIAAnHMBIrAJ/Ig7HUg");
	this.shape_3.setTransform(283.975,207.175);

	var maskedShapeInstanceList = [this.shape_2,this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},29).wait(47));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(51.4,52.5,465.20000000000005,210.10000000000002);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AjQYuIAUgZIGvFlIgVAZg");
	var mask_graphics_69 = new cjs.Graphics().p("Am8YvIHppSIGwFlInpJSg");
	var mask_graphics_70 = new cjs.Graphics().p("Ap9YvINqwjIGwFlItqQjg");
	var mask_graphics_71 = new cjs.Graphics().p("AsXYwISe2YIGvFlIyeWYg");
	var mask_graphics_72 = new cjs.Graphics().p("AuQYwIWO65IGwFkI2Oa6g");
	var mask_graphics_73 = new cjs.Graphics().p("AvqYxIZC+TIGwFjI5DeVg");
	var mask_graphics_74 = new cjs.Graphics().p("AwrYxMAbEggvIGvFkMgbEAgwg");
	var mask_graphics_75 = new cjs.Graphics().p("AxXYxMAcbgiYIGwFlMgcbAiYg");
	var mask_graphics_76 = new cjs.Graphics().p("AxxYxMAdPgjXIGwFkMgdQAjYg");
	var mask_graphics_77 = new cjs.Graphics().p("Ax/YxMAdrgj4IGvFlMgdqAj4g");
	var mask_graphics_78 = new cjs.Graphics().p("AyEYxMAd1gkEIGvFlMgd0AkEg");
	var mask_graphics_79 = new cjs.Graphics().p("Ax+YqMAd2gkGIGvFlMgd2AkGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:24.2809,y:193.8672}).wait(1).to({graphics:mask_graphics_69,x:47.6914,y:193.9525}).wait(1).to({graphics:mask_graphics_70,x:66.8675,y:194.0224}).wait(1).to({graphics:mask_graphics_71,x:82.2285,y:194.0783}).wait(1).to({graphics:mask_graphics_72,x:94.1953,y:194.1219}).wait(1).to({graphics:mask_graphics_73,x:103.1902,y:194.1546}).wait(1).to({graphics:mask_graphics_74,x:109.6365,y:194.178}).wait(1).to({graphics:mask_graphics_75,x:113.9582,y:194.1937}).wait(1).to({graphics:mask_graphics_76,x:116.5797,y:194.2033}).wait(1).to({graphics:mask_graphics_77,x:117.926,y:194.2082}).wait(1).to({graphics:mask_graphics_78,x:118.422,y:194.21}).wait(1).to({graphics:mask_graphics_79,x:119.1199,y:193.4922}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(88.8065,327.8967,0.7593,0.7252,0,-29.6758,-31.2359);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_68 = new cjs.Graphics().p("AjQYuIAUgZIGvFlIgVAZg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Am8YvIHppSIGwFlInpJSg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ap9YvINqwjIGwFlItqQjg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AsXYwISe2YIGvFlIyeWYg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AuQYwIWO65IGwFkI2Oa6g");
	var mask_1_graphics_73 = new cjs.Graphics().p("AvqYxIZC+TIGwFjI5DeVg");
	var mask_1_graphics_74 = new cjs.Graphics().p("AwrYxMAbEggvIGvFkMgbEAgwg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AxXYxMAcbgiYIGwFlMgcbAiYg");
	var mask_1_graphics_76 = new cjs.Graphics().p("AxxYxMAdPgjXIGwFkMgdQAjYg");
	var mask_1_graphics_77 = new cjs.Graphics().p("Ax/YxMAdrgj4IGvFlMgdqAj4g");
	var mask_1_graphics_78 = new cjs.Graphics().p("AyEYxMAd1gkEIGvFlMgd0AkEg");
	var mask_1_graphics_79 = new cjs.Graphics().p("Ax+YqMAd2gkGIGvFlMgd2AkGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_1_graphics_68,x:24.2809,y:193.8672}).wait(1).to({graphics:mask_1_graphics_69,x:47.6914,y:193.9525}).wait(1).to({graphics:mask_1_graphics_70,x:66.8675,y:194.0224}).wait(1).to({graphics:mask_1_graphics_71,x:82.2285,y:194.0783}).wait(1).to({graphics:mask_1_graphics_72,x:94.1953,y:194.1219}).wait(1).to({graphics:mask_1_graphics_73,x:103.1902,y:194.1546}).wait(1).to({graphics:mask_1_graphics_74,x:109.6365,y:194.178}).wait(1).to({graphics:mask_1_graphics_75,x:113.9582,y:194.1937}).wait(1).to({graphics:mask_1_graphics_76,x:116.5797,y:194.2033}).wait(1).to({graphics:mask_1_graphics_77,x:117.926,y:194.2082}).wait(1).to({graphics:mask_1_graphics_78,x:118.422,y:194.21}).wait(1).to({graphics:mask_1_graphics_79,x:119.1199,y:193.4922}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(124.7675,248.9843,0.7606,0.7264,0,-29.6759,-31.2354);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_54 = new cjs.Graphics().p("AMvPIIAygbIEEHwIgyAag");
	var mask_2_graphics_55 = new cjs.Graphics().p("AMsPIIA1gbIEEHvIg0Acg");
	var mask_2_graphics_56 = new cjs.Graphics().p("AMdPMIBEgjIEFHvIhEAkg");
	var mask_2_graphics_57 = new cjs.Graphics().p("AL0PXIBtg5IEFHvIhtA6g");
	var mask_2_graphics_58 = new cjs.Graphics().p("AKkPsIC9hjIEFHvIi9Bkg");
	var mask_2_graphics_59 = new cjs.Graphics().p("AIgQPIFBipIEFHwIlBCog");
	var mask_2_graphics_60 = new cjs.Graphics().p("AFbRCIIGkQIEFHwIoGEQg");
	var mask_2_graphics_61 = new cjs.Graphics().p("ABISLIMZmhIEFHvIsZGhg");
	var mask_2_graphics_62 = new cjs.Graphics().p("AkNTkIRupUIEFHwIxuJUg");
	var mask_2_graphics_63 = new cjs.Graphics().p("AofUtIWArlIEFHvI2BLlg");
	var mask_2_graphics_64 = new cjs.Graphics().p("ArkVgIZFtMIEFHvI5GNNg");
	var mask_2_graphics_65 = new cjs.Graphics().p("AtoWDIbJuSIEFHwI7KOSg");
	var mask_2_graphics_66 = new cjs.Graphics().p("Au5WYIcau8IEFHwI8aO8g");
	var mask_2_graphics_67 = new cjs.Graphics().p("AviWjIdDvSIEFHwI9DPSg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AvxWnIdSvaIEFHwI9SPag");
	var mask_2_graphics_69 = new cjs.Graphics().p("Av2WqIdUvbIEFHvI9VPbg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_2_graphics_54,x:112.55,y:146.3209}).wait(1).to({graphics:mask_2_graphics_55,x:112.5501,y:146.3778}).wait(1).to({graphics:mask_2_graphics_56,x:112.5506,y:146.7758}).wait(1).to({graphics:mask_2_graphics_57,x:112.5518,y:147.8561}).wait(1).to({graphics:mask_2_graphics_58,x:112.5543,y:149.9599}).wait(1).to({graphics:mask_2_graphics_59,x:112.5583,y:153.4287}).wait(1).to({graphics:mask_2_graphics_60,x:112.5644,y:158.6041}).wait(1).to({graphics:mask_2_graphics_61,x:112.5728,y:165.8284}).wait(1).to({graphics:mask_2_graphics_62,x:112.5832,y:174.8043}).wait(1).to({graphics:mask_2_graphics_63,x:112.5916,y:182.0325}).wait(1).to({graphics:mask_2_graphics_64,x:112.5977,y:187.2128}).wait(1).to({graphics:mask_2_graphics_65,x:112.6017,y:190.6858}).wait(1).to({graphics:mask_2_graphics_66,x:112.6042,y:192.7926}).wait(1).to({graphics:mask_2_graphics_67,x:112.6054,y:193.8745}).wait(1).to({graphics:mask_2_graphics_68,x:112.6059,y:194.2731}).wait(1).to({graphics:mask_2_graphics_69,x:112.275,y:194.532}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(146.4675,300.3025,0.7432,0.7432,-28.9415);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(54).to({_off:false},0).wait(26));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_54 = new cjs.Graphics().p("AMvPIIAygbIEEHwIgyAag");
	var mask_3_graphics_55 = new cjs.Graphics().p("AMsPIIA1gbIEEHvIg0Acg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AMdPMIBEgjIEFHvIhEAkg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AL0PXIBtg5IEFHvIhtA6g");
	var mask_3_graphics_58 = new cjs.Graphics().p("AKkPsIC9hjIEFHvIi9Bkg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AIgQPIFBipIEFHwIlBCog");
	var mask_3_graphics_60 = new cjs.Graphics().p("AFbRCIIGkQIEFHwIoGEQg");
	var mask_3_graphics_61 = new cjs.Graphics().p("ABISLIMZmhIEFHvIsZGhg");
	var mask_3_graphics_62 = new cjs.Graphics().p("AkNTkIRupUIEFHwIxuJUg");
	var mask_3_graphics_63 = new cjs.Graphics().p("AofUtIWArlIEFHvI2BLlg");
	var mask_3_graphics_64 = new cjs.Graphics().p("ArkVgIZFtMIEFHvI5GNNg");
	var mask_3_graphics_65 = new cjs.Graphics().p("AtoWDIbJuSIEFHwI7KOSg");
	var mask_3_graphics_66 = new cjs.Graphics().p("Au5WYIcau8IEFHwI8aO8g");
	var mask_3_graphics_67 = new cjs.Graphics().p("AviWjIdDvSIEFHwI9DPSg");
	var mask_3_graphics_68 = new cjs.Graphics().p("AvxWnIdSvaIEFHwI9SPag");
	var mask_3_graphics_69 = new cjs.Graphics().p("Av2WqIdUvbIEFHvI9VPbg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_3_graphics_54,x:112.55,y:146.3209}).wait(1).to({graphics:mask_3_graphics_55,x:112.5501,y:146.3778}).wait(1).to({graphics:mask_3_graphics_56,x:112.5506,y:146.7758}).wait(1).to({graphics:mask_3_graphics_57,x:112.5518,y:147.8561}).wait(1).to({graphics:mask_3_graphics_58,x:112.5543,y:149.9599}).wait(1).to({graphics:mask_3_graphics_59,x:112.5583,y:153.4287}).wait(1).to({graphics:mask_3_graphics_60,x:112.5644,y:158.6041}).wait(1).to({graphics:mask_3_graphics_61,x:112.5728,y:165.8284}).wait(1).to({graphics:mask_3_graphics_62,x:112.5832,y:174.8043}).wait(1).to({graphics:mask_3_graphics_63,x:112.5916,y:182.0325}).wait(1).to({graphics:mask_3_graphics_64,x:112.5977,y:187.2128}).wait(1).to({graphics:mask_3_graphics_65,x:112.6017,y:190.6858}).wait(1).to({graphics:mask_3_graphics_66,x:112.6042,y:192.7926}).wait(1).to({graphics:mask_3_graphics_67,x:112.6054,y:193.8745}).wait(1).to({graphics:mask_3_graphics_68,x:112.6059,y:194.2731}).wait(1).to({graphics:mask_3_graphics_69,x:112.275,y:194.532}).wait(11));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(117.4926,316.3249,0.7432,0.7432,-28.9415);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(54).to({_off:false},0).wait(26));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_29 = new cjs.Graphics().p("EgDtAkCIAug3IGtFoIguA3g");
	var mask_4_graphics_30 = new cjs.Graphics().p("EgFhAkCIEXlMIGsFnIkXFNg");
	var mask_4_graphics_31 = new cjs.Graphics().p("EgHMAkCIHspMIGtFnInsJMg");
	var mask_4_graphics_32 = new cjs.Graphics().p("EgIvAkCIKxs4IGuFoIqxM3g");
	var mask_4_graphics_33 = new cjs.Graphics().p("EgKJAkCINmwQIGtFoItmQPg");
	var mask_4_graphics_34 = new cjs.Graphics().p("EgLcAkCIQLzVIGuFoIwLTUg");
	var mask_4_graphics_35 = new cjs.Graphics().p("EgMnAkBISi2HIGtFoIyiWHg");
	var mask_4_graphics_36 = new cjs.Graphics().p("EgNrAkBIUq4pIGtFoI0qYpg");
	var mask_4_graphics_37 = new cjs.Graphics().p("EgOoAkBIWk67IGtFoI2ka7g");
	var mask_4_graphics_38 = new cjs.Graphics().p("EgPfAkBIYR8+IGuFoI4Rc+g");
	var mask_4_graphics_39 = new cjs.Graphics().p("EgQPAkBIZy+yIGtFoI5yeyg");
	var mask_4_graphics_40 = new cjs.Graphics().p("EgQ6AkBMAbIggYIGtFnMgbIAgZg");
	var mask_4_graphics_41 = new cjs.Graphics().p("EgRgAkBMAcUghyIGtFoMgcUAhyg");
	var mask_4_graphics_42 = new cjs.Graphics().p("EgSAAkBMAdUgjAIGtFoMgdUAjAg");
	var mask_4_graphics_43 = new cjs.Graphics().p("EgScAkBMAeMgkBIGtFmMgeMAkDg");
	var mask_4_graphics_44 = new cjs.Graphics().p("EgS0AkBMAe8gk6IGtFnMge8Ak7g");
	var mask_4_graphics_45 = new cjs.Graphics().p("EgTIAkBMAfjglpIGuFnMgfjAlqg");
	var mask_4_graphics_46 = new cjs.Graphics().p("EgTYAkBMAgEgmPIGtFmMggEAmRg");
	var mask_4_graphics_47 = new cjs.Graphics().p("EgTlAkBMAgegmuIGtFnMggeAmvg");
	var mask_4_graphics_48 = new cjs.Graphics().p("EgTvAkBMAgygnGIGtFnMggyAnHg");
	var mask_4_graphics_49 = new cjs.Graphics().p("EgT2AkBMAhAgnYIGtFnMghAAnZg");
	var mask_4_graphics_50 = new cjs.Graphics().p("EgT8AkBMAhMgnlIGtFnMghMAnmg");
	var mask_4_graphics_51 = new cjs.Graphics().p("EgT/AkBMAhSgnuIGtFnMghSAnvg");
	var mask_4_graphics_52 = new cjs.Graphics().p("EgUCAkBMAhXgnzIGuFnMghXAn0g");
	var mask_4_graphics_53 = new cjs.Graphics().p("EgUDAkBMAhagn2IGtFnMghaAn3g");
	var mask_4_graphics_54 = new cjs.Graphics().p("EgUDAkBMAhagn3IGtFnMghaAn4g");
	var mask_4_graphics_55 = new cjs.Graphics().p("EgUDAj9MAhagn3IGtFnMghaAn4g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_4_graphics_29,x:-9.4397,y:266.5616}).wait(1).to({graphics:mask_4_graphics_30,x:2.1889,y:266.553}).wait(1).to({graphics:mask_4_graphics_31,x:12.9242,y:266.5449}).wait(1).to({graphics:mask_4_graphics_32,x:22.8018,y:266.5375}).wait(1).to({graphics:mask_4_graphics_33,x:31.8573,y:266.5308}).wait(1).to({graphics:mask_4_graphics_34,x:40.1264,y:266.5246}).wait(1).to({graphics:mask_4_graphics_35,x:47.6446,y:266.519}).wait(1).to({graphics:mask_4_graphics_36,x:54.4477,y:266.5139}).wait(1).to({graphics:mask_4_graphics_37,x:60.5713,y:266.5093}).wait(1).to({graphics:mask_4_graphics_38,x:66.0512,y:266.5052}).wait(1).to({graphics:mask_4_graphics_39,x:70.923,y:266.5016}).wait(1).to({graphics:mask_4_graphics_40,x:75.2224,y:266.4983}).wait(1).to({graphics:mask_4_graphics_41,x:78.9853,y:266.4955}).wait(1).to({graphics:mask_4_graphics_42,x:82.2474,y:266.4931}).wait(1).to({graphics:mask_4_graphics_43,x:85.0443,y:266.491}).wait(1).to({graphics:mask_4_graphics_44,x:87.4119,y:266.4892}).wait(1).to({graphics:mask_4_graphics_45,x:89.3859,y:266.4878}).wait(1).to({graphics:mask_4_graphics_46,x:91.0021,y:266.4866}).wait(1).to({graphics:mask_4_graphics_47,x:92.2963,y:266.4856}).wait(1).to({graphics:mask_4_graphics_48,x:93.3042,y:266.4848}).wait(1).to({graphics:mask_4_graphics_49,x:94.0616,y:266.4843}).wait(1).to({graphics:mask_4_graphics_50,x:94.6044,y:266.4839}).wait(1).to({graphics:mask_4_graphics_51,x:94.9682,y:266.4836}).wait(1).to({graphics:mask_4_graphics_52,x:95.1888,y:266.4834}).wait(1).to({graphics:mask_4_graphics_53,x:95.3021,y:266.4833}).wait(1).to({graphics:mask_4_graphics_54,x:95.3439,y:266.4833}).wait(1).to({graphics:mask_4_graphics_55,x:96.0156,y:266.0866}).wait(25));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.008)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_4.setTransform(98,306);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_5.setTransform(80.1549,412.7901,0.7432,0.7432,-28.9415);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_5}]},29).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,6,300.8,600);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0178,0.0982,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1577,0.5759,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.036,0.464,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.6978,0.464,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.PPT_icon_sml();
	this.instance.setTransform(-7.75,-6.45,0.82,0.82);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon, new cjs.Rectangle(-7.7,-6.4,168.79999999999998,128), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Render0116();
	this.instance.setTransform(-2.6,17.85);

	this.instance_1 = new lib.Render0115sml();
	this.instance_1.setTransform(14.8,46.2,2,2);

	this.instance_2 = new lib.Render0114sml();
	this.instance_2.setTransform(14.65,45.45,2,2);

	this.instance_3 = new lib.Render0113sml();
	this.instance_3.setTransform(15.05,43.7,2,2);

	this.instance_4 = new lib.Render0112sml();
	this.instance_4.setTransform(15,40.15,2,2);

	this.instance_5 = new lib.Render0111sml();
	this.instance_5.setTransform(15.65,38.25,2,2);

	this.instance_6 = new lib.Render0110sml();
	this.instance_6.setTransform(15.9,34.3,2,2);

	this.instance_7 = new lib.Render0109sml();
	this.instance_7.setTransform(17.2,26.35,2,2);

	this.instance_8 = new lib.Render0108();
	this.instance_8.setTransform(-2.6,17.85);

	this.instance_9 = new lib.Render0117();
	this.instance_9.setTransform(-2.6,17.85);

	this.instance_10 = new lib.Render0118();
	this.instance_10.setTransform(-2.6,17.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance_2}]},3).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_7}]},7).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance_9}]},4).to({state:[{t:this.instance_10}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.6,17.9,100,151);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.circleSegment = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkgEMQAHjiCiihQCoipDwgBIAAJCg");
	mask.setTransform(28.925,28.95);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#36724B").ss(16,1,1).p("AHzAAQAADPiSCSQiTCSjOAAQjOAAiSiSQiSiSAAjPQAAjNCSiSQCSiTDOAAQDOAACTCTQCSCSAADNg");
	this.shape.setTransform(57.8259,57.8759);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circleSegment, new cjs.Rectangle(0,0,57.9,57.9), null);


(lib.circle_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.498)","rgba(0,0,0,0.247)","rgba(0,0,0,0.039)","rgba(0,0,0,0)"],[0.239,0.502,0.769,1],-0.1,-0.1,0,-0.1,-0.1,54.1).s().p("Al8F7QicidAAjeQAAjeCcieQCeicDeAAQDeAACdCcQCeCeAADeQAADeieCdQidCejeAAQjeAAieieg");
	this.shape.setTransform(128.5,128.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#000000","rgba(0,0,0,0.322)","rgba(0,0,0,0.047)","rgba(0,0,0,0)"],[0.769,0.875,0.945,0.976],0,0,0,0,0,130.4).s().p("AuMONQl4l5AAoUQAAoUF4l4QF4l4IUAAQIVAAF3F4QF5F4AAIUQAAIUl5F5Ql3F4oVAAQoUAAl4l4gAq4q4QkgEhAAGXQAAGYEgEhQEhEgGXAAQGYAAEgkgQEgkhABmYQgBmXkgkhQkgkgmYAAQmXAAkhEgg");
	this.shape_1.setTransform(128.5,128.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.039)","rgba(0,0,0,0.247)","#000000"],[0.655,0.718,0.808,1],0,0,0,0,0,80.1).s().p("AoyIyQjojpAAlJQAAlJDojpQDpjoFJAAQFJAADpDoQDpDpAAFJQAAFJjpDpQjpDplJAAQlJAAjpjpg");
	this.shape_2.setTransform(128.45,128.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Aq4K5QkgkhAAmYQAAmXEgkhQEhkgGXAAQGYAAEgEgQEhEhAAGXQAAGYkhEhQkgEgmYAAQmXAAkhkggAoyoyQjoDpAAFJQAAFJDoDpQDpDpFJAAQFJAADpjpQDpjpAAlJQAAlJjpjpQjpjolJAAQlJAAjpDog");
	this.shape_3.setTransform(128.45,128.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circle_shadow, new cjs.Rectangle(0,0,257,257), null);


(lib.chart_mask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApOJ2IAAzrIScAAIAATrg");
	this.shape.setTransform(59.05,62.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_mask, new cjs.Rectangle(0,0,118.1,125.9), null);


(lib.btn_frame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(0.5,1,1).p("AschxIY5AAIAADjI45AAg");
	this.shape.setTransform(79.625,11.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.898)").s().p("AscByIAAjjIY5AAIAADjg");
	this.shape_1.setTransform(79.625,11.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_frame, new cjs.Rectangle(-1,-1.1,161.3,24.8), null);


(lib.boxshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bottom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt3 = new cjs.Text("100%", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 31;
	this.txt3.parent = this;
	this.txt3.setTransform(438.2,5.15);

	this.txt2 = new cjs.Text("Display Settings", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.lineWidth = 31;
	this.txt2.parent = this;
	this.txt2.setTransform(321.85,4.9);

	this.txt1 = new cjs.Text("Ready", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.lineWidth = 14;
	this.txt1.parent = this;
	this.txt1.setTransform(2.3,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4F4F4F").s().p("AgBAMIAAgKIgKAAIAAgDIAKAAIAAgKIADAAIAAAKIAKAAIAAADIgKAAIAAAKg");
	this.shape.setTransform(433.2,3.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#757575").s().p("AgEAUIAAgQIifAAIAAgDICfAAIAAgUIAPAAIAAAUICZAAIAAADIiZAAIAAAQg");
	this.shape_1.setTransform(414.3,3.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4F4F4F").s().p("AgKAEIAAgHIAVAAIAAAHg");
	this.shape_2.setTransform(395.675,3.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgSATIAlAAIAAglIgLAAIAAAVIgaAAgAgEAAIAKAAIAAgSIgKAAgAgSAAIALAAIAAgSIgLAAg");
	this.shape_3.setTransform(386.7,3.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_4.setTransform(374.175,4.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_5.setTransform(374.175,3.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_6.setTransform(374.175,2.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4F4F4F").s().p("AgLARIAAghIAXAAIAAAhgAgJAOIASAAIAAgbIgSAAg");
	this.shape_7.setTransform(374.2,3.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgTATIAmAAIAAglIgmAAg");
	this.shape_8.setTransform(374.2,3.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAAJATIAKAAIAAgKIgKAAgAgEATIAKAAIAAgKIgKAAgAgSATIAMAAIAAgKIgMAAgAAJAGIAKAAIAAgKIgKAAgAgEAGIAKAAIAAgKIgKAAgAgSAGIAMAAIAAgKIgMAAgAAJgGIAKAAIAAgMIgKAAgAgEgGIAKAAIAAgMIgKAAgAgSgGIAMAAIAAgMIgMAAg");
	this.shape_9.setTransform(361.525,3.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4F4F4F").s().p("AgPAXIAAgEIALAAIAAgJIgSAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIAtAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIAAAaQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgBAAIgBgDIAAgBQAAAAABgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgCgBQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAABIgBABIgCAAIgBgBQAAgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAIgCAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAABIAAABIgBACIgBABIgBAAIgCABIgBAAIAAAJIAFAAIAAAEg");
	this.shape_10.setTransform(318.725,3.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4F4F4F").s().p("AAEALIgCgCQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAIgCACIgBAAIgCgBIAAgBIABgCQgCgCgBgDIgCAAIgBgBIAAgBIABAAIACgBIABgCIACgDIAAgCQgBgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIABAAIABACIAEAAIABgCIABAAIACABIAAABIgBACQACACABADIADABIAAAAIAAABIAAABIgDAAIgBACIgCAEIABACIgBABIgBAAgAgFgCQgEAFAHAEQAFADAEgGQADgGgGgEIgEgBQgDAAgCAFg");
	this.shape_11.setTransform(320.075,4.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F3F1F0").s().p("EgjPAAwIAAhfMBGfAAAIAABfg");
	this.shape_12.setTransform(225.575,4.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottom, new cjs.Rectangle(0,0,471.4,13.6), null);


(lib.big_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_big_msml();
	this.instance.setTransform(136,152,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_pie, new cjs.Rectangle(-0.2,0,420.2,420), null);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384549").s().p("A4MPeIAA7rIgBgWIgEgUIATgFQAUgFADABQARAFAQAAQAIAAAOgFQAPgFAJAAQALAAAGAGIAHAIIBSAoIAdACQADgGAHgEQAEgCAdgBIAcgBIARAKIALgGIAiAGIANgSIARAAIAOAKIBKgCIAKAHIBCgDIAJgHIAWACIAKgEIAfAAIAJgGQALgGAIAAQAOAAANAOIAigBIAJgHIAJADIAYAUIATAAIATAOIAWAAIAVAQIABANIANAAIADAOIAVAXIAOACIAAAKIASAIIABAIIALAAIAGAJIANABIgBALIAKAAIAOAKIABAJIAWAJIAXgUIALgFIAAgIIAjgMIADgJIAUgBIAVATIALAAIAeAcIANgJIATANQASgBADgBIANgLIAHAIIAJgGIALABIAJgEIARgDIALAKIAFgLIARgBIAHgCIAJADIAbAEIAJAIIAKgGIAKABIAGgRIASgQIAUgEQAEgBATADIA7AAIALgCIAMAGIANAAIAMgIIAQAKIAWAXIATABIAbAXIAMgCIAUAUIARACQAEAAAGAEIAHAHIAIANIAfALIAHAAIAEAHIA3AAIAGgGIAJAEIAeAAIAigoIAIAAIgCgJIAIgJIADgKQAQgJABgEQABgDAEgFIAGgEIAIgDIAAgSQAKACAAgDIgDgRIAIgBIAEgNIALgNQAOgOADgCQAEgCAPgCIATgNIAKABIAFgNIASAAIAAgQIAPgFIAHgKIAGgDQAFgEAEAAIAlADIAKACIAGAHIAdgdIABgOIAMAAIAZgNIAdgHIACgKIAIACIAEgJIALAAIABgJIATgLIACgMIANgCIANgLIABgJIAfgWIAQgGIAFAKIAQABIAXAPIASgUIAMgBIAGgHIAOAAIAOgMIANAAIAHAFIAhAAIAVAJIATgJIAgAAQApgDAOADQAOAEAQAKIAmABIAOgIIAQAGIACAHIBWABQAEAAAPgIQAPgHABAAQAEACAigBIAFgIIAJgCIAGAGIAWgLIAngBIAmgJIAOgHIAxAaIgITYIAALJg");
	this.shape.setTransform(155.4,98.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(0,0,310.8,198), null);


(lib.Background_img = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Bg_img_728x90_sml();
	this.instance.setTransform(35.5,209.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Background_img, new cjs.Rectangle(35.5,172.9,237,159.79999999999998), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAKBIIA5g1IjHAAIAAgkIDHAAIg5g2IAuAAIBNBHIhMBIg");
	this.shape.setTransform(3.5846,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(-4.1,0,15.4,8.4), null);


(lib.WordUI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.tablet_shadow_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tablet_shadow.cache(-30,-30,200,200,.25)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.tablet_shadow = new lib.tablet_shadow_sub();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(64.3,47.1,1,1,0,0,0,64.3,47.1);

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_vector, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.squareshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.tablet_shadow = new lib.tablet_shadow_vector();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.roundshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0.3,56,45), null);


(lib.Ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_26 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_27 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_28 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_29 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_30 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_31 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_32 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_33 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_34 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_35 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_36 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_37 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_38 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_39 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_40 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");
	var mask_graphics_41 = new cjs.Graphics().p("AjYHcIOsx/IFDDIIuuR/g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_graphics_26,x:104.6925,y:-67.5563}).wait(1).to({graphics:mask_graphics_27,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_28,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_29,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_30,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_31,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_32,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_33,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_34,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_35,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_36,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_37,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_38,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_39,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_40,x:104.6922,y:-67.556}).wait(1).to({graphics:mask_graphics_41,x:104.6925,y:-67.5563}).wait(9));

	// Layer_5 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AiyAvIFliKIitC3g");
	this.shape.setTransform(115.25,-27.05);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(26).to({_off:false},0).wait(24));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("AoNG7IMvunIDsAAItlPZg");
	this.shape_1.setTransform(150.2375,-67.15);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(26).to({_off:false},0).wait(24));

	// Layer_8 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AyQHeIIKpcIgBgBIEvldIXpAAIs5O6g");
	mask_1.setTransform(235.575,-67.2);

	// Layer_9
	this.bg_img = new lib.Background_img();
	this.bg_img.name = "bg_img";
	this.bg_img.setTransform(235.5,-88.7,1,1,0,0,0,155.5,233.3);
	this.bg_img.alpha = 0;
	this.bg_img._off = true;

	var maskedShapeInstanceList = [this.bg_img];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.bg_img).wait(25).to({_off:false},0).to({alpha:1},19).wait(6));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_10 = new cjs.Graphics().p("AWgqRIJ6gGIhEAdIp6AHg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AWgqRIJ6gGIhGAeIp7AHg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AWgqRIJ6gGIhVAlIp7AGg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AWfqRIJ6gGIh9A3Ip7AGg");
	var mask_2_graphics_14 = new cjs.Graphics().p("AWdqQIJ7gGIjMBYIp7AGg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AWbqPIJ7gGIlOCQIp6AGg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AWYqOIJ6gGIoODkIp7AGg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AWTqMIJ7gGIscFZIp7AGg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AWNqJIJ6gGIyCH0Ip6AGg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AWGqGIJ6gGI4zKvIp6AGg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AV/qDIJ7gGI+aNKIp5AGg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AV7qBIJ6gGMgimAO+Ip6AHg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AV3qAIJ7gGMglnAQTIp7AGg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AV1p/IJ7gGMgnpARLIp6AGg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AV0p+IJ6gGMgo3ARsIp6AGg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AVzp+IJ6gGMgpfAR+Ip6AGg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AVzp+IJ6gGMgpuASEIp6AHg");
	var mask_2_graphics_27 = new cjs.Graphics().p("AVqp6IJ6gGMgpwASFIp6AHg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_2_graphics_10,x:207.425,y:-66.425}).wait(1).to({graphics:mask_2_graphics_11,x:207.4217,y:-66.4234}).wait(1).to({graphics:mask_2_graphics_12,x:207.3961,y:-66.4125}).wait(1).to({graphics:mask_2_graphics_13,x:207.3263,y:-66.3827}).wait(1).to({graphics:mask_2_graphics_14,x:207.1905,y:-66.3247}).wait(1).to({graphics:mask_2_graphics_15,x:206.9667,y:-66.2291}).wait(1).to({graphics:mask_2_graphics_16,x:206.6327,y:-66.0865}).wait(1).to({graphics:mask_2_graphics_17,x:206.1667,y:-65.8874}).wait(1).to({graphics:mask_2_graphics_18,x:205.5465,y:-65.6224}).wait(1).to({graphics:mask_2_graphics_19,x:204.797,y:-65.3021}).wait(1).to({graphics:mask_2_graphics_20,x:204.1768,y:-65.0371}).wait(1).to({graphics:mask_2_graphics_21,x:203.7108,y:-64.8378}).wait(1).to({graphics:mask_2_graphics_22,x:203.3769,y:-64.6951}).wait(1).to({graphics:mask_2_graphics_23,x:203.1531,y:-64.5994}).wait(1).to({graphics:mask_2_graphics_24,x:203.0174,y:-64.5413}).wait(1).to({graphics:mask_2_graphics_25,x:202.9476,y:-64.5115}).wait(1).to({graphics:mask_2_graphics_26,x:202.922,y:-64.5005}).wait(1).to({graphics:mask_2_graphics_27,x:202.025,y:-64.1}).wait(23));

	// Layer_5 copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("Ak7BTIJ3jjIgEEhg");
	this.shape_2.setTransform(354.1652,-113.9067,0.6568,0.6568,-29.2388);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(10).to({_off:false},0).wait(40));

	// Layer_5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A1kG+MAoRgOuIC5A1MgoQAOsg");
	this.shape_3.setTransform(235.85,-67.8);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(10).to({_off:false},0).wait(40));

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("AQdhQIAhgkIFLDFIghAkg");
	var mask_3_graphics_1 = new cjs.Graphics().p("AQchQIAjgkIFLDFIgjAkg");
	var mask_3_graphics_2 = new cjs.Graphics().p("AQXhLIAsguIFMDFIgsAug");
	var mask_3_graphics_3 = new cjs.Graphics().p("AQKg9IBGhKIFMDFIhGBKg");
	var mask_3_graphics_4 = new cjs.Graphics().p("APxgjIB5h+IFLDFIh4B+g");
	var mask_3_graphics_5 = new cjs.Graphics().p("APIAIIDLjVIFLDGIjLDVg");
	var mask_3_graphics_6 = new cjs.Graphics().p("AOLBJIFGlXIFLDGIlGFXg");
	var mask_3_graphics_7 = new cjs.Graphics().p("AM1CjIHyoLIFLDGInyILg");
	var mask_3_graphics_8 = new cjs.Graphics().p("ALKEUILIrtIFLDGIrILtg");
	var mask_3_graphics_9 = new cjs.Graphics().p("AJ0FuIN0uhIFLDGIt0Ohg");
	var mask_3_graphics_10 = new cjs.Graphics().p("AI3GvIPvwjIFLDGIvvQjg");
	var mask_3_graphics_11 = new cjs.Graphics().p("AINHbIRCx7IFMDGIxCR7g");
	var mask_3_graphics_12 = new cjs.Graphics().p("AH0H1IR0yvIFMDGIx0Svg");
	var mask_3_graphics_13 = new cjs.Graphics().p("AHoIDISNzLIFMDGIyOTLg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AHjIIISXzVIFLDGIyXTVg");
	var mask_3_graphics_15 = new cjs.Graphics().p("AHkIIISZzWIFLDGIyYTWg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:141.7307,y:-11.1067}).wait(1).to({graphics:mask_3_graphics_1,x:141.7986,y:-11.1783}).wait(1).to({graphics:mask_3_graphics_2,x:142.2739,y:-11.6792}).wait(1).to({graphics:mask_3_graphics_3,x:143.5641,y:-13.0389}).wait(1).to({graphics:mask_3_graphics_4,x:146.0764,y:-15.6869}).wait(1).to({graphics:mask_3_graphics_5,x:150.2181,y:-20.0526}).wait(1).to({graphics:mask_3_graphics_6,x:156.3963,y:-26.5658}).wait(1).to({graphics:mask_3_graphics_7,x:165.0177,y:-35.6564}).wait(1).to({graphics:mask_3_graphics_8,x:175.7251,y:-46.9496}).wait(1).to({graphics:mask_3_graphics_9,x:184.3442,y:-56.0425}).wait(1).to({graphics:mask_3_graphics_10,x:190.5194,y:-62.5585}).wait(1).to({graphics:mask_3_graphics_11,x:194.6586,y:-66.9266}).wait(1).to({graphics:mask_3_graphics_12,x:197.1691,y:-69.5763}).wait(1).to({graphics:mask_3_graphics_13,x:198.4582,y:-70.9369}).wait(1).to({graphics:mask_3_graphics_14,x:198.9332,y:-71.4382}).wait(1).to({graphics:mask_3_graphics_15,x:199.2169,y:-71.9372}).wait(35));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("AooH0INnvnIDqAAItkPng");
	this.shape_4.setTransform(323.2375,-67.45);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(97.4,-132.3,281.20000000000005,114.9);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.option_btn_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#505050").ss(1,2,0,3).p("AgggRIAgAjIAhgj");
	this.shape.setTransform(146.2749,13.8183);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.option_btn_menu, new cjs.Rectangle(-0.3,-0.3,159.9,23.3), null);


(lib.option_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,-0.3,159.9,23.3);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:3.6,x:-0.1},0).wait(1).to({x:-1},0).wait(1).to({x:-2.1},0).wait(1).to({x:-2.8},0).wait(1).to({regX:5.6,x:-1.05},0).wait(1).to({regX:3.6,x:-2.95},0).wait(1).to({x:-2.6},0).wait(1).to({x:-2.15},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.5},0).wait(1).to({regX:5.6,x:0.55},0).wait(1).to({regX:3.6,x:-1.45},0).wait(1).to({x:-1.6},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.9},0).wait(1).to({x:-2},0).wait(1).to({regX:5.6,x:-0.05},0).wait(1).to({regX:3.6,x:-2},0).wait(1).to({x:-1.95},0).wait(1).to({x:-1.9},0).wait(1).to({x:-1.85},0).wait(1).to({regX:5.6,x:0.15},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(1).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(35));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.ribbon = new lib.Ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(218.8,205.15,1,1,0,0,0,218.8,92.8);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(0,-5.1,378.6,255.1), null);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask.setTransform(147.1518,94.651);

	// LeafA
	this.instance = new lib.leafA();
	this.instance.setTransform(58.25,128.95,0.6362,0.6362,0,0,0,99,122.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(105));

	// ScreenMaskA copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_1.setTransform(147.1518,94.651);

	// Grass
	this.instance_1 = new lib.grass();
	this.instance_1.setTransform(172.05,168.85,0.6595,0.6595,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(105));

	// ScreenMaskA copy 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_2.setTransform(147.1518,94.651);

	// LeafB
	this.instance_2 = new lib.leafB();
	this.instance_2.setTransform(255.85,101.15,0.6995,0.6995,0,0,0,55.1,54.6);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(150,70.95,0.7954,0.7954,0,0,0,50.2,75.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(55).to({mode:"synched",loop:false},0).to({y:72.9,startPosition:4},4,cjs.Ease.quadInOut).to({y:68.1,startPosition:16},12,cjs.Ease.quadInOut).to({startPosition:36},20,cjs.Ease.quadInOut).to({y:69.55,startPosition:44},8,cjs.Ease.quadInOut).wait(5).to({mode:"single",startPosition:49},0).wait(1));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(151.4,176.55,0.7338,0.7338,0,0,0,58.1,159.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55).to({regY:159.6,y:176.95},4,cjs.Ease.quadInOut).to({regY:159.7,scaleY:0.7573,y:175.65},16,cjs.Ease.quadInOut).to({scaleY:0.7571,y:175.6},12,cjs.Ease.quadInOut).to({scaleY:0.7338,y:176.55},12,cjs.Ease.quadInOut).wait(6));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_3.setTransform(147.1518,94.651);

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(167.9,158.75,0.8242,0.8242,0,0,0,155.3,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_4.setTransform(147.1518,94.651);

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(166.1,87.6,0.7852,0.7852,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(105));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(0,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(105));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,22.2,300,201);


(lib.main_ui = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MainText
	this.instance = new lib.main_txt();
	this.instance.setTransform(78.55,84.7,1,1,0,0,0,52,12.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Rows_Cells
	this.instance_1 = new lib.rowsandcells();
	this.instance_1.setTransform(233.3,34.55,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Top_bar_txt
	this.instance_2 = new lib.top_text();
	this.instance_2.setTransform(224.6,11.15,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Top_bar
	this.instance_3 = new lib.Topbar();
	this.instance_3.setTransform(225,5.5,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Top_grey
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#227347").s().p("AgOAIIgDAAIAAgYIAjAAIAAAYIgVAAIgLAJgAgPAGIAEAAIAAAGIAHgGIATAAIAAgTIgeAAg");
	this.shape.setTransform(416.4564,17.2001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#EEEDEC").ss(0.3).p("ACcAlIk3AAQgDAAgCgCQgCgCAAgDIAAg6QAAgIAHAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_1.setTransform(428.3065,17.1751);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibAlQgDAAgCgCQgCgCgBgDIAAg6QAAgIAIAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_2.setTransform(428.3065,17.1751);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#227347").s().p("AACAHQgJAAgFAEIgCABIAAgDIADgHQAEgGAJAAIAAgIIANAMIgNAOgAADAFIABAAIAAACIAHgHIgHgGIAAAEIgBAAQgLAAgDAJQAFgDAGABg");
	this.shape_3.setTransform(391.881,16.4001);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#227347").s().p("AgQANIAAgZIADAAIAAAWIAbAAIAAgLIADAAIAAAOg");
	this.shape_4.setTransform(391.106,17.9251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#474747").s().p("AgWAXQAAAAgBgBQAAAAAAAAQAAAAAAAAQABgBAAAAIARgRQgDgEAAgFQAAgHAFgFQADgFAHAAQAHAAAFAFQAFAFAAAHQAAAGgFAFQgFAEgHAAQgHAAgEgEIgRARgAgCgPQgEAEAAAGQAAAFAEAEQADAEAGAAQAGAAAEgEQAEgEAAgFQAAgGgEgEQgEgFgGABQgGgBgDAFg");
	this.shape_5.setTransform(205.7781,17.4501);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#EEEDEC").ss(0.3).p("ABnAlIjMAAQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_6.setTransform(397.9561,17.2001);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhlAlQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_7.setTransform(397.9561,17.2001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F0F0F0").s().p("EgjJAA9IAAh5MBGTAAAIAAB5g");
	this.shape_8.setTransform(225,17.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Scroll_bars
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#ABABAB").ss(0.3).p("AqYAXIAAgtIUxAAIAAAtg");
	this.shape_9.setTransform(277.1512,272.3786);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqXAXIAAgtIUvAAIAAAtg");
	this.shape_10.setTransform(277.1512,272.3786);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#787878").s().p("AgFgLIALALIgLAMg");
	this.shape_11.setTransform(437.3786,272.4286);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#787878").s().p("AgFAAIALgLIAAAXg");
	this.shape_12.setTransform(208.3001,272.4286);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_13.setTransform(437.2536,272.3786);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAXIAAgtIAsAAIAAAtg");
	this.shape_14.setTransform(437.2536,272.3786);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_15.setTransform(208.4251,272.4036);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAXIAAgsIAtAAIAAAsg");
	this.shape_16.setTransform(208.4251,272.4036);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#DBDBDB").ss(0.3).p("AxhAXIAAgtMAjDAAAIAAAtg");
	this.shape_17.setTransform(322.8519,272.3786);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DBDBDB").s().p("AxgAXIAAgtMAjCAAAIAAAtg");
	this.shape_18.setTransform(322.8519,272.3786);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#ABABAB").ss(0.3).p("AAXKZIgtAAIAA0xIAtAAg");
	this.shape_19.setTransform(445.3787,110.0511);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWKYIAA0vIAtAAIAAUvg");
	this.shape_20.setTransform(445.3787,110.0511);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAHAAIAAAFg");
	this.shape_21.setTransform(200.65,273.4536);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B3B3B3").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_22.setTransform(200.65,272.1536);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAHAAIAAAGg");
	this.shape_23.setTransform(200.65,270.8535);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787878").s().p("AgMAGIAMgLIAMALg");
	this.shape_24.setTransform(445.4037,41.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#787878").s().p("AgMgFIAYAAIgMALg");
	this.shape_25.setTransform(445.4037,265.2785);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_26.setTransform(445.3787,41.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_27.setTransform(445.3787,41.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_28.setTransform(445.4037,265.1285);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAsAAIAAAtg");
	this.shape_29.setTransform(445.4037,265.1285);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DBDBDB").ss(0.3).p("AAXRIIgtAAMAAAgiPIAtAAg");
	this.shape_30.setTransform(445.3787,153.2267);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DBDBDB").s().p("AgWRIMAAAgiPIAtAAMAAAAiPg");
	this.shape_31.setTransform(445.3787,153.2267);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// layout
	this.instance_4 = new lib.Layout();
	this.instance_4.setTransform(225,150.15,1,1,0,0,0,225,126.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Bottom
	this.instance_5 = new lib.bottom();
	this.instance_5.setTransform(225.6,281.85,1,1,0,0,0,225.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer_2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#E4DFD4").ss(1,1,1).p("EgifgVxMBE/AAAMAAAArjMhE/AAAg");
	this.shape_32.setTransform(223.225,143.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("EgifAVyMAAAgrjMBE/AAAMAAAArjg");
	this.shape_33.setTransform(223.225,143.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_ui, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.guyrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,-0.1,53,43), null);


(lib.guyrightcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.guylefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon, new cjs.Rectangle(0.1,0.1,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.graphLG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.graphGreen();
	this.instance.setTransform(49.9,49.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphLG, new cjs.Rectangle(-8,-8,115.8,115.8), null);


(lib.GraphCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// WhiteCoverOuter
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCAAQAADwiqCoQioCqjwAAQjvAAipiqQipioAAjwQAAjvCpipQCpipDvAAQDwAACoCpQCqCpAADvg");
	this.shape.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// WhiteCoverMid
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkpEpQh6h7AAiuQAAitB6h8QB8h6CtAAQCuAAB7B6QB7B8AACtQAACuh7B7Qh7B7iuAAQitAAh8h7g");
	this.shape_1.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(60));

	// Layer_3
	this.instance = new lib.circleSegment();
	this.instance.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:28.9,regY:29,rotation:-0.029,x:28.9,y:29},0).wait(1).to({rotation:-0.1186,x:28.85,y:29.05},0).wait(1).to({rotation:-0.273,x:28.8,y:29.1},0).wait(1).to({rotation:-0.4968,x:28.7,y:29.25},0).wait(1).to({rotation:-0.7954,x:28.55,y:29.4},0).wait(1).to({rotation:-1.1745,x:28.35,y:29.55},0).wait(1).to({rotation:-1.6408,x:28.15,y:29.8},0).wait(1).to({rotation:-2.2019,x:27.85,y:30.15},0).wait(1).to({rotation:-2.8662,x:27.5,y:30.45},0).wait(1).to({rotation:-3.6437,x:27.15,y:30.85},0).wait(1).to({rotation:-4.5458,x:26.7,y:31.35},0).wait(1).to({rotation:-5.5858,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7793,x:25.7,y:32.6},0).wait(1).to({rotation:-8.145,x:25.1,y:33.35},0).wait(1).to({rotation:-9.7052,x:24.5,y:34.3},0).wait(1).to({rotation:-11.4869,x:23.75,y:35.3},0).wait(1).to({rotation:-13.5237,x:23,y:36.55},0).wait(1).to({rotation:-15.8573,x:22.1,y:38},0).wait(1).to({rotation:-18.5409,x:21.2,y:39.7},0).wait(1).to({rotation:-21.6437,x:20.3,y:41.7},0).wait(1).to({rotation:-25.2575,x:19.35,y:44.1},0).wait(1).to({rotation:-29.5072,x:18.45,y:47},0).wait(1).to({rotation:-34.5678,x:17.65,y:50.55},0).wait(1).to({rotation:-40.6901,x:17.05,y:54.85},0).wait(1).to({rotation:-48.2363,y:60.25},0).wait(1).to({rotation:-57.704,x:18,y:66.9},0).wait(1).to({rotation:-69.5952,x:20.75,y:74.95},0).wait(1).to({rotation:-83.7062,x:25.95,y:83.5},0).wait(1).to({rotation:-98.1499,x:33.35,y:90.7},0).wait(1).to({rotation:-110.7267,x:41.05,y:95.2},0).wait(1).to({rotation:-120.8736,x:47.9,y:97.6},0).wait(1).to({rotation:-128.9999,x:53.6,y:98.6},0).wait(1).to({rotation:-135.6121,x:58.35,y:98.85},0).wait(1).to({rotation:-141.095,x:62.2,y:98.6},0).wait(1).to({rotation:-145.7175,x:65.5,y:98.1},0).wait(1).to({rotation:-149.667,x:68.25,y:97.45},0).wait(1).to({rotation:-153.0773,x:70.65,y:96.8},0).wait(1).to({rotation:-156.0464,x:72.6,y:96.1},0).wait(1).to({rotation:-158.6477,x:74.3,y:95.4},0).wait(1).to({rotation:-160.9377,x:75.8,y:94.7},0).wait(1).to({rotation:-162.9604,x:77.05,y:94.05},0).wait(1).to({rotation:-164.7513,x:78.2,y:93.4},0).wait(1).to({rotation:-166.3388,x:79.15,y:92.8},0).wait(1).to({rotation:-167.7463,x:80,y:92.3},0).wait(1).to({rotation:-168.9936,x:80.8,y:91.85},0).wait(1).to({rotation:-170.0968,x:81.45,y:91.4},0).wait(1).to({rotation:-171.0701,x:82,y:90.95},0).wait(1).to({rotation:-171.9252,x:82.45,y:90.65},0).wait(1).to({rotation:-172.6727,x:82.9,y:90.3},0).wait(1).to({rotation:-173.3213,x:83.25,y:90},0).wait(1).to({regX:57.9,regY:57.9,rotation:-173.879,x:57.85,y:57.95},0).wait(1).to({regX:28.9,regY:29,rotation:-173.9985,x:83.7,y:89.65},0).wait(1).to({rotation:-174.0984,x:83.75,y:89.6},0).wait(1).to({rotation:-174.1799,x:83.8,y:89.55},0).wait(1).to({rotation:-174.2445,x:83.85},0).wait(1).to({rotation:-174.2931,x:83.9},0).wait(1).to({rotation:-174.3267,y:89.5},0).wait(1).to({rotation:-174.3463},0).wait(1).to({regX:57.7,regY:57.8,rotation:-174.3527,x:58,y:57.95},0).wait(1));

	// Layer_2
	this.instance_1 = new lib.circleSegment();
	this.instance_1.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:28.9,regY:29,rotation:-0.0144,x:28.9,y:29},0).wait(1).to({rotation:-0.059},0).wait(1).to({rotation:-0.1357,x:28.85,y:29.05},0).wait(1).to({rotation:-0.247,x:28.8,y:29.1},0).wait(1).to({rotation:-0.3955,x:28.75,y:29.2},0).wait(1).to({rotation:-0.584,x:28.65,y:29.25},0).wait(1).to({rotation:-0.8159,x:28.5,y:29.4},0).wait(1).to({rotation:-1.0949,x:28.4,y:29.55},0).wait(1).to({rotation:-1.4252,x:28.2,y:29.75},0).wait(1).to({rotation:-1.8118,x:28,y:29.95},0).wait(1).to({rotation:-2.2604,x:27.85,y:30.15},0).wait(1).to({rotation:-2.7775,x:27.55,y:30.4},0).wait(1).to({rotation:-3.371,x:27.25,y:30.75},0).wait(1).to({rotation:-4.05,x:27,y:31.1},0).wait(1).to({rotation:-4.8258,x:26.6,y:31.5},0).wait(1).to({rotation:-5.7118,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7245,x:25.75,y:32.55},0).wait(1).to({rotation:-7.8849,x:25.3,y:33.25},0).wait(1).to({rotation:-9.2193,x:24.7,y:34},0).wait(1).to({rotation:-10.7621,x:24.05,y:34.9},0).wait(1).to({rotation:-12.559,x:23.35,y:35.95},0).wait(1).to({rotation:-14.6721,x:22.55,y:37.25},0).wait(1).to({rotation:-17.1885,x:21.65,y:38.8},0).wait(1).to({rotation:-20.2327,x:20.75,y:40.75},0).wait(1).to({rotation:-23.985,x:19.7,y:43.25},0).wait(1).to({rotation:-28.6927,x:18.6,y:46.45},0).wait(1).to({rotation:-34.6055,x:17.65,y:50.5},0).wait(1).to({rotation:-41.622,x:17.05,y:55.5},0).wait(1).to({rotation:-48.8041,x:17.1,y:60.6},0).wait(1).to({rotation:-55.0577,x:17.6,y:65.05},0).wait(1).to({rotation:-60.1032,x:18.45,y:68.55},0).wait(1).to({rotation:-64.1439,x:19.3,y:71.3},0).wait(1).to({rotation:-67.4317,x:20.15,y:73.5},0).wait(1).to({rotation:-70.1581,x:20.95,y:75.3},0).wait(1).to({rotation:-72.4565,x:21.65,y:76.75},0).wait(1).to({rotation:-74.4204,x:22.3,y:78},0).wait(1).to({rotation:-76.1161,x:22.95,y:79.05},0).wait(1).to({rotation:-77.5925,x:23.45,y:79.95},0).wait(1).to({rotation:-78.886,x:23.95,y:80.7},0).wait(1).to({rotation:-80.0246,x:24.45,y:81.35},0).wait(1).to({rotation:-81.0304,x:24.85,y:81.95},0).wait(1).to({rotation:-81.9209,x:25.25,y:82.5},0).wait(1).to({rotation:-82.7103,x:25.55,y:82.95},0).wait(1).to({rotation:-83.4102,x:25.9,y:83.35},0).wait(1).to({rotation:-84.0303,x:26.2,y:83.65},0).wait(1).to({rotation:-84.5789,x:26.45,y:84},0).wait(1).to({rotation:-85.0629,x:26.65,y:84.2},0).wait(1).to({rotation:-85.4881,x:26.8,y:84.5},0).wait(1).to({rotation:-85.8597,x:27,y:84.7},0).wait(1).to({rotation:-86.1822,x:27.15,y:84.85},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.4596,x:57.95,y:57.85},0).wait(1).to({regX:28.9,regY:29,rotation:-86.5188,x:27.35,y:85},0).wait(1).to({rotation:-86.5683,y:85.05},0).wait(1).to({rotation:-86.6087},0).wait(1).to({rotation:-86.6407,x:27.4},0).wait(1).to({rotation:-86.6647,y:85.1},0).wait(1).to({rotation:-86.6814,x:27.35},0).wait(1).to({rotation:-86.6911,y:85.05},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.6943,x:57.9,y:57.85},0).wait(1));

	// Layer_1
	this.instance_2 = new lib.circleSegment();
	this.instance_2.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-5.8,127.5,127.5);


(lib.girlrigthcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon, new cjs.Rectangle(-0.1,-0.2,51,43), null);


(lib.girlleftcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution, new cjs.Rectangle(0.1,-0.2,89,65), null);


(lib.excel_screen_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.white.cache(0,0,460,310,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.white = new lib.excel_screen_white_sub();
	this.white.name = "white";
	this.white.setTransform(225.3,151.3,1,1,0,0,0,225.3,151.3);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.shadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// a
	this.tablet_shadow_1 = new lib.tablet_shadow_vector();
	this.tablet_shadow_1.name = "tablet_shadow_1";
	this.tablet_shadow_1.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_2, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_124 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(124).call(this.frame_124).wait(1));

	// Icon
	this.instance = new lib.Icon();
	this.instance.setTransform(63.7,114.6,0.4734,0.4734,0,0,0,50.1,50.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:50.2,regY:50.3,scaleX:0.5022,scaleY:0.5022,x:-52.8,y:120.05},30,cjs.Ease.cubicInOut).wait(6));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(86.7,98.25,0.542,0.5022,0,-29.3001,-16.7953,58.8,15.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regX:58.7,scaleX:0.575,scaleY:0.5328,skewX:-29.2997,skewY:-16.797,x:-28.45,y:102.65,startPosition:104},30,cjs.Ease.cubicInOut).wait(6));

	// Shadow
	this.instance_2 = new lib.shadow_2();
	this.instance_2.setTransform(143.15,116.6,0.6,0.6,0,0,0,176.9,127.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(89).to({regX:176.8,regY:127.6,x:143.1,y:116.55},0).to({regY:127.7,scaleX:0.6035,scaleY:0.6035,x:29.95,y:127.4},30,cjs.Ease.cubicInOut).wait(6));

	// Layer_2
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(93.25,-214.7,1.0888,1.0888,30.1438,0,0,-0.1,-0.3);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-221.2,-198.8,498,652.4000000000001);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.chart_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.circle_shadow.cache(0,0,260,260);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_5
	this.circle_shadow = new lib.circle_shadow();
	this.circle_shadow.name = "circle_shadow";
	this.circle_shadow.setTransform(227.55,275.55,1,1,0,0,0,128.5,128.5);
	this.circle_shadow.alpha = 0.1484;

	this.timeline.addTween(cjs.Tween.get(this.circle_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_shadow, new cjs.Rectangle(0,0,420,420), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._3D_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{grow:1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		exportRoot.mainMC.page.obj1.screen.screen.gotoAndPlay("vanish");
	}
	this.frame_37 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(36).call(this.frame_37).wait(1));

	// percentage
	this.percantage = new lib.percantage();
	this.percantage.name = "percantage";
	this.percantage.setTransform(-43.15,-17.45,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.percantage.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.percantage).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-43.05,y:-17.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:247.2,regY:218.9,scaleX:0.6925,scaleY:0.6708,skewY:-4.1654,x:-16.5,y:-14.55},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1122,x:-15.15,y:-16},0).wait(1).to({scaleX:0.7169,scaleY:0.6939,skewY:-4.045,x:-13.5,y:-17.95},0).wait(1).to({scaleX:0.7333,scaleY:0.7094,skewY:-3.9642,x:-11.4,y:-20.2},0).wait(1).to({scaleX:0.7524,scaleY:0.7275,skewY:-3.8698,x:-9.1,y:-22.85},0).wait(1).to({scaleX:0.7742,scaleY:0.7481,skewY:-3.7625,x:-6.35,y:-25.85},0).wait(1).to({scaleX:0.7985,scaleY:0.7711,skewY:-3.6427,x:-3.35,y:-29.2},0).wait(1).to({scaleX:0.8252,scaleY:0.7964,skewY:-3.5111,x:-0.05,y:-32.85},0).wait(1).to({scaleX:0.8541,scaleY:0.8237,skewY:-3.3686,x:3.55,y:-36.85},0).wait(1).to({scaleX:0.885,scaleY:0.853,skewY:-3.2162,x:7.35,y:-41.1},0).wait(1).to({scaleX:0.9177,scaleY:0.8839,skewY:-3.0551,x:11.4,y:-45.6},0).wait(1).to({scaleX:0.9518,scaleY:0.9162,skewY:-2.8865,x:15.65,y:-50.3},0).wait(1).to({scaleX:0.9872,scaleY:0.9497,skewY:-2.7119,x:20.05,y:-55.15},0).wait(1).to({scaleX:1.0236,scaleY:0.9841,skewY:-2.5328,x:24.55,y:-60.15},0).wait(1).to({scaleX:1.0605,scaleY:1.019,skewY:-2.3508,x:29.15,y:-65.15},0).wait(1).to({scaleX:1.0977,scaleY:1.0542,skewY:-2.1675,x:33.75,y:-70.2},0).wait(1).to({scaleX:1.1348,scaleY:1.0893,skewY:-1.9845,x:38.35,y:-75.25},0).wait(1).to({scaleX:1.1715,scaleY:1.1241,skewY:-1.8033,x:42.9,y:-80.2},0).wait(1).to({scaleX:1.2076,scaleY:1.1582,skewY:-1.6255,x:47.4,y:-85.05},0).wait(1).to({scaleX:1.2427,scaleY:1.1914,skewY:-1.4525,x:51.75,y:-89.85},0).wait(1).to({scaleX:1.2765,scaleY:1.2234,skewY:-1.2856,x:55.9,y:-94.45},0).wait(1).to({scaleX:1.3089,scaleY:1.254,skewY:-1.126,x:59.95,y:-98.8},0).wait(1).to({scaleX:1.3395,scaleY:1.2831,skewY:-0.9748,x:63.75,y:-102.95},0).wait(1).to({scaleX:1.3683,scaleY:1.3103,skewY:-0.8327,x:67.3,y:-106.75},0).wait(1).to({scaleX:1.3952,scaleY:1.3357,skewY:-0.7006,x:70.6,y:-110.35},0).wait(1).to({scaleX:1.4198,scaleY:1.359,skewY:-0.5791,x:73.65,y:-113.65},0).wait(1).to({scaleX:1.4422,scaleY:1.3802,skewY:-0.4686,x:76.45,y:-116.7},0).wait(1).to({scaleX:1.4623,scaleY:1.3992,skewY:-0.3696,x:78.9,y:-119.35},0).wait(1).to({scaleX:1.48,scaleY:1.416,skewY:-0.2821,x:81.15,y:-121.75},0).wait(1).to({scaleX:1.4953,scaleY:1.4305,skewY:-0.2065,x:83.05,y:-123.8},0).wait(1).to({scaleX:1.5083,scaleY:1.4427,skewY:-0.1428,x:84.65,y:-125.55},0).wait(1).to({scaleX:1.5188,scaleY:1.4527,skewY:-0.0909,x:85.95,y:-126.9},0).wait(1).to({scaleX:1.5269,scaleY:1.4604,skewY:-0.0509,x:86.95,y:-128.05},0).wait(1).to({scaleX:1.5327,scaleY:1.4658,skewY:0,x:87.65,y:-128.8},0).wait(1).to({scaleX:1.5361,scaleY:1.4691,x:88.05,y:-129.25},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:30.7,y:-142.9},0).wait(1));

	// Big
	this.b_pie = new lib.big_pie();
	this.b_pie.name = "b_pie";
	this.b_pie.setTransform(-38.8,-25.9,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.b_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.b_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-38.7,y:-26.1,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:241.1,regY:237.8,scaleX:0.6924,scaleY:0.6707,skewY:-4.1658,x:-16.4,y:-9.95},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1121,x:-15.15,y:-11.1},0).wait(1).to({scaleX:0.7173,scaleY:0.6943,skewY:-4.0428,x:-13.55,y:-12.7},0).wait(1).to({scaleX:0.7347,scaleY:0.7108,skewY:-3.9571,x:-11.55,y:-14.6},0).wait(1).to({scaleX:0.7555,scaleY:0.7305,skewY:-3.8546,x:-9.15,y:-16.9},0).wait(1).to({scaleX:0.7798,scaleY:0.7534,skewY:-3.735,x:-6.4,y:-19.6},0).wait(1).to({scaleX:0.8075,scaleY:0.7796,skewY:-3.5984,x:-3.25,y:-22.6},0).wait(1).to({scaleX:0.8385,scaleY:0.809,skewY:-3.4452,x:0.3,y:-26.05},0).wait(1).to({scaleX:0.8727,scaleY:0.8414,skewY:-3.2766,x:4.2,y:-29.85},0).wait(1).to({scaleX:0.9097,scaleY:0.8764,skewY:-3.0943,x:8.45,y:-33.9},0).wait(1).to({scaleX:0.949,scaleY:0.9136,skewY:-2.9004,x:12.9,y:-38.2},0).wait(1).to({scaleX:0.9901,scaleY:0.9524,skewY:-2.6979,x:17.65,y:-42.65},0).wait(1).to({scaleX:1.0323,scaleY:0.9923,skewY:-2.4899,x:22.45,y:-47.3},0).wait(1).to({scaleX:1.0749,scaleY:1.0327,skewY:-2.2798,x:27.3,y:-51.9},0).wait(1).to({scaleX:1.1173,scaleY:1.0727,skewY:-2.0709,x:32.15,y:-56.5},0).wait(1).to({scaleX:1.1587,scaleY:1.112,skewY:-1.8662,x:36.85,y:-61},0).wait(1).to({scaleX:1.1988,scaleY:1.15,skewY:-1.6685,x:41.45,y:-65.35},0).wait(1).to({scaleX:1.2371,scaleY:1.1862,skewY:-1.4798,x:45.85,y:-69.5},0).wait(1).to({scaleX:1.2733,scaleY:1.2203,skewY:-1.3016,x:49.95,y:-73.35},0).wait(1).to({scaleX:1.307,scaleY:1.2523,skewY:-1.1352,x:53.8,y:-77},0).wait(1).to({scaleX:1.3383,scaleY:1.2819,skewY:-0.981,x:57.4,y:-80.3},0).wait(1).to({scaleX:1.367,scaleY:1.309,skewY:-0.8395,x:60.7,y:-83.45},0).wait(1).to({scaleX:1.3931,scaleY:1.3338,skewY:-0.7105,x:63.65,y:-86.25},0).wait(1).to({scaleX:1.4168,scaleY:1.3561,skewY:-0.594,x:66.35,y:-88.75},0).wait(1).to({scaleX:1.438,scaleY:1.3762,skewY:-0.4895,x:68.75,y:-91},0).wait(1).to({scaleX:1.4568,scaleY:1.394,skewY:-0.3967,x:70.9,y:-93.05},0).wait(1).to({scaleX:1.4733,scaleY:1.4097,skewY:-0.3151,x:72.8,y:-94.8},0).wait(1).to({scaleX:1.4877,scaleY:1.4233,skewY:-0.2441,x:74.5,y:-96.35},0).wait(1).to({scaleX:1.5001,scaleY:1.435,skewY:-0.1833,x:75.85,y:-97.6},0).wait(1).to({scaleX:1.5105,scaleY:1.4448,skewY:-0.1321,x:77.05,y:-98.75},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.09,x:78,y:-99.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0565,x:78.8,y:-100.35},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:79.4,y:-100.95},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:79.8,y:-101.35},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:80.05,y:-101.5},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:32.05,y:-142.9},0).wait(1));

	// Small
	this.s_pie = new lib.small_pie();
	this.s_pie.name = "s_pie";
	this.s_pie.setTransform(-40.3,-18.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.s_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.s_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-40.2,y:-18.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:269.2,regY:169.2,scaleX:0.6927,scaleY:0.6711,skewY:-4.1641,x:1.55,y:-50.05},0).wait(1).to({scaleX:0.7048,scaleY:0.6824,skewY:-4.1049,x:3.3,y:-52.3},0).wait(1).to({scaleX:0.7213,scaleY:0.6981,skewY:-4.0234,x:5.65,y:-55.3},0).wait(1).to({scaleX:0.7432,scaleY:0.7188,skewY:-3.9155,x:8.75,y:-59.4},0).wait(1).to({scaleX:0.7714,scaleY:0.7455,skewY:-3.7762,x:12.75,y:-64.6},0).wait(1).to({scaleX:0.8071,scaleY:0.7792,skewY:-3.6003,x:17.85,y:-71.2},0).wait(1).to({scaleX:0.8509,scaleY:0.8207,skewY:-3.3844,x:24.05,y:-79.25},0).wait(1).to({scaleX:0.9026,scaleY:0.8697,skewY:-3.1291,x:31.4,y:-88.75},0).wait(1).to({scaleX:0.9607,scaleY:0.9247,skewY:-2.8425,x:39.7,y:-99.4},0).wait(1).to({scaleX:1.0219,scaleY:0.9825,skewY:-2.541,x:48.4,y:-110.6},0).wait(1).to({scaleX:1.0823,scaleY:1.0396,skewY:-2.2435,x:57,y:-121.55},0).wait(1).to({scaleX:1.1388,scaleY:1.0931,skewY:-1.9646,x:65.05,y:-131.85},0).wait(1).to({scaleX:1.1901,scaleY:1.1416,skewY:-1.7118,x:72.3,y:-141.1},0).wait(1).to({scaleX:1.2357,scaleY:1.1848,skewY:-1.4869,x:78.85,y:-149.35},0).wait(1).to({scaleX:1.2759,scaleY:1.2229,skewY:-1.2886,x:84.55,y:-156.55},0).wait(1).to({scaleX:1.3113,scaleY:1.2563,skewY:-1.1142,x:89.55,y:-162.9},0).wait(1).to({scaleX:1.3423,scaleY:1.2857,skewY:-0.961,x:94,y:-168.45},0).wait(1).to({scaleX:1.3697,scaleY:1.3116,skewY:-0.8262,x:97.85,y:-173.35},0).wait(1).to({scaleX:1.3937,scaleY:1.3343,skewY:-0.7076,x:101.3,y:-177.7},0).wait(1).to({scaleX:1.4149,scaleY:1.3544,skewY:-0.603,x:104.3,y:-181.45},0).wait(1).to({scaleX:1.4336,scaleY:1.3721,skewY:-0.5109,x:106.95,y:-184.8},0).wait(1).to({scaleX:1.4501,scaleY:1.3876,skewY:-0.4298,x:109.35,y:-187.65},0).wait(1).to({scaleX:1.4646,scaleY:1.4013,skewY:-0.3585,x:111.4,y:-190.25},0).wait(1).to({scaleX:1.4772,scaleY:1.4134,skewY:-0.2959,x:113.2,y:-192.5},0).wait(1).to({scaleX:1.4883,scaleY:1.4238,skewY:-0.2411,x:114.75,y:-194.5},0).wait(1).to({scaleX:1.498,scaleY:1.433,skewY:-0.1936,x:116.15,y:-196.2},0).wait(1).to({scaleX:1.5063,scaleY:1.4409,skewY:-0.1524,x:117.35,y:-197.7},0).wait(1).to({scaleX:1.5135,scaleY:1.4476,skewY:-0.1172,x:118.3,y:-198.95},0).wait(1).to({scaleX:1.5195,scaleY:1.4533,skewY:-0.0874,x:119.2,y:-200},0).wait(1).to({scaleX:1.5245,scaleY:1.4581,skewY:-0.0627,x:119.9,y:-200.9},0).wait(1).to({scaleX:1.5286,scaleY:1.462,skewY:0,x:120.5,y:-201.65},0).wait(1).to({scaleX:1.5318,scaleY:1.465,x:120.95,y:-202.2},0).wait(1).to({scaleX:1.5343,scaleY:1.4673,x:121.25,y:-202.65},0).wait(1).to({scaleX:1.5359,scaleY:1.4689,x:121.5,y:-202.9},0).wait(1).to({scaleX:1.5369,scaleY:1.4698,x:121.7,y:-203.1},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.45,y:-143.4},0).wait(1));

	// Shadow
	this.c_shadow = new lib.chart_shadow();
	this.c_shadow.name = "c_shadow";
	this.c_shadow.setTransform(-26.45,-49.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.c_shadow.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.c_shadow).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,y:-49.55},1,cjs.Ease.cubicInOut).wait(1).to({regX:227.6,regY:275.6,scaleX:0.6926,scaleY:0.6709,skewY:-4.165,x:-13.6,y:-7.15,alpha:0.0512},0).wait(1).to({scaleX:0.7037,scaleY:0.6815,skewY:-4.1099,x:-12.65,y:-7.75,alpha:0.1221},0).wait(1).to({scaleX:0.7181,scaleY:0.6951,skewY:-4.0387,x:-11.45,y:-8.4,alpha:0.2138},0).wait(1).to({scaleX:0.7359,scaleY:0.7119,skewY:-3.9508,x:-9.95,y:-9.3,alpha:0.327},0).wait(1).to({scaleX:0.7572,scaleY:0.7321,skewY:-3.8458,x:-8.15,y:-10.35,alpha:0.4622},0).wait(1).to({scaleX:0.782,scaleY:0.7555,skewY:-3.7235,x:-6.1,y:-11.55,alpha:0.6198},0).wait(1).to({scaleX:0.8102,scaleY:0.7823,skewY:-3.5841,x:-3.7,y:-12.95,alpha:0.7993},0).wait(1).to({regX:209.8,regY:209.8,scaleX:0.8418,scaleY:0.8121,skewY:-3.4282,x:-16,y:-66.95,alpha:1},0).wait(1).to({regX:227.6,regY:275.6,scaleX:0.8765,scaleY:0.8449,skewY:-3.2574,x:1.9,y:-16.1},0).wait(1).to({scaleX:0.9138,scaleY:0.8803,skewY:-3.0733,x:5.05,y:-17.9},0).wait(1).to({scaleX:0.9534,scaleY:0.9177,skewY:-2.8783,x:8.35,y:-19.8},0).wait(1).to({scaleX:0.9945,scaleY:0.9566,skewY:-2.6753,x:11.85,y:-21.8},0).wait(1).to({scaleX:1.0367,scaleY:0.9965,skewY:-2.4676,x:15.45,y:-23.8},0).wait(1).to({scaleX:1.0791,scaleY:1.0367,skewY:-2.2583,x:18.95,y:-25.9},0).wait(1).to({scaleX:1.1212,scaleY:1.0765,skewY:-2.0509,x:22.5,y:-27.85},0).wait(1).to({scaleX:1.1623,scaleY:1.1154,skewY:-1.8481,x:26,y:-29.85},0).wait(1).to({scaleX:1.2021,scaleY:1.153,skewY:-1.6524,x:29.35,y:-31.7},0).wait(1).to({scaleX:1.2399,scaleY:1.1888,skewY:-1.4658,x:32.55,y:-33.45},0).wait(1).to({scaleX:1.2756,scaleY:1.2226,skewY:-1.2898,x:35.55,y:-35.2},0).wait(1).to({scaleX:1.309,scaleY:1.2541,skewY:-1.1253,x:38.35,y:-36.75},0).wait(1).to({scaleX:1.3399,scaleY:1.2834,skewY:-0.973,x:40.95,y:-38.25},0).wait(1).to({scaleX:1.3682,scaleY:1.3102,skewY:-0.8331,x:43.4,y:-39.55},0).wait(1).to({scaleX:1.3941,scaleY:1.3347,skewY:-0.7055,x:45.5,y:-40.75},0).wait(1).to({scaleX:1.4175,scaleY:1.3569,skewY:-0.5901,x:47.5,y:-41.85},0).wait(1).to({scaleX:1.4385,scaleY:1.3767,skewY:-0.4866,x:49.3,y:-42.9},0).wait(1).to({scaleX:1.4572,scaleY:1.3944,skewY:-0.3946,x:50.85,y:-43.7},0).wait(1).to({scaleX:1.4736,scaleY:1.4099,skewY:-0.3136,x:52.25,y:-44.45},0).wait(1).to({scaleX:1.4879,scaleY:1.4235,skewY:-0.2431,x:53.45,y:-45.15},0).wait(1).to({scaleX:1.5002,scaleY:1.4351,skewY:-0.1826,x:54.5,y:-45.75},0).wait(1).to({scaleX:1.5105,scaleY:1.4449,skewY:-0.1317,x:55.35,y:-46.2},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.0897,x:56.05,y:-46.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0564,x:56.6,y:-46.9},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:57.1,y:-47.15},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:57.35,y:-47.3},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:57.5,y:-47.4},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.2,y:-144.25},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140,-257.9,395.1,399.29999999999995);


(lib.UI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.mainUI.cache(-475,-300,950,600,0.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Main_UI
	this.mainUI = new lib.main_ui();
	this.mainUI.name = "mainUI";

	this.timeline.addTween(cjs.Tween.get(this.mainUI).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.screenanimation_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_84 = function() {
		exportRoot.mainMC.page.ribbon.ribbon.play();
	}
	this.frame_172 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(84).call(this.frame_84).wait(88).call(this.frame_172).wait(1));

	// guy right icon.png
	this.instance_3 = new lib.guyrighticon();
	this.instance_3.setTransform(198.85,-85.15,1,1,0,0,0,26.4,21.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({_off:false},0).to({x:171.9,y:-0.1,alpha:1},36,cjs.Ease.quadOut).wait(1).to({regX:26.5,regY:21.4,x:172,y:-0.2},0).wait(23).to({regX:26.4,regY:21.5,x:171.9,y:-0.1},0).wait(1).to({regX:26.5,regY:21.4,scaleX:0.9957,scaleY:0.9957,x:170.3,y:0.65},0).wait(1).to({scaleX:0.9895,scaleY:0.9895,x:167.9,y:1.8},0).wait(1).to({scaleX:0.9813,scaleY:0.9813,x:164.75,y:3.35},0).wait(1).to({scaleX:0.9712,scaleY:0.9712,x:160.9,y:5.3},0).wait(1).to({scaleX:0.9591,scaleY:0.9591,x:156.2,y:7.55},0).wait(1).to({scaleX:0.945,scaleY:0.945,x:150.75,y:10.2},0).wait(1).to({scaleX:0.9289,scaleY:0.9289,x:144.55,y:13.3},0).wait(1).to({scaleX:0.911,scaleY:0.911,x:137.65,y:16.65},0).wait(1).to({scaleX:0.8914,scaleY:0.8914,x:130.1,y:20.3},0).wait(1).to({scaleX:0.8704,scaleY:0.8704,x:122,y:24.3},0).wait(1).to({scaleX:0.8483,scaleY:0.8483,x:113.55,y:28.45},0).wait(1).to({scaleX:0.8255,scaleY:0.8255,x:104.7,y:32.7},0).wait(1).to({scaleX:0.8024,scaleY:0.8024,x:95.8,y:37.1},0).wait(1).to({scaleX:0.7794,scaleY:0.7794,x:86.95,y:41.45},0).wait(1).to({scaleX:0.757,scaleY:0.757,x:78.3,y:45.65},0).wait(1).to({scaleX:0.7356,scaleY:0.7356,x:70.1,y:49.75},0).wait(1).to({scaleX:0.7154,scaleY:0.7154,x:62.3,y:53.5},0).wait(1).to({scaleX:0.6968,scaleY:0.6968,x:55.1,y:57.05},0).wait(1).to({scaleX:0.6799,scaleY:0.6799,x:48.6,y:60.25},0).wait(1).to({scaleX:0.6649,scaleY:0.6649,x:42.8,y:63.1},0).wait(1).to({scaleX:0.6518,scaleY:0.6518,x:37.75,y:65.55},0).wait(1).to({scaleX:0.6406,scaleY:0.6406,x:33.45,y:67.65},0).wait(1).to({scaleX:0.6313,scaleY:0.6313,x:29.9,y:69.4},0).wait(1).to({scaleX:0.6238,scaleY:0.6238,x:27,y:70.85},0).wait(1).to({scaleX:0.6182,scaleY:0.6182,x:24.85,y:71.9},0).wait(1).to({scaleX:0.6142,scaleY:0.6142,x:23.3,y:72.65},0).wait(1).to({scaleX:0.6119,scaleY:0.6119,x:22.4,y:73.1},0).wait(1).to({regX:26.6,regY:21.6,scaleX:0.6112,scaleY:0.6112,x:22.05,y:73.3},0).wait(1).to({regX:26.5,regY:21.4,x:22,y:73.2},0).wait(8).to({regX:26.6,regY:21.6,x:22.05,y:73.3},0).wait(1).to({regX:26.5,regY:21.4,scaleX:0.611,scaleY:0.611,x:22,y:73.15},0).wait(1).to({scaleX:0.6108,scaleY:0.6108,y:73.1},0).wait(1).to({scaleX:0.6104,scaleY:0.6104,y:73.05},0).wait(1).to({scaleX:0.6098,scaleY:0.6098,y:73},0).wait(1).to({scaleX:0.6091,scaleY:0.6091,x:22.05,y:72.95},0).wait(1).to({scaleX:0.6083,scaleY:0.6083,y:72.85},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:22.1,y:72.75},0).wait(1).to({scaleX:0.6059,scaleY:0.6059,x:22.15,y:72.6},0).wait(1).to({scaleX:0.6043,scaleY:0.6043,x:22.2,y:72.45},0).wait(1).to({scaleX:0.6024,scaleY:0.6024,x:22.25,y:72.25},0).wait(1).to({scaleX:0.6002,scaleY:0.6002,x:22.35,y:72.05},0).wait(1).to({scaleX:0.5976,scaleY:0.5976,x:22.45,y:71.8},0).wait(1).to({scaleX:0.5946,scaleY:0.5946,x:22.55,y:71.4},0).wait(1).to({scaleX:0.5909,scaleY:0.5909,x:22.65,y:71.1},0).wait(1).to({scaleX:0.5865,scaleY:0.5865,x:22.85,y:70.6},0).wait(1).to({scaleX:0.5812,scaleY:0.5812,x:23,y:70.1},0).wait(1).to({scaleX:0.5746,scaleY:0.5746,x:23.25,y:69.4},0).wait(1).to({scaleX:0.5664,scaleY:0.5664,x:23.55,y:68.55},0).wait(1).to({scaleX:0.5558,scaleY:0.5558,x:23.95,y:67.5},0).wait(1).to({scaleX:0.5417,scaleY:0.5417,x:24.4,y:66.05},0).wait(1).to({scaleX:0.5231,scaleY:0.5231,x:25.05,y:64.1},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:25.8,y:61.95},0).wait(1).to({scaleX:0.4827,scaleY:0.4827,x:26.5,y:60},0).wait(1).to({scaleX:0.4681,scaleY:0.4681,x:27,y:58.45},0).wait(1).to({scaleX:0.457,scaleY:0.457,x:27.35,y:57.35},0).wait(1).to({scaleX:0.4483,scaleY:0.4483,x:27.7,y:56.45},0).wait(1).to({scaleX:0.4414,scaleY:0.4414,x:27.9,y:55.75},0).wait(1).to({scaleX:0.4357,scaleY:0.4357,x:28.1,y:55.1},0).wait(1).to({scaleX:0.431,scaleY:0.431,x:28.25,y:54.65},0).wait(1).to({scaleX:0.427,scaleY:0.427,x:28.4,y:54.25},0).wait(1).to({scaleX:0.4236,scaleY:0.4236,x:28.55,y:53.9},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:28.65,y:53.6},0).wait(1).to({scaleX:0.4182,scaleY:0.4182,x:28.75,y:53.35},0).wait(1).to({scaleX:0.4161,scaleY:0.4161,x:28.85,y:53.1},0).wait(1).to({scaleX:0.4142,scaleY:0.4142,x:28.9,y:52.9},0).wait(1).to({scaleX:0.4127,scaleY:0.4127,x:28.95,y:52.8},0).wait(1).to({scaleX:0.4113,scaleY:0.4113,y:52.65},0).wait(1).to({scaleX:0.4102,scaleY:0.4102,x:29,y:52.55},0).wait(1).to({scaleX:0.4092,scaleY:0.4092,x:29.05,y:52.4},0).wait(1).to({scaleX:0.4084,scaleY:0.4084,y:52.35},0).wait(1).to({scaleX:0.4078,scaleY:0.4078,x:29.1,y:52.3},0).wait(1).to({scaleX:0.4073,scaleY:0.4073,y:52.2},0).wait(1).to({scaleX:0.407,scaleY:0.407,x:29.15},0).wait(1).to({scaleX:0.4067,scaleY:0.4067,y:52.15},0).wait(1).to({scaleX:0.4066,scaleY:0.4066,x:29.1},0).wait(1).to({regX:26.4,regY:21.7,scaleX:0.4065,scaleY:0.4065,x:29.2,y:52.25},0).wait(1));

	// guy left icon.png
	this.instance_4 = new lib.guylefticon();
	this.instance_4.setTransform(-108.15,55.1,1,1,0,0,0,25.9,20.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({x:46.95,y:17.4,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:26.1,regY:20.6,x:47.15,y:17.6},0).wait(22).to({regX:25.9,regY:20.4,x:46.95,y:17.4},0).wait(1).to({regX:26.1,regY:20.6,scaleX:0.9945,scaleY:0.9945,x:46.65,y:18.4},0).wait(1).to({scaleX:0.9872,scaleY:0.9872,x:46.05,y:19.45},0).wait(1).to({scaleX:0.978,scaleY:0.978,x:45.25,y:20.7},0).wait(1).to({scaleX:0.9666,scaleY:0.9666,x:44.4,y:22.25},0).wait(1).to({scaleX:0.9531,scaleY:0.9531,x:43.25,y:24.2},0).wait(1).to({scaleX:0.9374,scaleY:0.9374,x:41.9,y:26.4},0).wait(1).to({scaleX:0.9193,scaleY:0.9193,x:40.45,y:28.95},0).wait(1).to({scaleX:0.8989,scaleY:0.8989,x:38.75,y:31.8},0).wait(1).to({scaleX:0.8762,scaleY:0.8762,x:36.85,y:35},0).wait(1).to({scaleX:0.8513,scaleY:0.8513,x:34.75,y:38.55},0).wait(1).to({scaleX:0.8244,scaleY:0.8244,x:32.55,y:42.35},0).wait(1).to({scaleX:0.7957,scaleY:0.7957,x:30.15,y:46.4},0).wait(1).to({scaleX:0.7657,scaleY:0.7657,x:27.7,y:50.55},0).wait(1).to({scaleX:0.7349,scaleY:0.7349,x:25.15,y:54.95},0).wait(1).to({scaleX:0.7038,scaleY:0.7038,x:22.55,y:59.35},0).wait(1).to({scaleX:0.673,scaleY:0.673,x:20,y:63.65},0).wait(1).to({scaleX:0.6431,scaleY:0.6431,x:17.55,y:67.85},0).wait(1).to({scaleX:0.6147,scaleY:0.6147,x:15.2,y:71.85},0).wait(1).to({scaleX:0.5882,scaleY:0.5882,x:13,y:75.6},0).wait(1).to({scaleX:0.5639,scaleY:0.5639,x:10.95,y:79},0).wait(1).to({scaleX:0.5421,scaleY:0.5421,x:9.2,y:82.1},0).wait(1).to({scaleX:0.5228,scaleY:0.5228,x:7.6,y:84.8},0).wait(1).to({scaleX:0.5061,scaleY:0.5061,x:6.2,y:87.2},0).wait(1).to({scaleX:0.492,scaleY:0.492,x:5.05,y:89.2},0).wait(1).to({scaleX:0.4804,scaleY:0.4804,x:4.05,y:90.8},0).wait(1).to({scaleX:0.4711,scaleY:0.4711,x:3.3,y:92.1},0).wait(1).to({scaleX:0.4642,scaleY:0.4642,x:2.7,y:93.05},0).wait(1).to({scaleX:0.4594,scaleY:0.4594,x:2.35,y:93.75},0).wait(1).to({scaleX:0.4566,scaleY:0.4566,x:2.05,y:94.15},0).wait(1).to({regY:20.5,scaleX:0.4557,scaleY:0.4557,x:1.9,y:94.25},0).wait(1).to({regY:20.6,y:94.3},0).wait(6).to({regY:20.5,y:94.25},0).wait(1).to({regY:20.6,y:94.3},0).wait(1).to({regY:20.5,y:94.25},0).wait(1).to({regY:20.6,scaleX:0.4556,scaleY:0.4556},0).wait(1).to({x:1.85,y:94.2},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:1.75,y:94.15},0).wait(1).to({scaleX:0.4554,scaleY:0.4554,x:1.6,y:94.05},0).wait(1).to({scaleX:0.4552,scaleY:0.4552,x:1.4,y:93.95},0).wait(1).to({scaleX:0.4551,scaleY:0.4551,x:1.2,y:93.75},0).wait(1).to({scaleX:0.4548,scaleY:0.4548,x:0.85,y:93.6},0).wait(1).to({scaleX:0.4545,scaleY:0.4545,x:0.5,y:93.4},0).wait(1).to({scaleX:0.4542,scaleY:0.4542,x:0.05,y:93.1},0).wait(1).to({scaleX:0.4538,scaleY:0.4538,x:-0.45,y:92.8},0).wait(1).to({scaleX:0.4533,scaleY:0.4533,x:-1.1,y:92.4},0).wait(1).to({scaleX:0.4526,scaleY:0.4526,x:-1.9,y:91.9},0).wait(1).to({scaleX:0.4518,scaleY:0.4518,x:-2.9,y:91.3},0).wait(1).to({scaleX:0.4508,scaleY:0.4508,x:-4.15,y:90.55},0).wait(1).to({scaleX:0.4496,scaleY:0.4496,x:-5.75,y:89.5},0).wait(1).to({scaleX:0.4478,scaleY:0.4478,x:-7.9,y:88.2},0).wait(1).to({scaleX:0.4455,scaleY:0.4455,x:-10.95,y:86.35},0).wait(1).to({scaleX:0.4422,scaleY:0.4422,x:-15.05,y:83.8},0).wait(1).to({scaleX:0.4386,scaleY:0.4386,x:-19.55,y:81.05},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:-23.1,y:78.9},0).wait(1).to({scaleX:0.4338,scaleY:0.4338,x:-25.65,y:77.3},0).wait(1).to({scaleX:0.4323,scaleY:0.4323,x:-27.5,y:76.15},0).wait(1).to({scaleX:0.4312,scaleY:0.4312,x:-28.95,y:75.25},0).wait(1).to({scaleX:0.4303,scaleY:0.4303,x:-30.1,y:74.5},0).wait(1).to({scaleX:0.4295,scaleY:0.4295,x:-31.05,y:73.95},0).wait(1).to({scaleX:0.4289,scaleY:0.4289,x:-31.8,y:73.5},0).wait(1).to({scaleX:0.4284,scaleY:0.4284,x:-32.45,y:73.05},0).wait(1).to({scaleX:0.428,scaleY:0.428,x:-33,y:72.75},0).wait(1).to({scaleX:0.4276,scaleY:0.4276,x:-33.45,y:72.45},0).wait(1).to({scaleX:0.4273,scaleY:0.4273,x:-33.8,y:72.25},0).wait(1).to({scaleX:0.4271,scaleY:0.4271,x:-34.1,y:72.05},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:-34.35,y:71.9},0).wait(1).to({scaleX:0.4267,scaleY:0.4267,x:-34.55,y:71.8},0).wait(1).to({scaleX:0.4266,scaleY:0.4266,x:-34.75,y:71.7},0).wait(1).to({scaleX:0.4265,scaleY:0.4265,x:-34.85,y:71.6},0).wait(1).to({scaleX:0.4264,scaleY:0.4264,x:-34.95,y:71.55},0).wait(1).to({x:-35,y:71.5},0).wait(1).to({scaleX:0.4263,scaleY:0.4263,x:-35.05},0).wait(1).to({regX:26.3,regY:20.8,x:-35.1,y:71.45},0).wait(6));

	// girl right icon.png
	this.instance_5 = new lib.girlrighticon();
	this.instance_5.setTransform(188.95,241.45,1,1,0,0,0,25.9,21.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({x:141.6,y:173.75,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:26,x:141.7},0).wait(23).to({regX:25.9,x:141.6},0).wait(1).to({regX:26,scaleX:0.9915,scaleY:0.9915,x:138.95,y:173.1},0).wait(1).to({scaleX:0.9815,scaleY:0.9815,x:135.7,y:172.4},0).wait(1).to({scaleX:0.9699,scaleY:0.9699,x:132,y:171.6},0).wait(1).to({scaleX:0.9569,scaleY:0.9569,x:127.85,y:170.65},0).wait(1).to({scaleX:0.9424,scaleY:0.9424,x:123.15,y:169.6},0).wait(1).to({scaleX:0.9265,scaleY:0.9265,x:118.05,y:168.45},0).wait(1).to({scaleX:0.9092,scaleY:0.9092,x:112.55,y:167.25},0).wait(1).to({scaleX:0.8908,scaleY:0.8908,x:106.6,y:165.95},0).wait(1).to({scaleX:0.8713,scaleY:0.8713,x:100.35,y:164.55},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:93.85,y:163.1},0).wait(1).to({scaleX:0.8301,scaleY:0.8301,x:87.15,y:161.6},0).wait(1).to({scaleX:0.809,scaleY:0.809,x:80.35,y:160.1},0).wait(1).to({scaleX:0.7878,scaleY:0.7878,x:73.55,y:158.6},0).wait(1).to({scaleX:0.7668,scaleY:0.7668,x:66.8,y:157.1},0).wait(1).to({scaleX:0.7464,scaleY:0.7464,x:60.2,y:155.65},0).wait(1).to({scaleX:0.7268,scaleY:0.7268,x:53.95,y:154.25},0).wait(1).to({scaleX:0.7081,scaleY:0.7081,x:47.95,y:152.9},0).wait(1).to({scaleX:0.6907,scaleY:0.6907,x:42.3,y:151.65},0).wait(1).to({scaleX:0.6745,scaleY:0.6745,x:37.15,y:150.5},0).wait(1).to({scaleX:0.6598,scaleY:0.6598,x:32.4,y:149.5},0).wait(1).to({scaleX:0.6465,scaleY:0.6465,x:28.15,y:148.5},0).wait(1).to({scaleX:0.6347,scaleY:0.6347,x:24.35,y:147.7},0).wait(1).to({scaleX:0.6245,scaleY:0.6245,x:21.1,y:147},0).wait(1).to({scaleX:0.6158,scaleY:0.6158,x:18.25,y:146.35},0).wait(1).to({scaleX:0.6085,scaleY:0.6085,x:15.95,y:145.85},0).wait(1).to({scaleX:0.6027,scaleY:0.6027,x:14.1,y:145.4},0).wait(1).to({scaleX:0.5983,scaleY:0.5983,x:12.7,y:145.05},0).wait(1).to({scaleX:0.5952,scaleY:0.5952,x:11.7,y:144.85},0).wait(1).to({scaleX:0.5933,scaleY:0.5933,x:11.15,y:144.7},0).wait(1).to({regX:26.2,regY:21.7,scaleX:0.5927,scaleY:0.5927,x:10.9},0).wait(1).to({regX:26,regY:21.5,x:10.75,y:144.6},0).wait(6).to({regX:26.2,regY:21.7,x:10.9,y:144.7},0).wait(1).to({regX:26,regY:21.5,x:10.75,y:144.6},0).wait(2).to({regX:26.2,regY:21.7,x:10.9,y:144.7},0).wait(1).to({regX:26,regY:21.5,scaleX:0.5926,scaleY:0.5926,x:10.75,y:144.5},0).wait(1).to({scaleX:0.5923,scaleY:0.5923,y:144.4},0).wait(1).to({scaleX:0.5919,scaleY:0.5919,x:10.7,y:144.25},0).wait(1).to({scaleX:0.5913,scaleY:0.5913,x:10.6,y:143.95},0).wait(1).to({scaleX:0.5906,scaleY:0.5906,x:10.5,y:143.65},0).wait(1).to({scaleX:0.5897,scaleY:0.5897,x:10.4,y:143.3},0).wait(1).to({scaleX:0.5885,scaleY:0.5885,x:10.25,y:142.75},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:10.05,y:142.15},0).wait(1).to({scaleX:0.5854,scaleY:0.5854,x:9.8,y:141.45},0).wait(1).to({scaleX:0.5833,scaleY:0.5833,x:9.55,y:140.6},0).wait(1).to({scaleX:0.5808,scaleY:0.5808,x:9.25,y:139.55},0).wait(1).to({scaleX:0.5779,scaleY:0.5779,x:8.85,y:138.3},0).wait(1).to({scaleX:0.5743,scaleY:0.5743,x:8.45,y:136.8},0).wait(1).to({scaleX:0.5701,scaleY:0.5701,x:7.85,y:135},0).wait(1).to({scaleX:0.5648,scaleY:0.5648,x:7.2,y:132.8},0).wait(1).to({scaleX:0.5582,scaleY:0.5582,x:6.35,y:130},0).wait(1).to({scaleX:0.5498,scaleY:0.5498,x:5.3,y:126.45},0).wait(1).to({scaleX:0.5386,scaleY:0.5386,x:3.85,y:121.8},0).wait(1).to({scaleX:0.5235,scaleY:0.5235,x:1.9,y:115.4},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:-0.65,y:107.05},0).wait(1).to({scaleX:0.483,scaleY:0.483,x:-3.3,y:98.35},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:-5.4,y:91.35},0).wait(1).to({scaleX:0.4541,scaleY:0.4541,x:-7,y:86.15},0).wait(1).to({scaleX:0.4447,scaleY:0.4447,x:-8.2,y:82.2},0).wait(1).to({scaleX:0.4375,scaleY:0.4375,x:-9.15,y:79.15},0).wait(1).to({scaleX:0.4316,scaleY:0.4316,x:-9.9,y:76.7},0).wait(1).to({scaleX:0.4268,scaleY:0.4268,x:-10.5,y:74.7},0).wait(1).to({scaleX:0.4228,scaleY:0.4228,x:-11,y:73},0).wait(1).to({scaleX:0.4194,scaleY:0.4194,x:-11.45,y:71.55},0).wait(1).to({scaleX:0.4166,scaleY:0.4166,x:-11.75,y:70.35},0).wait(1).to({scaleX:0.4142,scaleY:0.4142,x:-12.1,y:69.35},0).wait(1).to({scaleX:0.4121,scaleY:0.4121,x:-12.4,y:68.45},0).wait(1).to({scaleX:0.4104,scaleY:0.4104,x:-12.6,y:67.7},0).wait(1).to({scaleX:0.4089,scaleY:0.4089,x:-12.75,y:67.15},0).wait(1).to({scaleX:0.4077,scaleY:0.4077,x:-12.95,y:66.6},0).wait(1).to({scaleX:0.4066,scaleY:0.4066,x:-13.1,y:66.15},0).wait(1).to({scaleX:0.4058,scaleY:0.4058,x:-13.15,y:65.8},0).wait(1).to({scaleX:0.4051,scaleY:0.4051,x:-13.25,y:65.5},0).wait(1).to({scaleX:0.4046,scaleY:0.4046,x:-13.35,y:65.3},0).wait(1).to({scaleX:0.4042,scaleY:0.4042,x:-13.4,y:65.15},0).wait(1).to({scaleX:0.4039,scaleY:0.4039,y:65.05},0).wait(1).to({scaleX:0.4038,scaleY:0.4038,x:-13.45,y:65},0).wait(1).to({regX:26.3,regY:21.9,scaleX:0.4037,scaleY:0.4037,x:-13.4,y:65.05},0).wait(1));

	// girl left icon.png
	this.instance_6 = new lib.girllefticon();
	this.instance_6.setTransform(-119.4,159.2,1,1,0,0,0,25.3,21.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(22).to({_off:false},0).to({x:32.1,y:115.5,alpha:1},41,cjs.Ease.quadOut).wait(1).to({regX:25.4,x:32.2},0).wait(25).to({regX:25.3,x:32.1},0).wait(1).to({regX:25.4,scaleX:0.9955,scaleY:0.9955,x:31.95,y:115.45},0).wait(1).to({scaleX:0.9893,scaleY:0.9893,x:31.65},0).wait(1).to({scaleX:0.9813,scaleY:0.9813,x:31.2,y:115.5},0).wait(1).to({scaleX:0.9716,scaleY:0.9716,x:30.7},0).wait(1).to({scaleX:0.96,scaleY:0.96,x:30.05},0).wait(1).to({scaleX:0.9463,scaleY:0.9463,x:29.35},0).wait(1).to({scaleX:0.9307,scaleY:0.9307,x:28.5},0).wait(1).to({scaleX:0.9129,scaleY:0.9129,x:27.55},0).wait(1).to({scaleX:0.8931,scaleY:0.8931,x:26.5},0).wait(1).to({scaleX:0.8711,scaleY:0.8711,x:25.35},0).wait(1).to({scaleX:0.8473,scaleY:0.8473,x:24.05,y:115.55},0).wait(1).to({scaleX:0.8216,scaleY:0.8216,x:22.65},0).wait(1).to({scaleX:0.7945,scaleY:0.7945,x:21.25},0).wait(1).to({scaleX:0.7662,scaleY:0.7662,x:19.7},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:18.2},0).wait(1).to({scaleX:0.7078,scaleY:0.7078,x:16.7,y:115.6},0).wait(1).to({scaleX:0.6787,scaleY:0.6787,x:15.15},0).wait(1).to({scaleX:0.6503,scaleY:0.6503,x:13.6},0).wait(1).to({scaleX:0.6232,scaleY:0.6232,x:12.2},0).wait(1).to({scaleX:0.5976,scaleY:0.5976,x:10.85,y:115.65},0).wait(1).to({scaleX:0.574,scaleY:0.574,x:9.6},0).wait(1).to({scaleX:0.5524,scaleY:0.5524,x:8.45,y:115.6},0).wait(1).to({scaleX:0.5331,scaleY:0.5331,x:7.4,y:115.65},0).wait(1).to({scaleX:0.5161,scaleY:0.5161,x:6.45},0).wait(1).to({scaleX:0.5014,scaleY:0.5014,x:5.7,y:115.7},0).wait(1).to({scaleX:0.489,scaleY:0.489,x:5,y:115.65},0).wait(1).to({scaleX:0.4787,scaleY:0.4787,x:4.5},0).wait(1).to({scaleX:0.4706,scaleY:0.4706,x:4.05},0).wait(1).to({scaleX:0.4644,scaleY:0.4644,x:3.75,y:115.7},0).wait(1).to({scaleX:0.4602,scaleY:0.4602,x:3.5,y:115.65},0).wait(1).to({scaleX:0.4577,scaleY:0.4577,x:3.4,y:115.7},0).wait(1).to({regY:21.4,scaleX:0.4569,scaleY:0.4569,x:3.25},0).wait(1).to({regY:21.3,y:115.65},0).wait(4).to({regY:21.4,y:115.7},0).wait(1).to({regY:21.3,y:115.65},0).wait(4).to({regY:21.4,y:115.7},0).wait(1).to({regY:21.3,x:3.3,y:115.6},0).wait(1).to({scaleX:0.4568,scaleY:0.4568,y:115.5},0).wait(1).to({scaleX:0.4566,scaleY:0.4566,y:115.35},0).wait(1).to({scaleX:0.4565,scaleY:0.4565,y:115.1},0).wait(1).to({scaleX:0.4562,scaleY:0.4562,x:3.35,y:114.9},0).wait(1).to({scaleX:0.456,scaleY:0.456,x:3.4,y:114.55},0).wait(1).to({scaleX:0.4556,scaleY:0.4556,x:3.35,y:114.2},0).wait(1).to({scaleX:0.4552,scaleY:0.4552,x:3.4,y:113.7},0).wait(1).to({scaleX:0.4546,scaleY:0.4546,x:3.5,y:113.15},0).wait(1).to({scaleX:0.454,scaleY:0.454,x:3.55,y:112.4},0).wait(1).to({scaleX:0.4532,scaleY:0.4532,x:3.6,y:111.55},0).wait(1).to({scaleX:0.4523,scaleY:0.4523,x:3.7,y:110.5},0).wait(1).to({scaleX:0.4511,scaleY:0.4511,x:3.8,y:109.25},0).wait(1).to({scaleX:0.4497,scaleY:0.4497,x:3.9,y:107.7},0).wait(1).to({scaleX:0.4479,scaleY:0.4479,x:4.1,y:105.75},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:4.25,y:103.25},0).wait(1).to({scaleX:0.4426,scaleY:0.4426,x:4.55,y:99.9},0).wait(1).to({scaleX:0.4385,scaleY:0.4385,x:4.9,y:95.3},0).wait(1).to({scaleX:0.4329,scaleY:0.4329,x:5.4,y:89.1},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:5.9,y:82.55},0).wait(1).to({scaleX:0.4222,scaleY:0.4222,x:6.3,y:77.3},0).wait(1).to({scaleX:0.4187,scaleY:0.4187,x:6.65,y:73.4},0).wait(1).to({scaleX:0.4161,scaleY:0.4161,x:6.85,y:70.55},0).wait(1).to({scaleX:0.414,scaleY:0.414,x:7.05,y:68.3},0).wait(1).to({scaleX:0.4124,scaleY:0.4124,x:7.2,y:66.55},0).wait(1).to({scaleX:0.4111,scaleY:0.4111,x:7.3,y:65.1},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:7.4,y:63.9},0).wait(1).to({scaleX:0.4091,scaleY:0.4091,x:7.5,y:62.85},0).wait(1).to({scaleX:0.4083,scaleY:0.4083,x:7.55,y:62.05},0).wait(1).to({scaleX:0.4077,scaleY:0.4077,x:7.6,y:61.35},0).wait(1).to({scaleX:0.4072,scaleY:0.4072,x:7.65,y:60.7},0).wait(1).to({scaleX:0.4067,scaleY:0.4067,x:7.7,y:60.2},0).wait(1).to({scaleX:0.4063,scaleY:0.4063,y:59.8},0).wait(1).to({scaleX:0.406,scaleY:0.406,x:7.75,y:59.45},0).wait(1).to({scaleX:0.4057,scaleY:0.4057,y:59.15},0).wait(1).to({scaleX:0.4055,scaleY:0.4055,x:7.8,y:58.95},0).wait(1).to({scaleX:0.4054,scaleY:0.4054,y:58.75},0).wait(1).to({scaleX:0.4052,scaleY:0.4052,x:7.85,y:58.65},0).wait(1).to({y:58.55},0).wait(1).to({scaleX:0.4051,scaleY:0.4051,y:58.5},0).wait(1).to({regY:21.6,x:7.8,y:58.55},0).wait(1));

	// guy right contribution
	this.instance_7 = new lib.guyrightcontribution();
	this.instance_7.setTransform(240.6,-78.2,1,1,0,0,0,38.1,26.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29).to({_off:false},0).to({x:213.65,y:6.85,alpha:1},37,cjs.Ease.quadOut).wait(1).to({regX:37.5,regY:26,x:213.05,y:6.65},0).wait(22).to({regX:38.1,regY:26.2,x:213.65,y:6.85},0).wait(1).to({regX:37.5,regY:26,scaleX:0.9965,scaleY:0.9961,x:211.5,y:7.35},0).wait(1).to({scaleX:0.9917,scaleY:0.9907,skewY:-0.0564,x:209.4,y:8.2},0).wait(1).to({scaleX:0.9855,scaleY:0.9837,skewY:-0.0987,x:206.7,y:9.4},0).wait(1).to({scaleX:0.9778,scaleY:0.975,skewY:-0.1513,x:203.3,y:10.75},0).wait(1).to({scaleX:0.9685,scaleY:0.9644,skewY:-0.2147,x:199.25,y:12.5},0).wait(1).to({scaleX:0.9575,scaleY:0.952,skewY:-0.2898,x:194.45,y:14.5},0).wait(1).to({scaleX:0.9447,scaleY:0.9376,skewY:-0.377,x:188.85,y:16.9},0).wait(1).to({scaleX:0.9301,scaleY:0.921,skewY:-0.4767,x:182.5,y:19.6},0).wait(1).to({scaleX:0.9136,scaleY:0.9024,skewY:-0.5891,x:175.3,y:22.65},0).wait(1).to({scaleX:0.8952,scaleY:0.8817,skewY:-0.714,x:167.3,y:26},0).wait(1).to({scaleX:0.8752,scaleY:0.8591,skewY:-0.8507,x:158.55,y:29.7},0).wait(1).to({scaleX:0.8536,scaleY:0.8347,skewY:-0.9978,x:149.15,y:33.7},0).wait(1).to({scaleX:0.8308,scaleY:0.8089,skewY:-1.1532,x:139.2,y:37.9},0).wait(1).to({scaleX:0.8072,scaleY:0.7823,skewY:-1.314,x:128.85,y:42.25},0).wait(1).to({scaleX:0.7833,scaleY:0.7553,skewY:-1.4769,x:118.45,y:46.7},0).wait(1).to({scaleX:0.7596,scaleY:0.7286,skewY:-1.638,x:108.1,y:51.05},0).wait(1).to({scaleX:0.7368,scaleY:0.7028,skewY:-1.7936,x:98.15,y:55.25},0).wait(1).to({scaleX:0.7153,scaleY:0.6785,skewY:-1.9404,x:88.75,y:59.25},0).wait(1).to({scaleX:0.6954,scaleY:0.6561,skewY:-2.0757,x:80.1,y:62.9},0).wait(1).to({scaleX:0.6775,scaleY:0.6359,skewY:-2.1978,x:72.3,y:66.25},0).wait(1).to({scaleX:0.6617,scaleY:0.618,skewY:-2.3055,x:65.4,y:69.1},0).wait(1).to({scaleX:0.648,scaleY:0.6026,skewY:-2.3984,x:59.45,y:71.65},0).wait(1).to({scaleX:0.6365,scaleY:0.5896,skewY:-2.4767,x:54.45,y:73.8},0).wait(1).to({scaleX:0.6271,scaleY:0.579,skewY:-2.5409,x:50.35,y:75.5},0).wait(1).to({scaleX:0.6197,scaleY:0.5706,skewY:-2.5915,x:47.05,y:76.9},0).wait(1).to({scaleX:0.6141,scaleY:0.5644,skewY:-2.6294,x:44.65,y:77.9},0).wait(1).to({scaleX:0.6103,scaleY:0.56,skewY:-2.6554,x:42.95,y:78.6},0).wait(1).to({scaleX:0.6081,scaleY:0.5575,skewY:-2.6705,x:42.05,y:79.05},0).wait(1).to({regX:38.4,regY:26.3,scaleX:0.6074,scaleY:0.5567,skewY:-2.6753,x:42.1,y:79.25},0).wait(55));

	// guy left contribution
	this.instance_8 = new lib.guyleftcontribution_1();
	this.instance_8.setTransform(-59.8,65.85,1,1,0,0,0,30.4,9.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(33).to({_off:false},0).to({x:95.3,y:28.15,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:30.5,regY:9.7,x:95.4,y:28.05},0).wait(22).to({regX:30.4,regY:9.8,x:95.3,y:28.15},0).wait(1).to({regX:30.5,regY:9.7,scaleX:0.9953,scaleY:0.9954,skewX:-0.0654,skewY:-0.0111,x:94.7,y:28.7},0).wait(1).to({scaleX:0.9889,scaleY:0.989,skewX:-0.1546,skewY:-0.0262,x:93.8,y:29.6},0).wait(1).to({scaleX:0.9807,scaleY:0.9809,skewX:-0.2691,skewY:-0.0456,x:92.6,y:30.75},0).wait(1).to({scaleX:0.9705,scaleY:0.9708,skewX:-0.4109,skewY:-0.0696,x:91.15,y:32.1},0).wait(1).to({scaleX:0.9582,scaleY:0.9586,skewX:-0.5817,skewY:-0.0986,x:89.4,y:33.85},0).wait(1).to({scaleX:0.9437,scaleY:0.9442,skewX:-0.7833,skewY:-0.1328,x:87.4,y:35.9},0).wait(1).to({scaleX:0.9269,scaleY:0.9276,skewX:-1.0174,skewY:-0.1724,x:84.95,y:38.2},0).wait(1).to({scaleX:0.9076,scaleY:0.9085,skewX:-1.2854,skewY:-0.2179,x:82.25,y:40.9},0).wait(1).to({scaleX:0.8858,scaleY:0.8869,skewX:-1.5882,skewY:-0.2692,x:79.15,y:43.95},0).wait(1).to({scaleX:0.8615,scaleY:0.8629,skewX:-1.9259,skewY:-0.3264,x:75.75,y:47.35},0).wait(1).to({scaleX:0.8348,scaleY:0.8364,skewX:-2.2976,skewY:-0.3894,x:71.95,y:51.1},0).wait(1).to({scaleX:0.8058,scaleY:0.8077,skewX:-2.7006,skewY:-0.4577,x:67.8,y:55.15},0).wait(1).to({scaleX:0.7749,scaleY:0.7771,skewX:-3.1306,skewY:-0.5306,x:63.4,y:59.5},0).wait(1).to({scaleX:0.7425,scaleY:0.745,skewX:-3.581,skewY:-0.607,x:58.8,y:63.95},0).wait(1).to({scaleX:0.7093,scaleY:0.7121,skewX:-4.0435,skewY:-0.6854,x:54.1,y:68.6},0).wait(1).to({scaleX:0.6758,scaleY:0.6789,skewX:-4.5082,skewY:-0.7641,x:49.3,y:73.25},0).wait(1).to({scaleX:0.643,scaleY:0.6465,skewX:-4.9644,skewY:-0.8415,x:44.7,y:77.85},0).wait(1).to({scaleX:0.6116,scaleY:0.6153,skewX:-5.4021,skewY:-0.9156,x:40.2,y:82.25},0).wait(1).to({scaleX:0.582,scaleY:0.5861,skewX:-5.8127,skewY:-0.9852,x:36.05,y:86.35},0).wait(1).to({scaleX:0.555,scaleY:0.5592,skewX:-6.1893,skewY:-1.0491,x:32.2,y:90.15},0).wait(1).to({scaleX:0.5306,scaleY:0.5351,skewX:-6.5276,skewY:-1.1064,x:28.75,y:93.55},0).wait(1).to({scaleX:0.5093,scaleY:0.5139,skewX:-6.8251,skewY:-1.1568,x:25.7,y:96.55},0).wait(1).to({scaleX:0.4908,scaleY:0.4957,skewX:-7.0812,skewY:-1.2002,x:23.05,y:99.05},0).wait(1).to({scaleX:0.4753,scaleY:0.4804,skewX:-7.2966,skewY:-1.2368,x:20.9,y:101.25},0).wait(1).to({scaleX:0.4627,scaleY:0.4678,skewX:-7.4727,skewY:-1.2666,x:19.1,y:103},0).wait(1).to({scaleX:0.4527,scaleY:0.4579,skewX:-7.6116,skewY:-1.2902,x:17.65,y:104.4},0).wait(1).to({scaleX:0.4452,scaleY:0.4505,skewX:-7.7156,skewY:-1.3078,x:16.65,y:105.5},0).wait(1).to({scaleX:0.4401,scaleY:0.4454,skewX:-7.787,skewY:-1.3199,x:15.85,y:106.2},0).wait(1).to({scaleX:0.4371,scaleY:0.4425,skewX:-7.8282,skewY:-1.3269,x:15.5,y:106.6},0).wait(1).to({regX:30.6,regY:10.1,scaleX:0.4362,scaleY:0.4416,skewX:-7.8414,skewY:-1.3291,x:15.3,y:106.75},0).wait(54));

	// girl left contribution
	this.instance_9 = new lib.girlleftcontribution();
	this.instance_9.setTransform(-71.15,171.05,1,1,0,0,0,44,32.3);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(22).to({_off:false},0).to({x:80.35,y:127.35,alpha:1},42,cjs.Ease.quadOut).wait(1).to({regX:44.6,x:80.95},0).wait(24).to({regX:44,x:80.35},0).wait(1).to({regX:44.6,scaleX:0.9948,scaleY:0.9948,x:80.45,y:127.3},0).wait(1).to({scaleX:0.9877,scaleY:0.9877,x:79.85,y:127.2},0).wait(1).to({scaleX:0.9786,scaleY:0.9786,x:79.05,y:127.15},0).wait(1).to({scaleX:0.9674,scaleY:0.9674,x:78.05,y:127.05},0).wait(1).to({scaleX:0.9539,scaleY:0.9539,x:76.85,y:126.95},0).wait(1).to({scaleX:0.9381,scaleY:0.9381,x:75.45,y:126.8},0).wait(1).to({scaleX:0.9197,scaleY:0.9197,x:73.8,y:126.65},0).wait(1).to({scaleX:0.8988,scaleY:0.8988,x:71.95,y:126.5},0).wait(1).to({scaleX:0.8753,scaleY:0.8753,x:69.85,y:126.3},0).wait(1).to({scaleX:0.8491,scaleY:0.8491,x:67.5,y:126.15},0).wait(1).to({scaleX:0.8204,scaleY:0.8204,x:65,y:125.85},0).wait(1).to({scaleX:0.7892,scaleY:0.7892,x:62.2,y:125.65},0).wait(1).to({scaleX:0.756,scaleY:0.756,x:59.25,y:125.35},0).wait(1).to({scaleX:0.7212,scaleY:0.7212,x:56.15,y:125.1},0).wait(1).to({scaleX:0.6853,scaleY:0.6853,x:52.95,y:124.8},0).wait(1).to({scaleX:0.649,scaleY:0.649,x:49.75,y:124.45},0).wait(1).to({scaleX:0.6131,scaleY:0.6131,x:46.55,y:124.2},0).wait(1).to({scaleX:0.5783,scaleY:0.5783,x:43.45,y:123.95},0).wait(1).to({scaleX:0.5452,scaleY:0.5452,x:40.5,y:123.65},0).wait(1).to({scaleX:0.5144,scaleY:0.5144,x:37.8,y:123.4},0).wait(1).to({scaleX:0.4862,scaleY:0.4862,x:35.3,y:123.15},0).wait(1).to({scaleX:0.461,scaleY:0.461,x:33.05,y:123},0).wait(1).to({scaleX:0.4388,scaleY:0.4388,x:31.05,y:122.75},0).wait(1).to({scaleX:0.4197,scaleY:0.4197,x:29.35,y:122.6},0).wait(1).to({scaleX:0.4036,scaleY:0.4036,x:27.95,y:122.5},0).wait(1).to({scaleX:0.3904,scaleY:0.3904,x:26.75,y:122.4},0).wait(1).to({scaleX:0.38,scaleY:0.38,x:25.85,y:122.3},0).wait(1).to({scaleX:0.3722,scaleY:0.3722,x:25.15,y:122.25},0).wait(1).to({scaleX:0.3668,scaleY:0.3668,x:24.65,y:122.2},0).wait(1).to({scaleX:0.3636,scaleY:0.3636,x:24.4},0).wait(1).to({regX:44.4,regY:32.8,scaleX:0.3626,scaleY:0.3626,x:24.1},0).wait(53));

	// girl rigth contribution
	this.instance_10 = new lib.girlrigthcontribution();
	this.instance_10.setTransform(253.5,242.7,1,1,0,0,0,39.1,19.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(25).to({_off:false},0).to({x:206.15,y:175,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:206.05,y:174.9},0).wait(23).to({regX:39.1,regY:19.1,x:206.15,y:175},0).wait(1).to({regX:39,regY:19,scaleX:0.9954,scaleY:0.9954,x:204.7,y:174.6},0).wait(1).to({scaleX:0.9892,scaleY:0.9892,x:202.95,y:174.2},0).wait(1).to({scaleX:0.9814,scaleY:0.9814,x:200.65,y:173.75},0).wait(1).to({scaleX:0.9717,scaleY:0.9717,x:197.95,y:173.15},0).wait(1).to({scaleX:0.9602,scaleY:0.9602,x:194.65,y:172.45},0).wait(1).to({scaleX:0.9467,scaleY:0.9467,x:190.75,y:171.6},0).wait(1).to({scaleX:0.931,scaleY:0.931,x:186.25,y:170.65},0).wait(1).to({scaleX:0.913,scaleY:0.913,x:181.15,y:169.55},0).wait(1).to({scaleX:0.8927,scaleY:0.8927,x:175.35,y:168.3},0).wait(1).to({scaleX:0.87,scaleY:0.87,x:168.85,y:166.9},0).wait(1).to({scaleX:0.8449,scaleY:0.8449,x:161.65,y:165.35},0).wait(1).to({scaleX:0.8175,scaleY:0.8175,x:153.85,y:163.7},0).wait(1).to({scaleX:0.7879,scaleY:0.7879,x:145.4,y:161.85},0).wait(1).to({scaleX:0.7564,scaleY:0.7564,x:136.35,y:159.9},0).wait(1).to({scaleX:0.7234,scaleY:0.7234,x:126.9,y:157.9},0).wait(1).to({scaleX:0.6895,scaleY:0.6895,x:117.25,y:155.8},0).wait(1).to({scaleX:0.6553,scaleY:0.6553,x:107.45,y:153.7},0).wait(1).to({scaleX:0.6216,scaleY:0.6216,x:97.8,y:151.65},0).wait(1).to({scaleX:0.5889,scaleY:0.5889,x:88.45,y:149.65},0).wait(1).to({scaleX:0.558,scaleY:0.558,x:79.6,y:147.75},0).wait(1).to({scaleX:0.5294,scaleY:0.5294,x:71.45,y:145.95},0).wait(1).to({scaleX:0.5033,scaleY:0.5033,x:64,y:144.35},0).wait(1).to({scaleX:0.4801,scaleY:0.4801,x:57.3,y:142.95},0).wait(1).to({scaleX:0.4597,scaleY:0.4597,x:51.55,y:141.7},0).wait(1).to({scaleX:0.4422,scaleY:0.4422,x:46.5,y:140.65},0).wait(1).to({scaleX:0.4275,scaleY:0.4275,x:42.3,y:139.7},0).wait(1).to({scaleX:0.4155,scaleY:0.4155,x:38.9,y:139},0).wait(1).to({scaleX:0.4061,scaleY:0.4061,x:36.2,y:138.4},0).wait(1).to({scaleX:0.399,scaleY:0.399,x:34.15,y:138},0).wait(1).to({scaleX:0.3941,scaleY:0.3941,x:32.75,y:137.7},0).wait(1).to({scaleX:0.3913,scaleY:0.3913,x:31.95,y:137.5},0).wait(1).to({regX:39.3,regY:19.2,scaleX:0.3904,scaleY:0.3904,x:31.75},0).wait(52));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_22 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_66 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_67 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_68 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_69 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_70 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_71 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_72 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_73 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_74 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_75 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_76 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_77 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_78 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_79 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_80 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_81 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_82 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_83 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_84 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_85 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_86 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_87 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_88 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_89 = new cjs.Graphics().p("Azri5QAbgLPUkuIPRkuIIYPiI+6Jfg");
	var mask_graphics_90 = new cjs.Graphics().p("Azri5QAcgLPRktIPTkuIIXPhI+4Jfg");
	var mask_graphics_91 = new cjs.Graphics().p("Azqi5QAcgMPNkrIPWkvIIWPhI+3Jeg");
	var mask_graphics_92 = new cjs.Graphics().p("Azqi6QAfgLPGkpIPakxIIWPhI+3Jeg");
	var mask_graphics_93 = new cjs.Graphics().p("Azpi5QAhgMO9knIPekyIIXPfI+1Jeg");
	var mask_graphics_94 = new cjs.Graphics().p("Azni6QAjgMOykjIPlk0IIVPeI+yJdg");
	var mask_graphics_95 = new cjs.Graphics().p("Azli6QAmgOOlkeIPsk1IIUPbI+uJdg");
	var mask_graphics_96 = new cjs.Graphics().p("Azji6QAqgPOVkZQHsiWIJiiIITPaI+rJbg");
	var mask_graphics_97 = new cjs.Graphics().p("Azhi6QAvgQODkTQHriXITikIITPXI+nJag");
	var mask_graphics_98 = new cjs.Graphics().p("Azei7QAzgRNukMQHuiWIcipIISPVI+jJZg");
	var mask_graphics_99 = new cjs.Graphics().p("Azbi7QA5gTNXkEQHuiWIoisIIRPRI+eJYg");
	var mask_graphics_100 = new cjs.Graphics().p("AzXi7QA+gVM+j8QHviWI1iwIIPPOI+XJXg");
	var mask_graphics_101 = new cjs.Graphics().p("AzUi7QBFgXMjjzQHwiWJDi1IIOPKI+SJXg");
	var mask_graphics_102 = new cjs.Graphics().p("AzQi8QBLgYMHjqQHxiVJRi6IINPHI+MJUg");
	var mask_graphics_103 = new cjs.Graphics().p("AzMi8QBSgaLqjgQHyiVJgi/IILPDI+FJSg");
	var mask_graphics_104 = new cjs.Graphics().p("AzIi8QBZgdLMjWQH0iVJujEIIKO/I9+JSg");
	var mask_graphics_105 = new cjs.Graphics().p("AzEi9QBfgdKxjOQH1iUJ8jJIIIO8I94JPg");
	var mask_graphics_106 = new cjs.Graphics().p("AzAi9QBkggKXjEQH2iUKKjOIIGO4I9zJPg");
	var mask_graphics_107 = new cjs.Graphics().p("Ay9i9QBrghJ9i9QH3iTKXjTIIFO1I9tJNg");
	var mask_graphics_108 = new cjs.Graphics().p("Ay6i9QBwgjJni1QH4iUKijVIIEOxI9oJMg");
	var mask_graphics_109 = new cjs.Graphics().p("Ay4i+QB2gkJSiuQH6iTKsjaIIDOvI9kJMg");
	var mask_graphics_110 = new cjs.Graphics().p("Ay1i+QB6glJAipQH7iTK0jcIICOtI9fJKg");
	var mask_graphics_111 = new cjs.Graphics().p("Ayzi+QB9gnIyijQH6iSK9jgIIBOrI9dJKg");
	var mask_graphics_112 = new cjs.Graphics().p("Ayxi+QCAgoIkifQH8iSLCjhIIBOoI9ZJJg");
	var mask_graphics_113 = new cjs.Graphics().p("Aywi/QCDgoIZibQH8iSLIjjIIBOnI9XJIg");
	var mask_graphics_114 = new cjs.Graphics().p("Ayvi+QCFgpIQiZQH9iRLNjlIIAOmI9WJIg");
	var mask_graphics_115 = new cjs.Graphics().p("Ayti/QCGgpIIiWQH9iSLRjmIIAOlI9UJIg");
	var mask_graphics_116 = new cjs.Graphics().p("Ayti/QCIgpIDiUQH9iSLTjnIIAOkI9TJHg");
	var mask_graphics_117 = new cjs.Graphics().p("Ayti+QCJgqIAiTQH+iSLUjoIH/OkI9RJHg");
	var mask_graphics_118 = new cjs.Graphics().p("Aysi/QCJgqH+iSQH9iSLWjoIH/OkI9RJHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_22,x:155,y:94.225}).wait(44).to({graphics:mask_graphics_66,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_67,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_68,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_69,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_70,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_71,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_72,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_73,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_74,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_75,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_76,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_77,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_78,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_79,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_80,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_81,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_82,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_83,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_84,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_85,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_86,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_87,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_88,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_89,x:155,y:94.225}).wait(1).to({graphics:mask_graphics_90,x:154.075,y:94.35}).wait(1).to({graphics:mask_graphics_91,x:152.55,y:94.6}).wait(1).to({graphics:mask_graphics_92,x:150.35,y:94.9}).wait(1).to({graphics:mask_graphics_93,x:147.45,y:95.325}).wait(1).to({graphics:mask_graphics_94,x:143.75,y:95.875}).wait(1).to({graphics:mask_graphics_95,x:139.275,y:96.55}).wait(1).to({graphics:mask_graphics_96,x:133.95,y:97.3}).wait(1).to({graphics:mask_graphics_97,x:127.75,y:98.225}).wait(1).to({graphics:mask_graphics_98,x:120.7,y:99.25}).wait(1).to({graphics:mask_graphics_99,x:112.825,y:100.425}).wait(1).to({graphics:mask_graphics_100,x:104.175,y:101.7}).wait(1).to({graphics:mask_graphics_101,x:94.975,y:103.05}).wait(1).to({graphics:mask_graphics_102,x:85.35,y:104.45}).wait(1).to({graphics:mask_graphics_103,x:75.525,y:105.875}).wait(1).to({graphics:mask_graphics_104,x:65.75,y:107.325}).wait(1).to({graphics:mask_graphics_105,x:56.275,y:108.7}).wait(1).to({graphics:mask_graphics_106,x:47.3,y:110.025}).wait(1).to({graphics:mask_graphics_107,x:38.925,y:111.25}).wait(1).to({graphics:mask_graphics_108,x:31.275,y:112.375}).wait(1).to({graphics:mask_graphics_109,x:24.4,y:113.4}).wait(1).to({graphics:mask_graphics_110,x:18.35,y:114.275}).wait(1).to({graphics:mask_graphics_111,x:13.1,y:115.05}).wait(1).to({graphics:mask_graphics_112,x:8.625,y:115.725}).wait(1).to({graphics:mask_graphics_113,x:4.875,y:116.275}).wait(1).to({graphics:mask_graphics_114,x:1.8,y:116.7}).wait(1).to({graphics:mask_graphics_115,x:-0.6,y:117.075}).wait(1).to({graphics:mask_graphics_116,x:-2.425,y:117.325}).wait(1).to({graphics:mask_graphics_117,x:-3.7,y:117.5}).wait(1).to({graphics:mask_graphics_118,x:-4.45,y:117.625}).wait(55));

	// r guy i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(188.7,-72.65,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(29).to({_off:false},0).to({x:165.95,y:17.55,alpha:0.1602},36,cjs.Ease.quadOut).wait(1).to({regX:28,x:165.75},0).wait(23).to({regX:28.2,x:165.95},0).wait(1).to({regX:28,scaleX:0.9965,scaleY:0.9965,x:164.45,y:18.1},0).wait(1).to({scaleX:0.9917,scaleY:0.9917,x:162.65,y:18.85},0).wait(1).to({scaleX:0.9854,scaleY:0.9854,x:160.35,y:19.8},0).wait(1).to({scaleX:0.9776,scaleY:0.9776,x:157.45,y:21},0).wait(1).to({scaleX:0.9681,scaleY:0.9681,x:154,y:22.4},0).wait(1).to({scaleX:0.9569,scaleY:0.9569,x:149.85,y:24.1},0).wait(1).to({scaleX:0.9437,scaleY:0.9437,x:145,y:26.1},0).wait(1).to({scaleX:0.9286,scaleY:0.9286,x:139.45,y:28.45},0).wait(1).to({scaleX:0.9115,scaleY:0.9115,x:133.15,y:31.1},0).wait(1).to({scaleX:0.8923,scaleY:0.8923,x:126.1,y:34},0).wait(1).to({scaleX:0.8712,scaleY:0.8712,x:118.35,y:37.2},0).wait(1).to({scaleX:0.8485,scaleY:0.8485,x:109.95,y:40.75},0).wait(1).to({scaleX:0.8244,scaleY:0.8244,x:101.15,y:44.4},0).wait(1).to({scaleX:0.7994,scaleY:0.7994,x:91.95,y:48.25},0).wait(1).to({scaleX:0.7742,scaleY:0.7742,x:82.7,y:52.1},0).wait(1).to({scaleX:0.7495,scaleY:0.7495,x:73.6,y:55.9},0).wait(1).to({scaleX:0.7259,scaleY:0.7259,x:64.85,y:59.5},0).wait(1).to({scaleX:0.7039,scaleY:0.7039,x:56.8,y:62.85},0).wait(1).to({scaleX:0.684,scaleY:0.684,x:49.5,y:65.9},0).wait(1).to({scaleX:0.6664,scaleY:0.6664,x:43,y:68.6},0).wait(1).to({scaleX:0.6513,scaleY:0.6513,x:37.45,y:70.9},0).wait(1).to({scaleX:0.6385,scaleY:0.6385,x:32.75,y:72.85},0).wait(1).to({scaleX:0.6281,scaleY:0.6281,x:28.95,y:74.45},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:25.9,y:75.7},0).wait(1).to({scaleX:0.6139,scaleY:0.6139,x:23.7,y:76.65},0).wait(1).to({scaleX:0.6097,scaleY:0.6097,x:22.15,y:77.25},0).wait(1).to({scaleX:0.6073,scaleY:0.6073,x:21.3,y:77.65},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.6066,scaleY:0.6066,x:21.2,y:77.75},0).wait(1).to({regX:28,regY:22.8,x:20.95,y:77.7},0).wait(8).to({regX:28.4,regY:22.9,x:21.2,y:77.75},0).wait(1).to({regX:28,regY:22.8,scaleX:0.6064,scaleY:0.6064,x:20.95,y:77.65},0).wait(1).to({scaleX:0.6062,scaleY:0.6062,x:20.9,y:77.6},0).wait(1).to({scaleX:0.6058,scaleY:0.6058,x:20.95,y:77.55},0).wait(1).to({scaleX:0.6053,scaleY:0.6053,y:77.5},0).wait(1).to({scaleX:0.6046,scaleY:0.6046,x:21,y:77.45},0).wait(1).to({scaleX:0.6037,scaleY:0.6037,y:77.3},0).wait(1).to({scaleX:0.6026,scaleY:0.6026,x:21.05,y:77.25},0).wait(1).to({scaleX:0.6013,scaleY:0.6013,x:21.1,y:77.05},0).wait(1).to({scaleX:0.5998,scaleY:0.5998,x:21.15,y:76.85},0).wait(1).to({scaleX:0.5979,scaleY:0.5979,x:21.25,y:76.7},0).wait(1).to({scaleX:0.5957,scaleY:0.5957,x:21.35,y:76.45},0).wait(1).to({scaleX:0.5931,scaleY:0.5931,x:21.4,y:76.15},0).wait(1).to({scaleX:0.5901,scaleY:0.5901,x:21.5,y:75.8},0).wait(1).to({scaleX:0.5864,scaleY:0.5864,x:21.65,y:75.4},0).wait(1).to({scaleX:0.5821,scaleY:0.5821,x:21.85,y:74.9},0).wait(1).to({scaleX:0.5768,scaleY:0.5768,x:22,y:74.35},0).wait(1).to({scaleX:0.5703,scaleY:0.5703,x:22.25,y:73.65},0).wait(1).to({scaleX:0.5622,scaleY:0.5622,x:22.6,y:72.7},0).wait(1).to({scaleX:0.5516,scaleY:0.5516,x:22.95,y:71.6},0).wait(1).to({scaleX:0.5376,scaleY:0.5376,x:23.5,y:70},0).wait(1).to({scaleX:0.5192,scaleY:0.5192,x:24.2,y:68},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:24.95,y:65.6},0).wait(1).to({scaleX:0.479,scaleY:0.479,x:25.65,y:63.5},0).wait(1).to({scaleX:0.4645,scaleY:0.4645,x:26.2,y:61.9},0).wait(1).to({scaleX:0.4535,scaleY:0.4535,x:26.6,y:60.7},0).wait(1).to({scaleX:0.445,scaleY:0.445,x:26.95,y:59.75},0).wait(1).to({scaleX:0.4381,scaleY:0.4381,x:27.2,y:59},0).wait(1).to({scaleX:0.4325,scaleY:0.4325,x:27.4,y:58.35},0).wait(1).to({scaleX:0.4278,scaleY:0.4278,x:27.6,y:57.85},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:27.7,y:57.4},0).wait(1).to({scaleX:0.4204,scaleY:0.4204,x:27.85,y:57.05},0).wait(1).to({scaleX:0.4175,scaleY:0.4175,x:28,y:56.7},0).wait(1).to({scaleX:0.4151,scaleY:0.4151,x:28.05,y:56.4},0).wait(1).to({scaleX:0.4129,scaleY:0.4129,x:28.15,y:56.15},0).wait(1).to({scaleX:0.4111,scaleY:0.4111,x:28.2,y:55.95},0).wait(1).to({scaleX:0.4096,scaleY:0.4096,x:28.25,y:55.8},0).wait(1).to({scaleX:0.4082,scaleY:0.4082,x:28.35,y:55.65},0).wait(1).to({scaleX:0.4071,scaleY:0.4071,y:55.55},0).wait(1).to({scaleX:0.4062,scaleY:0.4062,y:55.4},0).wait(1).to({scaleX:0.4054,scaleY:0.4054,x:28.4,y:55.35},0).wait(1).to({scaleX:0.4048,scaleY:0.4048,x:28.45,y:55.3},0).wait(1).to({scaleX:0.4043,scaleY:0.4043,y:55.2},0).wait(1).to({scaleX:0.4039,scaleY:0.4039,y:55.15},0).wait(1).to({scaleX:0.4036,scaleY:0.4036,x:28.5},0).wait(1).to({scaleX:0.4035,scaleY:0.4035},0).wait(1).to({regX:28.4,regY:23.1,x:28.65,y:55.2},0).wait(1));

	// l guy i shadow
	this.instance_12 = new lib.roundshadow();
	this.instance_12.setTransform(-116,82.3,1,1,0,0,0,28.2,22.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({x:41.05,y:37.85,alpha:0.1602},33,cjs.Ease.quadOut).wait(1).to({regX:28,x:40.85},0).wait(22).to({regX:28.2,x:41.05},0).wait(1).to({regX:28,scaleX:0.9953,scaleY:0.9953,x:40.45,y:38.35},0).wait(1).to({scaleX:0.989,scaleY:0.989,x:40.05,y:39.05},0).wait(1).to({scaleX:0.9807,scaleY:0.9807,x:39.4,y:39.9},0).wait(1).to({scaleX:0.9706,scaleY:0.9706,x:38.7,y:41.05},0).wait(1).to({scaleX:0.9583,scaleY:0.9583,x:37.8,y:42.4},0).wait(1).to({scaleX:0.9439,scaleY:0.9439,x:36.75,y:43.95},0).wait(1).to({scaleX:0.9272,scaleY:0.9272,x:35.5,y:45.8},0).wait(1).to({scaleX:0.908,scaleY:0.908,x:34.1,y:47.9},0).wait(1).to({scaleX:0.8865,scaleY:0.8865,x:32.55,y:50.25},0).wait(1).to({scaleX:0.8626,scaleY:0.8626,x:30.85,y:52.85},0).wait(1).to({scaleX:0.8364,scaleY:0.8364,x:28.9,y:55.7},0).wait(1).to({scaleX:0.8082,scaleY:0.8082,x:26.9,y:58.85},0).wait(1).to({scaleX:0.7782,scaleY:0.7782,x:24.7,y:62.1},0).wait(1).to({scaleX:0.747,scaleY:0.747,x:22.4,y:65.55},0).wait(1).to({scaleX:0.7151,scaleY:0.7151,x:20.1,y:69},0).wait(1).to({scaleX:0.6833,scaleY:0.6833,x:17.85,y:72.5},0).wait(1).to({scaleX:0.6521,scaleY:0.6521,x:15.55,y:75.9},0).wait(1).to({scaleX:0.6222,scaleY:0.6222,x:13.35,y:79.2},0).wait(1).to({scaleX:0.5943,scaleY:0.5943,x:11.35,y:82.25},0).wait(1).to({scaleX:0.5687,scaleY:0.5687,x:9.5,y:85},0).wait(1).to({scaleX:0.5457,scaleY:0.5457,x:7.85,y:87.55},0).wait(1).to({scaleX:0.5254,scaleY:0.5254,x:6.35,y:89.8},0).wait(1).to({scaleX:0.5079,scaleY:0.5079,x:5.05,y:91.7},0).wait(1).to({scaleX:0.4932,scaleY:0.4932,x:4,y:93.3},0).wait(1).to({scaleX:0.4811,scaleY:0.4811,x:3.1,y:94.6},0).wait(1).to({scaleX:0.4715,scaleY:0.4715,x:2.45,y:95.65},0).wait(1).to({scaleX:0.4644,scaleY:0.4644,x:1.9,y:96.45},0).wait(1).to({scaleX:0.4594,scaleY:0.4594,x:1.55,y:96.95},0).wait(1).to({scaleX:0.4566,scaleY:0.4566,x:1.35,y:97.3},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.4557,scaleY:0.4557,y:97.4},0).wait(1).to({regX:28,regY:22.8,x:1.2,y:97.35},0).wait(6).to({regX:28.3,regY:22.9,x:1.35,y:97.4},0).wait(1).to({regX:28,regY:22.8,x:1.2,y:97.35},0).wait(1).to({regX:28.3,regY:22.9,x:1.35,y:97.4},0).wait(1).to({regX:28,regY:22.8,scaleX:0.4556,scaleY:0.4556,x:1.2,y:97.3},0).wait(1).to({x:1.15,y:97.25},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:1.05,y:97.2},0).wait(1).to({scaleX:0.4554,scaleY:0.4554,x:0.9,y:97.1},0).wait(1).to({scaleX:0.4552,scaleY:0.4552,x:0.7,y:97},0).wait(1).to({scaleX:0.4551,scaleY:0.4551,x:0.5,y:96.85},0).wait(1).to({scaleX:0.4548,scaleY:0.4548,x:0.2,y:96.65},0).wait(1).to({scaleX:0.4545,scaleY:0.4545,x:-0.15,y:96.4},0).wait(1).to({scaleX:0.4542,scaleY:0.4542,x:-0.6,y:96.15},0).wait(1).to({scaleX:0.4538,scaleY:0.4538,x:-1.15,y:95.85},0).wait(1).to({scaleX:0.4533,scaleY:0.4533,x:-1.8,y:95.45},0).wait(1).to({scaleX:0.4526,scaleY:0.4526,x:-2.6,y:94.9},0).wait(1).to({scaleX:0.4518,scaleY:0.4518,x:-3.6,y:94.3},0).wait(1).to({scaleX:0.4508,scaleY:0.4508,x:-4.85,y:93.55},0).wait(1).to({scaleX:0.4496,scaleY:0.4496,x:-6.4,y:92.5},0).wait(1).to({scaleX:0.4478,scaleY:0.4478,x:-8.6,y:91.15},0).wait(1).to({scaleX:0.4455,scaleY:0.4455,x:-11.65,y:89.3},0).wait(1).to({scaleX:0.4422,scaleY:0.4422,x:-15.7,y:86.7},0).wait(1).to({scaleX:0.4386,scaleY:0.4386,x:-20.15,y:83.9},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:-23.7,y:81.7},0).wait(1).to({scaleX:0.4338,scaleY:0.4338,x:-26.25,y:80.15},0).wait(1).to({scaleX:0.4323,scaleY:0.4323,x:-28.15,y:78.95},0).wait(1).to({scaleX:0.4312,scaleY:0.4312,x:-29.6,y:78.05},0).wait(1).to({scaleX:0.4303,scaleY:0.4303,x:-30.75,y:77.3},0).wait(1).to({scaleX:0.4295,scaleY:0.4295,x:-31.65,y:76.75},0).wait(1).to({scaleX:0.4289,scaleY:0.4289,x:-32.45,y:76.3},0).wait(1).to({scaleX:0.4284,scaleY:0.4284,x:-33.1,y:75.85},0).wait(1).to({scaleX:0.428,scaleY:0.428,x:-33.6,y:75.5},0).wait(1).to({scaleX:0.4276,scaleY:0.4276,x:-34.1,y:75.25},0).wait(1).to({scaleX:0.4273,scaleY:0.4273,x:-34.45,y:75},0).wait(1).to({scaleX:0.4271,scaleY:0.4271,x:-34.75,y:74.85},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:-35,y:74.7},0).wait(1).to({scaleX:0.4267,scaleY:0.4267,x:-35.2,y:74.55},0).wait(1).to({scaleX:0.4266,scaleY:0.4266,x:-35.35,y:74.45},0).wait(1).to({scaleX:0.4265,scaleY:0.4265,x:-35.5,y:74.3},0).wait(1).to({scaleX:0.4264,scaleY:0.4264,x:-35.6,y:74.25},0).wait(1).to({x:-35.65},0).wait(1).to({scaleX:0.4263,scaleY:0.4263,x:-35.7,y:74.2},0).wait(1).to({regX:28.5,regY:23,x:-35.6,y:74.3},0).wait(6));

	// r girl i shadow
	this.instance_13 = new lib.roundshadow();
	this.instance_13.setTransform(198.25,263.3,1,1,0,0,0,28.2,22.8);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(25).to({_off:false},0).to({x:130.85,y:192.2,alpha:0.1602},39,cjs.Ease.quadOut).wait(1).to({regX:28,x:131.05,y:191.7},0).wait(1).to({x:131.45,y:191.2},0).wait(1).to({x:131.85,y:190.65},0).wait(1).to({x:132.25,y:190.15},0).wait(1).to({x:132.7,y:189.65},0).wait(1).to({x:133.1,y:189.15},0).wait(1).to({x:133.5,y:188.65},0).wait(1).to({x:133.9,y:188.15},0).wait(1).to({x:134.35,y:187.65},0).wait(1).to({x:134.75,y:187.1},0).wait(1).to({x:135.2,y:186.6},0).wait(1).to({x:135.6,y:186.1},0).wait(1).to({x:136,y:185.6},0).wait(1).to({x:136.45,y:185.05},0).wait(1).to({x:136.85,y:184.55},0).wait(1).to({x:137.3,y:184},0).wait(1).to({x:137.7,y:183.5},0).wait(1).to({x:138.15,y:183},0).wait(1).to({x:138.6,y:182.45},0).wait(1).to({x:139,y:181.95},0).wait(1).to({x:139.45,y:181.4},0).wait(1).to({x:139.85,y:180.85},0).wait(1).to({x:140.3,y:180.35},0).wait(1).to({x:140.75,y:179.8},0).wait(1).to({regX:28.2,x:141.4,y:179.3},0).wait(1).to({regX:28,scaleX:0.9965,scaleY:0.9965,x:140,y:179},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:138.4,y:178.6},0).wait(1).to({scaleX:0.9852,scaleY:0.9852,x:136.35,y:178.1},0).wait(1).to({scaleX:0.9774,scaleY:0.9774,x:133.75,y:177.55},0).wait(1).to({scaleX:0.968,scaleY:0.968,x:130.65,y:176.8},0).wait(1).to({scaleX:0.9569,scaleY:0.9569,x:127.05,y:175.95},0).wait(1).to({scaleX:0.9441,scaleY:0.9441,x:122.85,y:175},0).wait(1).to({scaleX:0.9296,scaleY:0.9296,x:118.1,y:173.85},0).wait(1).to({scaleX:0.9133,scaleY:0.9133,x:112.7,y:172.55},0).wait(1).to({scaleX:0.8953,scaleY:0.8953,x:106.8,y:171.2},0).wait(1).to({scaleX:0.8757,scaleY:0.8757,x:100.4,y:169.65},0).wait(1).to({scaleX:0.8547,scaleY:0.8547,x:93.55,y:168.05},0).wait(1).to({scaleX:0.8327,scaleY:0.8327,x:86.3,y:166.4},0).wait(1).to({scaleX:0.8099,scaleY:0.8099,x:78.85,y:164.6},0).wait(1).to({scaleX:0.7868,scaleY:0.7868,x:71.25,y:162.85},0).wait(1).to({scaleX:0.7638,scaleY:0.7638,x:63.75,y:161.05},0).wait(1).to({scaleX:0.7415,scaleY:0.7415,x:56.4,y:159.3},0).wait(1).to({scaleX:0.7202,scaleY:0.7202,x:49.4,y:157.65},0).wait(1).to({scaleX:0.7003,scaleY:0.7003,x:42.85,y:156.1},0).wait(1).to({scaleX:0.682,scaleY:0.682,x:36.9,y:154.75},0).wait(1).to({scaleX:0.6656,scaleY:0.6656,x:31.5,y:153.45},0).wait(1).to({scaleX:0.6511,scaleY:0.6511,x:26.75,y:152.35},0).wait(1).to({scaleX:0.6385,scaleY:0.6385,x:22.65,y:151.35},0).wait(1).to({scaleX:0.6279,scaleY:0.6279,x:19.2,y:150.55},0).wait(1).to({scaleX:0.6192,scaleY:0.6192,x:16.35,y:149.85},0).wait(1).to({scaleX:0.6123,scaleY:0.6123,x:14.1,y:149.35},0).wait(1).to({scaleX:0.6071,scaleY:0.6071,x:12.4,y:148.95},0).wait(1).to({scaleX:0.6035,scaleY:0.6035,x:11.2,y:148.65},0).wait(1).to({scaleX:0.6014,scaleY:0.6014,x:10.55,y:148.5},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.6008,scaleY:0.6008,x:10.4,y:148.45},0).wait(1).to({regX:28,regY:22.8,x:10.2,y:148.4},0).wait(6).to({regX:28.3,regY:22.9,x:10.4,y:148.45},0).wait(1).to({regX:28,regY:22.8,x:10.2,y:148.4},0).wait(2).to({regX:28.3,regY:22.9,x:10.4,y:148.45},0).wait(1).to({regX:28,regY:22.8,scaleX:0.6006,scaleY:0.6006,x:10.2,y:148.3},0).wait(1).to({scaleX:0.6004,scaleY:0.6004,y:148.2},0).wait(1).to({scaleX:0.5999,scaleY:0.5999,x:10.15,y:148.05},0).wait(1).to({scaleX:0.5994,scaleY:0.5994,x:10.1,y:147.75},0).wait(1).to({scaleX:0.5986,scaleY:0.5986,x:9.95,y:147.45},0).wait(1).to({scaleX:0.5976,scaleY:0.5976,x:9.85,y:147.1},0).wait(1).to({scaleX:0.5965,scaleY:0.5965,x:9.7,y:146.55},0).wait(1).to({scaleX:0.595,scaleY:0.595,x:9.5,y:145.95},0).wait(1).to({scaleX:0.5933,scaleY:0.5933,x:9.3,y:145.25},0).wait(1).to({scaleX:0.5912,scaleY:0.5912,x:9.05,y:144.35},0).wait(1).to({scaleX:0.5887,scaleY:0.5887,x:8.75,y:143.25},0).wait(1).to({scaleX:0.5857,scaleY:0.5857,x:8.35,y:142},0).wait(1).to({scaleX:0.5821,scaleY:0.5821,x:7.9,y:140.5},0).wait(1).to({scaleX:0.5778,scaleY:0.5778,x:7.4,y:138.65},0).wait(1).to({scaleX:0.5724,scaleY:0.5724,x:6.7,y:136.4},0).wait(1).to({scaleX:0.5658,scaleY:0.5658,x:5.85,y:133.6},0).wait(1).to({scaleX:0.5572,scaleY:0.5572,x:4.75,y:130},0).wait(1).to({scaleX:0.5459,scaleY:0.5459,x:3.35,y:125.2},0).wait(1).to({scaleX:0.5305,scaleY:0.5305,x:1.4,y:118.75},0).wait(1).to({scaleX:0.5104,scaleY:0.5104,x:-1.1,y:110.25},0).wait(1).to({scaleX:0.4895,scaleY:0.4895,x:-3.75,y:101.4},0).wait(1).to({scaleX:0.4727,scaleY:0.4727,x:-5.85,y:94.3},0).wait(1).to({scaleX:0.4602,scaleY:0.4602,x:-7.4,y:89.05},0).wait(1).to({scaleX:0.4507,scaleY:0.4507,x:-8.65,y:85.05},0).wait(1).to({scaleX:0.4434,scaleY:0.4434,x:-9.55,y:81.9},0).wait(1).to({scaleX:0.4374,scaleY:0.4374,x:-10.3,y:79.4},0).wait(1).to({scaleX:0.4325,scaleY:0.4325,x:-10.9,y:77.35},0).wait(1).to({scaleX:0.4285,scaleY:0.4285,x:-11.4,y:75.65},0).wait(1).to({scaleX:0.4251,scaleY:0.4251,x:-11.85,y:74.2},0).wait(1).to({scaleX:0.4222,scaleY:0.4222,x:-12.25,y:73},0).wait(1).to({scaleX:0.4198,scaleY:0.4198,x:-12.5,y:71.95},0).wait(1).to({scaleX:0.4177,scaleY:0.4177,x:-12.75,y:71.05},0).wait(1).to({scaleX:0.4159,scaleY:0.4159,x:-13,y:70.35},0).wait(1).to({scaleX:0.4144,scaleY:0.4144,x:-13.2,y:69.7},0).wait(1).to({scaleX:0.4132,scaleY:0.4132,x:-13.35,y:69.15},0).wait(1).to({scaleX:0.4121,scaleY:0.4121,x:-13.45,y:68.75},0).wait(1).to({scaleX:0.4113,scaleY:0.4113,x:-13.6,y:68.4},0).wait(1).to({scaleX:0.4106,scaleY:0.4106,x:-13.65,y:68.05},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:-13.7,y:67.85},0).wait(1).to({scaleX:0.4096,scaleY:0.4096,x:-13.8,y:67.7},0).wait(1).to({scaleX:0.4094,scaleY:0.4094,x:-13.85,y:67.6},0).wait(1).to({scaleX:0.4092,scaleY:0.4092,y:67.5},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.4091,scaleY:0.4091,x:-13.75,y:67.55},0).wait(1));

	// l girl i shadow
	this.instance_14 = new lib.roundshadow();
	this.instance_14.setTransform(-129.35,179.15,1,1,0,0,0,28.2,22.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(22).to({_off:false},0).to({x:26.85,y:132.55,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:28,x:26.65},0).wait(25).to({regX:28.2,x:26.85},0).wait(1).to({regX:28,scaleX:0.9954,scaleY:0.9954,x:26.45,y:132.4},0).wait(1).to({scaleX:0.9891,scaleY:0.9891,x:26.2,y:132.25},0).wait(1).to({scaleX:0.9811,scaleY:0.9811,x:25.8,y:132},0).wait(1).to({scaleX:0.9712,scaleY:0.9712,x:25.4,y:131.8},0).wait(1).to({scaleX:0.9594,scaleY:0.9594,x:24.85,y:131.45},0).wait(1).to({scaleX:0.9456,scaleY:0.9456,x:24.3,y:131.15},0).wait(1).to({scaleX:0.9297,scaleY:0.9297,x:23.6,y:130.75},0).wait(1).to({scaleX:0.9117,scaleY:0.9117,x:22.8,y:130.3},0).wait(1).to({scaleX:0.8916,scaleY:0.8916,x:21.85,y:129.8},0).wait(1).to({scaleX:0.8695,scaleY:0.8695,x:20.9,y:129.2},0).wait(1).to({scaleX:0.8455,scaleY:0.8455,x:19.8,y:128.6},0).wait(1).to({scaleX:0.8197,scaleY:0.8197,x:18.7,y:127.95},0).wait(1).to({scaleX:0.7924,scaleY:0.7924,x:17.5,y:127.2},0).wait(1).to({scaleX:0.764,scaleY:0.764,x:16.25,y:126.5},0).wait(1).to({scaleX:0.735,scaleY:0.735,x:15,y:125.75},0).wait(1).to({scaleX:0.7057,scaleY:0.7057,x:13.65,y:125.05},0).wait(1).to({scaleX:0.6767,scaleY:0.6767,x:12.4,y:124.3},0).wait(1).to({scaleX:0.6484,scaleY:0.6484,x:11.15,y:123.6},0).wait(1).to({scaleX:0.6214,scaleY:0.6214,x:9.95,y:122.85},0).wait(1).to({scaleX:0.5959,scaleY:0.5959,x:8.85,y:122.25},0).wait(1).to({scaleX:0.5724,scaleY:0.5724,x:7.8,y:121.65},0).wait(1).to({scaleX:0.551,scaleY:0.551,x:6.85,y:121.05},0).wait(1).to({scaleX:0.5317,scaleY:0.5317,x:6,y:120.55},0).wait(1).to({scaleX:0.5148,scaleY:0.5148,x:5.2,y:120.15},0).wait(1).to({scaleX:0.5001,scaleY:0.5001,x:4.6,y:119.8},0).wait(1).to({scaleX:0.4877,scaleY:0.4877,x:4.05,y:119.45},0).wait(1).to({scaleX:0.4775,scaleY:0.4775,x:3.55,y:119.2},0).wait(1).to({scaleX:0.4693,scaleY:0.4693,x:3.25,y:119},0).wait(1).to({scaleX:0.4632,scaleY:0.4632,x:2.95,y:118.85},0).wait(1).to({scaleX:0.4589,scaleY:0.4589,x:2.75,y:118.7},0).wait(1).to({scaleX:0.4565,scaleY:0.4565,x:2.7,y:118.65},0).wait(1).to({regX:28.4,regY:23.1,scaleX:0.4557,scaleY:0.4557,y:118.7},0).wait(1).to({regX:28,regY:22.8,x:2.5,y:118.55},0).wait(4).to({regX:28.4,regY:23.1,x:2.7,y:118.7},0).wait(1).to({regX:28,regY:22.8,x:2.5,y:118.55},0).wait(4).to({regX:28.4,regY:23.1,x:2.7,y:118.7},0).wait(1).to({regX:28,regY:22.8,scaleX:0.4556,scaleY:0.4556,x:2.55,y:118.5},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,y:118.4},0).wait(1).to({scaleX:0.4554,scaleY:0.4554,y:118.25},0).wait(1).to({scaleX:0.4552,scaleY:0.4552,y:118.05},0).wait(1).to({scaleX:0.455,scaleY:0.455,x:2.6,y:117.75},0).wait(1).to({scaleX:0.4547,scaleY:0.4547,x:2.65,y:117.45},0).wait(1).to({scaleX:0.4544,scaleY:0.4544,y:117.05},0).wait(1).to({scaleX:0.4539,scaleY:0.4539,x:2.7,y:116.6},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:2.75,y:116},0).wait(1).to({scaleX:0.4528,scaleY:0.4528,x:2.8,y:115.25},0).wait(1).to({scaleX:0.452,scaleY:0.452,x:2.85,y:114.4},0).wait(1).to({scaleX:0.451,scaleY:0.451,x:2.95,y:113.4},0).wait(1).to({scaleX:0.4499,scaleY:0.4499,x:3.05,y:112.1},0).wait(1).to({scaleX:0.4485,scaleY:0.4485,x:3.15,y:110.6},0).wait(1).to({scaleX:0.4467,scaleY:0.4467,x:3.35,y:108.6},0).wait(1).to({scaleX:0.4445,scaleY:0.4445,x:3.55,y:106.1},0).wait(1).to({scaleX:0.4414,scaleY:0.4414,x:3.8,y:102.7},0).wait(1).to({scaleX:0.4373,scaleY:0.4373,x:4.2,y:98.05},0).wait(1).to({scaleX:0.4317,scaleY:0.4317,x:4.7,y:91.9},0).wait(1).to({scaleX:0.4257,scaleY:0.4257,x:5.2,y:85.25},0).wait(1).to({scaleX:0.421,scaleY:0.421,x:5.65,y:80},0).wait(1).to({scaleX:0.4175,scaleY:0.4175,x:5.95,y:76.1},0).wait(1).to({scaleX:0.4149,scaleY:0.4149,x:6.15,y:73.2},0).wait(1).to({scaleX:0.4129,scaleY:0.4129,x:6.35,y:71},0).wait(1).to({scaleX:0.4113,scaleY:0.4113,x:6.5,y:69.2},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:6.65,y:67.75},0).wait(1).to({scaleX:0.4089,scaleY:0.4089,x:6.75,y:66.5},0).wait(1).to({scaleX:0.408,scaleY:0.408,x:6.8,y:65.5},0).wait(1).to({scaleX:0.4072,scaleY:0.4072,x:6.85,y:64.7},0).wait(1).to({scaleX:0.4066,scaleY:0.4066,x:6.95,y:63.95},0).wait(1).to({scaleX:0.406,scaleY:0.406,y:63.35},0).wait(1).to({scaleX:0.4056,scaleY:0.4056,x:7,y:62.85},0).wait(1).to({scaleX:0.4052,scaleY:0.4052,x:7.05,y:62.45},0).wait(1).to({scaleX:0.4049,scaleY:0.4049,x:7.1,y:62.1},0).wait(1).to({scaleX:0.4046,scaleY:0.4046,x:7.15,y:61.75},0).wait(1).to({scaleX:0.4044,scaleY:0.4044,x:7.1,y:61.55},0).wait(1).to({scaleX:0.4042,scaleY:0.4042,y:61.35},0).wait(1).to({scaleX:0.4041,scaleY:0.4041,x:7.15,y:61.2},0).wait(1).to({scaleX:0.404,scaleY:0.404,y:61.15},0).wait(1).to({y:61.1},0).wait(1).to({regX:28.4,regY:23.2,x:7.3,y:61.2},0).wait(1));

	// l girl box shadow
	this.instance_15 = new lib.squareshadow();
	this.instance_15.setTransform(-77.95,180.65,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(22).to({_off:false},0).to({x:82.6,y:140.55,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:82.45},0).wait(25).to({regX:70.8,x:82.6},0).wait(1).to({regX:70.6,scaleX:0.6765,scaleY:0.6765,x:81.95,y:140.4,alpha:0.1588},0).wait(1).to({scaleX:0.6716,scaleY:0.6716,x:81.3,y:140.2,alpha:0.1571},0).wait(1).to({scaleX:0.6655,scaleY:0.6655,x:80.5,y:139.95,alpha:0.1548},0).wait(1).to({scaleX:0.6579,scaleY:0.6579,x:79.45,y:139.65,alpha:0.152},0).wait(1).to({scaleX:0.6488,scaleY:0.6488,x:78.25,y:139.3,alpha:0.1486},0).wait(1).to({scaleX:0.6382,scaleY:0.6382,x:76.85,y:138.85,alpha:0.1447},0).wait(1).to({scaleX:0.6259,scaleY:0.6259,x:75.2,y:138.35,alpha:0.1402},0).wait(1).to({scaleX:0.612,scaleY:0.612,x:73.3,y:137.85,alpha:0.135},0).wait(1).to({scaleX:0.5964,scaleY:0.5964,x:71.25,y:137.2,alpha:0.1292},0).wait(1).to({scaleX:0.5791,scaleY:0.5791,x:68.95,y:136.55,alpha:0.1229},0).wait(1).to({scaleX:0.5603,scaleY:0.5603,x:66.4,y:135.8,alpha:0.1159},0).wait(1).to({scaleX:0.54,scaleY:0.54,x:63.65,y:134.95,alpha:0.1084},0).wait(1).to({scaleX:0.5184,scaleY:0.5184,x:60.8,y:134.15,alpha:0.1004},0).wait(1).to({scaleX:0.4958,scaleY:0.4958,x:57.8,y:133.2,alpha:0.0921},0).wait(1).to({scaleX:0.4725,scaleY:0.4725,x:54.65,y:132.3,alpha:0.0835},0).wait(1).to({scaleX:0.449,scaleY:0.449,x:51.5,y:131.35,alpha:0.0748},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,x:48.4,y:130.45,alpha:0.0661},0).wait(1).to({scaleX:0.4027,scaleY:0.4027,x:45.35,y:129.5,alpha:0.0577},0).wait(1).to({scaleX:0.3808,scaleY:0.3808,x:42.4,y:128.65,alpha:0.0496},0).wait(1).to({scaleX:0.3601,scaleY:0.3601,x:39.6,y:127.8,alpha:0.0419},0).wait(1).to({scaleX:0.341,scaleY:0.341,x:37.05,y:127.05,alpha:0.0349},0).wait(1).to({scaleX:0.3235,scaleY:0.3235,x:34.75,y:126.35,alpha:0.0284},0).wait(1).to({scaleX:0.3079,scaleY:0.3079,x:32.65,y:125.75,alpha:0.0227},0).wait(1).to({scaleX:0.2942,scaleY:0.2942,x:30.8,y:125.2,alpha:0.0176},0).wait(1).to({scaleX:0.2823,scaleY:0.2823,x:29.25,y:124.75,alpha:0.0132},0).wait(1).to({scaleX:0.2723,scaleY:0.2723,x:27.9,y:124.35,alpha:0.0095},0).wait(1).to({scaleX:0.2641,scaleY:0.2641,x:26.8,y:124,alpha:0.0065},0).wait(1).to({scaleX:0.2576,scaleY:0.2576,x:25.9,y:123.75,alpha:0.004},0).wait(1).to({scaleX:0.2526,scaleY:0.2526,x:25.25,y:123.6,alpha:0.0022},0).wait(1).to({scaleX:0.2492,scaleY:0.2492,x:24.8,y:123.4,alpha:0.001},0).wait(1).to({scaleX:0.2472,scaleY:0.2472,x:24.5,y:123.35,alpha:0.0002},0).wait(1).to({regX:71.4,regY:48.3,scaleX:0.2466,scaleY:0.2466,alpha:0},0).wait(52));

	// r girl box shadow
	this.instance_16 = new lib.fill();
	this.instance_16.setTransform(52.2,118.8,1,1,0,0,0,32.5,30.1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(109).to({_off:false},0).to({regX:32.6,regY:30.2,scaleX:0.729,scaleY:0.729,x:24.8,y:123.35,alpha:1},9).wait(55));

	// r guy box shadow
	this.instance_17 = new lib.squareshadow();
	this.instance_17.setTransform(226.05,-55.6,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	var maskedShapeInstanceList = [this.instance_17];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(29).to({_off:false},0).to({x:210.2,y:22.9,alpha:0.1602},37,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:210.1},0).wait(22).to({regX:70.7,x:210.2},0).wait(1).to({regX:70.6,scaleX:0.5412,scaleY:0.5407,x:206.45,y:24.15},0).wait(1).to({scaleX:0.536,scaleY:0.5349,x:202.15,y:25.55},0).wait(1).to({scaleX:0.5299,scaleY:0.5282,x:197.1,y:27.25},0).wait(1).to({scaleX:0.5231,scaleY:0.5206,x:191.5,y:29.15},0).wait(1).to({scaleX:0.5154,scaleY:0.5121,x:185.2,y:31.3},0).wait(1).to({scaleX:0.507,scaleY:0.5028,x:178.3,y:33.6},0).wait(1).to({scaleX:0.498,scaleY:0.4927,x:170.8,y:36.15},0).wait(1).to({scaleX:0.4882,scaleY:0.4819,x:162.75,y:38.85},0).wait(1).to({scaleX:0.478,scaleY:0.4705,x:154.35,y:41.7},0).wait(1).to({scaleX:0.4674,scaleY:0.4587,x:145.6,y:44.65},0).wait(1).to({scaleX:0.4565,scaleY:0.4466,x:136.65,y:47.7},0).wait(1).to({scaleX:0.4455,scaleY:0.4344,x:127.55,y:50.75},0).wait(1).to({scaleX:0.4345,scaleY:0.4222,x:118.55,y:53.8},0).wait(1).to({scaleX:0.4238,scaleY:0.4103,x:109.65,y:56.8},0).wait(1).to({scaleX:0.4134,scaleY:0.3988,x:101.1,y:59.65},0).wait(1).to({scaleX:0.4035,scaleY:0.3877,x:92.95,y:62.45},0).wait(1).to({scaleX:0.3941,scaleY:0.3774,x:85.25,y:65.05},0).wait(1).to({scaleX:0.3855,scaleY:0.3678,x:78.1,y:67.45},0).wait(1).to({scaleX:0.3776,scaleY:0.359,x:71.55,y:69.65},0).wait(1).to({scaleX:0.3704,scaleY:0.3511,x:65.7,y:71.65},0).wait(1).to({scaleX:0.3641,scaleY:0.344,x:60.45,y:73.4},0).wait(1).to({scaleX:0.3586,scaleY:0.3379,x:55.9,y:74.95},0).wait(1).to({scaleX:0.3539,scaleY:0.3327,x:52.1,y:76.25},0).wait(1).to({scaleX:0.35,scaleY:0.3284,x:48.85,y:77.35},0).wait(1).to({scaleX:0.3469,scaleY:0.3249,x:46.25,y:78.25},0).wait(1).to({scaleX:0.3445,scaleY:0.3222,x:44.25,y:78.85},0).wait(1).to({scaleX:0.3428,scaleY:0.3204,x:42.9,y:79.3},0).wait(1).to({scaleX:0.3418,scaleY:0.3193,x:42.15,y:79.6},0).wait(1).to({regX:70.7,regY:48.1,scaleX:0.3415,scaleY:0.3189,x:41.9,y:79.7},0).wait(55));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(30.9,74.85,0.2637,0.2637,0,0,0,225.1,236.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(67).to({regX:232.4,regY:219.8,x:32.85,y:70.4},0).wait(22).to({regX:225.1,regY:236.7,x:30.9,y:74.85},0).wait(1).to({regX:232.4,regY:219.8,scaleX:0.2636,scaleY:0.2636,x:31.95,y:70.55},0).wait(1).to({scaleX:0.2635,scaleY:0.2635,x:30.55,y:70.75},0).wait(1).to({scaleX:0.2633,scaleY:0.2633,x:28.4,y:71.05},0).wait(1).to({scaleX:0.263,scaleY:0.263,x:25.6,y:71.5},0).wait(1).to({scaleX:0.2627,scaleY:0.2627,x:22.1,y:72.1},0).wait(1).to({scaleX:0.2623,scaleY:0.2623,x:17.8,y:72.75},0).wait(1).to({scaleX:0.2618,scaleY:0.2618,x:12.7,y:73.6},0).wait(1).to({scaleX:0.2613,scaleY:0.2613,x:6.75,y:74.55},0).wait(1).to({scaleX:0.2607,scaleY:0.2607,x:0.05,y:75.6},0).wait(1).to({scaleX:0.26,scaleY:0.26,x:-7.55,y:76.8},0).wait(1).to({scaleX:0.2592,scaleY:0.2592,x:-15.75,y:78.1},0).wait(1).to({scaleX:0.2584,scaleY:0.2584,x:-24.6,y:79.5},0).wait(1).to({scaleX:0.2575,scaleY:0.2575,x:-33.8,y:80.95},0).wait(1).to({scaleX:0.2566,scaleY:0.2566,x:-43.2,y:82.45},0).wait(1).to({scaleX:0.2558,scaleY:0.2558,x:-52.55,y:83.95},0).wait(1).to({scaleX:0.2549,scaleY:0.2549,x:-61.6,y:85.4},0).wait(1).to({scaleX:0.2541,scaleY:0.2541,x:-70.25,y:86.75},0).wait(1).to({scaleX:0.2534,scaleY:0.2534,x:-78.2,y:88.05},0).wait(1).to({scaleX:0.2527,scaleY:0.2527,x:-85.55,y:89.2},0).wait(1).to({scaleX:0.2521,scaleY:0.2521,x:-92.1,y:90.2},0).wait(1).to({scaleX:0.2516,scaleY:0.2516,x:-97.9,y:91.15},0).wait(1).to({scaleX:0.2511,scaleY:0.2511,x:-102.95,y:91.95},0).wait(1).to({scaleX:0.2507,scaleY:0.2507,x:-107.25,y:92.65},0).wait(1).to({scaleX:0.2504,scaleY:0.2504,x:-110.8,y:93.25},0).wait(1).to({scaleX:0.2501,scaleY:0.2501,x:-113.75,y:93.65},0).wait(1).to({scaleX:0.2499,scaleY:0.2499,x:-116.1,y:94},0).wait(1).to({scaleX:0.2497,scaleY:0.2497,x:-117.8,y:94.35},0).wait(1).to({scaleX:0.2496,scaleY:0.2496,x:-119,y:94.5},0).wait(1).to({regX:224.7,regY:237.1,scaleX:0.2495,scaleY:0.2495,x:-121.6,y:98.85},0).wait(55));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(101.95,79.4,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(27).to({regY:15.2,scaleX:0.7599,scaleY:0.7599,x:84,y:86.75},21,cjs.Ease.quadInOut).wait(19).to({regX:38,regY:15.3,x:84.1,y:86.85},0).wait(22).to({regX:37.9,regY:15.2,x:84,y:86.75},0).wait(1).to({regX:38,regY:15.3,scaleX:0.7597,scaleY:0.7597,x:83.15,y:86.9},0).wait(1).to({scaleX:0.7593,scaleY:0.7593,x:81.65,y:87.15},0).wait(1).to({scaleX:0.7587,scaleY:0.7587,x:79.55,y:87.5},0).wait(1).to({scaleX:0.758,scaleY:0.758,x:76.7,y:87.9},0).wait(1).to({scaleX:0.757,scaleY:0.757,x:73.1,y:88.45},0).wait(1).to({scaleX:0.7559,scaleY:0.7559,x:68.7,y:89.1},0).wait(1).to({scaleX:0.7545,scaleY:0.7545,x:63.5,y:89.9},0).wait(1).to({scaleX:0.7529,scaleY:0.7529,x:57.5,y:90.8},0).wait(1).to({scaleX:0.7511,scaleY:0.7511,x:50.65,y:91.85},0).wait(1).to({scaleX:0.7491,scaleY:0.7491,x:42.95,y:93},0).wait(1).to({scaleX:0.7469,scaleY:0.7469,x:34.6,y:94.3},0).wait(1).to({scaleX:0.7446,scaleY:0.7446,x:25.65,y:95.6},0).wait(1).to({scaleX:0.7421,scaleY:0.7421,x:16.25,y:97},0).wait(1).to({scaleX:0.7396,scaleY:0.7396,x:6.7,y:98.45},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:-2.85,y:99.9},0).wait(1).to({scaleX:0.7347,scaleY:0.7347,x:-12.1,y:101.3},0).wait(1).to({scaleX:0.7324,scaleY:0.7324,x:-20.8,y:102.6},0).wait(1).to({scaleX:0.7302,scaleY:0.7302,x:-29,y:103.8},0).wait(1).to({scaleX:0.7283,scaleY:0.7283,x:-36.45,y:104.95},0).wait(1).to({scaleX:0.7265,scaleY:0.7265,x:-43.1,y:105.95},0).wait(1).to({scaleX:0.725,scaleY:0.725,x:-49,y:106.85},0).wait(1).to({scaleX:0.7236,scaleY:0.7236,x:-54.1,y:107.6},0).wait(1).to({scaleX:0.7225,scaleY:0.7225,x:-58.5,y:108.3},0).wait(1).to({scaleX:0.7215,scaleY:0.7215,x:-62.15,y:108.85},0).wait(1).to({scaleX:0.7208,scaleY:0.7208,x:-65.1,y:109.3},0).wait(1).to({scaleX:0.7201,scaleY:0.7201,x:-67.5,y:109.6},0).wait(1).to({scaleX:0.7197,scaleY:0.7197,x:-69.25,y:109.9},0).wait(1).to({scaleX:0.7194,scaleY:0.7194,x:-70.5,y:110.1},0).wait(1).to({scaleX:0.7192,scaleY:0.7192,x:-71.3,y:110.15},0).wait(55));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(96.85,82.55,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(27).to({regX:37.7,regY:15.7,scaleX:0.7718,scaleY:0.7718,x:84,y:86.75},21,cjs.Ease.quadInOut).to({regX:37.9,regY:15.8,scaleX:0.5627,scaleY:0.5627,x:-98.9,y:74.35,alpha:0},18,cjs.Ease.quadOut).wait(107));

	// first image
	this.instance_18 = new lib.firstimage_1();
	this.instance_18.setTransform(211.45,64.75,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(32).to({regX:42,regY:26.6,scaleX:0.576,scaleY:0.576,x:214.6,y:73.55},22,cjs.Ease.quadInOut).wait(13).to({regX:41,regY:25.6,x:214,y:73},0).wait(22).to({regX:42,regY:26.6,x:214.6,y:73.55},0).wait(1).to({regX:41,regY:25.6,scaleX:0.5758,scaleY:0.5758,x:213.05,y:73.15},0).wait(1).to({scaleX:0.5755,scaleY:0.5755,x:211.5,y:73.4},0).wait(1).to({scaleX:0.5751,scaleY:0.5751,x:209.3,y:73.75},0).wait(1).to({scaleX:0.5745,scaleY:0.5745,x:206.35,y:74.25},0).wait(1).to({scaleX:0.5738,scaleY:0.5738,x:202.65,y:74.85},0).wait(1).to({scaleX:0.5729,scaleY:0.5729,x:198.1,y:75.6},0).wait(1).to({scaleX:0.5719,scaleY:0.5719,x:192.7,y:76.5},0).wait(1).to({scaleX:0.5707,scaleY:0.5707,x:186.45,y:77.5},0).wait(1).to({scaleX:0.5693,scaleY:0.5693,x:179.3,y:78.7},0).wait(1).to({scaleX:0.5678,scaleY:0.5678,x:171.35,y:80.05},0).wait(1).to({scaleX:0.5661,scaleY:0.5661,x:162.65,y:81.5},0).wait(1).to({scaleX:0.5643,scaleY:0.5643,x:153.35,y:83},0).wait(1).to({scaleX:0.5625,scaleY:0.5625,x:143.6,y:84.65},0).wait(1).to({scaleX:0.5606,scaleY:0.5606,x:133.7,y:86.25},0).wait(1).to({scaleX:0.5587,scaleY:0.5587,x:123.8,y:87.9},0).wait(1).to({scaleX:0.5569,scaleY:0.5569,x:114.25,y:89.5},0).wait(1).to({scaleX:0.5551,scaleY:0.5551,x:105.1,y:91},0).wait(1).to({scaleX:0.5535,scaleY:0.5535,x:96.65,y:92.4},0).wait(1).to({scaleX:0.552,scaleY:0.552,x:88.95,y:93.7},0).wait(1).to({scaleX:0.5507,scaleY:0.5507,x:82.05,y:94.85},0).wait(1).to({scaleX:0.5495,scaleY:0.5495,x:75.9,y:95.8},0).wait(1).to({scaleX:0.5485,scaleY:0.5485,x:70.6,y:96.75},0).wait(1).to({scaleX:0.5476,scaleY:0.5476,x:66.05,y:97.45},0).wait(1).to({scaleX:0.5469,scaleY:0.5469,x:62.2,y:98.1},0).wait(1).to({scaleX:0.5463,scaleY:0.5463,x:59.15,y:98.65},0).wait(1).to({scaleX:0.5458,scaleY:0.5458,x:56.7,y:99},0).wait(1).to({scaleX:0.5455,scaleY:0.5455,x:54.85,y:99.3},0).wait(1).to({scaleX:0.5452,scaleY:0.5452,x:53.6,y:99.55},0).wait(1).to({regX:42.1,regY:26.7,scaleX:0.5451,scaleY:0.5451,x:53.4,y:100.2},0).wait(55));

	// square shadow
	this.instance_19 = new lib.squareshadow();
	this.instance_19.setTransform(209.9,68.35,0.4651,0.4621,0,0,0,71,48);
	this.instance_19.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(32).to({regX:71.3,regY:48.3,scaleX:0.325,scaleY:0.3131,x:214.4,y:73.65},22,cjs.Ease.quadInOut).to({_off:true},1).wait(118));

	// second image
	this.instance_20 = new lib.secondimage();
	this.instance_20.setTransform(225.95,91.45,0.7473,0.7473,0,0,0,41.9,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(35).to({regX:42,regY:26.4,scaleX:0.5752,scaleY:0.5752,y:94.6},22,cjs.Ease.quadInOut).wait(10).to({regX:42.1,regY:26.8,x:226,y:94.8},0).wait(22).to({regX:42,regY:26.4,x:225.95,y:94.6},0).wait(1).to({regX:42.1,regY:26.8,scaleX:0.575,scaleY:0.575,x:225.05,y:94.95},0).wait(1).to({scaleX:0.5747,scaleY:0.5747,x:223.5,y:95.2},0).wait(1).to({scaleX:0.5743,scaleY:0.5743,x:221.3,y:95.55},0).wait(1).to({scaleX:0.5737,scaleY:0.5737,x:218.3,y:96.05},0).wait(1).to({scaleX:0.573,scaleY:0.573,x:214.55,y:96.6},0).wait(1).to({scaleX:0.5721,scaleY:0.5721,x:210.05,y:97.3},0).wait(1).to({scaleX:0.5711,scaleY:0.5711,x:204.65,y:98.15},0).wait(1).to({scaleX:0.5699,scaleY:0.5699,x:198.35,y:99.15},0).wait(1).to({scaleX:0.5685,scaleY:0.5685,x:191.2,y:100.3},0).wait(1).to({scaleX:0.567,scaleY:0.567,x:183.15,y:101.55},0).wait(1).to({scaleX:0.5653,scaleY:0.5653,x:174.4,y:102.9},0).wait(1).to({scaleX:0.5636,scaleY:0.5636,x:165.1,y:104.4},0).wait(1).to({scaleX:0.5617,scaleY:0.5617,x:155.3,y:105.95},0).wait(1).to({scaleX:0.5598,scaleY:0.5598,x:145.3,y:107.5},0).wait(1).to({scaleX:0.5579,scaleY:0.5579,x:135.4,y:109.05},0).wait(1).to({scaleX:0.5561,scaleY:0.5561,x:125.75,y:110.6},0).wait(1).to({scaleX:0.5543,scaleY:0.5543,x:116.65,y:112.05},0).wait(1).to({scaleX:0.5527,scaleY:0.5527,x:108.1,y:113.35},0).wait(1).to({scaleX:0.5512,scaleY:0.5512,x:100.35,y:114.6},0).wait(1).to({scaleX:0.5499,scaleY:0.5499,x:93.4,y:115.7},0).wait(1).to({scaleX:0.5487,scaleY:0.5487,x:87.3,y:116.65},0).wait(1).to({scaleX:0.5477,scaleY:0.5477,x:81.95,y:117.55},0).wait(1).to({scaleX:0.5469,scaleY:0.5469,x:77.35,y:118.2},0).wait(1).to({scaleX:0.5461,scaleY:0.5461,x:73.6,y:118.85},0).wait(1).to({scaleX:0.5455,scaleY:0.5455,x:70.45,y:119.3},0).wait(1).to({scaleX:0.5451,scaleY:0.5451,x:68,y:119.7},0).wait(1).to({scaleX:0.5447,scaleY:0.5447,x:66.2,y:120},0).wait(1).to({scaleX:0.5445,scaleY:0.5445,x:64.85,y:120.2},0).wait(1).to({regY:26.4,scaleX:0.5443,scaleY:0.5443,x:64.1,y:120.05},0).wait(55));

	// square shadow
	this.instance_21 = new lib.squareshadow();
	this.instance_21.setTransform(224.6,95.95,0.4651,0.4621,0,0,0,70.9,48.1);
	this.instance_21.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(35).to({regX:71.2,regY:48.4,scaleX:0.3475,scaleY:0.2831,x:226.05,y:95.2},22,cjs.Ease.quadInOut).to({_off:true},1).wait(115));

	// screen
	this.instance_22 = new lib.WordUI();
	this.instance_22.setTransform(155.1,94.8,0.8368,0.8368,0,0,0,151,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(67).to({regX:150.7,regY:96.1,x:154.85,y:94.95},0).wait(22).to({regX:151,regY:95.9,x:155.1,y:94.8},0).wait(1).to({regX:150.7,regY:96.1,scaleX:0.8366,scaleY:0.8366,x:153.9,y:95.1},0).wait(1).to({scaleX:0.8361,scaleY:0.8361,x:152.4,y:95.3},0).wait(1).to({scaleX:0.8355,scaleY:0.8355,x:150.2,y:95.6},0).wait(1).to({scaleX:0.8347,scaleY:0.8347,x:147.3,y:96},0).wait(1).to({scaleX:0.8337,scaleY:0.8337,x:143.65,y:96.55},0).wait(1).to({scaleX:0.8324,scaleY:0.8324,x:139.15,y:97.2},0).wait(1).to({scaleX:0.8309,scaleY:0.8309,x:133.8,y:98},0).wait(1).to({scaleX:0.8292,scaleY:0.8292,x:127.65,y:98.9},0).wait(1).to({scaleX:0.8272,scaleY:0.8272,x:120.65,y:99.9},0).wait(1).to({scaleX:0.825,scaleY:0.825,x:112.75,y:101.05},0).wait(1).to({scaleX:0.8225,scaleY:0.8225,x:104.15,y:102.25},0).wait(1).to({scaleX:0.8199,scaleY:0.8199,x:94.95,y:103.6},0).wait(1).to({scaleX:0.8172,scaleY:0.8172,x:85.35,y:105},0).wait(1).to({scaleX:0.8145,scaleY:0.8145,x:75.55,y:106.35},0).wait(1).to({scaleX:0.8117,scaleY:0.8117,x:65.85,y:107.8},0).wait(1).to({scaleX:0.8091,scaleY:0.8091,x:56.35,y:109.15},0).wait(1).to({scaleX:0.8065,scaleY:0.8065,x:47.35,y:110.45},0).wait(1).to({scaleX:0.8042,scaleY:0.8042,x:39,y:111.7},0).wait(1).to({scaleX:0.802,scaleY:0.802,x:31.35,y:112.75},0).wait(1).to({scaleX:0.8001,scaleY:0.8001,x:24.5,y:113.75},0).wait(1).to({scaleX:0.7984,scaleY:0.7984,x:18.5,y:114.6},0).wait(1).to({scaleX:0.7969,scaleY:0.7969,x:13.25,y:115.4},0).wait(1).to({scaleX:0.7956,scaleY:0.7956,x:8.75,y:116},0).wait(1).to({scaleX:0.7946,scaleY:0.7946,x:5.05,y:116.55},0).wait(1).to({scaleX:0.7937,scaleY:0.7937,x:1.95,y:117},0).wait(1).to({scaleX:0.793,scaleY:0.793,x:-0.45,y:117.35},0).wait(1).to({scaleX:0.7925,scaleY:0.7925,x:-2.25,y:117.6},0).wait(1).to({scaleX:0.7922,scaleY:0.7922,x:-3.5,y:117.8},0).wait(1).to({regX:151,regY:96,scaleX:0.792,scaleY:0.792,x:-4.05,y:117.75},0).wait(55));

	// screen shadow
	this.instance_23 = new lib.shadow_1();
	this.instance_23.setTransform(128.5,74.8,0.7,0.7,0,0,0,180.7,119.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(66).to({regX:180.6,regY:119.8,x:128.4,y:74.85},0).wait(1).to({regX:189.8,regY:149.6,x:134.85,y:95.7},0).wait(22).to({regX:180.6,regY:119.8,x:128.4,y:74.85},0).wait(1).to({regX:189.8,regY:149.6,scaleX:0.6997,scaleY:0.6997,x:133.9,y:95.9},0).wait(1).to({scaleX:0.6993,scaleY:0.6993,x:132.5,y:96.15},0).wait(1).to({scaleX:0.6987,scaleY:0.6987,x:130.3,y:96.55},0).wait(1).to({scaleX:0.6979,scaleY:0.6979,x:127.4,y:97},0).wait(1).to({scaleX:0.6969,scaleY:0.6969,x:123.8,y:97.6},0).wait(1).to({scaleX:0.6957,scaleY:0.6957,x:119.4,y:98.35},0).wait(1).to({scaleX:0.6942,scaleY:0.6942,x:114.1,y:99.25},0).wait(1).to({scaleX:0.6925,scaleY:0.6925,x:108.05,y:100.3},0).wait(1).to({scaleX:0.6905,scaleY:0.6905,x:101.05,y:101.5},0).wait(1).to({scaleX:0.6884,scaleY:0.6884,x:93.3,y:102.85},0).wait(1).to({scaleX:0.686,scaleY:0.686,x:84.8,y:104.2},0).wait(1).to({scaleX:0.6835,scaleY:0.6835,x:75.7,y:105.75},0).wait(1).to({scaleX:0.6808,scaleY:0.6808,x:66.2,y:107.35},0).wait(1).to({scaleX:0.6781,scaleY:0.6781,x:56.55,y:109},0).wait(1).to({scaleX:0.6754,scaleY:0.6754,x:46.9,y:110.65},0).wait(1).to({scaleX:0.6728,scaleY:0.6728,x:37.55,y:112.25},0).wait(1).to({scaleX:0.6703,scaleY:0.6703,x:28.7,y:113.75},0).wait(1).to({scaleX:0.668,scaleY:0.668,x:20.45,y:115.15},0).wait(1).to({scaleX:0.6659,scaleY:0.6659,x:12.9,y:116.4},0).wait(1).to({scaleX:0.6641,scaleY:0.6641,x:6.15,y:117.6},0).wait(1).to({scaleX:0.6624,scaleY:0.6624,x:0.15,y:118.6},0).wait(1).to({scaleX:0.6609,scaleY:0.6609,x:-5,y:119.5},0).wait(1).to({scaleX:0.6597,scaleY:0.6597,x:-9.45,y:120.25},0).wait(1).to({scaleX:0.6587,scaleY:0.6587,x:-13.15,y:120.9},0).wait(1).to({scaleX:0.6578,scaleY:0.6578,x:-16.15,y:121.35},0).wait(1).to({scaleX:0.6572,scaleY:0.6572,x:-18.5,y:121.75},0).wait(1).to({scaleX:0.6567,scaleY:0.6567,x:-20.3,y:122.1},0).wait(1).to({scaleX:0.6563,scaleY:0.6563,x:-21.6,y:122.3},0).wait(1).to({regX:181.1,regY:120.1,scaleX:0.6561,scaleY:0.6561,x:-28.35,y:102.9},0).wait(55));

	// Layer_2
	this.ribbon_1 = new lib.ribboncopy();
	this.ribbon_1.name = "ribbon_1";
	this.ribbon_1.setTransform(53,85.15,0.95,0.95,-0.012,0,0,280.4,152.2);
	this.ribbon_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon_1).wait(84).to({_off:false},0).wait(89));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-213.4,-106.7,505.79999999999995,369.7);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{chart:4,vanish:55});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(74).call(this.frame_74).wait(1));

	// Layer_7
	this.instance = new lib.excel_screen_white();
	this.instance.setTransform(115.65,-128.65,1,1,0,0,0,225.3,151.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61).to({_off:false},0).to({alpha:0.6016},13,cjs.Ease.cubicInOut).wait(1));

	// Layer_5
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(-19.5,-91.65);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({alpha:1},2,cjs.Ease.cubicInOut).wait(14));

	// Layer_3
	this.instance_2 = new lib.Rectangle111sml();
	this.instance_2.setTransform(-109.45,7.9,1.5099,1.5099);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75));

	// SmallGraphCover
	this.instance_3 = new lib.whitebar();
	this.instance_3.setTransform(284.05,-150.1,1.1639,1.0777,0,0,0,17.8,38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({regX:17.9,scaleX:1.4222,x:288.8},0).to({scaleX:1.2503,scaleY:0.5617,x:285.75,y:-189.9},51,cjs.Ease.quartInOut).wait(20));

	// SmallGraph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4AA167").s().p("Ai/JMIAAyXIF/AAIAASXg");
	this.shape.setTransform(282.6,-128.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#327545").s().p("Ai/KhIAA1BIF/AAIAACpIAASYg");
	this.shape_1.setTransform(244.175,-136.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(75));

	// Layer_6
	this.chart_mask = new lib.chart_mask();
	this.chart_mask.name = "chart_mask";
	this.chart_mask.setTransform(-29.15,-97.5,1,1,0,0,0,59.1,63);
	this.chart_mask.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.chart_mask).wait(75));

	// Text
	this.instance_4 = new lib.textanimation("synched",0,false);
	this.instance_4.setTransform(-26.65,-93.55,1,1,0,0,0,33.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(75));

	// GraphMask
	this.instance_5 = new lib.GraphCover("synched",0,false);
	this.instance_5.setTransform(-57.95,-124.7,1,1,0,0,0,28.9,28.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(75));

	// Graph_LG
	this.instance_6 = new lib.graphLG();
	this.instance_6.setTransform(-28.95,-95.65,1,1,0,0,0,49.9,49.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(75));

	// UI
	this.instance_7 = new lib.UI();
	this.instance_7.setTransform(115.85,-274.1,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,-279.6,471.79999999999995,305.70000000000005);


(lib.Pop_up_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.opt3 = new lib.option_btn();
	this.opt3.name = "opt3";
	this.opt3.setTransform(134.5,75.8,1,1,0,0,0,134.5,14.3);

	this.opt2 = new lib.option_btn();
	this.opt2.name = "opt2";
	this.opt2.setTransform(134.5,53.55,1,1,0,0,0,134.5,14.3);

	this.opt1 = new lib.option_btn();
	this.opt1.name = "opt1";
	this.opt1.setTransform(0,17);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.opt1},{t:this.opt2},{t:this.opt3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Pop_up_menu, new cjs.Rectangle(-0.3,16.7,159.9,67.8), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(77.05,13.75,0.6,0.6,0,0,0,13.8,10.8);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(57.4,15.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AnYCIIAAkPIOxAAIAAEPg");
	this.shape.setTransform(47.25,13.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D7").s().p("AnYCHIAAkNIOwAAIAAENg");
	this.shape_1.setTransform(47.2,13.425);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,-0.1,94.6,27.200000000000003), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.TL_MainScreen.tweenFromTo("frame0", "frame1");
		//exportRoot.TL_Clouds.tweenFromTo("frame0", "frame1");
	}
	this.frame_89 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(30).call(this.frame_89).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(63));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(63));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regY:0.3,scaleX:2.3428,scaleY:2.3428,x:-711.2,y:264.7},30,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.3,337.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},30,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-879.8,191.6,2358.3,291.6);


(lib.screenanimationexcel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		//this.title_s.cache(-38,-15.7,152,63,2);
	}
	this.frame_44 = function() {
		this.screen.gotoAndPlay("chart");
	}
	this.frame_99 = function() {
		this.td_graph.gotoAndPlay("grow");
	}
	this.frame_160 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(55).call(this.frame_99).wait(61).call(this.frame_160).wait(1));

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.setTransform(23.15,1.55,0.7883,0.7883,0,0,0,64.7,62.9);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(89).to({scaleX:0.7496,scaleY:0.7496,x:-127.95,y:6.4},30,cjs.Ease.cubicInOut).wait(42));

	// td_graph
	this.td_graph = new lib._3D_price();
	this.td_graph.name = "td_graph";
	this.td_graph.setTransform(94.7,59,0.3993,0.3586,0,0,0,5,0.7);

	this.timeline.addTween(cjs.Tween.get(this.td_graph).wait(89).to({regX:5.3,regY:0.9,scaleX:0.3797,scaleY:0.341,x:-59.95,y:61},30,cjs.Ease.cubicInOut).wait(42));

	// screen3
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(140,22.85,0.4713,0.3772,0,-28.3398,-17.0422,107.4,-133.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(89).to({regX:107.5,regY:-133.4,scaleX:0.4481,scaleY:0.3587,skewX:-28.3389,skewY:-17.0393,x:-16.9,y:26.65},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_2
	this.instance = new lib.shadow_1();
	this.instance.setTransform(120,6.25,0.72,0.72,0,0,0,180.6,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:180.8,regY:119.4,x:120.15,y:5.95},0).to({regX:180.6,regY:119.7,scaleX:0.6779,scaleY:0.6779,x:-37.05,y:12.3},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_4
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-166.1,-380.1,1.3303,1.3303,1.0878,0,0,-0.1,-0.3);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-173.1,-371.2,453.79999999999995,802);


(lib.object_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.screen = new lib.screenanimation_1();
	this.screen.name = "screen";
	this.screen.setTransform(224.7,93.4,0.79,0.79,0,0,0,196.9,130.8);

	this.screen_1 = new lib.screenanimation();
	this.screen_1.name = "screen_1";
	this.screen_1.setTransform(221.8,66.35,1,1,0,0,0,197.1,130.8);

	this.screen_2 = new lib.screenanimationexcel();
	this.screen_2.name = "screen_2";
	this.screen_2.setTransform(229.25,147,0.79,0.79,0,0,0,196.9,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen}]}).to({state:[{t:this.screen_1}]},1).to({state:[{t:this.screen_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-187,-2,728,149.4);


(lib.Page = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// obj1
	this.obj1 = new lib.object_1();
	this.obj1.name = "obj1";
	this.obj1.setTransform(315.8,204.5,1,1,0,0,0,127.8,219.5);

	this.timeline.addTween(cjs.Tween.get(this.obj1).wait(1));

	// bg
	this.bg = new lib.Page_bg();
	this.bg.name = "bg";
	this.bg.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page, new cjs.Rectangle(-125.9,-74.1,855,200.5), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(272.05,-59,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(953.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(669.2,59.15,0.9555,0.9555,0,0,0,0.8,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(633.55,46.95,1,1,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// page
	this.page = new lib.Page();
	this.page.name = "page";
	this.page.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.page).wait(1));

	// option_hits
	this.hit_down = new lib.option_hit();
	this.hit_down.name = "hit_down";
	this.hit_down.setTransform(653.2,177.25,0.6329,0.7256,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit_down, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit_opts = new lib.option_hit();
	this.hit_opts.name = "hit_opts";
	this.hit_opts.setTransform(652.95,11.1,0.6329,0.7256,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit_opts, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(653.2,78.45,0.6329,0.7256,0,0,0,134.6,14.3);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(653.2,55.95,0.6329,0.7256,0,0,0,134.6,14.3);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(653.2,33.5,0.6329,0.7256,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit_opts},{t:this.hit_down}]}).wait(1));

	// options
	this.popup_menu = new lib.Pop_up_menu();
	this.popup_menu.name = "popup_menu";
	this.popup_menu.setTransform(647.75,42.2,1,1,0,0,0,79.5,35.9);

	this.timeline.addTween(cjs.Tween.get(this.popup_menu).wait(1));

	// opts
	this.opts = new lib.option_btn_menu();
	this.opts.name = "opts";
	this.opts.setTransform(702.75,15,1,1,0,0,0,134.5,14.3);

	this.timeline.addTween(cjs.Tween.get(this.opts).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// first_frame
	this.background = new lib.mountain_anim();
	this.background.name = "background";
	this.background.setTransform(284.4,25.1,1,1,0,0,0,284.4,25.1);

	this.timeline.addTween(cjs.Tween.get(this.background).wait(1));

	// Bg
	this.instance = new lib.whitecopy();
	this.instance.setTransform(483.1,169.9,1,1,0,0,0,483.1,169.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-125.9,-13.4,1091.3,263.4), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var frequency = 5; 
		stage.enableMouseOver(frequency);
		
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "page") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillPage(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt1") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_1(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt2") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_2(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt3") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_3(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opts") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillPage = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.page.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.opts.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_1 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt1.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_2 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt2.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_3 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt3.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		var opt1 = mc.popup_menu.opt1
		var opt2 = mc.popup_menu.opt2
		var opt3 = mc.popup_menu.opt3
		var opts = mc.opts
		
		var hit1 = mc.hit1
		var hit2 = mc.hit2
		var hit3 = mc.hit3
		var hit_opts = mc.hit_opts
		var hit_down = mc.hit_down
		
		this.runBanner = function() {
			
			mc.replay_btn.visible=false
			mc.page.alpha=0
			
			mc.cta.alpha=0
			mc.txtCta.alpha=0
			
		/*	this.TL_Popup = new TimelineMax();	
			exportRoot.TL_Popup.add('frame0');
				exportRoot.TL_Popup.to(hit_opts, 0.1, {y: "+=100"}, "-=0");
				exportRoot.TL_Popup.from(opt1, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0");
				exportRoot.TL_Popup.from(hit1, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");		
				exportRoot.TL_Popup.from(opt2, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit2, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(opt3, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit3, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.to(hit_down, 0.1, {y: "-=100"}, "-=0");
			exportRoot.TL_Popup.add('frame1');
			exportRoot.TL_Popup.stop();*/
			
				this.TL_MainScreen = new TimelineMax();
				exportRoot.TL_MainScreen.add('frame0')
				
				exportRoot.TL_MainScreen.from(mc.background, 0.1, {x: "+=200", ease:Power2.easeOut, onStart:function(){mc.background.ribbon.play();}}, "+=0");
		
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
		
				}
				exportRoot.TL_MainScreen.from(opts, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit_opts, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");		
				exportRoot.TL_MainScreen.from(opt1, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit1, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");		
				exportRoot.TL_MainScreen.from(opt2, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit2, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_MainScreen.from(opt3, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit3, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");
		
				//exportRoot.TL_MainScreen.stop();
				exportRoot.TL_MainScreen.add('frame1');
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "+=0");
					if (i!=0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "-=0.5");
				}
				
				exportRoot.TL_MainScreen.to(mc.background, 0.8, {x: "-=150", ease:Power3.easeIn}, "-=0.6");
				exportRoot.TL_MainScreen.to(opts, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.7");
				exportRoot.TL_MainScreen.to(hit_opts, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit_down, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt1, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit1, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt2, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit2, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt3, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit3, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
		
				exportRoot.TL_MainScreen.add('frame2')
							
				exportRoot.TL_MainScreen.stop();	
				
				/*exportRoot.TL_Clouds = new TimelineMax();
				exportRoot.TL_Clouds.add('frame0')
				exportRoot.TL_Clouds.from(mc.background.ribbon, 3, { x: "+=20",	ease:Power4.easeOut, onStart:function(){mc.background.ribbon.play();}}, "0");
				exportRoot.TL_Clouds.add('frame1')		
				exportRoot.TL_Clouds.to(mc.background.ribbon, 2, { x: "-=20",	ease:Power4.easeIn}, "+=0");
				exportRoot.TL_Clouds.add('frame2')
				exportRoot.TL_Clouds.stop();*/
				
				mc.logo_intro.gotoAndPlay(1)
				
			exportRoot.tltxt1 = new TimelineMax();
			exportRoot.tltxt1.add('frame0')
			for (var i = 0; i < exportRoot.page_1_1.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_1_2.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt1.add('frame1')	
			exportRoot.tltxt1.stop();
			
			exportRoot.tltxt2 = new TimelineMax();
			exportRoot.tltxt2.add('frame0')
			for (var i = 0; i < exportRoot.page_2_1.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_2_2.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt2.add('frame1')	
			exportRoot.tltxt2.stop();
			
			/*var screen3 = mc.page.screen.screen3
			var icon = mc.page.screen.icon
			var shadow = mc.page.screen.shadow
			var mask = mc.page.screen.screen3.chart_mask
			var graph = mc.page.screen.td_graph*/
			
			exportRoot.tltxt3 = new TimelineMax();
			exportRoot.tltxt3.add('frame0')
			for (var i = 0; i < exportRoot.page_3_1.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_3_2.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
				
			exportRoot.tltxt3.add('frame1')	
			exportRoot.tltxt3.stop();
			
			//
			//   FRAME 2 ANIMATION IN / OUT
			//
			exportRoot.TL_Frame2_IN = new TimelineMax();
			
			mc.cta.alpha=1
			mc.txtCta.alpha=1
				
			exportRoot.TL_Frame2_IN.add('frame0')
			exportRoot.TL_Frame2_IN.from(mc.page.bg, 1, {x: "+=950",  ease:Power4.easeOut}, "+=0.3");
			exportRoot.TL_Frame2_IN.from(mc.page.obj1, 1.5, {x: "+=900",  ease:Power4.easeOut, onStart:function(){mc.page.obj1.screen.play();}}, "-=1");
		
			exportRoot.TL_Frame2_IN.from(mc.txtCta, 1, { alpha: 0, x: "+=100", ease:Power4.easeOut}, "+=1.8");
			exportRoot.TL_Frame2_IN.from(mc.cta, 1, {	alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=1");
			
			exportRoot.TL_Frame2_IN.add('frame1')
			
			exportRoot.TL_Frame2_IN.stop()	
		}
		
		exportRoot.selectedOption = function(id) {
			
			exportRoot.TL_MainScreen.tweenFromTo("frame1", "frame2");
				
			exportRoot.selectedScreenIn(id)
				
		}
		exportRoot.mainScreenOut = function() {
		
		}
		var IDtest = 0
		//mc.hit.mouseEnabled = false
		exportRoot.selectedScreenIn = function(id) {
			IDtest = id
			mc.page.obj1.gotoAndStop(id-1)
			mc.page.alpha=1
			var pageID = id
			mc.page.obj1.visible=true
			mc.page.obj1.alpha = 1
			
			if (id==1) {
				exportRoot.tltxt1.tweenFromTo("frame0", "frame1",{delay:.3});
				//myFT.tracker("Answer1_WorkingVirtually");
				};
			if (id==2) {
				exportRoot.tltxt2.tweenFromTo("frame0", "frame1",{delay:.3});
				//myFT.tracker("Answer2_KeepingMyKidsEngaged");
				};
			if (id==3) {
				exportRoot.tltxt3.tweenFromTo("frame0", "frame1",{delay:.3});
				//myFT.tracker("Answer3_SavingMoney");
				};
		
			exportRoot.TL_Frame2_IN.tweenFromTo("frame0", "frame1",{delay:.3});
			//mc.hit.mouseEnabled = true
		}
		
		/*mc.hit.addEventListener("click", mainHit.bind(this));
		mc.hit.addEventListener("mouseover", mainOver.bind(this));
		mc.hit.addEventListener("mouseout", mainOut.bind(this));*/
		
		/*function mainHit() {
			
			if (IDtest==1) window.open(clickTag_1);
		
			if (IDtest==2) window.open(clickTag_2);
		
			if (IDtest==3) window.open(clickTag_3);
		
		}*/
		function mainOver() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(1);
		}
		function mainOut() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(238.1,31.6,727.3,135.20000000000002);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 728,
	height: 90,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593187783838", id:"M365_FY21Q1_BTS_USA_728x90_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;