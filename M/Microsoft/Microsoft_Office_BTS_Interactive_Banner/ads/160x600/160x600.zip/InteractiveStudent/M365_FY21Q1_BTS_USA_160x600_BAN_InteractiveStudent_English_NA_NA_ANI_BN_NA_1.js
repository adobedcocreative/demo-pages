(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[302,0,302,192],[606,193,163,306],[931,153,74,126],[771,193,158,129],[904,324,107,56],[102,202,131,104],[0,355,84,53],[506,194,89,65],[283,425,51,43],[235,347,156,76],[547,408,52,43],[206,425,75,50],[0,414,122,39],[931,281,52,41],[904,382,76,52],[547,363,53,43],[235,202,47,69],[235,273,55,55],[124,414,80,48],[102,308,131,104],[283,475,300,10],[890,0,100,151],[992,0,30,52],[982,382,31,48],[336,425,31,46],[771,430,31,45],[992,54,30,44],[992,100,30,43],[804,430,30,43],[302,194,100,151],[404,194,100,151],[0,202,100,151],[547,316,56,45],[0,0,300,200],[506,261,85,53],[606,0,282,191],[393,347,152,63],[393,412,152,61],[771,324,131,104]]}
];


// symbols:



(lib.basicUIhalf = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bg_img_160x600_smlpngcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.bodyResize_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.chart_big_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.chart_sml_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Excel_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.girllefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Grass_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.guylefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.leafA_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.LeafB_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.percent_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.PPT_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Render0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Render0109sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Render0110sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Render0111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Render0112sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Render0113sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Render0114sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Render0115sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Render0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Render0117 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Render0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.secondimagesml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Word_icon_sml_update = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.WordIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.iconcache.cache(-260,-230,520,460,0.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Word_icon_sml_update();
	this.instance.setTransform(108,121,1.9,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(108,121,248.89999999999998,197.60000000000002), null);


(lib.whitebar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixGAIAAr/IFjAAIAAL/g");
	this.shape.setTransform(17.825,38.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebar, new cjs.Rectangle(0,0,35.7,76.8), null);


(lib.whitecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(80.0011,299.9992,0.5333,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitecopy, new cjs.Rectangle(0,0,160,600), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AsGrUIYXAAIAAWdI4hAMg");
	this.shape.setTransform(-0.0003,-0.0264);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.5,-72.5,157.1,145);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.Topbar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape.setTransform(268.579,5.5001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#437F5B").s().p("AgJgEIATAAIgKAJg");
	this.shape_1.setTransform(72.0759,5.5001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUAbIgGgGIAAgwIA1AAIAAATIgCAAIAAgQIgGAAIAAAQIgCAAIAAgQIggAAIAAAXIANAAIgBABIgPAAIAAgYIgGAAIAAArIAFAGIAFAAIAAgQIAGAAIAAADIgEAAIAAANIAGAAIAAACg");
	this.shape_2.setTransform(46.425,6.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMABIAAAEIgCAAIAAgJIAJAAIAAADIgGAAQAEAFAHAAQAKAAADgJIACABQgDAKgMAAQgIAAgEgFg");
	this.shape_3.setTransform(47.6,8.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAGIACgGQAFgGAHAAQAHAAAGAGIAAgEIACAAIAAAJIgKAAIAAgDIAHAAQgFgFgHAAQgFAAgFAEIgCAGg");
	this.shape_4.setTransform(47.6,6.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAQIgOgOIgNAOIgCAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAOgOIgOgNIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAABIANANIAOgNIACAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgOANIAOAOQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_5.setTransform(442.325,5.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQARIAAgaIAHAAIAAgHIAaAAIAAAaIgHAAIAAAHgAgNAOIAVAAIAAgUIgVAAgAgHgJIARAAIAAAQIAEAAIAAgUIgVAAg");
	this.shape_6.setTransform(427.1,5.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.3).p("AgRAAIAjAA");
	this.shape_7.setTransform(411.95,5.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUARIAAghIApAAIAAAhgAABAOIASAAIAAgUIglAAIAAAUIASAAIAAgOIgGAEIgBgCIAHgHIAIAHIgBACIgGgEgAgSgJIAlAAIAAgEIglAAg");
	this.shape_8.setTransform(396.625,5.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIABIAAgBIARAAIAAABg");
	this.shape_9.setTransform(78.65,4.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_10.setTransform(78.675,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_11.setTransform(60.575,5.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#437F5B").s().p("AgQAFQgFgFABgHQABgHAFgFIABAAQAFgFAHAAQAHACAEAEIAJAKIAAgTIACAAIAAAYIgWAAIAAgDIASAAIgJgKQgDgEgGgBQgFAAgFADIgCABQgEAEgBAGQAAAHAEADIAUAXIgCABg");
	this.shape_12.setTransform(67.2167,6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAaIAUgXQAEgDAAgHQgBgFgFgFIgBgBQgFgDgFAAQgGABgDAEIgJAKIASAAIAAADIgWAAIAAgYIACAAIAAATIAJgKQAEgEAGgCQAHAAAGAFIABAAQAFAFABAHQAAAHgEAFIgUAWg");
	this.shape_13.setTransform(55.625,6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AglAaQgKAAgIgIQgIgHAAgLQAAgKAIgHQAIgIAKAAIBLAAQALAAAHAIQAIAHAAAKQAAALgIAHQgHAIgLAAgAAdgIQgEAEAAAEQAAAFAEAEQADADAGAAQAFAAADgDQADgEAAgFQAAgEgDgEQgDgDgFAAQgGAAgDADg");
	this.shape_14.setTransform(32.4,5.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#227347").s().p("EgjJAA3IAAhuMBGTAAAIAABug");
	this.shape_15.setTransform(225,5.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Topbar, new cjs.Rectangle(0,0,450,11.1), null);


(lib.top_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt13 = new cjs.Text("Comments", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 7;
	this.txt13.lineWidth = 23;
	this.txt13.parent = this;
	this.txt13.setTransform(416.2,18.75);

	this.txt13_1 = new cjs.Text("Share", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13_1.name = "txt13_1";
	this.txt13_1.lineHeight = 7;
	this.txt13_1.lineWidth = 15;
	this.txt13_1.parent = this;
	this.txt13_1.setTransform(390.7,15.7);

	this.txt13_2 = new cjs.Text("Search", "5px 'Segoe Pro'", "#474747");
	this.txt13_2.name = "txt13_2";
	this.txt13_2.lineHeight = 8;
	this.txt13_2.lineWidth = 15;
	this.txt13_2.parent = this;
	this.txt13_2.setTransform(208,15.55);

	this.txt12 = new cjs.Text("Help", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 15;
	this.txt12.parent = this;
	this.txt12.setTransform(181,18.55);

	this.txt11 = new cjs.Text("View", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 15;
	this.txt11.parent = this;
	this.txt11.setTransform(162.95,18.55);

	this.txt10 = new cjs.Text("Review", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 15;
	this.txt10.parent = this;
	this.txt10.setTransform(140.55,18.55);

	this.txt9 = new cjs.Text("Date", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 15;
	this.txt9.parent = this;
	this.txt9.setTransform(122.5,18.55);

	this.txt8 = new cjs.Text("Formulas", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 24;
	this.txt8.parent = this;
	this.txt8.setTransform(95.4,18.55);

	this.txt7 = new cjs.Text("Page Layout", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 33;
	this.txt7.parent = this;
	this.txt7.setTransform(62.2,18.55);

	this.txt6 = new cjs.Text("Insert", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 13;
	this.txt6.parent = this;
	this.txt6.setTransform(41.25,18.55);

	this.txt5 = new cjs.Text("Home", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 13;
	this.txt5.parent = this;
	this.txt5.setTransform(19.9,18.55);

	this.txt4 = new cjs.Text("File", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 8;
	this.txt4.parent = this;
	this.txt4.setTransform(2.3,18.55);

	this.txt3 = new cjs.Text("Daniella Duarte", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 30;
	this.txt3.parent = this;
	this.txt3.setTransform(355.05,7.2);

	this.txt2 = new cjs.Text("Family Budget - Saved to OneDrive", "5px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 105;
	this.txt2.parent = this;
	this.txt2.setTransform(185.3,6.5);

	this.txt1 = new cjs.Text("On", "3px 'Segoe Pro'", "#227347");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 6;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(24.15,6.6);

	this.txt = new cjs.Text("AutoSave", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 7;
	this.txt.lineWidth = 19;
	this.txt.parent = this;
	this.txt.setTransform(2,6.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13_2},{t:this.txt13_1},{t:this.txt13}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_text, new cjs.Rectangle(0,4.5,441.2,22.3), null);


(lib.titleshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.textanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#44724B").s().p("AhZB4ICOjaQgaAHgjAAIgIAAQAJAMAAAOQAAAUgOAQQgOAQgXAAQgWAAgOgPQgPgPAAgVQAAgOAHgMQAHgLAMgHQAMgHANAAQAFAAANADQATAEAVAAQAQAAAPgCQAPgCAXgHIARAAIicDvgAhRhXQgJAKAAANQAAAOAJAIQAKAKANAAQANAAAKgKQAJgIAAgOQAAgNgJgKQgKgKgNAAQgNAAgKAKgAAXBhQgPgQAAgUQAAgWAPgOQAPgPAVAAQAVAAAPAPQAPAOAAAWQAAAUgPAQQgPAPgVAAQgVAAgPgPgAAkAmQgJAJAAAOQAAANAJAJQAKAJANAAQANAAAKgJQAJgJAAgNQAAgOgJgJQgKgKgNAAQgNAAgKAKg");
	this.shape.setTransform(46.925,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAFgIQAGgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgcARQAQAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_1.setTransform(26.9,20.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#44724B").s().p("AhIBuIBRhZQAZgaAIgNQAHgNAAgOQAAgSgNgNQgOgNgUAAQgTAAgOAOQgOAOgCAZIgUAAQABggAUgVQAVgVAdABQAdAAATATQASATAAAaQAAATgJAQQgIAOgaAcIg0A6IBiAAIAAAUg");
	this.shape_2.setTransform(10.225,20.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_3.setTransform(26.925,20.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAdABATATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_4.setTransform(26.9,20.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_5.setTransform(27.3,20.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#44724B").s().p("AhABlIBji+IhmAAIAAgUICHAAIhyDbg");
	this.shape_6.setTransform(27.625,20.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#44724B").s().p("Ag1BdQgTgVAAgYQAAgSAKgPQAJgOAXgKQgQgJgHgMQgJgMAAgOQABgOAIgNQAIgOAPgHQAPgIAQAAQARAAAPAIQAOAHAIAOQAIANAAAPQAAAOgIAMQgHALgPAJQAVAJAJAOQAKAOAAASQAAAZgRATQgTAXglAAQgjAAgSgUgAgjAPQgPAOAAATQAAAMAGALQAHAKALAGQAMAGAOAAQAXAAAOgOQAPgOAAgTQAAgSgPgOQgPgOgVAAQgVAAgPAPgAgchRQgMALAAAOQAAAPANALQAMAMAQAAQAKAAAKgFQAJgGAGgJQAGgJAAgJQAAgNgLgLQgKgLgVAAQgRAAgLAKg");
	this.shape_7.setTransform(26.95,20.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#44724B").s().p("AgoBmIA5hYQgMADgJAAQgZAAgTgRQgSgTAAgbQABgSAIgPQAJgPAQgJQAQgJARAAQASAAAPAIQAPAJAIAQQAKAPgBASQAAANgFAPQgFAOgOAUIhBBhgAgfhOQgNANAAATQAAATANANQAOANARAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgRAAgOANg");
	this.shape_8.setTransform(26.75,20.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#44724B").s().p("AglBlQgRgMgJgXQgJgYAAgqQAAgqAJgXQAJgXARgMQAQgMAVAAQAUAAARAMQARAMAKAYQAJAYAAAoQAAApgJAYQgKAYgRAMQgRAMgUAAQgVAAgQgMgAgahSQgNAJgGATQgHATAAAkQAAAkAHATQAGASANAKQANAKANAAQAOAAANgKQAMgJAHgTQAIgXAAggQgBgggHgVQgHgVgMgJQgNgKgOAAQgNAAgNAKg");
	this.shape_9.setTransform(26.95,20.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAGgIQAFgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgbARQAPAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_10.setTransform(10.25,20.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#44724B").s().p("AAGBsIAAjCIghAAIANgVIAqAAIAADXg");
	this.shape_11.setTransform(25.675,20.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_12.setTransform(10.275,20.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAeABASATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_13.setTransform(10.25,20.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_14.setTransform(10.65,20.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},7).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_4},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_12},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_14},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},4).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,66.4,39.8);


(lib.text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlleftcontributionsml();
	this.instance.setTransform(0.1,-0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,-0.2,89.1,65.2), null);


(lib.text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.tablet_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,-4,0,4.6,-4,8.6).s().p("AgMASQgKgKgGgKQgEgHgCgIIgCgKIgBgIIAAgGIBLAAIAAABIAABSQgegCgUgWg");
	this.shape.setTransform(-10.0002,11.9003);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-3.6,18.3,4.7,18.3).s().p("AglCAIAAghIABAHIACAKQACAJAEAHgAglBYIAAjXIBLAAIAADXg");
	this.shape_1.setTransform(-10.0002,-1.1249);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,4.1,0,4.6,4.1,8.6).s().p("AglAqIAAgCIAAAAQABgiAYgXQAUgWAegCIAABSIAAABg");
	this.shape_2.setTransform(-10.0002,-18.1502);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,4.2,-18.2,-4.2).s().p("ABkAqIjgAAIgDAAIAAgBIAAhSID/AAIAAABIAAAAIAABSg");
	this.shape_3.setTransform(6.5751,12.0003);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,-4.1,0,-4,-4.1,8.6).s().p("AgoAqIgBAAIAAhSIAAAAIAAgBIABAAIBSAAIAAABIAAADQAAAhgYAVQgXAZgiAAg");
	this.shape_4.setTransform(23.6253,12.0003);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],4.3,21.6,-4.1,21.6).s().p("AApBwIAAAAIhSAAIAAjaIBSAAIAAgFIABAAIAADfg");
	this.shape_5.setTransform(23.7003,-3.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ACABtIkAAAIAAgBIAAjXIAAgBIEAAAIABAAIAADZg");
	this.shape_6.setTransform(6.6251,-3.1249);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,-4.1,-18.2,4.3).s().p("Ah/AqIAAhSIAAgBIADAAIDgAAIAcAAIAABSIAAABg");
	this.shape_7.setTransform(6.5751,-18.2502);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,4.2,0,-4,4.2,8.6).s().p("AgoAqIgBAAIAAgBIAAhSIABAAIABAAQAiAAAXAYQAXAWABAfIAAAGg");
	this.shape_8.setTransform(23.6253,-18.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,5,1.1,-5).s().p("AkLAyIAAAAIABAAIABAAIACAAIAAgCIAAhhIGwAAIBjAAIAABhIAAACIgCAAIAAAAIAAAAg");
	this.shape_9.setTransform(36.375,89.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,-4.8,0,4.9,-4.8,10.2).s().p("AAwAyIgBAAIgCAAQgngBgagcQgdgbAAgoIAAgDIBhAAIACAAIAAABIAABhIAAABg");
	this.shape_10.setTransform(5,89.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-4.9,0.1,5.1,0.1).s().p("AAwFyIhhAAIAArjIBhAAIACAAIAALjg");
	this.shape_11.setTransform(5,47.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,4.8,0,4.9,4.8,10.2).s().p("AAwAzIhhAAIAAgCIAAgBQAAgpAdgbQAagcAngBIACAAIABAAIACAAIAABiIAAACg");
	this.shape_12.setTransform(5,5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,-5,1.1,5).s().p("ACpAyImwAAIAAhiIgCAAIgBAAIgBAAIAAgBIIVAAIAAABIAAAAIACAAIAABig");
	this.shape_13.setTransform(36.375,5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,5,0,-5).s().p("AECAyIoVAAIgDAAIAAAAIAAAAIACAAIAAgCIAAhhIAWAAIB8AAIEgAAIB3AAIAABhIAAACIABAAIABAAIAAAAg");
	this.shape_14.setTransform(90.875,89.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,-4.8,0,-4.8,-4.8,10.2).s().p("AgwAyIgBAAIAAgBIAAhhIAAgBIACAAIBhAAIAAADQgBAogdAbQgaAdgpAAIgBAAg");
	this.shape_15.setTransform(123.6,89.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,-5,0,5).s().p("ACeAyIkgAAIh8AAIgWAAIAAhiIgCAAIAAAAIAAgBIItAAIAAABIgBAAIgBAAIAABig");
	this.shape_16.setTransform(90.875,5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AGoFzIkhAAIh9AAIgUAAIhjAAImxAAIAAgBIAArjIAAgBIGxAAIBjAAIAUAAIB9AAIEhAAIB3AAIAAABIAALjIAAABg");
	this.shape_17.setTransform(64.3,47.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],5,0.1,-5,0.1).s().p("AgvFyIgCAAIAArjIACAAIBhAAIAALjg");
	this.shape_18.setTransform(123.6,47.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,4.8,0,-4.8,4.8,10.2).s().p("AgvAzIgCAAIAAgCIAAhiIABAAIABAAQApAAAaAdQAdAbABApIAAABIAAACg");
	this.shape_19.setTransform(123.6,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_sub, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.small_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_sml_msml();
	this.instance.setTransform(198,132,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.small_pie, new cjs.Rectangle(0,0,420,420), null);


(lib.secondimage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.secondimagesml();
	this.instance.setTransform(-0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage, new cjs.Rectangle(-0.4,0,85,53.3), null);


(lib.screenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.basicUIhalf();
	this.instance.setTransform(-0.35,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.rowsandcells = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//columns
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"

		//rows
		this.txt01.textBaseline = "alphabetic"
		this.txt02.textBaseline = "alphabetic"
		this.txt03.textBaseline = "alphabetic"
		this.txt04.textBaseline = "alphabetic"
		this.txt05.textBaseline = "alphabetic"
		this.txt06.textBaseline = "alphabetic"
		this.txt07.textBaseline = "alphabetic"
		this.txt08.textBaseline = "alphabetic"
		this.txt09.textBaseline = "alphabetic"
		this.txt010.textBaseline = "alphabetic"
		this.txt011.textBaseline = "alphabetic"
		this.txt012.textBaseline = "alphabetic"
		this.txt013.textBaseline = "alphabetic"
		this.txt014.textBaseline = "alphabetic"
		this.txt015.textBaseline = "alphabetic"
		this.txt016.textBaseline = "alphabetic"
		this.txt017.textBaseline = "alphabetic"
		this.txt018.textBaseline = "alphabetic"
		this.txt019.textBaseline = "alphabetic"
		this.txt020.textBaseline = "alphabetic"
		this.txt021.textBaseline = "alphabetic"
		this.txt022.textBaseline = "alphabetic"
		this.txt023.textBaseline = "alphabetic"
		this.txt024.textBaseline = "alphabetic"
		this.txt025.textBaseline = "alphabetic"
		this.txt026.textBaseline = "alphabetic"
		this.txt027.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt027 = new cjs.Text("27", "5px 'Segoe Pro'", "#474747");
	this.txt027.name = "txt027";
	this.txt027.lineHeight = 8;
	this.txt027.lineWidth = 6;
	this.txt027.parent = this;
	this.txt027.setTransform(-11,241.15);

	this.txt026 = new cjs.Text("26", "5px 'Segoe Pro'", "#474747");
	this.txt026.name = "txt026";
	this.txt026.lineHeight = 8;
	this.txt026.lineWidth = 6;
	this.txt026.parent = this;
	this.txt026.setTransform(-11,232.95);

	this.txt025 = new cjs.Text("25", "5px 'Segoe Pro'", "#474747");
	this.txt025.name = "txt025";
	this.txt025.lineHeight = 8;
	this.txt025.lineWidth = 6;
	this.txt025.parent = this;
	this.txt025.setTransform(-11,224.65);

	this.txt024 = new cjs.Text("24", "5px 'Segoe Pro'", "#474747");
	this.txt024.name = "txt024";
	this.txt024.lineHeight = 8;
	this.txt024.lineWidth = 6;
	this.txt024.parent = this;
	this.txt024.setTransform(-11,216.35);

	this.txt023 = new cjs.Text("23", "5px 'Segoe Pro'", "#474747");
	this.txt023.name = "txt023";
	this.txt023.lineHeight = 8;
	this.txt023.lineWidth = 6;
	this.txt023.parent = this;
	this.txt023.setTransform(-11,208.2);

	this.txt022 = new cjs.Text("22", "5px 'Segoe Pro'", "#474747");
	this.txt022.name = "txt022";
	this.txt022.lineHeight = 8;
	this.txt022.lineWidth = 6;
	this.txt022.parent = this;
	this.txt022.setTransform(-11,200);

	this.txt021 = new cjs.Text("21", "5px 'Segoe Pro'", "#474747");
	this.txt021.name = "txt021";
	this.txt021.lineHeight = 8;
	this.txt021.lineWidth = 6;
	this.txt021.parent = this;
	this.txt021.setTransform(-11,191.7);

	this.txt020 = new cjs.Text("20", "5px 'Segoe Pro'", "#474747");
	this.txt020.name = "txt020";
	this.txt020.lineHeight = 8;
	this.txt020.lineWidth = 6;
	this.txt020.parent = this;
	this.txt020.setTransform(-11,183.35);

	this.txt019 = new cjs.Text("19", "5px 'Segoe Pro'", "#474747");
	this.txt019.name = "txt019";
	this.txt019.lineHeight = 8;
	this.txt019.lineWidth = 6;
	this.txt019.parent = this;
	this.txt019.setTransform(-10.5,175.1);

	this.txt018 = new cjs.Text("18", "5px 'Segoe Pro'", "#474747");
	this.txt018.name = "txt018";
	this.txt018.lineHeight = 8;
	this.txt018.lineWidth = 6;
	this.txt018.parent = this;
	this.txt018.setTransform(-10.5,166.9);

	this.txt017 = new cjs.Text("17", "5px 'Segoe Pro'", "#474747");
	this.txt017.name = "txt017";
	this.txt017.lineHeight = 8;
	this.txt017.lineWidth = 6;
	this.txt017.parent = this;
	this.txt017.setTransform(-10.5,158.7);

	this.txt016 = new cjs.Text("16", "5px 'Segoe Pro'", "#474747");
	this.txt016.name = "txt016";
	this.txt016.lineHeight = 8;
	this.txt016.lineWidth = 6;
	this.txt016.parent = this;
	this.txt016.setTransform(-10.5,150.45);

	this.txt015 = new cjs.Text("15", "5px 'Segoe Pro'", "#474747");
	this.txt015.name = "txt015";
	this.txt015.lineHeight = 8;
	this.txt015.lineWidth = 6;
	this.txt015.parent = this;
	this.txt015.setTransform(-10.5,142.15);

	this.txt014 = new cjs.Text("14", "5px 'Segoe Pro'", "#474747");
	this.txt014.name = "txt014";
	this.txt014.lineHeight = 8;
	this.txt014.lineWidth = 6;
	this.txt014.parent = this;
	this.txt014.setTransform(-10.5,133.85);

	this.txt013 = new cjs.Text("13", "5px 'Segoe Pro'", "#474747");
	this.txt013.name = "txt013";
	this.txt013.lineHeight = 8;
	this.txt013.lineWidth = 6;
	this.txt013.parent = this;
	this.txt013.setTransform(-10.5,125.8);

	this.txt012 = new cjs.Text("12", "5px 'Segoe Pro'", "#474747");
	this.txt012.name = "txt012";
	this.txt012.lineHeight = 8;
	this.txt012.lineWidth = 6;
	this.txt012.parent = this;
	this.txt012.setTransform(-10.5,117.5);

	this.txt011 = new cjs.Text("11", "5px 'Segoe Pro'", "#474747");
	this.txt011.name = "txt011";
	this.txt011.lineHeight = 8;
	this.txt011.lineWidth = 6;
	this.txt011.parent = this;
	this.txt011.setTransform(-10.5,109.3);

	this.txt010 = new cjs.Text("10", "5px 'Segoe Pro'", "#474747");
	this.txt010.name = "txt010";
	this.txt010.lineHeight = 8;
	this.txt010.lineWidth = 6;
	this.txt010.parent = this;
	this.txt010.setTransform(-10.5,101.05);

	this.txt09 = new cjs.Text("9", "5px 'Segoe Pro'", "#474747");
	this.txt09.name = "txt09";
	this.txt09.lineHeight = 8;
	this.txt09.lineWidth = 6;
	this.txt09.parent = this;
	this.txt09.setTransform(-9.7,92.8);

	this.txt08 = new cjs.Text("8", "5px 'Segoe Pro'", "#474747");
	this.txt08.name = "txt08";
	this.txt08.lineHeight = 8;
	this.txt08.lineWidth = 6;
	this.txt08.parent = this;
	this.txt08.setTransform(-9.7,84.6);

	this.txt07 = new cjs.Text("7", "5px 'Segoe Pro'", "#474747");
	this.txt07.name = "txt07";
	this.txt07.lineHeight = 8;
	this.txt07.lineWidth = 6;
	this.txt07.parent = this;
	this.txt07.setTransform(-9.7,76.35);

	this.txt06 = new cjs.Text("6", "5px 'Segoe Pro'", "#474747");
	this.txt06.name = "txt06";
	this.txt06.lineHeight = 8;
	this.txt06.lineWidth = 6;
	this.txt06.parent = this;
	this.txt06.setTransform(-9.7,68.1);

	this.txt05 = new cjs.Text("5", "5px 'Segoe Pro'", "#474747");
	this.txt05.name = "txt05";
	this.txt05.lineHeight = 8;
	this.txt05.lineWidth = 6;
	this.txt05.parent = this;
	this.txt05.setTransform(-9.7,59.85);

	this.txt04 = new cjs.Text("4", "5px 'Segoe Pro'", "#474747");
	this.txt04.name = "txt04";
	this.txt04.lineHeight = 8;
	this.txt04.lineWidth = 6;
	this.txt04.parent = this;
	this.txt04.setTransform(-9.7,51.6);

	this.txt03 = new cjs.Text("3", "5px 'Segoe Pro'", "#474747");
	this.txt03.name = "txt03";
	this.txt03.lineHeight = 8;
	this.txt03.lineWidth = 6;
	this.txt03.parent = this;
	this.txt03.setTransform(-9.7,43.25);

	this.txt02 = new cjs.Text("2", "5px 'Segoe Pro'", "#474747");
	this.txt02.name = "txt02";
	this.txt02.lineHeight = 8;
	this.txt02.lineWidth = 6;
	this.txt02.parent = this;
	this.txt02.setTransform(-9.7,35.1);

	this.txt01 = new cjs.Text("1", "5px 'Segoe Pro'", "#474747");
	this.txt01.name = "txt01";
	this.txt01.lineHeight = 8;
	this.txt01.lineWidth = 6;
	this.txt01.parent = this;
	this.txt01.setTransform(-9.35,26.7);

	this.txt16 = new cjs.Text("Q", "5px 'Segoe Pro'", "#474747");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 8;
	this.txt16.lineWidth = 6;
	this.txt16.parent = this;
	this.txt16.setTransform(401.15,18.5);

	this.txt15 = new cjs.Text("P", "5px 'Segoe Pro'", "#474747");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 8;
	this.txt15.lineWidth = 6;
	this.txt15.parent = this;
	this.txt15.setTransform(376.95,18.5);

	this.txt14 = new cjs.Text("O", "5px 'Segoe Pro'", "#474747");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 8;
	this.txt14.lineWidth = 6;
	this.txt14.parent = this;
	this.txt14.setTransform(351.85,18.5);

	this.txt13 = new cjs.Text("N", "5px 'Segoe Pro'", "#474747");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 8;
	this.txt13.lineWidth = 6;
	this.txt13.parent = this;
	this.txt13.setTransform(327.05,18.5);

	this.txt12 = new cjs.Text("M", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 6;
	this.txt12.parent = this;
	this.txt12.setTransform(302,18.5);

	this.txt11 = new cjs.Text("L", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 6;
	this.txt11.parent = this;
	this.txt11.setTransform(278.35,18.5);

	this.txt10 = new cjs.Text("K", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 6;
	this.txt10.parent = this;
	this.txt10.setTransform(253.35,18.5);

	this.txt9 = new cjs.Text("J", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 6;
	this.txt9.parent = this;
	this.txt9.setTransform(229.05,18.5);

	this.txt8 = new cjs.Text("I", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 6;
	this.txt8.parent = this;
	this.txt8.setTransform(204.65,18.5);

	this.txt7 = new cjs.Text("H", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 6;
	this.txt7.parent = this;
	this.txt7.setTransform(178.85,18.5);

	this.txt6 = new cjs.Text("G", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 6;
	this.txt6.parent = this;
	this.txt6.setTransform(154.5,18.5);

	this.txt5 = new cjs.Text("F", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 6;
	this.txt5.parent = this;
	this.txt5.setTransform(130.3,18.5);

	this.txt4 = new cjs.Text("E", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 6;
	this.txt4.parent = this;
	this.txt4.setTransform(105.5,18.5);

	this.txt3 = new cjs.Text("D", "5px 'Segoe Pro'", "#474747");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 8;
	this.txt3.lineWidth = 6;
	this.txt3.parent = this;
	this.txt3.setTransform(80.45,18.5);

	this.txt2 = new cjs.Text("C", "5px 'Segoe Pro'", "#474747");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(55.95,18.5);

	this.txt1 = new cjs.Text("B", "5px 'Segoe Pro'", "#474747");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 8;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(31.3,18.5);

	this.txt = new cjs.Text("A", "5px 'Segoe Pro'", "#474747");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(6.4,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt01},{t:this.txt02},{t:this.txt03},{t:this.txt04},{t:this.txt05},{t:this.txt06},{t:this.txt07},{t:this.txt08},{t:this.txt09},{t:this.txt010},{t:this.txt011},{t:this.txt012},{t:this.txt013},{t:this.txt014},{t:this.txt015},{t:this.txt016},{t:this.txt017},{t:this.txt018},{t:this.txt019},{t:this.txt020},{t:this.txt021},{t:this.txt022},{t:this.txt023},{t:this.txt024},{t:this.txt025},{t:this.txt026},{t:this.txt027}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rowsandcells, new cjs.Rectangle(-13,16.5,422.2,232.7), null);


(lib.roundshadowshape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.roundshadow1sml();
	this.instance.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45.3), null);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bodyResize_sml();
	this.instance.setTransform(8,4,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(0,0,114,181), null);


(lib.percantage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.percent_msml();
	this.instance.setTransform(194,187,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.percantage, new cjs.Rectangle(0,0,420,420), null);


(lib.Page_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(242,242,242,0)","#F2F2F2"],[0,0.282],-143,0,283,0).s().p("EgWVAu4MAAAhdvMAsrAAAMAAABdvg");
	this.shape.setTransform(17.05,299.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_bg, new cjs.Rectangle(-125.9,0,649.6999999999999,600), null);


(lib.option_hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.2)").s().p("AzrCkIAAlHMAnXAAAIAAFHg");
	this.shape.setTransform(125.975,16.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AzrCkIAAlHMAnXAAAIAAFHg");
	this.shape_1.setTransform(125.975,16.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,252,32.8);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAIAqIAhgfIh3AAIAAgUIB3AAIghggIAbAAIAsApIgsAqg");
	this.shape.setTransform(-2.1,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-10,-4.1,15.8,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(172.2024,63.4258);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(172.2024,63.4258);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],20.7,54.8,0,20.7,54.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(172.2024,71.5759);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(0,0,344.4,135), null);


(lib.main_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
		this.txt20.textBaseline = "alphabetic"
		this.txt21.textBaseline = "alphabetic"
		this.txt22.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.txt22 = new cjs.Text("Expense", "7px 'Segoe Pro'", "#227347");
	this.txt22.name = "txt22";
	this.txt22.lineHeight = 11;
	this.txt22.lineWidth = 32;
	this.txt22.parent = this;
	this.txt22.setTransform(356.25,158);

	this.txt21 = new cjs.Text("Income", "7px 'Segoe Pro'", "#227347");
	this.txt21.name = "txt21";
	this.txt21.lineHeight = 11;
	this.txt21.lineWidth = 32;
	this.txt21.parent = this;
	this.txt21.setTransform(311.35,158);

	this.txt20 = new cjs.Text("$0", "6px 'Segoe Pro'", "#227347");
	this.txt20.name = "txt20";
	this.txt20.lineHeight = 10;
	this.txt20.lineWidth = 18;
	this.txt20.parent = this;
	this.txt20.setTransform(290,140.1);

	this.txt19 = new cjs.Text("$100", "6px 'Segoe Pro'", "#227347");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 10;
	this.txt19.lineWidth = 18;
	this.txt19.parent = this;
	this.txt19.setTransform(283.55,125.2);

	this.txt18 = new cjs.Text("$200", "6px 'Segoe Pro'", "#227347");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 10;
	this.txt18.lineWidth = 18;
	this.txt18.parent = this;
	this.txt18.setTransform(283.55,110.5);

	this.txt17 = new cjs.Text("$300", "6px 'Segoe Pro'", "#227347");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 10;
	this.txt17.lineWidth = 18;
	this.txt17.parent = this;
	this.txt17.setTransform(283.55,95.8);

	this.txt16 = new cjs.Text("$400", "6px 'Segoe Pro'", "#227347");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 10;
	this.txt16.lineWidth = 18;
	this.txt16.parent = this;
	this.txt16.setTransform(283.55,80.75);

	this.txt15 = new cjs.Text("$500", "6px 'Segoe Pro'", "#227347");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 10;
	this.txt15.lineWidth = 18;
	this.txt15.parent = this;
	this.txt15.setTransform(283.55,66.25);

	this.txt14 = new cjs.Text("$600", "6px 'Segoe Pro'", "#227347");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 10;
	this.txt14.lineWidth = 18;
	this.txt14.parent = this;
	this.txt14.setTransform(283.55,51.55);

	this.txt13 = new cjs.Text("$700", "6px 'Segoe Pro'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 10;
	this.txt13.lineWidth = 18;
	this.txt13.parent = this;
	this.txt13.setTransform(283.55,36.65);

	this.txt12 = new cjs.Text("$800", "6px 'Segoe Pro'", "#227347");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 10;
	this.txt12.lineWidth = 18;
	this.txt12.parent = this;
	this.txt12.setTransform(283.55,22.35);

	this.txt11 = new cjs.Text("$900", "6px 'Segoe Pro'", "#227347");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 10;
	this.txt11.lineWidth = 18;
	this.txt11.parent = this;
	this.txt11.setTransform(283.55,7.45);

	this.txt9 = new cjs.Text("Cash Balance", "7px 'Segoe Pro'", "#227347");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 11;
	this.txt9.lineWidth = 100;
	this.txt9.parent = this;
	this.txt9.setTransform(152.7,133.5);

	this.txt7 = new cjs.Text("Total monthly savings", "7px 'Segoe Pro'", "#227347");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 11;
	this.txt7.lineWidth = 100;
	this.txt7.parent = this;
	this.txt7.setTransform(152.7,98.7);

	this.txt5 = new cjs.Text("Total monthly expenses", "7px 'Segoe Pro'", "#227347");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 11;
	this.txt5.lineWidth = 100;
	this.txt5.parent = this;
	this.txt5.setTransform(152.7,64.1);

	this.txt10 = new cjs.Text("$130", "12px 'Segoe Pro'", "#227347");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 18;
	this.txt10.lineWidth = 100;
	this.txt10.parent = this;
	this.txt10.setTransform(152.7,150.1);

	this.txt8 = new cjs.Text("$100", "12px 'Segoe Pro'", "#227347");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 18;
	this.txt8.lineWidth = 100;
	this.txt8.parent = this;
	this.txt8.setTransform(152.7,115.5);

	this.txt6 = new cjs.Text("$670", "12px 'Segoe Pro'", "#227347");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 18;
	this.txt6.lineWidth = 100;
	this.txt6.parent = this;
	this.txt6.setTransform(152.7,80.65);

	this.txt4 = new cjs.Text("$900", "12px 'Segoe Pro'", "#227347");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 18;
	this.txt4.lineWidth = 100;
	this.txt4.parent = this;
	this.txt4.setTransform(152.7,45.85);

	this.txt3 = new cjs.Text("Total monthly income", "7px 'Segoe Pro'", "#227347");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 11;
	this.txt3.lineWidth = 100;
	this.txt3.parent = this;
	this.txt3.setTransform(152.7,29.3);

	this.txt2 = new cjs.Text("Summary", "8px 'Segoe Pro'", "#227347");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(152.7,11.2);

	this.txt1 = new cjs.Text("Percentage of income spent", "6px 'Segoe Pro'", "#B7B2A6");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 10;
	this.txt1.lineWidth = 100;
	this.txt1.parent = this;
	this.txt1.setTransform(2,26.4);

	this.txt = new cjs.Text("School Budget", "14px 'Segoe Pro'", "#227347");
	this.txt.name = "txt";
	this.txt.lineHeight = 20;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(2,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt6},{t:this.txt8},{t:this.txt10},{t:this.txt5},{t:this.txt7},{t:this.txt9},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt17},{t:this.txt18},{t:this.txt19},{t:this.txt20},{t:this.txt21},{t:this.txt22}]}).wait(1));

	// Graph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#49A166").s().p("AitJYIAAg5IA4AAIAAA5gAjBGUIAAvrIGDAAIAAPrg");
	this.shape.setTransform(365.3,97.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#337446").s().p("AjVMGIAAg4IA5AAIAAA4gAiqJCIAA1HIGAAAIAAFdIAAPqg");
	this.shape_1.setTransform(324.475,80.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E4DFD4").ss(0.3).p("ATPKLIqoABIkUAAIAAiFIAAyXAkvJ0IufAAAkvEOIufAAAkvhCIufAAAkvmfIufAA");
	this.shape_2.setTransform(271.7253,74.2752);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_txt, new cjs.Rectangle(0,3.1,395.9,166.4), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.LeafB_sml();
	this.instance.setTransform(0.15,0.55,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110.2,110.6), null);


(lib.leafA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA_sml();
	this.instance.setTransform(90.6,19.3,2.64,2.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA, new cjs.Rectangle(0,0,214.7,245.5), null);


(lib.Layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt = new cjs.Text("Budget", "5px 'Segoe Pro Semibold'", "#1C7347");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(39.3,248.65);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C7347").s().p("AiUAFIAAgIIEpAAIAAAIg");
	this.shape.setTransform(47.6,252.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.txt}]}).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#777777").s().p("AAAAFIgKgIIACgDIAIAJIAJgJIACADIgLAKg");
	this.shape_1.setTransform(445.4568,7.2001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C9C9C9").s().p("AgMAQQgEgBABgEIABgBIAGgIIAGgEIgJgGIAAgBQgDgCACgDQACgCADABIAIAKQAGgEAJgCIgNAJQAHAGAGAKQgFgFgLgJIgEAGIgEAHIAAABQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(50.8146,7.4594);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C9C9C9").s().p("AgNAVQAAAAgBgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIABABIABACIAAAAIACgCIACgDIAEgVIAAAAIgDAAIAAgBIAAgBIADAAIAAgBIABgDQACgEADgCIAFgDIADABIABACIgBACIgBAAIgCgBIgBgBIgBgBIgCABIgBAEIgBAFIgBABIAGAAIAAAAIgBACIgFAAIgEASQAAAEgCACIgEADIgEABg");
	this.shape_3.setTransform(74.0886,7.4251);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C9C9C9").s().p("AACAIIgCgBIAAgFIAAAAIgCAEIgCACIgDAAIgBgBQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAABAAIABAAIABAAIADgDIAAgBIABgBIgCgDIAAgBIgCgBIgBAAIgBAAIAAAAIABgBIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABABIABAFIAAAAIAAAAIACgDIACgCIACgBIACABIAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgDAEIAAAAIABAEIACACIABAAIACAAIAAABIgDABg");
	this.shape_4.setTransform(75.4618,8.0251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#C9C9C9").ss(0.5,1).p("AATgNQgSARgFAKQgBABgBgBIgMgM");
	this.shape_5.setTransform(63.0759,7.3251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAGAAIAAAFg");
	this.shape_6.setTransform(39.8006,8.7251);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAGAAIAAAGg");
	this.shape_7.setTransform(39.8006,7.4001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B3B3B3").s().p("AgDADIAAgGIAGAAIAAAGg");
	this.shape_8.setTransform(39.8006,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5F6060").s().p("AgNgGIAbAAIgOANg");
	this.shape_9.setTransform(31.3005,7.1001);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#C5C5C5").ss(0.3).p("AclAqMg5JAAAIAAhTMA5JAAAg");
	this.shape_10.setTransform(265.179,7.4251);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A8kAqIAAhTMA5JAAAIAABTg");
	this.shape_11.setTransform(265.179,7.4251);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C5C5C5").ss(0.3).p("ACzAqIllAAIAAhTIFlAAg");
	this.shape_12.setTransform(62.6509,7.4251);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiyAqIAAhTIFmAAIAABTg");
	this.shape_13.setTransform(62.6509,7.4251);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#C5C5C5").ss(0.3).p("ACnAqIlNAAIAAhTIFNAAg");
	this.shape_14.setTransform(18.0503,7.4251);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimAqIAAhTIFNAAIAABTg");
	this.shape_15.setTransform(18.0503,7.4251);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#787878").s().p("AgGAAIANgNIAAAbg");
	this.shape_16.setTransform(9.4,248.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#787878").s().p("AgGgNIANANIgNAOg");
	this.shape_17.setTransform(18.975,248.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#787878").s().p("AgCAOIAAgLIgLAAIAAgFIALAAIAAgLIAEAAIAAALIAMAAIAAAFIgMAAIAAALg");
	this.shape_18.setTransform(69.425,248.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#787878").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIgAgRgRQgHAIAAAJQAAAKAHAHQAIAIAJAAQAKAAAIgIQAHgHAAgKQAAgJgHgIQgIgHgKAAQgJAAgIAHg");
	this.shape_19.setTransform(69.425,248.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#999999").s().p("A9PSuIAAhUIlIAAIAAgDIBQAAIAAgNIhQAAIAAgDIBQAAIAAhVIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhOIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhCIADAAIAABCID2AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID0AAIAAhCIADAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIDyAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCIDzAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIB4AAMAAAAjEMg69AAAIAABUgEghEARXID3AAIAABUIElAAIAAhUMA6+AAAMAAAgi+MhDaAAAg");
	this.shape_20.setTransform(220.0284,133.1024);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B4B4B4").s().p("AgTAUIAngnIAAAng");
	this.shape_21.setTransform(5.125,16.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E6E6E6").s().p("EgjJAT0MAAAgnnMBGTAAAMAAAAnngEgh2ASYID2AAIAABUIEpAAIAAhUMA67AAAMAAAgjBMhDaAAAg");
	this.shape_22.setTransform(225,126.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Layout, new cjs.Rectangle(0,0,450,259.3), null);


(lib.image01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrightcontributionsml();
	this.instance.setTransform(-0.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel_icon_sml();
	this.instance.setTransform(16.5,28.85,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0,0,129.6,125.7), null);


(lib.hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.grass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Grass_sml();
	this.instance.setTransform(371.2,0.5,2.5,2.4999,0,0,180);

	this.instance_1 = new lib.Grass_sml();
	this.instance_1.setTransform(0.7,0.55,2.4999,2.4999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass, new cjs.Rectangle(0,0,372.1,126), null);


(lib.graphGreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#459F69").s().p("AmYGZQiqipAAjwQAAjuCqiqQCpiqDvAAQDvAACqCqQCqCqAADuQAADwiqCpIAAABQiqCpjvAAQjvAAipiqgAmiAAQAACuB7B6QB6B7CtAAQCtAAB7h7QB7h6AAiuQAAish7h7Qh7h7itAAQitAAh6B7IAAAAQh7B7AACsg");
	this.shape.setTransform(57.875,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphGreen, new cjs.Rectangle(0,0,115.8,115.8), null);


(lib.firstimage_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(-1.05,-0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(-1,-0.9,84,53), null);


(lib.fill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlrighticonsml();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girllefticonsml();
	this.instance.setTransform(-0.15,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(-0.1,-0.2,51.1,43.2), null);


(lib.face02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guylefticonsml();
	this.instance.setTransform(0.1,0.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52.1,41.1), null);


(lib.face01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrighticon1sml();
	this.instance.setTransform(-0.05,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,-0.1,53,43.1), null);


(lib.excel_screen_white_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjMASVMAAAgkpMBGZAAAMAAAAkpg");
	this.shape.setTransform(225.25,141.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white_sub, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.ribboncopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AjoLAIA3gTIGaSuIg3ASg");
	var mask_graphics_69 = new cjs.Graphics().p("As4K5IT3m1IF6S4Iz3G1g");
	var mask_graphics_70 = new cjs.Graphics().p("A0cKyMAjbgMKIFeTBMgjbAMMg");
	var mask_graphics_71 = new cjs.Graphics().p("A6gKuMAv5gQeIFITJMgv5AQeg");
	var mask_graphics_72 = new cjs.Graphics().p("A/PKqMA5ngT0IE4TPMg5nAT0g");
	var mask_graphics_73 = new cjs.Graphics().p("EgiyAKnMBA6gWVIErTTMhA6AWWg");
	var mask_graphics_74 = new cjs.Graphics().p("EglUAKlMBGIgYIIEhTWMhGIAYJg");
	var mask_graphics_75 = new cjs.Graphics().p("EgnBAKjMBJogZVIEbTYMhJoAZXg");
	var mask_graphics_76 = new cjs.Graphics().p("EgoEAKjMBLxgaFIEYTaMhLxAaFg");
	var mask_graphics_77 = new cjs.Graphics().p("EgomAKiMBM3gacIEWTaMhM3Aadg");
	var mask_graphics_78 = new cjs.Graphics().p("EgoyAKiMBNQgalIEVTaMhNQAamg");
	var mask_graphics_79 = new cjs.Graphics().p("Ego0AKdMBNUganIEVTbMhNUAang");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:-0.4538,y:190.1462}).wait(1).to({graphics:mask_graphics_69,x:59.7933,y:190.5388}).wait(1).to({graphics:mask_graphics_70,x:109.1132,y:190.8607}).wait(1).to({graphics:mask_graphics_71,x:148.6014,y:191.1186}).wait(1).to({graphics:mask_graphics_72,x:179.3524,y:191.3196}).wait(1).to({graphics:mask_graphics_73,x:202.4596,y:191.4708}).wait(1).to({graphics:mask_graphics_74,x:219.0161,y:191.5791}).wait(1).to({graphics:mask_graphics_75,x:230.114,y:191.6517}).wait(1).to({graphics:mask_graphics_76,x:236.8453,y:191.6958}).wait(1).to({graphics:mask_graphics_77,x:240.3019,y:191.7184}).wait(1).to({graphics:mask_graphics_78,x:241.5754,y:191.7268}).wait(1).to({graphics:mask_graphics_79,x:244.6351,y:191.2331}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvElgIesAAI/PLBg");
	this.shape.setTransform(132.0234,325.0216,1.2376,1.2376);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("EglBAE6MBJrgaJIAYRVMhHIAZKg");
	this.shape_1.setTransform(241.375,227.65);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_58 = new cjs.Graphics().p("Ab0fwIAFzbIAgAAIgFTbg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AbpfwIAFzbIArAAIgFTbg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AadfwIAIzbIB1AAIgHTbg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AXPfwIANzbIFAAAIgNTbg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AQ+fvIAYzbILJABIgYTbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AGpfuIApzbIVTACIgqTbg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AnXftIBBzcMAjCAAEIhBTcg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AxsfsIBTzcMAtLAAFIhTTcg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A3+frIBezbMAzVAAFIheTcg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A7LfrIBjzcMA2fAAHIhjTbg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A8XfqIBlzbMA3qAAHIhmTbg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A8tfqIBmzbMA31AAGIhmTbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_1_graphics_58,x:181.737,y:203.2391}).wait(1).to({graphics:mask_1_graphics_59,x:181.7462,y:203.2395}).wait(1).to({graphics:mask_1_graphics_60,x:181.8103,y:203.2398}).wait(1).to({graphics:mask_1_graphics_61,x:181.9843,y:203.2408}).wait(1).to({graphics:mask_1_graphics_62,x:182.3231,y:203.2427}).wait(1).to({graphics:mask_1_graphics_63,x:182.8817,y:203.2459}).wait(1).to({graphics:mask_1_graphics_64,x:183.6395,y:203.2502}).wait(1).to({graphics:mask_1_graphics_65,x:184.1981,y:203.2533}).wait(1).to({graphics:mask_1_graphics_66,x:184.5369,y:203.2552}).wait(1).to({graphics:mask_1_graphics_67,x:184.7109,y:203.2562}).wait(1).to({graphics:mask_1_graphics_68,x:184.775,y:203.2566}).wait(1).to({graphics:mask_1_graphics_69,x:180.4565,y:203.2108}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("APTmxIDCNZMgkpAAKg");
	this.shape_2.setTransform(243.25,338);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(58).to({_off:false},0).wait(22));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A8NoLMA1ZgABIDCQTMg1TAAGg");
	this.shape_3.setTransform(176.025,328.95);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_29 = new cjs.Graphics().p("A3icnIDShIIHHU/IjRBIg");
	var mask_2_graphics_30 = new cjs.Graphics().p("A3ecgIJ3jZIG8VDIp3DZg");
	var mask_2_graphics_31 = new cjs.Graphics().p("A3bcaIQZlpIGxVHIwZFog");
	var mask_2_graphics_32 = new cjs.Graphics().p("A3YcTIW0n2IGkVLI2yH2g");
	var mask_2_graphics_33 = new cjs.Graphics().p("A3UcNIdAp/IGbVOI9BJ/g");
	var mask_2_graphics_34 = new cjs.Graphics().p("A3RcHMAjAgMDIGQVSMgjAAMDg");
	var mask_2_graphics_35 = new cjs.Graphics().p("A3ZcBMAotgOBIGGVWMgotAOBg");
	var mask_2_graphics_36 = new cjs.Graphics().p("A6Bb8MAuGgP4IF9VZMguGAP4g");
	var mask_2_graphics_37 = new cjs.Graphics().p("A8eb3MAzJgRnIF0VcMgzJARmg");
	var mask_2_graphics_38 = new cjs.Graphics().p("A+wbyMA31gTOIFsVfMg31ATOg");
	var mask_2_graphics_39 = new cjs.Graphics().p("Egg3AbuMA8LgUuIFkVhMg8LAUug");
	var mask_2_graphics_40 = new cjs.Graphics().p("Egi0AbqMBAMgWGIFdVjMhAMAWGg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgknAbmMBD4gXXIFXVmMhD4AXXg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgmQAbjMBHQgYiIFRVoMhHQAYhg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgnwAbfMBKVgZlIFMVpMhKVAZmg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgpIAbdMBNKgakIFHVrMhNKAakg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgqZAbaMBPwgbcIFDVsMhPwAbdg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgriAbYMBSHgcRIE+VuMhSHAcRg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgslAbVMBURgc/IE6VuMhURAdBg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EgtjAbTMBWQgdrIE3VwMhWQAdsg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EgubAbSMBYDgeTIE0VxMhYDAeUg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgvOAbQMBZsge3IExVyMhZsAe4g");
	var mask_2_graphics_51 = new cjs.Graphics().p("Egv8AbPMBbLgfYIEuVyMhbLAfZg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EgwnAbNMBcjgf2IEsV0MhcjAf3g");
	var mask_2_graphics_53 = new cjs.Graphics().p("EgxNAbMMBdxggRIEqV0MhdxAgSg");
	var mask_2_graphics_54 = new cjs.Graphics().p("EgxwAbLMBe5ggqIEoV1Mhe5Agrg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EgyQAbKMBf7ghBIEmV2Mhf7AhBg");
	var mask_2_graphics_56 = new cjs.Graphics().p("EgytAbJMBg2ghVIElV2Mhg2AhWg");
	var mask_2_graphics_57 = new cjs.Graphics().p("EgzHAbIMBhsghnIEjV2MhhsAhpg");
	var mask_2_graphics_58 = new cjs.Graphics().p("EgzeAbHMBibgh4IEiV4MhibAh4g");
	var mask_2_graphics_59 = new cjs.Graphics().p("EgzzAbHMBjGgiHIEhV4MhjGAiHg");
	var mask_2_graphics_60 = new cjs.Graphics().p("Eg0GAbGMBjtgiUIEgV4MhjtAiVg");
	var mask_2_graphics_61 = new cjs.Graphics().p("Eg0WAbFMBkPgigIEeV4MhkPAihg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_2_graphics_29,x:-150.6661,y:317.3771}).wait(1).to({graphics:mask_2_graphics_30,x:-150.3289,y:317.1112}).wait(1).to({graphics:mask_2_graphics_31,x:-149.9949,y:316.8479}).wait(1).to({graphics:mask_2_graphics_32,x:-149.6672,y:316.5896}).wait(1).to({graphics:mask_2_graphics_33,x:-149.3487,y:316.3386}).wait(1).to({graphics:mask_2_graphics_34,x:-149.0425,y:316.0971}).wait(1).to({graphics:mask_2_graphics_35,x:-147.6719,y:315.8672}).wait(1).to({graphics:mask_2_graphics_36,x:-130.3589,y:315.6501}).wait(1).to({graphics:mask_2_graphics_37,x:-114.1421,y:315.4467}).wait(1).to({graphics:mask_2_graphics_38,x:-99.0511,y:315.2575}).wait(1).to({graphics:mask_2_graphics_39,x:-85.0816,y:315.0824}).wait(1).to({graphics:mask_2_graphics_40,x:-72.2024,y:314.9209}).wait(1).to({graphics:mask_2_graphics_41,x:-60.3645,y:314.7725}).wait(1).to({graphics:mask_2_graphics_42,x:-49.5073,y:314.6363}).wait(1).to({graphics:mask_2_graphics_43,x:-39.5647,y:314.5117}).wait(1).to({graphics:mask_2_graphics_44,x:-30.4692,y:314.3976}).wait(1).to({graphics:mask_2_graphics_45,x:-22.1544,y:314.2934}).wait(1).to({graphics:mask_2_graphics_46,x:-14.557,y:314.1981}).wait(1).to({graphics:mask_2_graphics_47,x:-7.618,y:314.1111}).wait(1).to({graphics:mask_2_graphics_48,x:-1.2825,y:314.0317}).wait(1).to({graphics:mask_2_graphics_49,x:4.4996,y:313.9592}).wait(1).to({graphics:mask_2_graphics_50,x:9.7738,y:313.8931}).wait(1).to({graphics:mask_2_graphics_51,x:14.5815,y:313.8328}).wait(1).to({graphics:mask_2_graphics_52,x:18.9602,y:313.7779}).wait(1).to({graphics:mask_2_graphics_53,x:22.9436,y:313.728}).wait(1).to({graphics:mask_2_graphics_54,x:26.5623,y:313.6826}).wait(1).to({graphics:mask_2_graphics_55,x:29.8439,y:313.6415}).wait(1).to({graphics:mask_2_graphics_56,x:32.8133,y:313.6042}).wait(1).to({graphics:mask_2_graphics_57,x:35.4932,y:313.5707}).wait(1).to({graphics:mask_2_graphics_58,x:37.904,y:313.5404}).wait(1).to({graphics:mask_2_graphics_59,x:40.0644,y:313.5133}).wait(1).to({graphics:mask_2_graphics_60,x:41.9911,y:313.4892}).wait(1).to({graphics:mask_2_graphics_61,x:44.4247,y:313.3925}).wait(19));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("Egw4AHrMBdyghfID/REMhgQAilg");
	this.shape_4.setTransform(55.425,469.025);
	this.shape_4._off = true;

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(29).to({_off:false},0).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-257.5,91.6,735.9,542.6999999999999);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AjQYuIAUgZIGvFlIgVAZg");
	var mask_graphics_69 = new cjs.Graphics().p("Am8YvIHppSIGwFlInpJSg");
	var mask_graphics_70 = new cjs.Graphics().p("Ap9YvINqwjIGwFlItqQjg");
	var mask_graphics_71 = new cjs.Graphics().p("AsXYwISe2YIGvFlIyeWYg");
	var mask_graphics_72 = new cjs.Graphics().p("AuQYwIWO65IGwFkI2Oa6g");
	var mask_graphics_73 = new cjs.Graphics().p("AvqYxIZC+TIGwFjI5DeVg");
	var mask_graphics_74 = new cjs.Graphics().p("AwrYxMAbEggvIGvFkMgbEAgwg");
	var mask_graphics_75 = new cjs.Graphics().p("AxXYxMAcbgiYIGwFlMgcbAiYg");
	var mask_graphics_76 = new cjs.Graphics().p("AxxYxMAdPgjXIGwFkMgdQAjYg");
	var mask_graphics_77 = new cjs.Graphics().p("Ax/YxMAdrgj4IGvFlMgdqAj4g");
	var mask_graphics_78 = new cjs.Graphics().p("AyEYxMAd1gkEIGvFlMgd0AkEg");
	var mask_graphics_79 = new cjs.Graphics().p("Ax+YqMAd2gkGIGvFlMgd2AkGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:24.2809,y:193.8672}).wait(1).to({graphics:mask_graphics_69,x:47.6914,y:193.9525}).wait(1).to({graphics:mask_graphics_70,x:66.8675,y:194.0224}).wait(1).to({graphics:mask_graphics_71,x:82.2285,y:194.0783}).wait(1).to({graphics:mask_graphics_72,x:94.1953,y:194.1219}).wait(1).to({graphics:mask_graphics_73,x:103.1902,y:194.1546}).wait(1).to({graphics:mask_graphics_74,x:109.6365,y:194.178}).wait(1).to({graphics:mask_graphics_75,x:113.9582,y:194.1937}).wait(1).to({graphics:mask_graphics_76,x:116.5797,y:194.2033}).wait(1).to({graphics:mask_graphics_77,x:117.926,y:194.2082}).wait(1).to({graphics:mask_graphics_78,x:118.422,y:194.21}).wait(1).to({graphics:mask_graphics_79,x:119.1199,y:193.4922}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(88.9294,327.8805,0.7597,0.7255,0,-29.6757,-31.2351);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_68 = new cjs.Graphics().p("AjQYuIAUgZIGvFlIgVAZg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Am8YvIHppSIGwFlInpJSg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ap9YvINqwjIGwFlItqQjg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AsXYwISe2YIGvFlIyeWYg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AuQYwIWO65IGwFkI2Oa6g");
	var mask_1_graphics_73 = new cjs.Graphics().p("AvqYxIZC+TIGwFjI5DeVg");
	var mask_1_graphics_74 = new cjs.Graphics().p("AwrYxMAbEggvIGvFkMgbEAgwg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AxXYxMAcbgiYIGwFlMgcbAiYg");
	var mask_1_graphics_76 = new cjs.Graphics().p("AxxYxMAdPgjXIGwFkMgdQAjYg");
	var mask_1_graphics_77 = new cjs.Graphics().p("Ax/YxMAdrgj4IGvFlMgdqAj4g");
	var mask_1_graphics_78 = new cjs.Graphics().p("AyEYxMAd1gkEIGvFlMgd0AkEg");
	var mask_1_graphics_79 = new cjs.Graphics().p("Ax+YqMAd2gkGIGvFlMgd2AkGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_1_graphics_68,x:24.2809,y:193.8672}).wait(1).to({graphics:mask_1_graphics_69,x:47.6914,y:193.9525}).wait(1).to({graphics:mask_1_graphics_70,x:66.8675,y:194.0224}).wait(1).to({graphics:mask_1_graphics_71,x:82.2285,y:194.0783}).wait(1).to({graphics:mask_1_graphics_72,x:94.1953,y:194.1219}).wait(1).to({graphics:mask_1_graphics_73,x:103.1902,y:194.1546}).wait(1).to({graphics:mask_1_graphics_74,x:109.6365,y:194.178}).wait(1).to({graphics:mask_1_graphics_75,x:113.9582,y:194.1937}).wait(1).to({graphics:mask_1_graphics_76,x:116.5797,y:194.2033}).wait(1).to({graphics:mask_1_graphics_77,x:117.926,y:194.2082}).wait(1).to({graphics:mask_1_graphics_78,x:118.422,y:194.21}).wait(1).to({graphics:mask_1_graphics_79,x:119.1199,y:193.4922}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(124.7675,248.9843,0.7606,0.7264,0,-29.6759,-31.2354);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_52 = new cjs.Graphics().p("AMvPIIAygbIEEHwIgyAag");
	var mask_2_graphics_53 = new cjs.Graphics().p("AMtPIIA0gbIEEHvIgzAcg");
	var mask_2_graphics_54 = new cjs.Graphics().p("AMjPLIA+ghIEFHwIg/Agg");
	var mask_2_graphics_55 = new cjs.Graphics().p("AMGPSIBbgvIEFHvIhbAwg");
	var mask_2_graphics_56 = new cjs.Graphics().p("ALPPhICShNIEFHwIiSBMg");
	var mask_2_graphics_57 = new cjs.Graphics().p("AJ1P4IDsh8IEFHwIjtB8g");
	var mask_2_graphics_58 = new cjs.Graphics().p("AHtQcIF0jDIEFHvIl0DEg");
	var mask_2_graphics_59 = new cjs.Graphics().p("AEwROIIxknIEFHwIoxEmg");
	var mask_2_graphics_60 = new cjs.Graphics().p("AA1SQIMsmrIEFHwIssGqg");
	var mask_2_graphics_61 = new cjs.Graphics().p("Aj6TfIRbpKIEFHwIxcJKg");
	var mask_2_graphics_62 = new cjs.Graphics().p("An1UhIVWrOIEFHvI1WLPg");
	var mask_2_graphics_63 = new cjs.Graphics().p("AqyVTIYTsyIEFHwI4TMyg");
	var mask_2_graphics_64 = new cjs.Graphics().p("As5V3Iaat6IEFHwI6bN5g");
	var mask_2_graphics_65 = new cjs.Graphics().p("AuUWPIb1upIEFHvI71Opg");
	var mask_2_graphics_66 = new cjs.Graphics().p("AvLWdIcsvGIEFHwI8sPGg");
	var mask_2_graphics_67 = new cjs.Graphics().p("AvnWlIdIvVIEFHvI9JPVg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AvyWnIdTvaIEFHwI9TPag");
	var mask_2_graphics_69 = new cjs.Graphics().p("Av2WqIdUvbIEFHvI9VPbg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_2_graphics_52,x:112.55,y:146.3209}).wait(1).to({graphics:mask_2_graphics_53,x:112.5501,y:146.3601}).wait(1).to({graphics:mask_2_graphics_54,x:112.5504,y:146.6334}).wait(1).to({graphics:mask_2_graphics_55,x:112.5513,y:147.3755}).wait(1).to({graphics:mask_2_graphics_56,x:112.5529,y:148.8207}).wait(1).to({graphics:mask_2_graphics_57,x:112.5557,y:151.2035}).wait(1).to({graphics:mask_2_graphics_58,x:112.5599,y:154.7584}).wait(1).to({graphics:mask_2_graphics_59,x:112.5657,y:159.7203}).wait(1).to({graphics:mask_2_graphics_60,x:112.5733,y:166.3245}).wait(1).to({graphics:mask_2_graphics_61,x:112.5826,y:174.3081}).wait(1).to({graphics:mask_2_graphics_62,x:112.5903,y:180.9155}).wait(1).to({graphics:mask_2_graphics_63,x:112.5961,y:185.8817}).wait(1).to({graphics:mask_2_graphics_64,x:112.6003,y:189.4407}).wait(1).to({graphics:mask_2_graphics_65,x:112.603,y:191.8266}).wait(1).to({graphics:mask_2_graphics_66,x:112.6047,y:193.2739}).wait(1).to({graphics:mask_2_graphics_67,x:112.6056,y:194.0171}).wait(1).to({graphics:mask_2_graphics_68,x:112.6059,y:194.291}).wait(1).to({graphics:mask_2_graphics_69,x:112.275,y:194.532}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(146.4675,300.3025,0.7432,0.7432,-28.9415);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(52).to({_off:false},0).wait(28));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_52 = new cjs.Graphics().p("AMvPIIAygbIEEHwIgyAag");
	var mask_3_graphics_53 = new cjs.Graphics().p("AMtPIIA0gbIEEHvIgzAcg");
	var mask_3_graphics_54 = new cjs.Graphics().p("AMjPLIA+ghIEFHwIg/Agg");
	var mask_3_graphics_55 = new cjs.Graphics().p("AMGPSIBbgvIEFHvIhbAwg");
	var mask_3_graphics_56 = new cjs.Graphics().p("ALPPhICShNIEFHwIiSBMg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AJ1P4IDsh8IEFHwIjtB8g");
	var mask_3_graphics_58 = new cjs.Graphics().p("AHtQcIF0jDIEFHvIl0DEg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AEwROIIxknIEFHwIoxEmg");
	var mask_3_graphics_60 = new cjs.Graphics().p("AA1SQIMsmrIEFHwIssGqg");
	var mask_3_graphics_61 = new cjs.Graphics().p("Aj6TfIRbpKIEFHwIxcJKg");
	var mask_3_graphics_62 = new cjs.Graphics().p("An1UhIVWrOIEFHvI1WLPg");
	var mask_3_graphics_63 = new cjs.Graphics().p("AqyVTIYTsyIEFHwI4TMyg");
	var mask_3_graphics_64 = new cjs.Graphics().p("As5V3Iaat6IEFHwI6bN5g");
	var mask_3_graphics_65 = new cjs.Graphics().p("AuUWPIb1upIEFHvI71Opg");
	var mask_3_graphics_66 = new cjs.Graphics().p("AvLWdIcsvGIEFHwI8sPGg");
	var mask_3_graphics_67 = new cjs.Graphics().p("AvnWlIdIvVIEFHvI9JPVg");
	var mask_3_graphics_68 = new cjs.Graphics().p("AvyWnIdTvaIEFHwI9TPag");
	var mask_3_graphics_69 = new cjs.Graphics().p("Av2WqIdUvbIEFHvI9VPbg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(52).to({graphics:mask_3_graphics_52,x:112.55,y:146.3209}).wait(1).to({graphics:mask_3_graphics_53,x:112.5501,y:146.3601}).wait(1).to({graphics:mask_3_graphics_54,x:112.5504,y:146.6334}).wait(1).to({graphics:mask_3_graphics_55,x:112.5513,y:147.3755}).wait(1).to({graphics:mask_3_graphics_56,x:112.5529,y:148.8207}).wait(1).to({graphics:mask_3_graphics_57,x:112.5557,y:151.2035}).wait(1).to({graphics:mask_3_graphics_58,x:112.5599,y:154.7584}).wait(1).to({graphics:mask_3_graphics_59,x:112.5657,y:159.7203}).wait(1).to({graphics:mask_3_graphics_60,x:112.5733,y:166.3245}).wait(1).to({graphics:mask_3_graphics_61,x:112.5826,y:174.3081}).wait(1).to({graphics:mask_3_graphics_62,x:112.5903,y:180.9155}).wait(1).to({graphics:mask_3_graphics_63,x:112.5961,y:185.8817}).wait(1).to({graphics:mask_3_graphics_64,x:112.6003,y:189.4407}).wait(1).to({graphics:mask_3_graphics_65,x:112.603,y:191.8266}).wait(1).to({graphics:mask_3_graphics_66,x:112.6047,y:193.2739}).wait(1).to({graphics:mask_3_graphics_67,x:112.6056,y:194.0171}).wait(1).to({graphics:mask_3_graphics_68,x:112.6059,y:194.291}).wait(1).to({graphics:mask_3_graphics_69,x:112.275,y:194.532}).wait(11));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(117.4926,316.3249,0.7432,0.7432,-28.9415);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(52).to({_off:false},0).wait(28));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_29 = new cjs.Graphics().p("EgDtAkCIAug3IGtFoIguA3g");
	var mask_4_graphics_30 = new cjs.Graphics().p("EgFqAkCIEpljIGsFoIkpFjg");
	var mask_4_graphics_31 = new cjs.Graphics().p("EgHdAkCIIOp1IGtFoIoOJ0g");
	var mask_4_graphics_32 = new cjs.Graphics().p("EgJGAkCILgtwIGtFoIrgNvg");
	var mask_4_graphics_33 = new cjs.Graphics().p("EgKlAkCIOexUIGtFoIueRTg");
	var mask_4_graphics_34 = new cjs.Graphics().p("EgL8AkBIRM0hIGtFoIxMUhg");
	var mask_4_graphics_35 = new cjs.Graphics().p("EgNKAkBITn3aIGuFoIznXag");
	var mask_4_graphics_36 = new cjs.Graphics().p("EgOPAkBIVy6AIGtFnI1yaBg");
	var mask_4_graphics_37 = new cjs.Graphics().p("EgPNAkBIXu8UIGtFoI3ucUg");
	var mask_4_graphics_38 = new cjs.Graphics().p("EgQEAkBIZb+WIGuFoI5beWg");
	var mask_4_graphics_39 = new cjs.Graphics().p("EgQzAkBMAa6ggIIGtFoMga6AgIg");
	var mask_4_graphics_40 = new cjs.Graphics().p("EgRdAkBMAcOghrIGtFoMgcOAhrg");
	var mask_4_graphics_41 = new cjs.Graphics().p("EgSAAkBMAdUgjAIGtFoMgdUAjAg");
	var mask_4_graphics_42 = new cjs.Graphics().p("EgSeAkBMAeQgkGIGtFmMgeQAkIg");
	var mask_4_graphics_43 = new cjs.Graphics().p("EgS3AkBMAfCglCIGtFnMgfCAlDg");
	var mask_4_graphics_44 = new cjs.Graphics().p("EgTMAkBMAfsglzIGtFnMgfsAl0g");
	var mask_4_graphics_45 = new cjs.Graphics().p("EgTcAkBMAgMgmaIGtFmMggMAmcg");
	var mask_4_graphics_46 = new cjs.Graphics().p("EgTpAkBMAgmgm5IGtFnMggmAm6g");
	var mask_4_graphics_47 = new cjs.Graphics().p("EgTzAkBMAg6gnQIGtFnMgg6AnRg");
	var mask_4_graphics_48 = new cjs.Graphics().p("EgT6AkBMAhIgngIGtFnMghIAnhg");
	var mask_4_graphics_49 = new cjs.Graphics().p("EgT+AkBMAhQgnrIGtFmMghQAntg");
	var mask_4_graphics_50 = new cjs.Graphics().p("EgUBAkBMAhWgnyIGtFnMghWAnzg");
	var mask_4_graphics_51 = new cjs.Graphics().p("EgUDAkBMAhZgn1IGuFmMghZAn3g");
	var mask_4_graphics_52 = new cjs.Graphics().p("EgUDAkBMAhagn3IGtFnMghaAn4g");
	var mask_4_graphics_53 = new cjs.Graphics().p("EgUDAj9MAhagn3IGtFnMghaAn4g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_4_graphics_29,x:-9.4397,y:266.5616}).wait(1).to({graphics:mask_4_graphics_30,x:3.1171,y:266.5523}).wait(1).to({graphics:mask_4_graphics_31,x:14.6291,y:266.5437}).wait(1).to({graphics:mask_4_graphics_32,x:25.1414,y:266.5358}).wait(1).to({graphics:mask_4_graphics_33,x:34.6993,y:266.5286}).wait(1).to({graphics:mask_4_graphics_34,x:43.3481,y:266.5222}).wait(1).to({graphics:mask_4_graphics_35,x:51.1333,y:266.5164}).wait(1).to({graphics:mask_4_graphics_36,x:58.1001,y:266.5112}).wait(1).to({graphics:mask_4_graphics_37,x:64.2939,y:266.5065}).wait(1).to({graphics:mask_4_graphics_38,x:69.7601,y:266.5024}).wait(1).to({graphics:mask_4_graphics_39,x:74.5441,y:266.4989}).wait(1).to({graphics:mask_4_graphics_40,x:78.6914,y:266.4958}).wait(1).to({graphics:mask_4_graphics_41,x:82.2474,y:266.4931}).wait(1).to({graphics:mask_4_graphics_42,x:85.2575,y:266.4908}).wait(1).to({graphics:mask_4_graphics_43,x:87.7673,y:266.489}).wait(1).to({graphics:mask_4_graphics_44,x:89.8221,y:266.4874}).wait(1).to({graphics:mask_4_graphics_45,x:91.4675,y:266.4862}).wait(1).to({graphics:mask_4_graphics_46,x:92.749,y:266.4852}).wait(1).to({graphics:mask_4_graphics_47,x:93.712,y:266.4845}).wait(1).to({graphics:mask_4_graphics_48,x:94.402,y:266.484}).wait(1).to({graphics:mask_4_graphics_49,x:94.8646,y:266.4837}).wait(1).to({graphics:mask_4_graphics_50,x:95.1451,y:266.4835}).wait(1).to({graphics:mask_4_graphics_51,x:95.2892,y:266.4833}).wait(1).to({graphics:mask_4_graphics_52,x:95.3423,y:266.4833}).wait(1).to({graphics:mask_4_graphics_53,x:96.0156,y:266.0866}).wait(27));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.008)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_4.setTransform(98,306);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_5.setTransform(80.1549,412.7901,0.7432,0.7432,-28.9415);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_5}]},29).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,6,300.8,600);


(lib.Icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.PPT_icon_sml();
	this.instance.setTransform(-7.75,-6.45,0.82,0.82);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon, new cjs.Rectangle(-7.7,-6.4,168.79999999999998,128), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Render0116();
	this.instance.setTransform(-2.6,17.85);

	this.instance_1 = new lib.Render0115sml();
	this.instance_1.setTransform(14.8,46.2,2,2);

	this.instance_2 = new lib.Render0114sml();
	this.instance_2.setTransform(14.65,45.45,2,2);

	this.instance_3 = new lib.Render0113sml();
	this.instance_3.setTransform(15.05,43.7,2,2);

	this.instance_4 = new lib.Render0112sml();
	this.instance_4.setTransform(15,40.15,2,2);

	this.instance_5 = new lib.Render0111sml();
	this.instance_5.setTransform(15.65,38.25,2,2);

	this.instance_6 = new lib.Render0110sml();
	this.instance_6.setTransform(15.9,34.3,2,2);

	this.instance_7 = new lib.Render0109sml();
	this.instance_7.setTransform(17.2,26.35,2,2);

	this.instance_8 = new lib.Render0108();
	this.instance_8.setTransform(-2.6,17.85);

	this.instance_9 = new lib.Render0117();
	this.instance_9.setTransform(-2.6,17.85);

	this.instance_10 = new lib.Render0118();
	this.instance_10.setTransform(-2.6,17.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance_2}]},3).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_7}]},7).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance_9}]},4).to({state:[{t:this.instance_10}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.6,17.9,100,151);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.circleSegment = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkgEMQAHjiCiihQCoipDwgBIAAJCg");
	mask.setTransform(28.925,28.95);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#36724B").ss(16,1,1).p("AHzAAQAADPiSCSQiTCSjOAAQjOAAiSiSQiSiSAAjPQAAjNCSiSQCSiTDOAAQDOAACTCTQCSCSAADNg");
	this.shape.setTransform(57.8259,57.8759);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circleSegment, new cjs.Rectangle(0,0,57.9,57.9), null);


(lib.circle_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.498)","rgba(0,0,0,0.247)","rgba(0,0,0,0.039)","rgba(0,0,0,0)"],[0.239,0.502,0.769,1],-0.1,-0.1,0,-0.1,-0.1,54.1).s().p("Al8F7QicidAAjeQAAjeCcieQCeicDeAAQDeAACdCcQCeCeAADeQAADeieCdQidCejeAAQjeAAieieg");
	this.shape.setTransform(128.5,128.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#000000","rgba(0,0,0,0.322)","rgba(0,0,0,0.047)","rgba(0,0,0,0)"],[0.769,0.875,0.945,0.976],0,0,0,0,0,130.4).s().p("AuMONQl4l5AAoUQAAoUF4l4QF4l4IUAAQIVAAF3F4QF5F4AAIUQAAIUl5F5Ql3F4oVAAQoUAAl4l4gAq4q4QkgEhAAGXQAAGYEgEhQEhEgGXAAQGYAAEgkgQEgkhABmYQgBmXkgkhQkgkgmYAAQmXAAkhEgg");
	this.shape_1.setTransform(128.5,128.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.039)","rgba(0,0,0,0.247)","#000000"],[0.655,0.718,0.808,1],0,0,0,0,0,80.1).s().p("AoyIyQjojpAAlJQAAlJDojpQDpjoFJAAQFJAADpDoQDpDpAAFJQAAFJjpDpQjpDplJAAQlJAAjpjpg");
	this.shape_2.setTransform(128.45,128.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Aq4K5QkgkhAAmYQAAmXEgkhQEhkgGXAAQGYAAEgEgQEhEhAAGXQAAGYkhEhQkgEgmYAAQmXAAkhkggAoyoyQjoDpAAFJQAAFJDoDpQDpDpFJAAQFJAADpjpQDpjpAAlJQAAlJjpjpQjpjolJAAQlJAAjpDog");
	this.shape_3.setTransform(128.45,128.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circle_shadow, new cjs.Rectangle(0,0,257,257), null);


(lib.chart_mask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApOJ2IAAzrIScAAIAATrg");
	this.shape.setTransform(59.05,62.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_mask, new cjs.Rectangle(0,0,118.1,125.9), null);


(lib.btn_frame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(0.5,1,1).p("Asfh6IY/AAIAAD1I4/AAg");
	this.shape.setTransform(80,12.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.8)").s().p("AsfB6IAAj0IY/AAIAAD0g");
	this.shape_1.setTransform(80,12.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_frame, new cjs.Rectangle(-1,-1,162,26.5), null);


(lib.boxshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bottom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt3 = new cjs.Text("100%", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 31;
	this.txt3.parent = this;
	this.txt3.setTransform(438.2,5.15);

	this.txt2 = new cjs.Text("Display Settings", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.lineWidth = 31;
	this.txt2.parent = this;
	this.txt2.setTransform(321.85,4.9);

	this.txt1 = new cjs.Text("Ready", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.lineWidth = 14;
	this.txt1.parent = this;
	this.txt1.setTransform(2.3,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4F4F4F").s().p("AgBAMIAAgKIgKAAIAAgDIAKAAIAAgKIADAAIAAAKIAKAAIAAADIgKAAIAAAKg");
	this.shape.setTransform(433.2,3.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#757575").s().p("AgEAUIAAgQIifAAIAAgDICfAAIAAgUIAPAAIAAAUICZAAIAAADIiZAAIAAAQg");
	this.shape_1.setTransform(414.3,3.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4F4F4F").s().p("AgKAEIAAgHIAVAAIAAAHg");
	this.shape_2.setTransform(395.675,3.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgSATIAlAAIAAglIgLAAIAAAVIgaAAgAgEAAIAKAAIAAgSIgKAAgAgSAAIALAAIAAgSIgLAAg");
	this.shape_3.setTransform(386.7,3.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_4.setTransform(374.175,4.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_5.setTransform(374.175,3.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_6.setTransform(374.175,2.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4F4F4F").s().p("AgLARIAAghIAXAAIAAAhgAgJAOIASAAIAAgbIgSAAg");
	this.shape_7.setTransform(374.2,3.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgTATIAmAAIAAglIgmAAg");
	this.shape_8.setTransform(374.2,3.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAAJATIAKAAIAAgKIgKAAgAgEATIAKAAIAAgKIgKAAgAgSATIAMAAIAAgKIgMAAgAAJAGIAKAAIAAgKIgKAAgAgEAGIAKAAIAAgKIgKAAgAgSAGIAMAAIAAgKIgMAAgAAJgGIAKAAIAAgMIgKAAgAgEgGIAKAAIAAgMIgKAAgAgSgGIAMAAIAAgMIgMAAg");
	this.shape_9.setTransform(361.525,3.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4F4F4F").s().p("AgPAXIAAgEIALAAIAAgJIgSAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIAtAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIAAAaQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgBAAIgBgDIAAgBQAAAAABgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgCgBQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAABIgBABIgCAAIgBgBQAAgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAIgCAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAABIAAABIgBACIgBABIgBAAIgCABIgBAAIAAAJIAFAAIAAAEg");
	this.shape_10.setTransform(318.725,3.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4F4F4F").s().p("AAEALIgCgCQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAIgCACIgBAAIgCgBIAAgBIABgCQgCgCgBgDIgCAAIgBgBIAAgBIABAAIACgBIABgCIACgDIAAgCQgBgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIABAAIABACIAEAAIABgCIABAAIACABIAAABIgBACQACACABADIADABIAAAAIAAABIAAABIgDAAIgBACIgCAEIABACIgBABIgBAAgAgFgCQgEAFAHAEQAFADAEgGQADgGgGgEIgEgBQgDAAgCAFg");
	this.shape_11.setTransform(320.075,4.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F3F1F0").s().p("EgjPAAwIAAhfMBGfAAAIAABfg");
	this.shape_12.setTransform(225.575,4.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottom, new cjs.Rectangle(0,0,471.4,13.6), null);


(lib.big_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_big_msml();
	this.instance.setTransform(136,152,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_pie, new cjs.Rectangle(-0.2,0,420.2,420), null);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384549").s().p("A4MPeIAA7rIgBgWIgEgUIATgFQAUgFADABQARAFAQAAQAIAAAOgFQAPgFAJAAQALAAAGAGIAHAIIBSAoIAdACQADgGAHgEQAEgCAdgBIAcgBIARAKIALgGIAiAGIANgSIARAAIAOAKIBKgCIAKAHIBCgDIAJgHIAWACIAKgEIAfAAIAJgGQALgGAIAAQAOAAANAOIAigBIAJgHIAJADIAYAUIATAAIATAOIAWAAIAVAQIABANIANAAIADAOIAVAXIAOACIAAAKIASAIIABAIIALAAIAGAJIANABIgBALIAKAAIAOAKIABAJIAWAJIAXgUIALgFIAAgIIAjgMIADgJIAUgBIAVATIALAAIAeAcIANgJIATANQASgBADgBIANgLIAHAIIAJgGIALABIAJgEIARgDIALAKIAFgLIARgBIAHgCIAJADIAbAEIAJAIIAKgGIAKABIAGgRIASgQIAUgEQAEgBATADIA7AAIALgCIAMAGIANAAIAMgIIAQAKIAWAXIATABIAbAXIAMgCIAUAUIARACQAEAAAGAEIAHAHIAIANIAfALIAHAAIAEAHIA3AAIAGgGIAJAEIAeAAIAigoIAIAAIgCgJIAIgJIADgKQAQgJABgEQABgDAEgFIAGgEIAIgDIAAgSQAKACAAgDIgDgRIAIgBIAEgNIALgNQAOgOADgCQAEgCAPgCIATgNIAKABIAFgNIASAAIAAgQIAPgFIAHgKIAGgDQAFgEAEAAIAlADIAKACIAGAHIAdgdIABgOIAMAAIAZgNIAdgHIACgKIAIACIAEgJIALAAIABgJIATgLIACgMIANgCIANgLIABgJIAfgWIAQgGIAFAKIAQABIAXAPIASgUIAMgBIAGgHIAOAAIAOgMIANAAIAHAFIAhAAIAVAJIATgJIAgAAQApgDAOADQAOAEAQAKIAmABIAOgIIAQAGIACAHIBWABQAEAAAPgIQAPgHABAAQAEACAigBIAFgIIAJgCIAGAGIAWgLIAngBIAmgJIAOgHIAxAaIgITYIAALJg");
	this.shape.setTransform(155.4,98.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(0,0,310.8,198), null);


(lib.Background_img = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Bg_img_160x600_smlpngcopy();
	this.instance.setTransform(88.05,125.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Background_img, new cjs.Rectangle(11.5,125.5,299,306), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAKBIIA5g1IjHAAIAAgkIDHAAIg5g2IAuAAIBNBHIhMBIg");
	this.shape.setTransform(3.5846,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(-4.1,0,15.4,8.4), null);


(lib.WordUI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.tablet_shadow_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tablet_shadow.cache(-500,-500,2000,2000,.25)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.tablet_shadow = new lib.tablet_shadow_sub();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(64.3,47.1,1,1,0,0,0,64.3,47.1);

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_vector, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.squareshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.tablet_shadow = new lib.tablet_shadow_vector();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.roundshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0.3,56,45), null);


(lib.Ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_26 = new cjs.Graphics().p("AgeBtIAhgMIgDGSIgiAMg");
	var mask_graphics_27 = new cjs.Graphics().p("AgeBtIAjgNIgEGSIgjANg");
	var mask_graphics_28 = new cjs.Graphics().p("AgeBtIAxgSIgEGSIgxASg");
	var mask_graphics_29 = new cjs.Graphics().p("AgpBtIBXggIgEGTIhXAfg");
	var mask_graphics_30 = new cjs.Graphics().p("AhNBtICfg6IgEGSIifA6g");
	var mask_graphics_31 = new cjs.Graphics().p("AiKBtIEZhmIgEGSIkZBmg");
	var mask_graphics_32 = new cjs.Graphics().p("AjkBtIHNimIgEGRInNCog");
	var mask_graphics_33 = new cjs.Graphics().p("AlhBuILHkCIgEGRIrHEDg");
	var mask_graphics_34 = new cjs.Graphics().p("An+BuIQBl0IgEGRIwBF1g");
	var mask_graphics_35 = new cjs.Graphics().p("Ap7BuIT7nPIgEGRIz7HQg");
	var mask_graphics_36 = new cjs.Graphics().p("ArVBuIWvoRIgEGTI2vIRg");
	var mask_graphics_37 = new cjs.Graphics().p("AsSBuIYpo9IgEGTI4pI9g");
	var mask_graphics_38 = new cjs.Graphics().p("As2BvIZxpYIgEGSI5xJYg");
	var mask_graphics_39 = new cjs.Graphics().p("AtJBvIaXpmIgEGSI6XJmg");
	var mask_graphics_40 = new cjs.Graphics().p("AtQBvIalprIgEGSI6lJrg");
	var mask_graphics_41 = new cjs.Graphics().p("AtRBtIanprIgEGSI6nJrg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_graphics_26,x:-3.4728,y:51.1083}).wait(1).to({graphics:mask_graphics_27,x:-3.4734,y:51.1088}).wait(1).to({graphics:mask_graphics_28,x:-3.4773,y:51.1103}).wait(1).to({graphics:mask_graphics_29,x:-2.4248,y:51.1141}).wait(1).to({graphics:mask_graphics_30,x:1.198,y:51.1217}).wait(1).to({graphics:mask_graphics_31,x:7.1704,y:51.1341}).wait(1).to({graphics:mask_graphics_32,x:16.0795,y:51.1526}).wait(1).to({graphics:mask_graphics_33,x:28.5123,y:51.1785}).wait(1).to({graphics:mask_graphics_34,x:43.9537,y:51.2106}).wait(1).to({graphics:mask_graphics_35,x:56.3838,y:51.2365}).wait(1).to({graphics:mask_graphics_36,x:65.2898,y:51.255}).wait(1).to({graphics:mask_graphics_37,x:71.2594,y:51.2674}).wait(1).to({graphics:mask_graphics_38,x:74.8802,y:51.275}).wait(1).to({graphics:mask_graphics_39,x:76.7395,y:51.2788}).wait(1).to({graphics:mask_graphics_40,x:77.4245,y:51.2803}).wait(1).to({graphics:mask_graphics_41,x:78.4661,y:51.0948}).wait(9));

	// Layer_5 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AhKh+ICVDLIiUAyg");
	this.shape.setTransform(7.7045,78.9864,1.1195,1.1622,0,0,-3.4874);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(26).to({_off:false},0).wait(24));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("EgiLAJ7MBEXgYZIAAEaMhEXAYkg");
	this.shape_1.setTransform(217.7783,0.2491);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(26).to({_off:false},0).wait(24));

	// Layer_8 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AuDuZIAwgRIAAgBIbXp5MAAAAm/I8HKKg");
	mask_1.setTransform(86.025,186.5125);

	// Layer_9
	this.bg_img = new lib.Background_img();
	this.bg_img.name = "bg_img";
	this.bg_img.setTransform(66.95,142,1,1,0,0,0,155.5,233.3);
	this.bg_img.alpha = 0;
	this.bg_img._off = true;

	var maskedShapeInstanceList = [this.bg_img];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.bg_img).wait(25).to({_off:false},0).to({alpha:1},19).wait(6));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_10 = new cjs.Graphics().p("AMZYRIATl6IAJAMIgTF6g");
	var mask_2_graphics_11 = new cjs.Graphics().p("AMYYPIATl5IAKANIgTF6g");
	var mask_2_graphics_12 = new cjs.Graphics().p("AMOYDIAUl5IATAZIgTF6g");
	var mask_2_graphics_13 = new cjs.Graphics().p("AL1XjIATl6IAuA6IgUF6g");
	var mask_2_graphics_14 = new cjs.Graphics().p("ALDWjIATl6IBgB6IgTF6g");
	var mask_2_graphics_15 = new cjs.Graphics().p("AJwU7IATl6ICzDjIgTF6g");
	var mask_2_graphics_16 = new cjs.Graphics().p("AH1SfIATl6IEvGAIgTF6g");
	var mask_2_graphics_17 = new cjs.Graphics().p("AFJPFIAUl6IHbJbIgTF6g");
	var mask_2_graphics_18 = new cjs.Graphics().p("ABlKjIATl6ILBN/IgTF6g");
	var mask_2_graphics_19 = new cjs.Graphics().p("AiuFEIAUl5IPVTfIgTF6g");
	var mask_2_graphics_20 = new cjs.Graphics().p("AmSAiIATl5IS7YDIgTF5g");
	var mask_2_graphics_21 = new cjs.Graphics().p("Ao+i3IAUl6IVnbeIgTF6g");
	var mask_2_graphics_22 = new cjs.Graphics().p("Aq4lTIATl6IXjd7IgTF5g");
	var mask_2_graphics_23 = new cjs.Graphics().p("AsLm8IAUl6IY2fkIgUF6g");
	var mask_2_graphics_24 = new cjs.Graphics().p("As9n7IAUl6MAZoAgkIgTF5g");
	var mask_2_graphics_25 = new cjs.Graphics().p("AtKocIATl6MAaCAhFIgTF6g");
	var mask_2_graphics_26 = new cjs.Graphics().p("AtPooIATl6MAaMAhRIgTF6g");
	var mask_2_graphics_27 = new cjs.Graphics().p("AtQo2IAUl6MAaNAhTIgUF6g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_2_graphics_10,x:82.1423,y:156.45}).wait(1).to({graphics:mask_2_graphics_11,x:82.1431,y:156.4511}).wait(1).to({graphics:mask_2_graphics_12,x:82.1486,y:156.4581}).wait(1).to({graphics:mask_2_graphics_13,x:82.1637,y:156.477}).wait(1).to({graphics:mask_2_graphics_14,x:82.1931,y:156.5139}).wait(1).to({graphics:mask_2_graphics_15,x:82.2415,y:156.5746}).wait(1).to({graphics:mask_2_graphics_16,x:82.3137,y:156.6652}).wait(1).to({graphics:mask_2_graphics_17,x:82.4145,y:156.7916}).wait(1).to({graphics:mask_2_graphics_18,x:82.5487,y:156.9598}).wait(1).to({graphics:mask_2_graphics_19,x:82.711,y:157.163}).wait(1).to({graphics:mask_2_graphics_20,x:82.8454,y:157.3311}).wait(1).to({graphics:mask_2_graphics_21,x:82.9464,y:157.4573}).wait(1).to({graphics:mask_2_graphics_22,x:83.0188,y:157.5478}).wait(1).to({graphics:mask_2_graphics_23,x:83.0674,y:157.6084}).wait(1).to({graphics:mask_2_graphics_24,x:83.0968,y:157.6452}).wait(1).to({graphics:mask_2_graphics_25,x:81.9007,y:157.664}).wait(1).to({graphics:mask_2_graphics_26,x:81.4366,y:157.671}).wait(1).to({graphics:mask_2_graphics_27,x:79.4186,y:156.45}).wait(23));

	// Layer_5 copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AhVhJICqhFIgCEeg");
	this.shape_2.setTransform(160.2408,294.5788,0.542,1.0048,0,0,21.4596);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(10).to({_off:false},0).wait(40));

	// Layer_5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A5vgRIABkiMAzeAFFIgFEig");
	this.shape_3.setTransform(81.1655,187.3433,0.714,1.3198,0,0,44.7723);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(10).to({_off:false},0).wait(40));

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("AjuYcIFOh6IgEGSIlOB6g");
	var mask_3_graphics_1 = new cjs.Graphics().p("AjuYcIFQh7IgEGSIlQB7g");
	var mask_3_graphics_2 = new cjs.Graphics().p("AjuYcIFfiAIgEGSIlfCAg");
	var mask_3_graphics_3 = new cjs.Graphics().p("AjuYcIGJiQIgEGTImJCPg");
	var mask_3_graphics_4 = new cjs.Graphics().p("AjuYcIHaitIgEGSInaCtg");
	var mask_3_graphics_5 = new cjs.Graphics().p("AktYcIJfjeIgEGSIpfDeg");
	var mask_3_graphics_6 = new cjs.Graphics().p("AmRYbIMnkmIgEGSIsnEng");
	var mask_3_graphics_7 = new cjs.Graphics().p("AocYbIQ9mLIgEGSIw9GLg");
	var mask_3_graphics_8 = new cjs.Graphics().p("ArJYbIWXoKIgEGSI2XIKg");
	var mask_3_graphics_9 = new cjs.Graphics().p("AtUYaIatpuIgEGSI6tJug");
	var mask_3_graphics_10 = new cjs.Graphics().p("Au4YaId1q3IgEGSI91K3g");
	var mask_3_graphics_11 = new cjs.Graphics().p("Av7YaIf7roIgEGSI/7Log");
	var mask_3_graphics_12 = new cjs.Graphics().p("AwjYaMAhLgMGIgEGTMghLAMFg");
	var mask_3_graphics_13 = new cjs.Graphics().p("Aw4YaMAh1gMVIgEGSMgh1AMVg");
	var mask_3_graphics_14 = new cjs.Graphics().p("AxAYaMAiFgMaIgEGSMgiFAMag");
	var mask_3_graphics_15 = new cjs.Graphics().p("AxBYaMAiHgMbIgEGSMgiHAMbg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-24.2978,y:196.6083}).wait(1).to({graphics:mask_3_graphics_1,x:-24.2972,y:196.6083}).wait(1).to({graphics:mask_3_graphics_2,x:-24.2925,y:196.6065}).wait(1).to({graphics:mask_3_graphics_3,x:-24.28,y:196.6014}).wait(1).to({graphics:mask_3_graphics_4,x:-24.2557,y:196.5914}).wait(1).to({graphics:mask_3_graphics_5,x:-17.799,y:196.575}).wait(1).to({graphics:mask_3_graphics_6,x:-7.706,y:196.5505}).wait(1).to({graphics:mask_3_graphics_7,x:6.3799,y:196.5164}).wait(1).to({graphics:mask_3_graphics_8,x:23.8764,y:196.474}).wait(1).to({graphics:mask_3_graphics_9,x:37.9623,y:196.4398}).wait(1).to({graphics:mask_3_graphics_10,x:48.0554,y:196.4154}).wait(1).to({graphics:mask_3_graphics_11,x:54.8211,y:196.399}).wait(1).to({graphics:mask_3_graphics_12,x:58.9249,y:196.389}).wait(1).to({graphics:mask_3_graphics_13,x:61.0322,y:196.3839}).wait(1).to({graphics:mask_3_graphics_14,x:61.8086,y:196.382}).wait(1).to({graphics:mask_3_graphics_15,x:62.0073,y:196.3833}).wait(35));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("EgiLAJ8MBEXgYbIAAEbMhEXAYjg");
	this.shape_4.setTransform(218.7783,277.2519);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.3,0,184.9,370);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.option_btn_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// this.isSingleFrame = false;
	// // timeline functions:
	// this.frame_0 = function() {
	// 	if(this.isSingleFrame) {
	// 		return;
	// 	}
	// 	if(this.totalFrames == 1) {
	// 		this.isSingleFrame = true;
	// 	}
	// 	this.stop();
	// }

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	// this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2
	// this.shape = new cjs.Shape();
	// this.shape.graphics.f().s("#505050").ss(1,2,0,3).p("AAhgRIghAjIgggj");
	// this.shape.setTransform(143.6751,14.0683);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#505050").ss(1,2,0,3).p("AggASIAggjIAhAj");
	this.shape.setTransform(143.6751,13.1817);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#505050").ss(1,2,0,3).p("AgggRIAgAjIAhgj");
	this.shape_1.setTransform(143.6751,13.9683);

	// this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(1));

	this._renderFirstFrame();

// }).prototype = getMCSymbolPrototype(lib.option_btn_menu, new cjs.Rectangle(-0.2,-0.2,160.5,25), null);
}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,160.5,25);


(lib.option_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,160.5,25);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:3.6,x:-0.1},0).wait(1).to({x:-1},0).wait(1).to({x:-2.1},0).wait(1).to({x:-2.8},0).wait(1).to({regX:5.6,x:-1.05},0).wait(1).to({regX:3.6,x:-2.95},0).wait(1).to({x:-2.6},0).wait(1).to({x:-2.15},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.5},0).wait(1).to({regX:5.6,x:0.55},0).wait(1).to({regX:3.6,x:-1.45},0).wait(1).to({x:-1.6},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.9},0).wait(1).to({x:-2},0).wait(1).to({regX:5.6,x:-0.05},0).wait(1).to({regX:3.6,x:-2},0).wait(1).to({x:-1.95},0).wait(1).to({x:-1.9},0).wait(1).to({x:-1.85},0).wait(1).to({regX:5.6,x:0.15},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(1).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(35));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.ribbon = new lib.Ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(218.8,205.15,1,1,0,0,0,218.8,92.8);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(-48.6,0,486.20000000000005,505.6), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.TL_MainScreen.tweenFromTo("frame0", "frame1");
		//exportRoot.TL_Clouds.tweenFromTo("frame0", "frame1");
	}
	this.frame_89 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(30).call(this.frame_89).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(73.1,908.7,0.1944,0.1944,0,0,0,-39.9,1.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.2168,scaleY:3.2168,x:73},13,cjs.Ease.quadOut).to({x:-105.8},12,cjs.Ease.quadInOut).to({_off:true},1).wait(63));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgVfBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_15 = new cjs.Graphics().p("EgVrBJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_16 = new cjs.Graphics().p("EgWRBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_17 = new cjs.Graphics().p("EgXPBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_18 = new cjs.Graphics().p("EgYmBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_19 = new cjs.Graphics().p("EgaWBJsIAAq2MA70AAAIAAK2g");
	var mask_graphics_20 = new cjs.Graphics().p("EgceBJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_21 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_22 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_23 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_24 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_25 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");
	var mask_graphics_26 = new cjs.Graphics().p("Egd5BJsIAAq2MA7zAAAIAAK2g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:245.2711,y:471.6178}).wait(1).to({graphics:mask_graphics_15,x:244.0282,y:471.6178}).wait(1).to({graphics:mask_graphics_16,x:240.2997,y:471.6178}).wait(1).to({graphics:mask_graphics_17,x:234.0854,y:471.6178}).wait(1).to({graphics:mask_graphics_18,x:225.3854,y:471.6178}).wait(1).to({graphics:mask_graphics_19,x:214.1996,y:471.6178}).wait(1).to({graphics:mask_graphics_20,x:200.5282,y:471.6178}).wait(1).to({graphics:mask_graphics_21,x:182.2746,y:471.6178}).wait(1).to({graphics:mask_graphics_22,x:159.9031,y:471.6178}).wait(1).to({graphics:mask_graphics_23,x:142.5031,y:471.6178}).wait(1).to({graphics:mask_graphics_24,x:130.0745,y:471.6178}).wait(1).to({graphics:mask_graphics_25,x:122.6174,y:471.6178}).wait(1).to({graphics:mask_graphics_26,x:120.2033,y:471.6178}).wait(1).to({graphics:null,x:0,y:0}).wait(63));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-207.9,904.85,3.2168,3.2168,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:23.25},12,cjs.Ease.quadInOut).wait(33).to({regY:0.4,scaleY:3.2175},0).to({regX:-0.1,scaleX:2.408,scaleY:2.408,x:-12,y:7.9},30,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(69,896.7,0.611,2.4487,0,0,0,0,0.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({regX:-1.2,regY:0.1,scaleX:0.6109,x:70.2,y:910.25},59).to({regX:0,regY:0,scaleX:0.611,x:66,y:899,alpha:0},30,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-234,-104.9,605,2014.9);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask.setTransform(147.1518,94.651);

	// LeafA
	this.instance = new lib.leafA();
	this.instance.setTransform(58.25,128.95,0.6362,0.6362,0,0,0,99,122.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(105));

	// ScreenMaskA copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_1.setTransform(147.1518,94.651);

	// Grass
	this.instance_1 = new lib.grass();
	this.instance_1.setTransform(172.05,168.85,0.6595,0.6595,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(105));

	// ScreenMaskA copy 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_2.setTransform(147.1518,94.651);

	// LeafB
	this.instance_2 = new lib.leafB();
	this.instance_2.setTransform(255.85,101.15,0.6995,0.6995,0,0,0,55.1,54.6);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(150,70.95,0.7954,0.7954,0,0,0,50.2,75.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(55).to({mode:"synched",loop:false},0).to({y:72.9,startPosition:4},4,cjs.Ease.quadInOut).to({y:68.1,startPosition:16},12,cjs.Ease.quadInOut).to({startPosition:36},20,cjs.Ease.quadInOut).to({y:69.55,startPosition:44},8,cjs.Ease.quadInOut).wait(5).to({mode:"single",startPosition:49},0).wait(1));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(151.4,176.55,0.7338,0.7338,0,0,0,58.1,159.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55).to({regY:159.6,y:176.95},4,cjs.Ease.quadInOut).to({regY:159.7,scaleY:0.7573,y:175.65},16,cjs.Ease.quadInOut).to({scaleY:0.7571,y:175.6},12,cjs.Ease.quadInOut).to({scaleY:0.7338,y:176.55},12,cjs.Ease.quadInOut).wait(6));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_3.setTransform(147.1518,94.651);

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(167.9,158.75,0.8242,0.8242,0,0,0,155.3,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_4.setTransform(147.1518,94.651);

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(166.1,87.6,0.7852,0.7852,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(105));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(0,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(105));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,22.2,300,201);


(lib.main_ui = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MainText
	this.instance = new lib.main_txt();
	this.instance.setTransform(78.55,84.7,1,1,0,0,0,52,12.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Rows_Cells
	this.instance_1 = new lib.rowsandcells();
	this.instance_1.setTransform(233.3,34.55,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Top_bar_txt
	this.instance_2 = new lib.top_text();
	this.instance_2.setTransform(224.6,11.15,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Top_bar
	this.instance_3 = new lib.Topbar();
	this.instance_3.setTransform(225,5.5,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Top_grey
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#227347").s().p("AgOAIIgDAAIAAgYIAjAAIAAAYIgVAAIgLAJgAgPAGIAEAAIAAAGIAHgGIATAAIAAgTIgeAAg");
	this.shape.setTransform(416.4564,17.2001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#EEEDEC").ss(0.3).p("ACcAlIk3AAQgDAAgCgCQgCgCAAgDIAAg6QAAgIAHAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_1.setTransform(428.3065,17.1751);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibAlQgDAAgCgCQgCgCgBgDIAAg6QAAgIAIAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_2.setTransform(428.3065,17.1751);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#227347").s().p("AACAHQgJAAgFAEIgCABIAAgDIADgHQAEgGAJAAIAAgIIANAMIgNAOgAADAFIABAAIAAACIAHgHIgHgGIAAAEIgBAAQgLAAgDAJQAFgDAGABg");
	this.shape_3.setTransform(391.881,16.4001);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#227347").s().p("AgQANIAAgZIADAAIAAAWIAbAAIAAgLIADAAIAAAOg");
	this.shape_4.setTransform(391.106,17.9251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#474747").s().p("AgWAXQAAAAgBgBQAAAAAAAAQAAAAAAAAQABgBAAAAIARgRQgDgEAAgFQAAgHAFgFQADgFAHAAQAHAAAFAFQAFAFAAAHQAAAGgFAFQgFAEgHAAQgHAAgEgEIgRARgAgCgPQgEAEAAAGQAAAFAEAEQADAEAGAAQAGAAAEgEQAEgEAAgFQAAgGgEgEQgEgFgGABQgGgBgDAFg");
	this.shape_5.setTransform(205.7781,17.4501);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#EEEDEC").ss(0.3).p("ABnAlIjMAAQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_6.setTransform(397.9561,17.2001);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhlAlQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_7.setTransform(397.9561,17.2001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F0F0F0").s().p("EgjJAA9IAAh5MBGTAAAIAAB5g");
	this.shape_8.setTransform(225,17.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Scroll_bars
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#ABABAB").ss(0.3).p("AqYAXIAAgtIUxAAIAAAtg");
	this.shape_9.setTransform(277.1512,272.3786);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqXAXIAAgtIUvAAIAAAtg");
	this.shape_10.setTransform(277.1512,272.3786);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#787878").s().p("AgFgLIALALIgLAMg");
	this.shape_11.setTransform(437.3786,272.4286);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#787878").s().p("AgFAAIALgLIAAAXg");
	this.shape_12.setTransform(208.3001,272.4286);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_13.setTransform(437.2536,272.3786);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAXIAAgtIAsAAIAAAtg");
	this.shape_14.setTransform(437.2536,272.3786);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_15.setTransform(208.4251,272.4036);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAXIAAgsIAtAAIAAAsg");
	this.shape_16.setTransform(208.4251,272.4036);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#DBDBDB").ss(0.3).p("AxhAXIAAgtMAjDAAAIAAAtg");
	this.shape_17.setTransform(322.8519,272.3786);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DBDBDB").s().p("AxgAXIAAgtMAjCAAAIAAAtg");
	this.shape_18.setTransform(322.8519,272.3786);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#ABABAB").ss(0.3).p("AAXKZIgtAAIAA0xIAtAAg");
	this.shape_19.setTransform(445.3787,110.0511);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWKYIAA0vIAtAAIAAUvg");
	this.shape_20.setTransform(445.3787,110.0511);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAHAAIAAAFg");
	this.shape_21.setTransform(200.65,273.4536);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B3B3B3").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_22.setTransform(200.65,272.1536);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAHAAIAAAGg");
	this.shape_23.setTransform(200.65,270.8535);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787878").s().p("AgMAGIAMgLIAMALg");
	this.shape_24.setTransform(445.4037,41.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#787878").s().p("AgMgFIAYAAIgMALg");
	this.shape_25.setTransform(445.4037,265.2785);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_26.setTransform(445.3787,41.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_27.setTransform(445.3787,41.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_28.setTransform(445.4037,265.1285);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAsAAIAAAtg");
	this.shape_29.setTransform(445.4037,265.1285);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DBDBDB").ss(0.3).p("AAXRIIgtAAMAAAgiPIAtAAg");
	this.shape_30.setTransform(445.3787,153.2267);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DBDBDB").s().p("AgWRIMAAAgiPIAtAAMAAAAiPg");
	this.shape_31.setTransform(445.3787,153.2267);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// layout
	this.instance_4 = new lib.Layout();
	this.instance_4.setTransform(225,150.15,1,1,0,0,0,225,126.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Bottom
	this.instance_5 = new lib.bottom();
	this.instance_5.setTransform(225.6,281.85,1,1,0,0,0,225.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer_2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#E4DFD4").ss(1,1,1).p("EgifgVxMBE/AAAMAAAArjMhE/AAAg");
	this.shape_32.setTransform(223.225,143.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("EgifAVyMAAAgrjMBE/AAAMAAAArjg");
	this.shape_33.setTransform(223.225,143.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_ui, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.guyrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,-0.1,53,43), null);


(lib.guyrightcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.guylefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon, new cjs.Rectangle(0.1,0.1,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.graphLG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.graphGreen();
	this.instance.setTransform(49.9,49.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphLG, new cjs.Rectangle(-8,-8,115.8,115.8), null);


(lib.GraphCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// WhiteCoverOuter
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCAAQAADwiqCoQioCqjwAAQjvAAipiqQipioAAjwQAAjvCpipQCpipDvAAQDwAACoCpQCqCpAADvg");
	this.shape.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// WhiteCoverMid
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkpEpQh6h7AAiuQAAitB6h8QB8h6CtAAQCuAAB7B6QB7B8AACtQAACuh7B7Qh7B7iuAAQitAAh8h7g");
	this.shape_1.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(60));

	// Layer_3
	this.instance = new lib.circleSegment();
	this.instance.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:28.9,regY:29,rotation:-0.029,x:28.9,y:29},0).wait(1).to({rotation:-0.1186,x:28.85,y:29.05},0).wait(1).to({rotation:-0.273,x:28.8,y:29.1},0).wait(1).to({rotation:-0.4968,x:28.7,y:29.25},0).wait(1).to({rotation:-0.7954,x:28.55,y:29.4},0).wait(1).to({rotation:-1.1745,x:28.35,y:29.55},0).wait(1).to({rotation:-1.6408,x:28.15,y:29.8},0).wait(1).to({rotation:-2.2019,x:27.85,y:30.15},0).wait(1).to({rotation:-2.8662,x:27.5,y:30.45},0).wait(1).to({rotation:-3.6437,x:27.15,y:30.85},0).wait(1).to({rotation:-4.5458,x:26.7,y:31.35},0).wait(1).to({rotation:-5.5858,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7793,x:25.7,y:32.6},0).wait(1).to({rotation:-8.145,x:25.1,y:33.35},0).wait(1).to({rotation:-9.7052,x:24.5,y:34.3},0).wait(1).to({rotation:-11.4869,x:23.75,y:35.3},0).wait(1).to({rotation:-13.5237,x:23,y:36.55},0).wait(1).to({rotation:-15.8573,x:22.1,y:38},0).wait(1).to({rotation:-18.5409,x:21.2,y:39.7},0).wait(1).to({rotation:-21.6437,x:20.3,y:41.7},0).wait(1).to({rotation:-25.2575,x:19.35,y:44.1},0).wait(1).to({rotation:-29.5072,x:18.45,y:47},0).wait(1).to({rotation:-34.5678,x:17.65,y:50.55},0).wait(1).to({rotation:-40.6901,x:17.05,y:54.85},0).wait(1).to({rotation:-48.2363,y:60.25},0).wait(1).to({rotation:-57.704,x:18,y:66.9},0).wait(1).to({rotation:-69.5952,x:20.75,y:74.95},0).wait(1).to({rotation:-83.7062,x:25.95,y:83.5},0).wait(1).to({rotation:-98.1499,x:33.35,y:90.7},0).wait(1).to({rotation:-110.7267,x:41.05,y:95.2},0).wait(1).to({rotation:-120.8736,x:47.9,y:97.6},0).wait(1).to({rotation:-128.9999,x:53.6,y:98.6},0).wait(1).to({rotation:-135.6121,x:58.35,y:98.85},0).wait(1).to({rotation:-141.095,x:62.2,y:98.6},0).wait(1).to({rotation:-145.7175,x:65.5,y:98.1},0).wait(1).to({rotation:-149.667,x:68.25,y:97.45},0).wait(1).to({rotation:-153.0773,x:70.65,y:96.8},0).wait(1).to({rotation:-156.0464,x:72.6,y:96.1},0).wait(1).to({rotation:-158.6477,x:74.3,y:95.4},0).wait(1).to({rotation:-160.9377,x:75.8,y:94.7},0).wait(1).to({rotation:-162.9604,x:77.05,y:94.05},0).wait(1).to({rotation:-164.7513,x:78.2,y:93.4},0).wait(1).to({rotation:-166.3388,x:79.15,y:92.8},0).wait(1).to({rotation:-167.7463,x:80,y:92.3},0).wait(1).to({rotation:-168.9936,x:80.8,y:91.85},0).wait(1).to({rotation:-170.0968,x:81.45,y:91.4},0).wait(1).to({rotation:-171.0701,x:82,y:90.95},0).wait(1).to({rotation:-171.9252,x:82.45,y:90.65},0).wait(1).to({rotation:-172.6727,x:82.9,y:90.3},0).wait(1).to({rotation:-173.3213,x:83.25,y:90},0).wait(1).to({regX:57.9,regY:57.9,rotation:-173.879,x:57.85,y:57.95},0).wait(1).to({regX:28.9,regY:29,rotation:-173.9985,x:83.7,y:89.65},0).wait(1).to({rotation:-174.0984,x:83.75,y:89.6},0).wait(1).to({rotation:-174.1799,x:83.8,y:89.55},0).wait(1).to({rotation:-174.2445,x:83.85},0).wait(1).to({rotation:-174.2931,x:83.9},0).wait(1).to({rotation:-174.3267,y:89.5},0).wait(1).to({rotation:-174.3463},0).wait(1).to({regX:57.7,regY:57.8,rotation:-174.3527,x:58,y:57.95},0).wait(1));

	// Layer_2
	this.instance_1 = new lib.circleSegment();
	this.instance_1.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:28.9,regY:29,rotation:-0.0144,x:28.9,y:29},0).wait(1).to({rotation:-0.059},0).wait(1).to({rotation:-0.1357,x:28.85,y:29.05},0).wait(1).to({rotation:-0.247,x:28.8,y:29.1},0).wait(1).to({rotation:-0.3955,x:28.75,y:29.2},0).wait(1).to({rotation:-0.584,x:28.65,y:29.25},0).wait(1).to({rotation:-0.8159,x:28.5,y:29.4},0).wait(1).to({rotation:-1.0949,x:28.4,y:29.55},0).wait(1).to({rotation:-1.4252,x:28.2,y:29.75},0).wait(1).to({rotation:-1.8118,x:28,y:29.95},0).wait(1).to({rotation:-2.2604,x:27.85,y:30.15},0).wait(1).to({rotation:-2.7775,x:27.55,y:30.4},0).wait(1).to({rotation:-3.371,x:27.25,y:30.75},0).wait(1).to({rotation:-4.05,x:27,y:31.1},0).wait(1).to({rotation:-4.8258,x:26.6,y:31.5},0).wait(1).to({rotation:-5.7118,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7245,x:25.75,y:32.55},0).wait(1).to({rotation:-7.8849,x:25.3,y:33.25},0).wait(1).to({rotation:-9.2193,x:24.7,y:34},0).wait(1).to({rotation:-10.7621,x:24.05,y:34.9},0).wait(1).to({rotation:-12.559,x:23.35,y:35.95},0).wait(1).to({rotation:-14.6721,x:22.55,y:37.25},0).wait(1).to({rotation:-17.1885,x:21.65,y:38.8},0).wait(1).to({rotation:-20.2327,x:20.75,y:40.75},0).wait(1).to({rotation:-23.985,x:19.7,y:43.25},0).wait(1).to({rotation:-28.6927,x:18.6,y:46.45},0).wait(1).to({rotation:-34.6055,x:17.65,y:50.5},0).wait(1).to({rotation:-41.622,x:17.05,y:55.5},0).wait(1).to({rotation:-48.8041,x:17.1,y:60.6},0).wait(1).to({rotation:-55.0577,x:17.6,y:65.05},0).wait(1).to({rotation:-60.1032,x:18.45,y:68.55},0).wait(1).to({rotation:-64.1439,x:19.3,y:71.3},0).wait(1).to({rotation:-67.4317,x:20.15,y:73.5},0).wait(1).to({rotation:-70.1581,x:20.95,y:75.3},0).wait(1).to({rotation:-72.4565,x:21.65,y:76.75},0).wait(1).to({rotation:-74.4204,x:22.3,y:78},0).wait(1).to({rotation:-76.1161,x:22.95,y:79.05},0).wait(1).to({rotation:-77.5925,x:23.45,y:79.95},0).wait(1).to({rotation:-78.886,x:23.95,y:80.7},0).wait(1).to({rotation:-80.0246,x:24.45,y:81.35},0).wait(1).to({rotation:-81.0304,x:24.85,y:81.95},0).wait(1).to({rotation:-81.9209,x:25.25,y:82.5},0).wait(1).to({rotation:-82.7103,x:25.55,y:82.95},0).wait(1).to({rotation:-83.4102,x:25.9,y:83.35},0).wait(1).to({rotation:-84.0303,x:26.2,y:83.65},0).wait(1).to({rotation:-84.5789,x:26.45,y:84},0).wait(1).to({rotation:-85.0629,x:26.65,y:84.2},0).wait(1).to({rotation:-85.4881,x:26.8,y:84.5},0).wait(1).to({rotation:-85.8597,x:27,y:84.7},0).wait(1).to({rotation:-86.1822,x:27.15,y:84.85},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.4596,x:57.95,y:57.85},0).wait(1).to({regX:28.9,regY:29,rotation:-86.5188,x:27.35,y:85},0).wait(1).to({rotation:-86.5683,y:85.05},0).wait(1).to({rotation:-86.6087},0).wait(1).to({rotation:-86.6407,x:27.4},0).wait(1).to({rotation:-86.6647,y:85.1},0).wait(1).to({rotation:-86.6814,x:27.35},0).wait(1).to({rotation:-86.6911,y:85.05},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.6943,x:57.9,y:57.85},0).wait(1));

	// Layer_1
	this.instance_2 = new lib.circleSegment();
	this.instance_2.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-5.8,127.5,127.5);


(lib.girlrigthcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon, new cjs.Rectangle(-0.1,-0.2,51,43), null);


(lib.girlleftcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution, new cjs.Rectangle(0.1,-0.2,89,65), null);


(lib.excel_screen_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.white.cache(0,0,460,310,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.white = new lib.excel_screen_white_sub();
	this.white.name = "white";
	this.white.setTransform(225.3,151.3,1,1,0,0,0,225.3,151.3);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.shadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// a
	this.tablet_shadow_1 = new lib.tablet_shadow_vector();
	this.tablet_shadow_1.name = "tablet_shadow_1";
	this.tablet_shadow_1.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_2, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_124 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(124).call(this.frame_124).wait(1));

	// Icon
	this.instance = new lib.Icon();
	this.instance.setTransform(71.6,81.75,0.7404,0.7404,0,0,0,50.3,50.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:50.2,regY:50.1,scaleX:0.4839,scaleY:0.4839,x:74,y:112.1},30,cjs.Ease.cubicInOut).wait(6));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(107.4,56.05,0.8476,0.7854,0,-29.2995,-16.7948,58.8,15.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regY:15.3,scaleX:0.554,scaleY:0.5134,skewX:-29.2988,skewY:-16.7949,x:97.5,y:95.35,startPosition:104},30,cjs.Ease.cubicInOut).wait(6));

	// Shadow
	this.instance_2 = new lib.shadow_2();
	this.instance_2.setTransform(195.55,84.65,0.9383,0.9383,0,0,0,176.8,127.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(89).to({regY:127.6,scaleX:0.5815,scaleY:0.5815,x:153.7,y:119.2},30,cjs.Ease.cubicInOut).wait(6));

	// Layer_2
	this.ribbon = new lib.ribboncopy();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(93.6,116.65,0.6419,0.6419,-0.5148,0,0,96.8,313.9);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,404.7,250);


(lib.chart_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.circle_shadow.cache(0,0,260,260);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_5
	this.circle_shadow = new lib.circle_shadow();
	this.circle_shadow.name = "circle_shadow";
	this.circle_shadow.setTransform(227.55,275.55,1,1,0,0,0,128.5,128.5);
	this.circle_shadow.alpha = 0.1484;

	this.timeline.addTween(cjs.Tween.get(this.circle_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_shadow, new cjs.Rectangle(0,0,420,420), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._3D_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{grow:1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		exportRoot.mainMC.page.obj1.screen.screen.gotoAndPlay("vanish");
	}
	this.frame_37 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(36).call(this.frame_37).wait(1));

	// percentage
	this.percantage = new lib.percantage();
	this.percantage.name = "percantage";
	this.percantage.setTransform(-43.15,-17.45,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.percantage.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.percantage).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-43.05,y:-17.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:247.2,regY:218.9,scaleX:0.6925,scaleY:0.6708,skewY:-4.1654,x:-16.5,y:-14.55},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1122,x:-15.15,y:-16},0).wait(1).to({scaleX:0.7169,scaleY:0.6939,skewY:-4.045,x:-13.5,y:-17.95},0).wait(1).to({scaleX:0.7333,scaleY:0.7094,skewY:-3.9642,x:-11.4,y:-20.2},0).wait(1).to({scaleX:0.7524,scaleY:0.7275,skewY:-3.8698,x:-9.1,y:-22.85},0).wait(1).to({scaleX:0.7742,scaleY:0.7481,skewY:-3.7625,x:-6.35,y:-25.85},0).wait(1).to({scaleX:0.7985,scaleY:0.7711,skewY:-3.6427,x:-3.35,y:-29.2},0).wait(1).to({scaleX:0.8252,scaleY:0.7964,skewY:-3.5111,x:-0.05,y:-32.85},0).wait(1).to({scaleX:0.8541,scaleY:0.8237,skewY:-3.3686,x:3.55,y:-36.85},0).wait(1).to({scaleX:0.885,scaleY:0.853,skewY:-3.2162,x:7.35,y:-41.1},0).wait(1).to({scaleX:0.9177,scaleY:0.8839,skewY:-3.0551,x:11.4,y:-45.6},0).wait(1).to({scaleX:0.9518,scaleY:0.9162,skewY:-2.8865,x:15.65,y:-50.3},0).wait(1).to({scaleX:0.9872,scaleY:0.9497,skewY:-2.7119,x:20.05,y:-55.15},0).wait(1).to({scaleX:1.0236,scaleY:0.9841,skewY:-2.5328,x:24.55,y:-60.15},0).wait(1).to({scaleX:1.0605,scaleY:1.019,skewY:-2.3508,x:29.15,y:-65.15},0).wait(1).to({scaleX:1.0977,scaleY:1.0542,skewY:-2.1675,x:33.75,y:-70.2},0).wait(1).to({scaleX:1.1348,scaleY:1.0893,skewY:-1.9845,x:38.35,y:-75.25},0).wait(1).to({scaleX:1.1715,scaleY:1.1241,skewY:-1.8033,x:42.9,y:-80.2},0).wait(1).to({scaleX:1.2076,scaleY:1.1582,skewY:-1.6255,x:47.4,y:-85.05},0).wait(1).to({scaleX:1.2427,scaleY:1.1914,skewY:-1.4525,x:51.75,y:-89.85},0).wait(1).to({scaleX:1.2765,scaleY:1.2234,skewY:-1.2856,x:55.9,y:-94.45},0).wait(1).to({scaleX:1.3089,scaleY:1.254,skewY:-1.126,x:59.95,y:-98.8},0).wait(1).to({scaleX:1.3395,scaleY:1.2831,skewY:-0.9748,x:63.75,y:-102.95},0).wait(1).to({scaleX:1.3683,scaleY:1.3103,skewY:-0.8327,x:67.3,y:-106.75},0).wait(1).to({scaleX:1.3952,scaleY:1.3357,skewY:-0.7006,x:70.6,y:-110.35},0).wait(1).to({scaleX:1.4198,scaleY:1.359,skewY:-0.5791,x:73.65,y:-113.65},0).wait(1).to({scaleX:1.4422,scaleY:1.3802,skewY:-0.4686,x:76.45,y:-116.7},0).wait(1).to({scaleX:1.4623,scaleY:1.3992,skewY:-0.3696,x:78.9,y:-119.35},0).wait(1).to({scaleX:1.48,scaleY:1.416,skewY:-0.2821,x:81.15,y:-121.75},0).wait(1).to({scaleX:1.4953,scaleY:1.4305,skewY:-0.2065,x:83.05,y:-123.8},0).wait(1).to({scaleX:1.5083,scaleY:1.4427,skewY:-0.1428,x:84.65,y:-125.55},0).wait(1).to({scaleX:1.5188,scaleY:1.4527,skewY:-0.0909,x:85.95,y:-126.9},0).wait(1).to({scaleX:1.5269,scaleY:1.4604,skewY:-0.0509,x:86.95,y:-128.05},0).wait(1).to({scaleX:1.5327,scaleY:1.4658,skewY:0,x:87.65,y:-128.8},0).wait(1).to({scaleX:1.5361,scaleY:1.4691,x:88.05,y:-129.25},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:30.7,y:-142.9},0).wait(1));

	// Big
	this.b_pie = new lib.big_pie();
	this.b_pie.name = "b_pie";
	this.b_pie.setTransform(-38.8,-25.9,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.b_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.b_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-38.7,y:-26.1,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:241.1,regY:237.8,scaleX:0.6924,scaleY:0.6707,skewY:-4.1658,x:-16.4,y:-9.95},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1121,x:-15.15,y:-11.1},0).wait(1).to({scaleX:0.7173,scaleY:0.6943,skewY:-4.0428,x:-13.55,y:-12.7},0).wait(1).to({scaleX:0.7347,scaleY:0.7108,skewY:-3.9571,x:-11.55,y:-14.6},0).wait(1).to({scaleX:0.7555,scaleY:0.7305,skewY:-3.8546,x:-9.15,y:-16.9},0).wait(1).to({scaleX:0.7798,scaleY:0.7534,skewY:-3.735,x:-6.4,y:-19.6},0).wait(1).to({scaleX:0.8075,scaleY:0.7796,skewY:-3.5984,x:-3.25,y:-22.6},0).wait(1).to({scaleX:0.8385,scaleY:0.809,skewY:-3.4452,x:0.3,y:-26.05},0).wait(1).to({scaleX:0.8727,scaleY:0.8414,skewY:-3.2766,x:4.2,y:-29.85},0).wait(1).to({scaleX:0.9097,scaleY:0.8764,skewY:-3.0943,x:8.45,y:-33.9},0).wait(1).to({scaleX:0.949,scaleY:0.9136,skewY:-2.9004,x:12.9,y:-38.2},0).wait(1).to({scaleX:0.9901,scaleY:0.9524,skewY:-2.6979,x:17.65,y:-42.65},0).wait(1).to({scaleX:1.0323,scaleY:0.9923,skewY:-2.4899,x:22.45,y:-47.3},0).wait(1).to({scaleX:1.0749,scaleY:1.0327,skewY:-2.2798,x:27.3,y:-51.9},0).wait(1).to({scaleX:1.1173,scaleY:1.0727,skewY:-2.0709,x:32.15,y:-56.5},0).wait(1).to({scaleX:1.1587,scaleY:1.112,skewY:-1.8662,x:36.85,y:-61},0).wait(1).to({scaleX:1.1988,scaleY:1.15,skewY:-1.6685,x:41.45,y:-65.35},0).wait(1).to({scaleX:1.2371,scaleY:1.1862,skewY:-1.4798,x:45.85,y:-69.5},0).wait(1).to({scaleX:1.2733,scaleY:1.2203,skewY:-1.3016,x:49.95,y:-73.35},0).wait(1).to({scaleX:1.307,scaleY:1.2523,skewY:-1.1352,x:53.8,y:-77},0).wait(1).to({scaleX:1.3383,scaleY:1.2819,skewY:-0.981,x:57.4,y:-80.3},0).wait(1).to({scaleX:1.367,scaleY:1.309,skewY:-0.8395,x:60.7,y:-83.45},0).wait(1).to({scaleX:1.3931,scaleY:1.3338,skewY:-0.7105,x:63.65,y:-86.25},0).wait(1).to({scaleX:1.4168,scaleY:1.3561,skewY:-0.594,x:66.35,y:-88.75},0).wait(1).to({scaleX:1.438,scaleY:1.3762,skewY:-0.4895,x:68.75,y:-91},0).wait(1).to({scaleX:1.4568,scaleY:1.394,skewY:-0.3967,x:70.9,y:-93.05},0).wait(1).to({scaleX:1.4733,scaleY:1.4097,skewY:-0.3151,x:72.8,y:-94.8},0).wait(1).to({scaleX:1.4877,scaleY:1.4233,skewY:-0.2441,x:74.5,y:-96.35},0).wait(1).to({scaleX:1.5001,scaleY:1.435,skewY:-0.1833,x:75.85,y:-97.6},0).wait(1).to({scaleX:1.5105,scaleY:1.4448,skewY:-0.1321,x:77.05,y:-98.75},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.09,x:78,y:-99.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0565,x:78.8,y:-100.35},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:79.4,y:-100.95},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:79.8,y:-101.35},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:80.05,y:-101.5},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:32.05,y:-142.9},0).wait(1));

	// Small
	this.s_pie = new lib.small_pie();
	this.s_pie.name = "s_pie";
	this.s_pie.setTransform(-40.3,-18.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.s_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.s_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-40.2,y:-18.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:269.2,regY:169.2,scaleX:0.6927,scaleY:0.6711,skewY:-4.1641,x:1.55,y:-50.05},0).wait(1).to({scaleX:0.7048,scaleY:0.6824,skewY:-4.1049,x:3.3,y:-52.3},0).wait(1).to({scaleX:0.7213,scaleY:0.6981,skewY:-4.0234,x:5.65,y:-55.3},0).wait(1).to({scaleX:0.7432,scaleY:0.7188,skewY:-3.9155,x:8.75,y:-59.4},0).wait(1).to({scaleX:0.7714,scaleY:0.7455,skewY:-3.7762,x:12.75,y:-64.6},0).wait(1).to({scaleX:0.8071,scaleY:0.7792,skewY:-3.6003,x:17.85,y:-71.2},0).wait(1).to({scaleX:0.8509,scaleY:0.8207,skewY:-3.3844,x:24.05,y:-79.25},0).wait(1).to({scaleX:0.9026,scaleY:0.8697,skewY:-3.1291,x:31.4,y:-88.75},0).wait(1).to({scaleX:0.9607,scaleY:0.9247,skewY:-2.8425,x:39.7,y:-99.4},0).wait(1).to({scaleX:1.0219,scaleY:0.9825,skewY:-2.541,x:48.4,y:-110.6},0).wait(1).to({scaleX:1.0823,scaleY:1.0396,skewY:-2.2435,x:57,y:-121.55},0).wait(1).to({scaleX:1.1388,scaleY:1.0931,skewY:-1.9646,x:65.05,y:-131.85},0).wait(1).to({scaleX:1.1901,scaleY:1.1416,skewY:-1.7118,x:72.3,y:-141.1},0).wait(1).to({scaleX:1.2357,scaleY:1.1848,skewY:-1.4869,x:78.85,y:-149.35},0).wait(1).to({scaleX:1.2759,scaleY:1.2229,skewY:-1.2886,x:84.55,y:-156.55},0).wait(1).to({scaleX:1.3113,scaleY:1.2563,skewY:-1.1142,x:89.55,y:-162.9},0).wait(1).to({scaleX:1.3423,scaleY:1.2857,skewY:-0.961,x:94,y:-168.45},0).wait(1).to({scaleX:1.3697,scaleY:1.3116,skewY:-0.8262,x:97.85,y:-173.35},0).wait(1).to({scaleX:1.3937,scaleY:1.3343,skewY:-0.7076,x:101.3,y:-177.7},0).wait(1).to({scaleX:1.4149,scaleY:1.3544,skewY:-0.603,x:104.3,y:-181.45},0).wait(1).to({scaleX:1.4336,scaleY:1.3721,skewY:-0.5109,x:106.95,y:-184.8},0).wait(1).to({scaleX:1.4501,scaleY:1.3876,skewY:-0.4298,x:109.35,y:-187.65},0).wait(1).to({scaleX:1.4646,scaleY:1.4013,skewY:-0.3585,x:111.4,y:-190.25},0).wait(1).to({scaleX:1.4772,scaleY:1.4134,skewY:-0.2959,x:113.2,y:-192.5},0).wait(1).to({scaleX:1.4883,scaleY:1.4238,skewY:-0.2411,x:114.75,y:-194.5},0).wait(1).to({scaleX:1.498,scaleY:1.433,skewY:-0.1936,x:116.15,y:-196.2},0).wait(1).to({scaleX:1.5063,scaleY:1.4409,skewY:-0.1524,x:117.35,y:-197.7},0).wait(1).to({scaleX:1.5135,scaleY:1.4476,skewY:-0.1172,x:118.3,y:-198.95},0).wait(1).to({scaleX:1.5195,scaleY:1.4533,skewY:-0.0874,x:119.2,y:-200},0).wait(1).to({scaleX:1.5245,scaleY:1.4581,skewY:-0.0627,x:119.9,y:-200.9},0).wait(1).to({scaleX:1.5286,scaleY:1.462,skewY:0,x:120.5,y:-201.65},0).wait(1).to({scaleX:1.5318,scaleY:1.465,x:120.95,y:-202.2},0).wait(1).to({scaleX:1.5343,scaleY:1.4673,x:121.25,y:-202.65},0).wait(1).to({scaleX:1.5359,scaleY:1.4689,x:121.5,y:-202.9},0).wait(1).to({scaleX:1.5369,scaleY:1.4698,x:121.7,y:-203.1},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.45,y:-143.4},0).wait(1));

	// Shadow
	this.c_shadow = new lib.chart_shadow();
	this.c_shadow.name = "c_shadow";
	this.c_shadow.setTransform(-26.45,-49.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.c_shadow.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.c_shadow).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,y:-49.55},1,cjs.Ease.cubicInOut).wait(1).to({regX:227.6,regY:275.6,scaleX:0.6926,scaleY:0.6709,skewY:-4.165,x:-13.6,y:-7.15,alpha:0.0512},0).wait(1).to({scaleX:0.7037,scaleY:0.6815,skewY:-4.1099,x:-12.65,y:-7.75,alpha:0.1221},0).wait(1).to({scaleX:0.7181,scaleY:0.6951,skewY:-4.0387,x:-11.45,y:-8.4,alpha:0.2138},0).wait(1).to({scaleX:0.7359,scaleY:0.7119,skewY:-3.9508,x:-9.95,y:-9.3,alpha:0.327},0).wait(1).to({scaleX:0.7572,scaleY:0.7321,skewY:-3.8458,x:-8.15,y:-10.35,alpha:0.4622},0).wait(1).to({scaleX:0.782,scaleY:0.7555,skewY:-3.7235,x:-6.1,y:-11.55,alpha:0.6198},0).wait(1).to({scaleX:0.8102,scaleY:0.7823,skewY:-3.5841,x:-3.7,y:-12.95,alpha:0.7993},0).wait(1).to({regX:209.8,regY:209.8,scaleX:0.8418,scaleY:0.8121,skewY:-3.4282,x:-16,y:-66.95,alpha:1},0).wait(1).to({regX:227.6,regY:275.6,scaleX:0.8765,scaleY:0.8449,skewY:-3.2574,x:1.9,y:-16.1},0).wait(1).to({scaleX:0.9138,scaleY:0.8803,skewY:-3.0733,x:5.05,y:-17.9},0).wait(1).to({scaleX:0.9534,scaleY:0.9177,skewY:-2.8783,x:8.35,y:-19.8},0).wait(1).to({scaleX:0.9945,scaleY:0.9566,skewY:-2.6753,x:11.85,y:-21.8},0).wait(1).to({scaleX:1.0367,scaleY:0.9965,skewY:-2.4676,x:15.45,y:-23.8},0).wait(1).to({scaleX:1.0791,scaleY:1.0367,skewY:-2.2583,x:18.95,y:-25.9},0).wait(1).to({scaleX:1.1212,scaleY:1.0765,skewY:-2.0509,x:22.5,y:-27.85},0).wait(1).to({scaleX:1.1623,scaleY:1.1154,skewY:-1.8481,x:26,y:-29.85},0).wait(1).to({scaleX:1.2021,scaleY:1.153,skewY:-1.6524,x:29.35,y:-31.7},0).wait(1).to({scaleX:1.2399,scaleY:1.1888,skewY:-1.4658,x:32.55,y:-33.45},0).wait(1).to({scaleX:1.2756,scaleY:1.2226,skewY:-1.2898,x:35.55,y:-35.2},0).wait(1).to({scaleX:1.309,scaleY:1.2541,skewY:-1.1253,x:38.35,y:-36.75},0).wait(1).to({scaleX:1.3399,scaleY:1.2834,skewY:-0.973,x:40.95,y:-38.25},0).wait(1).to({scaleX:1.3682,scaleY:1.3102,skewY:-0.8331,x:43.4,y:-39.55},0).wait(1).to({scaleX:1.3941,scaleY:1.3347,skewY:-0.7055,x:45.5,y:-40.75},0).wait(1).to({scaleX:1.4175,scaleY:1.3569,skewY:-0.5901,x:47.5,y:-41.85},0).wait(1).to({scaleX:1.4385,scaleY:1.3767,skewY:-0.4866,x:49.3,y:-42.9},0).wait(1).to({scaleX:1.4572,scaleY:1.3944,skewY:-0.3946,x:50.85,y:-43.7},0).wait(1).to({scaleX:1.4736,scaleY:1.4099,skewY:-0.3136,x:52.25,y:-44.45},0).wait(1).to({scaleX:1.4879,scaleY:1.4235,skewY:-0.2431,x:53.45,y:-45.15},0).wait(1).to({scaleX:1.5002,scaleY:1.4351,skewY:-0.1826,x:54.5,y:-45.75},0).wait(1).to({scaleX:1.5105,scaleY:1.4449,skewY:-0.1317,x:55.35,y:-46.2},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.0897,x:56.05,y:-46.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0564,x:56.6,y:-46.9},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:57.1,y:-47.15},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:57.35,y:-47.3},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:57.5,y:-47.4},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.2,y:-144.25},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140,-257.9,395.1,399.29999999999995);


(lib.UI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.mainUI.cache(-475,-300,950,600,0.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Main_UI
	this.mainUI = new lib.main_ui();
	this.mainUI.name = "mainUI";

	this.timeline.addTween(cjs.Tween.get(this.mainUI).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.screenanimation_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_172 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(172).call(this.frame_172).wait(3));

	// guy right icon.png
	this.instance_3 = new lib.guyrighticon();
	this.instance_3.setTransform(198.85,-85.15,1,1,0,0,0,26.4,21.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({_off:false},0).to({regY:21.4,scaleX:1.6102,scaleY:1.6102,x:261.15,y:-64.15,alpha:1},36,cjs.Ease.quadOut).wait(1).to({regX:26.5,x:261.3},0).wait(23).to({regX:26.4,x:261.15},0).wait(1).to({regX:26.5,scaleX:1.5993,scaleY:1.5993,x:260.4,y:-62.75},0).wait(1).to({scaleX:1.5839,scaleY:1.5839,x:259.1,y:-60.9},0).wait(1).to({scaleX:1.5636,scaleY:1.5636,x:257.5,y:-58.45},0).wait(1).to({scaleX:1.5384,scaleY:1.5384,x:255.4,y:-55.4},0).wait(1).to({scaleX:1.5083,scaleY:1.5083,x:252.9,y:-51.65},0).wait(1).to({scaleX:1.4731,scaleY:1.4731,x:250.05,y:-47.4},0).wait(1).to({scaleX:1.4331,scaleY:1.4331,x:246.75,y:-42.5},0).wait(1).to({scaleX:1.3884,scaleY:1.3884,x:243.05,y:-37.05},0).wait(1).to({scaleX:1.3396,scaleY:1.3396,x:239.05,y:-31.1},0).wait(1).to({scaleX:1.2873,scaleY:1.2873,x:234.75,y:-24.65},0).wait(1).to({scaleX:1.2323,scaleY:1.2323,x:230.2,y:-17.95},0).wait(1).to({scaleX:1.1755,scaleY:1.1755,x:225.55,y:-11},0).wait(1).to({scaleX:1.1179,scaleY:1.1179,x:220.8,y:-4},0).wait(1).to({scaleX:1.0607,scaleY:1.0607,x:216.1,y:3.05},0).wait(1).to({scaleX:1.0049,scaleY:1.0049,x:211.55,y:9.85},0).wait(1).to({scaleX:0.9516,scaleY:0.9516,x:207.1,y:16.35},0).wait(1).to({scaleX:0.9014,scaleY:0.9014,x:203,y:22.45},0).wait(1).to({scaleX:0.855,scaleY:0.855,x:199.2,y:28.1},0).wait(1).to({scaleX:0.813,scaleY:0.813,x:195.75,y:33.25},0).wait(1).to({scaleX:0.7755,scaleY:0.7755,x:192.65,y:37.85},0).wait(1).to({scaleX:0.7428,scaleY:0.7428,x:190,y:41.85},0).wait(1).to({scaleX:0.7149,scaleY:0.7149,x:187.65,y:45.25},0).wait(1).to({scaleX:0.6917,scaleY:0.6917,x:185.8,y:48.05},0).wait(1).to({scaleX:0.6732,scaleY:0.6732,x:184.25,y:50.35},0).wait(1).to({scaleX:0.6591,scaleY:0.6591,x:183.05,y:52.05},0).wait(1).to({scaleX:0.6493,scaleY:0.6493,x:182.25,y:53.25},0).wait(1).to({scaleX:0.6435,scaleY:0.6435,x:181.8,y:53.95},0).wait(1).to({regX:26.4,regY:21.5,scaleX:0.6417,scaleY:0.6417,x:181.65,y:54.25},0).wait(1).to({regX:26.5,regY:21.4,x:181.7,y:54.2},0).wait(8).to({regX:26.4,regY:21.5,x:181.65,y:54.25},0).wait(1).to({regX:26.5,regY:21.4,scaleX:0.6415,scaleY:0.6415,x:181.7,y:54.15},0).wait(1).to({scaleX:0.6413,scaleY:0.6413,y:54.1},0).wait(1).to({scaleX:0.6408,scaleY:0.6408,x:181.75,y:54.05},0).wait(1).to({scaleX:0.6403,scaleY:0.6403,x:181.7,y:54},0).wait(1).to({scaleX:0.6395,scaleY:0.6395,x:181.75,y:53.95},0).wait(1).to({scaleX:0.6386,scaleY:0.6386,y:53.85},0).wait(1).to({scaleX:0.6375,scaleY:0.6375,x:181.85,y:53.75},0).wait(1).to({scaleX:0.6361,scaleY:0.6361,y:53.55},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:181.9,y:53.45},0).wait(1).to({scaleX:0.6325,scaleY:0.6325,x:182,y:53.25},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:182.1,y:53},0).wait(1).to({scaleX:0.6275,scaleY:0.6275,x:182.2,y:52.7},0).wait(1).to({scaleX:0.6242,scaleY:0.6242,x:182.3,y:52.35},0).wait(1).to({scaleX:0.6204,scaleY:0.6204,x:182.45,y:52},0).wait(1).to({scaleX:0.6158,scaleY:0.6158,x:182.6,y:51.5},0).wait(1).to({scaleX:0.6102,scaleY:0.6102,x:182.75,y:50.9},0).wait(1).to({scaleX:0.6033,scaleY:0.6033,x:183.05,y:50.2},0).wait(1).to({scaleX:0.5947,scaleY:0.5947,x:183.35,y:49.35},0).wait(1).to({scaleX:0.5835,scaleY:0.5835,x:183.7,y:48.2},0).wait(1).to({scaleX:0.5687,scaleY:0.5687,x:184.25,y:46.65},0).wait(1).to({scaleX:0.5492,scaleY:0.5492,x:184.95,y:44.65},0).wait(1).to({scaleX:0.5267,scaleY:0.5267,x:185.75,y:42.35},0).wait(1).to({scaleX:0.5067,scaleY:0.5067,x:186.45,y:40.3},0).wait(1).to({scaleX:0.4914,scaleY:0.4914,x:186.95,y:38.7},0).wait(1).to({scaleX:0.4798,scaleY:0.4798,x:187.4,y:37.5},0).wait(1).to({scaleX:0.4707,scaleY:0.4707,x:187.7,y:36.55},0).wait(1).to({scaleX:0.4634,scaleY:0.4634,x:188,y:35.85},0).wait(1).to({scaleX:0.4575,scaleY:0.4575,x:188.15,y:35.25},0).wait(1).to({scaleX:0.4525,scaleY:0.4525,x:188.4,y:34.75},0).wait(1).to({scaleX:0.4483,scaleY:0.4483,x:188.55,y:34.3},0).wait(1).to({scaleX:0.4447,scaleY:0.4447,x:188.65,y:33.9},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:188.75,y:33.6},0).wait(1).to({scaleX:0.4391,scaleY:0.4391,x:188.85,y:33.35},0).wait(1).to({scaleX:0.4368,scaleY:0.4368,x:188.95,y:33.1},0).wait(1).to({scaleX:0.4349,scaleY:0.4349,y:32.9},0).wait(1).to({scaleX:0.4332,scaleY:0.4332,x:189.05,y:32.7},0).wait(1).to({scaleX:0.4318,scaleY:0.4318,x:189.1,y:32.6},0).wait(1).to({scaleX:0.4306,scaleY:0.4306,x:189.15,y:32.45},0).wait(1).to({scaleX:0.4296,scaleY:0.4296,x:189.2,y:32.4},0).wait(1).to({scaleX:0.4288,scaleY:0.4288,y:32.3},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:189.25,y:32.2},0).wait(1).to({scaleX:0.4276,scaleY:0.4276,y:32.15},0).wait(1).to({scaleX:0.4273,scaleY:0.4273},0).wait(1).to({scaleX:0.427,scaleY:0.427,y:32.1},0).wait(1).to({scaleX:0.4268,scaleY:0.4268},0).wait(1).to({regY:21.6,y:32.15},0).to({_off:true},1).wait(2));

	// guy left icon.png
	this.instance_4 = new lib.guylefticon();
	this.instance_4.setTransform(-108.15,55.1,1,1,0,0,0,25.9,20.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({scaleX:1.6102,scaleY:1.6102,x:59.95,y:-35.8,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:26.1,regY:20.6,x:60.3,y:-35.5},0).wait(22).to({regX:25.9,regY:20.4,x:59.95,y:-35.8},0).wait(1).to({regX:26.1,regY:20.6,scaleX:1.5988,scaleY:1.5988,x:61.3,y:-34.3},0).wait(1).to({scaleX:1.5836,scaleY:1.5836,x:62.65,y:-32.85},0).wait(1).to({scaleX:1.5643,scaleY:1.5643,x:64.35,y:-30.95},0).wait(1).to({scaleX:1.5407,scaleY:1.5407,x:66.4,y:-28.6},0).wait(1).to({scaleX:1.5127,scaleY:1.5127,x:68.9,y:-25.85},0).wait(1).to({scaleX:1.4799,scaleY:1.4799,x:71.8,y:-22.55},0).wait(1).to({scaleX:1.4424,scaleY:1.4424,x:75.15,y:-18.9},0).wait(1).to({scaleX:1.4,scaleY:1.4,x:78.9,y:-14.65},0).wait(1).to({scaleX:1.3528,scaleY:1.3528,x:83.05,y:-10},0).wait(1).to({scaleX:1.301,scaleY:1.301,x:87.65,y:-4.9},0).wait(1).to({scaleX:1.245,scaleY:1.245,x:92.65,y:0.65},0).wait(1).to({scaleX:1.1854,scaleY:1.1854,x:97.9,y:6.55},0).wait(1).to({scaleX:1.123,scaleY:1.123,x:103.45,y:12.75},0).wait(1).to({scaleX:1.0589,scaleY:1.0589,x:109.15,y:19.05},0).wait(1).to({scaleX:0.9942,scaleY:0.9942,x:114.85,y:25.4},0).wait(1).to({scaleX:0.9302,scaleY:0.9302,x:120.55,y:31.7},0).wait(1).to({scaleX:0.8682,scaleY:0.8682,x:126,y:37.9},0).wait(1).to({scaleX:0.8091,scaleY:0.8091,x:131.25,y:43.7},0).wait(1).to({scaleX:0.754,scaleY:0.754,x:136.15,y:49.15},0).wait(1).to({scaleX:0.7035,scaleY:0.7035,x:140.6,y:54.15},0).wait(1).to({scaleX:0.6581,scaleY:0.6581,x:144.7,y:58.65},0).wait(1).to({scaleX:0.618,scaleY:0.618,x:148.25,y:62.6},0).wait(1).to({scaleX:0.5833,scaleY:0.5833,x:151.25,y:66},0).wait(1).to({scaleX:0.5539,scaleY:0.5539,x:153.9,y:68.9},0).wait(1).to({scaleX:0.5297,scaleY:0.5297,x:156.05,y:71.3},0).wait(1).to({scaleX:0.5105,scaleY:0.5105,x:157.7,y:73.2},0).wait(1).to({scaleX:0.4961,scaleY:0.4961,x:159,y:74.65},0).wait(1).to({scaleX:0.4861,scaleY:0.4861,x:159.9,y:75.65},0).wait(1).to({scaleX:0.4803,scaleY:0.4803,x:160.45,y:76.2},0).wait(1).to({regX:26,scaleX:0.4784,scaleY:0.4784,x:160.55,y:76.3},0).wait(1).to({regX:26.1,x:160.6},0).wait(6).to({regX:26,x:160.55},0).wait(1).to({regX:26.1,x:160.6},0).wait(1).to({regX:26,x:160.55},0).wait(1).to({regX:26.1,y:76.25},0).wait(1).to({scaleX:0.4783,scaleY:0.4783,x:160.45,y:76.2},0).wait(1).to({scaleX:0.4782,scaleY:0.4782,x:160.35,y:76.15},0).wait(1).to({scaleX:0.4781,scaleY:0.4781,x:160.25,y:76.05},0).wait(1).to({scaleX:0.478,scaleY:0.478,x:160,y:75.95},0).wait(1).to({scaleX:0.4778,scaleY:0.4778,x:159.75,y:75.8},0).wait(1).to({scaleX:0.4775,scaleY:0.4775,x:159.45,y:75.6},0).wait(1).to({scaleX:0.4772,scaleY:0.4772,x:159.1,y:75.4},0).wait(1).to({scaleX:0.4769,scaleY:0.4769,x:158.65,y:75.05},0).wait(1).to({scaleX:0.4764,scaleY:0.4764,x:158.1,y:74.7},0).wait(1).to({scaleX:0.4759,scaleY:0.4759,x:157.35,y:74.3},0).wait(1).to({scaleX:0.4752,scaleY:0.4752,x:156.55,y:73.8},0).wait(1).to({scaleX:0.4744,scaleY:0.4744,x:155.5,y:73.15},0).wait(1).to({scaleX:0.4733,scaleY:0.4733,x:154.2,y:72.35},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:152.5,y:71.25},0).wait(1).to({scaleX:0.4702,scaleY:0.4702,x:150.2,y:69.9},0).wait(1).to({scaleX:0.4677,scaleY:0.4677,x:147.05,y:67.95},0).wait(1).to({scaleX:0.4643,scaleY:0.4643,x:142.7,y:65.25},0).wait(1).to({scaleX:0.4605,scaleY:0.4605,x:138,y:62.35},0).wait(1).to({scaleX:0.4576,scaleY:0.4576,x:134.35,y:60.1},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:131.65,y:58.45},0).wait(1).to({scaleX:0.4539,scaleY:0.4539,x:129.7,y:57.2},0).wait(1).to({scaleX:0.4527,scaleY:0.4527,x:128.15,y:56.25},0).wait(1).to({scaleX:0.4517,scaleY:0.4517,x:126.95,y:55.5},0).wait(1).to({scaleX:0.451,scaleY:0.451,x:125.95,y:54.9},0).wait(1).to({scaleX:0.4503,scaleY:0.4503,x:125.15,y:54.4},0).wait(1).to({scaleX:0.4498,scaleY:0.4498,x:124.5,y:53.95},0).wait(1).to({scaleX:0.4493,scaleY:0.4493,x:123.95,y:53.6},0).wait(1).to({scaleX:0.449,scaleY:0.449,x:123.45,y:53.35},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:123.05,y:53.1},0).wait(1).to({scaleX:0.4484,scaleY:0.4484,x:122.75,y:52.9},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:122.45,y:52.75},0).wait(1).to({scaleX:0.448,scaleY:0.448,x:122.25,y:52.6},0).wait(1).to({scaleX:0.4479,scaleY:0.4479,x:122.1,y:52.5},0).wait(1).to({scaleX:0.4478,scaleY:0.4478,x:121.95,y:52.4},0).wait(1).to({scaleX:0.4477,scaleY:0.4477,x:121.85,y:52.3},0).wait(1).to({scaleX:0.4476,scaleY:0.4476,x:121.8},0).wait(1).to({x:121.75,y:52.25},0).wait(1).to({regX:26.2,regY:20.7,y:52.3},0).to({_off:true},6).wait(2));

	// girl right icon.png
	this.instance_5 = new lib.girlrighticon();
	this.instance_5.setTransform(188.95,241.45,1,1,0,0,0,25.9,21.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({regY:21.6,scaleX:1.6102,scaleY:1.6102,x:212.35,y:215.9,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:26,regY:21.5,x:212.5,y:215.7},0).wait(23).to({regX:25.9,regY:21.6,x:212.35,y:215.9},0).wait(1).to({regX:26,regY:21.5,scaleX:1.5895,scaleY:1.5895,x:211.6,y:213.85},0).wait(1).to({scaleX:1.5651,scaleY:1.5651,x:210.55,y:211.75},0).wait(1).to({scaleX:1.5372,scaleY:1.5372,x:209.35,y:209.3},0).wait(1).to({scaleX:1.5056,scaleY:1.5056,x:208,y:206.5},0).wait(1).to({scaleX:1.4704,scaleY:1.4704,x:206.5,y:203.45},0).wait(1).to({scaleX:1.4318,scaleY:1.4318,x:204.8,y:200.05},0).wait(1).to({scaleX:1.3899,scaleY:1.3899,x:203,y:196.4},0).wait(1).to({scaleX:1.3452,scaleY:1.3452,x:201.05,y:192.45},0).wait(1).to({scaleX:1.298,scaleY:1.298,x:199.05,y:188.3},0).wait(1).to({scaleX:1.2488,scaleY:1.2488,x:196.9,y:184},0).wait(1).to({scaleX:1.1981,scaleY:1.1981,x:194.75,y:179.55},0).wait(1).to({scaleX:1.1468,scaleY:1.1468,x:192.5,y:175.05},0).wait(1).to({scaleX:1.0954,scaleY:1.0954,x:190.3,y:170.55},0).wait(1).to({scaleX:1.0446,scaleY:1.0446,x:188.1,y:166.1},0).wait(1).to({scaleX:0.995,scaleY:0.995,x:185.95,y:161.8},0).wait(1).to({scaleX:0.9474,scaleY:0.9474,x:183.95,y:157.6},0).wait(1).to({scaleX:0.9022,scaleY:0.9022,x:181.95,y:153.65},0).wait(1).to({scaleX:0.8598,scaleY:0.8598,x:180.15,y:149.95},0).wait(1).to({scaleX:0.8207,scaleY:0.8207,x:178.5,y:146.5},0).wait(1).to({scaleX:0.7849,scaleY:0.7849,x:176.9,y:143.4},0).wait(1).to({scaleX:0.7527,scaleY:0.7527,x:175.5,y:140.55},0).wait(1).to({scaleX:0.7242,scaleY:0.7242,x:174.35,y:138},0).wait(1).to({scaleX:0.6994,scaleY:0.6994,x:173.25,y:135.85},0).wait(1).to({scaleX:0.6782,scaleY:0.6782,x:172.35,y:134},0).wait(1).to({scaleX:0.6606,scaleY:0.6606,x:171.55,y:132.45},0).wait(1).to({scaleX:0.6464,scaleY:0.6464,x:170.95,y:131.2},0).wait(1).to({scaleX:0.6357,scaleY:0.6357,x:170.5,y:130.25},0).wait(1).to({scaleX:0.6282,scaleY:0.6282,x:170.2,y:129.6},0).wait(1).to({scaleX:0.6238,scaleY:0.6238,x:169.95,y:129.2},0).wait(1).to({regX:26.1,regY:21.6,scaleX:0.6223,scaleY:0.6223},0).wait(1).to({regX:26,regY:21.5,x:169.9,y:129.15},0).wait(6).to({regX:26.1,regY:21.6,x:169.95,y:129.2},0).wait(1).to({regX:26,regY:21.5,x:169.9,y:129.15},0).wait(2).to({regX:26.1,regY:21.6,x:169.95,y:129.2},0).wait(1).to({regX:26,regY:21.5,scaleX:0.6222,scaleY:0.6222,x:169.85,y:129.05},0).wait(1).to({scaleX:0.6219,scaleY:0.6219,x:169.8,y:128.9},0).wait(1).to({scaleX:0.6215,scaleY:0.6215,x:169.75,y:128.75},0).wait(1).to({scaleX:0.6209,scaleY:0.6209,x:169.7,y:128.5},0).wait(1).to({scaleX:0.6201,scaleY:0.6201,x:169.55,y:128.2},0).wait(1).to({scaleX:0.6191,scaleY:0.6191,x:169.45,y:127.75},0).wait(1).to({scaleX:0.6179,scaleY:0.6179,x:169.25,y:127.25},0).wait(1).to({scaleX:0.6164,scaleY:0.6164,x:169.1,y:126.6},0).wait(1).to({scaleX:0.6146,scaleY:0.6146,x:168.9,y:125.8},0).wait(1).to({scaleX:0.6124,scaleY:0.6124,x:168.55,y:124.9},0).wait(1).to({scaleX:0.6098,scaleY:0.6098,x:168.25,y:123.85},0).wait(1).to({scaleX:0.6067,scaleY:0.6067,x:167.9,y:122.55},0).wait(1).to({scaleX:0.603,scaleY:0.603,x:167.4,y:120.95},0).wait(1).to({scaleX:0.5985,scaleY:0.5985,x:166.8,y:119.05},0).wait(1).to({scaleX:0.593,scaleY:0.593,x:166.05,y:116.75},0).wait(1).to({scaleX:0.5861,scaleY:0.5861,x:165.2,y:113.85},0).wait(1).to({scaleX:0.5772,scaleY:0.5772,x:164.05,y:110.1},0).wait(1).to({scaleX:0.5655,scaleY:0.5655,x:162.55,y:105.15},0).wait(1).to({scaleX:0.5496,scaleY:0.5496,x:160.55,y:98.45},0).wait(1).to({scaleX:0.5288,scaleY:0.5288,x:157.85,y:89.65},0).wait(1).to({scaleX:0.5071,scaleY:0.5071,x:155.1,y:80.55},0).wait(1).to({scaleX:0.4896,scaleY:0.4896,x:152.85,y:73.2},0).wait(1).to({scaleX:0.4767,scaleY:0.4767,x:151.2,y:67.75},0).wait(1).to({scaleX:0.467,scaleY:0.467,x:149.95,y:63.65},0).wait(1).to({scaleX:0.4593,scaleY:0.4593,x:148.95,y:60.4},0).wait(1).to({scaleX:0.4532,scaleY:0.4532,x:148.2,y:57.85},0).wait(1).to({scaleX:0.4481,scaleY:0.4481,x:147.5,y:55.7},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:147,y:53.95},0).wait(1).to({scaleX:0.4404,scaleY:0.4404,x:146.55,y:52.4},0).wait(1).to({scaleX:0.4374,scaleY:0.4374,x:146.1,y:51.15},0).wait(1).to({scaleX:0.4349,scaleY:0.4349,x:145.8,y:50.1},0).wait(1).to({scaleX:0.4327,scaleY:0.4327,x:145.55,y:49.2},0).wait(1).to({scaleX:0.4309,scaleY:0.4309,x:145.3,y:48.4},0).wait(1).to({scaleX:0.4293,scaleY:0.4293,x:145.1,y:47.8},0).wait(1).to({scaleX:0.428,scaleY:0.428,x:144.95,y:47.25},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:144.8,y:46.8},0).wait(1).to({scaleX:0.4261,scaleY:0.4261,x:144.7,y:46.4},0).wait(1).to({scaleX:0.4253,scaleY:0.4253,x:144.6,y:46.1},0).wait(1).to({scaleX:0.4248,scaleY:0.4248,x:144.55,y:45.9},0).wait(1).to({scaleX:0.4244,scaleY:0.4244,x:144.5,y:45.65},0).wait(1).to({scaleX:0.4241,scaleY:0.4241,x:144.45,y:45.55},0).wait(1).to({scaleX:0.4239,scaleY:0.4239,x:144.4,y:45.5},0).wait(1).to({regX:26.2,regY:21.7,x:144.45,y:45.55},0).to({_off:true},1).wait(2));

	// girl left icon.png
	this.instance_6 = new lib.girllefticon();
	this.instance_6.setTransform(-119.4,159.2,1,1,0,0,0,25.3,21.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(22).to({_off:false},0).to({regX:25.4,regY:21.4,scaleX:1.6102,scaleY:1.6102,x:36.25,y:122.05,alpha:1},41,cjs.Ease.quadOut).wait(1).to({regY:21.3,y:121.9},0).wait(25).to({regY:21.4,y:122.05},0).wait(1).to({regY:21.3,scaleX:1.6007,scaleY:1.6007,x:37.3,y:121.7},0).wait(1).to({scaleX:1.5878,scaleY:1.5878,x:38.8,y:121.4},0).wait(1).to({scaleX:1.5713,scaleY:1.5713,x:40.55,y:121.05},0).wait(1).to({scaleX:1.551,scaleY:1.551,x:42.8,y:120.65},0).wait(1).to({scaleX:1.5268,scaleY:1.5268,x:45.5,y:120.15},0).wait(1).to({scaleX:1.4985,scaleY:1.4985,x:48.65,y:119.55},0).wait(1).to({scaleX:1.4658,scaleY:1.4658,x:52.3,y:118.9},0).wait(1).to({scaleX:1.4289,scaleY:1.4289,x:56.4,y:118.15},0).wait(1).to({scaleX:1.3875,scaleY:1.3875,x:61,y:117.3},0).wait(1).to({scaleX:1.3419,scaleY:1.3419,x:66.05,y:116.4},0).wait(1).to({scaleX:1.2922,scaleY:1.2922,x:71.55,y:115.35},0).wait(1).to({scaleX:1.2389,scaleY:1.2389,x:77.5,y:114.25},0).wait(1).to({scaleX:1.1824,scaleY:1.1824,x:83.8,y:113.1},0).wait(1).to({scaleX:1.1234,scaleY:1.1234,x:90.4,y:111.9},0).wait(1).to({scaleX:1.0629,scaleY:1.0629,x:97.1,y:110.65},0).wait(1).to({scaleX:1.0019,scaleY:1.0019,x:103.9,y:109.4},0).wait(1).to({scaleX:0.9413,scaleY:0.9413,x:110.6,y:108.15},0).wait(1).to({scaleX:0.8823,scaleY:0.8823,x:117.15,y:106.95},0).wait(1).to({scaleX:0.8258,scaleY:0.8258,x:123.5,y:105.8},0).wait(1).to({scaleX:0.7726,scaleY:0.7726,x:129.35,y:104.7},0).wait(1).to({scaleX:0.7234,scaleY:0.7234,x:134.85,y:103.7},0).wait(1).to({scaleX:0.6785,scaleY:0.6785,x:139.85,y:102.75},0).wait(1).to({scaleX:0.6383,scaleY:0.6383,x:144.3,y:101.95},0).wait(1).to({scaleX:0.6029,scaleY:0.6029,x:148.25,y:101.25},0).wait(1).to({scaleX:0.5723,scaleY:0.5723,x:151.65,y:100.6},0).wait(1).to({scaleX:0.5465,scaleY:0.5465,x:154.55,y:100.05},0).wait(1).to({scaleX:0.5251,scaleY:0.5251,x:156.9,y:99.65},0).wait(1).to({scaleX:0.5082,scaleY:0.5082,x:158.8,y:99.25},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:160.25,y:99},0).wait(1).to({scaleX:0.4865,scaleY:0.4865,x:161.2,y:98.8},0).wait(1).to({scaleX:0.4814,scaleY:0.4814,x:161.8,y:98.7},0).wait(1).to({regY:21.4,scaleX:0.4797,scaleY:0.4797,x:162,y:98.75},0).wait(1).to({regY:21.3,y:98.7},0).wait(4).to({regY:21.4,y:98.75},0).wait(1).to({regY:21.3,y:98.7},0).wait(4).to({regY:21.4,y:98.75},0).wait(1).to({regY:21.3,scaleX:0.4796,scaleY:0.4796,y:98.65},0).wait(1).to({y:98.55},0).wait(1).to({scaleX:0.4794,scaleY:0.4794,y:98.4},0).wait(1).to({scaleX:0.4792,scaleY:0.4792,y:98.2},0).wait(1).to({scaleX:0.479,scaleY:0.479,y:97.95},0).wait(1).to({scaleX:0.4787,scaleY:0.4787,x:162.05,y:97.6},0).wait(1).to({scaleX:0.4783,scaleY:0.4783,x:162.1,y:97.2},0).wait(1).to({scaleX:0.4779,scaleY:0.4779,x:162.15,y:96.7},0).wait(1).to({scaleX:0.4773,scaleY:0.4773,y:96.05},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:162.2,y:95.3},0).wait(1).to({scaleX:0.4758,scaleY:0.4758,x:162.3,y:94.45},0).wait(1).to({scaleX:0.4748,scaleY:0.4748,x:162.4,y:93.3},0).wait(1).to({scaleX:0.4736,scaleY:0.4736,x:162.5,y:92},0).wait(1).to({scaleX:0.4722,scaleY:0.4722,x:162.65,y:90.35},0).wait(1).to({scaleX:0.4703,scaleY:0.4703,x:162.8,y:88.3},0).wait(1).to({scaleX:0.4679,scaleY:0.4679,x:163,y:85.65},0).wait(1).to({scaleX:0.4647,scaleY:0.4647,x:163.25,y:82.15},0).wait(1).to({scaleX:0.4603,scaleY:0.4603,x:163.65,y:77.3},0).wait(1).to({scaleX:0.4545,scaleY:0.4545,x:164.2,y:70.85},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:164.75,y:63.95},0).wait(1).to({scaleX:0.4432,scaleY:0.4432,x:165.15,y:58.45},0).wait(1).to({scaleX:0.4396,scaleY:0.4396,x:165.5,y:54.4},0).wait(1).to({scaleX:0.4368,scaleY:0.4368,x:165.75,y:51.35},0).wait(1).to({scaleX:0.4347,scaleY:0.4347,x:165.95,y:49},0).wait(1).to({scaleX:0.433,scaleY:0.433,x:166.05,y:47.15},0).wait(1).to({scaleX:0.4316,scaleY:0.4316,x:166.2,y:45.65},0).wait(1).to({scaleX:0.4305,scaleY:0.4305,x:166.3,y:44.35},0).wait(1).to({scaleX:0.4295,scaleY:0.4295,x:166.35,y:43.3},0).wait(1).to({scaleX:0.4287,scaleY:0.4287,x:166.45,y:42.45},0).wait(1).to({scaleX:0.428,scaleY:0.428,x:166.5,y:41.65},0).wait(1).to({scaleX:0.4275,scaleY:0.4275,x:166.55,y:41.05},0).wait(1).to({scaleX:0.427,scaleY:0.427,x:166.6,y:40.5},0).wait(1).to({scaleX:0.4266,scaleY:0.4266,x:166.65,y:40.1},0).wait(1).to({scaleX:0.4263,scaleY:0.4263,x:166.7,y:39.7},0).wait(1).to({scaleX:0.426,scaleY:0.426,x:166.65,y:39.35},0).wait(1).to({scaleX:0.4258,scaleY:0.4258,x:166.7,y:39.15},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,y:38.95},0).wait(1).to({scaleX:0.4255,scaleY:0.4255,x:166.75,y:38.8},0).wait(1).to({scaleX:0.4254,scaleY:0.4254,y:38.7},0).wait(1).to({scaleX:0.4253,scaleY:0.4253,y:38.65},0).wait(1).to({regY:21.4,y:38.75},0).to({_off:true},1).wait(2));

	// guy right contribution
	this.instance_7 = new lib.guyrightcontribution();
	this.instance_7.setTransform(240.6,-78.2,1,1,0,0,0,38.1,26.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29).to({_off:false},0).to({regY:26.1,scaleX:1.6102,scaleY:1.6102,x:328.35,y:-52.95,alpha:1},37,cjs.Ease.quadOut).wait(1).to({regX:37.5,regY:26,x:327.4,y:-53.15},0).wait(22).to({regX:38.1,regY:26.1,x:328.35,y:-52.95},0).wait(1).to({regX:37.5,regY:26,scaleX:1.6015,scaleY:1.6011,x:326.25,y:-52.05},0).wait(1).to({scaleX:1.5897,scaleY:1.5885,skewY:-0.0565,x:324.7,y:-50.7},0).wait(1).to({scaleX:1.5743,scaleY:1.5723,skewY:-0.0988,x:322.75,y:-48.9},0).wait(1).to({scaleX:1.5552,scaleY:1.5522,skewY:-0.1513,x:320.25,y:-46.7},0).wait(1).to({scaleX:1.5321,scaleY:1.5278,skewY:-0.2149,x:317.3,y:-44},0).wait(1).to({scaleX:1.5049,scaleY:1.4991,skewY:-0.29,x:313.85,y:-40.8},0).wait(1).to({scaleX:1.4732,scaleY:1.4656,skewY:-0.3772,x:309.75,y:-37.1},0).wait(1).to({scaleX:1.4369,scaleY:1.4274,skewY:-0.477,x:305.1,y:-32.85},0).wait(1).to({scaleX:1.3961,scaleY:1.3843,skewY:-0.5895,x:299.8,y:-28.1},0).wait(1).to({scaleX:1.3506,scaleY:1.3364,skewY:-0.7145,x:293.95,y:-22.8},0).wait(1).to({scaleX:1.3009,scaleY:1.284,skewY:-0.8513,x:287.6,y:-16.95},0).wait(1).to({scaleX:1.2475,scaleY:1.2276,skewY:-0.9984,x:280.7,y:-10.75},0).wait(1).to({scaleX:1.191,scaleY:1.1681,skewY:-1.1539,x:273.45,y:-4.15},0).wait(1).to({scaleX:1.1326,scaleY:1.1064,skewY:-1.3149,x:265.9,y:2.7},0).wait(1).to({scaleX:1.0734,scaleY:1.044,skewY:-1.4778,x:258.3,y:9.6},0).wait(1).to({scaleX:1.0148,scaleY:0.9822,skewY:-1.639,x:250.8,y:16.45},0).wait(1).to({scaleX:0.9582,scaleY:0.9226,skewY:-1.7947,x:243.45,y:23.05},0).wait(1).to({scaleX:0.9049,scaleY:0.8663,skewY:-1.9416,x:236.6,y:29.25},0).wait(1).to({scaleX:0.8557,scaleY:0.8144,skewY:-2.0771,x:230.3,y:35},0).wait(1).to({scaleX:0.8113,scaleY:0.7676,skewY:-2.1992,x:224.6,y:40.2},0).wait(1).to({scaleX:0.7722,scaleY:0.7263,skewY:-2.3069,x:219.55,y:44.8},0).wait(1).to({scaleX:0.7384,scaleY:0.6907,skewY:-2.4,x:215.2,y:48.7},0).wait(1).to({scaleX:0.7099,scaleY:0.6607,skewY:-2.4783,x:211.55,y:52.05},0).wait(1).to({scaleX:0.6866,scaleY:0.6361,skewY:-2.5425,x:208.5,y:54.75},0).wait(1).to({scaleX:0.6682,scaleY:0.6167,skewY:-2.5931,x:206.2,y:56.9},0).wait(1).to({scaleX:0.6544,scaleY:0.6021,skewY:-2.6311,x:204.4,y:58.5},0).wait(1).to({scaleX:0.6449,scaleY:0.5922,skewY:-2.6571,x:203.2,y:59.65},0).wait(1).to({scaleX:0.6395,scaleY:0.5864,skewY:-2.6722,x:202.5,y:60.3},0).wait(1).to({regX:38.3,regY:26.3,scaleX:0.6377,scaleY:0.5845,skewY:-2.677,x:202.7,y:60.5},0).to({_off:true},55).wait(2));

	// guy left contribution
	this.instance_8 = new lib.guyleftcontribution_1();
	this.instance_8.setTransform(-59.8,65.85,1,1,0,0,0,30.4,9.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(33).to({_off:false},0).to({regY:9.7,scaleX:1.6102,scaleY:1.6102,x:137.8,y:-18.7,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:30.5,x:137.95},0).wait(22).to({regX:30.4,x:137.8},0).wait(1).to({regX:30.5,scaleX:1.6006,scaleY:1.6006,skewX:-0.0654,skewY:-0.0111,x:138.2,y:-17.7},0).wait(1).to({scaleX:1.5875,scaleY:1.5876,skewX:-0.1546,skewY:-0.0262,x:138.65,y:-16.5},0).wait(1).to({scaleX:1.5706,scaleY:1.5708,skewX:-0.2691,skewY:-0.0456,x:139.15,y:-14.95},0).wait(1).to({scaleX:1.5498,scaleY:1.5501,skewX:-0.4109,skewY:-0.0696,x:139.85,y:-12.95},0).wait(1).to({scaleX:1.5247,scaleY:1.5252,skewX:-0.5816,skewY:-0.0986,x:140.65,y:-10.65},0).wait(1).to({scaleX:1.4951,scaleY:1.4956,skewX:-0.7832,skewY:-0.1327,x:141.6,y:-7.85},0).wait(1).to({scaleX:1.4607,scaleY:1.4614,skewX:-1.0173,skewY:-0.1724,x:142.7,y:-4.7},0).wait(1).to({scaleX:1.4213,scaleY:1.4223,skewX:-1.2853,skewY:-0.2178,x:143.95,y:-0.95},0).wait(1).to({scaleX:1.3768,scaleY:1.378,skewX:-1.5882,skewY:-0.2692,x:145.35,y:3.2},0).wait(1).to({scaleX:1.3272,scaleY:1.3286,skewX:-1.9259,skewY:-0.3264,x:147,y:7.9},0).wait(1).to({scaleX:1.2726,scaleY:1.2742,skewX:-2.2975,skewY:-0.3894,x:148.65,y:12.95},0).wait(1).to({scaleX:1.2134,scaleY:1.2153,skewX:-2.7005,skewY:-0.4577,x:150.55,y:18.5},0).wait(1).to({scaleX:1.1502,scaleY:1.1524,skewX:-3.1305,skewY:-0.5306,x:152.6,y:24.45},0).wait(1).to({scaleX:1.084,scaleY:1.0865,skewX:-3.581,skewY:-0.6069,x:154.65,y:30.6},0).wait(1).to({scaleX:1.016,scaleY:1.0189,skewX:-4.0434,skewY:-0.6853,x:156.85,y:37},0).wait(1).to({scaleX:0.9477,scaleY:0.951,skewX:-4.5081,skewY:-0.764,x:159,y:43.4},0).wait(1).to({scaleX:0.8807,scaleY:0.8843,skewX:-4.9643,skewY:-0.8413,x:161.15,y:49.7},0).wait(1).to({scaleX:0.8164,scaleY:0.8203,skewX:-5.402,skewY:-0.9155,x:163.2,y:55.7},0).wait(1).to({scaleX:0.756,scaleY:0.7603,skewX:-5.8126,skewY:-0.9851,x:165.1,y:61.4},0).wait(1).to({scaleX:0.7007,scaleY:0.7052,skewX:-6.1892,skewY:-1.0489,x:166.85,y:66.55},0).wait(1).to({scaleX:0.651,scaleY:0.6557,skewX:-6.5274,skewY:-1.1063,x:168.45,y:71.2},0).wait(1).to({scaleX:0.6073,scaleY:0.6122,skewX:-6.825,skewY:-1.1567,x:169.85,y:75.35},0).wait(1).to({scaleX:0.5696,scaleY:0.5747,skewX:-7.0811,skewY:-1.2001,x:171.05,y:78.9},0).wait(1).to({scaleX:0.538,scaleY:0.5433,skewX:-7.2965,skewY:-1.2366,x:172.05,y:81.85},0).wait(1).to({scaleX:0.5121,scaleY:0.5175,skewX:-7.4726,skewY:-1.2665,x:172.85,y:84.25},0).wait(1).to({scaleX:0.4917,scaleY:0.4972,skewX:-7.6115,skewY:-1.29,x:173.55,y:86.15},0).wait(1).to({scaleX:0.4764,scaleY:0.482,skewX:-7.7154,skewY:-1.3076,x:174.05,y:87.6},0).wait(1).to({scaleX:0.4659,scaleY:0.4716,skewX:-7.7868,skewY:-1.3197,x:174.3,y:88.55},0).wait(1).to({scaleX:0.4599,scaleY:0.4655,skewX:-7.828,skewY:-1.3267,x:174.5,y:89.15},0).wait(1).to({regX:30.7,regY:9.8,scaleX:0.4579,scaleY:0.4636,skewX:-7.8413,skewY:-1.3289,x:174.6,y:89.3},0).to({_off:true},54).wait(2));

	// girl left contribution
	this.instance_9 = new lib.girlleftcontribution();
	this.instance_9.setTransform(-71.15,171.05,1,1,0,0,0,44,32.3);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(22).to({_off:false},0).to({regX:44.1,regY:32.4,scaleX:1.6102,scaleY:1.6102,x:113.8,y:141.15,alpha:1},42,cjs.Ease.quadOut).wait(1).to({regX:44.6,regY:32.3,x:114.6,y:141},0).wait(24).to({regX:44.1,regY:32.4,x:113.8,y:141.15},0).wait(1).to({regX:44.6,regY:32.3,scaleX:1.6001,scaleY:1.6001,x:115.15,y:140.7},0).wait(1).to({scaleX:1.5864,scaleY:1.5864,x:115.95,y:140.3},0).wait(1).to({scaleX:1.5688,scaleY:1.5688,x:116.9,y:139.75},0).wait(1).to({scaleX:1.5472,scaleY:1.5472,x:118.15,y:139.15},0).wait(1).to({scaleX:1.5212,scaleY:1.5212,x:119.6,y:138.45},0).wait(1).to({scaleX:1.4907,scaleY:1.4907,x:121.35,y:137.55},0).wait(1).to({scaleX:1.4553,scaleY:1.4553,x:123.35,y:136.5},0).wait(1).to({scaleX:1.415,scaleY:1.415,x:125.6,y:135.35},0).wait(1).to({scaleX:1.3696,scaleY:1.3696,x:128.2,y:134.05},0).wait(1).to({scaleX:1.3191,scaleY:1.3191,x:131.05,y:132.55},0).wait(1).to({scaleX:1.2636,scaleY:1.2636,x:134.15,y:130.95},0).wait(1).to({scaleX:1.2036,scaleY:1.2036,x:137.55,y:129.25},0).wait(1).to({scaleX:1.1396,scaleY:1.1396,x:141.15,y:127.4},0).wait(1).to({scaleX:1.0724,scaleY:1.0724,x:145,y:125.45},0).wait(1).to({scaleX:1.0031,scaleY:1.0031,x:148.9,y:123.45},0).wait(1).to({scaleX:0.9332,scaleY:0.9332,x:152.8,y:121.45},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:156.75,y:119.45},0).wait(1).to({scaleX:0.7967,scaleY:0.7967,x:160.55,y:117.5},0).wait(1).to({scaleX:0.7328,scaleY:0.7328,x:164.15,y:115.65},0).wait(1).to({scaleX:0.6734,scaleY:0.6734,x:167.5,y:113.95},0).wait(1).to({scaleX:0.6191,scaleY:0.6191,x:170.55,y:112.35},0).wait(1).to({scaleX:0.5704,scaleY:0.5704,x:173.35,y:111},0).wait(1).to({scaleX:0.5277,scaleY:0.5277,x:175.75,y:109.75},0).wait(1).to({scaleX:0.4908,scaleY:0.4908,x:177.8,y:108.65},0).wait(1).to({scaleX:0.4598,scaleY:0.4598,x:179.55,y:107.75},0).wait(1).to({scaleX:0.4343,scaleY:0.4343,x:181,y:107.05},0).wait(1).to({scaleX:0.4142,scaleY:0.4142,x:182.1,y:106.45},0).wait(1).to({scaleX:0.3991,scaleY:0.3991,x:183,y:106},0).wait(1).to({scaleX:0.3887,scaleY:0.3887,x:183.6,y:105.7},0).wait(1).to({scaleX:0.3827,scaleY:0.3827,x:183.9,y:105.55},0).wait(1).to({regX:44.3,regY:32.5,scaleX:0.3808,scaleY:0.3808,x:183.85,y:105.5},0).to({_off:true},53).wait(2));

	// girl rigth contribution
	this.instance_10 = new lib.girlrigthcontribution();
	this.instance_10.setTransform(253.5,242.7,1,1,0,0,0,39.1,19.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(25).to({_off:false},0).to({regY:19.2,scaleX:1.6102,scaleY:1.6102,x:316.3,y:217.9,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:316.15,y:217.6},0).wait(23).to({regX:39.1,regY:19.2,x:316.3,y:217.9},0).wait(1).to({regX:39,regY:19,scaleX:1.6011,scaleY:1.6011,x:315.2,y:216.8},0).wait(1).to({scaleX:1.5889,scaleY:1.5889,x:313.9,y:215.9},0).wait(1).to({scaleX:1.5735,scaleY:1.5735,x:312.3,y:214.65},0).wait(1).to({scaleX:1.5545,scaleY:1.5545,x:310.4,y:213.15},0).wait(1).to({scaleX:1.5318,scaleY:1.5318,x:308,y:211.3},0).wait(1).to({scaleX:1.5051,scaleY:1.5051,x:305.25,y:209.15},0).wait(1).to({scaleX:1.4742,scaleY:1.4742,x:302.05,y:206.7},0).wait(1).to({scaleX:1.4389,scaleY:1.4389,x:298.35,y:203.9},0).wait(1).to({scaleX:1.3989,scaleY:1.3989,x:294.25,y:200.7},0).wait(1).to({scaleX:1.3542,scaleY:1.3542,x:289.6,y:197.1},0).wait(1).to({scaleX:1.3048,scaleY:1.3048,x:284.5,y:193.15},0).wait(1).to({scaleX:1.2508,scaleY:1.2508,x:278.9,y:188.8},0).wait(1).to({scaleX:1.1925,scaleY:1.1925,x:272.85,y:184.15},0).wait(1).to({scaleX:1.1305,scaleY:1.1305,x:266.45,y:179.2},0).wait(1).to({scaleX:1.0656,scaleY:1.0656,x:259.7,y:174},0).wait(1).to({scaleX:0.9988,scaleY:0.9988,x:252.8,y:168.7},0).wait(1).to({scaleX:0.9315,scaleY:0.9315,x:245.85,y:163.3},0).wait(1).to({scaleX:0.865,scaleY:0.865,x:238.95,y:158},0).wait(1).to({scaleX:0.8008,scaleY:0.8008,x:232.3,y:152.8},0).wait(1).to({scaleX:0.7399,scaleY:0.7399,x:226,y:147.95},0).wait(1).to({scaleX:0.6835,scaleY:0.6835,x:220.15,y:143.45},0).wait(1).to({scaleX:0.6322,scaleY:0.6322,x:214.85,y:139.35},0).wait(1).to({scaleX:0.5864,scaleY:0.5864,x:210.05,y:135.7},0).wait(1).to({scaleX:0.5463,scaleY:0.5463,x:205.95,y:132.5},0).wait(1).to({scaleX:0.5119,scaleY:0.5119,x:202.35,y:129.75},0).wait(1).to({scaleX:0.483,scaleY:0.483,x:199.4,y:127.4},0).wait(1).to({scaleX:0.4594,scaleY:0.4594,x:196.9,y:125.55},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:195,y:124},0).wait(1).to({scaleX:0.4268,scaleY:0.4268,x:193.55,y:122.9},0).wait(1).to({scaleX:0.4172,scaleY:0.4172,x:192.55,y:122.15},0).wait(1).to({scaleX:0.4117,scaleY:0.4117,x:192,y:121.65},0).wait(1).to({regX:39.1,regY:19.3,scaleX:0.4099,scaleY:0.4099,x:191.9},0).to({_off:true},52).wait(2));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_22 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_66 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_67 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_68 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_69 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_70 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_71 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_72 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_73 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_74 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_75 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_76 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_77 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_78 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_79 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_80 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_81 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_82 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_83 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_84 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_85 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_86 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_87 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_88 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_89 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_90 = new cjs.Graphics().p("A/okqQAtgRYjnlQMSjzMUjyINbY9MgxpAPPg");
	var mask_graphics_91 = new cjs.Graphics().p("A/hkpQAugSYZnhQMQjzMTjyINZY4MgxdAPLg");
	var mask_graphics_92 = new cjs.Graphics().p("A/WkoQAvgSYLndIYfnjINUYvMgxMAPGg");
	var mask_graphics_93 = new cjs.Graphics().p("A/IkmQAxgSX4nXIYaniINOYkMgw2AO/g");
	var mask_graphics_94 = new cjs.Graphics().p("A+2kkQAzgTXgnPIYUnfINGYVMgwaAO3g");
	var mask_graphics_95 = new cjs.Graphics().p("A+hkhQA3gTXCnHIYMndIM+YEMgv4AOtg");
	var mask_graphics_96 = new cjs.Graphics().p("A+HkeQA6gUWgm7IYCnaIMzXvMgvPAOgg");
	var mask_graphics_97 = new cjs.Graphics().p("A9pkaQA+gVV3muIX4nXIMmXXMgugAOSg");
	var mask_graphics_98 = new cjs.Graphics().p("A9GkVQBCgYVImeQLdjgMPjzIMXW7MgtqAOCg");
	var mask_graphics_99 = new cjs.Graphics().p("A8gkRQBHgYUVmOQLQjcMOjzIMHWdMgsuANwg");
	var mask_graphics_100 = new cjs.Graphics().p("A73kLQBNgaTdl8QLCjYMMjyIL2V7MgrsANcg");
	var mask_graphics_101 = new cjs.Graphics().p("A7KkGQBSgbShlpQK0jSMKjzILkVXMgqmANIg");
	var mask_graphics_102 = new cjs.Graphics().p("A6bkAQBYgdRilUQKkjNMKjzILPUxMgpcAMyg");
	var mask_graphics_103 = new cjs.Graphics().p("A5sj6QBfgeQhlBQKVjHMIjyIK8UKMgoSAMbg");
	var mask_graphics_104 = new cjs.Graphics().p("A48jzQBkghPiksQKFjBMHjzIKnTlMgnHAMEg");
	var mask_graphics_105 = new cjs.Graphics().p("A4OjuQBqgiOkkYQJ2i8MFjzIKUTAMgl+ALvg");
	var mask_graphics_106 = new cjs.Graphics().p("A3jjpQBwgjNpkFQJoi3MEjzIKCScMgk6ALbg");
	var mask_graphics_107 = new cjs.Graphics().p("A26jjQB1glMyjzQJbizMCjzIJxR8Mgj6ALHg");
	var mask_graphics_108 = new cjs.Graphics().p("A2VjfQB6glMAjkQJPiuMBjzIJhReMgi/AK1g");
	var mask_graphics_109 = new cjs.Graphics().p("A10jaQB+gnLUjWQJEiqL/jzIJURDMgiLAKmg");
	var mask_graphics_110 = new cjs.Graphics().p("A1WjWQCCgpKrjJQI7imL/jzIJHQrMghdAKYg");
	var mask_graphics_111 = new cjs.Graphics().p("A09jTQCFgpKKi+QIxikL/jzII8QXMgg0AKMg");
	var mask_graphics_112 = new cjs.Graphics().p("A0njQQCHgrJti0QIrihL9jzIIzQFMggSAKCg");
	var mask_graphics_113 = new cjs.Graphics().p("A0VjPQCKgpJUitQIlifL8jzIIsP2I/2J6g");
	var mask_graphics_114 = new cjs.Graphics().p("A0GjNQCMgrJAilQIgieL8jzIIlPrI/eJyg");
	var mask_graphics_115 = new cjs.Graphics().p("Az6jLQCNgrIxihQIcicL7j0IIgPiI/MJtg");
	var mask_graphics_116 = new cjs.Graphics().p("AzxjKQCOgrIlidQIZibL7j0IIcPaI++Jpg");
	var mask_graphics_117 = new cjs.Graphics().p("AzsjJQCQgsIciaQIYiaL7j0IIZPVI+0Jmg");
	var mask_graphics_118 = new cjs.Graphics().p("AzojJQCQgrIXiaQIXiZL6j0IIZPTI+vJkg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_22,x:234.025,y:87.875}).wait(44).to({graphics:mask_graphics_66,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_67,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_68,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_69,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_70,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_71,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_72,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_73,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_74,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_75,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_76,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_77,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_78,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_79,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_80,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_81,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_82,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_83,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_84,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_85,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_86,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_87,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_88,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_89,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_90,x:233.575,y:87.95}).wait(1).to({graphics:mask_graphics_91,x:232.8,y:88.075}).wait(1).to({graphics:mask_graphics_92,x:231.675,y:88.25}).wait(1).to({graphics:mask_graphics_93,x:230.225,y:88.475}).wait(1).to({graphics:mask_graphics_94,x:228.375,y:88.8}).wait(1).to({graphics:mask_graphics_95,x:226.125,y:89.15}).wait(1).to({graphics:mask_graphics_96,x:223.425,y:89.575}).wait(1).to({graphics:mask_graphics_97,x:220.325,y:90.075}).wait(1).to({graphics:mask_graphics_98,x:216.775,y:90.65}).wait(1).to({graphics:mask_graphics_99,x:212.825,y:91.3}).wait(1).to({graphics:mask_graphics_100,x:208.5,y:92}).wait(1).to({graphics:mask_graphics_101,x:203.875,y:92.75}).wait(1).to({graphics:mask_graphics_102,x:199,y:93.525}).wait(1).to({graphics:mask_graphics_103,x:194.1,y:94.325}).wait(1).to({graphics:mask_graphics_104,x:189.175,y:95.1}).wait(1).to({graphics:mask_graphics_105,x:184.425,y:95.875}).wait(1).to({graphics:mask_graphics_106,x:179.875,y:96.625}).wait(1).to({graphics:mask_graphics_107,x:175.675,y:97.275}).wait(1).to({graphics:mask_graphics_108,x:171.825,y:97.9}).wait(1).to({graphics:mask_graphics_109,x:168.375,y:98.45}).wait(1).to({graphics:mask_graphics_110,x:165.35,y:98.95}).wait(1).to({graphics:mask_graphics_111,x:162.7,y:99.375}).wait(1).to({graphics:mask_graphics_112,x:160.45,y:99.75}).wait(1).to({graphics:mask_graphics_113,x:158.55,y:100.05}).wait(1).to({graphics:mask_graphics_114,x:157.025,y:100.3}).wait(1).to({graphics:mask_graphics_115,x:155.8,y:100.5}).wait(1).to({graphics:mask_graphics_116,x:154.9,y:100.625}).wait(1).to({graphics:mask_graphics_117,x:154.25,y:100.725}).wait(1).to({graphics:mask_graphics_118,x:153.875,y:100.8}).wait(57));

	// r guy i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(188.7,-72.65,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(29).to({_off:false},0).to({regX:28.3,regY:22.7,scaleX:1.6102,scaleY:1.6102,x:251.7,y:-35.7,alpha:0.1602},36,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.8,x:251.25,y:-35.55},0).wait(23).to({regX:28.3,regY:22.7,x:251.7,y:-35.7},0).wait(1).to({regX:28,regY:22.8,scaleX:1.6015,scaleY:1.6015,x:250.6,y:-34.7},0).wait(1).to({scaleX:1.5896,scaleY:1.5896,x:249.7,y:-33.5},0).wait(1).to({scaleX:1.5741,scaleY:1.5741,x:248.55,y:-32},0).wait(1).to({scaleX:1.5548,scaleY:1.5548,x:247.2,y:-30.15},0).wait(1).to({scaleX:1.5313,scaleY:1.5313,x:245.5,y:-27.85},0).wait(1).to({scaleX:1.5035,scaleY:1.5035,x:243.45,y:-25.15},0).wait(1).to({scaleX:1.471,scaleY:1.471,x:241.1,y:-21.95},0).wait(1).to({scaleX:1.4336,scaleY:1.4336,x:238.4,y:-18.35},0).wait(1).to({scaleX:1.3911,scaleY:1.3911,x:235.3,y:-14.25},0).wait(1).to({scaleX:1.3437,scaleY:1.3437,x:231.85,y:-9.6},0).wait(1).to({scaleX:1.2916,scaleY:1.2916,x:228.05,y:-4.55},0).wait(1).to({scaleX:1.2353,scaleY:1.2353,x:224,y:0.9},0).wait(1).to({scaleX:1.1756,scaleY:1.1756,x:219.65,y:6.7},0).wait(1).to({scaleX:1.1139,scaleY:1.1139,x:215.2,y:12.7},0).wait(1).to({scaleX:1.0516,scaleY:1.0516,x:210.65,y:18.8},0).wait(1).to({scaleX:0.9904,scaleY:0.9904,x:206.25,y:24.65},0).wait(1).to({scaleX:0.932,scaleY:0.932,x:202,y:30.35},0).wait(1).to({scaleX:0.8776,scaleY:0.8776,x:198,y:35.6},0).wait(1).to({scaleX:0.8284,scaleY:0.8284,x:194.5,y:40.4},0).wait(1).to({scaleX:0.7849,scaleY:0.7849,x:191.35,y:44.65},0).wait(1).to({scaleX:0.7474,scaleY:0.7474,x:188.6,y:48.3},0).wait(1).to({scaleX:0.7159,scaleY:0.7159,x:186.3,y:51.3},0).wait(1).to({scaleX:0.6902,scaleY:0.6902,x:184.45,y:53.85},0).wait(1).to({scaleX:0.67,scaleY:0.67,x:182.95,y:55.8},0).wait(1).to({scaleX:0.655,scaleY:0.655,x:181.9,y:57.25},0).wait(1).to({scaleX:0.6447,scaleY:0.6447,x:181.15,y:58.25},0).wait(1).to({scaleX:0.6388,scaleY:0.6388,x:180.7,y:58.8},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.6369,scaleY:0.6369,x:180.8,y:58.95},0).wait(1).to({regX:28,regY:22.8,x:180.55,y:58.85},0).wait(8).to({regX:28.4,regY:22.9,x:180.8,y:58.95},0).wait(1).to({regX:28,regY:22.8,scaleX:0.6367,scaleY:0.6367,x:180.55,y:58.8},0).wait(1).to({scaleX:0.6365,scaleY:0.6365,x:180.5},0).wait(1).to({scaleX:0.636,scaleY:0.636,x:180.55,y:58.75},0).wait(1).to({scaleX:0.6355,scaleY:0.6355,y:58.7},0).wait(1).to({scaleX:0.6348,scaleY:0.6348,y:58.6},0).wait(1).to({scaleX:0.6338,scaleY:0.6338,x:180.6,y:58.5},0).wait(1).to({scaleX:0.6327,scaleY:0.6327,x:180.65,y:58.4},0).wait(1).to({scaleX:0.6313,scaleY:0.6313,x:180.75,y:58.25},0).wait(1).to({scaleX:0.6297,scaleY:0.6297,x:180.8,y:58.05},0).wait(1).to({scaleX:0.6278,scaleY:0.6278,x:180.85,y:57.8},0).wait(1).to({scaleX:0.6255,scaleY:0.6255,x:180.9,y:57.55},0).wait(1).to({scaleX:0.6228,scaleY:0.6228,x:181.05,y:57.3},0).wait(1).to({scaleX:0.6196,scaleY:0.6196,x:181.15,y:56.95},0).wait(1).to({scaleX:0.6157,scaleY:0.6157,x:181.3,y:56.5},0).wait(1).to({scaleX:0.6112,scaleY:0.6112,x:181.45,y:56},0).wait(1).to({scaleX:0.6056,scaleY:0.6056,x:181.65,y:55.35},0).wait(1).to({scaleX:0.5988,scaleY:0.5988,x:181.9,y:54.6},0).wait(1).to({scaleX:0.5902,scaleY:0.5902,x:182.3,y:53.65},0).wait(1).to({scaleX:0.5792,scaleY:0.5792,x:182.65,y:52.45},0).wait(1).to({scaleX:0.5645,scaleY:0.5645,x:183.2,y:50.8},0).wait(1).to({scaleX:0.5451,scaleY:0.5451,x:183.95,y:48.7},0).wait(1).to({scaleX:0.5228,scaleY:0.5228,x:184.8,y:46.15},0).wait(1).to({scaleX:0.503,scaleY:0.503,x:185.55,y:43.95},0).wait(1).to({scaleX:0.4877,scaleY:0.4877,x:186.1,y:42.3},0).wait(1).to({scaleX:0.4762,scaleY:0.4762,x:186.55,y:41},0).wait(1).to({scaleX:0.4672,scaleY:0.4672,x:186.85,y:40},0).wait(1).to({scaleX:0.46,scaleY:0.46,x:187.15,y:39.25},0).wait(1).to({scaleX:0.454,scaleY:0.454,x:187.35,y:38.55},0).wait(1).to({scaleX:0.4491,scaleY:0.4491,x:187.5,y:38},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:187.7,y:37.55},0).wait(1).to({scaleX:0.4414,scaleY:0.4414,x:187.8,y:37.15},0).wait(1).to({scaleX:0.4384,scaleY:0.4384,x:187.9,y:36.85},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:188.05,y:36.55},0).wait(1).to({scaleX:0.4336,scaleY:0.4336,x:188.1,y:36.3},0).wait(1).to({scaleX:0.4316,scaleY:0.4316,x:188.2,y:36.1},0).wait(1).to({scaleX:0.43,scaleY:0.43,x:188.25,y:35.9},0).wait(1).to({scaleX:0.4286,scaleY:0.4286,x:188.3,y:35.7},0).wait(1).to({scaleX:0.4274,scaleY:0.4274,y:35.6},0).wait(1).to({scaleX:0.4264,scaleY:0.4264,x:188.4,y:35.5},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,y:35.4},0).wait(1).to({scaleX:0.425,scaleY:0.425,x:188.45,y:35.35},0).wait(1).to({scaleX:0.4244,scaleY:0.4244,y:35.3},0).wait(1).to({scaleX:0.4241,scaleY:0.4241,y:35.2},0).wait(1).to({scaleX:0.4238,scaleY:0.4238},0).wait(1).to({scaleX:0.4236,scaleY:0.4236},0).wait(1).to({regX:28.4,regY:22.9,x:188.7,y:35.25},0).to({_off:true},1).wait(2));

	// l guy i shadow
	this.instance_12 = new lib.roundshadow();
	this.instance_12.setTransform(-116,82.3,1,1,0,0,0,28.2,22.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({regX:28.3,regY:22.7,scaleX:1.6102,scaleY:1.6102,x:50.6,y:-3.05,alpha:0.1602},33,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.8,x:50.15,y:-2.9},0).wait(22).to({regX:28.3,regY:22.7,x:50.6,y:-3.05},0).wait(1).to({regX:28,regY:22.8,scaleX:1.6005,scaleY:1.6005,x:51.05,y:-2.15},0).wait(1).to({scaleX:1.5872,scaleY:1.5872,x:52.35,y:-1.2},0).wait(1).to({scaleX:1.5701,scaleY:1.5701,x:54,y:0.05},0).wait(1).to({scaleX:1.549,scaleY:1.549,x:56,y:1.6},0).wait(1).to({scaleX:1.5235,scaleY:1.5235,x:58.5,y:3.45},0).wait(1).to({scaleX:1.4935,scaleY:1.4935,x:61.4,y:5.65},0).wait(1).to({scaleX:1.4587,scaleY:1.4587,x:64.8,y:8.15},0).wait(1).to({scaleX:1.4189,scaleY:1.4189,x:68.65,y:11.05},0).wait(1).to({scaleX:1.3742,scaleY:1.3742,x:73,y:14.35},0).wait(1).to({scaleX:1.3245,scaleY:1.3245,x:77.8,y:17.95},0).wait(1).to({scaleX:1.2701,scaleY:1.2701,x:83.05,y:21.9},0).wait(1).to({scaleX:1.2113,scaleY:1.2113,x:88.75,y:26.2},0).wait(1).to({scaleX:1.149,scaleY:1.149,x:94.8,y:30.7},0).wait(1).to({scaleX:1.0841,scaleY:1.0841,x:101.1,y:35.4},0).wait(1).to({scaleX:1.0178,scaleY:1.0178,x:107.5,y:40.25},0).wait(1).to({scaleX:0.9516,scaleY:0.9516,x:113.95,y:45.1},0).wait(1).to({scaleX:0.8868,scaleY:0.8868,x:120.25,y:49.8},0).wait(1).to({scaleX:0.8247,scaleY:0.8247,x:126.25,y:54.35},0).wait(1).to({scaleX:0.7667,scaleY:0.7667,x:131.85,y:58.6},0).wait(1).to({scaleX:0.7134,scaleY:0.7134,x:137,y:62.45},0).wait(1).to({scaleX:0.6655,scaleY:0.6655,x:141.7,y:65.9},0).wait(1).to({scaleX:0.6234,scaleY:0.6234,x:145.75,y:69},0).wait(1).to({scaleX:0.587,scaleY:0.587,x:149.3,y:71.7},0).wait(1).to({scaleX:0.5563,scaleY:0.5563,x:152.25,y:73.9},0).wait(1).to({scaleX:0.5312,scaleY:0.5312,x:154.65,y:75.7},0).wait(1).to({scaleX:0.5114,scaleY:0.5114,x:156.6,y:77.15},0).wait(1).to({scaleX:0.4965,scaleY:0.4965,x:158.05,y:78.25},0).wait(1).to({scaleX:0.4862,scaleY:0.4862,x:159,y:79},0).wait(1).to({scaleX:0.4803,scaleY:0.4803,x:159.6,y:79.45},0).wait(1).to({regX:28.2,regY:22.9,scaleX:0.4784,scaleY:0.4784,x:159.95,y:79.55},0).wait(1).to({regX:28,regY:22.8,x:159.85,y:79.5},0).wait(6).to({regX:28.2,regY:22.9,x:159.95,y:79.55},0).wait(1).to({regX:28,regY:22.8,x:159.85,y:79.5},0).wait(1).to({regX:28.2,regY:22.9,x:159.95,y:79.55},0).wait(1).to({regX:28,regY:22.8,x:159.8,y:79.45},0).wait(1).to({scaleX:0.4783,scaleY:0.4783,x:159.7,y:79.4},0).wait(1).to({scaleX:0.4782,scaleY:0.4782,x:159.6,y:79.35},0).wait(1).to({scaleX:0.4781,scaleY:0.4781,x:159.5,y:79.25},0).wait(1).to({scaleX:0.478,scaleY:0.478,x:159.3,y:79.15},0).wait(1).to({scaleX:0.4778,scaleY:0.4778,x:159.05,y:79},0).wait(1).to({scaleX:0.4775,scaleY:0.4775,x:158.7,y:78.8},0).wait(1).to({scaleX:0.4772,scaleY:0.4772,x:158.35,y:78.6},0).wait(1).to({scaleX:0.4769,scaleY:0.4769,x:157.9,y:78.25},0).wait(1).to({scaleX:0.4764,scaleY:0.4764,x:157.35,y:77.9},0).wait(1).to({scaleX:0.4759,scaleY:0.4759,x:156.6,y:77.5},0).wait(1).to({scaleX:0.4752,scaleY:0.4752,x:155.8,y:77},0).wait(1).to({scaleX:0.4744,scaleY:0.4744,x:154.8,y:76.3},0).wait(1).to({scaleX:0.4733,scaleY:0.4733,x:153.45,y:75.5},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:151.75,y:74.45},0).wait(1).to({scaleX:0.4702,scaleY:0.4702,x:149.5,y:73},0).wait(1).to({scaleX:0.4677,scaleY:0.4677,x:146.35,y:71.05},0).wait(1).to({scaleX:0.4643,scaleY:0.4643,x:142,y:68.4},0).wait(1).to({scaleX:0.4605,scaleY:0.4605,x:137.3,y:65.45},0).wait(1).to({scaleX:0.4576,scaleY:0.4576,x:133.6,y:63.15},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:130.95,y:61.5},0).wait(1).to({scaleX:0.4539,scaleY:0.4539,x:128.95,y:60.25},0).wait(1).to({scaleX:0.4527,scaleY:0.4527,x:127.45,y:59.25},0).wait(1).to({scaleX:0.4517,scaleY:0.4517,x:126.25,y:58.55},0).wait(1).to({scaleX:0.451,scaleY:0.451,x:125.3,y:57.95},0).wait(1).to({scaleX:0.4503,scaleY:0.4503,x:124.45,y:57.4},0).wait(1).to({scaleX:0.4498,scaleY:0.4498,x:123.8,y:57},0).wait(1).to({scaleX:0.4493,scaleY:0.4493,x:123.25,y:56.65},0).wait(1).to({scaleX:0.449,scaleY:0.449,x:122.75,y:56.35},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:122.35,y:56.15},0).wait(1).to({scaleX:0.4484,scaleY:0.4484,x:122.05,y:55.9},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:121.75,y:55.7},0).wait(1).to({scaleX:0.448,scaleY:0.448,x:121.55,y:55.6},0).wait(1).to({scaleX:0.4479,scaleY:0.4479,x:121.4,y:55.5},0).wait(1).to({scaleX:0.4478,scaleY:0.4478,x:121.25,y:55.4},0).wait(1).to({scaleX:0.4477,scaleY:0.4477,x:121.15,y:55.35},0).wait(1).to({scaleX:0.4476,scaleY:0.4476,x:121.1,y:55.3},0).wait(1).to({x:121.05},0).wait(1).to({regX:28.4,regY:23,x:121.15,y:55.35},0).to({_off:true},6).wait(2));

	// r girl i shadow
	this.instance_13 = new lib.roundshadow();
	this.instance_13.setTransform(198.25,263.3,1,1,0,0,0,28.2,22.8);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(25).to({_off:false},0).to({regX:28.3,scaleX:1.6102,scaleY:1.6102,x:195.2,y:245.5,alpha:0.1602},39,cjs.Ease.quadOut).wait(1).to({regX:28,x:195.4,y:244.65},0).wait(1).to({x:196.05,y:243.85},0).wait(1).to({x:196.7,y:243.05},0).wait(1).to({x:197.35,y:242.25},0).wait(1).to({x:198.05,y:241.45},0).wait(1).to({x:198.7,y:240.6},0).wait(1).to({x:199.35,y:239.8},0).wait(1).to({x:200.05,y:239},0).wait(1).to({x:200.7,y:238.15},0).wait(1).to({x:201.4,y:237.35},0).wait(1).to({x:202.05,y:236.5},0).wait(1).to({x:202.75,y:235.7},0).wait(1).to({x:203.4,y:234.85},0).wait(1).to({x:204.1,y:234},0).wait(1).to({x:204.8,y:233.2},0).wait(1).to({x:205.45,y:232.35},0).wait(1).to({x:206.15,y:231.5},0).wait(1).to({x:206.85,y:230.65},0).wait(1).to({x:207.55,y:229.8},0).wait(1).to({x:208.25,y:229},0).wait(1).to({x:208.95,y:228.15},0).wait(1).to({x:209.6,y:227.25},0).wait(1).to({x:210.3,y:226.4},0).wait(1).to({x:211,y:225.55},0).wait(1).to({regX:28.3,x:212.2,y:224.65},0).wait(1).to({regX:28,scaleX:1.6014,scaleY:1.6014,x:211.35,y:223.8},0).wait(1).to({scaleX:1.5894,scaleY:1.5894,x:210.8,y:222.7},0).wait(1).to({scaleX:1.5739,scaleY:1.5739,x:210.1,y:221.25},0).wait(1).to({scaleX:1.5547,scaleY:1.5547,x:209.3,y:219.45},0).wait(1).to({scaleX:1.5316,scaleY:1.5316,x:208.3,y:217.3},0).wait(1).to({scaleX:1.5044,scaleY:1.5044,x:207.1,y:214.75},0).wait(1).to({scaleX:1.473,scaleY:1.473,x:205.75,y:211.85},0).wait(1).to({scaleX:1.4373,scaleY:1.4373,x:204.2,y:208.45},0).wait(1).to({scaleX:1.3973,scaleY:1.3973,x:202.5,y:204.75},0).wait(1).to({scaleX:1.3532,scaleY:1.3532,x:200.6,y:200.65},0).wait(1).to({scaleX:1.3052,scaleY:1.3052,x:198.5,y:196.15},0).wait(1).to({scaleX:1.2538,scaleY:1.2538,x:196.25,y:191.35},0).wait(1).to({scaleX:1.1997,scaleY:1.1997,x:193.9,y:186.3},0).wait(1).to({scaleX:1.1437,scaleY:1.1437,x:191.45,y:181.1},0).wait(1).to({scaleX:1.087,scaleY:1.087,x:189.05,y:175.8},0).wait(1).to({scaleX:1.0307,scaleY:1.0307,x:186.6,y:170.5},0).wait(1).to({scaleX:0.9759,scaleY:0.9759,x:184.25,y:165.4},0).wait(1).to({scaleX:0.9236,scaleY:0.9236,x:181.95,y:160.5},0).wait(1).to({scaleX:0.8748,scaleY:0.8748,x:179.85,y:155.95},0).wait(1).to({scaleX:0.83,scaleY:0.83,x:177.9,y:151.75},0).wait(1).to({scaleX:0.7897,scaleY:0.7897,x:176.15,y:148},0).wait(1).to({scaleX:0.7541,scaleY:0.7541,x:174.6,y:144.65},0).wait(1).to({scaleX:0.7234,scaleY:0.7234,x:173.25,y:141.8},0).wait(1).to({scaleX:0.6974,scaleY:0.6974,x:172.15,y:139.35},0).wait(1).to({scaleX:0.676,scaleY:0.676,x:171.25,y:137.35},0).wait(1).to({scaleX:0.6591,scaleY:0.6591,x:170.5,y:135.8},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:169.95,y:134.6},0).wait(1).to({scaleX:0.6375,scaleY:0.6375,x:169.55,y:133.8},0).wait(1).to({scaleX:0.6324,scaleY:0.6324,x:169.3,y:133.25},0).wait(1).to({regX:28.2,regY:22.9,scaleX:0.6307,scaleY:0.6307,x:169.45,y:133.2},0).wait(1).to({regX:28,regY:22.8,x:169.3,y:133.15},0).wait(6).to({regX:28.2,regY:22.9,x:169.45,y:133.2},0).wait(1).to({regX:28,regY:22.8,x:169.3,y:133.15},0).wait(2).to({regX:28.2,regY:22.9,x:169.45,y:133.2},0).wait(1).to({regX:28,regY:22.8,scaleX:0.6306,scaleY:0.6306,x:169.25,y:133.05},0).wait(1).to({scaleX:0.6303,scaleY:0.6303,y:132.9},0).wait(1).to({scaleX:0.6299,scaleY:0.6299,x:169.2,y:132.7},0).wait(1).to({scaleX:0.6293,scaleY:0.6293,x:169.1,y:132.5},0).wait(1).to({scaleX:0.6285,scaleY:0.6285,x:169,y:132.15},0).wait(1).to({scaleX:0.6275,scaleY:0.6275,x:168.85,y:131.7},0).wait(1).to({scaleX:0.6262,scaleY:0.6262,x:168.75,y:131.2},0).wait(1).to({scaleX:0.6247,scaleY:0.6247,x:168.55,y:130.55},0).wait(1).to({scaleX:0.6229,scaleY:0.6229,x:168.3,y:129.8},0).wait(1).to({scaleX:0.6207,scaleY:0.6207,x:168.05,y:128.85},0).wait(1).to({scaleX:0.6181,scaleY:0.6181,x:167.7,y:127.75},0).wait(1).to({scaleX:0.6149,scaleY:0.6149,x:167.3,y:126.4},0).wait(1).to({scaleX:0.6112,scaleY:0.6112,x:166.8,y:124.85},0).wait(1).to({scaleX:0.6066,scaleY:0.6066,x:166.25,y:122.95},0).wait(1).to({scaleX:0.601,scaleY:0.601,x:165.55,y:120.55},0).wait(1).to({scaleX:0.594,scaleY:0.594,x:164.7,y:117.6},0).wait(1).to({scaleX:0.585,scaleY:0.585,x:163.55,y:113.8},0).wait(1).to({scaleX:0.5731,scaleY:0.5731,x:162.05,y:108.75},0).wait(1).to({scaleX:0.557,scaleY:0.557,x:160.05,y:101.95},0).wait(1).to({scaleX:0.5359,scaleY:0.5359,x:157.4,y:93.05},0).wait(1).to({scaleX:0.5139,scaleY:0.5139,x:154.65,y:83.75},0).wait(1).to({scaleX:0.4962,scaleY:0.4962,x:152.4,y:76.3},0).wait(1).to({scaleX:0.4831,scaleY:0.4831,x:150.8,y:70.75},0).wait(1).to({scaleX:0.4732,scaleY:0.4732,x:149.5,y:66.6},0).wait(1).to({scaleX:0.4655,scaleY:0.4655,x:148.55,y:63.3},0).wait(1).to({scaleX:0.4592,scaleY:0.4592,x:147.75,y:60.65},0).wait(1).to({scaleX:0.4541,scaleY:0.4541,x:147.1,y:58.5},0).wait(1).to({scaleX:0.4499,scaleY:0.4499,x:146.6,y:56.7},0).wait(1).to({scaleX:0.4463,scaleY:0.4463,x:146.15,y:55.25},0).wait(1).to({scaleX:0.4433,scaleY:0.4433,x:145.75,y:53.95},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:145.45,y:52.85},0).wait(1).to({scaleX:0.4385,scaleY:0.4385,x:145.2,y:51.95},0).wait(1).to({scaleX:0.4367,scaleY:0.4367,x:144.95,y:51.15},0).wait(1).to({scaleX:0.4351,scaleY:0.4351,x:144.75,y:50.45},0).wait(1).to({scaleX:0.4338,scaleY:0.4338,x:144.55,y:49.95},0).wait(1).to({scaleX:0.4327,scaleY:0.4327,x:144.4,y:49.45},0).wait(1).to({scaleX:0.4318,scaleY:0.4318,x:144.35,y:49.1},0).wait(1).to({scaleX:0.4311,scaleY:0.4311,x:144.2,y:48.8},0).wait(1).to({scaleX:0.4305,scaleY:0.4305,x:144.15,y:48.5},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:144.1,y:48.35},0).wait(1).to({scaleX:0.4298,scaleY:0.4298,y:48.25},0).wait(1).to({scaleX:0.4296,scaleY:0.4296,x:144.05,y:48.15},0).wait(1).to({regX:28.4,x:144.15,y:48.2},0).to({_off:true},1).wait(2));

	// l girl i shadow
	this.instance_14 = new lib.roundshadow();
	this.instance_14.setTransform(-129.35,179.15,1,1,0,0,0,28.2,22.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(22).to({_off:false},0).to({regX:28.3,scaleX:1.6102,scaleY:1.6102,x:27.8,y:149.35,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:28,x:27.35},0).wait(25).to({regX:28.3,x:27.8},0).wait(1).to({regX:28,scaleX:1.6006,scaleY:1.6006,x:28.5,y:148.95},0).wait(1).to({scaleX:1.5875,scaleY:1.5875,x:30.05,y:148.4},0).wait(1).to({scaleX:1.5708,scaleY:1.5708,x:32.05,y:147.65},0).wait(1).to({scaleX:1.5503,scaleY:1.5503,x:34.45,y:146.85},0).wait(1).to({scaleX:1.5257,scaleY:1.5257,x:37.35,y:145.8},0).wait(1).to({scaleX:1.497,scaleY:1.497,x:40.75,y:144.6},0).wait(1).to({scaleX:1.464,scaleY:1.464,x:44.6,y:143.2},0).wait(1).to({scaleX:1.4266,scaleY:1.4266,x:49.05,y:141.65},0).wait(1).to({scaleX:1.3849,scaleY:1.3849,x:54,y:139.85},0).wait(1).to({scaleX:1.3389,scaleY:1.3389,x:59.45,y:137.95},0).wait(1).to({scaleX:1.2889,scaleY:1.2889,x:65.35,y:135.85},0).wait(1).to({scaleX:1.2352,scaleY:1.2352,x:71.7,y:133.6},0).wait(1).to({scaleX:1.1786,scaleY:1.1786,x:78.4,y:131.2},0).wait(1).to({scaleX:1.1196,scaleY:1.1196,x:85.35,y:128.75},0).wait(1).to({scaleX:1.0591,scaleY:1.0591,x:92.5,y:126.2},0).wait(1).to({scaleX:0.9982,scaleY:0.9982,x:99.75,y:123.65},0).wait(1).to({scaleX:0.9379,scaleY:0.9379,x:106.85,y:121.15},0).wait(1).to({scaleX:0.8791,scaleY:0.8791,x:113.8,y:118.65},0).wait(1).to({scaleX:0.8229,scaleY:0.8229,x:120.5,y:116.3},0).wait(1).to({scaleX:0.7701,scaleY:0.7701,x:126.7,y:114.05},0).wait(1).to({scaleX:0.7211,scaleY:0.7211,x:132.55,y:112.05},0).wait(1).to({scaleX:0.6765,scaleY:0.6765,x:137.8,y:110.1},0).wait(1).to({scaleX:0.6365,scaleY:0.6365,x:142.5,y:108.45},0).wait(1).to({scaleX:0.6013,scaleY:0.6013,x:146.7,y:107},0).wait(1).to({scaleX:0.5708,scaleY:0.5708,x:150.3,y:105.7},0).wait(1).to({scaleX:0.545,scaleY:0.545,x:153.35,y:104.65},0).wait(1).to({scaleX:0.5238,scaleY:0.5238,x:155.85,y:103.75},0).wait(1).to({scaleX:0.5069,scaleY:0.5069,x:157.9,y:103},0).wait(1).to({scaleX:0.4941,scaleY:0.4941,x:159.4,y:102.45},0).wait(1).to({scaleX:0.4852,scaleY:0.4852,x:160.45,y:102.1},0).wait(1).to({scaleX:0.4801,scaleY:0.4801,x:161.05,y:101.9},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.4784,scaleY:0.4784,x:161.4,y:101.85},0).wait(1).to({regX:28,regY:22.8,x:161.25,y:101.8},0).wait(4).to({regX:28.3,regY:22.9,x:161.4,y:101.85},0).wait(1).to({regX:28,regY:22.8,x:161.25,y:101.8},0).wait(4).to({regX:28.3,regY:22.9,x:161.4,y:101.85},0).wait(1).to({regX:28,regY:22.8,scaleX:0.4783,scaleY:0.4783,x:161.25,y:101.75},0).wait(1).to({y:101.65},0).wait(1).to({scaleX:0.4781,scaleY:0.4781,y:101.5},0).wait(1).to({scaleX:0.478,scaleY:0.478,x:161.3,y:101.3},0).wait(1).to({scaleX:0.4777,scaleY:0.4777,y:101.05},0).wait(1).to({scaleX:0.4774,scaleY:0.4774,y:100.7},0).wait(1).to({scaleX:0.477,scaleY:0.477,x:161.35,y:100.3},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:161.4,y:99.75},0).wait(1).to({scaleX:0.476,scaleY:0.476,x:161.45,y:99.15},0).wait(1).to({scaleX:0.4753,scaleY:0.4753,x:161.5,y:98.4},0).wait(1).to({scaleX:0.4745,scaleY:0.4745,x:161.6,y:97.45},0).wait(1).to({scaleX:0.4736,scaleY:0.4736,x:161.65,y:96.4},0).wait(1).to({scaleX:0.4724,scaleY:0.4724,x:161.8,y:95.05},0).wait(1).to({scaleX:0.4709,scaleY:0.4709,x:161.9,y:93.45},0).wait(1).to({scaleX:0.469,scaleY:0.469,x:162.05,y:91.35},0).wait(1).to({scaleX:0.4666,scaleY:0.4666,x:162.25,y:88.7},0).wait(1).to({scaleX:0.4635,scaleY:0.4635,x:162.55,y:85.15},0).wait(1).to({scaleX:0.4591,scaleY:0.4591,x:162.95,y:80.3},0).wait(1).to({scaleX:0.4532,scaleY:0.4532,x:163.45,y:73.8},0).wait(1).to({scaleX:0.447,scaleY:0.447,x:164,y:66.85},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:164.5,y:61.3},0).wait(1).to({scaleX:0.4384,scaleY:0.4384,x:164.75,y:57.25},0).wait(1).to({scaleX:0.4356,scaleY:0.4356,x:165.05,y:54.25},0).wait(1).to({scaleX:0.4335,scaleY:0.4335,x:165.25,y:51.85},0).wait(1).to({scaleX:0.4318,scaleY:0.4318,x:165.4,y:50},0).wait(1).to({scaleX:0.4304,scaleY:0.4304,x:165.5,y:48.4},0).wait(1).to({scaleX:0.4293,scaleY:0.4293,x:165.55,y:47.2},0).wait(1).to({scaleX:0.4283,scaleY:0.4283,x:165.7,y:46.1},0).wait(1).to({scaleX:0.4275,scaleY:0.4275,x:165.75,y:45.2},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:165.8,y:44.5},0).wait(1).to({scaleX:0.4263,scaleY:0.4263,x:165.85,y:43.8},0).wait(1).to({scaleX:0.4258,scaleY:0.4258,x:165.9,y:43.3},0).wait(1).to({scaleX:0.4254,scaleY:0.4254,x:165.95,y:42.85},0).wait(1).to({scaleX:0.4251,scaleY:0.4251,y:42.5},0).wait(1).to({scaleX:0.4248,scaleY:0.4248,x:166,y:42.2},0).wait(1).to({scaleX:0.4246,scaleY:0.4246,y:41.95},0).wait(1).to({scaleX:0.4244,scaleY:0.4244,x:166.05,y:41.75},0).wait(1).to({scaleX:0.4243,scaleY:0.4243,y:41.6},0).wait(1).to({scaleX:0.4242,scaleY:0.4242,y:41.5},0).wait(1).to({y:41.45},0).wait(1).to({regX:28.3,regY:23,scaleX:0.4241,scaleY:0.4241,x:166.2,y:41.5},0).to({_off:true},1).wait(2));

	// l girl box shadow
	this.instance_15 = new lib.squareshadow();
	this.instance_15.setTransform(-77.95,180.65,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(22).to({_off:false},0).to({regX:70.9,regY:47.9,scaleX:1.0949,scaleY:1.0949,x:117.5,y:162.4,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:70.6,regY:47.8,x:117.15,y:162.3},0).wait(25).to({regX:70.9,regY:47.9,x:117.5,y:162.4},0).wait(1).to({regX:70.6,regY:47.8,scaleX:1.0881,scaleY:1.0881,x:117.65,y:161.8,alpha:0.1588},0).wait(1).to({scaleX:1.0787,scaleY:1.0787,x:118.4,y:161.15,alpha:0.1571},0).wait(1).to({scaleX:1.0668,scaleY:1.0668,x:119.35,y:160.4,alpha:0.1548},0).wait(1).to({scaleX:1.0522,scaleY:1.0522,x:120.55,y:159.45,alpha:0.152},0).wait(1).to({scaleX:1.0347,scaleY:1.0347,x:121.95,y:158.25,alpha:0.1486},0).wait(1).to({scaleX:1.0142,scaleY:1.0142,x:123.6,y:156.9,alpha:0.1447},0).wait(1).to({scaleX:0.9905,scaleY:0.9905,x:125.5,y:155.35,alpha:0.1402},0).wait(1).to({scaleX:0.9637,scaleY:0.9637,x:127.65,y:153.55,alpha:0.135},0).wait(1).to({scaleX:0.9336,scaleY:0.9336,x:130.05,y:151.55,alpha:0.1292},0).wait(1).to({scaleX:0.9003,scaleY:0.9003,x:132.7,y:149.35,alpha:0.1229},0).wait(1).to({scaleX:0.864,scaleY:0.864,x:135.65,y:146.95,alpha:0.1159},0).wait(1).to({scaleX:0.8248,scaleY:0.8248,x:138.8,y:144.3,alpha:0.1084},0).wait(1).to({scaleX:0.7832,scaleY:0.7832,x:142.15,y:141.6,alpha:0.1004},0).wait(1).to({scaleX:0.7396,scaleY:0.7396,x:145.6,y:138.65,alpha:0.0921},0).wait(1).to({scaleX:0.6947,scaleY:0.6947,x:149.2,y:135.7,alpha:0.0835},0).wait(1).to({scaleX:0.6493,scaleY:0.6493,x:152.85,y:132.7,alpha:0.0748},0).wait(1).to({scaleX:0.6041,scaleY:0.6041,x:156.5,y:129.7,alpha:0.0661},0).wait(1).to({scaleX:0.56,scaleY:0.56,x:160.05,y:126.75,alpha:0.0577},0).wait(1).to({scaleX:0.5177,scaleY:0.5177,x:163.4,y:123.95,alpha:0.0496},0).wait(1).to({scaleX:0.4778,scaleY:0.4778,x:166.6,y:121.3,alpha:0.0419},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:169.6,y:118.85,alpha:0.0349},0).wait(1).to({scaleX:0.4073,scaleY:0.4073,x:172.25,y:116.6,alpha:0.0284},0).wait(1).to({scaleX:0.3772,scaleY:0.3772,x:174.7,y:114.65,alpha:0.0227},0).wait(1).to({scaleX:0.3507,scaleY:0.3507,x:176.8,y:112.85,alpha:0.0176},0).wait(1).to({scaleX:0.3279,scaleY:0.3279,x:178.65,y:111.3,alpha:0.0132},0).wait(1).to({scaleX:0.3086,scaleY:0.3086,x:180.2,y:110.05,alpha:0.0095},0).wait(1).to({scaleX:0.2927,scaleY:0.2927,x:181.45,y:109,alpha:0.0065},0).wait(1).to({scaleX:0.28,scaleY:0.28,x:182.45,y:108.15,alpha:0.004},0).wait(1).to({scaleX:0.2705,scaleY:0.2705,x:183.2,y:107.55,alpha:0.0022},0).wait(1).to({scaleX:0.264,scaleY:0.264,x:183.75,y:107.05,alpha:0.001},0).wait(1).to({scaleX:0.2601,scaleY:0.2601,x:184.05,y:106.85,alpha:0.0002},0).wait(1).to({regX:71.3,regY:48.3,scaleX:0.2589,scaleY:0.2589,x:184.25,y:106.8,alpha:0},0).to({_off:true},52).wait(2));

	// r girl box shadow
	this.instance_16 = new lib.fill();
	this.instance_16.setTransform(253.7,154,1,1,0,0,0,32.5,30.1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(109).to({_off:false},0).to({regX:32.6,regY:30.2,scaleX:0.7654,scaleY:0.7654,x:184.6,y:106.8,alpha:1},9).to({_off:true},55).wait(2));

	// r guy box shadow
	this.instance_17 = new lib.squareshadow();
	this.instance_17.setTransform(226.05,-55.6,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	var maskedShapeInstanceList = [this.instance_17];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(29).to({_off:false},0).to({regX:70.9,regY:47.6,scaleX:0.8786,scaleY:0.8786,x:322.95,y:-27.15,alpha:0.1602},37,cjs.Ease.quadOut).wait(1).to({regX:70.6,regY:47.8,x:322.7,y:-26.95},0).wait(22).to({regX:70.9,regY:47.6,x:322.95,y:-27.15},0).wait(1).to({regX:70.6,regY:47.8,scaleX:0.8673,scaleY:0.8667,x:320.05,y:-25},0).wait(1).to({scaleX:0.8539,scaleY:0.8528,x:316.95,y:-22.75},0).wait(1).to({scaleX:0.8385,scaleY:0.8367,x:313.4,y:-20.15},0).wait(1).to({scaleX:0.8211,scaleY:0.8184,x:309.35,y:-17.2},0).wait(1).to({scaleX:0.8016,scaleY:0.7981,x:304.85,y:-13.9},0).wait(1).to({scaleX:0.7802,scaleY:0.7757,x:299.95,y:-10.3},0).wait(1).to({scaleX:0.7571,scaleY:0.7515,x:294.55,y:-6.4},0).wait(1).to({scaleX:0.7323,scaleY:0.7257,x:288.85,y:-2.2},0).wait(1).to({scaleX:0.7063,scaleY:0.6984,x:282.8,y:2.25},0).wait(1).to({scaleX:0.6792,scaleY:0.6701,x:276.55,y:6.8},0).wait(1).to({scaleX:0.6514,scaleY:0.6411,x:270.15,y:11.5},0).wait(1).to({scaleX:0.6234,scaleY:0.6118,x:263.65,y:16.25},0).wait(1).to({scaleX:0.5955,scaleY:0.5826,x:257.2,y:20.95},0).wait(1).to({scaleX:0.5681,scaleY:0.554,x:250.9,y:25.6},0).wait(1).to({scaleX:0.5416,scaleY:0.5263,x:244.75,y:30},0).wait(1).to({scaleX:0.5164,scaleY:0.4999,x:238.9,y:34.3},0).wait(1).to({scaleX:0.4926,scaleY:0.475,x:233.45,y:38.3},0).wait(1).to({scaleX:0.4706,scaleY:0.452,x:228.3,y:42.05},0).wait(1).to({scaleX:0.4504,scaleY:0.4309,x:223.7,y:45.45},0).wait(1).to({scaleX:0.4322,scaleY:0.4119,x:219.45,y:48.55},0).wait(1).to({scaleX:0.4161,scaleY:0.3951,x:215.75,y:51.25},0).wait(1).to({scaleX:0.4021,scaleY:0.3804,x:212.5,y:53.65},0).wait(1).to({scaleX:0.3901,scaleY:0.3678,x:209.75,y:55.65},0).wait(1).to({scaleX:0.3801,scaleY:0.3574,x:207.45,y:57.35},0).wait(1).to({scaleX:0.3722,scaleY:0.3491,x:205.55,y:58.7},0).wait(1).to({scaleX:0.3661,scaleY:0.3427,x:204.2,y:59.7},0).wait(1).to({scaleX:0.3618,scaleY:0.3383,x:203.2,y:60.4},0).wait(1).to({scaleX:0.3594,scaleY:0.3357,x:202.6,y:60.85},0).wait(1).to({regX:70.9,regY:48.1,scaleX:0.3586,scaleY:0.3349,x:202.55,y:60.95},0).to({_off:true},55).wait(2));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(34.25,56.65,0.4246,0.4246,0,0,0,225,236.6);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(67).to({regX:232.4,regY:219.8,x:37.35,y:49.5},0).wait(22).to({regX:225,regY:236.6,x:34.25,y:56.65},0).wait(1).to({regX:232.4,regY:219.8,scaleX:0.4236,scaleY:0.4236,x:37.35,y:49.7},0).wait(1).to({scaleX:0.4221,scaleY:0.4221,y:49.95},0).wait(1).to({scaleX:0.4198,scaleY:0.4198,x:37.25,y:50.35},0).wait(1).to({scaleX:0.4169,scaleY:0.4169,x:37.2,y:50.8},0).wait(1).to({scaleX:0.4131,scaleY:0.4131,x:37.05,y:51.45},0).wait(1).to({scaleX:0.4085,scaleY:0.4085,x:36.95,y:52.25},0).wait(1).to({scaleX:0.4031,scaleY:0.4031,x:36.8,y:53.15},0).wait(1).to({scaleX:0.3968,scaleY:0.3968,x:36.6,y:54.2},0).wait(1).to({scaleX:0.3896,scaleY:0.3896,x:36.45,y:55.4},0).wait(1).to({scaleX:0.3816,scaleY:0.3816,x:36.2,y:56.7},0).wait(1).to({scaleX:0.3728,scaleY:0.3728,x:35.95,y:58.2},0).wait(1).to({scaleX:0.3634,scaleY:0.3634,x:35.7,y:59.75},0).wait(1).to({scaleX:0.3536,scaleY:0.3536,x:35.4,y:61.4},0).wait(1).to({scaleX:0.3435,scaleY:0.3435,x:35.15,y:63.1},0).wait(1).to({scaleX:0.3336,scaleY:0.3336,x:34.9,y:64.75},0).wait(1).to({scaleX:0.3239,scaleY:0.3239,x:34.6,y:66.4},0).wait(1).to({scaleX:0.3147,scaleY:0.3147,x:34.35,y:67.95},0).wait(1).to({scaleX:0.3062,scaleY:0.3062,x:34.1,y:69.3},0).wait(1).to({scaleX:0.2984,scaleY:0.2984,x:33.9,y:70.6},0).wait(1).to({scaleX:0.2914,scaleY:0.2914,x:33.65,y:71.75},0).wait(1).to({scaleX:0.2853,scaleY:0.2853,x:33.55,y:72.8},0).wait(1).to({scaleX:0.2799,scaleY:0.2799,x:33.35,y:73.65},0).wait(1).to({scaleX:0.2753,scaleY:0.2753,x:33.25,y:74.45},0).wait(1).to({scaleX:0.2715,scaleY:0.2715,x:33.15,y:75.05},0).wait(1).to({scaleX:0.2684,scaleY:0.2684,x:33.05,y:75.6},0).wait(1).to({scaleX:0.2659,scaleY:0.2659,x:33,y:76.05},0).wait(1).to({scaleX:0.264,scaleY:0.264,x:32.9,y:76.35},0).wait(1).to({scaleX:0.2628,scaleY:0.2628,y:76.55},0).wait(1).to({regX:224.8,regY:236.8,scaleX:0.262,scaleY:0.262,x:30.9,y:81.1},0).to({_off:true},55).wait(2));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(101.95,79.4,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(27).to({regY:15.3,scaleX:1.2235,scaleY:1.2235,x:119.6,y:75.75},21,cjs.Ease.quadInOut).wait(19).to({regX:38,x:119.75},0).wait(22).to({regX:37.9,x:119.6},0).wait(1).to({regX:38,scaleX:1.2208,scaleY:1.2208,x:119.5,y:75.85},0).wait(1).to({scaleX:1.2163,scaleY:1.2163,x:119.15,y:76},0).wait(1).to({scaleX:1.2099,scaleY:1.2099,x:118.65,y:76.25},0).wait(1).to({scaleX:1.2013,scaleY:1.2013,x:118,y:76.6},0).wait(1).to({scaleX:1.1905,scaleY:1.1905,x:117.2,y:76.95},0).wait(1).to({scaleX:1.1773,scaleY:1.1773,x:116.2,y:77.45},0).wait(1).to({scaleX:1.1617,scaleY:1.1617,x:114.95,y:78},0).wait(1).to({scaleX:1.1435,scaleY:1.1435,x:113.55,y:78.7},0).wait(1).to({scaleX:1.1227,scaleY:1.1227,x:111.95,y:79.45},0).wait(1).to({scaleX:1.0996,scaleY:1.0996,x:110.2,y:80.25},0).wait(1).to({scaleX:1.0743,scaleY:1.0743,x:108.25,y:81.25},0).wait(1).to({scaleX:1.0472,scaleY:1.0472,x:106.15,y:82.2},0).wait(1).to({scaleX:1.0189,scaleY:1.0189,x:103.95,y:83.25},0).wait(1).to({scaleX:0.99,scaleY:0.99,x:101.75,y:84.3},0).wait(1).to({scaleX:0.9614,scaleY:0.9614,x:99.6,y:85.35},0).wait(1).to({scaleX:0.9335,scaleY:0.9335,x:97.4,y:86.4},0).wait(1).to({scaleX:0.907,scaleY:0.907,x:95.4,y:87.35},0).wait(1).to({scaleX:0.8825,scaleY:0.8825,x:93.5,y:88.25},0).wait(1).to({scaleX:0.86,scaleY:0.86,x:91.8,y:89.05},0).wait(1).to({scaleX:0.8399,scaleY:0.8399,x:90.2,y:89.8},0).wait(1).to({scaleX:0.8221,scaleY:0.8221,x:88.9,y:90.5},0).wait(1).to({scaleX:0.8066,scaleY:0.8066,x:87.7,y:91.05},0).wait(1).to({scaleX:0.7935,scaleY:0.7935,x:86.65,y:91.55},0).wait(1).to({scaleX:0.7824,scaleY:0.7824,x:85.85,y:91.9},0).wait(1).to({scaleX:0.7734,scaleY:0.7734,x:85.15,y:92.25},0).wait(1).to({scaleX:0.7663,scaleY:0.7663,x:84.55,y:92.5},0).wait(1).to({scaleX:0.761,scaleY:0.761,x:84.15,y:92.7},0).wait(1).to({scaleX:0.7572,scaleY:0.7572,x:83.85,y:92.85},0).wait(1).to({regX:37.9,scaleX:0.7551,scaleY:0.7551,x:83.65,y:92.95},0).to({_off:true},55).wait(2));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(96.85,82.55,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(27).to({regX:37.8,regY:15.8,scaleX:1.2428,scaleY:1.2428,x:119.75,y:75.8},21,cjs.Ease.quadInOut).to({regX:37.9,scaleX:0.9512,scaleY:0.9512,x:113.65,y:75.75,alpha:0},18,cjs.Ease.quadOut).to({_off:true},107).wait(2));

	// first image
	this.instance_18 = new lib.firstimage_1();
	this.instance_18.setTransform(211.45,64.75,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(32).to({regX:42.1,regY:26.8,scaleX:0.9274,scaleY:0.9274,x:330,y:54.55},22,cjs.Ease.quadInOut).wait(13).to({regX:41,regY:25.6,x:328.95,y:53.45},0).wait(22).to({regX:42.1,regY:26.8,x:330,y:54.55},0).wait(1).to({regX:41,regY:25.6,scaleX:0.9253,scaleY:0.9253,x:328.3,y:53.6},0).wait(1).to({scaleX:0.9219,scaleY:0.9219,x:327.2,y:53.85},0).wait(1).to({scaleX:0.917,scaleY:0.917,x:325.6,y:54.25},0).wait(1).to({scaleX:0.9105,scaleY:0.9105,x:323.5,y:54.75},0).wait(1).to({scaleX:0.9024,scaleY:0.9024,x:320.85,y:55.4},0).wait(1).to({scaleX:0.8924,scaleY:0.8924,x:317.6,y:56.2},0).wait(1).to({scaleX:0.8805,scaleY:0.8805,x:313.75,y:57.2},0).wait(1).to({scaleX:0.8667,scaleY:0.8667,x:309.3,y:58.3},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:304.2,y:59.55},0).wait(1).to({scaleX:0.8334,scaleY:0.8334,x:298.5,y:60.95},0).wait(1).to({scaleX:0.8142,scaleY:0.8142,x:292.3,y:62.45},0).wait(1).to({scaleX:0.7937,scaleY:0.7937,x:285.65,y:64.1},0).wait(1).to({scaleX:0.7723,scaleY:0.7723,x:278.7,y:65.8},0).wait(1).to({scaleX:0.7504,scaleY:0.7504,x:271.6,y:67.55},0).wait(1).to({scaleX:0.7287,scaleY:0.7287,x:264.55,y:69.3},0).wait(1).to({scaleX:0.7076,scaleY:0.7076,x:257.75,y:71},0).wait(1).to({scaleX:0.6875,scaleY:0.6875,x:251.25,y:72.6},0).wait(1).to({scaleX:0.6689,scaleY:0.6689,x:245.2,y:74.1},0).wait(1).to({scaleX:0.6518,scaleY:0.6518,x:239.7,y:75.45},0).wait(1).to({scaleX:0.6366,scaleY:0.6366,x:234.75,y:76.7},0).wait(1).to({scaleX:0.6231,scaleY:0.6231,x:230.4,y:77.75},0).wait(1).to({scaleX:0.6114,scaleY:0.6114,x:226.6,y:78.7},0).wait(1).to({scaleX:0.6014,scaleY:0.6014,x:223.35,y:79.5},0).wait(1).to({scaleX:0.593,scaleY:0.593,x:220.65,y:80.2},0).wait(1).to({scaleX:0.5862,scaleY:0.5862,x:218.45,y:80.7},0).wait(1).to({scaleX:0.5808,scaleY:0.5808,x:216.7,y:81.1},0).wait(1).to({scaleX:0.5768,scaleY:0.5768,x:215.4,y:81.45},0).wait(1).to({scaleX:0.574,scaleY:0.574,x:214.5,y:81.7},0).wait(1).to({regX:42,regY:26.8,scaleX:0.5723,scaleY:0.5723,x:214.6,y:82.55},0).to({_off:true},55).wait(2));

	// square shadow
	this.instance_19 = new lib.squareshadow();
	this.instance_19.setTransform(209.9,68.35,0.4651,0.4621,0,0,0,71,48);
	this.instance_19.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(32).to({regX:71.5,regY:48.5,scaleX:0.5233,scaleY:0.5041,x:329.7,y:54.7},22,cjs.Ease.quadInOut).to({_off:true},1).wait(120));

	// second image
	this.instance_20 = new lib.secondimage();
	this.instance_20.setTransform(348.35,83.35,1.2033,1.2033,0,0,0,42,26.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(35).to({regX:42.1,regY:26.6,scaleX:0.9261,scaleY:0.9261,x:348.25,y:88.45},22,cjs.Ease.quadInOut).wait(10).to({regY:26.8,y:88.6},0).wait(22).to({regY:26.6,y:88.45},0).wait(1).to({regY:26.8,scaleX:0.924,scaleY:0.924,x:347.5,y:88.65},0).wait(1).to({scaleX:0.9206,scaleY:0.9206,x:346.3,y:88.8},0).wait(1).to({scaleX:0.9157,scaleY:0.9157,x:344.65,y:89.05},0).wait(1).to({scaleX:0.9093,scaleY:0.9093,x:342.45,y:89.3},0).wait(1).to({scaleX:0.9011,scaleY:0.9011,x:339.6,y:89.65},0).wait(1).to({scaleX:0.8911,scaleY:0.8911,x:336.15,y:90.1},0).wait(1).to({scaleX:0.8793,scaleY:0.8793,x:332.05,y:90.55},0).wait(1).to({scaleX:0.8655,scaleY:0.8655,x:327.3,y:91.15},0).wait(1).to({scaleX:0.8498,scaleY:0.8498,x:321.9,y:91.75},0).wait(1).to({scaleX:0.8323,scaleY:0.8323,x:315.85,y:92.5},0).wait(1).to({scaleX:0.8131,scaleY:0.8131,x:309.25,y:93.35},0).wait(1).to({scaleX:0.7926,scaleY:0.7926,x:302.15,y:94.2},0).wait(1).to({scaleX:0.7712,scaleY:0.7712,x:294.75,y:95.05},0).wait(1).to({scaleX:0.7494,scaleY:0.7494,x:287.25,y:96},0).wait(1).to({scaleX:0.7276,scaleY:0.7276,x:279.75,y:96.9},0).wait(1).to({scaleX:0.7066,scaleY:0.7066,x:272.45,y:97.8},0).wait(1).to({scaleX:0.6865,scaleY:0.6865,x:265.55,y:98.65},0).wait(1).to({scaleX:0.6679,scaleY:0.6679,x:259.1,y:99.4},0).wait(1).to({scaleX:0.6509,scaleY:0.6509,x:253.25,y:100.15},0).wait(1).to({scaleX:0.6357,scaleY:0.6357,x:248,y:100.8},0).wait(1).to({scaleX:0.6222,scaleY:0.6222,x:243.35,y:101.35},0).wait(1).to({scaleX:0.6105,scaleY:0.6105,x:239.35,y:101.8},0).wait(1).to({scaleX:0.6006,scaleY:0.6006,x:235.9,y:102.25},0).wait(1).to({scaleX:0.5922,scaleY:0.5922,x:233.05,y:102.55},0).wait(1).to({scaleX:0.5854,scaleY:0.5854,x:230.65,y:102.9},0).wait(1).to({scaleX:0.58,scaleY:0.58,x:228.8,y:103.1},0).wait(1).to({scaleX:0.576,scaleY:0.576,x:227.4,y:103.3},0).wait(1).to({scaleX:0.5732,scaleY:0.5732,x:226.45,y:103.4},0).wait(1).to({regY:26.4,scaleX:0.5715,scaleY:0.5715,x:225.85,y:103.35},0).to({_off:true},55).wait(2));

	// square shadow
	this.instance_21 = new lib.squareshadow();
	this.instance_21.setTransform(346,90.5,0.7489,0.744,0,0,0,71,48.3);
	this.instance_21.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(35).to({regX:71.3,regY:48.7,scaleX:0.5595,scaleY:0.4559,x:348.45,y:89.4},22,cjs.Ease.quadInOut).to({_off:true},1).wait(117));

	// screen
	this.instance_22 = new lib.WordUI();
	this.instance_22.setTransform(234.2,88.8,1.3474,1.3474,0,0,0,151.1,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(67).to({regX:150.7,regY:96.1,x:233.65,y:89.1},0).wait(22).to({regX:151.1,regY:95.9,x:234.2,y:88.8},0).wait(1).to({regX:150.7,regY:96.1,scaleX:1.3445,scaleY:1.3445,x:233.15,y:89.2},0).wait(1).to({scaleX:1.3395,scaleY:1.3395,x:232.4,y:89.3},0).wait(1).to({scaleX:1.3324,scaleY:1.3324,x:231.3,y:89.45},0).wait(1).to({scaleX:1.323,scaleY:1.323,x:229.85,y:89.7},0).wait(1).to({scaleX:1.3111,scaleY:1.3111,x:228.05,y:89.95},0).wait(1).to({scaleX:1.2966,scaleY:1.2966,x:225.8,y:90.3},0).wait(1).to({scaleX:1.2793,scaleY:1.2793,x:223.1,y:90.7},0).wait(1).to({scaleX:1.2593,scaleY:1.2593,x:220,y:91.15},0).wait(1).to({scaleX:1.2364,scaleY:1.2364,x:216.5,y:91.7},0).wait(1).to({scaleX:1.2109,scaleY:1.2109,x:212.55,y:92.25},0).wait(1).to({scaleX:1.183,scaleY:1.183,x:208.25,y:92.95},0).wait(1).to({scaleX:1.1532,scaleY:1.1532,x:203.65,y:93.6},0).wait(1).to({scaleX:1.1221,scaleY:1.1221,x:198.85,y:94.4},0).wait(1).to({scaleX:1.0903,scaleY:1.0903,x:193.9,y:95.1},0).wait(1).to({scaleX:1.0587,scaleY:1.0587,x:189.05,y:95.85},0).wait(1).to({scaleX:1.028,scaleY:1.028,x:184.25,y:96.55},0).wait(1).to({scaleX:0.9989,scaleY:0.9989,x:179.8,y:97.2},0).wait(1).to({scaleX:0.9718,scaleY:0.9718,x:175.6,y:97.8},0).wait(1).to({scaleX:0.9471,scaleY:0.9471,x:171.75,y:98.35},0).wait(1).to({scaleX:0.9249,scaleY:0.9249,x:168.4,y:98.9},0).wait(1).to({scaleX:0.9053,scaleY:0.9053,x:165.35,y:99.35},0).wait(1).to({scaleX:0.8883,scaleY:0.8883,x:162.7,y:99.75},0).wait(1).to({scaleX:0.8738,scaleY:0.8738,x:160.5,y:100.05},0).wait(1).to({scaleX:0.8616,scaleY:0.8616,x:158.6,y:100.35},0).wait(1).to({scaleX:0.8517,scaleY:0.8517,x:157.05,y:100.6},0).wait(1).to({scaleX:0.8439,scaleY:0.8439,x:155.85,y:100.8},0).wait(1).to({scaleX:0.838,scaleY:0.838,x:154.95,y:100.95},0).wait(1).to({scaleX:0.8339,scaleY:0.8339,x:154.3,y:101},0).wait(1).to({regX:151.1,regY:96,scaleX:0.8315,scaleY:0.8315,x:154.35,y:100.9},0).to({_off:true},55).wait(2));

	// screen shadow
	this.instance_23 = new lib.shadow_1();
	this.instance_23.setTransform(191.4,56.55,1.1271,1.1271,0,0,0,180.8,119.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(66).to({regX:180.7,regY:119.8,x:191.25,y:56.65},0).wait(1).to({regX:189.8,regY:149.6,x:201.5,y:90.25},0).wait(22).to({regX:180.7,regY:119.8,x:191.25,y:56.65},0).wait(1).to({regX:189.8,regY:149.6,scaleX:1.1245,scaleY:1.1245,x:201.15,y:90.4},0).wait(1).to({scaleX:1.1203,scaleY:1.1203,x:200.55,y:90.5},0).wait(1).to({scaleX:1.1143,scaleY:1.1143,x:199.6,y:90.75},0).wait(1).to({scaleX:1.1063,scaleY:1.1063,x:198.35,y:91},0).wait(1).to({scaleX:1.0962,scaleY:1.0962,x:196.85,y:91.4},0).wait(1).to({scaleX:1.0839,scaleY:1.0839,x:194.95,y:91.8},0).wait(1).to({scaleX:1.0692,scaleY:1.0692,x:192.8,y:92.35},0).wait(1).to({scaleX:1.0522,scaleY:1.0522,x:190.2,y:92.95},0).wait(1).to({scaleX:1.0328,scaleY:1.0328,x:187.2,y:93.65},0).wait(1).to({scaleX:1.0111,scaleY:1.0111,x:183.95,y:94.4},0).wait(1).to({scaleX:0.9874,scaleY:0.9874,x:180.35,y:95.25},0).wait(1).to({scaleX:0.9621,scaleY:0.9621,x:176.5,y:96.15},0).wait(1).to({scaleX:0.9357,scaleY:0.9357,x:172.5,y:97.05},0).wait(1).to({scaleX:0.9087,scaleY:0.9087,x:168.4,y:98.05},0).wait(1).to({scaleX:0.8818,scaleY:0.8818,x:164.3,y:99},0).wait(1).to({scaleX:0.8558,scaleY:0.8558,x:160.4,y:99.9},0).wait(1).to({scaleX:0.831,scaleY:0.831,x:156.65,y:100.8},0).wait(1).to({scaleX:0.808,scaleY:0.808,x:153.15,y:101.65},0).wait(1).to({scaleX:0.787,scaleY:0.787,x:149.95,y:102.4},0).wait(1).to({scaleX:0.7682,scaleY:0.7682,x:147.05,y:103},0).wait(1).to({scaleX:0.7516,scaleY:0.7516,x:144.55,y:103.65},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:142.35,y:104.15},0).wait(1).to({scaleX:0.7248,scaleY:0.7248,x:140.45,y:104.6},0).wait(1).to({scaleX:0.7145,scaleY:0.7145,x:138.9,y:104.95},0).wait(1).to({scaleX:0.706,scaleY:0.706,x:137.65,y:105.25},0).wait(1).to({scaleX:0.6994,scaleY:0.6994,x:136.65,y:105.45},0).wait(1).to({scaleX:0.6944,scaleY:0.6944,x:135.85,y:105.65},0).wait(1).to({scaleX:0.6909,scaleY:0.6909,x:135.35,y:105.75},0).wait(1).to({regX:181,regY:120,scaleX:0.6889,scaleY:0.6889,x:128.8,y:85.3},0).to({_off:true},55).wait(2));

	// Layer_2
	this.ribbon_1 = new lib.ribbon();
	this.ribbon_1.name = "ribbon_1";
	this.ribbon_1.setTransform(88,94.15,1.25,1.25,0,0,0,77.1,306.4);
	this.ribbon_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon_1).wait(84).to({_off:false},0).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.9,-281.3,1909.3000000000002,750);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{chart:4,vanish:55});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(74).call(this.frame_74).wait(1));

	// Layer_7
	this.instance = new lib.excel_screen_white();
	this.instance.setTransform(115.65,-128.65,1,1,0,0,0,225.3,151.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61).to({_off:false},0).to({alpha:0.6016},13,cjs.Ease.cubicInOut).wait(1));

	// Layer_5
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(-19.5,-91.65);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({alpha:1},2,cjs.Ease.cubicInOut).wait(14));

	// Layer_3
	this.instance_2 = new lib.Rectangle111sml();
	this.instance_2.setTransform(-109.45,7.9,1.5099,1.5099);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75));

	// SmallGraphCover
	this.instance_3 = new lib.whitebar();
	this.instance_3.setTransform(284.05,-150.1,1.1639,1.0777,0,0,0,17.8,38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({regX:17.9,scaleX:1.4222,x:288.8},0).to({scaleX:1.2503,scaleY:0.5617,x:285.75,y:-189.9},51,cjs.Ease.quartInOut).wait(20));

	// SmallGraph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4AA167").s().p("Ai/JMIAAyXIF/AAIAASXg");
	this.shape.setTransform(282.6,-128.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#327545").s().p("Ai/KhIAA1BIF/AAIAACpIAASYg");
	this.shape_1.setTransform(244.175,-136.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(75));

	// Layer_6
	this.chart_mask = new lib.chart_mask();
	this.chart_mask.name = "chart_mask";
	this.chart_mask.setTransform(-29.15,-97.5,1,1,0,0,0,59.1,63);
	this.chart_mask.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.chart_mask).wait(75));

	// Text
	this.instance_4 = new lib.textanimation("synched",0,false);
	this.instance_4.setTransform(-26.65,-93.55,1,1,0,0,0,33.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(75));

	// GraphMask
	this.instance_5 = new lib.GraphCover("synched",0,false);
	this.instance_5.setTransform(-57.95,-124.7,1,1,0,0,0,28.9,28.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(75));

	// Graph_LG
	this.instance_6 = new lib.graphLG();
	this.instance_6.setTransform(-28.95,-95.65,1,1,0,0,0,49.9,49.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(75));

	// UI
	this.instance_7 = new lib.UI();
	this.instance_7.setTransform(115.85,-274.1,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,-279.6,471.79999999999995,305.70000000000005);


(lib.Pop_up_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.opt3 = new lib.option_btn();
	this.opt3.name = "opt3";
	this.opt3.setTransform(134.5,62.3,1,1,0,0,0,134.5,14.3);

	this.opt2 = new lib.option_btn();
	this.opt2.name = "opt2";
	this.opt2.setTransform(134.5,37.8,1,1,0,0,0,134.5,14.3);

	this.opt1 = new lib.option_btn();
	this.opt1.name = "opt1";
	this.opt1.setTransform(134.5,13.3,1,1,0,0,0,134.5,14.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.opt1},{t:this.opt2},{t:this.opt3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Pop_up_menu, new cjs.Rectangle(-0.2,-1.2,160.5,74), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(83.3,14.5,0.6,0.6,0,0,0,13.8,10.8);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(57.4,15.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("An1CLIAAkVIPrAAIAAEVg");
	this.shape.setTransform(50.125,13.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D7").s().p("An2CMIAAkXIPsAAIAAEXg");
	this.shape_1.setTransform(50.2,13.925);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,-0.1,100.5,28.1), null);


(lib.screenanimationexcel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		//this.title_s.cache(-38,-15.7,152,63,2);
	}
	this.frame_44 = function() {
		this.screen.gotoAndPlay("chart");
	}
	this.frame_99 = function() {
		this.td_graph.gotoAndPlay("grow");
	}
	this.frame_160 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(55).call(this.frame_99).wait(61).call(this.frame_160).wait(1));

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.setTransform(35.45,-49.8,1.2333,1.2333,0,0,0,64.7,62.9);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(89).to({scaleX:0.7883,scaleY:0.7883,x:23.15,y:1.55},30,cjs.Ease.cubicInOut).wait(42));

	// td_graph
	this.td_graph = new lib._3D_price();
	this.td_graph.name = "td_graph";
	this.td_graph.setTransform(147.35,40.05,0.6248,0.561,0,0,0,5.1,0.7);

	this.timeline.addTween(cjs.Tween.get(this.td_graph).wait(89).to({regX:5,scaleX:0.3993,scaleY:0.3586,x:94.7,y:59},30,cjs.Ease.cubicInOut).wait(42));

	// screen3
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(218.15,-16.45,0.7374,0.5902,0,-28.3389,-17.0404,107.4,-133.6);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(89).to({regY:-133.8,scaleX:0.4713,scaleY:0.3772,skewX:-28.3398,skewY:-17.0422,x:140,y:22.85},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_2
	this.instance = new lib.shadow_1();
	this.instance.setTransform(187.15,-42.95,1.1264,1.1264,0,0,0,180.7,119.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:180.8,regY:119.4,scaleX:0.72,scaleY:0.72,x:120.15,y:5.95},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_4
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-17.3,-358.6,1.25,1.25);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39,-351.1,477.2,750);


(lib.object_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.screen = new lib.screenanimation_1();
	this.screen.name = "screen";
	this.screen.setTransform(6.7,175.4,0.79,0.79,0,0,0,196.9,130.8);

	this.screen_1 = new lib.screenanimation();
	this.screen_1.name = "screen_1";
	this.screen_1.setTransform(9.3,146.35,1,1,0,0,0,197.1,130.8);

	this.screen_2 = new lib.screenanimationexcel();
	this.screen_2.name = "screen_2";
	this.screen_2.setTransform(14.2,230.5,0.79,0.79,0,0,0,196.9,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen}]}).to({state:[{t:this.screen_1}]},1).to({state:[{t:this.screen_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-177,-154.9,394,600);


(lib.Page = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// obj1
	this.obj1 = new lib.object_1();
	this.obj1.name = "obj1";
	this.obj1.setTransform(265.8,375.5,1,1,0,0,0,127.8,219.5);

	this.timeline.addTween(cjs.Tween.get(this.obj1).wait(1));

	// bg
	this.bg = new lib.Page_bg();
	this.bg.name = "bg";
	this.bg.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page, new cjs.Rectangle(-125.9,0,461.20000000000005,600.5), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(953.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(95.5,568.05,0.9555,0.9555,0,0,0,0.8,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(59.85,555.85,1,1,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// page
	this.page = new lib.Page();
	this.page.name = "page";
	this.page.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.page).wait(1));

	// option_hits
	this.hit_down = new lib.option_hit();
	this.hit_down.name = "hit_down";
	this.hit_down.setTransform(85.75,685.8,0.6329,0.7506,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit_down, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit_opts = new lib.option_hit();
	this.hit_opts.name = "hit_opts";
	// this.hit_opts.setTransform(85.75,512.6,0.6329,0.7506,0,0,0,134.6,14.5);
	this.hit_opts.setTransform(85.75,585.8,0.6329,0.7506,0,0,0,134.6,14.5);
	new cjs.ButtonHelper(this.hit_opts, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	// this.hit3.setTransform(85.75,586.05,0.6329,0.7506,0,0,0,134.6,14.4);
	this.hit3.setTransform(85.75,561.05,0.6329,0.7506,0,0,0,134.6,14.4);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	// this.hit2.setTransform(85.75,561.35,0.6329,0.7506,0,0,0,134.6,14.5);
	this.hit2.setTransform(85.75,536.35,0.6329,0.7506,0,0,0,134.6,14.5);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	// this.hit1.setTransform(85.75,536.6,0.6329,0.7506,0,0,0,134.6,14.5);
	this.hit1.setTransform(85.75,512.6,0.6329,0.7506,0,0,0,134.6,14.5);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit_opts},{t:this.hit_down}]}).wait(1));

	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3bGfIAAs9MAu2AAAIAAM9g");
	mask.setTransform(79.95,532.85);

	// options
	this.popup_menu = new lib.Pop_up_menu();
	this.popup_menu.name = "popup_menu";
	// this.popup_menu.setTransform(79.5,563.4,1,1,0,0,0,79.5,35.9);
	this.popup_menu.setTransform(79.5,539.4,1,1,0,0,0,79.5,35.9);

	var maskedShapeInstanceList = [this.popup_menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.popup_menu).wait(1));

	// opts
	this.opts = new lib.option_btn_menu();
	this.opts.name = "opts";
	// this.opts.setTransform(134.5,516.3,1,1,0,0,0,134.5,14.3);
	this.opts.setTransform(134.5,589.3,1,1,0,0,0,134.5,14.3);

	this.timeline.addTween(cjs.Tween.get(this.opts).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// first_frame
	this.background = new lib.mountain_anim();
	this.background.name = "background";
	this.background.setTransform(284.4,25.1,1,1,0,0,0,284.4,25.1);

	this.timeline.addTween(cjs.Tween.get(this.background).wait(1));

	// Bg
	this.instance = new lib.whitecopy();
	this.instance.setTransform(483.1,169.9,1,1,0,0,0,483.1,169.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-125.9,-11.4,1091.3,711), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var frequency = 5;
		stage.enableMouseOver(frequency);

		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"

		this.initBanner = function (data) {

			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;

			Object.keys = function(obj) {
				var keys = [];

				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)

				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "page") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillPage(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt1") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_1(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt2") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_2(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt3") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_3(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opts") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}


		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillPage = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.page.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillOption = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.opts.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillOption_1 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt1.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillOption_2 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt2.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillOption_3 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt3.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}

		var mc = exportRoot.mainMC
		var opt1 = mc.popup_menu.opt1
		var opt2 = mc.popup_menu.opt2
		var opt3 = mc.popup_menu.opt3
		var opts = mc.opts

		var hit1 = mc.hit1
		var hit2 = mc.hit2
		var hit3 = mc.hit3
		var hit_opts = mc.hit_opts
		var hit_down = mc.hit_down

		this.runBanner = function() {

			mc.replay_btn.visible=false
			mc.page.alpha=0

			mc.cta.alpha=0
			mc.txtCta.alpha=0

			this.TL_Popup = new TimelineMax();
			exportRoot.TL_Popup.add('frame0');
				exportRoot.TL_Popup.to(hit_opts, 0.1, {y: "+=100"}, "-=0");
				exportRoot.TL_Popup.from(opt1, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0");
				exportRoot.TL_Popup.from(hit1, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(opt2, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit2, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(opt3, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit3, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.to(hit_down, 0.1, {y: "-=100"}, "-=0");
			exportRoot.TL_Popup.add('frame1');
			exportRoot.TL_Popup.stop();

				this.TL_MainScreen = new TimelineMax();
				exportRoot.TL_MainScreen.add('frame0')

				exportRoot.TL_MainScreen.from(mc.background, 0.1, {x: "+=200", ease:Power2.easeOut, onStart:function(){mc.background.ribbon.play();}}, "+=0");

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");

				}
				exportRoot.TL_MainScreen.from(opts, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit_opts, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_MainScreen.from(opt1, 0.6, {x: "+=150", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit1, 0.6, {x: "+=150", ease:Power3.easeIn}, "-=0.6");
				exportRoot.TL_MainScreen.from(opt2, 0.6, {x: "+=150", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit2, 0.6, {x: "+=150", ease:Power3.easeIn}, "-=0.6");
				exportRoot.TL_MainScreen.from(opt3, 0.6, {x: "+=150", alpha:0, ease:Power3.easeOut}, "-=0.5");
				exportRoot.TL_MainScreen.from(hit3, 0.6, {x: "+=150", ease:Power3.easeIn}, "-=0.6");

				//exportRoot.TL_MainScreen.stop();
				exportRoot.TL_MainScreen.add('frame1');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "+=0");
					if (i!=0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "-=0.5");
				}

				exportRoot.TL_MainScreen.to(mc.background, 0.8, {x: "-=150", ease:Power3.easeIn}, "-=0.6");
				exportRoot.TL_MainScreen.to(opts, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.7");
				exportRoot.TL_MainScreen.to(hit_opts, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit_down, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt1, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit1, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt2, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit2, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt3, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit3, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");

				exportRoot.TL_MainScreen.add('frame2')

				exportRoot.TL_MainScreen.stop();

				mc.logo_intro.gotoAndPlay(1)

			exportRoot.tltxt1 = new TimelineMax();
			exportRoot.tltxt1.add('frame0')
			for (var i = 0; i < exportRoot.page_1_1.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_1_2.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt1.add('frame1')
			exportRoot.tltxt1.stop();

			exportRoot.tltxt2 = new TimelineMax();
			exportRoot.tltxt2.add('frame0')
			for (var i = 0; i < exportRoot.page_2_1.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_2_2.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt2.add('frame1')
			exportRoot.tltxt2.stop();

			exportRoot.tltxt3 = new TimelineMax();
			exportRoot.tltxt3.add('frame0')
			for (var i = 0; i < exportRoot.page_3_1.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_3_2.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}

			exportRoot.tltxt3.add('frame1')
			exportRoot.tltxt3.stop();

			//
			//   FRAME 2 ANIMATION IN / OUT
			//
			exportRoot.TL_Frame2_IN = new TimelineMax();

			mc.cta.alpha=1
			mc.txtCta.alpha=1

			exportRoot.TL_Frame2_IN.add('frame0')
			exportRoot.TL_Frame2_IN.from(mc.page.bg, 1, {x: "+=450",  ease:Power4.easeOut}, "+=0.3");
			//exportRoot.TL_Frame2_IN.from(mc.page.ribbon, 2, {x: "+=400",  ease:Power4.easeOut}, "-=1");
			exportRoot.TL_Frame2_IN.from(mc.page.obj1, 1.5, {x: "+=400",  ease:Power4.easeOut, onStart:function(){mc.page.obj1.screen.play();}}, "-=1");

			exportRoot.TL_Frame2_IN.from(mc.txtCta, 1, { alpha: 0, x: "+=100", ease:Power4.easeOut}, "+=1.8");
			exportRoot.TL_Frame2_IN.from(mc.cta, 1, {	alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=1");

			exportRoot.TL_Frame2_IN.add('frame1')

			exportRoot.TL_Frame2_IN.stop()
		}

		exportRoot.selectedOption = function(id) {

			//exportRoot.TL_MainScreen.timeScale(1)
			//exportRoot.TL_Clouds.tweenFromTo("frame1", "frame2");
			exportRoot.TL_MainScreen.tweenFromTo("frame1", "frame2");

			exportRoot.selectedScreenIn(id)

		}
		exportRoot.mainScreenOut = function() {

		}
		var IDtest = 0
		exportRoot.selectedScreenIn = function(id) {
			IDtest = id
			mc.page.obj1.gotoAndStop(id-1)
			//mc.page.ribbon.gotoAndStop(id-1)

			mc.page.alpha=1
			var pageID = id
			mc.page.obj1.visible=true
			mc.page.obj1.alpha = 1

			if (id==1) {
				exportRoot.tltxt1.tweenFromTo("frame0", "frame1",{delay:.3});
				};
			if (id==2) {
				exportRoot.tltxt2.tweenFromTo("frame0", "frame1",{delay:.3});
				};
			if (id==3) {
				exportRoot.tltxt3.tweenFromTo("frame0", "frame1",{delay:.3});
				};

			exportRoot.TL_Frame2_IN.tweenFromTo("frame0", "frame1",{delay:.3});

		}

		function mainOver() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(1);
		}
		function mainOut() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-45.9,288.6,1011.3,386.4);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593187422196", id:"M365_FY21Q1_BTS_USA_160x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
	var lastW, lastH, lastS=1;
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas();
	function resizeCanvas() {
		var w = lib.properties.width, h = lib.properties.height;
		var iw = window.innerWidth, ih=window.innerHeight;
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
		if(isResp) {
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
				sRatio = lastS;
			}
			else if(!isScale) {
				if(iw<w || ih<h)
					sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==1) {
				sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==2) {
				sRatio = Math.max(xRatio, yRatio);
			}
		}
		domContainers[0].width = w * pRatio * sRatio;
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {
			container.style.width = w * sRatio + 'px';
			container.style.height = h * sRatio + 'px';
		});
		stage.scaleX = pRatio*sRatio;
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;
		stage.tickOnUpdate = false;
		stage.update();
		stage.tickOnUpdate = true;
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
