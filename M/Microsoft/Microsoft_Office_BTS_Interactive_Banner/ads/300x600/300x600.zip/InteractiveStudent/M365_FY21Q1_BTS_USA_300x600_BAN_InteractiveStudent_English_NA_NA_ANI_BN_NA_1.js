(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[604,0,302,192],[0,0,300,306],[711,387,74,126],[302,202,158,129],[154,414,107,56],[0,308,131,104],[523,452,84,53],[787,387,89,65],[0,506,51,43],[399,355,156,76],[787,504,52,43],[869,459,75,50],[399,433,122,39],[53,506,52,41],[609,452,76,52],[457,474,53,43],[350,439,47,69],[946,459,55,55],[787,454,80,48],[133,308,131,104],[0,494,300,10],[908,0,100,151],[564,202,30,52],[564,256,31,48],[564,306,31,46],[990,306,31,45],[990,353,30,44],[990,399,30,43],[302,494,30,43],[908,153,100,151],[462,202,100,151],[888,306,100,151],[399,474,56,45],[302,0,300,200],[263,439,85,53],[604,194,282,191],[557,387,152,63],[0,414,152,61],[266,333,131,104]]}
];


// symbols:



(lib.basicUIhalf = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bg_img_300x600_smlpngcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.bodyResize_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.chart_big_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.chart_sml_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Excel_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.girllefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Grass_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.guylefticonsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontributionsml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.leafA_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.LeafB_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.percent_msml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.PPT_icon_sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Render0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Render0109sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Render0110sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Render0111sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Render0112sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Render0113sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Render0114sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Render0115sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Render0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Render0117 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Render0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1sml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.secondimagesml = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Word_icon_sml_update = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.WordIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//this.iconcache.cache(-260,-230,520,460,0.8)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Word_icon_sml_update();
	this.instance.setTransform(108,121,1.9,1.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(108,121,248.89999999999998,197.60000000000002), null);


(lib.whitebar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixGAIAAr/IFjAAIAAL/g");
	this.shape.setTransform(17.825,38.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebar, new cjs.Rectangle(0,0,35.7,76.8), null);


(lib.whitecopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150.0023,299.9992,1,2.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitecopy, new cjs.Rectangle(0,0,300,600), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AsGrUIYXAAIAAWdI4hAMg");
	this.shape.setTransform(-0.0003,-0.0264);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-78.5,-72.5,157.1,145);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCZNMAAAkyZMCZbAAAMAAAEyZg");
	this.shape.setTransform(0,0.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-980.4,982,1961);


(lib.Topbar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape.setTransform(268.579,5.5001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#437F5B").s().p("AgJgEIATAAIgKAJg");
	this.shape_1.setTransform(72.0759,5.5001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUAbIgGgGIAAgwIA1AAIAAATIgCAAIAAgQIgGAAIAAAQIgCAAIAAgQIggAAIAAAXIANAAIgBABIgPAAIAAgYIgGAAIAAArIAFAGIAFAAIAAgQIAGAAIAAADIgEAAIAAANIAGAAIAAACg");
	this.shape_2.setTransform(46.425,6.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMABIAAAEIgCAAIAAgJIAJAAIAAADIgGAAQAEAFAHAAQAKAAADgJIACABQgDAKgMAAQgIAAgEgFg");
	this.shape_3.setTransform(47.6,8.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAGIACgGQAFgGAHAAQAHAAAGAGIAAgEIACAAIAAAJIgKAAIAAgDIAHAAQgFgFgHAAQgFAAgFAEIgCAGg");
	this.shape_4.setTransform(47.6,6.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAQIgOgOIgNAOIgCAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAOgOIgOgNIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAABIANANIAOgNIACAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgOANIAOAOQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_5.setTransform(442.325,5.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQARIAAgaIAHAAIAAgHIAaAAIAAAaIgHAAIAAAHgAgNAOIAVAAIAAgUIgVAAgAgHgJIARAAIAAAQIAEAAIAAgUIgVAAg");
	this.shape_6.setTransform(427.1,5.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.3).p("AgRAAIAjAA");
	this.shape_7.setTransform(411.95,5.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUARIAAghIApAAIAAAhgAABAOIASAAIAAgUIglAAIAAAUIASAAIAAgOIgGAEIgBgCIAHgHIAIAHIgBACIgGgEgAgSgJIAlAAIAAgEIglAAg");
	this.shape_8.setTransform(396.625,5.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIABIAAgBIARAAIAAABg");
	this.shape_9.setTransform(78.65,4.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_10.setTransform(78.675,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_11.setTransform(60.575,5.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#437F5B").s().p("AgQAFQgFgFABgHQABgHAFgFIABAAQAFgFAHAAQAHACAEAEIAJAKIAAgTIACAAIAAAYIgWAAIAAgDIASAAIgJgKQgDgEgGgBQgFAAgFADIgCABQgEAEgBAGQAAAHAEADIAUAXIgCABg");
	this.shape_12.setTransform(67.2167,6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAaIAUgXQAEgDAAgHQgBgFgFgFIgBgBQgFgDgFAAQgGABgDAEIgJAKIASAAIAAADIgWAAIAAgYIACAAIAAATIAJgKQAEgEAGgCQAHAAAGAFIABAAQAFAFABAHQAAAHgEAFIgUAWg");
	this.shape_13.setTransform(55.625,6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AglAaQgKAAgIgIQgIgHAAgLQAAgKAIgHQAIgIAKAAIBLAAQALAAAHAIQAIAHAAAKQAAALgIAHQgHAIgLAAgAAdgIQgEAEAAAEQAAAFAEAEQADADAGAAQAFAAADgDQADgEAAgFQAAgEgDgEQgDgDgFAAQgGAAgDADg");
	this.shape_14.setTransform(32.4,5.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#227347").s().p("EgjJAA3IAAhuMBGTAAAIAABug");
	this.shape_15.setTransform(225,5.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Topbar, new cjs.Rectangle(0,0,450,11.1), null);


(lib.top_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt13 = new cjs.Text("Comments", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 7;
	this.txt13.lineWidth = 23;
	this.txt13.parent = this;
	this.txt13.setTransform(416.2,18.75);

	this.txt13_1 = new cjs.Text("Share", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13_1.name = "txt13_1";
	this.txt13_1.lineHeight = 7;
	this.txt13_1.lineWidth = 15;
	this.txt13_1.parent = this;
	this.txt13_1.setTransform(390.7,15.7);

	this.txt13_2 = new cjs.Text("Search", "5px 'Segoe Pro'", "#474747");
	this.txt13_2.name = "txt13_2";
	this.txt13_2.lineHeight = 8;
	this.txt13_2.lineWidth = 15;
	this.txt13_2.parent = this;
	this.txt13_2.setTransform(208,15.55);

	this.txt12 = new cjs.Text("Help", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 15;
	this.txt12.parent = this;
	this.txt12.setTransform(181,18.55);

	this.txt11 = new cjs.Text("View", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 15;
	this.txt11.parent = this;
	this.txt11.setTransform(162.95,18.55);

	this.txt10 = new cjs.Text("Review", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 15;
	this.txt10.parent = this;
	this.txt10.setTransform(140.55,18.55);

	this.txt9 = new cjs.Text("Date", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 15;
	this.txt9.parent = this;
	this.txt9.setTransform(122.5,18.55);

	this.txt8 = new cjs.Text("Formulas", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 24;
	this.txt8.parent = this;
	this.txt8.setTransform(95.4,18.55);

	this.txt7 = new cjs.Text("Page Layout", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 33;
	this.txt7.parent = this;
	this.txt7.setTransform(62.2,18.55);

	this.txt6 = new cjs.Text("Insert", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 13;
	this.txt6.parent = this;
	this.txt6.setTransform(41.25,18.55);

	this.txt5 = new cjs.Text("Home", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 13;
	this.txt5.parent = this;
	this.txt5.setTransform(19.9,18.55);

	this.txt4 = new cjs.Text("File", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 8;
	this.txt4.parent = this;
	this.txt4.setTransform(2.3,18.55);

	this.txt3 = new cjs.Text("Daniella Duarte", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 30;
	this.txt3.parent = this;
	this.txt3.setTransform(355.05,7.2);

	this.txt2 = new cjs.Text("Family Budget - Saved to OneDrive", "5px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 105;
	this.txt2.parent = this;
	this.txt2.setTransform(185.3,6.5);

	this.txt1 = new cjs.Text("On", "3px 'Segoe Pro'", "#227347");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 6;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(24.15,6.6);

	this.txt = new cjs.Text("AutoSave", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 7;
	this.txt.lineWidth = 19;
	this.txt.parent = this;
	this.txt.setTransform(2,6.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13_2},{t:this.txt13_1},{t:this.txt13}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_text, new cjs.Rectangle(0,4.5,441.2,22.3), null);


(lib.titleshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.textanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#44724B").s().p("AhZB4ICOjaQgaAHgjAAIgIAAQAJAMAAAOQAAAUgOAQQgOAQgXAAQgWAAgOgPQgPgPAAgVQAAgOAHgMQAHgLAMgHQAMgHANAAQAFAAANADQATAEAVAAQAQAAAPgCQAPgCAXgHIARAAIicDvgAhRhXQgJAKAAANQAAAOAJAIQAKAKANAAQANAAAKgKQAJgIAAgOQAAgNgJgKQgKgKgNAAQgNAAgKAKgAAXBhQgPgQAAgUQAAgWAPgOQAPgPAVAAQAVAAAPAPQAPAOAAAWQAAAUgPAQQgPAPgVAAQgVAAgPgPgAAkAmQgJAJAAAOQAAANAJAJQAKAJANAAQANAAAKgJQAJgJAAgNQAAgOgJgJQgKgKgNAAQgNAAgKAKg");
	this.shape.setTransform(46.925,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAFgIQAGgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgcARQAQAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_1.setTransform(26.9,20.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#44724B").s().p("AhIBuIBRhZQAZgaAIgNQAHgNAAgOQAAgSgNgNQgOgNgUAAQgTAAgOAOQgOAOgCAZIgUAAQABggAUgVQAVgVAdABQAdAAATATQASATAAAaQAAATgJAQQgIAOgaAcIg0A6IBiAAIAAAUg");
	this.shape_2.setTransform(10.225,20.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_3.setTransform(26.925,20.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAdABATATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_4.setTransform(26.9,20.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_5.setTransform(27.3,20.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#44724B").s().p("AhABlIBji+IhmAAIAAgUICHAAIhyDbg");
	this.shape_6.setTransform(27.625,20.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#44724B").s().p("Ag1BdQgTgVAAgYQAAgSAKgPQAJgOAXgKQgQgJgHgMQgJgMAAgOQABgOAIgNQAIgOAPgHQAPgIAQAAQARAAAPAIQAOAHAIAOQAIANAAAPQAAAOgIAMQgHALgPAJQAVAJAJAOQAKAOAAASQAAAZgRATQgTAXglAAQgjAAgSgUgAgjAPQgPAOAAATQAAAMAGALQAHAKALAGQAMAGAOAAQAXAAAOgOQAPgOAAgTQAAgSgPgOQgPgOgVAAQgVAAgPAPgAgchRQgMALAAAOQAAAPANALQAMAMAQAAQAKAAAKgFQAJgGAGgJQAGgJAAgJQAAgNgLgLQgKgLgVAAQgRAAgLAKg");
	this.shape_7.setTransform(26.95,20.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#44724B").s().p("AgoBmIA5hYQgMADgJAAQgZAAgTgRQgSgTAAgbQABgSAIgPQAJgPAQgJQAQgJARAAQASAAAPAIQAPAJAIAQQAKAPgBASQAAANgFAPQgFAOgOAUIhBBhgAgfhOQgNANAAATQAAATANANQAOANARAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgRAAgOANg");
	this.shape_8.setTransform(26.75,20.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#44724B").s().p("AglBlQgRgMgJgXQgJgYAAgqQAAgqAJgXQAJgXARgMQAQgMAVAAQAUAAARAMQARAMAKAYQAJAYAAAoQAAApgJAYQgKAYgRAMQgRAMgUAAQgVAAgQgMgAgahSQgNAJgGATQgHATAAAkQAAAkAHATQAGASANAKQANAKANAAQAOAAANgKQAMgJAHgTQAIgXAAggQgBgggHgVQgHgVgMgJQgNgKgOAAQgNAAgNAKg");
	this.shape_9.setTransform(26.95,20.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAGgIQAFgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgbARQAPAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_10.setTransform(10.25,20.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#44724B").s().p("AAGBsIAAjCIghAAIANgVIAqAAIAADXg");
	this.shape_11.setTransform(25.675,20.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_12.setTransform(10.275,20.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAeABASATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_13.setTransform(10.25,20.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_14.setTransform(10.65,20.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},7).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_4},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_12},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_14},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},4).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,66.4,39.8);


(lib.text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlleftcontributionsml();
	this.instance.setTransform(0.1,-0.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,-0.2,89.1,65.2), null);


(lib.text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.tablet_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,-4,0,4.6,-4,8.6).s().p("AgMASQgKgKgGgKQgEgHgCgIIgCgKIgBgIIAAgGIBLAAIAAABIAABSQgegCgUgWg");
	this.shape.setTransform(-10.0002,11.9003);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-3.6,18.3,4.7,18.3).s().p("AglCAIAAghIABAHIACAKQACAJAEAHgAglBYIAAjXIBLAAIAADXg");
	this.shape_1.setTransform(-10.0002,-1.1249);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.6,4.1,0,4.6,4.1,8.6).s().p("AglAqIAAgCIAAAAQABgiAYgXQAUgWAegCIAABSIAAABg");
	this.shape_2.setTransform(-10.0002,-18.1502);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,4.2,-18.2,-4.2).s().p("ABkAqIjgAAIgDAAIAAgBIAAhSID/AAIAAABIAAAAIAABSg");
	this.shape_3.setTransform(6.5751,12.0003);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,-4.1,0,-4,-4.1,8.6).s().p("AgoAqIgBAAIAAhSIAAAAIAAgBIABAAIBSAAIAAABIAAADQAAAhgYAVQgXAZgiAAg");
	this.shape_4.setTransform(23.6253,12.0003);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],4.3,21.6,-4.1,21.6).s().p("AApBwIAAAAIhSAAIAAjaIBSAAIAAgFIABAAIAADfg");
	this.shape_5.setTransform(23.7003,-3.375);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ACABtIkAAAIAAgBIAAjXIAAgBIEAAAIABAAIAADZg");
	this.shape_6.setTransform(6.6251,-3.1249);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-18.2,-4.1,-18.2,4.3).s().p("Ah/AqIAAhSIAAgBIADAAIDgAAIAcAAIAABSIAAABg");
	this.shape_7.setTransform(6.5751,-18.2502);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4,4.2,0,-4,4.2,8.6).s().p("AgoAqIgBAAIAAgBIAAhSIABAAIABAAQAiAAAXAYQAXAWABAfIAAAGg");
	this.shape_8.setTransform(23.6253,-18.2502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,5,1.1,-5).s().p("AkLAyIAAAAIABAAIABAAIACAAIAAgCIAAhhIGwAAIBjAAIAABhIAAACIgCAAIAAAAIAAAAg");
	this.shape_9.setTransform(36.375,89.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,-4.8,0,4.9,-4.8,10.2).s().p("AAwAyIgBAAIgCAAQgngBgagcQgdgbAAgoIAAgDIBhAAIACAAIAAABIAABhIAAABg");
	this.shape_10.setTransform(5,89.175);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],-4.9,0.1,5.1,0.1).s().p("AAwFyIhhAAIAArjIBhAAIACAAIAALjg");
	this.shape_11.setTransform(5,47.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],4.9,4.8,0,4.9,4.8,10.2).s().p("AAwAzIhhAAIAAgCIAAgBQAAgpAdgbQAagcAngBIACAAIABAAIACAAIAABiIAAACg");
	this.shape_12.setTransform(5,5.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],1.1,-5,1.1,5).s().p("ACpAyImwAAIAAhiIgCAAIgBAAIgBAAIAAgBIIVAAIAAABIAAAAIACAAIAABig");
	this.shape_13.setTransform(36.375,5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,5,0,-5).s().p("AECAyIoVAAIgDAAIAAAAIAAAAIACAAIAAgCIAAhhIAWAAIB8AAIEgAAIB3AAIAABhIAAACIABAAIABAAIAAAAg");
	this.shape_14.setTransform(90.875,89.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,-4.8,0,-4.8,-4.8,10.2).s().p("AgwAyIgBAAIAAgBIAAhhIAAgBIACAAIBhAAIAAADQgBAogdAbQgaAdgpAAIgBAAg");
	this.shape_15.setTransform(123.6,89.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],0,-5,0,5).s().p("ACeAyIkgAAIh8AAIgWAAIAAhiIgCAAIAAAAIAAgBIItAAIAAABIgBAAIgBAAIAABig");
	this.shape_16.setTransform(90.875,5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AGoFzIkhAAIh9AAIgUAAIhjAAImxAAIAAgBIAArjIAAgBIGxAAIBjAAIAUAAIB9AAIEhAAIB3AAIAAABIAALjIAAABg");
	this.shape_17.setTransform(64.3,47.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(0,0,0,0)","#000000"],[0,1],5,0.1,-5,0.1).s().p("AgvFyIgCAAIAArjIACAAIBhAAIAALjg");
	this.shape_18.setTransform(123.6,47.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["#000000","rgba(0,0,0,0)"],[0,1],-4.8,4.8,0,-4.8,4.8,10.2).s().p("AgvAzIgCAAIAAgCIAAhiIABAAIABAAQApAAAaAdQAdAbABApIAAABIAAACg");
	this.shape_19.setTransform(123.6,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_sub, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.small_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_sml_msml();
	this.instance.setTransform(198,132,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.small_pie, new cjs.Rectangle(0,0,420,420), null);


(lib.secondimage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.secondimagesml();
	this.instance.setTransform(-0.4,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage, new cjs.Rectangle(-0.4,0,85,53.3), null);


(lib.screenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.basicUIhalf();
	this.instance.setTransform(-0.35,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.rowsandcells = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//columns
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		
		//rows
		this.txt01.textBaseline = "alphabetic"
		this.txt02.textBaseline = "alphabetic"
		this.txt03.textBaseline = "alphabetic"
		this.txt04.textBaseline = "alphabetic"
		this.txt05.textBaseline = "alphabetic"
		this.txt06.textBaseline = "alphabetic"
		this.txt07.textBaseline = "alphabetic"
		this.txt08.textBaseline = "alphabetic"
		this.txt09.textBaseline = "alphabetic"
		this.txt010.textBaseline = "alphabetic"
		this.txt011.textBaseline = "alphabetic"
		this.txt012.textBaseline = "alphabetic"
		this.txt013.textBaseline = "alphabetic"
		this.txt014.textBaseline = "alphabetic"
		this.txt015.textBaseline = "alphabetic"
		this.txt016.textBaseline = "alphabetic"
		this.txt017.textBaseline = "alphabetic"
		this.txt018.textBaseline = "alphabetic"
		this.txt019.textBaseline = "alphabetic"
		this.txt020.textBaseline = "alphabetic"
		this.txt021.textBaseline = "alphabetic"
		this.txt022.textBaseline = "alphabetic"
		this.txt023.textBaseline = "alphabetic"
		this.txt024.textBaseline = "alphabetic"
		this.txt025.textBaseline = "alphabetic"
		this.txt026.textBaseline = "alphabetic"
		this.txt027.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt027 = new cjs.Text("27", "5px 'Segoe Pro'", "#474747");
	this.txt027.name = "txt027";
	this.txt027.lineHeight = 8;
	this.txt027.lineWidth = 6;
	this.txt027.parent = this;
	this.txt027.setTransform(-11,241.15);

	this.txt026 = new cjs.Text("26", "5px 'Segoe Pro'", "#474747");
	this.txt026.name = "txt026";
	this.txt026.lineHeight = 8;
	this.txt026.lineWidth = 6;
	this.txt026.parent = this;
	this.txt026.setTransform(-11,232.95);

	this.txt025 = new cjs.Text("25", "5px 'Segoe Pro'", "#474747");
	this.txt025.name = "txt025";
	this.txt025.lineHeight = 8;
	this.txt025.lineWidth = 6;
	this.txt025.parent = this;
	this.txt025.setTransform(-11,224.65);

	this.txt024 = new cjs.Text("24", "5px 'Segoe Pro'", "#474747");
	this.txt024.name = "txt024";
	this.txt024.lineHeight = 8;
	this.txt024.lineWidth = 6;
	this.txt024.parent = this;
	this.txt024.setTransform(-11,216.35);

	this.txt023 = new cjs.Text("23", "5px 'Segoe Pro'", "#474747");
	this.txt023.name = "txt023";
	this.txt023.lineHeight = 8;
	this.txt023.lineWidth = 6;
	this.txt023.parent = this;
	this.txt023.setTransform(-11,208.2);

	this.txt022 = new cjs.Text("22", "5px 'Segoe Pro'", "#474747");
	this.txt022.name = "txt022";
	this.txt022.lineHeight = 8;
	this.txt022.lineWidth = 6;
	this.txt022.parent = this;
	this.txt022.setTransform(-11,200);

	this.txt021 = new cjs.Text("21", "5px 'Segoe Pro'", "#474747");
	this.txt021.name = "txt021";
	this.txt021.lineHeight = 8;
	this.txt021.lineWidth = 6;
	this.txt021.parent = this;
	this.txt021.setTransform(-11,191.7);

	this.txt020 = new cjs.Text("20", "5px 'Segoe Pro'", "#474747");
	this.txt020.name = "txt020";
	this.txt020.lineHeight = 8;
	this.txt020.lineWidth = 6;
	this.txt020.parent = this;
	this.txt020.setTransform(-11,183.35);

	this.txt019 = new cjs.Text("19", "5px 'Segoe Pro'", "#474747");
	this.txt019.name = "txt019";
	this.txt019.lineHeight = 8;
	this.txt019.lineWidth = 6;
	this.txt019.parent = this;
	this.txt019.setTransform(-10.5,175.1);

	this.txt018 = new cjs.Text("18", "5px 'Segoe Pro'", "#474747");
	this.txt018.name = "txt018";
	this.txt018.lineHeight = 8;
	this.txt018.lineWidth = 6;
	this.txt018.parent = this;
	this.txt018.setTransform(-10.5,166.9);

	this.txt017 = new cjs.Text("17", "5px 'Segoe Pro'", "#474747");
	this.txt017.name = "txt017";
	this.txt017.lineHeight = 8;
	this.txt017.lineWidth = 6;
	this.txt017.parent = this;
	this.txt017.setTransform(-10.5,158.7);

	this.txt016 = new cjs.Text("16", "5px 'Segoe Pro'", "#474747");
	this.txt016.name = "txt016";
	this.txt016.lineHeight = 8;
	this.txt016.lineWidth = 6;
	this.txt016.parent = this;
	this.txt016.setTransform(-10.5,150.45);

	this.txt015 = new cjs.Text("15", "5px 'Segoe Pro'", "#474747");
	this.txt015.name = "txt015";
	this.txt015.lineHeight = 8;
	this.txt015.lineWidth = 6;
	this.txt015.parent = this;
	this.txt015.setTransform(-10.5,142.15);

	this.txt014 = new cjs.Text("14", "5px 'Segoe Pro'", "#474747");
	this.txt014.name = "txt014";
	this.txt014.lineHeight = 8;
	this.txt014.lineWidth = 6;
	this.txt014.parent = this;
	this.txt014.setTransform(-10.5,133.85);

	this.txt013 = new cjs.Text("13", "5px 'Segoe Pro'", "#474747");
	this.txt013.name = "txt013";
	this.txt013.lineHeight = 8;
	this.txt013.lineWidth = 6;
	this.txt013.parent = this;
	this.txt013.setTransform(-10.5,125.8);

	this.txt012 = new cjs.Text("12", "5px 'Segoe Pro'", "#474747");
	this.txt012.name = "txt012";
	this.txt012.lineHeight = 8;
	this.txt012.lineWidth = 6;
	this.txt012.parent = this;
	this.txt012.setTransform(-10.5,117.5);

	this.txt011 = new cjs.Text("11", "5px 'Segoe Pro'", "#474747");
	this.txt011.name = "txt011";
	this.txt011.lineHeight = 8;
	this.txt011.lineWidth = 6;
	this.txt011.parent = this;
	this.txt011.setTransform(-10.5,109.3);

	this.txt010 = new cjs.Text("10", "5px 'Segoe Pro'", "#474747");
	this.txt010.name = "txt010";
	this.txt010.lineHeight = 8;
	this.txt010.lineWidth = 6;
	this.txt010.parent = this;
	this.txt010.setTransform(-10.5,101.05);

	this.txt09 = new cjs.Text("9", "5px 'Segoe Pro'", "#474747");
	this.txt09.name = "txt09";
	this.txt09.lineHeight = 8;
	this.txt09.lineWidth = 6;
	this.txt09.parent = this;
	this.txt09.setTransform(-9.7,92.8);

	this.txt08 = new cjs.Text("8", "5px 'Segoe Pro'", "#474747");
	this.txt08.name = "txt08";
	this.txt08.lineHeight = 8;
	this.txt08.lineWidth = 6;
	this.txt08.parent = this;
	this.txt08.setTransform(-9.7,84.6);

	this.txt07 = new cjs.Text("7", "5px 'Segoe Pro'", "#474747");
	this.txt07.name = "txt07";
	this.txt07.lineHeight = 8;
	this.txt07.lineWidth = 6;
	this.txt07.parent = this;
	this.txt07.setTransform(-9.7,76.35);

	this.txt06 = new cjs.Text("6", "5px 'Segoe Pro'", "#474747");
	this.txt06.name = "txt06";
	this.txt06.lineHeight = 8;
	this.txt06.lineWidth = 6;
	this.txt06.parent = this;
	this.txt06.setTransform(-9.7,68.1);

	this.txt05 = new cjs.Text("5", "5px 'Segoe Pro'", "#474747");
	this.txt05.name = "txt05";
	this.txt05.lineHeight = 8;
	this.txt05.lineWidth = 6;
	this.txt05.parent = this;
	this.txt05.setTransform(-9.7,59.85);

	this.txt04 = new cjs.Text("4", "5px 'Segoe Pro'", "#474747");
	this.txt04.name = "txt04";
	this.txt04.lineHeight = 8;
	this.txt04.lineWidth = 6;
	this.txt04.parent = this;
	this.txt04.setTransform(-9.7,51.6);

	this.txt03 = new cjs.Text("3", "5px 'Segoe Pro'", "#474747");
	this.txt03.name = "txt03";
	this.txt03.lineHeight = 8;
	this.txt03.lineWidth = 6;
	this.txt03.parent = this;
	this.txt03.setTransform(-9.7,43.25);

	this.txt02 = new cjs.Text("2", "5px 'Segoe Pro'", "#474747");
	this.txt02.name = "txt02";
	this.txt02.lineHeight = 8;
	this.txt02.lineWidth = 6;
	this.txt02.parent = this;
	this.txt02.setTransform(-9.7,35.1);

	this.txt01 = new cjs.Text("1", "5px 'Segoe Pro'", "#474747");
	this.txt01.name = "txt01";
	this.txt01.lineHeight = 8;
	this.txt01.lineWidth = 6;
	this.txt01.parent = this;
	this.txt01.setTransform(-9.35,26.7);

	this.txt16 = new cjs.Text("Q", "5px 'Segoe Pro'", "#474747");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 8;
	this.txt16.lineWidth = 6;
	this.txt16.parent = this;
	this.txt16.setTransform(401.15,18.5);

	this.txt15 = new cjs.Text("P", "5px 'Segoe Pro'", "#474747");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 8;
	this.txt15.lineWidth = 6;
	this.txt15.parent = this;
	this.txt15.setTransform(376.95,18.5);

	this.txt14 = new cjs.Text("O", "5px 'Segoe Pro'", "#474747");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 8;
	this.txt14.lineWidth = 6;
	this.txt14.parent = this;
	this.txt14.setTransform(351.85,18.5);

	this.txt13 = new cjs.Text("N", "5px 'Segoe Pro'", "#474747");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 8;
	this.txt13.lineWidth = 6;
	this.txt13.parent = this;
	this.txt13.setTransform(327.05,18.5);

	this.txt12 = new cjs.Text("M", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 6;
	this.txt12.parent = this;
	this.txt12.setTransform(302,18.5);

	this.txt11 = new cjs.Text("L", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 6;
	this.txt11.parent = this;
	this.txt11.setTransform(278.35,18.5);

	this.txt10 = new cjs.Text("K", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 6;
	this.txt10.parent = this;
	this.txt10.setTransform(253.35,18.5);

	this.txt9 = new cjs.Text("J", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 6;
	this.txt9.parent = this;
	this.txt9.setTransform(229.05,18.5);

	this.txt8 = new cjs.Text("I", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 6;
	this.txt8.parent = this;
	this.txt8.setTransform(204.65,18.5);

	this.txt7 = new cjs.Text("H", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 6;
	this.txt7.parent = this;
	this.txt7.setTransform(178.85,18.5);

	this.txt6 = new cjs.Text("G", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 6;
	this.txt6.parent = this;
	this.txt6.setTransform(154.5,18.5);

	this.txt5 = new cjs.Text("F", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 6;
	this.txt5.parent = this;
	this.txt5.setTransform(130.3,18.5);

	this.txt4 = new cjs.Text("E", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 6;
	this.txt4.parent = this;
	this.txt4.setTransform(105.5,18.5);

	this.txt3 = new cjs.Text("D", "5px 'Segoe Pro'", "#474747");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 8;
	this.txt3.lineWidth = 6;
	this.txt3.parent = this;
	this.txt3.setTransform(80.45,18.5);

	this.txt2 = new cjs.Text("C", "5px 'Segoe Pro'", "#474747");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(55.95,18.5);

	this.txt1 = new cjs.Text("B", "5px 'Segoe Pro'", "#474747");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 8;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(31.3,18.5);

	this.txt = new cjs.Text("A", "5px 'Segoe Pro'", "#474747");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(6.4,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt01},{t:this.txt02},{t:this.txt03},{t:this.txt04},{t:this.txt05},{t:this.txt06},{t:this.txt07},{t:this.txt08},{t:this.txt09},{t:this.txt010},{t:this.txt011},{t:this.txt012},{t:this.txt013},{t:this.txt014},{t:this.txt015},{t:this.txt016},{t:this.txt017},{t:this.txt018},{t:this.txt019},{t:this.txt020},{t:this.txt021},{t:this.txt022},{t:this.txt023},{t:this.txt024},{t:this.txt025},{t:this.txt026},{t:this.txt027}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rowsandcells, new cjs.Rectangle(-13,16.5,422.2,232.7), null);


(lib.roundshadowshape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.roundshadow1sml();
	this.instance.setTransform(0,0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45.3), null);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.bodyResize_sml();
	this.instance.setTransform(8,4,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(0,0,114,181), null);


(lib.percantage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.percent_msml();
	this.instance.setTransform(194,187,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.percantage, new cjs.Rectangle(0,0,420,420), null);


(lib.Page_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(242,242,242,0)","#F2F2F2"],[0,0.282],-213,0,213,0).s().p("EghRAu4MAAAhdvMBCjAAAMAAABdvg");
	this.shape.setTransform(87.05,299.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_bg, new cjs.Rectangle(-125.9,0,649.6999999999999,600), null);


(lib.option_hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.2)").s().p("AzrCkIAAlHMAnXAAAIAAFHg");
	this.shape.setTransform(125.975,16.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#333333").s().p("AzrCkIAAlHMAnXAAAIAAFHg");
	this.shape_1.setTransform(125.975,16.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,252,32.8);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAIAqIAhgfIh3AAIAAgUIB3AAIghggIAbAAIAsApIgsAqg");
	this.shape.setTransform(-2.1,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-10,-4.1,15.8,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(172.2024,63.4258);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(172.2024,63.4258);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],20.7,54.8,0,20.7,54.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(172.2024,71.5759);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(0,0,344.4,135), null);


(lib.main_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
		this.txt20.textBaseline = "alphabetic"
		this.txt21.textBaseline = "alphabetic"
		this.txt22.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.txt22 = new cjs.Text("Expense", "7px 'Segoe Pro'", "#227347");
	this.txt22.name = "txt22";
	this.txt22.lineHeight = 11;
	this.txt22.lineWidth = 32;
	this.txt22.parent = this;
	this.txt22.setTransform(356.25,158);

	this.txt21 = new cjs.Text("Income", "7px 'Segoe Pro'", "#227347");
	this.txt21.name = "txt21";
	this.txt21.lineHeight = 11;
	this.txt21.lineWidth = 32;
	this.txt21.parent = this;
	this.txt21.setTransform(311.35,158);

	this.txt20 = new cjs.Text("$0", "6px 'Segoe Pro'", "#227347");
	this.txt20.name = "txt20";
	this.txt20.lineHeight = 10;
	this.txt20.lineWidth = 18;
	this.txt20.parent = this;
	this.txt20.setTransform(290,140.1);

	this.txt19 = new cjs.Text("$100", "6px 'Segoe Pro'", "#227347");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 10;
	this.txt19.lineWidth = 18;
	this.txt19.parent = this;
	this.txt19.setTransform(283.55,125.2);

	this.txt18 = new cjs.Text("$200", "6px 'Segoe Pro'", "#227347");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 10;
	this.txt18.lineWidth = 18;
	this.txt18.parent = this;
	this.txt18.setTransform(283.55,110.5);

	this.txt17 = new cjs.Text("$300", "6px 'Segoe Pro'", "#227347");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 10;
	this.txt17.lineWidth = 18;
	this.txt17.parent = this;
	this.txt17.setTransform(283.55,95.8);

	this.txt16 = new cjs.Text("$400", "6px 'Segoe Pro'", "#227347");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 10;
	this.txt16.lineWidth = 18;
	this.txt16.parent = this;
	this.txt16.setTransform(283.55,80.75);

	this.txt15 = new cjs.Text("$500", "6px 'Segoe Pro'", "#227347");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 10;
	this.txt15.lineWidth = 18;
	this.txt15.parent = this;
	this.txt15.setTransform(283.55,66.25);

	this.txt14 = new cjs.Text("$600", "6px 'Segoe Pro'", "#227347");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 10;
	this.txt14.lineWidth = 18;
	this.txt14.parent = this;
	this.txt14.setTransform(283.55,51.55);

	this.txt13 = new cjs.Text("$700", "6px 'Segoe Pro'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 10;
	this.txt13.lineWidth = 18;
	this.txt13.parent = this;
	this.txt13.setTransform(283.55,36.65);

	this.txt12 = new cjs.Text("$800", "6px 'Segoe Pro'", "#227347");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 10;
	this.txt12.lineWidth = 18;
	this.txt12.parent = this;
	this.txt12.setTransform(283.55,22.35);

	this.txt11 = new cjs.Text("$900", "6px 'Segoe Pro'", "#227347");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 10;
	this.txt11.lineWidth = 18;
	this.txt11.parent = this;
	this.txt11.setTransform(283.55,7.45);

	this.txt9 = new cjs.Text("Cash Balance", "7px 'Segoe Pro'", "#227347");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 11;
	this.txt9.lineWidth = 100;
	this.txt9.parent = this;
	this.txt9.setTransform(152.7,133.5);

	this.txt7 = new cjs.Text("Total monthly savings", "7px 'Segoe Pro'", "#227347");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 11;
	this.txt7.lineWidth = 100;
	this.txt7.parent = this;
	this.txt7.setTransform(152.7,98.7);

	this.txt5 = new cjs.Text("Total monthly expenses", "7px 'Segoe Pro'", "#227347");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 11;
	this.txt5.lineWidth = 100;
	this.txt5.parent = this;
	this.txt5.setTransform(152.7,64.1);

	this.txt10 = new cjs.Text("$130", "12px 'Segoe Pro'", "#227347");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 18;
	this.txt10.lineWidth = 100;
	this.txt10.parent = this;
	this.txt10.setTransform(152.7,150.1);

	this.txt8 = new cjs.Text("$100", "12px 'Segoe Pro'", "#227347");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 18;
	this.txt8.lineWidth = 100;
	this.txt8.parent = this;
	this.txt8.setTransform(152.7,115.5);

	this.txt6 = new cjs.Text("$670", "12px 'Segoe Pro'", "#227347");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 18;
	this.txt6.lineWidth = 100;
	this.txt6.parent = this;
	this.txt6.setTransform(152.7,80.65);

	this.txt4 = new cjs.Text("$900", "12px 'Segoe Pro'", "#227347");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 18;
	this.txt4.lineWidth = 100;
	this.txt4.parent = this;
	this.txt4.setTransform(152.7,45.85);

	this.txt3 = new cjs.Text("Total monthly income", "7px 'Segoe Pro'", "#227347");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 11;
	this.txt3.lineWidth = 100;
	this.txt3.parent = this;
	this.txt3.setTransform(152.7,29.3);

	this.txt2 = new cjs.Text("Summary", "8px 'Segoe Pro'", "#227347");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(152.7,11.2);

	this.txt1 = new cjs.Text("Percentage of income spent", "6px 'Segoe Pro'", "#B7B2A6");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 10;
	this.txt1.lineWidth = 100;
	this.txt1.parent = this;
	this.txt1.setTransform(2,26.4);

	this.txt = new cjs.Text("School Budget", "14px 'Segoe Pro'", "#227347");
	this.txt.name = "txt";
	this.txt.lineHeight = 20;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(2,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt6},{t:this.txt8},{t:this.txt10},{t:this.txt5},{t:this.txt7},{t:this.txt9},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt17},{t:this.txt18},{t:this.txt19},{t:this.txt20},{t:this.txt21},{t:this.txt22}]}).wait(1));

	// Graph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#49A166").s().p("AitJYIAAg5IA4AAIAAA5gAjBGUIAAvrIGDAAIAAPrg");
	this.shape.setTransform(365.3,97.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#337446").s().p("AjVMGIAAg4IA5AAIAAA4gAiqJCIAA1HIGAAAIAAFdIAAPqg");
	this.shape_1.setTransform(324.475,80.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E4DFD4").ss(0.3).p("ATPKLIqoABIkUAAIAAiFIAAyXAkvJ0IufAAAkvEOIufAAAkvhCIufAAAkvmfIufAA");
	this.shape_2.setTransform(271.7253,74.2752);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_txt, new cjs.Rectangle(0,3.1,395.9,166.4), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.LeafB_sml();
	this.instance.setTransform(0.15,0.55,2,2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110.2,110.6), null);


(lib.leafA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA_sml();
	this.instance.setTransform(90.6,19.3,2.64,2.64);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA, new cjs.Rectangle(0,0,214.7,245.5), null);


(lib.Layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt = new cjs.Text("Budget", "5px 'Segoe Pro Semibold'", "#1C7347");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(39.3,248.65);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C7347").s().p("AiUAFIAAgIIEpAAIAAAIg");
	this.shape.setTransform(47.6,252.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.txt}]}).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#777777").s().p("AAAAFIgKgIIACgDIAIAJIAJgJIACADIgLAKg");
	this.shape_1.setTransform(445.4568,7.2001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C9C9C9").s().p("AgMAQQgEgBABgEIABgBIAGgIIAGgEIgJgGIAAgBQgDgCACgDQACgCADABIAIAKQAGgEAJgCIgNAJQAHAGAGAKQgFgFgLgJIgEAGIgEAHIAAABQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(50.8146,7.4594);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C9C9C9").s().p("AgNAVQAAAAgBgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIABABIABACIAAAAIACgCIACgDIAEgVIAAAAIgDAAIAAgBIAAgBIADAAIAAgBIABgDQACgEADgCIAFgDIADABIABACIgBACIgBAAIgCgBIgBgBIgBgBIgCABIgBAEIgBAFIgBABIAGAAIAAAAIgBACIgFAAIgEASQAAAEgCACIgEADIgEABg");
	this.shape_3.setTransform(74.0886,7.4251);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C9C9C9").s().p("AACAIIgCgBIAAgFIAAAAIgCAEIgCACIgDAAIgBgBQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAABAAIABAAIABAAIADgDIAAgBIABgBIgCgDIAAgBIgCgBIgBAAIgBAAIAAAAIABgBIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABABIABAFIAAAAIAAAAIACgDIACgCIACgBIACABIAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgDAEIAAAAIABAEIACACIABAAIACAAIAAABIgDABg");
	this.shape_4.setTransform(75.4618,8.0251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#C9C9C9").ss(0.5,1).p("AATgNQgSARgFAKQgBABgBgBIgMgM");
	this.shape_5.setTransform(63.0759,7.3251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAGAAIAAAFg");
	this.shape_6.setTransform(39.8006,8.7251);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAGAAIAAAGg");
	this.shape_7.setTransform(39.8006,7.4001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B3B3B3").s().p("AgDADIAAgGIAGAAIAAAGg");
	this.shape_8.setTransform(39.8006,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5F6060").s().p("AgNgGIAbAAIgOANg");
	this.shape_9.setTransform(31.3005,7.1001);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#C5C5C5").ss(0.3).p("AclAqMg5JAAAIAAhTMA5JAAAg");
	this.shape_10.setTransform(265.179,7.4251);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A8kAqIAAhTMA5JAAAIAABTg");
	this.shape_11.setTransform(265.179,7.4251);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C5C5C5").ss(0.3).p("ACzAqIllAAIAAhTIFlAAg");
	this.shape_12.setTransform(62.6509,7.4251);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiyAqIAAhTIFmAAIAABTg");
	this.shape_13.setTransform(62.6509,7.4251);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#C5C5C5").ss(0.3).p("ACnAqIlNAAIAAhTIFNAAg");
	this.shape_14.setTransform(18.0503,7.4251);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimAqIAAhTIFNAAIAABTg");
	this.shape_15.setTransform(18.0503,7.4251);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#787878").s().p("AgGAAIANgNIAAAbg");
	this.shape_16.setTransform(9.4,248.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#787878").s().p("AgGgNIANANIgNAOg");
	this.shape_17.setTransform(18.975,248.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#787878").s().p("AgCAOIAAgLIgLAAIAAgFIALAAIAAgLIAEAAIAAALIAMAAIAAAFIgMAAIAAALg");
	this.shape_18.setTransform(69.425,248.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#787878").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIgAgRgRQgHAIAAAJQAAAKAHAHQAIAIAJAAQAKAAAIgIQAHgHAAgKQAAgJgHgIQgIgHgKAAQgJAAgIAHg");
	this.shape_19.setTransform(69.425,248.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#999999").s().p("A9PSuIAAhUIlIAAIAAgDIBQAAIAAgNIhQAAIAAgDIBQAAIAAhVIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhOIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhCIADAAIAABCID2AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID0AAIAAhCIADAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIDyAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCIDzAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIB4AAMAAAAjEMg69AAAIAABUgEghEARXID3AAIAABUIElAAIAAhUMA6+AAAMAAAgi+MhDaAAAg");
	this.shape_20.setTransform(220.0284,133.1024);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B4B4B4").s().p("AgTAUIAngnIAAAng");
	this.shape_21.setTransform(5.125,16.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E6E6E6").s().p("EgjJAT0MAAAgnnMBGTAAAMAAAAnngEgh2ASYID2AAIAABUIEpAAIAAhUMA67AAAMAAAgjBMhDaAAAg");
	this.shape_22.setTransform(225,126.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Layout, new cjs.Rectangle(0,0,450,259.3), null);


(lib.image01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrightcontributionsml();
	this.instance.setTransform(-0.5,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel_icon_sml();
	this.instance.setTransform(16.5,28.85,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0,0,129.6,125.7), null);


(lib.hit = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.grass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Grass_sml();
	this.instance.setTransform(371.2,0.5,2.5,2.4999,0,0,180);

	this.instance_1 = new lib.Grass_sml();
	this.instance_1.setTransform(0.7,0.55,2.4999,2.4999);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass, new cjs.Rectangle(0,0,372.1,126), null);


(lib.graphGreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#459F69").s().p("AmYGZQiqipAAjwQAAjuCqiqQCpiqDvAAQDvAACqCqQCqCqAADuQAADwiqCpIAAABQiqCpjvAAQjvAAipiqgAmiAAQAACuB7B6QB6B7CtAAQCtAAB7h7QB7h6AAiuQAAish7h7Qh7h7itAAQitAAh6B7IAAAAQh7B7AACsg");
	this.shape.setTransform(57.875,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphGreen, new cjs.Rectangle(0,0,115.8,115.8), null);


(lib.firstimage_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(-1.05,-0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(-1,-0.9,84,53), null);


(lib.fill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girlrighticonsml();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.girllefticonsml();
	this.instance.setTransform(-0.15,-0.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(-0.1,-0.2,51.1,43.2), null);


(lib.face02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guylefticonsml();
	this.instance.setTransform(0.1,0.05);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52.1,41.1), null);


(lib.face01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.guyrighticon1sml();
	this.instance.setTransform(-0.05,-0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,-0.1,53,43.1), null);


(lib.excel_screen_white_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgjMASVMAAAgkpMBGZAAAMAAAAkpg");
	this.shape.setTransform(225.25,141.3);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white_sub, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AjQYuIAUgZIGvFlIgVAZg");
	var mask_graphics_69 = new cjs.Graphics().p("Am8YvIHppSIGwFlInpJSg");
	var mask_graphics_70 = new cjs.Graphics().p("Ap9YvINqwjIGwFlItqQjg");
	var mask_graphics_71 = new cjs.Graphics().p("AsXYwISe2YIGvFlIyeWYg");
	var mask_graphics_72 = new cjs.Graphics().p("AuQYwIWO65IGwFkI2Oa6g");
	var mask_graphics_73 = new cjs.Graphics().p("AvqYxIZC+TIGwFjI5DeVg");
	var mask_graphics_74 = new cjs.Graphics().p("AwrYxMAbEggvIGvFkMgbEAgwg");
	var mask_graphics_75 = new cjs.Graphics().p("AxXYxMAcbgiYIGwFlMgcbAiYg");
	var mask_graphics_76 = new cjs.Graphics().p("AxxYxMAdPgjXIGwFkMgdQAjYg");
	var mask_graphics_77 = new cjs.Graphics().p("Ax/YxMAdrgj4IGvFlMgdqAj4g");
	var mask_graphics_78 = new cjs.Graphics().p("AyEYxMAd1gkEIGvFlMgd0AkEg");
	var mask_graphics_79 = new cjs.Graphics().p("Ax+YqMAd2gkGIGvFlMgd2AkGg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:24.2809,y:193.8672}).wait(1).to({graphics:mask_graphics_69,x:47.6914,y:193.9525}).wait(1).to({graphics:mask_graphics_70,x:66.8675,y:194.0224}).wait(1).to({graphics:mask_graphics_71,x:82.2285,y:194.0783}).wait(1).to({graphics:mask_graphics_72,x:94.1953,y:194.1219}).wait(1).to({graphics:mask_graphics_73,x:103.1902,y:194.1546}).wait(1).to({graphics:mask_graphics_74,x:109.6365,y:194.178}).wait(1).to({graphics:mask_graphics_75,x:113.9582,y:194.1937}).wait(1).to({graphics:mask_graphics_76,x:116.5797,y:194.2033}).wait(1).to({graphics:mask_graphics_77,x:117.926,y:194.2082}).wait(1).to({graphics:mask_graphics_78,x:118.422,y:194.21}).wait(1).to({graphics:mask_graphics_79,x:119.1199,y:193.4922}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(88.9053,327.8823,0.7596,0.7254,0,-29.6754,-31.2356);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_68 = new cjs.Graphics().p("AjQYuIAUgZIGvFlIgVAZg");
	var mask_1_graphics_69 = new cjs.Graphics().p("Am8YvIHppSIGwFlInpJSg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Ap9YvINqwjIGwFlItqQjg");
	var mask_1_graphics_71 = new cjs.Graphics().p("AsXYwISe2YIGvFlIyeWYg");
	var mask_1_graphics_72 = new cjs.Graphics().p("AuQYwIWO65IGwFkI2Oa6g");
	var mask_1_graphics_73 = new cjs.Graphics().p("AvqYxIZC+TIGwFjI5DeVg");
	var mask_1_graphics_74 = new cjs.Graphics().p("AwrYxMAbEggvIGvFkMgbEAgwg");
	var mask_1_graphics_75 = new cjs.Graphics().p("AxXYxMAcbgiYIGwFlMgcbAiYg");
	var mask_1_graphics_76 = new cjs.Graphics().p("AxxYxMAdPgjXIGwFkMgdQAjYg");
	var mask_1_graphics_77 = new cjs.Graphics().p("Ax/YxMAdrgj4IGvFlMgdqAj4g");
	var mask_1_graphics_78 = new cjs.Graphics().p("AyEYxMAd1gkEIGvFlMgd0AkEg");
	var mask_1_graphics_79 = new cjs.Graphics().p("Ax+YqMAd2gkGIGvFlMgd2AkGg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_1_graphics_68,x:24.2809,y:193.8672}).wait(1).to({graphics:mask_1_graphics_69,x:47.6914,y:193.9525}).wait(1).to({graphics:mask_1_graphics_70,x:66.8675,y:194.0224}).wait(1).to({graphics:mask_1_graphics_71,x:82.2285,y:194.0783}).wait(1).to({graphics:mask_1_graphics_72,x:94.1953,y:194.1219}).wait(1).to({graphics:mask_1_graphics_73,x:103.1902,y:194.1546}).wait(1).to({graphics:mask_1_graphics_74,x:109.6365,y:194.178}).wait(1).to({graphics:mask_1_graphics_75,x:113.9582,y:194.1937}).wait(1).to({graphics:mask_1_graphics_76,x:116.5797,y:194.2033}).wait(1).to({graphics:mask_1_graphics_77,x:117.926,y:194.2082}).wait(1).to({graphics:mask_1_graphics_78,x:118.422,y:194.21}).wait(1).to({graphics:mask_1_graphics_79,x:119.1199,y:193.4922}).wait(1));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(124.7675,248.9843,0.7606,0.7264,0,-29.6759,-31.2354);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_54 = new cjs.Graphics().p("AMvPIIAygbIEEHwIgyAag");
	var mask_2_graphics_55 = new cjs.Graphics().p("AMsPIIA1gbIEEHvIg0Acg");
	var mask_2_graphics_56 = new cjs.Graphics().p("AMdPMIBEgjIEFHvIhEAkg");
	var mask_2_graphics_57 = new cjs.Graphics().p("AL0PXIBtg5IEFHvIhtA6g");
	var mask_2_graphics_58 = new cjs.Graphics().p("AKkPsIC9hjIEFHvIi9Bkg");
	var mask_2_graphics_59 = new cjs.Graphics().p("AIgQPIFBipIEFHwIlBCog");
	var mask_2_graphics_60 = new cjs.Graphics().p("AFbRCIIGkQIEFHwIoGEQg");
	var mask_2_graphics_61 = new cjs.Graphics().p("ABISLIMZmhIEFHvIsZGhg");
	var mask_2_graphics_62 = new cjs.Graphics().p("AkNTkIRupUIEFHwIxuJUg");
	var mask_2_graphics_63 = new cjs.Graphics().p("AofUtIWArlIEFHvI2BLlg");
	var mask_2_graphics_64 = new cjs.Graphics().p("ArkVgIZFtMIEFHvI5GNNg");
	var mask_2_graphics_65 = new cjs.Graphics().p("AtoWDIbJuSIEFHwI7KOSg");
	var mask_2_graphics_66 = new cjs.Graphics().p("Au5WYIcau8IEFHwI8aO8g");
	var mask_2_graphics_67 = new cjs.Graphics().p("AviWjIdDvSIEFHwI9DPSg");
	var mask_2_graphics_68 = new cjs.Graphics().p("AvxWnIdSvaIEFHwI9SPag");
	var mask_2_graphics_69 = new cjs.Graphics().p("Av2WqIdUvbIEFHvI9VPbg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_2_graphics_54,x:112.55,y:146.3209}).wait(1).to({graphics:mask_2_graphics_55,x:112.5501,y:146.3778}).wait(1).to({graphics:mask_2_graphics_56,x:112.5506,y:146.7758}).wait(1).to({graphics:mask_2_graphics_57,x:112.5518,y:147.8561}).wait(1).to({graphics:mask_2_graphics_58,x:112.5543,y:149.9599}).wait(1).to({graphics:mask_2_graphics_59,x:112.5583,y:153.4287}).wait(1).to({graphics:mask_2_graphics_60,x:112.5644,y:158.6041}).wait(1).to({graphics:mask_2_graphics_61,x:112.5728,y:165.8284}).wait(1).to({graphics:mask_2_graphics_62,x:112.5832,y:174.8043}).wait(1).to({graphics:mask_2_graphics_63,x:112.5916,y:182.0325}).wait(1).to({graphics:mask_2_graphics_64,x:112.5977,y:187.2128}).wait(1).to({graphics:mask_2_graphics_65,x:112.6017,y:190.6858}).wait(1).to({graphics:mask_2_graphics_66,x:112.6042,y:192.7926}).wait(1).to({graphics:mask_2_graphics_67,x:112.6054,y:193.8745}).wait(1).to({graphics:mask_2_graphics_68,x:112.6059,y:194.2731}).wait(1).to({graphics:mask_2_graphics_69,x:112.275,y:194.532}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(146.4675,300.3025,0.7432,0.7432,-28.9415);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(54).to({_off:false},0).wait(26));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_54 = new cjs.Graphics().p("AMvPIIAygbIEEHwIgyAag");
	var mask_3_graphics_55 = new cjs.Graphics().p("AMsPIIA1gbIEEHvIg0Acg");
	var mask_3_graphics_56 = new cjs.Graphics().p("AMdPMIBEgjIEFHvIhEAkg");
	var mask_3_graphics_57 = new cjs.Graphics().p("AL0PXIBtg5IEFHvIhtA6g");
	var mask_3_graphics_58 = new cjs.Graphics().p("AKkPsIC9hjIEFHvIi9Bkg");
	var mask_3_graphics_59 = new cjs.Graphics().p("AIgQPIFBipIEFHwIlBCog");
	var mask_3_graphics_60 = new cjs.Graphics().p("AFbRCIIGkQIEFHwIoGEQg");
	var mask_3_graphics_61 = new cjs.Graphics().p("ABISLIMZmhIEFHvIsZGhg");
	var mask_3_graphics_62 = new cjs.Graphics().p("AkNTkIRupUIEFHwIxuJUg");
	var mask_3_graphics_63 = new cjs.Graphics().p("AofUtIWArlIEFHvI2BLlg");
	var mask_3_graphics_64 = new cjs.Graphics().p("ArkVgIZFtMIEFHvI5GNNg");
	var mask_3_graphics_65 = new cjs.Graphics().p("AtoWDIbJuSIEFHwI7KOSg");
	var mask_3_graphics_66 = new cjs.Graphics().p("Au5WYIcau8IEFHwI8aO8g");
	var mask_3_graphics_67 = new cjs.Graphics().p("AviWjIdDvSIEFHwI9DPSg");
	var mask_3_graphics_68 = new cjs.Graphics().p("AvxWnIdSvaIEFHwI9SPag");
	var mask_3_graphics_69 = new cjs.Graphics().p("Av2WqIdUvbIEFHvI9VPbg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(54).to({graphics:mask_3_graphics_54,x:112.55,y:146.3209}).wait(1).to({graphics:mask_3_graphics_55,x:112.5501,y:146.3778}).wait(1).to({graphics:mask_3_graphics_56,x:112.5506,y:146.7758}).wait(1).to({graphics:mask_3_graphics_57,x:112.5518,y:147.8561}).wait(1).to({graphics:mask_3_graphics_58,x:112.5543,y:149.9599}).wait(1).to({graphics:mask_3_graphics_59,x:112.5583,y:153.4287}).wait(1).to({graphics:mask_3_graphics_60,x:112.5644,y:158.6041}).wait(1).to({graphics:mask_3_graphics_61,x:112.5728,y:165.8284}).wait(1).to({graphics:mask_3_graphics_62,x:112.5832,y:174.8043}).wait(1).to({graphics:mask_3_graphics_63,x:112.5916,y:182.0325}).wait(1).to({graphics:mask_3_graphics_64,x:112.5977,y:187.2128}).wait(1).to({graphics:mask_3_graphics_65,x:112.6017,y:190.6858}).wait(1).to({graphics:mask_3_graphics_66,x:112.6042,y:192.7926}).wait(1).to({graphics:mask_3_graphics_67,x:112.6054,y:193.8745}).wait(1).to({graphics:mask_3_graphics_68,x:112.6059,y:194.2731}).wait(1).to({graphics:mask_3_graphics_69,x:112.275,y:194.532}).wait(11));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(117.4926,316.3249,0.7432,0.7432,-28.9415);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(54).to({_off:false},0).wait(26));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_29 = new cjs.Graphics().p("EgDtAkCIAug3IGtFoIguA3g");
	var mask_4_graphics_30 = new cjs.Graphics().p("EgFhAkCIEXlMIGsFnIkXFNg");
	var mask_4_graphics_31 = new cjs.Graphics().p("EgHMAkCIHspMIGtFnInsJMg");
	var mask_4_graphics_32 = new cjs.Graphics().p("EgIvAkCIKxs4IGuFoIqxM3g");
	var mask_4_graphics_33 = new cjs.Graphics().p("EgKJAkCINmwQIGtFoItmQPg");
	var mask_4_graphics_34 = new cjs.Graphics().p("EgLcAkCIQLzVIGuFoIwLTUg");
	var mask_4_graphics_35 = new cjs.Graphics().p("EgMnAkBISi2HIGtFoIyiWHg");
	var mask_4_graphics_36 = new cjs.Graphics().p("EgNrAkBIUq4pIGtFoI0qYpg");
	var mask_4_graphics_37 = new cjs.Graphics().p("EgOoAkBIWk67IGtFoI2ka7g");
	var mask_4_graphics_38 = new cjs.Graphics().p("EgPfAkBIYR8+IGuFoI4Rc+g");
	var mask_4_graphics_39 = new cjs.Graphics().p("EgQPAkBIZy+yIGtFoI5yeyg");
	var mask_4_graphics_40 = new cjs.Graphics().p("EgQ6AkBMAbIggYIGtFnMgbIAgZg");
	var mask_4_graphics_41 = new cjs.Graphics().p("EgRgAkBMAcUghyIGtFoMgcUAhyg");
	var mask_4_graphics_42 = new cjs.Graphics().p("EgSAAkBMAdUgjAIGtFoMgdUAjAg");
	var mask_4_graphics_43 = new cjs.Graphics().p("EgScAkBMAeMgkBIGtFmMgeMAkDg");
	var mask_4_graphics_44 = new cjs.Graphics().p("EgS0AkBMAe8gk6IGtFnMge8Ak7g");
	var mask_4_graphics_45 = new cjs.Graphics().p("EgTIAkBMAfjglpIGuFnMgfjAlqg");
	var mask_4_graphics_46 = new cjs.Graphics().p("EgTYAkBMAgEgmPIGtFmMggEAmRg");
	var mask_4_graphics_47 = new cjs.Graphics().p("EgTlAkBMAgegmuIGtFnMggeAmvg");
	var mask_4_graphics_48 = new cjs.Graphics().p("EgTvAkBMAgygnGIGtFnMggyAnHg");
	var mask_4_graphics_49 = new cjs.Graphics().p("EgT2AkBMAhAgnYIGtFnMghAAnZg");
	var mask_4_graphics_50 = new cjs.Graphics().p("EgT8AkBMAhMgnlIGtFnMghMAnmg");
	var mask_4_graphics_51 = new cjs.Graphics().p("EgT/AkBMAhSgnuIGtFnMghSAnvg");
	var mask_4_graphics_52 = new cjs.Graphics().p("EgUCAkBMAhXgnzIGuFnMghXAn0g");
	var mask_4_graphics_53 = new cjs.Graphics().p("EgUDAkBMAhagn2IGtFnMghaAn3g");
	var mask_4_graphics_54 = new cjs.Graphics().p("EgUDAkBMAhagn3IGtFnMghaAn4g");
	var mask_4_graphics_55 = new cjs.Graphics().p("EgUDAj9MAhagn3IGtFnMghaAn4g");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_4_graphics_29,x:-9.4397,y:266.5616}).wait(1).to({graphics:mask_4_graphics_30,x:2.1889,y:266.553}).wait(1).to({graphics:mask_4_graphics_31,x:12.9242,y:266.5449}).wait(1).to({graphics:mask_4_graphics_32,x:22.8018,y:266.5375}).wait(1).to({graphics:mask_4_graphics_33,x:31.8573,y:266.5308}).wait(1).to({graphics:mask_4_graphics_34,x:40.1264,y:266.5246}).wait(1).to({graphics:mask_4_graphics_35,x:47.6446,y:266.519}).wait(1).to({graphics:mask_4_graphics_36,x:54.4477,y:266.5139}).wait(1).to({graphics:mask_4_graphics_37,x:60.5713,y:266.5093}).wait(1).to({graphics:mask_4_graphics_38,x:66.0512,y:266.5052}).wait(1).to({graphics:mask_4_graphics_39,x:70.923,y:266.5016}).wait(1).to({graphics:mask_4_graphics_40,x:75.2224,y:266.4983}).wait(1).to({graphics:mask_4_graphics_41,x:78.9853,y:266.4955}).wait(1).to({graphics:mask_4_graphics_42,x:82.2474,y:266.4931}).wait(1).to({graphics:mask_4_graphics_43,x:85.0443,y:266.491}).wait(1).to({graphics:mask_4_graphics_44,x:87.4119,y:266.4892}).wait(1).to({graphics:mask_4_graphics_45,x:89.3859,y:266.4878}).wait(1).to({graphics:mask_4_graphics_46,x:91.0021,y:266.4866}).wait(1).to({graphics:mask_4_graphics_47,x:92.2963,y:266.4856}).wait(1).to({graphics:mask_4_graphics_48,x:93.3042,y:266.4848}).wait(1).to({graphics:mask_4_graphics_49,x:94.0616,y:266.4843}).wait(1).to({graphics:mask_4_graphics_50,x:94.6044,y:266.4839}).wait(1).to({graphics:mask_4_graphics_51,x:94.9682,y:266.4836}).wait(1).to({graphics:mask_4_graphics_52,x:95.1888,y:266.4834}).wait(1).to({graphics:mask_4_graphics_53,x:95.3021,y:266.4833}).wait(1).to({graphics:mask_4_graphics_54,x:95.3439,y:266.4833}).wait(1).to({graphics:mask_4_graphics_55,x:96.0156,y:266.0866}).wait(25));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,0,0,0.008)").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape_4.setTransform(98,306);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_5.setTransform(80.1549,412.7901,0.7432,0.7432,-28.9415);

	var maskedShapeInstanceList = [this.shape_4,this.shape_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4}]}).to({state:[{t:this.shape_5}]},29).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63,6,300.8,600);


(lib.Icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.PPT_icon_sml();
	this.instance.setTransform(-7.75,-6.45,0.82,0.82);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon, new cjs.Rectangle(-7.7,-6.4,168.79999999999998,128), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Render0116();
	this.instance.setTransform(-2.6,17.85);

	this.instance_1 = new lib.Render0115sml();
	this.instance_1.setTransform(14.8,46.2,2,2);

	this.instance_2 = new lib.Render0114sml();
	this.instance_2.setTransform(14.65,45.45,2,2);

	this.instance_3 = new lib.Render0113sml();
	this.instance_3.setTransform(15.05,43.7,2,2);

	this.instance_4 = new lib.Render0112sml();
	this.instance_4.setTransform(15,40.15,2,2);

	this.instance_5 = new lib.Render0111sml();
	this.instance_5.setTransform(15.65,38.25,2,2);

	this.instance_6 = new lib.Render0110sml();
	this.instance_6.setTransform(15.9,34.3,2,2);

	this.instance_7 = new lib.Render0109sml();
	this.instance_7.setTransform(17.2,26.35,2,2);

	this.instance_8 = new lib.Render0108();
	this.instance_8.setTransform(-2.6,17.85);

	this.instance_9 = new lib.Render0117();
	this.instance_9.setTransform(-2.6,17.85);

	this.instance_10 = new lib.Render0118();
	this.instance_10.setTransform(-2.6,17.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance_2}]},3).to({state:[{t:this.instance_3}]},3).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_7}]},7).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_1}]},3).to({state:[{t:this.instance}]},3).to({state:[{t:this.instance_9}]},4).to({state:[{t:this.instance_10}]},3).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-2.6,17.9,100,151);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.circleSegment = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkgEMQAHjiCiihQCoipDwgBIAAJCg");
	mask.setTransform(28.925,28.95);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#36724B").ss(16,1,1).p("AHzAAQAADPiSCSQiTCSjOAAQjOAAiSiSQiSiSAAjPQAAjNCSiSQCSiTDOAAQDOAACTCTQCSCSAADNg");
	this.shape.setTransform(57.8259,57.8759);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circleSegment, new cjs.Rectangle(0,0,57.9,57.9), null);


(lib.circle_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(0,0,0,0.498)","rgba(0,0,0,0.247)","rgba(0,0,0,0.039)","rgba(0,0,0,0)"],[0.239,0.502,0.769,1],-0.1,-0.1,0,-0.1,-0.1,54.1).s().p("Al8F7QicidAAjeQAAjeCcieQCeicDeAAQDeAACdCcQCeCeAADeQAADeieCdQidCejeAAQjeAAieieg");
	this.shape.setTransform(128.5,128.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#000000","rgba(0,0,0,0.322)","rgba(0,0,0,0.047)","rgba(0,0,0,0)"],[0.769,0.875,0.945,0.976],0,0,0,0,0,130.4).s().p("AuMONQl4l5AAoUQAAoUF4l4QF4l4IUAAQIVAAF3F4QF5F4AAIUQAAIUl5F5Ql3F4oVAAQoUAAl4l4gAq4q4QkgEhAAGXQAAGYEgEhQEhEgGXAAQGYAAEgkgQEgkhABmYQgBmXkgkhQkgkgmYAAQmXAAkhEgg");
	this.shape_1.setTransform(128.5,128.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,0,0,0)","rgba(0,0,0,0.039)","rgba(0,0,0,0.247)","#000000"],[0.655,0.718,0.808,1],0,0,0,0,0,80.1).s().p("AoyIyQjojpAAlJQAAlJDojpQDpjoFJAAQFJAADpDoQDpDpAAFJQAAFJjpDpQjpDplJAAQlJAAjpjpg");
	this.shape_2.setTransform(128.45,128.45);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("Aq4K5QkgkhAAmYQAAmXEgkhQEhkgGXAAQGYAAEgEgQEhEhAAGXQAAGYkhEhQkgEgmYAAQmXAAkhkggAoyoyQjoDpAAFJQAAFJDoDpQDpDpFJAAQFJAADpjpQDpjpAAlJQAAlJjpjpQjpjolJAAQlJAAjpDog");
	this.shape_3.setTransform(128.45,128.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circle_shadow, new cjs.Rectangle(0,0,257,257), null);


(lib.chart_mask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApOJ2IAAzrIScAAIAATrg");
	this.shape.setTransform(59.05,62.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_mask, new cjs.Rectangle(0,0,118.1,125.9), null);


(lib.btn_frame = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(0.5,1,1).p("AyvifMAlfAAAIAAE/MglfAAAg");
	this.shape.setTransform(120,16);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.8)").s().p("AyvCgIAAk/MAlfAAAIAAE/g");
	this.shape_1.setTransform(120,16);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.btn_frame, new cjs.Rectangle(-1,-1,242,34), null);


(lib.boxshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bottom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt3 = new cjs.Text("100%", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 31;
	this.txt3.parent = this;
	this.txt3.setTransform(438.2,5.15);

	this.txt2 = new cjs.Text("Display Settings", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.lineWidth = 31;
	this.txt2.parent = this;
	this.txt2.setTransform(321.85,4.9);

	this.txt1 = new cjs.Text("Ready", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.lineWidth = 14;
	this.txt1.parent = this;
	this.txt1.setTransform(2.3,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4F4F4F").s().p("AgBAMIAAgKIgKAAIAAgDIAKAAIAAgKIADAAIAAAKIAKAAIAAADIgKAAIAAAKg");
	this.shape.setTransform(433.2,3.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#757575").s().p("AgEAUIAAgQIifAAIAAgDICfAAIAAgUIAPAAIAAAUICZAAIAAADIiZAAIAAAQg");
	this.shape_1.setTransform(414.3,3.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4F4F4F").s().p("AgKAEIAAgHIAVAAIAAAHg");
	this.shape_2.setTransform(395.675,3.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgSATIAlAAIAAglIgLAAIAAAVIgaAAgAgEAAIAKAAIAAgSIgKAAgAgSAAIALAAIAAgSIgLAAg");
	this.shape_3.setTransform(386.7,3.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_4.setTransform(374.175,4.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_5.setTransform(374.175,3.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_6.setTransform(374.175,2.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4F4F4F").s().p("AgLARIAAghIAXAAIAAAhgAgJAOIASAAIAAgbIgSAAg");
	this.shape_7.setTransform(374.2,3.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgTATIAmAAIAAglIgmAAg");
	this.shape_8.setTransform(374.2,3.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAAJATIAKAAIAAgKIgKAAgAgEATIAKAAIAAgKIgKAAgAgSATIAMAAIAAgKIgMAAgAAJAGIAKAAIAAgKIgKAAgAgEAGIAKAAIAAgKIgKAAgAgSAGIAMAAIAAgKIgMAAgAAJgGIAKAAIAAgMIgKAAgAgEgGIAKAAIAAgMIgKAAgAgSgGIAMAAIAAgMIgMAAg");
	this.shape_9.setTransform(361.525,3.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4F4F4F").s().p("AgPAXIAAgEIALAAIAAgJIgSAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIAtAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIAAAaQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgBAAIgBgDIAAgBQAAAAABgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgCgBQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAABIgBABIgCAAIgBgBQAAgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAIgCAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAABIAAABIgBACIgBABIgBAAIgCABIgBAAIAAAJIAFAAIAAAEg");
	this.shape_10.setTransform(318.725,3.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4F4F4F").s().p("AAEALIgCgCQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAIgCACIgBAAIgCgBIAAgBIABgCQgCgCgBgDIgCAAIgBgBIAAgBIABAAIACgBIABgCIACgDIAAgCQgBgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIABAAIABACIAEAAIABgCIABAAIACABIAAABIgBACQACACABADIADABIAAAAIAAABIAAABIgDAAIgBACIgCAEIABACIgBABIgBAAgAgFgCQgEAFAHAEQAFADAEgGQADgGgGgEIgEgBQgDAAgCAFg");
	this.shape_11.setTransform(320.075,4.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F3F1F0").s().p("EgjPAAwIAAhfMBGfAAAIAABfg");
	this.shape_12.setTransform(225.575,4.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottom, new cjs.Rectangle(0,0,471.4,13.6), null);


(lib.big_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.chart_big_msml();
	this.instance.setTransform(136,152,1.33,1.33);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_pie, new cjs.Rectangle(-0.2,0,420.2,420), null);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384549").s().p("A4MPeIAA7rIgBgWIgEgUIATgFQAUgFADABQARAFAQAAQAIAAAOgFQAPgFAJAAQALAAAGAGIAHAIIBSAoIAdACQADgGAHgEQAEgCAdgBIAcgBIARAKIALgGIAiAGIANgSIARAAIAOAKIBKgCIAKAHIBCgDIAJgHIAWACIAKgEIAfAAIAJgGQALgGAIAAQAOAAANAOIAigBIAJgHIAJADIAYAUIATAAIATAOIAWAAIAVAQIABANIANAAIADAOIAVAXIAOACIAAAKIASAIIABAIIALAAIAGAJIANABIgBALIAKAAIAOAKIABAJIAWAJIAXgUIALgFIAAgIIAjgMIADgJIAUgBIAVATIALAAIAeAcIANgJIATANQASgBADgBIANgLIAHAIIAJgGIALABIAJgEIARgDIALAKIAFgLIARgBIAHgCIAJADIAbAEIAJAIIAKgGIAKABIAGgRIASgQIAUgEQAEgBATADIA7AAIALgCIAMAGIANAAIAMgIIAQAKIAWAXIATABIAbAXIAMgCIAUAUIARACQAEAAAGAEIAHAHIAIANIAfALIAHAAIAEAHIA3AAIAGgGIAJAEIAeAAIAigoIAIAAIgCgJIAIgJIADgKQAQgJABgEQABgDAEgFIAGgEIAIgDIAAgSQAKACAAgDIgDgRIAIgBIAEgNIALgNQAOgOADgCQAEgCAPgCIATgNIAKABIAFgNIASAAIAAgQIAPgFIAHgKIAGgDQAFgEAEAAIAlADIAKACIAGAHIAdgdIABgOIAMAAIAZgNIAdgHIACgKIAIACIAEgJIALAAIABgJIATgLIACgMIANgCIANgLIABgJIAfgWIAQgGIAFAKIAQABIAXAPIASgUIAMgBIAGgHIAOAAIAOgMIANAAIAHAFIAhAAIAVAJIATgJIAgAAQApgDAOADQAOAEAQAKIAmABIAOgIIAQAGIACAHIBWABQAEAAAPgIQAPgHABAAQAEACAigBIAFgIIAJgCIAGAGIAWgLIAngBIAmgJIAOgHIAxAaIgITYIAALJg");
	this.shape.setTransform(155.4,98.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(0,0,310.8,198), null);


(lib.Background_img = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.instance = new lib.Bg_img_300x600_smlpngcopy();
	this.instance.setTransform(1.05,-31);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Background_img, new cjs.Rectangle(0,-31,301.1,306), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAKBIIA5g1IjHAAIAAgkIDHAAIg5g2IAuAAIBNBHIhMBIg");
	this.shape.setTransform(3.5846,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(-4.1,0,15.4,8.4), null);


(lib.WordUI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(-0.3,0.1,302,192), null);


(lib.tablet_shadow_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tablet_shadow.cache(-500,-500,2000,2000,.25)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.tablet_shadow = new lib.tablet_shadow_sub();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(64.3,47.1,1,1,0,0,0,64.3,47.1);

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tablet_shadow_vector, new cjs.Rectangle(-13.7,-22.4,142.29999999999998,116.69999999999999), null);


(lib.squareshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.tablet_shadow = new lib.tablet_shadow_vector();
	this.tablet_shadow.name = "tablet_shadow";
	this.tablet_shadow.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.roundshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0.3,56,45), null);


(lib.Ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_49 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(49).call(this.frame_49).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_26 = new cjs.Graphics().p("AgeBtIAhgMIgDGSIgiAMg");
	var mask_graphics_27 = new cjs.Graphics().p("AgeBtIAkgOIgEGTIgkANg");
	var mask_graphics_28 = new cjs.Graphics().p("AgeBtIA+gXIgEGSIg+AXg");
	var mask_graphics_29 = new cjs.Graphics().p("Ag/BtICDgwIgEGSIiDAwg");
	var mask_graphics_30 = new cjs.Graphics().p("AiCBtIEJhgIgEGSIkJBgg");
	var mask_graphics_31 = new cjs.Graphics().p("AjwBtIHliwIgEGSInlCwg");
	var mask_graphics_32 = new cjs.Graphics().p("AmVBtIMvknIgEGRIsvEpg");
	var mask_graphics_33 = new cjs.Graphics().p("Ap8BuIT9nQIgEGSIz9HQg");
	var mask_graphics_34 = new cjs.Graphics().p("AuaCHIc4qfIgDGSI84Kfg");
	var mask_graphics_35 = new cjs.Graphics().p("AyADbMAkFgNHIgEGSMgkFANHg");
	var mask_graphics_36 = new cjs.Graphics().p("A0lEXMApPgO/IgEGSMgpPAO/g");
	var mask_graphics_37 = new cjs.Graphics().p("A2TE/MAsrgQPIgEGSMgsrAQPg");
	var mask_graphics_38 = new cjs.Graphics().p("A3WFYMAuxgRBIgEGSMguxARBg");
	var mask_graphics_39 = new cjs.Graphics().p("A35FkMAv3gRZIgEGSMgv3ARZg");
	var mask_graphics_40 = new cjs.Graphics().p("A4FFpMAwPgRjIgEGSMgwPARjg");
	var mask_graphics_41 = new cjs.Graphics().p("A4HFqMAwTgRlIgEGSMgwTARlg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_graphics_26,x:-3.4728,y:51.1083}).wait(1).to({graphics:mask_graphics_27,x:-3.4734,y:51.1088}).wait(1).to({graphics:mask_graphics_28,x:-3.4772,y:51.1102}).wait(1).to({graphics:mask_graphics_29,x:-0.2031,y:51.114}).wait(1).to({graphics:mask_graphics_30,x:6.4642,y:51.1213}).wait(1).to({graphics:mask_graphics_31,x:17.4557,y:51.1334}).wait(1).to({graphics:mask_graphics_32,x:33.852,y:51.1515}).wait(1).to({graphics:mask_graphics_33,x:56.7329,y:51.1766}).wait(1).to({graphics:mask_graphics_34,x:85.1511,y:48.6941}).wait(1).to({graphics:mask_graphics_35,x:108.0275,y:40.3603}).wait(1).to({graphics:mask_graphics_36,x:124.4179,y:34.3853}).wait(1).to({graphics:mask_graphics_37,x:135.4043,y:30.3784}).wait(1).to({graphics:mask_graphics_38,x:142.068,y:27.9474}).wait(1).to({graphics:mask_graphics_39,x:145.4898,y:26.6988}).wait(1).to({graphics:mask_graphics_40,x:146.7504,y:26.2388}).wait(1).to({graphics:mask_graphics_41,x:148.81,y:25.4891}).wait(9));

	// Layer_5 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AjuipIHeCnIneCtg");
	this.shape.setTransform(23.1,82.9);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(26).to({_off:false},0).wait(24));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("EgiLAJiMBEXgYaIAAFNMhEXAYjg");
	this.shape_1.setTransform(217.775,4.75);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(26).to({_off:false},0).wait(24));

	// Layer_8 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A3vnTIAwgRIAAgBMAuvgQ5IAAfzMgvfARKg");
	mask_1.setTransform(148.025,141.15);

	// Layer_9
	this.bg_img = new lib.Background_img();
	this.bg_img.name = "bg_img";
	this.bg_img.setTransform(155.5,255.3,1,1,0,0,0,155.5,233.3);
	this.bg_img.alpha = 0;
	this.bg_img._off = true;

	var maskedShapeInstanceList = [this.bg_img];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.bg_img).wait(25).to({_off:false},0).to({alpha:1},19).wait(6));

	// Layer_6 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_12 = new cjs.Graphics().p("AWcQsIAXm8ICIAyIgXG8g");
	var mask_2_graphics_13 = new cjs.Graphics().p("AOFNqIAWm8IKVDzIgXG8g");
	var mask_2_graphics_14 = new cjs.Graphics().p("AGwLAIAXm7IRfGbIgXG7g");
	var mask_2_graphics_15 = new cjs.Graphics().p("AAaItIAXm8IXtIuIgXG7g");
	var mask_2_graphics_16 = new cjs.Graphics().p("AlBGvIAWm7IdCKqIgXG8g");
	var mask_2_graphics_17 = new cjs.Graphics().p("ApoFEIAXm7MAhiAMUIgXG8g");
	var mask_2_graphics_18 = new cjs.Graphics().p("AteDrIAXm7MAlTANsIgXG8g");
	var mask_2_graphics_19 = new cjs.Graphics().p("AwnCiIAXm7MAoYAO1IgXG8g");
	var mask_2_graphics_20 = new cjs.Graphics().p("AzIBnIAWm6MAq2APuIgWG8g");
	var mask_2_graphics_21 = new cjs.Graphics().p("A1GA6IAXm7MAsxAQcIgXG8g");
	var mask_2_graphics_22 = new cjs.Graphics().p("A2kAYIAXm7MAuNAQ+IgXG8g");
	var mask_2_graphics_23 = new cjs.Graphics().p("A3oAAIAXm8MAvQARXIgXG7g");
	var mask_2_graphics_24 = new cjs.Graphics().p("A4JgQIAXm8MAv8ARnIgXG7g");
	var mask_2_graphics_25 = new cjs.Graphics().p("A4WgaIAWm8MAwXARwIgWG8g");
	var mask_2_graphics_26 = new cjs.Graphics().p("A4dgfIAXm8MAwkAR1IgXG8g");
	var mask_2_graphics_27 = new cjs.Graphics().p("A4gghIAXm8MAwqAR3IgXG8g");
	var mask_2_graphics_28 = new cjs.Graphics().p("A4ggiIAXm7MAwqAR3IgXG8g");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(12).to({graphics:mask_2_graphics_12,x:159.4615,y:111.8}).wait(1).to({graphics:mask_2_graphics_13,x:158.3723,y:111.6636}).wait(1).to({graphics:mask_2_graphics_14,x:157.4192,y:111.5441}).wait(1).to({graphics:mask_2_graphics_15,x:156.5929,y:111.4404}).wait(1).to({graphics:mask_2_graphics_16,x:155.8845,y:111.3514}).wait(1).to({graphics:mask_2_graphics_17,x:155.2849,y:111.2761}).wait(1).to({graphics:mask_2_graphics_18,x:154.7849,y:111.2133}).wait(1).to({graphics:mask_2_graphics_19,x:154.3756,y:111.1618}).wait(1).to({graphics:mask_2_graphics_20,x:154.0478,y:111.1206}).wait(1).to({graphics:mask_2_graphics_21,x:153.7926,y:111.0885}).wait(1).to({graphics:mask_2_graphics_22,x:153.6007,y:111.0644}).wait(1).to({graphics:mask_2_graphics_23,x:153.4633,y:111.0471}).wait(1).to({graphics:mask_2_graphics_24,x:152.1624,y:111.0355}).wait(1).to({graphics:mask_2_graphics_25,x:150.705,y:111.0285}).wait(1).to({graphics:mask_2_graphics_26,x:149.9565,y:111.0249}).wait(1).to({graphics:mask_2_graphics_27,x:149.6808,y:111.0235}).wait(1).to({graphics:mask_2_graphics_28,x:149.5186,y:111}).wait(22));

	// Layer_5 copy
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("Aj7gEIH4i2IgDF1g");
	this.shape_2.setTransform(280.7543,198.9536);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(12).to({_off:false},0).wait(38));

	// Layer_5
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A4RmHIgJlyMAwwASBIAFFyg");
	this.shape_3.setTransform(140.65,178.25,1,1,0,0,0,-9.1,37.5);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(12).to({_off:false},0).wait(38));

	// Layer_2 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("AhHUbIBPgeIgEGSIhPAeg");
	var mask_3_graphics_1 = new cjs.Graphics().p("AhHUbIBTgfIgEGSIhTAfg");
	var mask_3_graphics_2 = new cjs.Graphics().p("AhHUbIBtgoIgEGSIhtAog");
	var mask_3_graphics_3 = new cjs.Graphics().p("AhWUaICxhBIgEGTIixBAg");
	var mask_3_graphics_4 = new cjs.Graphics().p("AiZUaIE3hyIgEGSIk3Byg");
	var mask_3_graphics_5 = new cjs.Graphics().p("AkIUZIIVjCIgEGSIoVDCg");
	var mask_3_graphics_6 = new cjs.Graphics().p("AmsUYINdk6IgEGSItdE6g");
	var mask_3_graphics_7 = new cjs.Graphics().p("AqSUWIUpnhIgEGSI0pHhg");
	var mask_3_graphics_8 = new cjs.Graphics().p("AuwUUIdkqxIgEGSI9jKxg");
	var mask_3_graphics_9 = new cjs.Graphics().p("AyVUSMAkvgNYIgEGSMgkvANYg");
	var mask_3_graphics_10 = new cjs.Graphics().p("A06URMAp5gPQIgEGSMgp5APQg");
	var mask_3_graphics_11 = new cjs.Graphics().p("A2oUQMAtVgQgIgEGSMgtVAQgg");
	var mask_3_graphics_12 = new cjs.Graphics().p("A3rUQMAvbgRRIgEGSMgvbARRg");
	var mask_3_graphics_13 = new cjs.Graphics().p("A4OUPMAwhgRqIgEGSMgwhARrg");
	var mask_3_graphics_14 = new cjs.Graphics().p("A4aUPMAw5gRzIgEGSMgw5ARzg");
	var mask_3_graphics_15 = new cjs.Graphics().p("A4cUPMAw9gR0IgEGSMgw9AR1g");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:-7.6228,y:170.8833}).wait(1).to({graphics:mask_3_graphics_1,x:-7.6184,y:170.8823}).wait(1).to({graphics:mask_3_graphics_2,x:-7.5871,y:170.8728}).wait(1).to({graphics:mask_3_graphics_3,x:-5.8845,y:170.8471}).wait(1).to({graphics:mask_3_graphics_4,x:1.1415,y:170.7971}).wait(1).to({graphics:mask_3_graphics_5,x:12.7248,y:170.7147}).wait(1).to({graphics:mask_3_graphics_6,x:30.0044,y:170.5917}).wait(1).to({graphics:mask_3_graphics_7,x:54.1194,y:170.4201}).wait(1).to({graphics:mask_3_graphics_8,x:84.0722,y:170.2069}).wait(1).to({graphics:mask_3_graphics_9,x:108.1856,y:170.0352}).wait(1).to({graphics:mask_3_graphics_10,x:125.4632,y:169.9122}).wait(1).to({graphics:mask_3_graphics_11,x:137.0447,y:169.8297}).wait(1).to({graphics:mask_3_graphics_12,x:144.0695,y:169.7797}).wait(1).to({graphics:mask_3_graphics_13,x:147.6768,y:169.754}).wait(1).to({graphics:mask_3_graphics_14,x:149.0058,y:169.7446}).wait(1).to({graphics:mask_3_graphics_15,x:149.1099,y:169.7583}).wait(35));

	// Layer_1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("A4QF3MAwhgRrIAAF3MgwhARyg");
	this.shape_4.setTransform(151.7773,260.6294);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(50));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.5,-50.9,344.2,387.2);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.option_btn_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#505050").ss(1,2,0,3).p("Ag2AfIA3g8IA3A8");
	this.shape.setTransform(220.3499,14.0817);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#505050").ss(1,2,0,3).p("AA3geIg3A8Ig2g8");
	this.shape_1.setTransform(220.2786,17.9195);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,240.5,32.5);


(lib.option_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// Layer_1
	this.btn_frame = new lib.btn_frame();
	this.btn_frame.name = "btn_frame";
	this.btn_frame.setTransform(134.4,14.3,1,1,0,0,0,134.4,14.3);

	this.timeline.addTween(cjs.Tween.get(this.btn_frame).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-0.2,240.5,32.5);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:3.6,x:-0.1},0).wait(1).to({x:-1},0).wait(1).to({x:-2.1},0).wait(1).to({x:-2.8},0).wait(1).to({regX:5.6,x:-1.05},0).wait(1).to({regX:3.6,x:-2.95},0).wait(1).to({x:-2.6},0).wait(1).to({x:-2.15},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.5},0).wait(1).to({regX:5.6,x:0.55},0).wait(1).to({regX:3.6,x:-1.45},0).wait(1).to({x:-1.6},0).wait(1).to({x:-1.75},0).wait(1).to({x:-1.9},0).wait(1).to({x:-2},0).wait(1).to({regX:5.6,x:-0.05},0).wait(1).to({regX:3.6,x:-2},0).wait(1).to({x:-1.95},0).wait(1).to({x:-1.9},0).wait(1).to({x:-1.85},0).wait(1).to({regX:5.6,x:0.15},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(1).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(35));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mountain_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.ribbon = new lib.Ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(218.8,236.65,1,1,0,0,0,218.8,92.8);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(-15.2,-139,322.3,624.6), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.TL_MainScreen.tweenFromTo("frame0", "frame1");
		//exportRoot.TL_Clouds.tweenFromTo("frame0", "frame1");
	}
	this.frame_89 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(30).call(this.frame_89).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,901.15,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(63));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSYBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgSrBKjIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgTlBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVEBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXJBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZ1BKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdHBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1BKjIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:477.1095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:477.1095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:477.1095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:477.1095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:477.1095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:477.1095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:477.1095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:477.1095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:477.1095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:477.1095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:477.1095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:477.1095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:477.1095}).wait(1).to({graphics:null,x:0,y:0}).wait(63));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,895.25,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.4,scaleX:2.4148,scaleY:2.4148,x:39.9,y:60.45},30,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,903.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},30,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-77.2,982,1960.9);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask.setTransform(147.1518,94.651);

	// LeafA
	this.instance = new lib.leafA();
	this.instance.setTransform(58.25,128.95,0.6362,0.6362,0,0,0,99,122.8);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(105));

	// ScreenMaskA copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_1.setTransform(147.1518,94.651);

	// Grass
	this.instance_1 = new lib.grass();
	this.instance_1.setTransform(172.05,168.85,0.6595,0.6595,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(105));

	// ScreenMaskA copy 2 (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	mask_2.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_2.setTransform(147.1518,94.651);

	// LeafB
	this.instance_2 = new lib.leafB();
	this.instance_2.setTransform(255.85,101.15,0.6995,0.6995,0,0,0,55.1,54.6);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(150,70.95,0.7954,0.7954,0,0,0,50.2,75.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(55).to({mode:"synched",loop:false},0).to({y:72.9,startPosition:4},4,cjs.Ease.quadInOut).to({y:68.1,startPosition:16},12,cjs.Ease.quadInOut).to({startPosition:36},20,cjs.Ease.quadInOut).to({y:69.55,startPosition:44},8,cjs.Ease.quadInOut).wait(5).to({mode:"single",startPosition:49},0).wait(1));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(151.4,176.55,0.7338,0.7338,0,0,0,58.1,159.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(55).to({regY:159.6,y:176.95},4,cjs.Ease.quadInOut).to({regY:159.7,scaleY:0.7573,y:175.65},16,cjs.Ease.quadInOut).to({scaleY:0.7571,y:175.6},12,cjs.Ease.quadInOut).to({scaleY:0.7338,y:176.55},12,cjs.Ease.quadInOut).wait(6));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	mask_3.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_3.setTransform(147.1518,94.651);

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(167.9,158.75,0.8242,0.8242,0,0,0,155.3,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(105));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	mask_4.graphics.p("AuqOzIAAzsMAlqAAAIAATsg");
	mask_4.setTransform(147.1518,94.651);

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(166.1,87.6,0.7852,0.7852,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(105));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(0,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(105));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,22.2,300,201);


(lib.main_ui = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MainText
	this.instance = new lib.main_txt();
	this.instance.setTransform(78.55,84.7,1,1,0,0,0,52,12.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Rows_Cells
	this.instance_1 = new lib.rowsandcells();
	this.instance_1.setTransform(233.3,34.55,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Top_bar_txt
	this.instance_2 = new lib.top_text();
	this.instance_2.setTransform(224.6,11.15,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Top_bar
	this.instance_3 = new lib.Topbar();
	this.instance_3.setTransform(225,5.5,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Top_grey
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#227347").s().p("AgOAIIgDAAIAAgYIAjAAIAAAYIgVAAIgLAJgAgPAGIAEAAIAAAGIAHgGIATAAIAAgTIgeAAg");
	this.shape.setTransform(416.4564,17.2001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#EEEDEC").ss(0.3).p("ACcAlIk3AAQgDAAgCgCQgCgCAAgDIAAg6QAAgIAHAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_1.setTransform(428.3065,17.1751);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibAlQgDAAgCgCQgCgCgBgDIAAg6QAAgIAIAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_2.setTransform(428.3065,17.1751);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#227347").s().p("AACAHQgJAAgFAEIgCABIAAgDIADgHQAEgGAJAAIAAgIIANAMIgNAOgAADAFIABAAIAAACIAHgHIgHgGIAAAEIgBAAQgLAAgDAJQAFgDAGABg");
	this.shape_3.setTransform(391.881,16.4001);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#227347").s().p("AgQANIAAgZIADAAIAAAWIAbAAIAAgLIADAAIAAAOg");
	this.shape_4.setTransform(391.106,17.9251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#474747").s().p("AgWAXQAAAAgBgBQAAAAAAAAQAAAAAAAAQABgBAAAAIARgRQgDgEAAgFQAAgHAFgFQADgFAHAAQAHAAAFAFQAFAFAAAHQAAAGgFAFQgFAEgHAAQgHAAgEgEIgRARgAgCgPQgEAEAAAGQAAAFAEAEQADAEAGAAQAGAAAEgEQAEgEAAgFQAAgGgEgEQgEgFgGABQgGgBgDAFg");
	this.shape_5.setTransform(205.7781,17.4501);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#EEEDEC").ss(0.3).p("ABnAlIjMAAQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_6.setTransform(397.9561,17.2001);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhlAlQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_7.setTransform(397.9561,17.2001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F0F0F0").s().p("EgjJAA9IAAh5MBGTAAAIAAB5g");
	this.shape_8.setTransform(225,17.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Scroll_bars
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#ABABAB").ss(0.3).p("AqYAXIAAgtIUxAAIAAAtg");
	this.shape_9.setTransform(277.1512,272.3786);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqXAXIAAgtIUvAAIAAAtg");
	this.shape_10.setTransform(277.1512,272.3786);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#787878").s().p("AgFgLIALALIgLAMg");
	this.shape_11.setTransform(437.3786,272.4286);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#787878").s().p("AgFAAIALgLIAAAXg");
	this.shape_12.setTransform(208.3001,272.4286);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_13.setTransform(437.2536,272.3786);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAXIAAgtIAsAAIAAAtg");
	this.shape_14.setTransform(437.2536,272.3786);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_15.setTransform(208.4251,272.4036);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAXIAAgsIAtAAIAAAsg");
	this.shape_16.setTransform(208.4251,272.4036);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#DBDBDB").ss(0.3).p("AxhAXIAAgtMAjDAAAIAAAtg");
	this.shape_17.setTransform(322.8519,272.3786);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DBDBDB").s().p("AxgAXIAAgtMAjCAAAIAAAtg");
	this.shape_18.setTransform(322.8519,272.3786);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#ABABAB").ss(0.3).p("AAXKZIgtAAIAA0xIAtAAg");
	this.shape_19.setTransform(445.3787,110.0511);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWKYIAA0vIAtAAIAAUvg");
	this.shape_20.setTransform(445.3787,110.0511);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAHAAIAAAFg");
	this.shape_21.setTransform(200.65,273.4536);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B3B3B3").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_22.setTransform(200.65,272.1536);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAHAAIAAAGg");
	this.shape_23.setTransform(200.65,270.8535);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787878").s().p("AgMAGIAMgLIAMALg");
	this.shape_24.setTransform(445.4037,41.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#787878").s().p("AgMgFIAYAAIgMALg");
	this.shape_25.setTransform(445.4037,265.2785);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_26.setTransform(445.3787,41.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_27.setTransform(445.3787,41.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_28.setTransform(445.4037,265.1285);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAsAAIAAAtg");
	this.shape_29.setTransform(445.4037,265.1285);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DBDBDB").ss(0.3).p("AAXRIIgtAAMAAAgiPIAtAAg");
	this.shape_30.setTransform(445.3787,153.2267);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DBDBDB").s().p("AgWRIMAAAgiPIAtAAMAAAAiPg");
	this.shape_31.setTransform(445.3787,153.2267);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// layout
	this.instance_4 = new lib.Layout();
	this.instance_4.setTransform(225,150.15,1,1,0,0,0,225,126.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Bottom
	this.instance_5 = new lib.bottom();
	this.instance_5.setTransform(225.6,281.85,1,1,0,0,0,225.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer_2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#E4DFD4").ss(1,1,1).p("EgifgVxMBE/AAAMAAAArjMhE/AAAg");
	this.shape_32.setTransform(223.225,143.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("EgifAVyMAAAgrjMBE/AAAMAAAArjg");
	this.shape_33.setTransform(223.225,143.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_ui, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.guyrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,-0.1,53,43), null);


(lib.guyrightcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution, new cjs.Rectangle(-0.5,0,76,52), null);


(lib.guylefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon, new cjs.Rectangle(0.1,0.1,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.graphLG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.graphGreen();
	this.instance.setTransform(49.9,49.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphLG, new cjs.Rectangle(-8,-8,115.8,115.8), null);


(lib.GraphCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// WhiteCoverOuter
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCAAQAADwiqCoQioCqjwAAQjvAAipiqQipioAAjwQAAjvCpipQCpipDvAAQDwAACoCpQCqCpAADvg");
	this.shape.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// WhiteCoverMid
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkpEpQh6h7AAiuQAAitB6h8QB8h6CtAAQCuAAB7B6QB7B8AACtQAACuh7B7Qh7B7iuAAQitAAh8h7g");
	this.shape_1.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(60));

	// Layer_3
	this.instance = new lib.circleSegment();
	this.instance.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:28.9,regY:29,rotation:-0.029,x:28.9,y:29},0).wait(1).to({rotation:-0.1186,x:28.85,y:29.05},0).wait(1).to({rotation:-0.273,x:28.8,y:29.1},0).wait(1).to({rotation:-0.4968,x:28.7,y:29.25},0).wait(1).to({rotation:-0.7954,x:28.55,y:29.4},0).wait(1).to({rotation:-1.1745,x:28.35,y:29.55},0).wait(1).to({rotation:-1.6408,x:28.15,y:29.8},0).wait(1).to({rotation:-2.2019,x:27.85,y:30.15},0).wait(1).to({rotation:-2.8662,x:27.5,y:30.45},0).wait(1).to({rotation:-3.6437,x:27.15,y:30.85},0).wait(1).to({rotation:-4.5458,x:26.7,y:31.35},0).wait(1).to({rotation:-5.5858,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7793,x:25.7,y:32.6},0).wait(1).to({rotation:-8.145,x:25.1,y:33.35},0).wait(1).to({rotation:-9.7052,x:24.5,y:34.3},0).wait(1).to({rotation:-11.4869,x:23.75,y:35.3},0).wait(1).to({rotation:-13.5237,x:23,y:36.55},0).wait(1).to({rotation:-15.8573,x:22.1,y:38},0).wait(1).to({rotation:-18.5409,x:21.2,y:39.7},0).wait(1).to({rotation:-21.6437,x:20.3,y:41.7},0).wait(1).to({rotation:-25.2575,x:19.35,y:44.1},0).wait(1).to({rotation:-29.5072,x:18.45,y:47},0).wait(1).to({rotation:-34.5678,x:17.65,y:50.55},0).wait(1).to({rotation:-40.6901,x:17.05,y:54.85},0).wait(1).to({rotation:-48.2363,y:60.25},0).wait(1).to({rotation:-57.704,x:18,y:66.9},0).wait(1).to({rotation:-69.5952,x:20.75,y:74.95},0).wait(1).to({rotation:-83.7062,x:25.95,y:83.5},0).wait(1).to({rotation:-98.1499,x:33.35,y:90.7},0).wait(1).to({rotation:-110.7267,x:41.05,y:95.2},0).wait(1).to({rotation:-120.8736,x:47.9,y:97.6},0).wait(1).to({rotation:-128.9999,x:53.6,y:98.6},0).wait(1).to({rotation:-135.6121,x:58.35,y:98.85},0).wait(1).to({rotation:-141.095,x:62.2,y:98.6},0).wait(1).to({rotation:-145.7175,x:65.5,y:98.1},0).wait(1).to({rotation:-149.667,x:68.25,y:97.45},0).wait(1).to({rotation:-153.0773,x:70.65,y:96.8},0).wait(1).to({rotation:-156.0464,x:72.6,y:96.1},0).wait(1).to({rotation:-158.6477,x:74.3,y:95.4},0).wait(1).to({rotation:-160.9377,x:75.8,y:94.7},0).wait(1).to({rotation:-162.9604,x:77.05,y:94.05},0).wait(1).to({rotation:-164.7513,x:78.2,y:93.4},0).wait(1).to({rotation:-166.3388,x:79.15,y:92.8},0).wait(1).to({rotation:-167.7463,x:80,y:92.3},0).wait(1).to({rotation:-168.9936,x:80.8,y:91.85},0).wait(1).to({rotation:-170.0968,x:81.45,y:91.4},0).wait(1).to({rotation:-171.0701,x:82,y:90.95},0).wait(1).to({rotation:-171.9252,x:82.45,y:90.65},0).wait(1).to({rotation:-172.6727,x:82.9,y:90.3},0).wait(1).to({rotation:-173.3213,x:83.25,y:90},0).wait(1).to({regX:57.9,regY:57.9,rotation:-173.879,x:57.85,y:57.95},0).wait(1).to({regX:28.9,regY:29,rotation:-173.9985,x:83.7,y:89.65},0).wait(1).to({rotation:-174.0984,x:83.75,y:89.6},0).wait(1).to({rotation:-174.1799,x:83.8,y:89.55},0).wait(1).to({rotation:-174.2445,x:83.85},0).wait(1).to({rotation:-174.2931,x:83.9},0).wait(1).to({rotation:-174.3267,y:89.5},0).wait(1).to({rotation:-174.3463},0).wait(1).to({regX:57.7,regY:57.8,rotation:-174.3527,x:58,y:57.95},0).wait(1));

	// Layer_2
	this.instance_1 = new lib.circleSegment();
	this.instance_1.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:28.9,regY:29,rotation:-0.0144,x:28.9,y:29},0).wait(1).to({rotation:-0.059},0).wait(1).to({rotation:-0.1357,x:28.85,y:29.05},0).wait(1).to({rotation:-0.247,x:28.8,y:29.1},0).wait(1).to({rotation:-0.3955,x:28.75,y:29.2},0).wait(1).to({rotation:-0.584,x:28.65,y:29.25},0).wait(1).to({rotation:-0.8159,x:28.5,y:29.4},0).wait(1).to({rotation:-1.0949,x:28.4,y:29.55},0).wait(1).to({rotation:-1.4252,x:28.2,y:29.75},0).wait(1).to({rotation:-1.8118,x:28,y:29.95},0).wait(1).to({rotation:-2.2604,x:27.85,y:30.15},0).wait(1).to({rotation:-2.7775,x:27.55,y:30.4},0).wait(1).to({rotation:-3.371,x:27.25,y:30.75},0).wait(1).to({rotation:-4.05,x:27,y:31.1},0).wait(1).to({rotation:-4.8258,x:26.6,y:31.5},0).wait(1).to({rotation:-5.7118,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7245,x:25.75,y:32.55},0).wait(1).to({rotation:-7.8849,x:25.3,y:33.25},0).wait(1).to({rotation:-9.2193,x:24.7,y:34},0).wait(1).to({rotation:-10.7621,x:24.05,y:34.9},0).wait(1).to({rotation:-12.559,x:23.35,y:35.95},0).wait(1).to({rotation:-14.6721,x:22.55,y:37.25},0).wait(1).to({rotation:-17.1885,x:21.65,y:38.8},0).wait(1).to({rotation:-20.2327,x:20.75,y:40.75},0).wait(1).to({rotation:-23.985,x:19.7,y:43.25},0).wait(1).to({rotation:-28.6927,x:18.6,y:46.45},0).wait(1).to({rotation:-34.6055,x:17.65,y:50.5},0).wait(1).to({rotation:-41.622,x:17.05,y:55.5},0).wait(1).to({rotation:-48.8041,x:17.1,y:60.6},0).wait(1).to({rotation:-55.0577,x:17.6,y:65.05},0).wait(1).to({rotation:-60.1032,x:18.45,y:68.55},0).wait(1).to({rotation:-64.1439,x:19.3,y:71.3},0).wait(1).to({rotation:-67.4317,x:20.15,y:73.5},0).wait(1).to({rotation:-70.1581,x:20.95,y:75.3},0).wait(1).to({rotation:-72.4565,x:21.65,y:76.75},0).wait(1).to({rotation:-74.4204,x:22.3,y:78},0).wait(1).to({rotation:-76.1161,x:22.95,y:79.05},0).wait(1).to({rotation:-77.5925,x:23.45,y:79.95},0).wait(1).to({rotation:-78.886,x:23.95,y:80.7},0).wait(1).to({rotation:-80.0246,x:24.45,y:81.35},0).wait(1).to({rotation:-81.0304,x:24.85,y:81.95},0).wait(1).to({rotation:-81.9209,x:25.25,y:82.5},0).wait(1).to({rotation:-82.7103,x:25.55,y:82.95},0).wait(1).to({rotation:-83.4102,x:25.9,y:83.35},0).wait(1).to({rotation:-84.0303,x:26.2,y:83.65},0).wait(1).to({rotation:-84.5789,x:26.45,y:84},0).wait(1).to({rotation:-85.0629,x:26.65,y:84.2},0).wait(1).to({rotation:-85.4881,x:26.8,y:84.5},0).wait(1).to({rotation:-85.8597,x:27,y:84.7},0).wait(1).to({rotation:-86.1822,x:27.15,y:84.85},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.4596,x:57.95,y:57.85},0).wait(1).to({regX:28.9,regY:29,rotation:-86.5188,x:27.35,y:85},0).wait(1).to({rotation:-86.5683,y:85.05},0).wait(1).to({rotation:-86.6087},0).wait(1).to({rotation:-86.6407,x:27.4},0).wait(1).to({rotation:-86.6647,y:85.1},0).wait(1).to({rotation:-86.6814,x:27.35},0).wait(1).to({rotation:-86.6911,y:85.05},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.6943,x:57.9,y:57.85},0).wait(1));

	// Layer_1
	this.instance_2 = new lib.circleSegment();
	this.instance_2.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-5.8,127.5,127.5);


(lib.girlrigthcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon, new cjs.Rectangle(-0.1,-0.2,51,43), null);


(lib.girlleftcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution, new cjs.Rectangle(0.1,-0.2,89,65), null);


(lib.excel_screen_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.white.cache(0,0,460,310,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.white = new lib.excel_screen_white_sub();
	this.white.name = "white";
	this.white.setTransform(225.3,151.3,1,1,0,0,0,225.3,151.3);

	this.timeline.addTween(cjs.Tween.get(this.white).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.excel_screen_white, new cjs.Rectangle(0,24,450.5,234.60000000000002), null);


(lib.shadow_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// a
	this.tablet_shadow_1 = new lib.tablet_shadow_vector();
	this.tablet_shadow_1.name = "tablet_shadow_1";
	this.tablet_shadow_1.setTransform(215.3,163.5,2.3747,1.8542,0,-26.5648,-17.1173,64.5,47.3);
	this.tablet_shadow_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.tablet_shadow_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_2, new cjs.Rectangle(-20.1,40.3,419.8,246.2), null);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_124 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(124).call(this.frame_124).wait(1));

	// Icon
	this.instance = new lib.Icon();
	this.instance.setTransform(71.6,74.75,0.7404,0.7404,0,0,0,50.3,50.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:50.4,scaleX:0.8191,scaleY:0.8191,x:88.2,y:68.2},30,cjs.Ease.cubicInOut).wait(6));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(107.4,56.05,0.8476,0.7854,0,-29.2995,-16.7948,58.8,15.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regX:58.9,regY:15.3,scaleX:0.9377,scaleY:0.8689,skewX:-29.2978,skewY:-16.7943,x:131.85,y:46.7,startPosition:104},30,cjs.Ease.cubicInOut).wait(6));

	// Shadow
	this.instance_2 = new lib.shadow_2();
	this.instance_2.setTransform(195.55,84.65,0.9383,0.9383,0,0,0,176.8,127.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(89).to({regX:176.9,scaleX:0.9842,scaleY:0.9842,x:227.05,y:87.15},30,cjs.Ease.cubicInOut).wait(6));

	// Layer_2
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(370.8,-621.4,2.2266,2.2266,30.144,0,0,-0.1,-0.3);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(46));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-272.2,-589,978.9000000000001,1334.1);


(lib.chart_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.circle_shadow.cache(0,0,260,260);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_5
	this.circle_shadow = new lib.circle_shadow();
	this.circle_shadow.name = "circle_shadow";
	this.circle_shadow.setTransform(227.55,275.55,1,1,0,0,0,128.5,128.5);
	this.circle_shadow.alpha = 0.1484;

	this.timeline.addTween(cjs.Tween.get(this.circle_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_shadow, new cjs.Rectangle(0,0,420,420), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._3D_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{grow:1});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		exportRoot.mainMC.page.obj1.screen.screen.gotoAndPlay("vanish");
	}
	this.frame_37 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(36).call(this.frame_37).wait(1));

	// percentage
	this.percantage = new lib.percantage();
	this.percantage.name = "percantage";
	this.percantage.setTransform(-43.15,-17.45,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.percantage.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.percantage).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-43.05,y:-17.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:247.2,regY:218.9,scaleX:0.6925,scaleY:0.6708,skewY:-4.1654,x:-16.5,y:-14.55},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1122,x:-15.15,y:-16},0).wait(1).to({scaleX:0.7169,scaleY:0.6939,skewY:-4.045,x:-13.5,y:-17.95},0).wait(1).to({scaleX:0.7333,scaleY:0.7094,skewY:-3.9642,x:-11.4,y:-20.2},0).wait(1).to({scaleX:0.7524,scaleY:0.7275,skewY:-3.8698,x:-9.1,y:-22.85},0).wait(1).to({scaleX:0.7742,scaleY:0.7481,skewY:-3.7625,x:-6.35,y:-25.85},0).wait(1).to({scaleX:0.7985,scaleY:0.7711,skewY:-3.6427,x:-3.35,y:-29.2},0).wait(1).to({scaleX:0.8252,scaleY:0.7964,skewY:-3.5111,x:-0.05,y:-32.85},0).wait(1).to({scaleX:0.8541,scaleY:0.8237,skewY:-3.3686,x:3.55,y:-36.85},0).wait(1).to({scaleX:0.885,scaleY:0.853,skewY:-3.2162,x:7.35,y:-41.1},0).wait(1).to({scaleX:0.9177,scaleY:0.8839,skewY:-3.0551,x:11.4,y:-45.6},0).wait(1).to({scaleX:0.9518,scaleY:0.9162,skewY:-2.8865,x:15.65,y:-50.3},0).wait(1).to({scaleX:0.9872,scaleY:0.9497,skewY:-2.7119,x:20.05,y:-55.15},0).wait(1).to({scaleX:1.0236,scaleY:0.9841,skewY:-2.5328,x:24.55,y:-60.15},0).wait(1).to({scaleX:1.0605,scaleY:1.019,skewY:-2.3508,x:29.15,y:-65.15},0).wait(1).to({scaleX:1.0977,scaleY:1.0542,skewY:-2.1675,x:33.75,y:-70.2},0).wait(1).to({scaleX:1.1348,scaleY:1.0893,skewY:-1.9845,x:38.35,y:-75.25},0).wait(1).to({scaleX:1.1715,scaleY:1.1241,skewY:-1.8033,x:42.9,y:-80.2},0).wait(1).to({scaleX:1.2076,scaleY:1.1582,skewY:-1.6255,x:47.4,y:-85.05},0).wait(1).to({scaleX:1.2427,scaleY:1.1914,skewY:-1.4525,x:51.75,y:-89.85},0).wait(1).to({scaleX:1.2765,scaleY:1.2234,skewY:-1.2856,x:55.9,y:-94.45},0).wait(1).to({scaleX:1.3089,scaleY:1.254,skewY:-1.126,x:59.95,y:-98.8},0).wait(1).to({scaleX:1.3395,scaleY:1.2831,skewY:-0.9748,x:63.75,y:-102.95},0).wait(1).to({scaleX:1.3683,scaleY:1.3103,skewY:-0.8327,x:67.3,y:-106.75},0).wait(1).to({scaleX:1.3952,scaleY:1.3357,skewY:-0.7006,x:70.6,y:-110.35},0).wait(1).to({scaleX:1.4198,scaleY:1.359,skewY:-0.5791,x:73.65,y:-113.65},0).wait(1).to({scaleX:1.4422,scaleY:1.3802,skewY:-0.4686,x:76.45,y:-116.7},0).wait(1).to({scaleX:1.4623,scaleY:1.3992,skewY:-0.3696,x:78.9,y:-119.35},0).wait(1).to({scaleX:1.48,scaleY:1.416,skewY:-0.2821,x:81.15,y:-121.75},0).wait(1).to({scaleX:1.4953,scaleY:1.4305,skewY:-0.2065,x:83.05,y:-123.8},0).wait(1).to({scaleX:1.5083,scaleY:1.4427,skewY:-0.1428,x:84.65,y:-125.55},0).wait(1).to({scaleX:1.5188,scaleY:1.4527,skewY:-0.0909,x:85.95,y:-126.9},0).wait(1).to({scaleX:1.5269,scaleY:1.4604,skewY:-0.0509,x:86.95,y:-128.05},0).wait(1).to({scaleX:1.5327,scaleY:1.4658,skewY:0,x:87.65,y:-128.8},0).wait(1).to({scaleX:1.5361,scaleY:1.4691,x:88.05,y:-129.25},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:30.7,y:-142.9},0).wait(1));

	// Big
	this.b_pie = new lib.big_pie();
	this.b_pie.name = "b_pie";
	this.b_pie.setTransform(-38.8,-25.9,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.b_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.b_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-38.7,y:-26.1,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:241.1,regY:237.8,scaleX:0.6924,scaleY:0.6707,skewY:-4.1658,x:-16.4,y:-9.95},0).wait(1).to({scaleX:0.7033,scaleY:0.681,skewY:-4.1121,x:-15.15,y:-11.1},0).wait(1).to({scaleX:0.7173,scaleY:0.6943,skewY:-4.0428,x:-13.55,y:-12.7},0).wait(1).to({scaleX:0.7347,scaleY:0.7108,skewY:-3.9571,x:-11.55,y:-14.6},0).wait(1).to({scaleX:0.7555,scaleY:0.7305,skewY:-3.8546,x:-9.15,y:-16.9},0).wait(1).to({scaleX:0.7798,scaleY:0.7534,skewY:-3.735,x:-6.4,y:-19.6},0).wait(1).to({scaleX:0.8075,scaleY:0.7796,skewY:-3.5984,x:-3.25,y:-22.6},0).wait(1).to({scaleX:0.8385,scaleY:0.809,skewY:-3.4452,x:0.3,y:-26.05},0).wait(1).to({scaleX:0.8727,scaleY:0.8414,skewY:-3.2766,x:4.2,y:-29.85},0).wait(1).to({scaleX:0.9097,scaleY:0.8764,skewY:-3.0943,x:8.45,y:-33.9},0).wait(1).to({scaleX:0.949,scaleY:0.9136,skewY:-2.9004,x:12.9,y:-38.2},0).wait(1).to({scaleX:0.9901,scaleY:0.9524,skewY:-2.6979,x:17.65,y:-42.65},0).wait(1).to({scaleX:1.0323,scaleY:0.9923,skewY:-2.4899,x:22.45,y:-47.3},0).wait(1).to({scaleX:1.0749,scaleY:1.0327,skewY:-2.2798,x:27.3,y:-51.9},0).wait(1).to({scaleX:1.1173,scaleY:1.0727,skewY:-2.0709,x:32.15,y:-56.5},0).wait(1).to({scaleX:1.1587,scaleY:1.112,skewY:-1.8662,x:36.85,y:-61},0).wait(1).to({scaleX:1.1988,scaleY:1.15,skewY:-1.6685,x:41.45,y:-65.35},0).wait(1).to({scaleX:1.2371,scaleY:1.1862,skewY:-1.4798,x:45.85,y:-69.5},0).wait(1).to({scaleX:1.2733,scaleY:1.2203,skewY:-1.3016,x:49.95,y:-73.35},0).wait(1).to({scaleX:1.307,scaleY:1.2523,skewY:-1.1352,x:53.8,y:-77},0).wait(1).to({scaleX:1.3383,scaleY:1.2819,skewY:-0.981,x:57.4,y:-80.3},0).wait(1).to({scaleX:1.367,scaleY:1.309,skewY:-0.8395,x:60.7,y:-83.45},0).wait(1).to({scaleX:1.3931,scaleY:1.3338,skewY:-0.7105,x:63.65,y:-86.25},0).wait(1).to({scaleX:1.4168,scaleY:1.3561,skewY:-0.594,x:66.35,y:-88.75},0).wait(1).to({scaleX:1.438,scaleY:1.3762,skewY:-0.4895,x:68.75,y:-91},0).wait(1).to({scaleX:1.4568,scaleY:1.394,skewY:-0.3967,x:70.9,y:-93.05},0).wait(1).to({scaleX:1.4733,scaleY:1.4097,skewY:-0.3151,x:72.8,y:-94.8},0).wait(1).to({scaleX:1.4877,scaleY:1.4233,skewY:-0.2441,x:74.5,y:-96.35},0).wait(1).to({scaleX:1.5001,scaleY:1.435,skewY:-0.1833,x:75.85,y:-97.6},0).wait(1).to({scaleX:1.5105,scaleY:1.4448,skewY:-0.1321,x:77.05,y:-98.75},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.09,x:78,y:-99.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0565,x:78.8,y:-100.35},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:79.4,y:-100.95},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:79.8,y:-101.35},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:80.05,y:-101.5},0).wait(1).to({regX:209.8,regY:209.8,scaleX:1.5372,scaleY:1.4701,x:32.05,y:-142.9},0).wait(1));

	// Small
	this.s_pie = new lib.small_pie();
	this.s_pie.name = "s_pie";
	this.s_pie.setTransform(-40.3,-18.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.s_pie.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.s_pie).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,x:-40.2,y:-18.65,alpha:1},1,cjs.Ease.cubicInOut).wait(1).to({regX:269.2,regY:169.2,scaleX:0.6927,scaleY:0.6711,skewY:-4.1641,x:1.55,y:-50.05},0).wait(1).to({scaleX:0.7048,scaleY:0.6824,skewY:-4.1049,x:3.3,y:-52.3},0).wait(1).to({scaleX:0.7213,scaleY:0.6981,skewY:-4.0234,x:5.65,y:-55.3},0).wait(1).to({scaleX:0.7432,scaleY:0.7188,skewY:-3.9155,x:8.75,y:-59.4},0).wait(1).to({scaleX:0.7714,scaleY:0.7455,skewY:-3.7762,x:12.75,y:-64.6},0).wait(1).to({scaleX:0.8071,scaleY:0.7792,skewY:-3.6003,x:17.85,y:-71.2},0).wait(1).to({scaleX:0.8509,scaleY:0.8207,skewY:-3.3844,x:24.05,y:-79.25},0).wait(1).to({scaleX:0.9026,scaleY:0.8697,skewY:-3.1291,x:31.4,y:-88.75},0).wait(1).to({scaleX:0.9607,scaleY:0.9247,skewY:-2.8425,x:39.7,y:-99.4},0).wait(1).to({scaleX:1.0219,scaleY:0.9825,skewY:-2.541,x:48.4,y:-110.6},0).wait(1).to({scaleX:1.0823,scaleY:1.0396,skewY:-2.2435,x:57,y:-121.55},0).wait(1).to({scaleX:1.1388,scaleY:1.0931,skewY:-1.9646,x:65.05,y:-131.85},0).wait(1).to({scaleX:1.1901,scaleY:1.1416,skewY:-1.7118,x:72.3,y:-141.1},0).wait(1).to({scaleX:1.2357,scaleY:1.1848,skewY:-1.4869,x:78.85,y:-149.35},0).wait(1).to({scaleX:1.2759,scaleY:1.2229,skewY:-1.2886,x:84.55,y:-156.55},0).wait(1).to({scaleX:1.3113,scaleY:1.2563,skewY:-1.1142,x:89.55,y:-162.9},0).wait(1).to({scaleX:1.3423,scaleY:1.2857,skewY:-0.961,x:94,y:-168.45},0).wait(1).to({scaleX:1.3697,scaleY:1.3116,skewY:-0.8262,x:97.85,y:-173.35},0).wait(1).to({scaleX:1.3937,scaleY:1.3343,skewY:-0.7076,x:101.3,y:-177.7},0).wait(1).to({scaleX:1.4149,scaleY:1.3544,skewY:-0.603,x:104.3,y:-181.45},0).wait(1).to({scaleX:1.4336,scaleY:1.3721,skewY:-0.5109,x:106.95,y:-184.8},0).wait(1).to({scaleX:1.4501,scaleY:1.3876,skewY:-0.4298,x:109.35,y:-187.65},0).wait(1).to({scaleX:1.4646,scaleY:1.4013,skewY:-0.3585,x:111.4,y:-190.25},0).wait(1).to({scaleX:1.4772,scaleY:1.4134,skewY:-0.2959,x:113.2,y:-192.5},0).wait(1).to({scaleX:1.4883,scaleY:1.4238,skewY:-0.2411,x:114.75,y:-194.5},0).wait(1).to({scaleX:1.498,scaleY:1.433,skewY:-0.1936,x:116.15,y:-196.2},0).wait(1).to({scaleX:1.5063,scaleY:1.4409,skewY:-0.1524,x:117.35,y:-197.7},0).wait(1).to({scaleX:1.5135,scaleY:1.4476,skewY:-0.1172,x:118.3,y:-198.95},0).wait(1).to({scaleX:1.5195,scaleY:1.4533,skewY:-0.0874,x:119.2,y:-200},0).wait(1).to({scaleX:1.5245,scaleY:1.4581,skewY:-0.0627,x:119.9,y:-200.9},0).wait(1).to({scaleX:1.5286,scaleY:1.462,skewY:0,x:120.5,y:-201.65},0).wait(1).to({scaleX:1.5318,scaleY:1.465,x:120.95,y:-202.2},0).wait(1).to({scaleX:1.5343,scaleY:1.4673,x:121.25,y:-202.65},0).wait(1).to({scaleX:1.5359,scaleY:1.4689,x:121.5,y:-202.9},0).wait(1).to({scaleX:1.5369,scaleY:1.4698,x:121.7,y:-203.1},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.45,y:-143.4},0).wait(1));

	// Shadow
	this.c_shadow = new lib.chart_shadow();
	this.c_shadow.name = "c_shadow";
	this.c_shadow.setTransform(-26.45,-49.4,0.6835,0.6623,0,0,-4.2045,209.8,209.8);
	this.c_shadow.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.c_shadow).to({scaleX:0.6845,scaleY:0.6633,skewY:-4.2047,y:-49.55},1,cjs.Ease.cubicInOut).wait(1).to({regX:227.6,regY:275.6,scaleX:0.6926,scaleY:0.6709,skewY:-4.165,x:-13.6,y:-7.15,alpha:0.0512},0).wait(1).to({scaleX:0.7037,scaleY:0.6815,skewY:-4.1099,x:-12.65,y:-7.75,alpha:0.1221},0).wait(1).to({scaleX:0.7181,scaleY:0.6951,skewY:-4.0387,x:-11.45,y:-8.4,alpha:0.2138},0).wait(1).to({scaleX:0.7359,scaleY:0.7119,skewY:-3.9508,x:-9.95,y:-9.3,alpha:0.327},0).wait(1).to({scaleX:0.7572,scaleY:0.7321,skewY:-3.8458,x:-8.15,y:-10.35,alpha:0.4622},0).wait(1).to({scaleX:0.782,scaleY:0.7555,skewY:-3.7235,x:-6.1,y:-11.55,alpha:0.6198},0).wait(1).to({scaleX:0.8102,scaleY:0.7823,skewY:-3.5841,x:-3.7,y:-12.95,alpha:0.7993},0).wait(1).to({regX:209.8,regY:209.8,scaleX:0.8418,scaleY:0.8121,skewY:-3.4282,x:-16,y:-66.95,alpha:1},0).wait(1).to({regX:227.6,regY:275.6,scaleX:0.8765,scaleY:0.8449,skewY:-3.2574,x:1.9,y:-16.1},0).wait(1).to({scaleX:0.9138,scaleY:0.8803,skewY:-3.0733,x:5.05,y:-17.9},0).wait(1).to({scaleX:0.9534,scaleY:0.9177,skewY:-2.8783,x:8.35,y:-19.8},0).wait(1).to({scaleX:0.9945,scaleY:0.9566,skewY:-2.6753,x:11.85,y:-21.8},0).wait(1).to({scaleX:1.0367,scaleY:0.9965,skewY:-2.4676,x:15.45,y:-23.8},0).wait(1).to({scaleX:1.0791,scaleY:1.0367,skewY:-2.2583,x:18.95,y:-25.9},0).wait(1).to({scaleX:1.1212,scaleY:1.0765,skewY:-2.0509,x:22.5,y:-27.85},0).wait(1).to({scaleX:1.1623,scaleY:1.1154,skewY:-1.8481,x:26,y:-29.85},0).wait(1).to({scaleX:1.2021,scaleY:1.153,skewY:-1.6524,x:29.35,y:-31.7},0).wait(1).to({scaleX:1.2399,scaleY:1.1888,skewY:-1.4658,x:32.55,y:-33.45},0).wait(1).to({scaleX:1.2756,scaleY:1.2226,skewY:-1.2898,x:35.55,y:-35.2},0).wait(1).to({scaleX:1.309,scaleY:1.2541,skewY:-1.1253,x:38.35,y:-36.75},0).wait(1).to({scaleX:1.3399,scaleY:1.2834,skewY:-0.973,x:40.95,y:-38.25},0).wait(1).to({scaleX:1.3682,scaleY:1.3102,skewY:-0.8331,x:43.4,y:-39.55},0).wait(1).to({scaleX:1.3941,scaleY:1.3347,skewY:-0.7055,x:45.5,y:-40.75},0).wait(1).to({scaleX:1.4175,scaleY:1.3569,skewY:-0.5901,x:47.5,y:-41.85},0).wait(1).to({scaleX:1.4385,scaleY:1.3767,skewY:-0.4866,x:49.3,y:-42.9},0).wait(1).to({scaleX:1.4572,scaleY:1.3944,skewY:-0.3946,x:50.85,y:-43.7},0).wait(1).to({scaleX:1.4736,scaleY:1.4099,skewY:-0.3136,x:52.25,y:-44.45},0).wait(1).to({scaleX:1.4879,scaleY:1.4235,skewY:-0.2431,x:53.45,y:-45.15},0).wait(1).to({scaleX:1.5002,scaleY:1.4351,skewY:-0.1826,x:54.5,y:-45.75},0).wait(1).to({scaleX:1.5105,scaleY:1.4449,skewY:-0.1317,x:55.35,y:-46.2},0).wait(1).to({scaleX:1.519,scaleY:1.4529,skewY:-0.0897,x:56.05,y:-46.6},0).wait(1).to({scaleX:1.5258,scaleY:1.4593,skewY:-0.0564,x:56.6,y:-46.9},0).wait(1).to({scaleX:1.5309,scaleY:1.4641,skewY:0,x:57.1,y:-47.15},0).wait(1).to({scaleX:1.5345,scaleY:1.4675,x:57.35,y:-47.3},0).wait(1).to({scaleX:1.5365,scaleY:1.4695,x:57.5,y:-47.4},0).wait(1).to({regX:209.8,regY:209.9,scaleX:1.5372,scaleY:1.4701,x:30.2,y:-144.25},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-140,-257.9,395.1,399.29999999999995);


(lib.UI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.mainUI.cache(-475,-300,950,600,0.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Main_UI
	this.mainUI = new lib.main_ui();
	this.mainUI.name = "mainUI";

	this.timeline.addTween(cjs.Tween.get(this.mainUI).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.screenanimation_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_172 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(172).call(this.frame_172).wait(3));

	// guy right icon.png
	this.instance_3 = new lib.guyrighticon();
	this.instance_3.setTransform(198.85,-85.15,1,1,0,0,0,26.4,21.5);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(29).to({_off:false},0).to({regY:21.4,scaleX:1.6102,scaleY:1.6102,x:261.15,y:-64.15,alpha:1},36,cjs.Ease.quadOut).wait(1).to({regX:26.5,x:261.3},0).wait(23).to({regX:26.4,x:261.15},0).wait(1).to({regX:26.5,scaleX:1.6034,scaleY:1.6034,x:261.7,y:-63.2},0).wait(1).to({scaleX:1.5937,scaleY:1.5937,x:262.25,y:-61.8},0).wait(1).to({scaleX:1.581,scaleY:1.581,x:262.95,y:-60},0).wait(1).to({scaleX:1.5653,scaleY:1.5653,x:263.85,y:-57.8},0).wait(1).to({scaleX:1.5464,scaleY:1.5464,x:264.9,y:-55.15},0).wait(1).to({scaleX:1.5243,scaleY:1.5243,x:266.15,y:-52.1},0).wait(1).to({scaleX:1.4993,scaleY:1.4993,x:267.55,y:-48.5},0).wait(1).to({scaleX:1.4713,scaleY:1.4713,x:269.15,y:-44.6},0).wait(1).to({scaleX:1.4408,scaleY:1.4408,x:270.9,y:-40.3},0).wait(1).to({scaleX:1.408,scaleY:1.408,x:272.7,y:-35.7},0).wait(1).to({scaleX:1.3735,scaleY:1.3735,x:274.65,y:-30.85},0).wait(1).to({scaleX:1.3379,scaleY:1.3379,x:276.65,y:-25.85},0).wait(1).to({scaleX:1.3019,scaleY:1.3019,x:278.7,y:-20.8},0).wait(1).to({scaleX:1.2661,scaleY:1.2661,x:280.7,y:-15.75},0).wait(1).to({scaleX:1.2312,scaleY:1.2312,x:282.7,y:-10.85},0).wait(1).to({scaleX:1.1977,scaleY:1.1977,x:284.6,y:-6.15},0).wait(1).to({scaleX:1.1663,scaleY:1.1663,x:286.35,y:-1.75},0).wait(1).to({scaleX:1.1373,scaleY:1.1373,x:288,y:2.35},0).wait(1).to({scaleX:1.1109,scaleY:1.1109,x:289.5,y:6},0).wait(1).to({scaleX:1.0875,scaleY:1.0875,x:290.75,y:9.3},0).wait(1).to({scaleX:1.067,scaleY:1.067,x:291.95,y:12.2},0).wait(1).to({scaleX:1.0495,scaleY:1.0495,x:292.9,y:14.65},0).wait(1).to({scaleX:1.035,scaleY:1.035,x:293.8,y:16.7},0).wait(1).to({scaleX:1.0234,scaleY:1.0234,x:294.4,y:18.35},0).wait(1).to({scaleX:1.0146,scaleY:1.0146,x:294.9,y:19.55},0).wait(1).to({scaleX:1.0084,scaleY:1.0084,x:295.25,y:20.45},0).wait(1).to({scaleX:1.0048,scaleY:1.0048,x:295.5,y:20.95},0).wait(1).to({regY:21.5,scaleX:1.0037,scaleY:1.0037,y:21.15},0).wait(1).to({regY:21.4,y:21.05},0).wait(8).to({regY:21.5,y:21.15},0).wait(1).to({regY:21.4,scaleX:1.0034,scaleY:1.0034,y:21},0).wait(1).to({scaleX:1.003,scaleY:1.003,y:20.95},0).wait(1).to({scaleX:1.0024,scaleY:1.0024,y:20.9},0).wait(1).to({scaleX:1.0015,scaleY:1.0015,x:295.55,y:20.85},0).wait(1).to({scaleX:1.0003,scaleY:1.0003,x:295.6,y:20.7},0).wait(1).to({scaleX:0.9989,scaleY:0.9989,y:20.6},0).wait(1).to({scaleX:0.9971,scaleY:0.9971,x:295.7,y:20.4},0).wait(1).to({scaleX:0.995,scaleY:0.995,x:295.75,y:20.15},0).wait(1).to({scaleX:0.9924,scaleY:0.9924,x:295.85,y:19.9},0).wait(1).to({scaleX:0.9893,scaleY:0.9893,x:295.95,y:19.55},0).wait(1).to({scaleX:0.9857,scaleY:0.9857,x:296.1,y:19.2},0).wait(1).to({scaleX:0.9814,scaleY:0.9814,x:296.25,y:18.75},0).wait(1).to({scaleX:0.9764,scaleY:0.9764,x:296.4,y:18.25},0).wait(1).to({scaleX:0.9703,scaleY:0.9703,x:296.65,y:17.6},0).wait(1).to({scaleX:0.9631,scaleY:0.9631,x:296.9,y:16.9},0).wait(1).to({scaleX:0.9544,scaleY:0.9544,x:297.2,y:15.95},0).wait(1).to({scaleX:0.9437,scaleY:0.9437,x:297.6,y:14.9},0).wait(1).to({scaleX:0.9302,scaleY:0.9302,x:298.05,y:13.5},0).wait(1).to({scaleX:0.9127,scaleY:0.9127,x:298.7,y:11.75},0).wait(1).to({scaleX:0.8896,scaleY:0.8896,x:299.45,y:9.35},0).wait(1).to({scaleX:0.859,scaleY:0.859,x:300.55,y:6.25},0).wait(1).to({scaleX:0.8239,scaleY:0.8239,x:301.85,y:2.6},0).wait(1).to({scaleX:0.7926,scaleY:0.7926,x:302.9,y:-0.6},0).wait(1).to({scaleX:0.7686,scaleY:0.7686,x:303.75,y:-3.05},0).wait(1).to({scaleX:0.7504,scaleY:0.7504,x:304.4,y:-4.95},0).wait(1).to({scaleX:0.7362,scaleY:0.7362,x:304.9,y:-6.4},0).wait(1).to({scaleX:0.7249,scaleY:0.7249,x:305.3,y:-7.55},0).wait(1).to({scaleX:0.7155,scaleY:0.7155,x:305.65,y:-8.55},0).wait(1).to({scaleX:0.7077,scaleY:0.7077,x:305.9,y:-9.3},0).wait(1).to({scaleX:0.7012,scaleY:0.7012,x:306.15,y:-10},0).wait(1).to({scaleX:0.6956,scaleY:0.6956,x:306.35,y:-10.55},0).wait(1).to({scaleX:0.6908,scaleY:0.6908,x:306.5,y:-11.05},0).wait(1).to({scaleX:0.6868,scaleY:0.6868,x:306.65,y:-11.45},0).wait(1).to({scaleX:0.6832,scaleY:0.6832,x:306.75,y:-11.85},0).wait(1).to({scaleX:0.6802,scaleY:0.6802,x:306.9,y:-12.15},0).wait(1).to({scaleX:0.6776,scaleY:0.6776,x:306.95,y:-12.4},0).wait(1).to({scaleX:0.6754,scaleY:0.6754,x:307.05,y:-12.65},0).wait(1).to({scaleX:0.6736,scaleY:0.6736,x:307.1,y:-12.85},0).wait(1).to({scaleX:0.672,scaleY:0.672,x:307.15,y:-12.95},0).wait(1).to({scaleX:0.6707,scaleY:0.6707,x:307.2,y:-13.1},0).wait(1).to({scaleX:0.6697,scaleY:0.6697,x:307.25,y:-13.2},0).wait(1).to({scaleX:0.6689,scaleY:0.6689,x:307.3,y:-13.3},0).wait(1).to({scaleX:0.6683,scaleY:0.6683,y:-13.35},0).wait(1).to({scaleX:0.6679,scaleY:0.6679,y:-13.4},0).wait(1).to({scaleX:0.6676,scaleY:0.6676,x:307.35},0).wait(1).to({regX:26.6,regY:21.5,scaleX:0.6675,scaleY:0.6675},0).to({_off:true},1).wait(2));

	// guy left icon.png
	this.instance_4 = new lib.guylefticon();
	this.instance_4.setTransform(-108.15,55.1,1,1,0,0,0,25.9,20.4);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(33).to({_off:false},0).to({scaleX:1.6102,scaleY:1.6102,x:59.95,y:-35.8,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:26.1,regY:20.6,x:60.3,y:-35.5},0).wait(22).to({regX:25.9,regY:20.4,x:59.95,y:-35.8},0).wait(1).to({regX:26.1,regY:20.6,scaleX:1.6015,scaleY:1.6015,x:62.3,y:-34.55},0).wait(1).to({scaleX:1.5899,scaleY:1.5899,x:65,y:-33.3},0).wait(1).to({scaleX:1.5752,scaleY:1.5752,x:68.45,y:-31.75},0).wait(1).to({scaleX:1.5573,scaleY:1.5573,x:72.65,y:-29.85},0).wait(1).to({scaleX:1.5359,scaleY:1.5359,x:77.7,y:-27.6},0).wait(1).to({scaleX:1.511,scaleY:1.511,x:83.55,y:-24.9},0).wait(1).to({scaleX:1.4824,scaleY:1.4824,x:90.25,y:-21.9},0).wait(1).to({scaleX:1.4501,scaleY:1.4501,x:97.85,y:-18.5},0).wait(1).to({scaleX:1.4141,scaleY:1.4141,x:106.25,y:-14.65},0).wait(1).to({scaleX:1.3747,scaleY:1.3747,x:115.55,y:-10.5},0).wait(1).to({scaleX:1.332,scaleY:1.332,x:125.55,y:-5.95},0).wait(1).to({scaleX:1.2867,scaleY:1.2867,x:136.2,y:-1.15},0).wait(1).to({scaleX:1.2392,scaleY:1.2392,x:147.35,y:3.9},0).wait(1).to({scaleX:1.1903,scaleY:1.1903,x:158.8,y:9},0).wait(1).to({scaleX:1.1411,scaleY:1.1411,x:170.4,y:14.25},0).wait(1).to({scaleX:1.0924,scaleY:1.0924,x:181.8,y:19.45},0).wait(1).to({scaleX:1.0451,scaleY:1.0451,x:192.95,y:24.4},0).wait(1).to({scaleX:1.0001,scaleY:1.0001,x:203.45,y:29.15},0).wait(1).to({scaleX:0.9581,scaleY:0.9581,x:213.3,y:33.6},0).wait(1).to({scaleX:0.9197,scaleY:0.9197,x:222.35,y:37.7},0).wait(1).to({scaleX:0.8851,scaleY:0.8851,x:230.5,y:41.35},0).wait(1).to({scaleX:0.8546,scaleY:0.8546,x:237.65,y:44.6},0).wait(1).to({scaleX:0.8281,scaleY:0.8281,x:243.85,y:47.4},0).wait(1).to({scaleX:0.8058,scaleY:0.8058,x:249.1,y:49.75},0).wait(1).to({scaleX:0.7874,scaleY:0.7874,x:253.45,y:51.7},0).wait(1).to({scaleX:0.7727,scaleY:0.7727,x:256.85,y:53.25},0).wait(1).to({scaleX:0.7617,scaleY:0.7617,x:259.45,y:54.45},0).wait(1).to({scaleX:0.7541,scaleY:0.7541,x:261.25,y:55.25},0).wait(1).to({scaleX:0.7497,scaleY:0.7497,x:262.25,y:55.7},0).wait(1).to({regX:26.2,regY:20.7,scaleX:0.7483,scaleY:0.7483,x:262.55},0).wait(1).to({regX:26.1,regY:20.6,x:262.5,y:55.6},0).wait(6).to({regX:26.2,regY:20.7,x:262.55,y:55.7},0).wait(1).to({regX:26.1,regY:20.6,x:262.5,y:55.6},0).wait(1).to({regX:26.2,regY:20.7,x:262.55,y:55.7},0).wait(1).to({regX:26.1,regY:20.6,scaleX:0.7482,scaleY:0.7482,x:262.4,y:55.55},0).wait(1).to({scaleX:0.7481,scaleY:0.7481,x:262.3,y:55.5},0).wait(1).to({scaleX:0.748,scaleY:0.748,x:262.1,y:55.4},0).wait(1).to({scaleX:0.7478,scaleY:0.7478,x:261.9,y:55.25},0).wait(1).to({scaleX:0.7476,scaleY:0.7476,x:261.6,y:55.05},0).wait(1).to({scaleX:0.7473,scaleY:0.7473,x:261.2,y:54.85},0).wait(1).to({scaleX:0.7469,scaleY:0.7469,x:260.75,y:54.55},0).wait(1).to({scaleX:0.7464,scaleY:0.7464,x:260.15,y:54.2},0).wait(1).to({scaleX:0.7459,scaleY:0.7459,x:259.4,y:53.7},0).wait(1).to({scaleX:0.7452,scaleY:0.7452,x:258.55,y:53.2},0).wait(1).to({scaleX:0.7443,scaleY:0.7443,x:257.5,y:52.55},0).wait(1).to({scaleX:0.7433,scaleY:0.7433,x:256.15,y:51.7},0).wait(1).to({scaleX:0.742,scaleY:0.742,x:254.5,y:50.7},0).wait(1).to({scaleX:0.7404,scaleY:0.7404,x:252.45,y:49.45},0).wait(1).to({scaleX:0.7383,scaleY:0.7383,x:249.8,y:47.8},0).wait(1).to({scaleX:0.7354,scaleY:0.7354,x:246.25,y:45.6},0).wait(1).to({scaleX:0.7315,scaleY:0.7315,x:241.3,y:42.5},0).wait(1).to({scaleX:0.7261,scaleY:0.7261,x:234.5,y:38.35},0).wait(1).to({scaleX:0.7203,scaleY:0.7203,x:227.15,y:33.85},0).wait(1).to({scaleX:0.7157,scaleY:0.7157,x:221.4,y:30.25},0).wait(1).to({scaleX:0.7124,scaleY:0.7124,x:217.2,y:27.7},0).wait(1).to({scaleX:0.71,scaleY:0.71,x:214.1,y:25.75},0).wait(1).to({scaleX:0.7081,scaleY:0.7081,x:211.7,y:24.3},0).wait(1).to({scaleX:0.7066,scaleY:0.7066,x:209.8,y:23.1},0).wait(1).to({scaleX:0.7053,scaleY:0.7053,x:208.25,y:22.2},0).wait(1).to({scaleX:0.7043,scaleY:0.7043,x:207,y:21.35},0).wait(1).to({scaleX:0.7035,scaleY:0.7035,x:205.95,y:20.75},0).wait(1).to({scaleX:0.7028,scaleY:0.7028,x:205.1,y:20.2},0).wait(1).to({scaleX:0.7022,scaleY:0.7022,x:204.35,y:19.7},0).wait(1).to({scaleX:0.7017,scaleY:0.7017,x:203.7,y:19.35},0).wait(1).to({scaleX:0.7013,scaleY:0.7013,x:203.2,y:19.05},0).wait(1).to({scaleX:0.701,scaleY:0.701,x:202.8,y:18.8},0).wait(1).to({scaleX:0.7007,scaleY:0.7007,x:202.45,y:18.6},0).wait(1).to({scaleX:0.7005,scaleY:0.7005,x:202.2,y:18.45},0).wait(1).to({scaleX:0.7004,scaleY:0.7004,x:202,y:18.3},0).wait(1).to({scaleX:0.7002,scaleY:0.7002,x:201.85,y:18.15},0).wait(1).to({x:201.7,y:18.1},0).wait(1).to({scaleX:0.7001,scaleY:0.7001,x:201.65,y:18.05},0).wait(1).to({regX:26.2,regY:20.8,x:201.7,y:18.15},0).to({_off:true},6).wait(2));

	// girl right icon.png
	this.instance_5 = new lib.girlrighticon();
	this.instance_5.setTransform(188.95,241.45,1,1,0,0,0,25.9,21.5);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({regY:21.6,scaleX:1.6102,scaleY:1.6102,x:212.35,y:215.9,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:26,regY:21.5,x:212.5,y:215.7},0).wait(23).to({regX:25.9,regY:21.6,x:212.35,y:215.9},0).wait(1).to({regX:26,regY:21.5,scaleX:1.5968,scaleY:1.5968,x:213.85,y:214.1},0).wait(1).to({scaleX:1.5811,scaleY:1.5811,x:215.45,y:212.15},0).wait(1).to({scaleX:1.5631,scaleY:1.5631,x:217.25,y:209.95},0).wait(1).to({scaleX:1.5427,scaleY:1.5427,x:219.3,y:207.5},0).wait(1).to({scaleX:1.5201,scaleY:1.5201,x:221.6,y:204.75},0).wait(1).to({scaleX:1.4952,scaleY:1.4952,x:224.15,y:201.7},0).wait(1).to({scaleX:1.4682,scaleY:1.4682,x:226.9,y:198.4},0).wait(1).to({scaleX:1.4394,scaleY:1.4394,x:229.8,y:194.95},0).wait(1).to({scaleX:1.4089,scaleY:1.4089,x:232.95,y:191.25},0).wait(1).to({scaleX:1.3772,scaleY:1.3772,x:236.15,y:187.35},0).wait(1).to({scaleX:1.3446,scaleY:1.3446,x:239.45,y:183.4},0).wait(1).to({scaleX:1.3115,scaleY:1.3115,x:242.8,y:179.4},0).wait(1).to({scaleX:1.2783,scaleY:1.2783,x:246.2,y:175.4},0).wait(1).to({scaleX:1.2456,scaleY:1.2456,x:249.5,y:171.4},0).wait(1).to({scaleX:1.2136,scaleY:1.2136,x:252.75,y:167.5},0).wait(1).to({scaleX:1.1829,scaleY:1.1829,x:255.85,y:163.8},0).wait(1).to({scaleX:1.1538,scaleY:1.1538,x:258.8,y:160.2},0).wait(1).to({scaleX:1.1265,scaleY:1.1265,x:261.6,y:156.9},0).wait(1).to({scaleX:1.1012,scaleY:1.1012,x:264.15,y:153.85},0).wait(1).to({scaleX:1.0782,scaleY:1.0782,x:266.5,y:151.05},0).wait(1).to({scaleX:1.0574,scaleY:1.0574,x:268.6,y:148.55},0).wait(1).to({scaleX:1.0391,scaleY:1.0391,x:270.45,y:146.3},0).wait(1).to({scaleX:1.023,scaleY:1.023,x:272.1,y:144.35},0).wait(1).to({scaleX:1.0094,scaleY:1.0094,x:273.5,y:142.65},0).wait(1).to({scaleX:0.998,scaleY:0.998,x:274.65,y:141.3},0).wait(1).to({scaleX:0.9889,scaleY:0.9889,x:275.55,y:140.2},0).wait(1).to({scaleX:0.982,scaleY:0.982,x:276.25,y:139.35},0).wait(1).to({scaleX:0.9772,scaleY:0.9772,x:276.75,y:138.75},0).wait(1).to({scaleX:0.9743,scaleY:0.9743,x:277.05,y:138.4},0).wait(1).to({regX:26.1,regY:21.7,scaleX:0.9734,scaleY:0.9734,x:277.1},0).wait(1).to({regX:26,regY:21.5,x:277,y:138.25},0).wait(6).to({regX:26.1,regY:21.7,x:277.1,y:138.4},0).wait(1).to({regX:26,regY:21.5,x:277,y:138.25},0).wait(2).to({regX:26.1,regY:21.7,x:277.1,y:138.4},0).wait(1).to({regX:26,regY:21.5,scaleX:0.9732,scaleY:0.9732,x:276.95,y:138.1},0).wait(1).to({scaleX:0.9727,scaleY:0.9727,x:276.9,y:137.9},0).wait(1).to({scaleX:0.972,scaleY:0.972,x:276.8,y:137.65},0).wait(1).to({scaleX:0.9711,scaleY:0.9711,x:276.7,y:137.25},0).wait(1).to({scaleX:0.9699,scaleY:0.9699,x:276.5,y:136.7},0).wait(1).to({scaleX:0.9683,scaleY:0.9683,x:276.35,y:136.05},0).wait(1).to({scaleX:0.9664,scaleY:0.9664,x:276.1,y:135.3},0).wait(1).to({scaleX:0.9641,scaleY:0.9641,x:275.75,y:134.3},0).wait(1).to({scaleX:0.9613,scaleY:0.9613,x:275.45,y:133.05},0).wait(1).to({scaleX:0.9579,scaleY:0.9579,x:275,y:131.65},0).wait(1).to({scaleX:0.9538,scaleY:0.9538,x:274.5,y:129.95},0).wait(1).to({scaleX:0.949,scaleY:0.949,x:273.85,y:127.9},0).wait(1).to({scaleX:0.9432,scaleY:0.9432,x:273.1,y:125.5},0).wait(1).to({scaleX:0.9361,scaleY:0.9361,x:272.2,y:122.5},0).wait(1).to({scaleX:0.9275,scaleY:0.9275,x:271.1,y:118.85},0).wait(1).to({scaleX:0.9167,scaleY:0.9167,x:269.7,y:114.3},0).wait(1).to({scaleX:0.9028,scaleY:0.9028,x:267.9,y:108.45},0).wait(1).to({scaleX:0.8845,scaleY:0.8845,x:265.6,y:100.75},0).wait(1).to({scaleX:0.8596,scaleY:0.8596,x:262.4,y:90.25},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,x:258.2,y:76.55},0).wait(1).to({scaleX:0.7931,scaleY:0.7931,x:253.85,y:62.2},0).wait(1).to({scaleX:0.7659,scaleY:0.7659,x:250.35,y:50.7},0).wait(1).to({scaleX:0.7457,scaleY:0.7457,x:247.8,y:42.25},0).wait(1).to({scaleX:0.7304,scaleY:0.7304,x:245.8,y:35.75},0).wait(1).to({scaleX:0.7184,scaleY:0.7184,x:244.3,y:30.75},0).wait(1).to({scaleX:0.7088,scaleY:0.7088,x:243.05,y:26.7},0).wait(1).to({scaleX:0.7009,scaleY:0.7009,x:242,y:23.35},0).wait(1).to({scaleX:0.6943,scaleY:0.6943,x:241.2,y:20.6},0).wait(1).to({scaleX:0.6888,scaleY:0.6888,x:240.45,y:18.25},0).wait(1).to({scaleX:0.6841,scaleY:0.6841,x:239.9,y:16.3},0).wait(1).to({scaleX:0.6802,scaleY:0.6802,x:239.4,y:14.6},0).wait(1).to({scaleX:0.6768,scaleY:0.6768,x:238.95,y:13.25},0).wait(1).to({scaleX:0.6739,scaleY:0.6739,x:238.55,y:12.05},0).wait(1).to({scaleX:0.6715,scaleY:0.6715,x:238.25,y:11.05},0).wait(1).to({scaleX:0.6695,scaleY:0.6695,x:238,y:10.15},0).wait(1).to({scaleX:0.6678,scaleY:0.6678,x:237.75,y:9.45},0).wait(1).to({scaleX:0.6664,scaleY:0.6664,x:237.6,y:8.9},0).wait(1).to({scaleX:0.6653,scaleY:0.6653,x:237.45,y:8.4},0).wait(1).to({scaleX:0.6644,scaleY:0.6644,x:237.3,y:8.05},0).wait(1).to({scaleX:0.6638,scaleY:0.6638,x:237.25,y:7.75},0).wait(1).to({scaleX:0.6633,scaleY:0.6633,x:237.2,y:7.55},0).wait(1).to({scaleX:0.6631,scaleY:0.6631,y:7.45},0).wait(1).to({regX:26.3,regY:21.7,scaleX:0.663,scaleY:0.663,x:237.3,y:7.55},0).to({_off:true},1).wait(2));

	// girl left icon.png
	this.instance_6 = new lib.girllefticon();
	this.instance_6.setTransform(-119.4,159.2,1,1,0,0,0,25.3,21.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(22).to({_off:false},0).to({regX:25.4,regY:21.4,scaleX:1.6102,scaleY:1.6102,x:36.25,y:122.05,alpha:1},41,cjs.Ease.quadOut).wait(1).to({regY:21.3,y:121.9},0).wait(25).to({regY:21.4,y:122.05},0).wait(1).to({regY:21.3,scaleX:1.6029,scaleY:1.6029,x:38.2,y:121.6},0).wait(1).to({scaleX:1.5931,scaleY:1.5931,x:40.75,y:121.25},0).wait(1).to({scaleX:1.5806,scaleY:1.5806,x:44.1,y:120.8},0).wait(1).to({scaleX:1.5652,scaleY:1.5652,x:48.15,y:120.25},0).wait(1).to({scaleX:1.5468,scaleY:1.5468,x:53.1,y:119.6},0).wait(1).to({scaleX:1.5252,scaleY:1.5252,x:58.8,y:118.8},0).wait(1).to({scaleX:1.5004,scaleY:1.5004,x:65.4,y:117.9},0).wait(1).to({scaleX:1.4723,scaleY:1.4723,x:72.85,y:116.85},0).wait(1).to({scaleX:1.4408,scaleY:1.4408,x:81.2,y:115.75},0).wait(1).to({scaleX:1.4061,scaleY:1.4061,x:90.4,y:114.5},0).wait(1).to({scaleX:1.3683,scaleY:1.3683,x:100.45,y:113.1},0).wait(1).to({scaleX:1.3278,scaleY:1.3278,x:111.25,y:111.65},0).wait(1).to({scaleX:1.2848,scaleY:1.2848,x:122.7,y:110.05},0).wait(1).to({scaleX:1.2399,scaleY:1.2399,x:134.6,y:108.45},0).wait(1).to({scaleX:1.1939,scaleY:1.1939,x:146.85,y:106.8},0).wait(1).to({scaleX:1.1475,scaleY:1.1475,x:159.15,y:105.1},0).wait(1).to({scaleX:1.1014,scaleY:1.1014,x:171.4,y:103.45},0).wait(1).to({scaleX:1.0566,scaleY:1.0566,x:183.3,y:101.8},0).wait(1).to({scaleX:1.0136,scaleY:1.0136,x:194.75,y:100.3},0).wait(1).to({scaleX:0.9731,scaleY:0.9731,x:205.45,y:98.8},0).wait(1).to({scaleX:0.9357,scaleY:0.9357,x:215.4,y:97.45},0).wait(1).to({scaleX:0.9015,scaleY:0.9015,x:224.5,y:96.2},0).wait(1).to({scaleX:0.871,scaleY:0.871,x:232.6,y:95.1},0).wait(1).to({scaleX:0.844,scaleY:0.844,x:239.75,y:94.15},0).wait(1).to({scaleX:0.8208,scaleY:0.8208,x:245.95,y:93.3},0).wait(1).to({scaleX:0.8011,scaleY:0.8011,x:251.2,y:92.55},0).wait(1).to({scaleX:0.7849,scaleY:0.7849,x:255.5,y:91.95},0).wait(1).to({scaleX:0.772,scaleY:0.772,x:258.9,y:91.5},0).wait(1).to({scaleX:0.7622,scaleY:0.7622,x:261.5,y:91.2},0).wait(1).to({scaleX:0.7555,scaleY:0.7555,x:263.3,y:90.95},0).wait(1).to({scaleX:0.7516,scaleY:0.7516,x:264.35,y:90.75},0).wait(1).to({regY:21.6,scaleX:0.7503,scaleY:0.7503,x:264.65,y:90.9},0).wait(1).to({regY:21.3,y:90.7},0).wait(4).to({regY:21.6,y:90.9},0).wait(1).to({regY:21.3,y:90.7},0).wait(4).to({regY:21.6,y:90.9},0).wait(1).to({regY:21.3,scaleX:0.7502,scaleY:0.7502,y:90.6},0).wait(1).to({scaleX:0.7501,scaleY:0.7501,y:90.45},0).wait(1).to({scaleX:0.7499,scaleY:0.7499,y:90.2},0).wait(1).to({scaleX:0.7496,scaleY:0.7496,x:264.7,y:89.9},0).wait(1).to({scaleX:0.7492,scaleY:0.7492,x:264.75,y:89.45},0).wait(1).to({scaleX:0.7488,scaleY:0.7488,y:88.95},0).wait(1).to({scaleX:0.7482,scaleY:0.7482,x:264.8,y:88.3},0).wait(1).to({scaleX:0.7474,scaleY:0.7474,x:264.9,y:87.5},0).wait(1).to({scaleX:0.7466,scaleY:0.7466,x:264.95,y:86.55},0).wait(1).to({scaleX:0.7455,scaleY:0.7455,x:265.05,y:85.4},0).wait(1).to({scaleX:0.7442,scaleY:0.7442,x:265.15,y:83.95},0).wait(1).to({scaleX:0.7427,scaleY:0.7427,x:265.3,y:82.25},0).wait(1).to({scaleX:0.7408,scaleY:0.7408,x:265.45,y:80.2},0).wait(1).to({scaleX:0.7385,scaleY:0.7385,x:265.65,y:77.65},0).wait(1).to({scaleX:0.7356,scaleY:0.7356,x:265.95,y:74.4},0).wait(1).to({scaleX:0.7319,scaleY:0.7319,x:266.25,y:70.3},0).wait(1).to({scaleX:0.7269,scaleY:0.7269,x:266.7,y:64.8},0).wait(1).to({scaleX:0.72,scaleY:0.72,x:267.3,y:57.25},0).wait(1).to({scaleX:0.7108,scaleY:0.7108,x:268.1,y:47.1},0).wait(1).to({scaleX:0.7011,scaleY:0.7011,x:268.95,y:36.3},0).wait(1).to({scaleX:0.6932,scaleY:0.6932,x:269.65,y:27.6},0).wait(1).to({scaleX:0.6875,scaleY:0.6875,x:270.15,y:21.35},0).wait(1).to({scaleX:0.6833,scaleY:0.6833,x:270.55,y:16.6},0).wait(1).to({scaleX:0.6799,scaleY:0.6799,x:270.8,y:13},0).wait(1).to({scaleX:0.6773,scaleY:0.6773,x:271.05,y:10.05},0).wait(1).to({scaleX:0.6751,scaleY:0.6751,x:271.25,y:7.7},0).wait(1).to({scaleX:0.6733,scaleY:0.6733,x:271.4,y:5.7},0).wait(1).to({scaleX:0.6718,scaleY:0.6718,x:271.55,y:4},0).wait(1).to({scaleX:0.6706,scaleY:0.6706,x:271.65,y:2.65},0).wait(1).to({scaleX:0.6695,scaleY:0.6695,x:271.75,y:1.45},0).wait(1).to({scaleX:0.6686,scaleY:0.6686,x:271.85,y:0.5},0).wait(1).to({scaleX:0.6679,scaleY:0.6679,x:271.9,y:-0.35},0).wait(1).to({scaleX:0.6672,scaleY:0.6672,x:271.95,y:-1.05},0).wait(1).to({scaleX:0.6667,scaleY:0.6667,x:272,y:-1.6},0).wait(1).to({scaleX:0.6663,scaleY:0.6663,y:-2.1},0).wait(1).to({scaleX:0.6659,scaleY:0.6659,x:272.05,y:-2.45},0).wait(1).to({scaleX:0.6657,scaleY:0.6657,x:272.1,y:-2.75},0).wait(1).to({scaleX:0.6655,scaleY:0.6655,y:-3},0).wait(1).to({scaleX:0.6654,scaleY:0.6654,y:-3.15},0).wait(1).to({scaleX:0.6653,scaleY:0.6653,y:-3.25},0).wait(1).to({regY:21.4,x:272.15,y:-3.05},0).to({_off:true},1).wait(2));

	// guy right contribution
	this.instance_7 = new lib.guyrightcontribution();
	this.instance_7.setTransform(240.6,-78.2,1,1,0,0,0,38.1,26.2);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(29).to({_off:false},0).to({regY:26.1,scaleX:1.6102,scaleY:1.6102,x:328.35,y:-52.95,alpha:1},37,cjs.Ease.quadOut).wait(1).to({regX:37.5,regY:26,x:327.4,y:-53.15},0).wait(22).to({regX:38.1,regY:26.1,x:328.35,y:-52.95},0).wait(1).to({regX:37.5,regY:26,scaleX:1.6047,scaleY:1.604,x:327.4,y:-52.35},0).wait(1).to({scaleX:1.5972,scaleY:1.5955,skewY:-0.0564,x:327.35,y:-51.3},0).wait(1).to({scaleX:1.5876,scaleY:1.5845,skewY:-0.0987,x:327.4,y:-50},0).wait(1).to({scaleX:1.5755,scaleY:1.5708,skewY:-0.1512,y:-48.35},0).wait(1).to({scaleX:1.561,scaleY:1.5543,skewY:-0.2147,y:-46.35},0).wait(1).to({scaleX:1.5438,scaleY:1.5348,skewY:-0.2897,y:-44},0).wait(1).to({scaleX:1.5239,scaleY:1.5121,skewY:-0.3768,y:-41.3},0).wait(1).to({scaleX:1.501,scaleY:1.4862,skewY:-0.4765,x:327.45,y:-38.1},0).wait(1).to({scaleX:1.4753,scaleY:1.4569,skewY:-0.5889,x:327.4,y:-34.55},0).wait(1).to({scaleX:1.4467,scaleY:1.4244,skewY:-0.7138,x:327.45,y:-30.7},0).wait(1).to({scaleX:1.4153,scaleY:1.3889,skewY:-0.8504,y:-26.4},0).wait(1).to({scaleX:1.3816,scaleY:1.3506,skewY:-0.9974,x:327.5,y:-21.75},0).wait(1).to({scaleX:1.3461,scaleY:1.3102,skewY:-1.1527,y:-16.85},0).wait(1).to({scaleX:1.3093,scaleY:1.2684,skewY:-1.3135,x:327.55,y:-11.75},0).wait(1).to({scaleX:1.2719,scaleY:1.226,skewY:-1.4763,x:327.6,y:-6.7},0).wait(1).to({scaleX:1.235,scaleY:1.1841,skewY:-1.6374,y:-1.6},0).wait(1).to({scaleX:1.1994,scaleY:1.1436,skewY:-1.7929,y:3.3},0).wait(1).to({scaleX:1.1658,scaleY:1.1054,skewY:-1.9396,x:327.65,y:7.85},0).wait(1).to({scaleX:1.1348,scaleY:1.0702,skewY:-2.0749,x:327.7,y:12.15},0).wait(1).to({scaleX:1.1068,scaleY:1.0385,skewY:-2.1969,x:327.65,y:15.95},0).wait(1).to({scaleX:1.0822,scaleY:1.0105,skewY:-2.3046,x:327.7,y:19.3},0).wait(1).to({scaleX:1.0609,scaleY:0.9863,skewY:-2.3975,y:22.3},0).wait(1).to({scaleX:1.0429,scaleY:0.9659,skewY:-2.4758,y:24.65},0).wait(1).to({scaleX:1.0282,scaleY:0.9492,skewY:-2.5399,y:26.7},0).wait(1).to({scaleX:1.0166,scaleY:0.9361,skewY:-2.5905,x:327.75,y:28.3},0).wait(1).to({scaleX:1.008,scaleY:0.9262,skewY:-2.6284,x:327.7,y:29.5},0).wait(1).to({scaleX:1.002,scaleY:0.9194,skewY:-2.6544,x:327.75,y:30.3},0).wait(1).to({scaleX:0.9986,scaleY:0.9155,skewY:-2.6694,y:30.75},0).wait(1).to({regX:38.4,regY:26.3,scaleX:0.9974,scaleY:0.9143,skewY:-2.6743,x:328.45,y:30.95},0).to({_off:true},55).wait(2));

	// guy left contribution
	this.instance_8 = new lib.guyleftcontribution_1();
	this.instance_8.setTransform(-59.8,65.85,1,1,0,0,0,30.4,9.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(33).to({_off:false},0).to({regY:9.7,scaleX:1.6102,scaleY:1.6102,x:137.8,y:-18.7,alpha:1},33,cjs.Ease.quadOut).wait(1).to({regX:30.5,x:137.95},0).wait(22).to({regX:30.4,x:137.8},0).wait(1).to({regX:30.5,scaleX:1.6027,scaleY:1.6028,skewX:-0.0654,skewY:-0.0111,x:139.15,y:-17.85},0).wait(1).to({scaleX:1.5925,scaleY:1.5927,skewX:-0.1546,skewY:-0.0262,x:140.8,y:-16.75},0).wait(1).to({scaleX:1.5795,scaleY:1.5798,skewX:-0.2691,skewY:-0.0455,x:142.9,y:-15.45},0).wait(1).to({scaleX:1.5633,scaleY:1.5638,skewX:-0.4108,skewY:-0.0695,x:145.6,y:-13.7},0).wait(1).to({scaleX:1.5439,scaleY:1.5446,skewX:-0.5815,skewY:-0.0984,x:148.8,y:-11.65},0).wait(1).to({scaleX:1.5209,scaleY:1.5218,skewX:-0.7831,skewY:-0.1325,x:152.6,y:-9.2},0).wait(1).to({scaleX:1.4942,scaleY:1.4954,skewX:-1.0171,skewY:-0.1722,x:156.9,y:-6.4},0).wait(1).to({scaleX:1.4636,scaleY:1.4651,skewX:-1.2851,skewY:-0.2175,x:161.95,y:-3.1},0).wait(1).to({scaleX:1.4291,scaleY:1.4309,skewX:-1.5878,skewY:-0.2688,x:167.65,y:0.5},0).wait(1).to({scaleX:1.3906,scaleY:1.3928,skewX:-1.9255,skewY:-0.3259,x:173.9,y:4.6},0).wait(1).to({scaleX:1.3483,scaleY:1.3509,skewX:-2.2971,skewY:-0.3888,x:180.85,y:9.1},0).wait(1).to({scaleX:1.3023,scaleY:1.3053,skewX:-2.7,skewY:-0.457,x:188.4,y:13.95},0).wait(1).to({scaleX:1.2533,scaleY:1.2568,skewX:-3.1299,skewY:-0.5298,x:196.4,y:19.1},0).wait(1).to({scaleX:1.202,scaleY:1.206,skewX:-3.5802,skewY:-0.606,x:204.85,y:24.6},0).wait(1).to({scaleX:1.1492,scaleY:1.1538,skewX:-4.0427,skewY:-0.6843,x:213.5,y:30.15},0).wait(1).to({scaleX:1.0962,scaleY:1.1013,skewX:-4.5072,skewY:-0.7629,x:222.2,y:35.75},0).wait(1).to({scaleX:1.0442,scaleY:1.0499,skewX:-4.9633,skewY:-0.8401,x:230.7,y:41.3},0).wait(1).to({scaleX:0.9943,scaleY:1.0004,skewX:-5.401,skewY:-0.9142,x:238.85,y:46.55},0).wait(1).to({scaleX:0.9475,scaleY:0.9541,skewX:-5.8114,skewY:-0.9836,x:246.55,y:51.55},0).wait(1).to({scaleX:0.9046,scaleY:0.9116,skewX:-6.188,skewY:-1.0474,x:253.6,y:56.1},0).wait(1).to({scaleX:0.866,scaleY:0.8734,skewX:-6.5262,skewY:-1.1046,x:259.85,y:60.2},0).wait(1).to({scaleX:0.8321,scaleY:0.8399,skewX:-6.8236,skewY:-1.155,x:265.4,y:63.8},0).wait(1).to({scaleX:0.8029,scaleY:0.8109,skewX:-7.0797,skewY:-1.1983,x:270.25,y:66.9},0).wait(1).to({scaleX:0.7784,scaleY:0.7866,skewX:-7.295,skewY:-1.2347,x:274.25,y:69.45},0).wait(1).to({scaleX:0.7583,scaleY:0.7667,skewX:-7.4711,skewY:-1.2646,x:277.5,y:71.6},0).wait(1).to({scaleX:0.7425,scaleY:0.7511,skewX:-7.61,skewY:-1.2881,x:280.15,y:73.25},0).wait(1).to({scaleX:0.7306,scaleY:0.7393,skewX:-7.7139,skewY:-1.3056,x:282.1,y:74.55},0).wait(1).to({scaleX:0.7225,scaleY:0.7313,skewX:-7.7853,skewY:-1.3177,x:283.45,y:75.45},0).wait(1).to({scaleX:0.7178,scaleY:0.7266,skewX:-7.8265,skewY:-1.3247,x:284.2,y:75.95},0).wait(1).to({regX:30.7,regY:10,scaleX:0.7163,scaleY:0.7251,skewX:-7.8397,skewY:-1.3269,x:284.5,y:76.15},0).to({_off:true},54).wait(2));

	// girl left contribution
	this.instance_9 = new lib.girlleftcontribution();
	this.instance_9.setTransform(-71.15,171.05,1,1,0,0,0,44,32.3);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(22).to({_off:false},0).to({regX:44.1,regY:32.4,scaleX:1.6102,scaleY:1.6102,x:113.8,y:141.15,alpha:1},42,cjs.Ease.quadOut).wait(1).to({regX:44.6,regY:32.3,x:114.6,y:141},0).wait(24).to({regX:44.1,regY:32.4,x:113.8,y:141.15},0).wait(1).to({regX:44.6,regY:32.3,scaleX:1.6018,scaleY:1.6018,x:116.1,y:140.65},0).wait(1).to({scaleX:1.5905,scaleY:1.5905,x:118.2,y:140.2},0).wait(1).to({scaleX:1.5761,scaleY:1.5761,x:120.8,y:139.65},0).wait(1).to({scaleX:1.5582,scaleY:1.5582,x:124.05,y:138.95},0).wait(1).to({scaleX:1.5368,scaleY:1.5368,x:127.95,y:138.15},0).wait(1).to({scaleX:1.5116,scaleY:1.5116,x:132.5,y:137.1},0).wait(1).to({scaleX:1.4824,scaleY:1.4824,x:137.8,y:136},0).wait(1).to({scaleX:1.4491,scaleY:1.4491,x:143.9,y:134.7},0).wait(1).to({scaleX:1.4116,scaleY:1.4116,x:150.7,y:133.2},0).wait(1).to({scaleX:1.3699,scaleY:1.3699,x:158.3,y:131.6},0).wait(1).to({scaleX:1.3242,scaleY:1.3242,x:166.6,y:129.8},0).wait(1).to({scaleX:1.2746,scaleY:1.2746,x:175.65,y:127.85},0).wait(1).to({scaleX:1.2218,scaleY:1.2218,x:185.25,y:125.8},0).wait(1).to({scaleX:1.1663,scaleY:1.1663,x:195.35,y:123.6},0).wait(1).to({scaleX:1.1092,scaleY:1.1092,x:205.7,y:121.4},0).wait(1).to({scaleX:1.0514,scaleY:1.0514,x:216.25,y:119.1},0).wait(1).to({scaleX:0.9943,scaleY:0.9943,x:226.65,y:116.9},0).wait(1).to({scaleX:0.9388,scaleY:0.9388,x:236.75,y:114.7},0).wait(1).to({scaleX:0.8861,scaleY:0.8861,x:246.3,y:112.65},0).wait(1).to({scaleX:0.837,scaleY:0.837,x:255.3,y:110.75},0).wait(1).to({scaleX:0.7922,scaleY:0.7922,x:263.45,y:109},0).wait(1).to({scaleX:0.7521,scaleY:0.7521,x:270.75,y:107.45},0).wait(1).to({scaleX:0.7168,scaleY:0.7168,x:277.1,y:106.05},0).wait(1).to({scaleX:0.6864,scaleY:0.6864,x:282.65,y:104.85},0).wait(1).to({scaleX:0.6608,scaleY:0.6608,x:287.3,y:103.85},0).wait(1).to({scaleX:0.6398,scaleY:0.6398,x:291.15,y:103},0).wait(1).to({scaleX:0.6232,scaleY:0.6232,x:294.2,y:102.4},0).wait(1).to({scaleX:0.6107,scaleY:0.6107,x:296.45,y:101.95},0).wait(1).to({scaleX:0.6021,scaleY:0.6021,x:298,y:101.55},0).wait(1).to({scaleX:0.5971,scaleY:0.5971,x:298.95,y:101.4},0).wait(1).to({regX:44.3,regY:32.6,scaleX:0.5955,scaleY:0.5955,y:101.35},0).to({_off:true},53).wait(2));

	// girl rigth contribution
	this.instance_10 = new lib.girlrigthcontribution();
	this.instance_10.setTransform(253.5,242.7,1,1,0,0,0,39.1,19.1);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(25).to({_off:false},0).to({regY:19.2,scaleX:1.6102,scaleY:1.6102,x:316.3,y:217.9,alpha:1},40,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:316.15,y:217.6},0).wait(23).to({regX:39.1,regY:19.2,x:316.3,y:217.9},0).wait(1).to({regX:39,regY:19,scaleX:1.6028,scaleY:1.6028,x:316.1,y:216.85},0).wait(1).to({scaleX:1.593,scaleY:1.593,x:316.05,y:215.95},0).wait(1).to({scaleX:1.5805,scaleY:1.5805,x:316,y:214.8},0).wait(1).to({scaleX:1.5652,scaleY:1.5652,x:315.9,y:213.35},0).wait(1).to({scaleX:1.5469,scaleY:1.5469,x:315.85,y:211.65},0).wait(1).to({scaleX:1.5254,scaleY:1.5254,x:315.7,y:209.6},0).wait(1).to({scaleX:1.5004,scaleY:1.5004,x:315.55,y:207.25},0).wait(1).to({scaleX:1.4719,scaleY:1.4719,x:315.45,y:204.55},0).wait(1).to({scaleX:1.4396,scaleY:1.4396,x:315.3,y:201.55},0).wait(1).to({scaleX:1.4035,scaleY:1.4035,x:315.15,y:198.15},0).wait(1).to({scaleX:1.3636,scaleY:1.3636,x:314.95,y:194.4},0).wait(1).to({scaleX:1.32,scaleY:1.32,x:314.7,y:190.3},0).wait(1).to({scaleX:1.273,scaleY:1.273,x:314.5,y:185.9},0).wait(1).to({scaleX:1.2229,scaleY:1.2229,x:314.25,y:181.2},0).wait(1).to({scaleX:1.1705,scaleY:1.1705,x:314,y:176.25},0).wait(1).to({scaleX:1.1166,scaleY:1.1166,x:313.7,y:171.15},0).wait(1).to({scaleX:1.0622,scaleY:1.0622,x:313.45,y:166.1},0).wait(1).to({scaleX:1.0086,scaleY:1.0086,x:313.2,y:161},0).wait(1).to({scaleX:0.9567,scaleY:0.9567,x:312.9,y:156.15},0).wait(1).to({scaleX:0.9076,scaleY:0.9076,x:312.7,y:151.55},0).wait(1).to({scaleX:0.862,scaleY:0.862,x:312.45,y:147.25},0).wait(1).to({scaleX:0.8206,scaleY:0.8206,x:312.25,y:143.35},0).wait(1).to({scaleX:0.7836,scaleY:0.7836,x:312.1,y:139.9},0).wait(1).to({scaleX:0.7512,scaleY:0.7512,x:311.95,y:136.8},0).wait(1).to({scaleX:0.7234,scaleY:0.7234,x:311.8,y:134.25},0).wait(1).to({scaleX:0.7001,scaleY:0.7001,x:311.7,y:132.05},0).wait(1).to({scaleX:0.681,scaleY:0.681,x:311.6,y:130.25},0).wait(1).to({scaleX:0.666,scaleY:0.666,x:311.5,y:128.8},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:311.45,y:127.8},0).wait(1).to({scaleX:0.647,scaleY:0.647,y:127.05},0).wait(1).to({scaleX:0.6426,scaleY:0.6426,x:311.4,y:126.6},0).wait(1).to({regX:39.3,regY:19.4,scaleX:0.6411,scaleY:0.6411,x:311.55,y:126.65},0).to({_off:true},52).wait(2));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_22 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_66 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_67 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_68 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_69 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_70 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_71 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_72 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_73 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_74 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_75 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_76 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_77 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_78 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_79 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_80 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_81 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_82 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_83 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_84 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_85 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_86 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_87 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_88 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_89 = new cjs.Graphics().p("A/tkrQAtgRYpnmQMTj0MUjyINeZBMgxwAPQg");
	var mask_graphics_90 = new cjs.Graphics().p("A/skqQAtgSYlnlIYqnnINdZBMgxvAPQg");
	var mask_graphics_91 = new cjs.Graphics().p("A/skrQAvgSYenjIYvnoINdZAMgxuAPRg");
	var mask_graphics_92 = new cjs.Graphics().p("A/rkrQAygSYUngIY0nqINdY/MgxtAPQg");
	var mask_graphics_93 = new cjs.Graphics().p("A/qksQA1gTYGnbIY9nsINdY9MgxrAPQg");
	var mask_graphics_94 = new cjs.Graphics().p("A/oksQA5gUX1nVIZHnwINcY8MgxoAPPg");
	var mask_graphics_95 = new cjs.Graphics().p("A/mksQA+gWXgnOIZUn0INbY6MgxlAPPg");
	var mask_graphics_96 = new cjs.Graphics().p("A/kktQBEgYXInFQMZj0NKkEINaY3MgxhAPOg");
	var mask_graphics_97 = new cjs.Graphics().p("A/iktQBMgaWqm8QMcj0NZkKINaY1MgxeAPOg");
	var mask_graphics_98 = new cjs.Graphics().p("A/fkuQBUgdWJmwQMdj0NskQINZYyMgxZAPNg");
	var mask_graphics_99 = new cjs.Graphics().p("A/ckvQBdgfVlmlQMgjyN/kYINYYvMgxUAPMg");
	var mask_graphics_100 = new cjs.Graphics().p("A/ZkwQBnghU9mYQMjjzOVkeINXYrMgxOAPKg");
	var mask_graphics_101 = new cjs.Graphics().p("A/VkwQBxglUSmJQMmjzOtkmINVYmMgxIAPJg");
	var mask_graphics_102 = new cjs.Graphics().p("A/RkxQB8goTll7QMojyPGkuINUYhMgxBAPJg");
	var mask_graphics_103 = new cjs.Graphics().p("A/NkyQCHgrS4lrQMrjzPfk3INSYeMgw7APHg");
	var mask_graphics_104 = new cjs.Graphics().p("A/JkzQCSgvSKlbQMujyP4lAINRYZMgw0APGg");
	var mask_graphics_105 = new cjs.Graphics().p("A/Fk0QCdgxRelOQMxjyQQlHINPYVMgwtAPEg");
	var mask_graphics_106 = new cjs.Graphics().p("A/Bk1QCng0Q0lAQMzjxQnlQINOYRMgwnAPEg");
	var mask_graphics_107 = new cjs.Graphics().p("A++k2QCwg3QOkyQM2jxQ8lYINNYOMgwiAPCg");
	var mask_graphics_108 = new cjs.Graphics().p("A+7k3QC5g5PqknQM5jxRPldINMYJMgwcAPCg");
	var mask_graphics_109 = new cjs.Graphics().p("A+4k4QDAg7PLkbQM6jyRhljINLYGMgwYAPCg");
	var mask_graphics_110 = new cjs.Graphics().p("A+2k4QDIg9OukTQM+jxRvloINKYEMgwUAO/g");
	var mask_graphics_111 = new cjs.Graphics().p("A+0k4QDOhAOWkKQM/jxR8ltINKYCMgwRAO/g");
	var mask_graphics_112 = new cjs.Graphics().p("A+yk5QDThBOBkDQNAjxSIlxINJYAMgwNAO/g");
	var mask_graphics_113 = new cjs.Graphics().p("A+xk5QDXhCNwj+QNBjxSSl0INJX+MgwMAO/g");
	var mask_graphics_114 = new cjs.Graphics().p("A+vk6QDahDNij4QNCjxSZl3INIX9MgwIAO+g");
	var mask_graphics_115 = new cjs.Graphics().p("A+uk6QDdhENWj1QNDjwSgl5INHX7MgwHAO+g");
	var mask_graphics_116 = new cjs.Graphics().p("A+uk6QDfhENOjyQNEjxSll7INGX7MgwGAO+g");
	var mask_graphics_117 = new cjs.Graphics().p("A+tk6QDhhFNHjwQNFjxSnl7INHX6MgwFAO9g");
	var mask_graphics_118 = new cjs.Graphics().p("A+tk6QDihFNEjvQNEjxSql8INHX6MgwFAO9g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(22).to({graphics:mask_graphics_22,x:234.025,y:87.875}).wait(44).to({graphics:mask_graphics_66,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_67,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_68,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_69,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_70,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_71,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_72,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_73,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_74,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_75,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_76,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_77,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_78,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_79,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_80,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_81,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_82,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_83,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_84,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_85,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_86,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_87,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_88,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_89,x:234.025,y:87.875}).wait(1).to({graphics:mask_graphics_90,x:234.125,y:87.9}).wait(1).to({graphics:mask_graphics_91,x:234.3,y:87.975}).wait(1).to({graphics:mask_graphics_92,x:234.55,y:88.05}).wait(1).to({graphics:mask_graphics_93,x:234.875,y:88.175}).wait(1).to({graphics:mask_graphics_94,x:235.275,y:88.3}).wait(1).to({graphics:mask_graphics_95,x:235.8,y:88.475}).wait(1).to({graphics:mask_graphics_96,x:236.375,y:88.675}).wait(1).to({graphics:mask_graphics_97,x:237.075,y:88.925}).wait(1).to({graphics:mask_graphics_98,x:237.9,y:89.2}).wait(1).to({graphics:mask_graphics_99,x:238.775,y:89.5}).wait(1).to({graphics:mask_graphics_100,x:239.75,y:89.85}).wait(1).to({graphics:mask_graphics_101,x:240.775,y:90.175}).wait(1).to({graphics:mask_graphics_102,x:241.875,y:90.55}).wait(1).to({graphics:mask_graphics_103,x:242.975,y:90.925}).wait(1).to({graphics:mask_graphics_104,x:244.075,y:91.3}).wait(1).to({graphics:mask_graphics_105,x:245.125,y:91.675}).wait(1).to({graphics:mask_graphics_106,x:246.15,y:92.025}).wait(1).to({graphics:mask_graphics_107,x:247.1,y:92.35}).wait(1).to({graphics:mask_graphics_108,x:247.95,y:92.65}).wait(1).to({graphics:mask_graphics_109,x:248.725,y:92.9}).wait(1).to({graphics:mask_graphics_110,x:249.4,y:93.15}).wait(1).to({graphics:mask_graphics_111,x:250,y:93.35}).wait(1).to({graphics:mask_graphics_112,x:250.5,y:93.525}).wait(1).to({graphics:mask_graphics_113,x:250.95,y:93.675}).wait(1).to({graphics:mask_graphics_114,x:251.275,y:93.8}).wait(1).to({graphics:mask_graphics_115,x:251.525,y:93.875}).wait(1).to({graphics:mask_graphics_116,x:251.75,y:93.95}).wait(1).to({graphics:mask_graphics_117,x:251.9,y:94}).wait(1).to({graphics:mask_graphics_118,x:251.975,y:94.025}).wait(57));

	// r guy i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(188.7,-72.65,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(29).to({_off:false},0).to({regX:28.3,regY:22.7,scaleX:1.6102,scaleY:1.6102,x:251.7,y:-35.7,alpha:0.1602},36,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.8,x:251.25,y:-35.55},0).wait(23).to({regX:28.3,regY:22.7,x:251.7,y:-35.7},0).wait(1).to({regX:28,regY:22.8,scaleX:1.6047,scaleY:1.6047,x:251.6,y:-34.95},0).wait(1).to({scaleX:1.5972,scaleY:1.5972,x:252.1,y:-34.15},0).wait(1).to({scaleX:1.5874,scaleY:1.5874,x:252.8,y:-33.15},0).wait(1).to({scaleX:1.5752,scaleY:1.5752,x:253.65,y:-31.85},0).wait(1).to({scaleX:1.5604,scaleY:1.5604,x:254.65,y:-30.3},0).wait(1).to({scaleX:1.5429,scaleY:1.5429,x:255.9,y:-28.45},0).wait(1).to({scaleX:1.5223,scaleY:1.5223,x:257.35,y:-26.35},0).wait(1).to({scaleX:1.4987,scaleY:1.4987,x:258.95,y:-23.9},0).wait(1).to({scaleX:1.472,scaleY:1.472,x:260.8,y:-21.1},0).wait(1).to({scaleX:1.4421,scaleY:1.4421,x:262.9,y:-17.9},0).wait(1).to({scaleX:1.4092,scaleY:1.4092,x:265.15,y:-14.5},0).wait(1).to({scaleX:1.3737,scaleY:1.3737,x:267.6,y:-10.8},0).wait(1).to({scaleX:1.336,scaleY:1.336,x:270.2,y:-6.85},0).wait(1).to({scaleX:1.2971,scaleY:1.2971,x:272.9,y:-2.8},0).wait(1).to({scaleX:1.2578,scaleY:1.2578,x:275.65,y:1.35},0).wait(1).to({scaleX:1.2192,scaleY:1.2192,x:278.35,y:5.35},0).wait(1).to({scaleX:1.1823,scaleY:1.1823,x:280.9,y:9.2},0).wait(1).to({scaleX:1.148,scaleY:1.148,x:283.3,y:12.8},0).wait(1).to({scaleX:1.117,scaleY:1.117,x:285.4,y:16.05},0).wait(1).to({scaleX:1.0895,scaleY:1.0895,x:287.35,y:18.95},0).wait(1).to({scaleX:1.0659,scaleY:1.0659,x:289,y:21.4},0).wait(1).to({scaleX:1.046,scaleY:1.046,x:290.35,y:23.5},0).wait(1).to({scaleX:1.0298,scaleY:1.0298,x:291.5,y:25.15},0).wait(1).to({scaleX:1.017,scaleY:1.017,x:292.4,y:26.45},0).wait(1).to({scaleX:1.0076,scaleY:1.0076,x:293,y:27.4},0).wait(1).to({scaleX:1.0011,scaleY:1.0011,x:293.5,y:28.1},0).wait(1).to({scaleX:0.9973,scaleY:0.9973,x:293.75,y:28.5},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.9961,scaleY:0.9961,x:294.1,y:28.45},0).wait(1).to({regX:28,regY:22.8,x:293.7,y:28.35},0).wait(8).to({regX:28.4,regY:22.9,x:294.1,y:28.45},0).wait(1).to({regX:28,regY:22.8,scaleX:0.9959,scaleY:0.9959,x:293.7,y:28.3},0).wait(1).to({scaleX:0.9955,scaleY:0.9955,x:293.65,y:28.25},0).wait(1).to({scaleX:0.9948,scaleY:0.9948,x:293.7,y:28.2},0).wait(1).to({scaleX:0.994,scaleY:0.994,x:293.75,y:28.1},0).wait(1).to({scaleX:0.9928,scaleY:0.9928,x:293.8,y:28},0).wait(1).to({scaleX:0.9914,scaleY:0.9914,x:293.85,y:27.8},0).wait(1).to({scaleX:0.9896,scaleY:0.9896,x:293.9,y:27.6},0).wait(1).to({scaleX:0.9875,scaleY:0.9875,x:294,y:27.35},0).wait(1).to({scaleX:0.9849,scaleY:0.9849,x:294.1,y:27.1},0).wait(1).to({scaleX:0.9819,scaleY:0.9819,x:294.2,y:26.75},0).wait(1).to({scaleX:0.9783,scaleY:0.9783,x:294.35,y:26.35},0).wait(1).to({scaleX:0.9741,scaleY:0.9741,x:294.45,y:25.9},0).wait(1).to({scaleX:0.9691,scaleY:0.9691,x:294.7,y:25.35},0).wait(1).to({scaleX:0.9631,scaleY:0.9631,x:294.9,y:24.65},0).wait(1).to({scaleX:0.9559,scaleY:0.9559,x:295.15,y:23.9},0).wait(1).to({scaleX:0.9472,scaleY:0.9472,x:295.45,y:22.9},0).wait(1).to({scaleX:0.9366,scaleY:0.9366,x:295.85,y:21.75},0).wait(1).to({scaleX:0.9232,scaleY:0.9232,x:296.4,y:20.3},0).wait(1).to({scaleX:0.9059,scaleY:0.9059,x:297.05,y:18.35},0).wait(1).to({scaleX:0.8829,scaleY:0.8829,x:297.9,y:15.85},0).wait(1).to({scaleX:0.8526,scaleY:0.8526,x:299,y:12.45},0).wait(1).to({scaleX:0.8177,scaleY:0.8177,x:300.35,y:8.6},0).wait(1).to({scaleX:0.7867,scaleY:0.7867,x:301.55,y:5.15},0).wait(1).to({scaleX:0.7629,scaleY:0.7629,x:302.4,y:2.5},0).wait(1).to({scaleX:0.7448,scaleY:0.7448,x:303.05,y:0.55},0).wait(1).to({scaleX:0.7307,scaleY:0.7307,x:303.6,y:-1.05},0).wait(1).to({scaleX:0.7194,scaleY:0.7194,x:304.05,y:-2.3},0).wait(1).to({scaleX:0.7102,scaleY:0.7102,x:304.4,y:-3.35},0).wait(1).to({scaleX:0.7025,scaleY:0.7025,x:304.65,y:-4.2},0).wait(1).to({scaleX:0.6959,scaleY:0.6959,x:304.9,y:-4.95},0).wait(1).to({scaleX:0.6904,scaleY:0.6904,x:305.15,y:-5.5},0).wait(1).to({scaleX:0.6857,scaleY:0.6857,x:305.3,y:-6.05},0).wait(1).to({scaleX:0.6816,scaleY:0.6816,x:305.45,y:-6.5},0).wait(1).to({scaleX:0.6781,scaleY:0.6781,x:305.6,y:-6.9},0).wait(1).to({scaleX:0.6751,scaleY:0.6751,x:305.7,y:-7.2},0).wait(1).to({scaleX:0.6726,scaleY:0.6726,x:305.8,y:-7.5},0).wait(1).to({scaleX:0.6704,scaleY:0.6704,x:305.85,y:-7.75},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,x:305.9,y:-7.95},0).wait(1).to({scaleX:0.667,scaleY:0.667,x:306,y:-8.15},0).wait(1).to({scaleX:0.6657,scaleY:0.6657,x:306.05,y:-8.25},0).wait(1).to({scaleX:0.6647,scaleY:0.6647,y:-8.4},0).wait(1).to({scaleX:0.6639,scaleY:0.6639,x:306.1,y:-8.45},0).wait(1).to({scaleX:0.6633,scaleY:0.6633,y:-8.55},0).wait(1).to({scaleX:0.6629,scaleY:0.6629,x:306.15,y:-8.6},0).wait(1).to({scaleX:0.6626,scaleY:0.6626},0).wait(1).to({regX:28.4,regY:22.9,x:306.4},0).to({_off:true},1).wait(2));

	// l guy i shadow
	this.instance_12 = new lib.roundshadow();
	this.instance_12.setTransform(-116,82.3,1,1,0,0,0,28.2,22.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(33).to({_off:false},0).to({regX:28.3,regY:22.7,scaleX:1.6102,scaleY:1.6102,x:50.6,y:-3.05,alpha:0.1602},33,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.8,x:50.15,y:-2.9},0).wait(22).to({regX:28.3,regY:22.7,x:50.6,y:-3.05},0).wait(1).to({regX:28,regY:22.8,scaleX:1.6028,scaleY:1.6028,x:51.95,y:-2.3},0).wait(1).to({scaleX:1.5927,scaleY:1.5927,x:54.4,y:-1.6},0).wait(1).to({scaleX:1.5797,scaleY:1.5797,x:57.6,y:-0.65},0).wait(1).to({scaleX:1.5636,scaleY:1.5636,x:61.55,y:0.6},0).wait(1).to({scaleX:1.5442,scaleY:1.5442,x:66.3,y:2},0).wait(1).to({scaleX:1.5213,scaleY:1.5213,x:71.9,y:3.7},0).wait(1).to({scaleX:1.4948,scaleY:1.4948,x:78.35,y:5.65},0).wait(1).to({scaleX:1.4645,scaleY:1.4645,x:85.8,y:7.9},0).wait(1).to({scaleX:1.4305,scaleY:1.4305,x:94.15,y:10.4},0).wait(1).to({scaleX:1.3926,scaleY:1.3926,x:103.4,y:13.2},0).wait(1).to({scaleX:1.3512,scaleY:1.3512,x:113.6,y:16.25},0).wait(1).to({scaleX:1.3064,scaleY:1.3064,x:124.55,y:19.6},0).wait(1).to({scaleX:1.259,scaleY:1.259,x:136.15,y:23.05},0).wait(1).to({scaleX:1.2096,scaleY:1.2096,x:148.25,y:26.75},0).wait(1).to({scaleX:1.1591,scaleY:1.1591,x:160.6,y:30.4},0).wait(1).to({scaleX:1.1086,scaleY:1.1086,x:173,y:34.15},0).wait(1).to({scaleX:1.0593,scaleY:1.0593,x:185.05,y:37.75},0).wait(1).to({scaleX:1.012,scaleY:1.012,x:196.65,y:41.25},0).wait(1).to({scaleX:0.9678,scaleY:0.9678,x:207.5,y:44.5},0).wait(1).to({scaleX:0.9272,scaleY:0.9272,x:217.4,y:47.55},0).wait(1).to({scaleX:0.8908,scaleY:0.8908,x:226.35,y:50.2},0).wait(1).to({scaleX:0.8587,scaleY:0.8587,x:234.25,y:52.6},0).wait(1).to({scaleX:0.831,scaleY:0.831,x:241,y:54.65},0).wait(1).to({scaleX:0.8076,scaleY:0.8076,x:246.7,y:56.35},0).wait(1).to({scaleX:0.7885,scaleY:0.7885,x:251.45,y:57.8},0).wait(1).to({scaleX:0.7734,scaleY:0.7734,x:255.1,y:58.9},0).wait(1).to({scaleX:0.762,scaleY:0.762,x:257.9,y:59.7},0).wait(1).to({scaleX:0.7542,scaleY:0.7542,x:259.8,y:60.3},0).wait(1).to({scaleX:0.7497,scaleY:0.7497,x:260.95,y:60.65},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.7483,scaleY:0.7483,x:261.55,y:60.7},0).wait(1).to({regX:28,regY:22.8,x:261.3,y:60.6},0).wait(6).to({regX:28.3,regY:22.9,x:261.55,y:60.7},0).wait(1).to({regX:28,regY:22.8,x:261.3,y:60.6},0).wait(1).to({regX:28.3,regY:22.9,x:261.55,y:60.7},0).wait(1).to({regX:28,regY:22.8,scaleX:0.7482,scaleY:0.7482,x:261.2,y:60.55},0).wait(1).to({scaleX:0.7481,scaleY:0.7481,x:261.1,y:60.5},0).wait(1).to({scaleX:0.748,scaleY:0.748,x:260.95,y:60.4},0).wait(1).to({scaleX:0.7478,scaleY:0.7478,x:260.75,y:60.25},0).wait(1).to({scaleX:0.7476,scaleY:0.7476,x:260.45,y:60.05},0).wait(1).to({scaleX:0.7473,scaleY:0.7473,x:260,y:59.85},0).wait(1).to({scaleX:0.7469,scaleY:0.7469,x:259.55,y:59.55},0).wait(1).to({scaleX:0.7464,scaleY:0.7464,x:258.95,y:59.15},0).wait(1).to({scaleX:0.7459,scaleY:0.7459,x:258.25,y:58.7},0).wait(1).to({scaleX:0.7452,scaleY:0.7452,x:257.35,y:58.15},0).wait(1).to({scaleX:0.7443,scaleY:0.7443,x:256.3,y:57.45},0).wait(1).to({scaleX:0.7433,scaleY:0.7433,x:255,y:56.7},0).wait(1).to({scaleX:0.742,scaleY:0.742,x:253.4,y:55.65},0).wait(1).to({scaleX:0.7404,scaleY:0.7404,x:251.35,y:54.4},0).wait(1).to({scaleX:0.7383,scaleY:0.7383,x:248.65,y:52.75},0).wait(1).to({scaleX:0.7354,scaleY:0.7354,x:245.15,y:50.5},0).wait(1).to({scaleX:0.7315,scaleY:0.7315,x:240.2,y:47.45},0).wait(1).to({scaleX:0.7261,scaleY:0.7261,x:233.45,y:43.25},0).wait(1).to({scaleX:0.7203,scaleY:0.7203,x:226.1,y:38.65},0).wait(1).to({scaleX:0.7157,scaleY:0.7157,x:220.3,y:35.05},0).wait(1).to({scaleX:0.7124,scaleY:0.7124,x:216.15,y:32.5},0).wait(1).to({scaleX:0.71,scaleY:0.71,x:213.05,y:30.55},0).wait(1).to({scaleX:0.7081,scaleY:0.7081,x:210.7,y:29.05},0).wait(1).to({scaleX:0.7066,scaleY:0.7066,x:208.8,y:27.9},0).wait(1).to({scaleX:0.7053,scaleY:0.7053,x:207.25,y:26.95},0).wait(1).to({scaleX:0.7043,scaleY:0.7043,x:205.95,y:26.15},0).wait(1).to({scaleX:0.7035,scaleY:0.7035,x:204.95,y:25.5},0).wait(1).to({scaleX:0.7028,scaleY:0.7028,x:204.1,y:24.9},0).wait(1).to({scaleX:0.7022,scaleY:0.7022,x:203.3,y:24.5},0).wait(1).to({scaleX:0.7017,scaleY:0.7017,x:202.7,y:24.1},0).wait(1).to({scaleX:0.7013,scaleY:0.7013,x:202.25,y:23.8},0).wait(1).to({scaleX:0.701,scaleY:0.701,x:201.8,y:23.55},0).wait(1).to({scaleX:0.7007,scaleY:0.7007,x:201.45,y:23.35},0).wait(1).to({scaleX:0.7005,scaleY:0.7005,x:201.15,y:23.15},0).wait(1).to({scaleX:0.7004,scaleY:0.7004,x:200.95,y:23},0).wait(1).to({scaleX:0.7002,scaleY:0.7002,x:200.8,y:22.9},0).wait(1).to({x:200.7,y:22.85},0).wait(1).to({scaleX:0.7001,scaleY:0.7001,x:200.65,y:22.8},0).wait(1).to({regX:28.4,regY:23.2,x:200.85,y:22.95},0).to({_off:true},6).wait(2));

	// r girl i shadow
	this.instance_13 = new lib.roundshadow();
	this.instance_13.setTransform(198.25,263.3,1,1,0,0,0,28.2,22.8);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(25).to({_off:false},0).to({regX:28.3,scaleX:1.6102,scaleY:1.6102,x:195.2,y:245.5,alpha:0.1602},39,cjs.Ease.quadOut).wait(1).to({regX:28,x:194.75},0).wait(24).to({regX:28.3,x:195.2},0).wait(1).to({regX:28,scaleX:1.6045,scaleY:1.6045,x:195.45,y:244.6},0).wait(1).to({scaleX:1.5966,scaleY:1.5966,x:196.5,y:243.3},0).wait(1).to({scaleX:1.5864,scaleY:1.5864,x:197.8,y:241.6},0).wait(1).to({scaleX:1.5738,scaleY:1.5738,x:199.45,y:239.6},0).wait(1).to({scaleX:1.5586,scaleY:1.5586,x:201.45,y:237.15},0).wait(1).to({scaleX:1.5408,scaleY:1.5408,x:203.75,y:234.3},0).wait(1).to({scaleX:1.5203,scaleY:1.5203,x:206.45,y:230.95},0).wait(1).to({scaleX:1.497,scaleY:1.497,x:209.45,y:227.2},0).wait(1).to({scaleX:1.4711,scaleY:1.4711,x:212.9,y:223},0).wait(1).to({scaleX:1.4425,scaleY:1.4425,x:216.6,y:218.4},0).wait(1).to({scaleX:1.4116,scaleY:1.4116,x:220.65,y:213.4},0).wait(1).to({scaleX:1.3787,scaleY:1.3787,x:224.95,y:208.05},0).wait(1).to({scaleX:1.3442,scaleY:1.3442,x:229.45,y:202.45},0).wait(1).to({scaleX:1.3088,scaleY:1.3088,x:234.1,y:196.75},0).wait(1).to({scaleX:1.273,scaleY:1.273,x:238.75,y:190.9},0).wait(1).to({scaleX:1.2375,scaleY:1.2375,x:243.35,y:185.2},0).wait(1).to({scaleX:1.2031,scaleY:1.2031,x:247.85,y:179.65},0).wait(1).to({scaleX:1.1704,scaleY:1.1704,x:252.1,y:174.35},0).wait(1).to({scaleX:1.1398,scaleY:1.1398,x:256.1,y:169.4},0).wait(1).to({scaleX:1.1118,scaleY:1.1118,x:259.8,y:164.9},0).wait(1).to({scaleX:1.0866,scaleY:1.0866,x:263.05,y:160.75},0).wait(1).to({scaleX:1.0643,scaleY:1.0643,x:266,y:157.2},0).wait(1).to({scaleX:1.045,scaleY:1.045,x:268.5,y:154.1},0).wait(1).to({scaleX:1.0287,scaleY:1.0287,x:270.65,y:151.4},0).wait(1).to({scaleX:1.0152,scaleY:1.0152,x:272.45,y:149.25},0).wait(1).to({scaleX:1.0045,scaleY:1.0045,x:273.85,y:147.5},0).wait(1).to({scaleX:0.9964,scaleY:0.9964,x:274.85,y:146.2},0).wait(1).to({scaleX:0.9908,scaleY:0.9908,x:275.6,y:145.3},0).wait(1).to({scaleX:0.9876,scaleY:0.9876,x:276,y:144.75},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.9865,scaleY:0.9865,x:276.4,y:144.6},0).wait(1).to({regX:28,regY:22.8,x:276.1,y:144.5},0).wait(6).to({regX:28.3,regY:22.9,x:276.4,y:144.6},0).wait(1).to({regX:28,regY:22.8,x:276.1,y:144.5},0).wait(2).to({regX:28.3,regY:22.9,x:276.4,y:144.6},0).wait(1).to({regX:28,regY:22.8,scaleX:0.9863,scaleY:0.9863,x:276.05,y:144.4},0).wait(1).to({scaleX:0.9859,scaleY:0.9859,x:276,y:144.2},0).wait(1).to({scaleX:0.9852,scaleY:0.9852,x:275.95,y:143.9},0).wait(1).to({scaleX:0.9842,scaleY:0.9842,x:275.8,y:143.5},0).wait(1).to({scaleX:0.983,scaleY:0.983,x:275.65,y:142.95},0).wait(1).to({scaleX:0.9814,scaleY:0.9814,x:275.45,y:142.3},0).wait(1).to({scaleX:0.9795,scaleY:0.9795,x:275.2,y:141.5},0).wait(1).to({scaleX:0.9771,scaleY:0.9771,x:274.9,y:140.5},0).wait(1).to({scaleX:0.9742,scaleY:0.9742,x:274.6,y:139.25},0).wait(1).to({scaleX:0.9708,scaleY:0.9708,x:274.15,y:137.85},0).wait(1).to({scaleX:0.9667,scaleY:0.9667,x:273.6,y:136.1},0).wait(1).to({scaleX:0.9618,scaleY:0.9618,x:273,y:134.05},0).wait(1).to({scaleX:0.9559,scaleY:0.9559,x:272.25,y:131.55},0).wait(1).to({scaleX:0.9488,scaleY:0.9488,x:271.35,y:128.55},0).wait(1).to({scaleX:0.94,scaleY:0.94,x:270.25,y:124.85},0).wait(1).to({scaleX:0.929,scaleY:0.929,x:268.85,y:120.2},0).wait(1).to({scaleX:0.915,scaleY:0.915,x:267.1,y:114.25},0).wait(1).to({scaleX:0.8965,scaleY:0.8965,x:264.8,y:106.45},0).wait(1).to({scaleX:0.8712,scaleY:0.8712,x:261.6,y:95.75},0).wait(1).to({scaleX:0.8382,scaleY:0.8382,x:257.45,y:81.8},0).wait(1).to({scaleX:0.8038,scaleY:0.8038,x:253.15,y:67.3},0).wait(1).to({scaleX:0.7762,scaleY:0.7762,x:249.7,y:55.65},0).wait(1).to({scaleX:0.7557,scaleY:0.7557,x:247.1,y:47},0).wait(1).to({scaleX:0.7402,scaleY:0.7402,x:245.15,y:40.45},0).wait(1).to({scaleX:0.7281,scaleY:0.7281,x:243.65,y:35.3},0).wait(1).to({scaleX:0.7183,scaleY:0.7183,x:242.4,y:31.2},0).wait(1).to({scaleX:0.7103,scaleY:0.7103,x:241.4,y:27.8},0).wait(1).to({scaleX:0.7036,scaleY:0.7036,x:240.55,y:25},0).wait(1).to({scaleX:0.698,scaleY:0.698,x:239.9,y:22.65},0).wait(1).to({scaleX:0.6933,scaleY:0.6933,x:239.25,y:20.65},0).wait(1).to({scaleX:0.6893,scaleY:0.6893,x:238.75,y:18.95},0).wait(1).to({scaleX:0.6859,scaleY:0.6859,x:238.35,y:17.5},0).wait(1).to({scaleX:0.683,scaleY:0.683,x:237.95,y:16.25},0).wait(1).to({scaleX:0.6805,scaleY:0.6805,x:237.65,y:15.3},0).wait(1).to({scaleX:0.6785,scaleY:0.6785,x:237.4,y:14.4},0).wait(1).to({scaleX:0.6767,scaleY:0.6767,x:237.2,y:13.7},0).wait(1).to({scaleX:0.6753,scaleY:0.6753,x:237,y:13.1},0).wait(1).to({scaleX:0.6742,scaleY:0.6742,x:236.9,y:12.6},0).wait(1).to({scaleX:0.6733,scaleY:0.6733,x:236.75,y:12.25},0).wait(1).to({scaleX:0.6727,scaleY:0.6727,x:236.7,y:12},0).wait(1).to({scaleX:0.6722,scaleY:0.6722,x:236.6,y:11.8},0).wait(1).to({scaleX:0.672,scaleY:0.672,y:11.65},0).wait(1).to({regX:28.4,scaleX:0.6719,scaleY:0.6719,x:236.8,y:11.7},0).to({_off:true},1).wait(2));

	// l girl i shadow
	this.instance_14 = new lib.roundshadow();
	this.instance_14.setTransform(-129.35,179.15,1,1,0,0,0,28.2,22.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(22).to({_off:false},0).to({regX:28.3,scaleX:1.6102,scaleY:1.6102,x:27.8,y:149.35,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:28,x:27.35},0).wait(25).to({regX:28.3,x:27.8},0).wait(1).to({regX:28,scaleX:1.6029,scaleY:1.6029,x:29.4,y:148.9},0).wait(1).to({scaleX:1.5929,scaleY:1.5929,x:32.1,y:148.25},0).wait(1).to({scaleX:1.5802,scaleY:1.5802,x:35.6,y:147.5},0).wait(1).to({scaleX:1.5645,scaleY:1.5645,x:39.85,y:146.45},0).wait(1).to({scaleX:1.5459,scaleY:1.5459,x:44.95,y:145.35},0).wait(1).to({scaleX:1.524,scaleY:1.524,x:50.9,y:143.95},0).wait(1).to({scaleX:1.4988,scaleY:1.4988,x:57.8,y:142.35},0).wait(1).to({scaleX:1.4704,scaleY:1.4704,x:65.6,y:140.6},0).wait(1).to({scaleX:1.4386,scaleY:1.4386,x:74.35,y:138.65},0).wait(1).to({scaleX:1.4036,scaleY:1.4036,x:83.95,y:136.45},0).wait(1).to({scaleX:1.3655,scaleY:1.3655,x:94.4,y:134.1},0).wait(1).to({scaleX:1.3246,scaleY:1.3246,x:105.6,y:131.5},0).wait(1).to({scaleX:1.2815,scaleY:1.2815,x:117.45,y:128.8},0).wait(1).to({scaleX:1.2365,scaleY:1.2365,x:129.7,y:126.05},0).wait(1).to({scaleX:1.1905,scaleY:1.1905,x:142.35,y:123.15},0).wait(1).to({scaleX:1.1441,scaleY:1.1441,x:155.1,y:120.25},0).wait(1).to({scaleX:1.0982,scaleY:1.0982,x:167.65,y:117.4},0).wait(1).to({scaleX:1.0535,scaleY:1.0535,x:179.95,y:114.6},0).wait(1).to({scaleX:1.0107,scaleY:1.0107,x:191.65,y:111.95},0).wait(1).to({scaleX:0.9704,scaleY:0.9704,x:202.7,y:109.4},0).wait(1).to({scaleX:0.9331,scaleY:0.9331,x:212.95,y:107.05},0).wait(1).to({scaleX:0.8991,scaleY:0.8991,x:222.25,y:104.95},0).wait(1).to({scaleX:0.8687,scaleY:0.8687,x:230.55,y:103.05},0).wait(1).to({scaleX:0.8419,scaleY:0.8419,x:237.9,y:101.4},0).wait(1).to({scaleX:0.8187,scaleY:0.8187,x:244.25,y:99.95},0).wait(1).to({scaleX:0.799,scaleY:0.799,x:249.65,y:98.7},0).wait(1).to({scaleX:0.7828,scaleY:0.7828,x:254.1,y:97.7},0).wait(1).to({scaleX:0.7699,scaleY:0.7699,x:257.65,y:96.9},0).wait(1).to({scaleX:0.7602,scaleY:0.7602,x:260.35,y:96.3},0).wait(1).to({scaleX:0.7535,scaleY:0.7535,x:262.15,y:95.9},0).wait(1).to({scaleX:0.7495,scaleY:0.7495,x:263.25,y:95.65},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.7483,scaleY:0.7483,x:263.8,y:95.6},0).wait(1).to({regX:28,regY:22.8,x:263.5,y:95.5},0).wait(4).to({regX:28.4,regY:22.9,x:263.8,y:95.6},0).wait(1).to({regX:28,regY:22.8,x:263.5,y:95.5},0).wait(4).to({regX:28.4,regY:22.9,x:263.8,y:95.6},0).wait(1).to({regX:28,regY:22.8,scaleX:0.7482,scaleY:0.7482,x:263.5,y:95.4},0).wait(1).to({scaleX:0.7481,scaleY:0.7481,y:95.25},0).wait(1).to({scaleX:0.7479,scaleY:0.7479,y:95.05},0).wait(1).to({scaleX:0.7476,scaleY:0.7476,x:263.55,y:94.75},0).wait(1).to({scaleX:0.7472,scaleY:0.7472,y:94.3},0).wait(1).to({scaleX:0.7467,scaleY:0.7467,x:263.6,y:93.8},0).wait(1).to({scaleX:0.7461,scaleY:0.7461,x:263.65,y:93.1},0).wait(1).to({scaleX:0.7454,scaleY:0.7454,x:263.7,y:92.35},0).wait(1).to({scaleX:0.7446,scaleY:0.7446,x:263.8,y:91.4},0).wait(1).to({scaleX:0.7435,scaleY:0.7435,x:263.9,y:90.2},0).wait(1).to({scaleX:0.7422,scaleY:0.7422,x:264.05,y:88.75},0).wait(1).to({scaleX:0.7407,scaleY:0.7407,x:264.15,y:87.1},0).wait(1).to({scaleX:0.7388,scaleY:0.7388,x:264.35,y:85},0).wait(1).to({scaleX:0.7365,scaleY:0.7365,x:264.5,y:82.4},0).wait(1).to({scaleX:0.7336,scaleY:0.7336,x:264.8,y:79.2},0).wait(1).to({scaleX:0.7299,scaleY:0.7299,x:265.1,y:75.05},0).wait(1).to({scaleX:0.7249,scaleY:0.7249,x:265.55,y:69.55},0).wait(1).to({scaleX:0.7181,scaleY:0.7181,x:266.15,y:61.9},0).wait(1).to({scaleX:0.7089,scaleY:0.7089,x:266.95,y:51.75},0).wait(1).to({scaleX:0.6991,scaleY:0.6991,x:267.85,y:40.9},0).wait(1).to({scaleX:0.6913,scaleY:0.6913,x:268.5,y:32.2},0).wait(1).to({scaleX:0.6856,scaleY:0.6856,x:269.05,y:25.9},0).wait(1).to({scaleX:0.6814,scaleY:0.6814,x:269.45,y:21.15},0).wait(1).to({scaleX:0.6781,scaleY:0.6781,x:269.7,y:17.45},0).wait(1).to({scaleX:0.6754,scaleY:0.6754,x:269.95,y:14.55},0).wait(1).to({scaleX:0.6733,scaleY:0.6733,x:270.15,y:12.15},0).wait(1).to({scaleX:0.6715,scaleY:0.6715,x:270.3,y:10.15},0).wait(1).to({scaleX:0.67,scaleY:0.67,x:270.4,y:8.55},0).wait(1).to({scaleX:0.6687,scaleY:0.6687,x:270.5,y:7.1},0).wait(1).to({scaleX:0.6677,scaleY:0.6677,x:270.65,y:5.9},0).wait(1).to({scaleX:0.6668,scaleY:0.6668,x:270.7,y:4.95},0).wait(1).to({scaleX:0.666,scaleY:0.666,x:270.75,y:4.15},0).wait(1).to({scaleX:0.6654,scaleY:0.6654,x:270.85,y:3.4},0).wait(1).to({scaleX:0.6649,scaleY:0.6649,y:2.85},0).wait(1).to({scaleX:0.6645,scaleY:0.6645,x:270.9,y:2.35},0).wait(1).to({scaleX:0.6641,scaleY:0.6641,x:270.95,y:2},0).wait(1).to({scaleX:0.6639,scaleY:0.6639,y:1.7},0).wait(1).to({scaleX:0.6637,scaleY:0.6637,x:271,y:1.5},0).wait(1).to({scaleX:0.6635,scaleY:0.6635,y:1.35},0).wait(1).to({scaleX:0.6634,scaleY:0.6634,y:1.25},0).wait(1).to({regX:28.4,regY:23,x:271.3},0).to({_off:true},1).wait(2));

	// l girl box shadow
	this.instance_15 = new lib.squareshadow();
	this.instance_15.setTransform(-77.95,180.65,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_15.alpha = 0;
	this.instance_15._off = true;

	var maskedShapeInstanceList = [this.instance_15];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(22).to({_off:false},0).to({regX:70.9,regY:47.9,scaleX:1.0949,scaleY:1.0949,x:117.5,y:162.4,alpha:0.1602},41,cjs.Ease.quadOut).wait(1).to({regX:70.6,regY:47.8,x:117.15,y:162.3},0).wait(25).to({regX:70.9,regY:47.9,x:117.5,y:162.4},0).wait(1).to({regX:70.6,regY:47.8,scaleX:1.0893,scaleY:1.0893,x:118.65,y:161.75,alpha:0.1588},0).wait(1).to({scaleX:1.0816,scaleY:1.0816,x:120.65,y:161.1,alpha:0.1571},0).wait(1).to({scaleX:1.0717,scaleY:1.0717,x:123.25,y:160.3,alpha:0.1548},0).wait(1).to({scaleX:1.0597,scaleY:1.0597,x:126.45,y:159.25,alpha:0.152},0).wait(1).to({scaleX:1.0452,scaleY:1.0452,x:130.3,y:158,alpha:0.1486},0).wait(1).to({scaleX:1.0283,scaleY:1.0283,x:134.75,y:156.55,alpha:0.1447},0).wait(1).to({scaleX:1.0088,scaleY:1.0088,x:139.9,y:154.9,alpha:0.1402},0).wait(1).to({scaleX:0.9866,scaleY:0.9866,x:145.75,y:153,alpha:0.135},0).wait(1).to({scaleX:0.9618,scaleY:0.9618,x:152.3,y:150.85,alpha:0.1292},0).wait(1).to({scaleX:0.9343,scaleY:0.9343,x:159.55,y:148.55,alpha:0.1229},0).wait(1).to({scaleX:0.9043,scaleY:0.9043,x:167.5,y:146,alpha:0.1159},0).wait(1).to({scaleX:0.872,scaleY:0.872,x:176,y:143.25,alpha:0.1084},0).wait(1).to({scaleX:0.8376,scaleY:0.8376,x:185.15,y:140.3,alpha:0.1004},0).wait(1).to({scaleX:0.8017,scaleY:0.8017,x:194.6,y:137.2,alpha:0.0921},0).wait(1).to({scaleX:0.7646,scaleY:0.7646,x:204.4,y:134.05,alpha:0.0835},0).wait(1).to({scaleX:0.7271,scaleY:0.7271,x:214.3,y:130.8,alpha:0.0748},0).wait(1).to({scaleX:0.6898,scaleY:0.6898,x:224.15,y:127.6,alpha:0.0661},0).wait(1).to({scaleX:0.6534,scaleY:0.6534,x:233.8,y:124.55,alpha:0.0577},0).wait(1).to({scaleX:0.6185,scaleY:0.6185,x:243,y:121.55,alpha:0.0496},0).wait(1).to({scaleX:0.5856,scaleY:0.5856,x:251.7,y:118.75,alpha:0.0419},0).wait(1).to({scaleX:0.5552,scaleY:0.5552,x:259.75,y:116.15,alpha:0.0349},0).wait(1).to({scaleX:0.5274,scaleY:0.5274,x:267.1,y:113.75,alpha:0.0284},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:273.65,y:111.6,alpha:0.0227},0).wait(1).to({scaleX:0.4807,scaleY:0.4807,x:279.4,y:109.8,alpha:0.0176},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:284.4,y:108.2,alpha:0.0132},0).wait(1).to({scaleX:0.4459,scaleY:0.4459,x:288.6,y:106.8,alpha:0.0095},0).wait(1).to({scaleX:0.4328,scaleY:0.4328,x:292.05,y:105.7,alpha:0.0065},0).wait(1).to({scaleX:0.4224,scaleY:0.4224,x:294.8,y:104.8,alpha:0.004},0).wait(1).to({scaleX:0.4146,scaleY:0.4146,x:296.85,y:104.1,alpha:0.0022},0).wait(1).to({scaleX:0.4091,scaleY:0.4091,x:298.35,y:103.65,alpha:0.001},0).wait(1).to({scaleX:0.406,scaleY:0.406,x:299.15,y:103.4,alpha:0.0002},0).wait(1).to({regX:71.5,regY:48.3,scaleX:0.405,scaleY:0.405,x:299.55,y:103.35,alpha:0},0).to({_off:true},52).wait(2));

	// r girl box shadow
	this.instance_16 = new lib.fill();
	this.instance_16.setTransform(253.7,154,1,1,0,0,0,32.5,30.1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	var maskedShapeInstanceList = [this.instance_16];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(109).to({_off:false},0).to({regX:32.6,regY:30.2,scaleX:1.1973,scaleY:1.1973,x:300.05,y:103.35,alpha:1},9).to({_off:true},55).wait(2));

	// r guy box shadow
	this.instance_17 = new lib.squareshadow();
	this.instance_17.setTransform(226.05,-55.6,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_17.alpha = 0;
	this.instance_17._off = true;

	var maskedShapeInstanceList = [this.instance_17];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(29).to({_off:false},0).to({regX:70.9,regY:47.6,scaleX:0.8786,scaleY:0.8786,x:322.95,y:-27.15,alpha:0.1602},37,cjs.Ease.quadOut).wait(1).to({regX:70.6,regY:47.8,x:322.7,y:-26.95},0).wait(22).to({regX:70.9,regY:47.6,x:322.95,y:-27.15},0).wait(1).to({regX:70.6,regY:47.8,scaleX:0.8717,scaleY:0.8709,x:322.8,y:-25.65},0).wait(1).to({scaleX:0.8635,scaleY:0.8617,x:322.9,y:-24.15},0).wait(1).to({scaleX:0.8541,scaleY:0.8512,x:323.05,y:-22.4},0).wait(1).to({scaleX:0.8434,scaleY:0.8393,x:323.25,y:-20.45},0).wait(1).to({scaleX:0.8315,scaleY:0.8261,x:323.45,y:-18.25},0).wait(1).to({scaleX:0.8185,scaleY:0.8115,x:323.65,y:-15.8},0).wait(1).to({scaleX:0.8043,scaleY:0.7957,x:323.9,y:-13.2},0).wait(1).to({scaleX:0.7892,scaleY:0.7788,x:324.15,y:-10.4},0).wait(1).to({scaleX:0.7733,scaleY:0.761,x:324.4,y:-7.45},0).wait(1).to({scaleX:0.7567,scaleY:0.7425,x:324.7,y:-4.4},0).wait(1).to({scaleX:0.7398,scaleY:0.7236,x:325,y:-1.3},0).wait(1).to({scaleX:0.7227,scaleY:0.7045,x:325.25,y:1.85},0).wait(1).to({scaleX:0.7056,scaleY:0.6854,x:325.55,y:5},0).wait(1).to({scaleX:0.6889,scaleY:0.6667,x:325.85,y:8.1},0).wait(1).to({scaleX:0.6727,scaleY:0.6487,x:326.1,y:11.1},0).wait(1).to({scaleX:0.6573,scaleY:0.6314,x:326.35,y:13.95},0).wait(1).to({scaleX:0.6427,scaleY:0.6152,x:326.65,y:16.6},0).wait(1).to({scaleX:0.6293,scaleY:0.6002,x:326.85,y:19.1},0).wait(1).to({scaleX:0.617,scaleY:0.5864,x:327.05,y:21.4},0).wait(1).to({scaleX:0.6059,scaleY:0.574,x:327.2,y:23.45},0).wait(1).to({scaleX:0.596,scaleY:0.563,x:327.4,y:25.25},0).wait(1).to({scaleX:0.5874,scaleY:0.5534,x:327.5,y:26.8},0).wait(1).to({scaleX:0.5801,scaleY:0.5453,x:327.65,y:28.1},0).wait(1).to({scaleX:0.574,scaleY:0.5385,x:327.75,y:29.25},0).wait(1).to({scaleX:0.5691,scaleY:0.533,x:327.85,y:30.2},0).wait(1).to({scaleX:0.5654,scaleY:0.5289,x:327.9,y:30.85},0).wait(1).to({scaleX:0.5628,scaleY:0.526,x:327.95,y:31.35},0).wait(1).to({scaleX:0.5613,scaleY:0.5243,x:328,y:31.6},0).wait(1).to({regX:71,regY:48.2,scaleX:0.5608,scaleY:0.5237,x:328.15,y:31.65},0).to({_off:true},55).wait(2));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(34.25,56.65,0.4246,0.4246,0,0,0,225,236.6);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(67).to({regX:232.4,regY:219.8,x:37.35,y:49.5},0).wait(22).to({regX:225,regY:236.6,x:34.25,y:56.65},0).wait(1).to({regX:232.4,regY:219.8,scaleX:0.4245,scaleY:0.4245,x:37.55,y:49.6},0).wait(1).to({scaleX:0.4243,scaleY:0.4243,x:37.75,y:49.65},0).wait(1).to({scaleX:0.4241,scaleY:0.4241,x:38.1,y:49.7},0).wait(1).to({scaleX:0.4239,scaleY:0.4239,x:38.6,y:49.85},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,x:39.2,y:50.05},0).wait(1).to({scaleX:0.4231,scaleY:0.4231,x:39.9,y:50.2},0).wait(1).to({scaleX:0.4226,scaleY:0.4226,x:40.75,y:50.45},0).wait(1).to({scaleX:0.422,scaleY:0.422,x:41.75,y:50.7},0).wait(1).to({scaleX:0.4214,scaleY:0.4214,x:42.9,y:51},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:44.1,y:51.35},0).wait(1).to({scaleX:0.4199,scaleY:0.4199,x:45.5,y:51.75},0).wait(1).to({scaleX:0.419,scaleY:0.419,x:46.95,y:52.1},0).wait(1).to({scaleX:0.4181,scaleY:0.4181,x:48.45,y:52.5},0).wait(1).to({scaleX:0.4172,scaleY:0.4172,x:50.05,y:52.95},0).wait(1).to({scaleX:0.4163,scaleY:0.4163,x:51.6,y:53.35},0).wait(1).to({scaleX:0.4154,scaleY:0.4154,x:53.1,y:53.75},0).wait(1).to({scaleX:0.4146,scaleY:0.4146,x:54.55,y:54.1},0).wait(1).to({scaleX:0.4138,scaleY:0.4138,x:55.85,y:54.5},0).wait(1).to({scaleX:0.4131,scaleY:0.4131,x:57.1,y:54.85},0).wait(1).to({scaleX:0.4125,scaleY:0.4125,x:58.2,y:55.1},0).wait(1).to({scaleX:0.4119,scaleY:0.4119,x:59.1,y:55.4},0).wait(1).to({scaleX:0.4114,scaleY:0.4114,x:59.95,y:55.6},0).wait(1).to({scaleX:0.411,scaleY:0.411,x:60.7,y:55.8},0).wait(1).to({scaleX:0.4107,scaleY:0.4107,x:61.3,y:55.95},0).wait(1).to({scaleX:0.4104,scaleY:0.4104,x:61.75,y:56.1},0).wait(1).to({scaleX:0.4101,scaleY:0.4101,x:62.15,y:56.2},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:62.5,y:56.25},0).wait(1).to({scaleX:0.4099,scaleY:0.4099,x:62.65,y:56.35},0).wait(1).to({regX:224.8,regY:236.8,scaleX:0.4098,scaleY:0.4098,x:59.7,y:63.2},0).to({_off:true},55).wait(2));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(101.95,79.4,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(27).to({regY:15.3,scaleX:1.2235,scaleY:1.2235,x:119.6,y:75.75},21,cjs.Ease.quadInOut).wait(19).to({regX:38,x:119.75},0).wait(22).to({regX:37.9,x:119.6},0).wait(1).to({regX:38,scaleX:1.2233,scaleY:1.2233,x:119.85},0).wait(1).to({scaleX:1.2229,scaleY:1.2229,x:120.05,y:75.85},0).wait(1).to({scaleX:1.2223,scaleY:1.2223,x:120.4,y:75.9},0).wait(1).to({scaleX:1.2215,scaleY:1.2215,x:120.75,y:76.05},0).wait(1).to({scaleX:1.2205,scaleY:1.2205,x:121.35,y:76.15},0).wait(1).to({scaleX:1.2193,scaleY:1.2193,x:121.95,y:76.35},0).wait(1).to({scaleX:1.2179,scaleY:1.2179,x:122.7,y:76.55},0).wait(1).to({scaleX:1.2163,scaleY:1.2163,x:123.55,y:76.75},0).wait(1).to({scaleX:1.2144,scaleY:1.2144,x:124.6,y:77.05},0).wait(1).to({scaleX:1.2123,scaleY:1.2123,x:125.7,y:77.35},0).wait(1).to({scaleX:1.21,scaleY:1.21,x:126.95,y:77.65},0).wait(1).to({scaleX:1.2075,scaleY:1.2075,x:128.25,y:77.95},0).wait(1).to({scaleX:1.2049,scaleY:1.2049,x:129.6,y:78.35},0).wait(1).to({scaleX:1.2023,scaleY:1.2023,x:131,y:78.7},0).wait(1).to({scaleX:1.1997,scaleY:1.1997,x:132.35,y:79.1},0).wait(1).to({scaleX:1.1972,scaleY:1.1972,x:133.7,y:79.4},0).wait(1).to({scaleX:1.1948,scaleY:1.1948,x:135,y:79.8},0).wait(1).to({scaleX:1.1926,scaleY:1.1926,x:136.15,y:80.1},0).wait(1).to({scaleX:1.1905,scaleY:1.1905,x:137.25,y:80.35},0).wait(1).to({scaleX:1.1887,scaleY:1.1887,x:138.2,y:80.65},0).wait(1).to({scaleX:1.1871,scaleY:1.1871,x:139.05,y:80.85},0).wait(1).to({scaleX:1.1857,scaleY:1.1857,x:139.8,y:81.05},0).wait(1).to({scaleX:1.1845,scaleY:1.1845,x:140.45,y:81.2},0).wait(1).to({scaleX:1.1835,scaleY:1.1835,x:140.95,y:81.35},0).wait(1).to({scaleX:1.1827,scaleY:1.1827,x:141.45,y:81.5},0).wait(1).to({scaleX:1.182,scaleY:1.182,x:141.75,y:81.6},0).wait(1).to({scaleX:1.1815,scaleY:1.1815,x:142.05,y:81.65},0).wait(1).to({scaleX:1.1812,scaleY:1.1812,x:142.2},0).wait(1).to({scaleX:1.181,scaleY:1.181,x:142.3,y:81.6},0).to({_off:true},55).wait(2));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(96.85,82.55,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(27).to({regX:37.8,regY:15.8,scaleX:1.2428,scaleY:1.2428,x:119.75,y:75.8},21,cjs.Ease.quadInOut).wait(1).to({regX:37.9,scaleX:1.4878,scaleY:1.4878,x:189.05,y:54.7,alpha:0},0).to({_off:true},124).wait(2));

	// first image
	this.instance_18 = new lib.firstimage_1();
	this.instance_18.setTransform(325.6,25.2,0.7473,0.7473,0,0,0,41.9,26.5);
	this.instance_18.alpha = 0;
	this.instance_18._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(32).to({_off:false},0).to({regX:42.1,regY:26.8,scaleX:0.9274,scaleY:0.9274,x:330,y:54.55,alpha:1},22,cjs.Ease.quadInOut).wait(13).to({regX:41,regY:25.6,x:328.95,y:53.45},0).wait(22).to({regX:42.1,regY:26.8,x:330,y:54.55},0).wait(1).to({regX:41,regY:25.6,scaleX:0.9272,scaleY:0.9272,x:329.05,y:53.5},0).wait(1).to({scaleX:0.9269,scaleY:0.9269,x:329.2,y:53.6},0).wait(1).to({scaleX:0.9264,scaleY:0.9264,x:329.45,y:53.7},0).wait(1).to({scaleX:0.9259,scaleY:0.9259,x:329.75,y:53.95},0).wait(1).to({scaleX:0.9251,scaleY:0.9251,x:330.15,y:54.2},0).wait(1).to({scaleX:0.9242,scaleY:0.9242,x:330.65,y:54.5},0).wait(1).to({scaleX:0.9231,scaleY:0.9231,x:331.2,y:54.85},0).wait(1).to({scaleX:0.9219,scaleY:0.9219,x:331.85,y:55.25},0).wait(1).to({scaleX:0.9204,scaleY:0.9204,x:332.6,y:55.75},0).wait(1).to({scaleX:0.9189,scaleY:0.9189,x:333.45,y:56.25},0).wait(1).to({scaleX:0.9171,scaleY:0.9171,x:334.35,y:56.9},0).wait(1).to({scaleX:0.9152,scaleY:0.9152,x:335.35,y:57.55},0).wait(1).to({scaleX:0.9133,scaleY:0.9133,x:336.4,y:58.2},0).wait(1).to({scaleX:0.9113,scaleY:0.9113,x:337.4,y:58.85},0).wait(1).to({scaleX:0.9093,scaleY:0.9093,x:338.5,y:59.5},0).wait(1).to({scaleX:0.9074,scaleY:0.9074,x:339.5,y:60.15},0).wait(1).to({scaleX:0.9056,scaleY:0.9056,x:340.45,y:60.8},0).wait(1).to({scaleX:0.9039,scaleY:0.9039,x:341.35,y:61.35},0).wait(1).to({scaleX:0.9024,scaleY:0.9024,x:342.15,y:61.85},0).wait(1).to({scaleX:0.901,scaleY:0.901,x:342.9,y:62.3},0).wait(1).to({scaleX:0.8998,scaleY:0.8998,x:343.55,y:62.75},0).wait(1).to({scaleX:0.8987,scaleY:0.8987,x:344.1,y:63.1},0).wait(1).to({scaleX:0.8978,scaleY:0.8978,x:344.6,y:63.4},0).wait(1).to({scaleX:0.897,scaleY:0.897,x:345,y:63.65},0).wait(1).to({scaleX:0.8964,scaleY:0.8964,x:345.3,y:63.85},0).wait(1).to({scaleX:0.8959,scaleY:0.8959,x:345.6,y:64.05},0).wait(1).to({scaleX:0.8955,scaleY:0.8955,x:345.75,y:64.2},0).wait(1).to({scaleX:0.8953,scaleY:0.8953,x:345.9},0).wait(1).to({regX:42.1,regY:26.8,scaleX:0.8951,scaleY:0.8951,x:347.05,y:65.4},0).to({_off:true},55).wait(2));

	// square shadow
	this.instance_19 = new lib.squareshadow();
	this.instance_19.setTransform(327.6,49.1,0.4651,0.4621,0,0,0,71,48);
	this.instance_19.alpha = 0;
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(32).to({_off:false},0).to({regX:71.5,regY:48.5,scaleX:0.5233,scaleY:0.5041,x:329.7,y:54.7,alpha:0.3086},22,cjs.Ease.quadInOut).to({_off:true},1).wait(120));

	// second image
	this.instance_20 = new lib.secondimage();
	this.instance_20.setTransform(348.35,83.35,1.2033,1.2033,0,0,0,42,26.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(35).to({regX:42.1,regY:26.6,scaleX:0.9261,scaleY:0.9261,x:348.25,y:88.45},22,cjs.Ease.quadInOut).wait(10).to({regY:26.8,y:88.6},0).wait(22).to({regY:26.6,y:88.45},0).wait(1).to({regY:26.8,scaleX:0.9259,scaleY:0.9259,x:348.35,y:88.65},0).wait(1).to({scaleX:0.9256,scaleY:0.9256,x:348.45,y:88.75},0).wait(1).to({scaleX:0.9251,scaleY:0.9251,x:348.7,y:88.9},0).wait(1).to({scaleX:0.9246,scaleY:0.9246,x:348.95,y:89.05},0).wait(1).to({scaleX:0.9238,scaleY:0.9238,x:349.4,y:89.25},0).wait(1).to({scaleX:0.9229,scaleY:0.9229,x:349.85,y:89.55},0).wait(1).to({scaleX:0.9218,scaleY:0.9218,x:350.4,y:89.85},0).wait(1).to({scaleX:0.9206,scaleY:0.9206,x:351,y:90.2},0).wait(1).to({scaleX:0.9192,scaleY:0.9192,x:351.75,y:90.65},0).wait(1).to({scaleX:0.9176,scaleY:0.9176,x:352.6,y:91.15},0).wait(1).to({scaleX:0.9158,scaleY:0.9158,x:353.45,y:91.65},0).wait(1).to({scaleX:0.914,scaleY:0.914,x:354.45,y:92.2},0).wait(1).to({scaleX:0.912,scaleY:0.912,x:355.4,y:92.75},0).wait(1).to({scaleX:0.91,scaleY:0.91,x:356.4,y:93.35},0).wait(1).to({scaleX:0.9081,scaleY:0.9081,x:357.45,y:93.95},0).wait(1).to({scaleX:0.9061,scaleY:0.9061,x:358.4,y:94.5},0).wait(1).to({scaleX:0.9043,scaleY:0.9043,x:359.3,y:95.05},0).wait(1).to({scaleX:0.9026,scaleY:0.9026,x:360.2,y:95.55},0).wait(1).to({scaleX:0.9011,scaleY:0.9011,x:361,y:96},0).wait(1).to({scaleX:0.8997,scaleY:0.8997,x:361.75,y:96.4},0).wait(1).to({scaleX:0.8985,scaleY:0.8985,x:362.35,y:96.8},0).wait(1).to({scaleX:0.8974,scaleY:0.8974,x:362.9,y:97.1},0).wait(1).to({scaleX:0.8965,scaleY:0.8965,x:363.35,y:97.4},0).wait(1).to({scaleX:0.8958,scaleY:0.8958,x:363.7,y:97.6},0).wait(1).to({scaleX:0.8951,scaleY:0.8951,x:364.05,y:97.8},0).wait(1).to({scaleX:0.8946,scaleY:0.8946,x:364.3,y:97.95},0).wait(1).to({scaleX:0.8943,scaleY:0.8943,x:364.5,y:98},0).wait(1).to({scaleX:0.894,scaleY:0.894,x:364.6,y:98.1},0).wait(1).to({regX:42.3,regY:26.4,scaleX:0.8939,scaleY:0.8939,x:364.7,y:97.9},0).to({_off:true},55).wait(2));

	// square shadow
	this.instance_21 = new lib.squareshadow();
	this.instance_21.setTransform(346,90.5,0.7489,0.744,0,0,0,71,48.3);
	this.instance_21.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(35).to({regX:71.3,regY:48.7,scaleX:0.5595,scaleY:0.4559,x:348.45,y:89.4},22,cjs.Ease.quadInOut).to({_off:true},1).wait(117));

	// screen
	this.instance_22 = new lib.WordUI();
	this.instance_22.setTransform(234.2,88.8,1.3474,1.3474,0,0,0,151.1,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(67).to({regX:150.7,regY:96.1,x:233.65,y:89.1},0).wait(22).to({regX:151.1,regY:95.9,x:234.2,y:88.8},0).wait(1).to({regX:150.7,regY:96.1,scaleX:1.3472,scaleY:1.3472,x:233.7,y:89.15},0).wait(1).to({scaleX:1.3467,scaleY:1.3467,x:233.9,y:89.2},0).wait(1).to({scaleX:1.3461,scaleY:1.3461,x:234.15,y:89.25},0).wait(1).to({scaleX:1.3452,scaleY:1.3452,x:234.5,y:89.4},0).wait(1).to({scaleX:1.3441,scaleY:1.3441,x:234.95,y:89.45},0).wait(1).to({scaleX:1.3428,scaleY:1.3428,x:235.45,y:89.65},0).wait(1).to({scaleX:1.3413,scaleY:1.3413,x:236.1,y:89.85},0).wait(1).to({scaleX:1.3394,scaleY:1.3394,x:236.8,y:90},0).wait(1).to({scaleX:1.3374,scaleY:1.3374,x:237.65,y:90.25},0).wait(1).to({scaleX:1.335,scaleY:1.335,x:238.55,y:90.55},0).wait(1).to({scaleX:1.3325,scaleY:1.3325,x:239.55,y:90.85},0).wait(1).to({scaleX:1.3298,scaleY:1.3298,x:240.6,y:91.15},0).wait(1).to({scaleX:1.327,scaleY:1.327,x:241.7,y:91.45},0).wait(1).to({scaleX:1.3241,scaleY:1.3241,x:242.9,y:91.8},0).wait(1).to({scaleX:1.3212,scaleY:1.3212,x:244,y:92.1},0).wait(1).to({scaleX:1.3184,scaleY:1.3184,x:245.1,y:92.45},0).wait(1).to({scaleX:1.3158,scaleY:1.3158,x:246.15,y:92.75},0).wait(1).to({scaleX:1.3133,scaleY:1.3133,x:247.1,y:93.05},0).wait(1).to({scaleX:1.3111,scaleY:1.3111,x:248.05,y:93.3},0).wait(1).to({scaleX:1.309,scaleY:1.309,x:248.8,y:93.55},0).wait(1).to({scaleX:1.3073,scaleY:1.3073,x:249.5,y:93.75},0).wait(1).to({scaleX:1.3057,scaleY:1.3057,x:250.1,y:93.95},0).wait(1).to({scaleX:1.3044,scaleY:1.3044,x:250.65,y:94.05},0).wait(1).to({scaleX:1.3033,scaleY:1.3033,x:251.1,y:94.2},0).wait(1).to({scaleX:1.3024,scaleY:1.3024,x:251.4,y:94.3},0).wait(1).to({scaleX:1.3017,scaleY:1.3017,x:251.7,y:94.4},0).wait(1).to({scaleX:1.3011,scaleY:1.3011,x:251.95,y:94.45},0).wait(1).to({scaleX:1.3008,scaleY:1.3008,x:252.1},0).wait(1).to({regX:151.1,regY:96,scaleX:1.3006,scaleY:1.3006,x:252.7,y:94.15},0).to({_off:true},55).wait(2));

	// screen shadow
	this.instance_23 = new lib.shadow_1();
	this.instance_23.setTransform(191.4,56.55,1.1271,1.1271,0,0,0,180.8,119.7);

	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(66).to({regX:180.7,regY:119.8,x:191.25,y:56.65},0).wait(1).to({regX:189.8,regY:149.6,x:201.5,y:90.25},0).wait(22).to({regX:180.7,regY:119.8,x:191.25,y:56.65},0).wait(1).to({regX:189.8,regY:149.6,scaleX:1.1268,scaleY:1.1268,x:201.65,y:90.35},0).wait(1).to({scaleX:1.1263,scaleY:1.1263,x:201.85,y:90.45},0).wait(1).to({scaleX:1.1256,scaleY:1.1256,x:202.15,y:90.65},0).wait(1).to({scaleX:1.1247,scaleY:1.1247,x:202.5,y:90.85},0).wait(1).to({scaleX:1.1236,scaleY:1.1236,x:203.05,y:91.1},0).wait(1).to({scaleX:1.1222,scaleY:1.1222,x:203.65,y:91.45},0).wait(1).to({scaleX:1.1205,scaleY:1.1205,x:204.3,y:91.85},0).wait(1).to({scaleX:1.1186,scaleY:1.1186,x:205.15,y:92.25},0).wait(1).to({scaleX:1.1164,scaleY:1.1164,x:206.1,y:92.75},0).wait(1).to({scaleX:1.1139,scaleY:1.1139,x:207.15,y:93.35},0).wait(1).to({scaleX:1.1113,scaleY:1.1113,x:208.25,y:94},0).wait(1).to({scaleX:1.1084,scaleY:1.1084,x:209.45,y:94.65},0).wait(1).to({scaleX:1.1054,scaleY:1.1054,x:210.7,y:95.35},0).wait(1).to({scaleX:1.1023,scaleY:1.1023,x:212,y:96.05},0).wait(1).to({scaleX:1.0993,scaleY:1.0993,x:213.3,y:96.75},0).wait(1).to({scaleX:1.0964,scaleY:1.0964,x:214.6,y:97.45},0).wait(1).to({scaleX:1.0936,scaleY:1.0936,x:215.75,y:98.1},0).wait(1).to({scaleX:1.0909,scaleY:1.0909,x:216.85,y:98.7},0).wait(1).to({scaleX:1.0886,scaleY:1.0886,x:217.85,y:99.3},0).wait(1).to({scaleX:1.0864,scaleY:1.0864,x:218.8,y:99.8},0).wait(1).to({scaleX:1.0846,scaleY:1.0846,x:219.6,y:100.2},0).wait(1).to({scaleX:1.0829,scaleY:1.0829,x:220.3,y:100.6},0).wait(1).to({scaleX:1.0815,scaleY:1.0815,x:220.85,y:100.95},0).wait(1).to({scaleX:1.0804,scaleY:1.0804,x:221.35,y:101.2},0).wait(1).to({scaleX:1.0794,scaleY:1.0794,x:221.75,y:101.45},0).wait(1).to({scaleX:1.0786,scaleY:1.0786,x:222.1,y:101.6},0).wait(1).to({scaleX:1.0781,scaleY:1.0781,x:222.3,y:101.75},0).wait(1).to({scaleX:1.0777,scaleY:1.0777,x:222.5,y:101.8},0).wait(1).to({regX:181.1,regY:120,scaleX:1.0775,scaleY:1.0775,x:212.8,y:69.75},0).to({_off:true},55).wait(2));

	// Layer_3
	this.ribbon_1 = new lib.ribbon();
	this.ribbon_1.name = "ribbon_1";
	this.ribbon_1.setTransform(245.75,16.95,2.14,2.14,30.6613,0,0,77,305.1);
	this.ribbon_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon_1).wait(84).to({_off:false},0).wait(91));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.9,-598,1909.3000000000002,1279.1);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{chart:4,vanish:55});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(74).call(this.frame_74).wait(1));

	// Layer_7
	this.instance = new lib.excel_screen_white();
	this.instance.setTransform(115.65,-128.65,1,1,0,0,0,225.3,151.3);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(61).to({_off:false},0).to({alpha:0.6016},13,cjs.Ease.cubicInOut).wait(1));

	// Layer_5
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(-19.5,-91.65);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({alpha:1},2,cjs.Ease.cubicInOut).wait(14));

	// Layer_3
	this.instance_2 = new lib.Rectangle111sml();
	this.instance_2.setTransform(-109.45,7.9,1.5099,1.5099);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(75));

	// SmallGraphCover
	this.instance_3 = new lib.whitebar();
	this.instance_3.setTransform(284.05,-150.1,1.1639,1.0777,0,0,0,17.8,38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(4).to({regX:17.9,scaleX:1.4222,x:288.8},0).to({scaleX:1.2503,scaleY:0.5617,x:285.75,y:-189.9},51,cjs.Ease.quartInOut).wait(20));

	// SmallGraph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4AA167").s().p("Ai/JMIAAyXIF/AAIAASXg");
	this.shape.setTransform(282.6,-128.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#327545").s().p("Ai/KhIAA1BIF/AAIAACpIAASYg");
	this.shape_1.setTransform(244.175,-136.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(75));

	// Layer_6
	this.chart_mask = new lib.chart_mask();
	this.chart_mask.name = "chart_mask";
	this.chart_mask.setTransform(-29.15,-97.5,1,1,0,0,0,59.1,63);
	this.chart_mask.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.chart_mask).wait(75));

	// Text
	this.instance_4 = new lib.textanimation("synched",0,false);
	this.instance_4.setTransform(-26.65,-93.55,1,1,0,0,0,33.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(75));

	// GraphMask
	this.instance_5 = new lib.GraphCover("synched",0,false);
	this.instance_5.setTransform(-57.95,-124.7,1,1,0,0,0,28.9,28.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(75));

	// Graph_LG
	this.instance_6 = new lib.graphLG();
	this.instance_6.setTransform(-28.95,-95.65,1,1,0,0,0,49.9,49.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(75));

	// UI
	this.instance_7 = new lib.UI();
	this.instance_7.setTransform(115.85,-274.1,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(75));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.6,-279.6,471.79999999999995,305.70000000000005);


(lib.Pop_up_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.opt3 = new lib.option_btn();
	this.opt3.name = "opt3";
	this.opt3.setTransform(134.5,77.3,1,1,0,0,0,134.5,14.3);

	this.opt2 = new lib.option_btn();
	this.opt2.name = "opt2";
	this.opt2.setTransform(134.5,45.3,1,1,0,0,0,134.5,14.3);

	this.opt1 = new lib.option_btn();
	this.opt1.name = "opt1";
	this.opt1.setTransform(134.5,13.3,1,1,0,0,0,134.5,14.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.opt1},{t:this.opt2},{t:this.opt3}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Pop_up_menu, new cjs.Rectangle(-0.2,-1.2,240.5,96.5), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(98.65,16.05,0.7,0.7,0,0,0,13.8,10.8);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(57.4,15.1,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("ApKCdIAAk5ISUAAIAAE5g");
	this.shape.setTransform(58.65,15.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D7").s().p("ApLCeIAAk7ISXAAIAAE7g");
	this.shape_1.setTransform(58.75,15.775);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,0,117.5,31.6), null);


(lib.screenanimationexcel = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		//this.title_s.cache(-38,-15.7,152,63,2);
	}
	this.frame_44 = function() {
		this.screen.gotoAndPlay("chart");
	}
	this.frame_99 = function() {
		this.td_graph.gotoAndPlay("grow");
	}
	this.frame_160 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(55).call(this.frame_99).wait(61).call(this.frame_160).wait(1));

	// icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.setTransform(35.45,-49.8,1.2333,1.2333,0,0,0,64.7,62.9);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(89).to({scaleX:1.2734,scaleY:1.2734,x:66.4,y:-49.2},30,cjs.Ease.cubicInOut).wait(42));

	// td_graph
	this.td_graph = new lib._3D_price();
	this.td_graph.name = "td_graph";
	this.td_graph.setTransform(147.35,40.05,0.6248,0.561,0,0,0,5.1,0.7);

	this.timeline.addTween(cjs.Tween.get(this.td_graph).wait(89).to({regX:5,scaleX:0.6451,scaleY:0.5792,x:181.85,y:43.55},30,cjs.Ease.cubicInOut).wait(42));

	// screen3
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(218.15,-16.45,0.7374,0.5902,0,-28.3389,-17.0404,107.4,-133.6);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(89).to({regX:107.5,regY:-133.8,scaleX:0.7613,scaleY:0.6093,skewX:-28.3395,skewY:-17.0418,x:255.05,y:-14.9},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_2
	this.instance = new lib.shadow_1();
	this.instance.setTransform(187.15,-42.95,1.1264,1.1264,0,0,0,180.7,119.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(89).to({regX:180.8,regY:119.4,scaleX:1.163,scaleY:1.163,x:222.95,y:-42.05},30,cjs.Ease.cubicInOut).wait(42));

	// Layer_4
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(144.7,-572.7,1.7467,1.7467,11.9343,0,0,0,-0.3);
	this.ribbon._off = true;

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(79).to({_off:false},0).wait(82));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.5,-555.4,525.7,1083.1);


(lib.object_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.screen = new lib.screenanimation_1();
	this.screen.name = "screen";
	this.screen.setTransform(6.7,194.4,0.79,0.79,0,0,0,196.9,130.8);

	this.screen_1 = new lib.screenanimation();
	this.screen_1.name = "screen_1";
	this.screen_1.setTransform(9.3,182.35,1,1,0,0,0,197.1,130.8);

	this.screen_2 = new lib.screenanimationexcel();
	this.screen_2.name = "screen_2";
	this.screen_2.setTransform(14.2,275.5,0.79,0.79,0,0,0,196.9,130.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen}]}).to({state:[{t:this.screen_1}]},1).to({state:[{t:this.screen_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-177,-154.9,394,600);


(lib.Page = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// obj1
	this.obj1 = new lib.object_1();
	this.obj1.name = "obj1";
	this.obj1.setTransform(265.8,375.5,1,1,0,0,0,127.8,219.5);

	this.timeline.addTween(cjs.Tween.get(this.obj1).wait(1));

	// bg
	this.bg = new lib.Page_bg();
	this.bg.name = "bg";
	this.bg.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page, new cjs.Rectangle(-225.6,-178.6,715.1,963.5), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(953.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(218.5,549.8,0.9555,0.9555,0,0,0,0.8,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(182.85,536.6,1,1,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// page
	this.page = new lib.Page();
	this.page.name = "page";
	this.page.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.page).wait(1));

	// option_hits
	this.hit_down = new lib.option_hit();
	this.hit_down.name = "hit_down";
	this.hit_down.setTransform(159,650.9,0.9466,0.9585,0,0,0,134.7,14.5);
	new cjs.ButtonHelper(this.hit_down, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit_opts = new lib.option_hit();
	this.hit_opts.name = "hit_opts";
	this.hit_opts.setTransform(159,551.55,0.9466,0.9585,0,0,0,134.7,14.6);
	new cjs.ButtonHelper(this.hit_opts, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit3 = new lib.option_hit();
	this.hit3.name = "hit3";
	this.hit3.setTransform(159,519.95,0.9466,0.9585,0,0,0,134.7,14.5);
	new cjs.ButtonHelper(this.hit3, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(159,488.35,0.9466,0.9585,0,0,0,134.7,14.6);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(159,456.75,0.9466,0.9585,0,0,0,134.7,14.6);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit3},{t:this.hit_opts},{t:this.hit_down}]}).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3WHgIAAu/MAutAAAIAAO/g");
	mask.setTransform(150.025,489.35);

	// options
	this.popup_menu = new lib.Pop_up_menu();
	this.popup_menu.name = "popup_menu";
	this.popup_menu.setTransform(110.5,478.9,1,1,0,0,0,79.5,35.9);

	var maskedShapeInstanceList = [this.popup_menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.popup_menu).wait(1));

	// opts
	this.opts = new lib.option_btn_menu();
	this.opts.name = "opts";
	this.opts.setTransform(165.5,551.05,1,1,0,0,0,134.5,14.3);

	this.timeline.addTween(cjs.Tween.get(this.opts).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// first_frame
	this.background = new lib.mountain_anim();
	this.background.name = "background";
	this.background.setTransform(284.4,25.1,1,1,0,0,0,284.4,25.1);

	this.timeline.addTween(cjs.Tween.get(this.background).wait(1));

	// Bg
	this.instance = new lib.whitecopy();
	this.instance.setTransform(483.1,169.9,1,1,0,0,0,483.1,169.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-125.9,-2.8,1091.3,671.1999999999999), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var frequency = 5; 
		stage.enableMouseOver(frequency);
		
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "page") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillPage(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt1") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_1(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt2") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_2(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opt3") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption_3(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "opts") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillOption(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillPage = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.page.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.opts.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_1 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt1.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_2 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt2.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillOption_3 = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.popup_menu.opt3.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		var mc = exportRoot.mainMC
		var opt1 = mc.popup_menu.opt1
		var opt2 = mc.popup_menu.opt2
		var opt3 = mc.popup_menu.opt3
		var opts = mc.opts
		
		var hit1 = mc.hit1
		var hit2 = mc.hit2
		var hit3 = mc.hit3
		var hit_opts = mc.hit_opts
		var hit_down = mc.hit_down
		
		this.runBanner = function() {
			
			mc.replay_btn.visible=false
			mc.page.alpha=0
			
			mc.cta.alpha=0
			mc.txtCta.alpha=0
			
			this.TL_Popup = new TimelineMax();	
			exportRoot.TL_Popup.add('frame0');
				exportRoot.TL_Popup.to(hit_opts, 0.1, {y: "+=100"}, "-=0");
				exportRoot.TL_Popup.from(opt1, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0");
				exportRoot.TL_Popup.from(hit1, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");		
				exportRoot.TL_Popup.from(opt2, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit2, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(opt3, 0.6, {y: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.from(hit3, 0.6, {y: "+=100", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_Popup.to(hit_down, 0.1, {y: "-=100"}, "-=0");
			exportRoot.TL_Popup.add('frame1');
			exportRoot.TL_Popup.stop();
			
				this.TL_MainScreen = new TimelineMax();
				exportRoot.TL_MainScreen.add('frame0')
				
				exportRoot.TL_MainScreen.from(mc.background, 0.1, {x: "+=200", ease:Power2.easeOut, onStart:function(){mc.background.ribbon.play();}}, "+=0");
		
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainScreen.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
		
				}
				exportRoot.TL_MainScreen.from(opts, 0.6, {x: "+=100", alpha:0, ease:Power3.easeOut}, "-=0.4");
				exportRoot.TL_MainScreen.from(hit_opts, 0.6, {x: "+=100", ease:Power3.easeOut}, "-=0.6");		
				
				//exportRoot.TL_MainScreen.stop();
				exportRoot.TL_MainScreen.add('frame1');
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "+=0");
					if (i!=0) exportRoot.TL_MainScreen.to(exportRoot.headline1[i], 0.6, { x: "-=100", alpha: 0, ease:Power3.easeIn}, "-=0.5");
				}
				
				exportRoot.TL_MainScreen.to(mc.background, 0.8, {x: "-=150", ease:Power3.easeIn}, "-=0.6");
				exportRoot.TL_MainScreen.to(opts, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.7");
				exportRoot.TL_MainScreen.to(hit_opts, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit_down, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt1, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit1, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt2, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit2, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(opt3, 0.8, {x: "-=150", alpha:0, ease:Power3.easeIn}, "-=0.8");
				exportRoot.TL_MainScreen.to(hit3, 0.8, {x: "-=250", ease:Power3.easeIn}, "-=0.8");
		
				exportRoot.TL_MainScreen.add('frame2')
							
				exportRoot.TL_MainScreen.stop();	
				
				mc.logo_intro.gotoAndPlay(1)
				
			exportRoot.tltxt1 = new TimelineMax();
			exportRoot.tltxt1.add('frame0')
			for (var i = 0; i < exportRoot.page_1_1.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_1_2.length; i++) {
				if (i==0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt1.from(exportRoot.page_1_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt1.add('frame1')	
			exportRoot.tltxt1.stop();
			
			exportRoot.tltxt2 = new TimelineMax();
			exportRoot.tltxt2.add('frame0')
			for (var i = 0; i < exportRoot.page_2_1.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_2_2.length; i++) {
				if (i==0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt2.from(exportRoot.page_2_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			exportRoot.tltxt2.add('frame1')	
			exportRoot.tltxt2.stop();
			
			exportRoot.tltxt3 = new TimelineMax();
			exportRoot.tltxt3.add('frame0')
			for (var i = 0; i < exportRoot.page_3_1.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"+=2.5");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_1[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
			for (var i = 0; i < exportRoot.page_3_2.length; i++) {
				if (i==0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut},"-=.6");
				if (i!=0) exportRoot.tltxt3.from(exportRoot.page_3_2[i], .8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=.7")
			}
				
			exportRoot.tltxt3.add('frame1')	
			exportRoot.tltxt3.stop();
			
			//
			//   FRAME 2 ANIMATION IN / OUT
			//
			exportRoot.TL_Frame2_IN = new TimelineMax();
			
			mc.cta.alpha=1
			mc.txtCta.alpha=1
				
			exportRoot.TL_Frame2_IN.add('frame0')
			exportRoot.TL_Frame2_IN.from(mc.page.bg, 1, {x: "+=450",  ease:Power4.easeOut}, "+=0.3");
			//exportRoot.TL_Frame2_IN.from(mc.page.ribbon, 2, {x: "+=400",  ease:Power4.easeOut}, "-=1");
			exportRoot.TL_Frame2_IN.from(mc.page.obj1, 1.5, {x: "+=400",  ease:Power4.easeOut, onStart:function(){mc.page.obj1.screen.play();}}, "-=1");
		
			exportRoot.TL_Frame2_IN.from(mc.txtCta, 1, { alpha: 0, x: "+=100", ease:Power4.easeOut}, "+=1.8");
			exportRoot.TL_Frame2_IN.from(mc.cta, 1, {	alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=1");
			
			exportRoot.TL_Frame2_IN.add('frame1')
			
			exportRoot.TL_Frame2_IN.stop()	
		}
		
		exportRoot.selectedOption = function(id) {
			
			//exportRoot.TL_MainScreen.timeScale(1)
			//exportRoot.TL_Clouds.tweenFromTo("frame1", "frame2");
			exportRoot.TL_MainScreen.tweenFromTo("frame1", "frame2");
				
			exportRoot.selectedScreenIn(id)
				
		}
		exportRoot.mainScreenOut = function() {
		
		}
		var IDtest = 0
		exportRoot.selectedScreenIn = function(id) {
			IDtest = id
			mc.page.obj1.gotoAndStop(id-1)
			//mc.page.ribbon.gotoAndStop(id-1)
			
			mc.page.alpha=1
			var pageID = id
			mc.page.obj1.visible=true
			mc.page.obj1.alpha = 1
		
			if (id==1) {
				exportRoot.tltxt1.tweenFromTo("frame0", "frame1",{delay:.3});
				};
			if (id==2) {
				exportRoot.tltxt2.tweenFromTo("frame0", "frame1",{delay:.3});
				};
			if (id==3) {
				exportRoot.tltxt3.tweenFromTo("frame0", "frame1",{delay:.3});
				};
		
			exportRoot.TL_Frame2_IN.tweenFromTo("frame0", "frame1",{delay:.3});
		
		}
		
		function mainOver() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(1);
		}
		function mainOut() {
			exportRoot.mainMC.cta.arrow.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(24,297.2,941.4,339.8);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593187603376", id:"M365_FY21Q1_BTS_USA_300x600_BAN_InteractiveStudent_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;