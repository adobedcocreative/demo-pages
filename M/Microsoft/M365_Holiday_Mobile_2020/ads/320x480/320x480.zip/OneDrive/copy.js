// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	bannerData.headline1 = ["<#a80000>Protect joyful|moments in the cloud","20px",31, 60,"22","3 50", "left"];
	bannerData.headline2 = ["<#505050>With 1 TB of OneDrive cloud storage","14px",32, 113,"16","3 50", "left"];

	bannerData.CTA = ["<#FFFFFF>BUY NOW","14px",0,00,"50","300", "left"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
