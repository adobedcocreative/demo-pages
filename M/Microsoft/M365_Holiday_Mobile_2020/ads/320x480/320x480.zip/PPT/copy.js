// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#A80000>Kickstart your |holiday creativity" ,"22.2px",33, 58,"25.8","3 50", "left"];
	bannerData.headline2 = ["<#505050>Spread cheer with 3D |animations in PowerPoint","14.2px",33,113,"15.2","3 50", "left"];


	bannerData.CTA = ["<#FFFFFF>BUY NOW","14px",2,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
