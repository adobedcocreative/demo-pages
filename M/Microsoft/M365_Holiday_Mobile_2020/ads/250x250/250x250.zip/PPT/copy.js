// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#A80000>Kickstart your |holiday creativity","18px",17, 41,"21","3 50", "left"];
	bannerData.headline2 = ["<#505050>Spread cheer |with 3D |animations in |PowerPoint","12px",17,88,"14","3 50", "left"];


	bannerData.CTA = ["<#FFFFFF>BUY NOW","12px",-2,-1,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 2,0]
