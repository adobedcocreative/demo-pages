// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	bannerData.headline1 = ["<#a80000>Protect joyful moments |in the cloud","18.4px",16, 43,"20","3 50", "left"];
	bannerData.headline2 = ["<#505050>With 1 TB of OneDrive |cloud storage","12.2px",16, 90,"14","3 50", "left"];

	bannerData.CTA = ["<#FFFFFF>BUY NOW","12.5px",8,0.5,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
