function frame0Anim() {

    exportRoot.runBanner = function() {

    }

}