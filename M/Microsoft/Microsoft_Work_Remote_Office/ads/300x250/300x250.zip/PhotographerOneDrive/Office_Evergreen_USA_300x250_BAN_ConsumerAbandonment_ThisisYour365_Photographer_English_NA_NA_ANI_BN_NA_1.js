(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[502,0,204,163],[0,0,500,408],[304,410,300,250],[0,410,302,252],[502,165,155,77],[502,244,120,77],[659,165,91,77],[708,79,60,77],[708,0,65,77],[502,323,103,78],[606,403,103,78]]}
];


// symbols:



(lib._300x600_laptop = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.final_img_2 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.final_img_300_snippet = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.frame_1_fg = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.tile_13 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.tile_14 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.tile_15 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.tile_16 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.tile_18 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.tile_19 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.tile_20 = function() {
	this.initialize(ss["Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteRect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteRect, new cjs.Rectangle(0,0,300,250), null);


(lib.whiteCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AryT2MAAAgnsIXlAAMAAAAnsg");
	this.shape.setTransform(75.525,127.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteCover, new cjs.Rectangle(0,0,151.1,254.1), null);


(lib.whiteBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAvuMAAAhfbMAu3AAAMAAABfbg");
	this.shape.setTransform(150,305.425);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whiteBG, new cjs.Rectangle(0,0,300,610.9), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.final_img_300_snippet();
	this.instance.setTransform(-47,-73);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47,-73,300,250);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.final_img_2();
	this.instance.setTransform(-477,-366,1.946,1.946);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-477,-366,973,794);


(lib.tile_20_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_20();
	this.instance.setTransform(-51.5,-39);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_20_1, new cjs.Rectangle(-51.5,-39,103,78), null);


(lib.tile_19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_19();
	this.instance.setTransform(-51.5,-39);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_19_1, new cjs.Rectangle(-51.5,-39,103,78), null);


(lib.tile_18_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEGBIAAsBIKJAAIAAMBg");

	// Layer_2
	this.instance = new lib.tile_18();
	this.instance.setTransform(-33,-39);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_18_1, new cjs.Rectangle(-32.5,-38.5,64.5,76.5), null);


(lib.tile_16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkrGBIAAsBIJXAAIAAMBg");

	// Layer_2
	this.instance = new lib.tile_15();
	this.instance.setTransform(50,-39,1,1,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_16_1, new cjs.Rectangle(-30,-38.5,60,76.5), null);


(lib.tile_15_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnGGBIAAsBIONAAIAAMBg");

	// Layer_2
	this.instance = new lib.final_img_2();
	this.instance.setTransform(-155,-70,0.4928,0.4928);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_15_1, new cjs.Rectangle(-45.5,-38.5,91,77), null);


(lib.tile_14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_14();
	this.instance.setTransform(-60,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_14_1, new cjs.Rectangle(-60,-38.5,120,77), null);


(lib.tile_13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_13();
	this.instance.setTransform(-77.5,-38.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_13_1, new cjs.Rectangle(-77.5,-38.5,155,77), null);


(lib.tile_12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3YLnIAA3NMAuxAAAIAAXNg");
	mask.setTransform(79.675,-22.875);

	// Layer_5
	this.instance = new lib.final_img_300_snippet();
	this.instance.setTransform(-69,-121,1,0.7051);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_12copy, new cjs.Rectangle(-69,-97.2,298.4,148.7), null);


(lib.tile_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlNH3IAAvtIKbAAIAAPtg");
	mask.setTransform(1.15,11.8);

	// Layer_2
	this.instance = new lib.tile_20();
	this.instance.setTransform(97.2,-39,1.4,1.4,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_10, new cjs.Rectangle(-32.2,-38.5,66.80000000000001,100.7), null);


(lib.replaySub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCoICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh9QAAgJgGgDQgDgHgJAAQgHAAgGAHQgGADAAAJIAAAxQAAABgDACQAAADgCAAQgCAAgCgDQgCgCAAgBIAAg/QAAgJgHgEQgDgGgJAAQgIAAgHAGQgGAEAAAJIAAAzQgBABgCAAQgDAAgBgBIAAhDQAAgGgGgHQgGgEgJAAQgIAAgEAEQgCAAAAABQgGAGAAAGIAABAQAAADAAABQgBAAgDAAQgCAAgBAAQAAgBAAgDIAAh6QAAgJgGgEQgHgGgIAAQgJAAgDAGQgGAEAAAJIAACqQAAADgCAAQAAABgCAAQgDADgDgDQgDgEgCgGIgEgOQAAgCgCAAIgPgRIgBgCQgRgNgOAKIAAADQgGAGgCAFQgDAIAFAIIBWBtIADACQADAHAAAHIAAAfQAAACACAAQACACACAAg");
	this.shape.setTransform(14.1804,16.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcCoQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhtQgFgIADgIQACgGAGgFIAAgEQAOgJARANIABACIAPARQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAGADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAirQAAgIAGgEQADgGAJAAQAIAAAHAGQAGAEAAAIIAAB7IAAADIADAAIAEAAIAAgDIAAhAQAAgHAGgFQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQAEgEAIAAQAJAAAGAEQAGAGAAAHIAABCIAEABIADgBIAAgyQAAgKAGgDQAHgGAIAAQAJAAADAGQAHADAAAKIAAA/QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgxQAAgJAGgDQAGgHAHAAQAJAAADAHQAGADAAAJIAAB9IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_1.setTransform(14.1804,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1.5,1,1).p("AgcCVICCAAQADAAABgCIAAgoQAAgGACgGIAVgrIAAADQABgEAAgFIAAh0QAAgIgGgEIAAgCQgDgEgJAAQgHAAgGAEIAAACQgGAEAAAIIAAAnQAAACgDACQAAADgCAAQgCAAgCgDQgCgCAAgCIAAg1QAAgIgHgFIAAgBQgDgGgJAAQgIAAgHAGIAAABQgGAFAAAIIAAApQgBABgCAAQgDAAgBgBIAAg3QAAgIgGgGQgGgEgJAAQgIAAgEAEIgCAAQgGAGAAAIIAAA1QAAACAAABQgBAAgDAAQgCAAgBAAQAAgBAAgCIAAhTQAAgIgGgGQgHgGgIAAQgGAAgGAGQgGAGAAAIIAACDQAAADgCAAQAAAAgCAAQgDADgDgDQgDgDgCgFIgEgPQAAgBgCAAIgPgTIgBgBQgRgNgOAJIAAAEQgGAFgCAGQgDAJAFAIIBWBsIADACQADAGAAAIIAAAfQAAACACAAQACACACAAg");
	this.shape_2.setTransform(14.1804,18.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#BCBCBC","#FCFCFC","#FFFFFF"],[0,0.259,1],-7.3,-14.5,1.8,9.6).s().p("AgcCVQAAAAgBAAQgBAAAAgBQgBAAAAAAQAAgBgBgBQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAgBIAAgeQAAgIgDgGIgDgCIhWhsQgFgIADgJQACgGAGgFIAAgEQAOgJARANIABACIAPASQAAAAABAAQAAAAAAAAQAAABABAAQAAAAAAAAIAEAPQACAFADAEQADACADgCIACgBQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBIAAiDQAAgHAGgHQAGgGAGAAQAIAAAHAGQAGAHAAAHIAABTIAAADIADAAIAEAAIAAgDIAAg1QAAgIAGgGIACAAQAEgDAIgBQAJABAGADQAGAGAAAIIAAA3IAEABIADgBIAAgpQAAgHAGgGIAAgBQAHgGAIAAQAJAAADAGIAAABQAHAGAAAHIAAA2QAAAAAAAAQAAABAAAAQABABAAAAQABAAAAABQABABAAAAQABABAAAAQABABAAAAQAAAAABAAQAAAAABAAQAAAAAAgBQAAAAABgBQAAAAAAgBQAAgBABAAQABAAAAgBQAAAAABgBQAAAAAAAAIAAgoQAAgIAGgEIAAgCQAGgEAHAAQAJAAADAEIAAACQAGAEAAAIIAAB0IgBAJIAAgDIgVArQgCAGAAAGIAAAnQAAABgBABQAAAAgBAAQAAABgBAAQAAAAgBAAg");
	this.shape_3.setTransform(14.1804,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},1).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.2,-1.2,28,35.6);


(lib.PageLayout_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Flow", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.PageLayout_txt, new cjs.Rectangle(0,0,18.4,15.5), null);


(lib.Name_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Daniela Duarte", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Name_txt, new cjs.Rectangle(0,0,44.5,13.6), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Insert_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Upload", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Insert_txt, new cjs.Rectangle(0,0,26.5,15.5), null);


(lib.Home_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("New", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Home_txt, new cjs.Rectangle(0,0,18.1,16), null);


(lib.Formulas_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Sync", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Formulas_txt, new cjs.Rectangle(0,0,18.3,15.5), null);


(lib.Excel_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("OneDrive", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_txt, new cjs.Rectangle(0,0,28.9,17.5), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.AutoSave_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Office 365", "6px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 10;
	this.txt.lineWidth = 30;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.AutoSave_txt, new cjs.Rectangle(0,0,33.6,21.7), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3/GkIAAtHMAv/AAAIAANHg");
	mask.setTransform(153.6,42);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ANiCnQgSgTAAgoIAAh8IhWAAIAADEIg6AAIAAjEIgpAAIAAgwIApAAIAAgiQAAgmAZgZQAZgYAnAAIATABQAIAAAGADIAAAyIgKgEQgIgDgIABQgTAAgJALQgKALAAAWIAAAdIBWAAIAAg2IA6gSIAABIIA6AAIAAAwIg6AAIAABxQAAAXAIAJQAIAKASAAIAMgDIAMgFIAAAvQgGADgMADQgLACgOAAQglAAgSgTgAG3CZQgigiAAg6QAAg8AjgjQAjgjA8AAQA5AAAgAiQAhAjAAA4QAAA8gjAjQghAjg8AAQg4AAgighgAHjAAQgSAVAAAnQAAAmASAUQARAUAhABQAfgBAQgUQARgUAAgoQAAgogRgTQgRgTgfAAQgfAAgSAUgAD5C2QgUgEgLgFIAAg5QANALAUAHQAUAGANABQATgBAKgFQAJgGAAgNQAAgLgJgIQgKgJgbgKQgggOgNgRQgNgQAAgaQAAggAagVQAagVAqgBQANAAAQAEQASADAIADIAAA4QgLgJgPgFQgOgFgQAAQgRAAgJAGQgJAHAAAKQAAAMAIAHQAIAIAaAKQAkAPANAQQAOARAAAZQAAAigbAWQgZAUgvAAQgQAAgRgEgAgbCZQghgiAAg6QAAg8AigjQAigjA8AAQA5AAAhAiQAgAjAAA4QAAA8giAjQgiAjg7AAQg5AAghghgAAQAAQgQAVAAAnQAAAmAQAUQASAUAgABQAfgBARgUQAQgUAAgoQAAgogRgTQgRgTgfAAQgfAAgSAUgAmWCYQgigiAAg1QAAg7AiglQAjgnA/AAQAPAAASAFQASAFAIAFIAAA2QgNgJgOgGQgOgFgOAAQgiAAgVAVQgVAXAAAlQAAAmAUATQAUAWAiAAQANgBAQgFQAQgHAMgJIAAA1QgOAJgRADQgQAEgXAAQg2AAghgigAjNC0IAAj0IA5AAIAAAnIABAAQAIgUAQgLQAQgMAWABIANABIAJACIAAA6QgEgDgJgDQgJgDgMAAQgWAAgOARQgPAQAAAnIAAB7gAoaC0IAAj0IA6AAIAAD0gAqNC0IAAkKIgBAAIhpEKIgoAAIhskKIgBAAIAAEKIg3AAIAAlUIBVAAIBiD8IACAAIBnj8IBSAAIAAFUgAoWhuQgKgKAAgOQAAgOALgKQAJgKAPAAQAPAAAKALQAKAJAAAOQAAAOgKAKQgKAJgPAAQgPAAgKgJg");
	this.shape.setTransform(201.475,18.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhPBeQgfggAAg9QAAg4AigkQAigjAwAAQAyAAAbAgQAcAgAAA5IAAAUIilAAQABAiAUASQATASAiAAQAoAAAggXIAAAtQgiAUg2AAQg1AAgeghgAgihEQgRARgDAcIBwAAQgBgegNgQQgOgRgYAAQgXAAgRASg");
	this.shape_1.setTransform(213.475,71.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("Ag9BeQghgiAAg2QAAg8AkgkQAkgkA6AAQAjAAAYALIAAA0QgZgTgdAAQgkAAgUAXQgXAYAAAlQAAAmAVAWQAVAWAjAAQAeAAAagVIAAAwQgdAQgoAAQg2AAghghg");
	this.shape_2.setTransform(190.675,71.225);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgbCzIAAjzIA2AAIAADzgAgXh8QgJgIAAgOQAAgOAJgJQAKgJANAAQAOAAAJAJQAKAJAAAOQAAAMgKAKQgJAJgOAAQgNAAgKgJg");
	this.shape_3.setTransform(175.225,65.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgnC3IAAjHIgpAAIAAgsIApAAIAAgnQAAgmAZgXQAZgWAlAAQAVAAAMAFIAAAtQgLgGgOAAQgpAAAAAtIAAAhIA5AAIAAAsIg5AAIAADHg");
	this.shape_4.setTransform(162.2,65.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgmC3IAAjHIgqAAIAAgsIAqAAIAAgnQAAgnAZgWQAYgWAmAAQAUAAAMAFIAAAtQgLgGgOAAQgpAAAAAtIAAAhIA5AAIAAAsIg4AAIAADHg");
	this.shape_5.setTransform(146.925,65.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ah2CAQgtgwAAhMQAAhRAtgxQAugxBMAAQBIAAAsAvQAsAxAABLQAABTgtAxQgtAwhKAAQhKAAgsgwgAhKhaQgdAiAAA5QAAA5AcAiQAdAjAuAAQAwAAAcgiQAcghAAg7QAAg8gbghQgbgigxABQguAAgdAjg");
	this.shape_6.setTransform(120.425,66.35);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhjCgIAAg1QAiAWAiAAQAhAAAVgSQAWgRgBgeQABgdgWgQQgVgQgoAAIg3ADIALiyICnAAIAAAvIh5AAIgGBVIAfgBQA1AAAdAcQAdAbAAAwQAAAzghAeQgiAeg6AAQgyAAgYgNg");
	this.shape_7.setTransform(297.15,66.675);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AhSCGQgggoABhLQAAg6ASgsQASgsAhgYQAigYAqAAQApAAATAKIAAAxQgdgOgdAAQgoAAgZAjQgZAigBA7IABAAQALgUAUgLQAUgLAWAAQAtAAAaAcQAbAdgBAvQAAAhgOAcQgPAagZAOQgbAPgeAAQg1AAgggqgAgmAQQgRARAAAaQABATAHARQAIARAMAJQAOAKAQAAQAagBAPgRQAPgTAAgdQAAgfgPgSQgPgQgaAAQgZAAgQAQg");
	this.shape_8.setTransform(272.05,66.4);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhECqQgXgFgMgHIAAg2QARAMAVAHQAWAIAVAAQAfAAATgQQATgOAAgaQAAgcgWgPQgXgPgoAAIgeAAIAAgsIAdAAQAkAAATgNQATgOABgbQAAgXgQgOQgQgMgbAAQgjAAggAYIAAgyQAQgJAVgFQAVgFAYAAQAeAAAXALQAYAMALARQAMAUgBAXQAAAggRAWQgSAWggAIIAAABQAmAFAUAUQAVAWAAAhQAAAughAdQgiAcg6AAQgWAAgYgGg");
	this.shape_9.setTransform(246.9,66.4);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(104.1,0,203.1,84), null);


(lib.ClipGroup_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("A3/GkIAAtHMAv/AAAIAANHg");
	mask_1.setTransform(153.6,42);

	// Layer_3
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#727272").s().p("ANiCnQgSgTAAgoIAAh8IhWAAIAADEIg6AAIAAjEIgpAAIAAgwIApAAIAAgiQAAgmAZgZQAZgYAnAAIATABQAIAAAGADIAAAyIgKgEQgIgDgIABQgTAAgJALQgKALAAAWIAAAdIBWAAIAAg2IA6gSIAABIIA6AAIAAAwIg6AAIAABxQAAAXAIAJQAIAKASAAIAMgDIAMgFIAAAvQgGADgMADQgLACgOAAQglAAgSgTgAG3CZQgigiAAg6QAAg8AjgjQAjgjA8AAQA5AAAgAiQAhAjAAA4QAAA8gjAjQghAjg8AAQg4AAgighgAHjAAQgSAVAAAnQAAAmASAUQARAUAhABQAfgBAQgUQARgUAAgoQAAgogRgTQgRgTgfAAQgfAAgSAUgAD5C2QgUgEgLgFIAAg5QANALAUAHQAUAGANABQATgBAKgFQAJgGAAgNQAAgLgJgIQgKgJgbgKQgggOgNgRQgNgQAAgaQAAggAagVQAagVAqgBQANAAAQAEQASADAIADIAAA4QgLgJgPgFQgOgFgQAAQgRAAgJAGQgJAHAAAKQAAAMAIAHQAIAIAaAKQAkAPANAQQAOARAAAZQAAAigbAWQgZAUgvAAQgQAAgRgEgAgbCZQghgiAAg6QAAg8AigjQAigjA8AAQA5AAAhAiQAgAjAAA4QAAA8giAjQgiAjg7AAQg5AAghghgAAQAAQgQAVAAAnQAAAmAQAUQASAUAgABQAfgBARgUQAQgUAAgoQAAgogRgTQgRgTgfAAQgfAAgSAUgAmWCYQgigiAAg1QAAg7AiglQAjgnA/AAQAPAAASAFQASAFAIAFIAAA2QgNgJgOgGQgOgFgOAAQgiAAgVAVQgVAXAAAlQAAAmAUATQAUAWAiAAQANgBAQgFQAQgHAMgJIAAA1QgOAJgRADQgQAEgXAAQg2AAghgigAjNC0IAAj0IA5AAIAAAnIABAAQAIgUAQgLQAQgMAWABIANABIAJACIAAA6QgEgDgJgDQgJgDgMAAQgWAAgOARQgPAQAAAnIAAB7gAoaC0IAAj0IA6AAIAAD0gAqNC0IAAkKIgBAAIhpEKIgoAAIhskKIgBAAIAAEKIg3AAIAAlUIBVAAIBiD8IACAAIBnj8IBSAAIAAFUgAoWhuQgKgKAAgOQAAgOALgKQAJgKAPAAQAPAAAKALQAKAJAAAOQAAAOgKAKQgKAJgPAAQgPAAgKgJg");
	this.shape_10.setTransform(201.475,18.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#727272").s().p("AhPBeQgfggAAg9QAAg4AigkQAigjAwAAQAyAAAbAgQAcAgAAA5IAAAUIilAAQABAiAUASQATASAiAAQAoAAAggXIAAAtQgiAUg2AAQg1AAgeghgAgihEQgRARgDAcIBwAAQgBgegNgQQgOgRgYAAQgXAAgRASg");
	this.shape_11.setTransform(213.475,71.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#727272").s().p("Ag9BeQghgiAAg2QAAg8AkgkQAkgkA6AAQAjAAAYALIAAA0QgZgTgdAAQgkAAgUAXQgXAYAAAlQAAAmAVAWQAVAWAjAAQAeAAAagVIAAAwQgdAQgoAAQg2AAghghg");
	this.shape_12.setTransform(190.675,71.225);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#727272").s().p("AgbCzIAAjzIA2AAIAADzgAgXh8QgJgIAAgOQAAgOAJgJQAKgJANAAQAOAAAJAJQAKAJAAAOQAAAMgKAKQgJAJgOAAQgNAAgKgJg");
	this.shape_13.setTransform(175.225,65.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#727272").s().p("AgnC3IAAjHIgpAAIAAgsIApAAIAAgnQAAgmAZgXQAZgWAlAAQAVAAAMAFIAAAtQgLgGgOAAQgpAAAAAtIAAAhIA5AAIAAAsIg5AAIAADHg");
	this.shape_14.setTransform(162.2,65.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#727272").s().p("AgmC3IAAjHIgqAAIAAgsIAqAAIAAgnQAAgnAZgWQAYgWAmAAQAUAAAMAFIAAAtQgLgGgOAAQgpAAAAAtIAAAhIA5AAIAAAsIg4AAIAADHg");
	this.shape_15.setTransform(146.925,65.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#727272").s().p("Ah2CAQgtgwAAhMQAAhRAtgxQAugxBMAAQBIAAAsAvQAsAxAABLQAABTgtAxQgtAwhKAAQhKAAgsgwgAhKhaQgdAiAAA5QAAA5AcAiQAdAjAuAAQAwAAAcgiQAcghAAg7QAAg8gbghQgbgigxABQguAAgdAjg");
	this.shape_16.setTransform(120.425,66.35);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#727272").s().p("AhjCgIAAg1QAiAWAiAAQAhAAAVgSQAWgRgBgeQABgdgWgQQgVgQgoAAIg3ADIALiyICnAAIAAAvIh5AAIgGBVIAfgBQA1AAAdAcQAdAbAAAwQAAAzghAeQgiAeg6AAQgyAAgYgNg");
	this.shape_17.setTransform(297.15,66.675);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#727272").s().p("AhSCGQgggoABhLQAAg6ASgsQASgsAhgYQAigYAqAAQApAAATAKIAAAxQgdgOgdAAQgoAAgZAjQgZAigBA7IABAAQALgUAUgLQAUgLAWAAQAtAAAaAcQAbAdgBAvQAAAhgOAcQgPAagZAOQgbAPgeAAQg1AAgggqgAgmAQQgRARAAAaQABATAHARQAIARAMAJQAOAKAQAAQAagBAPgRQAPgTAAgdQAAgfgPgSQgPgQgaAAQgZAAgQAQg");
	this.shape_18.setTransform(272.05,66.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#727272").s().p("AhECqQgXgFgMgHIAAg2QARAMAVAHQAWAIAVAAQAfAAATgQQATgOAAgaQAAgcgWgPQgXgPgoAAIgeAAIAAgsIAdAAQAkAAATgNQATgOABgbQAAgXgQgOQgQgMgbAAQgjAAggAYIAAgyQAQgJAVgFQAVgFAYAAQAeAAAXALQAYAMALARQAMAUgBAXQAAAggRAWQgSAWggAIIAAABQAmAFAUAUQAVAWAAAhQAAAughAdQgiAcg6AAQgWAAgYgGg");
	this.shape_19.setTransform(246.9,66.4);

	var maskedShapeInstanceList = [this.shape_10,this.shape_11,this.shape_12,this.shape_13,this.shape_14,this.shape_15,this.shape_16,this.shape_17,this.shape_18,this.shape_19];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ClipGroup_1, new cjs.Rectangle(104.1,0,203.1,84), null);


(lib.UI_Top_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#286DBD").s().p("AghAFIAAgJIBDAAIAAAJg");
	this.shape.setTransform(71.15,31.3,0.5788,0.5788,0,0,0,0.2,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#286DBD").s().p("AAAgBIgZAYIAAgVIAZgYIAZAYIAAAVg");
	this.shape_1.setTransform(71.006,33.7512,0.5776,0.5776);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#286DBD").s().p("AgHAwIAAhfIAOAAIAABfg");
	this.shape_2.setTransform(71.0079,36.1968,0.5782,0.5782);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Outline
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_3.setTransform(243.95,16.05,0.3993,0.3993,0,0,0,0.2,0.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEBGIAAgcQAAgJAPgPQANgKAFgIQAIgKAAgLQAAgTgLgKQgKgJgPAAQgPAAgKAKQgMAKAAASIgKAAQAAgXAPgNQAOgMASAAQATAAAMAMQAPANAAAXQAAAOgJANQgHAHgMAMQgOANAAAEIAAAcg");
	this.shape_4.setTransform(243.95,12.1,0.3993,0.3993,0,0,0,0.2,0.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#494846").s().p("AgdgKIAAgHIAdAcIAegcIAAAHIgeAcg");
	this.shape_5.setTransform(43.225,36.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(1));

	// Outline
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQBZIgfgMQgEgCABgEIAEgTIgBgCIgTAGQgFACgBgEIgOgeQgDgDAEgDIAQgLIgBgIIgQgLQgEgCACgEIAOgeQACgEADACIARAEIAEgFIgFgTQgBgEAFgCIAegMQAFgBABAEIAJAPIAGAAIAJgPQACgEAEABIAfAMQAEABgBAFIgEASIAFAGIARgFQAEgBACAEIAOAeQACAEgEACIgRALIAAABIgBAJIAPAKQADACgCAEIgOAeQgCAEgEgCIgTgGIAAABIAEATQABAEgEACIgfAMIgCAAQgDAAgBgDIgKgRIAAAAIgKARQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAIgCAAgAADA7QADAAACACIAJARIAWgJIgEgSQgBgDADgCIAFgEQACgDADACIARAFIAKgVIgNgKQgDgCABgDIABgKIgBgDQAAgFAEgBIAAAAIAPgJIgKgWIgQAEQgEABgBgCIgJgJQgDgDABgCIAEgRIgXgJIgIAOQgBADgDAAIgLAAQgDAAgCgCIgIgPIgXAJIAFASQAAADgCACIgIAIQgBACgEgBIgPgEIgKAWIAPAKQABAAAAABQABAAAAABQAAAAAAABQAAABAAAAIAAAEIABAIQAAAEgCABIgPALIALAWIARgGQAEgCABADIAGAFQACABAAAEIgEASIAWAJIAJgRQACgCADAAIABAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAg");
	this.shape_6.setTransform(231.6584,12.6239,0.3798,0.3798);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWAYQgKgKAAgOQAAgNAKgJQAJgKANAAQAOAAAKAKQAJAJAAANQAAAOgJAKQgKAJgOAAQgNAAgJgJgAgPgPQgHAHAAAIQAAAKAHAGQAHAHAIAAQAKAAAGgHQAHgGAAgKQAAgIgHgHQgGgHgKAAQgIAAgHAHg");
	this.shape_7.setTransform(231.6014,12.6204,0.3798,0.3798);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(1));

	// Outline
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOAFQgGgGAAgJIAKAAQAAAFADAEQADACAEAAQAFAAADgCQADgEAAgFIAKAAQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape_8.setTransform(219.6,15.65,0.3993,0.3993,0,0,0,0.2,0.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhDAFIAAgJICHAAIAAAJg");
	this.shape_9.setTransform(219.65,15.1,0.3993,0.3993,0,0,0,0.2,0.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAtA/IAAhGQAAgSgNgOQgNgNgTAAQgRAAgOANQgNAOAAASIAABGIgKAAIAAhGQAAgXAQgQQAQgQAWAAQAXAAAQAQQAQAQAAAXIAABGg");
	this.shape_10.setTransform(219.6,12.6,0.3993,0.3993,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Layer_2
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#286DBD").s().p("AAjAYQgTAAgRgJQgRgIgNgPIgCAMIgGgJIAFgSIASAEIAFAKIgKgDQALANAPAHQARAHASgBIAAAKg");
	this.shape_11.setTransform(172.375,38.8875,0.5,0.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#286DBD").s().p("AhMAaQAJgYAUgOQAUgPAZgBQAUgBATAIQATAJANAQIADgMIAFAJIgEASIgSgEIgGgKIAKADQgLgNgQgHQgRgHgQABQgWABgSANQgSANgIAUg");
	this.shape_12.setTransform(174.2125,33.1599,0.5,0.5);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#286DBD").s().p("AgWAzIAAgOIAPAAIAAgNIgqAAIAAhKIBjAAIAABKIgrAAIAAANIAQAAIAAAOgAgjAKIBHAAIAAguIhHAAg");
	this.shape_13.setTransform(177.025,37.6125,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11}]}).wait(1));

	// Outline
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#286DBD").s().p("AgEAqIAAgjIgmAAIAAgJIAmAAIAAgnIAJAAIAAAnIAlAAIAAAJIglAAIAAAjg");
	this.shape_14.setTransform(14.5975,35.8325,0.5994,0.5994);

	this.timeline.addTween(cjs.Tween.get(this.shape_14).wait(1));

	// Layer_2
	this.instance = new lib.Home_txt();
	this.instance.setTransform(33.05,42.6,1,1,0,0,0,12.4,7);

	this.instance_1 = new lib.AutoSave_txt();
	this.instance_1.setTransform(49.2,19.6,1,1,0,0,0,17.8,7);

	this.instance_2 = new lib.Excel_txt();
	this.instance_2.setTransform(149.9,21.2,1,1,0,0,0,13.5,8.6);

	this.instance_3 = new lib.Name_txt();
	this.instance_3.setTransform(276.6,19.4,1,1,0,0,0,25.6,6.8);

	this.instance_4 = new lib.Insert_txt();
	this.instance_4.setTransform(85.9,42.6,1,1,0,0,0,11.3,7);

	this.instance_5 = new lib.PageLayout_txt();
	this.instance_5.setTransform(157.15,42.6,1,1,0,0,0,22.4,7);

	this.instance_6 = new lib.Formulas_txt();
	this.instance_6.setTransform(200.55,42.6,1,1,0,0,0,17.2,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_2
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#286DBD").s().p("AgeAtIAAgOIAQAAIAbhMIATAAIAAAPIgJAAIgbBLg");
	this.shape_15.setTransform(125.2,35.825,0.5,0.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#286DBD").s().p("AgbAbIAAg2IA4AAIAAA2gAgNAMIAaAAIAAgXIgaAAg");
	this.shape_16.setTransform(128.15,33.9,0.5,0.5,0,0,0,0.1,0.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#286DBD").s().p("AgcAbIAAg2IA4AAIAAA2gAgMANIAaAAIAAgYIgaAAg");
	this.shape_17.setTransform(122.675,37.575,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15}]}).wait(1));

	// Layer_11
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#DBE9F6").ss(1,1,1).p("AAAh0IAADp");
	this.shape_18.setTransform(25.65,12.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAVAwIAAgaIAaAAIAAAagAgMAwIAAgaIAYAAIAAAagAguAwIAAgaIAZAAIAAAagAAVANIAAgZIAaAAIAAAZgAgMANIAAgZIAYAAIAAAZgAguANIAAgZIAZAAIAAAZgAAVgVIAAgaIAaAAIAAAagAgMgVIAAgaIAYAAIAAAagAgugVIAAgaIAZAAIAAAag");
	this.shape_19.setTransform(12.65,13.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18}]}).wait(1));

	// Layer_1
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#DBE9F6").s().p("A3bBkIAAjHMAu3AAAIAADHg");
	this.shape_20.setTransform(150.0023,35.6505);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#056EBF").s().p("A3bCAIAAj/MAu3AAAIAAD/g");
	this.shape_21.setTransform(150,12.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI_Top_bar, new cjs.Rectangle(0,-0.4,300,52), null);


(lib.tile_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ApXGHIAAsNISvAAIAAMNg");
	var mask_graphics_1 = new cjs.Graphics().p("ApXGIIAAsPISvAAIAAMPg");
	var mask_graphics_2 = new cjs.Graphics().p("ApbGLIAAsVIS3AAIAAMVg");
	var mask_graphics_3 = new cjs.Graphics().p("AplGVIAAspITLAAIAAMpg");
	var mask_graphics_4 = new cjs.Graphics().p("Ap5GpIAAtRITzAAIAANRg");
	var mask_graphics_5 = new cjs.Graphics().p("AqZHIIAAuPIUzAAIAAOPg");
	var mask_graphics_6 = new cjs.Graphics().p("ArIH4IAAvvIWRAAIAAPvg");
	var mask_graphics_7 = new cjs.Graphics().p("AsLI6IAAxzIYXAAIAARzg");
	var mask_graphics_8 = new cjs.Graphics().p("AtkKSIAA0jIbJAAIAAUjg");
	var mask_graphics_9 = new cjs.Graphics().p("AvWMDIAA4FIetAAIAAYFg");
	var mask_graphics_10 = new cjs.Graphics().p("AxcOJIAA8RMAi5AAAIAAcRg");
	var mask_graphics_11 = new cjs.Graphics().p("AzOP6IAA/zMAmdAAAIAAfzg");
	var mask_graphics_12 = new cjs.Graphics().p("A0nRSMAAAgijMApPAAAMAAAAijg");
	var mask_graphics_13 = new cjs.Graphics().p("A1qSUMAAAgknMArVAAAMAAAAkng");
	var mask_graphics_14 = new cjs.Graphics().p("A2ZTDMAAAgmFMAszAAAMAAAAmFg");
	var mask_graphics_15 = new cjs.Graphics().p("A25TjMAAAgnFMAtzAAAMAAAAnFg");
	var mask_graphics_16 = new cjs.Graphics().p("A3NT2MAAAgnrMAubAAAMAAAAnrg");
	var mask_graphics_17 = new cjs.Graphics().p("A3XUAMAAAgn/MAuvAAAMAAAAn/g");
	var mask_graphics_18 = new cjs.Graphics().p("A3bUEMAAAgoHMAu3AAAMAAAAoHg");
	var mask_graphics_19 = new cjs.Graphics().p("A3bUEMAAAgoHMAu3AAAMAAAAoHg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:0,y:-0.0275}).wait(1).to({graphics:mask_graphics_1,x:0.0467,y:-0.0572}).wait(1).to({graphics:mask_graphics_2,x:0.3735,y:-0.2646}).wait(1).to({graphics:mask_graphics_3,x:1.2604,y:-0.8276}).wait(1).to({graphics:mask_graphics_4,x:2.9877,y:-1.924}).wait(1).to({graphics:mask_graphics_5,x:5.8354,y:-3.7316}).wait(1).to({graphics:mask_graphics_6,x:10.0836,y:-6.4282}).wait(1).to({graphics:mask_graphics_7,x:16.0123,y:-10.1916}).wait(1).to({graphics:mask_graphics_8,x:23.9018,y:-15.1995}).wait(1).to({graphics:mask_graphics_9,x:34.032,y:-21.6298}).wait(1).to({graphics:mask_graphics_10,x:46.018,y:-29.2381}).wait(1).to({graphics:mask_graphics_11,x:56.1482,y:-35.6684}).wait(1).to({graphics:mask_graphics_12,x:64.0377,y:-40.6763}).wait(1).to({graphics:mask_graphics_13,x:69.9664,y:-44.4397}).wait(1).to({graphics:mask_graphics_14,x:74.2146,y:-47.1363}).wait(1).to({graphics:mask_graphics_15,x:77.0623,y:-48.9439}).wait(1).to({graphics:mask_graphics_16,x:78.7896,y:-50.0403}).wait(1).to({graphics:mask_graphics_17,x:79.6765,y:-50.6033}).wait(1).to({graphics:mask_graphics_18,x:80.0033,y:-50.8107}).wait(1).to({graphics:mask_graphics_19,x:80,y:-50.8404}).wait(1));

	// Layer_8
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(-45,-5.45,0.3,0.3);
	this.instance.alpha = 0;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:-0.1,regY:-0.3,scaleX:1,scaleY:0.9404,x:-23.1,y:-76.1,alpha:1},19,cjs.Ease.cubicInOut).wait(1));

	// Layer_5
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(-45,-5.45,0.3,0.3);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:-0.1,regY:-0.3,scaleX:1,scaleY:0.9404,x:-23.1,y:-76.1},19,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-70,-350,300,600);


(lib.ScreenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.whiteRect();
	this.instance.setTransform(150,236,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ScreenBG, new cjs.Rectangle(0,-64,300,250), null);


(lib.screen_tiles = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_12();
	this.instance.setTransform(-94.35,-47.5,0.4366,0.395,0,0,0,-45.1,-5.5);

	this.tile_18 = new lib.tile_18_1();
	this.tile_18.setTransform(7.1,-78.4,0.4331,0.4211,0,-0.4962,0,0.5,-0.5);

	this.instance_1 = new lib.tile_15();
	this.instance_1.setTransform(-16.65,-60.8,0.4123,0.3999,0,-0.5203,0);

	this.instance_2 = new lib.tile_16();
	this.instance_2.setTransform(-45.6,-60.8,0.4123,0.3999,0,-0.5203,0);

	this.instance_3 = new lib.tile_19();
	this.instance_3.setTransform(-53.45,-94.05,0.4237,0.411,0,-0.5191,0);

	this.instance_4 = new lib.tile_20();
	this.instance_4.setTransform(-100.85,-94.45,0.4287,0.4158,0,-0.5215,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.tile_18},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen_tiles, new cjs.Rectangle(-156.7,-94.6,177.89999999999998,97.8), null);


(lib.scene1_fg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.screen_tiles();
	this.instance.setTransform(209.1,131.75,1,1,0,0,0,-43.6,-63.2);
	this.instance.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_1
	this.instance_1 = new lib.frame_1_fg();
	this.instance_1.setTransform(-257,-2,1.02,1.02);

	this.instance_2 = new lib.frame_1_fg();
	this.instance_2.setTransform(49,-2,1.02,1.02);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene1_fg, new cjs.Rectangle(-257,-2,614.1,257.1), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replaySub("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.officeBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#E9E9E9").s().p("Am3FeIAAq7IBLAAIAAJrILJAAIAAprIBbAAIAAK7g");
	this.shape.setTransform(291.225,-10.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_8
	this.instance = new lib.tile_18_1();
	this.instance.setTransform(291.45,-23.15,0.7892,0.7892);
	this.instance.alpha = 0.75;

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],14.9,-14.3,15.4,0).s().p("AHpA/IvZAAIAAh8IAAgCINjAAIAAACIB+B8g");
	this.shape_1.setTransform(298.05,29.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#E1E1E1","#FFFFFF"],[0,1],-35.4,-1.1,-10.9,-0.9).s().p("AlbExIAAphIK3AAIAAJhg");
	this.shape_2.setTransform(291.725,-15.275);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],-14.4,-3.4,-2.7,-3.8).s().p("AA+GaIh9h9IAAgCIAAq0IB/AAIAAMzg");
	this.shape_3.setTransform(341.55,-4.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B5B5B5").s().p("AgEExIAAphIAJAAIAAJhg");
	this.shape_4.setTransform(256.4,-15.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#E9E9E9").s().p("AmsFbIgLAAIAAq1IAPAAIBIAAIAAJhIAKAAIK3AAIAAphIAFAAIBSAAIAAK1g");
	this.shape_5.setTransform(291.225,-11.075);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.instance}]}).wait(1));

	// Layer_3
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],27.2,-21.1,26.5,0).s().p("AjmBeIgLgBIC4i3IAAgDIErAAIAAABIAAACIAAC4g");
	this.shape_6.setTransform(353.575,75.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],-12.7,-21.1,-12,0).s().p("AlpBdIAAi4IAAgCIEUAAIEQAAIAAACICvC4IgLABg");
	this.shape_7.setTransform(414.025,75.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],-20.3,6.9,-3.7,6.3).s().p("ABMLZIALgBIivi5IAAgCIAAhfIAAvZIABAAIACgDIgBAAICBiLIAsguIACAAIAAAuIAARnIAAEbg");
	this.shape_8.setTransform(441.6,11.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],21.3,6.9,3.9,6.3).s().p("AhcLXIAA2uIACAAIC1C6IgBAAIABACIACAAIAAQ2IAAADIi3C5IALAAg");
	this.shape_9.setTransform(338.45,11.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],20.6,25.4,20.2,4.7).s().p("ABSBeIiLAAIgDgCIABgBIi2i4IHjAAIAAAtIAACKIAAACIAAABIAAABg");
	this.shape_10.setTransform(353.575,-51.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],-6.5,25.5,-6.1,4.8).s().p("AhVBeIkUAAIAAgBIAAgBIAAiLIAAgtIAAgBILTAAIgrAuIiCCLIABAAIgDACg");
	this.shape_11.setTransform(414.025,-51.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#E9E9E9").s().p("ACXIdIkSAAIAAgBIktAAIAAw2ICMAAIChAAIAAgBIESAAIESAAIAAPZIAABfgAlSHKIDXAAIESAAIDAAAIAAgMIAAuAIjAAAIAAABImzAAIg2AAg");
	this.shape_12.setTransform(390.25,11.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(1));

	// Layer_11
	this.instance_1 = new lib.tile_10();
	this.instance_1.setTransform(388.35,2.45,0.7256,0.7256,0,0,0,-0.5,0.8);
	this.instance_1.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_10
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#007FEC").ss(1,1,1).p("Al6HuIgFAAIAAvbIL/AAIAAAG");
	this.shape_13.setTransform(390,11.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.384,1],-37.7,0.4,36.7,0.4).s().p("Al/HuIAAgGIAAvVIL6AAIAFAAIAAPbg");
	this.shape_14.setTransform(390.5,12.45);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.18,1],-6.3,70.5,62.9,70.5).s().p("AgWA/IAAgsIAtAsgAgQAGIgGAAIAAgYIAZAYgAgQgeIgGAAIAAggIAgAgg");
	this.shape_15.setTransform(221.875,-35.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.18,1],-4.7,78.5,64.5,78.5).s().p("AgGACIAAgDIAKAAIADADg");
	this.shape_16.setTransform(220.275,-41.975);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13}]}).wait(1));

	// Layer_9
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#B3C2C0").s().p("A49TqMAAAgnTMAx7AAIMgASAnLg");
	this.shape_17.setTransform(283.475,91.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_17).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.officeBG, new cjs.Rectangle(0.1,-61,459.2,659.2), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MainComposition = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Top_bar = new lib.UI_Top_bar();

	this.timeline.addTween(cjs.Tween.get(this.Top_bar).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MainComposition, new cjs.Rectangle(0,0,300,51.6), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.laptop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_12copy();
	this.instance.setTransform(-70.8,2.3,0.512,0.5133,0,-0.8124,0,-45.6,-5.2);

	this.instance_1 = new lib._300x600_laptop();
	this.instance_1.setTransform(-102,-81.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.laptop, new cjs.Rectangle(-102,-81.5,204,163), null);


(lib.final_frame_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.laptop = new lib.laptop();
	this.laptop.setTransform(185.05,171.5);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// Layer_5
	this.instance = new lib.final_img_2();
	this.instance.setTransform(-428,-353,1.8535,1.8535);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.final_frame_bg, new cjs.Rectangle(-428,-625.9,926.8,1029.2), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._365Logo_Whiteai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 365Logo_White.ai
	this.instance = new lib.ClipGroup();
	this.instance.setTransform(153.6,42,1,1,0,0,0,153.6,42);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape.setTransform(61.675,64.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_1.setTransform(19.225,64.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_2.setTransform(61.675,21.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_3.setTransform(19.225,21.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,307.2,84);


(lib._365Logo_Greyai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 365Logo_Grey.ai
	this.instance = new lib.ClipGroup_1();
	this.instance.setTransform(153.6,42,1,1,0,0,0,153.6,42);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape.setTransform(61.675,64.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_1.setTransform(19.225,64.175);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_2.setTransform(61.675,21.725);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("Ai/DAIAAl/IF/AAIAAF/g");
	this.shape_3.setTransform(19.225,21.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,307.2,84);


(lib.screenAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_99 = function() {
		this.tile_12.play();
	}
	this.frame_120 = function() {
		this.stop()
			exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(21).call(this.frame_120).wait(1));

	// text
	this.UI = new lib.MainComposition();
	this.UI.setTransform(150,304.1,1,1,0,0,0,150,304.1);

	this.timeline.addTween(cjs.Tween.get(this.UI).wait(121));

	// hand
	this.instance = new lib.pointer("single",0);
	this.instance.setTransform(340.15,263.15,1,1,0,0,0,14,16.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(63).to({_off:false},0).to({x:80.7,y:219.35},23,cjs.Ease.quadOut).wait(13).to({startPosition:1},0).wait(4).to({startPosition:0},0).to({x:321.9,y:314.45},16,cjs.Ease.quadInOut).to({_off:true},1).wait(1));

	// UI
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#007FEC").ss(3,1,0,3).p("ApJl3ISTAAIAALvIyTAAg");
	this.shape.setTransform(70.7,177.45);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(81).to({_off:false},0).to({_off:true},19).wait(21));

	// Tile_12
	this.tile_12 = new lib.tile_12();
	this.tile_12.setTransform(70.7,222.25,0.9988,0.9988,0,0,0,0.1,0.1);
	this.tile_12.alpha = 0;
	this.tile_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_12).wait(14).to({_off:false},0).to({regY:0,y:177.25,alpha:1},24,cjs.Ease.quartOut).wait(15).to({regY:0.1,x:70.65,y:177.35},46).wait(22));

	// tile_20
	this.tile_10 = new lib.tile_20_1();
	this.tile_10.setTransform(61.75,140.05,0.9913,0.9913,0,0,0,0.1,0.1);
	this.tile_10.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.tile_10).to({regY:0,y:95.4,alpha:1},24,cjs.Ease.quartOut).wait(97));

	// tile_19
	this.tile_10_1 = new lib.tile_19_1();
	this.tile_10_1.setTransform(169.45,140.65,1.0011,1.0011,0,0,0,0.1,0.1);
	this.tile_10_1.alpha = 0;
	this.tile_10_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10_1).wait(5).to({_off:false},0).to({regY:0,y:95.55,alpha:1},25,cjs.Ease.quartOut).wait(91));

	// tile_18
	this.tile_10_2 = new lib.tile_18_1();
	this.tile_10_2.setTransform(257.55,140.25,0.9988,0.9988,0,0,0,0.1,0.1);
	this.tile_10_2.alpha = 0;
	this.tile_10_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10_2).wait(9).to({_off:false},0).to({regY:0,y:95.25,alpha:1},24,cjs.Ease.quartOut).wait(88));

	// tile_10
	this.tile_10_3 = new lib.tile_16_1();
	this.tile_10_3.setTransform(165.2,222.7,1.0054,1.0054,0,0,0,0.1,0.1);
	this.tile_10_3.alpha = 0;
	this.tile_10_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10_3).wait(19).to({_off:false},0).to({regY:0,y:177.4,alpha:1},24,cjs.Ease.quartOut).wait(78));

	// tile_15
	this.tile_10_4 = new lib.tile_15_1();
	this.tile_10_4.setTransform(245.2,222.7,1.0054,1.0054,0,0,0,0.1,0.1);
	this.tile_10_4.alpha = 0;
	this.tile_10_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10_4).wait(24).to({_off:false},0).to({regY:0,y:177.4,alpha:1},24,cjs.Ease.quartOut).wait(73));

	// tile_14
	this.tile_10_5 = new lib.tile_14_1();
	this.tile_10_5.setTransform(70.75,305.25,1.0017,1.0017,0,0,0,0.1,0.1);
	this.tile_10_5.alpha = 0;
	this.tile_10_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10_5).wait(30).to({_off:false},0).to({y:260.2,alpha:1},24,cjs.Ease.quartOut).wait(67));

	// tile_13
	this.tile_10_6 = new lib.tile_13_1();
	this.tile_10_6.setTransform(220.45,297.3,0.906,0.906,0,0,0,0.1,0.1);
	this.tile_10_6.alpha = 0;
	this.tile_10_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_10_6).wait(34).to({_off:false},0).to({y:256.55,alpha:1},24,cjs.Ease.quartOut).wait(63));

	// ScreenBG
	this.instance_1 = new lib.ScreenBG();
	this.instance_1.setTransform(150,163,1,1,0,0,0,150,98);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(121));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-117.3,0,471.7,354.4);


(lib.scene3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 300x600_laptop.png
	this.bg = new lib.final_frame_bg();
	this.bg.setTransform(6.5,4.95,0.8729,0.8729);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene3, new cjs.Rectangle(-367.1,-303.1,809,660.1), null);


(lib.scene_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.fg = new lib.scene1_fg();
	this.fg.setTransform(124.65,300,1,1,0,0,0,176,300);

	this.timeline.addTween(cjs.Tween.get(this.fg).wait(1));

	// Layer_6
	this.bg = new lib.officeBG();
	this.bg.setTransform(477.45,628.8,1,1,0,0,0,617,595.5);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.scene_1, new cjs.Rectangle(-308.3,-27.7,628,282.8), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.setTransform(-22.45,-1.1,0.85,0.8968,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("ArNCeIAAk7IWbAAIAAE7g");
	this.shape.setTransform(-35.55,-1.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-107.4,-17.5,143.7,31.6), null);


(lib.Microsoftlogo_rgb_cwhiteai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib._365Logo_Whiteai("synched",0);
	this.instance.setTransform(136.8,34.7,0.8901,0.8901,0,0,0,153.7,42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-2.7,273.5,74.8);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_51 = function() {
		exportRoot.tl1.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(51).call(this.frame_51).wait(23).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(296.05,338.05,0.3259,0.3259,0,0,0,-39.6,1.6);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:5.389,scaleY:5.389,y:337.8},13,cjs.Ease.quadOut).to({x:82.2},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("Al+e+IAAyKMBEdAAAIAASKg");
	var mask_graphics_15 = new cjs.Graphics().p("AmNe+IAAyKMBEdAAAIAASKg");
	var mask_graphics_16 = new cjs.Graphics().p("Am5e+IAAyKMBEdAAAIAASKg");
	var mask_graphics_17 = new cjs.Graphics().p("AoEe+IAAyKMBEdAAAIAASKg");
	var mask_graphics_18 = new cjs.Graphics().p("Apte+IAAyKMBEdAAAIAASKg");
	var mask_graphics_19 = new cjs.Graphics().p("Ar0e+IAAyKMBEdAAAIAASKg");
	var mask_graphics_20 = new cjs.Graphics().p("AuYe+IAAyKMBEdAAAIAASKg");
	var mask_graphics_21 = new cjs.Graphics().p("Aw9e+IAAyKMBEdAAAIAASKg");
	var mask_graphics_22 = new cjs.Graphics().p("AzDe+IAAyKMBEdAAAIAASKg");
	var mask_graphics_23 = new cjs.Graphics().p("A0se+IAAyKMBEdAAAIAASKg");
	var mask_graphics_24 = new cjs.Graphics().p("A13e+IAAyKMBEdAAAIAASKg");
	var mask_graphics_25 = new cjs.Graphics().p("A2ke+IAAyKMBEdAAAIAASKg");
	var mask_graphics_26 = new cjs.Graphics().p("A2ye+IAAyKMBEdAAAIAASKg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:399.939,y:198.2351}).wait(1).to({graphics:mask_graphics_15,x:398.4431,y:198.2351}).wait(1).to({graphics:mask_graphics_16,x:393.9554,y:198.2351}).wait(1).to({graphics:mask_graphics_17,x:386.4758,y:198.2351}).wait(1).to({graphics:mask_graphics_18,x:376.0045,y:198.2351}).wait(1).to({graphics:mask_graphics_19,x:362.5414,y:198.2351}).wait(1).to({graphics:mask_graphics_20,x:346.0865,y:198.2351}).wait(1).to({graphics:mask_graphics_21,x:329.6315,y:198.2351}).wait(1).to({graphics:mask_graphics_22,x:316.1684,y:198.2351}).wait(1).to({graphics:mask_graphics_23,x:305.6971,y:198.2351}).wait(1).to({graphics:mask_graphics_24,x:298.2176,y:198.2351}).wait(1).to({graphics:mask_graphics_25,x:293.7299,y:198.2351}).wait(1).to({graphics:mask_graphics_26,x:292.264,y:198.2351}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.setTransform(82.95,331.35,5.389,5.389,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(298.3,331.35,5.389,5.389,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},24).wait(25));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:298.3},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2A/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhMxA/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTfA/1MAAAh/pMCXtAAAMAAAB/pg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhaiA/1MAAAh/pMCXsAAAMAAAB/pg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:340.9396}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:340.9396}).wait(1).to({graphics:mask_1_graphics_52,x:295.8292,y:340.9396}).wait(1).to({graphics:mask_1_graphics_53,x:289.2197,y:340.9396}).wait(1).to({graphics:mask_1_graphics_54,x:278.2038,y:340.9396}).wait(1).to({graphics:mask_1_graphics_55,x:262.7816,y:340.9396}).wait(1).to({graphics:mask_1_graphics_56,x:242.953,y:340.9396}).wait(1).to({graphics:mask_1_graphics_57,x:218.7181,y:340.9396}).wait(1).to({graphics:mask_1_graphics_58,x:190.0769,y:340.9396}).wait(1).to({graphics:mask_1_graphics_59,x:157.0292,y:340.9396}).wait(1).to({graphics:mask_1_graphics_60,x:119.5753,y:340.9396}).wait(1).to({graphics:mask_1_graphics_61,x:77.7149,y:340.9396}).wait(1).to({graphics:mask_1_graphics_62,x:31.4483,y:340.9396}).wait(1).to({graphics:mask_1_graphics_63,x:-19.2247,y:340.9396}).wait(1).to({graphics:mask_1_graphics_64,x:-74.3041,y:340.9396}).wait(1).to({graphics:mask_1_graphics_65,x:-133.7898,y:340.9396}).wait(1).to({graphics:mask_1_graphics_66,x:-197.6819,y:340.9396}).wait(1).to({graphics:mask_1_graphics_67,x:-265.9803,y:340.9396}).wait(1).to({graphics:mask_1_graphics_68,x:-338.6851,y:340.9396}).wait(1).to({graphics:mask_1_graphics_69,x:-415.7962,y:340.9396}).wait(1).to({graphics:mask_1_graphics_70,x:-491.398,y:340.9396}).wait(1).to({graphics:mask_1_graphics_71,x:-534.3599,y:340.9396}).wait(1).to({graphics:mask_1_graphics_72,x:-579.525,y:340.9396}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.setTransform(298.3,331.35,5.389,5.389,0,0,0,0.1,0.2);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(297.95,340.9,1,1.0039,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-673.65},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.setTransform(297.95,340.9,1,1.0039,0,0,0,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-666.45},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1159,-67.6,1942.5,817.2);


(lib.endLogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._365Logo_Greyai("synched",0);
	this.instance.setTransform(27.25,7.45,0.1774,0.1774,0,0,0,153.6,42);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.endLogo, new cjs.Rectangle(0,0,54.5,14.9), null);


(lib.anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Logo
	this.logo_white = new lib.Microsoftlogo_rgb_cwhiteai();
	this.logo_white.setTransform(103.8,456.7,0.2042,0.2042,0,0,0,434.6,2163.3);

	this.timeline.addTween(cjs.Tween.get(this.logo_white).to({_off:true},1).wait(4));

	// Screen
	this.screenAnim = new lib.screenAnim();
	this.screenAnim.setTransform(150,301.4,1,1,0,0,0,150,301.4);

	this.timeline.addTween(cjs.Tween.get(this.screenAnim).wait(5));

	// scene1
	this.scene_1 = new lib.scene_1();
	this.scene_1.setTransform(158.1,89,1,1,0,0,0,158.1,89);

	this.timeline.addTween(cjs.Tween.get(this.scene_1).to({_off:true},1).wait(4));

	// scene3
	this.scene_3 = new lib.scene3();
	this.scene_3.setTransform(150,386.1,1,1,0,0,0,150,386.1);

	this.timeline.addTween(cjs.Tween.get(this.scene_3).wait(5));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-367.1,-303.1,809,660.1);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// intro logo
	this.logo_intro = new lib.logos();
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.setTransform(207.95,220.2,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.setTransform(266.4,222,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// EndLogo
	this.endLogo = new lib.endLogo();
	this.endLogo.setTransform(192.35,22.25,1,1,0,0,0,27.3,7.5);

	this.timeline.addTween(cjs.Tween.get(this.endLogo).wait(1));

	// WhiteCover
	this.whiteCV = new lib.whiteCover();
	this.whiteCV.setTransform(225.3,125.75,1,1,0,0,0,75.5,127);

	this.timeline.addTween(cjs.Tween.get(this.whiteCV).wait(1));

	// Anim
	this.animMC = new lib.anim();

	this.timeline.addTween(cjs.Tween.get(this.animMC).wait(1));

	// BG
	this.bg = new lib.whiteBG();
	this.bg.setTransform(150,124.95,1,0.4141,0,0,0,150,301.7);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-367.1,-303.1,809,660.1), null);


// stage content:
(lib.Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		this.runBanner = function() {
			
			
			
			
			exportRoot.tl1 = new TimelineLite();
			
			this.tl1.stop();
			mc.logo_intro.gotoAndPlay(1);
			
			//scene1 parallax
			exportRoot.tl1.from(mc.animMC.scene_1.fg, 2,{x:"+=75", ease:Power3.easeOut});
			exportRoot.tl1.from(mc.animMC.scene_1.bg, 2,{x:"+=50", ease:Power3.easeOut}, "-=2");
			
			//zoom in
			exportRoot.tl1.from(mc.animMC.screenAnim, 0.7,{alpha:0, scaleX:0.85, scaleY:0.85, x:"+=0", y:"+=50", skewX:-0.5, skewY:-0.3, ease: Power3.easeInOut}, "+=0");
			exportRoot.tl1.to(mc.animMC.scene_1, 0.7,{ scaleX:4, scaleY:4, y:"-=100", ease:Power3.easeInOut,onStart: function(){mc.animMC.screenAnim.play();}}, "-=0.7");
			exportRoot.tl1.to(mc.animMC.logo_white, 0.7,{ scaleX:4.25, scaleY:4.25, ease:Power3.easeInOut,onComplete: function(){ mc.animMC.scene_1.alpha=0; exportRoot.tl1.stop();}}, "-=0.7");
		
			
			//final Scene 
			//exportRoot.tl1.to(mc.animMC.screenAnim, 2,{ x:"-=3", y:"+=76", scaleX:.5133, scaleY:.1689, skewX:-0.4, alpha:0, ease:Power3.easeInOut});
		
			exportRoot.tl1.to(mc.animMC.screenAnim, 1,{ x:"+=0", y:"-=75", scaleX:.9, scaleY:.42, alpha:0, ease:Power3.easeInOut});
			exportRoot.tl1.from(mc.animMC.scene_3.bg, 1,{ y:"-=580", x:"-=640", scaleX:4.2, scaleY:4.2, ease:Power3.easeInOut},"-=1");
			//exportRoot.tl1.from(mc.animMC.scene_3.bg, 2,{ x:"+=50", ease:Power3.easeOut},"-=2");
		
			exportRoot.tl1.to(mc.animMC.scene_3.bg, 2,{ scaleX:.33, scaleY:.33, x:"+=122", y:"+=130", ease:Power3.easeInOut},"+=0");
			exportRoot.tl1.to(mc.animMC.scene_3.bg.laptop, 1,{ x:"+=25", ease:Power3.easeIn},"-=2");
			exportRoot.tl1.from(mc.whiteCV, 1,{ x:"+=230", ease:Power3.easeOut},"-=1");
			exportRoot.tl1.from(mc.endLogo, 1,{ x:"+=230", ease:Power3.easeOut},"-=1");
			
		
			exportRoot.tl1.stop();
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
					for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
		
			exportRoot.tl1.from(mc.cta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl1.from(mc.txtCta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "-=0.7");
			
			
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-217.1,-178.1,659,535.1);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#0078D4",
	opacity: 1.00,
	manifest: [
		{src:"images/Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_.png?1581962981606", id:"Office_Evergreen_USA_300x250_BAN_ConsumerAbandonment_ThisisYour365_Photographer_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;