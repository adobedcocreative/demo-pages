(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,487,220,326],[0,0,378,485],[222,487,204,163],[222,652,155,77],[380,79,120,77],[380,318,91,77],[380,397,60,77],[380,0,120,77],[380,158,103,78],[380,238,103,78]]}
];


// symbols:



(lib._160x600_foreground = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._300x600_final_frameCopy = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._300x600_laptop = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.tile_13 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.tile_14 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.tile_15 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.tile_16 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.tile_17 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.tile_19 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.tile_20 = function() {
	this.initialize(ss["O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whiteRect = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteRect, new cjs.Rectangle(0,0,300,600), null);


(lib.whiteBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAvKMAAAheTMAu3AAAMAAABeTg");
	this.shape.setTransform(150.0023,724.4012,1,2.4001);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.whiteBG, new cjs.Rectangle(0,0,300,1448.8), null);


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2A/lMAAAh/KMCXtAAAMAAAB/Kg");
	this.shape.setTransform(485.475,406.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,813.9), null);


(lib.UI_Bottom_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(-350,-382,1.5732,1.5732);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-350,-382,594.7,763);


(lib.tile_20_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_20();
	this.instance.parent = this;
	this.instance.setTransform(-50.6,-32.6,0.7628,0.7628);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_20_1, new cjs.Rectangle(-50.6,-32.6,78.6,59.5), null);


(lib.tile_19_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkMEvIAApcIIZAAIAAJcg");
	mask.setTransform(-46.35,-2.55);

	// Layer_1
	this.instance = new lib.tile_19();
	this.instance.parent = this;
	this.instance.setTransform(-73.15,-32.1,0.7577,0.7577);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_19_1, new cjs.Rectangle(-73.1,-32.1,53.699999999999996,59.1), null);


(lib.tile_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEGBIAAsBIKJAAIAAMBg");

	// Layer_2
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(-65,-38);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_18, new cjs.Rectangle(-32.5,-38,65,76.5), null);


(lib.tile_17_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmJEuIAApcIMTAAIAAJcg");
	mask.setTransform(39.8,-18.6);

	// Layer_1
	this.instance = new lib.tile_17();
	this.instance.parent = this;
	this.instance.setTransform(0.55,-48.8,0.7704,0.7704);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_17_1, new cjs.Rectangle(0.6,-48.8,78.60000000000001,59.3), null);


(lib.tile_16_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlbGBIAAsBIK3AAIAAMBg");
	mask.setTransform(-4.75,0);

	// Layer_2
	this.instance = new lib.tile_15();
	this.instance.parent = this;
	this.instance.setTransform(55.75,-57,1.3738,1.3738,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_16_1, new cjs.Rectangle(-39.5,-38.5,69.5,77), null);


(lib.tile_14_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmIEoIAApPIMRAAIAAJPg");
	mask.setTransform(10.85,-8.45);

	// Layer_1
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(-34,-48.8,0.9071,0.9071);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_14_1, new cjs.Rectangle(-28.4,-38,78.5,59.1), null);


(lib.tile_13_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlEFiIAArDIKJAAIAALDg");
	mask.setTransform(-42.8,-1);

	// Layer_1
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(-77.5,-38.5);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_13_1, new cjs.Rectangle(-75.3,-36.3,65,70.69999999999999), null);


(lib.tile_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AlYGBIAAsBIKxAAIAAMBg");

	// Layer_2
	this.instance = new lib.tile_19();
	this.instance.parent = this;
	this.instance.setTransform(-35,-39);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_10, new cjs.Rectangle(-34.5,-38.5,69,77), null);


(lib.tile_09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmIEoIAApPIMRAAIAAJPg");
	mask.setTransform(-11.55,59.925);

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(-119.4,9.05,0.3914,0.3914);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_09, new cjs.Rectangle(-50.8,30.3,78.6,59.3), null);


(lib.tile_08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsVMGIAApSIIaAAIAAJSg");
	mask.setTransform(-79.0484,77.3512);

	// Layer_2
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(219.95,-155.15,1,1,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_08, new cjs.Rectangle(-158,95.3,53.8,59.39999999999999), null);


(lib.tile_06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AmGk8IAApSIMNAAIAAJSg");
	mask.setTransform(-20.0639,-91.0628);

	// Layer_2
	this.instance = new lib.tile_17();
	this.instance.parent = this;
	this.instance.setTransform(110.55,-193.2,1.5,1.5,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_06, new cjs.Rectangle(-59.1,-182.1,78.1,59.39999999999999), null);


(lib.tile_05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AnXFpIAApSIMQAAIAAJSg");
	mask.setTransform(-47.2034,36.0556);

	// Layer_2
	this.instance = new lib.tile_19();
	this.instance.parent = this;
	this.instance.setTransform(-94.4,8.6,1.1,1.1);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_05, new cjs.Rectangle(-94.4,12.6,78.5,59.49999999999999), null);


(lib.tile_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AroEpIAApRIIYAAIAAJRg");
	mask.setTransform(-74.5033,-22.4716);

	// Layer_2
	this.instance = new lib.tile_20();
	this.instance.parent = this;
	this.instance.setTransform(-63.5,-53.3,1,1,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_04, new cjs.Rectangle(-149,-52.1,53.599999999999994,59.300000000000004), null);


(lib.tile_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ahjp4IAApTIIZAAIAAJTg");
	mask.setTransform(43.7542,-122.811);

	// Layer_2
	this.instance = new lib.tile_15();
	this.instance.parent = this;
	this.instance.setTransform(-22.5,-277.25,1.3738,1.3738);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_03, new cjs.Rectangle(33.7,-245.6,53.8,59.5), null);


(lib.tile_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsYk2IAApRIVjAAIAAJRg");
	mask.setTransform(-79.3454,-90.4093);

	// Layer_2
	this.instance = new lib.tile_14();
	this.instance.parent = this;
	this.instance.setTransform(-12.2,-184.9,1.3084,1.3084,0,0,180);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_02, new cjs.Rectangle(-158.7,-180.8,138,59.30000000000001), null);


(lib.tile_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AzQDdIAAk2IVnAAIAAE2g");
	mask.setTransform(-123.2542,22.0749);

	// Layer_2
	this.instance = new lib.tile_13();
	this.instance.parent = this;
	this.instance.setTransform(-246.5,13.05,0.8926,0.8926);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_01, new cjs.Rectangle(-246.5,13.1,138.4,31.1), null);


(lib.replaySub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("ABNA/YgaAagnAIghgOYgigOgWghAAgkYAAglAXghAigNYAigNAnAJAZAbIgWAUYgRgSgagGgWAJYgXAJgPAWAAAYYAAAYAOAWAXAKYAWAJAagFARgSg");
	this.shape.setTransform(1.25,0.05,0.8766,0.8766,135.0007,0,0,1.2,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1.2,1,1).p("AAChYIAACxAgMBZIAOAAIANAAAgNhYIAPAAIALAA");
	this.shape.setTransform(11.45,15.5);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(2).to({_off:false},0).wait(1));

	// Layer_3
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1.2,1,1).p("AgVCEIBlAAQACAAACgCIAAgfQAAgFABgFIARgiIAAADQAAgEAAgDIAAhiQAAgHgEgDQgDgFgHAAQgGAAgEAFQgFADAAAHIAAAmQAAABgCACQAAACgCAAQgBAAgCgCQgCgCAAgBIAAgyQAAgHgFgCQgCgFgIAAQgGAAgFAFQgFACAAAHIAAAoQgBABgBAAQgCAAgCgBIAAg0QAAgFgEgFQgFgEgHAAQgGAAgDAEQgCAAAAABQgEAEAAAFIAAAyQAAACAAABQgBAAgCAAQgCAAgBAAQAAgBAAgCIAAhgQAAgHgFgCQgFgFgGAAQgHAAgDAFQgFACAAAHIAACGQAAACgBAAQAAABgBAAQgDACgDgCQgCgDgBgFIgEgLQAAgBgBAAIgMgOIAAgBQgOgKgLAHIAAADQgFAEgBAFQgCAGADAGIBEBVIACACQADAFAAAGIAAAYQAAACABAAQACACACAAg");
	this.shape_1.setTransform(14.1886,16.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVCEQgBAAAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgZQAAgGgDgEIgCgCIhEhWQgDgGACgGQABgEAFgFIAAgDQALgHAOAKIAAACIAMANQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAIAEAMIADAHQADACADgCIABAAQAAAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAgBIAAiGQAAgGAFgDQADgFAHAAQAGAAAFAFQAFADAAAGIAABgIAAADIADAAIADAAIAAgDIAAgxQAAgGAEgEQAAAAAAAAQAAgBAAAAQAAAAABAAQAAAAABAAQADgDAGgBQAHABAFADQAEAFAAAGIAAAzIAEABIACgBIAAgnQAAgHAFgDQAFgFAGAAQAIAAACAFQAFADAAAHIAAAxQAAAAAAABQAAAAABAAQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQAAgBAAAAIAAgmQAAgHAFgDQAEgFAGAAQAHAAADAFQAEADAAAHIAABiIAAAHIAAgCIgRAhIgBAKIAAAfQgBAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAg");
	this.shape_2.setTransform(14.1886,16.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1.2,1,1).p("AgVB1IBlAAQACAAACgCIAAgfQAAgFABgFIARgiIAAADQAAgEAAgDIAAhbQAAgGgEgEIAAgBQgDgDgHAAQgGAAgEADIAAABQgFAEAAAGIAAAfQAAABgCACQAAACgCAAQgBAAgCgCQgCgCAAgBIAAgqQAAgGgFgEIAAgBQgCgFgIAAQgGAAgFAFIAAABQgFAEAAAGIAAAgQgBABgBAAQgCAAgCgBIAAgrQAAgGgEgFQgFgDgHAAQgGAAgDADIgCAAQgEAFAAAGIAAApQAAACAAABQgBAAgCAAQgCAAgBAAQAAgBAAgCIAAhBQAAgGgFgFQgFgEgGAAQgFAAgFAEQgFAFAAAGIAABnQAAACgBAAQAAABgBAAQgDACgDgCQgCgDgBgEIgEgLQAAgBgBAAIgMgPIAAgBQgOgKgLAHIAAADQgFAEgBAFQgCAHADAGIBEBUIACACQADAFAAAGIAAAYQAAACABAAQACACACAAg");
	this.shape_3.setTransform(14.1886,18.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#BCBCBC","#FCFCFC","#FFFFFF"],[0,0.259,1],-5.8,-11.4,1.4,7.5).s().p("AgVB1QgBAAAAAAQgBAAAAAAQgBgBAAAAQgBgBAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgZQAAgGgDgEIgCgCIhEhVQgDgGACgHQABgEAFgFIAAgDQALgHAOAKIAAACIAMAOQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAIAEAMIADAGQADACADgCIABAAQAAAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAgBIAAhmQAAgHAFgEQAFgFAFAAQAGAAAFAFQAFAEAAAHIAABAIAAADIADAAIADAAIAAgDIAAgpQAAgGAEgFIACAAQADgCAGgBQAHABAFACQAEAFAAAGIAAArIAEABIACgBIAAggQAAgGAFgDIAAgCQAFgEAGgBQAIABACAEIAAACQAFADAAAGIAAAqQAAAAAAABQAAAAABAAQAAABAAAAQABABAAAAQAAAAABABQAAAAABAAQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQAAAAABAAQAAgBAAAAQAAAAABgBQAAAAAAgBQABAAAAAAQAAgBAAAAIAAgfQAAgGAFgDIAAgCQAEgDAGAAQAHAAADADIAAACQAEADAAAGIAABbIAAAHIAAgCIgRAhIgBAKIAAAfQgBAAAAABQgBAAAAABQAAAAgBAAQAAAAgBAAg");
	this.shape_4.setTransform(14.1886,18.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1}]}).to({state:[{t:this.shape_4},{t:this.shape_3}]},1).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(3,2.5,22.4,28.4);


(lib.PageLayout_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Flow", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.PageLayout_txt, new cjs.Rectangle(0,0,18.4,15.5), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("AANApIAAgvIggAAIAABKIgVAAIAAhKIgQAAIAAgSIAQAAIAAgMQAAgJADgJQAFgIAHgDQAIgEAKgBQAGAAAFACIABAAIAAATIgBAAQgFgCgEgBQgGABgEAEQgDADgBAJIAAALIAgAAIAAgUIABgBIAUgGIABAAIAAAbIAWAAIAAASIgWAAIAAArQAAAJADADQADADAHABIAIgDIABgBIAAASIAAABIgHACIgJABQgcgBAAgdg");
	this.shape.setTransform(30.7515,0.0002);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXAMgMQANgOAWAAQAWAAAMANQAMAMAAAXQABAVgNAOQgNAOgWAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJALAAQANAAAGgJQAGgHAAgPQAAgNgGgJQgHgHgMgBQgLAAgGAIg");
	this.shape_1.setTransform(20.1013,2.2002);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AgSAvIgMgEIAAgVIABAAQAFAEAHADQAGACAGAAQAOAAAAgJQAAgDgCgDIgFgDIgKgGQgJgDgEgEQgEgCgDgFQgCgFAAgHQAAgNAKgHQAKgJAPAAIAKABIAKAEIABAAIAAAUIgBgBQgEgDgGgCIgLgBQgGAAgCACQgEACAAAFQAAAEADADQACADAKAEQANAGAFAFQAGAGAAAKQAAAMgKAIQgKAJgQAAIgNgCg");
	this.shape_2.setTransform(11.3262,2.2002);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AgiAjQgMgMAAgWQAAgXANgMQAMgOAWAAQAWAAAMANQAMANAAAWQABAVgNAOQgOAOgVAAQgVgBgNgNgAgRgWQgHAIAAAPQAAAOAHAHQAGAJAMAAQALAAAHgJQAGgIAAgOQAAgNgHgJQgGgHgMgBQgLAAgGAIg");
	this.shape_3.setTransform(2.451,2.2002);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("AgaAvIAAhcIAWAAIAAARIAAAAQADgIAEgEQAHgGAIAAQAFAAADABIABAAIAAAXIgBgBIgFgCIgHgBQgIAAgGAHQgEAJAAAKIAAAvg");
	this.shape_4.setTransform(-5.1241,2.1002);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("AgNAqQgLgFgFgLQgGgKAAgNQAAgOAGgMQAGgMALgGQALgGAPgBIAMACIAKADIAAABIAAAUIgBAAQgKgIgLAAQgMAAgHAJQgIAIAAAOQAAANAIAIQAGAJANAAQAFAAAGgCIAKgGIABgBIAAAUIAAAAQgLAHgPAAQgNAAgKgHg");
	this.shape_5.setTransform(-13.0742,2.2002);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AgIAJQgEgEAAgFQAAgEAEgEQADgDAFgBQAGABAEADQADADAAAFQAAAFgEAEQgDADgGABQgFgBgDgDg");
	this.shape_6.setTransform(-19.2743,-5.0999);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AgKAuIAAhbIAVAAIAABbg");
	this.shape_7.setTransform(-19.2993,2.1752);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#737373").s().p("AAwBAIABhoIgBAAIgCALIgnBdIgOAAIgmhcIgDgMIgBAAIABBoIgVAAIAAh/IAgAAIAlBhIAohhIAeAAIAAB/g");
	this.shape_8.setTransform(-29.4745,0.3502);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-7,72.9,14.1), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Microsoftlogo_rgb_cwhiteai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MS-symbol
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(54.9,54.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(17.125,54.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(54.9,17.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(17.125,17.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhsAAIAAD5IhKAAIAAj5Ig0AAIAAg7IA0AAIAAgrQAAgxAggfQAfggAyAAQANAAALACIASAEIAAA/QgDgCgKgDQgJgDgMAAQgXAAgMAOQgMAOAAAcIAAAmIBsAAIAAhGIBKgWIAABcIBJAAIAAA7IhJAAIAACQQAAAcAKANQAKALAXAAQAGAAAJgDQAHgCAIgFIAAA8QgHAEgQAEQgPADgQAAQgvAAgXgZgAIsDCQgrgrAAhJQAAhNAsgsQArgtBNAAQBJAAApAsQApAsAABHQAABMgsAsQgrAthLAAQhIAAgqgqgAJjAAQgWAaAAAyQAAAwAWAaQAWAZApAAQAoAAAVgZQAVgaAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAE7DnQgXgEgRgIIAAhHQAWAOAVAIQAWAIAUAAQAYAAAMgHQAMgHAAgQQAAgPgMgLQgMgKgigOQgogQgSgWQgRgVAAggQAAgpAigbQAhgbA1AAQAOAAAWADQATAEAPAGIAABFQgOgJgUgHQgRgHgVAAQgVAAgLAIQgMAIAAANQAAAQAKAJQAJAIAjAOQAsASARAVQASAWAAAfQAAAsgiAaQggAbg6AAQgTAAgYgFgAgiDCQgqgrAAhJQAAhNArgsQAqgtBOAAQBIAAApAsQApArAABIQAABMgsAsQgrAthLAAQhHAAgqgqgAAVAAQgVAZAAAzQAAAxAVAZQAWAZApAAQAnAAAVgZQAVgaAAgyQAAgzgWgYQgVgZgnAAQgoAAgWAagAoDDBQgqgrAAhEQAAhLArgvQAsgwBQAAQATAAAWAFQAVAFANAHIAABGQgQgLgTgIQgSgHgSAAQgrAAgaAbQgbAcAAAwQAAAvAaAaQAZAaAsAAQAQAAAUgHQAUgIAQgMIAABEQgRAJgXAGQgVAFgcAAQhEAAgrgrgAkEDkIAAk0IBIAAIAAAxIACAAQAKgaAUgOQAUgOAcAAIAQABIAMADIAABKQgGgEgLgEQgLgEgQAAQgaAAgTAVQgTAYAAAuIAACcgAqpDkIAAk0IBJAAIAAE0gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB9FAIABAAICDlAIBnAAIAAGvgAqkiMQgNgMAAgSQAAgRANgNQAOgMARAAQAUAAAMAMQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(215.625,34.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,337.7,72);


(lib.Microsoftlogo_rgb_cgrayai = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MS-symbol
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB82C").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(54.9,54.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A2EC").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(17.125,54.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7EB92D").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(54.9,17.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F55029").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(17.125,17.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#727272").s().p("ARIDTQgXgYAAgyIAAieIhsAAIAAD5IhKAAIAAj5Ig0AAIAAg7IA0AAIAAgrQAAgxAggfQAfggAyAAQANAAALACIASAEIAAA/QgDgCgKgDQgJgDgMAAQgXAAgMAOQgMAOAAAcIAAAmIBsAAIAAhGIBKgWIAABcIBJAAIAAA7IhJAAIAACQQAAAcAKANQAKALAXAAQAGAAAJgDQAHgCAIgFIAAA8QgHAEgQAEQgPADgQAAQgvAAgXgZgAIsDCQgrgrAAhJQAAhNAsgsQArgtBNAAQBJAAApAsQApAsAABHQAABMgsAsQgrAthLAAQhIAAgqgqgAJjAAQgWAaAAAyQAAAwAWAaQAWAZApAAQAoAAAVgZQAVgaAAgyQAAgygWgZQgVgZgnAAQgoAAgXAagAE7DnQgXgEgRgIIAAhHQAWAOAVAIQAWAIAUAAQAYAAAMgHQAMgHAAgQQAAgPgMgLQgMgKgigOQgogQgSgWQgRgVAAggQAAgpAigbQAhgbA1AAQAOAAAWADQATAEAPAGIAABFQgOgJgUgHQgRgHgVAAQgVAAgLAIQgMAIAAANQAAAQAKAJQAJAIAjAOQAsASARAVQASAWAAAfQAAAsgiAaQggAbg6AAQgTAAgYgFgAgiDCQgqgrAAhJQAAhNArgsQAqgtBOAAQBIAAApAsQApArAABIQAABMgsAsQgrAthLAAQhHAAgqgqgAAVAAQgVAZAAAzQAAAxAVAZQAWAZApAAQAnAAAVgZQAVgaAAgyQAAgzgWgYQgVgZgnAAQgoAAgWAagAoDDBQgqgrAAhEQAAhLArgvQAsgwBQAAQATAAAWAFQAVAFANAHIAABGQgQgLgTgIQgSgHgSAAQgrAAgaAbQgbAcAAAwQAAAvAaAaQAZAaAsAAQAQAAAUgHQAUgIAQgMIAABEQgRAJgXAGQgVAFgcAAQhEAAgrgrgAkEDkIAAk0IBIAAIAAAxIACAAQAKgaAUgOQAUgOAcAAIAQABIAMADIAABKQgGgEgLgEQgLgEgQAAQgaAAgTAVQgTAYAAAuIAACcgAqpDkIAAk0IBJAAIAAE0gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB9FAIABAAICDlAIBnAAIAAGvgAqkiMQgNgMAAgSQAAgRANgNQAOgMARAAQAUAAAMAMQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(215.625,34.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,337.7,72);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Insert_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("Upload", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Insert_txt, new cjs.Rectangle(0,0,26.5,15.5), null);


(lib.Home_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("New", "7px 'Segoe Pro'", "#494846");
	this.txt.name = "txt";
	this.txt.lineHeight = 11;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Home_txt, new cjs.Rectangle(0,0,18.1,16), null);


(lib.Excel_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("OneDrive", "13px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 19;
	this.txt.parent = this;
	this.txt.setTransform(-7,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

}).prototype = getMCSymbolPrototype(lib.Excel_txt, new cjs.Rectangle(-9,0,55.7,22.9), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.UI_Top_bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#286DBD").s().p("AghAFIAAgJIBDAAIAAAJg");
	this.shape.setTransform(69.9,49.7,0.7208,0.7208,0,0,0,0.3,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#286DBD").s().p("AAAgBIgZAYIAAgVIAZgYIAZAYIAAAVg");
	this.shape_1.setTransform(69.6265,52.6927,0.7202,0.7202);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#286DBD").s().p("AgHAwIAAhfIAOAAIAABfg");
	this.shape_2.setTransform(69.6275,55.738,0.7204,0.7204);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Outline
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_3.setTransform(240.5,20.85,0.525,0.525,0,0,0,0.1,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEBGIAAgcQAAgJAPgPQANgKAFgIQAIgKAAgLQAAgTgLgKQgKgJgPAAQgPAAgKAKQgMAKAAASIgKAAQAAgXAPgNQAOgMASAAQATAAAMAMQAPANAAAXQAAAOgJANQgHAHgMAMQgOANAAAEIAAAcg");
	this.shape_4.setTransform(240.55,15.65,0.525,0.525,0,0,0,0.2,0);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#494846").s().p("AglgMIAAgKIAlAkIAmgkIAAAKIgmAjg");
	this.shape_5.setTransform(50.875,56.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3}]}).wait(1));

	// Outline
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQBZIgfgMQgEgCABgEIAEgTIgBgCIgTAGQgFACgBgEIgOgeQgDgDAEgDIAQgLIgBgIIgQgLQgEgCACgEIAOgeQACgEADACIARAEIAEgFIgFgTQgBgEAFgCIAegMQAFgBABAEIAJAPIAGAAIAJgPQACgEAEABIAfAMQAEABgBAFIgEASIAFAGIARgFQAEgBACAEIAOAeQACAEgEACIgRALIAAABIgBAJIAPAKQADACgCAEIgOAeQgCAEgEgCIgTgGIAAABIAEATQABAEgEACIgfAMIgCAAQgDAAgBgDIgKgRIAAAAIgKARQgBABAAAAQAAABgBAAQAAABgBAAQAAAAgBAAIgCAAgAADA7QADAAACACIAJARIAWgJIgEgSQgBgDADgCIAFgEQACgDADACIARAFIAKgVIgNgKQgDgCABgDIABgKIgBgDQAAgFAEgBIAAAAIAPgJIgKgWIgQAEQgEABgBgCIgJgJQgDgDABgCIAEgRIgXgJIgIAOQgBADgDAAIgLAAQgDAAgCgCIgIgPIgXAJIAFASQAAADgCACIgIAIQgBACgEgBIgPgEIgKAWIAPAKQABAAAAABQABAAAAABQAAAAAAABQAAABAAAAIAAAEIABAIQAAAEgCABIgPALIALAWIARgGQAEgCABADIAGAFQACABAAAEIgEASIAWAJIAJgRQACgCADAAIABAAQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAg");
	this.shape_6.setTransform(224.4875,16.4422,0.5,0.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgWAYQgKgKAAgOQAAgNAKgJQAJgKANAAQAOAAAKAKQAJAJAAANQAAAOgJAKQgKAJgOAAQgNAAgJgJgAgPgPQgHAHAAAIQAAAKAHAGQAHAHAIAAQAKAAAGgHQAHgGAAgKQAAgIgHgHQgGgHgKAAQgIAAgHAHg");
	this.shape_7.setTransform(224.4125,16.4375,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6}]}).wait(1));

	// Outline
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOAFQgGgGAAgJIAKAAQAAAFADAEQADACAEAAQAFAAADgCQADgEAAgFIAKAAQAAAJgGAGQgGAGgJAAQgIAAgGgGg");
	this.shape_8.setTransform(208.5043,20.3368,0.525,0.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhDAFIAAgJICHAAIAAAJg");
	this.shape_9.setTransform(208.5831,19.5887,0.525,0.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAtA/IAAhGQAAgSgNgOQgNgNgTAAQgRAAgOANQgNAOAAASIAABGIgKAAIAAhGQAAgXAQgQQAQgQAWAAQAXAAAQAQQAQAQAAAXIAABGg");
	this.shape_10.setTransform(208.5043,16.2943,0.525,0.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Outline
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#286DBD").s().p("AgEAqIAAgjIgmAAIAAgJIAmAAIAAgnIAJAAIAAAnIAlAAIAAAJIglAAIAAAjg");
	this.shape_11.setTransform(14.3245,55.4058,0.7469,0.7469);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

	// Layer_2
	this.instance = new lib.Home_txt();
	this.instance.parent = this;
	this.instance.setTransform(36.7,64.8,1.2454,1.2454,0,0,0,12.4,7);

	this.instance_1 = new lib.Excel_txt();
	this.instance_1.parent = this;
	this.instance_1.setTransform(87.5,30.8,1,1,0,0,0,13.5,8.6);

	this.instance_2 = new lib.Insert_txt();
	this.instance_2.parent = this;
	this.instance_2.setTransform(88.05,64.8,1.2454,1.2454,0,0,0,11.3,7);

	this.instance_3 = new lib.PageLayout_txt();
	this.instance_3.parent = this;
	this.instance_3.setTransform(161.9,64.8,1.2454,1.2454,0,0,0,22.4,7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Layer_2
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#286DBD").s().p("AgeAtIAAgOIAQAAIAbhMIATAAIAAAPIgJAAIgbBLg");
	this.shape_12.setTransform(123.2,55.3,0.6227,0.6227,0,0,0,0.2,0.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#286DBD").s().p("AgbAbIAAg2IA4AAIAAA2gAgNAMIAaAAIAAgXIgaAAg");
	this.shape_13.setTransform(126.75,52.9,0.6227,0.6227,0,0,0,0.1,0.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#286DBD").s().p("AgcAbIAAg2IA4AAIAAA2gAgMANIAaAAIAAgYIgaAAg");
	this.shape_14.setTransform(119.9747,57.4704,0.6227,0.6227);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12}]}).wait(1));

	// Layer_11
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#DBE9F6").ss(1,1,1).p("AAAi2IAAFt");
	this.shape_15.setTransform(36.5,19);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAeBDIAAglIAlAAIAAAlgAgRBDIAAglIAjAAIAAAlgAhDBDIAAglIAlAAIAAAlgAAeATIAAglIAlAAIAAAlgAgRATIAAglIAjAAIAAAlgAhDATIAAglIAlAAIAAAlgAAegeIAAglIAlAAIAAAlgAgRgeIAAglIAjAAIAAAlgAhDgeIAAglIAlAAIAAAlg");
	this.shape_16.setTransform(17.75,19.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_16},{t:this.shape_15}]}).wait(1));

	// Layer_1
	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#DBE9F6").s().p("AsiCbIAAk1IZFAAIAAE1g");
	this.shape_17.setTransform(80.3,53.275);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#056EBF").s().p("AsjDAIAAl/IZHAAIAAF/g");
	this.shape_18.setTransform(80.35,18.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.UI_Top_bar, new cjs.Rectangle(0,-0.6,243,76.6), null);


(lib.tile_12copy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A3YLnIAA3NMAuxAAAIAAXNg");
	mask.setTransform(79.675,-22.875);

	// Layer_5
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(46.3,-52.25,0.7448,0.68,0,0,0,-0.4,-0.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.tile_12copy, new cjs.Rectangle(-70,-97.2,298.9,148.7), null);


(lib.tile_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(19).call(this.frame_19).wait(1));

	// Layer_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("ArkD4IAAnvIXJAAIAAHvg");
	var mask_graphics_1 = new cjs.Graphics().p("ArkD6IAAnzIXJAAIAAHzg");
	var mask_graphics_2 = new cjs.Graphics().p("ArnEEIAAoHIXPAAIAAIHg");
	var mask_graphics_3 = new cjs.Graphics().p("ArwEeIAAo7IXhAAIAAI7g");
	var mask_graphics_4 = new cjs.Graphics().p("AsAFTIAAqlIYBAAIAAKlg");
	var mask_graphics_5 = new cjs.Graphics().p("AsbGpIAAtRIY3AAIAANRg");
	var mask_graphics_6 = new cjs.Graphics().p("AtEIpIAAxRIaJAAIAARRg");
	var mask_graphics_7 = new cjs.Graphics().p("At8LcIAA23Ib5AAIAAW3g");
	var mask_graphics_8 = new cjs.Graphics().p("AvHPKIAA+TIePAAIAAeTg");
	var mask_graphics_9 = new cjs.Graphics().p("AwnT8MAAAgn3MAhPAAAMAAAAn3g");
	var mask_graphics_10 = new cjs.Graphics().p("AyYZnMAAAgzNMAkxAAAMAAAAzNg");
	var mask_graphics_11 = new cjs.Graphics().p("Az4eZMAAAg8xMAnxAAAMAAAA8xg");
	var mask_graphics_12 = new cjs.Graphics().p("EgVDAiHMAAAhENMAqHAAAMAAABENg");
	var mask_graphics_13 = new cjs.Graphics().p("EgV7Ak6MAAAhJzMAr3AAAMAAABJzg");
	var mask_graphics_14 = new cjs.Graphics().p("EgWkAm6MAAAhNzMAtJAAAMAAABNzg");
	var mask_graphics_15 = new cjs.Graphics().p("EgW/AoQMAAAhQfMAt/AAAMAAABQfg");
	var mask_graphics_16 = new cjs.Graphics().p("EgXPApEMAAAhSHMAufAAAMAAABSHg");
	var mask_graphics_17 = new cjs.Graphics().p("EgXYApfMAAAhS9MAuxAAAMAAABS9g");
	var mask_graphics_18 = new cjs.Graphics().p("EgXbAppMAAAhTRMAu3AAAMAAABTRg");
	var mask_graphics_19 = new cjs.Graphics().p("EgXbAprMAAAhTVMAu3AAAMAAABTVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-14.0494,y:14.1476}).wait(1).to({graphics:mask_graphics_1,x:-14.0148,y:14.1867}).wait(1).to({graphics:mask_graphics_2,x:-13.7725,y:14.4603}).wait(1).to({graphics:mask_graphics_3,x:-13.1149,y:15.203}).wait(1).to({graphics:mask_graphics_4,x:-11.8342,y:16.6493}).wait(1).to({graphics:mask_graphics_5,x:-9.7229,y:19.0337}).wait(1).to({graphics:mask_graphics_6,x:-6.5732,y:22.5907}).wait(1).to({graphics:mask_graphics_7,x:-2.1775,y:27.5549}).wait(1).to({graphics:mask_graphics_8,x:3.6719,y:34.1609}).wait(1).to({graphics:mask_graphics_9,x:11.1826,y:42.6431}).wait(1).to({graphics:mask_graphics_10,x:20.0692,y:52.679}).wait(1).to({graphics:mask_graphics_11,x:27.58,y:61.1612}).wait(1).to({graphics:mask_graphics_12,x:33.4294,y:67.7671}).wait(1).to({graphics:mask_graphics_13,x:37.8251,y:72.7313}).wait(1).to({graphics:mask_graphics_14,x:40.9747,y:76.2884}).wait(1).to({graphics:mask_graphics_15,x:43.0861,y:78.6728}).wait(1).to({graphics:mask_graphics_16,x:44.3667,y:80.119}).wait(1).to({graphics:mask_graphics_17,x:45.0243,y:80.8617}).wait(1).to({graphics:mask_graphics_18,x:45.2666,y:81.1353}).wait(1).to({graphics:mask_graphics_19,x:45.1012,y:81.2246}).wait(1));

	// Layer_5
	this.instance = new lib.Tween2("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-45,-5.45,0.3,0.3);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:-50,y:-51.5},19,cjs.Ease.cubicInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-104.9,-350,334.9,679.5);


(lib.ScreenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.whiteRect();
	this.instance.parent = this;
	this.instance.setTransform(150,236,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.ScreenBG, new cjs.Rectangle(0,-64,300,600), null);


(lib.screen_tiles = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_18 = new lib.tile_18();
	this.tile_18.name = "tile_18";
	this.tile_18.parent = this;
	this.tile_18.setTransform(76.95,-28.5,0.72,0.7,0,-0.4996,0,0.3,-0.4);

	this.instance = new lib.tile_15();
	this.instance.parent = this;
	this.instance.setTransform(35.9,1.95,0.7111,0.6897,0,-0.5223,0);

	this.instance_1 = new lib.tile_16();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-10.45,1.95,0.7111,0.6897,0,-0.5223,0);

	this.instance_2 = new lib.tile_17();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-99.65,1.95,0.7111,0.6897,0,-0.5223,0);

	this.instance_3 = new lib.tile_19();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-23.85,-55.05,0.7111,0.6897,0,-0.5223,0);

	this.instance_4 = new lib.tile_20();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-100.15,-55.05,0.7111,0.6897,0,-0.5223,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance},{t:this.tile_18}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.screen_tiles, new cjs.Rectangle(-100.1,-55.1,216.7,110.2), null);


(lib.scene1_fg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.screen_tiles();
	this.instance.parent = this;
	this.instance.setTransform(178.8,348.45,0.499,0.499);
	this.instance.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib._160x600_foreground();
	this.instance_1.parent = this;
	this.instance_1.setTransform(40,274);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene1_fg, new cjs.Rectangle(40,274,220,326), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.replaySub("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:16.55,alpha:1},1).to({_off:true},2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.officeBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_8
	this.instance = new lib.tile_18();
	this.instance.parent = this;
	this.instance.setTransform(189.35,141.7,1.4337,1.4337,0,0,0,0.1,0.1);
	this.instance.alpha = 0.75;

	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#E1E1E1","#FFFFFF"],[0,1],-89,-5.6,-29.8,-5.1).s().p("AtqKmIAAAAIAA1LIAWAAIF0AAIAAAYIVLAAIAAUzg");
	this.shape.setTransform(161.85,143.2375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],35.8,-34.5,37.1,0).s().p("AyvCZIAAjZIAAhVIAAgDMAgxAAAIAAADIBUBVIDaDZIgTAAg");
	this.shape_1.setTransform(173.625,239.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],-34.8,-8.5,-6.4,-9.5).s().p("ACCPeIATAAIjZjaIhUhUIAAgEIAAAAIAA5nIAAgjIBaAAIDXAAIAAe8g");
	this.shape_2.setTransform(278.725,156.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B5B5B5").s().p("At2MCIAA1LIAYAAIAAAAIAAVLgAnUoxIAAgYIAAAAIAAAAIVLAAIAAAAIAAAYgAt2reIAAgjIAYAAIAAAjg");
	this.shape_3.setTransform(160.65,134);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#E9E9E9").s().p("AwLM0IgaAAIAA5nIAjAAICuAAIAAAAIAYAAIbgAAICCAAIAAZnIAAAAgAtUKtIAAADIAYAAIbVAAIAAgCIAA00IAAgXIAAgBI1KAAIgBAAIAAABIlzAAIgXgBIgYAAg");
	this.shape_4.setTransform(157.225,142.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	// Layer_3
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],21.1,6.8,3.9,6.3).s().p("AhcLRIAA2hIADAAICzC3IgBABIACABIACAAIAAQuIAAACIi2C4IALAAg");
	this.shape_5.setTransform(265.104,217.3283);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],13.3,-20.9,12.5,0).s().p("Al4BdIC3i3IAAgCII6AAIAAACIAAC3IrmAAg");
	this.shape_6.setTransform(293.7795,280.1292);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#788281","rgba(120,130,129,0)"],[0,1],6.7,25.1,6.3,4.6).s().p("AjBBdIgEgCIABAAIi0i3ILxAAIAAC3IAAACg");
	this.shape_7.setTransform(293.7795,154.4773);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E9E9E9").s().p("AkcIXIAAwtII5AAIAABZInkAAIAAODIHkAAIAAA8IAAAVg");
	this.shape_8.setTransform(302.9296,217.2783);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5}]}).wait(1));

	// Layer_11
	this.instance_1 = new lib.tile_10();
	this.instance_1.parent = this;
	this.instance_1.setTransform(323.2,220.8,0.8897,0.8897,0,0,0,-0.4,0.8);
	this.instance_1.alpha = 0.75;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_10
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.18,1],-21.8,-4.5,14.1,-4.5).s().p("AjFHLIAAuLIGLGBIAAIKgAjFnIIAAgCIAGAAIACACg");
	this.shape_9.setTransform(302.2796,218.0283);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#BBBBBB","#E1E1E1","#FFFFFF"],[0,0.18,1],22.4,-20.6,22.4,15.3).s().p("AjGi7IAAgJIAHAAICgAAIDmAAIgDGJg");
	this.shape_10.setTransform(302.4046,191.9529);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// Layer_9
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B3C2C0").s().p("EgbpAu4MAAAhdvMA3TAAUMgAUBdbg");
	this.shape_11.setTransform(177.025,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_11).wait(1));

}).prototype = getMCSymbolPrototype(lib.officeBG, new cjs.Rectangle(0,0,384.1,600), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.parent = this;
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.ms.cache(-73,-14,146,28,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.parent = this;
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.MainComposition = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.Bottom_bar = new lib.UI_Bottom_bar();
	this.Bottom_bar.name = "Bottom_bar";
	this.Bottom_bar.parent = this;
	this.Bottom_bar.setTransform(150,589.7);

	this.Top_bar = new lib.UI_Top_bar();
	this.Top_bar.name = "Top_bar";
	this.Top_bar.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.Top_bar},{t:this.Bottom_bar}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.MainComposition, new cjs.Rectangle(0,-0.6,243,76.6), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ms();
	this.instance.parent = this;
	this.instance.setTransform(14,-0.35);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.0247,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.3249,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.0247,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.3249,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-50.4,-10.7,100.9,21.5), null);


(lib.laptop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tile_12copy();
	this.instance.parent = this;
	this.instance.setTransform(-70.8,2.3,0.512,0.5133,0,-0.8124,0,-45.6,-5.2);

	this.instance_1 = new lib._300x600_laptop();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-102,-81.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.laptop, new cjs.Rectangle(-159.2,-155,261.2,266.2), null);


(lib.final_frame_bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.laptop = new lib.laptop();
	this.laptop.name = "laptop";
	this.laptop.parent = this;
	this.laptop.setTransform(131.3,129.55,0.8113,0.8113);

	this.timeline.addTween(cjs.Tween.get(this.laptop).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(253,253,253,0)","rgba(253,253,253,0.184)","rgba(253,253,253,0.753)","#FDFDFD"],[0,0.243,0.651,1],-4,177.8,-4,57.8).s().p("EgzAAc5IjrgFMAAAg5tMBtXAAAMAAAA5tMhOqgApIgCgQQgCgUABgQQAbgQCLhMQB/hLAAgfQADgxhQgpQgugWhhgrQgVghgkgjIgnglIgwhEQgggtgagaQhPhOiCgDQjEgEh1C7QglA7gXBGIgRA7Ig4AAIggh4Qgnh8gmgWQgQgJhFAdQhLAfhUA4QjiCUhaCvQgeA8gIBRQgBAVAABOQgBAChBAAIipgBg");
	this.shape.setTransform(0,-440.8559);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_4
	this.instance = new lib._300x600_final_frameCopy();
	this.instance.parent = this;
	this.instance.setTransform(-246,-381,1.5721,1.5721);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.final_frame_bg, new cjs.Rectangle(-350,-625.9,700,1007.4), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.parent = this;
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.screenAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_99 = function() {
		this.tile_12.play();
	}
	this.frame_121 = function() {
		this.stop()
			exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(99).call(this.frame_99).wait(22).call(this.frame_121).wait(1));

	// hand
	this.instance = new lib.pointer("single",0);
	this.instance.parent = this;
	this.instance.setTransform(389.65,310.85,1,1,0,0,0,14,16.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(63).to({_off:false},0).to({x:110.75,y:247.95},23,cjs.Ease.quadOut).wait(13).to({startPosition:1},0).wait(4).to({startPosition:0},0).to({x:371.4,y:362.15},17,cjs.Ease.quadInOut).to({_off:true},1).wait(1));

	// UI
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#007FEC").ss(3,1,0,3).p("AqvkkIVfAAIAAJJI1fAAg");
	this.shape.setTransform(80.975,233.25);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(81).to({_off:false},0).to({_off:true},19).wait(22));

	// text
	this.UI = new lib.MainComposition();
	this.UI.name = "UI";
	this.UI.parent = this;
	this.UI.setTransform(150,304.1,1,1,0,0,0,150,304.1);

	this.timeline.addTween(cjs.Tween.get(this.UI).wait(122));

	// Tile_12
	this.tile_12 = new lib.tile_12();
	this.tile_12.name = "tile_12";
	this.tile_12.parent = this;
	this.tile_12.setTransform(116.75,217.1,1.189,1.189,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.tile_12).wait(122));

	// tile_01
	this.tile_01 = new lib.tile_01();
	this.tile_01.name = "tile_01";
	this.tile_01.parent = this;
	this.tile_01.setTransform(258.5,624.5);
	this.tile_01.alpha = 0;
	this.tile_01._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_01).wait(31).to({_off:false},0).to({y:579.5,alpha:1},24,cjs.Ease.quartOut).to({_off:true},66).wait(1));

	// tile_05
	this.tile_05 = new lib.tile_05();
	this.tile_05.name = "tile_05";
	this.tile_05.parent = this;
	this.tile_05.setTransform(166,561);
	this.tile_05.alpha = 0;
	this.tile_05._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_05).wait(29).to({_off:false},0).to({y:516,alpha:1},24,cjs.Ease.quartOut).wait(5).to({_off:true},63).wait(1));

	// tile_08
	this.tile_08 = new lib.tile_08();
	this.tile_08.name = "tile_08";
	this.tile_08.parent = this;
	this.tile_08.setTransform(170,478.5);
	this.tile_08.alpha = 0;
	this.tile_08._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_08).wait(27).to({_off:false},0).to({y:433.5,alpha:1},24,cjs.Ease.quartOut).wait(7).to({_off:true},63).wait(1));

	// tile_04
	this.tile_04 = new lib.tile_04();
	this.tile_04.name = "tile_04";
	this.tile_04.parent = this;
	this.tile_04.setTransform(245.5,561);
	this.tile_04.alpha = 0;
	this.tile_04._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_04).wait(25).to({_off:false},0).to({y:516,alpha:1},24,cjs.Ease.quartOut).wait(9).to({_off:true},63).wait(1));

	// tile_09
	this.tile_09 = new lib.tile_09();
	this.tile_09.name = "tile_09";
	this.tile_09.parent = this;
	this.tile_09.setTransform(62.5,478.5);
	this.tile_09.alpha = 0;
	this.tile_09._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_09).wait(23).to({_off:false},0).to({y:433.5,alpha:1},24,cjs.Ease.quartOut).wait(11).to({_off:true},63).wait(1));

	// tile_02
	this.tile_02 = new lib.tile_02();
	this.tile_02.name = "tile_02";
	this.tile_02.parent = this;
	this.tile_02.setTransform(170.5,624.5);
	this.tile_02.alpha = 0;
	this.tile_02._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_02).wait(21).to({_off:false},0).to({y:579.5,alpha:1},24,cjs.Ease.quartOut).wait(13).to({_off:true},63).wait(1));

	// tile_03
	this.tile_03 = new lib.tile_03();
	this.tile_03.name = "tile_03";
	this.tile_03.parent = this;
	this.tile_03.setTransform(62.5,624.5);
	this.tile_03.alpha = 0;
	this.tile_03._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_03).wait(19).to({_off:false},0).to({y:579.5,alpha:1},24,cjs.Ease.quartOut).wait(15).to({_off:true},63).wait(1));

	// tile_06
	this.tile_06 = new lib.tile_06();
	this.tile_06.name = "tile_06";
	this.tile_06.parent = this;
	this.tile_06.setTransform(71,561);
	this.tile_06.alpha = 0;
	this.tile_06._off = true;

	this.timeline.addTween(cjs.Tween.get(this.tile_06).wait(17).to({_off:false},0).to({y:516,alpha:1},24,cjs.Ease.quartOut).wait(40).to({_off:true},40).wait(1));

	// tile_13
	this.tile_13 = new lib.tile_13_1();
	this.tile_13.name = "tile_13";
	this.tile_13.parent = this;
	this.tile_13.setTransform(74.85,299.4,0.8357,0.8357);

	this.timeline.addTween(cjs.Tween.get(this.tile_13).to({_off:true},121).wait(1));

	// tile_14
	this.tile_14 = new lib.tile_14_1();
	this.tile_14.name = "tile_14";
	this.tile_14.parent = this;
	this.tile_14.setTransform(100,307.05);

	this.timeline.addTween(cjs.Tween.get(this.tile_14).to({_off:true},121).wait(1));

	// tile_16
	this.tile_16 = new lib.tile_16_1();
	this.tile_16.name = "tile_16";
	this.tile_16.parent = this;
	this.tile_16.setTransform(42.45,168.4,0.7714,0.7714,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.tile_16).to({_off:true},121).wait(1));

	// tile_17
	this.tile_17 = new lib.tile_17_1();
	this.tile_17.name = "tile_17";
	this.tile_17.parent = this;
	this.tile_17.setTransform(71,187.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_17).to({_off:true},121).wait(1));

	// tile_19
	this.tile_19 = new lib.tile_19_1();
	this.tile_19.name = "tile_19";
	this.tile_19.parent = this;
	this.tile_19.setTransform(169.5,106);

	this.timeline.addTween(cjs.Tween.get(this.tile_19).to({_off:true},121).wait(1));

	// tile_20
	this.tile_20 = new lib.tile_20_1();
	this.tile_20.name = "tile_20";
	this.tile_20.parent = this;
	this.tile_20.setTransform(62.5,106);

	this.timeline.addTween(cjs.Tween.get(this.tile_20).to({_off:true},121).wait(1));

	// ScreenBG
	this.instance_1 = new lib.ScreenBG();
	this.instance_1.parent = this;
	this.instance_1.setTransform(150,163,1,1,0,0,0,150,98);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(122));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-61.9,-0.6,463,809);


(lib.scene3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// 300x600_laptop.png
	this.bg = new lib.final_frame_bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(-49,218.5);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene3, new cjs.Rectangle(-399,-407.4,700,1007.4), null);


(lib.scene_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.fg = new lib.scene1_fg();
	this.fg.name = "fg";
	this.fg.parent = this;
	this.fg.setTransform(77.7,309,1,1,0,0,0,176,300);

	this.timeline.addTween(cjs.Tween.get(this.fg).wait(1));

	// Layer_6
	this.bg = new lib.officeBG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(455,595.5,1,1,0,0,0,617,595.5);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.scene_1, new cjs.Rectangle(-162,0,384.1,609), null);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(-11.6,-0.65,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.parent = this;
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#D83B01").s().p("ApyCgIAAk/ITkAAIAAE/g");
	this.shape.setTransform(-37.5,-1.65);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-100.1,-17.6,125.3,31.900000000000002), null);


(lib.MSFT_Logocopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(-0.35,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(1));

}).prototype = getMCSymbolPrototype(lib.MSFT_Logocopy, new cjs.Rectangle(-50.8,-9.3,100.9,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_51 = function() {
		exportRoot.tl1.play()
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(51).call(this.frame_51).wait(23).call(this.frame_74).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.parent = this;
	this.instance.setTransform(70.35,901.75,0.2458,0.2458,0,0,0,-39.6,1.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.0646,scaleY:4.0646,y:901.5},13,cjs.Ease.quadOut).to({x:-90.95},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgQcBJ5IAAttMAzoAAAIAANtg");
	var mask_graphics_15 = new cjs.Graphics().p("EgQoBJ5IAAttMAzoAAAIAANtg");
	var mask_graphics_16 = new cjs.Graphics().p("EgRJBJ5IAAttMAznAAAIAANtg");
	var mask_graphics_17 = new cjs.Graphics().p("EgSCBJ5IAAttMAzoAAAIAANtg");
	var mask_graphics_18 = new cjs.Graphics().p("EgTRBJ5IAAttMAzoAAAIAANtg");
	var mask_graphics_19 = new cjs.Graphics().p("EgU2BJ5IAAttMAzoAAAIAANtg");
	var mask_graphics_20 = new cjs.Graphics().p("EgWyBJ5IAAttMAznAAAIAANtg");
	var mask_graphics_21 = new cjs.Graphics().p("EgYvBJ5IAAttMAzoAAAIAANtg");
	var mask_graphics_22 = new cjs.Graphics().p("EgZzBJ5IAAttMAznAAAIAANtg");
	var mask_graphics_23 = new cjs.Graphics().p("EgZzBJ5IAAttMAznAAAIAANtg");
	var mask_graphics_24 = new cjs.Graphics().p("EgZzBJ5IAAttMAznAAAIAANtg");
	var mask_graphics_25 = new cjs.Graphics().p("EgZzBJ5IAAttMAznAAAIAANtg");
	var mask_graphics_26 = new cjs.Graphics().p("EgZzBJ5IAAttMAznAAAIAANtg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:225.1604,y:472.8866}).wait(1).to({graphics:mask_graphics_15,x:224.0323,y:472.8866}).wait(1).to({graphics:mask_graphics_16,x:220.648,y:472.8866}).wait(1).to({graphics:mask_graphics_17,x:215.0076,y:472.8866}).wait(1).to({graphics:mask_graphics_18,x:207.1109,y:472.8866}).wait(1).to({graphics:mask_graphics_19,x:196.9581,y:472.8866}).wait(1).to({graphics:mask_graphics_20,x:184.5491,y:472.8866}).wait(1).to({graphics:mask_graphics_21,x:172.1401,y:472.8866}).wait(1).to({graphics:mask_graphics_22,x:158.7263,y:472.8866}).wait(1).to({graphics:mask_graphics_23,x:142.933,y:472.8866}).wait(1).to({graphics:mask_graphics_24,x:131.6521,y:472.8866}).wait(1).to({graphics:mask_graphics_25,x:124.8836,y:472.8866}).wait(1).to({graphics:mask_graphics_26,x:122.6726,y:472.8866}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logocopy();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-90.35,896.6,4.0646,4.0646,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.parent = this;
	this.instance_2.setTransform(72.05,896.6,4.0646,4.0646,0,0,0,0.1,0.2);

	var maskedShapeInstanceList = [this.instance_1,this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},14).to({state:[{t:this.instance_2}]},12).to({state:[]},25).wait(24));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({_off:true,x:72.05},12,cjs.Ease.quadInOut).wait(49));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EgpSCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgpuCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgtACXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EgweCXoMAAAkvgMBSlAARMAAAEvgg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Eg0ICXoMAAAkvgMBSmAARMAAAEvgg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Eg3+CXoMAAAkvgMBSmAARMAAAEvgg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:76.7311,y:904.6245}).wait(51).to({graphics:mask_1_graphics_51,x:76.7311,y:904.6245}).wait(1).to({graphics:mask_1_graphics_52,x:75.5316,y:904.6205}).wait(1).to({graphics:mask_1_graphics_53,x:71.9329,y:904.6086}).wait(1).to({graphics:mask_1_graphics_54,x:65.9352,y:904.5888}).wait(1).to({graphics:mask_1_graphics_55,x:57.5384,y:904.561}).wait(1).to({graphics:mask_1_graphics_56,x:46.7425,y:904.5253}).wait(1).to({graphics:mask_1_graphics_57,x:33.5474,y:904.4816}).wait(1).to({graphics:mask_1_graphics_58,x:17.9533,y:904.43}).wait(1).to({graphics:mask_1_graphics_59,x:-0.0399,y:904.3705}).wait(1).to({graphics:mask_1_graphics_60,x:-20.4321,y:904.303}).wait(1).to({graphics:mask_1_graphics_61,x:-43.2235,y:904.2276}).wait(1).to({graphics:mask_1_graphics_62,x:-68.414,y:904.1443}).wait(1).to({graphics:mask_1_graphics_63,x:-96.0036,y:904.053}).wait(1).to({graphics:mask_1_graphics_64,x:-125.9922,y:903.9538}).wait(1).to({graphics:mask_1_graphics_65,x:-158.38,y:903.8467}).wait(1).to({graphics:mask_1_graphics_66,x:-193.1668,y:903.7316}).wait(1).to({graphics:mask_1_graphics_67,x:-230.3528,y:903.6086}).wait(1).to({graphics:mask_1_graphics_68,x:-267.1358,y:903.4776}).wait(1).to({graphics:mask_1_graphics_69,x:-288.1278,y:903.3388}).wait(1).to({graphics:mask_1_graphics_70,x:-310.3194,y:903.1919}).wait(1).to({graphics:mask_1_graphics_71,x:-333.7106,y:903.0372}).wait(1).to({graphics:mask_1_graphics_72,x:-358.3,y:902.8745}).wait(3));

	// Layer 3
	this.instance_3 = new lib.MSFT_Logo_anim();
	this.instance_3.parent = this;
	this.instance_3.setTransform(72.05,897,4.0649,4.066,0,0,0,0.1,0.3);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({_off:false},0).wait(24));

	// white
	this.instance_4 = new lib.white();
	this.instance_4.parent = this;
	this.instance_4.setTransform(76.7,904.45,0.5445,2.3867,0,0,0.1895,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({x:-452.3,y:902.7},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_5 = new lib.white();
	this.instance_5.parent = this;
	this.instance_5.setTransform(76.7,904.45,0.5445,2.3867,0,0,0.1895,485.4,406.9);
	this.instance_5.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(53).to({x:-448.4,y:902.75},21,cjs.Ease.quadIn).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-716.6,-69.2,1057.7,1946);


(lib.anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5));

	// Logo
	this.logo_white = new lib.Microsoftlogo_rgb_cwhiteai();
	this.logo_white.name = "logo_white";
	this.logo_white.parent = this;
	this.logo_white.setTransform(108.3,472.9,0.2111,0.2111,0,0,0,434.4,2163.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_white).wait(5));

	// Screen
	this.screenAnim = new lib.screenAnim();
	this.screenAnim.name = "screenAnim";
	this.screenAnim.parent = this;
	this.screenAnim.setTransform(150,302.4,1,1,0,0,0,150,302.4);

	this.timeline.addTween(cjs.Tween.get(this.screenAnim).wait(5));

	// scene1
	this.scene_1 = new lib.scene_1();
	this.scene_1.name = "scene_1";
	this.scene_1.parent = this;
	this.scene_1.setTransform(150.1,308.9,1,1,0,0,0,150.1,308.9);

	this.timeline.addTween(cjs.Tween.get(this.scene_1).to({_off:true},1).wait(4));

	// Logo
	this.logo_grey = new lib.Microsoftlogo_rgb_cgrayai();
	this.logo_grey.name = "logo_grey";
	this.logo_grey.parent = this;
	this.logo_grey.setTransform(52.3,23.9,0.2111,0.2111,0,0,0,169.1,36.3);

	this.timeline.addTween(cjs.Tween.get(this.logo_grey).wait(5));

	// scene3
	this.scene_3 = new lib.scene3();
	this.scene_3.name = "scene_3";
	this.scene_3.parent = this;
	this.scene_3.setTransform(150,386.1,1,1,0,0,0,150,386.1);

	this.timeline.addTween(cjs.Tween.get(this.scene_3).wait(5));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-399,-407.4,700,1016.4);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// intro logo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.parent = this;
	this.logo_intro.setTransform(57.55,19.65,0.312,0.312);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.parent = this;
	this.replay_btn.setTransform(142.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(101.1,569.3,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(153.3,570.85,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Anim
	this.animMC = new lib.anim();
	this.animMC.name = "animMC";
	this.animMC.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.animMC).wait(1));

	// BG
	this.bg = new lib.whiteBG();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(150,124.95,1,0.4141,0,0,0,150,301.7);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-399,-407.4,700,1016.4), null);


// stage content:
(lib.O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.animMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		this.runBanner = function() {
			
			
			
			
			exportRoot.tl1 = new TimelineLite();
			
			this.tl1.stop();
			mc.logo_intro.gotoAndPlay(1);
			
			//scene1 parallax
			exportRoot.tl1.from(mc.animMC.scene_1.fg, 2,{x:"+=100", ease:Power3.easeOut});
			exportRoot.tl1.from(mc.animMC.scene_1.bg, 2,{x:"+=50", ease:Power3.easeOut}, "-=2");
			
			//zoom in
			exportRoot.tl1.from(mc.animMC.screenAnim, 0.7,{alpha:0, scaleX:0.915, scaleY:0.235, x:"+=0", y:"+=50", skewX:-0.5, skewY:-0.3, ease: Power3.easeInOut}, "+=0");
			exportRoot.tl1.to(mc.animMC.scene_1, 0.7,{ scaleX:4.25, scaleY:4.25, y:"-=180", x:"+=300", ease:Power3.easeInOut,onStart: function(){mc.animMC.screenAnim.play();}}, "-=0.7");
			exportRoot.tl1.to(mc.animMC.logo_white, 0.7,{ scaleX:4.25, scaleY:4.25, ease:Power3.easeInOut,onComplete: function(){ mc.animMC.scene_1.alpha=0; exportRoot.tl1.stop();}}, "-=0.7");
		
			
			//final Scene 
			//exportRoot.tl1.to(mc.animMC.screenAnim, 2,{ x:"-=3", y:"+=76", scaleX:.5133, scaleY:.1689, skewX:-0.4, alpha:0, ease:Power3.easeInOut});
		
			exportRoot.tl1.to(mc.animMC.screenAnim, 1,{ x:"-=20", y:"+=0", scaleX:0.90, scaleY:0.05, alpha:0, ease:Power3.easeInOut});
			exportRoot.tl1.from(mc.animMC.scene_3.bg, 1,{ y:"-=860", x:"-=840", scaleX:5.9, scaleY:5.9, ease:Power3.easeInOut},"-=1");
			//exportRoot.tl1.from(mc.animMC.scene_3.bg, 2,{ x:"+=50", ease:Power3.easeOut},"-=2");
		
			exportRoot.tl1.to(mc.animMC.scene_3.bg, 2,{ scaleX:.635, scaleY:.635, x:"+=204", y:"+=195", ease:Power3.easeInOut},"+=0");
			exportRoot.tl1.to(mc.animMC.scene_3.bg.laptop, 1,{ x:"+=25", ease:Power3.easeIn},"-=1.5");
		
			exportRoot.tl1.stop();
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
					for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
			}
		
			exportRoot.tl1.from(mc.cta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.6");
			exportRoot.tl1.from(mc.txtCta, 0.8, {x: "+=150", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "-=0.7");
			
			
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.parent = this;
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-319,-107.4,620,716.4);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#0078D4",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_.png?1567186395208", id:"O365_GigWorkers_USA_160x600_BAN_Photographer_OneDrive_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;