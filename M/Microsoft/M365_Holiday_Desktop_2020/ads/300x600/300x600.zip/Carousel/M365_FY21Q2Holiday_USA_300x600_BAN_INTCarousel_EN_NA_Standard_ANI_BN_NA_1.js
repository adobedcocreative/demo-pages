(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1", frames: [[956,1376,137,243],[0,666,582,353],[584,666,582,353],[0,1021,582,353],[584,1021,582,353],[0,0,323,664],[325,0,323,664],[650,0,323,664],[1300,0,109,424],[975,0,323,664],[0,1376,420,214],[1411,53,44,43],[1411,0,51,51],[1386,758,103,103],[1168,1100,265,232],[1168,1334,265,232],[422,1376,265,232],[689,1376,265,232],[1168,666,216,432],[1300,426,184,215],[1386,863,103,85],[1386,643,109,113]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.CoffeeCup11 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Desktop_Images_0000s_0000_PPTDesktop11 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Desktop_Images_0000s_0001_WordDesktop = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Desktop_Images_0000s_0002_ExcelDesktop1 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Desktop_Images_0000s_0003_ODDesktop = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.enlargeonedrive = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Enlargedexcel = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Enlargedppt = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.enlargedshadow = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Enlargedword = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.firtwigandpineconeswhitebackgroundVUE4NYF = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.FY21HOLGoldFillerCluster3 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.FY21HOLGoldFillerStar1 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.FY21HOLGoldFillerStar2 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Mobile_Images_0000s_0000_PPTMobile = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Mobile_Images_0000s_0001_WordMobile = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Mobile_Images_0000s_0002_ExcelMobile1 = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Mobile_Images_0000s_0003_ODMobile = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.OneDriveBackgroundElements = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.OvenMit = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.snowflake_enlarge = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Snowflakes = function() {
	this.initialize(ss["M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAjKMAAAhGTMAu3AAAMAAABGTg");
	this.shape.setTransform(150,126);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,-99,300,450), null);


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,250);


(lib.Tween7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#505050").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#505050").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3A3A3").s().p("AgaAaQgKgMAAgOQAAgOAKgMQAMgKAOAAQAOAAAMAKQALAMgBAOQABAOgLAMQgMALgOgBQgOABgMgLg");
	this.shape.setTransform(0.05,0.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.Tween1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AgZAZQgLgKAAgPQAAgOALgLQALgLAOAAQAPAAAKALQAMALAAAOQAAAPgMAKQgKAMgPAAQgOAAgLgMg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.snowflakes_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_5
	this.instance = new lib.snowflake_enlarge();
	this.instance.setTransform(42.5,361.35,0.7584,0.7584,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_4
	this.instance_1 = new lib.FY21HOLGoldFillerCluster3();
	this.instance_1.setTransform(143.8,21.75,0.7023,0.7023,180);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Layer_3
	this.instance_2 = new lib.FY21HOLGoldFillerStar1();
	this.instance_2.setTransform(86,-24.55,0.7118,0.7118);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Layer_2
	this.instance_3 = new lib.FY21HOLGoldFillerStar2();
	this.instance_3.setTransform(94.15,-70.5,0.7874,0.7874);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snowflakes_2, new cjs.Rectangle(-35.6,-70.5,210.9,431.9), null);


(lib.snowflakes_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Snowflakes();
	this.instance.setTransform(89.25,48.65,0.8186,0.8186,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.snowflakes_1, new cjs.Rectangle(0,-43.8,89.3,92.5), null);


(lib.shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.enlargedshadow();
	this.instance.setTransform(161.45,-0.25,0.7948,0.7948,0,0,180);

	this.instance_1 = new lib.enlargedshadow();
	this.instance_1.setTransform(0,0,0.7948,0.7948);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,-0.2,161.5,337.2), null);


(lib.Screen_2_Word = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Desktop_Images_0000s_0001_WordDesktop();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_2_Word, new cjs.Rectangle(0,0,582,353), null);


(lib.Screen_2_PPT = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Desktop_Images_0000s_0000_PPTDesktop11();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_2_PPT, new cjs.Rectangle(0,0,582,353), null);


(lib.Screen_2_OneDrive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Desktop_Images_0000s_0003_ODDesktop();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_2_OneDrive, new cjs.Rectangle(0,0,582,353), null);


(lib.Screen_2_Excel = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Desktop_Images_0000s_0002_ExcelDesktop1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_2_Excel, new cjs.Rectangle(0,0,582,353), null);


(lib.Screen_1_Word = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mobile_Images_0000s_0001_WordMobile();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_1_Word, new cjs.Rectangle(0,0,265,232), null);


(lib.Screen_1_PPT = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mobile_Images_0000s_0000_PPTMobile();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_1_PPT, new cjs.Rectangle(0,0,265,232), null);


(lib.Screen_1_OneDrive = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mobile_Images_0000s_0003_ODMobile();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_1_OneDrive, new cjs.Rectangle(0,0,265,232), null);


(lib.Screen_1_Excel = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Mobile_Images_0000s_0002_ExcelMobile1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_1_Excel, new cjs.Rectangle(0,0,265,232), null);


(lib.option_hit_round = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AinCpQghghgRgnQgUgqAAgwIAAgLQAChgBEhDIAJgJIAGgGQBAg2BUgBIALAAQAwAAAqAUQAeAMAbAXIAPAPIAIAHQA+BEAABcQAABjhGBGQhGBGhjAAQhiAAhFhGg");
	this.shape.setTransform(14.1799,14.1799,1.4,1.4);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19.2,-19.2,66.8,66.8);


(lib.option_hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.008)").s().p("AhPBRIAAihICfAAIAAAuIAAA6IAAA5g");
	this.shape.setTransform(10.7,14.4);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,18.7,22.5);


(lib.object_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer_1
	this.instance = new lib.OneDriveBackgroundElements();
	this.instance.setTransform(187.5,-70.55,0.6526,0.6526);

	this.instance_1 = new lib.firtwigandpineconeswhitebackgroundVUE4NYF();
	this.instance_1.setTransform(396.45,181.6,0.7444,0.7444,-161.1676);

	this.instance_2 = new lib.OvenMit();
	this.instance_2.setTransform(199.4,117.4,0.7397,0.7397,-89.9976);

	this.instance_3 = new lib.CoffeeCup11();
	this.instance_3.setTransform(211.3,-9.95,0.6582,0.6582,0.0053);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(100.6,-70.5,347.29999999999995,281.9);


(lib.ms = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.logo_box = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.hit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,300,600);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_9 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.Btn_Return = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,2,0,3).p("AA9g4Ig5A4IA5A5AgDg4Ig5A4IA5A5");
	this.shape.setTransform(13.3258,14.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D4").s().p("AhnBoQgrgrgBg9QABg8ArgrQArgrA8gBQA9ABArArQAsArAAA8QAAA9gsArQgrAsg9AAQg8AAgrgsg");
	this.shape_1.setTransform(14.75,14.75);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btn_Return, new cjs.Rectangle(0,0,29.5,29.5), null);


(lib.Btn_Expand = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,2,0,3).p("AAAAAIgmAAAAAgmIAAAmAAnAAIgnAAIAAAn");
	this.shape.setTransform(14.775,14.775);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D4").s().p("AicCcQhAhAAAhcQAAhaBAhCQBChABaAAQBcAABABAQBBBCAABaQAABchBBAQhABBhcAAQhaAAhChBg");
	this.shape_1.setTransform(14.725,14.725);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Btn_Expand, new cjs.Rectangle(-7.4,-7.4,44.3,44.3), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {out:0,over:1,down:2,hit:3};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Page_indicator_dot = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {selected:1,deselected:17};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_16 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16).call(this.frame_16).wait(19));

	// Layer_2
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(0,0,0.5,0.5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,alpha:1},16,cjs.Ease.cubicInOut).to({scaleX:0.5,scaleY:0.5,alpha:0},18,cjs.Ease.cubicInOut).wait(1));

	// Layer_1
	this.instance_1 = new lib.Tween2("synched",0);
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({scaleX:1,scaleY:1},16,cjs.Ease.cubicInOut).to({scaleX:0.5,scaleY:0.5},18,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.6,-3.6,7.300000000000001,7.300000000000001);


(lib.Page_indicator = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.dot_4 = new lib.Page_indicator_dot();
	this.dot_4.name = "dot_4";
	this.dot_4.setTransform(89.75,5.45);

	this.dot_3 = new lib.Page_indicator_dot();
	this.dot_3.name = "dot_3";
	this.dot_3.setTransform(69.3,5.45);

	this.dot_2 = new lib.Page_indicator_dot();
	this.dot_2.name = "dot_2";
	this.dot_2.setTransform(48.85,5.45);

	this.dot_1 = new lib.Page_indicator_dot();
	this.dot_1.name = "dot_1";
	this.dot_1.setTransform(28.4,5.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.dot_1},{t:this.dot_2},{t:this.dot_3},{t:this.dot_4}]}).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0078D4").ss(1,2,0,3).p("AHzgyIAzAyIgzAzAnygyIgzAyIAzAz");
	this.shape.setTransform(58.075,5.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page_indicator, new cjs.Rectangle(-1,-1,119.5,13), null);


(lib.object_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer_2
	this.instance = new lib.enlargeonedrive();
	this.instance.setTransform(50.6,174.95,0.5746,0.5746,-7.0518);

	this.instance_1 = new lib.Enlargedexcel();
	this.instance_1.setTransform(50.6,174.95,0.5746,0.5746,-7.0518);

	this.instance_2 = new lib.Enlargedword();
	this.instance_2.setTransform(50.6,174.95,0.5746,0.5746,-7.0518);

	this.instance_3 = new lib.Enlargedppt();
	this.instance_3.setTransform(50.6,174.95,0.5746,0.5746,-7.0518);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	// shadow
	this.instance_4 = new lib.shadow();
	this.instance_4.setTransform(107.1,379.75,1.1492,1.1492,-7.0518,0,0,43.4,168.7);
	this.instance_4.alpha = 0.3516;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(33.8,152.2,260.8,425.59999999999997);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.mountain_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.indicator = new lib.Page_indicator();
	this.indicator.name = "indicator";
	this.indicator.setTransform(220.2,517.05,1.3,1.3,0,0,0,59,5.8);

	this.btn_expand = new lib.Btn_Expand();
	this.btn_expand.name = "btn_expand";
	this.btn_expand.setTransform(257.55,353.55,1,1,0,0,0,14.8,14.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn_expand},{t:this.indicator}]}).wait(1));

	// screen_mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgruAozMAAAhRlMBXcAAAMAAABRlg");
	mask.setTransform(286.9,301.125);

	// Onedrive
	this.screen_1_onedrive = new lib.Screen_1_OneDrive();
	this.screen_1_onedrive.name = "screen_1_onedrive";
	this.screen_1_onedrive.setTransform(160,326.65,0.8402,0.8402,0,0,0,191.6,129.3);

	this.screen_2_onedrive = new lib.Screen_2_OneDrive();
	this.screen_2_onedrive.name = "screen_2_onedrive";
	this.screen_2_onedrive.setTransform(328.75,264.45,0.8402,0.8402,0,0,0,291.3,176.7);

	var maskedShapeInstanceList = [this.screen_1_onedrive,this.screen_2_onedrive];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen_2_onedrive},{t:this.screen_1_onedrive}]}).wait(1));

	// Excel
	this.screen_1_excel = new lib.Screen_1_Excel();
	this.screen_1_excel.name = "screen_1_excel";
	this.screen_1_excel.setTransform(159.95,326.6,0.84,0.84,0,0,0,191.6,129.3);

	this.screen_2_excel = new lib.Screen_2_Excel();
	this.screen_2_excel.name = "screen_2_excel";
	this.screen_2_excel.setTransform(328.75,264.45,0.8402,0.8402,0,0,0,291.3,176.7);

	var maskedShapeInstanceList = [this.screen_1_excel,this.screen_2_excel];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen_2_excel},{t:this.screen_1_excel}]}).wait(1));

	// Word
	this.screen_1_word = new lib.Screen_1_Word();
	this.screen_1_word.name = "screen_1_word";
	this.screen_1_word.setTransform(160,326.7,0.8402,0.8402,0,0,0,191.6,129.4);

	this.screen_2_word = new lib.Screen_2_Word();
	this.screen_2_word.name = "screen_2_word";
	this.screen_2_word.setTransform(328.75,264.55,0.8402,0.8402,0,0,0,291.3,176.8);

	var maskedShapeInstanceList = [this.screen_1_word,this.screen_2_word];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen_2_word},{t:this.screen_1_word}]}).wait(1));

	// PPT
	this.screen_1_ppt = new lib.Screen_1_PPT();
	this.screen_1_ppt.name = "screen_1_ppt";
	this.screen_1_ppt.setTransform(160,326.65,0.8402,0.8402,0,0,0,191.6,129.3);

	this.screen_2_ppt = new lib.Screen_2_PPT();
	this.screen_2_ppt.name = "screen_2_ppt";
	this.screen_2_ppt.setTransform(328.75,264.45,0.8402,0.8402,0,0,0,291.3,176.7);

	var maskedShapeInstanceList = [this.screen_1_ppt,this.screen_2_ppt];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.screen_2_ppt},{t:this.screen_1_ppt}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mountain_anim, new cjs.Rectangle(7.1,116,559.6999999999999,408.1), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		exportRoot.TL_MainIntro.play();
	}
	this.frame_74 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(5).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(266.05,515.45,0.1852,0.1851,0,0,0,-39.1,2.1);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.5673,scaleY:4.5673,x:265.85,y:521.45},13,cjs.Ease.quadOut).to({x:11.9},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgR1AsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_15 = new cjs.Graphics().p("EgSHAsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_16 = new cjs.Graphics().p("EgS8AsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_17 = new cjs.Graphics().p("EgUUAsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_18 = new cjs.Graphics().p("EgWQAsCIAAvaMBU8AAAIAAPag");
	var mask_graphics_19 = new cjs.Graphics().p("EgYvAsCIAAvaMBU8AAAIAAPag");
	var mask_graphics_20 = new cjs.Graphics().p("EgbxAsCIAAvaMBU8AAAIAAPag");
	var mask_graphics_21 = new cjs.Graphics().p("EgezAsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_22 = new cjs.Graphics().p("EghSAsCIAAvaMBU8AAAIAAPag");
	var mask_graphics_23 = new cjs.Graphics().p("EgjNAsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_24 = new cjs.Graphics().p("EgklAsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_25 = new cjs.Graphics().p("EglaAsCIAAvaMBU7AAAIAAPag");
	var mask_graphics_26 = new cjs.Graphics().p("EglsAsCIAAvaMBU7AAAIAAPag");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:429.392,y:281.7938}).wait(1).to({graphics:mask_graphics_15,x:427.6271,y:281.7938}).wait(1).to({graphics:mask_graphics_16,x:422.3323,y:281.7938}).wait(1).to({graphics:mask_graphics_17,x:413.5076,y:281.7938}).wait(1).to({graphics:mask_graphics_18,x:401.1531,y:281.7938}).wait(1).to({graphics:mask_graphics_19,x:385.2686,y:281.7938}).wait(1).to({graphics:mask_graphics_20,x:365.8543,y:281.7938}).wait(1).to({graphics:mask_graphics_21,x:346.44,y:281.7938}).wait(1).to({graphics:mask_graphics_22,x:330.5556,y:281.7938}).wait(1).to({graphics:mask_graphics_23,x:318.2011,y:281.7938}).wait(1).to({graphics:mask_graphics_24,x:309.3764,y:281.7938}).wait(1).to({graphics:mask_graphics_25,x:304.0816,y:281.7938}).wait(1).to({graphics:mask_graphics_26,x:302.342,y:281.7938}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.85,516.4,4.5673,4.5673,0,0,0,0.1,0.3);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({regX:0.2,x:195.6},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhIMCOVMAAAkcpMCQZAAAMAAAEcpg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhIDCODMAAAkcFMCQHAAAMAAAEcFg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhIDCODMAAAkcFMCQHAAAMAAAEcFg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhIDCOEMAAAkcHMCQHAAAMAAAEcHg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhIECOEMAAAkcHMCQJAAAMAAAEcHg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhIECOFMAAAkcJMCQJAAAMAAAEcJg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhIFCOGMAAAkcLMCQLAAAMAAAEcLg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhIFCOIMAAAkcPMCQLAAAMAAAEcPg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhIGCOJMAAAkcRMCQNAAAMAAAEcRg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhIHCOLMAAAkcVMCQPAAAMAAAEcVg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhIICONMAAAkcZMCQRAAAMAAAEcZg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhIJCOQMAAAkcfMCQTAAAMAAAEcfg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhILCOSMAAAkcjMCQXAAAMAAAEcjg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhIMCOVMAAAkcpMCQZAAAMAAAEcpg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhIOCOYMAAAkcvMCQdAAAMAAAEcvg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhIPCObMAAAkc1MCQfAAAMAAAEc1g");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhIRCOfMAAAkc9MCQjAAAMAAAEc9g");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhITCOjMAAAkdFMCQnAAAMAAAEdFg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhIVCOnMAAAkdNMCQrAAAMAAAEdNg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhIXCOrMAAAkdVMCQvAAAMAAAEdVg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhJ9COwMAAAkdfMCQ1AAAMAAAEdfg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhQWCO1MAAAkdpMCQ6AAAMAAAEdpg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhXACO6MAAAkdzMCQ+AAAMAAAEdzg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:272.1918,y:522.6447}).wait(51).to({graphics:mask_1_graphics_51,x:271.2969,y:521.6564}).wait(1).to({graphics:mask_1_graphics_52,x:269.2067,y:521.662}).wait(1).to({graphics:mask_1_graphics_53,x:262.936,y:521.6787}).wait(1).to({graphics:mask_1_graphics_54,x:252.4848,y:521.7065}).wait(1).to({graphics:mask_1_graphics_55,x:237.8532,y:521.7454}).wait(1).to({graphics:mask_1_graphics_56,x:219.0411,y:521.7954}).wait(1).to({graphics:mask_1_graphics_57,x:196.0485,y:521.8565}).wait(1).to({graphics:mask_1_graphics_58,x:168.8755,y:521.9288}).wait(1).to({graphics:mask_1_graphics_59,x:137.5221,y:522.0122}).wait(1).to({graphics:mask_1_graphics_60,x:101.9881,y:522.1066}).wait(1).to({graphics:mask_1_graphics_61,x:62.2737,y:522.2122}).wait(1).to({graphics:mask_1_graphics_62,x:18.3788,y:522.329}).wait(1).to({graphics:mask_1_graphics_63,x:-29.6965,y:522.4568}).wait(1).to({graphics:mask_1_graphics_64,x:-81.9523,y:522.5957}).wait(1).to({graphics:mask_1_graphics_65,x:-138.3886,y:522.7458}).wait(1).to({graphics:mask_1_graphics_66,x:-199.0053,y:522.907}).wait(1).to({graphics:mask_1_graphics_67,x:-263.8025,y:523.0793}).wait(1).to({graphics:mask_1_graphics_68,x:-332.7801,y:523.2627}).wait(1).to({graphics:mask_1_graphics_69,x:-405.9383,y:523.4572}).wait(1).to({graphics:mask_1_graphics_70,x:-473.3732,y:523.6629}).wait(1).to({graphics:mask_1_graphics_71,x:-514.2555,y:523.8796}).wait(1).to({graphics:mask_1_graphics_72,x:-556.925,y:524.7172}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(195.6,516.4,4.5673,4.5673,0,0,0,0.2,0.3);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(1305.4,1659.85,3.0806,4.0484,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({scaleX:3.0746,scaleY:4.0405,x:1302.55,y:1656.65},0).to({regX:485.3,regY:406.8,scaleX:3.0932,scaleY:4.0648,x:387.25,y:1666.1},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(1305.4,1659.85,3.0806,4.0484,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({scaleX:3.0746,scaleY:4.0405,x:1302.55,y:1656.65},0).to({regX:485.3,regY:406.8,scaleX:3.0932,scaleY:4.0648,x:387.25,y:1666.1},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1113.8,-390.1,1848.1,1829.4);


(lib.bg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// snowflakes_1
	this.snowflakes_1 = new lib.snowflakes_1();
	this.snowflakes_1.name = "snowflakes_1";
	this.snowflakes_1.setTransform(299.15,67.6,1.2195,1.2195,180,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.snowflakes_1).wait(1));

	// snowflakes_2
	this.snowflakes_2 = new lib.snowflakes_2();
	this.snowflakes_2.name = "snowflakes_2";
	this.snowflakes_2.setTransform(43.5,553.4,1.3362,1.3362,180,0,0,131.8,-47.6);

	this.timeline.addTween(cjs.Tween.get(this.snowflakes_2).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F2F2").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150,300);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(-14.5,0,314.5,600), null);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.Page = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Button
	this.Btn_return = new lib.Btn_Return();
	this.Btn_return.name = "Btn_return";
	this.Btn_return.setTransform(272.9,519.9,1.4,1.4,0,0,0,14.8,14.8);

	this.timeline.addTween(cjs.Tween.get(this.Btn_return).wait(1));

	// obj2
	this.obj2 = new lib.object_2();
	this.obj2.name = "obj2";
	this.obj2.setTransform(316.6,243.1,1,1,0,0,0,316.6,243.1);

	this.timeline.addTween(cjs.Tween.get(this.obj2).wait(1));

	// obj1
	this.obj1 = new lib.object_1();
	this.obj1.name = "obj1";
	this.obj1.setTransform(127.8,234.5,1,1,0,0,0,127.8,219.5);

	this.timeline.addTween(cjs.Tween.get(this.obj1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Page, new cjs.Rectangle(33.8,-55.5,294.7,633.3), null);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-3.05,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Ap0C/IAAl9ITpAAIAAF9g");
	this.shape.setTransform(-46.825,-0.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-109.7,-19.7,125.80000000000001,38.3), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(61.7,128.1,0.33,0.33,0,0,0,0.6,0.3);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(953.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// BKbtn
	this.hit_shrink = new lib.option_hit_round();
	this.hit_shrink.name = "hit_shrink";
	this.hit_shrink.setTransform(271.65,520.55,0.7842,0.7842,0,0,0,12,15.1);
	new cjs.ButtonHelper(this.hit_shrink, 0, 1, 2, false, new lib.option_hit_round(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit_shrink).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(48.95,551.1,0.9555,0.9555,0,0,0,0.8,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(96.1,551.2,0.9013,0.9013,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(32.15,32.25,1.0595,1.0595,0,0,0,-52.2,-23.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// Screen_Enlarged
	this.Enlarged = new lib.Page();
	this.Enlarged.name = "Enlarged";
	this.Enlarged.setTransform(745,125,1,1,0,0,0,745,125);

	this.timeline.addTween(cjs.Tween.get(this.Enlarged).wait(1));

	// option_hits
	this.hit_expand = new lib.option_hit_round();
	this.hit_expand.name = "hit_expand";
	this.hit_expand.setTransform(251.15,389.65,0.882,0.882,0,0,0,14.4,14.3);
	new cjs.ButtonHelper(this.hit_expand, 0, 1, 2, false, new lib.option_hit_round(), 3);

	this.hit2 = new lib.option_hit();
	this.hit2.name = "hit2";
	this.hit2.setTransform(282.2,552.4,1.5999,1.6,0,0,0,11.6,13.8);
	new cjs.ButtonHelper(this.hit2, 0, 1, 2, false, new lib.option_hit(), 3);

	this.hit1 = new lib.option_hit();
	this.hit1.name = "hit1";
	this.hit1.setTransform(142.5,552.4,1.6,1.6,0,0,0,9.8,13.7);
	new cjs.ButtonHelper(this.hit1, 0, 1, 2, false, new lib.option_hit(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.hit1},{t:this.hit2},{t:this.hit_expand}]}).wait(1));

	// empty_hit
	this.no_hit = new lib.hit();
	this.no_hit.name = "no_hit";
	this.no_hit.setTransform(210.35,541.2,0.6292,0.1096,0,0,0,150.1,125);
	new cjs.ButtonHelper(this.no_hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.no_hit).wait(1));

	// hit
	this.hit = new lib.hit();
	this.hit.name = "hit";
	this.hit.setTransform(150,125,1,1,0,0,0,150,125);
	new cjs.ButtonHelper(this.hit, 0, 1, 2, false, new lib.hit(), 3);

	this.timeline.addTween(cjs.Tween.get(this.hit).wait(1));

	// Main_Screen
	this.main_screen = new lib.mountain_anim();
	this.main_screen.name = "main_screen";
	this.main_screen.setTransform(277.9,61.1,1,1,0,0,0,284.4,25.1);

	this.timeline.addTween(cjs.Tween.get(this.main_screen).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// Bg
	this.background = new lib.bg();
	this.background.name = "background";
	this.background.setTransform(-0.9,-1.1,1,1,0,0,0,-0.9,-1.1);

	this.timeline.addTween(cjs.Tween.get(this.background).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-14.5,-55.5,979.9,656.5), null);


// stage content:
(lib.M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var frequency = 5;
		stage.enableMouseOver(frequency);

		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"

		this.initBanner = function (data) {

			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;

			Object.keys = function (obj) {
				var keys = [];

				for (var i in obj) {
					if (obj.hasOwnProperty(i)) {
						keys.push(i);
					}
				}
				return keys
			}
			var keys = Object.keys(data)

			for (var i in keys) {
				var id = keys[i].substr(0, 4);
				if (id == "head") {
					exportRoot['' + keys[i]] = new Array()
					exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
				} else if (id == "enla") {
					exportRoot['' + keys[i]] = new Array()
					exportRoot.fillenlarged(data[keys[i]], exportRoot['' + keys[i]])
				} else if (id == "CTA" && data[keys[i]].length > 1) {
					exportRoot.fillCta(data[keys[i]])
				} else if (id == "CTAa") {
					mc.cta.arrow.visible = data[keys[i]][0]
					mc.cta.arrow.x += data[keys[i]][1]
					mc.cta.arrow.y += data[keys[i]][2]
				}
			}
		}


		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width * -1, mc.getTransformedBounds().height * -1, mc.getTransformedBounds().width * 2, mc.getTransformedBounds().height * 2, 1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillenlarged = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width * -1, mc.getTransformedBounds().height * -1, mc.getTransformedBounds().width * 2, mc.getTransformedBounds().height * 2, 1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width * -1, mc.getTransformedBounds().height * -1, mc.getTransformedBounds().width * 2, mc.getTransformedBounds().height * 2, 1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}

		var mc = exportRoot.mainMC

		var hit = mc.hit
		var hit1 = mc.hit1
		var hit2 = mc.hit2
		var no_hit = mc.no_hit

		var main_screen = mc.main_screen
		var screen_1_onedrive = mc.main_screen.screen_1_onedrive
		var screen_2_onedrive = mc.main_screen.screen_2_onedrive
		var screen_1_excel = mc.main_screen.screen_1_excel
		var screen_2_excel = mc.main_screen.screen_2_excel
		var screen_1_word = mc.main_screen.screen_1_word
		var screen_2_word = mc.main_screen.screen_2_word
		var screen_1_ppt = mc.main_screen.screen_1_ppt
		var screen_2_ppt = mc.main_screen.screen_2_ppt
		var dot_1 = mc.main_screen.indicator.dot_1
		var dot_2 = mc.main_screen.indicator.dot_2
		var dot_3 = mc.main_screen.indicator.dot_3
		var dot_4 = mc.main_screen.indicator.dot_4

		var snowflakes_1 = mc.background.snowflakes_1
		var snowflakes_2 = mc.background.snowflakes_2

		var indicator = mc.main_screen.indicator
		var btn_expand = mc.main_screen.btn_expand

		mc.cta.alpha = 0
		mc.txtCta.alpha = 0
		//hit.mouseEnabled = false;
		var menuPos = "shrunk"

			var init_onedrive_s1_x = screen_1_onedrive.x;
			var init_onedrive_s1_y = screen_1_onedrive.y;
			var init_onedrive_s2_x = screen_2_onedrive.x;
			var init_onedrive_s2_y = screen_2_onedrive.y;

			var status_button = "on";
			var ClickID = 0

			exportRoot.trigger_button = function() {
				//// console.log("status button "+status_button + " id "+ClickID)
				if (status_button == "on"){
					hit1.mouseEnabled = false;
					hit2.mouseEnabled = false;
					status_button = "off";
				} else {
					hit1.mouseEnabled = true;
					hit2.mouseEnabled = true;
					status_button = "on";
				}
			}


		this.runBanner = function () {

			mc.replay_btn.visible = false
			mc.cta.alpha = 1
			mc.txtCta.alpha = 1

				//INTRO ANIMATION

				this.TL_MainIntro = new TimelineMax();

				exportRoot.TL_MainIntro.from(screen_1_onedrive, 1.1, {x: "+=240",y: "+=360", ease:Power2.easeOut});
				exportRoot.TL_MainIntro.from(screen_2_onedrive, 1, {x: "+=240",y: "+=360", ease:Power3.easeOut}, "-=0.85");
				exportRoot.TL_MainIntro.from(indicator, 0.6, {alpha:0, ease:Power3.easeOut, onStart:function(){dot_1.gotoAndPlay("selected", exportRoot.TL_MainText.tweenTo("Out"));}}, "-=0.4");

				exportRoot.TL_MainIntro.from(mc.cta, 0.6, {x: "-=200", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_MainIntro.from(mc.txtCta, 0.6, {x: "-=200", ease:Power3.easeOut}, "-=0.6");
				exportRoot.TL_MainIntro.from(mc.hit1, 0.1, {y: "+=100"}, "-=0");
				exportRoot.TL_MainIntro.from(mc.hit2, 0.1, {y: "+=100"}, "-=0");

				exportRoot.TL_MainIntro.from(btn_expand, 0.6, {scaleX: 0, scaleY: 0, ease:Power3.easeOut}, "-=0.4");

				exportRoot.TL_MainIntro.stop();

				//CAROUSEL ANIMATION

				this.TL_MainScreen = new TimelineMax();
				exportRoot.TL_MainScreen.add('frame0');

				exportRoot.TL_MainScreen.to(mc, 0, {onStart:function(){exportRoot.trigger_button()}}, "=+0.01");

				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 0, scaleY: 0, ease:Power3.easeIn});

				exportRoot.TL_MainScreen.to(screen_1_onedrive, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power1.easeIn}, "=-0.4");
				exportRoot.TL_MainScreen.to(screen_2_onedrive, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power2.easeIn}, "-=.55");

				exportRoot.TL_MainScreen.from(screen_1_excel, 1.1, {x: "+=240", y: "+=360", ease:Power2.easeOut}, "-=0.6");
				exportRoot.TL_MainScreen.from(screen_2_excel, 1, {x: "+=240", y: "+=360", ease:Power3.easeOut}, "-=0.85");
				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 1, scaleY: 1, ease:Power3.easeOut}, "-=0.6");

				exportRoot.TL_MainScreen.to(mc, 0, {onStart:function(){exportRoot.trigger_button()}});

				exportRoot.TL_MainScreen.add('frame1');

				exportRoot.TL_MainScreen.to(mc, 0, {onComplete:function(){exportRoot.trigger_button()}}, "=+0.01");
				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 0, scaleY: 0, ease:Power3.easeIn});

				exportRoot.TL_MainScreen.to(screen_1_excel, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power1.easeIn}, "=-0.4");
				exportRoot.TL_MainScreen.to(screen_2_excel, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power2.easeIn}, "-=.55");

				exportRoot.TL_MainScreen.from(screen_1_word, 1.1, {x: "+=240", y: "+=360", ease:Power2.easeOut}, "-=0.6");
				exportRoot.TL_MainScreen.from(screen_2_word, 1, {x: "+=240", y: "+=360", ease:Power3.easeOut}, "-=0.85");
				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 1, scaleY: 1, ease:Power3.easeOut}, "-=0.6");

				exportRoot.TL_MainScreen.to(mc, 0, {onStart:function(){exportRoot.trigger_button()}});

				exportRoot.TL_MainScreen.add('frame2');

				exportRoot.TL_MainScreen.to(mc, 0, {onComplete:function(){exportRoot.trigger_button()}}, "=+0.01");

				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 0,scaleY: 0, ease:Power3.easeIn});

				exportRoot.TL_MainScreen.to(screen_1_word, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power1.easeIn}, "=-0.4");
				exportRoot.TL_MainScreen.to(screen_2_word, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power2.easeIn}, "-=.55");

				exportRoot.TL_MainScreen.from(screen_1_ppt, 1.1, {x: "+=240", y: "+=360", ease:Power2.easeOut}, "-=0.6");
				exportRoot.TL_MainScreen.from(screen_2_ppt, 1, {x: "+=240", y: "+=360", ease:Power3.easeOut}, "-=0.85");
				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 1, scaleY: 1, ease:Power3.easeOut}, "-=0.6");

				exportRoot.TL_MainScreen.to(mc, 0, {onStart:function(){exportRoot.trigger_button()}});

				exportRoot.TL_MainScreen.add('frame3');

				exportRoot.TL_MainScreen.to(mc, 0, {onComplete:function(){exportRoot.trigger_button()}}, "=+0.01");

				exportRoot.TL_MainScreen.to(screen_1_onedrive, 0.01, {x:init_onedrive_s1_x+240, y:init_onedrive_s1_y+360, alpha:1, ease:Power2.easeOut});
				exportRoot.TL_MainScreen.to(screen_2_onedrive, 0.01, {x:init_onedrive_s2_x+240, y:init_onedrive_s2_y+360, alpha:1, ease:Power3.easeOut}, "-=0.01");

				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 0,scaleY: 0, ease:Power3.easeIn}, "-=0.01");

				exportRoot.TL_MainScreen.to(screen_1_ppt, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power1.easeIn}, "=-0.4");
				exportRoot.TL_MainScreen.to(screen_2_ppt, .6, {x: "-=120", y: "-=180", alpha:0, ease:Power2.easeIn}, "-=.55");

				exportRoot.TL_MainScreen.to(screen_1_onedrive, 1.1, {x:init_onedrive_s1_x, y:init_onedrive_s1_y, alpha:1, ease:Power2.easeOut}, "-=0.6");
				exportRoot.TL_MainScreen.to(screen_2_onedrive, 1, {x:init_onedrive_s2_x, y:init_onedrive_s2_y, alpha:1, ease:Power3.easeOut}, "-=0.85");
				exportRoot.TL_MainScreen.to(btn_expand, 0.6, {scaleX: 1, scaleY: 1, ease:Power3.easeOut}, "-=0.6");

				exportRoot.TL_MainScreen.to(mc, 0, {onStart:function(){exportRoot.trigger_button()}});

				exportRoot.TL_MainScreen.add('frame4');

				exportRoot.TL_MainScreen.stop();

				//EXPAND ANIMATION

				exportRoot.TL_MainExpand = new TimelineMax();

				exportRoot.TL_MainExpand.add('menu');

				exportRoot.TL_MainExpand.to(hit1, 0.1, {scaleX: 0,scaleY: 0, ease:Power3.easeIn}, "-=0");
				exportRoot.TL_MainExpand.to(no_hit, 0.1, {x: "+=200", ease:Power3.easeIn}, "-=0.1");
				exportRoot.TL_MainExpand.to(hit2, 0.1, {scaleX: 0,scaleY: 0, ease:Power3.easeIn}, "-=0.1");
				exportRoot.TL_MainExpand.to(mc.hit_expand, 0.1, {scaleX: 0,scaleY: 0, ease:Power3.easeIn}, "-=0.1");

				exportRoot.TL_MainExpand.to(btn_expand, 0.6, {scaleX: 0,scaleY: 0, ease:Power3.easeIn}, "-=0.1");

				exportRoot.TL_MainExpand.to(main_screen, .6, {x: "-=120",y: "-=180", alpha:0, ease:Power2.easeIn});
				exportRoot.TL_MainExpand.to(indicator, .4, {alpha:0, ease:Power2.easeIn}, "-=.8");

				exportRoot.TL_MainExpand.to(snowflakes_1, .8, {alpha:0, y: "+=50", ease:Power2.easeIn}, "-=.4");
				exportRoot.TL_MainExpand.to(snowflakes_2, .8, {alpha:1, y: "-=50", ease:Power2.easeOut}, "-=.4");


				exportRoot.TL_MainExpand.from(mc.Enlarged.obj2, 1, {x: "+=100",y: "+=480", ease:Power2.easeOut}, "-=0.4");
				exportRoot.TL_MainExpand.from(mc.Enlarged.obj1, 1, {x: "+=150",y: "-=50", ease:Power3.easeOut}, "-=0.8");
				exportRoot.TL_MainExpand.from(snowflakes_2, .8, {alpha:0, y: "-=50", ease:Power2.easeOut}, "-=1");

				exportRoot.TL_MainExpand.from(mc.Enlarged.Btn_return, .6, {scaleX: 0,scaleY: 0, ease:Power3.easeOut}, "-=0.8");
				exportRoot.TL_MainExpand.from(mc.hit_shrink, .6, {scaleX: 0,scaleY: 0, ease:Power3.easeOut}, "-=0.6");

				exportRoot.TL_MainExpand.add('expanded');

				exportRoot.TL_MainExpand.stop();

				mc.logo_intro.gotoAndPlay(1)

				//TEXT ANIMATION

				exportRoot.TL_MainText = new TimelineMax();
				exportRoot.TL_MainText.add('In');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainText.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=0");
					if (i!=0) exportRoot.TL_MainText.from(exportRoot.headline1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.TL_MainText.from(exportRoot.headline2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.2");
					if (i!=0) exportRoot.TL_MainText.from(exportRoot.headline2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				exportRoot.TL_MainText.add('Out');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainText.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "+=0");
					if (i!=0) exportRoot.TL_MainText.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.TL_MainText.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}

				exportRoot.TL_MainText.add('End');

				exportRoot.TL_MainText.stop();

				exportRoot.TL_MainText1 = new TimelineMax();

				exportRoot.TL_MainText1.add('In');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainText1.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "+=0.5");
					if (i!=0) exportRoot.TL_MainText1.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.TL_MainText1.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText1.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_1_1.length; i++) {
					if (i==0) exportRoot.TL_MainText1.from(exportRoot.enlarged_1_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=0.2");
					if (i!=0) exportRoot.TL_MainText1.from(exportRoot.enlarged_1_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				for (var i = 0; i < exportRoot.enlarged_1_2.length; i++) {
					if (i==0) exportRoot.TL_MainText1.from(exportRoot.enlarged_1_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.4");
					if (i!=0) exportRoot.TL_MainText1.from(exportRoot.enlarged_1_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				exportRoot.TL_MainText1.add('Out');

				for (var i = 0; i < exportRoot.enlarged_1_1.length; i++) {
					if (i==0) exportRoot.TL_MainText1.to(exportRoot.enlarged_1_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainText1.to(exportRoot.enlarged_1_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_1_2.length; i++) {
					if (i==0) exportRoot.TL_MainText1.to(exportRoot.enlarged_1_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText1.to(exportRoot.enlarged_1_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}

				if (i!=0) exportRoot.TL_MainText1.to(mc, 0.1, {onComplete:function(){exportRoot.TL_MainText.tweenFromTo("In", "Out");}}, "-=0");

				exportRoot.TL_MainText1.add('End');

				exportRoot.TL_MainText1.stop();

				exportRoot.TL_MainText2 = new TimelineMax();

				exportRoot.TL_MainText2.add('In');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainText2.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "+=0.5");
					if (i!=0) exportRoot.TL_MainText2.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.TL_MainText2.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText2.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_2_1.length; i++) {
					if (i==0) exportRoot.TL_MainText2.from(exportRoot.enlarged_2_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=0.2");
					if (i!=0) exportRoot.TL_MainText2.from(exportRoot.enlarged_2_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				for (var i = 0; i < exportRoot.enlarged_2_2.length; i++) {
					if (i==0) exportRoot.TL_MainText2.from(exportRoot.enlarged_2_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.4");
					if (i!=0) exportRoot.TL_MainText2.from(exportRoot.enlarged_2_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				exportRoot.TL_MainText2.add('Out');

				for (var i = 0; i < exportRoot.enlarged_2_1.length; i++) {
					if (i==0) exportRoot.TL_MainText2.to(exportRoot.enlarged_2_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainText2.to(exportRoot.enlarged_2_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_2_2.length; i++) {
					if (i==0) exportRoot.TL_MainText2.to(exportRoot.enlarged_2_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText2.to(exportRoot.enlarged_2_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}
						if (i!=0) exportRoot.TL_MainText2.to(mc, 0.1, {onComplete:function(){exportRoot.TL_MainText.tweenFromTo("In", "Out");}}, "-=0");

				exportRoot.TL_MainText2.add('End');

				exportRoot.TL_MainText2.stop();

				exportRoot.TL_MainText3 = new TimelineMax();

				exportRoot.TL_MainText3.add('In');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainText3.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "+=0.5");
					if (i!=0) exportRoot.TL_MainText3.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.TL_MainText3.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText3.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_3_1.length; i++) {
					if (i==0) exportRoot.TL_MainText3.from(exportRoot.enlarged_3_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=0.2");
					if (i!=0) exportRoot.TL_MainText3.from(exportRoot.enlarged_3_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				for (var i = 0; i < exportRoot.enlarged_3_2.length; i++) {
					if (i==0) exportRoot.TL_MainText3.from(exportRoot.enlarged_3_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.4");
					if (i!=0) exportRoot.TL_MainText3.from(exportRoot.enlarged_3_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				exportRoot.TL_MainText3.add('Out');

				for (var i = 0; i < exportRoot.enlarged_3_1.length; i++) {
					if (i==0) exportRoot.TL_MainText3.to(exportRoot.enlarged_3_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainText3.to(exportRoot.enlarged_3_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_3_2.length; i++) {
					if (i==0) exportRoot.TL_MainText3.to(exportRoot.enlarged_3_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText3.to(exportRoot.enlarged_3_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}
				if (i!=0) exportRoot.TL_MainText3.to(mc, 0.1, {onComplete:function(){exportRoot.TL_MainText.tweenFromTo("In", "Out");}}, "-=0");

				exportRoot.TL_MainText3.add('End');

				exportRoot.TL_MainText3.stop();

				exportRoot.TL_MainText4 = new TimelineMax();

				exportRoot.TL_MainText4.add('In');

				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.TL_MainText4.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "+=0.5");
					if (i!=0) exportRoot.TL_MainText4.to(exportRoot.headline1[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.TL_MainText4.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText4.to(exportRoot.headline2[i], 0.3, { alpha: 0, ease:Power3.easeIn}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_4_1.length; i++) {
					if (i==0) exportRoot.TL_MainText4.from(exportRoot.enlarged_4_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "+=0.2");
					if (i!=0) exportRoot.TL_MainText4.from(exportRoot.enlarged_4_1[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				for (var i = 0; i < exportRoot.enlarged_4_2.length; i++) {
					if (i==0) exportRoot.TL_MainText4.from(exportRoot.enlarged_4_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.4");
					if (i!=0) exportRoot.TL_MainText4.from(exportRoot.enlarged_4_2[i], 0.6, { x: "+=100", alpha: 0, ease:Power3.easeOut}, "-=0.5");
				}

				exportRoot.TL_MainText4.add('Out');

				for (var i = 0; i < exportRoot.enlarged_4_1.length; i++) {
					if (i==0) exportRoot.TL_MainText4.to(exportRoot.enlarged_4_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "+=.5");
					if (i!=0) exportRoot.TL_MainText4.to(exportRoot.enlarged_4_1[i], 0.3, {  alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}

				for (var i = 0; i < exportRoot.enlarged_4_2.length; i++) {
					if (i==0) exportRoot.TL_MainText4.to(exportRoot.enlarged_4_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
					if (i!=0) exportRoot.TL_MainText4.to(exportRoot.enlarged_4_2[i], 0.3, { alpha: 0, ease:Power3.easeOut}, "-=0.3");
				}
						if (i!=0) exportRoot.TL_MainText4.to(mc, 0.1, {onComplete:function(){exportRoot.TL_MainText.tweenFromTo("In", "Out");}}, "-=0");

				exportRoot.TL_MainText4.add('End');

				exportRoot.TL_MainText4.stop();


			//
			//   CONTROL
			//

			exportRoot.subMenuClick = function (id) {


				// Check ID is within RANGE
				if (ClickID < 0) {
					ClickID = 3;
				}
				if (ClickID > 3) {
					ClickID = 0;
				}
				id = ClickID;
				exportRoot.selectedOption(id)
			}

			exportRoot.subMenuExpand = function (subID) {
				exportRoot.selectedExpand(subID)
			}

			exportRoot.subMenuShrink = function (subID) {
				exportRoot.selectedShrink(subID)
			}

			exportRoot.setMenu1 = function () {
				ClickID--;
				amoAdInteraction('Previous Click', ClickID);
				direction = "prev";
				exportRoot.subMenuClick(ClickID, direction);
			}
			exportRoot.setMenu2 = function () {
				ClickID++;
				amoAdInteraction('Next Click', ClickID);
				direction = "next";
				exportRoot.subMenuClick(ClickID, direction);
			}

			exportRoot.expandMenu = function (subID) {
				amoAdInteraction('Expand Click', ClickID);
				exportRoot.subMenuExpand(subID);
				menuPos = "expanded"
			}
			exportRoot.shrinkMenu = function (subID) {
				amoAdInteraction('Back Click', ClickID);
				exportRoot.subMenuShrink(subID);
				menuPos = "shrunk"
			}

			exportRoot.mainMC.hit1.addEventListener("click", exportRoot.setMenu1)
			exportRoot.mainMC.hit2.addEventListener("click", exportRoot.setMenu2)
			exportRoot.mainMC.hit_expand.addEventListener("click", exportRoot.expandMenu)
			exportRoot.mainMC.hit_shrink.addEventListener("click", exportRoot.shrinkMenu)

			exportRoot.selectedOption = function (subID) {

				if (direction=="next") {
					if (subID==0) {exportRoot.TL_MainScreen.tweenFromTo("frame3", "frame4"),dot_4.gotoAndPlay("deselected"),dot_1.gotoAndPlay("selected");}
					if (subID==1) {exportRoot.TL_MainScreen.tweenFromTo("frame0", "frame1"),dot_1.gotoAndPlay("deselected"),dot_2.gotoAndPlay("selected");}
					if (subID==2) {exportRoot.TL_MainScreen.tweenFromTo("frame1", "frame2"),dot_2.gotoAndPlay("deselected"),dot_3.gotoAndPlay("selected");}
					if (subID==3) {exportRoot.TL_MainScreen.tweenFromTo("frame2", "frame3"),dot_3.gotoAndPlay("deselected"),dot_4.gotoAndPlay("selected");}
				} else {
					if (subID==0) {exportRoot.TL_MainScreen.tweenFromTo("frame1", "frame0"),dot_2.gotoAndPlay("deselected"),dot_1.gotoAndPlay("selected");}
					if (subID==1) {exportRoot.TL_MainScreen.tweenFromTo("frame2", "frame1"),dot_3.gotoAndPlay("deselected"),dot_2.gotoAndPlay("selected");}
					if (subID==2) {exportRoot.TL_MainScreen.tweenFromTo("frame3", "frame2"),dot_4.gotoAndPlay("deselected"),dot_3.gotoAndPlay("selected");}
					if (subID==3) {exportRoot.TL_MainScreen.tweenFromTo("frame4", "frame3"),dot_1.gotoAndPlay("deselected"),dot_4.gotoAndPlay("selected");}
				}
				exportRoot.selectedScreenIn(subID)
			}

			exportRoot.selectedExpand = function (subID) {
				exportRoot.TL_MainExpand.timeScale(1.2)
				exportRoot.TL_MainExpand.tweenFromTo("menu", "expanded");
				if (ClickID==0) {exportRoot.TL_MainText1.tweenFromTo("In", "Out");}
				if (ClickID==1) {exportRoot.TL_MainText2.tweenFromTo("In", "Out");}
				if (ClickID==2) {exportRoot.TL_MainText3.tweenFromTo("In", "Out");}
				if (ClickID==3) {exportRoot.TL_MainText4.tweenFromTo("In", "Out");}
			}

			exportRoot.selectedShrink = function (subID) {
				exportRoot.TL_MainExpand.timeScale(1.5)
				exportRoot.TL_MainExpand.tweenFromTo("expanded", "menu");
				if (ClickID==0) {exportRoot.TL_MainText1.tweenFromTo("Out", "End");}
				if (ClickID==1) {exportRoot.TL_MainText2.tweenFromTo("Out", "End");}
				if (ClickID==2) {exportRoot.TL_MainText3.tweenFromTo("Out", "End");}
				if (ClickID==3) {exportRoot.TL_MainText4.tweenFromTo("Out", "End");}
			}

			exportRoot.selectedScreenIn = function (subID) {
				mc.Enlarged.obj2.gotoAndStop(subID)
				mc.Enlarged.obj1.gotoAndStop(subID)
			}

			exportRoot.mainMC.hit.addEventListener("mouseover", mainOver.bind(this));
			exportRoot.mainMC.hit.addEventListener("mouseout", mainOut.bind(this));

			/*exportRoot.mainMC.hit.addEventListener("click", function(event) {
				if (ClickID==0) window.open(clickTag1);
				if (ClickID==1) window.open(clickTag2);
				if (ClickID==2) window.open(clickTag3);
				if (ClickID==3) window.open(clickTag4);
			})~*/
			function mainOver() {
				exportRoot.mainMC.cta.arrow.gotoAndStop(1);
			}
			function mainOut() {
				exportRoot.mainMC.cta.arrow.gotoAndStop(0);
			}

			var swipe = new Swipe(exportRoot.mainMC.hit, 50, 100); // distance 50 pixels, duration 100 ms


			// 4. add an event to capture swipe
			swipe.on("swipe", function() {
				var dir = swipe.direction;
				if (dir == "none") {
					// if (ClickID==0) window.open(clickTag1);
					// if (ClickID==1) window.open(clickTag2);
					// if (ClickID==2) window.open(clickTag3);
					// if (ClickID==3) window.open(clickTag4);
					amoAdClick(ClickID);
				} else if (dir == "left") {
					if (status_button=="on" && menuPos == "shrunk") exportRoot.setMenu2()
				} else {
					if (status_button=="on" && menuPos == "shrunk") exportRoot.setMenu1()
				}
				// console.log(swipe.direction)
			});

		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(135.5,244.5,829.9,356.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1.png?1603189098480", id:"M365_FY21Q2Holiday_USA_300x600_BAN_INTCarousel_EN_NA_Standard_ANI_BN_NA_1_atlas_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
	var lastW, lastH, lastS=1;
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas();
	function resizeCanvas() {
		var w = lib.properties.width, h = lib.properties.height;
		var iw = window.innerWidth, ih=window.innerHeight;
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
		if(isResp) {
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
				sRatio = lastS;
			}
			else if(!isScale) {
				if(iw<w || ih<h)
					sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==1) {
				sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==2) {
				sRatio = Math.max(xRatio, yRatio);
			}
		}
		domContainers[0].width = w * pRatio * sRatio;
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {
			container.style.width = w * sRatio + 'px';
			container.style.height = h * sRatio + 'px';
		});
		stage.scaleX = pRatio*sRatio;
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;
		stage.tickOnUpdate = false;
		stage.update();
		stage.tickOnUpdate = true;
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
