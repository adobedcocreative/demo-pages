(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"G2_Black_BG_300x600_atlas_", frames: [[0,0,150,160],[152,0,150,160],[304,0,150,160],[456,0,150,160],[608,0,150,160],[760,0,150,160],[0,162,150,160],[152,162,150,160],[304,162,150,160],[456,162,150,160],[608,162,150,160],[760,162,150,160],[0,324,150,160],[152,324,150,160],[304,324,150,160],[456,324,150,160],[608,324,150,160],[760,324,150,160],[0,486,150,160],[152,486,150,160],[304,486,150,160],[456,486,150,160],[608,486,150,160],[760,486,150,160],[0,648,150,160],[152,648,150,160],[304,648,150,160],[456,648,150,160],[608,648,150,160],[760,648,150,160],[0,810,150,160],[152,810,150,160],[304,810,150,160],[456,810,150,160],[608,810,150,160],[760,810,150,160],[0,972,150,160],[152,972,150,160],[304,972,150,160],[456,972,150,160],[608,972,150,160],[912,0,90,120],[912,122,90,120],[912,244,90,120],[912,366,90,120],[912,488,90,120],[912,610,90,120],[912,732,90,120],[912,854,90,120],[760,972,90,120],[852,976,90,120],[760,1094,90,120],[852,1098,90,120],[0,1134,90,120],[92,1134,90,120],[184,1134,90,120],[276,1134,90,120],[368,1134,90,120],[460,1134,90,120],[552,1134,90,120],[644,1134,90,120],[736,1216,90,120],[828,1220,90,120],[920,1220,90,120],[0,1256,90,120],[92,1256,90,120],[184,1256,90,120],[276,1256,90,120],[368,1256,90,120],[460,1256,90,120],[552,1256,90,120],[644,1256,90,120],[736,1338,90,120],[828,1342,90,120],[920,1342,90,120],[0,1378,90,120],[92,1378,90,120],[184,1378,90,120],[276,1378,90,120],[368,1378,90,120],[460,1378,90,120]]}
];


// symbols:



(lib.Cube_1_00200 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00201 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00202 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00203 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00204 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00205 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00206 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00207 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00208 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00209 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00210 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00211 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00212 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00213 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00214 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00215 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00216 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00217 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00218 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00219 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00220 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00221 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00222 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00223 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00224 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00225 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00226 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00227 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00228 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00229 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00230 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00231 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00232 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00233 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00234 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(34);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00235 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(35);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00236 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(36);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00237 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(37);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00238 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(38);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00239 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(39);
}).prototype = p = new cjs.Sprite();



(lib.Cube_1_00240 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(40);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00078 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(41);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00079 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(42);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00080 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(43);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00081 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(44);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00082 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(45);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00083 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(46);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00084 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(47);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00085 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(48);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00086 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(49);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00087 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(50);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00088 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(51);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00089 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(52);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00090 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(53);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00091 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(54);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00092 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(55);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00093 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(56);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00094 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(57);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00095 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(58);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00096 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(59);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00097 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(60);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00098 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(61);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00099 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(62);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00100 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(63);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00101 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(64);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00102 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(65);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00103 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(66);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00104 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(67);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00105 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(68);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00106 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(69);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00107 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(70);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00108 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(71);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00109 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(72);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00110 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(73);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00111 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(74);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00112 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(75);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00113 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(76);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00114 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(77);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00115 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(78);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00116 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(79);
}).prototype = p = new cjs.Sprite();



(lib.Design_G_300x600Option2_00117 = function() {
	this.initialize(ss["G2_Black_BG_300x600_atlas_"]);
	this.gotoAndStop(80);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.2,-2.2,93.60000000000001,84.2);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MS-Azure_Logo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFB900").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-31.7664,-3.5164,0.2684,0.2684);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00A4EF").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-41.9108,-3.5164,0.2684,0.2684);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7FBA00").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-31.7664,-13.6608,0.2684,0.2684);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-41.9108,-13.6608,0.2684,0.2684);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhsAAIAAD5IhKAAIAAj5Ig0AAIAAg7IA0AAIAAgrQAAgyAggeQAfggAyAAQANAAALACIASAEIAAA/IgNgFQgJgDgMAAQgXAAgMAOQgMAOAAAcIAAAmIBsAAIAAhGIBJgWIAABcIBKAAIAAA7IhKAAIAACQQAAAdALALQAKAMAWAAQAHAAAJgDQAHgCAIgFIAAA8QgHAEgQADQgPAEgRAAQguAAgXgZgAIsDBQgrgpAAhKQAAhNAsgsQArgtBNAAQBJAAApAsQAoArAABIQAABLgrAtQgrAthLAAQhIAAgqgrgAJjAAQgWAaAAAyQAAAxAWAZQAWAZApAAQAoAAAVgZQAUgaAAgyQAAgzgVgYQgVgZgoAAQgnAAgXAagAE7DnQgXgEgRgIIAAhHQAUANAXAJQAZAIARAAQAYAAAMgHQAMgHAAgQQAAgPgMgLQgOgLghgNQgpgRgQgVQgRgUAAghQAAgpAigbQAhgbA1AAQARAAATADQAVAEANAGIAABFQgQgKgSgHQgUgHgSAAQgVAAgLAJQgMAIAAANQAAAQAKAIQAKAJAiAOQAsASARAVQASAVAAAgQAAAsgiAaQgiAbg5AAQgTAAgXgFgAgiDBQgrgqAAhJQAAhNAsgsQAqgtBNAAQBJAAApAsQApArAABIQAABLgsAtQgrAthLAAQhIAAgpgrgAAVAAQgWAaAAAyQAAAwAVAaQAXAZAoAAQApAAAUgZQAVgaAAgyQAAgygWgZQgVgZgnAAQgoAAgWAagAoDDBQgrgsAAhDQAAhLAsgvQAsgwBQAAQATAAAWAFQAVAFANAHIAABGQgPgLgUgIQgRgHgTAAQgqAAgcAbQgaAcAAAwQAAAvAZAaQAaAaAsAAQAQAAATgHQAUgIARgMIAABEQgTAKgVAFQgVAFgcAAQhEAAgrgrgAkFDkIAAk0IBJAAIAAAwIABAAQALgZAUgOQAUgPAcAAQAJAAAHACIAMADIAABJQgHgEgKgDQgKgEgRAAQgaAAgTAVQgTAWAAAwIAACcgAqpDkIAAk0IBIAAIAAE0gAs7DkIAAlRIgBAAIiGFRIgyAAIiJlRIgBAAIAAFRIhFAAIAAmvIBrAAIB8FAIACAAICDlAIBnAAIAAGvgAqkiMQgNgMAAgSQAAgSANgMQANgMASAAQAUAAAMAMQANAMAAASQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(11.4466,-8.9046,0.2687,0.2687);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhmB4QgngpAAhMQAAhHAqguQAqgvA/AAQBBAAAjAoQAkAnAABFIAAAiIjTAAQAFAvAZATQAZASAnAAQAbAAAXgIQAYgIASgNIAAA8QgTAMgdAHQgeAHggAAQhFAAgogqgAgohWQgUASgHAlICJAAQABgjgSgUQgQgTgfAAQgYAAgWATg");
	this.shape_5.setTransform(85.3095,-6.9269,0.2685,0.2685);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhZCdIAAk0IBJAAIAAAwIABAAQAKgZATgOQAVgPAcABQAJAAAGABIAMADIAABKQgFgEgMgEQgKgEgQAAQgbAAgTAXQgRAWAAAuIAACcg");
	this.shape_6.setTransform(78.9532,-7.0142,0.2685,0.2685);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhuB+QgcgdAAhCIAAi7IBKAAIAACzQAAAmAPAVQAQATAfAAQAeAAATgWQASgWAAgjIAAiyIBKAAIAAE1IhKAAIAAgpIgBAAQgOAVgYAMQgYAMgeAAQg2AAgcgfg");
	this.shape_7.setTransform(71.013,-6.8867,0.2685,0.2685);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AiBCbIAAgjICfjYIiTAAIAAg6ID2AAIAAAdIihDeICiAAIAAA6g");
	this.shape_8.setTransform(62.9117,-6.9403,0.2685,0.2685);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AB6DYIgmhrIipAAIglBrIhSAAICjmvIBTAAICjGvgAhBAuICAAAIg/i1IgBAAg");
	this.shape_9.setTransform(53.233,-8.5848,0.2685,0.2685);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-46.5,-18.2,135.6,19.3), null);


(lib.cube_Animation_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(70));

	// Layer_3
	this.instance = new lib.Cube_1_00239();
	this.instance.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_1 = new lib.Cube_1_00238();
	this.instance_1.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_2 = new lib.Cube_1_00236();
	this.instance_2.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_3 = new lib.Cube_1_00235();
	this.instance_3.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_4 = new lib.Cube_1_00233();
	this.instance_4.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_5 = new lib.Cube_1_00232();
	this.instance_5.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_6 = new lib.Cube_1_00230();
	this.instance_6.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_7 = new lib.Cube_1_00229();
	this.instance_7.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_8 = new lib.Cube_1_00227();
	this.instance_8.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_9 = new lib.Cube_1_00226();
	this.instance_9.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_10 = new lib.Cube_1_00224();
	this.instance_10.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_11 = new lib.Cube_1_00223();
	this.instance_11.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_12 = new lib.Cube_1_00221();
	this.instance_12.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_13 = new lib.Cube_1_00220();
	this.instance_13.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_14 = new lib.Cube_1_00218();
	this.instance_14.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_15 = new lib.Cube_1_00217();
	this.instance_15.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_16 = new lib.Cube_1_00215();
	this.instance_16.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_17 = new lib.Cube_1_00214();
	this.instance_17.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_18 = new lib.Cube_1_00212();
	this.instance_18.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_19 = new lib.Cube_1_00211();
	this.instance_19.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_20 = new lib.Cube_1_00209();
	this.instance_20.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_21 = new lib.Cube_1_00208();
	this.instance_21.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_22 = new lib.Cube_1_00207();
	this.instance_22.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_23 = new lib.Cube_1_00206();
	this.instance_23.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_24 = new lib.Cube_1_00205();
	this.instance_24.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_25 = new lib.Cube_1_00204();
	this.instance_25.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_26 = new lib.Cube_1_00203();
	this.instance_26.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_27 = new lib.Cube_1_00202();
	this.instance_27.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_28 = new lib.Cube_1_00201();
	this.instance_28.setTransform(-8.25,-6.2,0.51,0.51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},41).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).wait(1));

	// Layer_2
	this.instance_29 = new lib.Cube_1_00200();
	this.instance_29.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_30 = new lib.Cube_1_00201();
	this.instance_30.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_31 = new lib.Cube_1_00202();
	this.instance_31.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_32 = new lib.Cube_1_00203();
	this.instance_32.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_33 = new lib.Cube_1_00204();
	this.instance_33.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_34 = new lib.Cube_1_00205();
	this.instance_34.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_35 = new lib.Cube_1_00206();
	this.instance_35.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_36 = new lib.Cube_1_00207();
	this.instance_36.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_37 = new lib.Cube_1_00208();
	this.instance_37.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_38 = new lib.Cube_1_00209();
	this.instance_38.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_39 = new lib.Cube_1_00210();
	this.instance_39.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_40 = new lib.Cube_1_00211();
	this.instance_40.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_41 = new lib.Cube_1_00212();
	this.instance_41.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_42 = new lib.Cube_1_00213();
	this.instance_42.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_43 = new lib.Cube_1_00214();
	this.instance_43.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_44 = new lib.Cube_1_00215();
	this.instance_44.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_45 = new lib.Cube_1_00216();
	this.instance_45.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_46 = new lib.Cube_1_00217();
	this.instance_46.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_47 = new lib.Cube_1_00218();
	this.instance_47.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_48 = new lib.Cube_1_00219();
	this.instance_48.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_49 = new lib.Cube_1_00220();
	this.instance_49.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_50 = new lib.Cube_1_00221();
	this.instance_50.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_51 = new lib.Cube_1_00222();
	this.instance_51.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_52 = new lib.Cube_1_00223();
	this.instance_52.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_53 = new lib.Cube_1_00224();
	this.instance_53.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_54 = new lib.Cube_1_00225();
	this.instance_54.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_55 = new lib.Cube_1_00226();
	this.instance_55.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_56 = new lib.Cube_1_00227();
	this.instance_56.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_57 = new lib.Cube_1_00228();
	this.instance_57.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_58 = new lib.Cube_1_00229();
	this.instance_58.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_59 = new lib.Cube_1_00230();
	this.instance_59.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_60 = new lib.Cube_1_00231();
	this.instance_60.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_61 = new lib.Cube_1_00232();
	this.instance_61.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_62 = new lib.Cube_1_00233();
	this.instance_62.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_63 = new lib.Cube_1_00234();
	this.instance_63.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_64 = new lib.Cube_1_00235();
	this.instance_64.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_65 = new lib.Cube_1_00236();
	this.instance_65.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_66 = new lib.Cube_1_00237();
	this.instance_66.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_67 = new lib.Cube_1_00238();
	this.instance_67.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_68 = new lib.Cube_1_00239();
	this.instance_68.setTransform(-8.25,-6.2,0.51,0.51);

	this.instance_69 = new lib.Cube_1_00240();
	this.instance_69.setTransform(-8.25,-6.2,0.51,0.51);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_29}]}).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).to({state:[{t:this.instance_50}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_57}]},1).to({state:[{t:this.instance_58}]},1).to({state:[{t:this.instance_59}]},1).to({state:[{t:this.instance_60}]},1).to({state:[{t:this.instance_61}]},1).to({state:[{t:this.instance_62}]},1).to({state:[{t:this.instance_63}]},1).to({state:[{t:this.instance_64}]},1).to({state:[{t:this.instance_65}]},1).to({state:[{t:this.instance_66}]},1).to({state:[{t:this.instance_67}]},1).to({state:[{t:this.instance_68}]},1).to({state:[{t:this.instance_69}]},1).to({state:[]},1).wait(29));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.3,-6.2,77.6,82.5);


(lib.cube_Animation_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_69 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(1));

	// Layer_3
	this.instance = new lib.Design_G_300x600Option2_00117();
	this.instance.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_1 = new lib.Design_G_300x600Option2_00116();
	this.instance_1.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_2 = new lib.Design_G_300x600Option2_00115();
	this.instance_2.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_3 = new lib.Design_G_300x600Option2_00114();
	this.instance_3.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_4 = new lib.Design_G_300x600Option2_00113();
	this.instance_4.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_5 = new lib.Design_G_300x600Option2_00112();
	this.instance_5.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_6 = new lib.Design_G_300x600Option2_00111();
	this.instance_6.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_7 = new lib.Design_G_300x600Option2_00110();
	this.instance_7.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_8 = new lib.Design_G_300x600Option2_00108();
	this.instance_8.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_9 = new lib.Design_G_300x600Option2_00107();
	this.instance_9.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_10 = new lib.Design_G_300x600Option2_00105();
	this.instance_10.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_11 = new lib.Design_G_300x600Option2_00104();
	this.instance_11.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_12 = new lib.Design_G_300x600Option2_00102();
	this.instance_12.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_13 = new lib.Design_G_300x600Option2_00101();
	this.instance_13.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_14 = new lib.Design_G_300x600Option2_00099();
	this.instance_14.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_15 = new lib.Design_G_300x600Option2_00098();
	this.instance_15.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_16 = new lib.Design_G_300x600Option2_00096();
	this.instance_16.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_17 = new lib.Design_G_300x600Option2_00095();
	this.instance_17.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_18 = new lib.Design_G_300x600Option2_00093();
	this.instance_18.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_19 = new lib.Design_G_300x600Option2_00092();
	this.instance_19.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_20 = new lib.Design_G_300x600Option2_00090();
	this.instance_20.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_21 = new lib.Design_G_300x600Option2_00089();
	this.instance_21.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_22 = new lib.Design_G_300x600Option2_00087();
	this.instance_22.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_23 = new lib.Design_G_300x600Option2_00086();
	this.instance_23.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_24 = new lib.Design_G_300x600Option2_00084();
	this.instance_24.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_25 = new lib.Design_G_300x600Option2_00083();
	this.instance_25.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_26 = new lib.Design_G_300x600Option2_00081();
	this.instance_26.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_27 = new lib.Design_G_300x600Option2_00080();
	this.instance_27.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_28 = new lib.Design_G_300x600Option2_00079();
	this.instance_28.setTransform(-8.8,-35.55,0.847,0.847);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},41).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_16}]},1).to({state:[{t:this.instance_17}]},1).to({state:[{t:this.instance_18}]},1).to({state:[{t:this.instance_19}]},1).to({state:[{t:this.instance_20}]},1).to({state:[{t:this.instance_21}]},1).to({state:[{t:this.instance_22}]},1).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},1).to({state:[{t:this.instance_25}]},1).to({state:[{t:this.instance_26}]},1).to({state:[{t:this.instance_27}]},1).to({state:[{t:this.instance_28}]},1).wait(1));

	// Layer_2
	this.instance_29 = new lib.Design_G_300x600Option2_00078();
	this.instance_29.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_30 = new lib.Design_G_300x600Option2_00079();
	this.instance_30.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_31 = new lib.Design_G_300x600Option2_00080();
	this.instance_31.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_32 = new lib.Design_G_300x600Option2_00081();
	this.instance_32.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_33 = new lib.Design_G_300x600Option2_00082();
	this.instance_33.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_34 = new lib.Design_G_300x600Option2_00083();
	this.instance_34.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_35 = new lib.Design_G_300x600Option2_00084();
	this.instance_35.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_36 = new lib.Design_G_300x600Option2_00085();
	this.instance_36.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_37 = new lib.Design_G_300x600Option2_00086();
	this.instance_37.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_38 = new lib.Design_G_300x600Option2_00087();
	this.instance_38.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_39 = new lib.Design_G_300x600Option2_00088();
	this.instance_39.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_40 = new lib.Design_G_300x600Option2_00089();
	this.instance_40.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_41 = new lib.Design_G_300x600Option2_00090();
	this.instance_41.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_42 = new lib.Design_G_300x600Option2_00091();
	this.instance_42.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_43 = new lib.Design_G_300x600Option2_00092();
	this.instance_43.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_44 = new lib.Design_G_300x600Option2_00093();
	this.instance_44.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_45 = new lib.Design_G_300x600Option2_00094();
	this.instance_45.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_46 = new lib.Design_G_300x600Option2_00095();
	this.instance_46.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_47 = new lib.Design_G_300x600Option2_00096();
	this.instance_47.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_48 = new lib.Design_G_300x600Option2_00097();
	this.instance_48.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_49 = new lib.Design_G_300x600Option2_00098();
	this.instance_49.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_50 = new lib.Design_G_300x600Option2_00099();
	this.instance_50.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_51 = new lib.Design_G_300x600Option2_00100();
	this.instance_51.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_52 = new lib.Design_G_300x600Option2_00101();
	this.instance_52.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_53 = new lib.Design_G_300x600Option2_00102();
	this.instance_53.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_54 = new lib.Design_G_300x600Option2_00103();
	this.instance_54.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_55 = new lib.Design_G_300x600Option2_00104();
	this.instance_55.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_56 = new lib.Design_G_300x600Option2_00105();
	this.instance_56.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_57 = new lib.Design_G_300x600Option2_00106();
	this.instance_57.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_58 = new lib.Design_G_300x600Option2_00107();
	this.instance_58.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_59 = new lib.Design_G_300x600Option2_00108();
	this.instance_59.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_60 = new lib.Design_G_300x600Option2_00109();
	this.instance_60.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_61 = new lib.Design_G_300x600Option2_00110();
	this.instance_61.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_62 = new lib.Design_G_300x600Option2_00111();
	this.instance_62.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_63 = new lib.Design_G_300x600Option2_00112();
	this.instance_63.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_64 = new lib.Design_G_300x600Option2_00113();
	this.instance_64.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_65 = new lib.Design_G_300x600Option2_00114();
	this.instance_65.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_66 = new lib.Design_G_300x600Option2_00115();
	this.instance_66.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_67 = new lib.Design_G_300x600Option2_00116();
	this.instance_67.setTransform(-8.8,-35.55,0.847,0.847);

	this.instance_68 = new lib.Design_G_300x600Option2_00117();
	this.instance_68.setTransform(-8.8,-35.55,0.847,0.847);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_29}]}).to({state:[{t:this.instance_30}]},1).to({state:[{t:this.instance_31}]},1).to({state:[{t:this.instance_32}]},1).to({state:[{t:this.instance_33}]},1).to({state:[{t:this.instance_34}]},1).to({state:[{t:this.instance_35}]},1).to({state:[{t:this.instance_36}]},1).to({state:[{t:this.instance_37}]},1).to({state:[{t:this.instance_38}]},1).to({state:[{t:this.instance_39}]},1).to({state:[{t:this.instance_40}]},1).to({state:[{t:this.instance_41}]},1).to({state:[{t:this.instance_42}]},1).to({state:[{t:this.instance_43}]},1).to({state:[{t:this.instance_44}]},1).to({state:[{t:this.instance_45}]},1).to({state:[{t:this.instance_46}]},1).to({state:[{t:this.instance_47}]},1).to({state:[{t:this.instance_48}]},1).to({state:[{t:this.instance_49}]},1).to({state:[{t:this.instance_50}]},1).to({state:[{t:this.instance_51}]},1).to({state:[{t:this.instance_52}]},1).to({state:[{t:this.instance_53}]},1).to({state:[{t:this.instance_54}]},1).to({state:[{t:this.instance_55}]},1).to({state:[{t:this.instance_56}]},1).to({state:[{t:this.instance_57}]},1).to({state:[{t:this.instance_58}]},1).to({state:[{t:this.instance_59}]},1).to({state:[{t:this.instance_60}]},1).to({state:[{t:this.instance_61}]},1).to({state:[{t:this.instance_62}]},1).to({state:[{t:this.instance_63}]},1).to({state:[{t:this.instance_64}]},1).to({state:[{t:this.instance_65}]},1).to({state:[{t:this.instance_66}]},1).to({state:[{t:this.instance_67}]},1).to({state:[{t:this.instance_68}]},1).to({state:[]},2).wait(29));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.1,-35.9,76.6,103.30000000000001);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.c_cube = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_69 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(1));

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape.setTransform(42.25,40.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0078D3").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_1.setTransform(42.25,40.65);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0177D2").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_2.setTransform(42.25,40.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0177D1").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_3.setTransform(42.25,40.65);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0276CE").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_4.setTransform(42.25,40.65);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0474CA").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_5.setTransform(42.25,40.65);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0672C4").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_6.setTransform(42.25,40.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0A6EBC").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_7.setTransform(42.25,40.65);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0F69B0").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_8.setTransform(42.25,40.65);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1563A0").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_9.setTransform(42.25,40.65);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1E5A8B").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_10.setTransform(42.25,40.65);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#275175").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_11.setTransform(42.25,40.65);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#2D4B65").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_12.setTransform(42.25,40.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#324659").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_13.setTransform(42.25,40.65);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#364251").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_14.setTransform(42.25,40.65);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#38404B").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_15.setTransform(42.25,40.65);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#3A3E47").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_16.setTransform(42.25,40.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#3B3D44").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_17.setTransform(42.25,40.65);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#3B3D43").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_18.setTransform(42.25,40.65);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#3C3C42").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_19.setTransform(42.25,40.65);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#3C3C41").s().p("AiMhRIEZiiIAAFEIkZCjg");
	this.shape_20.setTransform(42.25,40.65);
	this.shape_20._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},9).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(14).to({_off:true},1).wait(49).to({_off:false},0).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_20).wait(34).to({_off:false},0).wait(10).to({_off:true},1).wait(25));

	// Layer_1
	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#3C3C41").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_21.setTransform(14.075,40.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#3C3C42").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_22.setTransform(14.075,40.65);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#3B3D43").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_23.setTransform(14.075,40.65);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#3B3D44").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_24.setTransform(14.075,40.65);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#3A3E47").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_25.setTransform(14.075,40.65);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#38404A").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_26.setTransform(14.075,40.65);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#364250").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_27.setTransform(14.075,40.65);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#324558").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_28.setTransform(14.075,40.65);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#2D4A64").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_29.setTransform(14.075,40.65);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#275074").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_30.setTransform(14.075,40.65);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#1E5989").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_31.setTransform(14.075,40.65);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#15619D").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_32.setTransform(14.075,40.65);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#0F67AD").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_33.setTransform(14.075,40.65);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#0A6CB9").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_34.setTransform(14.075,40.65);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#066FC1").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_35.setTransform(14.075,40.65);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#0471C7").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_36.setTransform(14.075,40.65);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#0273CA").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_37.setTransform(14.075,40.65);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#0174CD").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_38.setTransform(14.075,40.65);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#0174CE").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_39.setTransform(14.075,40.65);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#0075CF").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_40.setTransform(14.075,40.65);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#0075D0").s().p("AiMBRIAAlEIEZCiIAAFFg");
	this.shape_41.setTransform(14.075,40.65);
	this.shape_41._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21}]}).to({state:[{t:this.shape_21}]},9).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_21).wait(14).to({_off:true},1).wait(49).to({_off:false},0).wait(6));
	this.timeline.addTween(cjs.Tween.get(this.shape_41).wait(34).to({_off:false},0).wait(10).to({_off:true},1).wait(25));

	// Layer_4
	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#75757A").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_42.setTransform(28.175,16.25);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#747479").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_43.setTransform(28.175,16.25);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#737378").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_44.setTransform(28.175,16.25);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#717176").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_45.setTransform(28.175,16.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#6F6F74").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_46.setTransform(28.175,16.25);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#6B6B70").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_47.setTransform(28.175,16.25);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#66666A").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_48.setTransform(28.175,16.25);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#5F5F62").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_49.setTransform(28.175,16.25);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#545458").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_50.setTransform(28.175,16.25);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#47474A").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_51.setTransform(28.175,16.25);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#3A3A3B").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_52.setTransform(28.175,16.25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#2F2F31").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_53.setTransform(28.175,16.25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#282829").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_54.setTransform(28.175,16.25);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#232323").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_55.setTransform(28.175,16.25);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1F1F1F").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_56.setTransform(28.175,16.25);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#1D1D1D").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_57.setTransform(28.175,16.25);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#1B1B1B").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_58.setTransform(28.175,16.25);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#1A1A1A").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_59.setTransform(28.175,16.25);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#191919").s().p("AkZAAIEZiiIEaCiIkaCig");
	this.shape_60.setTransform(28.175,16.25);
	this.shape_60._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42}]}).to({state:[{t:this.shape_42}]},9).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_42}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_42).wait(15).to({_off:true},1).wait(47).to({_off:false},0).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.shape_60).wait(33).to({_off:false},0).wait(12).to({_off:true},1).wait(24));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,56.4,65.1);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,2,0,3).p("Agbg+IA3A/Ig3A+");
	this.shape.setTransform(6.5139,4.3758);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(2.3,-3.3,8.5,15.399999999999999), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:6.5,regY:4.4,x:2.9,y:0.25},0).wait(1).to({x:2.25},0).wait(1).to({x:1.3},0).wait(1).to({x:0.5},0).wait(1).to({x:0},0).wait(1).to({regX:5.6,regY:4.2,x:-1.05,y:0.05},0).wait(1).to({regX:6.5,regY:4.4,x:-0.05,y:0.25},0).wait(1).to({x:0.3},0).wait(1).to({x:0.75},0).wait(1).to({x:1.15},0).wait(1).to({x:1.4},0).wait(1).to({regX:5.6,regY:4.2,x:0.55,y:0.05},0).wait(1).to({regX:6.5,regY:4.4,x:1.45,y:0.25},0).wait(1).to({x:1.3},0).wait(1).to({x:1.15},0).wait(1).to({x:1},0).wait(1).to({x:0.9},0).wait(1).to({regX:5.6,regY:4.2,x:-0.05,y:0.05},0).wait(1).to({regX:6.5,regY:4.4,x:0.9,y:0.25},0).wait(1).to({x:0.95},0).wait(1).to({x:1},0).wait(1).to({x:1.05},0).wait(1).to({regX:5.6,regY:4.2,x:0.15,y:0.05},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-7.4,20.5,15.4);


(lib.cube_vector = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cc = new lib.c_cube();
	this.cc.name = "cc";
	this.cc.setTransform(28.2,32.5,1,1,0,0,0,28.2,32.5);

	this.timeline.addTween(cjs.Tween.get(this.cc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cube_vector, new cjs.Rectangle(0,0,56.4,65.1), null);


(lib.BoxAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.cube7 = new lib.cube_vector();
	this.cube7.name = "cube7";
	this.cube7.setTransform(304.35,290.2,0.9879,0.9879,0,0,0,28.2,32.6);

	this.cube6 = new lib.cube_vector();
	this.cube6.name = "cube6";
	this.cube6.setTransform(360,290.2,0.9879,0.9879,0,0,0,28.2,32.6);

	this.cube5 = new lib.cube_vector();
	this.cube5.name = "cube5";
	this.cube5.setTransform(332.25,241.95,0.9879,0.9879,0,0,0,28.2,32.6);

	this.cube4 = new lib.cube_Animation_1();
	this.cube4.name = "cube4";
	this.cube4.setTransform(387.8,242.05,0.9879,0.9879,0,0,0,28.2,32.6);

	this.cube3 = new lib.cube_Animation_2();
	this.cube3.name = "cube3";
	this.cube3.setTransform(443.2,243,0.9879,0.9879,0,0,0,28.2,32.6);

	this.cube2 = new lib.cube_vector();
	this.cube2.name = "cube2";
	this.cube2.setTransform(415.3,194.75,0.9879,0.9879,0,0,0,28.2,32.6);

	this.cube1 = new lib.cube_vector();
	this.cube1.name = "cube1";
	this.cube1.setTransform(359.15,162.2,0.9879,0.9879,0,0,0,28.2,32.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cube1},{t:this.cube2},{t:this.cube3},{t:this.cube4},{t:this.cube5},{t:this.cube6},{t:this.cube7}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BoxAnim, new cjs.Rectangle(276.5,130,206.3,192.3), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(5.3,6.6);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(4.25,0.55,1.0352,1.0352,0,0,0,13.5,10.6);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("ArRDEIAAmHIWjAAIAAGHg");
	this.shape.setTransform(-52.75,0.2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-124.9,-19.4,144.3,39.2), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(104.6,363.35,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(165.85,363.45,1,1,0,0,0,0.1,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(34.3,36.1,1.0601,1.0533,0,0,0,-52.9,-23.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// price
	this.price = new lib.price();
	this.price.name = "price";
	this.price.setTransform(169.55,408.95,1.1299,1.1299,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.price).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#000000","rgba(0,0,0,0)"],[0,0.631],-14.9,66,-14.9,160).s().p("EgZJAggMAAAhA/MAyTAAAMAAABA/g");
	this.shape.setTransform(151,208.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// BoxAnim
	this.boxAnim = new lib.BoxAnim();
	this.boxAnim.name = "boxAnim";
	this.boxAnim.setTransform(223.65,560.9,0.7809,0.7809,0,0,0,377.5,276.1);

	this.timeline.addTween(cjs.Tween.get(this.boxAnim).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-10,0.1,322,596.9), null);


// stage content:
(lib.G2_Black_BG_300x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		
		
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
		
		
				
			exportRoot.isReplay = false;
			exportRoot.cubeReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
			mc.txtCta.visible=false
			mc.cta.visible=false
			mc.replay_btn.visible=false
			mc.boxAnim.cube1.visible=false
			mc.boxAnim.cube2.visible=false
			mc.boxAnim.cube3.visible=false
			mc.boxAnim.cube4.visible=false
			mc.boxAnim.cube5.visible=false
			mc.boxAnim.cube6.visible=false
			mc.boxAnim.cube7.visible=false
		
		
		this.runBanner = function() {
			mc.txtCta.visible=true
			mc.cta.visible=true
			mc.replay_btn.visible=true
			mc.boxAnim.cube1.visible=true
			mc.boxAnim.cube2.visible=true
			mc.boxAnim.cube3.visible=true
			mc.boxAnim.cube4.visible=true
			mc.boxAnim.cube5.visible=true
			mc.boxAnim.cube6.visible=true
			mc.boxAnim.cube7.visible=true
		
			this.tl1 = new TimelineLite();
					
				//exportRoot.tl1.from(mc.whiteBg, 1.4, { x: "+=200",	ease:Power4.easeInOut}, "-=1.4");
					
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.9, { y: "+=40", alpha: 0, ease:Power3.easeOut}, "+=.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.9, { y: "+=40", alpha: 0, ease:Power3.easeOut}, "-=.82");
				}	
			
				exportRoot.tl1.from(mc.boxAnim.cube7, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.5")
				exportRoot.tl1.from(mc.boxAnim.cube6, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.4")
				exportRoot.tl1.from(mc.boxAnim.cube5, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.4")
				exportRoot.tl1.from(mc.boxAnim.cube4, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.4")
				exportRoot.tl1.from(mc.boxAnim.cube3, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.4")
				exportRoot.tl1.from(mc.boxAnim.cube2, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.4")		
				exportRoot.tl1.from(mc.boxAnim.cube1, 2.5, { y:"-=400", ease:Elastic.easeInOut.config(0.65, 0.45)}, "-=2.4")
		
				exportRoot.tl1.from(mc.cta, 0.7, {scaleX:.2, x: "+=100", alpha:0, ease:Power4.easeOut}, "-=.6");
				exportRoot.tl1.from(mc.txtCta, 0.5, { x: "+=40", alpha:0, ease:Power3.easeOut}, "-=0.4");
				exportRoot.tl1.from(mc.cta.arrow, 0.5, {scaleX:.5, scaleY:.5, x: "-=15", alpha:0, ease:Power3.easeOut}, "-=0.3");
				
				//Cubes in
		exportRoot.tl1.to(mc.boxAnim.cube1, .4, {y:"-=8", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube1.cc.play()}}, "-=.6")
				exportRoot.tl1.to(mc.boxAnim.cube1, .6, {y:"+=44", ease:Power1.easeInOut}, "-=.2")
				exportRoot.tl1.to(mc.boxAnim.cube5, 1, {y:"-=31", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube5.cc.play()}}, "-=1.05")
				exportRoot.tl1.to(mc.boxAnim.cube7, 1, {y:"-=65", ease:Power2.easeInOut, onStart:function(){mc.boxAnim.cube7.cc.play()}}, "-=1.1")
				exportRoot.tl1.to(mc.boxAnim.cube6, .4, {y:"+=8", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube6.cc.play()}}, "-=1.05")
				exportRoot.tl1.to(mc.boxAnim.cube6, .6, {y:"-=73", ease:Power1.easeInOut}, "-=.8")
				exportRoot.tl1.to(mc.boxAnim.cube2, .4, {x:"+=12", y:"-=8", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube2.cc.play()}}, "-=1.1")
				exportRoot.tl1.to(mc.boxAnim.cube2, .6, {x:"-=12", y:"+=48", ease:Power1.easeInOut}, "-=.8")
				exportRoot.tl1.from(mc.boxAnim.cube4, 1, {y:"+=0",  ease:Power2.easeInOut, onStart:function(){mc.boxAnim.cube4.play()}}, "-=1.1")
				exportRoot.tl1.from(mc.boxAnim.cube3, 1, {y:"+=0",  ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube3.play()}}, "-=1.05")
				//Cubes out
				exportRoot.tl1.to(mc.boxAnim.cube1, .4, {y:"-=44", ease:Power1.easeInOut}, "+=0")
				exportRoot.tl1.to(mc.boxAnim.cube1, .3, {y:"+=8", ease:Power1.easeInOut}, "-=0")
				exportRoot.tl1.to(mc.boxAnim.cube5, .7, {y:"+=31", ease:Power2.easeInOut}, "-=.7")
				exportRoot.tl1.to(mc.boxAnim.cube7, .7, {y:"+=65", ease:Power2.easeInOut}, "-=.7")
				exportRoot.tl1.to(mc.boxAnim.cube6, .6, {y:"+=73", ease:Power1.easeInOut}, "-=.8")
				exportRoot.tl1.to(mc.boxAnim.cube6, .3, {y:"-=8", ease:Power1.easeInOut}, "-=.2")
				exportRoot.tl1.to(mc.boxAnim.cube2, .6, {x:"+=12", y:"-=48", ease:Power2.easeInOut}, "-=1")
				exportRoot.tl1.to(mc.boxAnim.cube2, .3, {x:"-=12", y:"+=8", ease:Power2.easeInOut, onComplete:function(){exportRoot.cubeReplay=true;}}, "-=.4")
		
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0, ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
				
				this.tlroll = new TimelineLite();
			
				exportRoot.tlroll.to(mc.boxAnim.cube1, .4, {y:"-=8", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube1.cc.gotoAndPlay(1)}}, "+=0")
				exportRoot.tlroll.to(mc.boxAnim.cube1, .6, {y:"+=44", ease:Power1.easeInOut}, "+=0")
				exportRoot.tlroll.to(mc.boxAnim.cube5, 1, {y:"-=31", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube5.cc.gotoAndPlay(1)}}, "-=1")
				exportRoot.tlroll.to(mc.boxAnim.cube7, 1, {y:"-=65", ease:Power2.easeInOut, onStart:function(){mc.boxAnim.cube7.cc.gotoAndPlay(1)}}, "-=1")
				exportRoot.tlroll.to(mc.boxAnim.cube6, .4, {y:"+=8", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube6.cc.gotoAndPlay(1)}}, "-=1")
				exportRoot.tlroll.to(mc.boxAnim.cube6, .6, {y:"-=73", ease:Power1.easeInOut}, "-=.6")
				exportRoot.tlroll.to(mc.boxAnim.cube2, .4, {x:"+=12", y:"-=8", ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube2.cc.gotoAndPlay(1)}}, "-=1")
				exportRoot.tlroll.to(mc.boxAnim.cube2, .6, {x:"-=12", y:"+=48", ease:Power1.easeInOut}, "-=.6")
				exportRoot.tlroll.from(mc.boxAnim.cube4, 1, {y:"+=0",  ease:Power2.easeInOut, onStart:function(){mc.boxAnim.cube4.gotoAndPlay(1)}}, "-=1")
				exportRoot.tlroll.from(mc.boxAnim.cube3, 1, {y:"+=0",  ease:Power1.easeInOut, onStart:function(){mc.boxAnim.cube3.gotoAndPlay(1)}}, "-=1")
		
				//Cubes out
				exportRoot.tlroll.to(mc.boxAnim.cube1, .4, {y:"-=44", ease:Power1.easeInOut}, "+=0")
				exportRoot.tlroll.to(mc.boxAnim.cube1, .3, {y:"+=8", ease:Power1.easeInOut}, "-=0")
				exportRoot.tlroll.to(mc.boxAnim.cube5, .7, {y:"+=31", ease:Power2.easeInOut}, "-=.7")
				exportRoot.tlroll.to(mc.boxAnim.cube7, .7, {y:"+=65", ease:Power2.easeInOut}, "-=.7")
				exportRoot.tlroll.to(mc.boxAnim.cube6, .6, {y:"+=73", ease:Power1.easeInOut}, "-=.7")
				exportRoot.tlroll.to(mc.boxAnim.cube6, .3, {y:"-=8", ease:Power1.easeInOut}, "-=.1")
				exportRoot.tlroll.to(mc.boxAnim.cube2, .6, {x:"+=12", y:"-=48", ease:Power2.easeInOut}, "-=.8")
				exportRoot.tlroll.to(mc.boxAnim.cube2, .3, {x:"-=12", y:"+=8", ease:Power2.easeInOut}, "-=.2")
				
				exportRoot.tlroll.stop();	
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(140,300,172,297);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#000000",
	opacity: 1.00,
	manifest: [
		{src:"images/G2_Black_BG_300x600_atlas_.png?1591203918231", id:"G2_Black_BG_300x600_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;