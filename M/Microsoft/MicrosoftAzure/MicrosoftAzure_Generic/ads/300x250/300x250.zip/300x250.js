(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"300x250_atlas_P_", frames: [[0,0,150,150],[152,0,150,150],[304,0,150,150],[456,0,150,150],[608,0,150,150],[760,0,150,150],[0,152,150,150],[152,152,150,150],[304,152,150,150],[456,152,150,150],[608,152,150,150],[760,152,150,150],[0,304,150,150],[152,304,150,150],[304,304,150,150],[456,304,150,150],[608,304,200,29]]}
];


// symbols:



(lib.Comp1_00000 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00001 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00002 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00003 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00004 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00005 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00006 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00007 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00008 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00009 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00010 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00011 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00012 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00013 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00014 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00015 = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.MSAzureLogo_horGr = function() {
	this.initialize(ss["300x250_atlas_P_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Square_teal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4EE3FB").s().p("AnzH0IAAvnIPnAAIAAPng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_teal, new cjs.Rectangle(-50,-50,100,100), null);


(lib.Square_outline_teal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#4EE4FC").ss(3,1,1).p("AnpnpIPTAAIAAPTIvTAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_outline_teal, new cjs.Rectangle(-50.5,-50.5,101,101), null);


(lib.Square_outline_grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#757578").ss(3,1,1).p("AnpnpIPTAAIAAPTIvTAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_outline_grey, new cjs.Rectangle(-50.5,-50.5,101,101), null);


(lib.Square_grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#757578").s().p("AnzH0IAAvnIPnAAIAAPng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_grey, new cjs.Rectangle(-50,-50,100,100), null);


(lib.Square_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_8, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#50E6FF").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_7, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square_6, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.overlay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A4/VGMAAAgqLMAx/AAAMAAAAqLg");
	this.shape.setTransform(160,135);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlay, new cjs.Rectangle(0,0,320,270), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.Text = new cjs.Text("Try Azure freeee", "14px 'Segoe Pro Semibold'", "#FFFFFF");
	this.Text.name = "Text";
	this.Text.textAlign = "center";
	this.Text.lineHeight = 19;
	this.Text.lineWidth = 111;
	this.Text.parent = this;
	this.Text.setTransform(57.3,2);

	this.timeline.addTween(cjs.Tween.get(this.Text).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,114.6,22.9), null);


(lib.mc_CalloutAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(47));

	// blueBox
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("AhrC+IAAl7IDXAAIAAF7g");
	this.shape.setTransform(52.225,28.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0178D4").s().p("AhrC9IAAl5IDXAAIAAF5g");
	this.shape_1.setTransform(52.775,28.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0178D4").s().p("AhrC8IAAl3IDXAAIAAF3g");
	this.shape_2.setTransform(53.175,28.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0178D4").s().p("AhrC6IAAlzIDXAAIAAFzg");
	this.shape_3.setTransform(53.675,29.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0178D4").s().p("AhrC5IAAlxIDXAAIAAFxg");
	this.shape_4.setTransform(54.325,29.275);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0178D4").s().p("AhrC3IAAltIDXAAIAAFtg");
	this.shape_5.setTransform(55.075,29.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0178D4").s().p("AhrC1IAAlpIDXAAIAAFpg");
	this.shape_6.setTransform(55.975,29.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0178D4").s().p("AhrCyIAAljIDXAAIAAFjg");
	this.shape_7.setTransform(56.975,29.925);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0178D4").s().p("AhrCvIAAldIDXAAIAAFdg");
	this.shape_8.setTransform(58.075,30.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0178D4").s().p("AhrCsIAAlXIDXAAIAAFXg");
	this.shape_9.setTransform(59.325,30.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0178D4").s().p("AhrCpIAAlRIDXAAIAAFRg");
	this.shape_10.setTransform(60.675,30.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0178D4").s().p("AhrClIAAlJIDXAAIAAFJg");
	this.shape_11.setTransform(62.125,31.225);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0178D4").s().p("AhrChIAAlBIDXAAIAAFBg");
	this.shape_12.setTransform(63.725,31.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0178D4").s().p("AhrCdIAAk5IDXAAIAAE5g");
	this.shape_13.setTransform(65.425,32.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0178D4").s().p("AhrCZIAAkwIDXAAIAAEwg");
	this.shape_14.setTransform(67.225,32.5);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0178D4").s().p("AhrCiIAAlDIDXAAIAAFDg");
	this.shape_15.setTransform(61.625,31.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#0178D4").s().p("AhrCmIAAlLIDXAAIAAFLg");
	this.shape_16.setTransform(59.125,31.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0178D4").s().p("AhrCqIAAlTIDXAAIAAFTg");
	this.shape_17.setTransform(56.825,30.775);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#0178D4").s().p("AhrCtIAAlZIDXAAIAAFZg");
	this.shape_18.setTransform(54.725,30.425);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0178D4").s().p("AhrCxIAAlhIDXAAIAAFhg");
	this.shape_19.setTransform(52.825,30.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0178D4").s().p("AhrCzIAAllIDXAAIAAFlg");
	this.shape_20.setTransform(51.125,29.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0178D4").s().p("AhrC2IAAlrIDXAAIAAFrg");
	this.shape_21.setTransform(49.625,29.575);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#0178D4").s().p("AhrC4IAAlvIDXAAIAAFvg");
	this.shape_22.setTransform(48.325,29.35);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#0178D4").s().p("AhrC7IAAl1IDXAAIAAF1g");
	this.shape_23.setTransform(46.325,29.025);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#0178D4").s().p("AhrC9IAAl4IDXAAIAAF4g");
	this.shape_24.setTransform(45.625,28.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1,p:{x:52.775,y:28.875}}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3,p:{x:53.675,y:29.125}}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13,p:{x:65.425,y:32.05}}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_13,p:{x:64.325,y:32.025}}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_3,p:{x:47.225,y:29.175}}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_1,p:{x:45.125,y:28.825}}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({x:52.275,y:28.775},0).wait(1).to({x:52.475,y:28.8},0).to({_off:true},1).wait(27).to({_off:false,x:44.825,y:28.775},0).wait(1).to({x:44.725,y:28.75},0).wait(1).to({x:45.675},0).wait(1).to({x:46.575},0).wait(1).to({x:47.425},0).wait(1).to({x:48.175},0).wait(1).to({x:48.875},0).wait(1).to({x:49.525},0).wait(1).to({x:50.075},0).wait(1).to({x:50.575},0).wait(1).to({x:51.025},0).wait(1).to({x:51.375},0).wait(1).to({x:51.675},0).wait(1).to({x:51.925},0).wait(1).to({x:52.075},0).wait(1).to({x:52.175},0).wait(1).to({x:52.225},0).wait(1));

	// blueCallout
	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#00B5EB").s().p("Ak6DvIAAndIJ1AAIAAHdg");
	this.shape_25.setTransform(31.5,23.875);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#00B5EB").s().p("Ak7DvIAAndIJ3AAIAAHdg");
	this.shape_26.setTransform(31.625,23.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#00B5EB").s().p("Ak9DwIAAnfIJ7AAIAAHfg");
	this.shape_27.setTransform(31.775,23.75);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#00B5EB").s().p("Ak/DxIAAnhIJ/AAIAAHhg");
	this.shape_28.setTransform(31.975,23.65);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#00B5EB").s().p("AlBDzIAAnkIKDAAIAAHkg");
	this.shape_29.setTransform(32.225,23.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#00B5EB").s().p("AlFD0IAAnnIKKAAIAAHng");
	this.shape_30.setTransform(32.55,23.35);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#00B5EB").s().p("AlID2IAAnrIKRAAIAAHrg");
	this.shape_31.setTransform(32.925,23.15);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#00B5EB").s().p("AlND4IAAnvIKbAAIAAHvg");
	this.shape_32.setTransform(33.375,22.95);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#00B5EB").s().p("AlSD7IAAn0IKlAAIAAH0g");
	this.shape_33.setTransform(33.875,22.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#00B5EB").s().p("AlXD+IAAn7IKvAAIAAH7g");
	this.shape_34.setTransform(34.425,22.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#00B5EB").s().p("AleEBIAAoAIK9AAIAAIAg");
	this.shape_35.setTransform(35.05,22.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#00B5EB").s().p("AlkEEIAAoHILJAAIAAIHg");
	this.shape_36.setTransform(35.725,21.775);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#00B5EB").s().p("AlsEIIAAoPILZAAIAAIPg");
	this.shape_37.setTransform(36.45,21.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#00B5EB").s().p("Al0EMIAAoXILpAAIAAIXg");
	this.shape_38.setTransform(37.25,21);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#00B5EB").s().p("Al8EQIAAofIL5AAIAAIfg");
	this.shape_39.setTransform(38.1,20.575);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#00B5EB").s().p("AmFEUIAAonIMLAAIAAIng");
	this.shape_40.setTransform(39,20.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#00B5EB").s().p("Al3ELIAAoVILuAAIAAIVg");
	this.shape_41.setTransform(37.55,21.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#00B5EB").s().p("AlpECIAAoDILTAAIAAIDg");
	this.shape_42.setTransform(36.2,22);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#00B5EB").s().p("AldD5IAAnxIK7AAIAAHxg");
	this.shape_43.setTransform(34.95,22.825);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#00B5EB").s().p("AlRDyIAAniIKjAAIAAHig");
	this.shape_44.setTransform(33.8,23.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#00B5EB").s().p("AlHDrIAAnVIKPAAIAAHVg");
	this.shape_45.setTransform(32.75,24.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#00B5EB").s().p("Ak9DkIAAnHIJ7AAIAAHHg");
	this.shape_46.setTransform(31.8,24.925);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#00B5EB").s().p("Ak1DfIAAm9IJrAAIAAG9g");
	this.shape_47.setTransform(30.95,25.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#00B5EB").s().p("AktDaIAAmzIJbAAIAAGzg");
	this.shape_48.setTransform(30.2,26);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#00B5EB").s().p("AknDVIAAmpIJPAAIAAGpg");
	this.shape_49.setTransform(29.55,26.425);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#00B5EB").s().p("AkhDSIAAmjIJDAAIAAGjg");
	this.shape_50.setTransform(29,26.8);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#00B5EB").s().p("AkdDPIAAmcII6AAIAAGcg");
	this.shape_51.setTransform(28.55,27.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#00B5EB").s().p("AkZDMIAAmXIIzAAIAAGXg");
	this.shape_52.setTransform(28.2,27.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#00B5EB").s().p("AkXDLIAAmUIIuAAIAAGUg");
	this.shape_53.setTransform(27.95,27.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#00B5EB").s().p("AkVDKIAAmSIIrAAIAAGSg");
	this.shape_54.setTransform(27.8,27.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#00B5EB").s().p("AkVDJIAAmRIIrAAIAAGRg");
	this.shape_55.setTransform(27.75,27.625);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#00B5EB").s().p("AkZDOIAAmbIIzAAIAAGbg");
	this.shape_56.setTransform(28.225,27.15);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#00B5EB").s().p("AkeDTIAAmkII9AAIAAGkg");
	this.shape_57.setTransform(28.675,26.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#00B5EB").s().p("AkiDXIAAmtIJFAAIAAGtg");
	this.shape_58.setTransform(29.1,26.275);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#00B5EB").s().p("AkmDbIAAm1IJNAAIAAG1g");
	this.shape_59.setTransform(29.475,25.9);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#00B5EB").s().p("AkpDeIAAm7IJTAAIAAG7g");
	this.shape_60.setTransform(29.825,25.55);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#00B5EB").s().p("AktDhIAAnBIJaAAIAAHBg");
	this.shape_61.setTransform(30.15,25.225);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#00B5EB").s().p("AkvDkIAAnHIJfAAIAAHHg");
	this.shape_62.setTransform(30.425,24.95);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#00B5EB").s().p("AkyDnIAAnNIJlAAIAAHNg");
	this.shape_63.setTransform(30.675,24.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#00B5EB").s().p("Ak0DpIAAnRIJpAAIAAHRg");
	this.shape_64.setTransform(30.9,24.475);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#00B5EB").s().p("Ak2DrIAAnVIJtAAIAAHVg");
	this.shape_65.setTransform(31.075,24.3);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#00B5EB").s().p("Ak3DsIAAnXIJvAAIAAHXg");
	this.shape_66.setTransform(31.225,24.15);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#00B5EB").s().p("Ak5DtIAAnZIJzAAIAAHZg");
	this.shape_67.setTransform(31.35,24.025);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#00B5EB").s().p("Ak5DuIAAnbIJzAAIAAHbg");
	this.shape_68.setTransform(31.425,23.95);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#00B5EB").s().p("Ak6DvIAAncIJ1AAIAAHcg");
	this.shape_69.setTransform(31.475,23.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25,p:{x:31.5,y:23.875}}]}).to({state:[{t:this.shape_25,p:{x:31.525,y:23.85}}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_25,p:{x:31.5,y:23.875}}]},1).wait(1));

	// grayCallout
	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#B9B9B9").s().p("Ak6DvIAAndIJ1AAIAAHdg");
	this.shape_70.setTransform(72.75,33.625);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#B9B9B9").s().p("Ak6DvIAAncIJ1AAIAAHcg");
	this.shape_71.setTransform(72.775,33.65);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#B9B9B9").s().p("Ak5DuIAAnbIJzAAIAAHbg");
	this.shape_72.setTransform(72.875,33.675);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#B9B9B9").s().p("Ak3DuIAAnbIJvAAIAAHbg");
	this.shape_73.setTransform(73.025,33.75);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#B9B9B9").s().p("Ak1DtIAAnZIJrAAIAAHZg");
	this.shape_74.setTransform(73.225,33.85);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#B9B9B9").s().p("AkzDrIAAnVIJnAAIAAHVg");
	this.shape_75.setTransform(73.475,34);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#B9B9B9").s().p("AkvDqIAAnSIJfAAIAAHSg");
	this.shape_76.setTransform(73.8,34.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#B9B9B9").s().p("AksDoIAAnPIJZAAIAAHPg");
	this.shape_77.setTransform(74.175,34.35);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#B9B9B9").s().p("AknDlIAAnJIJPAAIAAHJg");
	this.shape_78.setTransform(74.625,34.575);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#B9B9B9").s().p("AkiDjIAAnFIJFAAIAAHFg");
	this.shape_79.setTransform(75.125,34.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#B9B9B9").s().p("AkdDgIAAm/II7AAIAAG/g");
	this.shape_80.setTransform(75.675,35.1);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#B9B9B9").s().p("AkXDdIAAm5IIuAAIAAG5g");
	this.shape_81.setTransform(76.3,35.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#B9B9B9").s().p("AkQDaIAAmzIIhAAIAAGzg");
	this.shape_82.setTransform(76.975,35.725);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#B9B9B9").s().p("AkJDWIAAmrIISAAIAAGrg");
	this.shape_83.setTransform(77.7,36.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#B9B9B9").s().p("AkBDSIAAmjIICAAIAAGjg");
	this.shape_84.setTransform(78.5,36.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#B9B9B9").s().p("Aj4DOIAAmbIHxAAIAAGbg");
	this.shape_85.setTransform(79.35,36.925);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#B9B9B9").s().p("AjvDJIAAmRIHfAAIAAGRg");
	this.shape_86.setTransform(80.25,37.375);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#B9B9B9").s().p("Aj9DOIAAmbIH7AAIAAGbg");
	this.shape_87.setTransform(78.8,36.9);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#B9B9B9").s().p("AkLDTIAAmlIIXAAIAAGlg");
	this.shape_88.setTransform(77.45,36.45);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#B9B9B9").s().p("AkYDXIAAmtIIwAAIAAGtg");
	this.shape_89.setTransform(76.2,36.025);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#B9B9B9").s().p("AkjDbIAAm1IJHAAIAAG1g");
	this.shape_90.setTransform(75.05,35.65);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#B9B9B9").s().p("AkuDeIAAm7IJcAAIAAG7g");
	this.shape_91.setTransform(74,35.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#B9B9B9").s().p("Ak3DhIAAnBIJvAAIAAHBg");
	this.shape_92.setTransform(73.05,34.975);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#B9B9B9").s().p("AlADkIAAnHIKAAAIAAHHg");
	this.shape_93.setTransform(72.2,34.7);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#B9B9B9").s().p("AlHDnIAAnMIKPAAIAAHMg");
	this.shape_94.setTransform(71.45,34.45);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#B9B9B9").s().p("AlODpIAAnRIKcAAIAAHRg");
	this.shape_95.setTransform(70.8,34.225);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#B9B9B9").s().p("AlTDrIAAnUIKnAAIAAHUg");
	this.shape_96.setTransform(70.25,34.05);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#B9B9B9").s().p("AlXDsIAAnXIKvAAIAAHXg");
	this.shape_97.setTransform(69.8,33.9);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#B9B9B9").s().p("AlbDtIAAnZIK3AAIAAHZg");
	this.shape_98.setTransform(69.45,33.775);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#B9B9B9").s().p("AleDuIAAnbIK8AAIAAHbg");
	this.shape_99.setTransform(69.2,33.7);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#B9B9B9").s().p("AlfDvIAAncIK/AAIAAHcg");
	this.shape_100.setTransform(69.05,33.65);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#B9B9B9").s().p("AlgDvIAAndILAAAIAAHdg");
	this.shape_101.setTransform(69,33.625);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#B9B9B9").s().p("AlbDvIAAndIK3AAIAAHdg");
	this.shape_102.setTransform(69.475,33.625);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#B9B9B9").s().p("AlWDvIAAndIKtAAIAAHdg");
	this.shape_103.setTransform(69.925,33.625);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#B9B9B9").s().p("AlSDvIAAndIKlAAIAAHdg");
	this.shape_104.setTransform(70.35,33.625);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#B9B9B9").s().p("AlODvIAAndIKdAAIAAHdg");
	this.shape_105.setTransform(70.725,33.625);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#B9B9B9").s().p("AlLDvIAAndIKXAAIAAHdg");
	this.shape_106.setTransform(71.075,33.625);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#B9B9B9").s().p("AlIDvIAAndIKQAAIAAHdg");
	this.shape_107.setTransform(71.4,33.625);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#B9B9B9").s().p("AlFDvIAAndIKLAAIAAHdg");
	this.shape_108.setTransform(71.675,33.625);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#B9B9B9").s().p("AlCDvIAAndIKFAAIAAHdg");
	this.shape_109.setTransform(71.925,33.625);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#B9B9B9").s().p("AlADvIAAndIKBAAIAAHdg");
	this.shape_110.setTransform(72.15,33.625);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#B9B9B9").s().p("Ak+DvIAAndIJ9AAIAAHdg");
	this.shape_111.setTransform(72.325,33.625);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#B9B9B9").s().p("Ak9DvIAAndIJ7AAIAAHdg");
	this.shape_112.setTransform(72.475,33.625);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#B9B9B9").s().p("Ak7DvIAAndIJ3AAIAAHdg");
	this.shape_113.setTransform(72.6,33.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_70,p:{x:72.75}}]}).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113,p:{x:72.6}}]},1).to({state:[{t:this.shape_113,p:{x:72.675}}]},1).to({state:[{t:this.shape_70,p:{x:72.725}}]},1).to({state:[{t:this.shape_70,p:{x:72.75}}]},1).wait(1));

	// pointer
	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#B9B9B9").s().p("Ag4g4IBxAAIhxBxg");
	this.shape_114.setTransform(5.675,53.425);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#00B5EB").s().p("Ag4g4IBxAAIAABxg");
	this.shape_115.setTransform(98.575,63.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_115},{t:this.shape_114}]}).wait(47));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-7.5,104.3,76.4);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MSAzureLogo_horGr();
	this.instance.setTransform(0,0,0.54,0.5396);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,108,15.7), null);


(lib.impossibleTri = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],120.8,-30.5,44.4,0.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape.setTransform(9.975,-4.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],119.2,-30.2,44.3,1.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_1.setTransform(9.975,-4.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],117.6,-30,44.1,2.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_2.setTransform(9.975,-4.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],116,-29.7,43.9,3.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_3.setTransform(9.975,-4.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],114.4,-29.4,43.7,5.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_4.setTransform(9.975,-4.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],112.8,-29.2,43.5,6.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_5.setTransform(9.975,-4.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],111.2,-28.9,43.3,7.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_6.setTransform(9.975,-4.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],109.6,-28.6,43.1,8.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_7.setTransform(9.975,-4.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],108,-28.3,42.9,9.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_8.setTransform(9.975,-4.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],106.4,-28.1,42.7,10.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_9.setTransform(9.975,-4.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],104.8,-27.8,42.5,12).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_10.setTransform(9.975,-4.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],103.2,-27.5,42.3,13.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_11.setTransform(9.975,-4.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],101.5,-27.3,42.1,14.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_12.setTransform(9.975,-4.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],99.9,-27,41.9,15.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_13.setTransform(9.975,-4.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],98.3,-26.7,41.7,16.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_14.setTransform(9.975,-4.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],96.7,-26.4,41.5,17.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_15.setTransform(9.975,-4.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],95.1,-26.2,41.3,18.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_16.setTransform(9.975,-4.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],93.4,-25.9,41.1,20.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_17.setTransform(9.975,-4.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],91.8,-25.7,40.9,21.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_18.setTransform(9.975,-4.85);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],90.2,-25.4,40.7,22.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_19.setTransform(9.975,-4.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],88.6,-25.1,40.5,23.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_20.setTransform(9.975,-4.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],87,-24.8,40.3,24.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_21.setTransform(9.975,-4.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],85.4,-24.6,40.1,25.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_22.setTransform(9.975,-4.85);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],83.8,-24.3,39.9,27).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_23.setTransform(9.975,-4.85);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],82.2,-24,39.8,28.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_24.setTransform(9.975,-4.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],80.6,-23.7,39.6,29.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_25.setTransform(9.975,-4.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],79,-23.5,39.4,30.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_26.setTransform(9.975,-4.85);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],77.4,-23.2,39.2,31.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_27.setTransform(9.975,-4.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],75.8,-22.9,39,32.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_28.setTransform(9.975,-4.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],74.2,-22.7,38.8,33.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_29.setTransform(9.975,-4.85);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],72.6,-22.4,38.6,35.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_30.setTransform(9.975,-4.85);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],70.9,-22.1,38.4,36.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_31.setTransform(9.975,-4.85);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],69.3,-21.8,38.2,37.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_32.setTransform(9.975,-4.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],67.7,-21.6,38,38.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_33.setTransform(9.975,-4.85);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],66.1,-21.3,37.8,39.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_34.setTransform(9.975,-4.85);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],64.5,-21.1,37.7,40.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_35.setTransform(9.975,-4.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],62.9,-20.7,37.5,42).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_36.setTransform(9.975,-4.85);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],61.3,-20.5,37.3,43.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_37.setTransform(9.975,-4.85);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],59.7,-20.2,37.1,44.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_38.setTransform(9.975,-4.85);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],58.1,-20,36.9,45.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_39.setTransform(9.975,-4.85);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],56.5,-19.7,36.7,46.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_40.setTransform(9.975,-4.85);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],54.9,-19.4,36.5,47.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_41.setTransform(9.975,-4.85);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],53.3,-19.2,36.3,48.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_42.setTransform(9.975,-4.85);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],51.7,-18.9,36.1,50).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_43.setTransform(9.975,-4.85);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],50,-18.6,35.9,51.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_44.setTransform(9.975,-4.85);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],48.4,-18.3,35.7,52.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_45.setTransform(9.975,-4.85);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],46.8,-18.1,35.5,53.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_46.setTransform(9.975,-4.85);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],45.2,-17.8,35.3,54.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_47.setTransform(9.975,-4.85);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],43.6,-17.5,35.1,55.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_48.setTransform(9.975,-4.85);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],42,-17.2,34.9,57).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_49.setTransform(9.975,-4.85);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],40.4,-17,34.7,58.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_50.setTransform(9.975,-4.85);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],38.7,-16.7,34.5,59.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_51.setTransform(9.975,-4.85);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],37.2,-16.4,34.3,60.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_52.setTransform(9.975,-4.85);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],35.5,-16.2,34.1,61.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_53.setTransform(9.975,-4.85);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],33.9,-15.9,33.9,62.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_54.setTransform(9.975,-4.85);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],32.3,-15.6,33.7,63.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_55.setTransform(9.975,-4.85);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],30.7,-15.3,33.5,65.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_56.setTransform(9.975,-4.85);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],29.1,-15.1,33.3,66.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_57.setTransform(9.975,-4.85);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],27.5,-14.8,33.1,67.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_58.setTransform(9.975,-4.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},75).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[]},1).wait(30));

	// Layer_6
	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],72,-1037.5,-253.6,-596.3).s().p("EgrGgDwMBNtgh2IIgFsMhGVAe6MAlhAc+IiPJpg");
	this.shape_59.setTransform(6.1908,7.1591,0.1766,0.1766,156.0355);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],54.8,159,74.2,64.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_60.setTransform(14.375,16.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],55,155.3,72.9,61.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_61.setTransform(14.375,16.975);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],55.3,151.5,71.7,58.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_62.setTransform(14.375,16.975);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],55.5,147.8,70.5,55).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_63.setTransform(14.375,16.975);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],55.7,144.1,69.2,51.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_64.setTransform(14.375,16.975);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],55.9,140.3,67.9,48.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_65.setTransform(14.375,16.975);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],56.2,136.6,66.7,45.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_66.setTransform(14.375,16.975);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],56.4,132.9,65.4,41.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_67.setTransform(14.375,16.975);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],56.6,129.2,64.2,38.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_68.setTransform(14.375,16.975);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],56.9,125.4,62.9,35.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_69.setTransform(14.375,16.975);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],57.1,121.7,61.7,31.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_70.setTransform(14.375,16.975);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],57.3,118,60.4,28.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_71.setTransform(14.375,16.975);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],57.5,114.3,59.1,25.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_72.setTransform(14.375,16.975);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],57.8,110.5,57.9,22).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_73.setTransform(14.375,16.975);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],57.9,106.8,56.6,18.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_74.setTransform(14.375,16.975);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],58.2,103.1,55.4,15.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_75.setTransform(14.375,16.975);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],58.4,99.3,54.2,12.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_76.setTransform(14.375,16.975);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],58.6,95.6,52.8,8.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_77.setTransform(14.375,16.975);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],58.8,91.9,51.6,5.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_78.setTransform(14.375,16.975);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],59.1,88.2,50.4,2.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_79.setTransform(14.375,16.975);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],59.3,84.4,49.1,-1.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_80.setTransform(14.375,16.975);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],59.5,80.7,47.8,-4.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_81.setTransform(14.375,16.975);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],59.8,77,46.6,-7.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_82.setTransform(14.375,16.975);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],60,73.3,45.3,-10.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_83.setTransform(14.375,16.975);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],60.2,69.5,44.1,-14.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_84.setTransform(14.375,16.975);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],60.4,65.8,42.8,-17.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_85.setTransform(14.375,16.975);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],60.6,62.1,41.6,-20.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_86.setTransform(14.375,16.975);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],60.9,58.4,40.3,-24.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_87.setTransform(14.375,16.975);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],61.1,54.6,39.1,-27.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_88.setTransform(14.375,16.975);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],61.3,50.9,37.8,-30.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_89.setTransform(14.375,16.975);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],61.5,47.2,36.5,-34).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_90.setTransform(14.375,16.975);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],61.8,43.4,35.3,-37.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_91.setTransform(14.375,16.975);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],62,39.7,34,-40.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_92.setTransform(14.375,16.975);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],62.2,36,32.8,-43.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_93.setTransform(14.375,16.975);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],62.4,32.3,31.5,-47.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_94.setTransform(14.375,16.975);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],62.7,28.5,30.3,-50.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_95.setTransform(14.375,16.975);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],62.9,24.8,29,-53.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_96.setTransform(14.375,16.975);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],63.1,21.1,27.7,-57).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_97.setTransform(14.375,16.975);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],63.3,17.4,26.5,-60.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_98.setTransform(14.375,16.975);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],63.5,13.6,25.2,-63.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_99.setTransform(14.375,16.975);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],63.8,9.9,24,-67).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_100.setTransform(14.375,16.975);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],64,6.2,22.7,-70.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_101.setTransform(14.375,16.975);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],64.2,2.5,21.5,-73.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_102.setTransform(14.375,16.975);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],64.5,-1.3,20.2,-76.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_103.setTransform(14.375,16.975);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],64.7,-5,19,-80.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_104.setTransform(14.375,16.975);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],64.9,-8.7,17.7,-83.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_105.setTransform(14.375,16.975);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],65.1,-12.5,16.5,-86.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_106.setTransform(14.375,16.975);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],65.4,-16.2,15.2,-90.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_107.setTransform(14.375,16.975);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],65.5,-19.9,13.9,-93.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_108.setTransform(14.375,16.975);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],65.8,-23.6,12.7,-96.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_109.setTransform(14.375,16.975);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],66,-27.4,11.4,-100).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_110.setTransform(14.375,16.975);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],66.3,-31.1,10.2,-103.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_111.setTransform(14.375,16.975);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],66.5,-34.8,8.9,-106.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_112.setTransform(14.375,16.975);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],66.7,-38.5,7.7,-109.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_113.setTransform(14.375,16.975);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],66.9,-42.3,6.4,-113.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_114.setTransform(14.375,16.975);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],67.1,-46,5.1,-116.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_115.setTransform(14.375,16.975);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],67.4,-49.7,3.9,-119.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_116.setTransform(14.375,16.975);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],67.6,-53.4,2.6,-123).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_117.setTransform(14.375,16.975);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],67.8,-57.2,1.4,-126.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_118.setTransform(14.375,16.975);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-512.2,89.3,-318.7,601.3).s().p("EgrGgDwMBNtgh2IIgFsMhGVAe6MAlhAc+IiPJpg");
	this.shape_119.setTransform(6.1908,7.1591,0.1766,0.1766,156.0355);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_59}]},74).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[]},1).wait(29));

	// Layer_5
	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-100.1,-94.2,-50.5,-35.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_120.setTransform(-3.8,8.425);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-98.6,-92.8,-48.7,-35.5).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_121.setTransform(-3.8,8.425);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-97.1,-91.4,-47,-35.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_122.setTransform(-3.8,8.425);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-95.6,-89.9,-45.2,-35.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_123.setTransform(-3.8,8.425);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-94.1,-88.5,-43.4,-36.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_124.setTransform(-3.8,8.425);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-92.7,-87,-41.7,-36.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_125.setTransform(-3.8,8.425);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-91.2,-85.6,-39.9,-36.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_126.setTransform(-3.8,8.425);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-89.7,-84.2,-38.1,-36.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_127.setTransform(-3.8,8.425);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-88.2,-82.7,-36.3,-36.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_128.setTransform(-3.8,8.425);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-86.7,-81.3,-34.5,-36.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_129.setTransform(-3.8,8.425);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-85.3,-79.9,-32.8,-37.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_130.setTransform(-3.8,8.425);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-83.8,-78.4,-31,-37.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_131.setTransform(-3.8,8.425);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-82.2,-76.9,-29.2,-37.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_132.setTransform(-3.8,8.425);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-80.8,-75.5,-27.4,-37.5).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_133.setTransform(-3.8,8.425);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-79.3,-74.1,-25.7,-37.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_134.setTransform(-3.8,8.425);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-77.8,-72.6,-23.8,-37.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_135.setTransform(-3.8,8.425);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-76.3,-71.2,-22.1,-38.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_136.setTransform(-3.8,8.425);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-74.8,-69.8,-20.3,-38.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_137.setTransform(-3.8,8.425);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-73.4,-68.3,-18.6,-38.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_138.setTransform(-3.8,8.425);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-71.9,-66.9,-16.8,-38.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_139.setTransform(-3.8,8.425);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-70.4,-65.4,-15,-38.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_140.setTransform(-3.8,8.425);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-68.9,-64,-13.2,-38.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_141.setTransform(-3.8,8.425);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-67.4,-62.6,-11.4,-39.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_142.setTransform(-3.8,8.425);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-65.9,-61.1,-9.6,-39.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_143.setTransform(-3.8,8.425);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-64.5,-59.7,-7.9,-39.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_144.setTransform(-3.8,8.425);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-62.9,-58.2,-6.1,-39.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_145.setTransform(-3.8,8.425);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-61.5,-56.8,-4.3,-39.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_146.setTransform(-3.8,8.425);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-60,-55.3,-2.6,-39.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_147.setTransform(-3.8,8.425);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-58.5,-53.9,-0.7,-40.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_148.setTransform(-3.8,8.425);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-57,-52.5,1,-40.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_149.setTransform(-3.8,8.425);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-55.5,-51,2.8,-40.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_150.setTransform(-3.8,8.425);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-54,-49.6,4.6,-40.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_151.setTransform(-3.8,8.425);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-52.6,-48.2,6.3,-40.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_152.setTransform(-3.8,8.425);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-51.1,-46.7,8.1,-40.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_153.setTransform(-3.8,8.425);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-49.6,-45.3,9.9,-41.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_154.setTransform(-3.8,8.425);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-48.1,-43.8,11.7,-41.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_155.setTransform(-3.8,8.425);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-46.6,-42.4,13.5,-41.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_156.setTransform(-3.8,8.425);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-45.2,-41,15.2,-41.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_157.setTransform(-3.8,8.425);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-43.6,-39.5,17,-41.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_158.setTransform(-3.8,8.425);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-42.1,-38.1,18.8,-41.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_159.setTransform(-3.8,8.425);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-40.7,-36.7,20.5,-42.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_160.setTransform(-3.8,8.425);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-39.2,-35.2,22.3,-42.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_161.setTransform(-3.8,8.425);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-37.7,-33.7,24.1,-42.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_162.setTransform(-3.8,8.425);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-36.2,-32.3,25.9,-42.5).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_163.setTransform(-3.8,8.425);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-34.7,-30.9,27.7,-42.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_164.setTransform(-3.8,8.425);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-33.2,-29.4,29.5,-42.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_165.setTransform(-3.8,8.425);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-31.8,-28,31.2,-43.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_166.setTransform(-3.8,8.425);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-30.2,-26.6,33,-43.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_167.setTransform(-3.8,8.425);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-28.8,-25.1,34.8,-43.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_168.setTransform(-3.8,8.425);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-27.3,-23.7,36.6,-43.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_169.setTransform(-3.8,8.425);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-25.8,-22.2,38.4,-43.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_170.setTransform(-3.8,8.425);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-24.3,-20.8,40.1,-43.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_171.setTransform(-3.8,8.425);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-22.8,-19.4,41.9,-44.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_172.setTransform(-3.8,8.425);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-21.3,-17.9,43.7,-44.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_173.setTransform(-3.8,8.425);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-19.9,-16.4,45.4,-44.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_174.setTransform(-3.8,8.425);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-18.4,-15,47.2,-44.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_175.setTransform(-3.8,8.425);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-16.9,-13.6,49,-44.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_176.setTransform(-3.8,8.425);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-15.4,-12.1,50.8,-44.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_177.setTransform(-3.8,8.425);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-13.9,-10.7,52.6,-45.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_178.setTransform(-3.8,8.425);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-12.5,-9.3,54.3,-45.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_179.setTransform(-3.8,8.425);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-10.9,-7.8,56.1,-45.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_180.setTransform(-3.8,8.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_120}]},74).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[]},1).wait(29));

	// Layer_1
	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["#3E7BBE","rgba(62,123,190,0)"],[0.831,0.988],54.6,99.7,261.5,-323.3).s().p("EglBgM6ICwrsMAzKApXMAKYguMIJxkQMgPABDXg");
	this.shape_181.setTransform(5.7381,-18.4206,0.1766,0.1766,156.0355);
	this.shape_181._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_181).wait(39).to({_off:false},0).wait(109).to({_off:true},1).wait(15));

	// Layer_3
	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["#40403F","rgba(64,64,63,0)"],[0.831,0.988],-315.8,-156.7,-237.7,386.8).s().p("EgrGgDwMBNtgh2IIgFsMhGVAe6MAlhAc+IiPJpg");
	this.shape_182.setTransform(6.1908,7.1591,0.1766,0.1766,156.0355);
	this.shape_182._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_182).wait(39).to({_off:false},0).wait(109).to({_off:true},1).wait(15));

	// Layer_2
	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["#969696","rgba(150,150,150,0)"],[0.831,0.973],37.8,84.2,99.1,38.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_183.setTransform(-3.8,8.425);
	this.shape_183._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_183).wait(39).to({_off:false},0).wait(109).to({_off:true},1).wait(15));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.3,-43.1,94.69999999999999,105);


(lib.grSlash = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00B5EB").s().p("AkJHqIGSvTICAAAImSPTg");
	this.shape.setTransform(26.55,48.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,53.1,98);


(lib.grGreater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Aj/C1IF3irIAAgEIl3i9IAAhtIH/ERIAAA7In/D9g");
	this.shape.setTransform(25.6,29.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,51.2,58.5);


(lib.grBracket = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("AAAHVQg0gvAAhYIAAiwQAAg7gXgcQgWgbgugCIAAhSQAugEAWgbQAXgdAAg7IAAisQAAhYA1gxQAzgtBcgCIAABKQhdADAAByIAACsQAAB8hXAbIAAABQBXAbAAB7IAACqQAABBAWAcQAVAcAyABIgCBKQhcgCgygtg");
	this.shape.setTransform(14.425,51.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.9,103.1);


(lib.cubeElement = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16));

	// Layer_1
	this.instance = new lib.Comp1_00000();

	this.instance_1 = new lib.Comp1_00001();

	this.instance_2 = new lib.Comp1_00002();

	this.instance_3 = new lib.Comp1_00003();

	this.instance_4 = new lib.Comp1_00004();

	this.instance_5 = new lib.Comp1_00005();

	this.instance_6 = new lib.Comp1_00006();

	this.instance_7 = new lib.Comp1_00007();

	this.instance_8 = new lib.Comp1_00008();

	this.instance_9 = new lib.Comp1_00009();

	this.instance_10 = new lib.Comp1_00010();

	this.instance_11 = new lib.Comp1_00011();

	this.instance_12 = new lib.Comp1_00012();

	this.instance_13 = new lib.Comp1_00013();

	this.instance_14 = new lib.Comp1_00014();

	this.instance_15 = new lib.Comp1_00015();

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,150,150);


(lib.box_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_5, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D0").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_4, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B9B9B9").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_3, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D0").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_2, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00B5EB").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.box_1, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,300,250), null);


(lib.bar20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglB5IAAjxIBLAAIAADxg");
	this.shape.setTransform(5.0581,16.0285,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar20, new cjs.Rectangle(0,0,10.1,32.1), null);


(lib.bar19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(5.0469,21.4268,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar19, new cjs.Rectangle(0,0,10.1,42.9), null);


(lib.bar18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3178B5").s().p("AglFWIAAqsIBLAAIAAKsg");
	this.shape.setTransform(5.0357,45.3842,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar18, new cjs.Rectangle(0,0,10.1,90.8), null);


(lib.bar17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglHUIAAunIBLAAIAAOng");
	this.shape.setTransform(5.0459,62.0254,1.3259,1.3255);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar17, new cjs.Rectangle(0,0,10.1,124.1), null);


(lib.bar16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AglF6IAArzIBLAAIAALzg");
	this.shape.setTransform(5.0633,50.1453,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar16, new cjs.Rectangle(0,0,10.1,100.3), null);


(lib.bar15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglAxIAAhiIBLAAIAABig");
	this.shape.setTransform(5.052,6.5731,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar15, new cjs.Rectangle(0,0,10.1,13.2), null);


(lib.bar14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AglCxIAAlhIBLAAIAAFhg");
	this.shape.setTransform(5.0397,23.5059,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar14, new cjs.Rectangle(0,0,10.1,47.1), null);


(lib.bar13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglEEIAAoHIBLAAIAAIHg");
	this.shape.setTransform(5.0617,34.4869,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar13, new cjs.Rectangle(0,0,10.2,69), null);


(lib.bar12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3178B5").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(5.0336,8.8028,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar12, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglB5IAAjxIBLAAIAADxg");
	this.shape.setTransform(5.0224,16.0285,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar11, new cjs.Rectangle(0,0,10.1,32.1), null);


(lib.bar10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(5.0612,21.4268,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar10, new cjs.Rectangle(0,0,10.1,42.9), null);


(lib.bar09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AglDuIAAncIBLAAIAAHcg");
	this.shape.setTransform(5.0163,31.62,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar09, new cjs.Rectangle(0,0,10.1,63.3), null);


(lib.bar08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglEFIAAoJIBLAAIAAIJg");
	this.shape.setTransform(5.0893,34.5875,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar08, new cjs.Rectangle(0,0,10.2,69.2), null);


(lib.bar07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3A3A3").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(5.0275,21.4268,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar07, new cjs.Rectangle(0,0,10.1,42.9), null);


(lib.bar06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglB5IAAjxIBLAAIAADxg");
	this.shape.setTransform(5.0163,16.0285,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar06, new cjs.Rectangle(0,0,10.1,32.1), null);


(lib.bar05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3178B5").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(5.0551,8.8028,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar05, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(5.0276,8.8028,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar04, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglAkIAAhHIBLAAIAABHg");
	this.shape.setTransform(5.0327,4.7458,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar03, new cjs.Rectangle(0,0,10.1,9.5), null);


(lib.bar02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3A3A3").s().p("AglAkIAAhHIBLAAIAABHg");
	this.shape.setTransform(5.0551,4.7458,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar02, new cjs.Rectangle(0,0,10.1,9.5), null);


(lib.bar01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AgyAwIAAhfIBkAAIAABfg");
	this.shape.setTransform(5.05,4.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bar01, new cjs.Rectangle(0,0,10.1,9.5), null);


(lib.arrowSub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowSub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designWHITESub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DDDDDD").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designWHITESub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designLBLUESub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#50E6FF").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designLBLUESub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designGREYSub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#939393").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designGREYSub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designBLUESub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D0").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designBLUESub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AguA1IA4g1Ig4g2IARgRIBLBHIhLBIg");
	this.shape.setTransform(8.4813,4.3854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(5.8,0.2,5.3999999999999995,8.4), null);


(lib.aCircle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0675CA").s().p("Ag2A3QgXgXAAggQAAgfAXgXQAXgXAfAAQAgAAAXAXQAWAXAAAfQAAAggWAXQgXAWggAAQgfAAgXgWg");
	this.shape.setTransform(7.75,7.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aCircle, new cjs.Rectangle(0,0,15.5,15.5), null);


(lib.Triangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{setStop:74});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_74 = function() {
		this.stop()
		exportRoot.bannerStart = false
	}
	this.frame_75 = function() {
		exportRoot.bannerStart = true
	}
	this.frame_146 = function() {
		this.gotoAndStop('setStop')
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(74).call(this.frame_74).wait(1).call(this.frame_75).wait(71).call(this.frame_146).wait(3));

	// Layer 1
	this.instance = new lib.impossibleTri("synched",39);
	this.instance.setTransform(234.65,198.85,1,1,0,0,0,0,1.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({startPosition:39},0).wait(110));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(192.3,154.6,94.80000000000001,105.00000000000003);


(lib.StaticData = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Square_1
	this.square_9 = new lib.Square_teal();
	this.square_9.setTransform(713,552);

	this.square_8 = new lib.Square_teal();
	this.square_8.setTransform(303,552);

	this.square_7 = new lib.Square_grey();
	this.square_7.setTransform(303,757);

	this.square_6 = new lib.Square_grey();
	this.square_6.setTransform(303,347);

	this.square_5 = new lib.Square_teal();
	this.square_5.setTransform(508,552);

	this.square_4 = new lib.Square_grey();
	this.square_4.setTransform(508,347);

	this.square_3 = new lib.Square_grey();
	this.square_3.setTransform(713,143);

	this.square_2 = new lib.Square_grey();
	this.square_2.setTransform(508,143);

	this.square_1 = new lib.Square_grey();
	this.square_1.setTransform(303,143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.square_1},{t:this.square_2},{t:this.square_3},{t:this.square_4},{t:this.square_5},{t:this.square_6},{t:this.square_7},{t:this.square_8},{t:this.square_9}]}).wait(1));

	// Square_1
	this.outline_16 = new lib.Square_outline_grey();
	this.outline_16.setTransform(918,757);

	this.outline_15 = new lib.Square_outline_grey();
	this.outline_15.setTransform(713,757);

	this.outline_14 = new lib.Square_outline_grey();
	this.outline_14.setTransform(508,757);

	this.outline_12 = new lib.Square_outline_teal();
	this.outline_12.setTransform(918,552);

	this.outline_8 = new lib.Square_outline_grey();
	this.outline_8.setTransform(918,347);

	this.outline_7 = new lib.Square_outline_grey();
	this.outline_7.setTransform(713,347);

	this.outline_6 = new lib.Square_outline_grey();
	this.outline_6.setTransform(508,347);

	this.outline_4 = new lib.Square_outline_grey();
	this.outline_4.setTransform(918,143);

	this.outline_3 = new lib.Square_outline_grey();
	this.outline_3.setTransform(713,143);

	this.outline_2 = new lib.Square_outline_grey();
	this.outline_2.setTransform(508,143);

	this.outline_1 = new lib.Square_outline_grey();
	this.outline_1.setTransform(303,143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.outline_1},{t:this.outline_2},{t:this.outline_3},{t:this.outline_4},{t:this.outline_6},{t:this.outline_7},{t:this.outline_8},{t:this.outline_12},{t:this.outline_14},{t:this.outline_15},{t:this.outline_16}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.StaticData, new cjs.Rectangle(252.5,92.5,716,715), null);


(lib.Square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Square_8
	this.square_8 = new lib.Square_8();
	this.square_8.setTransform(597,642.2,0.12,0.12,0,0,0,-1.7,332.6);

	this.timeline.addTween(cjs.Tween.get(this.square_8).wait(1));

	// Square_7
	this.square_7 = new lib.Square_7();
	this.square_7.setTransform(597,642.2,0.42,0.42,0,0,0,-1.9,332.3);

	this.timeline.addTween(cjs.Tween.get(this.square_7).wait(1));

	// Square_6
	this.square_6 = new lib.Square_6();
	this.square_6.setTransform(597,642.15,0.6,0.6,0,0,0,-1.9,332.2);

	this.timeline.addTween(cjs.Tween.get(this.square_6).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Square, new cjs.Rectangle(-300,-756,1800,1800), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag3A4QgXgXAAghQAAggAXgXQAXgXAgAAQAhAAAXAXQAXAXAAAgQAAAhgXAXQgXAXghAAQggAAgXgXg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:8.5,regY:4.4,x:4.9,y:0.25},0).wait(1).to({x:4.25},0).wait(1).to({x:3.3},0).wait(1).to({x:2.5},0).wait(1).to({x:2},0).wait(1).to({regX:5.6,regY:4.2,x:-1.05,y:0.05},0).wait(1).to({regX:8.5,regY:4.4,x:1.95,y:0.25},0).wait(1).to({x:2.3},0).wait(1).to({x:2.75},0).wait(1).to({x:3.15},0).wait(1).to({x:3.4},0).wait(1).to({regX:5.6,regY:4.2,x:0.55,y:0.05},0).wait(1).to({regX:8.5,regY:4.4,x:3.45,y:0.25},0).wait(1).to({x:3.3},0).wait(1).to({x:3.15},0).wait(1).to({x:3},0).wait(1).to({x:2.9},0).wait(1).to({regX:5.6,regY:4.2,x:-0.05,y:0.05},0).wait(1).to({regX:8.5,regY:4.4,x:2.9,y:0.25},0).wait(1).to({x:2.95},0).wait(1).to({x:3},0).wait(1).to({x:3.05},0).wait(1).to({regX:5.6,regY:4.2,x:0.15,y:0.05},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.9,-3.9,15.8,8.3);


(lib.mc_SymbolAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(55));

	// greater
	this.instance = new lib.grGreater("synched",0);
	this.instance.setTransform(61.9,48.75,1,1,0,0,0,25.6,29.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({startPosition:0},0).to({regX:25.7,scaleX:1.1,scaleY:1.1,x:61.95,y:48.7},9,cjs.Ease.quadOut).wait(18).to({startPosition:0},0).to({regX:25.6,scaleX:1,scaleY:1,x:61.9,y:48.75},9,cjs.Ease.quadOut).wait(10));

	// slash
	this.instance_1 = new lib.grSlash("synched",0);
	this.instance_1.setTransform(56,49,1,1,0,0,0,26.6,49);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1,x:55.95},9,cjs.Ease.quadOut).wait(18).to({startPosition:0},0).to({scaleX:1,scaleY:1,x:56},9,cjs.Ease.quadOut).wait(4));

	// bracket
	this.instance_2 = new lib.grBracket("synched",0);
	this.instance_2.setTransform(14.4,56.35,1,1,0,0,0,14.4,51.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1,y:56.3},9,cjs.Ease.quadOut).wait(18).to({startPosition:0},0).to({scaleX:1,scaleY:1,y:56.35},9,cjs.Ease.quadOut).wait(16));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-4.9,91.4,117.9);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.c16 = new lib.aCircle();
	this.c16.setTransform(762.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c15 = new lib.aCircle();
	this.c15.setTransform(504.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c14 = new lib.aCircle();
	this.c14.setTransform(254.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c13 = new lib.aCircle();
	this.c13.setTransform(7.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c12 = new lib.aCircle();
	this.c12.setTransform(762.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c11 = new lib.aCircle();
	this.c11.setTransform(504.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c10 = new lib.aCircle();
	this.c10.setTransform(254.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c09 = new lib.aCircle();
	this.c09.setTransform(7.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c08 = new lib.aCircle();
	this.c08.setTransform(762.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c07 = new lib.aCircle();
	this.c07.setTransform(504.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c06 = new lib.aCircle();
	this.c06.setTransform(254.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c05 = new lib.aCircle();
	this.c05.setTransform(7.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c04 = new lib.aCircle();
	this.c04.setTransform(762.8,7.8,1,1,0,0,0,7.8,7.8);

	this.c03 = new lib.aCircle();
	this.c03.setTransform(504.8,7.8,1,1,0,0,0,7.8,7.8);

	this.c02 = new lib.aCircle();
	this.c02.setTransform(254.8,7.8,1,1,0,0,0,7.8,7.8);

	this.c01 = new lib.aCircle();
	this.c01.setTransform(7.8,7.8,1,1,0,0,0,7.8,7.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.c01},{t:this.c02},{t:this.c03},{t:this.c04},{t:this.c05},{t:this.c06},{t:this.c07},{t:this.c08},{t:this.c09},{t:this.c10},{t:this.c11},{t:this.c12},{t:this.c13},{t:this.c14},{t:this.c15},{t:this.c16}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,0,770.5,786.5), null);


(lib.DataBrick = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Square_1
	this.square_9 = new lib.Square_teal();
	this.square_9.setTransform(713,757);

	this.square_8 = new lib.Square_teal();
	this.square_8.setTransform(508,757);

	this.square_7 = new lib.Square_grey();
	this.square_7.setTransform(713,552);

	this.square_6 = new lib.Square_grey();
	this.square_6.setTransform(303,552);

	this.square_5 = new lib.Square_teal();
	this.square_5.setTransform(918,347);

	this.square_4 = new lib.Square_grey();
	this.square_4.setTransform(508,347);

	this.square_3 = new lib.Square_grey();
	this.square_3.setTransform(713,143);

	this.square_2 = new lib.Square_grey();
	this.square_2.setTransform(508,143);

	this.square_1 = new lib.Square_grey();
	this.square_1.setTransform(303,143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.square_1},{t:this.square_2},{t:this.square_3},{t:this.square_4},{t:this.square_5},{t:this.square_6},{t:this.square_7},{t:this.square_8},{t:this.square_9}]}).wait(1));

	// Square_1
	this.outline_16 = new lib.Square_outline_grey();
	this.outline_16.setTransform(918,757);

	this.outline_15 = new lib.Square_outline_grey();
	this.outline_15.setTransform(713,757);

	this.outline_14 = new lib.Square_outline_grey();
	this.outline_14.setTransform(508,757);

	this.outline_13 = new lib.Square_outline_grey();
	this.outline_13.setTransform(303,757);

	this.outline_12 = new lib.Square_outline_teal();
	this.outline_12.setTransform(918,552);

	this.outline_11 = new lib.Square_outline_teal();
	this.outline_11.setTransform(713,552);

	this.outline_10 = new lib.Square_outline_teal();
	this.outline_10.setTransform(508,552);

	this.outline_9 = new lib.Square_outline_teal();
	this.outline_9.setTransform(303,552);

	this.outline_8 = new lib.Square_outline_grey();
	this.outline_8.setTransform(918,347);

	this.outline_7 = new lib.Square_outline_grey();
	this.outline_7.setTransform(713,347);

	this.outline_6 = new lib.Square_outline_grey();
	this.outline_6.setTransform(508,347);

	this.outline_5 = new lib.Square_outline_grey();
	this.outline_5.setTransform(303,347);

	this.outline_4 = new lib.Square_outline_grey();
	this.outline_4.setTransform(918,143);

	this.outline_3 = new lib.Square_outline_grey();
	this.outline_3.setTransform(713,143);

	this.outline_2 = new lib.Square_outline_grey();
	this.outline_2.setTransform(508,143);

	this.outline_1 = new lib.Square_outline_grey();
	this.outline_1.setTransform(303,143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.outline_1},{t:this.outline_2},{t:this.outline_3},{t:this.outline_4},{t:this.outline_5},{t:this.outline_6},{t:this.outline_7},{t:this.outline_8},{t:this.outline_9},{t:this.outline_10},{t:this.outline_11},{t:this.outline_12},{t:this.outline_13},{t:this.outline_14},{t:this.outline_15},{t:this.outline_16}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.DataBrick, new cjs.Rectangle(252.5,92.5,716,715), null);


(lib.cubeAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cu6 = new lib.cubeElement();
	this.cu6.setTransform(20.15,98.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu7 = new lib.cubeElement();
	this.cu7.setTransform(52.55,98.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu5 = new lib.cubeElement();
	this.cu5.setTransform(101.3,70.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu3 = new lib.cubeElement();
	this.cu3.setTransform(36.4,70.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu4 = new lib.cubeElement();
	this.cu4.setTransform(68.8,70.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu2 = new lib.cubeElement();
	this.cu2.setTransform(85.1,42.25,0.28,0.28,0,0,0,75.5,75.7);

	this.cu1 = new lib.cubeElement();
	this.cu1.setTransform(52.95,21.2,0.28,0.28,0,0,0,75.5,75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cu1},{t:this.cu2},{t:this.cu4},{t:this.cu3},{t:this.cu5},{t:this.cu7},{t:this.cu6}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cubeAnim, new cjs.Rectangle(-1,0,123.2,119.1), null);


(lib.Cube = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cubeAnim = new lib.cubeAnim();
	this.cubeAnim.setTransform(202.5,166.5,1,1,0,0,0,22.5,22.5);

	this.timeline.addTween(cjs.Tween.get(this.cubeAnim).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Cube, new cjs.Rectangle(179,144,123.19999999999999,119.10000000000002), null);


(lib.Code = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.symbolAnim = new lib.mc_SymbolAnim();
	this.symbolAnim.setTransform(244.8,193.9,1,1,0,0,0,43.8,53.9);

	this.timeline.addTween(cjs.Tween.get(this.symbolAnim).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Code, new cjs.Rectangle(201,140,87.5,107.9), null);


(lib.Chat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.calloutAnim = new lib.mc_CalloutAnim();
	this.calloutAnim.setTransform(232.1,199.4,1,1,0,0,0,52.1,34.4);

	this.timeline.addTween(cjs.Tween.get(this.calloutAnim).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Chat, new cjs.Rectangle(180,165,104.30000000000001,68.9), null);


(lib.barAnimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.bar01 = new lib.bar01();
	this.bar01.setTransform(5,124,1,1,0,0,0,5,9.5);

	this.bar17 = new lib.bar17();
	this.bar17.setTransform(164.95,124,1,1,0,0,0,5,124.1);

	this.bar20 = new lib.bar20();
	this.bar20.setTransform(194.95,123.95,1,1,0,0,0,5,32);

	this.bar19 = new lib.bar19();
	this.bar19.setTransform(184.95,124.05,1,1,0,0,0,5,42.9);

	this.bar18 = new lib.bar18();
	this.bar18.setTransform(174.95,124,1,1,0,0,0,5,90.8);

	this.bar16 = new lib.bar16();
	this.bar16.setTransform(155,124,1,1,0,0,0,5.1,100.3);

	this.bar15 = new lib.bar15();
	this.bar15.setTransform(145,124.05,1,1,0,0,0,5.1,13.2);

	this.bar14 = new lib.bar14();
	this.bar14.setTransform(135,124.05,1,1,0,0,0,4.9,47.1);

	this.bar13 = new lib.bar13();
	this.bar13.setTransform(125,124,1,1,0,0,0,4.9,69);

	this.bar12 = new lib.bar12();
	this.bar12.setTransform(115.05,124,1,1,0,0,0,4.9,17.6);

	this.bar11 = new lib.bar11();
	this.bar11.setTransform(105.05,123.95,1,1,0,0,0,4.9,32);

	this.bar10 = new lib.bar10();
	this.bar10.setTransform(95,124.05,1,1,0,0,0,4.9,42.9);

	this.bar09 = new lib.bar09();
	this.bar09.setTransform(85,123.95,1,1,0,0,0,4.8,63.2);

	this.bar08 = new lib.bar08();
	this.bar08.setTransform(74.95,124,1,1,0,0,0,5,69.2);

	this.bar07 = new lib.bar07();
	this.bar07.setTransform(65,124.05,1,1,0,0,0,4.9,42.9);

	this.bar06 = new lib.bar06();
	this.bar06.setTransform(55,123.95,1,1,0,0,0,4.9,32);

	this.bar05 = new lib.bar05();
	this.bar05.setTransform(45.05,124,1,1,0,0,0,5,17.6);

	this.bar04 = new lib.bar04();
	this.bar04.setTransform(35,124,1,1,0,0,0,5,17.6);

	this.bar03 = new lib.bar03();
	this.bar03.setTransform(25.05,124,1,1,0,0,0,5,9.5);

	this.bar02 = new lib.bar02();
	this.bar02.setTransform(14.95,124,1,1,0,0,0,5,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bar02},{t:this.bar03},{t:this.bar04},{t:this.bar05},{t:this.bar06},{t:this.bar07},{t:this.bar08},{t:this.bar09},{t:this.bar10},{t:this.bar11},{t:this.bar12},{t:this.bar13},{t:this.bar14},{t:this.bar15},{t:this.bar16},{t:this.bar18},{t:this.bar19},{t:this.bar20},{t:this.bar17},{t:this.bar01}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.barAnimation, new cjs.Rectangle(0,-0.1,200.1,124.1), null);


(lib.Bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.barAnimation = new lib.barAnimation();
	this.barAnimation.setTransform(200,188,1,1,0,0,0,100,62);

	this.timeline.addTween(cjs.Tween.get(this.barAnimation).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Bar, new cjs.Rectangle(100,125.9,200.10000000000002,124.1), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.arrow = new lib.cta_arrowmo();

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowMain, new cjs.Rectangle(-7.9,-7.9,15.8,15.8), null);


(lib.arrow_designWHITE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designWHITESub();
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designWHITE, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designLBLUE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designLBLUESub();
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designLBLUE, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designGREY = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designGREYSub();
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designGREY, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designBLUE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designBLUESub();
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_designBLUE, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_design = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrowSub();
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow_design, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib._3dPlainMov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// box_5
	this.instance = new lib.box_5();
	this.instance.setTransform(-25,259,0.5121,0.9087,0,65.5312,27.4507,0.8,0.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(74).to({_off:false},0).wait(1).to({regX:0,regY:-55.8,scaleY:0.9086,skewX:65.5186,skewY:27.4504,x:21.5,y:237.45},0).wait(1).to({scaleY:0.9084,skewX:65.496,skewY:27.4498},0).wait(1).to({scaleY:0.9081,skewX:65.4627,skewY:27.449,x:21.55,y:237.4},0).wait(1).to({scaleY:0.9077,skewX:65.418,skewY:27.4479},0).wait(1).to({scaleY:0.9071,skewX:65.3612,skewY:27.4464,x:21.6,y:237.3},0).wait(1).to({scaleY:0.9065,skewX:65.2916,skewY:27.4446,x:21.65,y:237.2},0).wait(1).to({scaleX:0.512,scaleY:0.9057,skewX:65.2086,skewY:27.4425,x:21.75,y:237.15},0).wait(1).to({scaleY:0.9048,skewX:65.1114,skewY:27.44,x:21.8,y:237.05},0).wait(1).to({scaleY:0.9037,skewX:64.9997,skewY:27.4372,x:21.9,y:236.95},0).wait(1).to({scaleY:0.9025,skewX:64.873,skewY:27.4339,x:22,y:236.8},0).wait(1).to({scaleY:0.9012,skewX:64.7313,skewY:27.4303,x:22.15,y:236.65},0).wait(1).to({scaleX:0.5119,scaleY:0.8998,skewX:64.5747,skewY:27.4263,x:22.25,y:236.5},0).wait(1).to({scaleY:0.8982,skewX:64.404,skewY:27.422,x:22.4,y:236.35},0).wait(1).to({scaleY:0.8964,skewX:64.2203,skewY:27.4173,x:22.55,y:236.15},0).wait(1).to({scaleX:0.5118,scaleY:0.8946,skewX:64.0252,skewY:27.4123,x:22.7,y:235.95},0).wait(1).to({scaleY:0.8927,skewX:63.8212,skewY:27.4071,x:22.85,y:235.7},0).wait(1).to({scaleY:0.8907,skewX:63.611,skewY:27.4017,x:23,y:235.55},0).wait(1).to({scaleX:0.5117,scaleY:0.8887,skewX:63.3978,skewY:27.3963,x:23.2,y:235.35},0).wait(1).to({scaleY:0.8868,skewX:63.1849,skewY:27.3909,x:23.35,y:235.15},0).wait(1).to({scaleY:0.8848,skewX:62.9755,skewY:27.3855,x:23.55,y:234.9},0).wait(1).to({scaleX:0.5116,scaleY:0.8829,skewX:62.7727,skewY:27.3804,x:23.65,y:234.7},0).wait(1).to({scaleY:0.8811,skewX:62.5789,skewY:27.3754,x:23.85,y:234.55},0).wait(1).to({scaleY:0.8794,skewX:62.3962,skewY:27.3707,x:24,y:234.35},0).wait(1).to({scaleX:0.5115,scaleY:0.8778,skewX:62.2259,skewY:27.3664,x:24.1,y:234.2},0).wait(1).to({scaleY:0.8763,skewX:62.069,skewY:27.3624,x:24.25,y:234.05},0).wait(1).to({scaleY:0.875,skewX:61.9259,skewY:27.3587,x:24.35,y:233.9},0).wait(1).to({scaleY:0.8737,skewX:61.7968,skewY:27.3554,x:24.45,y:233.8},0).wait(1).to({scaleX:0.5114,scaleY:0.8727,skewX:61.6814,skewY:27.3525,x:24.5,y:233.7},0).wait(1).to({scaleY:0.8717,skewX:61.5795,skewY:27.3499,x:24.65,y:233.6},0).wait(1).to({scaleY:0.8709,skewX:61.4905,skewY:27.3476,x:24.7,y:233.5},0).wait(1).to({scaleY:0.8702,skewX:61.4138,skewY:27.3457,x:24.75,y:233.4},0).wait(1).to({scaleY:0.8696,skewX:61.3489,skewY:27.344,x:24.8},0).wait(1).to({regX:0.9,regY:1,scaleY:0.869,skewX:61.2952,skewY:27.3426,x:-18,y:257.15},0).to({_off:true},1).wait(3).to({_off:false,regX:0.8,regY:0.8,scaleY:0.8682,skewX:61.193,skewY:27.338,x:-17.7,y:257},0).to({scaleX:0.5121,scaleY:0.9087,skewX:65.5312,skewY:27.4507,x:-25.5,y:258.5},34,cjs.Ease.quadInOut).wait(1));

	// box_4
	this.instance_1 = new lib.box_4();
	this.instance_1.setTransform(65.55,216.55,0.5121,0.8898,0,103.2269,27.4507,0.8,1);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(74).to({_off:false},0).wait(1).to({regX:0,regY:-55.8,scaleY:0.8895,skewX:103.222,skewY:27.4504,x:114.35,y:227.85},0).wait(1).to({scaleY:0.8891,skewX:103.2131,skewY:27.4498},0).wait(1).to({scaleY:0.8886,skewX:103.2,skewY:27.449,x:114.3,y:227.75},0).wait(1).to({scaleY:0.8878,skewX:103.1825,skewY:27.4478,y:227.65},0).wait(1).to({scaleY:0.8868,skewX:103.1602,skewY:27.4463,x:114.25,y:227.55},0).wait(1).to({scaleY:0.8856,skewX:103.1329,skewY:27.4445,x:114.15,y:227.45},0).wait(1).to({scaleX:0.512,scaleY:0.8842,skewX:103.1003,skewY:27.4424,x:114.1,y:227.3},0).wait(1).to({scaleY:0.8825,skewX:103.0622,skewY:27.4399,x:114,y:227.1},0).wait(1).to({scaleY:0.8806,skewX:103.0183,skewY:27.437,x:113.9,y:226.85},0).wait(1).to({scaleY:0.8784,skewX:102.9686,skewY:27.4337,x:113.8,y:226.65},0).wait(1).to({scaleY:0.8759,skewX:102.913,skewY:27.43,x:113.7,y:226.35},0).wait(1).to({scaleX:0.5119,scaleY:0.8732,skewX:102.8515,skewY:27.426,x:113.55,y:226.05},0).wait(1).to({scaleY:0.8703,skewX:102.7845,skewY:27.4216,x:113.4,y:225.75},0).wait(1).to({scaleY:0.8671,skewX:102.7124,skewY:27.4168,x:113.25,y:225.4},0).wait(1).to({scaleX:0.5118,scaleY:0.8637,skewX:102.6359,skewY:27.4118,x:113.1,y:225},0).wait(1).to({scaleY:0.8602,skewX:102.5558,skewY:27.4065,x:112.9,y:224.65},0).wait(1).to({scaleY:0.8566,skewX:102.4733,skewY:27.401,x:112.7,y:224.2},0).wait(1).to({scaleX:0.5117,scaleY:0.8528,skewX:102.3896,skewY:27.3955,x:112.55,y:223.8},0).wait(1).to({scaleY:0.8492,skewX:102.3061,skewY:27.39,x:112.35,y:223.4},0).wait(1).to({scaleY:0.8456,skewX:102.2239,skewY:27.3846,x:112.15,y:223.05},0).wait(1).to({scaleX:0.5116,scaleY:0.8421,skewX:102.1443,skewY:27.3793,x:112,y:222.65},0).wait(1).to({scaleY:0.8387,skewX:102.0683,skewY:27.3743,x:111.8,y:222.3},0).wait(1).to({scaleY:0.8355,skewX:101.9965,skewY:27.3696,x:111.65,y:221.95},0).wait(1).to({scaleY:0.8326,skewX:101.9297,skewY:27.3652,x:111.5,y:221.6},0).wait(1).to({scaleX:0.5115,scaleY:0.8299,skewX:101.8681,skewY:27.3611,x:111.4,y:221.3},0).wait(1).to({scaleY:0.8274,skewX:101.812,skewY:27.3574,x:111.3,y:221.05},0).wait(1).to({scaleY:0.8252,skewX:101.7613,skewY:27.3541,x:111.2,y:220.85},0).wait(1).to({scaleY:0.8232,skewX:101.716,skewY:27.3511,x:111.1,y:220.6},0).wait(1).to({scaleX:0.5114,scaleY:0.8214,skewX:101.676,skewY:27.3484,x:111,y:220.45},0).wait(1).to({scaleY:0.8199,skewX:101.6411,skewY:27.3461,x:110.9,y:220.25},0).wait(1).to({scaleY:0.8185,skewX:101.611,skewY:27.3441,x:110.85,y:220.1},0).wait(1).to({scaleY:0.8174,skewX:101.5855,skewY:27.3425,x:110.8,y:219.95},0).wait(1).to({regX:0.8,regY:0.9,scaleY:0.8165,skewX:101.5644,skewY:27.3411,x:65.7,y:210.8},0).to({_off:true},1).wait(3).to({_off:false,scaleY:0.8148,skewX:101.5256,x:65.65,y:210.6},0).to({regY:1,scaleX:0.5121,scaleY:0.8898,skewX:103.2269,skewY:27.4507,x:65.55,y:216.55},34,cjs.Ease.quadInOut).wait(1));

	// box_3
	this.instance_2 = new lib.box_3();
	this.instance_2.setTransform(242.3,237.25,0.5024,0.9087,0,65.5312,28.8817,0.8,0.8);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(74).to({_off:false},0).wait(1).to({regX:0,regY:-55.8,scaleY:0.9089,skewX:65.5447,skewY:28.8815,x:288.7,y:215.7},0).wait(1).to({scaleY:0.9093,skewX:65.5689,skewY:28.8812,x:288.75,y:215.65},0).wait(1).to({scaleY:0.9099,skewX:65.6046,skewY:28.8808},0).wait(1).to({scaleY:0.9107,skewX:65.6524,skewY:28.8802,y:215.55},0).wait(1).to({scaleY:0.9117,skewX:65.7132,skewY:28.8795,y:215.5},0).wait(1).to({scaleY:0.9129,skewX:65.7877,skewY:28.8786,y:215.35},0).wait(1).to({scaleY:0.9144,skewX:65.8766,skewY:28.8775,x:288.8,y:215.25},0).wait(1).to({scaleX:0.5023,scaleY:0.9161,skewX:65.9806,skewY:28.8762,x:288.85,y:215.1},0).wait(1).to({scaleY:0.9181,skewX:66.1002,skewY:28.8748,y:214.95},0).wait(1).to({scaleY:0.9203,skewX:66.2358,skewY:28.8731,y:214.75},0).wait(1).to({scaleY:0.9228,skewX:66.3876,skewY:28.8713,x:288.9,y:214.6},0).wait(1).to({scaleX:0.5022,scaleY:0.9256,skewX:66.5552,skewY:28.8693,x:288.95,y:214.35},0).wait(1).to({scaleY:0.9286,skewX:66.738,skewY:28.867,y:214.1},0).wait(1).to({scaleY:0.9318,skewX:66.9347,skewY:28.8646,x:289.05,y:213.85},0).wait(1).to({scaleX:0.5021,scaleY:0.9352,skewX:67.1435,skewY:28.8621,y:213.6},0).wait(1).to({scaleY:0.9388,skewX:67.3619,skewY:28.8595,x:289.1,y:213.3},0).wait(1).to({scaleY:0.9425,skewX:67.5869,skewY:28.8567,x:289.15,y:213},0).wait(1).to({scaleX:0.502,scaleY:0.9462,skewX:67.8152,skewY:28.8539,x:289.2,y:212.7},0).wait(1).to({scaleY:0.95,skewX:68.0431,skewY:28.8512,y:212.45},0).wait(1).to({scaleY:0.9537,skewX:68.2673,skewY:28.8485,x:289.3,y:212.15},0).wait(1).to({scaleX:0.5019,scaleY:0.9573,skewX:68.4844,skewY:28.8458,x:289.35,y:211.85},0).wait(1).to({scaleY:0.9606,skewX:68.6918,skewY:28.8433,y:211.55},0).wait(1).to({scaleY:0.9639,skewX:68.8875,skewY:28.8409,x:289.4,y:211.35},0).wait(1).to({scaleX:0.5018,scaleY:0.9669,skewX:69.0698,skewY:28.8387,x:289.45,y:211.15},0).wait(1).to({scaleY:0.9696,skewX:69.2378,skewY:28.8367,x:289.5,y:210.9},0).wait(1).to({scaleY:0.9722,skewX:69.3909,skewY:28.8348,y:210.7},0).wait(1).to({scaleY:0.9744,skewX:69.5292,skewY:28.8331,x:289.55,y:210.55},0).wait(1).to({scaleX:0.5017,scaleY:0.9765,skewX:69.6527,skewY:28.8316,y:210.4},0).wait(1).to({scaleY:0.9783,skewX:69.7619,skewY:28.8303,y:210.25},0).wait(1).to({scaleY:0.9798,skewX:69.8572,skewY:28.8291,x:289.6,y:210.15},0).wait(1).to({scaleY:0.9812,skewX:69.9392,skewY:28.8281,x:289.65,y:210.05},0).wait(1).to({scaleY:0.9823,skewX:70.0087,skewY:28.8273,x:289.6,y:209.95},0).wait(1).to({regX:0.8,regY:0.8,scaleY:0.9832,skewX:70.0662,skewY:28.8266,x:237.7,y:229.1},0).to({_off:true},1).wait(3).to({_off:false,regX:1,scaleY:0.9851,skewX:70.1751,skewY:28.8258,x:237.65,y:228.9},0).to({regX:0.8,scaleX:0.5024,scaleY:0.9087,skewX:65.5312,skewY:28.8817,x:242.3,y:237.25},34,cjs.Ease.quadInOut).wait(1));

	// box_2
	this.instance_3 = new lib.box_2();
	this.instance_3.setTransform(254.25,196.75,0.5103,0.3619,0,-166.2198,27.8241,1.2,0.2);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(74).to({_off:false},0).wait(1).to({regX:0,regY:-55.8,scaleY:0.362,skewX:-166.2386,skewY:27.824,x:248.85,y:216.05},0).wait(1).to({scaleY:0.3621,skewX:-166.2726,skewY:27.8239,x:248.8},0).wait(1).to({scaleY:0.3623,skewX:-166.3226,skewY:27.8238,x:248.7,y:215.95},0).wait(1).to({scaleY:0.3625,skewX:-166.3897,skewY:27.8237,x:248.65,y:215.85},0).wait(1).to({scaleX:0.5102,scaleY:0.3627,skewX:-166.475,skewY:27.8234,x:248.55,y:215.75},0).wait(1).to({scaleY:0.363,skewX:-166.5794,skewY:27.8232,x:248.45,y:215.55},0).wait(1).to({scaleY:0.3634,skewX:-166.7041,skewY:27.8229,x:248.3,y:215.4},0).wait(1).to({scaleY:0.3638,skewX:-166.8499,skewY:27.8226,x:248.1,y:215.15},0).wait(1).to({scaleY:0.3644,skewX:-167.0176,skewY:27.8222,x:247.9,y:214.95},0).wait(1).to({scaleY:0.3649,skewX:-167.2077,skewY:27.8217,x:247.7,y:214.65},0).wait(1).to({scaleX:0.5101,scaleY:0.3656,skewX:-167.4204,skewY:27.8212,x:247.4,y:214.35},0).wait(1).to({scaleY:0.3663,skewX:-167.6554,skewY:27.8206,x:247.15,y:214},0).wait(1).to({scaleY:0.3671,skewX:-167.9117,skewY:27.82,x:246.8,y:213.7},0).wait(1).to({scaleY:0.3679,skewX:-168.1875,skewY:27.8194,x:246.5,y:213.25},0).wait(1).to({scaleX:0.51,scaleY:0.3688,skewX:-168.4802,skewY:27.8187,x:246.15,y:212.8},0).wait(1).to({scaleY:0.3697,skewX:-168.7865,skewY:27.818,x:245.8,y:212.4},0).wait(1).to({scaleY:0.3707,skewX:-169.102,skewY:27.8172,x:245.4,y:211.95},0).wait(1).to({scaleX:0.5099,scaleY:0.3716,skewX:-169.422,skewY:27.8165,x:245.05,y:211.5},0).wait(1).to({scaleY:0.3726,skewX:-169.7416,skewY:27.8157,x:244.65,y:211},0).wait(1).to({scaleX:0.5098,scaleY:0.3736,skewX:-170.0558,skewY:27.815,x:244.3,y:210.55},0).wait(1).to({scaleY:0.3745,skewX:-170.3603,skewY:27.8142,x:243.9,y:210.1},0).wait(1).to({scaleY:0.3754,skewX:-170.6511,skewY:27.8135,x:243.6,y:209.65},0).wait(1).to({scaleX:0.5097,scaleY:0.3762,skewX:-170.9254,skewY:27.8129,x:243.25,y:209.3},0).wait(1).to({scaleY:0.377,skewX:-171.181,skewY:27.8123,x:243,y:208.95},0).wait(1).to({scaleY:0.3777,skewX:-171.4165,skewY:27.8117,x:242.65,y:208.6},0).wait(1).to({scaleY:0.3783,skewX:-171.6313,skewY:27.8112,x:242.45,y:208.25},0).wait(1).to({scaleX:0.5096,scaleY:0.3789,skewX:-171.8251,skewY:27.8108,x:242.2,y:208},0).wait(1).to({scaleY:0.3794,skewX:-171.9983,skewY:27.8103,x:242,y:207.7},0).wait(1).to({scaleY:0.3799,skewX:-172.1513,skewY:27.81,x:241.8,y:207.5},0).wait(1).to({scaleY:0.3803,skewX:-172.2849,skewY:27.8097,x:241.65,y:207.3},0).wait(1).to({scaleY:0.3807,skewX:-172.3999,skewY:27.8094,x:241.55,y:207.15},0).wait(1).to({scaleY:0.381,skewX:-172.4973,skewY:27.8092,x:241.45,y:206.95},0).wait(1).to({regX:1.2,regY:0.1,scaleY:0.3812,skewX:-172.578,skewY:27.809,x:244.65,y:186},0).to({_off:true},1).wait(3).to({_off:false,scaleY:0.3817,skewX:-172.7284,skewY:27.8097,x:244.4,y:185.65},0).to({regY:0.2,scaleX:0.5103,scaleY:0.3619,skewX:-166.2198,skewY:27.8241,x:254.25,y:196.75},34,cjs.Ease.quadInOut).wait(1));

	// box_1
	this.instance_4 = new lib.box_1();
	this.instance_4.setTransform(161.75,239.25,0.5121,0.9087,0,65.5312,27.4507,0.8,0.8);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(74).to({_off:false},0).wait(1).to({regX:0,regY:-55.8,skewX:65.5273,skewY:27.4504,x:208.15,y:217.7},0).wait(1).to({scaleY:0.9086,skewX:65.5203,skewY:27.4498,x:208.1,y:217.65},0).wait(1).to({scaleY:0.9085,skewX:65.51,skewY:27.449,x:208.05,y:217.55},0).wait(1).to({scaleY:0.9083,skewX:65.4961,skewY:27.4479,x:207.95,y:217.45},0).wait(1).to({scaleY:0.9081,skewX:65.4785,skewY:27.4464,x:207.85,y:217.3},0).wait(1).to({scaleY:0.9078,skewX:65.4569,skewY:27.4446,x:207.7,y:217.15},0).wait(1).to({scaleX:0.512,scaleY:0.9075,skewX:65.4312,skewY:27.4425,x:207.5,y:216.95},0).wait(1).to({scaleY:0.9071,skewX:65.401,skewY:27.44,x:207.3,y:216.7},0).wait(1).to({scaleY:0.9067,skewX:65.3664,skewY:27.4372,x:207.1,y:216.4},0).wait(1).to({scaleY:0.9062,skewX:65.3271,skewY:27.4339,x:206.85,y:216.15},0).wait(1).to({scaleY:0.9056,skewX:65.2832,skewY:27.4303,x:206.55,y:215.75},0).wait(1).to({scaleX:0.5119,scaleY:0.905,skewX:65.2346,skewY:27.4263,x:206.2,y:215.4},0).wait(1).to({scaleY:0.9043,skewX:65.1817,skewY:27.422,x:205.85,y:214.95},0).wait(1).to({scaleY:0.9036,skewX:65.1247,skewY:27.4173,x:205.5,y:214.55},0).wait(1).to({scaleX:0.5118,scaleY:0.9029,skewX:65.0642,skewY:27.4123,x:205.1,y:214.05},0).wait(1).to({scaleY:0.902,skewX:65.0009,skewY:27.4071,x:204.65,y:213.6},0).wait(1).to({scaleY:0.9012,skewX:64.9358,skewY:27.4017,x:204.25,y:213.05},0).wait(1).to({scaleX:0.5117,scaleY:0.9004,skewX:64.8696,skewY:27.3963,x:203.85,y:212.55},0).wait(1).to({scaleY:0.8996,skewX:64.8036,skewY:27.3909,x:203.35,y:212.05},0).wait(1).to({scaleY:0.8987,skewX:64.7387,skewY:27.3855,x:202.95,y:211.55},0).wait(1).to({scaleX:0.5116,scaleY:0.898,skewX:64.6758,skewY:27.3804,x:202.55,y:211},0).wait(1).to({scaleY:0.8972,skewX:64.6157,skewY:27.3754,x:202.15,y:210.6},0).wait(1).to({scaleY:0.8965,skewX:64.5591,skewY:27.3707,x:201.75,y:210.1},0).wait(1).to({scaleX:0.5115,scaleY:0.8958,skewX:64.5063,skewY:27.3664,x:201.4,y:209.75},0).wait(1).to({scaleY:0.8952,skewX:64.4576,skewY:27.3624,x:201.05,y:209.3},0).wait(1).to({scaleY:0.8947,skewX:64.4132,skewY:27.3587,x:200.8,y:209},0).wait(1).to({scaleY:0.8942,skewX:64.3732,skewY:27.3554,x:200.55,y:208.65},0).wait(1).to({scaleX:0.5114,scaleY:0.8937,skewX:64.3374,skewY:27.3525,x:200.3,y:208.4},0).wait(1).to({scaleY:0.8933,skewX:64.3058,skewY:27.3499,x:200.05,y:208.15},0).wait(1).to({scaleY:0.8929,skewX:64.2782,skewY:27.3476,x:199.9,y:207.95},0).wait(1).to({scaleY:0.8927,skewX:64.2544,skewY:27.3457,x:199.75,y:207.75},0).wait(1).to({scaleY:0.8924,skewX:64.2343,skewY:27.344,x:199.6,y:207.6},0).wait(1).to({regX:1,regY:0.8,scaleY:0.8922,skewX:64.2176,skewY:27.3426,x:154.5,y:229.65},0).to({_off:true},1).wait(3).to({_off:false,regX:0.8,scaleY:0.8918,skewX:64.1846,skewY:27.338,x:154.25,y:229.35},0).to({scaleX:0.5121,scaleY:0.9087,skewX:65.5312,skewY:27.4507,x:161.75,y:239.25},34,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.6,135.7,428.40000000000003,157.5);


(lib.Wave = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"setStop":0});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		exportRoot.bannerStart = false
	}
	this.frame_1 = function() {
		exportRoot.bannerStart = true
	}
	this.frame_71 = function() {
		this.gotoAndStop('setStop')
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(70).call(this.frame_71).wait(3));

	// Layer_4
	this.instance = new lib._3dPlainMov("synched",74,false);
	this.instance.setTransform(162.5,211.6,1,1,0,0,0,164.5,216);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:221.6,startPosition:111},34,cjs.Ease.quadInOut).to({y:211.6,startPosition:145},36,cjs.Ease.quadInOut).wait(4));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.6,173.6,428.40000000000003,104.79999999999998);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.setTransform(130.2,30.45,1.4736,1.4736,0,0,0,11,10.5);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AqiCWIAAkrIVFAAIAAErg");
	this.shape.setTransform(67.5,15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,0,135,30), null);


(lib.Arrows = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"setStop":0});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		this.stop()
		exportRoot.bannerStart = false
	}
	this.frame_1 = function() {
		exportRoot.bannerStart = true
	}
	this.frame_72 = function() {
		this.gotoAndStop('setStop')
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(71).call(this.frame_72).wait(20));

	// arrow_design
	this.arr_1 = new lib.arrow_designGREY();
	this.arr_1.setTransform(215.4,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_1).wait(3).to({alpha:0},8).wait(2).to({alpha:1},17).wait(62));

	// arrow_design
	this.arr_2 = new lib.arrow_designWHITE();
	this.arr_2.setTransform(240.85,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.arr_2).wait(3).to({alpha:0},8).wait(8).to({alpha:1},17).wait(56));

	// arrow_design
	this.arr_3 = new lib.arrow_designLBLUE();
	this.arr_3.setTransform(266.25,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_3).wait(3).to({alpha:0},8).wait(14).to({alpha:1},17).wait(50));

	// arrow_design
	this.arr_4 = new lib.arrow_designBLUE();
	this.arr_4.setTransform(266.25,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_4).wait(3).to({alpha:0},8).wait(21).to({alpha:1},17).wait(43));

	// arrow_design
	this.arr_1_1 = new lib.arrow_design();
	this.arr_1_1.setTransform(215.4,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_1_1).wait(92));

	// arrow_design
	this.arr_2_1 = new lib.arrow_design();
	this.arr_2_1.setTransform(240.85,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.arr_2_1).wait(92));

	// arrow_design
	this.arr_3_1 = new lib.arrow_design();
	this.arr_3_1.setTransform(266.25,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_3_1).wait(92));

	// arrow_design
	this.arr_4_1 = new lib.arrow_design();
	this.arr_4_1.setTransform(266.25,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_4_1).wait(92));

	// arrow_design
	this.instance = new lib.arrow_design();
	this.instance.setTransform(291.3,163.2,0.1956,0.1956,90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(92));

	// arrow_design
	this.instance_1 = new lib.arrow_design();
	this.instance_1.setTransform(164.95,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(92));

	// arrow_design
	this.instance_2 = new lib.arrow_design();
	this.instance_2.setTransform(189.95,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(92));

	// arrow_design
	this.instance_3 = new lib.arrow_design();
	this.instance_3.setTransform(189.95,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(92));

	// arrow_design
	this.instance_4 = new lib.arrow_design();
	this.instance_4.setTransform(215.4,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(92));

	// arrow_design
	this.instance_5 = new lib.arrow_design();
	this.instance_5.setTransform(215.4,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(92));

	// arrow_design
	this.instance_6 = new lib.arrow_design();
	this.instance_6.setTransform(240.85,187.75,0.1956,0.1956,180,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(92));

	// arrow_design
	this.instance_7 = new lib.arrow_design();
	this.instance_7.setTransform(240.85,236.35,0.1956,0.1956,0,0,0,0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(92));

	// arrow_design
	this.instance_8 = new lib.arrow_design();
	this.instance_8.setTransform(266.25,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(92));

	// arrow_design
	this.instance_9 = new lib.arrow_design();
	this.instance_9.setTransform(291.3,187.75,0.1956,0.1956,180,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(92));

	// arrow_design
	this.instance_10 = new lib.arrow_design();
	this.instance_10.setTransform(291.3,236.35,0.1956,0.1956,0,0,0,0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(92));

	// arrow_design
	this.instance_11 = new lib.arrow_design();
	this.instance_11.setTransform(291.3,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(92));

	// arrow_design
	this.instance_12 = new lib.arrow_design();
	this.instance_12.setTransform(190.15,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(92));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(156.2,154.5,145.7,92.4);


// stage content:
(lib._300x250 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var firefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
		var windows = navigator.userAgent.toLowerCase().indexOf('windows') > -1;
		var ie = Boolean(navigator.userAgent.indexOf('MSIE')!==-1 || navigator.appVersion.indexOf('Trident/') > -1);
		var edge = navigator.userAgent.toLowerCase().indexOf('edge') > -1;
		if (!(ie || edge) && createjs) {
		//if ((firefox || windows) && createjs) {
		//if (firefox && createjs) {
			createjs.Text.prototype._drawTextLine = function(ctx, text, y) {
				// Adjust text position only if textBaseline is "top"
				if (this.textBaseline === "top") {
					var lineHeight = this.lineHeight || this.getMeasuredLineHeight();
					y += lineHeight * 0.2;
				}
				// Chrome 17 will fail to draw the text if the last param is included but null, so we feed it a large value instead:
				if (this.outline) { ctx.strokeText(text, 0, y, this.maxWidth||0xFFFF); }
				else { ctx.fillText(text, 0, y, this.maxWidth||0xFFFF); }
			};
		}
		var ad = (function(config) {
			var root = config.root;
			var loadedAssets = [], cachedImages = [];
			var loadAssets = function(list, callbackFunction, callbackData){ //loadAssets(list of URLs, callback function)
				if(list && typeof list == 'string') {
					var path = list;
					list = [];
					list.push(path);
				}
				if(list && typeof list == 'object' && list.length) {
					var loadCounter = [];
					var head = document.querySelector('head');
					function loadCheck(e) {
						loadCounter.push(this);
						if(loadCounter.length == list.length) {
							loadCounter.forEach(function(asset) {
								if(asset) {
									var isExistFlag = false;
									if(loadedAssets.length) {
										for(var i = 0; i < loadedAssets.length; i++) {
											var loadedAsset = loadedAssets[i];
											if(loadedAsset && loadedAsset.dataset.url == asset.dataset.url) {
												isExistFlag = true;
												break;
											}
										}
									}
									if(!isExistFlag) {
										loadedAssets.push(asset);
										if(asset.dataset.type == 'image') { cachedImages.push(asset); }
									}
								}
							});
							if(callbackFunction) {
								callbackFunction(loadCounter, callbackData); //This function is called when all the provided assets are loaded properly.
							}
						}
					}
					list.forEach(function(path) {
						var isExistFlag = false;
						if(path && loadedAssets.length) {
							for(var i = 0; i < loadedAssets.length; i++) {
								var loadedAsset = loadedAssets[i];
								if(loadedAsset && loadedAsset.dataset.url == path) {
									isExistFlag = true;
									break;
								}
							}
						}
						if(isExistFlag) {
							loadCheck(loadedAssets[i]);
						}
						else if(path && typeof path == 'string' && path.length && !isExistFlag) {
							if(path.indexOf('.js') > 0) { //For loading JS file
								var script = document.createElement('script');
								script.type = 'text/javascript';
								script.onload = loadCheck;
								script.dataset.type = 'js';
								script.dataset.url = path;
								script.src = path;
								head.appendChild(script);
							} else if(path.indexOf('.css') > 0) { //For loading CSS file
								var style = document.createElement('style');
								style.type = 'text/css';
								style.setAttribute('rel', 'stylesheet');
								style.onload = loadCheck;
								style.dataset.type = 'css';
								style.dataset.url = path;
								style.setAttribute('href', path);
								head.appendChild(style);
							} else {	//For loading Image file
								var image = new Image();
								image.crossOrigin = "Anonymous";
								image.onload = loadCheck;
								image.dataset.type = 'image';
								image.dataset.url = path;
								image.src = path;
							}
						}
					});
				}
			}
			var resetRegistrationPoint = function(instance) {
				if(instance && typeof instance == 'object') {
					instance.x -= instance.regX;
					instance.y -= instance.regY;
					instance.regX = 0;
					instance.regY = 0;
				}
			}
			var setText = function(selector, text, type) { //setText(selector or element, dynamic text, specify type - 'resize' or 'clip' text)
				//var extraSpace = 0;
				type = type && typeof type == 'string' &&  type.length ? type : 'resize';
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(text && text.length && instance && typeof instance == 'object') {
					text = text.split('<br>').join('\n');
					var initialTextHeight = instance.containerHeight || instance.getBounds().height || instance.getMeasuredHeight();
					var initialLineHeight = instance.lineHeight || instance.getMeasuredLineHeight();
					var initialTextWidth = instance.containerWidth || instance.getBounds().width;
					var initialFontSize = parseFloat(instance.font.split(' ').map(function(props){ return props.indexOf('px') > 0 ? (parseFloat(props) - 1) : '' }).join(''));
					instance.text = text;
					if(initialTextHeight < instance.getMeasuredHeight() || initialTextWidth < instance.getBounds().width) {// || initialTextWidth < instance.getMeasuredWidth()
						if(type == 'clip') { //Clip extra text
							for(var i = text.length - 3; i > 0; i--) {
								instance.text = text.slice(0, i) + '...';
								if(initialTextHeight >= instance.getMeasuredHeight()) { break; }
							}
						} else { //Resize text to fit in the container
							var fontSize = parseFloat(instance.font.split(' ').map(function(props){ return props.indexOf('px') > 0 ? (parseFloat(props) - 1) : '' }).join(''))*10;
							if(fontSize && fontSize > 1) {
								for(var i = fontSize; i > 0; i--) {
									instance.font = instance.font.split(' ').map(function(props){ return props.indexOf('px') > 0 ? i/10 + 'px' : props }).join(' ');
									instance.lineHeight = (i/(10*initialFontSize))*initialLineHeight;
									if(initialTextHeight >= instance.getMeasuredHeight()&& initialTextWidth >= instance.getBounds().width) { break; }// && initialTextWidth >= instance.getMeasuredWidth()
								}
							}
						}
						instance.x -= 2;
						instance.y -= 2;
						return true;
					} else if(initialTextHeight > instance.getMeasuredHeight() && (type == 'resize' || type == 'clip')) { //Center align text
						instance.regY = -(initialTextHeight - instance.getMeasuredHeight())/2;
						//extraSpace = (type == 'center' ? (initialLineHeight - initialFontSize)/2 : 0)
						//if(type == 'resize' || type == 'clip') {}
						return false;
					}
					//instance.regY = extraSpace - (initialTextHeight - instance.getMeasuredHeight())/2;
				}
			}
			var setImage = function(selector, imagePath, alignment) { //setImage(selector or element, image path, alignment - 'top left')
				alignment = alignment && typeof alignment == 'string' && alignment.length ? alignment : 'center';
				var addImage = function(image) {
					if(image) {
						var bounds = instance.nominalBounds || instance.getBounds() || instance.getTransformedBounds();
						//var bounds = instance.getTransformedBounds();
						var scale = 1;
						var imageWidth = image.width, imageHeight = image.height;
						var outerWidth = bounds.width, outerHeight = bounds.height;
						if(image.width > bounds.width || image.height > bounds.height) {
							var ratio = bounds.width/image.width;
							ratio = image.height*ratio > bounds.height ? bounds.height/image.height : ratio;
							bitmap.scaleX = bitmap.scaleY = ratio; //scale image to fit the image container
							imageWidth = image.width*ratio, imageHeight = image.height*ratio;
						}
						var xCenter = (outerWidth - imageWidth)/2;
						var yCenter = (outerHeight - imageHeight)/2;
						var xRight = (outerWidth - imageWidth);
						var yBottom = (outerHeight - imageHeight);
						switch(alignment) {	//align image
							case 'center':
							case 'center center':	bitmap.x = xCenter;
													bitmap.y = yCenter;
													break;
							case 'top':
							case 'top center':
							case 'center top': 		bitmap.x = xCenter;
													bitmap.y = 0;
													break;
							case 'left':
							case 'left center':
							case 'center left': 	bitmap.x = 0;
													bitmap.y = yCenter;
													break;
							case 'bottom':
							case 'bottom center':
							case 'center bottom': 	bitmap.x = xCenter;
													bitmap.y = yBottom;
													break;
							case 'right':
							case 'right center':
							case 'center right': 	bitmap.x = xRight;
													bitmap.y = yCenter;
													break;
							case 'top left':
							case 'left top': 		bitmap.x = bitmap.y = 0;
													break;
							case 'top right':
							case 'right top': 		bitmap.x = xRight;
													bitmap.y = 0;
													break;
							case 'bottom left':
							case 'left bottom': 	bitmap.x = 0;
													bitmap.y = yBottom;
													break;
							case 'bottom right':
							case 'right bottom': 	bitmap.x = xRight;
													bitmap.y = yBottom;
													break;
							default: 				bitmap.x = xCenter;
													bitmap.y = yCenter;
						}

						instance.removeAllChildren();
						instance.setBounds(bounds.x, bounds.y, bounds.width, bounds.height);
						instance.addChild(bitmap);
					}
				}
				var bitmap = imagePath && imagePath.length ? new createjs.Bitmap(imagePath) : 0;
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(bitmap && instance && typeof instance == 'object') {
					//var image = loadedAssets.find(function(asset) { return asset.dataset.src == imagePath; });
					var image;
					for(var i = 0; i < loadedAssets.length; i++) {
						if(loadedAssets[i] && loadedAssets[i].dataset.url == imagePath ) { image = loadedAssets[i]; break; }
					}
					if(image) { addImage(image); } else { loadAssets(imagePath, function(images){ addImage(images[0]); }); }
				}
			}
			var addClick = function(selector, url) { //addClick(selector or element, click through Url)
				url = url && typeof url == 'string' && url.length ? url : '';
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(url && instance && typeof instance == 'object') {
					instance.onClickFunction = function(){ window.open(url, '_blank'); }
					instance.addEventListener("click", instance.onClickFunction);
				} else { return false; }
				return true;
			}
			var removeClick = function(selector) { //removeClick(selector or element)
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(instance && typeof instance == 'object' && 'onClickFunction' in instance && instance.onClickFunction) {
					instance.removeEventListener("click", instance.onClickFunction);
				} else { return false; }
				return true;
			}
			return { //exposed parameters and methods
				root: root,
				loadAssets: function(list, callbackFunction) { return loadAssets(list, callbackFunction); },
				resetRegistrationPoint: function(instance) { return resetRegistrationPoint(instance); },
				setText: function(selector, text, type) { return setText(selector, text, type); },
				setImage: function(selector, imagePath, alignment) { return setImage(selector, imagePath, alignment); },
				addClick: function(selector, url){ return addClick(selector, url); }
			}
		})({
			root: this
		});
		createjs.Touch.enable(stage);
		stage.enableMouseOver(10);
		//createjs.Ticker.on("tick", stage);
		// OR
		//createjs.Ticker.addEventListener("tick", stage);
		// OR
		createjs.Ticker.on("tick", tick);
		function tick(event) { stage.update(event); }

		var canvasContainer = document.querySelector('#animation_container');
		if(canvasContainer) { canvasContainer.style.cursor = 'pointer'; }

		function cubeAnimation() {
			var rotationFlag = true;
			var cubes = [];
			for(var i = 1; i < 8; i++) { cubes.push(ad.root.Cube.cubeAnim['cu' + i]); }
			function startAnimation () {
				if(rotationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					var count = 0;
					rotationFlag = false;
					var rollOverTimer = setInterval(function(){
						if(count < cubes.length) { cubes[count].gotoAndPlay(1); }
						else { clearInterval(rollOverTimer); setTimeout(function(){ rotationFlag = true;}, 200); }
						count++;
					}, 80);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Cube.visible = true;
		}

		function barAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					//ad.root.Bar.equilizer.gotoAndPlay(1);
					/*var r1 = 0.6
					var r2 = "-=0.575"

					var r3 = 0.5
					var r4 = "-=0.45"

					exportRoot.tlMO.to(mc.anim.bar_01, r1, {scaleY: Math.floor((Math.random() * 99) + 1)/100,	ease: Power4.easeInOut}, r2);


					exportRoot.tlMO.to(mc.anim.bar_01, r3, {scaleY: 1,	ease: Power4.easeOut});
					exportRoot.tlMO.to(mc.anim.bar_02, r3, {scaleY: 1,	ease: Power4.easeOut}, r4);*/
					for(var i = 1; i<=20; i++) {
						createjs.Tween.get(ad.root.Bar.barAnimation['bar' + ((i > 9 ? '' : '0') + i)], {override:true}).wait(i*25).to({scaleY: Math.floor((Math.random() * 99) + 1)/100}, 600, createjs.Ease.getPowInOut(4));//getPowInOut , createjs.Ease.getPowInOut(4)
					}
					setTimeout(function(){
						for(var i = 1; i<=20; i++) {
							createjs.Tween.get(ad.root.Bar.barAnimation['bar' + ((i > 9 ? '' : '0') + i)], {override:true}).wait(i*50).to({scaleY: 1}, 500, createjs.Ease.getPowOut(4));
						}
					},1000);

					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 2000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Bar.visible = true;
		}

		function waveAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Wave.gotoAndPlay('setStop');
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Wave.visible = true;
		}

		function triangleAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Triangle.gotoAndPlay(75);
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Triangle.visible = true;
		}

		function arrowsAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Arrows.gotoAndPlay('setStop');
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Arrows.visible = true;
		}

		function codeAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Code.symbolAnim.gotoAndPlay(1);
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Code.visible = true;
		}

		function chatAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Chat.calloutAnim.gotoAndPlay(1);
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Chat.visible = true;
		}

		function squareAnimation() {
			var animationFlag = true;
			startAnimation ()
			function startAnimation () {
				if(animationFlag) {
					animationFlag = false;
					exportRoot.tl1 = new TimelineLite();

					//exportRoot.tl1.from(exportRoot.Square.square_2,  2.1, { scaleX:0.6, scaleY:0.6, ease:Power3.easeInOut},"=0")
					//exportRoot.tl1.from(exportRoot.Square.square_3,  2.1, { scaleX:0.42, scaleY:0.42, ease:Power3.easeInOut},"-=2")
					//exportRoot.tl1.from(exportRoot.Square.square_4,  2.1, { scaleX:0.12, scaleY:0.12, ease:Power3.easeInOut},"-=1.85")
					//exportRoot.tl1.from(exportRoot.Square.square_5,  2.1, { scaleX:0, scaleY:0, ease:Power3.easeInOut},"-=1.75")
					exportRoot.tl1.from(exportRoot.Square.square_6,  2.05, { scaleX:0, scaleY:0, ease:Power2.easeInOut},"-=1.75")
					exportRoot.tl1.from(exportRoot.Square.square_7,  2.05, { scaleX:0, scaleY:0, ease:Power2.easeInOut},"-=1.75")
					exportRoot.tl1.from(exportRoot.Square.square_8,  2, { scaleX:0, scaleY:0, ease:Power2.easeInOut,onComplete:function(){animationFlag = true;}},"-=1.75")

				}
			}
			function restartAnimation(){
				exportRoot.tl1.restart(true, false);
			}
			document.querySelector('#canvas').addEventListener('mouseenter', restartAnimation);
			ad.root.Square.visible = true;
		}

		function databrickAnimation(){
			var animationFlag = true;
			startAnimation ()
			function startAnimation () {
				if(animationFlag) {
					animationFlag = false;
					exportRoot.tl1 = new TimelineLite();

					exportRoot.tl1.from(exportRoot.DataBrick.outline_12,  .34, {alpha:0, ease:Power2.easeInOut},"=0")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_7,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_15,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_14,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_4,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_8,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_16,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_11,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_1,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_10,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_13,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_5,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_9,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_2,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_6,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_3,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")

					exportRoot.tl1.from(exportRoot.DataBrick.square_9,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_1,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_3,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_5,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_8,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_7,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_4,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_6,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_2,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")

					exportRoot.tl1.to(exportRoot.DataBrick.square_8,  .34, {y:"551", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_4,  .34, {x:"303", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_7,  .34, {y:"346", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_9,  .34, {x:"508", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_6,  .34, {y:"756", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_8,  .34, {x:"303", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_2,  .34, {y:"346", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_9,  .34, {y:"551", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_5,  .34, {y:"551", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_3,  .34, {x:"508", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_7,  .34, {y:"141", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_5,  .34, {x:"713", ease:Power3.easeInOut},"-=.2")

					exportRoot.tl1.to(exportRoot.DataBrick.outline_12,  .34, {alpha:1, ease:Power2.easeInOut},"+=.5")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_7,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_15,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_14,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_4,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_8,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_16,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")

					exportRoot.tl1.to(exportRoot.DataBrick.square_9,  .34, {alpha:1, ease:Power3.easeInOut},"-=.1")
					exportRoot.tl1.to(exportRoot.DataBrick.square_1,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_2,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_3,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_5,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_8,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_7,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_4,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_6,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")

					exportRoot.tl1.to(exportRoot.DataBrick.outline_11,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_1,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_10,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_13,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_5,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_9,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_2,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_6,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_3,  .34, {alpha:1, ease:Power2.easeInOut,onComplete:function(){animationFlag = true;}},"-=.285");

				}
			}
			function restartAnimation(){
				exportRoot.tl1.restart(true, false);
				ad.root.StaticDataBrick.visible = false;
				ad.root.DataBrick.visible = true;
			}
			document.querySelector('#canvas').addEventListener('mouseenter', restartAnimation);
			ad.root.StaticDataBrick.visible = true;
		}

		function serverlessAnimation(){
			var animationFlag = true;
			var pathStart
			var pathEnd
			var mc = exportRoot.Serverless
			var color = 0xff6600;


			var line = new createjs.Shape();
			mc.addChild(line);

			var coords1
			var serverlessCount = 0;
			var totalcount = 10
			var tl;

			exportRoot.updatePath = function() {

					serverlessCount++;
					if(serverlessCount > totalcount){
						tl.pause();
						return;
					}
					coords1 = 	[
					mc.c01.x, mc.c01.y,   mc.c06.x, mc.c06.y,   mc.c01.x, mc.c01.y,   mc.c07.x, mc.c07.y,   mc.c01.x, mc.c01.y,   mc.c10.x, mc.c10.y,   mc.c01.x, mc.c01.y,   mc.c14.x, mc.c14.y,
					]

					coords2 = 	[
					mc.c06.x, mc.c06.y,   mc.c07.x, mc.c07.y,   mc.c06.x, mc.c06.y,   mc.c09.x, mc.c09.y,   mc.c06.x, mc.c06.y,   mc.c13.x, mc.c13.y,   mc.c06.x, mc.c06.y,   mc.c10.x, mc.c10.y,   mc.c06.x, mc.c06.y,   mc.c15.x, mc.c15.y,   mc.c06.x, mc.c06.y,   mc.c11.x, mc.c11.y,   mc.c06.x, mc.c06.y,   mc.c12.x, mc.c12.y,
					]

					coords3 = 	[
					mc.c10.x, mc.c10.y,   mc.c13.x, mc.c13.y,   mc.c10.x, mc.c10.y,   mc.c14.x, mc.c14.y,   mc.c10.x, mc.c10.y,   mc.c15.x, mc.c15.y,   mc.c10.x, mc.c10.y,   mc.c16.x, mc.c16.y,   mc.c10.x, mc.c10.y,   mc.c11.x, mc.c11.y,
					]

					coords4 = 	[
					mc.c07.x, mc.c07.y,   mc.c08.x, mc.c08.y,   mc.c07.x, mc.c07.y,   mc.c09.x, mc.c09.y,   mc.c07.x, mc.c07.y,   mc.c10.x, mc.c10.y,   mc.c07.x, mc.c07.y,   mc.c14.x, mc.c14.y,   mc.c07.x, mc.c07.y,   mc.c11.x, mc.c11.y,   mc.c07.x, mc.c07.y,   mc.c16.x, mc.c16.y,   mc.c07.x, mc.c07.y,   mc.c12.x, mc.c12.y,
					]

					coords5 = 	[
					mc.c05.x, mc.c05.y,   mc.c06.x, mc.c06.y,   mc.c05.x, mc.c05.y,   mc.c10.x, mc.c10.y,   mc.c05.x, mc.c05.y,   mc.c14.x, mc.c14.y,
					]

					coords6 = 	[
					mc.c08.x, mc.c08.y,   mc.c10.x, mc.c10.y,   mc.c08.x, mc.c08.y,   mc.c11.x, mc.c11.y,   mc.c08.x, mc.c08.y,   mc.c15.x, mc.c15.y,
					]

					coords7 = 	[
					mc.c11.x, mc.c11.y,   mc.c13.x, mc.c13.y,   mc.c11.x, mc.c11.y,   mc.c14.x, mc.c14.y,   mc.c11.x, mc.c11.y,   mc.c15.x, mc.c15.y,   mc.c11.x, mc.c11.y,   mc.c16.x, mc.c16.y,   mc.c11.x, mc.c11.y,   mc.c12.x, mc.c12.y
					]

					coords8 = 	[
					mc.c12.x, mc.c12.y,   mc.c13.x, mc.c13.y,   mc.c12.x, mc.c12.y,   mc.c14.x, mc.c14.y,   mc.c12.x, mc.c12.y,   mc.c15.x, mc.c15.y
					]

					coords9 = 	[
					mc.c04.x, mc.c04.y,   mc.c06.x, mc.c06.y,   mc.c04.x, mc.c04.y,   mc.c09.x, mc.c09.y,   mc.c04.x, mc.c04.y,   mc.c07.x, mc.c07.y,   mc.c04.x, mc.c04.y,   mc.c11.x, mc.c11.y,   mc.c04.x, mc.c04.y,   mc.c15.x, mc.c15.y,
					]

					coords10 = 	[
					mc.c09.x, mc.c09.y,   mc.c10.x, mc.c10.y,   mc.c09.x, mc.c09.y,   mc.c14.x, mc.c14.y,   mc.c09.x, mc.c09.y,   mc.c15.x, mc.c15.y,
					]

					coords11 = 	[
					mc.c02.x, mc.c02.y,   mc.c05.x, mc.c05.y,   mc.c02.x, mc.c02.y,   mc.c09.x, mc.c09.y,   mc.c02.x, mc.c02.y,   mc.c13.x, mc.c13.y,   mc.c02.x, mc.c02.y,   mc.c06.x, mc.c06.y,   mc.c02.x, mc.c02.y,   mc.c11.x, mc.c11.y,   mc.c02.x, mc.c02.y,   mc.c07.x, mc.c07.y,   mc.c02.x, mc.c02.y,   mc.c08.x, mc.c08.y,
					]

					coords12 = 	[
					mc.c03.x, mc.c03.y,   mc.c05.x, mc.c05.y,   mc.c03.x, mc.c03.y,   mc.c06.x, mc.c06.y,   mc.c03.x, mc.c03.y,   mc.c10.x, mc.c10.y,   mc.c03.x, mc.c03.y,   mc.c07.x, mc.c07.y,   mc.c03.x, mc.c03.y,   mc.c16.x, mc.c16.y,   mc.c03.x, mc.c03.y,   mc.c12.x, mc.c12.y,   mc.c03.x, mc.c03.y,   mc.c08.x, mc.c08.y,
					]

					line.graphics.clear()
					line.graphics.setStrokeStyle(1.5);
					line.graphics.beginStroke('#0675CA');

					for (var i = 2; i< coords1.length; i+=2) {
						line.graphics.moveTo(coords1[i-2], coords1[i-1]);
						line.graphics.lineTo(coords1[i], coords1[i+1]);
					}
					for (var i = 2; i< coords2.length; i+=2) {
						line.graphics.moveTo(coords2[i-2], coords2[i-1]);
						line.graphics.lineTo(coords2[i], coords2[i+1]);
					}
					for (var i = 2; i< coords3.length; i+=2) {
						line.graphics.moveTo(coords3[i-2], coords3[i-1]);
						line.graphics.lineTo(coords3[i], coords3[i+1]);
					}
					for (var i = 2; i< coords4.length; i+=2) {
						line.graphics.moveTo(coords4[i-2], coords4[i-1]);
						line.graphics.lineTo(coords4[i], coords4[i+1]);
					}
					for (var i = 2; i< coords5.length; i+=2) {
						line.graphics.moveTo(coords5[i-2], coords5[i-1]);
						line.graphics.lineTo(coords5[i], coords5[i+1]);
					}
					for (var i = 2; i< coords6.length; i+=2) {
						line.graphics.moveTo(coords6[i-2], coords6[i-1]);
						line.graphics.lineTo(coords6[i], coords6[i+1]);
					}
					line.graphic
					for (var i = 2; i< coords7.length; i+=2) {
						line.graphics.moveTo(coords7[i-2], coords7[i-1]);
						line.graphics.lineTo(coords7[i], coords7[i+1]);
					}
					for (var i = 2; i< coords8.length; i+=2) {
						line.graphics.moveTo(coords8[i-2], coords8[i-1]);
						line.graphics.lineTo(coords8[i], coords8[i+1]);
					}
					for (var i = 2; i< coords9.length; i+=2) {
						line.graphics.moveTo(coords9[i-2], coords9[i-1]);
						line.graphics.lineTo(coords9[i], coords9[i+1]);
					}
					for (var i = 2; i< coords10.length; i+=2) {
						line.graphics.moveTo(coords10[i-2], coords10[i-1]);
						line.graphics.lineTo(coords10[i], coords10[i+1]);
					}
					for (var i = 2; i< coords11.length; i+=2) {
						line.graphics.moveTo(coords11[i-2], coords11[i-1]);
						line.graphics.lineTo(coords11[i], coords11[i+1]);
					}
					for (var i = 2; i< coords12.length; i+=2) {
						line.graphics.moveTo(coords12[i-2], coords12[i-1]);
						line.graphics.lineTo(coords12[i], coords12[i+1]);
					}
			}

			TweenMax.delayedCall(0.2,function(){exportRoot.runBanner()})

			ad.root.runBanner = function() {

				tl = new TimelineMax({onUpdate:function(){exportRoot.updatePath()}})
				tl.fromTo(mc.c01, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1})
				tl.fromTo(mc.c05, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=50", y:"-=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c09, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=50", y:"+=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c13, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")

				tl.fromTo(mc.c02, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c06, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=35", y:"+=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c10, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=35", y:"-=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c14, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")

				tl.fromTo(mc.c03, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c07, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=55", y:"+=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c11, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=55", y:"-=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c15, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")

				tl.fromTo(mc.c04, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c08, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=50", y:"-=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c12, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=50", y:"+=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c16, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")

			}

			function startAnimation () {
				serverlessCount = 0;
				totalcount = 200;
				tl.play();
			}

			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Serverless.visible = true;
		}

		function setData(data, cam) {
			data = data && data.length ? data: 0, assets = [];
			if(cam) {
				//ad.setText(ad.root.content.footerText, 'footer' in cam && cam.footer && cam.footer.length ? cam.footer: '');
			}
			if(data) {
				if(data[0].impressionTracker.toLowerCase() != 'na'){
					var impressionTracker = data[0].impressionTracker;
					var isn = 'data' in amo && 'isn' in amo.data ? amo.data.isn : '';
					var trackingCode = 'data' in amo && 'data' in amo.data && 'atsParams' in amo.data.data && 'x2_tracking_code_5' in amo.data.data.atsParams ? amo.data.data.atsParams.x2_tracking_code_5 : '';
					if(isn.length) { impressionTracker = impressionTracker.replace('(t_td_isn)', isn); }
					if(trackingCode.length){ impressionTracker = impressionTracker.replace('$(t_qp_TC_5)', trackingCode); }
					(new Image()).src = impressionTracker;
				}
				data.forEach(function(obj) { /*assets.push(obj.image);*/ assets.push(obj.logo); });
				function addContent(assets) {
					data = data[0];
					ad.root.headlineText.containerWidth = 265;
					ad.root.headlineText.containerHeight = 85;
					if(data['headlineText'].split('|')[1]){
						ad.root.headlineText.font = data['headlineText'].split('|')[1] + 'px Segoe Pro Semibold';
					}
					ad.setText(ad.root.headlineText, data['headlineText'].split('|')[0], 'top');
					if(ad.root.headlineText.getMeasuredHeight() > 60) {
						ad.root.txtCta.y += 20;
						ad.root.cta.y += 20;
					}
					if(data.headlineAlignment) {
						ad.root.headlineText.textAlign = 'right';
						ad.root.headlineText.x += ad.root.headlineText.containerWidth;
					}
					var ctaAligned = ad.setText(ad.root.txtCta.Text, data['ctaText']);
					if(ctaAligned) { ad.root.txtCta.y = ad.root.cta.y + (ad.root.cta.nominalBounds.height - ad.root.txtCta.getBounds().height)/2; }
					ad.setImage(ad.root.logo, data['logo']);
					ad.root.bg.shape.graphics._fill.style = data['backgroundColor'];
					ad.root.headlineText.color = data['textColor'];
					if(data['ctaTextColor']){
						ad.root.txtCta.Text.color = data['ctaTextColor'];
						ad.root.cta.arrow.arrow.instance.shape.graphics._fill.style = data['ctaTextColor'];
					}
					ad.root.cta.shape.graphics._fill.style = data['ctaBackgroundColor'];
					if(ad.root) {
						ad.root.addEventListener("click", function(e) {
							if(e.target.name == 'cta') {
								//amo.onDynAdClick(data.feedData, "CTA_CLICK", data.url);
								//amo.onDynAdClick(data.feedData, data.dataId, data.url);
								amo.onDynAdClick(data.feedData, "CLICK", data.url, data.dataId, (new Date()).getTime());
							} else {
							/*if(e.target.parent.name == 'next' || e.target.parent.name == 'prev') {

							}  else {*/
								//amo.onDynAdClick(data.feedData, "CLICK", data.url);
								//amo.onDynAdClick(data.feedData, data.dataId, data.url);
								amo.onDynAdClick(data.feedData, "CLICK", data.url, data.dataId, (new Date()).getTime());
							}
						});
					}

					ad.root.Cube.visible = false;
					ad.root.Bar.visible = false;
					ad.root.Wave.visible = false;
					ad.root.Triangle.visible = false;
					ad.root.Arrows.visible = false;
					ad.root.Code.visible = false;
					ad.root.Chat.visible = false;
					ad.root.Square.visible = false;
					ad.root.DataBrick.visible = false;
					ad.root.StaticDataBrick.visible = false;
					ad.root.Serverless.visible = false;
					switch(data['animationType'].toLowerCase()) {
						case 'cube': cubeAnimation(); break;
						case 'bar': barAnimation(); break;
						case 'wave': waveAnimation(); break;
						case 'triangle': triangleAnimation(); break;
						case 'arrows': arrowsAnimation(); break;
						case 'code': codeAnimation(); break;
						case 'chat': chatAnimation(); break;
						case 'square': squareAnimation(); break;
						case 'databrick': databrickAnimation(); break;
						case 'serverless': serverlessAnimation(); break;
						default : cubeAnimation();
					}
					ad.root.gotoAndPlay(1);
				}
				if(assets && assets.length) { ad.loadAssets(assets, addContent); } else { addContent(); }


			}
		}
		function loadData() {
			var replaceMacro = function(text, data) {
				if(text.indexOf('!{') != -1 && text.indexOf('}') != -1) {
					text = text.split('!{');
					text = text.map(function(string){
						if(string.indexOf('}') != -1) {
							string = string.split('}');
							for(var key in data) { if(key == string[0]) { string[0] = data[key]; } }
							string = string.join('');
						}
						return string;
					}).join('');
				}
				return text.split('^').join(' ');
			}
			var contentD = [
				{
					"name": "Generic",
					"description": "Launch Apache&#8482; Spark™ clusters in minutes with Azure Databricks",//"Code, experiment, and build your next great web app",
					"passthroughfield1": "Попробуйте Azure бесплатно",//Testez Azure gratuitement//Try Azure free//Teste o Azure gratuitamente
					// "passthroughfield2": "True",
					"passthroughfield5": "RightAlign",
					"product_url": "https://azure.microsoft.com/",
				}
			];
			if(contentD && contentD.length) { contentD.forEach(function(data) { amo.registerContent(data); }); }
			amo.registerVariation("headlineText", "!{description}");
			//amo.registerVariation("logo", "assets/MSAzureLogo_horGr.png");
			amo.registerVariation("logo", "assets/MSAzureLogo_horWh.png");
			amo.registerVariation("animationType", "Serverless");//Cube, Bar, Wave, Triangle, Arrows, Code, Chat, Square, DataBrick, Serverless
			//amo.registerVariation("color", "#ffffff|#000000");
			amo.registerVariation("color", "#505050|#ffffff");
			amo.registerVariation("ctaText", "!{passthroughfield1}");
			// amo.registerVariation("ctaColor", "#000|#fff");
			// amo.registerVariation("ctaArrowVisibleFlag", "!{passthroughfield2}");
			amo.registerVariation("clickURL", "!{product_url}");
			amo.registerVariation("impressionTracker", "https://mscom.demdex.net/event?d_sid=12703198");
			var content = [], cam = {};
			var cam = {
				headlineText: amo.variation['headlineText'],
				logo: amo.variation['logo'],
				animationType: amo.variation['animationType'],
				color: amo.variation['color'],
				cta: amo.variation['ctaText'],
				ctaColor: '#0078D4|#fff',
				// ctaColor: amo.variation['ctaColor'],
				// ctaArrowVisibleFlag: amo.variation['ctaArrowVisibleFlag'],
				url: amo.variation['clickURL'],
				impressionTracker: amo.variation['impressionTracker'],
			};
			if(amo.content && amo.content.length) {
				amo.content.forEach(function(data) {
					content.push({
						feedData: data,
						dataId: cam.color + '|' + cam.animationType,
						headlineText: cam.headlineText,
						headlineAlignment: Boolean(data.passthroughfield5.toLowerCase() == 'rightalign'),
						logo: cam.logo,
						animationType: cam.animationType,
						color: cam.color,
						ctaText: cam.cta,
						ctaBackgroundColor: cam.ctaColor.split('|')[0],
						ctaTextColor: cam.ctaColor.split('|').length>1 ? cam.ctaColor.split('|')[1] : '',
						// ctaArrowVisibleFlag: cam.ctaArrowVisibleFlag.toString().toLowerCase() == 'false' ? false : true,
						ctaArrowVisibleFlag: true,
						url: cam.url,
						impressionTracker: cam.impressionTracker,
					});
				});
				if(content && content.length) {
					content.map(function(data){
						for(var key in data) { data[key] = typeof data[key] == 'string' ? replaceMacro(data[key], data.feedData) : data[key]; }
					});
					content.map(function(data){
						data.textColor = data.color.split('|')[0];
						data.backgroundColor = data.color.split('|')[1];
					});
					document.querySelector('canvas').setAttribute('aria-label','Microsoft Logo   Headline:'+content[0].headlineText+' '+content[0].ctaText)
				}
			}
			setTimeout(function(){ setData(content, cam); }, 2000);
		}
		ad.root.stop();
		loadData();
	}
	this.frame_71 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(71).call(this.frame_71).wait(1));

	// overlay
	this.overlay = new lib.overlay();
	this.overlay.setTransform(140,115,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.overlay).to({alpha:0},11).wait(61));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2.4,1,1).p("A3bzhMAu3AAAMAAAAnDMgu3AAAg");
	this.shape.setTransform(150,125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(80,80,80,0)").s().p("A3bTiMAAAgnDMAu3AAAMAAAAnDg");
	this.shape_1.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(72));

	// MSFT Logo
	this.logo = new lib.logo();
	this.logo.setTransform(69,22.8,1,1,0,0,0,54,7.8);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(72));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.setTransform(16,138);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(72));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.setTransform(15.2,135.4,1,1,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(72));

	// headlineText
	this.headlineText = new cjs.Text("Build intelligent apps faster with analytics and built-in AI with analytics and built-in AI", "20px 'Segoe Pro Semibold'", "#505050");
	this.headlineText.name = "headlineText";
	this.headlineText.lineHeight = 27;
	this.headlineText.lineWidth = 260;
	this.headlineText.parent = this;
	this.headlineText.setTransform(17,55);

	this.timeline.addTween(cjs.Tween.get(this.headlineText).wait(72));

	// Serverless
	this.Serverless = new lib.mainMC();
	this.Serverless.setTransform(246.95,233.55,0.1851,0.1847,-34.7981,0,0,387.8,396.2);

	this.timeline.addTween(cjs.Tween.get(this.Serverless).wait(72));

	// DataBricks
	this.StaticDataBrick = new lib.StaticData();
	this.StaticDataBrick.setTransform(244.8,195.05,0.112,0.1119,0,0,0,611.1,451.2);

	this.DataBrick = new lib.DataBrick();
	this.DataBrick.setTransform(244.75,195.05,0.1118,0.1117,0,0,0,611.6,452.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.DataBrick},{t:this.StaticDataBrick}]}).wait(72));

	// Square
	this.Square = new lib.Square();
	this.Square.setTransform(241.15,154,0.1222,0.1221,0,0,0,602.9,144.6);

	this.timeline.addTween(cjs.Tween.get(this.Square).wait(72));

	// Cube
	this.Cube = new lib.Cube();
	this.Cube.setTransform(241,204,1,1,0,0,0,241,204);

	this.timeline.addTween(cjs.Tween.get(this.Cube).wait(72));

	// Bar
	this.Bar = new lib.Bar();
	this.Bar.setTransform(200,188,1,1,0,0,0,200,188);

	this.timeline.addTween(cjs.Tween.get(this.Bar).wait(72));

	// Triangle
	this.Triangle = new lib.Triangle();
	this.Triangle.setTransform(300,250.2,1,1,0,0,0,300,250.2);

	this.timeline.addTween(cjs.Tween.get(this.Triangle).wait(72));

	// Arrows
	this.Arrows = new lib.Arrows();
	this.Arrows.setTransform(300,250.2,1,1,0,0,0,300,250.2);

	this.timeline.addTween(cjs.Tween.get(this.Arrows).wait(72));

	// Code
	this.Code = new lib.Code();
	this.Code.setTransform(245,194,1,1,0,0,0,245,194);

	this.timeline.addTween(cjs.Tween.get(this.Code).wait(72));

	// Chat
	this.Chat = new lib.Chat();
	this.Chat.setTransform(232,199,1,1,0,0,0,232,199);

	this.timeline.addTween(cjs.Tween.get(this.Chat).wait(72));

	// Wave
	this.Wave = new lib.Wave();
	this.Wave.setTransform(300,250.2,1,1,0,0,0,300,250.2);

	this.timeline.addTween(cjs.Tween.get(this.Wave).wait(72));

	// bg
	this.bg = new lib.bg();
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(72));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(92,115,271.3,218.7);
// library properties:
lib.properties = {
	id: 'F4972F44B4874BF3A9D610527B0A2B56',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/300x250_atlas_P_.png?1574668136043", id:"300x250_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F4972F44B4874BF3A9D610527B0A2B56'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
	var lastW, lastH, lastS=1;
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas();
	function resizeCanvas() {
		var w = lib.properties.width, h = lib.properties.height;
		var iw = window.innerWidth, ih=window.innerHeight;
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
		if(isResp) {
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
				sRatio = lastS;
			}
			else if(!isScale) {
				if(iw<w || ih<h)
					sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==1) {
				sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==2) {
				sRatio = Math.max(xRatio, yRatio);
			}
		}
		domContainers[0].width = w * pRatio * sRatio;
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {
			container.style.width = w * sRatio + 'px';
			container.style.height = h * sRatio + 'px';
		});
		stage.scaleX = pRatio*sRatio;
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;
		stage.tickOnUpdate = false;
		stage.update();
		stage.tickOnUpdate = true;
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
