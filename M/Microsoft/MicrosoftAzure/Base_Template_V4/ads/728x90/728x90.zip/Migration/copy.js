// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#000000>Migrate your on-premises workloads|to the cloud with confidence","16px",190, 14,"19","350", "left"];

	bannerData.CTA = ["<#0078D3>Try Azure free","12.3px",0,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
