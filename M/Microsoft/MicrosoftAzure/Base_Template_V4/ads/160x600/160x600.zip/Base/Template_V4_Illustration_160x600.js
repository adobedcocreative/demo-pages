(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4Migration160x600F4 = function() {
	this.initialize(img._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4Migration160x600F4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,1200);


(lib._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4MigrationF1 = function() {
	this.initialize(img._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4MigrationF1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,320,1200);


(lib.Microsoftlogo_rgb_cgray1 = function() {
	this.initialize(img.Microsoftlogo_rgb_cgray1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,224,32);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.tileShadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0)","#000000","#000000","rgba(0,0,0,0)"],[0,0.153,0.871,1],0,101.2,0,-101.3).s().p("Egu3APoIAA/PMBdvAAAIAAfPg");
	this.shape.setTransform(300,100);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tileShadow, new cjs.Rectangle(-11,-6,611,266), null);


(lib.shadow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Egu3AXcMAAAgu3MBdvAAAMAAAAu3g");
	this.shape.setTransform(300,150);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(0,0,600,300), null);


(lib.screen2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4Migration160x600F4();
	this.instance.setTransform(0.55,1.55);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screen2, new cjs.Rectangle(0.6,1.6,320,1200), null);


(lib.cta = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.logo2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Microsoftlogo_rgb_cgray1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo2, new cjs.Rectangle(0,0,224,32), null);


(lib.cta_glare = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.arrowSubSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#0078D3").ss(1.5,0,0,3).p("AgihAIBABAIhABB");
	this.shape.setTransform(3.4902,6.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowSubSub, new cjs.Rectangle(-1,-1,8.5,14.9), null);


(lib.screentrans2Tile2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.shadow();
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:0.7109},13).to({_off:true},1).wait(14));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D3").s().p("Egu3AXcMAAAgu3MBdvAAAMAAAAu3g");
	this.shape.setTransform(300,150);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13).to({_off:true},1).wait(14));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600,300);


(lib.screentrans1Tile = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_3
	this.instance = new lib.shadow();
	this.instance.setTransform(300,0,1,1,0,0,0,300,0);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(13).to({_off:false},0).to({alpha:0.4648},13).to({_off:true},1).wait(1));

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D3").s().p("Egu3AXcMAAAgu3MBdvAAAMAAAAu3g");
	this.shape.setTransform(300,150);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(13).to({_off:false},0).wait(13).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600,300);


(lib.screen1Tile = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_4
	this.instance = new lib.shadow();
	this.instance.setTransform(150,125,1,1,0,0,0,150,125);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({alpha:0.418},15).to({_off:true},1).wait(3));

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Egu3AXcMAAAgu3MBdvAAAMAAAAu3g");
	var mask_graphics_16 = new cjs.Graphics().p("Egu3AXcMAAAgu3MBdvAAAMAAAAu3g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:300,y:150}).wait(16).to({graphics:mask_graphics_16,x:300,y:150}).wait(1).to({graphics:null,x:0,y:0}).wait(3));

	// Layer_1
	this.instance_1 = new lib._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4MigrationF1();

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(16).to({_off:true},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600,300);


(lib.screen1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_98 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(98).call(this.frame_98).wait(4));

	// Layer_2
	this.instance = new lib._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4MigrationF1();

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},1).wait(101));

	// tile3
	this.instance_1 = new lib.screentrans2Tile2("synched",0,false);
	this.instance_1.setTransform(300,1200,1,1,0,180,0,300,0);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(82).to({_off:false},0).to({scaleY:0.032,startPosition:13},13).to({_off:true},1).wait(6));

	// tile3
	this.instance_2 = new lib.screentrans1Tile("synched",13,false);
	this.instance_2.setTransform(300,900,1,0.0387,0,0,0,300,0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(69).to({_off:false},0).to({scaleY:1,startPosition:26},13,cjs.Ease.cubicOut).to({_off:true},1).wait(19));

	// tile2
	this.instance_3 = new lib.screentrans2Tile2("synched",0,false);
	this.instance_3.setTransform(300,900,1,1,0,180,0,300,0);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(56).to({_off:false},0).to({scaleY:0.032,startPosition:13},13).to({_off:true},1).wait(32));

	// tile2
	this.instance_4 = new lib.screentrans1Tile("synched",13,false);
	this.instance_4.setTransform(300,600,1,0.0387,0,0,0,300,0);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(43).to({_off:false},0).to({scaleY:1,startPosition:26},13,cjs.Ease.cubicOut).to({_off:true},1).wait(45));

	// tile1
	this.instance_5 = new lib.screentrans2Tile2("synched",0,false);
	this.instance_5.setTransform(300,600,1,1,0,180,0,300,0);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(30).to({_off:false},0).to({scaleY:0.032,startPosition:13},13).to({_off:true},1).wait(58));

	// tile1
	this.instance_6 = new lib.screentrans1Tile("synched",13,false);
	this.instance_6.setTransform(300,300,1,0.0387,0,0,0,300,0);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(17).to({_off:false},0).to({scaleY:1,startPosition:26},13,cjs.Ease.cubicOut).to({_off:true},1).wait(71));

	// tile1
	this.instance_7 = new lib.screen1Tile("single",0);
	this.instance_7.setTransform(150,250,1,1,0,0,0,150,250);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({regX:320.1,regY:302.2,x:320.1,y:302.2,mode:"synched",loop:false},1).to({regY:302,scaleY:0.0187,startPosition:16},16).to({_off:true},1).wait(84));

	// Layer_16
	this.instance_8 = new lib.tileShadow();
	this.instance_8.setTransform(150,899,1,0.016,0,0,0,150,0);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(56).to({_off:false},0).wait(1).to({regX:300,regY:100,scaleY:0.0165,x:300,y:900.65,alpha:0.0002},0).wait(1).to({scaleY:0.018,y:900.8,alpha:0.001},0).wait(1).to({scaleY:0.0207,y:901.05,alpha:0.0024},0).wait(1).to({scaleY:0.0249,y:901.5,alpha:0.0045},0).wait(1).to({scaleY:0.0307,y:902.1,alpha:0.0075},0).wait(1).to({scaleY:0.0387,y:902.95,alpha:0.0116},0).wait(1).to({scaleY:0.0494,y:904.1,alpha:0.017},0).wait(1).to({scaleY:0.0637,y:905.6,alpha:0.0243},0).wait(1).to({scaleY:0.0829,y:907.65,alpha:0.0341},0).wait(1).to({scaleY:0.1096,y:910.4,alpha:0.0477},0).wait(1).to({scaleY:0.1491,y:914.6,alpha:0.0679},0).wait(1).to({scaleY:0.2171,y:921.75,alpha:0.1025},0).wait(1).to({regX:150,regY:0,scaleY:0.3914,x:150,y:901,alpha:0.1914},0).wait(1).to({regX:300,regY:100,scaleY:0.6693,x:300,y:967.45,alpha:0.3323},0).wait(1).to({scaleY:0.7783,y:978.2,alpha:0.3876},0).wait(1).to({scaleY:0.8432,y:984.55,alpha:0.4205},0).wait(1).to({scaleY:0.8874,y:988.9,alpha:0.4429},0).wait(1).to({scaleY:0.9195,y:992.05,alpha:0.4592},0).wait(1).to({scaleY:0.9435,y:994.4,alpha:0.4713},0).wait(1).to({scaleY:0.9615,y:996.2,alpha:0.4805},0).wait(1).to({scaleY:0.975,y:997.5,alpha:0.4873},0).wait(1).to({scaleY:0.985,y:998.5,alpha:0.4924},0).wait(1).to({scaleY:0.992,y:999.2,alpha:0.4959},0).wait(1).to({scaleY:0.9966,y:999.65,alpha:0.4983},0).wait(1).to({scaleY:0.9992,y:999.9,alpha:0.4996},0).wait(1).to({regX:150,regY:0,scaleY:1,x:150,y:900,alpha:0.5},0).to({_off:true},1).wait(19));

	// Layer_15
	this.instance_9 = new lib.tileShadow();
	this.instance_9.setTransform(150,599,1,0.016,0,0,0,150,0);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(30).to({_off:false},0).wait(1).to({regX:300,regY:100,scaleY:0.0165,x:300,y:600.65,alpha:0.0002},0).wait(1).to({scaleY:0.018,y:600.8,alpha:0.001},0).wait(1).to({scaleY:0.0207,y:601.05,alpha:0.0024},0).wait(1).to({scaleY:0.0249,y:601.5,alpha:0.0045},0).wait(1).to({scaleY:0.0307,y:602.1,alpha:0.0075},0).wait(1).to({scaleY:0.0387,y:602.95,alpha:0.0116},0).wait(1).to({scaleY:0.0494,y:604.1,alpha:0.017},0).wait(1).to({scaleY:0.0637,y:605.6,alpha:0.0243},0).wait(1).to({scaleY:0.0829,y:607.65,alpha:0.0341},0).wait(1).to({scaleY:0.1096,y:610.4,alpha:0.0477},0).wait(1).to({scaleY:0.1491,y:614.6,alpha:0.0679},0).wait(1).to({scaleY:0.2171,y:621.75,alpha:0.1025},0).wait(1).to({regX:150,regY:0,scaleY:0.3914,x:150,y:601,alpha:0.1914},0).wait(1).to({regX:300,regY:100,scaleY:0.6693,x:300,y:667.45,alpha:0.3323},0).wait(1).to({scaleY:0.7783,y:678.2,alpha:0.3876},0).wait(1).to({scaleY:0.8432,y:684.55,alpha:0.4205},0).wait(1).to({scaleY:0.8874,y:688.9,alpha:0.4429},0).wait(1).to({scaleY:0.9195,y:692.05,alpha:0.4592},0).wait(1).to({scaleY:0.9435,y:694.4,alpha:0.4713},0).wait(1).to({scaleY:0.9615,y:696.2,alpha:0.4805},0).wait(1).to({scaleY:0.975,y:697.5,alpha:0.4873},0).wait(1).to({scaleY:0.985,y:698.5,alpha:0.4924},0).wait(1).to({scaleY:0.992,y:699.2,alpha:0.4959},0).wait(1).to({scaleY:0.9966,y:699.65,alpha:0.4983},0).wait(1).to({scaleY:0.9992,y:699.9,alpha:0.4996},0).wait(1).to({regX:150,regY:0,scaleY:1,x:150,y:600,alpha:0.5},0).to({_off:true},1).wait(45));

	// Layer_14
	this.instance_10 = new lib.tileShadow();
	this.instance_10.setTransform(150,299,1,0.016,0,0,0,150,0);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(1).to({_off:false},0).wait(1).to({regX:300,regY:100,scaleY:0.0163,x:300,y:300.65,alpha:0.0002},0).wait(1).to({scaleY:0.0173,y:300.75,alpha:0.0007},0).wait(1).to({scaleY:0.019,y:300.9,alpha:0.0015},0).wait(1).to({scaleY:0.0216,y:301.15,alpha:0.0029},0).wait(1).to({scaleY:0.0252,y:301.5,alpha:0.0047},0).wait(1).to({scaleY:0.0299,y:302.05,alpha:0.0071},0).wait(1).to({scaleY:0.036,y:302.7,alpha:0.0102},0).wait(1).to({scaleY:0.0437,y:303.45,alpha:0.0141},0).wait(1).to({scaleY:0.0534,y:304.5,alpha:0.0191},0).wait(1).to({scaleY:0.0658,y:305.85,alpha:0.0254},0).wait(1).to({scaleY:0.0815,y:307.45,alpha:0.0334},0).wait(1).to({scaleY:0.102,y:309.65,alpha:0.0438},0).wait(1).to({scaleY:0.1296,y:312.55,alpha:0.0579},0).wait(1).to({scaleY:0.1696,y:316.75,alpha:0.0783},0).wait(1).to({scaleY:0.2368,y:323.85,alpha:0.1126},0).wait(1).to({regX:150,regY:0,scaleY:0.3914,x:150,y:301,alpha:0.1914},0).wait(1).to({regX:300,regY:100,scaleY:0.6693,x:300,y:367.45,alpha:0.3323},0).wait(1).to({scaleY:0.7783,y:378.2,alpha:0.3876},0).wait(1).to({scaleY:0.8432,y:384.55,alpha:0.4205},0).wait(1).to({scaleY:0.8874,y:388.9,alpha:0.4429},0).wait(1).to({scaleY:0.9195,y:392.05,alpha:0.4592},0).wait(1).to({scaleY:0.9435,y:394.4,alpha:0.4713},0).wait(1).to({scaleY:0.9615,y:396.2,alpha:0.4805},0).wait(1).to({scaleY:0.975,y:397.5,alpha:0.4873},0).wait(1).to({scaleY:0.985,y:398.5,alpha:0.4924},0).wait(1).to({scaleY:0.992,y:399.2,alpha:0.4959},0).wait(1).to({scaleY:0.9966,y:399.65,alpha:0.4983},0).wait(1).to({scaleY:0.9992,y:399.9,alpha:0.4996},0).wait(1).to({regX:150,regY:0,scaleY:1,x:150,y:300,alpha:0.5},0).to({_off:true},1).wait(71));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Egu3BdwMAAAi7fMBdvAAAMAAAC7fg");
	var mask_graphics_1 = new cjs.Graphics().p("Egu3B1KMAAAi7gMBdvAAAMAAAC7gg");
	var mask_graphics_30 = new cjs.Graphics().p("Egu3CMmMAAAi7gMBdvAAAMAAAC7gg");
	var mask_graphics_56 = new cjs.Graphics().p("Egu3CkCMAAAi7gMBdvAAAMAAAC7gg");
	var mask_graphics_82 = new cjs.Graphics().p("Egu3CkCMAAAi7gMBdvAAAMAAAC7gg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:300.025,y:600}).wait(1).to({graphics:mask_graphics_1,x:300.0296,y:749.7592}).wait(29).to({graphics:mask_graphics_30,x:300.0296,y:899.7592}).wait(26).to({graphics:mask_graphics_56,x:300.0296,y:1049.7592}).wait(26).to({graphics:mask_graphics_82,x:300.0296,y:1049.7592}).wait(1).to({graphics:null,x:0,y:0}).wait(19));

	// oldBG
	this.instance_11 = new lib._086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4MigrationF1();

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).to({_off:true},83).wait(19));

	// logo2
	this.instance_12 = new lib.logo2();
	this.instance_12.setTransform(145,48,1,1,0,0,0,113,16);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).to({_off:true},101).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,600.1,1200);


(lib.arrowSub = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.arrowSubSub = new lib.arrowSubSub();
	this.arrowSubSub.name = "arrowSubSub";
	this.arrowSubSub.setTransform(3.4,6.5,1,1,0,0,0,3.4,6.5);

	this.timeline.addTween(cjs.Tween.get(this.arrowSubSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrowSub, new cjs.Rectangle(-0.7,-0.7,8.2,14.399999999999999), null);


(lib.arrow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_2
	this.arrowSub = new lib.arrowSub();
	this.arrowSub.name = "arrowSub";
	this.arrowSub.setTransform(7.45,4.2,1,1,0,0,0,3.4,6.5);

	this.timeline.addTween(cjs.Tween.get(this.arrowSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(3.3,-3,8.3,14.4), null);


(lib.cta_arrowmo = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.arrow2 = new lib.arrow();
	this.arrow2.name = "arrow2";
	this.arrow2.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.arrow2.alpha = 0;

	var maskedShapeInstanceList = [this.arrow2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.arrow2).wait(12).to({alpha:1},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:7.5,x:3.9},0).wait(1).to({x:3.25},0).wait(1).to({x:2.3},0).wait(1).to({x:1.5},0).wait(1).to({x:1},0).wait(1).to({regX:5.6,x:-1.05},0).wait(1).to({regX:7.5,x:0.95},0).wait(1).to({x:1.3},0).wait(1).to({x:1.75},0).wait(1).to({x:2.15},0).wait(1).to({x:2.4},0).wait(1).to({regX:5.6,x:0.55},0).wait(1).to({regX:7.5,x:2.45},0).wait(1).to({x:2.3},0).wait(1).to({x:2.15},0).wait(1).to({x:2},0).wait(1).to({x:1.9},0).wait(1).to({regX:5.6,x:-0.05},0).wait(1).to({regX:7.5,x:1.9},0).wait(1).to({x:1.95},0).wait(1).to({x:2},0).wait(1).to({x:2.05},0).wait(1).to({regX:5.6,x:0.15},0).wait(10));

	// Layer 2
	this.arrow1 = new lib.arrow();
	this.arrow1.name = "arrow1";
	this.arrow1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.arrow1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.arrow1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).wait(1).to({alpha:0},0).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-7.4,20.5,14.9);


(lib.arrowMain = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		this.arrow.visible=false;
		this.arrowStatic.visible=true;
	}
	this.frame_1 = function() {
		this.stop();
		this.arrow.visible=true;
		this.arrowStatic.visible=false;
		this.arrow.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// mouseOverAnimation
	this.arrow = new lib.cta_arrowmo();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(2));

	// staticArrow
	this.arrowStatic = new lib.arrow();
	this.arrowStatic.name = "arrowStatic";
	this.arrowStatic.setTransform(5.35,6.6);

	this.timeline.addTween(cjs.Tween.get(this.arrowStatic).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.7,0.5,30.7,20.5);


(lib.CTA_btn = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-4.5,1.95,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-51.4,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(51,51,51,0)").s().p("Ao7CWIAAkrIR3AAIAAErg");
	this.shape.setTransform(-55.025,1.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-112.2,-13,114.4,30), null);


(lib.mainMC = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// screen1
	this.screen1 = new lib.screen1();
	this.screen1.name = "screen1";
	this.screen1.setTransform(150,125,0.5,0.5,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.screen1).wait(1));

	// txt
	this.txt = new lib.txt_mc();
	this.txt.name = "txt";
	this.txt.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// txtCta
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(78.45,583.15,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// cta
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(131,581.3,1.1404,1.1404,0,0,0,0.2,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// screen2
	this.instance = new lib.screen2();
	this.instance.setTransform(150,125,0.5,0.5,0,0,0,300,250);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,0,300.1,600.8), null);


// stage content:
(lib.Template_V4_Illustration_160x600 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"

		this.initBanner = function (data) {

			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;

			Object.keys = function(obj) {
				var keys = [];

				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)

				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}

		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}

		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			var ctaArrowColor = new Array()

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					ctaArrowColor.push(aSentenceLine[i][j].color);
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}

				//console.log("color"+ctaArrowColor[0]);

				this.mainMC.cta.arrow.arrowStatic.arrowSub.cache(0,0,50,50,2);
				this.mainMC.cta.arrow.arrow.arrow1.arrowSub.cache(0,0,50,50,2);
				this.mainMC.cta.arrow.arrow.arrow2.arrowSub.cache(0,0,50,50,2);

				gsap.to(this.mainMC.cta.arrow.arrowStatic.arrowSub, 0, {easel: {tint: ctaArrowColor[0], tintAmount: 1}});
				gsap.to(this.mainMC.cta.arrow.arrow.arrow1.arrowSub, 0, {easel: {tint: ctaArrowColor[0], tintAmount: 1}});
				gsap.to(this.mainMC.cta.arrow.arrow.arrow2.arrowSub, 0, {easel: {tint: ctaArrowColor[0], tintAmount: 1}});


		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}

		var mc = exportRoot.mainMC;

		//mc.cta.alpha = 0;

		this.runBanner = function() {

				mc.cta.alpha = 1;

				this.tlText = gsap.timeline({defaults: {ease:Power4.easeOut}});

				gsap.delayedCall(1, function(){mc.screen1.play();});
				/*this.tlText.from(exportRoot.headline1,{
					duration:0.8,
					x: "-=250", alpha: 0,
					stagger:0.1
				}, "-=2");*/

				//this.tlText.from(mc.cta, { duration: 0.6, x: "-=150"}, "-=1.4");
				//this.tlText.from(mc.txtCta, { duration: 0.6, x: "-=150"}, "-=1.4");

		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,0.9981,0.9987,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(80,300,219.5,300);
var adSize = '160x600';
var logoImage = 'Microsoftlogo_rgb_cgray1.png';
var frameImage1 = 'Illustration_Migration/' + adSize + '_Illustration_Migration_F1.png';
var frameImage2 = 'Illustration_Migration/' + adSize + 'Illustration_Migration_F2.png';
var iframe = window.frameElement;
var parentWindow = iframe.contentWindow.parent ? iframe.contentWindow.parent  : iframe.contentWindow;
var bannerData = parentWindow.getBannerData();
var layout = bannerData.layout;
if(layout) {
	switch (layout) {
		case 'Illustration_AI' :
		case 'Illustration_HybridCloud' :
		case 'Illustration_MachineLearning' :
		case 'Illustration_Migration' :
		case 'Illustration_OpenSource' :
		case 'Lifestyle_Male' :
		case 'Lifestyle_Female' :
		case 'UI_AI' :
		case 'UI_FreeAccount' :
		case 'UI_HybridCloud' :
		case 'UI_MachineLearning' :
		case 'UI_Migration' :
		case 'UI_OpenSource' : frameImage1 = layout+'/' + adSize + '_' + layout + '_F1.png';frameImage2 = layout+'/' + adSize + '_' + layout + '_F2.png'; break;
		default:
	}
	switch (layout) {
		case 'Illustration_HybridCloud' :
		case 'Illustration_MachineLearning' :
		case 'Illustration_OpenSource' :  logoImage = 'Microsoftlogo_rgb_cwhite.png'; break;
		default:
	}
}
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/" + frameImage2, id:"_086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4Migration160x600F4"},
		{src:"images/" + frameImage1, id:"_086E0069_FY21_AzureDirect_Creative_Refresh_BSV4_Illustration_MigrationV4MigrationF1"},
		{src:"images/" + logoImage, id:"Microsoftlogo_rgb_cgray1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
	var lastW, lastH, lastS=1;
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas();
	function resizeCanvas() {
		var w = lib.properties.width, h = lib.properties.height;
		var iw = window.innerWidth, ih=window.innerHeight;
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
		if(isResp) {
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
				sRatio = lastS;
			}
			else if(!isScale) {
				if(iw<w || ih<h)
					sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==1) {
				sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==2) {
				sRatio = Math.max(xRatio, yRatio);
			}
		}
		domContainers[0].width = w * pRatio * sRatio;
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {
			container.style.width = w * sRatio + 'px';
			container.style.height = h * sRatio + 'px';
		});
		stage.scaleX = pRatio*sRatio;
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;
		stage.tickOnUpdate = false;
		stage.update();
		stage.tickOnUpdate = true;
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
