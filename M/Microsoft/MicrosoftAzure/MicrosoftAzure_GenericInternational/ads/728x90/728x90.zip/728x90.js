(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"728x90_atlas_P_", frames: [[0,0,150,150],[0,152,150,150],[0,304,150,150],[0,456,150,150],[152,0,150,150],[0,608,150,150],[0,760,150,150],[152,152,150,150],[152,304,150,150],[152,456,150,150],[152,608,150,150],[152,760,150,150],[304,0,150,150],[304,152,150,150],[304,304,150,150],[304,456,150,150],[304,608,105,30]]}
];


// symbols:



(lib.Comp1_00000 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00001 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00002 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00003 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00004 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00005 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00006 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00007 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00008 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00009 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00010 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00011 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00012 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00013 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00014 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Comp1_00015 = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.MSAzureLogo_StackGr = function() {
	this.initialize(ss["728x90_atlas_P_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Square_teal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4EE3FB").s().p("AnzH0IAAvnIPnAAIAAPng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_teal, new cjs.Rectangle(-50,-50,100,100), null);


(lib.Square_outline_teal = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#4EE4FC").ss(3,1,1).p("AnpnpIPTAAIAAPTIvTAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_outline_teal, new cjs.Rectangle(-50.5,-50.5,101,101), null);


(lib.Square_outline_grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#757578").ss(3,1,1).p("AnpnpIPTAAIAAPTIvTAAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_outline_grey, new cjs.Rectangle(-50.5,-50.5,101,101), null);


(lib.Square_grey = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#757578").s().p("AnzH0IAAvnIPnAAIAAPng");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_grey, new cjs.Rectangle(-50,-50,100,100), null);


(lib.Square_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_8, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#50E6FF").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_7, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_6, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_5, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEFEFE").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_4, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#50E6FF").s().p("EhdvBdwMAAAi7fMC7fAAAMAAAC7fg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_3, new cjs.Rectangle(-600,-600,1200,1200), null);


(lib.Square_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("Ehc9Bc+MAAAi57MC57AAAMAAAC57g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square_2, new cjs.Rectangle(-595,-595,1190,1190), null);


(lib.overlay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg6bAImIAAxLMB03AAAIAARLg");
	this.shape.setTransform(374,55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.overlay, new cjs.Rectangle(0,0,748,110), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.Text = new cjs.Text("Try Azure freeee\nTry Azure freeee", "14px 'Segoe Pro Semibold'", "#FFFFFF");
	this.Text.name = "Text";
	this.Text.textAlign = "center";
	this.Text.lineHeight = 19;
	this.Text.lineWidth = 111;
	this.Text.parent = this;
	this.Text.setTransform(57.3,2);

	this.timeline.addTween(cjs.Tween.get(this.Text).wait(1));

}).prototype = getMCSymbolPrototype(lib.cta, new cjs.Rectangle(0,0,114.6,41.7), null);


(lib.mc_CalloutAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(47));

	// blueBox
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("AhrC+IAAl7IDXAAIAAF7g");
	this.shape.setTransform(52.225,28.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#0178D4").s().p("AhrC8IAAl3IDXAAIAAF3g");
	this.shape_1.setTransform(53.1625,28.9844);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#0178D4").s().p("AhrC5IAAlxIDXAAIAAFxg");
	this.shape_2.setTransform(54.1,29.2188);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#0178D4").s().p("AhrC3IAAltIDXAAIAAFtg");
	this.shape_3.setTransform(55.0375,29.4531);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#0178D4").s().p("AhrC1IAAlpIDXAAIAAFpg");
	this.shape_4.setTransform(55.975,29.6875);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#0178D4").s().p("AhrCyIAAljIDXAAIAAFjg");
	this.shape_5.setTransform(56.9125,29.9219);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#0178D4").s().p("AhrCwIAAlfIDXAAIAAFfg");
	this.shape_6.setTransform(57.85,30.1563);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#0178D4").s().p("AhrCuIAAlbIDXAAIAAFbg");
	this.shape_7.setTransform(58.7875,30.3906);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#0178D4").s().p("AhrCrIAAlVIDXAAIAAFVg");
	this.shape_8.setTransform(59.725,30.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#0178D4").s().p("AhrCpIAAlRIDXAAIAAFRg");
	this.shape_9.setTransform(60.6625,30.8594);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#0178D4").s().p("AhrCnIAAlNIDXAAIAAFNg");
	this.shape_10.setTransform(61.6,31.0938);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#0178D4").s().p("AhrCkIAAlHIDXAAIAAFHg");
	this.shape_11.setTransform(62.5375,31.3281);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#0178D4").s().p("AhrCiIAAlDIDXAAIAAFDg");
	this.shape_12.setTransform(63.475,31.5625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#0178D4").s().p("AhrCgIAAk/IDXAAIAAE/g");
	this.shape_13.setTransform(64.4125,31.7969);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#0178D4").s().p("AhrCdIAAk5IDXAAIAAE5g");
	this.shape_14.setTransform(65.35,32.0313);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#0178D4").s().p("AhrCbIAAk1IDXAAIAAE1g");
	this.shape_15.setTransform(66.2875,32.2656);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#0178D4").s().p("AhrCZIAAkwIDXAAIAAEwg");
	this.shape_16.setTransform(67.225,32.5);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#0178D4").s().p("AhrCeIAAk6IDXAAIAAE6g");
	this.shape_17.setTransform(64.225,32);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#0178D4").s().p("AhrCjIAAlFIDXAAIAAFFg");
	this.shape_18.setTransform(61.225,31.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#0178D4").s().p("AhrClIAAlJIDXAAIAAFJg");
	this.shape_19.setTransform(59.725,31.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#0178D4").s().p("AhrCoIAAlPIDXAAIAAFPg");
	this.shape_20.setTransform(58.225,31);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#0178D4").s().p("AhrCqIAAlTIDXAAIAAFTg");
	this.shape_21.setTransform(56.725,30.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#0178D4").s().p("AhrCtIAAlZIDXAAIAAFZg");
	this.shape_22.setTransform(55.225,30.5);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#0178D4").s().p("AhrCvIAAldIDXAAIAAFdg");
	this.shape_23.setTransform(53.725,30.25);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#0178D4").s().p("AhrC0IAAlnIDXAAIAAFng");
	this.shape_24.setTransform(50.725,29.75);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#0178D4").s().p("AhrC8IAAl2IDXAAIAAF2g");
	this.shape_25.setTransform(46.225,29);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2,p:{x:54.1,y:29.2188}}]},1).to({state:[{t:this.shape_3,p:{x:55.0375,y:29.4531}}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5,p:{x:56.9125,y:29.9219}}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13,p:{x:64.4125,y:31.7969}}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15,p:{x:66.2875,y:32.2656}}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_15,p:{x:65.725,y:32.25}}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_13,p:{x:62.725,y:31.75}}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_5,p:{x:52.225,y:30}}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_3,p:{x:49.225,y:29.5}}]},1).to({state:[{t:this.shape_2,p:{x:47.725,y:29.25}}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape).to({_off:true},1).wait(30).to({_off:false,x:44.725},0).wait(1).to({x:45.225},0).wait(1).to({x:45.725},0).wait(1).to({x:46.225},0).wait(1).to({x:46.725},0).wait(1).to({x:47.225},0).wait(1).to({x:47.725},0).wait(1).to({x:48.225},0).wait(1).to({x:48.725},0).wait(1).to({x:49.225},0).wait(1).to({x:49.725},0).wait(1).to({x:50.225},0).wait(1).to({x:50.725},0).wait(1).to({x:51.225},0).wait(1).to({x:51.725},0).wait(1).to({x:52.225},0).wait(1));

	// blueCallout
	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#00B5EB").s().p("Ak6DvIAAndIJ1AAIAAHdg");
	this.shape_26.setTransform(31.5,23.875);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#00B5EB").s().p("Ak/DxIAAnhIJ/AAIAAHhg");
	this.shape_27.setTransform(31.9688,23.6406);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#00B5EB").s().p("AlDDzIAAnlIKHAAIAAHlg");
	this.shape_28.setTransform(32.4375,23.4063);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#00B5EB").s().p("AlID2IAAnrIKRAAIAAHrg");
	this.shape_29.setTransform(32.9063,23.1719);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#00B5EB").s().p("AlND4IAAnvIKbAAIAAHvg");
	this.shape_30.setTransform(33.375,22.9375);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#00B5EB").s().p("AlRD6IAAnzIKjAAIAAHzg");
	this.shape_31.setTransform(33.8438,22.7031);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#00B5EB").s().p("AlWD9IAAn5IKtAAIAAH5g");
	this.shape_32.setTransform(34.3125,22.4688);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#00B5EB").s().p("AlbD/IAAn9IK3AAIAAH9g");
	this.shape_33.setTransform(34.7813,22.2344);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#00B5EB").s().p("AlgECIAAoDILAAAIAAIDg");
	this.shape_34.setTransform(35.25,22);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#00B5EB").s().p("AlkEEIAAoHILJAAIAAIHg");
	this.shape_35.setTransform(35.7188,21.7656);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#00B5EB").s().p("AlpEGIAAoLILTAAIAAILg");
	this.shape_36.setTransform(36.1875,21.5313);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#00B5EB").s().p("AluEJIAAoRILdAAIAAIRg");
	this.shape_37.setTransform(36.6563,21.2969);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#00B5EB").s().p("AlyELIAAoVILlAAIAAIVg");
	this.shape_38.setTransform(37.125,21.0625);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#00B5EB").s().p("Al3ENIAAoZILvAAIAAIZg");
	this.shape_39.setTransform(37.5938,20.8281);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#00B5EB").s().p("Al8EQIAAofIL5AAIAAIfg");
	this.shape_40.setTransform(38.0625,20.5938);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#00B5EB").s().p("AmAESIAAojIMBAAIAAIjg");
	this.shape_41.setTransform(38.5313,20.3594);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#00B5EB").s().p("AmFEUIAAonIMLAAIAAIng");
	this.shape_42.setTransform(39,20.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#00B5EB").s().p("Al+EPIAAodIL9AAIAAIdg");
	this.shape_43.setTransform(38.25,20.625);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#00B5EB").s().p("Al2EKIAAoTILtAAIAAITg");
	this.shape_44.setTransform(37.5,21.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#00B5EB").s().p("AlvEFIAAoJILfAAIAAIJg");
	this.shape_45.setTransform(36.75,21.625);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#00B5EB").s().p("AlnEAIAAn/ILPAAIAAH/g");
	this.shape_46.setTransform(36,22.125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#00B5EB").s().p("AlgD7IAAn1ILAAAIAAH1g");
	this.shape_47.setTransform(35.25,22.625);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#00B5EB").s().p("AlYD2IAAnrIKxAAIAAHrg");
	this.shape_48.setTransform(34.5,23.125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#00B5EB").s().p("AlRDxIAAnhIKjAAIAAHhg");
	this.shape_49.setTransform(33.75,23.625);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#00B5EB").s().p("AlJDsIAAnXIKTAAIAAHXg");
	this.shape_50.setTransform(33,24.125);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#00B5EB").s().p("AlCDnIAAnNIKFAAIAAHNg");
	this.shape_51.setTransform(32.25,24.625);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#00B5EB").s().p("Ak6DiIAAnDIJ1AAIAAHDg");
	this.shape_52.setTransform(31.5,25.125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#00B5EB").s().p("AkzDdIAAm5IJmAAIAAG5g");
	this.shape_53.setTransform(30.75,25.625);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#00B5EB").s().p("AkrDYIAAmvIJXAAIAAGvg");
	this.shape_54.setTransform(30,26.125);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#00B5EB").s().p("AkkDTIAAmlIJJAAIAAGlg");
	this.shape_55.setTransform(29.25,26.625);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#00B5EB").s().p("AkcDOIAAmbII5AAIAAGbg");
	this.shape_56.setTransform(28.5,27.125);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#00B5EB").s().p("AkVDJIAAmRIIrAAIAAGRg");
	this.shape_57.setTransform(27.75,27.625);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#00B5EB").s().p("AkXDMIAAmXIIvAAIAAGXg");
	this.shape_58.setTransform(28,27.375);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#00B5EB").s().p("AkaDOIAAmbII1AAIAAGbg");
	this.shape_59.setTransform(28.25,27.125);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#00B5EB").s().p("AkcDRIAAmhII5AAIAAGhg");
	this.shape_60.setTransform(28.5,26.875);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#00B5EB").s().p("AkfDTIAAmlII/AAIAAGlg");
	this.shape_61.setTransform(28.75,26.625);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#00B5EB").s().p("AkhDWIAAmrIJDAAIAAGrg");
	this.shape_62.setTransform(29,26.375);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#00B5EB").s().p("AkkDYIAAmvIJJAAIAAGvg");
	this.shape_63.setTransform(29.25,26.125);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#00B5EB").s().p("AkmDbIAAm1IJNAAIAAG1g");
	this.shape_64.setTransform(29.5,25.875);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#00B5EB").s().p("AkpDdIAAm5IJSAAIAAG5g");
	this.shape_65.setTransform(29.75,25.625);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#00B5EB").s().p("AkrDgIAAm/IJXAAIAAG/g");
	this.shape_66.setTransform(30,25.375);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#00B5EB").s().p("AkuDiIAAnDIJcAAIAAHDg");
	this.shape_67.setTransform(30.25,25.125);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#00B5EB").s().p("AkwDlIAAnJIJhAAIAAHJg");
	this.shape_68.setTransform(30.5,24.875);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#00B5EB").s().p("AkzDnIAAnNIJmAAIAAHNg");
	this.shape_69.setTransform(30.75,24.625);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#00B5EB").s().p("Ak1DqIAAnTIJrAAIAAHTg");
	this.shape_70.setTransform(31,24.375);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#00B5EB").s().p("Ak4DsIAAnXIJwAAIAAHXg");
	this.shape_71.setTransform(31.25,24.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_26}]}).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_26}]},1).wait(1));

	// grayCallout
	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#B9B9B9").s().p("Ak6DvIAAndIJ1AAIAAHdg");
	this.shape_72.setTransform(72.75,33.625);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#B9B9B9").s().p("Ak1DsIAAnXIJrAAIAAHXg");
	this.shape_73.setTransform(73.2188,33.8594);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#B9B9B9").s().p("AkxDqIAAnTIJjAAIAAHTg");
	this.shape_74.setTransform(73.6875,34.0938);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#B9B9B9").s().p("AksDoIAAnPIJZAAIAAHPg");
	this.shape_75.setTransform(74.1563,34.3281);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#B9B9B9").s().p("AknDlIAAnJIJPAAIAAHJg");
	this.shape_76.setTransform(74.625,34.5625);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#B9B9B9").s().p("AkjDjIAAnFIJHAAIAAHFg");
	this.shape_77.setTransform(75.0938,34.7969);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#B9B9B9").s().p("AkeDhIAAnBII9AAIAAHBg");
	this.shape_78.setTransform(75.5625,35.0313);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#B9B9B9").s().p("AkZDeIAAm7IIzAAIAAG7g");
	this.shape_79.setTransform(76.0313,35.2656);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#B9B9B9").s().p("AkUDcIAAm3IIpAAIAAG3g");
	this.shape_80.setTransform(76.5,35.5);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#B9B9B9").s().p("AkQDaIAAmzIIhAAIAAGzg");
	this.shape_81.setTransform(76.9688,35.7344);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#B9B9B9").s().p("AkLDXIAAmtIIXAAIAAGtg");
	this.shape_82.setTransform(77.4375,35.9688);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#B9B9B9").s().p("AkGDVIAAmpIINAAIAAGpg");
	this.shape_83.setTransform(77.9063,36.2031);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#B9B9B9").s().p("AkCDTIAAmlIIFAAIAAGlg");
	this.shape_84.setTransform(78.375,36.4375);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#B9B9B9").s().p("Aj9DQIAAmfIH7AAIAAGfg");
	this.shape_85.setTransform(78.8438,36.6719);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#B9B9B9").s().p("Aj4DOIAAmbIHxAAIAAGbg");
	this.shape_86.setTransform(79.3125,36.9063);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#B9B9B9").s().p("Aj0DMIAAmXIHpAAIAAGXg");
	this.shape_87.setTransform(79.7813,37.1406);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#B9B9B9").s().p("AjvDJIAAmRIHfAAIAAGRg");
	this.shape_88.setTransform(80.25,37.375);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#B9B9B9").s().p("Aj3DMIAAmXIHuAAIAAGXg");
	this.shape_89.setTransform(79.5,37.125);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#B9B9B9").s().p("Aj+DOIAAmbIH9AAIAAGbg");
	this.shape_90.setTransform(78.75,36.875);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#B9B9B9").s().p("AkGDRIAAmhIIMAAIAAGhg");
	this.shape_91.setTransform(78,36.625);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#B9B9B9").s().p("AkNDTIAAmlIIbAAIAAGlg");
	this.shape_92.setTransform(77.25,36.375);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#B9B9B9").s().p("AkUDWIAAmrIIpAAIAAGrg");
	this.shape_93.setTransform(76.5,36.125);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#B9B9B9").s().p("AkcDYIAAmvII5AAIAAGvg");
	this.shape_94.setTransform(75.75,35.875);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#B9B9B9").s().p("AkkDbIAAm1IJIAAIAAG1g");
	this.shape_95.setTransform(75,35.625);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#B9B9B9").s().p("AkrDdIAAm5IJXAAIAAG5g");
	this.shape_96.setTransform(74.25,35.375);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#B9B9B9").s().p("AkzDgIAAm/IJmAAIAAG/g");
	this.shape_97.setTransform(73.5,35.125);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#B9B9B9").s().p("Ak6DiIAAnDIJ1AAIAAHDg");
	this.shape_98.setTransform(72.75,34.875);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#B9B9B9").s().p("AlBDlIAAnJIKDAAIAAHJg");
	this.shape_99.setTransform(72,34.625);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#B9B9B9").s().p("AlJDnIAAnNIKTAAIAAHNg");
	this.shape_100.setTransform(71.25,34.375);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#B9B9B9").s().p("AlRDqIAAnTIKiAAIAAHTg");
	this.shape_101.setTransform(70.5,34.125);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#B9B9B9").s().p("AlYDsIAAnXIKxAAIAAHXg");
	this.shape_102.setTransform(69.75,33.875);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#B9B9B9").s().p("AlgDvIAAndILAAAIAAHdg");
	this.shape_103.setTransform(69,33.625);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#B9B9B9").s().p("AldDvIAAndIK7AAIAAHdg");
	this.shape_104.setTransform(69.25,33.625);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#B9B9B9").s().p("AlbDvIAAndIK2AAIAAHdg");
	this.shape_105.setTransform(69.5,33.625);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#B9B9B9").s().p("AlYDvIAAndIKxAAIAAHdg");
	this.shape_106.setTransform(69.75,33.625);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#B9B9B9").s().p("AlWDvIAAndIKsAAIAAHdg");
	this.shape_107.setTransform(70,33.625);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#B9B9B9").s().p("AlTDvIAAndIKnAAIAAHdg");
	this.shape_108.setTransform(70.25,33.625);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#B9B9B9").s().p("AlRDvIAAndIKiAAIAAHdg");
	this.shape_109.setTransform(70.5,33.625);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#B9B9B9").s().p("AlODvIAAndIKdAAIAAHdg");
	this.shape_110.setTransform(70.75,33.625);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#B9B9B9").s().p("AlMDvIAAndIKYAAIAAHdg");
	this.shape_111.setTransform(71,33.625);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#B9B9B9").s().p("AlJDvIAAndIKTAAIAAHdg");
	this.shape_112.setTransform(71.25,33.625);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#B9B9B9").s().p("AlGDvIAAndIKNAAIAAHdg");
	this.shape_113.setTransform(71.5,33.625);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#B9B9B9").s().p("AlEDvIAAndIKJAAIAAHdg");
	this.shape_114.setTransform(71.75,33.625);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#B9B9B9").s().p("AlBDvIAAndIKDAAIAAHdg");
	this.shape_115.setTransform(72,33.625);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#B9B9B9").s().p("Ak/DvIAAndIJ/AAIAAHdg");
	this.shape_116.setTransform(72.25,33.625);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#B9B9B9").s().p("Ak8DvIAAndIJ5AAIAAHdg");
	this.shape_117.setTransform(72.5,33.625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_72}]}).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_72}]},1).wait(1));

	// pointer
	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#B9B9B9").s().p("Ag4g4IBxAAIhxBxg");
	this.shape_118.setTransform(5.675,53.425);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#00B5EB").s().p("Ag4g4IBxAAIAABxg");
	this.shape_119.setTransform(98.575,63.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_119},{t:this.shape_118}]}).wait(47));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-7.5,104.3,76.4);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.MSAzureLogo_StackGr();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.6857,0.685);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(0,0,72,20.6), null);


(lib.impossibleTri = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_7
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],120.8,-30.5,44.4,0.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape.setTransform(9.975,-4.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],119.2,-30.2,44.2,1.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_1.setTransform(9.975,-4.85);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],117.6,-29.9,44.1,2.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_2.setTransform(9.975,-4.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],116,-29.7,43.9,3.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_3.setTransform(9.975,-4.85);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],114.4,-29.4,43.7,5.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_4.setTransform(9.975,-4.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],112.8,-29.1,43.5,6.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_5.setTransform(9.975,-4.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],111.2,-28.9,43.3,7.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_6.setTransform(9.975,-4.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],109.6,-28.6,43.1,8.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_7.setTransform(9.975,-4.85);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],108,-28.3,42.9,9.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_8.setTransform(9.975,-4.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],106.4,-28,42.7,10.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_9.setTransform(9.975,-4.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],104.8,-27.8,42.5,12).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_10.setTransform(9.975,-4.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],103.1,-27.5,42.3,13.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_11.setTransform(9.975,-4.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],101.5,-27.3,42.1,14.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_12.setTransform(9.975,-4.85);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],99.9,-27,41.9,15.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_13.setTransform(9.975,-4.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],98.3,-26.7,41.7,16.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_14.setTransform(9.975,-4.85);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],96.7,-26.4,41.5,17.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_15.setTransform(9.975,-4.85);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],95.1,-26.2,41.3,18.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_16.setTransform(9.975,-4.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],93.5,-25.9,41.1,20.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_17.setTransform(9.975,-4.85);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],91.8,-25.6,40.9,21.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_18.setTransform(9.975,-4.85);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],90.2,-25.3,40.7,22.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_19.setTransform(9.975,-4.85);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],88.6,-25.1,40.5,23.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_20.setTransform(9.975,-4.85);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],87,-24.8,40.3,24.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_21.setTransform(9.975,-4.85);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],85.4,-24.6,40.1,25.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_22.setTransform(9.975,-4.85);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],83.8,-24.3,40,27).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_23.setTransform(9.975,-4.85);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],82.2,-24.1,39.8,28.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_24.setTransform(9.975,-4.85);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],80.6,-23.7,39.6,29.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_25.setTransform(9.975,-4.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],79,-23.5,39.4,30.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_26.setTransform(9.975,-4.85);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],77.4,-23.2,39.2,31.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_27.setTransform(9.975,-4.85);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],75.8,-23,39,32.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_28.setTransform(9.975,-4.85);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],74.2,-22.7,38.8,33.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_29.setTransform(9.975,-4.85);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],72.6,-22.4,38.6,35.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_30.setTransform(9.975,-4.85);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],70.9,-22.1,38.4,36.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_31.setTransform(9.975,-4.85);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],69.3,-21.9,38.2,37.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_32.setTransform(9.975,-4.85);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],67.7,-21.6,38,38.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_33.setTransform(9.975,-4.85);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],66.1,-21.3,37.8,39.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_34.setTransform(9.975,-4.85);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],64.5,-21.1,37.6,40.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_35.setTransform(9.975,-4.85);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],62.9,-20.8,37.5,42).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_36.setTransform(9.975,-4.85);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],61.3,-20.5,37.3,43.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_37.setTransform(9.975,-4.85);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],59.7,-20.2,37.1,44.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_38.setTransform(9.975,-4.85);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],58.1,-20,36.9,45.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_39.setTransform(9.975,-4.85);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],56.5,-19.7,36.7,46.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_40.setTransform(9.975,-4.85);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],54.9,-19.5,36.5,47.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_41.setTransform(9.975,-4.85);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],53.3,-19.2,36.3,48.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_42.setTransform(9.975,-4.85);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],51.7,-18.9,36.1,50.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_43.setTransform(9.975,-4.85);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],50,-18.6,35.9,51.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_44.setTransform(9.975,-4.85);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],48.4,-18.4,35.7,52.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_45.setTransform(9.975,-4.85);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],46.8,-18.1,35.5,53.5).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_46.setTransform(9.975,-4.85);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],45.2,-17.8,35.3,54.7).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_47.setTransform(9.975,-4.85);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],43.6,-17.5,35.1,55.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_48.setTransform(9.975,-4.85);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],42,-17.3,34.9,57).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_49.setTransform(9.975,-4.85);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],40.4,-17,34.7,58.1).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_50.setTransform(9.975,-4.85);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],38.8,-16.7,34.5,59.3).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_51.setTransform(9.975,-4.85);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],37.1,-16.5,34.3,60.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_52.setTransform(9.975,-4.85);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],35.5,-16.2,34.1,61.6).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_53.setTransform(9.975,-4.85);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],33.9,-15.9,33.9,62.8).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_54.setTransform(9.975,-4.85);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],32.3,-15.6,33.7,63.9).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_55.setTransform(9.975,-4.85);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],30.7,-15.4,33.5,65).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_56.setTransform(9.975,-4.85);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],29.1,-15.1,33.3,66.2).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_57.setTransform(9.975,-4.85);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],27.5,-14.8,33.2,67.4).s().p("Amnl+IM2DTIAZCFIrMjAIBoILIhRBZg");
	this.shape_58.setTransform(9.975,-4.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},75).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[]},1).wait(30));

	// Layer_6
	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],72,-1037.5,-253.6,-596.3).s().p("EgrGgDwMBNtgh2IIgFsMhGVAe6MAlhAc+IiPJpg");
	this.shape_59.setTransform(6.1908,7.1591,0.1766,0.1766,156.0355);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],341.3,-795,24.4,-352.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_60.setTransform(14.375,16.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],331.6,-776.2,23.3,-332.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_61.setTransform(14.375,16.975);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],321.8,-757.4,22.2,-312.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_62.setTransform(14.375,16.975);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],312.1,-738.6,21.1,-292.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_63.setTransform(14.375,16.975);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],302.3,-719.9,20,-272.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_64.setTransform(14.375,16.975);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],292.6,-701.1,18.9,-252.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_65.setTransform(14.375,16.975);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],282.8,-682.3,17.8,-232.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_66.setTransform(14.375,16.975);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],273.1,-663.5,16.7,-212.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_67.setTransform(14.375,16.975);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],263.4,-644.7,15.7,-192.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_68.setTransform(14.375,16.975);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],253.7,-626,14.6,-173).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_69.setTransform(14.375,16.975);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],243.9,-607.2,13.5,-153).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_70.setTransform(14.375,16.975);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],234.2,-588.4,12.4,-133).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_71.setTransform(14.375,16.975);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],224.4,-569.6,11.3,-113.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_72.setTransform(14.375,16.975);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],214.7,-550.8,10.3,-93.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_73.setTransform(14.375,16.975);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],205,-532.1,9.2,-73.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_74.setTransform(14.375,16.975);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],195.3,-513.3,8.1,-53.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_75.setTransform(14.375,16.975);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],185.5,-494.5,7,-33.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_76.setTransform(14.375,16.975);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],175.8,-475.7,5.9,-13.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_77.setTransform(14.375,16.975);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],166,-456.9,4.8,6.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_78.setTransform(14.375,16.975);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],156.3,-438.2,3.8,26.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_79.setTransform(14.375,16.975);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],146.5,-419.4,2.6,46.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_80.setTransform(14.375,16.975);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],136.8,-400.6,1.6,66.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_81.setTransform(14.375,16.975);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],127.1,-381.8,0.5,86.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_82.setTransform(14.375,16.975);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],117.3,-363,-0.6,106.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_83.setTransform(14.375,16.975);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],107.6,-344.3,-1.7,126.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_84.setTransform(14.375,16.975);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],97.8,-325.5,-2.8,146.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_85.setTransform(14.375,16.975);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],88.1,-306.7,-3.9,166.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_86.setTransform(14.375,16.975);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],78.4,-287.9,-4.9,186.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_87.setTransform(14.375,16.975);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],68.7,-269.1,-6,206.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_88.setTransform(14.375,16.975);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],58.9,-250.4,-7.1,226.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_89.setTransform(14.375,16.975);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],49.2,-231.6,-8.2,246.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_90.setTransform(14.375,16.975);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],39.4,-212.8,-9.3,266.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_91.setTransform(14.375,16.975);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],29.7,-194,-10.3,286.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_92.setTransform(14.375,16.975);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],20,-175.3,-11.4,306).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_93.setTransform(14.375,16.975);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],10.3,-156.5,-12.5,326).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_94.setTransform(14.375,16.975);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],0.5,-137.7,-13.6,346).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_95.setTransform(14.375,16.975);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-9.2,-118.9,-14.6,365.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_96.setTransform(14.375,16.975);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-18.9,-100.1,-15.7,385.9).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_97.setTransform(14.375,16.975);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-28.6,-81.4,-16.8,405.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_98.setTransform(14.375,16.975);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-38.4,-62.6,-17.9,425.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_99.setTransform(14.375,16.975);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-48.1,-43.8,-19,445.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_100.setTransform(14.375,16.975);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-57.9,-25,-20.1,465.8).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_101.setTransform(14.375,16.975);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-67.6,-6.2,-21.1,485.7).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_102.setTransform(14.375,16.975);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-77.4,12.5,-22.3,505.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_103.setTransform(14.375,16.975);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-87.1,31.3,-23.3,525.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_104.setTransform(14.375,16.975);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-96.8,50.1,-24.4,545.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_105.setTransform(14.375,16.975);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-106.5,68.9,-25.5,565.6).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_106.setTransform(14.375,16.975);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-116.3,87.7,-26.6,585.5).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_107.setTransform(14.375,16.975);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-126,106.4,-27.7,605.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_108.setTransform(14.375,16.975);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-135.8,125.2,-28.8,625.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_109.setTransform(14.375,16.975);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-145.5,144,-29.8,645.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_110.setTransform(14.375,16.975);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-155.2,162.8,-30.9,665.4).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_111.setTransform(14.375,16.975);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-165,181.6,-32,685.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_112.setTransform(14.375,16.975);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-174.7,200.4,-33.1,705.3).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_113.setTransform(14.375,16.975);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-184.5,219.1,-34.2,725.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_114.setTransform(14.375,16.975);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-194.2,237.9,-35.3,745.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_115.setTransform(14.375,16.975);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-203.9,256.7,-36.3,765.2).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_116.setTransform(14.375,16.975);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-213.7,275.5,-37.5,785.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_117.setTransform(14.375,16.975);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-223.4,294.3,-38.5,805.1).s().p("Al7GuIJHqCIoIh/IgUhtILMDAIqGLBg");
	this.shape_118.setTransform(14.375,16.975);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-512.2,89.3,-318.7,601.3).s().p("EgrGgDwMBNtgh2IIgFsMhGVAe6MAlhAc+IiPJpg");
	this.shape_119.setTransform(6.1908,7.1591,0.1766,0.1766,156.0355);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_59}]},74).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[]},1).wait(29));

	// Layer_5
	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-100.1,-94.3,-50.5,-35.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_120.setTransform(-3.8,8.425);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-98.6,-92.8,-48.7,-35.5).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_121.setTransform(-3.8,8.425);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-97.1,-91.4,-46.9,-35.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_122.setTransform(-3.8,8.425);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-95.6,-89.9,-45.2,-35.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_123.setTransform(-3.8,8.425);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-94.1,-88.5,-43.4,-36.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_124.setTransform(-3.8,8.425);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-92.6,-87,-41.6,-36.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_125.setTransform(-3.8,8.425);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-91.2,-85.6,-39.9,-36.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_126.setTransform(-3.8,8.425);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-89.7,-84.2,-38.1,-36.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_127.setTransform(-3.8,8.425);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-88.2,-82.7,-36.3,-36.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_128.setTransform(-3.8,8.425);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-86.7,-81.3,-34.5,-36.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_129.setTransform(-3.8,8.425);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-85.2,-79.9,-32.7,-37.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_130.setTransform(-3.8,8.425);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-83.8,-78.4,-31,-37.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_131.setTransform(-3.8,8.425);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-82.3,-76.9,-29.2,-37.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_132.setTransform(-3.8,8.425);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-80.7,-75.5,-27.4,-37.5).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_133.setTransform(-3.8,8.425);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-79.3,-74.1,-25.6,-37.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_134.setTransform(-3.8,8.425);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-77.8,-72.6,-23.8,-37.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_135.setTransform(-3.8,8.425);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-76.3,-71.2,-22.1,-38.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_136.setTransform(-3.8,8.425);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-74.8,-69.8,-20.3,-38.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_137.setTransform(-3.8,8.425);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-73.3,-68.3,-18.5,-38.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_138.setTransform(-3.8,8.425);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-71.8,-66.9,-16.7,-38.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_139.setTransform(-3.8,8.425);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-70.4,-65.4,-15,-38.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_140.setTransform(-3.8,8.425);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-68.9,-64,-13.2,-38.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_141.setTransform(-3.8,8.425);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-67.4,-62.6,-11.4,-39.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_142.setTransform(-3.8,8.425);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-65.9,-61.1,-9.6,-39.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_143.setTransform(-3.8,8.425);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-64.4,-59.7,-7.8,-39.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_144.setTransform(-3.8,8.425);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-62.9,-58.2,-6.1,-39.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_145.setTransform(-3.8,8.425);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-61.4,-56.8,-4.3,-39.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_146.setTransform(-3.8,8.425);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-59.9,-55.3,-2.5,-39.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_147.setTransform(-3.8,8.425);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-58.5,-53.9,-0.8,-40.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_148.setTransform(-3.8,8.425);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-57,-52.5,1,-40.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_149.setTransform(-3.8,8.425);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-55.5,-51,2.8,-40.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_150.setTransform(-3.8,8.425);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-54,-49.6,4.6,-40.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_151.setTransform(-3.8,8.425);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-52.5,-48.2,6.4,-40.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_152.setTransform(-3.8,8.425);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-51.1,-46.7,8.1,-40.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_153.setTransform(-3.8,8.425);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-49.6,-45.3,9.9,-41.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_154.setTransform(-3.8,8.425);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-48.1,-43.8,11.7,-41.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_155.setTransform(-3.8,8.425);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-46.6,-42.4,13.5,-41.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_156.setTransform(-3.8,8.425);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-45.1,-41,15.3,-41.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_157.setTransform(-3.8,8.425);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-43.6,-39.5,17.1,-41.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_158.setTransform(-3.8,8.425);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-42.1,-38.1,18.8,-41.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_159.setTransform(-3.8,8.425);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-40.6,-36.6,20.6,-42.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_160.setTransform(-3.8,8.425);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-39.2,-35.2,22.3,-42.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_161.setTransform(-3.8,8.425);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-37.7,-33.7,24.1,-42.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_162.setTransform(-3.8,8.425);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-36.2,-32.3,25.9,-42.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_163.setTransform(-3.8,8.425);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-34.7,-30.9,27.7,-42.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_164.setTransform(-3.8,8.425);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-33.2,-29.4,29.5,-42.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_165.setTransform(-3.8,8.425);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-31.7,-28,31.3,-43.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_166.setTransform(-3.8,8.425);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-30.3,-26.6,33,-43.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_167.setTransform(-3.8,8.425);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-28.8,-25.1,34.8,-43.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_168.setTransform(-3.8,8.425);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-27.3,-23.7,36.6,-43.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_169.setTransform(-3.8,8.425);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-25.8,-22.2,38.3,-43.7).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_170.setTransform(-3.8,8.425);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-24.3,-20.8,40.1,-43.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_171.setTransform(-3.8,8.425);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-22.9,-19.3,41.8,-44.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_172.setTransform(-3.8,8.425);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-21.4,-17.9,43.6,-44.2).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_173.setTransform(-3.8,8.425);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-19.9,-16.4,45.4,-44.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_174.setTransform(-3.8,8.425);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-18.4,-15,47.2,-44.6).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_175.setTransform(-3.8,8.425);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-16.9,-13.6,49,-44.8).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_176.setTransform(-3.8,8.425);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-15.4,-12.1,50.8,-44.9).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_177.setTransform(-3.8,8.425);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-14,-10.7,52.5,-45.1).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_178.setTransform(-3.8,8.425);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.lf(["#FFFFFF","#FFFFFF","#FFFFFF","#FFFFFF"],[0.718,0.737,0.902,0.922],-12.5,-9.3,54.3,-45.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_179.setTransform(-3.8,8.425);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.4)","rgba(255,255,255,0.4)","rgba(255,255,255,0)"],[0.718,0.737,0.902,0.922],-10.9,-7.8,56.1,-45.4).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_180.setTransform(-3.8,8.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_120}]},74).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[]},1).wait(29));

	// Layer_1
	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.lf(["#3E7BBE","rgba(62,123,190,0)"],[0.831,0.988],54.6,99.7,261.5,-323.3).s().p("EglBgM6ICwrsMAzKApXMAKYguMIJxkQMgPABDXg");
	this.shape_181.setTransform(5.7381,-18.4206,0.1766,0.1766,156.0355);

	this.timeline.addTween(cjs.Tween.get(this.shape_181).wait(164));

	// Layer_3
	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.lf(["#40403F","rgba(64,64,63,0)"],[0.831,0.988],-315.8,-156.7,-237.7,386.8).s().p("EgrGgDwMBNtgh2IIgFsMhGVAe6MAlhAc+IiPJpg");
	this.shape_182.setTransform(6.1908,7.1591,0.1766,0.1766,156.0355);

	this.timeline.addTween(cjs.Tween.get(this.shape_182).wait(164));

	// Layer_2
	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.lf(["#969696","rgba(150,150,150,0)"],[0.831,0.973],37.8,84.2,99.1,38.3).s().p("AmBmWIBjhsICbL8IF1mbICPAjIpHKBg");
	this.shape_183.setTransform(-3.8,8.425);

	this.timeline.addTween(cjs.Tween.get(this.shape_183).wait(164));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.3,-43.1,94.69999999999999,105);


(lib.grSlash = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00B5EB").s().p("AkJHqIGSvTICAAAImSPTg");
	this.shape.setTransform(26.55,48.975);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,53.1,98);


(lib.grGreater = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Aj/C1IF3irIAAgEIl3i9IAAhtIH/ERIAAA7In/D9g");
	this.shape.setTransform(25.6,29.25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,51.2,58.5);


(lib.grBracket = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0178D4").s().p("AAAHVQg0gvAAhYIAAiwQAAg7gXgcQgWgbgugCIAAhSQAugEAWgbQAXgdAAg7IAAisQAAhYA1gxQAzgtBcgCIAABKQhdADAAByIAACsQAAB8hXAbIAAABQBXAbAAB7IAACqQAABBAWAcQAVAcAyABIgCBKQhcgCgygtg");
	this.shape.setTransform(14.425,51.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,28.9,103.1);


(lib.cubeElement = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(16));

	// Layer_1
	this.instance = new lib.Comp1_00000();
	this.instance.parent = this;

	this.instance_1 = new lib.Comp1_00001();
	this.instance_1.parent = this;

	this.instance_2 = new lib.Comp1_00002();
	this.instance_2.parent = this;

	this.instance_3 = new lib.Comp1_00003();
	this.instance_3.parent = this;

	this.instance_4 = new lib.Comp1_00004();
	this.instance_4.parent = this;

	this.instance_5 = new lib.Comp1_00005();
	this.instance_5.parent = this;

	this.instance_6 = new lib.Comp1_00006();
	this.instance_6.parent = this;

	this.instance_7 = new lib.Comp1_00007();
	this.instance_7.parent = this;

	this.instance_8 = new lib.Comp1_00008();
	this.instance_8.parent = this;

	this.instance_9 = new lib.Comp1_00009();
	this.instance_9.parent = this;

	this.instance_10 = new lib.Comp1_00010();
	this.instance_10.parent = this;

	this.instance_11 = new lib.Comp1_00011();
	this.instance_11.parent = this;

	this.instance_12 = new lib.Comp1_00012();
	this.instance_12.parent = this;

	this.instance_13 = new lib.Comp1_00013();
	this.instance_13.parent = this;

	this.instance_14 = new lib.Comp1_00014();
	this.instance_14.parent = this;

	this.instance_15 = new lib.Comp1_00015();
	this.instance_15.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).to({state:[{t:this.instance_9}]},1).to({state:[{t:this.instance_10}]},1).to({state:[{t:this.instance_11}]},1).to({state:[{t:this.instance_12}]},1).to({state:[{t:this.instance_13}]},1).to({state:[{t:this.instance_14}]},1).to({state:[{t:this.instance_15}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,150,150);


(lib.box_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.box_5, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D0").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.box_4, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B9B9B9").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.box_3, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D0").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.box_2, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.box_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00B5EB").s().p("AqzIuIAAxbIVnAAIAARbg");
	this.shape.setTransform(0,-55.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.box_1, new cjs.Rectangle(-69.2,-111.5,138.5,111.5), null);


(lib.bg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bg, new cjs.Rectangle(0,0,728,90), null);


(lib.bar27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078BA").s().p("AgxBxIAAjhIBjAAIAADhg");
	this.shape.setTransform(4.9,22.8,1,1,0,0,0,-0.1,11.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar27, new cjs.Rectangle(0,0,10.1,22.7), null);


(lib.bar26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(4.85,31.95,1.326,0.9994,0,0,0,-0.1,15.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar26, new cjs.Rectangle(0,0,10.1,32.3), null);


(lib.bar25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglHUIAAunIBLAAIAAOng");
	this.shape.setTransform(5.25,79.75,1.3259,0.8546,0,0,0,0.2,46.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar25, new cjs.Rectangle(0,0,10.1,80), null);


(lib.bar24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AgyKeIAA07IBlAAIAAU7g");
	this.shape.setTransform(4.95,134.4,1,1,0,0,0,-0.1,67.4);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar24, new cjs.Rectangle(0,0,10.2,134), null);


(lib.bar23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AgxCbIAAk1IBjAAIAAE1g");
	this.shape.setTransform(5.05,31,1,1,0,0,0,0,15.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar23, new cjs.Rectangle(0,0,10.1,31.1), null);


(lib.bar22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3A3A3").s().p("AgxCvIAAldIBjAAIAAFdg");
	this.shape.setTransform(5,35,1,1,0,0,0,0,17.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar22, new cjs.Rectangle(0,0,10.1,35), null);


(lib.bar21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078BA").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(4.85,17.8,1.326,1.3256,0,0,0,-0.1,6.8);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar21, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglB5IAAjxIBLAAIAADxg");
	this.shape.setTransform(5.0581,16.0285,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar20, new cjs.Rectangle(0,0,10.1,32.1), null);


(lib.bar19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(5.0469,21.4268,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar19, new cjs.Rectangle(0,0,10.1,42.9), null);


(lib.bar18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3178B5").s().p("AglFWIAAqsIBLAAIAAKsg");
	this.shape.setTransform(5.0357,45.3842,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar18, new cjs.Rectangle(0,0,10.1,90.8), null);


(lib.bar17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglHUIAAunIBLAAIAAOng");
	this.shape.setTransform(5.0363,62.0254,1.3259,1.3255);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar17, new cjs.Rectangle(0,0,10.1,124.1), null);


(lib.bar16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AglF6IAArzIBLAAIAALzg");
	this.shape.setTransform(5.0633,50.1453,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar16, new cjs.Rectangle(0,0,10.1,100.3), null);


(lib.bar15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglAxIAAhiIBLAAIAABig");
	this.shape.setTransform(5.052,6.5731,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar15, new cjs.Rectangle(0,0,10.1,13.2), null);


(lib.bar14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AglCxIAAlhIBLAAIAAFhg");
	this.shape.setTransform(5.0397,23.5059,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar14, new cjs.Rectangle(0,0,10.1,47.1), null);


(lib.bar13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglEEIAAoHIBLAAIAAIHg");
	this.shape.setTransform(5.0617,34.4869,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar13, new cjs.Rectangle(0,0,10.2,69), null);


(lib.bar12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3178B5").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(5.0336,8.8028,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar12, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglB5IAAjxIBLAAIAADxg");
	this.shape.setTransform(5.0224,16.0285,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar11, new cjs.Rectangle(0,0,10.1,32.1), null);


(lib.bar10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(5.0612,21.4268,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar10, new cjs.Rectangle(0,0,10.1,42.9), null);


(lib.bar09 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AglDuIAAncIBLAAIAAHcg");
	this.shape.setTransform(5.0163,31.62,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar09, new cjs.Rectangle(0,0,10.1,63.3), null);


(lib.bar08 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglEFIAAoJIBLAAIAAIJg");
	this.shape.setTransform(5.0893,34.5875,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar08, new cjs.Rectangle(0,0,10.2,69.2), null);


(lib.bar07 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3A3A3").s().p("AglChIAAlCIBLAAIAAFCg");
	this.shape.setTransform(5.0275,21.4268,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar07, new cjs.Rectangle(0,0,10.1,42.9), null);


(lib.bar06 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglB5IAAjxIBLAAIAADxg");
	this.shape.setTransform(5.0163,16.0285,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar06, new cjs.Rectangle(0,0,10.1,32.1), null);


(lib.bar05 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3178B5").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(5.0551,8.8028,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar05, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AglBCIAAiDIBLAAIAACDg");
	this.shape.setTransform(5.0276,8.8028,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar04, new cjs.Rectangle(0,0,10.1,17.6), null);


(lib.bar03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6D6E70").s().p("AglAkIAAhHIBLAAIAABHg");
	this.shape.setTransform(5.0327,4.7458,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar03, new cjs.Rectangle(0,0,10.1,9.5), null);


(lib.bar02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A3A3A3").s().p("AglAkIAAhHIBLAAIAABHg");
	this.shape.setTransform(5.0551,4.7458,1.326,1.3256);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar02, new cjs.Rectangle(0,0,10.1,9.5), null);


(lib.bar01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#449ED0").s().p("AgyAwIAAhfIBkAAIAABfg");
	this.shape.setTransform(5.05,4.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.bar01, new cjs.Rectangle(0,0,10.1,9.5), null);


(lib.arrowSub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#303030").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrowSub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designWHITESub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DDDDDD").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designWHITESub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designLBLUESub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#50E6FF").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designLBLUESub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designGREYSub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#939393").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designGREYSub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designBLUESub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D0").s().p("AnBAIICLh0IDaD4IAAqjIC5AAIAAKjIDaj4ICLB0InCIQg");
	this.shape.setTransform(0.025,-53.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designBLUESub, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AguA1IA4g1Ig4g2IARgRIBLBHIhLBIg");
	this.shape.setTransform(8.4813,4.3854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(5.8,0.2,5.3999999999999995,8.4), null);


(lib.aCircle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0675CA").s().p("Ag2A3QgXgXAAggQAAgfAXgXQAXgXAfAAQAgAAAXAXQAWAXAAAfQAAAggWAXQgXAWggAAQgfAAgXgWg");
	this.shape.setTransform(7.75,7.75);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.aCircle, new cjs.Rectangle(0,0,15.5,15.5), null);


(lib.Triangle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{setStop:74});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_74 = function() {
		this.stop()
		exportRoot.bannerStart = false
	}
	this.frame_75 = function() {
		exportRoot.bannerStart = true
	}
	this.frame_146 = function() {
		this.gotoAndStop('setStop')
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(74).call(this.frame_74).wait(1).call(this.frame_75).wait(71).call(this.frame_146).wait(3));

	// Layer 1
	this.instance = new lib.impossibleTri("synched",39);
	this.instance.parent = this;
	this.instance.setTransform(234.65,198.85,1,1,0,0,0,0,1.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({startPosition:39},0).wait(110));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(192.3,154.6,94.80000000000001,105.00000000000003);


(lib.Square = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Square_8
	this.square_8 = new lib.Square_8();
	this.square_8.name = "square_8";
	this.square_8.parent = this;
	this.square_8.setTransform(597,642.2,0.12,0.12,0,0,0,-1.7,332.6);

	this.timeline.addTween(cjs.Tween.get(this.square_8).wait(1));

	// Square_7
	this.square_7 = new lib.Square_7();
	this.square_7.name = "square_7";
	this.square_7.parent = this;
	this.square_7.setTransform(597,642.2,0.42,0.42,0,0,0,-1.9,332.3);

	this.timeline.addTween(cjs.Tween.get(this.square_7).wait(1));

	// Square_6
	this.square_6 = new lib.Square_6();
	this.square_6.name = "square_6";
	this.square_6.parent = this;
	this.square_6.setTransform(597,642.15,0.6,0.6,0,0,0,-1.9,332.2);

	this.timeline.addTween(cjs.Tween.get(this.square_6).wait(1));

	// Square_5
	this.square_5 = new lib.Square_5();
	this.square_5.name = "square_5";
	this.square_5.parent = this;
	this.square_5.setTransform(597,642.25,1.5,1.5,0,0,0,-2,332.2);

	this.timeline.addTween(cjs.Tween.get(this.square_5).wait(1));

	// Square_4
	this.square_4 = new lib.Square_4();
	this.square_4.name = "square_4";
	this.square_4.parent = this;
	this.square_4.setTransform(597,642.25,1.5,1.5,0,0,0,-2,332.2);

	this.timeline.addTween(cjs.Tween.get(this.square_4).wait(1));

	// Square_3
	this.square_3 = new lib.Square_3();
	this.square_3.name = "square_3";
	this.square_3.parent = this;
	this.square_3.setTransform(597,642.25,1.5,1.5,0,0,0,-2,332.2);

	this.timeline.addTween(cjs.Tween.get(this.square_3).wait(1));

	// Square_2
	this.square_2 = new lib.Square_2();
	this.square_2.name = "square_2";
	this.square_2.parent = this;
	this.square_2.setTransform(597,642.25,1.5,1.5,0,0,0,-2,332.2);

	this.timeline.addTween(cjs.Tween.get(this.square_2).wait(1));

}).prototype = getMCSymbolPrototype(lib.Square, new cjs.Rectangle(-300,-756,1800,1800), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Ag3A4QgXgXAAghQAAggAXgXQAXgXAgAAQAhAAAXAXQAXAXAAAgQAAAhgXAXQgXAXghAAQggAAgXgXg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.parent = this;
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({regX:8.5,regY:4.4,x:4.9,y:0.25},0).wait(1).to({x:4.25},0).wait(1).to({x:3.3},0).wait(1).to({x:2.5},0).wait(1).to({x:2},0).wait(1).to({regX:5.6,regY:4.2,x:-1.05,y:0.05},0).wait(1).to({regX:8.5,regY:4.4,x:1.95,y:0.25},0).wait(1).to({x:2.3},0).wait(1).to({x:2.75},0).wait(1).to({x:3.15},0).wait(1).to({x:3.4},0).wait(1).to({regX:5.6,regY:4.2,x:0.55,y:0.05},0).wait(1).to({regX:8.5,regY:4.4,x:3.45,y:0.25},0).wait(1).to({x:3.3},0).wait(1).to({x:3.15},0).wait(1).to({x:3},0).wait(1).to({x:2.9},0).wait(1).to({regX:5.6,regY:4.2,x:-0.05,y:0.05},0).wait(1).to({regX:8.5,regY:4.4,x:2.9,y:0.25},0).wait(1).to({x:2.95},0).wait(1).to({x:3},0).wait(1).to({x:3.05},0).wait(1).to({regX:5.6,regY:4.2,x:0.15,y:0.05},0).wait(10));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-7.9,-3.9,15.8,8.3);


(lib.mc_SymbolAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(55));

	// greater
	this.instance = new lib.grGreater("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(61.9,48.75,1,1,0,0,0,25.6,29.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(9).to({startPosition:0},0).to({regX:25.7,scaleX:1.1,scaleY:1.1,x:61.95,y:48.7},9,cjs.Ease.quadOut).wait(18).to({startPosition:0},0).to({regX:25.6,scaleX:1,scaleY:1,x:61.9,y:48.75},9,cjs.Ease.quadOut).wait(10));

	// slash
	this.instance_1 = new lib.grSlash("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(56,49,1,1,0,0,0,26.6,49);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(15).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1,x:55.95},9,cjs.Ease.quadOut).wait(18).to({startPosition:0},0).to({scaleX:1,scaleY:1,x:56},9,cjs.Ease.quadOut).wait(4));

	// bracket
	this.instance_2 = new lib.grBracket("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(14.4,56.35,1,1,0,0,0,14.4,51.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(3).to({startPosition:0},0).to({scaleX:1.1,scaleY:1.1,y:56.3},9,cjs.Ease.quadOut).wait(18).to({startPosition:0},0).to({scaleX:1,scaleY:1,y:56.35},9,cjs.Ease.quadOut).wait(16));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.4,-4.9,91.4,117.9);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.c16 = new lib.aCircle();
	this.c16.name = "c16";
	this.c16.parent = this;
	this.c16.setTransform(762.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c15 = new lib.aCircle();
	this.c15.name = "c15";
	this.c15.parent = this;
	this.c15.setTransform(504.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c14 = new lib.aCircle();
	this.c14.name = "c14";
	this.c14.parent = this;
	this.c14.setTransform(254.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c13 = new lib.aCircle();
	this.c13.name = "c13";
	this.c13.parent = this;
	this.c13.setTransform(7.8,778.8,1,1,0,0,0,7.8,7.8);

	this.c12 = new lib.aCircle();
	this.c12.name = "c12";
	this.c12.parent = this;
	this.c12.setTransform(762.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c11 = new lib.aCircle();
	this.c11.name = "c11";
	this.c11.parent = this;
	this.c11.setTransform(504.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c10 = new lib.aCircle();
	this.c10.name = "c10";
	this.c10.parent = this;
	this.c10.setTransform(254.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c09 = new lib.aCircle();
	this.c09.name = "c09";
	this.c09.parent = this;
	this.c09.setTransform(7.8,518.8,1,1,0,0,0,7.8,7.8);

	this.c08 = new lib.aCircle();
	this.c08.name = "c08";
	this.c08.parent = this;
	this.c08.setTransform(762.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c07 = new lib.aCircle();
	this.c07.name = "c07";
	this.c07.parent = this;
	this.c07.setTransform(504.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c06 = new lib.aCircle();
	this.c06.name = "c06";
	this.c06.parent = this;
	this.c06.setTransform(254.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c05 = new lib.aCircle();
	this.c05.name = "c05";
	this.c05.parent = this;
	this.c05.setTransform(7.8,258.8,1,1,0,0,0,7.8,7.8);

	this.c04 = new lib.aCircle();
	this.c04.name = "c04";
	this.c04.parent = this;
	this.c04.setTransform(762.8,7.8,1,1,0,0,0,7.8,7.8);

	this.c03 = new lib.aCircle();
	this.c03.name = "c03";
	this.c03.parent = this;
	this.c03.setTransform(504.8,7.8,1,1,0,0,0,7.8,7.8);

	this.c02 = new lib.aCircle();
	this.c02.name = "c02";
	this.c02.parent = this;
	this.c02.setTransform(254.8,7.8,1,1,0,0,0,7.8,7.8);

	this.c01 = new lib.aCircle();
	this.c01.name = "c01";
	this.c01.parent = this;
	this.c01.setTransform(7.8,7.8,1,1,0,0,0,7.8,7.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.c01},{t:this.c02},{t:this.c03},{t:this.c04},{t:this.c05},{t:this.c06},{t:this.c07},{t:this.c08},{t:this.c09},{t:this.c10},{t:this.c11},{t:this.c12},{t:this.c13},{t:this.c14},{t:this.c15},{t:this.c16}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(0,0,770.5,786.5), null);


(lib.DataBrick = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Square_1
	this.square_9 = new lib.Square_teal();
	this.square_9.name = "square_9";
	this.square_9.parent = this;
	this.square_9.setTransform(713,757);

	this.square_8 = new lib.Square_teal();
	this.square_8.name = "square_8";
	this.square_8.parent = this;
	this.square_8.setTransform(508,757);

	this.square_7 = new lib.Square_grey();
	this.square_7.name = "square_7";
	this.square_7.parent = this;
	this.square_7.setTransform(713,552);

	this.square_6 = new lib.Square_grey();
	this.square_6.name = "square_6";
	this.square_6.parent = this;
	this.square_6.setTransform(303,552);

	this.square_5 = new lib.Square_teal();
	this.square_5.name = "square_5";
	this.square_5.parent = this;
	this.square_5.setTransform(918,347);

	this.square_4 = new lib.Square_grey();
	this.square_4.name = "square_4";
	this.square_4.parent = this;
	this.square_4.setTransform(508,347);

	this.square_3 = new lib.Square_grey();
	this.square_3.name = "square_3";
	this.square_3.parent = this;
	this.square_3.setTransform(713,143);

	this.square_2 = new lib.Square_grey();
	this.square_2.name = "square_2";
	this.square_2.parent = this;
	this.square_2.setTransform(508,143);

	this.square_1 = new lib.Square_grey();
	this.square_1.name = "square_1";
	this.square_1.parent = this;
	this.square_1.setTransform(303,143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.square_1},{t:this.square_2},{t:this.square_3},{t:this.square_4},{t:this.square_5},{t:this.square_6},{t:this.square_7},{t:this.square_8},{t:this.square_9}]}).wait(1));

	// Square_1
	this.outline_16 = new lib.Square_outline_grey();
	this.outline_16.name = "outline_16";
	this.outline_16.parent = this;
	this.outline_16.setTransform(918,757);

	this.outline_15 = new lib.Square_outline_grey();
	this.outline_15.name = "outline_15";
	this.outline_15.parent = this;
	this.outline_15.setTransform(713,757);

	this.outline_14 = new lib.Square_outline_grey();
	this.outline_14.name = "outline_14";
	this.outline_14.parent = this;
	this.outline_14.setTransform(508,757);

	this.outline_13 = new lib.Square_outline_grey();
	this.outline_13.name = "outline_13";
	this.outline_13.parent = this;
	this.outline_13.setTransform(303,757);

	this.outline_12 = new lib.Square_outline_teal();
	this.outline_12.name = "outline_12";
	this.outline_12.parent = this;
	this.outline_12.setTransform(918,552);

	this.outline_11 = new lib.Square_outline_teal();
	this.outline_11.name = "outline_11";
	this.outline_11.parent = this;
	this.outline_11.setTransform(713,552);

	this.outline_10 = new lib.Square_outline_teal();
	this.outline_10.name = "outline_10";
	this.outline_10.parent = this;
	this.outline_10.setTransform(508,552);

	this.outline_9 = new lib.Square_outline_teal();
	this.outline_9.name = "outline_9";
	this.outline_9.parent = this;
	this.outline_9.setTransform(303,552);

	this.outline_8 = new lib.Square_outline_grey();
	this.outline_8.name = "outline_8";
	this.outline_8.parent = this;
	this.outline_8.setTransform(918,347);

	this.outline_7 = new lib.Square_outline_grey();
	this.outline_7.name = "outline_7";
	this.outline_7.parent = this;
	this.outline_7.setTransform(713,347);

	this.outline_6 = new lib.Square_outline_grey();
	this.outline_6.name = "outline_6";
	this.outline_6.parent = this;
	this.outline_6.setTransform(508,347);

	this.outline_5 = new lib.Square_outline_grey();
	this.outline_5.name = "outline_5";
	this.outline_5.parent = this;
	this.outline_5.setTransform(303,347);

	this.outline_4 = new lib.Square_outline_grey();
	this.outline_4.name = "outline_4";
	this.outline_4.parent = this;
	this.outline_4.setTransform(918,143);

	this.outline_3 = new lib.Square_outline_grey();
	this.outline_3.name = "outline_3";
	this.outline_3.parent = this;
	this.outline_3.setTransform(713,143);

	this.outline_2 = new lib.Square_outline_grey();
	this.outline_2.name = "outline_2";
	this.outline_2.parent = this;
	this.outline_2.setTransform(508,143);

	this.outline_1 = new lib.Square_outline_grey();
	this.outline_1.name = "outline_1";
	this.outline_1.parent = this;
	this.outline_1.setTransform(303,143);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.outline_1},{t:this.outline_2},{t:this.outline_3},{t:this.outline_4},{t:this.outline_5},{t:this.outline_6},{t:this.outline_7},{t:this.outline_8},{t:this.outline_9},{t:this.outline_10},{t:this.outline_11},{t:this.outline_12},{t:this.outline_13},{t:this.outline_14},{t:this.outline_15},{t:this.outline_16}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.DataBrick, new cjs.Rectangle(252.5,92.5,716,715), null);


(lib.cubeAnim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cu6 = new lib.cubeElement();
	this.cu6.name = "cu6";
	this.cu6.parent = this;
	this.cu6.setTransform(20.15,98.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu7 = new lib.cubeElement();
	this.cu7.name = "cu7";
	this.cu7.parent = this;
	this.cu7.setTransform(52.55,98.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu5 = new lib.cubeElement();
	this.cu5.name = "cu5";
	this.cu5.parent = this;
	this.cu5.setTransform(101.3,70.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu3 = new lib.cubeElement();
	this.cu3.name = "cu3";
	this.cu3.parent = this;
	this.cu3.setTransform(36.4,70.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu4 = new lib.cubeElement();
	this.cu4.name = "cu4";
	this.cu4.parent = this;
	this.cu4.setTransform(68.8,70.3,0.28,0.28,0,0,0,75.5,75.7);

	this.cu2 = new lib.cubeElement();
	this.cu2.name = "cu2";
	this.cu2.parent = this;
	this.cu2.setTransform(85.1,42.25,0.28,0.28,0,0,0,75.5,75.7);

	this.cu1 = new lib.cubeElement();
	this.cu1.name = "cu1";
	this.cu1.parent = this;
	this.cu1.setTransform(52.95,21.2,0.28,0.28,0,0,0,75.5,75.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.cu1},{t:this.cu2},{t:this.cu4},{t:this.cu3},{t:this.cu5},{t:this.cu7},{t:this.cu6}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.cubeAnim, new cjs.Rectangle(-1,0,123.2,119.1), null);


(lib.Cube = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.cubeAnim = new lib.cubeAnim();
	this.cubeAnim.name = "cubeAnim";
	this.cubeAnim.parent = this;
	this.cubeAnim.setTransform(130.85,365,1,1,0,0,0,22.5,22.5);

	this.timeline.addTween(cjs.Tween.get(this.cubeAnim).wait(1));

}).prototype = getMCSymbolPrototype(lib.Cube, new cjs.Rectangle(107.4,342.5,123.1,119.10000000000002), null);


(lib.Code = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.symbolAnim = new lib.mc_SymbolAnim();
	this.symbolAnim.name = "symbolAnim";
	this.symbolAnim.parent = this;
	this.symbolAnim.setTransform(244.8,193.9,1,1,0,0,0,43.8,53.9);

	this.timeline.addTween(cjs.Tween.get(this.symbolAnim).wait(1));

}).prototype = getMCSymbolPrototype(lib.Code, new cjs.Rectangle(201,140,87.5,107.9), null);


(lib.Chat = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.calloutAnim = new lib.mc_CalloutAnim();
	this.calloutAnim.name = "calloutAnim";
	this.calloutAnim.parent = this;
	this.calloutAnim.setTransform(232.1,199.4,1,1,0,0,0,52.1,34.4);

	this.timeline.addTween(cjs.Tween.get(this.calloutAnim).wait(1));

}).prototype = getMCSymbolPrototype(lib.Chat, new cjs.Rectangle(180,165,104.30000000000001,68.9), null);


(lib.barAnimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.bar27 = new lib.bar27();
	this.bar27.name = "bar27";
	this.bar27.parent = this;
	this.bar27.setTransform(265,124.4,1,1,0,0,0,5,22.9);

	this.bar26 = new lib.bar26();
	this.bar26.name = "bar26";
	this.bar26.parent = this;
	this.bar26.setTransform(255,123.95,1,1,0,0,0,5,31.9);

	this.bar25 = new lib.bar25();
	this.bar25.name = "bar25";
	this.bar25.parent = this;
	this.bar25.setTransform(245,124,1,1,0,0,0,5,79.9);

	this.bar24 = new lib.bar24();
	this.bar24.name = "bar24";
	this.bar24.parent = this;
	this.bar24.setTransform(235,125,1,1,0,0,0,5,134.4);

	this.bar23 = new lib.bar23();
	this.bar23.name = "bar23";
	this.bar23.parent = this;
	this.bar23.setTransform(224.95,124,1,1,0,0,0,5,31);

	this.bar22 = new lib.bar22();
	this.bar22.name = "bar22";
	this.bar22.parent = this;
	this.bar22.setTransform(215,124,1,1,0,0,0,5,35);

	this.bar21 = new lib.bar21();
	this.bar21.name = "bar21";
	this.bar21.parent = this;
	this.bar21.setTransform(205,124.2,1,1,0,0,0,5,17.8);

	this.bar01 = new lib.bar01();
	this.bar01.name = "bar01";
	this.bar01.parent = this;
	this.bar01.setTransform(5,124,1,1,0,0,0,5,9.5);

	this.bar17 = new lib.bar17();
	this.bar17.name = "bar17";
	this.bar17.parent = this;
	this.bar17.setTransform(164.95,124,1,1,0,0,0,5,124.1);

	this.bar20 = new lib.bar20();
	this.bar20.name = "bar20";
	this.bar20.parent = this;
	this.bar20.setTransform(194.95,123.95,1,1,0,0,0,5,32);

	this.bar19 = new lib.bar19();
	this.bar19.name = "bar19";
	this.bar19.parent = this;
	this.bar19.setTransform(184.95,124.05,1,1,0,0,0,5,42.9);

	this.bar18 = new lib.bar18();
	this.bar18.name = "bar18";
	this.bar18.parent = this;
	this.bar18.setTransform(174.95,124,1,1,0,0,0,5,90.8);

	this.bar16 = new lib.bar16();
	this.bar16.name = "bar16";
	this.bar16.parent = this;
	this.bar16.setTransform(155,124,1,1,0,0,0,5.1,100.3);

	this.bar15 = new lib.bar15();
	this.bar15.name = "bar15";
	this.bar15.parent = this;
	this.bar15.setTransform(145,124.05,1,1,0,0,0,5.1,13.2);

	this.bar14 = new lib.bar14();
	this.bar14.name = "bar14";
	this.bar14.parent = this;
	this.bar14.setTransform(135,124.05,1,1,0,0,0,4.9,47.1);

	this.bar13 = new lib.bar13();
	this.bar13.name = "bar13";
	this.bar13.parent = this;
	this.bar13.setTransform(125,124,1,1,0,0,0,4.9,69);

	this.bar12 = new lib.bar12();
	this.bar12.name = "bar12";
	this.bar12.parent = this;
	this.bar12.setTransform(115.05,124,1,1,0,0,0,4.9,17.6);

	this.bar11 = new lib.bar11();
	this.bar11.name = "bar11";
	this.bar11.parent = this;
	this.bar11.setTransform(105.05,123.95,1,1,0,0,0,4.9,32);

	this.bar10 = new lib.bar10();
	this.bar10.name = "bar10";
	this.bar10.parent = this;
	this.bar10.setTransform(95,124.05,1,1,0,0,0,4.9,42.9);

	this.bar09 = new lib.bar09();
	this.bar09.name = "bar09";
	this.bar09.parent = this;
	this.bar09.setTransform(85,123.95,1,1,0,0,0,4.8,63.2);

	this.bar08 = new lib.bar08();
	this.bar08.name = "bar08";
	this.bar08.parent = this;
	this.bar08.setTransform(74.95,124,1,1,0,0,0,5,69.2);

	this.bar07 = new lib.bar07();
	this.bar07.name = "bar07";
	this.bar07.parent = this;
	this.bar07.setTransform(65,124.05,1,1,0,0,0,4.9,42.9);

	this.bar06 = new lib.bar06();
	this.bar06.name = "bar06";
	this.bar06.parent = this;
	this.bar06.setTransform(55,123.95,1,1,0,0,0,4.9,32);

	this.bar05 = new lib.bar05();
	this.bar05.name = "bar05";
	this.bar05.parent = this;
	this.bar05.setTransform(45.05,124,1,1,0,0,0,5,17.6);

	this.bar04 = new lib.bar04();
	this.bar04.name = "bar04";
	this.bar04.parent = this;
	this.bar04.setTransform(35,124,1,1,0,0,0,5,17.6);

	this.bar03 = new lib.bar03();
	this.bar03.name = "bar03";
	this.bar03.parent = this;
	this.bar03.setTransform(25.05,124,1,1,0,0,0,5,9.5);

	this.bar02 = new lib.bar02();
	this.bar02.name = "bar02";
	this.bar02.parent = this;
	this.bar02.setTransform(14.95,124,1,1,0,0,0,5,9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.bar02},{t:this.bar03},{t:this.bar04},{t:this.bar05},{t:this.bar06},{t:this.bar07},{t:this.bar08},{t:this.bar09},{t:this.bar10},{t:this.bar11},{t:this.bar12},{t:this.bar13},{t:this.bar14},{t:this.bar15},{t:this.bar16},{t:this.bar18},{t:this.bar19},{t:this.bar20},{t:this.bar17},{t:this.bar01},{t:this.bar21},{t:this.bar22},{t:this.bar23},{t:this.bar24},{t:this.bar25},{t:this.bar26},{t:this.bar27}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.barAnimation, new cjs.Rectangle(0,-9.4,270.1,134), null);


(lib.Bar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.barAnimation = new lib.barAnimation();
	this.barAnimation.name = "barAnimation";
	this.barAnimation.parent = this;
	this.barAnimation.setTransform(200,188,1,1,0,0,0,100,62);

	this.timeline.addTween(cjs.Tween.get(this.barAnimation).wait(1));

}).prototype = getMCSymbolPrototype(lib.Bar, new cjs.Rectangle(100,116.6,270.1,134), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.arrow = new lib.cta_arrowmo();
	this.arrow.name = "arrow";
	this.arrow.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrowMain, new cjs.Rectangle(-7.9,-7.9,15.8,15.8), null);


(lib.arrow_designWHITE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designWHITESub();
	this.subAr.name = "subAr";
	this.subAr.parent = this;
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designWHITE, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designLBLUE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designLBLUESub();
	this.subAr.name = "subAr";
	this.subAr.parent = this;
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designLBLUE, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designGREY = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designGREYSub();
	this.subAr.name = "subAr";
	this.subAr.parent = this;
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designGREY, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_designBLUE = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrow_designBLUESub();
	this.subAr.name = "subAr";
	this.subAr.parent = this;
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_designBLUE, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib.arrow_design = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.subAr.cache(-100, -100, 200, 200,0.5);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.subAr = new lib.arrowSub();
	this.subAr.name = "subAr";
	this.subAr.parent = this;
	this.subAr.setTransform(0,-53.6,1,1,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.subAr).wait(1));

}).prototype = getMCSymbolPrototype(lib.arrow_design, new cjs.Rectangle(-44.9,-107.2,89.9,107.2), null);


(lib._3dPlainMov = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// box_5
	this.instance = new lib.box_5();
	this.instance.parent = this;
	this.instance.setTransform(11.25,277.7,0.5114,0.8104,0,38.8571,27.338,1.2,0.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regX:0.8,regY:0.8,scaleX:0.5121,scaleY:0.9087,skewX:65.5308,skewY:27.4507,x:-25,y:259},74,cjs.Ease.quadInOut).to({scaleX:0.5114,scaleY:0.8682,skewX:61.193,skewY:27.338,x:-17.7,y:257},37,cjs.Ease.quadInOut).to({scaleX:0.5121,scaleY:0.9087,skewX:65.5308,skewY:27.4507,x:-25.5,y:258.5},34,cjs.Ease.quadInOut).wait(1));

	// box_4
	this.instance_1 = new lib.box_4();
	this.instance_1.parent = this;
	this.instance_1.setTransform(66,206.65,0.5114,0.7473,0,92.769,27.338,1.4,1.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({regX:0.8,regY:1,scaleX:0.5121,scaleY:0.8898,skewX:103.2269,skewY:27.4507,x:65.55,y:216.55},74,cjs.Ease.quadInOut).to({regY:0.9,scaleX:0.5114,scaleY:0.8148,skewX:101.5246,skewY:27.338,x:65.65,y:210.6},37,cjs.Ease.quadInOut).to({regY:1,scaleX:0.5121,scaleY:0.8898,skewX:103.2269,skewY:27.4507,x:65.55,y:216.55},34,cjs.Ease.quadInOut).wait(1));

	// box_3
	this.instance_2 = new lib.box_3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(229.6,200.35,0.5017,0.9076,0,65.6619,28.8258,1,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({regX:0,regY:-55.8,x:275.95,y:178.95},0).wait(1).to({skewX:65.6617,skewY:28.8259,y:179},0).wait(1).to({skewX:65.6613,skewY:28.826,x:276,y:179.1},0).wait(1).to({skewX:65.6609,skewY:28.8262,x:276.05,y:179.2},0).wait(1).to({skewX:65.6603,skewY:28.8265,x:276.1,y:179.4},0).wait(1).to({skewX:65.6595,skewY:28.8268,x:276.15,y:179.6},0).wait(1).to({skewX:65.6586,skewY:28.8272,x:276.25,y:179.85},0).wait(1).to({skewX:65.6576,skewY:28.8276,x:276.35,y:180.15},0).wait(1).to({skewX:65.6565,skewY:28.8281,x:276.45,y:180.4},0).wait(1).to({skewX:65.6552,skewY:28.8286,x:276.6,y:180.75},0).wait(1).to({skewX:65.6538,skewY:28.8292,x:276.7,y:181.15},0).wait(1).to({skewX:65.6522,skewY:28.8299,x:276.85,y:181.6},0).wait(1).to({skewX:65.6506,skewY:28.8306,x:277.05,y:182.05},0).wait(1).to({scaleY:0.9077,skewX:65.6488,skewY:28.8314,x:277.2,y:182.6},0).wait(1).to({scaleX:0.5018,skewX:65.6468,skewY:28.8322,x:277.4,y:183.1},0).wait(1).to({skewX:65.6448,skewY:28.8331,x:277.6,y:183.7},0).wait(1).to({skewX:65.6427,skewY:28.834,x:277.8,y:184.3},0).wait(1).to({skewX:65.6404,skewY:28.8349,x:278,y:184.95},0).wait(1).to({scaleY:0.9078,skewX:65.638,skewY:28.8359,x:278.25,y:185.6},0).wait(1).to({skewX:65.6356,skewY:28.837,x:278.5,y:186.3},0).wait(1).to({skewX:65.633,skewY:28.8381,x:278.75,y:187},0).wait(1).to({scaleX:0.5019,skewX:65.6304,skewY:28.8392,x:279,y:187.75},0).wait(1).to({skewX:65.6277,skewY:28.8403,x:279.25,y:188.5},0).wait(1).to({scaleY:0.9079,skewX:65.625,skewY:28.8415,x:279.5,y:189.3},0).wait(1).to({skewX:65.6221,skewY:28.8427,x:279.8,y:190.1},0).wait(1).to({skewX:65.6193,skewY:28.8439,x:280.05,y:190.9},0).wait(1).to({skewX:65.6164,skewY:28.8452,x:280.35,y:191.7},0).wait(1).to({scaleY:0.908,skewX:65.6135,skewY:28.8464,x:280.65,y:192.5},0).wait(1).to({scaleX:0.502,skewX:65.6105,skewY:28.8477,x:280.95,y:193.35},0).wait(1).to({skewX:65.6075,skewY:28.849,x:281.2,y:194.2},0).wait(1).to({scaleY:0.9081,skewX:65.6046,skewY:28.8502,x:281.5,y:195},0).wait(1).to({skewX:65.6016,skewY:28.8515,x:281.8,y:195.8},0).wait(1).to({skewX:65.5986,skewY:28.8528,x:282.1,y:196.65},0).wait(1).to({skewX:65.5957,skewY:28.854,x:282.35,y:197.5},0).wait(1).to({scaleX:0.5021,scaleY:0.9082,skewX:65.5928,skewY:28.8553,x:282.65,y:198.3},0).wait(1).to({skewX:65.5899,skewY:28.8565,x:282.95,y:199.1},0).wait(1).to({skewX:65.587,skewY:28.8577,x:283.2,y:199.9},0).wait(1).to({skewX:65.5842,skewY:28.8589,x:283.5,y:200.7},0).wait(1).to({scaleY:0.9083,skewX:65.5815,skewY:28.8601,x:283.75,y:201.5},0).wait(1).to({skewX:65.5788,skewY:28.8612,x:284,y:202.25},0).wait(1).to({scaleX:0.5022,skewX:65.5761,skewY:28.8624,x:284.25,y:203},0).wait(1).to({skewX:65.5735,skewY:28.8635,x:284.5,y:203.7},0).wait(1).to({scaleY:0.9084,skewX:65.571,skewY:28.8645,x:284.75,y:204.4},0).wait(1).to({skewX:65.5686,skewY:28.8656,x:285,y:205.1},0).wait(1).to({skewX:65.5662,skewY:28.8666,x:285.25,y:205.8},0).wait(1).to({skewX:65.5639,skewY:28.8676,x:285.45,y:206.45},0).wait(1).to({skewX:65.5616,skewY:28.8685,x:285.7,y:207.05},0).wait(1).to({skewX:65.5595,skewY:28.8695,x:285.9,y:207.65},0).wait(1).to({scaleX:0.5023,scaleY:0.9085,skewX:65.5574,skewY:28.8703,x:286.1,y:208.2},0).wait(1).to({skewX:65.5554,skewY:28.8712,x:286.3,y:208.75},0).wait(1).to({skewX:65.5535,skewY:28.872,x:286.45,y:209.3},0).wait(1).to({skewX:65.5517,skewY:28.8728,x:286.65,y:209.85},0).wait(1).to({skewX:65.5499,skewY:28.8735,x:286.8,y:210.3},0).wait(1).to({scaleY:0.9086,skewX:65.5482,skewY:28.8743,x:287,y:210.8},0).wait(1).to({skewX:65.5466,skewY:28.8749,x:287.15,y:211.25},0).wait(1).to({skewX:65.5451,skewY:28.8756,x:287.3,y:211.65},0).wait(1).to({skewX:65.5437,skewY:28.8762,x:287.45,y:212.1},0).wait(1).to({skewX:65.5423,skewY:28.8768,x:287.55,y:212.45},0).wait(1).to({skewX:65.541,skewY:28.8773,x:287.7,y:212.8},0).wait(1).to({scaleX:0.5024,skewX:65.5398,skewY:28.8778,x:287.8,y:213.15},0).wait(1).to({skewX:65.5387,skewY:28.8783,x:287.9,y:213.45},0).wait(1).to({skewX:65.5377,skewY:28.8788,x:288,y:213.75},0).wait(1).to({skewX:65.5367,skewY:28.8792,x:288.1,y:214.05},0).wait(1).to({scaleY:0.9087,skewX:65.5358,skewY:28.8796,x:288.2,y:214.3},0).wait(1).to({skewX:65.535,skewY:28.8799,x:288.25,y:214.5},0).wait(1).to({skewX:65.5343,skewY:28.8802,x:288.35,y:214.75},0).wait(1).to({skewX:65.5336,skewY:28.8805,x:288.4,y:214.9},0).wait(1).to({skewX:65.533,skewY:28.8808,x:288.45,y:215.1},0).wait(1).to({skewX:65.5324,skewY:28.881,x:288.5,y:215.25},0).wait(1).to({skewX:65.532,skewY:28.8812,x:288.55,y:215.35},0).wait(1).to({skewX:65.5316,skewY:28.8814,x:288.6,y:215.5},0).wait(1).to({skewX:65.5313,skewY:28.8815,x:288.65,y:215.55},0).wait(1).to({skewX:65.531,skewY:28.8816,y:215.65},0).wait(1).to({regX:0.8,regY:0.8,skewX:65.5308,skewY:28.8817,x:242.3,y:237.25},0).to({regX:1,scaleX:0.5017,scaleY:0.9851,skewX:70.1748,skewY:28.8258,x:237.65,y:228.9},37,cjs.Ease.quadInOut).to({regX:0.8,scaleX:0.5024,scaleY:0.9087,skewX:65.5308,skewY:28.8817,x:242.3,y:237.25},34,cjs.Ease.quadInOut).wait(1));

	// box_2
	this.instance_3 = new lib.box_2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(219.7,152.4,0.5096,0.4412,0,164.9698,27.8097,1.4,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:1.2,regY:0.2,scaleX:0.5103,scaleY:0.3619,skewX:193.7808,skewY:27.8225,x:254.25,y:196.75},74,cjs.Ease.quadInOut).to({regY:0.1,scaleX:0.5096,scaleY:0.3817,skewX:187.2716,skewY:27.8097,x:244.4,y:185.65},37,cjs.Ease.quadInOut).to({regY:0.2,scaleX:0.5103,scaleY:0.3619,skewX:193.7808,skewY:27.8225,x:254.25,y:196.75},34,cjs.Ease.quadInOut).wait(1));

	// box_1
	this.instance_4 = new lib.box_1();
	this.instance_4.parent = this;
	this.instance_4.setTransform(149.85,211.55,0.5114,0.8101,0,49.6271,27.3373,1.1,0.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({regX:0.8,scaleX:0.5121,scaleY:0.9087,skewX:65.5308,skewY:27.4507,x:161.75,y:239.25},74,cjs.Ease.quadInOut).to({scaleX:0.5114,scaleY:0.8918,skewX:64.1846,skewY:27.338,x:154.25,y:229.35},37,cjs.Ease.quadInOut).to({scaleX:0.5121,scaleY:0.9087,skewX:65.5308,skewY:27.4507,x:161.75,y:239.25},34,cjs.Ease.quadInOut).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.6,135.7,428.40000000000003,157.5);


(lib.Wave = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"setStop":0});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		exportRoot.bannerStart = false
	}
	this.frame_1 = function() {
		exportRoot.bannerStart = true
	}
	this.frame_71 = function() {
		this.gotoAndStop('setStop')
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(70).call(this.frame_71).wait(3));

	// Layer_4
	this.instance = new lib._3dPlainMov("synched",74,false);
	this.instance.parent = this;
	this.instance.setTransform(162.5,211.6,1,1,0,0,0,164.5,216);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:221.6,startPosition:111},34,cjs.Ease.quadInOut).to({y:211.6,startPosition:145},36,cjs.Ease.quadInOut).wait(4));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-58.6,173.6,428.40000000000003,104.9);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.parent = this;
	this.arrow.setTransform(130.2,40.45,1.4736,1.4736,0,0,0,11,10.5);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D4").s().p("AqiD6IAAnzIVFAAIAAHzg");
	this.shape.setTransform(67.5,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(0,0,135,50), null);


(lib.Arrows = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"setStop":0});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
		this.stop()
		exportRoot.bannerStart = false
	}
	this.frame_1 = function() {
		exportRoot.bannerStart = true
	}
	this.frame_72 = function() {
		this.gotoAndStop('setStop')
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(71).call(this.frame_72).wait(20));

	// arrow_design
	this.arr_1 = new lib.arrow_designGREY();
	this.arr_1.name = "arr_1";
	this.arr_1.parent = this;
	this.arr_1.setTransform(215.4,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_1).wait(3).to({alpha:0},8).wait(2).to({alpha:1},17).wait(62));

	// arrow_design
	this.arr_2 = new lib.arrow_designWHITE();
	this.arr_2.name = "arr_2";
	this.arr_2.parent = this;
	this.arr_2.setTransform(240.85,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.arr_2).wait(3).to({alpha:0},8).wait(8).to({alpha:1},17).wait(56));

	// arrow_design
	this.arr_3 = new lib.arrow_designLBLUE();
	this.arr_3.name = "arr_3";
	this.arr_3.parent = this;
	this.arr_3.setTransform(266.25,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_3).wait(3).to({alpha:0},8).wait(14).to({alpha:1},17).wait(50));

	// arrow_design
	this.arr_4 = new lib.arrow_designBLUE();
	this.arr_4.name = "arr_4";
	this.arr_4.parent = this;
	this.arr_4.setTransform(266.25,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_4).wait(3).to({alpha:0},8).wait(21).to({alpha:1},17).wait(43));

	// arrow_design
	this.arr_1_1 = new lib.arrow_design();
	this.arr_1_1.name = "arr_1_1";
	this.arr_1_1.parent = this;
	this.arr_1_1.setTransform(215.4,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_1_1).wait(92));

	// arrow_design
	this.arr_2_1 = new lib.arrow_design();
	this.arr_2_1.name = "arr_2_1";
	this.arr_2_1.parent = this;
	this.arr_2_1.setTransform(240.85,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.arr_2_1).wait(92));

	// arrow_design
	this.arr_3_1 = new lib.arrow_design();
	this.arr_3_1.name = "arr_3_1";
	this.arr_3_1.parent = this;
	this.arr_3_1.setTransform(266.25,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_3_1).wait(92));

	// arrow_design
	this.arr_4_1 = new lib.arrow_design();
	this.arr_4_1.name = "arr_4_1";
	this.arr_4_1.parent = this;
	this.arr_4_1.setTransform(266.25,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.arr_4_1).wait(92));

	// arrow_design
	this.instance = new lib.arrow_design();
	this.instance.parent = this;
	this.instance.setTransform(291.3,163.2,0.1956,0.1956,90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(92));

	// arrow_design
	this.instance_1 = new lib.arrow_design();
	this.instance_1.parent = this;
	this.instance_1.setTransform(164.95,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(92));

	// arrow_design
	this.instance_2 = new lib.arrow_design();
	this.instance_2.parent = this;
	this.instance_2.setTransform(189.95,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(92));

	// arrow_design
	this.instance_3 = new lib.arrow_design();
	this.instance_3.parent = this;
	this.instance_3.setTransform(189.95,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(92));

	// arrow_design
	this.instance_4 = new lib.arrow_design();
	this.instance_4.parent = this;
	this.instance_4.setTransform(215.4,187.75,0.1956,0.1956,180,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(92));

	// arrow_design
	this.instance_5 = new lib.arrow_design();
	this.instance_5.parent = this;
	this.instance_5.setTransform(215.4,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(92));

	// arrow_design
	this.instance_6 = new lib.arrow_design();
	this.instance_6.parent = this;
	this.instance_6.setTransform(240.85,187.75,0.1956,0.1956,180,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(92));

	// arrow_design
	this.instance_7 = new lib.arrow_design();
	this.instance_7.parent = this;
	this.instance_7.setTransform(240.85,236.35,0.1956,0.1956,0,0,0,0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(92));

	// arrow_design
	this.instance_8 = new lib.arrow_design();
	this.instance_8.parent = this;
	this.instance_8.setTransform(266.25,236.35,0.1956,0.1956,0,0,0,0,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(92));

	// arrow_design
	this.instance_9 = new lib.arrow_design();
	this.instance_9.parent = this;
	this.instance_9.setTransform(291.3,187.75,0.1956,0.1956,180,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(92));

	// arrow_design
	this.instance_10 = new lib.arrow_design();
	this.instance_10.parent = this;
	this.instance_10.setTransform(291.3,236.35,0.1956,0.1956,0,0,0,0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(92));

	// arrow_design
	this.instance_11 = new lib.arrow_design();
	this.instance_11.parent = this;
	this.instance_11.setTransform(291.3,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(92));

	// arrow_design
	this.instance_12 = new lib.arrow_design();
	this.instance_12.parent = this;
	this.instance_12.setTransform(190.15,212.2,0.1956,0.1956,-90,0,0,-0.2,-53.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(92));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(156.2,154.5,145.7,92.4);


// stage content:
(lib._728x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		var firefox = navigator.userAgent.toLowerCase().indexOf('firefox') > -1;
		var windows = navigator.userAgent.toLowerCase().indexOf('windows') > -1;
		var ie = Boolean(navigator.userAgent.indexOf('MSIE')!==-1 || navigator.appVersion.indexOf('Trident/') > -1);
		var edge = navigator.userAgent.toLowerCase().indexOf('edge') > -1;
		if (!(ie || edge) && createjs) {
		//if ((firefox || windows) && createjs) {
		//if (firefox && createjs) {
			createjs.Text.prototype._drawTextLine = function(ctx, text, y) {
				// Adjust text position only if textBaseline is "top"
				if (this.textBaseline === "top") {
					var lineHeight = this.lineHeight || this.getMeasuredLineHeight();
					y += lineHeight * 0.2;
				}
				// Chrome 17 will fail to draw the text if the last param is included but null, so we feed it a large value instead:
				if (this.outline) { ctx.strokeText(text, 0, y, this.maxWidth||0xFFFF); }
				else { ctx.fillText(text, 0, y, this.maxWidth||0xFFFF); }
			};
		}
		var ad = (function(config) {
			var root = config.root;
			var loadedAssets = [], cachedImages = [];
			var loadAssets = function(list, callbackFunction, callbackData){ //loadAssets(list of URLs, callback function)
				if(list && typeof list == 'string') {
					var path = list;
					list = [];
					list.push(path);
				}  
				if(list && typeof list == 'object' && list.length) {
					var loadCounter = [];
					var head = document.querySelector('head');
					function loadCheck(e) { 
						loadCounter.push(this);
						if(loadCounter.length == list.length) {
							loadCounter.forEach(function(asset) { 
								if(asset) {
									var isExistFlag = false;
									if(loadedAssets.length) {
										for(var i = 0; i < loadedAssets.length; i++) {
											var loadedAsset = loadedAssets[i];
											if(loadedAsset && loadedAsset.dataset.url == asset.dataset.url) {
												isExistFlag = true;
												break;
											}
										}
									} 
									if(!isExistFlag) {
										loadedAssets.push(asset);
										if(asset.dataset.type == 'image') { cachedImages.push(asset); }
									}
								}
							});
							if(callbackFunction) {
								callbackFunction(loadCounter, callbackData); //This function is called when all the provided assets are loaded properly.
							}					
						}
					}
					list.forEach(function(path) {
						var isExistFlag = false;
						if(path && loadedAssets.length) {
							for(var i = 0; i < loadedAssets.length; i++) {
								var loadedAsset = loadedAssets[i];
								if(loadedAsset && loadedAsset.dataset.url == path) {
									isExistFlag = true;
									break;
								}
							}
						} 
						if(isExistFlag) {
							loadCheck(loadedAssets[i]);
						}
						else if(path && typeof path == 'string' && path.length && !isExistFlag) {					
							if(path.indexOf('.js') > 0) { //For loading JS file
								var script = document.createElement('script');
								script.type = 'text/javascript';
								script.onload = loadCheck;
								script.dataset.type = 'js';
								script.dataset.url = path;
								script.src = path;
								head.appendChild(script);
							} else if(path.indexOf('.css') > 0) { //For loading CSS file
								var style = document.createElement('style');
								style.type = 'text/css';
								style.setAttribute('rel', 'stylesheet');
								style.onload = loadCheck;
								style.dataset.type = 'css';
								style.dataset.url = path;
								style.setAttribute('href', path);
								head.appendChild(style);
							} else {	//For loading Image file
								var image = new Image();
								image.crossOrigin = "Anonymous";
								image.onload = loadCheck;
								image.dataset.type = 'image';
								image.dataset.url = path;
								image.src = path;
							}
						}
					});
				}
			}
			var resetRegistrationPoint = function(instance) {
				if(instance && typeof instance == 'object') {
					instance.x -= instance.regX;
					instance.y -= instance.regY;
					instance.regX = 0;
					instance.regY = 0;
				}	
			}
			var setText = function(selector, text, type) { //setText(selector or element, dynamic text, specify type - 'resize' or 'clip' text)
				var extraSpace = 0;
				type = type && typeof type == 'string' &&  type.length ? type : 'resize'; 
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(text && text.length && instance && typeof instance == 'object') {
					text = text.split('<br>').join('\n');
					var initialTextHeight = instance.containerHeight || instance.getBounds().height || instance.getMeasuredHeight();
					var initialLineHeight = instance.lineHeight || instance.getMeasuredLineHeight();
					var initialTextWidth = instance.containerWidth || instance.getBounds().width;
					var initialFontSize = parseFloat(instance.font.split(' ').map(function(props){ return props.indexOf('px') > 0 ? (parseFloat(props) - 1) : '' }).join(''));
					instance.text = text;
					var flag = false;
					if(initialTextHeight < instance.getMeasuredHeight() || initialTextWidth < instance.getBounds().width) {
						if(type == 'clip') { //Clip extra text
							for(var i = text.length - 3; i > 0; i--) {
								instance.text = text.slice(0, i) + '...';
								if(initialTextHeight >= instance.getMeasuredHeight()) { break; }
							}
						} else { //Resize text to fit in the container
							var fontSize = parseFloat(instance.font.split(' ').map(function(props){ return props.indexOf('px') > 0 ? (parseFloat(props) - 1) : '' }).join(''))*10;
							if(fontSize && fontSize > 1) {
								for(var i = fontSize; i > 0; i--) {
									instance.font = instance.font.split(' ').map(function(props){ return props.indexOf('px') > 0 ? i/10 + 'px' : props }).join(' ');
									instance.lineHeight = (i/(10*initialFontSize))*initialLineHeight;
									if(initialTextHeight >= instance.getMeasuredHeight() && initialTextWidth >= instance.getBounds().width) { break; }
								}
							}
						}
						instance.x -= 2;
						instance.y -= 2;
						flag = true;
					} else if(initialTextHeight > instance.getMeasuredHeight()) { //Center align text
						//instance.regY = -(initialTextHeight - instance.getMeasuredHeight())/2;
						extraSpace = (type == 'center' ? (initialLineHeight - initialFontSize)/2 : 0)			
						if(type == 'resize' || type == 'clip') {}
					}	
					instance.regY = extraSpace - (initialTextHeight - instance.getMeasuredHeight())/2;
					return flag;
				}
			}
			var setImage = function(selector, imagePath, alignment) { //setImage(selector or element, image path, alignment - 'top left')
				alignment = alignment && typeof alignment == 'string' && alignment.length ? alignment : 'center';
				var addImage = function(image) {
					if(image) {
						var bounds = instance.nominalBounds || instance.getBounds() || instance.getTransformedBounds();
						//var bounds = instance.getTransformedBounds();
						var scale = 1;
						var imageWidth = image.width, imageHeight = image.height;
						var outerWidth = bounds.width, outerHeight = bounds.height;
						if(image.width > bounds.width || image.height > bounds.height) {
							var ratio = bounds.width/image.width;
							ratio = image.height*ratio > bounds.height ? bounds.height/image.height : ratio;				
							bitmap.scaleX = bitmap.scaleY = ratio; //scale image to fit the image container
							imageWidth = image.width*ratio, imageHeight = image.height*ratio;
						}
						var xCenter = (outerWidth - imageWidth)/2;
						var yCenter = (outerHeight - imageHeight)/2;
						var xRight = (outerWidth - imageWidth);
						var yBottom = (outerHeight - imageHeight);
						switch(alignment) {	//align image
							case 'center': 
							case 'center center':	bitmap.x = xCenter;
													bitmap.y = yCenter;
													break;						
							case 'top': 
							case 'top center': 
							case 'center top': 		bitmap.x = xCenter;
													bitmap.y = 0;
													break;
							case 'left': 
							case 'left center': 
							case 'center left': 	bitmap.x = 0;
													bitmap.y = yCenter;
													break;					
							case 'bottom': 
							case 'bottom center': 
							case 'center bottom': 	bitmap.x = xCenter;
													bitmap.y = yBottom;
													break;					
							case 'right': 
							case 'right center': 
							case 'center right': 	bitmap.x = xRight;
													bitmap.y = yCenter;
													break;					
							case 'top left': 
							case 'left top': 		bitmap.x = bitmap.y = 0;
													break;						
							case 'top right': 
							case 'right top': 		bitmap.x = xRight;
													bitmap.y = 0;
													break;						
							case 'bottom left': 
							case 'left bottom': 	bitmap.x = 0;
													bitmap.y = yBottom;
													break;							
							case 'bottom right': 
							case 'right bottom': 	bitmap.x = xRight;
													bitmap.y = yBottom;
													break;							
							default: 				bitmap.x = xCenter;
													bitmap.y = yCenter;
						}
						
						instance.removeAllChildren();
						instance.setBounds(bounds.x, bounds.y, bounds.width, bounds.height);
						instance.addChild(bitmap);
					}
				} 
				var bitmap = imagePath && imagePath.length ? new createjs.Bitmap(imagePath) : 0;
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(bitmap && instance && typeof instance == 'object') {
					//var image = loadedAssets.find(function(asset) { return asset.dataset.src == imagePath; });
					var image;
					for(var i = 0; i < loadedAssets.length; i++) {
						if(loadedAssets[i] && loadedAssets[i].dataset.url == imagePath ) { image = loadedAssets[i]; break; }
					}
					if(image) { addImage(image); } else { loadAssets(imagePath, function(images){ addImage(images[0]); }); }
				}
			}
			var addClick = function(selector, url) { //addClick(selector or element, click through Url)
				url = url && typeof url == 'string' && url.length ? url : '';
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(url && instance && typeof instance == 'object') {
					instance.onClickFunction = function(){ window.open(url, '_blank'); }
					instance.addEventListener("click", instance.onClickFunction);
				} else { return false; }
				return true;
			}
			var removeClick = function(selector) { //removeClick(selector or element)
				var instance = typeof selector == 'string' && selector && selector.length && root[selector] ? root[selector] : selector;
				if(instance && typeof instance == 'object' && 'onClickFunction' in instance && instance.onClickFunction) {
					instance.removeEventListener("click", instance.onClickFunction);
				} else { return false; }
				return true;
			}
			return { //exposed parameters and methods
				root: root,
				loadAssets: function(list, callbackFunction) { return loadAssets(list, callbackFunction); },
				resetRegistrationPoint: function(instance) { return resetRegistrationPoint(instance); },
				setText: function(selector, text, type) { return setText(selector, text, type); },
				setImage: function(selector, imagePath, alignment) { return setImage(selector, imagePath, alignment); },
				addClick: function(selector, url){ return addClick(selector, url); }
			}
		})({
			root: this
		});
		createjs.Touch.enable(stage);
		stage.enableMouseOver(10);
		//createjs.Ticker.on("tick", stage);
		// OR
		//createjs.Ticker.addEventListener("tick", stage);
		// OR
		createjs.Ticker.on("tick", tick);
		function tick(event) { stage.update(event); }
		
		var canvasContainer = document.querySelector('#animation_container');
		if(canvasContainer) { canvasContainer.style.cursor = 'pointer'; }
		
		function cubeAnimation() {
			var rotationFlag = true;
			var cubes = [];
			for(var i = 1; i < 8; i++) { cubes.push(ad.root.Cube.cubeAnim['cu' + i]); }
			function startAnimation () {
				if(rotationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					var count = 0;
					rotationFlag = false;
					var rollOverTimer = setInterval(function(){
						if(count < cubes.length) { cubes[count].gotoAndPlay(1); }
						else { clearInterval(rollOverTimer); setTimeout(function(){ rotationFlag = true;}, 200); }
						count++;
					}, 80);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Cube.visible = true;
		}
		
		function barAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					for(var i = 1; i<=27; i++) {
						createjs.Tween.get(ad.root.Bar.barAnimation['bar' + ((i > 9 ? '' : '0') + i)], {override:true}).wait(i*25).to({scaleY: Math.floor((Math.random() * 99) + 1)/100}, 600, createjs.Ease.getPowInOut(4));//getPowInOut , createjs.Ease.getPowInOut(4)
					}
					setTimeout(function(){
						for(var i = 1; i<=27; i++) {
							createjs.Tween.get(ad.root.Bar.barAnimation['bar' + ((i > 9 ? '' : '0') + i)], {override:true}).wait(i*50).to({scaleY: 1}, 500, createjs.Ease.getPowOut(4));
						}
					},1000);
					
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 2000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Bar.visible = true;
		}
		
		function waveAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Wave.gotoAndPlay('setStop');
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Wave.visible = true;
		}
		
		function triangleAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Triangle.gotoAndPlay(75);
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Triangle.visible = true;
		}
		
		function arrowsAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Arrows.gotoAndPlay('setStop');
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Arrows.visible = true;
		}
		
		function codeAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Code.symbolAnim.gotoAndPlay(1);
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Code.visible = true;
		}
		
		function chatAnimation() {
			var animationFlag = true;
			function startAnimation () {
				if(animationFlag) {
					ad.root.cta.arrow.arrow.gotoAndPlay(0);
					ad.root.Chat.calloutAnim.gotoAndPlay(1);
					animationFlag = false;
					setTimeout(function(){ animationFlag = true;}, 1000);
				}
			}
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Chat.visible = true;
		}
		
		function squareAnimation() {
			var animationFlag = true;
			startAnimation ()
			function startAnimation () {	
				if(animationFlag) {	
					animationFlag = false;
					exportRoot.tl1 = new TimelineLite();	
					
					//exportRoot.tl1.from(exportRoot.Square.square_2,  2.1, { scaleX:0.6, scaleY:0.6, ease:Power3.easeInOut},"=0")
					//exportRoot.tl1.from(exportRoot.Square.square_3,  2.1, { scaleX:0.42, scaleY:0.42, ease:Power3.easeInOut},"-=2")
					//exportRoot.tl1.from(exportRoot.Square.square_4,  2.1, { scaleX:0.12, scaleY:0.12, ease:Power3.easeInOut},"-=1.85")
					//exportRoot.tl1.from(exportRoot.Square.square_5,  2.1, { scaleX:0, scaleY:0, ease:Power3.easeInOut},"-=1.75")
					exportRoot.tl1.from(exportRoot.Square.square_6,  2.05, { scaleX:0, scaleY:0, ease:Power2.easeInOut},"-=1.75")
					exportRoot.tl1.from(exportRoot.Square.square_7,  2.05, { scaleX:0, scaleY:0, ease:Power2.easeInOut},"-=1.75")
					exportRoot.tl1.from(exportRoot.Square.square_8,  2, { scaleX:0, scaleY:0, ease:Power2.easeInOut,onComplete:function(){animationFlag = true;}},"-=1.75")
		
				}
			}
			function restartAnimation(){
				exportRoot.tl1.restart(true, false);
			}
			document.querySelector('#canvas').addEventListener('mouseenter', restartAnimation);
			ad.root.Square.visible = true;
		}
		
		
		function databrickAnimation(){
			var animationFlag = true;
			startAnimation ()	
			function startAnimation () {	
				if(animationFlag) {	
					animationFlag = false;
					exportRoot.tl1 = new TimelineLite();
					
					exportRoot.tl1.from(exportRoot.DataBrick.outline_12,  .34, {alpha:0, ease:Power2.easeInOut},"=0")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_7,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_15,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_14,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_4,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_8,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_16,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_11,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_1,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_10,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_13,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_5,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_9,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_2,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_6,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.from(exportRoot.DataBrick.outline_3,  .34, {alpha:0, ease:Power2.easeInOut},"-=.285")
		
					exportRoot.tl1.from(exportRoot.DataBrick.square_9,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_1,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_3,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_5,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_8,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_7,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_4,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_6,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
					exportRoot.tl1.from(exportRoot.DataBrick.square_2,  .34, {alpha:0, ease:Power2.easeInOut},"-=.265")
		
					exportRoot.tl1.to(exportRoot.DataBrick.square_8,  .34, {y:"551", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_4,  .34, {x:"303", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_7,  .34, {y:"346", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_9,  .34, {x:"508", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_6,  .34, {y:"756", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_8,  .34, {x:"303", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_2,  .34, {y:"346", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_9,  .34, {y:"551", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_5,  .34, {y:"551", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_3,  .34, {x:"508", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_7,  .34, {y:"141", ease:Power3.easeInOut},"-=.2")
					exportRoot.tl1.to(exportRoot.DataBrick.square_5,  .34, {x:"713", ease:Power3.easeInOut},"-=.2")
		
					exportRoot.tl1.to(exportRoot.DataBrick.outline_12,  .34, {alpha:1, ease:Power2.easeInOut},"+=.5")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_7,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_15,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_14,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_4,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_8,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_16,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
		
					exportRoot.tl1.to(exportRoot.DataBrick.square_9,  .34, {alpha:1, ease:Power3.easeInOut},"-=.1")
					exportRoot.tl1.to(exportRoot.DataBrick.square_1,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_2,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_3,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_5,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_8,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_7,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_4,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.square_6,  .34, {alpha:1, ease:Power3.easeInOut},"-=.285")
		
					exportRoot.tl1.to(exportRoot.DataBrick.outline_11,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_1,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_10,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_13,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_5,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_9,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_2,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_6,  .34, {alpha:1, ease:Power2.easeInOut},"-=.285")
					exportRoot.tl1.to(exportRoot.DataBrick.outline_3,  .34, {alpha:1, ease:Power2.easeInOut,onComplete:function(){animationFlag = true;}},"-=.285");
		
				}
			}
			function restartAnimation(){
				exportRoot.tl1.restart(true, false);
			}
			document.querySelector('#canvas').addEventListener('mouseenter', restartAnimation);
			ad.root.DataBrick.visible = true;
		}
		
		function serverlessAnimation(){
			var animationFlag = true;
			var pathStart
			var pathEnd
			var mc = exportRoot.Serverless
			var color = 0xff6600;
		
		
			var line = new createjs.Shape();
			mc.addChild(line);
		
			var coords1
			var serverlessCount = 0;
			var tl;
			
			exportRoot.updatePath = function() {
					
					serverlessCount++;
					if(serverlessCount > 200){
						tl.pause();
						return;
					}
					coords1 = 	[
					mc.c01.x, mc.c01.y,   mc.c06.x, mc.c06.y,   mc.c01.x, mc.c01.y,   mc.c07.x, mc.c07.y,   mc.c01.x, mc.c01.y,   mc.c10.x, mc.c10.y,   mc.c01.x, mc.c01.y,   mc.c14.x, mc.c14.y,   
					]
		
					coords2 = 	[
					mc.c06.x, mc.c06.y,   mc.c07.x, mc.c07.y,   mc.c06.x, mc.c06.y,   mc.c09.x, mc.c09.y,   mc.c06.x, mc.c06.y,   mc.c13.x, mc.c13.y,   mc.c06.x, mc.c06.y,   mc.c10.x, mc.c10.y,   mc.c06.x, mc.c06.y,   mc.c15.x, mc.c15.y,   mc.c06.x, mc.c06.y,   mc.c11.x, mc.c11.y,   mc.c06.x, mc.c06.y,   mc.c12.x, mc.c12.y,
					]
					
					coords3 = 	[
					mc.c10.x, mc.c10.y,   mc.c13.x, mc.c13.y,   mc.c10.x, mc.c10.y,   mc.c14.x, mc.c14.y,   mc.c10.x, mc.c10.y,   mc.c15.x, mc.c15.y,   mc.c10.x, mc.c10.y,   mc.c16.x, mc.c16.y,   mc.c10.x, mc.c10.y,   mc.c11.x, mc.c11.y,   
					]
					
					coords4 = 	[
					mc.c07.x, mc.c07.y,   mc.c08.x, mc.c08.y,   mc.c07.x, mc.c07.y,   mc.c09.x, mc.c09.y,   mc.c07.x, mc.c07.y,   mc.c10.x, mc.c10.y,   mc.c07.x, mc.c07.y,   mc.c14.x, mc.c14.y,   mc.c07.x, mc.c07.y,   mc.c11.x, mc.c11.y,   mc.c07.x, mc.c07.y,   mc.c16.x, mc.c16.y,   mc.c07.x, mc.c07.y,   mc.c12.x, mc.c12.y,   
					]
					
					coords5 = 	[
					mc.c05.x, mc.c05.y,   mc.c06.x, mc.c06.y,   mc.c05.x, mc.c05.y,   mc.c10.x, mc.c10.y,   mc.c05.x, mc.c05.y,   mc.c14.x, mc.c14.y,   
					]
					
					coords6 = 	[
					mc.c08.x, mc.c08.y,   mc.c10.x, mc.c10.y,   mc.c08.x, mc.c08.y,   mc.c11.x, mc.c11.y,   mc.c08.x, mc.c08.y,   mc.c15.x, mc.c15.y,   
					]
					
					coords7 = 	[
					mc.c11.x, mc.c11.y,   mc.c13.x, mc.c13.y,   mc.c11.x, mc.c11.y,   mc.c14.x, mc.c14.y,   mc.c11.x, mc.c11.y,   mc.c15.x, mc.c15.y,   mc.c11.x, mc.c11.y,   mc.c16.x, mc.c16.y,   mc.c11.x, mc.c11.y,   mc.c12.x, mc.c12.y   
					]
		
					coords8 = 	[
					mc.c12.x, mc.c12.y,   mc.c13.x, mc.c13.y,   mc.c12.x, mc.c12.y,   mc.c14.x, mc.c14.y,   mc.c12.x, mc.c12.y,   mc.c15.x, mc.c15.y
					]
					
					coords9 = 	[
					mc.c04.x, mc.c04.y,   mc.c06.x, mc.c06.y,   mc.c04.x, mc.c04.y,   mc.c09.x, mc.c09.y,   mc.c04.x, mc.c04.y,   mc.c07.x, mc.c07.y,   mc.c04.x, mc.c04.y,   mc.c11.x, mc.c11.y,   mc.c04.x, mc.c04.y,   mc.c15.x, mc.c15.y,      
					]
					
					coords10 = 	[
					mc.c09.x, mc.c09.y,   mc.c10.x, mc.c10.y,   mc.c09.x, mc.c09.y,   mc.c14.x, mc.c14.y,   mc.c09.x, mc.c09.y,   mc.c15.x, mc.c15.y,   
					]
					
					coords11 = 	[
					mc.c02.x, mc.c02.y,   mc.c05.x, mc.c05.y,   mc.c02.x, mc.c02.y,   mc.c09.x, mc.c09.y,   mc.c02.x, mc.c02.y,   mc.c13.x, mc.c13.y,   mc.c02.x, mc.c02.y,   mc.c06.x, mc.c06.y,   mc.c02.x, mc.c02.y,   mc.c11.x, mc.c11.y,   mc.c02.x, mc.c02.y,   mc.c07.x, mc.c07.y,   mc.c02.x, mc.c02.y,   mc.c08.x, mc.c08.y,
					]
					
					coords12 = 	[
					mc.c03.x, mc.c03.y,   mc.c05.x, mc.c05.y,   mc.c03.x, mc.c03.y,   mc.c06.x, mc.c06.y,   mc.c03.x, mc.c03.y,   mc.c10.x, mc.c10.y,   mc.c03.x, mc.c03.y,   mc.c07.x, mc.c07.y,   mc.c03.x, mc.c03.y,   mc.c16.x, mc.c16.y,   mc.c03.x, mc.c03.y,   mc.c12.x, mc.c12.y,   mc.c03.x, mc.c03.y,   mc.c08.x, mc.c08.y,
					]
					
					line.graphics.clear()
					line.graphics.setStrokeStyle(1.5);
					line.graphics.beginStroke('#0675CA');
		
					for (var i = 2; i< coords1.length; i+=2) {
						line.graphics.moveTo(coords1[i-2], coords1[i-1]);
						line.graphics.lineTo(coords1[i], coords1[i+1]);
					}
					for (var i = 2; i< coords2.length; i+=2) {
						line.graphics.moveTo(coords2[i-2], coords2[i-1]);
						line.graphics.lineTo(coords2[i], coords2[i+1]);
					}
					for (var i = 2; i< coords3.length; i+=2) {
						line.graphics.moveTo(coords3[i-2], coords3[i-1]);
						line.graphics.lineTo(coords3[i], coords3[i+1]);
					}
					for (var i = 2; i< coords4.length; i+=2) {
						line.graphics.moveTo(coords4[i-2], coords4[i-1]);
						line.graphics.lineTo(coords4[i], coords4[i+1]);
					}
					for (var i = 2; i< coords5.length; i+=2) {
						line.graphics.moveTo(coords5[i-2], coords5[i-1]);
						line.graphics.lineTo(coords5[i], coords5[i+1]);
					}
					for (var i = 2; i< coords6.length; i+=2) {
						line.graphics.moveTo(coords6[i-2], coords6[i-1]);
						line.graphics.lineTo(coords6[i], coords6[i+1]);
					}
					line.graphic
					for (var i = 2; i< coords7.length; i+=2) {
						line.graphics.moveTo(coords7[i-2], coords7[i-1]);
						line.graphics.lineTo(coords7[i], coords7[i+1]);
					}
					for (var i = 2; i< coords8.length; i+=2) {
						line.graphics.moveTo(coords8[i-2], coords8[i-1]);
						line.graphics.lineTo(coords8[i], coords8[i+1]);
					}
					for (var i = 2; i< coords9.length; i+=2) {
						line.graphics.moveTo(coords9[i-2], coords9[i-1]);
						line.graphics.lineTo(coords9[i], coords9[i+1]);
					}
					for (var i = 2; i< coords10.length; i+=2) {
						line.graphics.moveTo(coords10[i-2], coords10[i-1]);
						line.graphics.lineTo(coords10[i], coords10[i+1]);
					}
					for (var i = 2; i< coords11.length; i+=2) {
						line.graphics.moveTo(coords11[i-2], coords11[i-1]);
						line.graphics.lineTo(coords11[i], coords11[i+1]);
					}
					for (var i = 2; i< coords12.length; i+=2) {
						line.graphics.moveTo(coords12[i-2], coords12[i-1]);
						line.graphics.lineTo(coords12[i], coords12[i+1]);
					}
			}
			
			TweenMax.delayedCall(0.2,function(){exportRoot.runBanner()})
			
			ad.root.runBanner = function() {
		
				tl = new TimelineMax({onUpdate:function(){exportRoot.updatePath()}})
				tl.fromTo(mc.c01, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1})
				tl.fromTo(mc.c05, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=50", y:"-=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c09, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=50", y:"+=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c13, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				
				tl.fromTo(mc.c02, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c06, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=35", y:"+=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c10, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=35", y:"-=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c14, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				
				tl.fromTo(mc.c03, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c07, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=55", y:"+=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c11, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=55", y:"-=6", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c15, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
		
				tl.fromTo(mc.c04, 2, {  x:"+=50", y:"+=20", ease:Power1.easeInOut}, {  x:"-=50", y:"-=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c08, 2, {  x:"+=50", y:"+=8", ease:Power1.easeInOut}, {  x:"-=50", y:"-=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c12, 2, {  x:"+=50", y:"-=8", ease:Power1.easeInOut}, {  x:"-=50", y:"+=8", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")
				tl.fromTo(mc.c16, 2, {  x:"+=50", y:"-=20", ease:Power1.easeInOut}, {  x:"-=50", y:"+=20", ease:Power1.easeInOut,  yoyo:true,  repeat:-1},"-=1.9")	
				
			}
		
			function startAnimation () {	
				serverlessCount = 0;
				tl.play();
			}
			
			document.querySelector('#canvas').addEventListener('mouseenter', startAnimation);
			ad.root.Serverless.visible = true;
		}
		
		function setData(data, cam) {
			data = data && data.length ? data: 0, assets = [];
			if(cam) {
				//ad.setText(ad.root.content.footerText, 'footer' in cam && cam.footer && cam.footer.length ? cam.footer: '');
			}
			if(data) {						
				if(data[0].impressionTracker.toLowerCase() != 'na'){
					var impressionTracker = data[0].impressionTracker;
					var isn = 'data' in amo && 'isn' in amo.data ? amo.data.isn : '';
					var trackingCode = 'data' in amo && 'data' in amo.data && 'atsParams' in amo.data.data && 'x2_tracking_code_5' in amo.data.data.atsParams ? amo.data.data.atsParams.x2_tracking_code_5 : '';
					if(isn.length) { impressionTracker = impressionTracker.replace('(t_td_isn)', isn); }
					if(trackingCode.length){ impressionTracker = impressionTracker.replace('$(t_qp_TC_5)', trackingCode); }
					(new Image()).src = impressionTracker;
				}
				data.forEach(function(obj) { /*assets.push(obj.image);*/ assets.push(obj.logo); });
				function addContent(assets) {
					data = data[0];
					//ad.root.headlineText.setBounds(0, 0, 284, 70);
					ad.root.headlineText.containerWidth = 284;
					ad.root.headlineText.containerHeight = 70;			
					ad.setText(ad.root.headlineText, data['headlineText'], 'center');
					/*if(ad.root.headlineText.getMeasuredHeight() > 60) {
						ad.root.txtCta.y += 20;
						ad.root.cta.y += 20;
					}*/
					if(data.headlineAlignment) {
						ad.root.headlineText.textAlign = 'right';
						ad.root.headlineText.x += ad.root.headlineText.containerWidth;
					}
					var ctaAligned = ad.setText(ad.root.txtCta.Text, data['ctaText']);
					if(ctaAligned) { ad.root.txtCta.Text.regY = 0; ad.root.txtCta.y = ad.root.cta.y + (ad.root.cta.nominalBounds.height - ad.root.txtCta.getBounds().height)/2; }
					ad.setImage(ad.root.logo, data['logo']);
					ad.root.bg.shape.graphics._fill.style = data['backgroundColor'];
					ad.root.headlineText.color = data['textColor'];
					if(data['ctaTextColor']){
						ad.root.txtCta.Text.color = data['ctaTextColor'];
						ad.root.cta.arrow.arrow.instance.shape.graphics._fill.style = data['ctaTextColor'];
					}
					ad.root.cta.shape.graphics._fill.style = data['ctaBackgroundColor'];
					if(ad.root) {
						ad.root.addEventListener("click", function(e) {
							if(e.target.name == 'cta') {
								//amo.onDynAdClick(data.feedData, "CTA_CLICK", data.url);
								//amo.onDynAdClick(data.feedData, data.dataId, data.url);
								amo.onDynAdClick(data.feedData, "CLICK", data.url, data.dataId, (new Date()).getTime());
							} else {
							/*if(e.target.parent.name == 'next' || e.target.parent.name == 'prev') {
								
							}  else {*/
								//amo.onDynAdClick(data.feedData, "CLICK", data.url);
								//amo.onDynAdClick(data.feedData, data.dataId, data.url);
								amo.onDynAdClick(data.feedData, "CLICK", data.url, data.dataId, (new Date()).getTime());
							}
						});
					}
					
					ad.root.Cube.visible = false;
					ad.root.Bar.visible = false;
					ad.root.Wave.visible = false;
					ad.root.Triangle.visible = false;
					ad.root.Arrows.visible = false;
					ad.root.Code.visible = false;
					ad.root.Chat.visible = false;	
					ad.root.Square.visible = false;
					ad.root.DataBrick.visible = false;
					ad.root.Serverless.visible = false;
					switch(data['animationType'].toLowerCase()) {
						case 'cube': cubeAnimation(); break;
						case 'bar': barAnimation(); break;
						case 'wave': waveAnimation(); break;
						case 'triangle': triangleAnimation(); break;
						case 'arrows': arrowsAnimation(); break;
						case 'code': codeAnimation(); break;				
						case 'chat': chatAnimation(); break;
						case 'square': squareAnimation(); break;
						case 'databrick': databrickAnimation(); break;
						case 'serverless': serverlessAnimation(); break;
						default : cubeAnimation();
					}
					ad.root.gotoAndPlay(1);
				}
				if(assets && assets.length) { ad.loadAssets(assets, addContent); } else { addContent(); }
				
				
			}	
		}
		function loadData() {
			var replaceMacro = function(text, data) {
				if(text.indexOf('!{') != -1 && text.indexOf('}') != -1) {
					text = text.split('!{');
					text = text.map(function(string){
						if(string.indexOf('}') != -1) {
							string = string.split('}');
							for(var key in data) { if(key == string[0]) { string[0] = data[key]; } }
							string = string.join('');
						}
						return string;
					}).join('');
				}
				return text.split('^').join(' ');
			}
			var contentD = [
				{
					"name": "Generic",
					//"description": "Get actionable insights with monitoring and diagnostic visualization from Azure|Wave",//"Code, experiment, and build your next great web app",
					"description": "Detecte, avalie e migre suas máquinas virtuais da infraestrutura local para a nuvem. Migre seus aplicativos para o Azure com confiança.",//Migrate your on-premises workloads to the cloud with confidence
					"passthroughfield1": "Попробуйте Azure бесплатно",//Testez Azure gratuitement//Try Azure free//Teste o Azure gratuitamente
					// "passthroughfield2": "True",
					"passthroughfield5": "RightAlign",
					"product_url": "https://azure.microsoft.com/",
				}
			];
			if(contentD && contentD.length) { contentD.forEach(function(data) { amo.registerContent(data); }); }
			amo.registerVariation("headlineText", "!{description}");
			//amo.registerVariation("logo", "assets/MSAzureLogo_StackGr.png");
			amo.registerVariation("logo", "assets/MSAzureLogo_StackWh.png");
			amo.registerVariation("animationType", "Square");//Cube, Bar, Wave, Triangle, Arrows, Code, Chat, Square, DataBrick, Serverless
			//amo.registerVariation("color", "#ffffff|#000000");
			amo.registerVariation("color", "#505050|#ffffff");
			amo.registerVariation("ctaText", "!{passthroughfield1}");
			// amo.registerVariation("ctaColor", "#000|#fff");
			// amo.registerVariation("ctaArrowVisibleFlag", "!{passthroughfield2}");
			amo.registerVariation("clickURL", "!{product_url}");
			amo.registerVariation("impressionTracker", "https://mscom.demdex.net/event?d_sid=12703198");
			var content = [], cam = {};
			var cam = {
				headlineText: amo.variation['headlineText'],
				logo: amo.variation['logo'],
				animationType: amo.variation['animationType'],
				color: amo.variation['color'],
				cta: amo.variation['ctaText'],
				ctaColor: '#0078D4|#fff',
				// ctaColor: amo.variation['ctaColor'],
				// ctaArrowVisibleFlag: amo.variation['ctaArrowVisibleFlag'],
				url: amo.variation['clickURL'],
				impressionTracker: amo.variation['impressionTracker'],
			};
			if(amo.content && amo.content.length) {
				amo.content.forEach(function(data) {
					content.push({
						feedData: data,
						dataId: cam.color + '|' + cam.animationType,
						headlineText: cam.headlineText,
						headlineAlignment: Boolean(data.passthroughfield5.toLowerCase() == 'rightalign'),
						logo: cam.logo,
						animationType: cam.animationType,
						color: cam.color,
						ctaText: cam.cta,
						ctaBackgroundColor: cam.ctaColor.split('|')[0],
						ctaTextColor: cam.ctaColor.split('|').length>1 ? cam.ctaColor.split('|')[1] : '',
						// ctaArrowVisibleFlag: cam.ctaArrowVisibleFlag.toString().toLowerCase() == 'false' ? false : true,
						ctaArrowVisibleFlag: true,
						url: cam.url,
						impressionTracker: cam.impressionTracker,
					});
				});
				if(content && content.length) {
					content.map(function(data){
						for(var key in data) { data[key] = typeof data[key] == 'string' ? replaceMacro(data[key], data.feedData) : data[key]; }
					});
					content.map(function(data){
						data.textColor = data.color.split('|')[0];
						data.backgroundColor = data.color.split('|')[1];
					});
					document.querySelector('canvas').setAttribute('aria-label','Microsoft Logo   Headline:'+content[0].headlineText+' '+content[0].ctaText)
				}
			}
			setTimeout(function(){ setData(content, cam); }, 2000);
		}
		ad.root.stop();
		loadData();
	}
	this.frame_71 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(71).call(this.frame_71).wait(1));

	// overlay
	this.overlay = new lib.overlay();
	this.overlay.name = "overlay";
	this.overlay.parent = this;
	this.overlay.setTransform(140,115,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.overlay).to({alpha:0},11).wait(61));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("Eg43gHBMBxvAAAIAAODMhxvAAAg");
	this.shape.setTransform(364,45);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(80,80,80,0)").s().p("Eg43AHCIAAuDMBxvAAAIAAODg");
	this.shape_1.setTransform(364,45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(72));

	// MSFT Two lines
	this.logo = new lib.logo();
	this.logo.name = "logo";
	this.logo.parent = this;
	this.logo.setTransform(57,30.2,1,1,0,0,0,36,10.2);

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(72));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.parent = this;
	this.txtCta.setTransform(577,23);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(72));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.parent = this;
	this.cta.setTransform(575.2,20.4,1,1,0,0,0,0.2,0.4);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(72));

	// headlineText
	this.headlineText = new cjs.Text("Build intelligent apps faster with analytics and built-in AI", "20px 'Segoe Pro Semibold'", "#505050");
	this.headlineText.name = "headlineText";
	this.headlineText.lineHeight = 27;
	this.headlineText.lineWidth = 280;
	this.headlineText.parent = this;
	this.headlineText.setTransform(277,12);

	this.timeline.addTween(cjs.Tween.get(this.headlineText).wait(72));

	// Serverless
	this.Serverless = new lib.mainMC();
	this.Serverless.name = "Serverless";
	this.Serverless.parent = this;
	this.Serverless.setTransform(192,46,0.1038,0.1017,0,0,0,390.2,393.2);

	this.timeline.addTween(cjs.Tween.get(this.Serverless).wait(72));

	// DataBricks
	this.DataBrick = new lib.DataBrick();
	this.DataBrick.name = "DataBrick";
	this.DataBrick.parent = this;
	this.DataBrick.setTransform(191,45,0.0979,0.0978,0,0,0,610.8,450.8);

	this.timeline.addTween(cjs.Tween.get(this.DataBrick).wait(72));

	// Square
	this.Square = new lib.Square();
	this.Square.name = "Square";
	this.Square.parent = this;
	this.Square.setTransform(189,26,0.0667,0.0666,0,0,0,602.2,144.1);

	this.timeline.addTween(cjs.Tween.get(this.Square).wait(72));

	// Cube
	this.Cube = new lib.Cube();
	this.Cube.name = "Cube";
	this.Cube.parent = this;
	this.Cube.setTransform(226.1,-103.85,0.75,0.75,0,0,0,241,204);

	this.timeline.addTween(cjs.Tween.get(this.Cube).wait(72));

	// Bar
	this.Bar = new lib.Bar();
	this.Bar.name = "Bar";
	this.Bar.parent = this;
	this.Bar.setTransform(148.9,52.4,0.6,0.6,0,0,0,199.8,187.9);

	this.timeline.addTween(cjs.Tween.get(this.Bar).wait(72));

	// Triangle
	this.Triangle = new lib.Triangle();
	this.Triangle.name = "Triangle";
	this.Triangle.parent = this;
	this.Triangle.setTransform(226,76.1,0.65,0.65,0,0,0,299.9,250.2);

	this.timeline.addTween(cjs.Tween.get(this.Triangle).wait(72));

	// Arrows
	this.Arrows = new lib.Arrows();
	this.Arrows.name = "Arrows";
	this.Arrows.parent = this;
	this.Arrows.setTransform(228.6,79.4,0.7,0.7,0,0,0,299.9,250.3);

	this.timeline.addTween(cjs.Tween.get(this.Arrows).wait(72));

	// Code
	this.Code = new lib.Code();
	this.Code.name = "Code";
	this.Code.parent = this;
	this.Code.setTransform(182.55,45,0.55,0.55,0,0,0,244.8,194.3);

	this.timeline.addTween(cjs.Tween.get(this.Code).wait(72));

	// Chat
	this.Chat = new lib.Chat();
	this.Chat.name = "Chat";
	this.Chat.parent = this;
	this.Chat.setTransform(182.95,48,0.75,0.75,0,0,0,231.8,199);

	this.timeline.addTween(cjs.Tween.get(this.Chat).wait(72));

	// Wave
	this.Wave = new lib.Wave();
	this.Wave.name = "Wave";
	this.Wave.parent = this;
	this.Wave.setTransform(225,87,0.55,0.55,0,0,0,300.1,250.3);

	this.timeline.addTween(cjs.Tween.get(this.Wave).wait(72));

	// bg
	this.bg = new lib.bg();
	this.bg.name = "bg";
	this.bg.parent = this;
	this.bg.setTransform(150,125,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(72));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-47,-32,864.4,816);
// library properties:
lib.properties = {
	id: 'F4972F44B4874BF3A9D610527B0A2B56',
	width: 728,
	height: 90,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/728x90_atlas_P_.png?1573670687865", id:"728x90_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['F4972F44B4874BF3A9D610527B0A2B56'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;