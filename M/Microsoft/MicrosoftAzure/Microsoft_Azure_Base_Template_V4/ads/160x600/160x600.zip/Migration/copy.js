// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#000000>Migrate your|on-premises|workloads to|the cloud with|confidence","21px",16, 75,"25","350", "left"];

	bannerData.CTA = ["<#FFFFFF>Try Azure free","13.5px",-5,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
