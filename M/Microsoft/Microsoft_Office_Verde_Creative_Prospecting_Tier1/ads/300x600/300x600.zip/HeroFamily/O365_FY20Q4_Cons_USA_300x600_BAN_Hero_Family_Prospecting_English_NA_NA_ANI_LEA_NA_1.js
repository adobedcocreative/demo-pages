(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_", frames: [[0,0,481,470],[483,0,180,180]]}
];


// symbols:



(lib.bg_img = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Clock_300x600 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.mainImage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#88857C").s().p("EglVATZMAAAgmxMBKrAAAMAAAAmxg");
	this.shape.setTransform(64.25,155.6);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.instance = new lib.bg_img();
	this.instance.setTransform(-174.25,188.5,0.9906,0.9906);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainImage, new cjs.Rectangle(-174.7,31.5,478,622.6), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.clock = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_26 = function() {
		exportRoot.tlClock.play()
	}
	this.frame_124 = function() {
		this.stop();
		exportRoot.tl1.play();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(26).call(this.frame_26).wait(98).call(this.frame_124).wait(1));

	// smiles mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("AB0JMQj5g/iGjeQgbgtgTgwIJOjlIA/JxQgbACgbAAQhYAAhSgUg");
	var mask_graphics_86 = new cjs.Graphics().p("AB0JMQj5g/iGjeQgbgtgTgwIJOjlIA/JxQgbACgbAAQhYAAhSgUg");
	var mask_graphics_87 = new cjs.Graphics().p("AB0JMQj5g/iGjeQgbgtgSgwIJNjlIA/JxQgbACgbAAQhYAAhSgUg");
	var mask_graphics_88 = new cjs.Graphics().p("AB0JLQj6g/iFjeQgbgugSgvIJOjkIA+JxQgbACgaAAQhZAAhSgVg");
	var mask_graphics_89 = new cjs.Graphics().p("AByJKQj5hAiEjfQgbgugSgwIJQjgIA6JyIgwABQhbAAhVgWg");
	var mask_graphics_90 = new cjs.Graphics().p("ABvJIQj4hDiCjgQgagugSgxIJSjZIAzJyIgnABQhgAAhYgYg");
	var mask_graphics_91 = new cjs.Graphics().p("ABpJFQj2hIh+jjQgZgugRgxIJWjOIAoJzIgaAAQhnAAhfgbg");
	var mask_graphics_92 = new cjs.Graphics().p("ABiI/Qj1hOh3jmQgZgwgPgwIJci/IAWJ0IgEAAQhzAAhnghg");
	var mask_graphics_93 = new cjs.Graphics().p("ABWI3QjyhYhujqQgWgxgOgxIJjinIgCJ1Qh1gEhogmg");
	var mask_graphics_94 = new cjs.Graphics().p("AA5IrQjthkhijvQgUgygLgyIJriHIgiJzQh1gKhmgrg");
	var mask_graphics_95 = new cjs.Graphics().p("AAYIcQjmh0hSj2QgRgygHgzIJxheIhLJvQh0gRhigxg");
	var mask_graphics_96 = new cjs.Graphics().p("AgRIGQjdiGg9j7QgNg0gDgzIJ3grIh+JnQhygbhdg5g");
	var mask_graphics_97 = new cjs.Graphics().p("AhEHqQjOibgkkBQgIg1ACgyIJ5AUIi7JYQhvgnhXhCg");
	var mask_graphics_98 = new cjs.Graphics().p("Ah8HGQi6izgGkDQgBg0AIgzIJyBeIkBI+QhpgzhPhMg");
	var mask_graphics_99 = new cjs.Graphics().p("Ai3GYQifjLAfkBQAHg0APgxIJeC1IlPIUQhhhBhEhXg");
	var mask_graphics_100 = new cjs.Graphics().p("AjnFoQiBjgBDj5QAOgzAWgvII+EKImWHfQhYhOg2hgg");
	var mask_graphics_101 = new cjs.Graphics().p("AkIE+QhljtBgjwQAUgxAbgrIIbFMInNGrQhNhYgrhmg");
	var mask_graphics_102 = new cjs.Graphics().p("AkdEbQhNj2B4jlQAZgvAfgoIH2GAIn1F7QhEhggghpg");
	var mask_graphics_103 = new cjs.Graphics().p("AkrD+Qg4j7CKjaQAdgtAigmIHWGoIoTFRQg7hlgZhsg");
	var mask_graphics_104 = new cjs.Graphics().p("AkyDoQgoj+CYjSQAggrAlgjIG4HGIonEtQg1hogRhtg");
	var mask_graphics_105 = new cjs.Graphics().p("Ak2DWQgbkACjjJQAigpAmgiIGhHcIo2ERQgwhrgLhug");
	var mask_graphics_106 = new cjs.Graphics().p("Ak4DJQgRkACqjDQAkgoAnggIGPHrIpAD7QgshtgHhug");
	var mask_graphics_107 = new cjs.Graphics().p("Ak5DAQgKkBCwi+QAkgnApgfIGAH2IpGDrQgphugEhug");
	var mask_graphics_108 = new cjs.Graphics().p("Ak5C6QgFkBCzi7QAlgnApgeIF3H+IpLDgQgmhvgChug");
	var mask_graphics_109 = new cjs.Graphics().p("Ak5C2QgCkBC1i5QAlgmAqgeIFxICIpNDaQglhwgBhug");
	var mask_graphics_110 = new cjs.Graphics().p("Ak5C0QgBkBC2i4QAmgmAqgdIFuIEIpODWQglhwAAhug");
	var mask_graphics_111 = new cjs.Graphics().p("Ak5CzQAAkBC2i3QAmgmAqgdIFtIEIpPDVQgkhvAAhvg");
	var mask_graphics_112 = new cjs.Graphics().p("Ak5CzQAAkCC2i3QAmgmAqgdIFtIFIpPDUQgkhvAAhug");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:34.0481,y:60.7965}).wait(86).to({graphics:mask_graphics_86,x:34.0481,y:60.7965}).wait(1).to({graphics:mask_graphics_87,x:34.0386,y:60.7965}).wait(1).to({graphics:mask_graphics_88,x:33.9725,y:60.7975}).wait(1).to({graphics:mask_graphics_89,x:33.7929,y:60.8005}).wait(1).to({graphics:mask_graphics_90,x:33.443,y:60.8068}).wait(1).to({graphics:mask_graphics_91,x:32.8655,y:60.8193}).wait(1).to({graphics:mask_graphics_92,x:32.0027,y:60.8428}).wait(1).to({graphics:mask_graphics_93,x:30.892,y:60.8637}).wait(1).to({graphics:mask_graphics_94,x:30.8245,y:60.8206}).wait(1).to({graphics:mask_graphics_95,x:30.4466,y:60.6454}).wait(1).to({graphics:mask_graphics_96,x:30.1634,y:60.2388}).wait(1).to({graphics:mask_graphics_97,x:30.0864,y:59.463}).wait(1).to({graphics:mask_graphics_98,x:30.1001,y:58.1384}).wait(1).to({graphics:mask_graphics_99,x:30.109,y:56.0451}).wait(1).to({graphics:mask_graphics_100,x:30.0997,y:53.4197}).wait(1).to({graphics:mask_graphics_101,x:30.1183,y:50.8201}).wait(1).to({graphics:mask_graphics_102,x:30.1623,y:48.4167}).wait(1).to({graphics:mask_graphics_103,x:30.2155,y:46.3071}).wait(1).to({graphics:mask_graphics_104,x:30.2647,y:44.5359}).wait(1).to({graphics:mask_graphics_105,x:30.3035,y:43.1114}).wait(1).to({graphics:mask_graphics_106,x:30.3306,y:42.0173}).wait(1).to({graphics:mask_graphics_107,x:30.3479,y:41.2219}).wait(1).to({graphics:mask_graphics_108,x:30.3581,y:40.6837}).wait(1).to({graphics:mask_graphics_109,x:30.3635,y:40.3554}).wait(1).to({graphics:mask_graphics_110,x:30.3661,y:40.1863}).wait(1).to({graphics:mask_graphics_111,x:30.367,y:40.1239}).wait(1).to({graphics:mask_graphics_112,x:30.2276,y:40.0452}).wait(13));

	// smiles slice
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(117,190,221,0.749)").s().p("Aj9B3QAAjQCUiTQAegfAigXIEnGgIncCmQgfhUAAhZg");
	this.shape.setTransform(30.2868,43.3201,1.2385,1.2385);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(125));

	// memory mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("AgBEtIo2kLQBijXDehkQDfhjDzBhQD0BgBXC8QBXC9gQCOg");
	var mask_1_graphics_43 = new cjs.Graphics().p("AgBEtIo2kLQBijXDehkQDfhjDzBhQD0BgBXC8QBXC9gQCOg");
	var mask_1_graphics_44 = new cjs.Graphics().p("AgBEtIo2kMQBijXDfhjQDehjDzBhQD0BgBXC9QBXC9gQCNg");
	var mask_1_graphics_45 = new cjs.Graphics().p("AgCEsIo0kPQBjjWDfhiQDfhiDzBhQDzBiBWC9QBWC9gQCNg");
	var mask_1_graphics_46 = new cjs.Graphics().p("AgCEoIoxkVQBmjVDghgQDghfDyBkQDyBlBUC+QBTC+gSCNg");
	var mask_1_graphics_47 = new cjs.Graphics().p("AgCEhIoqkhQBqjUDjhaQDhhaDwBqQDwBqBPDAQBPDAgVCNg");
	var mask_1_graphics_48 = new cjs.Graphics().p("AgCEVIofk2QBzjQDmhRQDkhSDsB0QDsBzBHDDQBIDDgbCMg");
	var mask_1_graphics_49 = new cjs.Graphics().p("AgCEEIoMlVQB/jJDphEQDphEDlCBQDlCAA8DHQA9DHgjCKg");
	var mask_1_graphics_50 = new cjs.Graphics().p("AgBDrInvl9QCOi+DugyQDugxDZCTQDaCTAsDKQAtDLguCHg");
	var mask_1_graphics_51 = new cjs.Graphics().p("AgBDLInEmwQCiiuDygXQDygYDJCpQDICpAXDOQAWDPg7CBg");
	var mask_1_graphics_52 = new cjs.Graphics().p("AgDCkImEnqQC4iWDyAKQDzAJCwDDQCwDDgGDPQgGDQhMB4g");
	var mask_1_graphics_53 = new cjs.Graphics().p("AgFB3IkrokQDPh1DtAzQDuAzCMDeQCNDegqDLQgpDMhgBpg");
	var mask_1_graphics_54 = new cjs.Graphics().p("AgEBJIizpXQDhhIDeBkQDfBjBbD2QBbD1hSC/QhTC/h0BTg");
	var mask_1_graphics_55 = new cjs.Graphics().p("AgCAeIgYpxQDrgNC/CXQC/CYAcEFQAbEEiAClQh/CkiEA0g");
	var mask_1_graphics_56 = new cjs.Graphics().p("AgEgGICepdQDnA4CKDJQCLDIgyEBQgyECiqB4QiqB4iOALg");
	var mask_1_graphics_57 = new cjs.Graphics().p("AhpJWIBjpnIFHoVQDMB5BKDoQBKDnh6DoQh7DojGBCQiGAshqAAQgyAAgtgKg");
	var mask_1_graphics_58 = new cjs.Graphics().p("Aj+IrID5o8IHBmyQCnCnAPD0QAODyixDCQiwDDjQAOQgmADgjAAQidAAhng1g");
	var mask_1_graphics_59 = new cjs.Graphics().p("AgyJeQjOgdhvhZIFqn8IISlMQCBDHgkDwQglDxjVCZQizCCiuAAQggAAghgFg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AibJNQjHhAhdhrIG7m2IJCjtQBdDahMDmQhNDnjsBzQiYBKiIAAQhLAAhGgWg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AjtIzQi7hahPh2IHzl2IJdicQA/DkhrDaQhsDbj5BRQh3AnhoAAQhzAAhjgvg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AkpIYQixhthBh+IIYk/IJqhbQAmDpiCDOQiCDOkBA3QhWAShLAAQiaAAh2hJg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AlUIAQinh7g3iDIIwkTIJvgpQATDriSDDQiSDDkFAiQg4AHgzAAQi8AAiEhgg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AlxHsQihiFgviGII/jyIJxgFQAFDsidC6QidC6kGAUQghACgeAAQjaAAiMh0g");
	var mask_1_graphics_65 = new cjs.Graphics().p("AmEHeQiciLgqiIIJIjcIJxASQgEDuikCzQikC0kHAJIgeABQjxAAiRiCg");
	var mask_1_graphics_66 = new cjs.Graphics().p("AmQHUQiXiOgniJIJMjOIJwAhQgJDtioCwQioCwkHADIgKAAQj/AAiViMg");
	var mask_1_graphics_67 = new cjs.Graphics().p("AAHJgQkGAAiWiQQiWiQgmiKIJQjHIJvAoQgMDtiqCuQirCukGAAIAAAAg");
	var mask_1_graphics_68 = new cjs.Graphics().p("AAEJgQkGgBiViRQiWiRgkiJIJQjFIJvArQgNDtirCtQiqCskEAAIgEAAg");
	var mask_1_graphics_69 = new cjs.Graphics().p("AACJfQkGgBiViRQiWiRgkiJIJQjFIJvAsQgNDtirCtQiqCrkEAAIgEAAg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:62.344,y:28.9128}).wait(43).to({graphics:mask_1_graphics_43,x:62.344,y:28.9128}).wait(1).to({graphics:mask_1_graphics_44,x:62.3444,y:28.9322}).wait(1).to({graphics:mask_1_graphics_45,x:62.3472,y:29.0667}).wait(1).to({graphics:mask_1_graphics_46,x:62.3539,y:29.4317}).wait(1).to({graphics:mask_1_graphics_47,x:62.3632,y:30.1434}).wait(1).to({graphics:mask_1_graphics_48,x:62.3687,y:31.3182}).wait(1).to({graphics:mask_1_graphics_49,x:62.3585,y:33.0712}).wait(1).to({graphics:mask_1_graphics_50,x:62.3234,y:35.5084}).wait(1).to({graphics:mask_1_graphics_51,x:62.2925,y:38.705}).wait(1).to({graphics:mask_1_graphics_52,x:62.4496,y:42.6463}).wait(1).to({graphics:mask_1_graphics_53,x:62.6521,y:47.1012}).wait(1).to({graphics:mask_1_graphics_54,x:62.6047,y:51.7687}).wait(1).to({graphics:mask_1_graphics_55,x:62.3468,y:56.0519}).wait(1).to({graphics:mask_1_graphics_56,x:62.4991,y:59.6805}).wait(1).to({graphics:mask_1_graphics_57,x:62.7275,y:60.8273}).wait(1).to({graphics:mask_1_graphics_58,x:62.6609,y:60.7692}).wait(1).to({graphics:mask_1_graphics_59,x:62.5632,y:61.0736}).wait(1).to({graphics:mask_1_graphics_60,x:62.5225,y:61.1316}).wait(1).to({graphics:mask_1_graphics_61,x:62.4587,y:61.0404}).wait(1).to({graphics:mask_1_graphics_62,x:62.3866,y:60.9241}).wait(1).to({graphics:mask_1_graphics_63,x:62.3272,y:60.8408}).wait(1).to({graphics:mask_1_graphics_64,x:62.2881,y:60.8008}).wait(1).to({graphics:mask_1_graphics_65,x:62.2629,y:60.7908}).wait(1).to({graphics:mask_1_graphics_66,x:62.2313,y:60.7938}).wait(1).to({graphics:mask_1_graphics_67,x:62.2084,y:60.7985}).wait(1).to({graphics:mask_1_graphics_68,x:62.1988,y:60.8006}).wait(1).to({graphics:mask_1_graphics_69,x:62.0238,y:60.7312}).wait(56));

	// memories slice
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(98,123,157,0.749)").s().p("Al0BkQhVhUgjhoIHgifIH5AlQgUC5iAB9QiVCUjQAAQjSAAiWiUg");
	this.shape_1.setTransform(63.3248,89.7344,1.2385,1.2385);

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(125));

	// family mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("AiVGaQiwjAALkBQAKkFC+iuQAbgZAdgVIF2H2IAAABIiGJrQi/goiMiYg");
	var mask_2_graphics_1 = new cjs.Graphics().p("AiVGZQiwi/ALkCQAKkEC+iuQAcgZAcgVIF2H2IAAABIiGJrQi/goiMiZg");
	var mask_2_graphics_2 = new cjs.Graphics().p("AiXGYQivjBAMkBQALkEC/iuQAbgYAdgVIF0H4IAAAAIiJJrQi/gpiLiZg");
	var mask_2_graphics_3 = new cjs.Graphics().p("AibGUQitjCAOkBQAOkFDBirQAbgZAdgUIFvH7IAAABIiPJpQi+griKiag");
	var mask_2_graphics_4 = new cjs.Graphics().p("AijGMQipjGATkAQATkEDEioQAcgYAdgUIFlIDIAAAAIibJmQi9guiHidg");
	var mask_2_graphics_5 = new cjs.Graphics().p("AiwF/QijjLAckAQAbkDDJiiQAdgWAegTIFUINIAAABIiuJhQi8g1iCihg");
	var mask_2_graphics_6 = new cjs.Graphics().p("AjCFrQiZjSAoj/QAnkBDRiYQAegVAegSIE7IeIAAAAIjLJYQi5g9h6iog");
	var mask_2_graphics_7 = new cjs.Graphics().p("AjZFQQiLjdA5j7QA4j+DbiJQAegUAggPIEXIxIAAAAIjzJJQi1hJhuivg");
	var mask_2_graphics_8 = new cjs.Graphics().p("Aj1EsQh2joBOj1QBQj4Dkh2QAhgRAhgMIDkJHIAAAAIkmIyQiuhZhei4g");
	var mask_2_graphics_9 = new cjs.Graphics().p("AkSEHQhbjzBqjrQBrjuDxhaQAigNAigJICgJdIAAABIljINQikhthIjCg");
	var mask_2_graphics_10 = new cjs.Graphics().p("AksDVQg4j9CLjaQCMjcD7g3QAkgIAjgEIBIJuIAAAAImrHVQiSiDgsjKg");
	var mask_2_graphics_11 = new cjs.Graphics().p("AlNCTQgLkDCui/QCvjAECgLQAlgCAjADIglJxIAAAAIn1GEQh6ibgIjOg");
	var mask_2_graphics_12 = new cjs.Graphics().p("AmFBJQArkADSiWQDTiYD/ArQAkAGAiAKIimJbIAAAAIo7EUQhXixAjjLg");
	var mask_2_graphics_13 = new cjs.Graphics().p("AmfAAQBpjvDwheQDxhgDtBoQAhAPAfASIk1IgIAAABIpsB/QgpjABTi8g");
	var mask_2_graphics_14 = new cjs.Graphics().p("AoUEfQAHjEB/iiQCgjND/ghQECghDMCeQAdAXAZAYImwHFIgBAAg");
	var mask_2_graphics_15 = new cjs.Graphics().p("AAyE8IplifQAwi+CeiFQDHioEAAVQEEAVCmDGQAYAcAUAdIoGFhg");
	var mask_2_graphics_16 = new cjs.Graphics().p("AAXE9IpAkIQBQiyCzhoQDhiCD5BBQD8BCCCDfQASAfAPAgIo7EDg");
	var mask_2_graphics_17 = new cjs.Graphics().p("AAIE9IoVlWQBpimDAhNQDwhiDuBlQDxBlBgDuQAOAiAJAiIpZCvg");
	var mask_2_graphics_18 = new cjs.Graphics().p("AAAE9InqmRQB7iZDHg3QD6hFDhB/QDjB/BFD4QAKAkAGAjIpqBpg");
	var mask_2_graphics_19 = new cjs.Graphics().p("AgCE9InGm7QCIiNDMglQD/gvDVCSQDXCTAuD9QAHAkACAkIpwAyg");
	var mask_2_graphics_20 = new cjs.Graphics().p("AgDE8ImnnXQCRiFDOgXQEBgdDLCgQDNChAdD/QAEAlAAAjIpyAJg");
	var mask_2_graphics_21 = new cjs.Graphics().p("AgDEyIAAgBImQnrQCXh9DPgOQECgRDDCqQDFCrAREAQACAlgBAjg");
	var mask_2_graphics_22 = new cjs.Graphics().p("AgDEoIAAgBImAn4QCbh4DPgHQEDgJC9CwQC/CwAJECQABAlgCAjg");
	var mask_2_graphics_23 = new cjs.Graphics().p("AgDEhIAAAAIl2n/QCdh1DPgDQEDgEC6CzQC8C0ADECQABAlgDAjg");
	var mask_2_graphics_24 = new cjs.Graphics().p("AgDEeIAAAAIlxoDQCfh0DOAAQEEgCC4C2QC5C1ACEDQAAAkgEAjg");
	var mask_2_graphics_25 = new cjs.Graphics().p("AgDEdIAAAAIlvoFQCfhyDPgBQEDAAC3C2QC5C3ABECQAAAkgEAkg");
	var mask_2_graphics_26 = new cjs.Graphics().p("AgFEdIAAAAIlvoFQCghzDOAAQEDAAC4C2QC5C3AAECQAAAlgEAjg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:29.1737,y:60.1851}).wait(1).to({graphics:mask_2_graphics_1,x:29.1737,y:60.1815}).wait(1).to({graphics:mask_2_graphics_2,x:29.1744,y:60.1556}).wait(1).to({graphics:mask_2_graphics_3,x:29.1762,y:60.0833}).wait(1).to({graphics:mask_2_graphics_4,x:29.1791,y:59.9338}).wait(1).to({graphics:mask_2_graphics_5,x:29.1826,y:59.662}).wait(1).to({graphics:mask_2_graphics_6,x:29.1869,y:59.1987}).wait(1).to({graphics:mask_2_graphics_7,x:29.1955,y:58.4382}).wait(1).to({graphics:mask_2_graphics_8,x:29.2196,y:57.1321}).wait(1).to({graphics:mask_2_graphics_9,x:29.2816,y:54.1286}).wait(1).to({graphics:mask_2_graphics_10,x:29.4071,y:50.4686}).wait(1).to({graphics:mask_2_graphics_11,x:31.4283,y:46.164}).wait(1).to({graphics:mask_2_graphics_12,x:37.9735,y:40.4109}).wait(1).to({graphics:mask_2_graphics_13,x:45.2005,y:32.93}).wait(1).to({graphics:mask_2_graphics_14,x:51.6121,y:26.6764}).wait(1).to({graphics:mask_2_graphics_15,x:56.7623,y:26.7605}).wait(1).to({graphics:mask_2_graphics_16,x:59.4748,y:26.7841}).wait(1).to({graphics:mask_2_graphics_17,x:61.0479,y:26.8463}).wait(1).to({graphics:mask_2_graphics_18,x:61.8631,y:26.9369}).wait(1).to({graphics:mask_2_graphics_19,x:62.2162,y:27.0262}).wait(1).to({graphics:mask_2_graphics_20,x:62.3172,y:27.0966}).wait(1).to({graphics:mask_2_graphics_21,x:62.3319,y:28.2265}).wait(1).to({graphics:mask_2_graphics_22,x:62.3424,y:29.26}).wait(1).to({graphics:mask_2_graphics_23,x:62.3497,y:29.8839}).wait(1).to({graphics:mask_2_graphics_24,x:62.3539,y:30.2032}).wait(1).to({graphics:mask_2_graphics_25,x:62.3555,y:30.3207}).wait(1).to({graphics:mask_2_graphics_26,x:62.1813,y:30.477}).wait(99));

	// family slice
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(222,108,95,0.749)").s().p("AhoDmIgBAAIknmhQCAhdCnAAQDRAACUCTQCWCTAADRQAAAegEAcg");
	this.shape_2.setTransform(74.7813,30.4703,1.2385,1.2385);

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(125));

	// Layer_2
	this.instance = new lib.Clock_300x600();
	this.instance.setTransform(-9.5,-11.95,0.7782,0.7782);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(125));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-11.9,140.1,140.1);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_50 = function() {
		exportRoot.tl1.play();
		//exportRoot.tlbg.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(50).call(this.frame_50).wait(24).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.5,897.95,0.2,0.2,0,0,0,-39.8,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4,y:897.45},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSYBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_15 = new cjs.Graphics().p("EgSrBKRIAAwpMBbtAAAIAAQpg");
	var mask_graphics_16 = new cjs.Graphics().p("EgTlBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_17 = new cjs.Graphics().p("EgVEBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_18 = new cjs.Graphics().p("EgXJBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_19 = new cjs.Graphics().p("EgZ1BKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_20 = new cjs.Graphics().p("EgdHBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_21 = new cjs.Graphics().p("EggYBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_23 = new cjs.Graphics().p("EglJBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_25 = new cjs.Graphics().p("EgniBKRIAAwpMBbuAAAIAAQpg");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1BKRIAAwpMBbuAAAIAAQpg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:475.2595}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:475.2595}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:475.2595}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:475.2595}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:475.2595}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:475.2595}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:475.2595}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:475.2595}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:475.2595}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:475.2595}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:475.2595}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:475.2595}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:475.2595}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,891.55,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EhL2CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_70 = new cjs.Graphics().p("EhM1CYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_71 = new cjs.Graphics().p("EhTjCYiMAAAkxDMCXtAAAMAAAExDg");
	var mask_1_graphics_72 = new cjs.Graphics().p("EhanCYiMAAAkxDMCXtAAAMAAAExDg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:298.0324,y:908.6028}).wait(51).to({graphics:mask_1_graphics_51,x:298.0324,y:908.6028}).wait(1).to({graphics:mask_1_graphics_52,x:295.8271,y:908.6028}).wait(1).to({graphics:mask_1_graphics_53,x:289.2111,y:908.6028}).wait(1).to({graphics:mask_1_graphics_54,x:278.1844,y:908.6028}).wait(1).to({graphics:mask_1_graphics_55,x:262.7471,y:908.6028}).wait(1).to({graphics:mask_1_graphics_56,x:242.8992,y:908.6028}).wait(1).to({graphics:mask_1_graphics_57,x:218.6406,y:908.6028}).wait(1).to({graphics:mask_1_graphics_58,x:189.9713,y:908.6028}).wait(1).to({graphics:mask_1_graphics_59,x:156.8914,y:908.6028}).wait(1).to({graphics:mask_1_graphics_60,x:119.4008,y:908.6028}).wait(1).to({graphics:mask_1_graphics_61,x:77.4995,y:908.6028}).wait(1).to({graphics:mask_1_graphics_62,x:31.1876,y:908.6028}).wait(1).to({graphics:mask_1_graphics_63,x:-19.5349,y:908.6028}).wait(1).to({graphics:mask_1_graphics_64,x:-74.6682,y:908.6028}).wait(1).to({graphics:mask_1_graphics_65,x:-134.212,y:908.6028}).wait(1).to({graphics:mask_1_graphics_66,x:-198.1666,y:908.6028}).wait(1).to({graphics:mask_1_graphics_67,x:-266.5318,y:908.6028}).wait(1).to({graphics:mask_1_graphics_68,x:-339.3076,y:908.6028}).wait(1).to({graphics:mask_1_graphics_69,x:-416.4941,y:908.6028}).wait(1).to({graphics:mask_1_graphics_70,x:-491.7868,y:908.6028}).wait(1).to({graphics:mask_1_graphics_71,x:-534.7908,y:908.6028}).wait(1).to({graphics:mask_1_graphics_72,x:-580,y:908.6028}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(222.05,891.55,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(297.95,2254.65,1,5.7086,0,0,0,485.4,406.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({regY:406.9,scaleY:5.7085,x:-674.6,y:2255.2},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(297.95,2255.25,1,5.7085,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(53).to({x:-674.6},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1160,-67.6,1943.5,1953.1999999999998);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-15.4,-0.15,0.85,0.85,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-61.15,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("AqDCeIAAk7IUGAAIAAE7g");
	this.shape.setTransform(-58.05,-0.7);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-122.4,-16.5,128.70000000000002,31.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(285.7,3.4,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(234.3,556,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(297.35,556.25,0.9433,0.9433,0,0,0,0.1,0.2);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(32.15,31.6,0.9619,0.9619,0,0,0,-52.4,-23.5);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// bg img
	this.clock = new lib.clock();
	this.clock.name = "clock";
	this.clock.setTransform(194.1,261.1,1,1,0,0,0,60,60);

	this.backImage = new lib.mainImage();
	this.backImage.name = "backImage";
	this.backImage.setTransform(238.5,132.95,1,1,0,0,0,220.3,165.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.backImage},{t:this.clock}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-156.5,-1.3,478,622.5999999999999), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "cloc") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillClock(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillClock = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.clock.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var phone = mc.phone
		
		mc.cta.alpha=0
		mc.replay_btn.alpha=0
		
		
		this.runBanner = function() {
			
			mc.cta.alpha=1
			mc.replay_btn.alpha=1
		
		
			this.tl1 = new TimelineLite();
				
				exportRoot.tl1.from(mc.backImage, 1.4, {x:"+=200", ease:Power4.easeOut},"+=0");
				exportRoot.tl1.from(mc.clock, 1.4, {x:"+=200", ease:Power4.easeOut, onComplete:function(){mc.clock.play(); exportRoot.tl1.stop();}},"-=1.3");
				
				
				//exportRoot.tl1.to(mc.backImage, 1.4, {x:"-=77.2", ease:Power4.easeInOut},"+=0.7");
				//exportRoot.tl1.to(mc.clock, 1.4, {x:"-=156.8", ease:Power4.easeInOut},"-=1.4");
				//exportRoot.tl1.to(mc.white, 1.4, {x:"-=150", ease:Power4.easeInOut},"-=1.4");
				//exportRoot.tl1.from(mc.logo_1, 1.4, {x:"+=150", ease:Power4.easeInOut},"-=1.2");
				
				
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
					if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0");
					if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
					if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
					if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
			exportRoot.tlClock = new TimelineLite();
				for (var i = 0; i < exportRoot.clockText1.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText1[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText1[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				for (var i = 0; i < exportRoot.clockText2.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText2[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "+=0.5");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText2[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				for (var i = 0; i < exportRoot.clockText3.length; i++) {
					if (i==0) exportRoot.tlClock.from(exportRoot.clockText3[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "+=0.1");
					if (i!=0) exportRoot.tlClock.from(exportRoot.clockText3[i], 0.8, { alpha: 0, ease:Power4.easeOut}, "-=0.6");
				}
				exportRoot.tlClock.stop()
				//exportRoot.tl1.to(mc.clock, 1.4, {x:"-=153.15", ease:Power4.easeOut},"0");
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {	alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
				
				
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.6,298.7,328.1,322.59999999999997);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_.png?1582652746130", id:"O365_FY20Q4_Cons_USA_300x600_BAN_Hero_Family_Prospecting_English_NA_NA_ANI_LEA_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;