// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ['<#505050>Discover Microsoft 365','16px',281,35,'22','350', 'left']	['<#505050>+ Business Voice','16px',305,44,'17','350', 'left']	['<#505050>Meet Microsoft 365 with|Business Voice','16.2px',370 ,14,'18','350', 'left']	['<#505050>Meet, chat, and call coworkers and clients|from a single app','10.2px',371,55,'12','350','left']


	bannerData.CTA = ['<#FFFFFF>LEARN MORE','10px',0,0,'50','300', 'center']
	
	bannerData.CTAarrowVisible = [true, 0,0]
