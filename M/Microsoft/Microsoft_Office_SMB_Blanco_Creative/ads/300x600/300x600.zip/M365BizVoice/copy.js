// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ['<#505050>Discover Microsoft 365','20px',150,273,'24','350', 'center']	['<#505050>+ Business Voice','20px',150,278,'24','350', 'center']	['<#505050>Meet Microsoft 365|with Business Voice','22.5px',30,67,'27','350', 'left']	['<#505050>Meet, chat, and call coworkers|and clients from a single app','15px',30,130,'18','350','left']


	bannerData.CTA = ['<#FFFFFF>LEARN MORE','12px',1,0,'50','300', 'center']
	
	bannerData.CTAarrowVisible = [true, 0,0]
