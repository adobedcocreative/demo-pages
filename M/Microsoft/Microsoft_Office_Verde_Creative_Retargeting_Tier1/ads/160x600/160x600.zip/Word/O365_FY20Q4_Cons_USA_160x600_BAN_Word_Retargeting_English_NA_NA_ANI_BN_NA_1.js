(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[612,709,138,108],[612,492,268,215],[752,709,138,108],[612,819,138,108],[752,819,138,108],[741,0,138,108],[0,492,610,374],[0,0,739,490],[741,110,138,108]]}
];


// symbols:



(lib.Aimes = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Excel = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.OneDrive = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Outlook = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.Powerpoint = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.ScreenNoShadow = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.ScreenShadow11111 = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Word_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Word_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(98.5,114.35,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Word_1, new cjs.Rectangle(98.5,114.4,231,180.70000000000002), null);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg8HDe5MAAAm9xMB4OAAAMAAAG9xg");
	this.shape.setTransform(-1.25,0.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-386,-1426.4,769.5,2853);


(lib.Screen_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.ScreenShadow11111();
	this.instance.setTransform(28.1,-45.55,1.4999,1.4999,-0.7881);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen_Shadow, new cjs.Rectangle(28.1,-60.8,1118.4,750.0999999999999), null);


(lib.Screen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.ScreenNoShadow();
	this.instance.setTransform(121,48.3,1.504,1.504,-0.9487);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Screen, new cjs.Rectangle(121,33.1,926.5999999999999,577.6), null);


(lib.Powerpoint_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.pointer2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoCvQgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgFQgDgHACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAhuQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAEQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gdQgGAFgBAHQgCAGAEAFIBXBvQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhkQAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACVQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgNIgRgUQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,19.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCbIAAgeQAAgMgHgIIhXhvQgEgFACgGQABgHAGgFQALgJANAKIARAUIAFANQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAiVQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAABkQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,19.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2_sub, new cjs.Rectangle(0,2.4,29.6,35), null);


(lib.pointer1_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoC7QgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgGQgDgGACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAiGQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAcQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gRQgGAFgBAHQgCAFAEAFIBXBwQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAh8QAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACtQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgOIgRgTQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,18.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCnIAAgeQAAgMgHgIIhXhwQgEgFACgFQABgHAGgFQALgJANAKIARATIAFAOQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAitQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAAB8QAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,18.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1_sub, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.overlay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.098)").s().p("Aq1CYIAAkvIVrAAIAAEvg");
	this.shape.setTransform(69.425,15.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlay, new cjs.Rectangle(0,0,138.9,30.3), null);


(lib.Outlook_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.OneDrive_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.menu_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt1 = new cjs.Text("Learn more", "12px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 12;
	this.txt1.lineWidth = 137;
	this.txt1.parent = this;
	this.txt1.setTransform(2,2);

	this.txt2 = new cjs.Text("Monthly subscription", "12px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 137;
	this.txt2.parent = this;
	this.txt2.setTransform(2,32);

	this.txt3 = new cjs.Text("SAVE 16%\nAnnual subscription", "12px 'Segoe Pro'", "#0078D3");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 12;
	this.txt3.lineWidth = 137;
	this.txt3.parent = this;
	this.txt3.setTransform(2,54.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt3},{t:this.txt2},{t:this.txt1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.menu_text, new cjs.Rectangle(0,0,141.1,84.9), null);


(lib.mainBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFEFEF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Excel_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.dropDownMenuBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s().p("Aq8CWIAAkrIV5AAIAAErg");
	this.shape.setTransform(70.125,15);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,140.3,30);


(lib.choice_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("BUY NOW", "12px 'Segoe Pro'", "#0078D3");
	this.txt.name = "txt";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 216;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.choice_text, new cjs.Rectangle(0,0,219.8,26.6), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(80.0011,300.0046,0.5333,1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,160,600), null);


(lib.Aimes_Shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Aimes_Shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.Wordcopy2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(98.5,114.35,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_2
	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Wordcopy2, new cjs.Rectangle(84.5,114.4,254.60000000000002,219.79999999999998), null);


(lib.Wordcopy = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Word_Shadow();
	this.instance.setTransform(211.9,232.15,0.95,0.95,0,0,0,134.1,107.5);
	this.instance.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Wordcopy, new cjs.Rectangle(84.5,130.1,254.60000000000002,204.20000000000002), null);


(lib.Teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Aimes();
	this.instance.setTransform(96.75,90.55,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Aimes_Shadow();
	this.instance_1.setTransform(211.15,212.1,0.95,0.95,0,0,0,134,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Teams, new cjs.Rectangle(83.9,90.6,254.6,223.70000000000002), null);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_207 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(207).call(this.frame_207).wait(1));

	// Word
	this.instance = new lib.Word_1();
	this.instance.setTransform(93.15,-192.8,0.055,0.055,0,0,0,221,196.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(185).to({_off:false},0).to({regX:220.7,regY:196.6,scaleX:0.4447,scaleY:0.4447,x:203.5,y:-206.65},22,cjs.Ease.quadOut).wait(1));

	// Word Shadow
	this.instance_1 = new lib.Wordcopy();
	this.instance_1.setTransform(93.15,-192.8,0.055,0.055,0,0,0,221,196.4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(185).to({_off:false},0).to({regX:220.7,regY:196.6,scaleX:0.4447,scaleY:0.4447,x:203.5,y:-206.65},22,cjs.Ease.quadOut).wait(1));

	// Screen
	this.instance_2 = new lib.Screen();
	this.instance_2.setTransform(748.15,671.55,1,1,0,0,0,581.6,357.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:361.6,y:43.15},119).wait(1).to({regX:584.3,regY:321.9,x:361.9,y:2.65},0).wait(1).to({x:359.4,y:-2},0).wait(1).to({x:356.9,y:-6.7},0).wait(1).to({x:354.4,y:-11.45},0).wait(1).to({x:351.9,y:-16.2},0).wait(1).to({x:349.4,y:-20.95},0).wait(1).to({x:346.85,y:-25.75},0).wait(1).to({x:344.3,y:-30.5},0).wait(1).to({x:341.8,y:-35.3},0).wait(1).to({x:339.25,y:-40.05},0).wait(1).to({x:336.75,y:-44.8},0).wait(1).to({x:334.25,y:-49.5},0).wait(1).to({x:331.8,y:-54.15},0).wait(1).to({x:329.35,y:-58.8},0).wait(1).to({x:326.95,y:-63.35},0).wait(1).to({x:324.55,y:-67.85},0).wait(1).to({x:322.2,y:-72.25},0).wait(1).to({x:319.95,y:-76.55},0).wait(1).to({x:317.7,y:-80.8},0).wait(1).to({x:315.5,y:-84.95},0).wait(1).to({x:313.35,y:-88.95},0).wait(1).to({x:311.3,y:-92.85},0).wait(1).to({x:309.3,y:-96.6},0).wait(1).to({x:307.4,y:-100.25},0).wait(1).to({x:305.55,y:-103.75},0).wait(1).to({x:303.75,y:-107.1},0).wait(1).to({x:302.05,y:-110.3},0).wait(1).to({x:300.45,y:-113.4},0).wait(1).to({x:298.9,y:-116.3},0).wait(1).to({x:297.45,y:-119.05},0).wait(1).to({x:296.05,y:-121.65},0).wait(1).to({x:294.8,y:-124.05},0).wait(1).to({x:293.6,y:-126.35},0).wait(1).to({x:292.45,y:-128.45},0).wait(1).to({x:291.45,y:-130.4},0).wait(1).to({x:290.5,y:-132.2},0).wait(1).to({x:289.6,y:-133.85},0).wait(1).to({x:288.85,y:-135.3},0).wait(1).to({x:288.1,y:-136.65},0).wait(1).to({x:287.5,y:-137.85},0).wait(1).to({x:286.95,y:-138.85},0).wait(1).to({x:286.45,y:-139.75},0).wait(1).to({x:286.1,y:-140.5},0).wait(1).to({x:285.75,y:-141.1},0).wait(1).to({x:285.5,y:-141.6},0).wait(1).to({regX:581.6,regY:357.8,x:282.6,y:-106.05},0).wait(1).to({regX:584.3,regY:321.9,scaleX:0.9984,scaleY:0.9984,x:285.75,y:-142},0).wait(1).to({scaleX:0.9959,scaleY:0.9959,x:286.4,y:-142.2},0).wait(1).to({scaleX:0.9923,scaleY:0.9923,x:287.3,y:-142.4},0).wait(1).to({scaleX:0.9877,scaleY:0.9877,x:288.5,y:-142.75},0).wait(1).to({scaleX:0.9818,scaleY:0.9818,x:290.05,y:-143.15},0).wait(1).to({scaleX:0.9746,scaleY:0.9746,x:291.9,y:-143.65},0).wait(1).to({scaleX:0.9658,scaleY:0.9658,x:294.2,y:-144.25},0).wait(1).to({scaleX:0.9554,scaleY:0.9554,x:296.9,y:-144.9},0).wait(1).to({scaleX:0.9431,scaleY:0.9431,x:300.05,y:-145.75},0).wait(1).to({scaleX:0.9289,scaleY:0.9289,x:303.8,y:-146.7},0).wait(1).to({scaleX:0.9126,scaleY:0.9126,x:308,y:-147.8},0).wait(1).to({scaleX:0.8942,scaleY:0.8942,x:312.8,y:-149.05},0).wait(1).to({scaleX:0.8738,scaleY:0.8738,x:318.1,y:-150.45},0).wait(1).to({scaleX:0.8517,scaleY:0.8517,x:323.8,y:-151.9},0).wait(1).to({scaleX:0.8283,scaleY:0.8283,x:329.9,y:-153.5},0).wait(1).to({scaleX:0.8043,scaleY:0.8043,x:336.05,y:-155.15},0).wait(1).to({scaleX:0.7804,scaleY:0.7804,x:342.3,y:-156.75},0).wait(1).to({scaleX:0.757,scaleY:0.757,x:348.35,y:-158.3},0).wait(1).to({scaleX:0.7348,scaleY:0.7348,x:354.1,y:-159.8},0).wait(1).to({scaleX:0.7141,scaleY:0.7141,x:359.5,y:-161.2},0).wait(1).to({scaleX:0.6949,scaleY:0.6949,x:364.45,y:-162.5},0).wait(1).to({scaleX:0.6774,scaleY:0.6774,x:368.95,y:-163.7},0).wait(1).to({scaleX:0.6616,scaleY:0.6616,x:373.1,y:-164.75},0).wait(1).to({scaleX:0.6473,scaleY:0.6473,x:376.85,y:-165.7},0).wait(1).to({scaleX:0.6344,scaleY:0.6344,x:380.1,y:-166.6},0).wait(1).to({scaleX:0.6229,scaleY:0.6229,x:383.1,y:-167.35},0).wait(1).to({scaleX:0.6126,scaleY:0.6126,x:385.75,y:-168.05},0).wait(1).to({scaleX:0.6034,scaleY:0.6034,x:388.1,y:-168.65},0).wait(1).to({scaleX:0.5953,scaleY:0.5953,x:390.25,y:-169.25},0).wait(1).to({scaleX:0.5881,scaleY:0.5881,x:392.1,y:-169.7},0).wait(1).to({scaleX:0.5818,scaleY:0.5818,x:393.75,y:-170.15},0).wait(1).to({scaleX:0.5762,scaleY:0.5762,x:395.2,y:-170.5},0).wait(1).to({scaleX:0.5715,scaleY:0.5715,x:396.45,y:-170.8},0).wait(1).to({scaleX:0.5673,scaleY:0.5673,x:397.5,y:-171.1},0).wait(1).to({scaleX:0.5638,scaleY:0.5638,x:398.4,y:-171.35},0).wait(1).to({scaleX:0.5609,scaleY:0.5609,x:399.15,y:-171.55},0).wait(1).to({scaleX:0.5585,scaleY:0.5585,x:399.75,y:-171.7},0).wait(1).to({scaleX:0.5567,scaleY:0.5567,x:400.25,y:-171.8},0).wait(1).to({scaleX:0.5553,scaleY:0.5553,x:400.65,y:-171.9},0).wait(1).to({scaleX:0.5543,scaleY:0.5543,x:400.85,y:-172},0).wait(1).to({scaleX:0.5537,scaleY:0.5537,x:401.05},0).wait(1).to({regX:581.7,regY:357.7,scaleX:0.5535,scaleY:0.5535,x:399.65,y:-152.2},0).wait(1));

	// Screen Shadow
	this.instance_3 = new lib.Screen_Shadow();
	this.instance_3.setTransform(755.2,672,1,1,0,0,0,581.6,357.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:361.6,y:40.1},119).wait(1).to({regX:587.3,regY:314.3,x:364.75,y:-8},0).wait(1).to({x:362.15,y:-12.65},0).wait(1).to({x:359.55,y:-17.35},0).wait(1).to({x:356.9,y:-22.1},0).wait(1).to({x:354.25,y:-26.85},0).wait(1).to({x:351.6,y:-31.6},0).wait(1).to({x:348.95,y:-36.4},0).wait(1).to({x:346.3,y:-41.15},0).wait(1).to({x:343.65,y:-45.95},0).wait(1).to({x:341,y:-50.7},0).wait(1).to({x:338.35,y:-55.45},0).wait(1).to({x:335.7,y:-60.15},0).wait(1).to({x:333.15,y:-64.8},0).wait(1).to({x:330.55,y:-69.45},0).wait(1).to({x:328,y:-74},0).wait(1).to({x:325.5,y:-78.5},0).wait(1).to({x:323.05,y:-82.9},0).wait(1).to({x:320.65,y:-87.2},0).wait(1).to({x:318.3,y:-91.45},0).wait(1).to({x:316,y:-95.6},0).wait(1).to({x:313.75,y:-99.6},0).wait(1).to({x:311.6,y:-103.5},0).wait(1).to({x:309.5,y:-107.25},0).wait(1).to({x:307.45,y:-110.9},0).wait(1).to({x:305.5,y:-114.4},0).wait(1).to({x:303.65,y:-117.75},0).wait(1).to({x:301.85,y:-120.95},0).wait(1).to({x:300.15,y:-124.05},0).wait(1).to({x:298.55,y:-126.95},0).wait(1).to({x:297,y:-129.7},0).wait(1).to({x:295.55,y:-132.3},0).wait(1).to({x:294.2,y:-134.7},0).wait(1).to({x:292.95,y:-137},0).wait(1).to({x:291.8,y:-139.1},0).wait(1).to({x:290.7,y:-141.05},0).wait(1).to({x:289.7,y:-142.85},0).wait(1).to({x:288.8,y:-144.5},0).wait(1).to({x:287.95,y:-145.95},0).wait(1).to({x:287.2,y:-147.3},0).wait(1).to({x:286.55,y:-148.5},0).wait(1).to({x:286,y:-149.5},0).wait(1).to({x:285.5,y:-150.4},0).wait(1).to({x:285.05,y:-151.15},0).wait(1).to({x:284.75,y:-151.75},0).wait(1).to({x:284.45,y:-152.25},0).wait(1).to({regX:581.6,regY:357.8,x:278.55,y:-109.1},0).wait(1).to({regX:587.3,regY:314.3,scaleX:0.9984,scaleY:0.9984,x:284.7,y:-152.65},0).wait(1).to({scaleX:0.9959,scaleY:0.9959,x:285.35,y:-152.8},0).wait(1).to({scaleX:0.9923,scaleY:0.9923,x:286.3,y:-152.95},0).wait(1).to({scaleX:0.9877,scaleY:0.9877,x:287.55,y:-153.2},0).wait(1).to({scaleX:0.9818,scaleY:0.9818,x:289.1,y:-153.55},0).wait(1).to({scaleX:0.9746,scaleY:0.9746,x:291.05,y:-153.95},0).wait(1).to({scaleX:0.9658,scaleY:0.9658,x:293.35,y:-154.4},0).wait(1).to({scaleX:0.9554,scaleY:0.9554,x:296.1,y:-154.9},0).wait(1).to({scaleX:0.9431,scaleY:0.9431,x:299.4,y:-155.55},0).wait(1).to({scaleX:0.9289,scaleY:0.9289,x:303.2,y:-156.35},0).wait(1).to({scaleX:0.9126,scaleY:0.9126,x:307.5,y:-157.2},0).wait(1).to({scaleX:0.8942,scaleY:0.8942,x:312.4,y:-158.15},0).wait(1).to({scaleX:0.8738,scaleY:0.8738,x:317.8,y:-159.3},0).wait(1).to({scaleX:0.8517,scaleY:0.8517,x:323.7,y:-160.45},0).wait(1).to({scaleX:0.8283,scaleY:0.8283,x:329.85,y:-161.65},0).wait(1).to({scaleX:0.8043,scaleY:0.8043,x:336.25,y:-162.95},0).wait(1).to({scaleX:0.7804,scaleY:0.7804,x:342.55,y:-164.25},0).wait(1).to({scaleX:0.757,scaleY:0.757,x:348.75,y:-165.45},0).wait(1).to({scaleX:0.7348,scaleY:0.7348,x:354.65,y:-166.65},0).wait(1).to({scaleX:0.7141,scaleY:0.7141,x:360.2,y:-167.7},0).wait(1).to({scaleX:0.6949,scaleY:0.6949,x:365.25,y:-168.75},0).wait(1).to({scaleX:0.6774,scaleY:0.6774,x:369.9,y:-169.7},0).wait(1).to({scaleX:0.6616,scaleY:0.6616,x:374.1,y:-170.5},0).wait(1).to({scaleX:0.6473,scaleY:0.6473,x:377.95,y:-171.25},0).wait(1).to({scaleX:0.6344,scaleY:0.6344,x:381.25,y:-171.95},0).wait(1).to({scaleX:0.6229,scaleY:0.6229,x:384.35,y:-172.55},0).wait(1).to({scaleX:0.6126,scaleY:0.6126,x:387.05,y:-173.1},0).wait(1).to({scaleX:0.6034,scaleY:0.6034,x:389.45,y:-173.6},0).wait(1).to({scaleX:0.5953,scaleY:0.5953,x:391.65,y:-174},0).wait(1).to({scaleX:0.5881,scaleY:0.5881,x:393.6,y:-174.4},0).wait(1).to({scaleX:0.5818,scaleY:0.5818,x:395.2,y:-174.75},0).wait(1).to({scaleX:0.5762,scaleY:0.5762,x:396.7,y:-175.05},0).wait(1).to({scaleX:0.5715,scaleY:0.5715,x:397.95,y:-175.3},0).wait(1).to({scaleX:0.5673,scaleY:0.5673,x:399.1,y:-175.5},0).wait(1).to({scaleX:0.5638,scaleY:0.5638,x:400,y:-175.7},0).wait(1).to({scaleX:0.5609,scaleY:0.5609,x:400.75,y:-175.85},0).wait(1).to({scaleX:0.5585,scaleY:0.5585,x:401.4,y:-175.95},0).wait(1).to({scaleX:0.5567,scaleY:0.5567,x:401.9,y:-176.05},0).wait(1).to({scaleX:0.5553,scaleY:0.5553,x:402.3,y:-176.15},0).wait(1).to({scaleX:0.5543,scaleY:0.5543,x:402.55,y:-176.2},0).wait(1).to({scaleX:0.5537,scaleY:0.5537,x:402.7},0).wait(1).to({regX:581.7,regY:357.7,scaleX:0.5535,scaleY:0.5535,x:399.65,y:-152.2},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-274.9,-527.7,1595,1531.2);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.Powerpoint_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Powerpoint();
	this.instance.setTransform(92.6,111.85,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Powerpoint_Shadow();
	this.instance_1.setTransform(202.7,235.85,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Powerpoint_1, new cjs.Rectangle(75.3,111.9,254.59999999999997,226.1), null);


(lib.pointer2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer2_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(11.35,8.3,1,1,-3.4817,0,0,11.3,8.3);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2, new cjs.Rectangle(-0.3,1.3,31.6,36.7), null);


(lib.pointer1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer1_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_1
	this.instance = new lib.pointer1();
	this.instance.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.instance_1 = new lib.pointer2();
	this.instance_1.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0,31.6,38);


(lib.Outlook_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_4
	this.instance = new lib.Outlook();
	this.instance.setTransform(97.4,110.5,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_1, new cjs.Rectangle(84.5,110.5,254.60000000000002,223.7), null);


(lib.OneDrive_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.OneDrive();
	this.instance.setTransform(97.4,110.5,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3 copy
	this.instance_1 = new lib.OneDrive_shadow();
	this.instance_1.setTransform(211.9,232.05,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.OneDrive_1, new cjs.Rectangle(84.5,110.5,254.60000000000002,223.7), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		exportRoot.mainMC.icons.play()
	}
	this.frame_86 = function() {
		exportRoot.tl1.play()
		exportRoot.mainMC.screen.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(17).call(this.frame_86).wait(14).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:0.3,scaleX:3.2298,scaleY:3.2298,x:166.95,y:-920.35},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(298.9,337.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-87.1,-1088.8,769.5,2853);


(lib.menuChoice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.choice_text.cache(0,-20,220,27,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3F3F").s().p("AgkASIAkgjIAlAjg");
	this.shape.setTransform(173.675,195.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Outline
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#292929").s().p("Aq3CYIAAkvIAHAAIVoAAIAAEvgAqwCSIVhAAIAAkgI1hAAg");
	this.shape_1.setTransform(122.95,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Text
	this.choice_text = new lib.choice_text();
	this.choice_text.name = "choice_text";
	this.choice_text.setTransform(174.9,211.5,1,1,0,0,0,109.9,13.3);

	this.timeline.addTween(cjs.Tween.get(this.choice_text).wait(1));

	// Layer_2
	this.txt2 = new cjs.Text("", "11px 'Segoe Pro'", "#D84739");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 17;
	this.txt2.lineWidth = 216;
	this.txt2.parent = this;
	this.txt2.setTransform(67,200.2);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqzCVIAAkpIVnAAIAAEpg");
	this.shape_2.setTransform(122.925,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(53.4,180.4,231.4,44.400000000000006);


(lib.Menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.menu_text.cache(0,-10,150,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.btn1 = new lib.dropDownMenuBtn();
	this.btn1.name = "btn1";
	this.btn1.setTransform(0.15,-0.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn2 = new lib.dropDownMenuBtn();
	this.btn2.name = "btn2";
	this.btn2.setTransform(0.15,29.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn3 = new lib.dropDownMenuBtn();
	this.btn3.name = "btn3";
	this.btn3.setTransform(0.15,58.9,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn3},{t:this.btn2},{t:this.btn1}]}).wait(1));

	// Outline
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#292929").s().p("AKzG+IAAgBI1lAAIAAABIgHAAIAAt7IVyAAIAAN7gAqyG2IVlAAIAAkeI1lAAgAqyCRIVlAAIAAkeI1lAAgAqyiUIVlAAIAAkiI1lAAg");
	this.shape.setTransform(69.15,43.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// txt_backup
	this.menu_text = new lib.menu_text();
	this.menu_text.name = "menu_text";
	this.menu_text.setTransform(81.75,59.5,1,1,0,0,0,70.5,42.5);

	this.timeline.addTween(cjs.Tween.get(this.menu_text).wait(1));

	// rollOver
	this.ro3 = new lib.overlay();
	this.ro3.name = "ro3";
	this.ro3.setTransform(114.2,73.1,1,0.9439,0,0,0,114.4,15.2);
	this.ro3.alpha = 0;

	this.ro2 = new lib.overlay();
	this.ro2.name = "ro2";
	this.ro2.setTransform(114.2,43.9,1,0.9439,0,0,0,114.4,15.2);
	this.ro2.alpha = 0;

	this.ro1 = new lib.overlay();
	this.ro1.name = "ro1";
	this.ro1.setTransform(114.2,14.65,1,1,0,0,0,114.4,15.2);
	this.ro1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ro1},{t:this.ro2},{t:this.ro3}]}).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AqzG6IAAtzIVnAAIAANzg");
	this.shape_1.setTransform(68.925,43.575);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-0.9,152.9,102.80000000000001);


(lib.Excel_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.Excel();
	this.instance.setTransform(111.85,124.45,1.6738,1.6738);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_3
	this.instance_1 = new lib.Excel_Shadow();
	this.instance_1.setTransform(226.25,246,0.95,0.95,0,0,0,134,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Excel_1, new cjs.Rectangle(99,124.5,254.60000000000002,223.7), null);


(lib.drop_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// pointer
	this.pointer = new lib.pointer();
	this.pointer.name = "pointer";
	this.pointer.setTransform(117.8,232.6,0.6379,0.6379,0,0,0,14.8,18.8);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsHCkIAAlHIYPAAIAAFHg");
	mask.setTransform(90.4,220.825);

	// Menu
	this.selectorBox = new lib.menuChoice();
	this.selectorBox.name = "selectorBox";
	this.selectorBox.setTransform(138.45,114.6,1,1,0,0,0,175.3,90.5);

	var maskedShapeInstanceList = [this.selectorBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.selectorBox).wait(1));

	// Layer_6 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ay1HhIAAvBMAlrAAAIAAPBg");
	mask_1.setTransform(133.4,157.025);

	// Menu copy
	this.menu = new lib.Menu();
	this.menu.name = "menu";
	this.menu.setTransform(16.5,205.3,1,1,0,0,0,-0.5,-0.7);

	var maskedShapeInstanceList = [this.menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.menu).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.drop_menu, new cjs.Rectangle(16.4,204.5,152.9,40), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,160,600,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,160,600), null);


(lib.icon_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_200 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(200).call(this.frame_200).wait(1));

	// OneDrive
	this.instance = new lib.OneDrive_1();
	this.instance.setTransform(337.85,167.2,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-229.1,y:-785.4},149).wait(1).to({regX:211.8,regY:222.3,x:-240.7,y:-764.95},0).wait(1).to({x:-243.65,y:-770.1},0).wait(1).to({x:-246.6,y:-775.25},0).wait(1).to({x:-249.6,y:-780.45},0).wait(1).to({x:-252.6,y:-785.65},0).wait(1).to({x:-255.65,y:-790.95},0).wait(1).to({x:-258.7,y:-796.25},0).wait(1).to({x:-261.8,y:-801.65},0).wait(1).to({x:-264.95,y:-807.05},0).wait(1).to({x:-268.1,y:-812.55},0).wait(1).to({x:-271.3,y:-818.1},0).wait(1).to({x:-274.55,y:-823.75},0).wait(1).to({x:-277.8,y:-829.45},0).wait(1).to({x:-281.15,y:-835.2},0).wait(1).to({x:-284.5,y:-841.1},0).wait(1).to({x:-287.95,y:-847.05},0).wait(1).to({x:-291.45,y:-853.1},0).wait(1).to({x:-295,y:-859.25},0).wait(1).to({x:-298.6,y:-865.55},0).wait(1).to({x:-302.3,y:-871.95},0).wait(1).to({x:-306.05,y:-878.5},0).wait(1).to({x:-309.9,y:-885.2},0).wait(1).to({x:-313.85,y:-892.05},0).wait(1).to({x:-317.85,y:-899.05},0).wait(1).to({x:-322,y:-906.25},0).wait(1).to({x:-326.25,y:-913.65},0).wait(1).to({x:-330.65,y:-921.25},0).wait(1).to({x:-335.15,y:-929.1},0).wait(1).to({x:-339.8,y:-937.15},0).wait(1).to({x:-344.65,y:-945.55},0).wait(1).to({x:-349.6,y:-954.2},0).wait(1).to({x:-354.8,y:-963.2},0).wait(1).to({x:-360.15,y:-972.5},0).wait(1).to({x:-365.75,y:-982.2},0).wait(1).to({x:-371.55,y:-992.35},0).wait(1).to({x:-377.65,y:-1002.9},0).wait(1).to({x:-384,y:-1013.95},0).wait(1).to({x:-390.65,y:-1025.5},0).wait(1).to({x:-397.65,y:-1037.65},0).wait(1).to({x:-405,y:-1050.4},0).wait(1).to({x:-412.7,y:-1063.85},0).wait(1).to({x:-420.85,y:-1078},0).wait(1).to({x:-429.45,y:-1092.95},0).wait(1).to({x:-438.55,y:-1108.75},0).wait(1).to({x:-448.15,y:-1125.45},0).wait(1).to({x:-458.35,y:-1143.1},0).wait(1).to({x:-469.1,y:-1161.8},0).wait(1).to({x:-480.5,y:-1181.6},0).wait(1).to({x:-492.55,y:-1202.55},0).wait(1).to({regX:220.5,regY:196.8,x:-496.6,y:-1250.2},0).to({_off:true},1).wait(1));

	// Outlook
	this.instance_1 = new lib.Outlook_1();
	this.instance_1.setTransform(313.95,355.4,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-253,y:-597.2},149).wait(1).to({regX:211.8,regY:222.3,x:-264.6,y:-576.75},0).wait(1).to({x:-267.55,y:-581.9},0).wait(1).to({x:-270.5,y:-587.05},0).wait(1).to({x:-273.5,y:-592.25},0).wait(1).to({x:-276.5,y:-597.45},0).wait(1).to({x:-279.55,y:-602.75},0).wait(1).to({x:-282.6,y:-608.05},0).wait(1).to({x:-285.7,y:-613.45},0).wait(1).to({x:-288.85,y:-618.85},0).wait(1).to({x:-292,y:-624.35},0).wait(1).to({x:-295.2,y:-629.9},0).wait(1).to({x:-298.45,y:-635.55},0).wait(1).to({x:-301.7,y:-641.25},0).wait(1).to({x:-305.05,y:-647},0).wait(1).to({x:-308.4,y:-652.9},0).wait(1).to({x:-311.85,y:-658.85},0).wait(1).to({x:-315.35,y:-664.9},0).wait(1).to({x:-318.9,y:-671.05},0).wait(1).to({x:-322.5,y:-677.35},0).wait(1).to({x:-326.2,y:-683.75},0).wait(1).to({x:-329.95,y:-690.3},0).wait(1).to({x:-333.8,y:-697},0).wait(1).to({x:-337.75,y:-703.85},0).wait(1).to({x:-341.75,y:-710.85},0).wait(1).to({x:-345.9,y:-718.05},0).wait(1).to({x:-350.15,y:-725.45},0).wait(1).to({x:-354.55,y:-733.05},0).wait(1).to({x:-359.05,y:-740.9},0).wait(1).to({x:-363.7,y:-748.95},0).wait(1).to({x:-368.55,y:-757.35},0).wait(1).to({x:-373.5,y:-766},0).wait(1).to({x:-378.7,y:-775},0).wait(1).to({x:-384.05,y:-784.3},0).wait(1).to({x:-389.65,y:-794},0).wait(1).to({x:-395.45,y:-804.15},0).wait(1).to({x:-401.55,y:-814.7},0).wait(1).to({x:-407.9,y:-825.75},0).wait(1).to({x:-414.55,y:-837.3},0).wait(1).to({x:-421.55,y:-849.45},0).wait(1).to({x:-428.9,y:-862.2},0).wait(1).to({x:-436.6,y:-875.65},0).wait(1).to({x:-444.75,y:-889.8},0).wait(1).to({x:-453.35,y:-904.75},0).wait(1).to({x:-462.45,y:-920.55},0).wait(1).to({x:-472.05,y:-937.25},0).wait(1).to({x:-482.25,y:-954.9},0).wait(1).to({x:-493,y:-973.6},0).wait(1).to({x:-504.4,y:-993.4},0).wait(1).to({x:-516.45,y:-1014.35},0).wait(1).to({regX:220.5,regY:196.8,x:-520.5,y:-1062},0).to({_off:true},1).wait(1));

	// Aimes
	this.instance_2 = new lib.Teams();
	this.instance_2.setTransform(511.6,312.75,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({x:-71.6,y:-639.85},149).wait(1).to({regX:211.1,regY:202.4,x:-83.9,y:-639.3},0).wait(1).to({x:-86.85,y:-644.45},0).wait(1).to({x:-89.8,y:-649.6},0).wait(1).to({x:-92.8,y:-654.8},0).wait(1).to({x:-95.8,y:-660},0).wait(1).to({x:-98.85,y:-665.3},0).wait(1).to({x:-101.9,y:-670.6},0).wait(1).to({x:-105,y:-676},0).wait(1).to({x:-108.15,y:-681.4},0).wait(1).to({x:-111.3,y:-686.9},0).wait(1).to({x:-114.5,y:-692.45},0).wait(1).to({x:-117.75,y:-698.1},0).wait(1).to({x:-121,y:-703.8},0).wait(1).to({x:-124.35,y:-709.55},0).wait(1).to({x:-127.7,y:-715.45},0).wait(1).to({x:-131.15,y:-721.4},0).wait(1).to({x:-134.65,y:-727.45},0).wait(1).to({x:-138.2,y:-733.6},0).wait(1).to({x:-141.8,y:-739.9},0).wait(1).to({x:-145.5,y:-746.3},0).wait(1).to({x:-149.25,y:-752.85},0).wait(1).to({x:-153.1,y:-759.55},0).wait(1).to({x:-157.05,y:-766.4},0).wait(1).to({x:-161.05,y:-773.4},0).wait(1).to({x:-165.2,y:-780.6},0).wait(1).to({x:-169.45,y:-788},0).wait(1).to({x:-173.85,y:-795.6},0).wait(1).to({x:-178.35,y:-803.45},0).wait(1).to({x:-183,y:-811.5},0).wait(1).to({x:-187.85,y:-819.9},0).wait(1).to({x:-192.8,y:-828.55},0).wait(1).to({x:-198,y:-837.55},0).wait(1).to({x:-203.35,y:-846.85},0).wait(1).to({x:-208.95,y:-856.55},0).wait(1).to({x:-214.75,y:-866.7},0).wait(1).to({x:-220.85,y:-877.25},0).wait(1).to({x:-227.2,y:-888.3},0).wait(1).to({x:-233.85,y:-899.85},0).wait(1).to({x:-240.85,y:-912},0).wait(1).to({x:-248.2,y:-924.75},0).wait(1).to({x:-255.9,y:-938.2},0).wait(1).to({x:-264.05,y:-952.35},0).wait(1).to({x:-272.65,y:-967.3},0).wait(1).to({x:-281.75,y:-983.1},0).wait(1).to({x:-291.35,y:-999.8},0).wait(1).to({x:-301.55,y:-1017.45},0).wait(1).to({x:-312.3,y:-1036.15},0).wait(1).to({x:-323.7,y:-1055.95},0).wait(1).to({x:-335.75,y:-1076.9},0).wait(1).to({regX:220.5,regY:196.8,x:-339.1,y:-1104.65},0).to({_off:true},1).wait(1));

	// Powerpoint
	this.instance_3 = new lib.Powerpoint_1();
	this.instance_3.setTransform(498.4,491.3,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({x:-68.55,y:-461.3},149).wait(1).to({regX:202.6,regY:224.9,x:-89.35,y:-438.25},0).wait(1).to({x:-92.3,y:-443.4},0).wait(1).to({x:-95.25,y:-448.55},0).wait(1).to({x:-98.25,y:-453.75},0).wait(1).to({x:-101.25,y:-458.95},0).wait(1).to({x:-104.3,y:-464.25},0).wait(1).to({x:-107.35,y:-469.55},0).wait(1).to({x:-110.45,y:-474.95},0).wait(1).to({x:-113.6,y:-480.35},0).wait(1).to({x:-116.75,y:-485.85},0).wait(1).to({x:-119.95,y:-491.4},0).wait(1).to({x:-123.2,y:-497.05},0).wait(1).to({x:-126.45,y:-502.75},0).wait(1).to({x:-129.8,y:-508.5},0).wait(1).to({x:-133.15,y:-514.4},0).wait(1).to({x:-136.6,y:-520.35},0).wait(1).to({x:-140.1,y:-526.4},0).wait(1).to({x:-143.65,y:-532.55},0).wait(1).to({x:-147.25,y:-538.85},0).wait(1).to({x:-150.95,y:-545.25},0).wait(1).to({x:-154.7,y:-551.8},0).wait(1).to({x:-158.55,y:-558.5},0).wait(1).to({x:-162.5,y:-565.35},0).wait(1).to({x:-166.5,y:-572.35},0).wait(1).to({x:-170.65,y:-579.55},0).wait(1).to({x:-174.9,y:-586.95},0).wait(1).to({x:-179.3,y:-594.55},0).wait(1).to({x:-183.8,y:-602.4},0).wait(1).to({x:-188.45,y:-610.45},0).wait(1).to({x:-193.3,y:-618.85},0).wait(1).to({x:-198.25,y:-627.5},0).wait(1).to({x:-203.45,y:-636.5},0).wait(1).to({x:-208.8,y:-645.8},0).wait(1).to({x:-214.4,y:-655.5},0).wait(1).to({x:-220.2,y:-665.65},0).wait(1).to({x:-226.3,y:-676.2},0).wait(1).to({x:-232.65,y:-687.25},0).wait(1).to({x:-239.3,y:-698.8},0).wait(1).to({x:-246.3,y:-710.95},0).wait(1).to({x:-253.65,y:-723.7},0).wait(1).to({x:-261.35,y:-737.15},0).wait(1).to({x:-269.5,y:-751.3},0).wait(1).to({x:-278.1,y:-766.25},0).wait(1).to({x:-287.2,y:-782.05},0).wait(1).to({x:-296.8,y:-798.75},0).wait(1).to({x:-307,y:-816.4},0).wait(1).to({x:-317.75,y:-835.1},0).wait(1).to({x:-329.15,y:-854.9},0).wait(1).to({x:-341.2,y:-875.85},0).wait(1).to({regX:220.5,regY:196.8,x:-336.05,y:-926.1},0).to({_off:true},1).wait(1));

	// Excel
	this.instance_4 = new lib.Wordcopy2();
	this.instance_4.setTransform(700.25,607.15,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).to({x:130.5,y:-340.3},149).wait(1).to({regX:211.8,regY:224.3,x:118.9,y:-317.9},0).wait(1).to({x:115.95,y:-323},0).wait(1).to({x:113,y:-328.2},0).wait(1).to({x:110,y:-333.4},0).wait(1).to({x:107,y:-338.65},0).wait(1).to({x:103.95,y:-343.9},0).wait(1).to({x:100.9,y:-349.25},0).wait(1).to({x:97.8,y:-354.65},0).wait(1).to({x:94.7,y:-360.1},0).wait(1).to({x:91.55,y:-365.6},0).wait(1).to({x:88.35,y:-371.2},0).wait(1).to({x:85.1,y:-376.8},0).wait(1).to({x:81.85,y:-382.55},0).wait(1).to({x:78.55,y:-388.35},0).wait(1).to({x:75.15,y:-394.2},0).wait(1).to({x:71.75,y:-400.2},0).wait(1).to({x:68.25,y:-406.25},0).wait(1).to({x:64.7,y:-412.45},0).wait(1).to({x:61.1,y:-418.75},0).wait(1).to({x:57.4,y:-425.15},0).wait(1).to({x:53.65,y:-431.75},0).wait(1).to({x:49.8,y:-438.45},0).wait(1).to({x:45.9,y:-445.3},0).wait(1).to({x:41.85,y:-452.35},0).wait(1).to({x:37.7,y:-459.55},0).wait(1).to({x:33.45,y:-466.95},0).wait(1).to({x:29.1,y:-474.6},0).wait(1).to({x:24.6,y:-482.45},0).wait(1).to({x:19.95,y:-490.55},0).wait(1).to({x:15.15,y:-498.95},0).wait(1).to({x:10.15,y:-507.65},0).wait(1).to({x:5,y:-516.65},0).wait(1).to({x:-0.35,y:-526},0).wait(1).to({x:-5.95,y:-535.75},0).wait(1).to({x:-11.75,y:-545.9},0).wait(1).to({x:-17.85,y:-556.5},0).wait(1).to({x:-24.2,y:-567.55},0).wait(1).to({x:-30.85,y:-579.15},0).wait(1).to({x:-37.8,y:-591.35},0).wait(1).to({x:-45.15,y:-604.15},0).wait(1).to({x:-52.85,y:-617.6},0).wait(1).to({x:-61,y:-631.8},0).wait(1).to({x:-69.6,y:-646.8},0).wait(1).to({x:-78.65,y:-662.6},0).wait(1).to({x:-88.25,y:-679.35},0).wait(1).to({x:-98.4,y:-697.05},0).wait(1).to({x:-109.15,y:-715.8},0).wait(1).to({x:-120.5,y:-735.65},0).wait(1).to({x:-132.55,y:-756.65},0).wait(1).to({regX:220.5,regY:196.8,x:-136.6,y:-806.4},0).to({_off:true},1).wait(1));

	// Excel
	this.instance_5 = new lib.Excel_1();
	this.instance_5.setTransform(677.9,412.35,1,1,0,0,0,220.5,196.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:110.95,y:-540.25},149).wait(1).to({regX:226.2,regY:236.3,x:113.75,y:-505.8},0).wait(1).to({x:110.8,y:-510.95},0).wait(1).to({x:107.85,y:-516.1},0).wait(1).to({x:104.85,y:-521.3},0).wait(1).to({x:101.85,y:-526.5},0).wait(1).to({x:98.8,y:-531.8},0).wait(1).to({x:95.75,y:-537.1},0).wait(1).to({x:92.65,y:-542.5},0).wait(1).to({x:89.5,y:-547.9},0).wait(1).to({x:86.35,y:-553.4},0).wait(1).to({x:83.15,y:-558.95},0).wait(1).to({x:79.9,y:-564.6},0).wait(1).to({x:76.65,y:-570.3},0).wait(1).to({x:73.3,y:-576.05},0).wait(1).to({x:69.95,y:-581.95},0).wait(1).to({x:66.5,y:-587.9},0).wait(1).to({x:63,y:-593.95},0).wait(1).to({x:59.45,y:-600.1},0).wait(1).to({x:55.85,y:-606.4},0).wait(1).to({x:52.15,y:-612.8},0).wait(1).to({x:48.4,y:-619.35},0).wait(1).to({x:44.55,y:-626.05},0).wait(1).to({x:40.6,y:-632.9},0).wait(1).to({x:36.6,y:-639.9},0).wait(1).to({x:32.45,y:-647.1},0).wait(1).to({x:28.2,y:-654.5},0).wait(1).to({x:23.8,y:-662.1},0).wait(1).to({x:19.3,y:-669.95},0).wait(1).to({x:14.65,y:-678},0).wait(1).to({x:9.8,y:-686.4},0).wait(1).to({x:4.85,y:-695.05},0).wait(1).to({x:-0.35,y:-704.05},0).wait(1).to({x:-5.7,y:-713.35},0).wait(1).to({x:-11.3,y:-723.05},0).wait(1).to({x:-17.1,y:-733.2},0).wait(1).to({x:-23.2,y:-743.75},0).wait(1).to({x:-29.55,y:-754.8},0).wait(1).to({x:-36.2,y:-766.35},0).wait(1).to({x:-43.2,y:-778.5},0).wait(1).to({x:-50.55,y:-791.25},0).wait(1).to({x:-58.25,y:-804.7},0).wait(1).to({x:-66.4,y:-818.85},0).wait(1).to({x:-75,y:-833.8},0).wait(1).to({x:-84.1,y:-849.6},0).wait(1).to({x:-93.7,y:-866.3},0).wait(1).to({x:-103.9,y:-883.95},0).wait(1).to({x:-114.65,y:-902.65},0).wait(1).to({x:-126.05,y:-922.45},0).wait(1).to({x:-138.1,y:-943.4},0).wait(1).to({regX:220.5,regY:196.8,x:-156.55,y:-1005.05},0).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-656.5,-1336.5,1475.4,2081.1);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// icons
	this.icons = new lib.icon_anim();
	this.icons.name = "icons";
	this.icons.setTransform(191.4,431.9,0.57,0.57,0,0,0,284.2,24.9);

	this.timeline.addTween(cjs.Tween.get(this.icons).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(80.7,300.6,0.22,0.22,0,0,0,298.7,339.2);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(143.6,4.3,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// drop_menu
	this.dropdown = new lib.drop_menu();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(-6,349.25);

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// dropDownMenuBtn
	this.dropDownMenuBtn = new lib.dropDownMenuBtn();
	this.dropDownMenuBtn.name = "dropDownMenuBtn";
	this.dropDownMenuBtn.setTransform(126,635.75,1,1,0,0,0,116,81.5);
	new cjs.ButtonHelper(this.dropDownMenuBtn, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.dropDownMenuBtn).wait(1));

	// screen
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(76.85,426.5,0.57,0.57,0,0,0,283.9,24.9);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// BG
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-4.2,-13.5,671.6,997.8), null);


// stage content:
(lib.O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						}
				}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var screen = mc.screen
		var phone = mc.phone
		
		this.runBanner = function() {
			
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "+=0", alpha: 0, ease:Power4.easeIn}, "+=1.8");
				if (i!=0) exportRoot.tl1.to(exportRoot.headline1[i], 0.8, { x: "+=0", alpha: 0, ease:Power4.easeIn}, "-=0.8");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "+=1.2");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline3.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline3[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}		
		
			exportRoot.tl1.from(mc.dropdown, 0.8, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.5");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "+=0.5");
				
			exportRoot.tl1.from(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {alpha:1, onStart:function(){mc.dropdown.pointer.gotoAndPlay(1);exportRoot.showMenu()}}, "+=0.2");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power3.easeIn}, "+=0.5");
				
			exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1);
		}
		exportRoot.myTimer = function() {
			exportRoot.hideMenu()
		}
		
		exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		
		
		var theMenu = exportRoot.mainMC.dropdown.menu
		var theMenuBtn = exportRoot.mainMC.dropDownMenuBtn
		var menuClosed = true
		
		exportRoot.btn1 = theMenu.btn1; var ro1 = theMenu.ro1;
		exportRoot.btn2 = theMenu.btn2; var ro2 = theMenu.ro2;
		exportRoot.btn3 = theMenu.btn3; var ro3 = theMenu.ro3;
		exportRoot.btn1.enabled = false
		exportRoot.btn2.enabled = false
		exportRoot.btn3.enabled = false
		
		theMenuBtn.addEventListener("click", function(event) { exportRoot.menuClick() })
		
		this.menuClick = function() {
			TweenMax.killTweensOf(theMenu);
			if (menuClosed) exportRoot.showMenu()
			if (!menuClosed) exportRoot.hideMenu()
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		
		this.showMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:117, ease:Power4.easeOut, onComplete:function(){menuClosed = false}});
			exportRoot.btn1.enabled = true
			exportRoot.btn2.enabled = true
			exportRoot.btn3.enabled = true
			
		}
		this.hideMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:206.3, ease:Power4.easeOut, onComplete:function(){menuClosed = true}});
			exportRoot.btn1.enabled = false
			exportRoot.btn2.enabled = false
			exportRoot.btn3.enabled = false
		}
		
		exportRoot.btn1.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(1) })
		exportRoot.btn2.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(2) })
		exportRoot.btn3.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(3) })
		
		
		exportRoot.btn1.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(1) })
		exportRoot.btn2.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(2) })
		exportRoot.btn3.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(3) })
		
		exportRoot.rollOverAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:1});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		exportRoot.rollOutAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:0});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	// btn
	this.btn = new lib.mainBtn();
	this.btn.name = "btn";
	this.btn.setTransform(102.5,92,1,1,0,0,0,102.5,92);
	new cjs.ButtonHelper(this.btn, 0, 1, 2, false, new lib.mainBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(75.8,286.5,591.6,697.8);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_.png?1582639838525", id:"O365_FY20Q4_Cons_USA_160x600_BAN_Word_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;