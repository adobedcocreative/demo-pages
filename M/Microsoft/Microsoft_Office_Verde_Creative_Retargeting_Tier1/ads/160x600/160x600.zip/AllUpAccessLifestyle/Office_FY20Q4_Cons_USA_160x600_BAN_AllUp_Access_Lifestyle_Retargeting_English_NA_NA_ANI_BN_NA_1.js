(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,0,392,314],[464,0,178,479],[214,316,248,426],[0,316,212,522]]}
];


// symbols:



(lib.bg_2 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Lady_01 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.lady_02 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.man_01 = function() {
	this.initialize(ss["Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhL2AauMAAAg1bMCXtAAAMAAAA1bg");
	this.shape.setTransform(485.475,171);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(0,0,971,342), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.pointer2_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoCvQgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgFQgDgHACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAhuQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAEQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gdQgGAFgBAHQgCAGAEAFIBXBvQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhkQAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACVQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgNIgRgUQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,19.875);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCbIAAgeQAAgMgHgIIhXhvQgEgFACgGQABgHAGgFQALgJANAKIARAUIAFANQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAiVQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAABkQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,19.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2_sub, new cjs.Rectangle(0,2.4,29.6,35), null);


(lib.pointer1_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgoC7QgEAAgDgDQgDgDAAgEIAAgoQAAgEgCgEIhYhwQgEgFgBgGQgDgGACgJQADgPAMgJQALgIANAAQAOABAMAKIABABIAKAMIAAiGQAAgOAKgLQAKgKAPAAQAOAAALAKQAKALAAAOIAAAcQAGgDAIAAIAAAAQAKAAAJAGQAIAFAEAJQAJgFAJAAQALAAAIAGQAJAFAEAJQAIgFAKAAQAPAAAKAKQAKALAAAOIAAB/QAAAIgDAGIgVAsIgBAGIAAAvQAAAEgDADQgDADgEAAgAh3gRQgGAFgBAHQgCAFAEAFIBXBwQAHAIAAAMIAAAeICFAAIAAglQAAgHADgHIAVgsIABgGIAAh/QAAgGgEgEQgFgFgGAAQgGAAgEAFQgFAEAAAGIAAAyQAAAKgKAAQgKAAAAgKIAAhBQAAgGgEgEQgEgFgHAAQgGAAgEAFQgEAEAAAGIAAAxQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAhAQAAgGgFgEQgEgFgGAAIAAAAQgGAAgFAFQgDAEAAAGIAABAQAAAEgDADQgDADgEAAQgEAAgDgDQgDgDAAgEIAAh8QAAgGgFgEQgEgFgGAAQgGAAgEAFQgFAEAAAGIAACtQAAAEgCADQgDADgDABQgGABgEgFQgCgDgDgJIgFgOIgRgTQgHgFgGAAQgGAAgFAEg");
	this.shape.setTransform(14.7719,18.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeCnIAAgeQAAgMgHgIIhXhwQgEgFACgFQABgHAGgFQALgJANAKIARATIAFAOQADAJACADQAEAFAGgBQADgBADgDQACgDAAgEIAAitQAAgGAFgEQAEgFAGAAQAGAAAEAFQAFAEAAAGIAAB8QAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAhAQAAgGADgEQAFgFAGAAIAAAAQAGAAAEAFQAFAEAAAGIAABAQAAAEADADQADADAEAAQAEAAADgDQADgDAAgEIAAgxQAAgGAEgEQAEgFAGAAQAHAAAEAFQAEAEAAAGIAABBQAAAKAKAAQAKAAAAgKIAAgyQAAgGAFgEQAEgFAGAAQAGAAAFAFQAEAEAAAGIAAB/IgBAGIgVAsQgDAHAAAHIAAAlg");
	this.shape_1.setTransform(14.7775,18.675);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1_sub, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.overlay = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.098)").s().p("Aq1CYIAAkvIVrAAIAAEvg");
	this.shape.setTransform(69.425,15.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlay, new cjs.Rectangle(0,0,138.9,30.3), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.menu_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt1 = new cjs.Text("Learn more", "12px 'Segoe Pro'");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 12;
	this.txt1.lineWidth = 137;
	this.txt1.parent = this;
	this.txt1.setTransform(2,2);

	this.txt2 = new cjs.Text("Monthly subscription", "12px 'Segoe Pro'");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 137;
	this.txt2.parent = this;
	this.txt2.setTransform(2,32);

	this.txt3 = new cjs.Text("SAVE 16%\nAnnual subscription", "12px 'Segoe Pro'", "#0078D3");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 12;
	this.txt3.lineWidth = 137;
	this.txt3.parent = this;
	this.txt3.setTransform(2,54.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt3},{t:this.txt2},{t:this.txt1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.menu_text, new cjs.Rectangle(0,0,141.1,84.9), null);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.Man_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.man_01();
	this.instance.setTransform(69,-330);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Man_01, new cjs.Rectangle(69,-330,212,522), null);


(lib.mainBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFEFEF").s().p("EgMfAu4MAAAhdvIY/AAMAAABdvg");
	this.shape.setTransform(80,300);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,160,600);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.logo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F9B90E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape.setTransform(-41.1223,-12.067,0.211,0.211);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#39A4EE").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_1.setTransform(-49.0922,-12.067,0.211,0.211);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#83BB1E").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_2.setTransform(-41.1223,-20.0369,0.211,0.211);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#EA4E17").s().p("AiqCrIAAlVIFVAAIAAFVg");
	this.shape_3.setTransform(-49.0922,-20.0369,0.211,0.211);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape_4.setTransform(-7.2067,-16.3025,0.211,0.211);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_5.setTransform(38.1418,-15.9649,0.211,0.211);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_6.setTransform(31.6963,-16.0441,0.211,0.211);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_7.setTransform(25.0978,-16.0441,0.211,0.211);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo, new cjs.Rectangle(-52.7,-23.6,93.6,15.200000000000001), null);


(lib.Lady_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.lady_02();
	this.instance.setTransform(50.55,-18.25);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Lady_02, new cjs.Rectangle(50.6,-18.2,248.00000000000003,426), null);


(lib.Lady_01_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Lady_01();
	this.instance.setTransform(34.5,-32.75);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Lady_01_1, new cjs.Rectangle(34.5,-32.7,178,479), null);


(lib.dropDownMenuBtn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00CCFF").s().p("Aq8CWIAAkrIV5AAIAAErg");
	this.shape.setTransform(70.125,15);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,140.3,30);


(lib.CityBg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.bg_2();
	this.instance.setTransform(203.6,-353);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CityBg, new cjs.Rectangle(203.6,-353,392,600), null);


(lib.choice_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt = new cjs.Text("BUY NOW", "12px 'Segoe Pro'", "#0078D3");
	this.txt.name = "txt";
	this.txt.lineHeight = 18;
	this.txt.lineWidth = 216;
	this.txt.parent = this;
	this.txt.setTransform(2,2);

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.choice_text, new cjs.Rectangle(0,0,219.8,26.6), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.pointer2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer2_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(11.35,8.3,1,1,-3.4817,0,0,11.3,8.3);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer2, new cjs.Rectangle(-0.3,1.3,31.6,36.7), null);


(lib.pointer1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.pointerSub.cache(-30,-40,60,80,1.5)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.pointerSub = new lib.pointer1_sub();
	this.pointerSub.name = "pointerSub";
	this.pointerSub.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get(this.pointerSub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pointer1, new cjs.Rectangle(0,0,29.6,37.4), null);


(lib.pointer = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer_1
	this.instance = new lib.pointer1();
	this.instance.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.instance_1 = new lib.pointer2();
	this.instance_1.setTransform(14.8,18.7,1,1,0,0,0,14.8,18.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.3,0,31.6,38);


(lib.people = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Lady_01
	this.l1 = new lib.Lady_01_1();
	this.l1.name = "l1";
	this.l1.setTransform(-161.4,-75.7,1,1,0,0,0,85.4,177.7);

	this.timeline.addTween(cjs.Tween.get(this.l1).wait(1));

	// Lady_02
	this.l2 = new lib.Lady_02();
	this.l2.name = "l2";
	this.l2.setTransform(6.15,-55.65,1,1,0,0,0,115.2,158.8);

	this.timeline.addTween(cjs.Tween.get(this.l2).wait(1));

	// Man_01
	this.m1 = new lib.Man_01();
	this.m1.name = "m1";
	this.m1.setTransform(-127.8,195.4,1,1,0,0,0,80.3,193.8);

	this.timeline.addTween(cjs.Tween.get(this.m1).wait(1));

	// BG
	this.bg = new lib.CityBg();
	this.bg.name = "bg";
	this.bg.setTransform(-145.55,165.25,1,1,0,0,0,254,218.9);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.people, new cjs.Rectangle(-212.3,-406.6,408.4,600.2), null);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_48 = function() {
		exportRoot.tl1.play();
	}
	this.frame_74 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(48).call(this.frame_48).wait(26).call(this.frame_74).wait(1));

	// Layer_5
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(66.5,886.1,0.1849,0.1849,0,0,0,-39.5,1.9);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:3.0594,scaleY:3.0594,x:66.4},13,cjs.Ease.quadOut).to({x:-103.6},12,cjs.Ease.quadInOut).to({_off:true},1).wait(48));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgUrBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_15 = new cjs.Graphics().p("EgU3BHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_16 = new cjs.Graphics().p("EgVaBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_17 = new cjs.Graphics().p("EgWVBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_18 = new cjs.Graphics().p("EgXoBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_19 = new cjs.Graphics().p("EgZSBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_20 = new cjs.Graphics().p("EgbUBHzIAAqUMA44AAAIAAKUg");
	var mask_graphics_21 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_22 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_23 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_24 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_25 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");
	var mask_graphics_26 = new cjs.Graphics().p("EgccBHzIAAqUMA45AAAIAAKUg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:231.7572,y:459.506}).wait(1).to({graphics:mask_graphics_15,x:230.575,y:459.506}).wait(1).to({graphics:mask_graphics_16,x:227.0284,y:459.506}).wait(1).to({graphics:mask_graphics_17,x:221.1174,y:459.506}).wait(1).to({graphics:mask_graphics_18,x:212.842,y:459.506}).wait(1).to({graphics:mask_graphics_19,x:202.2023,y:459.506}).wait(1).to({graphics:mask_graphics_20,x:189.1981,y:459.506}).wait(1).to({graphics:mask_graphics_21,x:170.3212,y:459.506}).wait(1).to({graphics:mask_graphics_22,x:149.0417,y:459.506}).wait(1).to({graphics:mask_graphics_23,x:132.491,y:459.506}).wait(1).to({graphics:mask_graphics_24,x:120.669,y:459.506}).wait(1).to({graphics:mask_graphics_25,x:113.5758,y:459.506}).wait(1).to({graphics:mask_graphics_26,x:111.3476,y:459.506}).wait(1).to({graphics:null,x:0,y:0}).wait(48));

	// Layer_7
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-200.65,882.4,3.0594,3.0594,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:19.15},12,cjs.Ease.quadInOut).to({_off:true},24).wait(25));

	// white (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_51 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_52 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_53 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_54 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_55 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_56 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_57 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_58 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_59 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_60 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_61 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_62 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_63 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_64 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_65 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_66 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_67 = new cjs.Graphics().p("EgpDCaqMAAAk1TMBSHAAAMAAAE1Tg");
	var mask_1_graphics_68 = new cjs.Graphics().p("EgqKCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_69 = new cjs.Graphics().p("EgtbCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_70 = new cjs.Graphics().p("Egw4CaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_71 = new cjs.Graphics().p("Eg0hCaqMAAAk1TMBSIAAAMAAAE1Tg");
	var mask_1_graphics_72 = new cjs.Graphics().p("Eg4UCaqMAAAk1TMBSHAAAMAAAE1Tg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:68.2273,y:916.1858}).wait(51).to({graphics:mask_1_graphics_51,x:68.2273,y:916.1858}).wait(1).to({graphics:mask_1_graphics_52,x:67.0331,y:916.1858}).wait(1).to({graphics:mask_1_graphics_53,x:63.4503,y:916.1858}).wait(1).to({graphics:mask_1_graphics_54,x:57.479,y:916.1858}).wait(1).to({graphics:mask_1_graphics_55,x:49.1193,y:916.1858}).wait(1).to({graphics:mask_1_graphics_56,x:38.371,y:916.1858}).wait(1).to({graphics:mask_1_graphics_57,x:25.2342,y:916.1858}).wait(1).to({graphics:mask_1_graphics_58,x:9.7088,y:916.1858}).wait(1).to({graphics:mask_1_graphics_59,x:-8.205,y:916.1858}).wait(1).to({graphics:mask_1_graphics_60,x:-28.5073,y:916.1858}).wait(1).to({graphics:mask_1_graphics_61,x:-51.1982,y:916.1858}).wait(1).to({graphics:mask_1_graphics_62,x:-76.2775,y:916.1858}).wait(1).to({graphics:mask_1_graphics_63,x:-103.7454,y:916.1858}).wait(1).to({graphics:mask_1_graphics_64,x:-133.6018,y:916.1858}).wait(1).to({graphics:mask_1_graphics_65,x:-165.8467,y:916.1858}).wait(1).to({graphics:mask_1_graphics_66,x:-200.4801,y:916.1858}).wait(1).to({graphics:mask_1_graphics_67,x:-237.502,y:916.1858}).wait(1).to({graphics:mask_1_graphics_68,x:-269.8699,y:916.1858}).wait(1).to({graphics:mask_1_graphics_69,x:-290.7693,y:916.1858}).wait(1).to({graphics:mask_1_graphics_70,x:-312.8631,y:916.1858}).wait(1).to({graphics:mask_1_graphics_71,x:-336.151,y:916.1858}).wait(1).to({graphics:mask_1_graphics_72,x:-360.525,y:916.1858}).wait(3));

	// Layer_9
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(19.15,882.4,3.0594,3.0594,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(50).to({_off:false},0).wait(25));

	// white
	this.instance_3 = new lib.white();
	this.instance_3.setTransform(68.2,2281.7,0.5414,5.7885,0,0,0,485.4,406.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(51).to({scaleY:5.7403,y:2262.05},0).to({regX:484.9,x:-458.55},21,cjs.Ease.quadIn).wait(3));

	// white copy
	this.instance_4 = new lib.white();
	this.instance_4.setTransform(68.2,2281.7,0.5414,5.7885,0,0,0,485.4,406.9);
	this.instance_4.alpha = 0.6016;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(51).to({scaleY:5.741,y:2262.35},0).wait(2).to({regX:484.9,scaleY:5.7885,x:-458.55,y:2281.7},21,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-721,-73.6,1052.1,1979.6);


(lib.menuChoice = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.choice_text.cache(0,-20,220,27,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3F3F3F").s().p("AgkASIAkgjIAlAjg");
	this.shape.setTransform(173.675,195.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Outline
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#292929").s().p("Aq3CYIAAkvIAHAAIVoAAIAAEvgAqwCSIVhAAIAAkgI1hAAg");
	this.shape_1.setTransform(122.95,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	// Text
	this.choice_text = new lib.choice_text();
	this.choice_text.name = "choice_text";
	this.choice_text.setTransform(174.9,211.5,1,1,0,0,0,109.9,13.3);

	this.timeline.addTween(cjs.Tween.get(this.choice_text).wait(1));

	// Layer_2
	this.txt2 = new cjs.Text("", "11px 'Segoe Pro'", "#D84739");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 17;
	this.txt2.lineWidth = 216;
	this.txt2.parent = this;
	this.txt2.setTransform(67,200.2);

	this.timeline.addTween(cjs.Tween.get(this.txt2).wait(1));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AqzCVIAAkpIVnAAIAAEpg");
	this.shape_2.setTransform(122.925,195.625);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(53.4,180.4,231.4,44.400000000000006);


(lib.Menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.menu_text.cache(0,-10,150,90,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Arrow
	this.btn1 = new lib.dropDownMenuBtn();
	this.btn1.name = "btn1";
	this.btn1.setTransform(0.15,-0.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn1, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn2 = new lib.dropDownMenuBtn();
	this.btn2.name = "btn2";
	this.btn2.setTransform(0.15,29.3,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn2, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.btn3 = new lib.dropDownMenuBtn();
	this.btn3.name = "btn3";
	this.btn3.setTransform(0.15,58.9,0.9866,0.9865,0,0,0,0.3,0.3);
	new cjs.ButtonHelper(this.btn3, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.btn3},{t:this.btn2},{t:this.btn1}]}).wait(1));

	// Outline
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#292929").s().p("AKzG+IAAgBI1lAAIAAABIgHAAIAAt7IVyAAIAAN7gAqyG2IVlAAIAAkeI1lAAgAqyCRIVlAAIAAkeI1lAAgAqyiUIVlAAIAAkiI1lAAg");
	this.shape.setTransform(69.15,43.625);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// txt_backup
	this.menu_text = new lib.menu_text();
	this.menu_text.name = "menu_text";
	this.menu_text.setTransform(81.75,59.5,1,1,0,0,0,70.5,42.5);

	this.timeline.addTween(cjs.Tween.get(this.menu_text).wait(1));

	// rollOver
	this.ro3 = new lib.overlay();
	this.ro3.name = "ro3";
	this.ro3.setTransform(114.2,73.1,1,0.9439,0,0,0,114.4,15.2);
	this.ro3.alpha = 0;

	this.ro2 = new lib.overlay();
	this.ro2.name = "ro2";
	this.ro2.setTransform(114.2,43.9,1,0.9439,0,0,0,114.4,15.2);
	this.ro2.alpha = 0;

	this.ro1 = new lib.overlay();
	this.ro1.name = "ro1";
	this.ro1.setTransform(114.2,14.65,1,1,0,0,0,114.4,15.2);
	this.ro1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.ro1},{t:this.ro2},{t:this.ro3}]}).wait(1));

	// bg
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AqzG6IAAtzIVnAAIAANzg");
	this.shape_1.setTransform(68.925,43.575);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.6,-0.9,152.9,102.80000000000001);


(lib.laptop_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_39 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(39).call(this.frame_39).wait(1));

	// Mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Ege6AvDMAAAheFMA91AAAMAAABeFg");
	var mask_graphics_1 = new cjs.Graphics().p("Ege5AvBMAAAheBMA9zAAAMAAABeBg");
	var mask_graphics_2 = new cjs.Graphics().p("Ege1Au7MAAAhd1MA9rAAAMAAABd1g");
	var mask_graphics_3 = new cjs.Graphics().p("EgeuAuwMAAAhdfMA9dAAAMAAABdfg");
	var mask_graphics_4 = new cjs.Graphics().p("EgelAuiMAAAhdDMA9LAAAMAAABdDg");
	var mask_graphics_5 = new cjs.Graphics().p("EgeZAuPMAAAhcdMA8zAAAMAAABcdg");
	var mask_graphics_6 = new cjs.Graphics().p("EgeKAt4MAAAhbvMA8VAAAMAAABbvg");
	var mask_graphics_7 = new cjs.Graphics().p("Egd4AtdMAAAha5MA7xAAAMAAABa5g");
	var mask_graphics_8 = new cjs.Graphics().p("EgdkAs+MAAAhZ7MA7JAAAMAAABZ7g");
	var mask_graphics_9 = new cjs.Graphics().p("EgdNAsbMAAAhY1MA6bAAAMAAABY1g");
	var mask_graphics_10 = new cjs.Graphics().p("EgczAr0MAAAhXnMA5nAAAMAAABXng");
	var mask_graphics_11 = new cjs.Graphics().p("EgcXArJMAAAhWRMA4vAAAMAAABWRg");
	var mask_graphics_12 = new cjs.Graphics().p("Egb4AqZMAAAhUxMA3xAAAMAAABUxg");
	var mask_graphics_13 = new cjs.Graphics().p("EgbWAplMAAAhTJMA2tAAAMAAABTJg");
	var mask_graphics_14 = new cjs.Graphics().p("EgayAotMAAAhRZMA1lAAAMAAABRZg");
	var mask_graphics_15 = new cjs.Graphics().p("EgaLAnxMAAAhPhMA0XAAAMAAABPhg");
	var mask_graphics_16 = new cjs.Graphics().p("EgZhAmxMAAAhNhMAzDAAAMAAABNhg");
	var mask_graphics_17 = new cjs.Graphics().p("EgY0AltMAAAhLZMAxpAAAMAAABLZg");
	var mask_graphics_18 = new cjs.Graphics().p("EgYFAklMAAAhJJMAwLAAAMAAABJJg");
	var mask_graphics_19 = new cjs.Graphics().p("EgXTAjYMAAAhGvMAunAAAMAAABGvg");
	var mask_graphics_20 = new cjs.Graphics().p("EgWfAiJMAAAhERMAs/AAAMAAABERg");
	var mask_graphics_21 = new cjs.Graphics().p("EgVtAg8MAAAhB3MArbAAAMAAABB3g");
	var mask_graphics_22 = new cjs.Graphics().p("A0+f0MAAAg/nMAp9AAAMAAAA/ng");
	var mask_graphics_23 = new cjs.Graphics().p("A0RevMAAAg9dMAojAAAMAAAA9dg");
	var mask_graphics_24 = new cjs.Graphics().p("AzndvMAAAg7dMAnPAAAMAAAA7dg");
	var mask_graphics_25 = new cjs.Graphics().p("AzAczMAAAg5lMAmBAAAMAAAA5lg");
	var mask_graphics_26 = new cjs.Graphics().p("Aycb8MAAAg33MAk5AAAMAAAA33g");
	var mask_graphics_27 = new cjs.Graphics().p("Ax6bIMAAAg2PMAj1AAAMAAAA2Pg");
	var mask_graphics_28 = new cjs.Graphics().p("AxbaYMAAAg0vMAi3AAAMAAAA0vg");
	var mask_graphics_29 = new cjs.Graphics().p("Aw/ZtMAAAgzZMAh/AAAMAAAAzZg");
	var mask_graphics_30 = new cjs.Graphics().p("AwJZGMAAAgyLMAhLAAAMAAAAyLg");
	var mask_graphics_31 = new cjs.Graphics().p("AvYYiMAAAgxDMAgdAAAMAAAAxDg");
	var mask_graphics_32 = new cjs.Graphics().p("AutYDMAAAgwFIf0AAMAAAAwFg");
	var mask_graphics_33 = new cjs.Graphics().p("AuIXoMAAAgvPIfRAAMAAAAvPg");
	var mask_graphics_34 = new cjs.Graphics().p("AtpXSMAAAgujIe0AAMAAAAujg");
	var mask_graphics_35 = new cjs.Graphics().p("AtPW/MAAAgt9IebAAMAAAAt9g");
	var mask_graphics_36 = new cjs.Graphics().p("As7WxMAAAgthIeIAAMAAAAthg");
	var mask_graphics_37 = new cjs.Graphics().p("AstWmMAAAgtLId7AAMAAAAtLg");
	var mask_graphics_38 = new cjs.Graphics().p("AslWgMAAAgs/IdzAAMAAAAs/g");
	var mask_graphics_39 = new cjs.Graphics().p("AsiWeMAAAgs7IdwAAMAAAAs7g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:-0.2654,y:-106.0204}).wait(1).to({graphics:mask_graphics_1,x:-0.1004,y:-105.937}).wait(1).to({graphics:mask_graphics_2,x:0.3945,y:-105.6868}).wait(1).to({graphics:mask_graphics_3,x:1.2194,y:-105.2698}).wait(1).to({graphics:mask_graphics_4,x:2.3743,y:-104.6859}).wait(1).to({graphics:mask_graphics_5,x:3.8591,y:-103.9353}).wait(1).to({graphics:mask_graphics_6,x:5.6739,y:-103.0178}).wait(1).to({graphics:mask_graphics_7,x:7.8186,y:-101.9335}).wait(1).to({graphics:mask_graphics_8,x:10.2933,y:-100.6825}).wait(1).to({graphics:mask_graphics_9,x:13.0979,y:-99.2646}).wait(1).to({graphics:mask_graphics_10,x:16.2325,y:-97.6799}).wait(1).to({graphics:mask_graphics_11,x:19.697,y:-95.9284}).wait(1).to({graphics:mask_graphics_12,x:23.4916,y:-94.01}).wait(1).to({graphics:mask_graphics_13,x:27.616,y:-91.9249}).wait(1).to({graphics:mask_graphics_14,x:32.0704,y:-89.673}).wait(1).to({graphics:mask_graphics_15,x:36.8548,y:-87.2542}).wait(1).to({graphics:mask_graphics_16,x:41.9692,y:-84.6686}).wait(1).to({graphics:mask_graphics_17,x:47.4135,y:-81.9163}).wait(1).to({graphics:mask_graphics_18,x:53.1877,y:-78.9971}).wait(1).to({graphics:mask_graphics_19,x:59.2919,y:-75.9111}).wait(1).to({graphics:mask_graphics_20,x:65.6436,y:-72.7}).wait(1).to({graphics:mask_graphics_21,x:71.7478,y:-69.614}).wait(1).to({graphics:mask_graphics_22,x:77.5221,y:-66.6948}).wait(1).to({graphics:mask_graphics_23,x:82.9664,y:-63.9424}).wait(1).to({graphics:mask_graphics_24,x:88.0807,y:-61.3569}).wait(1).to({graphics:mask_graphics_25,x:92.8651,y:-58.9381}).wait(1).to({graphics:mask_graphics_26,x:97.3195,y:-56.6862}).wait(1).to({graphics:mask_graphics_27,x:101.444,y:-54.601}).wait(1).to({graphics:mask_graphics_28,x:105.2385,y:-52.6827}).wait(1).to({graphics:mask_graphics_29,x:108.703,y:-50.9312}).wait(1).to({graphics:mask_graphics_30,x:109.0126,y:-49.3465}).wait(1).to({graphics:mask_graphics_31,x:109.2673,y:-47.9286}).wait(1).to({graphics:mask_graphics_32,x:109.4919,y:-46.6775}).wait(1).to({graphics:mask_graphics_33,x:109.6867,y:-45.5932}).wait(1).to({graphics:mask_graphics_34,x:109.8514,y:-44.6758}).wait(1).to({graphics:mask_graphics_35,x:109.9862,y:-43.9251}).wait(1).to({graphics:mask_graphics_36,x:110.0911,y:-43.3413}).wait(1).to({graphics:mask_graphics_37,x:110.166,y:-42.9243}).wait(1).to({graphics:mask_graphics_38,x:110.2109,y:-42.6741}).wait(1).to({graphics:mask_graphics_39,x:110.2259,y:-42.4474}).wait(1));

	// People
	this.ppl_inner = new lib.people();
	this.ppl_inner.name = "ppl_inner";
	this.ppl_inner.setTransform(111.9,-19.5,1,1,0,0,0,111.9,-19.5);

	var maskedShapeInstanceList = [this.ppl_inner];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.ppl_inner).to({regX:112.1,regY:-19.3,scaleX:0.4821,scaleY:0.4821,x:179.9,y:-0.35},39,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-198.2,-406.6,418.6,600.2);


(lib.drop_menu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// pointer
	this.pointer = new lib.pointer();
	this.pointer.name = "pointer";
	this.pointer.setTransform(117.8,232.6,0.6379,0.6379,0,0,0,14.8,18.8);

	this.timeline.addTween(cjs.Tween.get(this.pointer).wait(1));

	// Layer_6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AsHCkIAAlHIYPAAIAAFHg");
	mask.setTransform(90.4,220.825);

	// Menu
	this.selectorBox = new lib.menuChoice();
	this.selectorBox.name = "selectorBox";
	this.selectorBox.setTransform(138.45,114.6,1,1,0,0,0,175.3,90.5);

	var maskedShapeInstanceList = [this.selectorBox];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.selectorBox).wait(1));

	// Layer_6 copy (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	mask_1.graphics.p("Ay1HhIAAvBMAlrAAAIAAPBg");
	mask_1.setTransform(133.4,157.025);

	// Menu copy
	this.menu = new lib.Menu();
	this.menu.name = "menu";
	this.menu.setTransform(16.5,205.3,1,1,0,0,0,-0.5,-0.7);

	var maskedShapeInstanceList = [this.menu];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.menu).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.drop_menu, new cjs.Rectangle(16.4,204.5,152.9,40), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// drop_menu
	this.dropdown = new lib.drop_menu();
	this.dropdown.name = "dropdown";
	this.dropdown.setTransform(-6,349.25);
	this.dropdown.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.dropdown).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// dropDownMenuBtn
	this.dropDownMenuBtn = new lib.dropDownMenuBtn();
	this.dropDownMenuBtn.name = "dropDownMenuBtn";
	this.dropDownMenuBtn.setTransform(126,635.75,1,1,0,0,0,116,81.5);
	new cjs.ButtonHelper(this.dropDownMenuBtn, 0, 1, 2, false, new lib.dropDownMenuBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.dropDownMenuBtn).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(144.65,2.55,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// logo
	this.logo_1 = new lib.logo();
	this.logo_1.name = "logo_1";
	this.logo_1.setTransform(16.25,15.95,0.9696,0.9696,0,0,0,-52.5,-23.7);

	this.timeline.addTween(cjs.Tween.get(this.logo_1).wait(1));

	// people
	this.people = new lib.laptop_anim();
	this.people.name = "people";
	this.people.setTransform(253.35,431.35,1,1,0,0,0,284.2,24.8);

	this.timeline.addTween(cjs.Tween.get(this.people).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-243.1,-1.7,491.1,658.9000000000001), null);


// stage content:
(lib.Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						}
				}
		}
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC
		var icons = mc.icons
		var screen = mc.screen
		var phone = mc.phone
		
		this.runBanner = function() {
			
			mc.replay_btn.alpha=1
			
			this.tl1 = new TimelineLite();
					
				exportRoot.tl1.from(mc.people.ppl_inner.bg, 2.2, { x: "+=160",	ease:Power4.easeInOut}, "+=0");
				exportRoot.tl1.from(mc.people.ppl_inner.l1, 2.2, { x: "+=180", ease:Power4.easeInOut}, "-=2.2");
				exportRoot.tl1.from(mc.people.ppl_inner.l2, 2.2, { x: "+=180", ease:Power4.easeInOut}, "-=2.2");
				exportRoot.tl1.from(mc.people.ppl_inner.m1, 2.2, { x: "+=160",	ease:Power4.easeInOut, onComplete:function(){mc.people.play();}}, "-=2.2");
					
				exportRoot.tl1.from(mc.logo_1, 0.7, { x: "+=200",alpha: 0,	ease:Power4.easeOut}, "+=0.5");
				
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "+=200", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
		
				exportRoot.tl1.from(mc.dropdown, 0.8, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.to(mc.dropdown, 0.1, {alpha: 1, ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.from(mc.replay_btn, 0.8, {alpha: 0, onStart:function(){exportRoot.isReplay = true;}}, "+=0.5");
				
			exportRoot.tl1.from(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power4.easeOut}, "-=0.8");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {alpha:1, onStart:function(){mc.dropdown.pointer.gotoAndPlay(1);exportRoot.showMenu()}}, "+=0.2");
			exportRoot.tl1.to(mc.dropdown.pointer, 1, {x: "+=50", y: "+=200", ease:Power3.easeIn}, "+=0.5");
				
			exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1);
		}
		exportRoot.myTimer = function() {
			exportRoot.hideMenu()
		}
		
		exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		
		
		var theMenu = exportRoot.mainMC.dropdown.menu
		var theMenuBtn = exportRoot.mainMC.dropDownMenuBtn
		var menuClosed = true
		
		exportRoot.btn1 = theMenu.btn1; var ro1 = theMenu.ro1;
		exportRoot.btn2 = theMenu.btn2; var ro2 = theMenu.ro2;
		exportRoot.btn3 = theMenu.btn3; var ro3 = theMenu.ro3;
		exportRoot.btn1.enabled = false
		exportRoot.btn2.enabled = false
		exportRoot.btn3.enabled = false
		
		theMenuBtn.addEventListener("click", function(event) { exportRoot.menuClick() })
		
		this.menuClick = function() {
			TweenMax.killTweensOf(theMenu);
			if (menuClosed) exportRoot.showMenu()
			if (!menuClosed) exportRoot.hideMenu()
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		
		this.showMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:117, ease:Power4.easeOut, onComplete:function(){menuClosed = false}});
			exportRoot.btn1.enabled = true
			exportRoot.btn2.enabled = true
			exportRoot.btn3.enabled = true
			
		}
		this.hideMenu = function() {
			TweenMax.to(theMenu, 0.4, {y:206.3, ease:Power4.easeOut, onComplete:function(){menuClosed = true}});
			exportRoot.btn1.enabled = false
			exportRoot.btn2.enabled = false
			exportRoot.btn3.enabled = false
		}
		
		exportRoot.btn1.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(1) })
		exportRoot.btn2.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(2) })
		exportRoot.btn3.addEventListener("mouseover", function(event) { exportRoot.rollOverAnim(3) })
		
		
		exportRoot.btn1.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(1) })
		exportRoot.btn2.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(2) })
		exportRoot.btn3.addEventListener("mouseout", function(event) { exportRoot.rollOutAnim(3) })
		
		exportRoot.rollOverAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:1});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
		exportRoot.rollOutAnim = function(id) {
			TweenMax.killTweensOf(theMenu["ro"+id]);
			TweenMax.to(theMenu["ro"+id], 0.2, {alpha:0});
			window.clearInterval(exportRoot.TimerVar)
			exportRoot.TimerVar = setInterval(exportRoot.myTimer, 4500);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	// btn
	this.btn = new lib.mainBtn();
	this.btn.name = "btn";
	this.btn.setTransform(102.5,92,1,1,0,0,0,102.5,92);
	new cjs.ButtonHelper(this.btn, 0, 1, 2, false, new lib.mainBtn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.btn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-163.1,298.3,411.1,358.90000000000003);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 160,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_.png?1582628444439", id:"Office_FY20Q4_Cons_USA_160x600_BAN_AllUp_Access_Lifestyle_Retargeting_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;