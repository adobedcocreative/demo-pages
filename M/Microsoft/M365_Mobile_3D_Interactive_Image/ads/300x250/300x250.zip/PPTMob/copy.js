// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#505050>3D isn’t just for|the movies","20.2px",15, 43,"22","3 50", "left"];
	bannerData.headline2 = ["<#505050>Create slides|that sing with|3D animations","13.2px",15,95,"15","3 50", "left"];


	bannerData.CTA = ["<#FFFFFF>BUY NOW","13px",0,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
