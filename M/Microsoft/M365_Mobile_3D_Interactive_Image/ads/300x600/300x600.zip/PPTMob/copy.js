// JavaScript Document
	//  TEXT, TEXTSIZE, XPOS, YPOS, LINE SPACING, LINE WIDTH, JUSTIFYTEXT
	// use | for new line.  Use <#FFFFFF> for color change.
	// when this occurs you can use line height to adjust line spacing.
	// lineWidth is no longer needed.
	var bannerData = new Object()
	
	
	
	bannerData.headline1 = ["<#505050>3D isn’t just for|the movies","24.9px",33, 58,"27.2","3 50", "left"];
	bannerData.headline2 = ["<#505050>Create slides that sing |with 3D animations","15.3px",33,123,"15","3 50", "left"];


	bannerData.CTA = ["<#FFFFFF>BUY NOW","15px",3,0,"50","300", "center"];
	
	bannerData.CTAarrowVisible = [true, 0,0]
