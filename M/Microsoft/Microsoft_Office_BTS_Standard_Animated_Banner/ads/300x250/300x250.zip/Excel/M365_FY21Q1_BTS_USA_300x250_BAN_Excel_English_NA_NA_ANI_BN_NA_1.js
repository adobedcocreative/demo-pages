(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,0,420,420],[422,0,420,420],[844,0,420,420],[0,1266,400,388],[0,422,420,420],[422,422,420,420],[754,1266,600,19],[844,422,420,420],[0,844,420,420],[402,1266,350,233],[422,844,420,420],[844,844,420,420],[1266,0,120,111]]}
];


// symbols:



(lib.b_depth = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.b_part = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.b_withshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.ExcelTessScreenFlatSchoolBudget = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.n_depth = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.n_top = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.Rectangle111jpg = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.s_part = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.s_part_3d = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.shine = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.whitebar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AixGAIAAr/IFjAAIAAL/g");
	this.shape.setTransform(17.825,38.375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.whitebar, new cjs.Rectangle(0,0,35.7,76.8), null);


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0.0046,0.0302);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.Topbar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape.setTransform(268.579,5.5001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#437F5B").s().p("AgJgEIATAAIgKAJg");
	this.shape_1.setTransform(72.0759,5.5001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgUAbIgGgGIAAgwIA1AAIAAATIgCAAIAAgQIgGAAIAAAQIgCAAIAAgQIggAAIAAAXIANAAIgBABIgPAAIAAgYIgGAAIAAArIAFAGIAFAAIAAgQIAGAAIAAADIgEAAIAAANIAGAAIAAACg");
	this.shape_2.setTransform(46.425,6.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgMABIAAAEIgCAAIAAgJIAJAAIAAADIgGAAQAEAFAHAAQAKAAADgJIACABQgDAKgMAAQgIAAgEgFg");
	this.shape_3.setTransform(47.6,8.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAGIACgGQAFgGAHAAQAHAAAGAGIAAgEIACAAIAAAJIgKAAIAAgDIAHAAQgFgFgHAAQgFAAgFAEIgCAGg");
	this.shape_4.setTransform(47.6,6.35);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAQIgOgOIgNAOIgCAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBAAAAIAOgOIgOgNIAAgBQAAgBABAAQAAAAAAAAQAAAAABAAQAAAAAAABIANANIAOgNIACAAQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIgOANIAOAOQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAg");
	this.shape_5.setTransform(442.325,5.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgQARIAAgaIAHAAIAAgHIAaAAIAAAaIgHAAIAAAHgAgNAOIAVAAIAAgUIgVAAgAgHgJIARAAIAAAQIAEAAIAAgUIgVAAg");
	this.shape_6.setTransform(427.1,5.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(0.3).p("AgRAAIAjAA");
	this.shape_7.setTransform(411.95,5.45);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUARIAAghIApAAIAAAhgAABAOIASAAIAAgUIglAAIAAAUIASAAIAAgOIgGAEIgBgCIAHgHIAIAHIgBACIgGgEgAgSgJIAlAAIAAgEIglAAg");
	this.shape_8.setTransform(396.625,5.275);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgIABIAAgBIARAAIAAABg");
	this.shape_9.setTransform(78.65,4.925);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_10.setTransform(78.675,6.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJgEIATAAIgKAJg");
	this.shape_11.setTransform(60.575,5.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#437F5B").s().p("AgQAFQgFgFABgHQABgHAFgFIABAAQAFgFAHAAQAHACAEAEIAJAKIAAgTIACAAIAAAYIgWAAIAAgDIASAAIgJgKQgDgEgGgBQgFAAgFADIgCABQgEAEgBAGQAAAHAEADIAUAXIgCABg");
	this.shape_12.setTransform(67.2167,6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgFAaIAUgXQAEgDAAgHQgBgFgFgFIgBgBQgFgDgFAAQgGABgDAEIgJAKIASAAIAAADIgWAAIAAgYIACAAIAAATIAJgKQAEgEAGgCQAHAAAGAFIABAAQAFAFABAHQAAAHgEAFIgUAWg");
	this.shape_13.setTransform(55.625,6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AglAaQgKAAgIgIQgIgHAAgLQAAgKAIgHQAIgIAKAAIBLAAQALAAAHAIQAIAHAAAKQAAALgIAHQgHAIgLAAgAAdgIQgEAEAAAEQAAAFAEAEQADADAGAAQAFAAADgDQADgEAAgFQAAgEgDgEQgDgDgFAAQgGAAgDADg");
	this.shape_14.setTransform(32.4,5.275);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#227347").s().p("EgjJAA3IAAhuMBGTAAAIAABug");
	this.shape_15.setTransform(225,5.55);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Topbar, new cjs.Rectangle(0,0,450,11.1), null);


(lib.top_text = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt13 = new cjs.Text("Comments", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 7;
	this.txt13.lineWidth = 23;
	this.txt13.parent = this;
	this.txt13.setTransform(416.2,18.75);

	this.txt13_1 = new cjs.Text("Share", "4px 'Segoe Pro Semibold'", "#227347");
	this.txt13_1.name = "txt13_1";
	this.txt13_1.lineHeight = 7;
	this.txt13_1.lineWidth = 15;
	this.txt13_1.parent = this;
	this.txt13_1.setTransform(390.7,15.7);

	this.txt13_2 = new cjs.Text("Search", "5px 'Segoe Pro'", "#474747");
	this.txt13_2.name = "txt13_2";
	this.txt13_2.lineHeight = 8;
	this.txt13_2.lineWidth = 15;
	this.txt13_2.parent = this;
	this.txt13_2.setTransform(208,15.55);

	this.txt12 = new cjs.Text("Help", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 15;
	this.txt12.parent = this;
	this.txt12.setTransform(181,18.55);

	this.txt11 = new cjs.Text("View", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 15;
	this.txt11.parent = this;
	this.txt11.setTransform(162.95,18.55);

	this.txt10 = new cjs.Text("Review", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 15;
	this.txt10.parent = this;
	this.txt10.setTransform(140.55,18.55);

	this.txt9 = new cjs.Text("Date", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 15;
	this.txt9.parent = this;
	this.txt9.setTransform(122.5,18.55);

	this.txt8 = new cjs.Text("Formulas", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 24;
	this.txt8.parent = this;
	this.txt8.setTransform(95.4,18.55);

	this.txt7 = new cjs.Text("Page Layout", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 33;
	this.txt7.parent = this;
	this.txt7.setTransform(62.2,18.55);

	this.txt6 = new cjs.Text("Insert", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 13;
	this.txt6.parent = this;
	this.txt6.setTransform(41.25,18.55);

	this.txt5 = new cjs.Text("Home", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 13;
	this.txt5.parent = this;
	this.txt5.setTransform(19.9,18.55);

	this.txt4 = new cjs.Text("File", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 8;
	this.txt4.parent = this;
	this.txt4.setTransform(2.3,18.55);

	this.txt3 = new cjs.Text("Daniella Duarte", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 30;
	this.txt3.parent = this;
	this.txt3.setTransform(355.05,7.2);

	this.txt2 = new cjs.Text("Family Budget - Saved to OneDrive", "5px 'Segoe Pro'", "#FFFFFF");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 105;
	this.txt2.parent = this;
	this.txt2.setTransform(185.3,6.5);

	this.txt1 = new cjs.Text("On", "3px 'Segoe Pro'", "#227347");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 6;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(24.15,6.6);

	this.txt = new cjs.Text("AutoSave", "4px 'Segoe Pro'", "#FFFFFF");
	this.txt.name = "txt";
	this.txt.lineHeight = 7;
	this.txt.lineWidth = 19;
	this.txt.parent = this;
	this.txt.setTransform(2,6.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13_2},{t:this.txt13_1},{t:this.txt13}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.top_text, new cjs.Rectangle(0,4.5,441.2,22.3), null);


(lib.tile_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.textanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#44724B").s().p("AhZB4ICOjaQgaAHgjAAIgIAAQAJAMAAAOQAAAUgOAQQgOAQgXAAQgWAAgOgPQgPgPAAgVQAAgOAHgMQAHgLAMgHQAMgHANAAQAFAAANADQATAEAVAAQAQAAAPgCQAPgCAXgHIARAAIicDvgAhRhXQgJAKAAANQAAAOAJAIQAKAKANAAQANAAAKgKQAJgIAAgOQAAgNgJgKQgKgKgNAAQgNAAgKAKgAAXBhQgPgQAAgUQAAgWAPgOQAPgPAVAAQAVAAAPAPQAPAOAAAWQAAAUgPAQQgPAPgVAAQgVAAgPgPgAAkAmQgJAJAAAOQAAANAJAJQAKAJANAAQANAAAKgJQAJgJAAgNQAAgOgJgJQgKgKgNAAQgNAAgKAKg");
	this.shape.setTransform(46.925,20.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAFgIQAGgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgcARQAQAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_1.setTransform(26.9,20.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#44724B").s().p("AhIBuIBRhZQAZgaAIgNQAHgNAAgOQAAgSgNgNQgOgNgUAAQgTAAgOAOQgOAOgCAZIgUAAQABggAUgVQAVgVAdABQAdAAATATQASATAAAaQAAATgJAQQgIAOgaAcIg0A6IBiAAIAAAUg");
	this.shape_2.setTransform(10.225,20.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_3.setTransform(26.925,20.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAdABATATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_4.setTransform(26.9,20.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_5.setTransform(27.3,20.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#44724B").s().p("AhABlIBji+IhmAAIAAgUICHAAIhyDbg");
	this.shape_6.setTransform(27.625,20.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#44724B").s().p("Ag1BdQgTgVAAgYQAAgSAKgPQAJgOAXgKQgQgJgHgMQgJgMAAgOQABgOAIgNQAIgOAPgHQAPgIAQAAQARAAAPAIQAOAHAIAOQAIANAAAPQAAAOgIAMQgHALgPAJQAVAJAJAOQAKAOAAASQAAAZgRATQgTAXglAAQgjAAgSgUgAgjAPQgPAOAAATQAAAMAGALQAHAKALAGQAMAGAOAAQAXAAAOgOQAPgOAAgTQAAgSgPgOQgPgOgVAAQgVAAgPAPgAgchRQgMALAAAOQAAAPANALQAMAMAQAAQAKAAAKgFQAJgGAGgJQAGgJAAgJQAAgNgLgLQgKgLgVAAQgRAAgLAKg");
	this.shape_7.setTransform(26.95,20.575);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#44724B").s().p("AgoBmIA5hYQgMADgJAAQgZAAgTgRQgSgTAAgbQABgSAIgPQAJgPAQgJQAQgJARAAQASAAAPAIQAPAJAIAQQAKAPgBASQAAANgFAPQgFAOgOAUIhBBhgAgfhOQgNANAAATQAAATANANQAOANARAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgRAAgOANg");
	this.shape_8.setTransform(26.75,20.575);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#44724B").s().p("AglBlQgRgMgJgXQgJgYAAgqQAAgqAJgXQAJgXARgMQAQgMAVAAQAUAAARAMQARAMAKAYQAJAYAAAoQAAApgJAYQgKAYgRAMQgRAMgUAAQgVAAgQgMgAgahSQgNAJgGATQgHATAAAkQAAAkAHATQAGASANAKQANAKANAAQAOAAANgKQAMgJAHgTQAIgXAAggQgBgggHgVQgHgVgMgJQgNgKgOAAQgNAAgNAKg");
	this.shape_9.setTransform(26.95,20.575);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#44724B").s().p("AgvBhQgSgQgGgfIAVAAQAGAVAKAJQANAMAVAAQAXAAANgOQAPgOAAgTQAAgMgHgLQgHgLgMgGQgMgFgYgBIAAgUQAOAAAMgFQAMgFAGgIQAFgIAAgKQAAgOgLgKQgMgKgQAAQgOAAgJAIQgLAHgHATIgWAAQAGgaARgPQARgOAXAAQAQAAAPAIQAPAHAHANQAJANgBAPQAAAbgbARQAPAGAKALQAOARAAAVQAAATgKAQQgJARgRAJQgRAJgTAAQgcAAgTgQg");
	this.shape_10.setTransform(10.25,20.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#44724B").s().p("AAGBsIAAjCIghAAIANgVIAqAAIAADXg");
	this.shape_11.setTransform(25.675,20.575);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#44724B").s().p("AAcBuIAAgxIhmAAIB3iqIAEAAIAACVIAaAAIAAAVIgaAAIAAAxgAgjAoIA/AAIAAhag");
	this.shape_12.setTransform(10.275,20.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#44724B").s().p("AgwBfQgSgRgDgZIAWAAQADAMAFAIQAGAIAKAFQAKAEAKAAQAVAAAPgQQAQgQAAgYQgBgVgOgOQgNgNgWAAQgTAAgbAMIAThrIBdAAIAAAUIhMAAIgKA7QAOgEAKgBQAeABASATQAUATgBAfQAAAVgJASQgKARgRAKQgRAKgUgBQgbAAgSgPg");
	this.shape_13.setTransform(10.25,20.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#44724B").s().p("AghBpQgPgJgJgPQgIgQgBgSQAAgNAGgOQAGgPANgUIBAhhIASALIg5BZQAMgEAJAAQAaAAARARQATATgBAbQAAASgIAQQgJAOgPAJQgRAJgRAAQgRAAgQgIgAgfAPQgNANAAATQAAATANANQANANASAAQATAAANgNQAOgNAAgTQAAgTgOgNQgNgNgTAAQgSAAgNANg");
	this.shape_14.setTransform(10.65,20.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_1},{t:this.shape}]}).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},7).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_4},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},2).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_2,p:{x:10.225}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_10},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_12},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_3,p:{x:10.275}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_13},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_1},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_4},{t:this.shape}]},1).to({state:[{t:this.shape_14},{t:this.shape_5,p:{x:27.3}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_6,p:{x:27.625}},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_7},{t:this.shape}]},1).to({state:[{t:this.shape_5,p:{x:10.65}},{t:this.shape_8},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_9},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_11},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_2,p:{x:26.875}},{t:this.shape}]},1).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_1},{t:this.shape}]},3).to({state:[{t:this.shape_6,p:{x:10.975}},{t:this.shape_3,p:{x:26.925}},{t:this.shape}]},4).wait(3));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.2,66.4,39.8);


(lib.smalldepth = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.s_part_3d();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.smalldepth, new cjs.Rectangle(0,0,420,420), null);


(lib.small_top = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.s_part();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.small_top, new cjs.Rectangle(0,0,420,420), null);


(lib.shine_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shine();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shine_1, new cjs.Rectangle(0,0,420,420), null);


(lib.screenshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.screenshadow();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.rowsandcells = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		//columns
		this.txt.textBaseline = "alphabetic"
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"

		//rows
		this.txt01.textBaseline = "alphabetic"
		this.txt02.textBaseline = "alphabetic"
		this.txt03.textBaseline = "alphabetic"
		this.txt04.textBaseline = "alphabetic"
		this.txt05.textBaseline = "alphabetic"
		this.txt06.textBaseline = "alphabetic"
		this.txt07.textBaseline = "alphabetic"
		this.txt08.textBaseline = "alphabetic"
		this.txt09.textBaseline = "alphabetic"
		this.txt010.textBaseline = "alphabetic"
		this.txt011.textBaseline = "alphabetic"
		this.txt012.textBaseline = "alphabetic"
		this.txt013.textBaseline = "alphabetic"
		this.txt014.textBaseline = "alphabetic"
		this.txt015.textBaseline = "alphabetic"
		this.txt016.textBaseline = "alphabetic"
		this.txt017.textBaseline = "alphabetic"
		this.txt018.textBaseline = "alphabetic"
		this.txt019.textBaseline = "alphabetic"
		this.txt020.textBaseline = "alphabetic"
		this.txt021.textBaseline = "alphabetic"
		this.txt022.textBaseline = "alphabetic"
		this.txt023.textBaseline = "alphabetic"
		this.txt024.textBaseline = "alphabetic"
		this.txt025.textBaseline = "alphabetic"
		this.txt026.textBaseline = "alphabetic"
		this.txt027.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.txt027 = new cjs.Text("27", "5px 'Segoe Pro'", "#474747");
	this.txt027.name = "txt027";
	this.txt027.lineHeight = 8;
	this.txt027.lineWidth = 6;
	this.txt027.parent = this;
	this.txt027.setTransform(-11,241.15);

	this.txt026 = new cjs.Text("26", "5px 'Segoe Pro'", "#474747");
	this.txt026.name = "txt026";
	this.txt026.lineHeight = 8;
	this.txt026.lineWidth = 6;
	this.txt026.parent = this;
	this.txt026.setTransform(-11,232.95);

	this.txt025 = new cjs.Text("25", "5px 'Segoe Pro'", "#474747");
	this.txt025.name = "txt025";
	this.txt025.lineHeight = 8;
	this.txt025.lineWidth = 6;
	this.txt025.parent = this;
	this.txt025.setTransform(-11,224.65);

	this.txt024 = new cjs.Text("24", "5px 'Segoe Pro'", "#474747");
	this.txt024.name = "txt024";
	this.txt024.lineHeight = 8;
	this.txt024.lineWidth = 6;
	this.txt024.parent = this;
	this.txt024.setTransform(-11,216.35);

	this.txt023 = new cjs.Text("23", "5px 'Segoe Pro'", "#474747");
	this.txt023.name = "txt023";
	this.txt023.lineHeight = 8;
	this.txt023.lineWidth = 6;
	this.txt023.parent = this;
	this.txt023.setTransform(-11,208.2);

	this.txt022 = new cjs.Text("22", "5px 'Segoe Pro'", "#474747");
	this.txt022.name = "txt022";
	this.txt022.lineHeight = 8;
	this.txt022.lineWidth = 6;
	this.txt022.parent = this;
	this.txt022.setTransform(-11,200);

	this.txt021 = new cjs.Text("21", "5px 'Segoe Pro'", "#474747");
	this.txt021.name = "txt021";
	this.txt021.lineHeight = 8;
	this.txt021.lineWidth = 6;
	this.txt021.parent = this;
	this.txt021.setTransform(-11,191.7);

	this.txt020 = new cjs.Text("20", "5px 'Segoe Pro'", "#474747");
	this.txt020.name = "txt020";
	this.txt020.lineHeight = 8;
	this.txt020.lineWidth = 6;
	this.txt020.parent = this;
	this.txt020.setTransform(-11,183.35);

	this.txt019 = new cjs.Text("19", "5px 'Segoe Pro'", "#474747");
	this.txt019.name = "txt019";
	this.txt019.lineHeight = 8;
	this.txt019.lineWidth = 6;
	this.txt019.parent = this;
	this.txt019.setTransform(-10.5,175.1);

	this.txt018 = new cjs.Text("18", "5px 'Segoe Pro'", "#474747");
	this.txt018.name = "txt018";
	this.txt018.lineHeight = 8;
	this.txt018.lineWidth = 6;
	this.txt018.parent = this;
	this.txt018.setTransform(-10.5,166.9);

	this.txt017 = new cjs.Text("17", "5px 'Segoe Pro'", "#474747");
	this.txt017.name = "txt017";
	this.txt017.lineHeight = 8;
	this.txt017.lineWidth = 6;
	this.txt017.parent = this;
	this.txt017.setTransform(-10.5,158.7);

	this.txt016 = new cjs.Text("16", "5px 'Segoe Pro'", "#474747");
	this.txt016.name = "txt016";
	this.txt016.lineHeight = 8;
	this.txt016.lineWidth = 6;
	this.txt016.parent = this;
	this.txt016.setTransform(-10.5,150.45);

	this.txt015 = new cjs.Text("15", "5px 'Segoe Pro'", "#474747");
	this.txt015.name = "txt015";
	this.txt015.lineHeight = 8;
	this.txt015.lineWidth = 6;
	this.txt015.parent = this;
	this.txt015.setTransform(-10.5,142.15);

	this.txt014 = new cjs.Text("14", "5px 'Segoe Pro'", "#474747");
	this.txt014.name = "txt014";
	this.txt014.lineHeight = 8;
	this.txt014.lineWidth = 6;
	this.txt014.parent = this;
	this.txt014.setTransform(-10.5,133.85);

	this.txt013 = new cjs.Text("13", "5px 'Segoe Pro'", "#474747");
	this.txt013.name = "txt013";
	this.txt013.lineHeight = 8;
	this.txt013.lineWidth = 6;
	this.txt013.parent = this;
	this.txt013.setTransform(-10.5,125.8);

	this.txt012 = new cjs.Text("12", "5px 'Segoe Pro'", "#474747");
	this.txt012.name = "txt012";
	this.txt012.lineHeight = 8;
	this.txt012.lineWidth = 6;
	this.txt012.parent = this;
	this.txt012.setTransform(-10.5,117.5);

	this.txt011 = new cjs.Text("11", "5px 'Segoe Pro'", "#474747");
	this.txt011.name = "txt011";
	this.txt011.lineHeight = 8;
	this.txt011.lineWidth = 6;
	this.txt011.parent = this;
	this.txt011.setTransform(-10.5,109.3);

	this.txt010 = new cjs.Text("10", "5px 'Segoe Pro'", "#474747");
	this.txt010.name = "txt010";
	this.txt010.lineHeight = 8;
	this.txt010.lineWidth = 6;
	this.txt010.parent = this;
	this.txt010.setTransform(-10.5,101.05);

	this.txt09 = new cjs.Text("9", "5px 'Segoe Pro'", "#474747");
	this.txt09.name = "txt09";
	this.txt09.lineHeight = 8;
	this.txt09.lineWidth = 6;
	this.txt09.parent = this;
	this.txt09.setTransform(-9.7,92.8);

	this.txt08 = new cjs.Text("8", "5px 'Segoe Pro'", "#474747");
	this.txt08.name = "txt08";
	this.txt08.lineHeight = 8;
	this.txt08.lineWidth = 6;
	this.txt08.parent = this;
	this.txt08.setTransform(-9.7,84.6);

	this.txt07 = new cjs.Text("7", "5px 'Segoe Pro'", "#474747");
	this.txt07.name = "txt07";
	this.txt07.lineHeight = 8;
	this.txt07.lineWidth = 6;
	this.txt07.parent = this;
	this.txt07.setTransform(-9.7,76.35);

	this.txt06 = new cjs.Text("6", "5px 'Segoe Pro'", "#474747");
	this.txt06.name = "txt06";
	this.txt06.lineHeight = 8;
	this.txt06.lineWidth = 6;
	this.txt06.parent = this;
	this.txt06.setTransform(-9.7,68.1);

	this.txt05 = new cjs.Text("5", "5px 'Segoe Pro'", "#474747");
	this.txt05.name = "txt05";
	this.txt05.lineHeight = 8;
	this.txt05.lineWidth = 6;
	this.txt05.parent = this;
	this.txt05.setTransform(-9.7,59.85);

	this.txt04 = new cjs.Text("4", "5px 'Segoe Pro'", "#474747");
	this.txt04.name = "txt04";
	this.txt04.lineHeight = 8;
	this.txt04.lineWidth = 6;
	this.txt04.parent = this;
	this.txt04.setTransform(-9.7,51.6);

	this.txt03 = new cjs.Text("3", "5px 'Segoe Pro'", "#474747");
	this.txt03.name = "txt03";
	this.txt03.lineHeight = 8;
	this.txt03.lineWidth = 6;
	this.txt03.parent = this;
	this.txt03.setTransform(-9.7,43.25);

	this.txt02 = new cjs.Text("2", "5px 'Segoe Pro'", "#474747");
	this.txt02.name = "txt02";
	this.txt02.lineHeight = 8;
	this.txt02.lineWidth = 6;
	this.txt02.parent = this;
	this.txt02.setTransform(-9.7,35.1);

	this.txt01 = new cjs.Text("1", "5px 'Segoe Pro'", "#474747");
	this.txt01.name = "txt01";
	this.txt01.lineHeight = 8;
	this.txt01.lineWidth = 6;
	this.txt01.parent = this;
	this.txt01.setTransform(-9.35,26.7);

	this.txt16 = new cjs.Text("Q", "5px 'Segoe Pro'", "#474747");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 8;
	this.txt16.lineWidth = 6;
	this.txt16.parent = this;
	this.txt16.setTransform(401.15,18.5);

	this.txt15 = new cjs.Text("P", "5px 'Segoe Pro'", "#474747");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 8;
	this.txt15.lineWidth = 6;
	this.txt15.parent = this;
	this.txt15.setTransform(376.95,18.5);

	this.txt14 = new cjs.Text("O", "5px 'Segoe Pro'", "#474747");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 8;
	this.txt14.lineWidth = 6;
	this.txt14.parent = this;
	this.txt14.setTransform(351.85,18.5);

	this.txt13 = new cjs.Text("N", "5px 'Segoe Pro'", "#474747");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 8;
	this.txt13.lineWidth = 6;
	this.txt13.parent = this;
	this.txt13.setTransform(327.05,18.5);

	this.txt12 = new cjs.Text("M", "5px 'Segoe Pro'", "#474747");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 8;
	this.txt12.lineWidth = 6;
	this.txt12.parent = this;
	this.txt12.setTransform(302,18.5);

	this.txt11 = new cjs.Text("L", "5px 'Segoe Pro'", "#474747");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 8;
	this.txt11.lineWidth = 6;
	this.txt11.parent = this;
	this.txt11.setTransform(278.35,18.5);

	this.txt10 = new cjs.Text("K", "5px 'Segoe Pro'", "#474747");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 8;
	this.txt10.lineWidth = 6;
	this.txt10.parent = this;
	this.txt10.setTransform(253.35,18.5);

	this.txt9 = new cjs.Text("J", "5px 'Segoe Pro'", "#474747");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 8;
	this.txt9.lineWidth = 6;
	this.txt9.parent = this;
	this.txt9.setTransform(229.05,18.5);

	this.txt8 = new cjs.Text("I", "5px 'Segoe Pro'", "#474747");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 8;
	this.txt8.lineWidth = 6;
	this.txt8.parent = this;
	this.txt8.setTransform(204.65,18.5);

	this.txt7 = new cjs.Text("H", "5px 'Segoe Pro'", "#474747");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 8;
	this.txt7.lineWidth = 6;
	this.txt7.parent = this;
	this.txt7.setTransform(178.85,18.5);

	this.txt6 = new cjs.Text("G", "5px 'Segoe Pro'", "#474747");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 8;
	this.txt6.lineWidth = 6;
	this.txt6.parent = this;
	this.txt6.setTransform(154.5,18.5);

	this.txt5 = new cjs.Text("F", "5px 'Segoe Pro'", "#474747");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 8;
	this.txt5.lineWidth = 6;
	this.txt5.parent = this;
	this.txt5.setTransform(130.3,18.5);

	this.txt4 = new cjs.Text("E", "5px 'Segoe Pro'", "#474747");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 8;
	this.txt4.lineWidth = 6;
	this.txt4.parent = this;
	this.txt4.setTransform(105.5,18.5);

	this.txt3 = new cjs.Text("D", "5px 'Segoe Pro'", "#474747");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 8;
	this.txt3.lineWidth = 6;
	this.txt3.parent = this;
	this.txt3.setTransform(80.45,18.5);

	this.txt2 = new cjs.Text("C", "5px 'Segoe Pro'", "#474747");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 8;
	this.txt2.lineWidth = 6;
	this.txt2.parent = this;
	this.txt2.setTransform(55.95,18.5);

	this.txt1 = new cjs.Text("B", "5px 'Segoe Pro'", "#474747");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 8;
	this.txt1.lineWidth = 6;
	this.txt1.parent = this;
	this.txt1.setTransform(31.3,18.5);

	this.txt = new cjs.Text("A", "5px 'Segoe Pro'", "#474747");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 6;
	this.txt.parent = this;
	this.txt.setTransform(6.4,18.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt5},{t:this.txt6},{t:this.txt7},{t:this.txt8},{t:this.txt9},{t:this.txt10},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt01},{t:this.txt02},{t:this.txt03},{t:this.txt04},{t:this.txt05},{t:this.txt06},{t:this.txt07},{t:this.txt08},{t:this.txt09},{t:this.txt010},{t:this.txt011},{t:this.txt012},{t:this.txt013},{t:this.txt014},{t:this.txt015},{t:this.txt016},{t:this.txt017},{t:this.txt018},{t:this.txt019},{t:this.txt020},{t:this.txt021},{t:this.txt022},{t:this.txt023},{t:this.txt024},{t:this.txt025},{t:this.txt026},{t:this.txt027}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rowsandcells, new cjs.Rectangle(-13,16.5,422.2,232.7), null);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_44 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(44).call(this.frame_44).wait(4));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_26 = new cjs.Graphics().p("AjhFNIDuhSIEuNwIjvBSg");
	var mask_graphics_27 = new cjs.Graphics().p("ApUFNIPWlRIEuNvIvVFSg");
	var mask_graphics_28 = new cjs.Graphics().p("AubFNIZmozIEvNvI5nIzg");
	var mask_graphics_29 = new cjs.Graphics().p("Ay6FMMAilgL4IEvNvMgilAL5g");
	var mask_graphics_30 = new cjs.Graphics().p("A2yFMMAqWgOjIEvNuMgqWAOlg");
	var mask_graphics_31 = new cjs.Graphics().p("A6HFMMAxBgQ3IEvNvMgxBAQ4g");
	var mask_graphics_32 = new cjs.Graphics().p("A87FMMA2rgSzIEvNvMg2rAS0g");
	var mask_graphics_33 = new cjs.Graphics().p("A/RFMMA7YgUbIEvNwMg7YAUbg");
	var mask_graphics_34 = new cjs.Graphics().p("EghMAFMMA/OgVwIEvNwMg/OAVwg");
	var mask_graphics_35 = new cjs.Graphics().p("EgivAFMMBCUgW0IEvNvMhCUAW0g");
	var mask_graphics_36 = new cjs.Graphics().p("Egj7AFMMBEugXpIEuNvMhEtAXpg");
	var mask_graphics_37 = new cjs.Graphics().p("Egk1AFRMBGigYRIEuNwMhGhAYRg");
	var mask_graphics_38 = new cjs.Graphics().p("EgleAFfMBH0gYtIEvNwMhH0AYtg");
	var mask_graphics_39 = new cjs.Graphics().p("Egl6AFpMBIsgZBIEvNwMhIsAZBg");
	var mask_graphics_40 = new cjs.Graphics().p("EgmLAFvMBJOgZMIEvNvMhJOAZMg");
	var mask_graphics_41 = new cjs.Graphics().p("EgmTAFyMBJfgZSIEuNvMhJeAZSg");
	var mask_graphics_42 = new cjs.Graphics().p("EgmXAFzMBJmgZVIEvNwMhJmAZVg");
	var mask_graphics_43 = new cjs.Graphics().p("EgmUAFzMBJmgZVIEvNwMhJmAZVg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_graphics_26,x:31.5433,y:121.2897}).wait(1).to({graphics:mask_graphics_27,x:68.8413,y:121.2627}).wait(1).to({graphics:mask_graphics_28,x:101.755,y:121.2389}).wait(1).to({graphics:mask_graphics_29,x:130.5588,y:121.2181}).wait(1).to({graphics:mask_graphics_30,x:155.5271,y:121.2}).wait(1).to({graphics:mask_graphics_31,x:176.9343,y:121.1846}).wait(1).to({graphics:mask_graphics_32,x:195.0545,y:121.1715}).wait(1).to({graphics:mask_graphics_33,x:210.1619,y:121.1605}).wait(1).to({graphics:mask_graphics_34,x:222.5305,y:121.1516}).wait(1).to({graphics:mask_graphics_35,x:232.4343,y:121.1444}).wait(1).to({graphics:mask_graphics_36,x:240.1474,y:121.1388}).wait(1).to({graphics:mask_graphics_37,x:245.9435,y:120.5854}).wait(1).to({graphics:mask_graphics_38,x:250.0966,y:119.1516}).wait(1).to({graphics:mask_graphics_39,x:252.8805,y:118.1905}).wait(1).to({graphics:mask_graphics_40,x:254.5691,y:117.6074}).wait(1).to({graphics:mask_graphics_41,x:255.4362,y:117.3081}).wait(1).to({graphics:mask_graphics_42,x:255.7557,y:117.1978}).wait(1).to({graphics:mask_graphics_43,x:256.0776,y:116.9051}).wait(5));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(164.2794,181.3981,1.0698,1.0698);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(26).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_26 = new cjs.Graphics().p("AjhFNIDuhSIEuNwIjvBSg");
	var mask_1_graphics_27 = new cjs.Graphics().p("ApUFNIPWlRIEuNvIvVFSg");
	var mask_1_graphics_28 = new cjs.Graphics().p("AubFNIZmozIEvNvI5nIzg");
	var mask_1_graphics_29 = new cjs.Graphics().p("Ay6FMMAilgL4IEvNvMgilAL5g");
	var mask_1_graphics_30 = new cjs.Graphics().p("A2yFMMAqWgOjIEvNuMgqWAOlg");
	var mask_1_graphics_31 = new cjs.Graphics().p("A6HFMMAxBgQ3IEvNvMgxBAQ4g");
	var mask_1_graphics_32 = new cjs.Graphics().p("A87FMMA2rgSzIEvNvMg2rAS0g");
	var mask_1_graphics_33 = new cjs.Graphics().p("A/RFMMA7YgUbIEvNwMg7YAUbg");
	var mask_1_graphics_34 = new cjs.Graphics().p("EghMAFMMA/OgVwIEvNwMg/OAVwg");
	var mask_1_graphics_35 = new cjs.Graphics().p("EgivAFMMBCUgW0IEvNvMhCUAW0g");
	var mask_1_graphics_36 = new cjs.Graphics().p("Egj7AFMMBEugXpIEuNvMhEtAXpg");
	var mask_1_graphics_37 = new cjs.Graphics().p("Egk1AFRMBGigYRIEuNwMhGhAYRg");
	var mask_1_graphics_38 = new cjs.Graphics().p("EgleAFfMBH0gYtIEvNwMhH0AYtg");
	var mask_1_graphics_39 = new cjs.Graphics().p("Egl6AFpMBIsgZBIEvNwMhIsAZBg");
	var mask_1_graphics_40 = new cjs.Graphics().p("EgmLAFvMBJOgZMIEvNvMhJOAZMg");
	var mask_1_graphics_41 = new cjs.Graphics().p("EgmTAFyMBJfgZSIEuNvMhJeAZSg");
	var mask_1_graphics_42 = new cjs.Graphics().p("EgmXAFzMBJmgZVIEvNwMhJmAZVg");
	var mask_1_graphics_43 = new cjs.Graphics().p("EgmUAFzMBJmgZVIEvNwMhJmAZVg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(26).to({graphics:mask_1_graphics_26,x:31.5433,y:121.2897}).wait(1).to({graphics:mask_1_graphics_27,x:68.8413,y:121.2627}).wait(1).to({graphics:mask_1_graphics_28,x:101.755,y:121.2389}).wait(1).to({graphics:mask_1_graphics_29,x:130.5588,y:121.2181}).wait(1).to({graphics:mask_1_graphics_30,x:155.5271,y:121.2}).wait(1).to({graphics:mask_1_graphics_31,x:176.9343,y:121.1846}).wait(1).to({graphics:mask_1_graphics_32,x:195.0545,y:121.1715}).wait(1).to({graphics:mask_1_graphics_33,x:210.1619,y:121.1605}).wait(1).to({graphics:mask_1_graphics_34,x:222.5305,y:121.1516}).wait(1).to({graphics:mask_1_graphics_35,x:232.4343,y:121.1444}).wait(1).to({graphics:mask_1_graphics_36,x:240.1474,y:121.1388}).wait(1).to({graphics:mask_1_graphics_37,x:245.9435,y:120.5854}).wait(1).to({graphics:mask_1_graphics_38,x:250.0966,y:119.1516}).wait(1).to({graphics:mask_1_graphics_39,x:252.8805,y:118.1905}).wait(1).to({graphics:mask_1_graphics_40,x:254.5691,y:117.6074}).wait(1).to({graphics:mask_1_graphics_41,x:255.4362,y:117.3081}).wait(1).to({graphics:mask_1_graphics_42,x:255.7557,y:117.1978}).wait(1).to({graphics:mask_1_graphics_43,x:256.0776,y:116.9051}).wait(5));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(263.1235,109.2808,1.0711,1.0711);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(26).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_10 = new cjs.Graphics().p("AcPRnIADuiIA2AAIgDOig");
	var mask_2_graphics_11 = new cjs.Graphics().p("AcNRnIADuiIA4AAIgDOig");
	var mask_2_graphics_12 = new cjs.Graphics().p("Ab6RnIAEuiIBKAAIgDOig");
	var mask_2_graphics_13 = new cjs.Graphics().p("AbJRnIADuiIB7AAIgDOig");
	var mask_2_graphics_14 = new cjs.Graphics().p("AZpRnIAEuiIDZAAIgDOig");
	var mask_2_graphics_15 = new cjs.Graphics().p("AXMRnIADujIF1ABIgDOig");
	var mask_2_graphics_16 = new cjs.Graphics().p("ATgRmIADuiIJeABIgEOig");
	var mask_2_graphics_17 = new cjs.Graphics().p("AOXRmIADujIOiACIgDOig");
	var mask_2_graphics_18 = new cjs.Graphics().p("AHiRkIADuiIVRADIgDOig");
	var mask_2_graphics_19 = new cjs.Graphics().p("AguRjIADujIdaAFIgDOig");
	var mask_2_graphics_20 = new cjs.Graphics().p("AnkRhIADujMAkLAAHIgEOig");
	var mask_2_graphics_21 = new cjs.Graphics().p("AstRfIADuiMApPAAIIgDOig");
	var mask_2_graphics_22 = new cjs.Graphics().p("AwYReIADuiMAs3AAJIgDOig");
	var mask_2_graphics_23 = new cjs.Graphics().p("Ay2RdIADuiMAvTAAKIgDOig");
	var mask_2_graphics_24 = new cjs.Graphics().p("A0WRdIADujMAwyAALIgDOig");
	var mask_2_graphics_25 = new cjs.Graphics().p("A1HRcIADuiMAxiAALIgDOig");
	var mask_2_graphics_26 = new cjs.Graphics().p("A1ZRcIADuiMAx0AALIgDOig");
	var mask_2_graphics_27 = new cjs.Graphics().p("A02RcIADuiMAx3AAKIgEOjg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_2_graphics_10,x:186.4089,y:112.725}).wait(1).to({graphics:mask_2_graphics_11,x:186.4055,y:112.7252}).wait(1).to({graphics:mask_2_graphics_12,x:186.3814,y:112.7251}).wait(1).to({graphics:mask_2_graphics_13,x:186.3161,y:112.725}).wait(1).to({graphics:mask_2_graphics_14,x:186.1888,y:112.7246}).wait(1).to({graphics:mask_2_graphics_15,x:185.979,y:112.724}).wait(1).to({graphics:mask_2_graphics_16,x:185.666,y:112.7229}).wait(1).to({graphics:mask_2_graphics_17,x:185.2292,y:112.7213}).wait(1).to({graphics:mask_2_graphics_18,x:184.6479,y:112.7188}).wait(1).to({graphics:mask_2_graphics_19,x:183.9454,y:112.7153}).wait(1).to({graphics:mask_2_graphics_20,x:183.3641,y:112.712}).wait(1).to({graphics:mask_2_graphics_21,x:182.9273,y:112.7092}).wait(1).to({graphics:mask_2_graphics_22,x:182.6143,y:112.7072}).wait(1).to({graphics:mask_2_graphics_23,x:182.4045,y:112.7057}).wait(1).to({graphics:mask_2_graphics_24,x:182.2772,y:112.7048}).wait(1).to({graphics:mask_2_graphics_25,x:182.2119,y:112.7043}).wait(1).to({graphics:mask_2_graphics_26,x:182.1878,y:112.7042}).wait(1).to({graphics:mask_2_graphics_27,x:185.9589,y:112.675}).wait(21));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(258.866,181.6051,1.0711,1.0711);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(10).to({_off:false},0).wait(38));

	// mask (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_10 = new cjs.Graphics().p("AcPRnIADuiIA2AAIgDOig");
	var mask_3_graphics_11 = new cjs.Graphics().p("AcNRnIADuiIA4AAIgDOig");
	var mask_3_graphics_12 = new cjs.Graphics().p("Ab6RnIAEuiIBKAAIgDOig");
	var mask_3_graphics_13 = new cjs.Graphics().p("AbJRnIADuiIB7AAIgDOig");
	var mask_3_graphics_14 = new cjs.Graphics().p("AZpRnIAEuiIDZAAIgDOig");
	var mask_3_graphics_15 = new cjs.Graphics().p("AXMRnIADujIF1ABIgDOig");
	var mask_3_graphics_16 = new cjs.Graphics().p("ATgRmIADuiIJeABIgEOig");
	var mask_3_graphics_17 = new cjs.Graphics().p("AOXRmIADujIOiACIgDOig");
	var mask_3_graphics_18 = new cjs.Graphics().p("AHiRkIADuiIVRADIgDOig");
	var mask_3_graphics_19 = new cjs.Graphics().p("AguRjIADujIdaAFIgDOig");
	var mask_3_graphics_20 = new cjs.Graphics().p("AnkRhIADujMAkLAAHIgEOig");
	var mask_3_graphics_21 = new cjs.Graphics().p("AstRfIADuiMApPAAIIgDOig");
	var mask_3_graphics_22 = new cjs.Graphics().p("AwYReIADuiMAs3AAJIgDOig");
	var mask_3_graphics_23 = new cjs.Graphics().p("Ay2RdIADuiMAvTAAKIgDOig");
	var mask_3_graphics_24 = new cjs.Graphics().p("A0WRdIADujMAwyAALIgDOig");
	var mask_3_graphics_25 = new cjs.Graphics().p("A1HRcIADuiMAxiAALIgDOig");
	var mask_3_graphics_26 = new cjs.Graphics().p("A1ZRcIADuiMAx0AALIgDOig");
	var mask_3_graphics_27 = new cjs.Graphics().p("A02RcIADuiMAx3AAKIgEOjg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:null,x:0,y:0}).wait(10).to({graphics:mask_3_graphics_10,x:186.4089,y:112.725}).wait(1).to({graphics:mask_3_graphics_11,x:186.4055,y:112.7252}).wait(1).to({graphics:mask_3_graphics_12,x:186.3814,y:112.7251}).wait(1).to({graphics:mask_3_graphics_13,x:186.3161,y:112.725}).wait(1).to({graphics:mask_3_graphics_14,x:186.1888,y:112.7246}).wait(1).to({graphics:mask_3_graphics_15,x:185.979,y:112.724}).wait(1).to({graphics:mask_3_graphics_16,x:185.666,y:112.7229}).wait(1).to({graphics:mask_3_graphics_17,x:185.2292,y:112.7213}).wait(1).to({graphics:mask_3_graphics_18,x:184.6479,y:112.7188}).wait(1).to({graphics:mask_3_graphics_19,x:183.9454,y:112.7153}).wait(1).to({graphics:mask_3_graphics_20,x:183.3641,y:112.712}).wait(1).to({graphics:mask_3_graphics_21,x:182.9273,y:112.7092}).wait(1).to({graphics:mask_3_graphics_22,x:182.6143,y:112.7072}).wait(1).to({graphics:mask_3_graphics_23,x:182.4045,y:112.7057}).wait(1).to({graphics:mask_3_graphics_24,x:182.2772,y:112.7048}).wait(1).to({graphics:mask_3_graphics_25,x:182.2119,y:112.7043}).wait(1).to({graphics:mask_3_graphics_26,x:182.1878,y:112.7042}).wait(1).to({graphics:mask_3_graphics_27,x:185.9589,y:112.675}).wait(21));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(211.1496,181.6051,1.0711,1.0711);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(10).to({_off:false},0).wait(38));

	// mask (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("AxwTeIQelqIEtNwIwcFqg");
	var mask_4_graphics_1 = new cjs.Graphics().p("AxuTeIc0p7IEvNwI80J7g");
	var mask_4_graphics_2 = new cjs.Graphics().p("A2OTdMAnugNrIEvNwMgnuANrg");
	var mask_4_graphics_3 = new cjs.Graphics().p("A7ATdMAxSgQ+IEvNwMgxSAQ9g");
	var mask_4_graphics_4 = new cjs.Graphics().p("A/ITcMA5jgTzIEuNvMg5jAT0g");
	var mask_4_graphics_5 = new cjs.Graphics().p("EgisATcMBAqgWQIEvNvMhAqAWRg");
	var mask_4_graphics_6 = new cjs.Graphics().p("EglsATcMBGqgYUIEvNvMhGqAYUg");
	var mask_4_graphics_7 = new cjs.Graphics().p("EgoMATbMBLqgaCIEvNvMhLqAaDg");
	var mask_4_graphics_8 = new cjs.Graphics().p("EgqPATbMBPxgbcIEuNuMhPxAbeg");
	var mask_4_graphics_9 = new cjs.Graphics().p("Egr5ATbMBTEgclIEvNvMhTEAcmg");
	var mask_4_graphics_10 = new cjs.Graphics().p("EgtKATbMBVngddIEuNuMhVnAdfg");
	var mask_4_graphics_11 = new cjs.Graphics().p("EguIATbMBXigeIIEvNvMhXiAeJg");
	var mask_4_graphics_12 = new cjs.Graphics().p("Egu0ATbMBY6gemIEvNuMhY6Aeog");
	var mask_4_graphics_13 = new cjs.Graphics().p("EgvRATbMBZ1ge7IEuNvMhZ1Ae7g");
	var mask_4_graphics_14 = new cjs.Graphics().p("EgvjATbMBaZgfHIEuNvMhaZAfHg");
	var mask_4_graphics_15 = new cjs.Graphics().p("EgvtATbMBasgfNIEvNuMhasAfOg");
	var mask_4_graphics_16 = new cjs.Graphics().p("EgvwATbMBaygfQIEvNvMhayAfQg");
	var mask_4_graphics_17 = new cjs.Graphics().p("EgvwATcMBazgfQIEuNvMhazAfRg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:-113.65,y:212.6147}).wait(1).to({graphics:mask_4_graphics_1,x:-113.4752,y:212.5527}).wait(1).to({graphics:mask_4_graphics_2,x:-84.3527,y:212.498}).wait(1).to({graphics:mask_4_graphics_3,x:-53.5217,y:212.4502}).wait(1).to({graphics:mask_4_graphics_4,x:-26.7951,y:212.4087}).wait(1).to({graphics:mask_4_graphics_5,x:-3.8797,y:212.3732}).wait(1).to({graphics:mask_4_graphics_6,x:15.5177,y:212.3431}).wait(1).to({graphics:mask_4_graphics_7,x:31.6903,y:212.318}).wait(1).to({graphics:mask_4_graphics_8,x:44.9313,y:212.2974}).wait(1).to({graphics:mask_4_graphics_9,x:55.5338,y:212.281}).wait(1).to({graphics:mask_4_graphics_10,x:63.7911,y:212.2682}).wait(1).to({graphics:mask_4_graphics_11,x:69.9962,y:212.2585}).wait(1).to({graphics:mask_4_graphics_12,x:74.4424,y:212.2516}).wait(1).to({graphics:mask_4_graphics_13,x:77.4229,y:212.247}).wait(1).to({graphics:mask_4_graphics_14,x:79.2307,y:212.2442}).wait(1).to({graphics:mask_4_graphics_15,x:80.159,y:212.2428}).wait(1).to({graphics:mask_4_graphics_16,x:80.501,y:212.2422}).wait(1).to({graphics:mask_4_graphics_17,x:79.9497,y:212.3897}).wait(31));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_4.setTransform(96.7855,277.2254,1.0711,1.0711);

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(48));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-169.3,2.2,636.2,405.40000000000003);


(lib.overlay_c = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AzBi8Id6pUIIJPAI+AJgg");
	this.shape.setTransform(121.825,78.45);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.overlay_c, new cjs.Rectangle(0,0,243.7,156.9), null);


(lib.numtop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.n_top();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.numtop, new cjs.Rectangle(0,0,420,420), null);


(lib.numdepth = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.n_depth();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.numdepth, new cjs.Rectangle(0,0,420,420), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.main_txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
		this.txt4.textBaseline = "alphabetic"
		this.txt5.textBaseline = "alphabetic"
		this.txt6.textBaseline = "alphabetic"
		this.txt7.textBaseline = "alphabetic"
		this.txt8.textBaseline = "alphabetic"
		this.txt9.textBaseline = "alphabetic"
		this.txt10.textBaseline = "alphabetic"
		this.txt11.textBaseline = "alphabetic"
		this.txt12.textBaseline = "alphabetic"
		this.txt13.textBaseline = "alphabetic"
		this.txt14.textBaseline = "alphabetic"
		this.txt15.textBaseline = "alphabetic"
		this.txt16.textBaseline = "alphabetic"
		this.txt17.textBaseline = "alphabetic"
		this.txt18.textBaseline = "alphabetic"
		this.txt19.textBaseline = "alphabetic"
		this.txt20.textBaseline = "alphabetic"
		this.txt21.textBaseline = "alphabetic"
		this.txt22.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// text
	this.txt22 = new cjs.Text("Expense", "7px 'Segoe Pro'", "#227347");
	this.txt22.name = "txt22";
	this.txt22.lineHeight = 11;
	this.txt22.lineWidth = 32;
	this.txt22.parent = this;
	this.txt22.setTransform(356.25,158);

	this.txt21 = new cjs.Text("Income", "7px 'Segoe Pro'", "#227347");
	this.txt21.name = "txt21";
	this.txt21.lineHeight = 11;
	this.txt21.lineWidth = 32;
	this.txt21.parent = this;
	this.txt21.setTransform(311.35,158);

	this.txt20 = new cjs.Text("$0", "6px 'Segoe Pro'", "#227347");
	this.txt20.name = "txt20";
	this.txt20.lineHeight = 10;
	this.txt20.lineWidth = 18;
	this.txt20.parent = this;
	this.txt20.setTransform(290,140.1);

	this.txt19 = new cjs.Text("$100", "6px 'Segoe Pro'", "#227347");
	this.txt19.name = "txt19";
	this.txt19.lineHeight = 10;
	this.txt19.lineWidth = 18;
	this.txt19.parent = this;
	this.txt19.setTransform(283.55,125.2);

	this.txt18 = new cjs.Text("$200", "6px 'Segoe Pro'", "#227347");
	this.txt18.name = "txt18";
	this.txt18.lineHeight = 10;
	this.txt18.lineWidth = 18;
	this.txt18.parent = this;
	this.txt18.setTransform(283.55,110.5);

	this.txt17 = new cjs.Text("$300", "6px 'Segoe Pro'", "#227347");
	this.txt17.name = "txt17";
	this.txt17.lineHeight = 10;
	this.txt17.lineWidth = 18;
	this.txt17.parent = this;
	this.txt17.setTransform(283.55,95.8);

	this.txt16 = new cjs.Text("$400", "6px 'Segoe Pro'", "#227347");
	this.txt16.name = "txt16";
	this.txt16.lineHeight = 10;
	this.txt16.lineWidth = 18;
	this.txt16.parent = this;
	this.txt16.setTransform(283.55,80.75);

	this.txt15 = new cjs.Text("$500", "6px 'Segoe Pro'", "#227347");
	this.txt15.name = "txt15";
	this.txt15.lineHeight = 10;
	this.txt15.lineWidth = 18;
	this.txt15.parent = this;
	this.txt15.setTransform(283.55,66.25);

	this.txt14 = new cjs.Text("$600", "6px 'Segoe Pro'", "#227347");
	this.txt14.name = "txt14";
	this.txt14.lineHeight = 10;
	this.txt14.lineWidth = 18;
	this.txt14.parent = this;
	this.txt14.setTransform(283.55,51.55);

	this.txt13 = new cjs.Text("$700", "6px 'Segoe Pro'", "#227347");
	this.txt13.name = "txt13";
	this.txt13.lineHeight = 10;
	this.txt13.lineWidth = 18;
	this.txt13.parent = this;
	this.txt13.setTransform(283.55,36.65);

	this.txt12 = new cjs.Text("$800", "6px 'Segoe Pro'", "#227347");
	this.txt12.name = "txt12";
	this.txt12.lineHeight = 10;
	this.txt12.lineWidth = 18;
	this.txt12.parent = this;
	this.txt12.setTransform(283.55,22.35);

	this.txt11 = new cjs.Text("$900", "6px 'Segoe Pro'", "#227347");
	this.txt11.name = "txt11";
	this.txt11.lineHeight = 10;
	this.txt11.lineWidth = 18;
	this.txt11.parent = this;
	this.txt11.setTransform(283.55,7.45);

	this.txt9 = new cjs.Text("Cash Balance", "7px 'Segoe Pro'", "#227347");
	this.txt9.name = "txt9";
	this.txt9.lineHeight = 11;
	this.txt9.lineWidth = 100;
	this.txt9.parent = this;
	this.txt9.setTransform(152.7,133.5);

	this.txt7 = new cjs.Text("Total monthly savings", "7px 'Segoe Pro'", "#227347");
	this.txt7.name = "txt7";
	this.txt7.lineHeight = 11;
	this.txt7.lineWidth = 100;
	this.txt7.parent = this;
	this.txt7.setTransform(152.7,98.7);

	this.txt5 = new cjs.Text("Total monthly expenses", "7px 'Segoe Pro'", "#227347");
	this.txt5.name = "txt5";
	this.txt5.lineHeight = 11;
	this.txt5.lineWidth = 100;
	this.txt5.parent = this;
	this.txt5.setTransform(152.7,64.1);

	this.txt10 = new cjs.Text("$130", "12px 'Segoe Pro'", "#227347");
	this.txt10.name = "txt10";
	this.txt10.lineHeight = 18;
	this.txt10.lineWidth = 100;
	this.txt10.parent = this;
	this.txt10.setTransform(152.7,150.1);

	this.txt8 = new cjs.Text("$100", "12px 'Segoe Pro'", "#227347");
	this.txt8.name = "txt8";
	this.txt8.lineHeight = 18;
	this.txt8.lineWidth = 100;
	this.txt8.parent = this;
	this.txt8.setTransform(152.7,115.5);

	this.txt6 = new cjs.Text("$670", "12px 'Segoe Pro'", "#227347");
	this.txt6.name = "txt6";
	this.txt6.lineHeight = 18;
	this.txt6.lineWidth = 100;
	this.txt6.parent = this;
	this.txt6.setTransform(152.7,80.65);

	this.txt4 = new cjs.Text("$900", "12px 'Segoe Pro'", "#227347");
	this.txt4.name = "txt4";
	this.txt4.lineHeight = 18;
	this.txt4.lineWidth = 100;
	this.txt4.parent = this;
	this.txt4.setTransform(152.7,45.85);

	this.txt3 = new cjs.Text("Total monthly income", "7px 'Segoe Pro'", "#227347");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 11;
	this.txt3.lineWidth = 100;
	this.txt3.parent = this;
	this.txt3.setTransform(152.7,29.3);

	this.txt2 = new cjs.Text("Summary", "8px 'Segoe Pro'", "#227347");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 12;
	this.txt2.lineWidth = 100;
	this.txt2.parent = this;
	this.txt2.setTransform(152.7,11.2);

	this.txt1 = new cjs.Text("Percentage of income spent", "6px 'Segoe Pro'", "#B7B2A6");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 10;
	this.txt1.lineWidth = 100;
	this.txt1.parent = this;
	this.txt1.setTransform(2,26.4);

	this.txt = new cjs.Text("School Budget", "14px 'Segoe Pro'", "#227347");
	this.txt.name = "txt";
	this.txt.lineHeight = 20;
	this.txt.lineWidth = 100;
	this.txt.parent = this;
	this.txt.setTransform(2,6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt},{t:this.txt1},{t:this.txt2},{t:this.txt3},{t:this.txt4},{t:this.txt6},{t:this.txt8},{t:this.txt10},{t:this.txt5},{t:this.txt7},{t:this.txt9},{t:this.txt11},{t:this.txt12},{t:this.txt13},{t:this.txt14},{t:this.txt15},{t:this.txt16},{t:this.txt17},{t:this.txt18},{t:this.txt19},{t:this.txt20},{t:this.txt21},{t:this.txt22}]}).wait(1));

	// Graph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#49A166").s().p("AitJYIAAg5IA4AAIAAA5gAjBGUIAAvrIGDAAIAAPrg");
	this.shape.setTransform(365.3,97.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#337446").s().p("AjVMGIAAg4IA5AAIAAA4gAiqJCIAA1HIGAAAIAAFdIAAPqg");
	this.shape_1.setTransform(324.475,80.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#E4DFD4").ss(0.3).p("ATPKLIqoABIkUAAIAAiFIAAyXAkvJ0IufAAAkvEOIufAAAkvhCIufAAAkvmfIufAA");
	this.shape_2.setTransform(271.7253,74.2752);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_txt, new cjs.Rectangle(0,3.1,395.9,166.4), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.Layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt = new cjs.Text("Budget", "5px 'Segoe Pro Semibold'", "#1C7347");
	this.txt.name = "txt";
	this.txt.lineHeight = 8;
	this.txt.lineWidth = 21;
	this.txt.parent = this;
	this.txt.setTransform(39.3,248.65);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1C7347").s().p("AiUAFIAAgIIEpAAIAAAIg");
	this.shape.setTransform(47.6,252.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.txt}]}).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#777777").s().p("AAAAFIgKgIIACgDIAIAJIAJgJIACADIgLAKg");
	this.shape_1.setTransform(445.4568,7.2001);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C9C9C9").s().p("AgMAQQgEgBABgEIABgBIAGgIIAGgEIgJgGIAAgBQgDgCACgDQACgCADABIAIAKQAGgEAJgCIgNAJQAHAGAGAKQgFgFgLgJIgEAGIgEAHIAAABQAAAAAAABQAAAAgBABQAAAAgBAAQAAAAgBAAIgBAAg");
	this.shape_2.setTransform(50.8146,7.4594);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C9C9C9").s().p("AgNAVQAAAAgBgBQAAgBAAAAQAAgBAAAAQABAAAAgBQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAIABABIABACIAAAAIACgCIACgDIAEgVIAAAAIgDAAIAAgBIAAgBIADAAIAAgBIABgDQACgEADgCIAFgDIADABIABACIgBACIgBAAIgCgBIgBgBIgBgBIgCABIgBAEIgBAFIgBABIAGAAIAAAAIgBACIgFAAIgEASQAAAEgCACIgEADIgEABg");
	this.shape_3.setTransform(74.0886,7.4251);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#C9C9C9").s().p("AACAIIgCgBIAAgFIAAAAIgCAEIgCACIgDAAIgBgBQAAgBAAAAQAAgBAAAAQAAAAABAAQAAAAABAAIABAAIABAAIADgDIAAgBIABgBIgCgDIAAgBIgCgBIgBAAIgBAAIAAAAIABgBIACgBQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIABABIABAFIAAAAIAAAAIACgDIACgCIACgBIACABIAAABQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIgCAAQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgDAEIAAAAIABAEIACACIABAAIACAAIAAABIgDABg");
	this.shape_4.setTransform(75.4618,8.0251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#C9C9C9").ss(0.5,1).p("AATgNQgSARgFAKQgBABgBgBIgMgM");
	this.shape_5.setTransform(63.0759,7.3251);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAGAAIAAAFg");
	this.shape_6.setTransform(39.8006,8.7251);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAGAAIAAAGg");
	this.shape_7.setTransform(39.8006,7.4001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B3B3B3").s().p("AgDADIAAgGIAGAAIAAAGg");
	this.shape_8.setTransform(39.8006,6.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#5F6060").s().p("AgNgGIAbAAIgOANg");
	this.shape_9.setTransform(31.3005,7.1001);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#C5C5C5").ss(0.3).p("AclAqMg5JAAAIAAhTMA5JAAAg");
	this.shape_10.setTransform(265.179,7.4251);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("A8kAqIAAhTMA5JAAAIAABTg");
	this.shape_11.setTransform(265.179,7.4251);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#C5C5C5").ss(0.3).p("ACzAqIllAAIAAhTIFlAAg");
	this.shape_12.setTransform(62.6509,7.4251);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AiyAqIAAhTIFmAAIAABTg");
	this.shape_13.setTransform(62.6509,7.4251);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#C5C5C5").ss(0.3).p("ACnAqIlNAAIAAhTIFNAAg");
	this.shape_14.setTransform(18.0503,7.4251);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AimAqIAAhTIFNAAIAABTg");
	this.shape_15.setTransform(18.0503,7.4251);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#787878").s().p("AgGAAIANgNIAAAbg");
	this.shape_16.setTransform(9.4,248.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#787878").s().p("AgGgNIANANIgNAOg");
	this.shape_17.setTransform(18.975,248.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#787878").s().p("AgCAOIAAgLIgLAAIAAgFIALAAIAAgLIAEAAIAAALIAMAAIAAAFIgMAAIAAALg");
	this.shape_18.setTransform(69.425,248.95);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#787878").s().p("AgSATQgIgIAAgLQAAgKAIgIQAIgIAKAAQALAAAIAIQAIAIAAAKQAAALgIAIQgIAIgLAAQgKAAgIgIgAgRgRQgHAIAAAJQAAAKAHAHQAIAIAJAAQAKAAAIgIQAHgHAAgKQAAgJgHgIQgIgHgKAAQgJAAgIAHg");
	this.shape_19.setTransform(69.425,248.975);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#999999").s().p("A9PSuIAAhUIlIAAIAAgDIBQAAIAAgNIhQAAIAAgDIBQAAIAAhVIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhOIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgCIBQAAIAAhQIhQAAIAAgDIBQAAIAAhQIhQAAIAAgDIBQAAIAAhPIhQAAIAAgDIBQAAIAAhCIADAAIAABCID2AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID0AAIAAhCIADAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIDyAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID0AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCIDzAAIAAhCIADAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIACAAIAABCID1AAIAAhCIADAAIAABCID0AAIAAhCIADAAIAABCID0AAIAAhCIACAAIAABCIB4AAMAAAAjEMg69AAAIAABUgEghEARXID3AAIAABUIElAAIAAhUMA6+AAAMAAAgi+MhDaAAAg");
	this.shape_20.setTransform(220.0284,133.1024);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B4B4B4").s().p("AgTAUIAngnIAAAng");
	this.shape_21.setTransform(5.125,16.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#E6E6E6").s().p("EgjJAT0MAAAgnnMBGTAAAMAAAAnngEgh2ASYID2AAIAABUIEpAAIAAhUMA67AAAMAAAgjBMhDaAAAg");
	this.shape_22.setTransform(225,126.825);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Layout, new cjs.Rectangle(0,0,450,259.3), null);


(lib.icon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ExcelTessScreenFlatSchoolBudget();
	this.instance.setTransform(0,0,0.3239,0.3239);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon, new cjs.Rectangle(0,0,129.6,125.7), null);


(lib.graphGreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#459F69").s().p("AmYGZQiqipAAjwQAAjuCqiqQCpiqDvAAQDvAACqCqQCqCqAADuQAADwiqCpIAAABQiqCpjvAAQjvAAipiqgAmiAAQAACuB7B6QB6B7CtAAQCtAAB7h7QB7h6AAiuQAAish7h7Qh7h7itAAQitAAh6B7IAAAAQh7B7AACsg");
	this.shape.setTransform(57.875,57.875);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphGreen, new cjs.Rectangle(0,0,115.8,115.8), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.circleSegment = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AkgEMQAHjiCiihQCoipDwgBIAAJCg");
	mask.setTransform(28.925,28.95);

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#36724B").ss(16,1,1).p("AHzAAQAADPiSCSQiTCSjOAAQjOAAiSiSQiSiSAAjPQAAjNCSiSQCSiTDOAAQDOAACTCTQCSCSAADNg");
	this.shape.setTransform(57.8259,57.8759);

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.circleSegment, new cjs.Rectangle(0,0,57.9,57.9), null);


(lib.chart_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_shadow, new cjs.Rectangle(0,0,420,420), null);


(lib.chart_mask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ApOJ2IAAzrIScAAIAATrg");
	this.shape.setTransform(59.05,62.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.chart_mask, new cjs.Rectangle(0,0,118.1,125.9), null);


(lib.bottom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.txt1.textBaseline = "alphabetic"
		this.txt2.textBaseline = "alphabetic"
		this.txt3.textBaseline = "alphabetic"
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.txt3 = new cjs.Text("100%", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt3.name = "txt3";
	this.txt3.lineHeight = 7;
	this.txt3.lineWidth = 31;
	this.txt3.parent = this;
	this.txt3.setTransform(438.2,5.15);

	this.txt2 = new cjs.Text("Display Settings", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt2.name = "txt2";
	this.txt2.lineHeight = 7;
	this.txt2.lineWidth = 31;
	this.txt2.parent = this;
	this.txt2.setTransform(321.85,4.9);

	this.txt1 = new cjs.Text("Ready", "4px 'Segoe Pro'", "#4F4F4F");
	this.txt1.name = "txt1";
	this.txt1.lineHeight = 7;
	this.txt1.lineWidth = 14;
	this.txt1.parent = this;
	this.txt1.setTransform(2.3,4.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.txt1},{t:this.txt2},{t:this.txt3}]}).wait(1));

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4F4F4F").s().p("AgBAMIAAgKIgKAAIAAgDIAKAAIAAgKIADAAIAAAKIAKAAIAAADIgKAAIAAAKg");
	this.shape.setTransform(433.2,3.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#757575").s().p("AgEAUIAAgQIifAAIAAgDICfAAIAAgUIAPAAIAAAUICZAAIAAADIiZAAIAAAQg");
	this.shape_1.setTransform(414.3,3.625);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#4F4F4F").s().p("AgKAEIAAgHIAVAAIAAAHg");
	this.shape_2.setTransform(395.675,3.675);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgSATIAlAAIAAglIgLAAIAAAVIgaAAgAgEAAIAKAAIAAgSIgKAAgAgSAAIALAAIAAgSIgLAAg");
	this.shape_3.setTransform(386.7,3.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_4.setTransform(374.175,4.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_5.setTransform(374.175,3.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#4F4F4F").s().p("AgEABIAAgBIAJAAIAAABg");
	this.shape_6.setTransform(374.175,2.925);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#4F4F4F").s().p("AgLARIAAghIAXAAIAAAhgAgJAOIASAAIAAgbIgSAAg");
	this.shape_7.setTransform(374.2,3.55);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAgTATIAmAAIAAglIgmAAg");
	this.shape_8.setTransform(374.2,3.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#4F4F4F").s().p("AgVAWIAAgrIArAAIAAArgAAJATIAKAAIAAgKIgKAAgAgEATIAKAAIAAgKIgKAAgAgSATIAMAAIAAgKIgMAAgAAJAGIAKAAIAAgKIgKAAgAgEAGIAKAAIAAgKIgKAAgAgSAGIAMAAIAAgKIgMAAgAAJgGIAKAAIAAgMIgKAAgAgEgGIAKAAIAAgMIgKAAgAgSgGIAMAAIAAgMIgMAAg");
	this.shape_9.setTransform(361.525,3.55);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#4F4F4F").s().p("AgPAXIAAgEIALAAIAAgJIgSAAQgBAAgBAAQAAAAgBgBQAAAAAAgBQAAAAAAgBIAAgaQAAgBAAAAQAAgBAAAAQABgBAAAAQABAAABAAIAtAAQABAAAAAAQABAAAAABQABAAAAABQAAAAAAABIAAAaQAAAAAAABQAAAAAAAAQAAABAAAAQgBAAAAAAIgBAAIgBgDIAAgBQAAAAABgBQAAgBgBAAQAAgBAAAAQgBgBAAAAIgCgBQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAABIgBABIgCAAIgBgBQAAgBgBAAQAAAAAAAAQgBAAgBAAQAAAAgBAAIgCAAQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAABIAAABIgBACIgBABIgBAAIgCABIgBAAIAAAJIAFAAIAAAEg");
	this.shape_10.setTransform(318.725,3.575);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#4F4F4F").s().p("AAEALIgCgCQAAAAgBAAQAAABgBAAQAAAAAAgBQgBAAAAAAIgCACIgBAAIgCgBIAAgBIABgCQgCgCgBgDIgCAAIgBgBIAAgBIABAAIACgBIABgCIACgDIAAgCQgBgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIACgBIABAAIABACIAEAAIABgCIABAAIACABIAAABIgBACQACACABADIADABIAAAAIAAABIAAABIgDAAIgBACIgCAEIABACIgBABIgBAAgAgFgCQgEAFAHAEQAFADAEgGQADgGgGgEIgEgBQgDAAgCAFg");
	this.shape_11.setTransform(320.075,4.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#F3F1F0").s().p("EgjPAAwIAAhfMBGfAAAIAABfg");
	this.shape_12.setTransform(225.575,4.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bottom, new cjs.Rectangle(0,0,471.4,13.6), null);


(lib.bigtop = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.b_part();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bigtop, new cjs.Rectangle(0,0,420,420), null);


(lib.bigshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.b_withshadow();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bigshadow, new cjs.Rectangle(0,0,420,420), null);


(lib.bigdepth = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.b_depth();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bigdepth, new cjs.Rectangle(0,0,420,420), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150.0023,124.9924,1,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.small_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// shine
	this.shine = new lib.shine_1();
	this.shine.name = "shine";
	this.shine.setTransform(210,210,1,1,0,0,0,210,210);
	this.shine.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.shine).wait(1));

	// top
	this.s_top = new lib.small_top();
	this.s_top.name = "s_top";
	this.s_top.setTransform(210,210,1,1,0,0,0,210,210);

	this.timeline.addTween(cjs.Tween.get(this.s_top).wait(1));

	// depth
	this.s_depth = new lib.smalldepth();
	this.s_depth.name = "s_depth";
	this.s_depth.setTransform(210,210,1,1,0,0,0,210,210);

	this.timeline.addTween(cjs.Tween.get(this.s_depth).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.small_pie, new cjs.Rectangle(0,0,420,420), null);


(lib.shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(145.55,66.2,1.2031,1.2031,0,0,0,208.3,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-105,-100.5,501.1,333.5), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.3,0,32.199999999999996,30.6);


(lib.percantage = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// top
	this.numtop = new lib.numtop();
	this.numtop.name = "numtop";
	this.numtop.setTransform(210,210,1,1,0,0,0,210,210);

	this.timeline.addTween(cjs.Tween.get(this.numtop).wait(1));

	// depth
	this.numdepth = new lib.numdepth();
	this.numdepth.name = "numdepth";
	this.numdepth.setTransform(210,210,1,1,0,0,0,210,210);

	this.timeline.addTween(cjs.Tween.get(this.numdepth).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.percantage, new cjs.Rectangle(0,0,420,420), null);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_69 = function() {
		//exportRoot.mainMC.icons.play()
		exportRoot.mainMC.screen.play()
	}
	this.frame_86 = function() {
		exportRoot.tl1.play()
	}
	this.frame_100 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(69).call(this.frame_69).wait(17).call(this.frame_86).wait(14).call(this.frame_100).wait(10));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,338.35,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(83));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("AyYelIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("AyrelIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("AzlelIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("A1EelIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("A3JelIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("A51elIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("A9HelIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniAelIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1AelIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:195.7095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:195.7095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:195.7095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:195.7095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:195.7095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:195.7095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:195.7095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:195.7095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:195.7095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:195.7095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:195.7095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:195.7095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:195.7095}).wait(1).to({graphics:null,x:0,y:0}).wait(83));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-132.35,332.45,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.4,scaleX:2.408,scaleY:2.408,x:-12,y:7.9},41,cjs.Ease.quadInOut).to({_off:true},1).wait(9));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,340.35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(10));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-68.3,982,817.0999999999999);


(lib.main_ui = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MainText
	this.instance = new lib.main_txt();
	this.instance.setTransform(78.55,84.7,1,1,0,0,0,52,12.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Rows_Cells
	this.instance_1 = new lib.rowsandcells();
	this.instance_1.setTransform(233.3,34.55,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Top_bar_txt
	this.instance_2 = new lib.top_text();
	this.instance_2.setTransform(224.6,11.15,1,1,0,0,0,220.6,11.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1));

	// Top_bar
	this.instance_3 = new lib.Topbar();
	this.instance_3.setTransform(225,5.5,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1));

	// Top_grey
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#227347").s().p("AgOAIIgDAAIAAgYIAjAAIAAAYIgVAAIgLAJgAgPAGIAEAAIAAAGIAHgGIATAAIAAgTIgeAAg");
	this.shape.setTransform(416.4564,17.2001);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#EEEDEC").ss(0.3).p("ACcAlIk3AAQgDAAgCgCQgCgCAAgDIAAg6QAAgIAHAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_1.setTransform(428.3065,17.1751);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AibAlQgDAAgCgCQgCgCgBgDIAAg6QAAgIAIAAIE3AAQAIAAAAAIIAAA6QAAAHgIAAg");
	this.shape_2.setTransform(428.3065,17.1751);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#227347").s().p("AACAHQgJAAgFAEIgCABIAAgDIADgHQAEgGAJAAIAAgIIANAMIgNAOgAADAFIABAAIAAACIAHgHIgHgGIAAAEIgBAAQgLAAgDAJQAFgDAGABg");
	this.shape_3.setTransform(391.881,16.4001);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#227347").s().p("AgQANIAAgZIADAAIAAAWIAbAAIAAgLIADAAIAAAOg");
	this.shape_4.setTransform(391.106,17.9251);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#474747").s().p("AgWAXQAAAAgBgBQAAAAAAAAQAAAAAAAAQABgBAAAAIARgRQgDgEAAgFQAAgHAFgFQADgFAHAAQAHAAAFAFQAFAFAAAHQAAAGgFAFQgFAEgHAAQgHAAgEgEIgRARgAgCgPQgEAEAAAGQAAAFAEAEQADAEAGAAQAGAAAEgEQAEgEAAgFQAAgGgEgEQgEgFgGABQgGgBgDAFg");
	this.shape_5.setTransform(205.7781,17.4501);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#EEEDEC").ss(0.3).p("ABnAlIjMAAQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_6.setTransform(397.9561,17.2001);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AhlAlQgIAAAAgHIAAg7QAAgHAIAAIDMAAQAHAAAAAHIAAA7QAAAHgHAAg");
	this.shape_7.setTransform(397.9561,17.2001);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#F0F0F0").s().p("EgjJAA9IAAh5MBGTAAAIAAB5g");
	this.shape_8.setTransform(225,17.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Scroll_bars
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#ABABAB").ss(0.3).p("AqYAXIAAgtIUxAAIAAAtg");
	this.shape_9.setTransform(277.1512,272.3786);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AqXAXIAAgtIUvAAIAAAtg");
	this.shape_10.setTransform(277.1512,272.3786);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#787878").s().p("AgFgLIALALIgLAMg");
	this.shape_11.setTransform(437.3786,272.4286);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#787878").s().p("AgFAAIALgLIAAAXg");
	this.shape_12.setTransform(208.3001,272.4286);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_13.setTransform(437.2536,272.3786);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgVAXIAAgtIAsAAIAAAtg");
	this.shape_14.setTransform(437.2536,272.3786);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#ABABAB").ss(0.3).p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_15.setTransform(208.4251,272.4036);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgWAXIAAgsIAtAAIAAAsg");
	this.shape_16.setTransform(208.4251,272.4036);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#DBDBDB").ss(0.3).p("AxhAXIAAgtMAjDAAAIAAAtg");
	this.shape_17.setTransform(322.8519,272.3786);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#DBDBDB").s().p("AxgAXIAAgtMAjCAAAIAAAtg");
	this.shape_18.setTransform(322.8519,272.3786);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#ABABAB").ss(0.3).p("AAXKZIgtAAIAA0xIAtAAg");
	this.shape_19.setTransform(445.3787,110.0511);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgWKYIAA0vIAtAAIAAUvg");
	this.shape_20.setTransform(445.3787,110.0511);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B3B3B3").s().p("AgDADIAAgFIAHAAIAAAFg");
	this.shape_21.setTransform(200.65,273.4536);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B3B3B3").s().p("AgDAEIAAgHIAHAAIAAAHg");
	this.shape_22.setTransform(200.65,272.1536);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B3B3B3").s().p("AgDAEIAAgGIAHAAIAAAGg");
	this.shape_23.setTransform(200.65,270.8535);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#787878").s().p("AgMAGIAMgLIAMALg");
	this.shape_24.setTransform(445.4037,41.225);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#787878").s().p("AgMgFIAYAAIgMALg");
	this.shape_25.setTransform(445.4037,265.2785);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_26.setTransform(445.3787,41.325);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAtAAIAAAtg");
	this.shape_27.setTransform(445.3787,41.325);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#ABABAB").ss(0.3).p("AAXAXIgtAAIAAgtIAtAAg");
	this.shape_28.setTransform(445.4037,265.1285);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgWAXIAAgtIAsAAIAAAtg");
	this.shape_29.setTransform(445.4037,265.1285);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#DBDBDB").ss(0.3).p("AAXRIIgtAAMAAAgiPIAtAAg");
	this.shape_30.setTransform(445.3787,153.2267);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#DBDBDB").s().p("AgWRIMAAAgiPIAtAAMAAAAiPg");
	this.shape_31.setTransform(445.3787,153.2267);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9}]}).wait(1));

	// layout
	this.instance_4 = new lib.Layout();
	this.instance_4.setTransform(225,150.15,1,1,0,0,0,225,126.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(1));

	// Bottom
	this.instance_5 = new lib.bottom();
	this.instance_5.setTransform(225.6,281.85,1,1,0,0,0,225.6,4.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1));

	// Layer_2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#E4DFD4").ss(1,1,1).p("EgifgVxMBE/AAAMAAAArjMhE/AAAg");
	this.shape_32.setTransform(223.225,143.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("EgifAVyMAAAgrjMBE/AAAMAAAArjg");
	this.shape_33.setTransform(223.225,143.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.main_ui, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.icon_teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.graphLG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.graphGreen();
	this.instance.setTransform(49.9,49.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.graphLG, new cjs.Rectangle(-8,-8,115.8,115.8), null);


(lib.GraphCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// WhiteCoverOuter
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("AJCAAQAADwiqCoQioCqjwAAQjvAAipiqQipioAAjwQAAjvCpipQCpipDvAAQDwAACoCpQCqCpAADvg");
	this.shape.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(60));

	// WhiteCoverMid
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AkpEpQh6h7AAiuQAAitB6h8QB8h6CtAAQCuAAB7B6QB7B8AACtQAACuh7B7Qh7B7iuAAQitAAh8h7g");
	this.shape_1.setTransform(57.95,57.95);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(60));

	// Layer_3
	this.instance = new lib.circleSegment();
	this.instance.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regX:28.9,regY:29,rotation:-0.029,x:28.9,y:29},0).wait(1).to({rotation:-0.1186,x:28.85,y:29.05},0).wait(1).to({rotation:-0.273,x:28.8,y:29.1},0).wait(1).to({rotation:-0.4968,x:28.7,y:29.25},0).wait(1).to({rotation:-0.7954,x:28.55,y:29.4},0).wait(1).to({rotation:-1.1745,x:28.35,y:29.55},0).wait(1).to({rotation:-1.6408,x:28.15,y:29.8},0).wait(1).to({rotation:-2.2019,x:27.85,y:30.15},0).wait(1).to({rotation:-2.8662,x:27.5,y:30.45},0).wait(1).to({rotation:-3.6437,x:27.15,y:30.85},0).wait(1).to({rotation:-4.5458,x:26.7,y:31.35},0).wait(1).to({rotation:-5.5858,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7793,x:25.7,y:32.6},0).wait(1).to({rotation:-8.145,x:25.1,y:33.35},0).wait(1).to({rotation:-9.7052,x:24.5,y:34.3},0).wait(1).to({rotation:-11.4869,x:23.75,y:35.3},0).wait(1).to({rotation:-13.5237,x:23,y:36.55},0).wait(1).to({rotation:-15.8573,x:22.1,y:38},0).wait(1).to({rotation:-18.5409,x:21.2,y:39.7},0).wait(1).to({rotation:-21.6437,x:20.3,y:41.7},0).wait(1).to({rotation:-25.2575,x:19.35,y:44.1},0).wait(1).to({rotation:-29.5072,x:18.45,y:47},0).wait(1).to({rotation:-34.5678,x:17.65,y:50.55},0).wait(1).to({rotation:-40.6901,x:17.05,y:54.85},0).wait(1).to({rotation:-48.2363,y:60.25},0).wait(1).to({rotation:-57.704,x:18,y:66.9},0).wait(1).to({rotation:-69.5952,x:20.75,y:74.95},0).wait(1).to({rotation:-83.7062,x:25.95,y:83.5},0).wait(1).to({rotation:-98.1499,x:33.35,y:90.7},0).wait(1).to({rotation:-110.7267,x:41.05,y:95.2},0).wait(1).to({rotation:-120.8736,x:47.9,y:97.6},0).wait(1).to({rotation:-128.9999,x:53.6,y:98.6},0).wait(1).to({rotation:-135.6121,x:58.35,y:98.85},0).wait(1).to({rotation:-141.095,x:62.2,y:98.6},0).wait(1).to({rotation:-145.7175,x:65.5,y:98.1},0).wait(1).to({rotation:-149.667,x:68.25,y:97.45},0).wait(1).to({rotation:-153.0773,x:70.65,y:96.8},0).wait(1).to({rotation:-156.0464,x:72.6,y:96.1},0).wait(1).to({rotation:-158.6477,x:74.3,y:95.4},0).wait(1).to({rotation:-160.9377,x:75.8,y:94.7},0).wait(1).to({rotation:-162.9604,x:77.05,y:94.05},0).wait(1).to({rotation:-164.7513,x:78.2,y:93.4},0).wait(1).to({rotation:-166.3388,x:79.15,y:92.8},0).wait(1).to({rotation:-167.7463,x:80,y:92.3},0).wait(1).to({rotation:-168.9936,x:80.8,y:91.85},0).wait(1).to({rotation:-170.0968,x:81.45,y:91.4},0).wait(1).to({rotation:-171.0701,x:82,y:90.95},0).wait(1).to({rotation:-171.9252,x:82.45,y:90.65},0).wait(1).to({rotation:-172.6727,x:82.9,y:90.3},0).wait(1).to({rotation:-173.3213,x:83.25,y:90},0).wait(1).to({regX:57.9,regY:57.9,rotation:-173.879,x:57.85,y:57.95},0).wait(1).to({regX:28.9,regY:29,rotation:-173.9985,x:83.7,y:89.65},0).wait(1).to({rotation:-174.0984,x:83.75,y:89.6},0).wait(1).to({rotation:-174.1799,x:83.8,y:89.55},0).wait(1).to({rotation:-174.2445,x:83.85},0).wait(1).to({rotation:-174.2931,x:83.9},0).wait(1).to({rotation:-174.3267,y:89.5},0).wait(1).to({rotation:-174.3463},0).wait(1).to({regX:57.7,regY:57.8,rotation:-174.3527,x:58,y:57.95},0).wait(1));

	// Layer_2
	this.instance_1 = new lib.circleSegment();
	this.instance_1.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regX:28.9,regY:29,rotation:-0.0144,x:28.9,y:29},0).wait(1).to({rotation:-0.059},0).wait(1).to({rotation:-0.1357,x:28.85,y:29.05},0).wait(1).to({rotation:-0.247,x:28.8,y:29.1},0).wait(1).to({rotation:-0.3955,x:28.75,y:29.2},0).wait(1).to({rotation:-0.584,x:28.65,y:29.25},0).wait(1).to({rotation:-0.8159,x:28.5,y:29.4},0).wait(1).to({rotation:-1.0949,x:28.4,y:29.55},0).wait(1).to({rotation:-1.4252,x:28.2,y:29.75},0).wait(1).to({rotation:-1.8118,x:28,y:29.95},0).wait(1).to({rotation:-2.2604,x:27.85,y:30.15},0).wait(1).to({rotation:-2.7775,x:27.55,y:30.4},0).wait(1).to({rotation:-3.371,x:27.25,y:30.75},0).wait(1).to({rotation:-4.05,x:27,y:31.1},0).wait(1).to({rotation:-4.8258,x:26.6,y:31.5},0).wait(1).to({rotation:-5.7118,x:26.2,y:31.95},0).wait(1).to({rotation:-6.7245,x:25.75,y:32.55},0).wait(1).to({rotation:-7.8849,x:25.3,y:33.25},0).wait(1).to({rotation:-9.2193,x:24.7,y:34},0).wait(1).to({rotation:-10.7621,x:24.05,y:34.9},0).wait(1).to({rotation:-12.559,x:23.35,y:35.95},0).wait(1).to({rotation:-14.6721,x:22.55,y:37.25},0).wait(1).to({rotation:-17.1885,x:21.65,y:38.8},0).wait(1).to({rotation:-20.2327,x:20.75,y:40.75},0).wait(1).to({rotation:-23.985,x:19.7,y:43.25},0).wait(1).to({rotation:-28.6927,x:18.6,y:46.45},0).wait(1).to({rotation:-34.6055,x:17.65,y:50.5},0).wait(1).to({rotation:-41.622,x:17.05,y:55.5},0).wait(1).to({rotation:-48.8041,x:17.1,y:60.6},0).wait(1).to({rotation:-55.0577,x:17.6,y:65.05},0).wait(1).to({rotation:-60.1032,x:18.45,y:68.55},0).wait(1).to({rotation:-64.1439,x:19.3,y:71.3},0).wait(1).to({rotation:-67.4317,x:20.15,y:73.5},0).wait(1).to({rotation:-70.1581,x:20.95,y:75.3},0).wait(1).to({rotation:-72.4565,x:21.65,y:76.75},0).wait(1).to({rotation:-74.4204,x:22.3,y:78},0).wait(1).to({rotation:-76.1161,x:22.95,y:79.05},0).wait(1).to({rotation:-77.5925,x:23.45,y:79.95},0).wait(1).to({rotation:-78.886,x:23.95,y:80.7},0).wait(1).to({rotation:-80.0246,x:24.45,y:81.35},0).wait(1).to({rotation:-81.0304,x:24.85,y:81.95},0).wait(1).to({rotation:-81.9209,x:25.25,y:82.5},0).wait(1).to({rotation:-82.7103,x:25.55,y:82.95},0).wait(1).to({rotation:-83.4102,x:25.9,y:83.35},0).wait(1).to({rotation:-84.0303,x:26.2,y:83.65},0).wait(1).to({rotation:-84.5789,x:26.45,y:84},0).wait(1).to({rotation:-85.0629,x:26.65,y:84.2},0).wait(1).to({rotation:-85.4881,x:26.8,y:84.5},0).wait(1).to({rotation:-85.8597,x:27,y:84.7},0).wait(1).to({rotation:-86.1822,x:27.15,y:84.85},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.4596,x:57.95,y:57.85},0).wait(1).to({regX:28.9,regY:29,rotation:-86.5188,x:27.35,y:85},0).wait(1).to({rotation:-86.5683,y:85.05},0).wait(1).to({rotation:-86.6087},0).wait(1).to({rotation:-86.6407,x:27.4},0).wait(1).to({rotation:-86.6647,y:85.1},0).wait(1).to({rotation:-86.6814,x:27.35},0).wait(1).to({rotation:-86.6911,y:85.05},0).wait(1).to({regX:57.9,regY:57.9,rotation:-86.6943,x:57.9,y:57.85},0).wait(1));

	// Layer_1
	this.instance_2 = new lib.circleSegment();
	this.instance_2.setTransform(57.9,57.9,1,1,0,0,0,57.9,57.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(60));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-5.8,-5.8,127.5,127.5);


(lib.blur = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.overlayc.cache(-0,-0,245,157,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.overlayc = new lib.overlay_c();
	this.overlayc.name = "overlayc";
	this.overlayc.setTransform(121.8,78.5,1,1,0,0,0,121.8,78.5);

	this.timeline.addTween(cjs.Tween.get(this.overlayc).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.blur, new cjs.Rectangle(0,0,243.7,156.9), null);


(lib.big_pie = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// w/ shadow
	this.b_shadow = new lib.bigshadow();
	this.b_shadow.name = "b_shadow";
	this.b_shadow.setTransform(210,210,1,1,0,0,0,210,210);
	this.b_shadow.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.b_shadow).wait(1));

	// top
	this.b_top = new lib.bigtop();
	this.b_top.name = "b_top";
	this.b_top.setTransform(210,210,1,1,0,0,0,210,210);

	this.timeline.addTween(cjs.Tween.get(this.b_top).wait(1));

	// depth
	this.b_depth = new lib.bigdepth();
	this.b_depth.name = "b_depth";
	this.b_depth.setTransform(209.75,210,1,1,0,0,0,210,210);

	this.timeline.addTween(cjs.Tween.get(this.b_depth).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.big_pie, new cjs.Rectangle(-0.2,0,420.2,420), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib._3D_price = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// percentage
	this.percantage = new lib.percantage();
	this.percantage.name = "percantage";
	this.percantage.setTransform(-17.1,-14.4,0.554,0.5298,0,0,0,209.8,210);

	this.timeline.addTween(cjs.Tween.get(this.percantage).wait(1));

	// Big
	this.b_pie = new lib.big_pie();
	this.b_pie.name = "b_pie";
	this.b_pie.setTransform(-16.6,-14.4,0.554,0.5298,0,0,0,209.8,210);

	this.timeline.addTween(cjs.Tween.get(this.b_pie).wait(1));

	// Small
	this.s_pie = new lib.small_pie();
	this.s_pie.name = "s_pie";
	this.s_pie.setTransform(-17.85,-8.5,0.554,0.5298,0,0,0,209.8,210);

	this.timeline.addTween(cjs.Tween.get(this.s_pie).wait(1));

	// Shadow
	this.c_shadow = new lib.chart_shadow();
	this.c_shadow.name = "c_shadow";
	this.c_shadow.setTransform(-17.3,-14.95,0.554,0.5298,0,0,0,209.8,210);

	this.timeline.addTween(cjs.Tween.get(this.c_shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._3D_price, new cjs.Rectangle(-134.1,-126.2,234,229), null);


(lib.UI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.mainUI.cache(-475,-300,950,600,0.6)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Main_UI
	this.mainUI = new lib.main_ui();
	this.mainUI.name = "mainUI";

	this.timeline.addTween(cjs.Tween.get(this.mainUI).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.UI, new cjs.Rectangle(-0.3,0,471.7,290.7), null);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.screen_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_69 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4).call(this.frame_4).wait(65).call(this.frame_69).wait(1));

	// Layer_4
	this.instance = new lib.Rectangle111jpg();
	this.instance.setTransform(-108.9,7.05,0.7519,1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(70));

	// SmallGraphCover
	this.instance_1 = new lib.whitebar();
	this.instance_1.setTransform(284.05,-150.1,1.1639,1.0777,0,0,0,17.8,38.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(4).to({regX:17.9,scaleX:1.4222,x:288.8},0).to({scaleX:1.2503,scaleY:0.5617,x:285.75,y:-189.9},51,cjs.Ease.quartInOut).wait(15));

	// SmallGraph
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4AA167").s().p("Ai/JMIAAyXIF/AAIAASXg");
	this.shape.setTransform(282.6,-128.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#327545").s().p("Ai/KhIAA1BIF/AAIAACpIAASYg");
	this.shape_1.setTransform(244.175,-136.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(70));

	// Layer_6
	this.chart_mask = new lib.chart_mask();
	this.chart_mask.name = "chart_mask";
	this.chart_mask.setTransform(-29.15,-97.5,1,1,0,0,0,59.1,63);
	this.chart_mask.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.chart_mask).wait(70));

	// Text
	this.instance_2 = new lib.textanimation("synched",0,false);
	this.instance_2.setTransform(-26.65,-93.55,1,1,0,0,0,33.1,22.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(70));

	// GraphMask
	this.instance_3 = new lib.GraphCover("synched",0,false);
	this.instance_3.setTransform(-57.95,-124.7,1,1,0,0,0,28.9,28.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(70));

	// Graph_LG
	this.instance_4 = new lib.graphLG();
	this.instance_4.setTransform(-28.95,-95.65,1,1,0,0,0,49.9,49.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(70));

	// UI
	this.instance_5 = new lib.UI();
	this.instance_5.setTransform(115.85,-274.1,1,1,0,0,0,225,5.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(70));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-109.4,-279.6,471.6,305.70000000000005);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-30.35,2.5,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("Am6B5IAAjyIN1AAIAADyg");
	this.shape.setTransform(-59.375,2);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-10.1,88.7,24.299999999999997), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(46.05,220.4,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(117.2,217.5,1.1404,1.1404,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// graf_3D
	this.td_graph = new lib._3D_price();
	this.td_graph.name = "td_graph";
	this.td_graph.setTransform(125.5,163.75,0.5888,0.5412,0,0,0,5.5,0.8);
	this.td_graph.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.td_graph).wait(1));

	// Icon
	this.icon = new lib.icon();
	this.icon.name = "icon";
	this.icon.setTransform(48.45,99.95,0.9238,0.9238,0,0,0,64.8,62.9);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(1));

	// Overlay
	this.overlay = new lib.blur();
	this.overlay.name = "overlay";
	this.overlay.setTransform(216.85,172.25,1,1,0,0,0,121.8,78.5);
	this.overlay.alpha = 0;
	this.overlay.filters = [new cjs.BlurFilter(15, 15, 1)];
	this.overlay.cache(-2,-2,248,161);

	this.timeline.addTween(cjs.Tween.get(this.overlay).wait(1));

	// screen
	this.screen = new lib.screen_anim();
	this.screen.name = "screen";
	this.screen.setTransform(185.45,124.8,0.5523,0.4421,0,-28.3421,-17.0437,107.7,-133.9);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// shadow
	this.shadow = new lib.shadow_1();
	this.shadow.name = "shadow";
	this.shadow.setTransform(207.95,152.1,0.8321,0.832,0,0,0,180.5,119.9);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(283.7,4.05,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Ribbon
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-227.3,-31.3,614.6,456.6), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"


		this.initBanner = function (data) {

			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;

			Object.keys = function(obj) {
				var keys = [];

				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)

				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}


		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]

			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}



		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]


			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)

			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset

				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}

		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines

			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()

				for (var j = 0; j < aSplit.length; j++) {

					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}


		var mc = exportRoot.mainMC
		var screen = mc.screen
		var ribbon = mc.ribbon
		var icon = mc.icon
		var shadow = mc.shadow
		var mask = screen.chart_mask
		var graph = mc.td_graph
		/*mc.cta.alpha=0
		mc.replay_btn.alpha=0*/

		this.runBanner = function() {

			this.tl1 = new TimelineLite();

				exportRoot.tl1.from(screen, 1.4, {  x: "+=250",y: "+=250",	ease:Power4.easeOut,onComplete:function(){screen.gotoAndPlay(05);}}, "+=0.2");
				exportRoot.tl1.from(icon, 1.4, {  x: "+=250",y: "+=250",	ease:Power4.easeOut}, "-=1.4");
				exportRoot.tl1.from(shadow, 1.4, {  x: "+=250",y: "+=250",	ease:Power4.easeOut}, "-=1.4");


				exportRoot.tl1.to(screen, 1.2, {x: "+=27",y: "+=48",scaleX: "0.45",scaleY: "0.36", ease:Power4.easeInOut,onComplete:function(){ribbon.gotoAndPlay(0);}}, "+=1.4");
				exportRoot.tl1.to(icon, 1.2, {x: "+=53",y: "+=50",scaleX: "0.76",scaleY: "0.76", ease:Power4.easeInOut}, "-=1.2");
			    exportRoot.tl1.to(shadow, 1.2, {x: "+=37",y: "+=47",scaleX: "0.75",scaleY: "0.75", ease:Power4.easeInOut}, "-=1.2");


				//Start : 3D chart
				exportRoot.tl1.to(mask, 0.2, {alpha :1, ease:Power2.easeInOut}, "-=1");
				exportRoot.tl1.to(graph, 0.2, {alpha :1, ease:Power2.easeInOut}, "-=1");
				exportRoot.tl1.to(graph, 1.6, {x: "+=74",y: "+=7",scaleX: "1",scaleY: "1", ease:Power4.easeInOut}, "-=1.4");
				exportRoot.tl1.to(mc.overlay, 0.7, {alpha :0.60, ease:Power2.easeInOut}, "-=1.2");

				exportRoot.tl1.to(graph.s_pie, 1, {x: "+=1.3",y: "-=6", ease:Power2.easeInOut}, "-=0.8");
				exportRoot.tl1.to(graph.s_pie.shine, 1, {alpha :1, ease:Power2.easeInOut}, "-=1");
				exportRoot.tl1.from(graph.s_pie.s_depth, 1, {alpha :0,x: "-=0.5",y: "-=4.5", ease:Power2.easeInOut}, "-=1");

				exportRoot.tl1.to(graph.b_pie.b_shadow, 1, {alpha :1, ease:Power2.easeInOut}, "-=1");
				exportRoot.tl1.from(graph.b_pie.b_depth, 1, {alpha :0,x: "-=0.25",y: "-=4.5", ease:Power2.easeInOut}, "-=1");

				exportRoot.tl1.from(graph.percantage, 1, {x: "-=3.35",y: "+=7", ease:Power2.easeInOut}, "-=1");
				exportRoot.tl1.from(graph.percantage.numdepth, 1, {alpha :0,x: "+=1",y: "-=1.3", ease:Power2.easeInOut}, "-=1");

				exportRoot.tl1.from(graph.c_shadow, 0.3, {alpha :0,ease:Power2.easeInOut}, "-=1");
				exportRoot.tl1.from(graph.c_shadow, 1, {x: "+=6",y: "-=16", ease:Power2.easeInOut}, "-=1");
				//End : 3D chart


				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.6");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}

				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}


				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "-=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");

				exportRoot.tl1.stop();

			mc.logo_intro.gotoAndPlay(1)

		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.3,93.7,464.6,331.6);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 250,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593011887462", id:"M365_FY21Q1_BTS_USA_300x250_BAN_Excel_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {
	var lastW, lastH, lastS=1;
	window.addEventListener('resize', resizeCanvas);
	resizeCanvas();
	function resizeCanvas() {
		var w = lib.properties.width, h = lib.properties.height;
		var iw = window.innerWidth, ih=window.innerHeight;
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;
		if(isResp) {
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {
				sRatio = lastS;
			}
			else if(!isScale) {
				if(iw<w || ih<h)
					sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==1) {
				sRatio = Math.min(xRatio, yRatio);
			}
			else if(scaleType==2) {
				sRatio = Math.max(xRatio, yRatio);
			}
		}
		domContainers[0].width = w * pRatio * sRatio;
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {
			container.style.width = w * sRatio + 'px';
			container.style.height = h * sRatio + 'px';
		});
		stage.scaleX = pRatio*sRatio;
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;
		stage.tickOnUpdate = false;
		stage.update();
		stage.tickOnUpdate = true;
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;
