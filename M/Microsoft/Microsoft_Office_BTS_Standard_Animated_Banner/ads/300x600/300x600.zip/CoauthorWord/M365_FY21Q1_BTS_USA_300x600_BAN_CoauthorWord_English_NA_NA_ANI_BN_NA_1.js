(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[0,0,604,384],[606,235,268,215],[634,452,168,106],[284,386,177,130],[560,623,102,86],[804,558,156,76],[107,579,104,86],[463,386,122,39],[664,623,104,82],[804,452,151,104],[0,579,105,86],[876,345,112,90],[606,0,350,233],[463,452,169,106],[0,386,282,191],[284,518,120,111],[406,560,152,63],[560,560,152,61],[876,235,138,108]]}
];


// symbols:



(lib.basicUI = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.Bitmap1 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.firstimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.girlleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.girllefticon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.girlrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.girlrighticon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.guyleftcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.guylefticon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.guyrightcontribution = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.guyrighticon1 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.roundshadow1 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow1111 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.secondimage = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.Teams_icon_1500x15001 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.titleshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.title = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Word = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtA/0MAAAh/nMCZbAAAMAAAB/ng");
	this.shape.setTransform(0,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-408.3,982,816.7);


(lib.titleshadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.titleshadow();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.titleshadow_1, new cjs.Rectangle(0,0,76,31.5), null);


(lib.title_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.title();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.title_1, new cjs.Rectangle(0,0,76,30.5), null);


(lib.tile_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#CCCCCC").ss(1,1,1).p("Ap6sQIT1AAQCWAAAACWIAAT1QAACWiWAAIz1AAQiWAAAAiWIAAz1QAAiWCWAAg");
	this.shape.setTransform(78.5,78.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ap6MRQiWAAAAiWIAAz1QAAiWCWAAIT1AAQCWAAAACWIAAT1QAACWiWAAg");
	this.shape_1.setTransform(78.5,78.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,-8.4,0.1,8.5).s().p("AIdBXIwmAAIg2AAIAAisIEbAAIJbAAIEJAAIAACsg");
	this.shape_2.setTransform(77.6,157.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA6gbBEAAQB9AABZBZQBZBZAAB8QAABFgbA6IkaAAIAACsIA1AAQgXAEgYAAQh8AAhZhZg");
	this.shape_3.setTransform(20.7,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_4.setTransform(-0.6,77.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AgtErIAjAAIAAisIkJAAQgbg6AAhFQAAh8BZhZQBZhZB8AAQBFAAA6AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh+AAQgXAAgWgEg");
	this.shape_5.setTransform(136.3,136.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_6.setTransform(157.65,79.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_7.setTransform(136.3,20.475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_8.setTransform(79.4,-0.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_9.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.tile_shadow_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],0.1,11.9,0.1,28.8).s().p("AIdEhIwmAAIg2AAIAApBIB+AAIOVAAIBsAAIAAJBg");
	this.shape.setTransform(77.6,137.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],9.1,0,0,9.1,0,31).s().p("Ah5DWQhZhYAAh+QAAgXADgWIAAAjICtAAIAAkJQA5gbBFAAQBAAAA3AYIh+AAIAAJBIA1AAQgWAEgYAAQh9AAhYhZg");
	this.shape_1.setTransform(11.5125,136.55);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],8.5,0.1,-8.4,0.1).s().p("AhWJAIAAgjIAAwrIAAgxICsAAIAAEWIAAJgIAAEJg");
	this.shape_2.setTransform(-0.6,77.85);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],-9.2,0,0,-9.2,0,31).s().p("AiJErIAjAAIAApBIhsAAQA3gYBAAAQBFAAA5AbIAAEWICtAAIAAgwQADAWAAAXQAAB+hYBYQhZBZh9AAQgYAAgWgEg");
	this.shape_3.setTransform(145.5,136.55);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-8.5,-0.1,8.4,-0.1).s().p("AhVJAIAAkWIAApgIAAkJICsAAIAAAjIAAQrIAAAxg");
	this.shape_4.setTransform(157.65,79.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("AjVDWQhZhZAAh9QAAhEAbg6IEaAAIAAitIg0AAQAWgDAXAAQB+AABZBZQBYBZAAB8QAAAYgDAXIAAgkIitAAIAAEJQg6AbhFAAQh8AAhZhZg");
	this.shape_5.setTransform(136.3,20.475);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0,1],-0.1,8.5,-0.1,-8.4).s().p("AElBXIpbAAIkJAAIAAitIAkAAIQmAAIA1AAIAACtg");
	this.shape_6.setTransform(79.4,-0.85);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(0,0,0,0.149)","rgba(0,0,0,0)"],[0.412,0.976],0,0,0,0,0,31).s().p("Ah+EUIAAkVIitAAIAAAwQgDgXAAgYQAAh8BZhZQBZhZB8AAQAYAAAXADIgkAAIAACtIEJAAQAbA6AABEQAAB9hZBZQhZBZh9AAQhEAAg6gbg");
	this.shape_7.setTransform(20.7,20.475);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.tile_shadow_sub, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.text03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text03, new cjs.Rectangle(0,0,78,38), null);


(lib.text02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text02, new cjs.Rectangle(0,0,88.5,65), null);


(lib.text01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyleftcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text01, new cjs.Rectangle(0,0,61,19.5), null);


(lib.secondimage_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.secondimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.secondimage_1, new cjs.Rectangle(0,0,84.5,53), null);


(lib.screenBG = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.basicUI();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenBG, new cjs.Rectangle(0,0,302,192), null);


(lib.screenshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.screenshadow1111();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.roundshadowshape = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.roundshadow1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadowshape, new cjs.Rectangle(0,0,56,45), null);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AiyP1IA3gTIEuNvIg3ASg");
	var mask_graphics_69 = new cjs.Graphics().p("AsSP1IT3m1IEuNvIz3G1g");
	var mask_graphics_70 = new cjs.Graphics().p("A0FP1MAjcgMMIEvNvMgjcAMMg");
	var mask_graphics_71 = new cjs.Graphics().p("A6UP2MAv6gQeIEvNuMgv6AQfg");
	var mask_graphics_72 = new cjs.Graphics().p("A/KP2MA5ngT0IEuNuMg5nAT1g");
	var mask_graphics_73 = new cjs.Graphics().p("Egi0AP2MBA6gWVIEvNuMhA6AWWg");
	var mask_graphics_74 = new cjs.Graphics().p("EglbAP2MBGIgYIIEvNuMhGIAYJg");
	var mask_graphics_75 = new cjs.Graphics().p("EgnLAP2MBJogZVIEvNuMhJoAZWg");
	var mask_graphics_76 = new cjs.Graphics().p("EgoPAP2MBLwgaEIEvNuMhLwAaFg");
	var mask_graphics_77 = new cjs.Graphics().p("EgoyAP2MBM2gacIEvNuMhM2Aadg");
	var mask_graphics_78 = new cjs.Graphics().p("Ego/AP2MBNQgalIEvNuMhNQAamg");
	var mask_graphics_79 = new cjs.Graphics().p("EgpBAPxMBNUgamIEvNuMhNUAang");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:4.3586,y:189.1495}).wait(1).to({graphics:mask_graphics_69,x:64.9841,y:189.1916}).wait(1).to({graphics:mask_graphics_70,x:114.6137,y:189.2262}).wait(1).to({graphics:mask_graphics_71,x:154.35,y:189.2539}).wait(1).to({graphics:mask_graphics_72,x:185.2941,y:189.2756}).wait(1).to({graphics:mask_graphics_73,x:208.5465,y:189.2918}).wait(1).to({graphics:mask_graphics_74,x:225.2069,y:189.3034}).wait(1).to({graphics:mask_graphics_75,x:236.3746,y:189.3112}).wait(1).to({graphics:mask_graphics_76,x:243.1482,y:189.316}).wait(1).to({graphics:mask_graphics_77,x:246.6265,y:189.3184}).wait(1).to({graphics:mask_graphics_78,x:247.908,y:189.3193}).wait(1).to({graphics:mask_graphics_79,x:250.9688,y:188.8245}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvWlDIetAAI8pKIg");
	this.shape.setTransform(125.5534,333.0522,1.2376,1.2376);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("A9tFfMA7bgVGIAAK8Mg5XAUTg");
	this.shape_1.setTransform(240.1785,249.6936,1.2397,1.2397);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_58 = new cjs.Graphics().p("Ab2dVIADuRIAgAAIgDORg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AbrdVIADuRIArAAIgDOSg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AagdVIAEuRIB1AAIgDOSg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AXWdVIADuRIFAAAIgDOSg");
	var mask_1_graphics_62 = new cjs.Graphics().p("ARNdUIADuRILJABIgDOSg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AHEdTIADuRIVSADIgDORg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AmsdSIADuRMAjDAAEIgEORg");
	var mask_1_graphics_65 = new cjs.Graphics().p("Aw1dRIAEuRMAtLAAFIgDORg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A2+dQIADuRMAzVAAGIgDORg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A6IdQIADuRMA2fAAGIgDORg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A7TdQIADuSMA3qAAHIgDORg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A74dPIADuRMA30AAGIgDORg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_1_graphics_58,x:181.7064,y:187.75}).wait(1).to({graphics:mask_1_graphics_59,x:181.7066,y:187.7503}).wait(1).to({graphics:mask_1_graphics_60,x:181.7083,y:187.7507}).wait(1).to({graphics:mask_1_graphics_61,x:181.7129,y:187.7519}).wait(1).to({graphics:mask_1_graphics_62,x:181.7218,y:187.7541}).wait(1).to({graphics:mask_1_graphics_63,x:181.7365,y:187.7579}).wait(1).to({graphics:mask_1_graphics_64,x:181.7564,y:187.763}).wait(1).to({graphics:mask_1_graphics_65,x:181.7711,y:187.7667}).wait(1).to({graphics:mask_1_graphics_66,x:181.78,y:187.769}).wait(1).to({graphics:mask_1_graphics_67,x:181.7846,y:187.7701}).wait(1).to({graphics:mask_1_graphics_68,x:181.7863,y:187.7706}).wait(1).to({graphics:mask_1_graphics_69,x:179.1064,y:187.725}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("AvKFFIcXqIIB/KIg");
	this.shape_2.setTransform(235.2505,333.4075,1.2397,1.2397);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(58).to({_off:false},0).wait(22));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A0EFFIiEqIMAqSAAAIB/KIg");
	this.shape_3.setTransform(180.0198,333.4075,1.2397,1.2397);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_29 = new cjs.Graphics().p("A3Gf8IDShIIFTPYIjRBIg");
	var mask_2_graphics_30 = new cjs.Graphics().p("A3Ff7IJ3jZIFTPZIp3DZg");
	var mask_2_graphics_31 = new cjs.Graphics().p("A3Ff7IQZlpIFTPZIwZFpg");
	var mask_2_graphics_32 = new cjs.Graphics().p("A3Ef7IWzn2IFSPZI2yH2g");
	var mask_2_graphics_33 = new cjs.Graphics().p("A3Ef7IdBp/IFTPYI9BKAg");
	var mask_2_graphics_34 = new cjs.Graphics().p("A3Df7MAjAgMDIFTPYMgjAAMEg");
	var mask_2_graphics_35 = new cjs.Graphics().p("A3Df7MAotgOBIFTPZMgotAOAg");
	var mask_2_graphics_36 = new cjs.Graphics().p("A5sf6MAuGgP3IFTPZMguGAP3g");
	var mask_2_graphics_37 = new cjs.Graphics().p("A8Nf6MAzIgRmIFTPZMgzIARmg");
	var mask_2_graphics_38 = new cjs.Graphics().p("A+kf6MA31gTOIFUPZMg31ATOg");
	var mask_2_graphics_39 = new cjs.Graphics().p("EggvAf6MA8MgUuIFTPZMg8MAUug");
	var mask_2_graphics_40 = new cjs.Graphics().p("EgivAf6MBAMgWGIFTPZMhAMAWGg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgklAf6MBD4gXXIFTPYMhD4AXYg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgmRAf6MBHQgYiIFTPZMhHQAYig");
	var mask_2_graphics_43 = new cjs.Graphics().p("Egn0Af6MBKWgZmIFTPZMhKWAZlg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgpOAf5MBNKgakIFTPZMhNKAakg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgqhAf5MBPwgbdIFTPZMhPwAbdg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgrtAf5MBSIgcRIFTPZMhSIAcRg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgsyAf5MBUSgdAIFTPYMhUSAdBg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EgtxAf5MBWQgdsIFTPZMhWQAdsg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EguqAf5MBYCgeUIFTPZMhYCAeUg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgvfAf5MBZsge4IFTPZMhZsAe4g");
	var mask_2_graphics_51 = new cjs.Graphics().p("EgwPAf5MBbMgfZIFTPZMhbMAfZg");
	var mask_2_graphics_52 = new cjs.Graphics().p("Egw6Af5MBcigf3IFTPZMhciAf3g");
	var mask_2_graphics_53 = new cjs.Graphics().p("EgxiAf5MBdyggRIFTPYMhdyAgSg");
	var mask_2_graphics_54 = new cjs.Graphics().p("EgyGAf5MBe6ggqIFTPYMhe6Agrg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EgymAf5MBf6ghBIFTPYMhf6AhCg");
	var mask_2_graphics_56 = new cjs.Graphics().p("EgzEAf5MBg2ghVIFTPYMhg2AhWg");
	var mask_2_graphics_57 = new cjs.Graphics().p("EgzfAf5MBhsghnIFTPXMhhsAhpg");
	var mask_2_graphics_58 = new cjs.Graphics().p("Egz3Af5MBicgh4IFTPYMhicAh5g");
	var mask_2_graphics_59 = new cjs.Graphics().p("Eg0MAf5MBjGgiHIFTPYMhjGAiIg");
	var mask_2_graphics_60 = new cjs.Graphics().p("Eg0fAf5MBjsgiUIFTPYMhjsAiVg");
	var mask_2_graphics_61 = new cjs.Graphics().p("Eg0wAf4MBkOgigIFTPYMhkOAihg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_2_graphics_29,x:-147.85,y:302.8431}).wait(1).to({graphics:mask_2_graphics_30,x:-147.8049,y:302.8244}).wait(1).to({graphics:mask_2_graphics_31,x:-147.7602,y:302.8059}).wait(1).to({graphics:mask_2_graphics_32,x:-147.7164,y:302.7878}).wait(1).to({graphics:mask_2_graphics_33,x:-147.6739,y:302.7702}).wait(1).to({graphics:mask_2_graphics_34,x:-147.6329,y:302.7533}).wait(1).to({graphics:mask_2_graphics_35,x:-147.5939,y:302.7372}).wait(1).to({graphics:mask_2_graphics_36,x:-130.6243,y:302.7219}).wait(1).to({graphics:mask_2_graphics_37,x:-114.4138,y:302.7077}).wait(1).to({graphics:mask_2_graphics_38,x:-99.3288,y:302.6944}).wait(1).to({graphics:mask_2_graphics_39,x:-85.3647,y:302.6821}).wait(1).to({graphics:mask_2_graphics_40,x:-72.4906,y:302.6708}).wait(1).to({graphics:mask_2_graphics_41,x:-60.6573,y:302.6604}).wait(1).to({graphics:mask_2_graphics_42,x:-49.8043,y:302.6508}).wait(1).to({graphics:mask_2_graphics_43,x:-39.8656,y:302.6421}).wait(1).to({graphics:mask_2_graphics_44,x:-30.7736,y:302.6341}).wait(1).to({graphics:mask_2_graphics_45,x:-22.4621,y:302.6268}).wait(1).to({graphics:mask_2_graphics_46,x:-14.8677,y:302.6201}).wait(1).to({graphics:mask_2_graphics_47,x:-7.9314,y:302.614}).wait(1).to({graphics:mask_2_graphics_48,x:-1.5984,y:302.6084}).wait(1).to({graphics:mask_2_graphics_49,x:4.1814,y:302.6033}).wait(1).to({graphics:mask_2_graphics_50,x:9.4535,y:302.5987}).wait(1).to({graphics:mask_2_graphics_51,x:14.2594,y:302.5945}).wait(1).to({graphics:mask_2_graphics_52,x:18.6363,y:302.5906}).wait(1).to({graphics:mask_2_graphics_53,x:22.6182,y:302.5871}).wait(1).to({graphics:mask_2_graphics_54,x:26.2355,y:302.5839}).wait(1).to({graphics:mask_2_graphics_55,x:29.5158,y:302.5811}).wait(1).to({graphics:mask_2_graphics_56,x:32.4841,y:302.5784}).wait(1).to({graphics:mask_2_graphics_57,x:35.1629,y:302.5761}).wait(1).to({graphics:mask_2_graphics_58,x:37.5728,y:302.574}).wait(1).to({graphics:mask_2_graphics_59,x:39.7322,y:302.5721}).wait(1).to({graphics:mask_2_graphics_60,x:41.6582,y:302.5704}).wait(1).to({graphics:mask_2_graphics_61,x:44.092,y:302.4935}).wait(19));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("Egm0AIAMBLqgbAIB/KJMhNpAb4g");
	this.shape_4.setTransform(47.6459,444.0858,1.2397,1.2397);
	this.shape_4._off = true;

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(29).to({_off:false},0).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-260.4,0,736.4,595);


(lib.Outlook_shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Bitmap1();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Outlook_shadow, new cjs.Rectangle(0,0,268,215), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.image01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyrightcontribution();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.image01, new cjs.Rectangle(0,0,75.5,52), null);


(lib.firstimage_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.firstimage();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.firstimage_1, new cjs.Rectangle(0,0,84,53), null);


(lib.fill = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#EFF2F4").s().p("Ai9A3QgHgUABAAIF0hsIATAhIl7ByIgGgTg");
	this.shape.setTransform(19.5683,7.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F3F4FC").s().p("AkrhLICsg9IgSgZID6hIIDDFGImaCNg");
	this.shape_1.setTransform(35.1625,36.875);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.fill, new cjs.Rectangle(0,0,65.2,60.3), null);


(lib.face04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girlrighticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face04, new cjs.Rectangle(0,0,52,43), null);


(lib.face03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.girllefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face03, new cjs.Rectangle(0,0,51,43), null);


(lib.face02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guylefticon();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face02, new cjs.Rectangle(0,0,52,41), null);


(lib.face01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.guyrighticon1();
	this.instance.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.face01, new cjs.Rectangle(0,0,52.5,43), null);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.boxshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.setTransform(-70.4,-47.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.boxshadowpicture, new cjs.Rectangle(-70.4,-47.7,282,191), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAu4MAAAhdvMAu3AAAMAAABdvg");
	this.shape.setTransform(150.0023,124.9924,1,0.4166);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,250), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.WordUI = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.screen.cache(-151,-96,608,384,2);
		this.screen.cache(-475,-300,950,600,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.screen = new lib.screenBG();
	this.screen.name = "screen";
	this.screen.setTransform(150.8,95.8,1,1,0,0,0,150.8,95.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordUI, new cjs.Rectangle(0,0,302,192), null);


(lib.squareshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-71,-48,283,192);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.boxshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(70.5,47.75,0.5,0.5,0,0,0,70.5,47.8);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.squareshadow, new cjs.Rectangle(0.1,0,141,95.5), null);


(lib.shadow_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-31.6,-11.15,416.5,277.25,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(176.7,127.45,1,1,0,0,0,208.3,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow_1, new cjs.Rectangle(-31.6,-11.1,416.5,277.20000000000005), null);


(lib.roundshadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-28,-22.5,112,90,2);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.shadow = new lib.roundshadowshape();
	this.shadow.name = "shadow";
	this.shadow.setTransform(28,22.5,1,1,0,0,0,28,22.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.roundshadow, new cjs.Rectangle(0,0,56,45), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_59 = function() {
		exportRoot.tl1.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(296.7,899.9,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:296.65},13,cjs.Ease.quadOut).to({x:22.4},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgShBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgS0BKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgTtBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVNBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXSBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZ+BKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdPBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EgghBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjMBKdIAAwoMBbtAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglSBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmxBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgnqBKdIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn9BKdIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:468.4789,y:476.4845}).wait(1).to({graphics:mask_graphics_15,x:466.573,y:476.4845}).wait(1).to({graphics:mask_graphics_16,x:460.8553,y:476.4845}).wait(1).to({graphics:mask_graphics_17,x:451.3258,y:476.4845}).wait(1).to({graphics:mask_graphics_18,x:437.9844,y:476.4845}).wait(1).to({graphics:mask_graphics_19,x:420.8313,y:476.4845}).wait(1).to({graphics:mask_graphics_20,x:399.8664,y:476.4845}).wait(1).to({graphics:mask_graphics_21,x:378.9015,y:476.4845}).wait(1).to({graphics:mask_graphics_22,x:361.7483,y:476.4845}).wait(1).to({graphics:mask_graphics_23,x:348.407,y:476.4845}).wait(1).to({graphics:mask_graphics_24,x:338.8775,y:476.4845}).wait(1).to({graphics:mask_graphics_25,x:333.1598,y:476.4845}).wait(1).to({graphics:mask_graphics_26,x:331.2539,y:476.4845}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_1 = new lib.MSFT_Logo_anim();
	this.instance_1.setTransform(-134.1,894,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({x:220.3},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.4,scaleX:2.408,scaleY:2.408,x:36.8,y:33.9},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_2 = new lib.Tween1("synched",0);
	this.instance_2.setTransform(299.85,916,1,2.4487,0,0,0,0,4.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-94,982,2000);


(lib.iconcache = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Word();
	this.instance.setTransform(14,0,1.6738,1.6738);

	this.instance_1 = new lib.Outlook_shadow();
	this.instance_1.setTransform(127.4,117.7,0.95,0.95,0,0,0,134.1,107.5);
	this.instance_1.alpha = 0.1992;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.iconcache, new cjs.Rectangle(0,0,254.6,219.9), null);


(lib.icon_teams = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.tile_sub.cache(0,0,157,157,1)
		this.shadow_sub.cache(-20,-20,197,197,1)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.instance = new lib.Teams_icon_1500x15001();
	this.instance.setTransform(21.2,25.15,0.95,0.95);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer_5
	this.tile_sub = new lib.tile_sub();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	// Layer_3
	this.shadow_sub = new lib.tile_shadow_sub();
	this.shadow_sub.name = "shadow_sub";
	this.shadow_sub.setTransform(78.5,78.5,1,1,0,0,0,78.5,78.5);

	this.timeline.addTween(cjs.Tween.get(this.shadow_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.icon_teams, new cjs.Rectangle(-9.6,-9.8,176.2,176.70000000000002), null);


(lib.guyrighticon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face01.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face01 = new lib.face01();
	this.face01.name = "face01";
	this.face01.setTransform(26.4,21.5,1,1,0,0,0,26.4,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrighticon, new cjs.Rectangle(0,0,52.5,43), null);


(lib.guyrightcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.image01.cache(-80,-55,160,110,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.image01 = new lib.image01();
	this.image01.name = "image01";
	this.image01.setTransform(38.1,26.2,1,1,0,0,0,38.1,26.2);

	this.timeline.addTween(cjs.Tween.get(this.image01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyrightcontribution_1, new cjs.Rectangle(0,0,75.5,52), null);


(lib.guylefticon_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face02.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face02 = new lib.face02();
	this.face02.name = "face02";
	this.face02.setTransform(25.9,20.4,1,1,0,0,0,25.9,20.4);

	this.timeline.addTween(cjs.Tween.get(this.face02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guylefticon_1, new cjs.Rectangle(0,0,52,41), null);


(lib.guyleftcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text01.cache(-70,-20,140,40,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text01 = new lib.text01();
	this.text01.name = "text01";
	this.text01.setTransform(30.4,9.8,1,1,0,0,0,30.4,9.8);

	this.timeline.addTween(cjs.Tween.get(this.text01).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.guyleftcontribution_1, new cjs.Rectangle(0,0,61,19.5), null);


(lib.girlrigthcontribution = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text03.cache(-80,-40,160,80,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text03 = new lib.text03();
	this.text03.name = "text03";
	this.text03.setTransform(39.1,19.1,1,1,0,0,0,39.1,19.1);

	this.timeline.addTween(cjs.Tween.get(this.text03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrigthcontribution, new cjs.Rectangle(0,0,78,38), null);


(lib.girlrighticon_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face04.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face04 = new lib.face04();
	this.face04.name = "face04";
	this.face04.setTransform(25.9,21.5,1,1,0,0,0,25.9,21.5);

	this.timeline.addTween(cjs.Tween.get(this.face04).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlrighticon_1, new cjs.Rectangle(0,0,52,43), null);


(lib.girllefticon_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.face03.cache(-54,-45,108,90,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.face03 = new lib.face03();
	this.face03.name = "face03";
	this.face03.setTransform(25.3,21.3,1,1,0,0,0,25.3,21.3);

	this.timeline.addTween(cjs.Tween.get(this.face03).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girllefticon_1, new cjs.Rectangle(0,0,51,43), null);


(lib.girlleftcontribution_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.text02.cache(-90,-70,180,140,1.4)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.text02 = new lib.text02();
	this.text02.name = "text02";
	this.text02.setTransform(44,32.3,1,1,0,0,0,44,32.3);

	this.timeline.addTween(cjs.Tween.get(this.text02).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.girlleftcontribution_1, new cjs.Rectangle(0,0,88.5,65), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,250,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,250), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.WordIcon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.iconcache.cache(-260,-230,520,460,0.8);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.iconcache = new lib.iconcache();
	this.iconcache.name = "iconcache";
	this.iconcache.setTransform(225.3,236.4,1,1,0,0,0,127.3,109.9);

	this.timeline.addTween(cjs.Tween.get(this.iconcache).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.WordIcon, new cjs.Rectangle(98,126.5,254.60000000000002,219.89999999999998), null);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.tile_sub = new lib.icon_teams();
	this.tile_sub.name = "tile_sub";
	this.tile_sub.setTransform(-62.7,61.15,0.7,0.7,0,0,0,77,79);

	this.timeline.addTween(cjs.Tween.get(this.tile_sub).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_mc, new cjs.Rectangle(-123.3,-1,123.3,123.7), null);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);
	}
	this.frame_81 = function() {
		exportRoot.tl1.play();
	}
	this.frame_140 = function() {
		exportRoot.tl1.pause();
	}
	this.frame_157 = function() {
		exportRoot.tl1.play();
	}
	this.frame_218 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(81).call(this.frame_81).wait(59).call(this.frame_140).wait(17).call(this.frame_157).wait(61).call(this.frame_218).wait(1));

	// guy right icon.png
	this.instance = new lib.guyrighticon();
	this.instance.setTransform(222.3,-24.35,1,1,0,0,0,26.4,21.5);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(19).to({_off:false},0).to({scaleX:1.037,scaleY:1.037,x:203.15,y:57.55,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:26.2,x:202.9},0).wait(11).to({regX:26.4,x:203.15},0).wait(1).to({regX:26.2,scaleX:1.0334,scaleY:1.0334,x:202.9,y:58},0).wait(1).to({scaleX:1.0293,scaleY:1.0293,y:58.55},0).wait(1).to({scaleX:1.025,scaleY:1.025,x:202.95,y:59.1},0).wait(1).to({scaleX:1.0203,scaleY:1.0203,x:203,y:59.75},0).wait(1).to({scaleX:1.0152,scaleY:1.0152,x:203.05,y:60.4},0).wait(1).to({scaleX:1.0098,scaleY:1.0098,y:61.1},0).wait(1).to({scaleX:1.0041,scaleY:1.0041,x:203.1,y:61.85},0).wait(1).to({scaleX:0.998,scaleY:0.998,x:203.15,y:62.65},0).wait(1).to({scaleX:0.9916,scaleY:0.9916,x:203.2,y:63.5},0).wait(1).to({scaleX:0.9848,scaleY:0.9848,y:64.35},0).wait(1).to({scaleX:0.9778,scaleY:0.9778,x:203.25,y:65.3},0).wait(1).to({scaleX:0.9704,scaleY:0.9704,x:203.3,y:66.25},0).wait(1).to({scaleX:0.9627,scaleY:0.9627,x:203.35,y:67.3},0).wait(1).to({scaleX:0.9547,scaleY:0.9547,x:203.4,y:68.35},0).wait(1).to({scaleX:0.9465,scaleY:0.9465,x:203.45,y:69.45},0).wait(1).to({scaleX:0.938,scaleY:0.938,x:203.5,y:70.55},0).wait(1).to({scaleX:0.9292,scaleY:0.9292,x:203.55,y:71.7},0).wait(1).to({scaleX:0.9203,scaleY:0.9203,x:203.6,y:72.9},0).wait(1).to({scaleX:0.9112,scaleY:0.9112,x:203.65,y:74.1},0).wait(1).to({scaleX:0.9019,scaleY:0.9019,x:203.75,y:75.3},0).wait(1).to({scaleX:0.8925,scaleY:0.8925,x:203.8,y:76.55},0).wait(1).to({scaleX:0.883,scaleY:0.883,x:203.85,y:77.8},0).wait(1).to({scaleX:0.8735,scaleY:0.8735,x:203.95,y:79.05},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:204,y:80.25},0).wait(1).to({scaleX:0.8544,scaleY:0.8544,x:204.05,y:81.5},0).wait(1).to({scaleX:0.8449,scaleY:0.8449,x:204.1,y:82.75},0).wait(1).to({scaleX:0.8354,scaleY:0.8354,x:204.15,y:84},0).wait(1).to({scaleX:0.8261,scaleY:0.8261,x:204.2,y:85.25},0).wait(1).to({scaleX:0.8169,scaleY:0.8169,x:204.25,y:86.45},0).wait(1).to({scaleX:0.8079,scaleY:0.8079,x:204.3,y:87.65},0).wait(1).to({scaleX:0.799,scaleY:0.799,x:204.4,y:88.85},0).wait(1).to({scaleX:0.7904,scaleY:0.7904,y:89.95},0).wait(1).to({scaleX:0.782,scaleY:0.782,x:204.5,y:91.05},0).wait(1).to({scaleX:0.7739,scaleY:0.7739,x:204.55,y:92.15},0).wait(1).to({scaleX:0.766,scaleY:0.766,y:93.15},0).wait(1).to({scaleX:0.7585,scaleY:0.7585,x:204.6,y:94.15},0).wait(1).to({scaleX:0.7512,scaleY:0.7512,x:204.7,y:95.1},0).wait(1).to({scaleX:0.7443,scaleY:0.7443,y:96},0).wait(1).to({scaleX:0.7377,scaleY:0.7377,x:204.8,y:96.85},0).wait(1).to({scaleX:0.7315,scaleY:0.7315,y:97.7},0).wait(1).to({scaleX:0.7255,scaleY:0.7255,x:204.85,y:98.5},0).wait(1).to({scaleX:0.72,scaleY:0.72,y:99.25},0).wait(1).to({scaleX:0.7148,scaleY:0.7148,x:204.95,y:99.9},0).wait(1).to({scaleX:0.7099,scaleY:0.7099,y:100.55},0).wait(1).to({scaleX:0.7054,scaleY:0.7054,x:205,y:101.1},0).wait(1).to({scaleX:0.7012,scaleY:0.7012,x:204.95,y:101.7},0).wait(1).to({scaleX:0.6973,scaleY:0.6973,x:205,y:102.2},0).wait(1).to({scaleX:0.6938,scaleY:0.6938,x:205.05,y:102.65},0).wait(1).to({scaleX:0.6907,scaleY:0.6907,y:103.05},0).wait(1).to({scaleX:0.6878,scaleY:0.6878,y:103.45},0).wait(1).to({scaleX:0.6853,scaleY:0.6853,x:205.1,y:103.8},0).wait(1).to({scaleX:0.6831,scaleY:0.6831,y:104.05},0).wait(1).to({scaleX:0.6813,scaleY:0.6813,y:104.3},0).wait(1).to({scaleX:0.6797,scaleY:0.6797,y:104.5},0).wait(1).to({scaleX:0.6784,scaleY:0.6784,y:104.7},0).wait(1).to({scaleX:0.6774,scaleY:0.6774,x:205.15,y:104.8},0).wait(1).to({scaleX:0.6768,scaleY:0.6768,y:104.9},0).wait(1).to({scaleX:0.6763,scaleY:0.6763,x:205.1,y:104.95},0).wait(1).to({regX:26.6,regY:21.7,scaleX:0.6762,scaleY:0.6762,x:205.35,y:105},0).wait(1).to({regX:26.2,regY:21.5,x:205.05,y:104.9},0).wait(15).to({regX:26.6,regY:21.7,x:205.35,y:105},0).wait(1).to({regX:26.2,regY:21.5,scaleX:0.6761,scaleY:0.6761,x:205.05,y:104.85},0).wait(1).to({scaleX:0.6759,scaleY:0.6759},0).wait(1).to({scaleX:0.6756,scaleY:0.6756},0).wait(1).to({scaleX:0.6752,scaleY:0.6752,x:205.1,y:104.75},0).wait(1).to({scaleX:0.6748,scaleY:0.6748},0).wait(1).to({scaleX:0.6742,scaleY:0.6742,y:104.7},0).wait(1).to({scaleX:0.6735,scaleY:0.6735,x:205.15,y:104.65},0).wait(1).to({scaleX:0.6726,scaleY:0.6726,y:104.55},0).wait(1).to({scaleX:0.6717,scaleY:0.6717,x:205.2,y:104.5},0).wait(1).to({scaleX:0.6706,scaleY:0.6706,y:104.4},0).wait(1).to({scaleX:0.6693,scaleY:0.6693,x:205.25,y:104.35},0).wait(1).to({scaleX:0.6678,scaleY:0.6678,x:205.3,y:104.2},0).wait(1).to({scaleX:0.6662,scaleY:0.6662,x:205.35,y:104.05},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,x:205.4,y:103.95},0).wait(1).to({scaleX:0.6621,scaleY:0.6621,x:205.45,y:103.75},0).wait(1).to({scaleX:0.6597,scaleY:0.6597,x:205.55,y:103.6},0).wait(1).to({scaleX:0.657,scaleY:0.657,x:205.6,y:103.35},0).wait(1).to({scaleX:0.6539,scaleY:0.6539,x:205.75,y:103.1},0).wait(1).to({scaleX:0.6503,scaleY:0.6503,x:205.85,y:102.85},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:205.95,y:102.5},0).wait(1).to({scaleX:0.6416,scaleY:0.6416,x:206.05,y:102.15},0).wait(1).to({scaleX:0.6362,scaleY:0.6362,x:206.2,y:101.7},0).wait(1).to({scaleX:0.6299,scaleY:0.6299,x:206.45,y:101.2},0).wait(1).to({scaleX:0.6224,scaleY:0.6224,x:206.65,y:100.65},0).wait(1).to({scaleX:0.6134,scaleY:0.6134,x:206.9,y:99.9},0).wait(1).to({scaleX:0.6023,scaleY:0.6023,x:207.3,y:99},0).wait(1).to({scaleX:0.5886,scaleY:0.5886,x:207.65,y:97.95},0).wait(1).to({scaleX:0.5717,scaleY:0.5717,x:208.2,y:96.6},0).wait(1).to({scaleX:0.5522,scaleY:0.5522,x:208.75,y:95.05},0).wait(1).to({scaleX:0.5326,scaleY:0.5326,x:209.35,y:93.5},0).wait(1).to({scaleX:0.5154,scaleY:0.5154,x:209.85,y:92.15},0).wait(1).to({scaleX:0.5014,scaleY:0.5014,x:210.3,y:91.05},0).wait(1).to({scaleX:0.49,scaleY:0.49,x:210.65,y:90.15},0).wait(1).to({scaleX:0.4806,scaleY:0.4806,x:210.9,y:89.4},0).wait(1).to({scaleX:0.4728,scaleY:0.4728,x:211.15,y:88.75},0).wait(1).to({scaleX:0.4661,scaleY:0.4661,x:211.35,y:88.25},0).wait(1).to({scaleX:0.4604,scaleY:0.4604,x:211.5,y:87.8},0).wait(1).to({scaleX:0.4555,scaleY:0.4555,x:211.7,y:87.4},0).wait(1).to({scaleX:0.4511,scaleY:0.4511,x:211.8,y:87.05},0).wait(1).to({scaleX:0.4473,scaleY:0.4473,x:211.9,y:86.75},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:212.05,y:86.5},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:212.1,y:86.3},0).wait(1).to({scaleX:0.4382,scaleY:0.4382,x:212.2,y:86},0).wait(1).to({scaleX:0.4358,scaleY:0.4358,x:212.25,y:85.85},0).wait(1).to({scaleX:0.4337,scaleY:0.4337,x:212.3,y:85.65},0).wait(1).to({scaleX:0.4318,scaleY:0.4318,x:212.35,y:85.55},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:212.4,y:85.4},0).wait(1).to({scaleX:0.4286,scaleY:0.4286,x:212.5,y:85.25},0).wait(1).to({scaleX:0.4272,scaleY:0.4272,x:212.55,y:85.2},0).wait(1).to({scaleX:0.426,scaleY:0.426,y:85.05},0).wait(1).to({scaleX:0.4249,scaleY:0.4249,x:212.6,y:85},0).wait(1).to({scaleX:0.424,scaleY:0.424,y:84.9},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,x:212.65,y:84.85},0).wait(1).to({scaleX:0.4225,scaleY:0.4225,y:84.8},0).wait(1).to({scaleX:0.4219,scaleY:0.4219,x:212.7,y:84.75},0).wait(1).to({scaleX:0.4214,scaleY:0.4214,y:84.7},0).wait(1).to({scaleX:0.421,scaleY:0.421,x:212.75},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:212.7,y:84.65},0).wait(1).to({scaleX:0.4204,scaleY:0.4204},0).wait(1).to({scaleX:0.4203,scaleY:0.4203},0).wait(1).to({scaleX:0.4202,scaleY:0.4202},0).wait(1).to({regX:26.6,regY:21.6,scaleX:0.4201,scaleY:0.4201,x:212.95,y:84.7},0).wait(1));

	// guy left icon.png
	this.instance_1 = new lib.guylefticon_1();
	this.instance_1.setTransform(-84.7,115.9,1,1,0,0,0,25.9,20.4);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(25).to({_off:false},0).to({x:72.55,y:74.6,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:26,regY:20.5,x:72.65,y:74.7},0).wait(12).to({regX:25.9,regY:20.4,x:72.55,y:74.6},0).wait(1).to({regX:26,regY:20.5,scaleX:0.995,scaleY:0.995,x:73.75,y:75.25},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:75,y:75.85},0).wait(1).to({scaleX:0.9834,scaleY:0.9834,x:76.3,y:76.45},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:77.75,y:77.2},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:79.3,y:77.95},0).wait(1).to({scaleX:0.9626,scaleY:0.9626,x:81,y:78.75},0).wait(1).to({scaleX:0.9547,scaleY:0.9547,x:82.7,y:79.55},0).wait(1).to({scaleX:0.9464,scaleY:0.9464,x:84.55,y:80.45},0).wait(1).to({scaleX:0.9375,scaleY:0.9375,x:86.55,y:81.4},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:88.6,y:82.45},0).wait(1).to({scaleX:0.9185,scaleY:0.9185,x:90.8,y:83.5},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:93,y:84.55},0).wait(1).to({scaleX:0.8978,scaleY:0.8978,x:95.4,y:85.7},0).wait(1).to({scaleX:0.8869,scaleY:0.8869,x:97.8,y:86.9},0).wait(1).to({scaleX:0.8755,scaleY:0.8755,x:100.35,y:88.1},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:102.95,y:89.35},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:105.65,y:90.65},0).wait(1).to({scaleX:0.8396,scaleY:0.8396,x:108.4,y:92},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,x:111.15,y:93.35},0).wait(1).to({scaleX:0.8143,scaleY:0.8143,x:113.95,y:94.75},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,x:116.9,y:96.15},0).wait(1).to({scaleX:0.7884,scaleY:0.7884,x:119.75,y:97.5},0).wait(1).to({scaleX:0.7753,scaleY:0.7753,x:122.7,y:98.95},0).wait(1).to({scaleX:0.7621,scaleY:0.7621,x:125.6,y:100.35},0).wait(1).to({scaleX:0.749,scaleY:0.749,x:128.5,y:101.75},0).wait(1).to({scaleX:0.7359,scaleY:0.7359,x:131.45,y:103.2},0).wait(1).to({scaleX:0.723,scaleY:0.723,x:134.35,y:104.55},0).wait(1).to({scaleX:0.7101,scaleY:0.7101,x:137.2,y:105.95},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:140.05,y:107.35},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:142.75,y:108.7},0).wait(1).to({scaleX:0.6729,scaleY:0.6729,x:145.5,y:110},0).wait(1).to({scaleX:0.661,scaleY:0.661,x:148.15,y:111.25},0).wait(1).to({scaleX:0.6495,scaleY:0.6495,x:150.7,y:112.5},0).wait(1).to({scaleX:0.6384,scaleY:0.6384,x:153.2,y:113.75},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:155.55,y:114.85},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:157.9,y:116},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:160.15,y:117.1},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:162.25,y:118.1},0).wait(1).to({scaleX:0.5887,scaleY:0.5887,x:164.25,y:119.05},0).wait(1).to({scaleX:0.5801,scaleY:0.5801,x:166.2,y:120},0).wait(1).to({scaleX:0.5719,scaleY:0.5719,x:167.95,y:120.85},0).wait(1).to({scaleX:0.5643,scaleY:0.5643,x:169.65,y:121.7},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:171.3,y:122.45},0).wait(1).to({scaleX:0.5504,scaleY:0.5504,x:172.75,y:123.25},0).wait(1).to({scaleX:0.5442,scaleY:0.5442,x:174.15,y:123.9},0).wait(1).to({scaleX:0.5385,scaleY:0.5385,x:175.45,y:124.5},0).wait(1).to({scaleX:0.5332,scaleY:0.5332,x:176.6,y:125.1},0).wait(1).to({scaleX:0.5284,scaleY:0.5284,x:177.7,y:125.6},0).wait(1).to({scaleX:0.524,scaleY:0.524,x:178.65,y:126.05},0).wait(1).to({scaleX:0.5201,scaleY:0.5201,x:179.5,y:126.45},0).wait(1).to({scaleX:0.5167,scaleY:0.5167,x:180.3,y:126.85},0).wait(1).to({scaleX:0.5137,scaleY:0.5137,x:180.95,y:127.2},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:181.55,y:127.5},0).wait(1).to({scaleX:0.5089,scaleY:0.5089,x:182.05,y:127.7},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:182.4,y:127.9},0).wait(1).to({scaleX:0.5058,scaleY:0.5058,x:182.7,y:128},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:182.95,y:128.15},0).wait(1).to({scaleX:0.5043,scaleY:0.5043,x:183.05,y:128.2},0).wait(1).to({regX:26.2,regY:20.7,scaleX:0.5042,scaleY:0.5042,y:128.25},0).wait(1).to({regX:26,regY:20.5,x:182.95,y:128.15},0).wait(15).to({regX:26.2,regY:20.7,x:183.05,y:128.25},0).wait(1).to({regX:26,regY:20.5,scaleX:0.5041,scaleY:0.5041,x:182.9,y:128.1},0).wait(1).to({scaleX:0.504,scaleY:0.504,x:182.85},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,x:182.8,y:128.05},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,x:182.75,y:128},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:182.65,y:127.9},0).wait(1).to({scaleX:0.5034,scaleY:0.5034,x:182.55,y:127.85},0).wait(1).to({scaleX:0.5032,scaleY:0.5032,x:182.4,y:127.75},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:182.25,y:127.65},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:182,y:127.5},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:181.75,y:127.35},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:181.5,y:127.2},0).wait(1).to({scaleX:0.5011,scaleY:0.5011,x:181.2,y:126.95},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:180.8,y:126.75},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:180.4,y:126.5},0).wait(1).to({scaleX:0.4989,scaleY:0.4989,x:179.9,y:126.2},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:179.35,y:125.8},0).wait(1).to({scaleX:0.4968,scaleY:0.4968,x:178.65,y:125.35},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:177.9,y:124.85},0).wait(1).to({scaleX:0.4938,scaleY:0.4938,x:176.95,y:124.25},0).wait(1).to({scaleX:0.4918,scaleY:0.4918,x:175.85,y:123.55},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:174.4,y:122.65},0).wait(1).to({scaleX:0.4864,scaleY:0.4864,x:172.7,y:121.5},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:170.45,y:120.05},0).wait(1).to({scaleX:0.4776,scaleY:0.4776,x:167.6,y:118.2},0).wait(1).to({scaleX:0.4718,scaleY:0.4718,x:164.3,y:116.05},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:161.15,y:114.05},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:158.55,y:112.35},0).wait(1).to({scaleX:0.4584,scaleY:0.4584,x:156.55,y:111.1},0).wait(1).to({scaleX:0.4557,scaleY:0.4557,x:154.95,y:110.05},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:153.7,y:109.2},0).wait(1).to({scaleX:0.4516,scaleY:0.4516,x:152.6,y:108.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:151.7,y:107.9},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:150.9,y:107.45},0).wait(1).to({scaleX:0.4475,scaleY:0.4475,x:150.3,y:107},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:149.7,y:106.65},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:149.2,y:106.35},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:148.75,y:106.05},0).wait(1).to({scaleX:0.4442,scaleY:0.4442,x:148.35,y:105.8},0).wait(1).to({scaleX:0.4437,scaleY:0.4437,x:148.05,y:105.6},0).wait(1).to({scaleX:0.4431,scaleY:0.4431,x:147.7,y:105.4},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:147.5,y:105.25},0).wait(1).to({scaleX:0.4423,scaleY:0.4423,x:147.25,y:105.05},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:147.1,y:104.95},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:146.9,y:104.85},0).wait(1).to({scaleX:0.4414,scaleY:0.4414,x:146.8,y:104.75},0).wait(1).to({scaleX:0.4412,scaleY:0.4412,x:146.6,y:104.7},0).wait(1).to({scaleX:0.4411,scaleY:0.4411,x:146.5,y:104.6},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:146.45,y:104.55},0).wait(1).to({scaleX:0.4408,scaleY:0.4408,x:146.4},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:146.35,y:104.5},0).wait(1).to({x:146.3},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,y:104.45},0).wait(1).to({regX:26.2,regY:20.8,x:146.4,y:104.55},0).wait(8));

	// girl right icon.png
	this.instance_2 = new lib.girlrighticon_1();
	this.instance_2.setTransform(212.4,302.25,1,1,0,0,0,25.9,21.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({scaleX:1.0251,scaleY:1.0251,x:170.1,y:237.45,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:26,x:170.2},0).wait(16).to({regX:25.9,x:170.1},0).wait(1).to({regX:26,scaleX:1.0214,scaleY:1.0214,x:170.4,y:236.85},0).wait(1).to({scaleX:1.0174,scaleY:1.0174,x:170.65,y:236.25},0).wait(1).to({scaleX:1.013,scaleY:1.013,x:170.95,y:235.7},0).wait(1).to({scaleX:1.0083,scaleY:1.0083,x:171.2,y:235},0).wait(1).to({scaleX:1.0032,scaleY:1.0032,x:171.55,y:234.25},0).wait(1).to({scaleX:0.9978,scaleY:0.9978,x:171.85,y:233.45},0).wait(1).to({scaleX:0.9921,scaleY:0.9921,x:172.2,y:232.65},0).wait(1).to({scaleX:0.986,scaleY:0.986,x:172.6,y:231.75},0).wait(1).to({scaleX:0.9796,scaleY:0.9796,x:172.95,y:230.8},0).wait(1).to({scaleX:0.9729,scaleY:0.9729,x:173.4,y:229.85},0).wait(1).to({scaleX:0.9658,scaleY:0.9658,x:173.8,y:228.8},0).wait(1).to({scaleX:0.9584,scaleY:0.9584,x:174.25,y:227.75},0).wait(1).to({scaleX:0.9508,scaleY:0.9508,x:174.75,y:226.65},0).wait(1).to({scaleX:0.9428,scaleY:0.9428,x:175.25,y:225.5},0).wait(1).to({scaleX:0.9346,scaleY:0.9346,x:175.75,y:224.3},0).wait(1).to({scaleX:0.9261,scaleY:0.9261,x:176.3,y:223.05},0).wait(1).to({scaleX:0.9173,scaleY:0.9173,x:176.8,y:221.8},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:177.35,y:220.55},0).wait(1).to({scaleX:0.8993,scaleY:0.8993,x:177.95,y:219.25},0).wait(1).to({scaleX:0.89,scaleY:0.89,x:178.5,y:217.9},0).wait(1).to({scaleX:0.8806,scaleY:0.8806,x:179.1,y:216.5},0).wait(1).to({scaleX:0.8711,scaleY:0.8711,x:179.65,y:215.15},0).wait(1).to({scaleX:0.8615,scaleY:0.8615,x:180.25,y:213.7},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:180.85,y:212.35},0).wait(1).to({scaleX:0.8423,scaleY:0.8423,x:181.45,y:210.95},0).wait(1).to({scaleX:0.8327,scaleY:0.8327,x:182,y:209.55},0).wait(1).to({scaleX:0.8231,scaleY:0.8231,x:182.6,y:208.2},0).wait(1).to({scaleX:0.8137,scaleY:0.8137,x:183.2,y:206.85},0).wait(1).to({scaleX:0.8043,scaleY:0.8043,x:183.75,y:205.5},0).wait(1).to({scaleX:0.7952,scaleY:0.7952,x:184.3,y:204.15},0).wait(1).to({scaleX:0.7862,scaleY:0.7862,x:184.9,y:202.85},0).wait(1).to({scaleX:0.7774,scaleY:0.7774,x:185.4,y:201.55},0).wait(1).to({scaleX:0.7688,scaleY:0.7688,x:185.95,y:200.35},0).wait(1).to({scaleX:0.7605,scaleY:0.7605,x:186.45,y:199.15},0).wait(1).to({scaleX:0.7524,scaleY:0.7524,x:186.95,y:198},0).wait(1).to({scaleX:0.7446,scaleY:0.7446,x:187.45,y:196.85},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:187.9,y:195.75},0).wait(1).to({scaleX:0.73,scaleY:0.73,x:188.35,y:194.7},0).wait(1).to({scaleX:0.7231,scaleY:0.7231,x:188.75,y:193.75},0).wait(1).to({scaleX:0.7166,scaleY:0.7166,x:189.2,y:192.75},0).wait(1).to({scaleX:0.7104,scaleY:0.7104,x:189.55,y:191.85},0).wait(1).to({scaleX:0.7046,scaleY:0.7046,x:189.9,y:191.05},0).wait(1).to({scaleX:0.6991,scaleY:0.6991,x:190.25,y:190.25},0).wait(1).to({scaleX:0.6939,scaleY:0.6939,x:190.55,y:189.5},0).wait(1).to({scaleX:0.6891,scaleY:0.6891,x:190.85,y:188.8},0).wait(1).to({scaleX:0.6846,scaleY:0.6846,x:191.15,y:188.15},0).wait(1).to({scaleX:0.6805,scaleY:0.6805,x:191.4,y:187.6},0).wait(1).to({scaleX:0.6767,scaleY:0.6767,x:191.65,y:187},0).wait(1).to({scaleX:0.6732,scaleY:0.6732,x:191.85,y:186.5},0).wait(1).to({scaleX:0.6701,scaleY:0.6701,x:192,y:186.05},0).wait(1).to({scaleX:0.6673,scaleY:0.6673,x:192.2,y:185.65},0).wait(1).to({scaleX:0.6648,scaleY:0.6648,x:192.35,y:185.3},0).wait(1).to({scaleX:0.6627,scaleY:0.6627,x:192.5,y:185},0).wait(1).to({scaleX:0.6608,scaleY:0.6608,x:192.6,y:184.7},0).wait(1).to({scaleX:0.6593,scaleY:0.6593,x:192.7,y:184.45},0).wait(1).to({scaleX:0.658,scaleY:0.658,x:192.75,y:184.3},0).wait(1).to({scaleX:0.657,scaleY:0.657,x:192.85,y:184.2},0).wait(1).to({scaleX:0.6564,scaleY:0.6564,y:184.05},0).wait(1).to({scaleX:0.656,scaleY:0.656,x:192.9,y:184},0).wait(1).to({regX:26.2,regY:21.8,scaleX:0.6558,scaleY:0.6558,x:192.95,y:184.05},0).wait(1).to({regX:26,regY:21.5,x:192.8,y:183.85},0).wait(14).to({regX:26.2,regY:21.8,x:192.95,y:184.05},0).wait(1).to({regX:26,regY:21.5,scaleX:0.6557,scaleY:0.6557,x:192.75,y:183.8},0).wait(1).to({scaleX:0.6555,scaleY:0.6555,y:183.7},0).wait(1).to({scaleX:0.6552,scaleY:0.6552,y:183.6},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:192.65,y:183.5},0).wait(1).to({scaleX:0.6543,scaleY:0.6543,x:192.6,y:183.25},0).wait(1).to({scaleX:0.6537,scaleY:0.6537,x:192.55,y:183.05},0).wait(1).to({scaleX:0.6529,scaleY:0.6529,x:192.5,y:182.8},0).wait(1).to({scaleX:0.652,scaleY:0.652,x:192.4,y:182.45},0).wait(1).to({scaleX:0.651,scaleY:0.651,x:192.3,y:182.1},0).wait(1).to({scaleX:0.6498,scaleY:0.6498,x:192.15,y:181.6},0).wait(1).to({scaleX:0.6484,scaleY:0.6484,x:192,y:181.15},0).wait(1).to({scaleX:0.6467,scaleY:0.6467,x:191.85,y:180.55},0).wait(1).to({scaleX:0.6449,scaleY:0.6449,x:191.65,y:179.85},0).wait(1).to({scaleX:0.6428,scaleY:0.6428,x:191.45,y:179.1},0).wait(1).to({scaleX:0.6404,scaleY:0.6404,x:191.2,y:178.25},0).wait(1).to({scaleX:0.6376,scaleY:0.6376,x:190.95,y:177.25},0).wait(1).to({scaleX:0.6345,scaleY:0.6345,x:190.65,y:176.15},0).wait(1).to({scaleX:0.6309,scaleY:0.6309,x:190.25,y:174.8},0).wait(1).to({scaleX:0.6267,scaleY:0.6267,x:189.85,y:173.3},0).wait(1).to({scaleX:0.6218,scaleY:0.6218,x:189.35,y:171.55},0).wait(1).to({scaleX:0.6161,scaleY:0.6161,x:188.75,y:169.5},0).wait(1).to({scaleX:0.6092,scaleY:0.6092,x:188.1,y:167},0).wait(1).to({scaleX:0.601,scaleY:0.601,x:187.25,y:164},0).wait(1).to({scaleX:0.5908,scaleY:0.5908,x:186.2,y:160.35},0).wait(1).to({scaleX:0.578,scaleY:0.578,x:184.95,y:155.8},0).wait(1).to({scaleX:0.562,scaleY:0.562,x:183.3,y:150},0).wait(1).to({scaleX:0.5429,scaleY:0.5429,x:181.35,y:143.05},0).wait(1).to({scaleX:0.5232,scaleY:0.5232,x:179.4,y:136},0).wait(1).to({scaleX:0.506,scaleY:0.506,x:177.65,y:129.8},0).wait(1).to({scaleX:0.4921,scaleY:0.4921,x:176.25,y:124.8},0).wait(1).to({scaleX:0.481,scaleY:0.481,x:175.15,y:120.8},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:174.2,y:117.5},0).wait(1).to({scaleX:0.4645,scaleY:0.4645,x:173.5,y:114.8},0).wait(1).to({scaleX:0.4582,scaleY:0.4582,x:172.85,y:112.55},0).wait(1).to({scaleX:0.4528,scaleY:0.4528,x:172.3,y:110.6},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:171.85,y:108.95},0).wait(1).to({scaleX:0.4441,scaleY:0.4441,x:171.45,y:107.45},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,x:171.05,y:106.15},0).wait(1).to({scaleX:0.4374,scaleY:0.4374,x:170.75,y:105.05},0).wait(1).to({scaleX:0.4347,scaleY:0.4347,x:170.45,y:104.05},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:170.25,y:103.2},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:170.05,y:102.4},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:169.85,y:101.7},0).wait(1).to({scaleX:0.4265,scaleY:0.4265,x:169.65,y:101.05},0).wait(1).to({scaleX:0.425,scaleY:0.425,x:169.5,y:100.55},0).wait(1).to({scaleX:0.4236,scaleY:0.4236,x:169.35,y:100.05},0).wait(1).to({scaleX:0.4225,scaleY:0.4225,x:169.25,y:99.65},0).wait(1).to({scaleX:0.4215,scaleY:0.4215,x:169.15,y:99.25},0).wait(1).to({scaleX:0.4206,scaleY:0.4206,x:169.05,y:98.95},0).wait(1).to({scaleX:0.4198,scaleY:0.4198,x:168.95,y:98.7},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:168.9,y:98.45},0).wait(1).to({scaleX:0.4186,scaleY:0.4186,x:168.85,y:98.25},0).wait(1).to({scaleX:0.4182,scaleY:0.4182,x:168.8,y:98.1},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,x:168.75,y:98},0).wait(1).to({scaleX:0.4176,scaleY:0.4176,y:97.9},0).wait(1).to({scaleX:0.4174,scaleY:0.4174,y:97.8},0).wait(1).to({scaleX:0.4173,scaleY:0.4173,x:168.7,y:97.75},0).wait(1).to({regX:26.3,regY:21.8,x:168.8,y:97.9},0).wait(1));

	// girl left icon.png
	this.instance_3 = new lib.girllefticon_1();
	this.instance_3.setTransform(-95.95,220,1,1,0,0,0,25.3,21.3);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(9).to({_off:false},0).to({regX:25.4,regY:21.4,scaleX:1.0222,scaleY:1.0222,x:55.45,y:178.7,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:25.5,regY:21.5,x:55.55,y:178.8},0).wait(19).to({regX:25.4,regY:21.4,x:55.45,y:178.7},0).wait(1).to({regX:25.5,regY:21.5,scaleX:1.0168,scaleY:1.0168,x:56.9,y:178.45},0).wait(1).to({scaleX:1.011,scaleY:1.011,x:58.35,y:178.2},0).wait(1).to({scaleX:1.0046,scaleY:1.0046,x:59.9,y:177.85},0).wait(1).to({scaleX:0.9977,scaleY:0.9977,x:61.65,y:177.5},0).wait(1).to({scaleX:0.9903,scaleY:0.9903,x:63.5,y:177.1},0).wait(1).to({scaleX:0.9824,scaleY:0.9824,x:65.5,y:176.65},0).wait(1).to({scaleX:0.974,scaleY:0.974,x:67.6,y:176.25},0).wait(1).to({scaleX:0.9651,scaleY:0.9651,x:69.8,y:175.8},0).wait(1).to({scaleX:0.9556,scaleY:0.9556,x:72.15,y:175.3},0).wait(1).to({scaleX:0.9457,scaleY:0.9457,x:74.6,y:174.8},0).wait(1).to({scaleX:0.9353,scaleY:0.9353,x:77.25,y:174.25},0).wait(1).to({scaleX:0.9245,scaleY:0.9245,x:79.9,y:173.7},0).wait(1).to({scaleX:0.9132,scaleY:0.9132,x:82.75,y:173.1},0).wait(1).to({scaleX:0.9015,scaleY:0.9015,x:85.7,y:172.5},0).wait(1).to({scaleX:0.8894,scaleY:0.8894,x:88.7,y:171.85},0).wait(1).to({scaleX:0.8769,scaleY:0.8769,x:91.8,y:171.2},0).wait(1).to({scaleX:0.8641,scaleY:0.8641,x:95.05,y:170.55},0).wait(1).to({scaleX:0.851,scaleY:0.851,x:98.3,y:169.85},0).wait(1).to({scaleX:0.8377,scaleY:0.8377,x:101.6,y:169.15},0).wait(1).to({scaleX:0.8241,scaleY:0.8241,x:105,y:168.45},0).wait(1).to({scaleX:0.8104,scaleY:0.8104,x:108.4,y:167.75},0).wait(1).to({scaleX:0.7965,scaleY:0.7965,x:111.85,y:167.05},0).wait(1).to({scaleX:0.7826,scaleY:0.7826,x:115.35,y:166.35},0).wait(1).to({scaleX:0.7687,scaleY:0.7687,x:118.85,y:165.6},0).wait(1).to({scaleX:0.7548,scaleY:0.7548,x:122.3,y:164.9},0).wait(1).to({scaleX:0.741,scaleY:0.741,x:125.75,y:164.2},0).wait(1).to({scaleX:0.7273,scaleY:0.7273,x:129.2,y:163.45},0).wait(1).to({scaleX:0.7138,scaleY:0.7138,x:132.55,y:162.75},0).wait(1).to({scaleX:0.7005,scaleY:0.7005,x:135.85,y:162.05},0).wait(1).to({scaleX:0.6874,scaleY:0.6874,x:139.15,y:161.4},0).wait(1).to({scaleX:0.6747,scaleY:0.6747,x:142.3,y:160.7},0).wait(1).to({scaleX:0.6623,scaleY:0.6623,x:145.4,y:160.1},0).wait(1).to({scaleX:0.6503,scaleY:0.6503,x:148.4,y:159.5},0).wait(1).to({scaleX:0.6387,scaleY:0.6387,x:151.3,y:158.85},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:154.05,y:158.3},0).wait(1).to({scaleX:0.6168,scaleY:0.6168,x:156.75,y:157.7},0).wait(1).to({scaleX:0.6066,scaleY:0.6066,x:159.3,y:157.2},0).wait(1).to({scaleX:0.5968,scaleY:0.5968,x:161.75,y:156.7},0).wait(1).to({scaleX:0.5875,scaleY:0.5875,x:164.1,y:156.2},0).wait(1).to({scaleX:0.5787,scaleY:0.5787,x:166.25,y:155.75},0).wait(1).to({scaleX:0.5705,scaleY:0.5705,x:168.35,y:155.3},0).wait(1).to({scaleX:0.5627,scaleY:0.5627,x:170.25,y:154.9},0).wait(1).to({scaleX:0.5555,scaleY:0.5555,x:172.05,y:154.55},0).wait(1).to({scaleX:0.5488,scaleY:0.5488,x:173.75,y:154.2},0).wait(1).to({scaleX:0.5426,scaleY:0.5426,x:175.3,y:153.85},0).wait(1).to({scaleX:0.5369,scaleY:0.5369,x:176.7,y:153.6},0).wait(1).to({scaleX:0.5317,scaleY:0.5317,x:178,y:153.3},0).wait(1).to({scaleX:0.527,scaleY:0.527,x:179.2,y:153.1},0).wait(1).to({scaleX:0.5228,scaleY:0.5228,x:180.25,y:152.85},0).wait(1).to({scaleX:0.519,scaleY:0.519,x:181.2,y:152.65},0).wait(1).to({scaleX:0.5158,scaleY:0.5158,x:181.95,y:152.5},0).wait(1).to({scaleX:0.513,scaleY:0.513,x:182.7,y:152.35},0).wait(1).to({scaleX:0.5107,scaleY:0.5107,x:183.25,y:152.25},0).wait(1).to({scaleX:0.5088,scaleY:0.5088,x:183.7,y:152.15},0).wait(1).to({scaleX:0.5074,scaleY:0.5074,x:184.1,y:152.05},0).wait(1).to({scaleX:0.5063,scaleY:0.5063,x:184.35,y:152},0).wait(1).to({scaleX:0.5057,scaleY:0.5057,x:184.5,y:151.95},0).wait(1).to({regX:25.3,regY:21.6,scaleX:0.5055,scaleY:0.5055,y:151.9},0).wait(1).to({regX:25.5,regY:21.5,x:184.6,y:151.85},0).wait(16).to({regX:25.3,regY:21.6,x:184.5,y:151.9},0).wait(1).to({regX:25.5,regY:21.5,x:184.6,y:151.8},0).wait(1).to({scaleX:0.5054,scaleY:0.5054,y:151.75},0).wait(1).to({scaleX:0.5053,scaleY:0.5053,y:151.65},0).wait(1).to({scaleX:0.5051,scaleY:0.5051,y:151.55},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:184.65,y:151.4},0).wait(1).to({scaleX:0.5047,scaleY:0.5047,x:184.6,y:151.25},0).wait(1).to({scaleX:0.5044,scaleY:0.5044,x:184.65,y:151.05},0).wait(1).to({scaleX:0.504,scaleY:0.504,y:150.8},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:184.7,y:150.55},0).wait(1).to({scaleX:0.5031,scaleY:0.5031,x:184.75,y:150.15},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,y:149.8},0).wait(1).to({scaleX:0.5019,scaleY:0.5019,x:184.8,y:149.35},0).wait(1).to({scaleX:0.5012,scaleY:0.5012,x:184.9,y:148.85},0).wait(1).to({scaleX:0.5003,scaleY:0.5003,x:184.95,y:148.2},0).wait(1).to({scaleX:0.4994,scaleY:0.4994,x:185,y:147.55},0).wait(1).to({scaleX:0.4983,scaleY:0.4983,x:185.1,y:146.75},0).wait(1).to({scaleX:0.497,scaleY:0.497,x:185.15,y:145.9},0).wait(1).to({scaleX:0.4955,scaleY:0.4955,x:185.3,y:144.8},0).wait(1).to({scaleX:0.4937,scaleY:0.4937,x:185.4,y:143.6},0).wait(1).to({scaleX:0.4917,scaleY:0.4917,x:185.55,y:142.15},0).wait(1).to({scaleX:0.4892,scaleY:0.4892,x:185.7,y:140.45},0).wait(1).to({scaleX:0.4862,scaleY:0.4862,x:185.95,y:138.35},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:186.2,y:135.75},0).wait(1).to({scaleX:0.4779,scaleY:0.4779,x:186.55,y:132.55},0).wait(1).to({scaleX:0.472,scaleY:0.472,x:186.95,y:128.45},0).wait(1).to({scaleX:0.4649,scaleY:0.4649,x:187.45,y:123.45},0).wait(1).to({scaleX:0.4575,scaleY:0.4575,x:188,y:118.3},0).wait(1).to({scaleX:0.451,scaleY:0.451,x:188.45,y:113.75},0).wait(1).to({scaleX:0.4458,scaleY:0.4458,x:188.8,y:110.1},0).wait(1).to({scaleX:0.4416,scaleY:0.4416,x:189.1,y:107.2},0).wait(1).to({scaleX:0.4383,scaleY:0.4383,x:189.4,y:104.85},0).wait(1).to({scaleX:0.4355,scaleY:0.4355,x:189.55,y:102.95},0).wait(1).to({scaleX:0.4332,scaleY:0.4332,x:189.75,y:101.3},0).wait(1).to({scaleX:0.4312,scaleY:0.4312,x:189.85,y:99.95},0).wait(1).to({scaleX:0.4295,scaleY:0.4295,x:190,y:98.8},0).wait(1).to({scaleX:0.4281,scaleY:0.4281,x:190.1,y:97.75},0).wait(1).to({scaleX:0.4268,scaleY:0.4268,x:190.2,y:96.85},0).wait(1).to({scaleX:0.4257,scaleY:0.4257,x:190.25,y:96.05},0).wait(1).to({scaleX:0.4247,scaleY:0.4247,x:190.35,y:95.4},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:190.4,y:94.75},0).wait(1).to({scaleX:0.423,scaleY:0.423,x:190.45,y:94.25},0).wait(1).to({scaleX:0.4223,scaleY:0.4223,x:190.5,y:93.75},0).wait(1).to({scaleX:0.4217,scaleY:0.4217,x:190.55,y:93.3},0).wait(1).to({scaleX:0.4212,scaleY:0.4212,x:190.6,y:92.95},0).wait(1).to({scaleX:0.4207,scaleY:0.4207,x:190.65,y:92.65},0).wait(1).to({scaleX:0.4203,scaleY:0.4203,y:92.35},0).wait(1).to({scaleX:0.42,scaleY:0.42,y:92.15},0).wait(1).to({scaleX:0.4197,scaleY:0.4197,x:190.7,y:91.9},0).wait(1).to({scaleX:0.4194,scaleY:0.4194,y:91.7},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:190.75,y:91.55},0).wait(1).to({scaleX:0.4191,scaleY:0.4191,y:91.45},0).wait(1).to({scaleX:0.4189,scaleY:0.4189,y:91.35},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,x:190.8,y:91.3},0).wait(1).to({scaleX:0.4187,scaleY:0.4187,y:91.25},0).wait(1).to({y:91.2},0).wait(1).to({regX:25.4,regY:21.6,x:190.7,y:91.25},0).wait(2));

	// guy right contribution
	this.instance_4 = new lib.guyrightcontribution_1();
	this.instance_4.setTransform(264.05,-17.4,1,1,0,0,0,38.1,26.2);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(19).to({_off:false},0).to({scaleX:1.037,scaleY:1.037,x:246.45,y:64.7,alpha:1},50,cjs.Ease.quadOut).wait(1).to({regX:37.7,regY:26,x:246.05,y:64.5},0).wait(11).to({regX:38.1,regY:26.2,x:246.45,y:64.7},0).wait(1).to({regX:37.7,regY:26,scaleX:1.0329,scaleY:1.0324,x:245.8,y:65},0).wait(1).to({scaleX:1.0285,scaleY:1.0273,skewY:-0.0571,x:245.55,y:65.5},0).wait(1).to({scaleX:1.0236,scaleY:1.0219,skewY:-0.0894,x:245.35,y:66.1},0).wait(1).to({scaleX:1.0184,scaleY:1.0159,skewY:-0.1243,x:245.1,y:66.7},0).wait(1).to({scaleX:1.0128,scaleY:1.0096,skewY:-0.1617,x:244.8,y:67.4},0).wait(1).to({scaleX:1.0068,scaleY:1.0028,skewY:-0.2017,x:244.5,y:68.05},0).wait(1).to({scaleX:1.0004,scaleY:0.9956,skewY:-0.2443,x:244.15,y:68.9},0).wait(1).to({scaleX:0.9937,scaleY:0.9879,skewY:-0.2893,x:243.8,y:69.65},0).wait(1).to({scaleX:0.9865,scaleY:0.9798,skewY:-0.3369,x:243.5,y:70.55},0).wait(1).to({scaleX:0.979,scaleY:0.9713,skewY:-0.3869,x:243.1,y:71.4},0).wait(1).to({scaleX:0.9712,scaleY:0.9624,skewY:-0.4394,x:242.7,y:72.3},0).wait(1).to({scaleX:0.963,scaleY:0.9531,skewY:-0.4941,x:242.3,y:73.35},0).wait(1).to({scaleX:0.9544,scaleY:0.9435,skewY:-0.5511,x:241.85,y:74.35},0).wait(1).to({scaleX:0.9456,scaleY:0.9334,skewY:-0.6102,x:241.4,y:75.4},0).wait(1).to({scaleX:0.9364,scaleY:0.9231,skewY:-0.6714,x:240.95,y:76.5},0).wait(1).to({scaleX:0.9269,scaleY:0.9124,skewY:-0.7343,x:240.45,y:77.6},0).wait(1).to({scaleX:0.9172,scaleY:0.9014,skewY:-0.799,x:240,y:78.8},0).wait(1).to({scaleX:0.9073,scaleY:0.8901,skewY:-0.8652,x:239.45,y:80},0).wait(1).to({scaleX:0.8972,scaleY:0.8787,skewY:-0.9328,x:238.95,y:81.2},0).wait(1).to({scaleX:0.8869,scaleY:0.867,skewY:-1.0015,x:238.45,y:82.4},0).wait(1).to({scaleX:0.8765,scaleY:0.8552,skewY:-1.071,x:237.9,y:83.7},0).wait(1).to({scaleX:0.8659,scaleY:0.8433,skewY:-1.1413,x:237.4,y:84.9},0).wait(1).to({scaleX:0.8553,scaleY:0.8313,skewY:-1.212,x:236.85,y:86.15},0).wait(1).to({scaleX:0.8447,scaleY:0.8192,skewY:-1.2829,x:236.3,y:87.45},0).wait(1).to({scaleX:0.8341,scaleY:0.8072,skewY:-1.3537,x:235.8,y:88.75},0).wait(1).to({scaleX:0.8235,scaleY:0.7952,skewY:-1.4243,x:235.25,y:90.05},0).wait(1).to({scaleX:0.813,scaleY:0.7834,skewY:-1.4942,x:234.7,y:91.25},0).wait(1).to({scaleX:0.8026,scaleY:0.7716,skewY:-1.5635,x:234.2,y:92.45},0).wait(1).to({scaleX:0.7924,scaleY:0.76,skewY:-1.6317,x:233.65,y:93.7},0).wait(1).to({scaleX:0.7824,scaleY:0.7487,skewY:-1.6986,x:233.2,y:94.9},0).wait(1).to({scaleX:0.7725,scaleY:0.7375,skewY:-1.7642,x:232.65,y:96.1},0).wait(1).to({scaleX:0.7629,scaleY:0.7267,skewY:-1.8281,x:232.2,y:97.25},0).wait(1).to({scaleX:0.7536,scaleY:0.7161,skewY:-1.8903,x:231.7,y:98.3},0).wait(1).to({scaleX:0.7446,scaleY:0.7059,skewY:-1.9505,x:231.25,y:99.4},0).wait(1).to({scaleX:0.7359,scaleY:0.696,skewY:-2.0087,x:230.85,y:100.5},0).wait(1).to({scaleX:0.7275,scaleY:0.6865,skewY:-2.0646,x:230.4,y:101.45},0).wait(1).to({scaleX:0.7194,scaleY:0.6774,skewY:-2.1183,x:230,y:102.4},0).wait(1).to({scaleX:0.7117,scaleY:0.6687,skewY:-2.1696,x:229.6,y:103.35},0).wait(1).to({scaleX:0.7044,scaleY:0.6604,skewY:-2.2185,x:229.25,y:104.15},0).wait(1).to({scaleX:0.6975,scaleY:0.6525,skewY:-2.2648,x:228.85,y:105},0).wait(1).to({scaleX:0.6909,scaleY:0.6451,skewY:-2.3087,x:228.55,y:105.8},0).wait(1).to({scaleX:0.6847,scaleY:0.6381,skewY:-2.35,x:228.25,y:106.6},0).wait(1).to({scaleX:0.6789,scaleY:0.6315,skewY:-2.3886,x:227.9,y:107.25},0).wait(1).to({scaleX:0.6735,scaleY:0.6254,skewY:-2.4248,x:227.65,y:107.9},0).wait(1).to({scaleX:0.6685,scaleY:0.6197,skewY:-2.4583,x:227.45,y:108.45},0).wait(1).to({scaleX:0.6638,scaleY:0.6144,skewY:-2.4893,x:227.15,y:109},0).wait(1).to({scaleX:0.6595,scaleY:0.6096,skewY:-2.5178,x:226.95,y:109.55},0).wait(1).to({scaleX:0.6557,scaleY:0.6052,skewY:-2.5437,x:226.75,y:110.05},0).wait(1).to({scaleX:0.6521,scaleY:0.6012,skewY:-2.5671,x:226.55,y:110.45},0).wait(1).to({scaleX:0.649,scaleY:0.5976,skewY:-2.5881,x:226.45,y:110.85},0).wait(1).to({scaleX:0.6462,scaleY:0.5945,skewY:-2.6067,x:226.3,y:111.15},0).wait(1).to({scaleX:0.6438,scaleY:0.5917,skewY:-2.623,x:226.15,y:111.5},0).wait(1).to({scaleX:0.6417,scaleY:0.5894,skewY:-2.6369,x:226.05,y:111.7},0).wait(1).to({scaleX:0.6399,scaleY:0.5874,skewY:-2.6485,x:225.95,y:111.9},0).wait(1).to({scaleX:0.6385,scaleY:0.5858,skewY:-2.658,x:225.9,y:112.1},0).wait(1).to({scaleX:0.6374,scaleY:0.5846,skewY:-2.6652,x:225.85,y:112.25},0).wait(1).to({scaleX:0.6367,scaleY:0.5837,skewY:-2.6703,x:225.8,y:112.35},0).wait(1).to({scaleX:0.6362,scaleY:0.5832,skewY:-2.6733,x:225.75},0).wait(1).to({regX:38.4,regY:26.4,scaleX:0.6361,scaleY:0.583,skewY:-2.6743,x:226.05,y:112.5},0).wait(79));

	// guy left contribution
	this.instance_5 = new lib.guyleftcontribution_1();
	this.instance_5.setTransform(-36.35,126.65,1,1,0,0,0,30.4,9.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(25).to({_off:false},0).to({x:120.9,y:85.35,alpha:1},45,cjs.Ease.quadOut).wait(1).to({regX:30.5,regY:9.7,x:121,y:85.25},0).wait(12).to({regX:30.4,regY:9.8,x:120.9,y:85.35},0).wait(1).to({regX:30.5,regY:9.7,scaleX:0.9947,scaleY:0.9948,skewX:-0.08,skewY:-0.0135,x:121.75,y:85.8},0).wait(1).to({scaleX:0.989,scaleY:0.9891,skewX:-0.1674,skewY:-0.0283,x:122.65,y:86.45},0).wait(1).to({scaleX:0.9827,scaleY:0.9829,skewX:-0.2621,skewY:-0.0444,x:123.55,y:87.15},0).wait(1).to({scaleX:0.976,scaleY:0.9763,skewX:-0.3644,skewY:-0.0616,x:124.5,y:87.8},0).wait(1).to({scaleX:0.9687,scaleY:0.9691,skewX:-0.4741,skewY:-0.0802,x:125.65,y:88.65},0).wait(1).to({scaleX:0.961,scaleY:0.9615,skewX:-0.5913,skewY:-0.1,x:126.75,y:89.55},0).wait(1).to({scaleX:0.9528,scaleY:0.9533,skewX:-0.716,skewY:-0.1211,x:127.95,y:90.4},0).wait(1).to({scaleX:0.944,scaleY:0.9447,skewX:-0.8482,skewY:-0.1435,x:129.3,y:91.35},0).wait(1).to({scaleX:0.9348,scaleY:0.9356,skewX:-0.9876,skewY:-0.1671,x:130.65,y:92.35},0).wait(1).to({scaleX:0.9252,scaleY:0.926,skewX:-1.1343,skewY:-0.1919,x:132.1,y:93.45},0).wait(1).to({scaleX:0.915,scaleY:0.916,skewX:-1.2879,skewY:-0.2179,x:133.6,y:94.55},0).wait(1).to({scaleX:0.9044,scaleY:0.9055,skewX:-1.4484,skewY:-0.2451,x:135.2,y:95.75},0).wait(1).to({scaleX:0.8934,scaleY:0.8946,skewX:-1.6155,skewY:-0.2733,x:136.85,y:96.85},0).wait(1).to({scaleX:0.882,scaleY:0.8833,skewX:-1.7888,skewY:-0.3026,x:138.5,y:98.15},0).wait(1).to({scaleX:0.8701,scaleY:0.8716,skewX:-1.9679,skewY:-0.333,x:140.3,y:99.45},0).wait(1).to({scaleX:0.858,scaleY:0.8596,skewX:-2.1526,skewY:-0.3642,x:142.05,y:100.85},0).wait(1).to({scaleX:0.8454,scaleY:0.8472,skewX:-2.3422,skewY:-0.3963,x:144,y:102.15},0).wait(1).to({scaleX:0.8326,scaleY:0.8345,skewX:-2.5363,skewY:-0.4291,x:145.85,y:103.6},0).wait(1).to({scaleX:0.8196,scaleY:0.8216,skewX:-2.7343,skewY:-0.4626,x:147.8,y:105},0).wait(1).to({scaleX:0.8063,scaleY:0.8085,skewX:-2.9356,skewY:-0.4967,x:149.8,y:106.5},0).wait(1).to({scaleX:0.7928,scaleY:0.7952,skewX:-3.1395,skewY:-0.5312,x:151.75,y:107.95},0).wait(1).to({scaleX:0.7792,scaleY:0.7818,skewX:-3.3455,skewY:-0.566,x:153.8,y:109.4},0).wait(1).to({scaleX:0.7655,scaleY:0.7682,skewX:-3.5527,skewY:-0.6011,x:155.8,y:110.95},0).wait(1).to({scaleX:0.7518,scaleY:0.7547,skewX:-3.7605,skewY:-0.6362,x:157.9,y:112.45},0).wait(1).to({scaleX:0.7381,scaleY:0.7411,skewX:-3.9682,skewY:-0.6714,x:159.9,y:113.95},0).wait(1).to({scaleX:0.7245,scaleY:0.7276,skewX:-4.1749,skewY:-0.7063,x:161.9,y:115.45},0).wait(1).to({scaleX:0.7109,scaleY:0.7142,skewX:-4.3801,skewY:-0.7411,x:164,y:116.9},0).wait(1).to({scaleX:0.6975,scaleY:0.701,skewX:-4.583,skewY:-0.7754,x:165.9,y:118.4},0).wait(1).to({scaleX:0.6843,scaleY:0.688,skewX:-4.7829,skewY:-0.8092,x:167.85,y:119.85},0).wait(1).to({scaleX:0.6713,scaleY:0.6752,skewX:-4.9793,skewY:-0.8424,x:169.8,y:121.25},0).wait(1).to({scaleX:0.6587,scaleY:0.6626,skewX:-5.1714,skewY:-0.8749,x:171.75,y:122.65},0).wait(1).to({scaleX:0.6463,scaleY:0.6504,skewX:-5.3589,skewY:-0.9067,x:173.55,y:124.05},0).wait(1).to({scaleX:0.6343,scaleY:0.6385,skewX:-5.5411,skewY:-0.9375,x:175.35,y:125.3},0).wait(1).to({scaleX:0.6226,scaleY:0.627,skewX:-5.7176,skewY:-0.9674,x:177.05,y:126.6},0).wait(1).to({scaleX:0.6114,scaleY:0.6159,skewX:-5.8881,skewY:-0.9962,x:178.75,y:127.85},0).wait(1).to({scaleX:0.6005,scaleY:0.6052,skewX:-6.0521,skewY:-1.024,x:180.3,y:129},0).wait(1).to({scaleX:0.5902,scaleY:0.5949,skewX:-6.2095,skewY:-1.0506,x:181.85,y:130.15},0).wait(1).to({scaleX:0.5802,scaleY:0.5851,skewX:-6.3598,skewY:-1.076,x:183.4,y:131.25},0).wait(1).to({scaleX:0.5708,scaleY:0.5757,skewX:-6.5031,skewY:-1.1002,x:184.8,y:132.25},0).wait(1).to({scaleX:0.5618,scaleY:0.5669,skewX:-6.639,skewY:-1.1232,x:186.15,y:133.25},0).wait(1).to({scaleX:0.5533,scaleY:0.5585,skewX:-6.7675,skewY:-1.145,x:187.35,y:134.2},0).wait(1).to({scaleX:0.5453,scaleY:0.5506,skewX:-6.8884,skewY:-1.1654,x:188.6,y:135.05},0).wait(1).to({scaleX:0.5378,scaleY:0.5432,skewX:-7.0019,skewY:-1.1846,x:189.65,y:135.9},0).wait(1).to({scaleX:0.5309,scaleY:0.5363,skewX:-7.1078,skewY:-1.2026,x:190.7,y:136.65},0).wait(1).to({scaleX:0.5244,scaleY:0.5299,skewX:-7.2061,skewY:-1.2192,x:191.7,y:137.35},0).wait(1).to({scaleX:0.5184,scaleY:0.5239,skewX:-7.2969,skewY:-1.2346,x:192.55,y:138},0).wait(1).to({scaleX:0.5129,scaleY:0.5185,skewX:-7.3803,skewY:-1.2487,x:193.4,y:138.65},0).wait(1).to({scaleX:0.5078,scaleY:0.5135,skewX:-7.4563,skewY:-1.2615,x:194.15,y:139.2},0).wait(1).to({scaleX:0.5033,scaleY:0.5091,skewX:-7.5251,skewY:-1.2732,x:194.8,y:139.65},0).wait(1).to({scaleX:0.4993,scaleY:0.505,skewX:-7.5867,skewY:-1.2836,x:195.4,y:140.1},0).wait(1).to({scaleX:0.4956,scaleY:0.5015,skewX:-7.6412,skewY:-1.2928,x:195.9,y:140.5},0).wait(1).to({scaleX:0.4925,scaleY:0.4984,skewX:-7.6888,skewY:-1.3009,x:196.4,y:140.85},0).wait(1).to({scaleX:0.4898,scaleY:0.4957,skewX:-7.7296,skewY:-1.3078,x:196.8,y:141.15},0).wait(1).to({scaleX:0.4876,scaleY:0.4935,skewX:-7.7637,skewY:-1.3135,x:197.1,y:141.4},0).wait(1).to({scaleX:0.4857,scaleY:0.4917,skewX:-7.7913,skewY:-1.3182,x:197.4,y:141.6},0).wait(1).to({scaleX:0.4843,scaleY:0.4903,skewX:-7.8125,skewY:-1.3218,x:197.6,y:141.75},0).wait(1).to({scaleX:0.4834,scaleY:0.4893,skewX:-7.8275,skewY:-1.3243,x:197.8,y:141.85},0).wait(1).to({scaleX:0.4828,scaleY:0.4887,skewX:-7.8364,skewY:-1.3258,x:197.85,y:141.9},0).wait(1).to({regX:30.8,regY:10.1,scaleX:0.4826,scaleY:0.4885,skewX:-7.8393,skewY:-1.3263,y:142},0).wait(77));

	// girl left contribution
	this.instance_6 = new lib.girlleftcontribution_1();
	this.instance_6.setTransform(-47.7,231.85,1,1,0,0,0,44,32.3);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(9).to({_off:false},0).to({scaleX:1.0222,scaleY:1.0222,x:104.7,y:190.7,alpha:1},57,cjs.Ease.quadOut).wait(1).to({regX:44.2,regY:32.5,x:104.9,y:190.9},0).wait(18).to({regX:44,regY:32.3,x:104.7,y:190.7},0).wait(1).to({regX:44.2,regY:32.5,scaleX:1.0159,scaleY:1.0159,x:105.9,y:190.55},0).wait(1).to({scaleX:1.0089,scaleY:1.0089,x:107.05,y:190.25},0).wait(1).to({scaleX:1.0014,scaleY:1.0014,x:108.3,y:189.85},0).wait(1).to({scaleX:0.9933,scaleY:0.9933,x:109.65,y:189.45},0).wait(1).to({scaleX:0.9846,scaleY:0.9846,x:111.05,y:188.95},0).wait(1).to({scaleX:0.9754,scaleY:0.9754,x:112.6,y:188.5},0).wait(1).to({scaleX:0.9655,scaleY:0.9655,x:114.2,y:188},0).wait(1).to({scaleX:0.955,scaleY:0.955,x:115.95,y:187.45},0).wait(1).to({scaleX:0.944,scaleY:0.944,x:117.8,y:186.9},0).wait(1).to({scaleX:0.9324,scaleY:0.9324,x:119.7,y:186.3},0).wait(1).to({scaleX:0.9202,scaleY:0.9202,x:121.75,y:185.65},0).wait(1).to({scaleX:0.9075,scaleY:0.9075,x:123.85,y:185.05},0).wait(1).to({scaleX:0.8942,scaleY:0.8942,x:126,y:184.35},0).wait(1).to({scaleX:0.8805,scaleY:0.8805,x:128.3,y:183.6},0).wait(1).to({scaleX:0.8663,scaleY:0.8663,x:130.65,y:182.9},0).wait(1).to({scaleX:0.8517,scaleY:0.8517,x:133.1,y:182.2},0).wait(1).to({scaleX:0.8367,scaleY:0.8367,x:135.6,y:181.4},0).wait(1).to({scaleX:0.8213,scaleY:0.8213,x:138.1,y:180.6},0).wait(1).to({scaleX:0.8056,scaleY:0.8056,x:140.7,y:179.8},0).wait(1).to({scaleX:0.7897,scaleY:0.7897,x:143.35,y:178.95},0).wait(1).to({scaleX:0.7735,scaleY:0.7735,x:146.05,y:178.15},0).wait(1).to({scaleX:0.7572,scaleY:0.7572,x:148.7,y:177.3},0).wait(1).to({scaleX:0.7408,scaleY:0.7408,x:151.45,y:176.5},0).wait(1).to({scaleX:0.7243,scaleY:0.7243,x:154.15,y:175.65},0).wait(1).to({scaleX:0.7079,scaleY:0.7079,x:156.9,y:174.8},0).wait(1).to({scaleX:0.6915,scaleY:0.6915,x:159.6,y:173.95},0).wait(1).to({scaleX:0.6753,scaleY:0.6753,x:162.3,y:173.15},0).wait(1).to({scaleX:0.6592,scaleY:0.6592,x:165,y:172.3},0).wait(1).to({scaleX:0.6433,scaleY:0.6433,x:167.6,y:171.5},0).wait(1).to({scaleX:0.6278,scaleY:0.6278,x:170.15,y:170.7},0).wait(1).to({scaleX:0.6126,scaleY:0.6126,x:172.7,y:169.9},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:175.1,y:169.2},0).wait(1).to({scaleX:0.5833,scaleY:0.5833,x:177.55,y:168.4},0).wait(1).to({scaleX:0.5693,scaleY:0.5693,x:179.85,y:167.7},0).wait(1).to({scaleX:0.5558,scaleY:0.5558,x:182.05,y:167},0).wait(1).to({scaleX:0.5428,scaleY:0.5428,x:184.25,y:166.35},0).wait(1).to({scaleX:0.5303,scaleY:0.5303,x:186.3,y:165.7},0).wait(1).to({scaleX:0.5184,scaleY:0.5184,x:188.25,y:165.1},0).wait(1).to({scaleX:0.5071,scaleY:0.5071,x:190.15,y:164.55},0).wait(1).to({scaleX:0.4963,scaleY:0.4963,x:191.95,y:164},0).wait(1).to({scaleX:0.4861,scaleY:0.4861,x:193.65,y:163.45},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:195.2,y:162.95},0).wait(1).to({scaleX:0.4676,scaleY:0.4676,x:196.65,y:162.5},0).wait(1).to({scaleX:0.4592,scaleY:0.4592,x:198.1,y:162.05},0).wait(1).to({scaleX:0.4514,scaleY:0.4514,x:199.35,y:161.65},0).wait(1).to({scaleX:0.4442,scaleY:0.4442,x:200.55,y:161.3},0).wait(1).to({scaleX:0.4376,scaleY:0.4376,x:201.65,y:160.95},0).wait(1).to({scaleX:0.4316,scaleY:0.4316,x:202.65,y:160.65},0).wait(1).to({scaleX:0.4261,scaleY:0.4261,x:203.55,y:160.35},0).wait(1).to({scaleX:0.4213,scaleY:0.4213,x:204.35,y:160.15},0).wait(1).to({scaleX:0.4169,scaleY:0.4169,x:205.1,y:159.9},0).wait(1).to({scaleX:0.4132,scaleY:0.4132,x:205.7,y:159.75},0).wait(1).to({scaleX:0.4099,scaleY:0.4099,x:206.2,y:159.5},0).wait(1).to({scaleX:0.4072,scaleY:0.4072,x:206.7,y:159.4},0).wait(1).to({scaleX:0.405,scaleY:0.405,x:207.05,y:159.3},0).wait(1).to({scaleX:0.4034,scaleY:0.4034,x:207.35,y:159.2},0).wait(1).to({scaleX:0.4022,scaleY:0.4022,x:207.55,y:159.1},0).wait(1).to({scaleX:0.4015,scaleY:0.4015,x:207.65},0).wait(1).to({regX:44.4,regY:32.8,scaleX:0.4012,scaleY:0.4012,x:207.6,y:159.05},0).wait(75));

	// girl rigth contribution
	this.instance_7 = new lib.girlrigthcontribution();
	this.instance_7.setTransform(276.95,303.5,1,1,0,0,0,39.1,19.1);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(14).to({_off:false},0).to({scaleX:1.0251,scaleY:1.0251,x:236.3,y:238.7,alpha:1},54,cjs.Ease.quadOut).wait(1).to({regX:39,regY:19,x:236.2,y:238.6},0).wait(16).to({regX:39.1,regY:19.1,x:236.3,y:238.7},0).wait(1).to({regX:39,regY:19,scaleX:1.0192,scaleY:1.0192,x:235.95,y:237.9},0).wait(1).to({scaleX:1.0127,scaleY:1.0127,x:235.75,y:237.25},0).wait(1).to({scaleX:1.0057,scaleY:1.0057,x:235.45,y:236.5},0).wait(1).to({scaleX:0.9981,scaleY:0.9981,x:235.25,y:235.7},0).wait(1).to({scaleX:0.99,scaleY:0.99,x:234.95,y:234.85},0).wait(1).to({scaleX:0.9813,scaleY:0.9813,x:234.65,y:233.95},0).wait(1).to({scaleX:0.9721,scaleY:0.9721,x:234.35,y:232.95},0).wait(1).to({scaleX:0.9623,scaleY:0.9623,x:234.05,y:231.95},0).wait(1).to({scaleX:0.952,scaleY:0.952,x:233.7,y:230.85},0).wait(1).to({scaleX:0.9412,scaleY:0.9412,x:233.3,y:229.7},0).wait(1).to({scaleX:0.9298,scaleY:0.9298,x:232.9,y:228.45},0).wait(1).to({scaleX:0.918,scaleY:0.918,x:232.5,y:227.25},0).wait(1).to({scaleX:0.9057,scaleY:0.9057,x:232.1,y:225.9},0).wait(1).to({scaleX:0.8929,scaleY:0.8929,x:231.65,y:224.55},0).wait(1).to({scaleX:0.8797,scaleY:0.8797,x:231.2,y:223.15},0).wait(1).to({scaleX:0.866,scaleY:0.866,x:230.75,y:221.75},0).wait(1).to({scaleX:0.852,scaleY:0.852,x:230.3,y:220.25},0).wait(1).to({scaleX:0.8377,scaleY:0.8377,x:229.75,y:218.75},0).wait(1).to({scaleX:0.823,scaleY:0.823,x:229.3,y:217.2},0).wait(1).to({scaleX:0.8081,scaleY:0.8081,x:228.75,y:215.6},0).wait(1).to({scaleX:0.793,scaleY:0.793,x:228.3,y:214},0).wait(1).to({scaleX:0.7777,scaleY:0.7777,x:227.75,y:212.45},0).wait(1).to({scaleX:0.7623,scaleY:0.7623,x:227.25,y:210.8},0).wait(1).to({scaleX:0.7469,scaleY:0.7469,x:226.75,y:209.15},0).wait(1).to({scaleX:0.7314,scaleY:0.7314,x:226.15,y:207.5},0).wait(1).to({scaleX:0.716,scaleY:0.716,x:225.65,y:205.9},0).wait(1).to({scaleX:0.7007,scaleY:0.7007,x:225.15,y:204.25},0).wait(1).to({scaleX:0.6855,scaleY:0.6855,x:224.65,y:202.65},0).wait(1).to({scaleX:0.6705,scaleY:0.6705,x:224.1,y:201.1},0).wait(1).to({scaleX:0.6558,scaleY:0.6558,x:223.6,y:199.5},0).wait(1).to({scaleX:0.6413,scaleY:0.6413,x:223.1,y:198},0).wait(1).to({scaleX:0.6272,scaleY:0.6272,x:222.65,y:196.5},0).wait(1).to({scaleX:0.6134,scaleY:0.6134,x:222.15,y:195.05},0).wait(1).to({scaleX:0.6,scaleY:0.6,x:221.7,y:193.65},0).wait(1).to({scaleX:0.5871,scaleY:0.5871,x:221.3,y:192.25},0).wait(1).to({scaleX:0.5746,scaleY:0.5746,x:220.85,y:190.95},0).wait(1).to({scaleX:0.5626,scaleY:0.5626,x:220.45,y:189.7},0).wait(1).to({scaleX:0.551,scaleY:0.551,x:220.05,y:188.45},0).wait(1).to({scaleX:0.54,scaleY:0.54,x:219.65,y:187.3},0).wait(1).to({scaleX:0.5296,scaleY:0.5296,x:219.3,y:186.2},0).wait(1).to({scaleX:0.5196,scaleY:0.5196,x:218.95,y:185.1},0).wait(1).to({scaleX:0.5102,scaleY:0.5102,x:218.65,y:184.15},0).wait(1).to({scaleX:0.5014,scaleY:0.5014,x:218.35,y:183.25},0).wait(1).to({scaleX:0.4931,scaleY:0.4931,x:218.1,y:182.35},0).wait(1).to({scaleX:0.4854,scaleY:0.4854,x:217.85,y:181.5},0).wait(1).to({scaleX:0.4782,scaleY:0.4782,x:217.6,y:180.8},0).wait(1).to({scaleX:0.4716,scaleY:0.4716,x:217.35,y:180.05},0).wait(1).to({scaleX:0.4655,scaleY:0.4655,x:217.15,y:179.45},0).wait(1).to({scaleX:0.4599,scaleY:0.4599,x:216.95,y:178.85},0).wait(1).to({scaleX:0.4549,scaleY:0.4549,x:216.8,y:178.3},0).wait(1).to({scaleX:0.4504,scaleY:0.4504,x:216.6,y:177.8},0).wait(1).to({scaleX:0.4464,scaleY:0.4464,x:216.5,y:177.45},0).wait(1).to({scaleX:0.4429,scaleY:0.4429,x:216.35,y:177.05},0).wait(1).to({scaleX:0.44,scaleY:0.44,x:216.25,y:176.7},0).wait(1).to({scaleX:0.4375,scaleY:0.4375,x:216.2,y:176.45},0).wait(1).to({scaleX:0.4355,scaleY:0.4355,x:216.15,y:176.25},0).wait(1).to({scaleX:0.4339,scaleY:0.4339,x:216.05,y:176.1},0).wait(1).to({scaleX:0.4328,scaleY:0.4328,y:175.95},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:216,y:175.9},0).wait(1).to({regX:39.3,regY:19.1,scaleX:0.4319,scaleY:0.4319,x:216.05,y:175.95},0).wait(74));

	// screen mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_9 = new cjs.Graphics().p("Azsi5QAcgLPTkuIPTkuIIWPiI+4Jfg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(9).to({graphics:mask_graphics_9,x:178.45,y:155.025}).wait(210));

	// r guy i shadow
	this.instance_8 = new lib.roundshadow();
	this.instance_8.setTransform(212.15,-11.85,1,1,0,0,0,28.2,22.8);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	var maskedShapeInstanceList = [this.instance_8];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(19).to({_off:false},0).to({scaleX:1.037,scaleY:1.037,x:197,y:75.85,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:196.8,y:75.55},0).wait(11).to({regX:28.2,regY:22.8,x:197,y:75.85},0).wait(1).to({regX:28,regY:22.5,scaleX:1.0333,scaleY:1.0333,x:196.85},0).wait(1).to({scaleX:1.0292,scaleY:1.0292,x:196.9,y:76.25},0).wait(1).to({scaleX:1.0248,scaleY:1.0248,x:197,y:76.65},0).wait(1).to({scaleX:1.02,scaleY:1.02,x:197.1,y:77.1},0).wait(1).to({scaleX:1.0149,scaleY:1.0149,x:197.2,y:77.6},0).wait(1).to({scaleX:1.0094,scaleY:1.0094,x:197.3,y:78.1},0).wait(1).to({scaleX:1.0036,scaleY:1.0036,x:197.45,y:78.65},0).wait(1).to({scaleX:0.9974,scaleY:0.9974,x:197.6,y:79.2},0).wait(1).to({scaleX:0.9909,scaleY:0.9909,x:197.7,y:79.85},0).wait(1).to({scaleX:0.9841,scaleY:0.9841,x:197.85,y:80.45},0).wait(1).to({scaleX:0.9769,scaleY:0.9769,x:197.95,y:81.15},0).wait(1).to({scaleX:0.9694,scaleY:0.9694,x:198.15,y:81.8},0).wait(1).to({scaleX:0.9616,scaleY:0.9616,x:198.3,y:82.6},0).wait(1).to({scaleX:0.9535,scaleY:0.9535,x:198.45,y:83.3},0).wait(1).to({scaleX:0.9452,scaleY:0.9452,x:198.6,y:84.1},0).wait(1).to({scaleX:0.9366,scaleY:0.9366,x:198.75,y:84.9},0).wait(1).to({scaleX:0.9277,scaleY:0.9277,x:199,y:85.7},0).wait(1).to({scaleX:0.9187,scaleY:0.9187,x:199.15,y:86.55},0).wait(1).to({scaleX:0.9094,scaleY:0.9094,x:199.35,y:87.45},0).wait(1).to({scaleX:0.9,scaleY:0.9,x:199.55,y:88.35},0).wait(1).to({scaleX:0.8905,scaleY:0.8905,x:199.75,y:89.25},0).wait(1).to({scaleX:0.8809,scaleY:0.8809,x:199.9,y:90.1},0).wait(1).to({scaleX:0.8712,scaleY:0.8712,x:200.1,y:91.05},0).wait(1).to({scaleX:0.8615,scaleY:0.8615,x:200.3,y:91.95},0).wait(1).to({scaleX:0.8518,scaleY:0.8518,x:200.5,y:92.85},0).wait(1).to({scaleX:0.8422,scaleY:0.8422,x:200.7,y:93.75},0).wait(1).to({scaleX:0.8326,scaleY:0.8326,x:200.9,y:94.65},0).wait(1).to({scaleX:0.8231,scaleY:0.8231,x:201.1,y:95.5},0).wait(1).to({scaleX:0.8138,scaleY:0.8138,x:201.3,y:96.4},0).wait(1).to({scaleX:0.8046,scaleY:0.8046,x:201.5,y:97.25},0).wait(1).to({scaleX:0.7957,scaleY:0.7957,x:201.65,y:98.1},0).wait(1).to({scaleX:0.7869,scaleY:0.7869,x:201.85,y:98.9},0).wait(1).to({scaleX:0.7784,scaleY:0.7784,x:202,y:99.7},0).wait(1).to({scaleX:0.7702,scaleY:0.7702,x:202.15,y:100.5},0).wait(1).to({scaleX:0.7622,scaleY:0.7622,x:202.3,y:101.25},0).wait(1).to({scaleX:0.7546,scaleY:0.7546,x:202.5,y:101.95},0).wait(1).to({scaleX:0.7472,scaleY:0.7472,x:202.6,y:102.65},0).wait(1).to({scaleX:0.7402,scaleY:0.7402,x:202.8,y:103.3},0).wait(1).to({scaleX:0.7335,scaleY:0.7335,x:202.9,y:103.9},0).wait(1).to({scaleX:0.7272,scaleY:0.7272,x:203,y:104.5},0).wait(1).to({scaleX:0.7212,scaleY:0.7212,x:203.15,y:105.1},0).wait(1).to({scaleX:0.7155,scaleY:0.7155,x:203.25,y:105.6},0).wait(1).to({scaleX:0.7102,scaleY:0.7102,x:203.4,y:106.1},0).wait(1).to({scaleX:0.7053,scaleY:0.7053,x:203.45,y:106.55},0).wait(1).to({scaleX:0.7007,scaleY:0.7007,x:203.55,y:107},0).wait(1).to({scaleX:0.6965,scaleY:0.6965,x:203.65,y:107.35},0).wait(1).to({scaleX:0.6926,scaleY:0.6926,x:203.75,y:107.75},0).wait(1).to({scaleX:0.689,scaleY:0.689,x:203.8,y:108.1},0).wait(1).to({scaleX:0.6858,scaleY:0.6858,x:203.85,y:108.4},0).wait(1).to({scaleX:0.6829,scaleY:0.6829,x:203.9,y:108.65},0).wait(1).to({scaleX:0.6804,scaleY:0.6804,x:203.95,y:108.9},0).wait(1).to({scaleX:0.6782,scaleY:0.6782,x:204,y:109.1},0).wait(1).to({scaleX:0.6763,scaleY:0.6763,x:204.05,y:109.25},0).wait(1).to({scaleX:0.6747,scaleY:0.6747,x:204.1,y:109.45},0).wait(1).to({scaleX:0.6734,scaleY:0.6734,y:109.55},0).wait(1).to({scaleX:0.6724,scaleY:0.6724,x:204.15,y:109.65},0).wait(1).to({scaleX:0.6717,scaleY:0.6717,y:109.7},0).wait(1).to({scaleX:0.6713,scaleY:0.6713,y:109.75},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.6711,scaleY:0.6711,x:204.3,y:109.9},0).wait(1).to({regX:28,regY:22.5,x:204.05,y:109.65},0).wait(15).to({regX:28.4,regY:22.9,x:204.3,y:109.9},0).wait(1).to({regX:28,regY:22.5,scaleX:0.671,scaleY:0.671,x:204.05,y:109.6},0).wait(1).to({scaleX:0.6708,scaleY:0.6708},0).wait(1).to({scaleX:0.6706,scaleY:0.6706},0).wait(1).to({scaleX:0.6702,scaleY:0.6702,y:109.55},0).wait(1).to({scaleX:0.6697,scaleY:0.6697,y:109.5},0).wait(1).to({scaleX:0.6691,scaleY:0.6691,x:204.1,y:109.45},0).wait(1).to({scaleX:0.6684,scaleY:0.6684,y:109.4},0).wait(1).to({scaleX:0.6676,scaleY:0.6676,x:204.15,y:109.3},0).wait(1).to({scaleX:0.6666,scaleY:0.6666,y:109.25},0).wait(1).to({scaleX:0.6655,scaleY:0.6655,x:204.2,y:109.1},0).wait(1).to({scaleX:0.6643,scaleY:0.6643,x:204.25,y:109.05},0).wait(1).to({scaleX:0.6628,scaleY:0.6628,y:108.9},0).wait(1).to({scaleX:0.6612,scaleY:0.6612,x:204.3,y:108.8},0).wait(1).to({scaleX:0.6593,scaleY:0.6593,x:204.4,y:108.6},0).wait(1).to({scaleX:0.6572,scaleY:0.6572,x:204.45,y:108.45},0).wait(1).to({scaleX:0.6548,scaleY:0.6548,x:204.55,y:108.2},0).wait(1).to({scaleX:0.6521,scaleY:0.6521,x:204.6,y:107.95},0).wait(1).to({scaleX:0.649,scaleY:0.649,x:204.7,y:107.7},0).wait(1).to({scaleX:0.6455,scaleY:0.6455,x:204.8,y:107.35},0).wait(1).to({scaleX:0.6414,scaleY:0.6414,x:204.95,y:107.05},0).wait(1).to({scaleX:0.6368,scaleY:0.6368,x:205.1,y:106.65},0).wait(1).to({scaleX:0.6315,scaleY:0.6315,x:205.3,y:106.15},0).wait(1).to({scaleX:0.6252,scaleY:0.6252,x:205.45,y:105.6},0).wait(1).to({scaleX:0.6177,scaleY:0.6177,x:205.7,y:105},0).wait(1).to({scaleX:0.6088,scaleY:0.6088,x:206,y:104.2},0).wait(1).to({scaleX:0.5978,scaleY:0.5978,x:206.35,y:103.25},0).wait(1).to({scaleX:0.5842,scaleY:0.5842,x:206.75,y:102.05},0).wait(1).to({scaleX:0.5675,scaleY:0.5675,x:207.3,y:100.6},0).wait(1).to({scaleX:0.5481,scaleY:0.5481,x:207.9,y:98.95},0).wait(1).to({scaleX:0.5286,scaleY:0.5286,x:208.55,y:97.25},0).wait(1).to({scaleX:0.5116,scaleY:0.5116,x:209.05,y:95.75},0).wait(1).to({scaleX:0.4976,scaleY:0.4976,x:209.5,y:94.55},0).wait(1).to({scaleX:0.4863,scaleY:0.4863,x:209.85,y:93.55},0).wait(1).to({scaleX:0.477,scaleY:0.477,x:210.15,y:92.75},0).wait(1).to({scaleX:0.4692,scaleY:0.4692,x:210.4,y:92.05},0).wait(1).to({scaleX:0.4626,scaleY:0.4626,x:210.6,y:91.5},0).wait(1).to({scaleX:0.457,scaleY:0.457,x:210.8,y:91},0).wait(1).to({scaleX:0.4521,scaleY:0.4521,x:210.95,y:90.55},0).wait(1).to({scaleX:0.4477,scaleY:0.4477,x:211.1,y:90.2},0).wait(1).to({scaleX:0.4439,scaleY:0.4439,x:211.25,y:89.9},0).wait(1).to({scaleX:0.4406,scaleY:0.4406,x:211.35,y:89.55},0).wait(1).to({scaleX:0.4376,scaleY:0.4376,x:211.4,y:89.3},0).wait(1).to({scaleX:0.4349,scaleY:0.4349,x:211.5,y:89.1},0).wait(1).to({scaleX:0.4326,scaleY:0.4326,x:211.55,y:88.9},0).wait(1).to({scaleX:0.4304,scaleY:0.4304,x:211.65,y:88.7},0).wait(1).to({scaleX:0.4285,scaleY:0.4285,x:211.7,y:88.55},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:211.75,y:88.4},0).wait(1).to({scaleX:0.4253,scaleY:0.4253,x:211.8,y:88.25},0).wait(1).to({scaleX:0.424,scaleY:0.424,y:88.15},0).wait(1).to({scaleX:0.4228,scaleY:0.4228,x:211.9,y:88},0).wait(1).to({scaleX:0.4218,scaleY:0.4218,y:87.95},0).wait(1).to({scaleX:0.4208,scaleY:0.4208,x:211.95,y:87.85},0).wait(1).to({scaleX:0.42,scaleY:0.42,y:87.8},0).wait(1).to({scaleX:0.4193,scaleY:0.4193,x:212,y:87.75},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,y:87.65},0).wait(1).to({scaleX:0.4183,scaleY:0.4183},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,x:212.05,y:87.6},0).wait(1).to({scaleX:0.4175,scaleY:0.4175},0).wait(1).to({scaleX:0.4173,scaleY:0.4173,y:87.55},0).wait(1).to({scaleX:0.4171,scaleY:0.4171,x:212.1},0).wait(1).to({scaleX:0.417,scaleY:0.417},0).wait(1).to({regX:28.3,regY:23,x:212.25,y:87.75},0).wait(1));

	// l guy i shadow
	this.instance_9 = new lib.roundshadow();
	this.instance_9.setTransform(-92.55,143.1,1,1,0,0,0,28.2,22.8);
	this.instance_9.alpha = 0;
	this.instance_9._off = true;

	var maskedShapeInstanceList = [this.instance_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(25).to({_off:false},0).to({x:66.65,y:95.05,alpha:0.1602},45,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:66.45,y:94.75},0).wait(12).to({regX:28.2,regY:22.8,x:66.65,y:95.05},0).wait(1).to({regX:28,regY:22.5,scaleX:0.995,scaleY:0.995,x:67.6,y:95.1},0).wait(1).to({scaleX:0.9894,scaleY:0.9894,x:68.9,y:95.5},0).wait(1).to({scaleX:0.9834,scaleY:0.9834,x:70.3,y:96},0).wait(1).to({scaleX:0.977,scaleY:0.977,x:71.8,y:96.45},0).wait(1).to({scaleX:0.97,scaleY:0.97,x:73.4,y:96.95},0).wait(1).to({scaleX:0.9626,scaleY:0.9626,x:75.15,y:97.5},0).wait(1).to({scaleX:0.9547,scaleY:0.9547,x:77,y:98.1},0).wait(1).to({scaleX:0.9464,scaleY:0.9464,x:78.95,y:98.7},0).wait(1).to({scaleX:0.9375,scaleY:0.9375,x:81,y:99.35},0).wait(1).to({scaleX:0.9283,scaleY:0.9283,x:83.2,y:100.05},0).wait(1).to({scaleX:0.9185,scaleY:0.9185,x:85.45,y:100.75},0).wait(1).to({scaleX:0.9084,scaleY:0.9084,x:87.85,y:101.55},0).wait(1).to({scaleX:0.8978,scaleY:0.8978,x:90.3,y:102.3},0).wait(1).to({scaleX:0.8869,scaleY:0.8869,x:92.9,y:103.1},0).wait(1).to({scaleX:0.8755,scaleY:0.8755,x:95.5,y:103.95},0).wait(1).to({scaleX:0.8639,scaleY:0.8639,x:98.25,y:104.85},0).wait(1).to({scaleX:0.8519,scaleY:0.8519,x:101.05,y:105.7},0).wait(1).to({scaleX:0.8396,scaleY:0.8396,x:103.9,y:106.65},0).wait(1).to({scaleX:0.8271,scaleY:0.8271,x:106.8,y:107.55},0).wait(1).to({scaleX:0.8143,scaleY:0.8143,x:109.8,y:108.45},0).wait(1).to({scaleX:0.8014,scaleY:0.8014,x:112.85,y:109.45},0).wait(1).to({scaleX:0.7884,scaleY:0.7884,x:115.85,y:110.45},0).wait(1).to({scaleX:0.7753,scaleY:0.7753,x:118.9,y:111.4},0).wait(1).to({scaleX:0.7621,scaleY:0.7621,x:122,y:112.35},0).wait(1).to({scaleX:0.749,scaleY:0.749,x:125.05,y:113.35},0).wait(1).to({scaleX:0.7359,scaleY:0.7359,x:128.1,y:114.3},0).wait(1).to({scaleX:0.723,scaleY:0.723,x:131.15,y:115.25},0).wait(1).to({scaleX:0.7101,scaleY:0.7101,x:134.15,y:116.25},0).wait(1).to({scaleX:0.6975,scaleY:0.6975,x:137.1,y:117.15},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:140,y:118.05},0).wait(1).to({scaleX:0.6729,scaleY:0.6729,x:142.85,y:119},0).wait(1).to({scaleX:0.661,scaleY:0.661,x:145.6,y:119.85},0).wait(1).to({scaleX:0.6495,scaleY:0.6495,x:148.3,y:120.7},0).wait(1).to({scaleX:0.6384,scaleY:0.6384,x:150.9,y:121.55},0).wait(1).to({scaleX:0.6276,scaleY:0.6276,x:153.4,y:122.3},0).wait(1).to({scaleX:0.6172,scaleY:0.6172,x:155.9,y:123.1},0).wait(1).to({scaleX:0.6072,scaleY:0.6072,x:158.2,y:123.85},0).wait(1).to({scaleX:0.5977,scaleY:0.5977,x:160.4,y:124.55},0).wait(1).to({scaleX:0.5887,scaleY:0.5887,x:162.55,y:125.25},0).wait(1).to({scaleX:0.5801,scaleY:0.5801,x:164.55,y:125.85},0).wait(1).to({scaleX:0.5719,scaleY:0.5719,x:166.4,y:126.45},0).wait(1).to({scaleX:0.5643,scaleY:0.5643,x:168.2,y:127.05},0).wait(1).to({scaleX:0.5571,scaleY:0.5571,x:169.9,y:127.6},0).wait(1).to({scaleX:0.5504,scaleY:0.5504,x:171.45,y:128.1},0).wait(1).to({scaleX:0.5442,scaleY:0.5442,x:172.9,y:128.55},0).wait(1).to({scaleX:0.5385,scaleY:0.5385,x:174.25,y:128.95},0).wait(1).to({scaleX:0.5332,scaleY:0.5332,x:175.5,y:129.35},0).wait(1).to({scaleX:0.5284,scaleY:0.5284,x:176.6,y:129.7},0).wait(1).to({scaleX:0.524,scaleY:0.524,x:177.6,y:130.05},0).wait(1).to({scaleX:0.5201,scaleY:0.5201,x:178.5,y:130.3},0).wait(1).to({scaleX:0.5167,scaleY:0.5167,x:179.3,y:130.6},0).wait(1).to({scaleX:0.5137,scaleY:0.5137,x:180.05,y:130.8},0).wait(1).to({scaleX:0.5111,scaleY:0.5111,x:180.65,y:131},0).wait(1).to({scaleX:0.5089,scaleY:0.5089,x:181.15,y:131.15},0).wait(1).to({scaleX:0.5072,scaleY:0.5072,x:181.55,y:131.25},0).wait(1).to({scaleX:0.5058,scaleY:0.5058,x:181.85,y:131.4},0).wait(1).to({scaleX:0.5049,scaleY:0.5049,x:182.1,y:131.45},0).wait(1).to({scaleX:0.5043,scaleY:0.5043,x:182.2,y:131.5},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.5042,scaleY:0.5042,x:182.4,y:131.65},0).wait(1).to({regX:28,regY:22.5,x:182.25,y:131.45},0).wait(15).to({regX:28.3,regY:22.9,x:182.4,y:131.65},0).wait(1).to({regX:28,regY:22.5,scaleX:0.5041,scaleY:0.5041,x:182.2,y:131.4},0).wait(1).to({scaleX:0.504,scaleY:0.504,x:182.15},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,x:182.1,y:131.35},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,x:182.05,y:131.3},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:181.95,y:131.25},0).wait(1).to({scaleX:0.5034,scaleY:0.5034,x:181.85,y:131.15},0).wait(1).to({scaleX:0.5032,scaleY:0.5032,x:181.7,y:131.05},0).wait(1).to({scaleX:0.5029,scaleY:0.5029,x:181.55,y:130.95},0).wait(1).to({scaleX:0.5026,scaleY:0.5026,x:181.3,y:130.8},0).wait(1).to({scaleX:0.5021,scaleY:0.5021,x:181.1,y:130.65},0).wait(1).to({scaleX:0.5017,scaleY:0.5017,x:180.8,y:130.5},0).wait(1).to({scaleX:0.5011,scaleY:0.5011,x:180.5,y:130.3},0).wait(1).to({scaleX:0.5005,scaleY:0.5005,x:180.1,y:130},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:179.7,y:129.75},0).wait(1).to({scaleX:0.4989,scaleY:0.4989,x:179.2,y:129.45},0).wait(1).to({scaleX:0.4979,scaleY:0.4979,x:178.65,y:129.05},0).wait(1).to({scaleX:0.4968,scaleY:0.4968,x:178,y:128.65},0).wait(1).to({scaleX:0.4954,scaleY:0.4954,x:177.2,y:128.1},0).wait(1).to({scaleX:0.4938,scaleY:0.4938,x:176.3,y:127.5},0).wait(1).to({scaleX:0.4918,scaleY:0.4918,x:175.15,y:126.75},0).wait(1).to({scaleX:0.4894,scaleY:0.4894,x:173.75,y:125.85},0).wait(1).to({scaleX:0.4864,scaleY:0.4864,x:172,y:124.7},0).wait(1).to({scaleX:0.4825,scaleY:0.4825,x:169.8,y:123.2},0).wait(1).to({scaleX:0.4776,scaleY:0.4776,x:166.95,y:121.35},0).wait(1).to({scaleX:0.4718,scaleY:0.4718,x:163.65,y:119.15},0).wait(1).to({scaleX:0.4664,scaleY:0.4664,x:160.5,y:117.1},0).wait(1).to({scaleX:0.4619,scaleY:0.4619,x:158,y:115.45},0).wait(1).to({scaleX:0.4584,scaleY:0.4584,x:156,y:114.1},0).wait(1).to({scaleX:0.4557,scaleY:0.4557,x:154.35,y:113.05},0).wait(1).to({scaleX:0.4534,scaleY:0.4534,x:153.1,y:112.2},0).wait(1).to({scaleX:0.4516,scaleY:0.4516,x:152,y:111.5},0).wait(1).to({scaleX:0.45,scaleY:0.45,x:151.1,y:110.9},0).wait(1).to({scaleX:0.4487,scaleY:0.4487,x:150.35,y:110.4},0).wait(1).to({scaleX:0.4475,scaleY:0.4475,x:149.7,y:109.95},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:149.1,y:109.6},0).wait(1).to({scaleX:0.4457,scaleY:0.4457,x:148.65,y:109.3},0).wait(1).to({scaleX:0.4449,scaleY:0.4449,x:148.2,y:108.95},0).wait(1).to({scaleX:0.4442,scaleY:0.4442,x:147.8,y:108.75},0).wait(1).to({scaleX:0.4437,scaleY:0.4437,x:147.45,y:108.55},0).wait(1).to({scaleX:0.4431,scaleY:0.4431,x:147.15,y:108.3},0).wait(1).to({scaleX:0.4427,scaleY:0.4427,x:146.95,y:108.15},0).wait(1).to({scaleX:0.4423,scaleY:0.4423,x:146.7,y:108},0).wait(1).to({scaleX:0.442,scaleY:0.442,x:146.55,y:107.9},0).wait(1).to({scaleX:0.4417,scaleY:0.4417,x:146.3,y:107.75},0).wait(1).to({scaleX:0.4414,scaleY:0.4414,x:146.2,y:107.7},0).wait(1).to({scaleX:0.4412,scaleY:0.4412,x:146.05,y:107.6},0).wait(1).to({scaleX:0.4411,scaleY:0.4411,x:146,y:107.5},0).wait(1).to({scaleX:0.4409,scaleY:0.4409,x:145.9,y:107.45},0).wait(1).to({scaleX:0.4408,scaleY:0.4408,x:145.85,y:107.4},0).wait(1).to({scaleX:0.4407,scaleY:0.4407,x:145.8},0).wait(1).to({x:145.75,y:107.35},0).wait(1).to({scaleX:0.4406,scaleY:0.4406},0).wait(1).to({regX:28.5,regY:23.1,x:145.85,y:107.6},0).wait(8));

	// r girl i shadow
	this.instance_10 = new lib.roundshadow();
	this.instance_10.setTransform(221.7,324.1,1,1,0,0,0,28.2,22.8);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	var maskedShapeInstanceList = [this.instance_10];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(14).to({_off:false},0).to({regX:28.3,scaleX:1.0251,scaleY:1.0251,x:160.2,y:251.75,alpha:0.1602},54,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:159.9,y:251.45},0).wait(16).to({regX:28.3,regY:22.8,x:160.2,y:251.75},0).wait(1).to({regX:28,regY:22.5,scaleX:1.0215,scaleY:1.0215,y:250.8},0).wait(1).to({scaleX:1.0176,scaleY:1.0176,x:160.55,y:250.1},0).wait(1).to({scaleX:1.0133,scaleY:1.0133,x:160.9,y:249.35},0).wait(1).to({scaleX:1.0087,scaleY:1.0087,x:161.35,y:248.55},0).wait(1).to({scaleX:1.0038,scaleY:1.0038,x:161.8,y:247.7},0).wait(1).to({scaleX:0.9985,scaleY:0.9985,x:162.25,y:246.75},0).wait(1).to({scaleX:0.9929,scaleY:0.9929,x:162.75,y:245.75},0).wait(1).to({scaleX:0.987,scaleY:0.987,x:163.3,y:244.7},0).wait(1).to({scaleX:0.9807,scaleY:0.9807,x:163.85,y:243.6},0).wait(1).to({scaleX:0.9741,scaleY:0.9741,x:164.5,y:242.45},0).wait(1).to({scaleX:0.9672,scaleY:0.9672,x:165.1,y:241.25},0).wait(1).to({scaleX:0.96,scaleY:0.96,x:165.75,y:239.95},0).wait(1).to({scaleX:0.9525,scaleY:0.9525,x:166.35,y:238.65},0).wait(1).to({scaleX:0.9448,scaleY:0.9448,x:167.1,y:237.25},0).wait(1).to({scaleX:0.9367,scaleY:0.9367,x:167.85,y:235.9},0).wait(1).to({scaleX:0.9284,scaleY:0.9284,x:168.55,y:234.4},0).wait(1).to({scaleX:0.9199,scaleY:0.9199,x:169.3,y:232.9},0).wait(1).to({scaleX:0.9112,scaleY:0.9112,x:170.1,y:231.35},0).wait(1).to({scaleX:0.9023,scaleY:0.9023,x:170.9,y:229.8},0).wait(1).to({scaleX:0.8933,scaleY:0.8933,x:171.7,y:228.2},0).wait(1).to({scaleX:0.8841,scaleY:0.8841,x:172.55,y:226.6},0).wait(1).to({scaleX:0.8748,scaleY:0.8748,x:173.35,y:224.95},0).wait(1).to({scaleX:0.8654,scaleY:0.8654,x:174.2,y:223.3},0).wait(1).to({scaleX:0.8561,scaleY:0.8561,x:175.05,y:221.65},0).wait(1).to({scaleX:0.8467,scaleY:0.8467,x:175.9,y:220},0).wait(1).to({scaleX:0.8373,scaleY:0.8373,x:176.75,y:218.35},0).wait(1).to({scaleX:0.828,scaleY:0.828,x:177.6,y:216.7},0).wait(1).to({scaleX:0.8188,scaleY:0.8188,x:178.4,y:215.05},0).wait(1).to({scaleX:0.8097,scaleY:0.8097,x:179.2,y:213.45},0).wait(1).to({scaleX:0.8007,scaleY:0.8007,x:180,y:211.9},0).wait(1).to({scaleX:0.7919,scaleY:0.7919,x:180.8,y:210.35},0).wait(1).to({scaleX:0.7833,scaleY:0.7833,x:181.6,y:208.8},0).wait(1).to({scaleX:0.7749,scaleY:0.7749,x:182.35,y:207.35},0).wait(1).to({scaleX:0.7668,scaleY:0.7668,x:183.05,y:205.9},0).wait(1).to({scaleX:0.759,scaleY:0.759,x:183.75,y:204.55},0).wait(1).to({scaleX:0.7514,scaleY:0.7514,x:184.45,y:203.2},0).wait(1).to({scaleX:0.7441,scaleY:0.7441,x:185.1,y:201.9},0).wait(1).to({scaleX:0.7371,scaleY:0.7371,x:185.75,y:200.7},0).wait(1).to({scaleX:0.7304,scaleY:0.7304,x:186.35,y:199.5},0).wait(1).to({scaleX:0.724,scaleY:0.724,x:186.85,y:198.4},0).wait(1).to({scaleX:0.718,scaleY:0.718,x:187.45,y:197.3},0).wait(1).to({scaleX:0.7123,scaleY:0.7123,x:187.95,y:196.35},0).wait(1).to({scaleX:0.7069,scaleY:0.7069,x:188.45,y:195.35},0).wait(1).to({scaleX:0.7019,scaleY:0.7019,x:188.9,y:194.5},0).wait(1).to({scaleX:0.6972,scaleY:0.6972,x:189.3,y:193.65},0).wait(1).to({scaleX:0.6928,scaleY:0.6928,x:189.7,y:192.9},0).wait(1).to({scaleX:0.6888,scaleY:0.6888,x:190.05,y:192.2},0).wait(1).to({scaleX:0.6851,scaleY:0.6851,x:190.4,y:191.5},0).wait(1).to({scaleX:0.6817,scaleY:0.6817,x:190.7,y:190.95},0).wait(1).to({scaleX:0.6787,scaleY:0.6787,x:190.95,y:190.35},0).wait(1).to({scaleX:0.6759,scaleY:0.6759,x:191.25,y:189.9},0).wait(1).to({scaleX:0.6735,scaleY:0.6735,x:191.4,y:189.5},0).wait(1).to({scaleX:0.6714,scaleY:0.6714,x:191.6,y:189.1},0).wait(1).to({scaleX:0.6696,scaleY:0.6696,x:191.8,y:188.75},0).wait(1).to({scaleX:0.6681,scaleY:0.6681,x:191.9,y:188.55},0).wait(1).to({scaleX:0.6668,scaleY:0.6668,x:192,y:188.3},0).wait(1).to({scaleX:0.6659,scaleY:0.6659,x:192.1,y:188.15},0).wait(1).to({scaleX:0.6652,scaleY:0.6652,x:192.2,y:188},0).wait(1).to({scaleX:0.6648,scaleY:0.6648,y:187.95},0).wait(1).to({regX:28.3,regY:22.9,scaleX:0.6647,scaleY:0.6647,x:192.4,y:188.1},0).wait(1).to({regX:28,regY:22.5,x:192.2,y:187.85},0).wait(14).to({regX:28.3,regY:22.9,x:192.4,y:188.1},0).wait(1).to({regX:28,regY:22.5,scaleX:0.6646,scaleY:0.6646,x:192.15,y:187.8},0).wait(1).to({scaleX:0.6644,scaleY:0.6644,y:187.7},0).wait(1).to({scaleX:0.6641,scaleY:0.6641,y:187.6},0).wait(1).to({scaleX:0.6637,scaleY:0.6637,x:192.1,y:187.45},0).wait(1).to({scaleX:0.6632,scaleY:0.6632,x:192,y:187.25},0).wait(1).to({scaleX:0.6625,scaleY:0.6625,x:191.95,y:187.05},0).wait(1).to({scaleX:0.6618,scaleY:0.6618,x:191.9,y:186.75},0).wait(1).to({scaleX:0.6608,scaleY:0.6608,x:191.8,y:186.4},0).wait(1).to({scaleX:0.6598,scaleY:0.6598,x:191.7,y:186.05},0).wait(1).to({scaleX:0.6586,scaleY:0.6586,x:191.6,y:185.6},0).wait(1).to({scaleX:0.6571,scaleY:0.6571,x:191.45,y:185.1},0).wait(1).to({scaleX:0.6555,scaleY:0.6555,x:191.25,y:184.5},0).wait(1).to({scaleX:0.6536,scaleY:0.6536,x:191.1,y:183.8},0).wait(1).to({scaleX:0.6515,scaleY:0.6515,x:190.9,y:183.05},0).wait(1).to({scaleX:0.6491,scaleY:0.6491,x:190.6,y:182.15},0).wait(1).to({scaleX:0.6463,scaleY:0.6463,x:190.35,y:181.15},0).wait(1).to({scaleX:0.6431,scaleY:0.6431,x:190.05,y:180},0).wait(1).to({scaleX:0.6394,scaleY:0.6394,x:189.7,y:178.7},0).wait(1).to({scaleX:0.6352,scaleY:0.6352,x:189.3,y:177.15},0).wait(1).to({scaleX:0.6302,scaleY:0.6302,x:188.8,y:175.35},0).wait(1).to({scaleX:0.6244,scaleY:0.6244,x:188.2,y:173.25},0).wait(1).to({scaleX:0.6175,scaleY:0.6175,x:187.55,y:170.75},0).wait(1).to({scaleX:0.6091,scaleY:0.6091,x:186.7,y:167.7},0).wait(1).to({scaleX:0.5988,scaleY:0.5988,x:185.65,y:163.95},0).wait(1).to({scaleX:0.5859,scaleY:0.5859,x:184.4,y:159.3},0).wait(1).to({scaleX:0.5696,scaleY:0.5696,x:182.8,y:153.4},0).wait(1).to({scaleX:0.5502,scaleY:0.5502,x:180.85,y:146.45},0).wait(1).to({scaleX:0.5303,scaleY:0.5303,x:178.9,y:139.2},0).wait(1).to({scaleX:0.5129,scaleY:0.5129,x:177.15,y:132.9},0).wait(1).to({scaleX:0.4988,scaleY:0.4988,x:175.8,y:127.8},0).wait(1).to({scaleX:0.4875,scaleY:0.4875,x:174.7,y:123.7},0).wait(1).to({scaleX:0.4784,scaleY:0.4784,x:173.8,y:120.4},0).wait(1).to({scaleX:0.4708,scaleY:0.4708,x:173.05,y:117.65},0).wait(1).to({scaleX:0.4644,scaleY:0.4644,x:172.4,y:115.35},0).wait(1).to({scaleX:0.4589,scaleY:0.4589,x:171.85,y:113.4},0).wait(1).to({scaleX:0.4542,scaleY:0.4542,x:171.35,y:111.65},0).wait(1).to({scaleX:0.4501,scaleY:0.4501,x:171,y:110.2},0).wait(1).to({scaleX:0.4465,scaleY:0.4465,x:170.65,y:108.9},0).wait(1).to({scaleX:0.4433,scaleY:0.4433,x:170.3,y:107.7},0).wait(1).to({scaleX:0.4405,scaleY:0.4405,x:170.05,y:106.7},0).wait(1).to({scaleX:0.4381,scaleY:0.4381,x:169.8,y:105.85},0).wait(1).to({scaleX:0.4359,scaleY:0.4359,x:169.55,y:105.05},0).wait(1).to({scaleX:0.4339,scaleY:0.4339,x:169.4,y:104.35},0).wait(1).to({scaleX:0.4322,scaleY:0.4322,x:169.2,y:103.7},0).wait(1).to({scaleX:0.4307,scaleY:0.4307,x:169.05,y:103.15},0).wait(1).to({scaleX:0.4293,scaleY:0.4293,x:168.9,y:102.65},0).wait(1).to({scaleX:0.4282,scaleY:0.4282,x:168.85,y:102.25},0).wait(1).to({scaleX:0.4271,scaleY:0.4271,x:168.7,y:101.85},0).wait(1).to({scaleX:0.4262,scaleY:0.4262,x:168.65,y:101.55},0).wait(1).to({scaleX:0.4255,scaleY:0.4255,x:168.55,y:101.25},0).wait(1).to({scaleX:0.4248,scaleY:0.4248,x:168.5,y:101.05},0).wait(1).to({scaleX:0.4243,scaleY:0.4243,x:168.45,y:100.85},0).wait(1).to({scaleX:0.4238,scaleY:0.4238,x:168.35,y:100.7},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,y:100.6},0).wait(1).to({scaleX:0.4232,scaleY:0.4232,y:100.45},0).wait(1).to({scaleX:0.423,scaleY:0.423,x:168.3,y:100.35},0).wait(1).to({scaleX:0.4229,scaleY:0.4229},0).wait(1).to({regX:28.3,regY:22.9,x:168.45,y:100.55},0).wait(1));

	// l girl i shadow
	this.instance_11 = new lib.roundshadow();
	this.instance_11.setTransform(-105.9,239.95,1,1,0,0,0,28.2,22.8);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	var maskedShapeInstanceList = [this.instance_11];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(9).to({_off:false},0).to({scaleX:1.0222,scaleY:1.0222,x:50,y:196,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:28,regY:22.5,x:49.75,y:195.7},0).wait(19).to({regX:28.2,regY:22.8,x:50,y:196},0).wait(1).to({regX:28,regY:22.5,scaleX:1.0168,scaleY:1.0168,x:51.1,y:195.25},0).wait(1).to({scaleX:1.0109,scaleY:1.0109,x:52.65,y:194.8},0).wait(1).to({scaleX:1.0045,scaleY:1.0045,x:54.35,y:194.3},0).wait(1).to({scaleX:0.9976,scaleY:0.9976,x:56.1,y:193.75},0).wait(1).to({scaleX:0.9902,scaleY:0.9902,x:58.05,y:193.2},0).wait(1).to({scaleX:0.9823,scaleY:0.9823,x:60.05,y:192.55},0).wait(1).to({scaleX:0.9739,scaleY:0.9739,x:62.25,y:191.85},0).wait(1).to({scaleX:0.9649,scaleY:0.9649,x:64.55,y:191.15},0).wait(1).to({scaleX:0.9555,scaleY:0.9555,x:67,y:190.45},0).wait(1).to({scaleX:0.9455,scaleY:0.9455,x:69.55,y:189.65},0).wait(1).to({scaleX:0.9351,scaleY:0.9351,x:72.3,y:188.85},0).wait(1).to({scaleX:0.9242,scaleY:0.9242,x:75.1,y:188},0).wait(1).to({scaleX:0.9129,scaleY:0.9129,x:78,y:187.1},0).wait(1).to({scaleX:0.9012,scaleY:0.9012,x:81.1,y:186.2},0).wait(1).to({scaleX:0.889,scaleY:0.889,x:84.2,y:185.2},0).wait(1).to({scaleX:0.8765,scaleY:0.8765,x:87.45,y:184.2},0).wait(1).to({scaleX:0.8637,scaleY:0.8637,x:90.8,y:183.25},0).wait(1).to({scaleX:0.8506,scaleY:0.8506,x:94.15,y:182.2},0).wait(1).to({scaleX:0.8372,scaleY:0.8372,x:97.65,y:181.15},0).wait(1).to({scaleX:0.8236,scaleY:0.8236,x:101.15,y:180.1},0).wait(1).to({scaleX:0.8098,scaleY:0.8098,x:104.7,y:178.95},0).wait(1).to({scaleX:0.7959,scaleY:0.7959,x:108.3,y:177.9},0).wait(1).to({scaleX:0.782,scaleY:0.782,x:111.9,y:176.8},0).wait(1).to({scaleX:0.768,scaleY:0.768,x:115.55,y:175.7},0).wait(1).to({scaleX:0.7541,scaleY:0.7541,x:119.1,y:174.6},0).wait(1).to({scaleX:0.7402,scaleY:0.7402,x:122.75,y:173.5},0).wait(1).to({scaleX:0.7265,scaleY:0.7265,x:126.3,y:172.45},0).wait(1).to({scaleX:0.7129,scaleY:0.7129,x:129.75,y:171.4},0).wait(1).to({scaleX:0.6996,scaleY:0.6996,x:133.25,y:170.35},0).wait(1).to({scaleX:0.6865,scaleY:0.6865,x:136.6,y:169.3},0).wait(1).to({scaleX:0.6738,scaleY:0.6738,x:139.9,y:168.3},0).wait(1).to({scaleX:0.6614,scaleY:0.6614,x:143.1,y:167.35},0).wait(1).to({scaleX:0.6493,scaleY:0.6493,x:146.25,y:166.35},0).wait(1).to({scaleX:0.6377,scaleY:0.6377,x:149.25,y:165.45},0).wait(1).to({scaleX:0.6265,scaleY:0.6265,x:152.15,y:164.6},0).wait(1).to({scaleX:0.6157,scaleY:0.6157,x:154.95,y:163.75},0).wait(1).to({scaleX:0.6055,scaleY:0.6055,x:157.6,y:162.9},0).wait(1).to({scaleX:0.5957,scaleY:0.5957,x:160.15,y:162.15},0).wait(1).to({scaleX:0.5864,scaleY:0.5864,x:162.5,y:161.45},0).wait(1).to({scaleX:0.5776,scaleY:0.5776,x:164.8,y:160.75},0).wait(1).to({scaleX:0.5693,scaleY:0.5693,x:166.95,y:160.1},0).wait(1).to({scaleX:0.5615,scaleY:0.5615,x:168.95,y:159.5},0).wait(1).to({scaleX:0.5543,scaleY:0.5543,x:170.85,y:158.9},0).wait(1).to({scaleX:0.5475,scaleY:0.5475,x:172.6,y:158.35},0).wait(1).to({scaleX:0.5413,scaleY:0.5413,x:174.2,y:157.9},0).wait(1).to({scaleX:0.5356,scaleY:0.5356,x:175.7,y:157.45},0).wait(1).to({scaleX:0.5304,scaleY:0.5304,x:177.05,y:157.05},0).wait(1).to({scaleX:0.5257,scaleY:0.5257,x:178.25,y:156.7},0).wait(1).to({scaleX:0.5214,scaleY:0.5214,x:179.35,y:156.35},0).wait(1).to({scaleX:0.5177,scaleY:0.5177,x:180.3,y:156.05},0).wait(1).to({scaleX:0.5145,scaleY:0.5145,x:181.15,y:155.8},0).wait(1).to({scaleX:0.5117,scaleY:0.5117,x:181.9,y:155.55},0).wait(1).to({scaleX:0.5093,scaleY:0.5093,x:182.45,y:155.35},0).wait(1).to({scaleX:0.5074,scaleY:0.5074,x:182.95,y:155.2},0).wait(1).to({scaleX:0.506,scaleY:0.506,x:183.35,y:155.15},0).wait(1).to({scaleX:0.505,scaleY:0.505,x:183.6,y:155},0).wait(1).to({scaleX:0.5044,scaleY:0.5044,x:183.75},0).wait(1).to({regX:28.4,regY:22.9,scaleX:0.5042,scaleY:0.5042,x:183.9,y:155.15},0).wait(1).to({regX:28,regY:22.5,x:183.7,y:154.95},0).wait(16).to({regX:28.4,regY:22.9,x:183.9,y:155.15},0).wait(1).to({regX:28,regY:22.5,scaleX:0.5041,scaleY:0.5041,x:183.7,y:154.9},0).wait(1).to({scaleX:0.504,scaleY:0.504,y:154.85},0).wait(1).to({scaleX:0.5039,scaleY:0.5039,y:154.75},0).wait(1).to({scaleX:0.5038,scaleY:0.5038,y:154.65},0).wait(1).to({scaleX:0.5036,scaleY:0.5036,x:183.75,y:154.5},0).wait(1).to({scaleX:0.5033,scaleY:0.5033,y:154.3},0).wait(1).to({scaleX:0.503,scaleY:0.503,x:183.8,y:154.1},0).wait(1).to({scaleX:0.5027,scaleY:0.5027,x:183.75,y:153.85},0).wait(1).to({scaleX:0.5022,scaleY:0.5022,x:183.8,y:153.6},0).wait(1).to({scaleX:0.5018,scaleY:0.5018,x:183.85,y:153.25},0).wait(1).to({scaleX:0.5012,scaleY:0.5012,x:183.9,y:152.85},0).wait(1).to({scaleX:0.5006,scaleY:0.5006,x:183.95,y:152.4},0).wait(1).to({scaleX:0.4998,scaleY:0.4998,x:184,y:151.85},0).wait(1).to({scaleX:0.499,scaleY:0.499,x:184.05,y:151.3},0).wait(1).to({scaleX:0.498,scaleY:0.498,x:184.15,y:150.6},0).wait(1).to({scaleX:0.4969,scaleY:0.4969,x:184.2,y:149.8},0).wait(1).to({scaleX:0.4956,scaleY:0.4956,x:184.35,y:148.9},0).wait(1).to({scaleX:0.4941,scaleY:0.4941,x:184.45,y:147.8},0).wait(1).to({scaleX:0.4924,scaleY:0.4924,x:184.55,y:146.65},0).wait(1).to({scaleX:0.4903,scaleY:0.4903,x:184.7,y:145.15},0).wait(1).to({scaleX:0.4879,scaleY:0.4879,x:184.85,y:143.45},0).wait(1).to({scaleX:0.4849,scaleY:0.4849,x:185.1,y:141.3},0).wait(1).to({scaleX:0.4812,scaleY:0.4812,x:185.35,y:138.75},0).wait(1).to({scaleX:0.4766,scaleY:0.4766,x:185.7,y:135.45},0).wait(1).to({scaleX:0.4707,scaleY:0.4707,x:186.15,y:131.3},0).wait(1).to({scaleX:0.4636,scaleY:0.4636,x:186.65,y:126.3},0).wait(1).to({scaleX:0.4562,scaleY:0.4562,x:187.15,y:121.05},0).wait(1).to({scaleX:0.4497,scaleY:0.4497,x:187.65,y:116.45},0).wait(1).to({scaleX:0.4445,scaleY:0.4445,x:188.05,y:112.8},0).wait(1).to({scaleX:0.4404,scaleY:0.4404,x:188.35,y:109.9},0).wait(1).to({scaleX:0.4371,scaleY:0.4371,x:188.6,y:107.55},0).wait(1).to({scaleX:0.4343,scaleY:0.4343,x:188.75,y:105.6},0).wait(1).to({scaleX:0.432,scaleY:0.432,x:188.95,y:103.95},0).wait(1).to({scaleX:0.4301,scaleY:0.4301,x:189.1,y:102.6},0).wait(1).to({scaleX:0.4284,scaleY:0.4284,x:189.2,y:101.4},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:189.3,y:100.35},0).wait(1).to({scaleX:0.4256,scaleY:0.4256,x:189.4,y:99.5},0).wait(1).to({scaleX:0.4245,scaleY:0.4245,x:189.5,y:98.65},0).wait(1).to({scaleX:0.4235,scaleY:0.4235,x:189.55,y:98},0).wait(1).to({scaleX:0.4226,scaleY:0.4226,x:189.65,y:97.35},0).wait(1).to({scaleX:0.4219,scaleY:0.4219,y:96.8},0).wait(1).to({scaleX:0.4212,scaleY:0.4212,x:189.75,y:96.35},0).wait(1).to({scaleX:0.4206,scaleY:0.4206,x:189.8,y:95.9},0).wait(1).to({scaleX:0.4201,scaleY:0.4201,y:95.55},0).wait(1).to({scaleX:0.4196,scaleY:0.4196,x:189.85,y:95.2},0).wait(1).to({scaleX:0.4192,scaleY:0.4192,x:189.9,y:94.95},0).wait(1).to({scaleX:0.4188,scaleY:0.4188,y:94.65},0).wait(1).to({scaleX:0.4185,scaleY:0.4185,y:94.45},0).wait(1).to({scaleX:0.4183,scaleY:0.4183,x:189.95,y:94.25},0).wait(1).to({scaleX:0.4181,scaleY:0.4181,y:94.15},0).wait(1).to({scaleX:0.4179,scaleY:0.4179,y:94},0).wait(1).to({scaleX:0.4178,scaleY:0.4178,x:190,y:93.9},0).wait(1).to({scaleX:0.4177,scaleY:0.4177,y:93.85},0).wait(1).to({scaleX:0.4176,scaleY:0.4176,y:93.8},0).wait(1).to({y:93.75},0).wait(1).to({regX:28.4,regY:23.1,scaleX:0.4175,scaleY:0.4175,x:190.2,y:93.95},0).wait(2));

	// l girl box shadow
	this.instance_12 = new lib.squareshadow();
	this.instance_12.setTransform(-54.5,241.45,0.68,0.68,0,0,0,70.8,47.8);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	var maskedShapeInstanceList = [this.instance_12];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(9).to({_off:false},0).to({regY:47.9,scaleX:0.6951,scaleY:0.6951,x:106.95,y:204.25,alpha:0.1602},57,cjs.Ease.quadOut).wait(1).to({regX:70.6,regY:47.8,x:106.85,y:204.2},0).wait(19).to({regX:70.8,regY:47.9,x:106.95,y:204.25},0).wait(1).to({regX:70.6,regY:47.8,scaleX:0.6908,scaleY:0.6908,x:107.8,y:203.7,alpha:0.1585},0).wait(1).to({scaleX:0.6861,scaleY:0.6861,x:108.95,y:203.2,alpha:0.1567},0).wait(1).to({scaleX:0.681,scaleY:0.681,x:110.2,y:202.7,alpha:0.1548},0).wait(1).to({scaleX:0.6755,scaleY:0.6755,x:111.5,y:202.15,alpha:0.1527},0).wait(1).to({scaleX:0.6696,scaleY:0.6696,x:112.9,y:201.5,alpha:0.1505},0).wait(1).to({scaleX:0.6633,scaleY:0.6633,x:114.45,y:200.85,alpha:0.1481},0).wait(1).to({scaleX:0.6566,scaleY:0.6566,x:116.05,y:200.15,alpha:0.1455},0).wait(1).to({scaleX:0.6494,scaleY:0.6494,x:117.75,y:199.4,alpha:0.1428},0).wait(1).to({scaleX:0.6419,scaleY:0.6419,x:119.5,y:198.65,alpha:0.14},0).wait(1).to({scaleX:0.634,scaleY:0.634,x:121.4,y:197.8,alpha:0.137},0).wait(1).to({scaleX:0.6257,scaleY:0.6257,x:123.45,y:196.95,alpha:0.1338},0).wait(1).to({scaleX:0.6171,scaleY:0.6171,x:125.45,y:196.05,alpha:0.1306},0).wait(1).to({scaleX:0.6081,scaleY:0.6081,x:127.65,y:195.1,alpha:0.1272},0).wait(1).to({scaleX:0.5988,scaleY:0.5988,x:129.85,y:194.15,alpha:0.1236},0).wait(1).to({scaleX:0.5891,scaleY:0.5891,x:132.2,y:193.15,alpha:0.12},0).wait(1).to({scaleX:0.5792,scaleY:0.5792,x:134.6,y:192.15,alpha:0.1162},0).wait(1).to({scaleX:0.569,scaleY:0.569,x:137,y:191.05,alpha:0.1123},0).wait(1).to({scaleX:0.5585,scaleY:0.5585,x:139.55,y:189.95,alpha:0.1083},0).wait(1).to({scaleX:0.5478,scaleY:0.5478,x:142.1,y:188.85,alpha:0.1043},0).wait(1).to({scaleX:0.537,scaleY:0.537,x:144.65,y:187.7,alpha:0.1002},0).wait(1).to({scaleX:0.526,scaleY:0.526,x:147.3,y:186.6,alpha:0.096},0).wait(1).to({scaleX:0.5149,scaleY:0.5149,x:149.95,y:185.45,alpha:0.0918},0).wait(1).to({scaleX:0.5037,scaleY:0.5037,x:152.6,y:184.3,alpha:0.0876},0).wait(1).to({scaleX:0.4926,scaleY:0.4926,x:155.3,y:183.15,alpha:0.0833},0).wait(1).to({scaleX:0.4814,scaleY:0.4814,x:158,y:181.95,alpha:0.0791},0).wait(1).to({scaleX:0.4702,scaleY:0.4702,x:160.65,y:180.85,alpha:0.0749},0).wait(1).to({scaleX:0.4592,scaleY:0.4592,x:163.3,y:179.65,alpha:0.0707},0).wait(1).to({scaleX:0.4482,scaleY:0.4482,x:165.9,y:178.55,alpha:0.0665},0).wait(1).to({scaleX:0.4375,scaleY:0.4375,x:168.5,y:177.4,alpha:0.0624},0).wait(1).to({scaleX:0.4269,scaleY:0.4269,x:171.05,y:176.3,alpha:0.0584},0).wait(1).to({scaleX:0.4165,scaleY:0.4165,x:173.5,y:175.2,alpha:0.0545},0).wait(1).to({scaleX:0.4064,scaleY:0.4064,x:175.95,y:174.2,alpha:0.0507},0).wait(1).to({scaleX:0.3966,scaleY:0.3966,x:178.25,y:173.15,alpha:0.047},0).wait(1).to({scaleX:0.3871,scaleY:0.3871,x:180.55,y:172.15,alpha:0.0433},0).wait(1).to({scaleX:0.3779,scaleY:0.3779,x:182.75,y:171.2,alpha:0.0399},0).wait(1).to({scaleX:0.3691,scaleY:0.3691,x:184.85,y:170.3,alpha:0.0365},0).wait(1).to({scaleX:0.3606,scaleY:0.3606,x:186.9,y:169.45,alpha:0.0333},0).wait(1).to({scaleX:0.3525,scaleY:0.3525,x:188.85,y:168.6,alpha:0.0302},0).wait(1).to({scaleX:0.3448,scaleY:0.3448,x:190.7,y:167.8,alpha:0.0273},0).wait(1).to({scaleX:0.3375,scaleY:0.3375,x:192.45,y:167.05,alpha:0.0245},0).wait(1).to({scaleX:0.3306,scaleY:0.3306,x:194.1,y:166.3,alpha:0.0219},0).wait(1).to({scaleX:0.3241,scaleY:0.3241,x:195.65,y:165.65,alpha:0.0194},0).wait(1).to({scaleX:0.3179,scaleY:0.3179,x:197.1,y:165,alpha:0.0171},0).wait(1).to({scaleX:0.3122,scaleY:0.3122,x:198.5,y:164.4,alpha:0.0149},0).wait(1).to({scaleX:0.3069,scaleY:0.3069,x:199.75,y:163.85,alpha:0.0129},0).wait(1).to({scaleX:0.302,scaleY:0.302,x:200.9,y:163.35,alpha:0.0111},0).wait(1).to({scaleX:0.2976,scaleY:0.2976,x:202,y:162.85,alpha:0.0094},0).wait(1).to({scaleX:0.2935,scaleY:0.2935,x:202.95,y:162.5,alpha:0.0078},0).wait(1).to({scaleX:0.2898,scaleY:0.2898,x:203.85,y:162.05,alpha:0.0064},0).wait(1).to({scaleX:0.2864,scaleY:0.2864,x:204.65,y:161.75,alpha:0.0052},0).wait(1).to({scaleX:0.2835,scaleY:0.2835,x:205.35,y:161.4,alpha:0.004},0).wait(1).to({scaleX:0.2809,scaleY:0.2809,x:206,y:161.15,alpha:0.0031},0).wait(1).to({scaleX:0.2787,scaleY:0.2787,x:206.5,y:160.9,alpha:0.0022},0).wait(1).to({scaleX:0.2769,scaleY:0.2769,x:206.95,y:160.75,alpha:0.0015},0).wait(1).to({scaleX:0.2754,scaleY:0.2754,x:207.3,y:160.55,alpha:0.001},0).wait(1).to({scaleX:0.2743,scaleY:0.2743,x:207.55,y:160.45,alpha:0.0005},0).wait(1).to({scaleX:0.2735,scaleY:0.2735,x:207.75,y:160.35,alpha:0.0002},0).wait(1).to({scaleX:0.273,scaleY:0.273,x:207.85,alpha:0.0001},0).wait(1).to({regX:71.5,regY:48.2,scaleX:0.2728,scaleY:0.2728,x:208,alpha:0},0).wait(74));

	// r girl box shadow
	this.instance_13 = new lib.fill();
	this.instance_13.setTransform(208.3,160.35,0.8066,0.8066,0,0,0,32.6,30.2);
	this.instance_13.alpha = 0;
	this.instance_13._off = true;

	var maskedShapeInstanceList = [this.instance_13];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(124).to({_off:false},0).to({regX:32.7,regY:30.4,scaleX:0.8549,scaleY:0.8274,x:209.95,y:159.85,alpha:1},16).wait(79));

	// r guy box shadow
	this.instance_14 = new lib.squareshadow();
	this.instance_14.setTransform(249.5,5.2,0.5457,0.5457,0,0,0,70.7,47.8);
	this.instance_14.alpha = 0;
	this.instance_14._off = true;

	var maskedShapeInstanceList = [this.instance_14];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(19).to({_off:false},0).to({scaleX:0.5659,scaleY:0.5659,x:244.25,y:72.65,alpha:0.1602},50,cjs.Ease.quadOut).wait(1).to({regX:70.6,x:244.2},0).wait(11).to({regX:70.7,x:244.25},0).wait(1).to({regX:70.6,scaleX:0.5637,scaleY:0.5635,x:244,y:73.05},0).wait(1).to({scaleX:0.5614,scaleY:0.5609,x:243.8,y:73.45},0).wait(1).to({scaleX:0.5589,scaleY:0.5581,x:243.55,y:74},0).wait(1).to({scaleX:0.5562,scaleY:0.5551,x:243.3,y:74.5},0).wait(1).to({scaleX:0.5533,scaleY:0.5518,x:243.05,y:75.1},0).wait(1).to({scaleX:0.5501,scaleY:0.5484,x:242.8,y:75.65},0).wait(1).to({scaleX:0.5468,scaleY:0.5447,x:242.5,y:76.3},0).wait(1).to({scaleX:0.5433,scaleY:0.5408,x:242.2,y:77},0).wait(1).to({scaleX:0.5396,scaleY:0.5366,x:241.85,y:77.7},0).wait(1).to({scaleX:0.5357,scaleY:0.5323,x:241.5,y:78.45},0).wait(1).to({scaleX:0.5316,scaleY:0.5278,x:241.2,y:79.3},0).wait(1).to({scaleX:0.5274,scaleY:0.523,x:240.8,y:80.1},0).wait(1).to({scaleX:0.5229,scaleY:0.5181,x:240.4,y:80.9},0).wait(1).to({scaleX:0.5183,scaleY:0.5129,x:240,y:81.8},0).wait(1).to({scaleX:0.5136,scaleY:0.5076,x:239.55,y:82.75},0).wait(1).to({scaleX:0.5087,scaleY:0.5022,x:239.15,y:83.7},0).wait(1).to({scaleX:0.5036,scaleY:0.4966,x:238.7,y:84.7},0).wait(1).to({scaleX:0.4985,scaleY:0.4908,x:238.25,y:85.65},0).wait(1).to({scaleX:0.4932,scaleY:0.485,x:237.75,y:86.7},0).wait(1).to({scaleX:0.4879,scaleY:0.479,x:237.3,y:87.75},0).wait(1).to({scaleX:0.4825,scaleY:0.473,x:236.8,y:88.75},0).wait(1).to({scaleX:0.477,scaleY:0.4669,x:236.35,y:89.8},0).wait(1).to({scaleX:0.4715,scaleY:0.4608,x:235.9,y:90.9},0).wait(1).to({scaleX:0.466,scaleY:0.4546,x:235.4,y:92},0).wait(1).to({scaleX:0.4604,scaleY:0.4485,x:234.9,y:93.05},0).wait(1).to({scaleX:0.4549,scaleY:0.4424,x:234.4,y:94.1},0).wait(1).to({scaleX:0.4495,scaleY:0.4363,x:233.95,y:95.15},0).wait(1).to({scaleX:0.4441,scaleY:0.4303,x:233.45,y:96.2},0).wait(1).to({scaleX:0.4388,scaleY:0.4244,x:233,y:97.25},0).wait(1).to({scaleX:0.4336,scaleY:0.4186,x:232.5,y:98.25},0).wait(1).to({scaleX:0.4285,scaleY:0.4129,x:232.1,y:99.25},0).wait(1).to({scaleX:0.4235,scaleY:0.4074,x:231.65,y:100.2},0).wait(1).to({scaleX:0.4187,scaleY:0.402,x:231.2,y:101.15},0).wait(1).to({scaleX:0.414,scaleY:0.3967,x:230.85,y:102.05},0).wait(1).to({scaleX:0.4094,scaleY:0.3917,x:230.4,y:102.9},0).wait(1).to({scaleX:0.4051,scaleY:0.3868,x:230.05,y:103.8},0).wait(1).to({scaleX:0.4009,scaleY:0.3822,x:229.65,y:104.55},0).wait(1).to({scaleX:0.3969,scaleY:0.3777,x:229.3,y:105.35},0).wait(1).to({scaleX:0.3931,scaleY:0.3735,x:228.95,y:106.1},0).wait(1).to({scaleX:0.3895,scaleY:0.3695,x:228.65,y:106.8},0).wait(1).to({scaleX:0.3861,scaleY:0.3657,x:228.35,y:107.5},0).wait(1).to({scaleX:0.3829,scaleY:0.3621,x:228.1,y:108.05},0).wait(1).to({scaleX:0.3799,scaleY:0.3588,x:227.8,y:108.65},0).wait(1).to({scaleX:0.377,scaleY:0.3556,x:227.55,y:109.2},0).wait(1).to({scaleX:0.3744,scaleY:0.3527,x:227.35,y:109.7},0).wait(1).to({scaleX:0.372,scaleY:0.35,x:227.1,y:110.2},0).wait(1).to({scaleX:0.3698,scaleY:0.3476,x:226.9,y:110.6},0).wait(1).to({scaleX:0.3678,scaleY:0.3453,x:226.75,y:111},0).wait(1).to({scaleX:0.366,scaleY:0.3433,x:226.6,y:111.35},0).wait(1).to({scaleX:0.3643,scaleY:0.3415,x:226.4,y:111.65},0).wait(1).to({scaleX:0.3629,scaleY:0.3398,x:226.3,y:111.95},0).wait(1).to({scaleX:0.3616,scaleY:0.3384,x:226.2,y:112.2},0).wait(1).to({scaleX:0.3605,scaleY:0.3372,x:226.1,y:112.4},0).wait(1).to({scaleX:0.3596,scaleY:0.3362,x:226.05,y:112.55},0).wait(1).to({scaleX:0.3589,scaleY:0.3354,x:225.95,y:112.75},0).wait(1).to({scaleX:0.3583,scaleY:0.3348,x:225.9,y:112.85},0).wait(1).to({scaleX:0.3579,scaleY:0.3343,x:225.85,y:112.95},0).wait(1).to({scaleX:0.3577,scaleY:0.3341},0).wait(1).to({regX:71,regY:48.4,scaleX:0.3576,scaleY:0.334,x:225.9,y:113},0).wait(79));

	// icon
	this.icon = new lib.WordIcon();
	this.icon.name = "icon";
	this.icon.setTransform(54.35,135.65,0.2637,0.2637,0,0,0,225.1,236.7);

	this.timeline.addTween(cjs.Tween.get(this.icon).wait(70).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(11).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(1).to({regX:225.3,regY:236.4,x:54.4,y:135.6},0).wait(58).to({regX:225.1,regY:236.7,x:54.35,y:135.65},0).wait(79));

	// title.png
	this.title = new lib.title_1();
	this.title.name = "title";
	this.title.setTransform(125.4,140.2,1,1,0,0,0,37.9,15.1);

	this.timeline.addTween(cjs.Tween.get(this.title).wait(17).to({regY:15.2,scaleX:0.7599,scaleY:0.7599,x:107.45,y:147.55},28,cjs.Ease.quadInOut).wait(25).to({regX:38,regY:15.3,x:107.55,y:147.65},0).wait(11).to({regX:37.9,regY:15.2,x:107.45,y:147.55},0).wait(1).to({regX:38,regY:15.3,x:107.55,y:147.65},0).wait(58).to({regX:37.9,regY:15.2,x:107.45,y:147.55},0).wait(79));

	// title shadow.png
	this.title_s = new lib.titleshadow_1();
	this.title_s.name = "title_s";
	this.title_s.setTransform(120.3,143.35,1,1,0,0,0,37.6,15.6);

	this.timeline.addTween(cjs.Tween.get(this.title_s).wait(17).to({regX:37.7,regY:15.7,scaleX:0.7718,scaleY:0.7718,x:107.45,y:147.55},28,cjs.Ease.quadInOut).to({alpha:0},24,cjs.Ease.quadOut).to({_off:true},1).wait(149));

	// first image
	this.instance_15 = new lib.firstimage_1();
	this.instance_15.setTransform(234.9,125.55,0.7473,0.7473,0,0,0,41.9,26.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(23).to({regX:42,regY:26.6,scaleX:0.576,scaleY:0.576,x:238.05,y:134.35},30,cjs.Ease.quadInOut).wait(17).to({regY:26.5,y:134.3},0).wait(11).to({regY:26.6,y:134.35},0).wait(1).to({regY:26.5,y:134.3},0).wait(58).to({regY:26.6,y:134.35},0).wait(79));

	// square shadow
	this.instance_16 = new lib.squareshadow();
	this.instance_16.setTransform(233.35,129.15,0.4651,0.4621,0,0,0,71,48);
	this.instance_16.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(23).to({regX:71.3,regY:48.2,scaleX:0.325,scaleY:0.3131,x:237.85,y:134.45},30,cjs.Ease.quadInOut).to({_off:true},1).wait(165));

	// second image
	this.instance_17 = new lib.secondimage_1();
	this.instance_17.setTransform(249.4,152.25,0.7473,0.7473,0,0,0,41.9,26.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(27).to({regX:42,regY:26.4,scaleX:0.5752,scaleY:0.5752,y:155.4},30,cjs.Ease.quadInOut).wait(13).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(11).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(1).to({regX:42.2,regY:26.5,x:249.5,y:155.45},0).wait(58).to({regX:42,regY:26.4,x:249.4,y:155.4},0).wait(79));

	// square shadow
	this.instance_18 = new lib.squareshadow();
	this.instance_18.setTransform(248.05,156.75,0.4651,0.4621,0,0,0,70.9,48.1);
	this.instance_18.alpha = 0.3086;

	this.timeline.addTween(cjs.Tween.get(this.instance_18).wait(27).to({regX:71.2,regY:48.4,scaleX:0.3475,scaleY:0.2831,x:249.5,y:156},30,cjs.Ease.quadInOut).to({_off:true},1).wait(161));

	// screen
	this.instance_19 = new lib.WordUI();
	this.instance_19.setTransform(178.55,155.6,0.8368,0.8368,0,0,0,151,95.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(70).to({regY:96,y:155.7},0).wait(11).to({regY:95.9,y:155.6},0).wait(1).to({regY:96,y:155.7},0).wait(58).to({regY:95.9,y:155.6},0).wait(79));

	// screen shadow
	this.instance_20 = new lib.shadow_1();
	this.instance_20.setTransform(179.9,132.35,0.888,0.888,0,0,0,180.6,119.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(70).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(11).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(1).to({regX:176.7,regY:127.5,x:176.45,y:139.15},0).wait(58).to({regX:180.6,regY:119.8,x:179.9,y:132.35},0).wait(79));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-391.9,-72.1,1909.3000000000002,395.9);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-29.7,2.3,0.6158,0.5649,0,0,0,13.6,10.7);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("AnIB7IAAj1IORAAIAAD1g");
	this.shape.setTransform(-60.75,2.175);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-106.4,-10.1,91.4,24.6), null);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.8,29.2,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(198.35,278.2,1.1308,1.1308,0,0,0,197,130.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(284.3,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(231.55,552.6,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(319.9,549.7,1.2871,1.2871,0,0,0,0.3,0.4);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Ribbon
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-17.55,-5.2);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,719.15,1,2.3964,0,0,0,150,300.1);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-984.2,0,1825.2,617.5), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		var ribbon = mc.ribbon;
		
		
		
		this.runBanner = function() {
			
			this.tl1 = new TimelineLite();
						
				exportRoot.tl1.from(screen, 1.5, { alpha: 0, x: "+=250",y: "+=250", ease:Power3.easeOut,
					onStart: function() {screen.gotoAndPlay(1);},
					onComplete: function() {exportRoot.tl1.pause();}
				}, "+=0.5");
				
				
				//exportRoot.tl1.to(screen, 1.475, {x: "+=17",y: "+=30",scaleX: 1,scaleY: 1, ease:Quad.easeInOut}, "+=0");
				//exportRoot.tl1.to(screen, 1.5, {x: "-=43",y: "+=0",scaleX: 0.935,scaleY: 0.935, ease:Power3.easeInOut,onStart:function(){ribbon.gotoAndPlay(0);}}, "+=0.1");
				exportRoot.tl1.to(screen, 1.5, {x: "+=13",y: "+=12",scaleX: 1.227,scaleY: 1.227, ease:Quad.easeInOut}, "+=0");
				
				exportRoot.tl1.to(screen, 1.5, {x: "-=0",onStart:function(){ribbon.gotoAndPlay(0);}}, "+=0");
			
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.5");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "+=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "+=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(116.1,294.8,268.20000000000005,322.7);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593010328934", id:"M365_FY21Q1_BTS_USA_300x600_BAN_CoauthorWord_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;