(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_", frames: [[796,188,130,182],[352,202,130,182],[484,202,130,182],[616,224,130,182],[0,235,130,182],[132,235,130,182],[748,372,130,182],[880,372,130,182],[264,386,130,182],[396,386,130,182],[528,408,130,182],[0,419,130,182],[132,419,130,182],[660,556,130,182],[792,556,130,182],[264,570,130,182],[396,592,250,86],[654,0,140,222],[924,556,100,80],[796,0,150,186],[0,603,110,109],[0,0,350,233],[352,0,300,200]]}
];


// symbols:



(lib._0090 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._0092 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib._0094 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib._0096 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib._0098 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib._0100 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib._0102 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib._0104 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib._0106 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib._0108 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib._0110 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib._0112 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib._0114 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib._0116 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib._0118 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib._0120 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.BG_Grass2 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.body300X600 = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.Icon = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.leafA = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.LeafB = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.screenshadow = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.ScreenBGjpgcopy = function() {
	this.initialize(ss["M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.txt_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.txt = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#2F2F2F").s().p("AgiBMQgbgQgLgfQgKgdALgeQALgdAbgRQAbgQAfAEQAfAFAWAXIgWAUQgOgPgVgDQgVgDgSALQgSALgHAUQgHATAGAUQAHAUASALQASALAUgCQAWgDAOgPIAWAVQgWAXggADIgMABQgYAAgVgOg");
	this.shape.setTransform(2.0202,-0.7048,0.8766,0.8766,135.0007);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#2F2F2F").s().p("AgmgTIBNAAIgnAmg");
	this.shape_1.setTransform(-5.3,2.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.2,-7.8,18.4,15.8);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhMtCZNMAAAkyZMCZbAAAMAAAEyZg");
	this.shape.setTransform(0,0.075);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-491,-980.4,982,1961);


(lib.logo_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.screenshadowpicture = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.screenshadow();
	this.instance.setTransform(0,0,1.19,1.19);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.screenshadowpicture, new cjs.Rectangle(0,0,416.5,277.3), null);


(lib.ribbon = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_79 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(79).call(this.frame_79).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_68 = new cjs.Graphics().p("AjoLAIA3gTIGaSuIg3ASg");
	var mask_graphics_69 = new cjs.Graphics().p("As4K5IT3m1IF6S4Iz3G1g");
	var mask_graphics_70 = new cjs.Graphics().p("A0cKyMAjbgMKIFeTBMgjbAMMg");
	var mask_graphics_71 = new cjs.Graphics().p("A6gKuMAv5gQeIFITJMgv5AQeg");
	var mask_graphics_72 = new cjs.Graphics().p("A/PKqMA5ngT0IE4TPMg5nAT0g");
	var mask_graphics_73 = new cjs.Graphics().p("EgiyAKnMBA6gWVIErTTMhA6AWWg");
	var mask_graphics_74 = new cjs.Graphics().p("EglUAKlMBGIgYIIEhTWMhGIAYJg");
	var mask_graphics_75 = new cjs.Graphics().p("EgnBAKjMBJogZVIEbTYMhJoAZXg");
	var mask_graphics_76 = new cjs.Graphics().p("EgoEAKjMBLxgaFIEYTaMhLxAaFg");
	var mask_graphics_77 = new cjs.Graphics().p("EgomAKiMBM3gacIEWTaMhM3Aadg");
	var mask_graphics_78 = new cjs.Graphics().p("EgoyAKiMBNQgalIEVTaMhNQAamg");
	var mask_graphics_79 = new cjs.Graphics().p("Ego0AKdMBNUganIEVTbMhNUAang");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(68).to({graphics:mask_graphics_68,x:-0.4538,y:190.1462}).wait(1).to({graphics:mask_graphics_69,x:59.7933,y:190.5388}).wait(1).to({graphics:mask_graphics_70,x:109.1132,y:190.8607}).wait(1).to({graphics:mask_graphics_71,x:148.6014,y:191.1186}).wait(1).to({graphics:mask_graphics_72,x:179.3524,y:191.3196}).wait(1).to({graphics:mask_graphics_73,x:202.4596,y:191.4708}).wait(1).to({graphics:mask_graphics_74,x:219.0161,y:191.5791}).wait(1).to({graphics:mask_graphics_75,x:230.114,y:191.6517}).wait(1).to({graphics:mask_graphics_76,x:236.8453,y:191.6958}).wait(1).to({graphics:mask_graphics_77,x:240.3019,y:191.7184}).wait(1).to({graphics:mask_graphics_78,x:241.5754,y:191.7268}).wait(1).to({graphics:mask_graphics_79,x:244.6351,y:191.2331}).wait(1));

	// top_orange
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FDE200").s().p("AvElgIesAAI/PLBg");
	this.shape.setTransform(132.0234,325.0216,1.2376,1.2376);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(68).to({_off:false},0).wait(12));

	// top
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FEF000").s().p("EglBAE6MBJrgaJIAYRVMhHIAZKg");
	this.shape_1.setTransform(241.375,227.65);
	this.shape_1._off = true;

	var maskedShapeInstanceList = [this.shape_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(68).to({_off:false},0).wait(12));

	// mask (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_58 = new cjs.Graphics().p("Ab0fwIAFzbIAgAAIgFTbg");
	var mask_1_graphics_59 = new cjs.Graphics().p("AbpfwIAFzbIArAAIgFTbg");
	var mask_1_graphics_60 = new cjs.Graphics().p("AadfwIAIzbIB1AAIgHTbg");
	var mask_1_graphics_61 = new cjs.Graphics().p("AXPfwIANzbIFAAAIgNTbg");
	var mask_1_graphics_62 = new cjs.Graphics().p("AQ+fvIAYzbILJABIgYTbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("AGpfuIApzbIVTACIgqTbg");
	var mask_1_graphics_64 = new cjs.Graphics().p("AnXftIBBzcMAjCAAEIhBTcg");
	var mask_1_graphics_65 = new cjs.Graphics().p("AxsfsIBTzcMAtLAAFIhTTcg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A3+frIBezbMAzVAAFIheTcg");
	var mask_1_graphics_67 = new cjs.Graphics().p("A7LfrIBjzcMA2fAAHIhjTbg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A8XfqIBlzbMA3qAAHIhmTbg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A8tfqIBmzbMA31AAGIhmTbg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:null,x:0,y:0}).wait(58).to({graphics:mask_1_graphics_58,x:181.737,y:203.2391}).wait(1).to({graphics:mask_1_graphics_59,x:181.7462,y:203.2395}).wait(1).to({graphics:mask_1_graphics_60,x:181.8103,y:203.2398}).wait(1).to({graphics:mask_1_graphics_61,x:181.9843,y:203.2408}).wait(1).to({graphics:mask_1_graphics_62,x:182.3231,y:203.2427}).wait(1).to({graphics:mask_1_graphics_63,x:182.8817,y:203.2459}).wait(1).to({graphics:mask_1_graphics_64,x:183.6395,y:203.2502}).wait(1).to({graphics:mask_1_graphics_65,x:184.1981,y:203.2533}).wait(1).to({graphics:mask_1_graphics_66,x:184.5369,y:203.2552}).wait(1).to({graphics:mask_1_graphics_67,x:184.7109,y:203.2562}).wait(1).to({graphics:mask_1_graphics_68,x:184.775,y:203.2566}).wait(1).to({graphics:mask_1_graphics_69,x:180.4565,y:203.2108}).wait(11));

	// bot_orange
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FDE200").s().p("APTmxIDCNZMgkpAAKg");
	this.shape_2.setTransform(243.25,338);
	this.shape_2._off = true;

	var maskedShapeInstanceList = [this.shape_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(58).to({_off:false},0).wait(22));

	// mid
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FEF000").s().p("A8NoLMA1ZgABIDCQTMg1TAAGg");
	this.shape_3.setTransform(176.025,328.95);
	this.shape_3._off = true;

	var maskedShapeInstanceList = [this.shape_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_3).wait(58).to({_off:false},0).wait(22));

	// mask (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_29 = new cjs.Graphics().p("A3icnIDShIIHHU/IjRBIg");
	var mask_2_graphics_30 = new cjs.Graphics().p("A3ecgIJ3jZIG8VDIp3DZg");
	var mask_2_graphics_31 = new cjs.Graphics().p("A3bcaIQZlpIGxVHIwZFog");
	var mask_2_graphics_32 = new cjs.Graphics().p("A3YcTIW0n2IGkVLI2yH2g");
	var mask_2_graphics_33 = new cjs.Graphics().p("A3UcNIdAp/IGbVOI9BJ/g");
	var mask_2_graphics_34 = new cjs.Graphics().p("A3RcHMAjAgMDIGQVSMgjAAMDg");
	var mask_2_graphics_35 = new cjs.Graphics().p("A3ZcBMAotgOBIGGVWMgotAOBg");
	var mask_2_graphics_36 = new cjs.Graphics().p("A6Bb8MAuGgP4IF9VZMguGAP4g");
	var mask_2_graphics_37 = new cjs.Graphics().p("A8eb3MAzJgRnIF0VcMgzJARmg");
	var mask_2_graphics_38 = new cjs.Graphics().p("A+wbyMA31gTOIFsVfMg31ATOg");
	var mask_2_graphics_39 = new cjs.Graphics().p("Egg3AbuMA8LgUuIFkVhMg8LAUug");
	var mask_2_graphics_40 = new cjs.Graphics().p("Egi0AbqMBAMgWGIFdVjMhAMAWGg");
	var mask_2_graphics_41 = new cjs.Graphics().p("EgknAbmMBD4gXXIFXVmMhD4AXXg");
	var mask_2_graphics_42 = new cjs.Graphics().p("EgmQAbjMBHQgYiIFRVoMhHQAYhg");
	var mask_2_graphics_43 = new cjs.Graphics().p("EgnwAbfMBKVgZlIFMVpMhKVAZmg");
	var mask_2_graphics_44 = new cjs.Graphics().p("EgpIAbdMBNKgakIFHVrMhNKAakg");
	var mask_2_graphics_45 = new cjs.Graphics().p("EgqZAbaMBPwgbcIFDVsMhPwAbdg");
	var mask_2_graphics_46 = new cjs.Graphics().p("EgriAbYMBSHgcRIE+VuMhSHAcRg");
	var mask_2_graphics_47 = new cjs.Graphics().p("EgslAbVMBURgc/IE6VuMhURAdBg");
	var mask_2_graphics_48 = new cjs.Graphics().p("EgtjAbTMBWQgdrIE3VwMhWQAdsg");
	var mask_2_graphics_49 = new cjs.Graphics().p("EgubAbSMBYDgeTIE0VxMhYDAeUg");
	var mask_2_graphics_50 = new cjs.Graphics().p("EgvOAbQMBZsge3IExVyMhZsAe4g");
	var mask_2_graphics_51 = new cjs.Graphics().p("Egv8AbPMBbLgfYIEuVyMhbLAfZg");
	var mask_2_graphics_52 = new cjs.Graphics().p("EgwnAbNMBcjgf2IEsV0MhcjAf3g");
	var mask_2_graphics_53 = new cjs.Graphics().p("EgxNAbMMBdxggRIEqV0MhdxAgSg");
	var mask_2_graphics_54 = new cjs.Graphics().p("EgxwAbLMBe5ggqIEoV1Mhe5Agrg");
	var mask_2_graphics_55 = new cjs.Graphics().p("EgyQAbKMBf7ghBIEmV2Mhf7AhBg");
	var mask_2_graphics_56 = new cjs.Graphics().p("EgytAbJMBg2ghVIElV2Mhg2AhWg");
	var mask_2_graphics_57 = new cjs.Graphics().p("EgzHAbIMBhsghnIEjV2MhhsAhpg");
	var mask_2_graphics_58 = new cjs.Graphics().p("EgzeAbHMBibgh4IEiV4MhibAh4g");
	var mask_2_graphics_59 = new cjs.Graphics().p("EgzzAbHMBjGgiHIEhV4MhjGAiHg");
	var mask_2_graphics_60 = new cjs.Graphics().p("Eg0GAbGMBjtgiUIEgV4MhjtAiVg");
	var mask_2_graphics_61 = new cjs.Graphics().p("Eg0WAbFMBkPgigIEeV4MhkPAihg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:null,x:0,y:0}).wait(29).to({graphics:mask_2_graphics_29,x:-150.6661,y:317.3771}).wait(1).to({graphics:mask_2_graphics_30,x:-150.3289,y:317.1112}).wait(1).to({graphics:mask_2_graphics_31,x:-149.9949,y:316.8479}).wait(1).to({graphics:mask_2_graphics_32,x:-149.6672,y:316.5896}).wait(1).to({graphics:mask_2_graphics_33,x:-149.3487,y:316.3386}).wait(1).to({graphics:mask_2_graphics_34,x:-149.0425,y:316.0971}).wait(1).to({graphics:mask_2_graphics_35,x:-147.6719,y:315.8672}).wait(1).to({graphics:mask_2_graphics_36,x:-130.3589,y:315.6501}).wait(1).to({graphics:mask_2_graphics_37,x:-114.1421,y:315.4467}).wait(1).to({graphics:mask_2_graphics_38,x:-99.0511,y:315.2575}).wait(1).to({graphics:mask_2_graphics_39,x:-85.0816,y:315.0824}).wait(1).to({graphics:mask_2_graphics_40,x:-72.2024,y:314.9209}).wait(1).to({graphics:mask_2_graphics_41,x:-60.3645,y:314.7725}).wait(1).to({graphics:mask_2_graphics_42,x:-49.5073,y:314.6363}).wait(1).to({graphics:mask_2_graphics_43,x:-39.5647,y:314.5117}).wait(1).to({graphics:mask_2_graphics_44,x:-30.4692,y:314.3976}).wait(1).to({graphics:mask_2_graphics_45,x:-22.1544,y:314.2934}).wait(1).to({graphics:mask_2_graphics_46,x:-14.557,y:314.1981}).wait(1).to({graphics:mask_2_graphics_47,x:-7.618,y:314.1111}).wait(1).to({graphics:mask_2_graphics_48,x:-1.2825,y:314.0317}).wait(1).to({graphics:mask_2_graphics_49,x:4.4996,y:313.9592}).wait(1).to({graphics:mask_2_graphics_50,x:9.7738,y:313.8931}).wait(1).to({graphics:mask_2_graphics_51,x:14.5815,y:313.8328}).wait(1).to({graphics:mask_2_graphics_52,x:18.9602,y:313.7779}).wait(1).to({graphics:mask_2_graphics_53,x:22.9436,y:313.728}).wait(1).to({graphics:mask_2_graphics_54,x:26.5623,y:313.6826}).wait(1).to({graphics:mask_2_graphics_55,x:29.8439,y:313.6415}).wait(1).to({graphics:mask_2_graphics_56,x:32.8133,y:313.6042}).wait(1).to({graphics:mask_2_graphics_57,x:35.4932,y:313.5707}).wait(1).to({graphics:mask_2_graphics_58,x:37.904,y:313.5404}).wait(1).to({graphics:mask_2_graphics_59,x:40.0644,y:313.5133}).wait(1).to({graphics:mask_2_graphics_60,x:41.9911,y:313.4892}).wait(1).to({graphics:mask_2_graphics_61,x:44.4247,y:313.3925}).wait(19));

	// bottom
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FEF000").s().p("Egw4AHrMBdyghfID/REMhgQAilg");
	this.shape_4.setTransform(55.425,469.025);
	this.shape_4._off = true;

	var maskedShapeInstanceList = [this.shape_4];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape_4).wait(29).to({_off:false},0).wait(51));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-257.5,0,735.9,634.3);


(lib.rexBody = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.instance = new lib.body300X600();
	this.instance.setTransform(-37.15,-1.35,1.2052,1.2052);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.rexBody, new cjs.Rectangle(-37.1,-1.3,168.7,267.5), null);


(lib.mscopy_white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mscopy_white, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.ms = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#737373").s().p("ARIDTQgXgYAAgyIAAieIhtAAIAAD5IhJAAIAAj5Ig0AAIAAg8IA0AAIAAgrQAAgwAfggQAggfAyAAIAXABIATAEIAAA/IgNgFQgJgDgMAAQgWAAgNAPQgNAPAAAbIAAAlIBtAAIAAhFIBJgXIAABcIBKAAIAAA8IhKAAIAACQQAAAcALAMQAKAMAWAAQAHAAAJgDQALgEAEgDIAAA8QgHAEgQADQgTAEgNAAQguAAgXgZgAIrDBQgqgqAAhJQAAhNArgsQAsgtBNAAQBJAAAoArQApArAABJQAABMgrAsQgsAthKAAQhHAAgsgrgAJjAAQgWAaAAAxQAAAwAWAaQAWAaApAAQAoAAAUgaQAVgZAAgzQAAgygVgYQgWgZgnAAQgoAAgWAagAE7DnQgYgFgQgHIAAhIQASANAZAJQAWAIATAAQAaAAALgHQAMgGAAgRQAAgPgNgKQgMgLgigNQgngQgSgWQgRgVAAghQAAgpAhgbQAigbA1AAQAPAAAVAEQARADARAGIAABGQgOgKgUgHQgUgHgSAAQgVAAgMAIQgLAJAAANQAAAPAKAJQAJAJAjAOQArARASAWQASAXAAAeQAAArgiAbQgiAbg5AAQgQAAgagFgAgiDBQgrgqAAhJQAAhNAsgsQArgtBMAAQBJAAApArQAoAsAABIQAABLgrAtQgrAthLAAQhIAAgpgrgAAUAAQgVAaAAAxQAAAwAVAaQAWAaApAAQAoAAAVgaQAVgZAAgzQAAgxgWgZQgVgZgnAAQgpAAgWAagAoDDAQgrgrAAhDQAAhKAsgwQAsgxBQAAQATAAAWAGQAVAFAMAHIAABGQgRgNgRgGQgSgHgSAAQgrAAgbAbQgaAdAAAvQAAAvAZAaQAaAaArAAQARAAATgIQAUgHAQgMIAABDQgTALgUAEQgYAGgZAAQhEAAgrgsgAkFDkIAAk1IBJAAIAAAxIABAAQAKgZAUgPQAUgOAdAAIAQABIALADIAABKQgEgDgMgFQgMgEgPAAQgbAAgSAWQgTAWAAAwIAACcgAqqDkIAAk1IBJAAIAAE1gAs7DkIAAlSIgBAAIiGFSIgyAAIiJlSIgBAAIAAFSIhFAAIAAmvIBrAAIB8E/IACAAICDk/IBnAAIAAGvgAqkiMQgNgNAAgRQAAgSANgMQANgNASAAQATAAANANQANANAAARQAAASgNAMQgNAMgTAAQgSAAgNgMg");
	this.shape.setTransform(-0.0145,0.0987,0.2986,0.2986);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#737373").s().p("Ah+DKIAAhDQArAcAqAAQArAAAbgWQAbgWAAgmQAAgkgbgVQgbgUgyAAQgWAAgxADIAPjiIDUAAIAAA8IiZAAIgIBsIAmgBQBEAAAlAjQAmAigBA9QAABAgrAnQgqAnhLAAQg/AAgegSg");
	this.shape_1.setTransform(64.1669,0.5765,0.2986,0.2986);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#737373").s().p("AhoCqQgogzAAheQAAhLAXg3QAWg4ArgeQAqgfA2AAQAyAAAaAMIAAA/QgjgSgmAAQgzAAggArQggAtgBBKIACAAQANgYAagPQAagOAcAAQA4AAAiAkQAhAkAAA9QAAApgTAiQgTAigfATQghASgoAAQhDAAgog1gAgxAUQgUAXAAAfQgBAZAKAUQAJAVARANQAQAMAWAAQAhAAATgWQATgXAAgmQAAgngTgWQgTgVgiAAQgeAAgWAUg");
	this.shape_2.setTransform(55.0447,0.4645,0.2986,0.2986);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#737373").s().p("AhWDYQgegHgOgKIAAhEQAUAQAbAJQAcAKAbAAQAoAAAYgUQAYgTAAggQAAgkgcgSQgcgTg0AAIgmAAIAAg5IAkAAQAuAAAYgRQAZgRAAghQAAgegTgRQgUgQgjAAQguAAgnAfIAAhAQASgKAcgIQAbgGAfAAQAmAAAcAOQAeANAPAYQAPAXAAAfQAAAqgWAbQgXAbgpAMIAAAAQAvAGAbAbQAbAbAAApQAAA8grAjQgqAkhJAAQggAAgbgHg");
	this.shape_3.setTransform(45.706,0.4645,0.2986,0.2986);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.ms, new cjs.Rectangle(-36.4,-6.9,104.4,14.100000000000001), null);


(lib.cta_arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(0.1794,0.0354,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.cta_arrow, new cjs.Rectangle(-5.4,-4.1,11.2,8.3), null);


(lib.cta = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.MergedSkylin = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],-128.1,-51.4,0,-128.1,-51.4,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape.setTransform(172.2024,63.4258);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["#61636A","rgba(102,96,101,0)"],[0,1],59,-65.9,0,59,-65.9,88.6).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_1.setTransform(172.2024,63.4258);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["#DE954B","#666065"],[0,1],20.7,54.8,0,20.7,54.8,132.8).s().p("A65J6IAAzzMA1zAAAIAATzg");
	this.shape_2.setTransform(172.2024,71.5759);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MergedSkylin, new cjs.Rectangle(0,0,344.4,135), null);


(lib.aMask = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#33CC00").s().p("A2GFAIAAp/MAsNAAAIAAJ/g");
	this.shape.setTransform(141.5038,32.0005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.aMask, new cjs.Rectangle(0,0,283,64), null);


(lib.logo_box = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(5.6253,5.6753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-5.6749,5.6753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(5.6253,-5.6249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-5.6749,-5.6249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_box, new cjs.Rectangle(-10.8,-10.7,21.6,21.5), null);


(lib.leafB = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.LeafB();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafB, new cjs.Rectangle(0,0,110,109), null);


(lib.leafA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.leafA();
	this.instance.setTransform(0,0,1.32,1.32);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.leafA_1, new cjs.Rectangle(0,0,198,245.5), null);


(lib.Icon_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Icon();
	this.instance.setTransform(1.1,-6.45,1.6,1.6,0.0005);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Icon_1, new cjs.Rectangle(1.1,-6.4,160,128), null);


(lib.grassCover = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(56,69,73,0)","rgba(28,43,39,0.918)","#162125"],[0,0.651,1],-10.3,-100,-10.3,92.4).s().p("A7QPNIAA+ZMA2hAAAIAAeZg");
	this.shape.setTransform(174.475,97.325);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grassCover, new cjs.Rectangle(0,0,349,194.7), null);


(lib.DinoHead = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Dino300x600
	this.instance = new lib._0090();
	this.instance.setTransform(-62.65,14.85);

	this.instance_1 = new lib._0092();
	this.instance_1.setTransform(-62.65,14.85);

	this.instance_2 = new lib._0094();
	this.instance_2.setTransform(-62.65,14.85);

	this.instance_3 = new lib._0096();
	this.instance_3.setTransform(-62.65,14.85);

	this.instance_4 = new lib._0098();
	this.instance_4.setTransform(-62.65,14.85);

	this.instance_5 = new lib._0100();
	this.instance_5.setTransform(-62.65,14.85);

	this.instance_6 = new lib._0102();
	this.instance_6.setTransform(-62.65,14.85);

	this.instance_7 = new lib._0104();
	this.instance_7.setTransform(-62.65,14.85);

	this.instance_8 = new lib._0106();
	this.instance_8.setTransform(-62.65,14.85);

	this.instance_9 = new lib._0108();
	this.instance_9.setTransform(-62.65,14.85);

	this.instance_10 = new lib._0110();
	this.instance_10.setTransform(-62.65,14.85);

	this.instance_11 = new lib._0112();
	this.instance_11.setTransform(-62.65,14.85);

	this.instance_12 = new lib._0114();
	this.instance_12.setTransform(-62.65,14.85);

	this.instance_13 = new lib._0116();
	this.instance_13.setTransform(-62.65,14.85);

	this.instance_14 = new lib._0118();
	this.instance_14.setTransform(-62.65,14.85);

	this.instance_15 = new lib._0120();
	this.instance_15.setTransform(-62.65,14.85);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},2).to({state:[{t:this.instance_2}]},2).to({state:[{t:this.instance_3}]},2).to({state:[{t:this.instance_4}]},2).to({state:[{t:this.instance_5}]},2).to({state:[{t:this.instance_6}]},2).to({state:[{t:this.instance_7}]},2).to({state:[{t:this.instance_8}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_15}]},2).to({state:[{t:this.instance_15}]},24).to({state:[]},1).to({state:[{t:this.instance_15}]},4).to({state:[{t:this.instance_15}]},1).to({state:[{t:this.instance_14}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_10}]},2).to({state:[{t:this.instance_9}]},2).to({state:[{t:this.instance_8}]},3).to({state:[{t:this.instance_9}]},3).to({state:[{t:this.instance_10}]},3).to({state:[{t:this.instance_11}]},2).to({state:[{t:this.instance_12}]},2).to({state:[{t:this.instance_13}]},2).to({state:[{t:this.instance_14}]},2).to({state:[]},1).to({state:[{t:this.instance_15}]},7).wait(7));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(30).to({_off:false},0).wait(24).to({_off:true},1).wait(4).to({_off:false},0).wait(1).to({_off:true},2).wait(35).to({_off:false},0).wait(7));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-62.6,14.9,153.6,182);


(lib.cta_glare = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_9 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(9).call(this.frame_9).wait(1));

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],-125.2,-0.1,-58.4,-0.1).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape.setTransform(57.35,15.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(255,255,255,0)","rgba(255,255,255,0.478)","rgba(255,255,255,0)"],[0,0.51,1],58.5,-0.9,125.3,-0.9).s().p("Ao9CXIAAktIR6AAIAAEtg");
	this.shape_1.setTransform(57.35,15.125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[{t:this.shape_1}]},7).to({state:[]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,30.3);


(lib.bgMounts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#384549").s().p("A4MTYMAAAgjfIgBgWIgEgUIATgFQAUgFADABQARAEAQAAQAIABAOgFQAPgFAJAAQALAAAGAFIAHAJIBSAoIAdACQADgGAHgEQAEgCAdgCIAcAAIARAJIALgFIAiAFIANgRIARAAIAOAJIBKgBIAKAHIBCgDIAJgHIAWACIAKgFIAfAAIAJgFQALgHAIAAQAOAAANAPIAigBIAJgHIAJADIAYAUIATAAIATAOIAWAAIAVAQIABANIANAAIADAOIAVAXIAOACIAAAKIASAHIABAIIALAAIAGAJIANABIgBAMIAKAAIAOAKIABAJIAWAJIAXgUIALgGIAAgIIAjgLIADgJIAUgBIAVATIALAAIAeAcIANgJIATAMQASAAADgCIANgKIAHAIIAJgGIALABIAJgEIARgDIALAKIAFgMIARAAIAHgDIAJADIAbAFIAJAIIAKgHIAKACIAGgRIASgRIAUgEQAEAAATADIA7AAIALgCIAMAGIANAAIAMgIIAQAKIAWAXIATABIAbAWIAMgBIAUATIARACQAEAAAGAFIAHAHIAIANIAfAKIAHAAIAEAHIA3AAIAGgFIAJAEIAeAAIAigoIAIgBIgCgIIAIgJIADgKQAQgJABgEQABgDAEgFIAGgFIAIgDIAAgSQAKADAAgDIgDgRIAIgBIAEgNIALgOQAOgOADgBQAEgCAPgCIATgNIAKABIAFgOIASAAIAAgPIAPgFIAHgKIAGgEQAFgDAEAAIAlACIAKACIAGAIIAdgeIABgNIAMAAIAZgNIAdgIIACgJIAIABIAEgIIALAAIABgJIATgMIACgLIANgCIANgMIABgJIAfgVIAQgGIAFAJIAQACIAXAOIASgTIAMgBIAGgHIAOgBIAOgLIANAAIAHAFIAhgBIAVAKIATgJIAggBQApgCAOADQAOAEAQAKIAmABIAOgJIAQAHIACAHIBWABQAEgBAPgHQAPgIABABQAEACAigCIAFgIIAJgBIAGAGIAWgMIAnAAIAmgJIAOgHIAxAaIgITYIAAS9g");
	this.shape.setTransform(155.4,124);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bgMounts, new cjs.Rectangle(0,0,310.8,248), null);


(lib.bg_sub = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F5F5F5").s().p("EgXbAvCMAAAheDMAu3AAAMAAABeDg");
	this.shape.setTransform(150,301.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.bg_sub, new cjs.Rectangle(0,0,300,602.1), null);


(lib.arrow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYBIIA4g1IiBAAIAAgkICBAAIg5g2IAuAAIBNBHIhNBIg");
	this.shape.setTransform(5.6294,4.1854,0.576,0.576);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.arrow, new cjs.Rectangle(0,0,11.3,8.4), null);


(lib.shadow = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.shadow.cache(-31.6,-11.15,416.5,277.25,1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_2
	this.shadow = new lib.screenshadowpicture();
	this.shadow.name = "shadow";
	this.shadow.setTransform(176.7,127.45,1,1,0,0,0,208.3,138.6);

	this.timeline.addTween(cjs.Tween.get(this.shadow).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.shadow, new cjs.Rectangle(-31.6,-11.1,416.5,277.20000000000005), null);


(lib.replay_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{out:0,over:1,down:2,hit:3});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(4));

	// Layer 6
	this.instance = new lib.Tween7("synched",0);
	this.instance.setTransform(-18.15,16.65,1.754,1.754);
	this.instance.alpha = 0.5;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({x:-18.65,y:16.55,alpha:1},1).to({_off:true},2).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-34.8,0,32.699999999999996,30.6);


(lib.cta_arrowmo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_52 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(52).call(this.frame_52).wait(1));

	// Layer 3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("AhIBJQgegfAAgqQAAgpAegfQAfgeApAAQAqAAAfAeQAeAfAAApQAAAqgeAfQgfAegqAAQgpAAgfgeg");

	// Layer 4
	this.instance = new lib.arrow();
	this.instance.setTransform(-18.15,0.05,1,1,0,0,0,5.6,4.2);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(12).to({_off:false},0).to({x:2.15},8,cjs.Ease.get(1)).wait(1).to({x:2},0).wait(1).to({x:1.35},0).wait(1).to({x:0.4},0).wait(1).to({x:-0.4},0).wait(1).to({x:-0.9},0).wait(1).to({x:-1.05},0).wait(1).to({x:-0.95},0).wait(1).to({x:-0.6},0).wait(1).to({x:-0.15},0).wait(1).to({x:0.25},0).wait(1).to({x:0.5},0).wait(1).to({x:0.55},0).wait(2).to({x:0.4},0).wait(1).to({x:0.25},0).wait(1).to({x:0.1},0).wait(1).to({x:0},0).wait(1).to({x:-0.05},0).wait(1).to({x:0},0).wait(1).to({x:0.05},0).wait(1).to({x:0.1},0).wait(1).to({x:0.15},0).wait(11));

	// Layer 2
	this.instance_1 = new lib.arrow();
	this.instance_1.setTransform(0.15,0.05,1,1,0,0,0,5.6,4.2);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({x:-1.15},8,cjs.Ease.get(1)).wait(2).to({x:19.85},8,cjs.Ease.get(-1)).to({_off:true},1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10.2,-4.1,20.5,8.3);


(lib.MSFT_logo_sq = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.logo_box.cache(-22,-22,44,44,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.logo_box = new lib.logo_box();
	this.logo_box.name = "logo_box";
	this.logo_box.setTransform(-40,1.4);

	this.timeline.addTween(cjs.Tween.get(this.logo_box).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_logo_sq, new cjs.Rectangle(-50.8,-9.3,21.599999999999998,21.5), null);


(lib.MSFT_Logo_anim_White = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.mscopy_white();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim_White, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.MSFT_Logo_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.ms.cache(-105,-16,210,32,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer 1
	this.ms = new lib.ms();
	this.ms.name = "ms";
	this.ms.setTransform(13.65,1.05);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FEBA00").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape.setTransform(-34.3747,7.0753);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#03A5EA").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_1.setTransform(-45.6749,7.0753);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#7CBB01").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_2.setTransform(-34.3747,-4.2249);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F25022").s().p("AgyAzIAAhlIBlAAIAABlg");
	this.shape_3.setTransform(-45.6749,-4.2249);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.ms}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.MSFT_Logo_anim, new cjs.Rectangle(-50.8,-9.3,132.39999999999998,21.5), null);


(lib.logos = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}
	this.frame_59 = function() {
		exportRoot.tl1.play();
	}
	this.frame_100 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(59).call(this.frame_59).wait(41).call(this.frame_100).wait(1));

	// Layer_2
	this.instance = new lib.MSFT_logo_sq();
	this.instance.setTransform(298.45,901.15,0.2981,0.2981,0,0,0,-39.9,1.5);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({_off:false},0).to({regX:-40,regY:1.4,scaleX:4.9325,scaleY:4.9325,x:298.4},13,cjs.Ease.quadOut).to({x:24.15},12,cjs.Ease.quadInOut).to({_off:true},1).wait(74));

	// WhiteLogo
	this.instance_1 = new lib.MSFT_Logo_anim_White();
	this.instance_1.setTransform(222.05,895.25,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.msoftLogoWhite = new lib.MSFT_Logo_anim_White();
	this.msoftLogoWhite.name = "msoftLogoWhite";
	this.msoftLogoWhite.setTransform(39.9,60.45,2.4148,2.4148,0,0,0,-0.1,0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},59).to({state:[{t:this.msoftLogoWhite}]},41).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(59).to({_off:false},0).to({_off:true,regX:-0.1,regY:0.4,scaleX:2.4148,scaleY:2.4148,x:39.9,y:60.45,alpha:1},41,cjs.Ease.quadInOut).wait(1));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_14 = new cjs.Graphics().p("EgSYBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_15 = new cjs.Graphics().p("EgSrBKjIAAwoMBbtAAAIAAQog");
	var mask_graphics_16 = new cjs.Graphics().p("EgTlBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_17 = new cjs.Graphics().p("EgVEBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_18 = new cjs.Graphics().p("EgXJBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_19 = new cjs.Graphics().p("EgZ1BKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_20 = new cjs.Graphics().p("EgdHBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_21 = new cjs.Graphics().p("EggYBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_22 = new cjs.Graphics().p("EgjEBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_23 = new cjs.Graphics().p("EglJBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_24 = new cjs.Graphics().p("EgmoBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_25 = new cjs.Graphics().p("EgniBKjIAAwoMBbuAAAIAAQog");
	var mask_graphics_26 = new cjs.Graphics().p("Egn1BKjIAAwoMBbuAAAIAAQog");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(14).to({graphics:mask_graphics_14,x:469.3539,y:477.1095}).wait(1).to({graphics:mask_graphics_15,x:467.448,y:477.1095}).wait(1).to({graphics:mask_graphics_16,x:461.7303,y:477.1095}).wait(1).to({graphics:mask_graphics_17,x:452.2008,y:477.1095}).wait(1).to({graphics:mask_graphics_18,x:438.8594,y:477.1095}).wait(1).to({graphics:mask_graphics_19,x:421.7063,y:477.1095}).wait(1).to({graphics:mask_graphics_20,x:400.7414,y:477.1095}).wait(1).to({graphics:mask_graphics_21,x:379.7765,y:477.1095}).wait(1).to({graphics:mask_graphics_22,x:362.6233,y:477.1095}).wait(1).to({graphics:mask_graphics_23,x:349.282,y:477.1095}).wait(1).to({graphics:mask_graphics_24,x:339.7525,y:477.1095}).wait(1).to({graphics:mask_graphics_25,x:334.0348,y:477.1095}).wait(1).to({graphics:mask_graphics_26,x:332.1289,y:477.1095}).wait(1).to({graphics:null,x:0,y:0}).wait(74));

	// Layer 3
	this.instance_2 = new lib.MSFT_Logo_anim();
	this.instance_2.setTransform(-132.35,895.25,4.9325,4.9325,0,0,0,0.1,0.2);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(14).to({_off:false},0).to({x:222.05},12,cjs.Ease.quadInOut).wait(33).to({regX:-0.1,regY:0.4,scaleX:2.4148,scaleY:2.4148,x:39.9,y:60.45},41,cjs.Ease.quadInOut).wait(1));

	// Layer_5
	this.instance_3 = new lib.Tween1("synched",0);
	this.instance_3.setTransform(299.85,903.15);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({startPosition:0},59).to({alpha:0},41,cjs.Ease.cubicInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-191.1,-77.2,982,1960.9);


(lib.grass = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// gradient
	this.instance = new lib.grassCover();
	this.instance.setTransform(186.7,102.45,1,1,0,0,0,174.5,97.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// GrassFront
	this.instance_1 = new lib.BG_Grass2();
	this.instance_1.setTransform(11.85,4.65,1.3923,1.3923);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// GrassBuildout
	this.instance_2 = new lib.BG_Grass2();
	this.instance_2.setTransform(117.7,215.25,1.4352,1.2579,0,180,0);

	this.instance_3 = new lib.BG_Grass2();
	this.instance_3.setTransform(16.75,67.95,1.4352,1.2579,0,-90,90);

	this.instance_4 = new lib.BG_Grass2();
	this.instance_4.setTransform(15.9,92.3,1.4352,1.2579);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.grass, new cjs.Rectangle(11.9,4.7,464.6,422.1), null);


(lib.BG_gray = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		this.bg.cache(0,0,300,600,2)
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.bg = new lib.bg_sub();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BG_gray, new cjs.Rectangle(0,0,300,602.1), null);


(lib.arrowMain = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(2));

	// Layer 1
	this.arrow = new lib.cta_arrow();
	this.arrow.name = "arrow";
	this.arrow.setTransform(10.75,10.75);

	this.arrow_1 = new lib.cta_arrowmo();
	this.arrow_1.name = "arrow_1";
	this.arrow_1.setTransform(10.75,10.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.arrow}]}).to({state:[{t:this.arrow_1}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.5,0.5,20.5,20.5);


(lib.CTA_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 3
	this.arrow = new lib.arrowMain();
	this.arrow.name = "arrow";
	this.arrow.setTransform(-18.1,0.55,0.6954,0.638,0,0,0,13.5,10.8);

	this.timeline.addTween(cjs.Tween.get(this.arrow).wait(1));

	// CTA_text
	this.cta_glare = new lib.cta_glare();
	this.cta_glare.name = "cta_glare";
	this.cta_glare.setTransform(-42.75,-2.45,1,1,0,0,0,57.4,15.1);

	this.timeline.addTween(cjs.Tween.get(this.cta_glare).wait(1));

	// bg
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#0078D7").s().p("AoKCMIAAkXIQVAAIAAEXg");
	this.shape.setTransform(-51.4,0.15);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA_btn, new cjs.Rectangle(-103.7,-13.8,104.60000000000001,28), null);


(lib.MainScreen = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// ScreenMaskA (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_graphics_79 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_graphics_80 = new cjs.Graphics().p("EgXdAu3MAAAhdtMAu7AAAMAAABdtg");
	var mask_graphics_81 = new cjs.Graphics().p("EgXbAunMAAAhdNMAu3AAAMAAABdNg");
	var mask_graphics_82 = new cjs.Graphics().p("EgXVAuNMAAAhcZMAuxAAAMAAABcZg");
	var mask_graphics_83 = new cjs.Graphics().p("EgXMAtoMAAAhbPMAuoAAAMAAABbPg");
	var mask_graphics_84 = new cjs.Graphics().p("EgXBAs4MAAAhZvMAucAAAMAAABZvg");
	var mask_graphics_85 = new cjs.Graphics().p("EgWzAr+MAAAhX7MAuNAAAMAAABX7g");
	var mask_graphics_86 = new cjs.Graphics().p("EgWiAq6MAAAhVzMAt7AAAMAAABVzg");
	var mask_graphics_87 = new cjs.Graphics().p("EgWQAprMAAAhTVMAtoAAAMAAABTVg");
	var mask_graphics_88 = new cjs.Graphics().p("EgV6AoRMAAAhQhMAtRAAAMAAABQhg");
	var mask_graphics_89 = new cjs.Graphics().p("EgViAmtMAAAhNZMAs4AAAMAAABNZg");
	var mask_graphics_90 = new cjs.Graphics().p("EgVIAk+MAAAhJ7MAsdAAAMAAABJ7g");
	var mask_graphics_91 = new cjs.Graphics().p("EgUrAjFMAAAhGJMAr+AAAMAAABGJg");
	var mask_graphics_92 = new cjs.Graphics().p("EgULAhBMAAAhCBMArdAAAMAAABCBg");
	var mask_graphics_93 = new cjs.Graphics().p("AzpeyMAAAg9jMAq5AAAMAAAA9jg");
	var mask_graphics_94 = new cjs.Graphics().p("AzFcZMAAAg4xMAqTAAAMAAAA4xg");
	var mask_graphics_95 = new cjs.Graphics().p("AygaAMAAAgz/MApsAAAMAAAAz/g");
	var mask_graphics_96 = new cjs.Graphics().p("Ax+XyMAAAgvjMApIAAAMAAAAvjg");
	var mask_graphics_97 = new cjs.Graphics().p("AxfVuMAAAgrbMAooAAAMAAAArbg");
	var mask_graphics_98 = new cjs.Graphics().p("AxCT1MAAAgnpMAoJAAAMAAAAnpg");
	var mask_graphics_99 = new cjs.Graphics().p("AwoS3MAAAgkKMAnuAAAMAAAAkKg");
	var mask_graphics_100 = new cjs.Graphics().p("AwQSGMAAAghCMAnVAAAMAAAAhCg");
	var mask_graphics_101 = new cjs.Graphics().p("Av6RaIAA+PMAm9AAAIAAePg");
	var mask_graphics_102 = new cjs.Graphics().p("AvnQyIAA7wMAmpAAAIAAbwg");
	var mask_graphics_103 = new cjs.Graphics().p("AvXQRIAA5oMAmZAAAIAAZog");
	var mask_graphics_104 = new cjs.Graphics().p("AvJP0IAA3zMAmKAAAIAAXzg");
	var mask_graphics_105 = new cjs.Graphics().p("Au+PcIAA2UMAl+AAAIAAWUg");
	var mask_graphics_106 = new cjs.Graphics().p("Au1PKIAA1KMAl1AAAIAAVKg");
	var mask_graphics_107 = new cjs.Graphics().p("AuvO9IAA0WMAlvAAAIAAUWg");
	var mask_graphics_108 = new cjs.Graphics().p("AurO1IAAz2MAlqAAAIAAT2g");
	var mask_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:149.8293,y:123.417}).wait(79).to({graphics:mask_graphics_79,x:149.8293,y:123.417}).wait(1).to({graphics:mask_graphics_80,x:149.8825,y:123.4235}).wait(1).to({graphics:mask_graphics_81,x:150.0283,y:123.4428}).wait(1).to({graphics:mask_graphics_82,x:149.9958,y:123.4752}).wait(1).to({graphics:mask_graphics_83,x:149.9502,y:123.5204}).wait(1).to({graphics:mask_graphics_84,x:149.8917,y:123.5786}).wait(1).to({graphics:mask_graphics_85,x:149.8201,y:123.6497}).wait(1).to({graphics:mask_graphics_86,x:149.7356,y:123.7337}).wait(1).to({graphics:mask_graphics_87,x:149.638,y:123.8307}).wait(1).to({graphics:mask_graphics_88,x:149.5274,y:123.9406}).wait(1).to({graphics:mask_graphics_89,x:149.4038,y:124.0634}).wait(1).to({graphics:mask_graphics_90,x:149.2672,y:124.1992}).wait(1).to({graphics:mask_graphics_91,x:149.1175,y:124.3479}).wait(1).to({graphics:mask_graphics_92,x:148.9549,y:124.5095}).wait(1).to({graphics:mask_graphics_93,x:148.7792,y:124.684}).wait(1).to({graphics:mask_graphics_94,x:148.5906,y:124.8715}).wait(1).to({graphics:mask_graphics_95,x:148.4019,y:125.0589}).wait(1).to({graphics:mask_graphics_96,x:148.2263,y:125.2335}).wait(1).to({graphics:mask_graphics_97,x:148.0636,y:125.3951}).wait(1).to({graphics:mask_graphics_98,x:147.914,y:125.5438}).wait(1).to({graphics:mask_graphics_99,x:147.7774,y:120.7295}).wait(1).to({graphics:mask_graphics_100,x:147.6538,y:115.7794}).wait(1).to({graphics:mask_graphics_101,x:147.5432,y:111.3502}).wait(1).to({graphics:mask_graphics_102,x:147.4456,y:107.4422}).wait(1).to({graphics:mask_graphics_103,x:147.361,y:104.0552}).wait(1).to({graphics:mask_graphics_104,x:147.2895,y:101.1894}).wait(1).to({graphics:mask_graphics_105,x:147.2309,y:98.8445}).wait(1).to({graphics:mask_graphics_106,x:147.1854,y:97.0208}).wait(1).to({graphics:mask_graphics_107,x:147.1529,y:95.7181}).wait(1).to({graphics:mask_graphics_108,x:147.1333,y:94.9365}).wait(1).to({graphics:mask_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_graphics_135,x:147.1518,y:94.651}).wait(41));

	// LeafA
	this.instance = new lib.leafA_1();
	this.instance.setTransform(112,-24.3,1.2828,1.2828,0,0,0,99,122.7);

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({regY:122.8,scaleX:0.6362,scaleY:0.6362,x:58.25,y:128.95},30,cjs.Ease.quadInOut).wait(67));

	// ScreenMaskA copy 2 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_1_graphics_79 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_1_graphics_80 = new cjs.Graphics().p("EgXdAu3MAAAhdtMAu7AAAMAAABdtg");
	var mask_1_graphics_81 = new cjs.Graphics().p("EgXbAunMAAAhdNMAu3AAAMAAABdNg");
	var mask_1_graphics_82 = new cjs.Graphics().p("EgXVAuNMAAAhcZMAuxAAAMAAABcZg");
	var mask_1_graphics_83 = new cjs.Graphics().p("EgXMAtoMAAAhbPMAuoAAAMAAABbPg");
	var mask_1_graphics_84 = new cjs.Graphics().p("EgXBAs4MAAAhZvMAucAAAMAAABZvg");
	var mask_1_graphics_85 = new cjs.Graphics().p("EgWzAr+MAAAhX7MAuNAAAMAAABX7g");
	var mask_1_graphics_86 = new cjs.Graphics().p("EgWiAq6MAAAhVzMAt7AAAMAAABVzg");
	var mask_1_graphics_87 = new cjs.Graphics().p("EgWQAprMAAAhTVMAtoAAAMAAABTVg");
	var mask_1_graphics_88 = new cjs.Graphics().p("EgV6AoRMAAAhQhMAtRAAAMAAABQhg");
	var mask_1_graphics_89 = new cjs.Graphics().p("EgViAmtMAAAhNZMAs4AAAMAAABNZg");
	var mask_1_graphics_90 = new cjs.Graphics().p("EgVIAk+MAAAhJ7MAsdAAAMAAABJ7g");
	var mask_1_graphics_91 = new cjs.Graphics().p("EgUrAjFMAAAhGJMAr+AAAMAAABGJg");
	var mask_1_graphics_92 = new cjs.Graphics().p("EgULAhBMAAAhCBMArdAAAMAAABCBg");
	var mask_1_graphics_93 = new cjs.Graphics().p("AzpeyMAAAg9jMAq5AAAMAAAA9jg");
	var mask_1_graphics_94 = new cjs.Graphics().p("AzFcZMAAAg4xMAqTAAAMAAAA4xg");
	var mask_1_graphics_95 = new cjs.Graphics().p("AygaAMAAAgz/MApsAAAMAAAAz/g");
	var mask_1_graphics_96 = new cjs.Graphics().p("Ax+XyMAAAgvjMApIAAAMAAAAvjg");
	var mask_1_graphics_97 = new cjs.Graphics().p("AxfVuMAAAgrbMAooAAAMAAAArbg");
	var mask_1_graphics_98 = new cjs.Graphics().p("AxCT1MAAAgnpMAoJAAAMAAAAnpg");
	var mask_1_graphics_99 = new cjs.Graphics().p("AwoS3MAAAgkKMAnuAAAMAAAAkKg");
	var mask_1_graphics_100 = new cjs.Graphics().p("AwQSGMAAAghCMAnVAAAMAAAAhCg");
	var mask_1_graphics_101 = new cjs.Graphics().p("Av6RaIAA+PMAm9AAAIAAePg");
	var mask_1_graphics_102 = new cjs.Graphics().p("AvnQyIAA7wMAmpAAAIAAbwg");
	var mask_1_graphics_103 = new cjs.Graphics().p("AvXQRIAA5oMAmZAAAIAAZog");
	var mask_1_graphics_104 = new cjs.Graphics().p("AvJP0IAA3zMAmKAAAIAAXzg");
	var mask_1_graphics_105 = new cjs.Graphics().p("Au+PcIAA2UMAl+AAAIAAWUg");
	var mask_1_graphics_106 = new cjs.Graphics().p("Au1PKIAA1KMAl1AAAIAAVKg");
	var mask_1_graphics_107 = new cjs.Graphics().p("AuvO9IAA0WMAlvAAAIAAUWg");
	var mask_1_graphics_108 = new cjs.Graphics().p("AurO1IAAz2MAlqAAAIAAT2g");
	var mask_1_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_1_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:149.8293,y:123.417}).wait(79).to({graphics:mask_1_graphics_79,x:149.8293,y:123.417}).wait(1).to({graphics:mask_1_graphics_80,x:149.8825,y:123.4235}).wait(1).to({graphics:mask_1_graphics_81,x:150.0283,y:123.4428}).wait(1).to({graphics:mask_1_graphics_82,x:149.9958,y:123.4752}).wait(1).to({graphics:mask_1_graphics_83,x:149.9502,y:123.5204}).wait(1).to({graphics:mask_1_graphics_84,x:149.8917,y:123.5786}).wait(1).to({graphics:mask_1_graphics_85,x:149.8201,y:123.6497}).wait(1).to({graphics:mask_1_graphics_86,x:149.7356,y:123.7337}).wait(1).to({graphics:mask_1_graphics_87,x:149.638,y:123.8307}).wait(1).to({graphics:mask_1_graphics_88,x:149.5274,y:123.9406}).wait(1).to({graphics:mask_1_graphics_89,x:149.4038,y:124.0634}).wait(1).to({graphics:mask_1_graphics_90,x:149.2672,y:124.1992}).wait(1).to({graphics:mask_1_graphics_91,x:149.1175,y:124.3479}).wait(1).to({graphics:mask_1_graphics_92,x:148.9549,y:124.5095}).wait(1).to({graphics:mask_1_graphics_93,x:148.7792,y:124.684}).wait(1).to({graphics:mask_1_graphics_94,x:148.5906,y:124.8715}).wait(1).to({graphics:mask_1_graphics_95,x:148.4019,y:125.0589}).wait(1).to({graphics:mask_1_graphics_96,x:148.2263,y:125.2335}).wait(1).to({graphics:mask_1_graphics_97,x:148.0636,y:125.3951}).wait(1).to({graphics:mask_1_graphics_98,x:147.914,y:125.5438}).wait(1).to({graphics:mask_1_graphics_99,x:147.7774,y:120.7295}).wait(1).to({graphics:mask_1_graphics_100,x:147.6538,y:115.7793}).wait(1).to({graphics:mask_1_graphics_101,x:147.5432,y:111.3502}).wait(1).to({graphics:mask_1_graphics_102,x:147.4456,y:107.4422}).wait(1).to({graphics:mask_1_graphics_103,x:147.361,y:104.0552}).wait(1).to({graphics:mask_1_graphics_104,x:147.2895,y:101.1894}).wait(1).to({graphics:mask_1_graphics_105,x:147.2309,y:98.8445}).wait(1).to({graphics:mask_1_graphics_106,x:147.1854,y:97.0208}).wait(1).to({graphics:mask_1_graphics_107,x:147.1529,y:95.7181}).wait(1).to({graphics:mask_1_graphics_108,x:147.1333,y:94.9365}).wait(1).to({graphics:mask_1_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_1_graphics_135,x:147.1518,y:94.651}).wait(41));

	// LeafB
	this.instance_1 = new lib.leafB();
	this.instance_1.setTransform(220.15,-98.65,1.4905,1.4905,0,0,0,55.1,54.5);

	var maskedShapeInstanceList = [this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_1;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(79).to({regY:54.6,scaleX:0.6995,scaleY:0.6995,x:255.85,y:101.15},30,cjs.Ease.quadInOut).wait(67));

	// ScreenMaskA copy (mask)
	var mask_2 = new cjs.Shape();
	mask_2._off = true;
	var mask_2_graphics_0 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_2_graphics_79 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_2_graphics_80 = new cjs.Graphics().p("EgXdAu3MAAAhdtMAu7AAAMAAABdtg");
	var mask_2_graphics_81 = new cjs.Graphics().p("EgXbAunMAAAhdNMAu3AAAMAAABdNg");
	var mask_2_graphics_82 = new cjs.Graphics().p("EgXVAuNMAAAhcZMAuxAAAMAAABcZg");
	var mask_2_graphics_83 = new cjs.Graphics().p("EgXMAtoMAAAhbPMAuoAAAMAAABbPg");
	var mask_2_graphics_84 = new cjs.Graphics().p("EgXBAs4MAAAhZvMAucAAAMAAABZvg");
	var mask_2_graphics_85 = new cjs.Graphics().p("EgWzAr+MAAAhX7MAuNAAAMAAABX7g");
	var mask_2_graphics_86 = new cjs.Graphics().p("EgWiAq6MAAAhVzMAt7AAAMAAABVzg");
	var mask_2_graphics_87 = new cjs.Graphics().p("EgWQAprMAAAhTVMAtoAAAMAAABTVg");
	var mask_2_graphics_88 = new cjs.Graphics().p("EgV6AoRMAAAhQhMAtRAAAMAAABQhg");
	var mask_2_graphics_89 = new cjs.Graphics().p("EgViAmtMAAAhNZMAs4AAAMAAABNZg");
	var mask_2_graphics_90 = new cjs.Graphics().p("EgVIAk+MAAAhJ7MAsdAAAMAAABJ7g");
	var mask_2_graphics_91 = new cjs.Graphics().p("EgUrAjFMAAAhGJMAr+AAAMAAABGJg");
	var mask_2_graphics_92 = new cjs.Graphics().p("EgULAhBMAAAhCBMArdAAAMAAABCBg");
	var mask_2_graphics_93 = new cjs.Graphics().p("AzpeyMAAAg9jMAq5AAAMAAAA9jg");
	var mask_2_graphics_94 = new cjs.Graphics().p("AzFcZMAAAg4xMAqTAAAMAAAA4xg");
	var mask_2_graphics_95 = new cjs.Graphics().p("AygaAMAAAgz/MApsAAAMAAAAz/g");
	var mask_2_graphics_96 = new cjs.Graphics().p("Ax+XyMAAAgvjMApIAAAMAAAAvjg");
	var mask_2_graphics_97 = new cjs.Graphics().p("AxfVuMAAAgrbMAooAAAMAAAArbg");
	var mask_2_graphics_98 = new cjs.Graphics().p("AxCT1MAAAgnpMAoJAAAMAAAAnpg");
	var mask_2_graphics_99 = new cjs.Graphics().p("AwoS3MAAAgkKMAnuAAAMAAAAkKg");
	var mask_2_graphics_100 = new cjs.Graphics().p("AwQSGMAAAghCMAnVAAAMAAAAhCg");
	var mask_2_graphics_101 = new cjs.Graphics().p("Av6RaIAA+PMAm9AAAIAAePg");
	var mask_2_graphics_102 = new cjs.Graphics().p("AvnQyIAA7wMAmpAAAIAAbwg");
	var mask_2_graphics_103 = new cjs.Graphics().p("AvXQRIAA5oMAmZAAAIAAZog");
	var mask_2_graphics_104 = new cjs.Graphics().p("AvJP0IAA3zMAmKAAAIAAXzg");
	var mask_2_graphics_105 = new cjs.Graphics().p("Au+PcIAA2UMAl+AAAIAAWUg");
	var mask_2_graphics_106 = new cjs.Graphics().p("Au1PKIAA1KMAl1AAAIAAVKg");
	var mask_2_graphics_107 = new cjs.Graphics().p("AuvO9IAA0WMAlvAAAIAAUWg");
	var mask_2_graphics_108 = new cjs.Graphics().p("AurO1IAAz2MAlqAAAIAAT2g");
	var mask_2_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_2_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_2).to({graphics:mask_2_graphics_0,x:149.8293,y:123.417}).wait(79).to({graphics:mask_2_graphics_79,x:149.8293,y:123.417}).wait(1).to({graphics:mask_2_graphics_80,x:149.8825,y:123.4235}).wait(1).to({graphics:mask_2_graphics_81,x:150.0283,y:123.4428}).wait(1).to({graphics:mask_2_graphics_82,x:149.9958,y:123.4752}).wait(1).to({graphics:mask_2_graphics_83,x:149.9502,y:123.5204}).wait(1).to({graphics:mask_2_graphics_84,x:149.8917,y:123.5786}).wait(1).to({graphics:mask_2_graphics_85,x:149.8201,y:123.6497}).wait(1).to({graphics:mask_2_graphics_86,x:149.7356,y:123.7337}).wait(1).to({graphics:mask_2_graphics_87,x:149.638,y:123.8307}).wait(1).to({graphics:mask_2_graphics_88,x:149.5274,y:123.9406}).wait(1).to({graphics:mask_2_graphics_89,x:149.4038,y:124.0634}).wait(1).to({graphics:mask_2_graphics_90,x:149.2672,y:124.1992}).wait(1).to({graphics:mask_2_graphics_91,x:149.1175,y:124.3479}).wait(1).to({graphics:mask_2_graphics_92,x:148.9549,y:124.5095}).wait(1).to({graphics:mask_2_graphics_93,x:148.7792,y:124.684}).wait(1).to({graphics:mask_2_graphics_94,x:148.5906,y:124.8715}).wait(1).to({graphics:mask_2_graphics_95,x:148.4019,y:125.0589}).wait(1).to({graphics:mask_2_graphics_96,x:148.2263,y:125.2335}).wait(1).to({graphics:mask_2_graphics_97,x:148.0636,y:125.3951}).wait(1).to({graphics:mask_2_graphics_98,x:147.914,y:125.5438}).wait(1).to({graphics:mask_2_graphics_99,x:147.7774,y:120.7295}).wait(1).to({graphics:mask_2_graphics_100,x:147.6538,y:115.7793}).wait(1).to({graphics:mask_2_graphics_101,x:147.5432,y:111.3502}).wait(1).to({graphics:mask_2_graphics_102,x:147.4456,y:107.4422}).wait(1).to({graphics:mask_2_graphics_103,x:147.361,y:104.0552}).wait(1).to({graphics:mask_2_graphics_104,x:147.2895,y:101.1894}).wait(1).to({graphics:mask_2_graphics_105,x:147.2309,y:98.8445}).wait(1).to({graphics:mask_2_graphics_106,x:147.1854,y:97.0208}).wait(1).to({graphics:mask_2_graphics_107,x:147.1529,y:95.7181}).wait(1).to({graphics:mask_2_graphics_108,x:147.1333,y:94.9365}).wait(1).to({graphics:mask_2_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_2_graphics_135,x:147.1518,y:94.651}).wait(41));

	// Grass
	this.instance_2 = new lib.grass();
	this.instance_2.setTransform(166.15,295.7,1,1,0,0,0,186,63);

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_2;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(79).to({regX:186.2,regY:63.1,scaleX:0.7513,scaleY:0.6595,x:163.55,y:150.1},30,cjs.Ease.quadInOut).wait(67));

	// Head
	this.instance_3 = new lib.DinoHead("single",0);
	this.instance_3.setTransform(221.65,55.2,1.5085,1.5085,-2.4268,0,0,50.3,75.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).to({regX:50.2,regY:75.4,rotation:0,x:221.5,y:55.05,mode:"synched",loop:false},24,cjs.Ease.cubicInOut).to({y:58.7,startPosition:5},5,cjs.Ease.quadInOut).wait(1).to({regX:2.4,regY:105.9,x:149.35,y:104.4,startPosition:6},0).wait(1).to({y:103.65,startPosition:7},0).wait(1).to({y:102.35,startPosition:8},0).wait(1).to({y:100.55,startPosition:9},0).wait(1).to({y:98.15,startPosition:10},0).wait(1).to({y:95.15,startPosition:11},0).wait(1).to({y:91.7,startPosition:12},0).wait(1).to({y:88.05,startPosition:13},0).wait(1).to({y:84.45,startPosition:14},0).wait(1).to({y:81.25,startPosition:15},0).wait(1).to({regX:50.2,regY:75.4,x:221.5,y:32.45,startPosition:16},0).wait(1).to({regX:2.4,regY:105.9,x:149.35,y:76.2,startPosition:17},0).wait(1).to({y:74.45,startPosition:18},0).wait(1).to({y:73.2,startPosition:19},0).wait(1).to({y:72.45,startPosition:20},0).wait(1).to({regX:50.2,regY:75.4,x:221.5,y:26.05,startPosition:21},0).to({regX:50.3,regY:75.2,rotation:-3.5202,x:221.65,y:32.75,startPosition:30},9,cjs.Ease.cubicIn).to({regY:75.3,rotation:-6.7386,y:33,mode:"single",startPosition:52},25,cjs.Ease.cubicOut).to({regY:75.5,scaleX:0.54,scaleY:0.54,rotation:-6.5521,x:164.9,y:63.15,startPosition:54},30,cjs.Ease.quadInOut).wait(15).to({startPosition:54},0).to({rotation:-9.4873,y:65.2,mode:"synched",startPosition:59,loop:false},9,cjs.Ease.quadInOut).to({regX:50.4,rotation:2.8719,x:164.95,y:59.1,startPosition:73},14,cjs.Ease.quadInOut).to({regX:50.1,rotation:-4.5738,x:164.8,y:63.2,startPosition:97},17,cjs.Ease.quadInOut).wait(12));

	// Body
	this.instance_4 = new lib.rexBody();
	this.instance_4.setTransform(186.4,235.05,1.3916,1.3916,0,0,0,58.1,159.6);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(24).to({y:235.95},5,cjs.Ease.quadInOut).to({regY:159.7,scaleY:1.4362,y:233.45},12,cjs.Ease.quadInOut).to({regY:159.6,scaleY:1.3916,y:235.05},16,cjs.Ease.quadInOut).wait(22).to({regX:58.3,regY:159.8,scaleX:0.5154,scaleY:0.5154,x:152.3,y:136.85},30,cjs.Ease.quadInOut).wait(15).to({regY:159.9,scaleY:0.4978,y:136.95},9,cjs.Ease.quadInOut).to({regY:160.1,scaleY:0.5331},14,cjs.Ease.quadInOut).to({regY:159.8,scaleY:0.5154,y:136.85},17,cjs.Ease.quadInOut).wait(12));

	// ScreenMaskA copy 3 (mask)
	var mask_3 = new cjs.Shape();
	mask_3._off = true;
	var mask_3_graphics_0 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_3_graphics_79 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_3_graphics_80 = new cjs.Graphics().p("EgXdAu3MAAAhdtMAu7AAAMAAABdtg");
	var mask_3_graphics_81 = new cjs.Graphics().p("EgXbAunMAAAhdNMAu3AAAMAAABdNg");
	var mask_3_graphics_82 = new cjs.Graphics().p("EgXVAuNMAAAhcZMAuxAAAMAAABcZg");
	var mask_3_graphics_83 = new cjs.Graphics().p("EgXMAtoMAAAhbPMAuoAAAMAAABbPg");
	var mask_3_graphics_84 = new cjs.Graphics().p("EgXBAs4MAAAhZvMAucAAAMAAABZvg");
	var mask_3_graphics_85 = new cjs.Graphics().p("EgWzAr+MAAAhX7MAuNAAAMAAABX7g");
	var mask_3_graphics_86 = new cjs.Graphics().p("EgWiAq6MAAAhVzMAt7AAAMAAABVzg");
	var mask_3_graphics_87 = new cjs.Graphics().p("EgWQAprMAAAhTVMAtoAAAMAAABTVg");
	var mask_3_graphics_88 = new cjs.Graphics().p("EgV6AoRMAAAhQhMAtRAAAMAAABQhg");
	var mask_3_graphics_89 = new cjs.Graphics().p("EgViAmtMAAAhNZMAs4AAAMAAABNZg");
	var mask_3_graphics_90 = new cjs.Graphics().p("EgVIAk+MAAAhJ7MAsdAAAMAAABJ7g");
	var mask_3_graphics_91 = new cjs.Graphics().p("EgUrAjFMAAAhGJMAr+AAAMAAABGJg");
	var mask_3_graphics_92 = new cjs.Graphics().p("EgULAhBMAAAhCBMArdAAAMAAABCBg");
	var mask_3_graphics_93 = new cjs.Graphics().p("AzpeyMAAAg9jMAq5AAAMAAAA9jg");
	var mask_3_graphics_94 = new cjs.Graphics().p("AzFcZMAAAg4xMAqTAAAMAAAA4xg");
	var mask_3_graphics_95 = new cjs.Graphics().p("AygaAMAAAgz/MApsAAAMAAAAz/g");
	var mask_3_graphics_96 = new cjs.Graphics().p("Ax+XyMAAAgvjMApIAAAMAAAAvjg");
	var mask_3_graphics_97 = new cjs.Graphics().p("AxfVuMAAAgrbMAooAAAMAAAArbg");
	var mask_3_graphics_98 = new cjs.Graphics().p("AxCT1MAAAgnpMAoJAAAMAAAAnpg");
	var mask_3_graphics_99 = new cjs.Graphics().p("AwoS3MAAAgkKMAnuAAAMAAAAkKg");
	var mask_3_graphics_100 = new cjs.Graphics().p("AwQSGMAAAghCMAnVAAAMAAAAhCg");
	var mask_3_graphics_101 = new cjs.Graphics().p("Av6RaIAA+PMAm9AAAIAAePg");
	var mask_3_graphics_102 = new cjs.Graphics().p("AvnQyIAA7wMAmpAAAIAAbwg");
	var mask_3_graphics_103 = new cjs.Graphics().p("AvXQRIAA5oMAmZAAAIAAZog");
	var mask_3_graphics_104 = new cjs.Graphics().p("AvJP0IAA3zMAmKAAAIAAXzg");
	var mask_3_graphics_105 = new cjs.Graphics().p("Au+PcIAA2UMAl+AAAIAAWUg");
	var mask_3_graphics_106 = new cjs.Graphics().p("Au1PKIAA1KMAl1AAAIAAVKg");
	var mask_3_graphics_107 = new cjs.Graphics().p("AuvO9IAA0WMAlvAAAIAAUWg");
	var mask_3_graphics_108 = new cjs.Graphics().p("AurO1IAAz2MAlqAAAIAAT2g");
	var mask_3_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_3_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_3).to({graphics:mask_3_graphics_0,x:149.8293,y:123.417}).wait(79).to({graphics:mask_3_graphics_79,x:149.8293,y:123.417}).wait(1).to({graphics:mask_3_graphics_80,x:149.8825,y:123.4235}).wait(1).to({graphics:mask_3_graphics_81,x:150.0283,y:123.4428}).wait(1).to({graphics:mask_3_graphics_82,x:149.9958,y:123.4752}).wait(1).to({graphics:mask_3_graphics_83,x:149.9502,y:123.5204}).wait(1).to({graphics:mask_3_graphics_84,x:149.8917,y:123.5786}).wait(1).to({graphics:mask_3_graphics_85,x:149.8201,y:123.6497}).wait(1).to({graphics:mask_3_graphics_86,x:149.7356,y:123.7337}).wait(1).to({graphics:mask_3_graphics_87,x:149.638,y:123.8307}).wait(1).to({graphics:mask_3_graphics_88,x:149.5274,y:123.9406}).wait(1).to({graphics:mask_3_graphics_89,x:149.4038,y:124.0634}).wait(1).to({graphics:mask_3_graphics_90,x:149.2672,y:124.1992}).wait(1).to({graphics:mask_3_graphics_91,x:149.1175,y:124.3479}).wait(1).to({graphics:mask_3_graphics_92,x:148.9549,y:124.5095}).wait(1).to({graphics:mask_3_graphics_93,x:148.7792,y:124.684}).wait(1).to({graphics:mask_3_graphics_94,x:148.5906,y:124.8715}).wait(1).to({graphics:mask_3_graphics_95,x:148.4019,y:125.0589}).wait(1).to({graphics:mask_3_graphics_96,x:148.2263,y:125.2335}).wait(1).to({graphics:mask_3_graphics_97,x:148.0636,y:125.3951}).wait(1).to({graphics:mask_3_graphics_98,x:147.914,y:125.5438}).wait(1).to({graphics:mask_3_graphics_99,x:147.7774,y:120.7295}).wait(1).to({graphics:mask_3_graphics_100,x:147.6538,y:115.7793}).wait(1).to({graphics:mask_3_graphics_101,x:147.5432,y:111.3502}).wait(1).to({graphics:mask_3_graphics_102,x:147.4456,y:107.4422}).wait(1).to({graphics:mask_3_graphics_103,x:147.361,y:104.0552}).wait(1).to({graphics:mask_3_graphics_104,x:147.2895,y:101.1894}).wait(1).to({graphics:mask_3_graphics_105,x:147.2309,y:98.8445}).wait(1).to({graphics:mask_3_graphics_106,x:147.1854,y:97.0208}).wait(1).to({graphics:mask_3_graphics_107,x:147.1529,y:95.7181}).wait(1).to({graphics:mask_3_graphics_108,x:147.1333,y:94.9365}).wait(1).to({graphics:mask_3_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_3_graphics_135,x:147.1518,y:94.651}).wait(41));

	// BGMountain
	this.instance_5 = new lib.bgMounts();
	this.instance_5.setTransform(16.7,150.55,1.8594,1.8594,0,0,0,155.4,99);

	var maskedShapeInstanceList = [this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_3;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(79).to({regX:155.3,scaleX:0.8242,scaleY:0.8242,x:167.9,y:158.75},30,cjs.Ease.quadInOut).wait(67));

	// ScreenMaskA copy 4 (mask)
	var mask_4 = new cjs.Shape();
	mask_4._off = true;
	var mask_4_graphics_0 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_4_graphics_79 = new cjs.Graphics().p("EgXeAu8MAAAhd3MAu9AAAMAAABd3g");
	var mask_4_graphics_80 = new cjs.Graphics().p("EgXdAu3MAAAhdtMAu7AAAMAAABdtg");
	var mask_4_graphics_81 = new cjs.Graphics().p("EgXbAunMAAAhdNMAu3AAAMAAABdNg");
	var mask_4_graphics_82 = new cjs.Graphics().p("EgXVAuNMAAAhcZMAuxAAAMAAABcZg");
	var mask_4_graphics_83 = new cjs.Graphics().p("EgXMAtoMAAAhbPMAuoAAAMAAABbPg");
	var mask_4_graphics_84 = new cjs.Graphics().p("EgXBAs4MAAAhZvMAucAAAMAAABZvg");
	var mask_4_graphics_85 = new cjs.Graphics().p("EgWzAr+MAAAhX7MAuNAAAMAAABX7g");
	var mask_4_graphics_86 = new cjs.Graphics().p("EgWiAq6MAAAhVzMAt7AAAMAAABVzg");
	var mask_4_graphics_87 = new cjs.Graphics().p("EgWQAprMAAAhTVMAtoAAAMAAABTVg");
	var mask_4_graphics_88 = new cjs.Graphics().p("EgV6AoRMAAAhQhMAtRAAAMAAABQhg");
	var mask_4_graphics_89 = new cjs.Graphics().p("EgViAmtMAAAhNZMAs4AAAMAAABNZg");
	var mask_4_graphics_90 = new cjs.Graphics().p("EgVIAk+MAAAhJ7MAsdAAAMAAABJ7g");
	var mask_4_graphics_91 = new cjs.Graphics().p("EgUrAjFMAAAhGJMAr+AAAMAAABGJg");
	var mask_4_graphics_92 = new cjs.Graphics().p("EgULAhBMAAAhCBMArdAAAMAAABCBg");
	var mask_4_graphics_93 = new cjs.Graphics().p("AzpeyMAAAg9jMAq5AAAMAAAA9jg");
	var mask_4_graphics_94 = new cjs.Graphics().p("AzFcZMAAAg4xMAqTAAAMAAAA4xg");
	var mask_4_graphics_95 = new cjs.Graphics().p("AygaAMAAAgz/MApsAAAMAAAAz/g");
	var mask_4_graphics_96 = new cjs.Graphics().p("Ax+XyMAAAgvjMApIAAAMAAAAvjg");
	var mask_4_graphics_97 = new cjs.Graphics().p("AxfVuMAAAgrbMAooAAAMAAAArbg");
	var mask_4_graphics_98 = new cjs.Graphics().p("AxCT1MAAAgnpMAoJAAAMAAAAnpg");
	var mask_4_graphics_99 = new cjs.Graphics().p("AwoS3MAAAgkKMAnuAAAMAAAAkKg");
	var mask_4_graphics_100 = new cjs.Graphics().p("AwQSGMAAAghCMAnVAAAMAAAAhCg");
	var mask_4_graphics_101 = new cjs.Graphics().p("Av6RaIAA+PMAm9AAAIAAePg");
	var mask_4_graphics_102 = new cjs.Graphics().p("AvnQyIAA7wMAmpAAAIAAbwg");
	var mask_4_graphics_103 = new cjs.Graphics().p("AvXQRIAA5oMAmZAAAIAAZog");
	var mask_4_graphics_104 = new cjs.Graphics().p("AvJP0IAA3zMAmKAAAIAAXzg");
	var mask_4_graphics_105 = new cjs.Graphics().p("Au+PcIAA2UMAl+AAAIAAWUg");
	var mask_4_graphics_106 = new cjs.Graphics().p("Au1PKIAA1KMAl1AAAIAAVKg");
	var mask_4_graphics_107 = new cjs.Graphics().p("AuvO9IAA0WMAlvAAAIAAUWg");
	var mask_4_graphics_108 = new cjs.Graphics().p("AurO1IAAz2MAlqAAAIAAT2g");
	var mask_4_graphics_109 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");
	var mask_4_graphics_135 = new cjs.Graphics().p("AuqOzIAAzsMAlqAAAIAATsg");

	this.timeline.addTween(cjs.Tween.get(mask_4).to({graphics:mask_4_graphics_0,x:149.8293,y:123.417}).wait(79).to({graphics:mask_4_graphics_79,x:149.8293,y:123.417}).wait(1).to({graphics:mask_4_graphics_80,x:149.8825,y:123.4235}).wait(1).to({graphics:mask_4_graphics_81,x:150.0283,y:123.4428}).wait(1).to({graphics:mask_4_graphics_82,x:149.9958,y:123.4752}).wait(1).to({graphics:mask_4_graphics_83,x:149.9502,y:123.5204}).wait(1).to({graphics:mask_4_graphics_84,x:149.8917,y:123.5786}).wait(1).to({graphics:mask_4_graphics_85,x:149.8201,y:123.6497}).wait(1).to({graphics:mask_4_graphics_86,x:149.7356,y:123.7337}).wait(1).to({graphics:mask_4_graphics_87,x:149.638,y:123.8307}).wait(1).to({graphics:mask_4_graphics_88,x:149.5274,y:123.9406}).wait(1).to({graphics:mask_4_graphics_89,x:149.4038,y:124.0634}).wait(1).to({graphics:mask_4_graphics_90,x:149.2672,y:124.1992}).wait(1).to({graphics:mask_4_graphics_91,x:149.1175,y:124.3479}).wait(1).to({graphics:mask_4_graphics_92,x:148.9549,y:124.5095}).wait(1).to({graphics:mask_4_graphics_93,x:148.7792,y:124.684}).wait(1).to({graphics:mask_4_graphics_94,x:148.5906,y:124.8715}).wait(1).to({graphics:mask_4_graphics_95,x:148.4019,y:125.0589}).wait(1).to({graphics:mask_4_graphics_96,x:148.2263,y:125.2335}).wait(1).to({graphics:mask_4_graphics_97,x:148.0636,y:125.3951}).wait(1).to({graphics:mask_4_graphics_98,x:147.914,y:125.5438}).wait(1).to({graphics:mask_4_graphics_99,x:147.7774,y:120.7295}).wait(1).to({graphics:mask_4_graphics_100,x:147.6538,y:115.7793}).wait(1).to({graphics:mask_4_graphics_101,x:147.5432,y:111.3502}).wait(1).to({graphics:mask_4_graphics_102,x:147.4456,y:107.4422}).wait(1).to({graphics:mask_4_graphics_103,x:147.361,y:104.0552}).wait(1).to({graphics:mask_4_graphics_104,x:147.2895,y:101.1894}).wait(1).to({graphics:mask_4_graphics_105,x:147.2309,y:98.8445}).wait(1).to({graphics:mask_4_graphics_106,x:147.1854,y:97.0208}).wait(1).to({graphics:mask_4_graphics_107,x:147.1529,y:95.7181}).wait(1).to({graphics:mask_4_graphics_108,x:147.1333,y:94.9365}).wait(1).to({graphics:mask_4_graphics_109,x:147.1518,y:94.651}).wait(26).to({graphics:mask_4_graphics_135,x:147.1518,y:94.651}).wait(41));

	// MergedLayer_1
	this.instance_6 = new lib.MergedSkylin();
	this.instance_6.setTransform(130.05,-71.55,1,1.8296,0,0,0,172.2,67.5);

	var maskedShapeInstanceList = [this.instance_6];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask_4;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(79).to({scaleX:0.7852,scaleY:0.7852,x:166.1,y:87.6},30,cjs.Ease.quadInOut).wait(67));

	// ScreenBG
	this.instance_7 = new lib.ScreenBGjpgcopy();
	this.instance_7.setTransform(0,23.2);

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(176));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.4,-177,300.5,600.9);


(lib.screenanimation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
		/*this.title_s.cache(-38,-15.7,152,63,2);
		this.title.cache(-38,-15.7,152,63,2);*/
	}
	this.frame_88 = function() {
		exportRoot.tlLogo.to(exportRoot.mainMC.logo_intro.msoftLogoWhite, 0.3, { alpha: 0}, "-=0");
	}
	this.frame_120 = function() {
		exportRoot.tl1.play();
	}
	this.frame_187 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(88).call(this.frame_88).wait(32).call(this.frame_120).wait(67).call(this.frame_187).wait(1));

	// Icon
	this.instance = new lib.Icon_1();
	this.instance.setTransform(24.9,253.85,1.1518,1.1518,0,0,0,50.1,50.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(110).to({_off:false},0).to({scaleX:0.8813,scaleY:0.8813,x:36.9,y:275.45,alpha:1},15,cjs.Ease.quartOut).wait(63));

	// Screen
	this.instance_1 = new lib.MainScreen("synched",0,false);
	this.instance_1.setTransform(58.6,191.8,1,1,0,0,0,58.6,14.8);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(89).to({startPosition:89},0).to({regX:58.8,regY:15,scaleX:0.9521,scaleY:0.8818,skewX:-29.3082,skewY:-16.7773,x:81.7,y:253.9,startPosition:119},30,cjs.Ease.quadInOut).wait(69));

	// Shadow
	this.instance_2 = new lib.shadow();
	this.instance_2.setTransform(204.3,290.6,1.2861,1.2861,0,0,0,176.6,127.5);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(105).to({_off:false},0).to({alpha:1},14,cjs.Ease.quadOut).wait(69));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-63.4,0,535.7,605.4);


(lib.mainMC = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Text
	this.txt_mc = new lib.txt_mc();
	this.txt_mc.name = "txt_mc";
	this.txt_mc.setTransform(70.5,70.55,1,1,0,0,0,70.5,70.5);

	this.timeline.addTween(cjs.Tween.get(this.txt_mc).wait(1));

	// MSoftLogo
	this.logo_intro = new lib.logos();
	this.logo_intro.name = "logo_intro";
	this.logo_intro.setTransform(58.05,21,0.3087,0.3087,0,0,0,0.1,0);

	this.timeline.addTween(cjs.Tween.get(this.logo_intro).wait(1));

	// screen
	this.screen = new lib.screenanimation();
	this.screen.name = "screen";
	this.screen.setTransform(197.1,130.8,1,1,0,0,0,197.1,130.8);

	this.timeline.addTween(cjs.Tween.get(this.screen).wait(1));

	// replay
	this.replay_btn = new lib.replay_btn();
	this.replay_btn.name = "replay_btn";
	this.replay_btn.setTransform(284.3,3.95,0.3475,0.3475,0,0,180,-0.3,0);

	this.timeline.addTween(cjs.Tween.get(this.replay_btn).wait(1));

	// CTA
	this.txtCta = new lib.cta();
	this.txtCta.name = "txtCta";
	this.txtCta.setTransform(235.9,552.55,1,1,0,0,0,0.7,0.1);

	this.timeline.addTween(cjs.Tween.get(this.txtCta).wait(1));

	// CTA_BG
	this.cta = new lib.CTA_btn();
	this.cta.name = "cta";
	this.cta.setTransform(301.25,551.7,1.1404,1.1404,0,0,0,0.3,0.3);

	this.timeline.addTween(cjs.Tween.get(this.cta).wait(1));

	// txt
	this.txt = new lib.txt();
	this.txt.name = "txt";

	this.timeline.addTween(cjs.Tween.get(this.txt).wait(1));

	// Ribbon
	this.ribbon = new lib.ribbon();
	this.ribbon.name = "ribbon";
	this.ribbon.setTransform(-17.55,-5.2);

	this.timeline.addTween(cjs.Tween.get(this.ribbon).wait(1));

	// Layer_2
	this.bg = new lib.BG_gray();
	this.bg.name = "bg";
	this.bg.setTransform(150,300,1,1,0,0,0,150,300);

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.mainMC, new cjs.Rectangle(-272.2,-18,728.9,854.5), null);


// stage content:
(lib.M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var mc = exportRoot.mainMC
		exportRoot.replayAnim = "inProgress"
		
		
		this.initBanner = function (data) {
			
			exportRoot.isReplay = false;
			exportRoot.shadowReplay = false;
			
			Object.keys = function(obj) {
				var keys = [];
		
				for (var i in obj) {
				  if (obj.hasOwnProperty(i)) {
					keys.push(i);
				  }
				}
				return keys
			}
			var keys = Object.keys(data)
			
				for (var i in keys) {
					var id = keys[i].substr(0, 4);
						if (id == "head") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillHead(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "word") {
							exportRoot['' + keys[i]] = new Array()
							exportRoot.fillDocument(data[keys[i]], exportRoot['' + keys[i]])
						} else if (id == "CTA" && data[keys[i]].length > 1) {
							exportRoot.fillCta(data[keys[i]])
						} else if (id == "CTAa") {
							mc.cta.arrow.visible = data[keys[i]][0]
							mc.cta.arrow.x += data[keys[i]][1]
							mc.cta.arrow.y += data[keys[i]][2]
						}
				}
		}
		
		
		this.fillHead = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.txt.addChild(mc);
				aVar.push(mc)
			}
		}
		this.fillDocument = function (txtDetails, aVar) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += parseInt(size)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.8)
				exportRoot.mainMC.addChild(mc);
				aVar.push(mc)
			}
		}
		
		
		
		this.fillCta = function (txtDetails) {
			var text = txtDetails[0]
			var size = txtDetails[1]
			var xOffset = txtDetails[2]
			var yOffset = txtDetails[3]
			var lineSpacing = txtDetails[4]
			var lineWidth = txtDetails[5]
			var align = txtDetails[6]
		
		
			var aSentenceLine = this.getTheSentences(text, size, xOffset, yOffset, lineSpacing, lineWidth, align)
		
			for (var i = 0; i < aSentenceLine.length; i++) {
				var mc = new createjs.MovieClip();
				mc.y = (i * parseInt(lineSpacing))
				mc.y += yOffset
				mc.y += (parseInt(size) * 0.90)
				mc.x += xOffset
		
				var txtWidth = 0
				for (var j = 0; j < aSentenceLine[i].length; j++) {
					var text = new createjs.Text(aSentenceLine[i][j].txt, "normal " + size + " Segoe Pro", aSentenceLine[i][j].color);
					text.textAlign = "Left"
					text.x = txtWidth
					text.textBaseline = "alphabetic"
					txtWidth += (text.getTransformedBounds().width)
					mc.addChild(text)
				}
				if (align == "center") mc.x = mc.x - mc.getTransformedBounds().width / 2
				if (align == "right") mc.x = mc.x - mc.getTransformedBounds().width
				mc.y = mc.y - (mc.getTransformedBounds().height / 2)
				if (mc.getTransformedBounds()) mc.cache(mc.getTransformedBounds().width*-1,mc.getTransformedBounds().height*-1,mc.getTransformedBounds().width*2,mc.getTransformedBounds().height*2,1.5)
				this.mainMC.txtCta.addChild(mc);
			}
		}
		
		this.getTheSentences = function (text, size, xOffset, yOffset, lineSpacing, lineWidth, align) {
			var sentences = new Array()
			var aSentenceLine = new Array()
			var aStr = text.substr(0);
			sentences = aStr.split("|");
			var lastColor = "#000000"
			// Figure out the setence lines
		
			for (var i = 0; i < sentences.length; i++) {
				var aS = sentences[i].substr(0);
				var aSplit = new Array()
				aSplit = aS.split("<");
				aSplit = aSplit.filter(Boolean)
				var wholeSentence = new Array()
		
				for (var j = 0; j < aSplit.length; j++) {
		
					var checkColor = aSplit[j].indexOf("#")
					var color = (checkColor == -1) ? lastColor : aSplit[j].substr(0, 7);
					lastColor = color
					var txt = (checkColor == -1) ? aSplit[j].substr(0) : aSplit[j].substr(8);
					var subSentence = {
						color: color,
						txt: txt
					};
					wholeSentence.push(subSentence)
				}
				aSentenceLine.push(wholeSentence)
			}
			return aSentenceLine
		}
		
		
		var mc = exportRoot.mainMC;
		var screen = mc.screen;
		var ribbon = mc.ribbon;
		
		
		
		this.runBanner = function() {
			
			this.tlLogo = new TimelineLite();
			this.tl1 = new TimelineLite();
						
				exportRoot.tl1.from(screen, 0.5, { alpha: 1, ease:Power3.easeOut,onStart: function() {;screen.gotoAndPlay(1)}, onComplete: function() {exportRoot.tl1.pause()}}, "+=0.5");
				
				
				exportRoot.tl1.to(screen, 0.3, { alpha: 1, ease:Power3.easeInOut,onComplete:function(){ribbon.gotoAndPlay(0);}}, "-=0");
		
			
				for (var i = 0; i < exportRoot.headline1.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.3");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline1[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
		
				for (var i = 0; i < exportRoot.headline2.length; i++) {
				if (i==0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				if (i!=0) exportRoot.tl1.from(exportRoot.headline2[i], 0.8, { x: "-=100", alpha: 0, ease:Power4.easeOut}, "-=0.7");
				}
				
				
				exportRoot.tl1.from(mc.txtCta, 0.7, { alpha: 0, x: "-=100",	ease:Power4.easeOut}, "-=0.5");
				exportRoot.tl1.from(mc.cta, 0.7, {alpha: 0, x: "-=100", ease:Power4.easeOut}, "-=0.7");
				exportRoot.tl1.from(mc.replay_btn, 0.7, { alpha: 0,ease:Power4.easeOut, onStart:function(){exportRoot.isReplay = true;}}, "-=.6");	
		
				exportRoot.tl1.stop();	
		
			mc.logo_intro.gotoAndPlay(1)
			
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// mainMC
	this.mainMC = new lib.mainMC();
	this.mainMC.name = "mainMC";
	this.mainMC.setTransform(0,0.1,1,1,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get(this.mainMC).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-122.2,282,578.9,554.5);
// library properties:
lib.properties = {
	id: '90A26FE74B042E4A89CA750D1DA2DF1F',
	width: 300,
	height: 600,
	fps: 40,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_.png?1593094085372", id:"M365_FY21Q1_BTS_USA_300x600_BAN_3DPPT_English_NA_NA_ANI_BN_NA_1_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['90A26FE74B042E4A89CA750D1DA2DF1F'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;